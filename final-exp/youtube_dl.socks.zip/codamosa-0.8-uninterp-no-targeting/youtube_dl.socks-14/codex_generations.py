

# Generated at 2022-06-22 09:31:46.774028
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()

# Generated at 2022-06-22 09:31:49.388539
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    exception = InvalidVersionError(expected_version=1, got_version=2)
    # Verify that there's a message in the exception.
    assert exception.message != ''

# Generated at 2022-06-22 09:31:53.976330
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    socks5_auth = Socks5Auth()
    assert socks5_auth.AUTH_NONE == 0x00
    assert socks5_auth.AUTH_GSSAPI == 0x01
    assert socks5_auth.AUTH_USER_PASS == 0x02
    assert socks5_auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:32:05.809061
# Unit test for constructor of class ProxyError
def test_ProxyError():
    # Test regular constructor
    err = ProxyError(Socks4Error.ERR_SUCCESS, 'TestMessage')
    assert err.args[0] == Socks4Error.ERR_SUCCESS
    assert err.args[1] == 'TestMessage'
    assert str(err) == '[Errno {0}] TestMessage'.format(Socks4Error.ERR_SUCCESS)
    # Test new style constructor
    err = ProxyError(msg='TestMessage')
    assert err.args[0] is None
    assert err.args[1] == 'TestMessage'
    assert str(err) == 'TestMessage'
    # Test new style constructor with unknown code
    err = ProxyError(code=42, msg='TestMessage')
    assert err.args[0] == 42

# Generated at 2022-06-22 09:32:11.730644
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    # Test SOCKS4 proxy
    proxy = Proxy(ProxyType.SOCKS4, '8.8.8.8', 8888)
    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == '8.8.8.8'
    assert proxy.port == 8888

    proxy = Proxy(ProxyType.SOCKS4, '8.8.8.8', 8888, 'user', 'pass', False)
    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == '8.8.8.8'
    assert proxy.port == 8888
    assert proxy.username == 'user'
    assert proxy.password == 'pass'
    assert not proxy.remote_dns

    # Test SOCKS4A proxy

# Generated at 2022-06-22 09:32:18.802846
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    # Test for invalid code
    try:
        invalid_code_error = Socks4Error(123)
    except ProxyError as e:
        assert e.__str__() == '123: unknown error'
    else:
        assert False

    # Test for valid code
    success_error = Socks4Error(Socks4Error.ERR_SUCCESS)
    assert success_error.__str__() == '90: request rejected or failed'



# Generated at 2022-06-22 09:32:19.339225
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    pass

# Generated at 2022-06-22 09:32:23.676678
# Unit test for constructor of class ProxyType
def test_ProxyType():
    x = ProxyType()
    assert x.SOCKS4 == 0
    assert x.SOCKS4A == 1
    assert x.SOCKS5 == 2


# Generated at 2022-06-22 09:32:25.674665
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    error = Socks5Error(5, 'connection refused')
    assert error.code == 5
    assert error.msg == 'connection refused'
    assert error.args == (5, 'connection refused')
    assert isinstance(error, socket.error)

# Generated at 2022-06-22 09:32:30.980933
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    auth = Socks5Auth()
    assert auth.AUTH_NONE == 0x00
    assert auth.AUTH_GSSAPI == 0x01
    assert auth.AUTH_USER_PASS == 0x02
    assert auth.AUTH_NO_ACCEPTABLE == 0xFF

# Generated at 2022-06-22 09:33:05.605645
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import random
    import string
    import unittest

    class SocksSocketTest(unittest.TestCase):

        def test_recvall(self):
            def rand_string(length):
                return ''.join([random.choice(string.ascii_letters + string.digits) for _ in range(length)])

            for _ in range(10):
                s = sockssocket()
                test_str = rand_string(random.randint(1024, 5000))
                s.sendall(test_str.encode('utf-8'))
                self.assertEqual(s.recvall(len(test_str.encode('utf-8'))).decode('utf-8'), test_str)
                s.close()

if __name__ == '__main__':
    unittest.main

# Generated at 2022-06-22 09:33:10.259544
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError().__repr__() == '<error(0, None)>'
    assert ProxyError(1).__repr__() == '<error(1, None)>'
    assert ProxyError(None, 'error1').__repr__() == '<error(None, error1)>'
    assert ProxyError(1, 'error1').__repr__() == '<error(1, error1)>'

if __name__ == '__main__':
    test_ProxyError()

# Generated at 2022-06-22 09:33:15.937470
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    error = InvalidVersionError(0, 0)
    assert error.args[1] == 'unknown error'
    error = InvalidVersionError(0, 0xFF)
    assert error.args[1] == 'Invalid response version from server. Expected 00 got ff'

# Generated at 2022-06-22 09:33:23.957382
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError()
    except ProxyError as e:
        assert isinstance(e, socket.error)
        assert e.message == 'unknown error'
        assert isinstance(e, ProxyError)
    try:
        raise ProxyError(1, 'test')
    except ProxyError as e:
        assert e.message == 'test'
    try:
        raise ProxyError(code=1)
    except ProxyError as e:
        assert e.message == 'unknown error'
    try:
        raise ProxyError(msg='test')
    except ProxyError as e:
        assert e.message == 'test'



# Generated at 2022-06-22 09:33:27.367697
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 255)
    except InvalidVersionError as e:
        assert str(e) == 'Invalid response version from server. Expected 00 got ff'



# Generated at 2022-06-22 09:33:28.541028
# Unit test for constructor of class ProxyType
def test_ProxyType():
    proxy_type = ProxyType.SOCKS5
    assert (proxy_type == 2)


# Generated at 2022-06-22 09:33:31.391820
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    msg = InvalidVersionError(0x00, 0xFF).strerror
    assert msg == 'Invalid response version from server. Expected 00 got ff'



# Generated at 2022-06-22 09:33:32.045238
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    Socks5Command()

# Generated at 2022-06-22 09:33:38.926373
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    e = Socks4Error()
    assert e.args[0] is None
    assert e.args[1] == 'success'
    
    e = Socks4Error(91)
    assert e.args[0] == 91
    assert e.args[1] == 'request rejected or failed'
    
    e = Socks4Error(code=92)
    assert e.args[0] == 92
    assert e.args[1] == 'request rejected because SOCKS server cannot connect to identd on the client'
    
    e = Socks4Error(msg='custom message')
    assert e.args[0] is None
    assert e.args[1] == 'custom message'

# Generated at 2022-06-22 09:33:40.800350
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:34:05.601830
# Unit test for constructor of class ProxyError
def test_ProxyError():
    with ProxyError(code=1) as e:
        assert e.errno == 1
        assert e.strerror == 'request rejected or failed'
        assert e.args == (1, 'request rejected or failed')
        assert str(e) == '1: request rejected or failed'



# Generated at 2022-06-22 09:34:09.353857
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND
    assert Socks5Command.CMD_UDP_ASSOCIATE != Socks4Command.CMD_BIND

# Generated at 2022-06-22 09:34:10.490797
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sockssocket()


# Generated at 2022-06-22 09:34:14.373753
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF



# Generated at 2022-06-22 09:34:16.576560
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2



# Generated at 2022-06-22 09:34:19.589657
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    expected_version = 0xFF
    got_version = 0xFE

    try:
        raise InvalidVersionError(expected_version, got_version)
    except InvalidVersionError as e:
        assert(expected_version == e.expected_version)
        assert(got_version == e.got_version)

# Generated at 2022-06-22 09:34:24.471628
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    print(Socks5AddressType.ATYP_IPV4)
    print(Socks5AddressType.ATYP_DOMAINNAME)
    print(Socks5AddressType.ATYP_IPV6)

# Generated at 2022-06-22 09:34:31.508980
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS5, '127.0.0.1', 1081, 'test', 'qwerty', True)
    assert proxy.type == ProxyType.SOCKS5
    assert proxy.host == '127.0.0.1'
    assert proxy.port == 1081
    assert proxy.username == 'test'
    assert proxy.password == 'qwerty'
    assert proxy.remote_dns

if __name__ == '__main__':
    import unittest
    import contextlib

    class SocksTest(unittest.TestCase):
        def test_socks4(self):
            with contextlib.closing(sockssocket()) as s:
                s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 1081)
                s

# Generated at 2022-06-22 09:34:42.848798
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    # test string '74.125.79.103'
    assert socket.inet_aton('74.125.79.103') == Socks5AddressType.ATYP_IPV4
    # test string 'www.google.com'
    assert len(socket.inet_aton('173.194.33.78')) == 4
    # test string 'google.com'
    assert len(socket.inet_aton('google.com')) == 4
    # test string '120.52.162.15'
    assert len(socket.inet_aton('120.52.162.15')) == 4
    # test string 'IPv6'
    assert len(socket.inet_aton('IPv6')) == 16


if __name__ == '__main__':
    test_Socks5AddressType()

    proxy = ProxyType.S

# Generated at 2022-06-22 09:34:48.030410
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.connect(('www.python.org', 80))
        sock.sendall(b'GET / HTTP/1.0\r\n\r\n')
        data = sock.recvall(100)
        assert len(data) == 100
        data = sock.recvall(100)
        assert len(data) == 100
        data = sock.recvall(100)
        assert len(data) == 100
        data = sock.recvall(100)
        assert len(data) == 100
    finally:
        sock.close()

# Generated at 2022-06-22 09:35:07.445665
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
	assert Socks5AddressType.ATYP_IPV4 == 0x01
	assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
	assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-22 09:35:15.521707
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import io
    s = sockssocket()
    # Create a mock socket object
    class mock_socket(io.BytesIO):
        def __init__(self, *args, **kwargs):
            super(mock_socket, self).__init__(*args, **kwargs)

        def recv(self, cnt):
            return super(mock_socket, self).read(cnt)

        def sendall(self, data):
            return super(mock_socket, self).write(data)

    s.__class__ = mock_socket
    s.__init__()
    s.write(b'123456789')
    s.seek(0)
    assert s.recvall(3) == b'123'
    assert s.recvall(4) == b'4567'

# Generated at 2022-06-22 09:35:19.856403
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    command = Socks5Command()
    assert command.CMD_CONNECT == 0x01
    assert command.CMD_BIND == 0x02
    assert command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-22 09:35:22.147858
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Unit tests for constructor and method of class Socks4Error

# Generated at 2022-06-22 09:35:31.698949
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert getattr(Socks5AddressType, 'ATYP_IPV4') == Socks5AddressType.ATYP_IPV4
    assert getattr(Socks5AddressType, 'ATYP_DOMAINNAME') == Socks5AddressType.ATYP_DOMAINNAME
    assert getattr(Socks5AddressType, 'ATYP_IPV6') == Socks5AddressType.ATYP_IPV6
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-22 09:35:40.380375
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    proxy_address = '127.0.0.1'
    proxy_port = 1080
    remote_address = 'www.google.com'
    remote_port = 80

    # Test invalid address
    invalid_address = '123.456.789.123'
    with sockssocket(socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP) as sock:
        sock.setproxy(ProxyType.SOCKS4, proxy_address, proxy_port)
        assert sock.connect_ex((invalid_address, remote_port)) == Socks4Error.ERR_SUCCESS

        # Non-existing server
        assert sock.connect_ex((invalid_address, 1)) == socket.error

if __name__ == '__main__':
    test_sockssocket_connect_ex()

# Generated at 2022-06-22 09:35:44.934779
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    try:
        s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    except:
        print('test_sockssocket_connect_ex: sockssocket init failed')
        return
    s.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 8080, rdns=False)
    try:
        print('test_sockssocket_connect_ex:', s.connect_ex(('127.0.0.1', 8080)))
    except:
        print('test_sockssocket_connect_ex: connect_ex failed')
    finally:
        s.close()

if __name__ == '__main__':
    test_sockssocket_connect_ex()

# Generated at 2022-06-22 09:35:57.193310
# Unit test for constructor of class ProxyType
def test_ProxyType():
    # Test for ProxyType.SOCKS4
    proxytype = ProxyType.SOCKS4
    assert proxytype == ProxyType.SOCKS4
    assert proxytype != ProxyType.SOCKS4A
    assert proxytype != ProxyType.SOCKS5
    # Test for ProxyType.SOCKS4A
    proxytype = ProxyType.SOCKS4A
    assert proxytype != ProxyType.SOCKS4
    assert proxytype == ProxyType.SOCKS4A
    assert proxytype != ProxyType.SOCKS5
    # Test for ProxyType.SOCKS5
    proxytype = ProxyType.SOCKS5
    assert proxytype != ProxyType.SOCKS4
    assert proxytype != ProxyType.SOCKS4A
    assert proxytype == ProxyType.SOCKS5

# Generated at 2022-06-22 09:36:04.860554
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    from .extractor import gen_extractors
    sockssocket_proxy = sockssocket()
    sockssocket_proxy.setproxy(ProxyType.SOCKS5, "127.0.0.1", 1080)
    assert sockssocket_proxy._proxy.type == ProxyType.SOCKS5
    assert sockssocket_proxy._proxy.host == "127.0.0.1"
    assert sockssocket_proxy._proxy.port == 1080
    assert sockssocket_proxy._proxy.username == None
    assert sockssocket_proxy._proxy.password == None
    assert sockssocket_proxy._proxy.remote_dns == True

# Generated at 2022-06-22 09:36:10.258597
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    port = 1080
    message = b'Hello, SOCKS proxy!'

    with socket.socket() as listener:
        listener.bind(('localhost', 0))
        listener.listen(1)
        connection_port = listener.getsockname()[1]

        with sockssocket() as client_socket:
            client_socket.setproxy(
                ProxyType.SOCKS4, 'localhost', port,
                username='hello', password='world', remote_dns=False)
            client_socket.connect(('localhost', connection_port))

            with listener.accept()[0] as server_socket:
                server_socket.sendall(message)

                assert client_socket.recv(len(message)) == message



# Generated at 2022-06-22 09:36:39.509813
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(SOCKS5_VERSION, SOCKS4_REPLY_VERSION)
    except InvalidVersionError as e:
        assert e.args[0] == 0
        assert e.args[1] == 'Invalid response version from server. Expected 05 got 00'
# Unit tests for class Socks4Error (static methods)

# Generated at 2022-06-22 09:36:45.535686
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(
        type=ProxyType.SOCKS5,
        host='',
        port=0,
        username='',
        password='',
        remote_dns=False,
    )
    assert proxy.type == ProxyType.SOCKS5
    assert proxy.host == ''
    assert proxy.port == 0
    assert proxy.username == ''
    assert proxy.password == ''
    assert proxy.remote_dns == False

# Generated at 2022-06-22 09:36:46.641334
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    pass


# Generated at 2022-06-22 09:36:52.097329
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError(code=None, msg=None) == ProxyError(0, 'unknown error')
    assert ProxyError(code=None, msg='something went wrong') == ProxyError(0, 'something went wrong')

    assert ProxyError(1).errno == 1
    assert ProxyError(msg='something went wrong').errno == 0


# Generated at 2022-06-22 09:36:55.710188
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    ssocket = sockssocket()
    ssocket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    ssocket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, username='username', password='password')



# Generated at 2022-06-22 09:36:56.578009
# Unit test for constructor of class ProxyType
def test_ProxyType():
    proxyType = ProxyType()


# Generated at 2022-06-22 09:36:58.828507
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    print("Successfully constructed a sockssocket")


# Generated at 2022-06-22 09:37:09.398428
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    socks_socket = sockssocket()

    # DNS request using SOCKS5 proxy
    socks_socket.setproxy(ProxyType.SOCKS5, '104.28.27.30', port=8080)
    assert socks_socket.connect_ex(('www.example.com', 80)) == 0

    # DNS request using SOCKS4 proxy
    socks_socket.setproxy(ProxyType.SOCKS4, '104.28.27.30', port=8080)
    assert socks_socket.connect_ex(('www.example.com', 80)) == 0

    # DNS request using SOCKS4a proxy
    socks_socket.setproxy(ProxyType.SOCKS4A, '104.28.27.30', port=8080)

# Generated at 2022-06-22 09:37:16.007445
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    cmd = Socks5Command()
    result = [cmd.CMD_CONNECT, cmd.CMD_BIND, cmd.CMD_UDP_ASSOCIATE]
    expected = [0x01, 0x02, 0x03]
    assert result == expected



# Generated at 2022-06-22 09:37:18.492816
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    error = InvalidVersionError(1, 2)
    assert error.errno == 0
    assert error.msg == 'Invalid response version from server. Expected 01 got 02'


# Generated at 2022-06-22 09:38:07.852744
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    assert s.connect_ex(('127.0.0.1', 80)) == 0


if __name__ == '__main__':
    test_sockssocket_connect_ex()

# Generated at 2022-06-22 09:38:10.193770
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:38:11.829584
# Unit test for constructor of class ProxyType
def test_ProxyType():
    proxy_type = ProxyType()
    assert hasattr(proxy_type, 'SOCKS4')
    assert hasattr(proxy_type, 'SOCKS4A')
    assert hasattr(proxy_type, 'SOCKS5')


# Generated at 2022-06-22 09:38:14.245857
# Unit test for constructor of class ProxyType
def test_ProxyType():
  pt = ProxyType()
  assert pt.SOCKS4 == 0
  assert pt.SOCKS4A == 1
  assert pt.SOCKS5 == 2


# Generated at 2022-06-22 09:38:17.204805
# Unit test for constructor of class ProxyError
def test_ProxyError():
    while True:
        try:
            raise ProxyError()
        except ProxyError as proxyError:
            assert proxyError.code is None and proxyError.msg is None
            break



# Generated at 2022-06-22 09:38:28.640641
# Unit test for constructor of class ProxyError
def test_ProxyError():
    pe=ProxyError()
    try:
        raise ProxyError()
    except ProxyError as err:
        pass
    assert pe.strerror==pe.msg
    assert pe.errno==pe.code
    assert pe.__class__.__name__=='ProxyError'
    assert err.strerror==err.msg
    assert err.errno==err.code
    assert err.__class__.__name__=='ProxyError'
    assert pe.strerror==err.strerror
    assert pe.errno==err.errno
    assert pe.__class__.__name__==err.__class__.__name__
    try:
        raise ProxyError(pe.errno, pe.strerror)
    except ProxyError as err:
        pass
    assert pe.strerror==err.st

# Generated at 2022-06-22 09:38:29.689930
# Unit test for constructor of class ProxyType
def test_ProxyType():
    pass


# Generated at 2022-06-22 09:38:40.654014
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # Create a Proxy
    _proxy = Proxy(ProxyType.SOCKS5, 'localhost', 1080, None, None, True)
    # Create a socket object
    sockssocketObject = sockssocket()
    # Set its proxy
    sockssocketObject.setproxy(_proxy.type, _proxy.host, _proxy.port, _proxy.remote_dns, _proxy.username, _proxy.password)
    # Test its method
    print('Result of testing method connect_ex of class sockssocket: ' + str(sockssocketObject.connect_ex(('baidu.com', 80))))

# Create a sockssocket object and set its proxy
_proxy = Proxy(ProxyType.SOCKS5, 'localhost', 1080, None, None, True)
sockssocketObject = sockssocket()

# Generated at 2022-06-22 09:38:47.563670
# Unit test for constructor of class Proxy
def test_Proxy():
    p = Proxy('a', 'b', 'c', 'd', 'e', 'f')
    assert p.type == 'a'
    assert p.host == 'b'
    assert p.port == 'c'
    assert p.username == 'd'
    assert p.password == 'e'
    assert p.remote_dns == 'f'



# Generated at 2022-06-22 09:38:49.321411
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    import pytest
    with pytest.raises(InvalidVersionError):
        raise InvalidVersionError(SOCKS5_VERSION, SOCKS4_VERSION)

# Generated at 2022-06-22 09:40:38.136768
# Unit test for constructor of class ProxyError
def test_ProxyError():
    with pytest.raises(ProxyError):
        raise ProxyError()

    with pytest.raises(ProxyError):
        raise ProxyError(91)


# Generated at 2022-06-22 09:40:40.644230
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    try:
        sockssocket.connect_ex(sockssocket(), ('', -1))
    except ProxyError as e:
        return True
    return False


# Generated at 2022-06-22 09:40:49.353568
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    from .compat import compat_httplib

    with sockssocket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.connect(('www.youtube.com', 80))
        sock.sendall(b'GET / HTTP/1.1\r\nHost: youtube.com\r\nConnection: close\r\n\r\n')
        response = b''
        while True:
            line = sock.recvall(1)
            response += line
            if line == b'\n' and compat_httplib.is_end_of_chunked_response(response):
                break
        assert response.startswith(b'HTTP/1.1 301')

# Generated at 2022-06-22 09:40:55.939978
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    # Test SOCKS4
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    ss.setproxy(ProxyType.SOCKS4, '127.0.0.1', 8080)
    assert ss._proxy == Proxy(ProxyType.SOCKS4, '127.0.0.1', 8080, None, None, True)

    # Test SOCKS4A
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    ss.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 8080, remote_dns=True)
    assert ss._proxy == Proxy(ProxyType.SOCKS4A, '127.0.0.1', 8080, None, None, True)

    # Test SOCK

# Generated at 2022-06-22 09:40:59.286782
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-22 09:41:03.361641
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy1 = Proxy(ProxyType.SOCKS4, '127.0.0.1', 5000)
    assert proxy1
    proxy2 = Proxy(
        ProxyType.SOCKS5, '192.168.1.1', 1080, 'testuser', 'testpassword', True)
    assert proxy2


# Generated at 2022-06-22 09:41:05.773489
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    error_code = 123
    exception = Socks4Error(error_code)

    assert exception.errno == error_code
    assert exception.args[0] == exception.errno
    assert exception.args[1] == exception.strerror


# Generated at 2022-06-22 09:41:16.790255
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()

    expected_proxy = Proxy(
        type=ProxyType.SOCKS4,
        host='127.0.0.1',
        port=1080,
        username='user',
        password='pass',
        remote_dns=False)
    s.setproxy(
        ProxyType.SOCKS4,
        username='user',
        password='pass',
        remote_dns=False,
        addr='127.0.0.1',
        port=1080)
    assert s._proxy == expected_proxy

    expected_proxy = Proxy(
        type=ProxyType.SOCKS4A,
        host='127.0.0.1',
        port=1080,
        username=None,
        password=None,
        remote_dns=True)

# Generated at 2022-06-22 09:41:22.043685
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
	s = Socks5Command.CMD_CONNECT
	s1 = Socks5Command.CMD_BIND
	
	print(s, s1);