

# Generated at 2022-06-22 09:31:54.252601
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    def connect_func(self, address):
        print('Connecting to', address)

    sockssocket.connect = connect_func
    ss = sockssocket()
    ss.setproxy(0, '127.0.0.1', 1234)
    ss.connect(('www.baidu.com', 80))

if __name__ == '__main__':
    test_sockssocket_connect()

# Generated at 2022-06-22 09:32:05.773277
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import socket, threading

    def server(sock):
        conn, addr = sock.accept()
        conn.sendall(b'ok')
        conn.close()

    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.setproxy(sockssocket.PROXY_TYPE_SOCKS4, '127.0.0.1', 1080)
    t = threading.Thread(target=server, args=(s,))
    t.daemon = True
    t.start()
    s.bind(('127.0.0.1', 0))
    s.listen(5)
    s.settimeout(3)

# Generated at 2022-06-22 09:32:07.645102
# Unit test for constructor of class ProxyType
def test_ProxyType():
    type = ProxyType()
    assert type.SOCKS4 == 0
    assert type.SOCKS4A == 1
    assert type.SOCKS5 == 2



# Generated at 2022-06-22 09:32:16.935637
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError == ProxyError.__new__(ProxyError)
    assert ProxyError(None, 'foo') == ProxyError(None, 'foo')
    assert ProxyError(None, 'foo') == ProxyError(None, 'foo')
    assert ProxyError(None, 'foo') != ProxyError(None, 'bar')
    assert ProxyError(None, 'foo') != ProxyError(1, 'foo')
    assert ProxyError(1, 'foo') != ProxyError(1, 'bar')

    with pytest.raises(ProxyError):
        raise ProxyError()
    with pytest.raises(ProxyError):
        raise ProxyError(None)
    with pytest.raises(ProxyError):
        raise ProxyError(None, 'foo')


# Generated at 2022-06-22 09:32:24.241158
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error() == Socks4Error(None, None)
    assert Socks4Error(code=91).message == 'request rejected or failed'
    assert Socks4Error(msg='msg').message == 'msg'
    assert Socks4Error(code=53, msg='msg').message == 'msg'
    assert Socks4Error(1).message == 'unknown error'



# Generated at 2022-06-22 09:32:26.986983
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(10, 20)
    except InvalidVersionError as e:
        assert e.errno == 0
        assert e.strerror == 'Invalid response version from server. Expected 0a got 14'


# Generated at 2022-06-22 09:32:30.436518
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:32:34.451806
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0x03, 0x04)
    except InvalidVersionError as iv:
        assert iv.errno == 0
        assert iv.strerror == 'Invalid response version from server. Expected 03 got 04'

# Generated at 2022-06-22 09:32:43.557035
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    _socks5auth_values = dir(Socks5Auth)
    assert len(_socks5auth_values) == 5, 'length of _socks5auth_values is not correct'
    assert 'AUTH_NONE' in _socks5auth_values, 'attribute AUTH_NONE is missing'
    assert 'AUTH_GSSAPI' in _socks5auth_values, 'attribute AUTH_GSSAPI is missing'
    assert 'AUTH_USER_PASS' in _socks5auth_values, 'attribute AUTH_USER_PASS is missing'
    assert 'AUTH_NO_ACCEPTABLE' in _socks5auth_values, 'attribute AUTH_NO_ACCEPTABLE is missing'
    assert '__doc__' in _socks5auth_values, 'attribute __doc__ is missing'
    assert isinstance

# Generated at 2022-06-22 09:32:46.336611
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 1)
    except InvalidVersionError as error:
        assert error.args == (0, 'Invalid response version from server. Expected 00 got 01')
    else:
        assert False

# Generated at 2022-06-22 09:33:05.481460
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    import os
    import random
    import socket
    import unittest

    # Default timeout in seconds for socket operations
    timeout = os.environ.get('SOCKS_TEST_TIMEOUT', 10)

    class ProxyTest(unittest.TestCase):
        def _make_socket(self, proxytype=ProxyType.SOCKS4, **kwargs):
            sock = sockssocket()
            sock.settimeout(timeout)
            sock.setproxy(proxytype, self.proxy_host, self.proxy_port, **kwargs)
            return sock

        def setUp(self):
            self.proxy_host = '127.0.0.1'
            self.proxy_port = random.randint(1025, 65535)
            self.server_host = '127.0.0.1'

# Generated at 2022-06-22 09:33:15.761020
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import sys
    import unittest
    from .compat import (
        compat_socket_create_connection
    )

    class _SocksSocketTest(unittest.TestCase):
        def test_sockssocket_recvall(self):
            s = sockssocket()
            s.setproxy(ProxyType.SOCKS4A, "138.68.185.212", 1080)
            s = compat_socket_create_connection((s, "youtube.com", 443))

# Generated at 2022-06-22 09:33:18.425082
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    s = Socks4Error(91)
    assert s.strerror == 'request rejected or failed'
    assert s.errno == 91


# Generated at 2022-06-22 09:33:24.179566
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss = sockssocket()
    assert ss.family == socket.AF_INET
    assert ss.type == socket.SOCK_STREAM
    assert ss.proto == 0
    assert ss.fileno() != -1

if __name__ == '__main__':
    test_sockssocket()

# Generated at 2022-06-22 09:33:27.495117
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error(91)
    assert Socks4Error(92)
    assert Socks4Error(93)

if __name__ == '__main__':
    test_Socks4Error()

# Generated at 2022-06-22 09:33:32.670889
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    host = '127.0.0.1'
    port = 1080

    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    s.sendall(compat_struct_pack('!B', 5))
    methods = s.recvall(1)[0]
    if methods != 1:
        raise Exception('Invalid authentication methods: %s' % methods)
    s.close()



# Generated at 2022-06-22 09:33:35.790492
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:33:39.108539
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    e = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    assert e.args[1] == 'general SOCKS server failure'

# Generated at 2022-06-22 09:33:49.009516
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    import random
    import types

    def is_port_open(ip, port):
        """
        Returns True if the port is open on the host IP
        """
        status = sockssocket().connect_ex((ip, port))
        if status == 0:
            return True
        else:
            return False

    # Test connection on port 4444 of localhost
    assert is_port_open(b'localhost', 4444)

    # Test connection on random port of localhost
    assert is_port_open(b'localhost', random.randint(2000, 3000))

    # Test connection error because the port is not open
    assert not is_port_open(b'localhost', random.randint(2000, 3000))

    # Test exception raised when ip is not provided

# Generated at 2022-06-22 09:33:49.637777
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    error = Socks5Error()

# Generated at 2022-06-22 09:34:09.870096
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    address = ('www.google.com', 80)
    proxy_type = ProxyType.SOCKS5
    proxy = Proxy(proxy_type, '127.0.0.1', 1080)
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.setproxy(proxy.type, proxy.host, proxy.port, rdns=proxy.remote_dns,
               username=proxy.username, password=proxy.password)
    s.connect(address)
    print('Connected to {}:{} via {} proxy {}:{}'.format(
        address[0], address[1], proxy_type.name, proxy.host, proxy.port))
    s.close()

# Generated at 2022-06-22 09:34:10.908666
# Unit test for constructor of class ProxyError
def test_ProxyError():
    ProxyError(1, 'test')

# Generated at 2022-06-22 09:34:14.594224
# Unit test for constructor of class Proxy
def test_Proxy():
    p = Proxy(ProxyType.SOCKS4, '192.168.1.1', 1080, None, None, True)
    assert p.type == ProxyType.SOCKS4
    assert p.host == '192.168.1.1'
    assert p.port == 1080
    assert p.username is None
    assert p.password is None
    assert p.remote_dns is True



# Generated at 2022-06-22 09:34:16.943338
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    socks5a = Socks5Auth()
    # The following line will print the status of the constructor
    print("Initializing Socks5Auth class: ", socks5a)


# Generated at 2022-06-22 09:34:25.736592
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(type=ProxyType.SOCKS4, host='127.0.0.1', port=1080,
                  username='test', password='test', remote_dns=True)
    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == '127.0.0.1'
    assert proxy.port == 1080
    assert proxy.username == 'test'
    assert proxy.password == 'test'
    assert proxy.remote_dns == True


# Generated at 2022-06-22 09:34:32.333522
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    def test_connect(proxy, address, expected_result):
        assert address[0] != '200.200.200.200'
        s = sockssocket()
        s.setproxy(proxy[0], proxy[1], proxy[2])
        s.connect(address)
        s.sendall(b'GET https://www.python.org/ HTTP/1.0\r\n\r\n')
        print('Send request success')
        print(s.recvall(1024))
        s.shutdown(socket.SHUT_RDWR)
        s.close()

    # Test with a working proxy
    test_connect((2, '198.211.120.59', 1080), ('www.python.org', 80), 0)

    # Test with a not working proxy

# Generated at 2022-06-22 09:34:43.364566
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    sss = sockssocket()
    assert sss._proxy == None, 'Default value of attribut _proxy should be None'

    sss.setproxy(ProxyType.SOCKS4, '127.0.0.1', 3128)
    assert sss._proxy.type == ProxyType.SOCKS4, 'Wrong value for attribut _proxy.type'
    assert sss._proxy.host == '127.0.0.1', 'Wrong value for attribut _proxy.host'
    assert sss._proxy.port == 3128, 'Wrong value for attribut _proxy.port'
    assert sss._proxy.remote_dns == True, 'Wrong value for attribut _proxy.remote_dns'

    sss.setproxy(ProxyType.SOCKS5, '127.0.0.1', 3128, False)


# Generated at 2022-06-22 09:34:45.529732
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    pass

# Generated at 2022-06-22 09:34:56.151410
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import random
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    # RFC 5737 TEST-NET-1
    sock.connect(('192.0.2.0', 80))
    expected_data = b'GET / HTTP/1.0\r\n'
    sock.sendall(expected_data)
    got_data = sock.recvall(len(expected_data))
    assert got_data == expected_data
    # https://tools.ietf.org/html/rfc5737#section-3.5
    # "192.0.2.0/24 - This block, despite being in the DNS, is for
    # documentation. It is often used in examples of network protocol
    # headers.  It should not be used publicly."
    sock.sendall(expected_data)

# Generated at 2022-06-22 09:34:59.537053
# Unit test for constructor of class Proxy
def test_Proxy():
    Proxy(1, '0.0.0.0', 1080, 'username', 'password', False)
    Proxy(2, '1.1.1.1', 1080, None, None, False)

# Generated at 2022-06-22 09:35:24.251981
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import pycurl
    import StringIO
    import sys

    # Network proxy
    socks_proxy = 'socks5://127.0.0.1:8080'
    if len(sys.argv) >= 2:
        socks_proxy = sys.argv[1]

    # Create a socket
    socks_socket = sockssocket()

    # Set proxy
    socks_proxy_type, socks_proxy_host, socks_proxy_port_str, socks_proxy_auth = pycurl.parse_proxy(socks_proxy)
    socks_proxy_port = int(socks_proxy_port_str)

    socks_socket.setproxy(socks_proxy_type, socks_proxy_host, socks_proxy_port)

    # Connect to remote host
    socks_socket.connect(('google.com', 80))

   

# Generated at 2022-06-22 09:35:29.615753
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:35:34.028634
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(2, 3, 4, 'username', 'password', True)
    assert proxy.type == 2
    assert proxy.host == 3
    assert proxy.port == 4
    assert proxy.username == 'username'
    assert proxy.password == 'password'
    assert proxy.remote_dns == True

# Generated at 2022-06-22 09:35:37.124774
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-22 09:35:38.531624
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    error = Socks4Error(91)
    assert error.code == 91
    assert error.msg == 'request rejected or failed'


# Generated at 2022-06-22 09:35:44.392312
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS4, '127.0.0.1', 1080)
    assert proxy.type == ProxyType.SOCKS4
    assert proxy.host == '127.0.0.1'
    assert proxy.port == 1080
    assert proxy.username == ''
    assert proxy.password == ''
    assert proxy.remote_dns == True

# Generated at 2022-06-22 09:35:44.826108
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    pass

# Generated at 2022-06-22 09:35:50.866178
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    e = Socks4Error()
    assert Socks4Error.ERR_SUCCESS == e.errno, 'Socks4Error.errno must be equal to Socks4Error.ERR_SUCCESS'
    assert 'request rejected or failed' == e.strerror, 'Socks4Error.strerror must be equal to "request rejected or failed"'


# Generated at 2022-06-22 09:35:53.042856
# Unit test for constructor of class sockssocket
def test_sockssocket():
    print(sockssocket)

if __name__ == '__main__':
    test_sockssocket()

# Generated at 2022-06-22 09:36:01.047738
# Unit test for constructor of class ProxyType

# Generated at 2022-06-22 09:37:12.336029
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    import unittest
    from .compat import unittest_data_property

    # https://github.com/davidmoreno/onionshare/issues/602
    # https://stackoverflow.com/a/37268719
    class CheckSetProxyTestCase(unittest.TestCase):
        @staticmethod
        def setUpModule():
            pass

        @staticmethod
        def tearDownModule():
            pass

        def setUp(self):
            self.s = sockssocket()

        def tearDown(self):
            pass


# Generated at 2022-06-22 09:37:16.676633
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error(91)
    except ProxyError as e:
        assert e.errno == 91
        assert e.strerror == 'request rejected or failed'
        return e


# Generated at 2022-06-22 09:37:23.009943
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    with pytest.raises(InvalidVersionError) as exc_info:
        raise InvalidVersionError(0x00, 0x01)
    assert exc_info.value.args == (0, 'Invalid response version from server. Expected 00 got 01')

# Generated at 2022-06-22 09:37:29.539100
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    # test "assert proxytype in (ProxyType.SOCKS4, ProxyType.SOCKS4A, ProxyType.SOCKS5)"
    ss = sockssocket()
    try:
        ss.setproxy(3,'127.0.0.1',9050)
    except Exception as e:
        assert 'AssertionError' in str(e)
    else:
        assert False

# Generated at 2022-06-22 09:37:39.737099
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    import mock
    import time
    from .compat import HTTPAdapter

    class MockSocket(sockssocket):
        def __init__(self):
            self._proxy = None
            self.sent = b''

        def sendall(self, data):
            self.sent += data

    s = MockSocket()

    with mock.patch('socket.socket.connect_ex') as m_connect_ex:
        m_connect_ex.side_effect = lambda address: 0

        # SOCKS4 without username
        s.setproxy(ProxyType.SOCKS4, 'localhost', 1080)
        s.connect(('www.example.com', 80))

# Generated at 2022-06-22 09:37:43.810359
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    args = (99, 98)
    message = ('Invalid response version from server. '
               'Expected {0:02x} got {1:02x}'.format(*args))
    try:
        raise InvalidVersionError(*args)
    except InvalidVersionError as e:
        assert e.args[1] == message

# Generated at 2022-06-22 09:37:52.609007
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    socks4 = Proxy(ProxyType.SOCKS4, '', 0)
    socks5 = Proxy(ProxyType.SOCKS5, '', 0)
    destination = ('localhost', 8181)
    s = sockssocket()
    s.settimeout(1)
    assert s.connect_ex(destination) == 0
    s.close()

    s = sockssocket()
    s.settimeout(1)
    s.setproxy(*socks4)
    assert s.connect_ex(destination) == 0
    s.close()

    s = sockssocket()
    s.settimeout(1)
    s.setproxy(*socks5)
    assert s.connect_ex(destination) == 0
    s.close()

# Generated at 2022-06-22 09:37:56.741041
# Unit test for constructor of class ProxyType
def test_ProxyType():
    '''
    >>> type(sockssocket.Socks4) == int
    True
    >>> type(sockssocket.Socks4a) == int
    True
    >>> type(sockssocket.Socks5) == int
    True
    '''
    pass


# Generated at 2022-06-22 09:38:00.030543
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    test_success = Socks5Error()
    assert(test_success.args == ('unknown error',))
    test_error = Socks5Error(0x01)
    assert(test_error.args == ('general SOCKS server failure',))

# Generated at 2022-06-22 09:38:00.994314
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    Socks4Command()


# Generated at 2022-06-22 09:39:48.601576
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    # test if the constructor is successful or not
    assert Socks5AddressType().ATYP_IPV4 == 0x01



# Generated at 2022-06-22 09:39:54.445476
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket()
    # Create, bind, listen and accept a socket
    serversock = socket.socket()
    serversock.bind(('', 0))
    serversock.listen(5)
    # Get the port number and connect the sockssocket
    port = serversock.getsockname()[1]
    sock.connect(('localhost', port))
    # Accept the connection to the accepted socket
    (clientsock, address) = serversock.accept()
    # Test recvall
    # Test case: Short strings (less than one buffer)
    clientsock.send(b'1')
    assert sock.recvall(1) == b'1'
    # Test case: Long strings (more than one buffer)
    clientsock.send(b'123456789')
    assert sock.recvall(9) == b

# Generated at 2022-06-22 09:39:57.905316
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-22 09:39:59.558715
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    c = Socks4Command()
    assert c is not None

# Generated at 2022-06-22 09:40:02.384322
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error(code=1)
    except Socks5Error as e:
        assert e.args[0] == 1
        assert e.args[1] == Socks5Error.CODES[e.args[0]]

# Generated at 2022-06-22 09:40:10.324834
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # Create a sockssocket object to connect to localhost:8000 via SOCKS5 proxy
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, "127.0.0.1", 8000)

    # Connect the socket to HOST:PORT
    s.connect_ex(("127.0.0.1", 8080))

    # Send 'GET /' request to proxy
    s.send("GET /")

    # Receive data from proxy

# Generated at 2022-06-22 09:40:12.045696
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_BIND == 0x02



# Generated at 2022-06-22 09:40:15.303357
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert str(ProxyError(7, 'test')) == '(7, test)'
    assert str(ProxyError(99, 'test')) == '(99, test)'
    assert str(ProxyError(7)) == '(7, unknown error)'


# Generated at 2022-06-22 09:40:20.766588
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:40:25.166277
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError().__str__() == 'None'
    assert ProxyError(code=0x00, msg='success').__str__() == 'success'
