

# Generated at 2022-06-22 09:31:37.561494
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    cmd = Socks4Command()
    assert cmd.CMD_CONNECT == 0x01
    assert cmd.CMD_BIND == 0x02


# Generated at 2022-06-22 09:31:39.889357
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(type=1, host='localhost', port=12345, username='foo', password='secret', remote_dns=1)

    assert proxy.type == 1
    assert proxy.host == 'localhost'
    assert proxy.port == 12345
    assert proxy.username == 'foo'
    assert proxy.password == 'secret'
    assert proxy.remote_dns == 1


# Generated at 2022-06-22 09:31:50.067102
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    command = Socks5Command()
    # print("Value of Socks5Command.CMD_CONNECT: {0}".format(command.CMD_CONNECT))
    assert (command.CMD_CONNECT == 0x01)
    # print("Value of Socks5Command.CMD_BIND: {0}".format(command.CMD_BIND))
    assert (command.CMD_BIND == 0x02)
    # print("Value of Socks5Command.CMD_UDP_ASSOCIATE: {0}".format(command.CMD_UDP_ASSOCIATE))
    assert (command.CMD_UDP_ASSOCIATE == 0x03)


# Generated at 2022-06-22 09:31:53.881747
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
	# test for 1.1
    expected_version = 1.1
    got_version = 1.2
    invalid_version_error = InvalidVersionError(expected_version, got_version)
    assert invalid_version_error.code == 0
    assert invalid_version_error.msg == 'Invalid response version from server. Expected 01 got 02'


# Generated at 2022-06-22 09:32:00.029154
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:32:07.110146
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # Create a client socket and connect it to the proxy server
    client_socket = sockssocket()
    client_socket.setproxy(
        proxytype=ProxyType.SOCKS5,
        addr="localhost",
        port=1080)
    # Establish a TCP/IP connection with an HTTP server on the internet
    result = client_socket.connect_ex(("www.google.com", 80))
    print('connect_ex result %d' % result)
    if result == 0:
        print('Connect to local socks5 proxy successfully')
    else:
        print('Cannot connect to local socks5 proxy')



# Generated at 2022-06-22 09:32:10.953454
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    socks = sockssocket()
    socks.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    socks.connect(('youtube.com', 443))


if __name__ == '__main__':
    test_sockssocket_connect()

# Generated at 2022-06-22 09:32:12.829556
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    try:
        auth = Socks5Auth()
    except TypeError:
        return
    return 1

# Generated at 2022-06-22 09:32:22.722831
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.setproxy(ProxyType.SOCKS5,'127.0.0.1', 1080)
        s.connect(('ya.ru', 80))
    except:
        print('connect error')
    s.sendall(b'GET / HTTP/1.0\n\n')
    data = s.recvall(1024)
    if len(data) != 1024:
        raise Exception("recvall() error");
    s.close()

# Test with and without proxy
test_sockssocket_recvall()

# Generated at 2022-06-22 09:32:24.159123
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 != ProxyType.SOCKS5


# Generated at 2022-06-22 09:32:43.243710
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0x00, 0x01)
    except InvalidVersionError as e:
        assert e.__str__() == '0: Invalid response version from server. Expected 00 got 01'


# Generated at 2022-06-22 09:32:46.087851
# Unit test for constructor of class sockssocket
def test_sockssocket():
    def test():
        sockssocket()
        sockssocket(socket.AF_INET, socket.SOCK_STREAM)
        sockssocket(socket.AF_INET, socket.SOCK_STREAM, 0)
    test()



# Generated at 2022-06-22 09:32:50.166331
# Unit test for constructor of class ProxyType
def test_ProxyType():
    proxyType = ProxyType()
    if proxyType.SOCKS4 != 0 or proxyType.SOCKS4A != 1 or proxyType.SOCKS5 != 2:
        print('Class ProxyType is incorrect')
        exit(1)


# Generated at 2022-06-22 09:32:52.681738
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()

if __name__ == '__main__':
    test_sockssocket()

# Generated at 2022-06-22 09:32:54.610124
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert str(Socks4Command.CMD_CONNECT) == '1'
    assert str(Socks4Command.CMD_BIND) == '2'


# Generated at 2022-06-22 09:32:58.770709
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:33:07.738244
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    import _socket as original_socket

    sockssocket.socket = original_socket.socket
    sockssocket.socket.connect = original_socket.connect

    # Let's fake a SOCKS server
    addr, port = '127.0.0.1', 12345
    s = sockssocket()
    s.bind((addr, port))
    s.listen(1)
    s.settimeout(10)

    address = 'localhost', 56630
    ss = sockssocket()
    ss.setproxy(ProxyType.SOCKS5, addr, port)

    # Starts client
    ss.connect_ex(address)

    # Process request
    conn, _ = s.accept()
    conn.settimeout(10)
    conn.recvall(3)
    conn.sendall(b'\x05\xFF')


# Generated at 2022-06-22 09:33:08.250630
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    pass

# Generated at 2022-06-22 09:33:10.932668
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF



# Generated at 2022-06-22 09:33:23.564764
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import os

    from .compat import compat_struct_pack
    from .compat import compat_struct_unpack
    # Create a pair of connected sockets
    lsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # Disable timouts on sockets
    lsock.settimeout(None)
    lsock.bind(('127.0.0.1', 0))
    lsock.listen(1)
    csock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    csock.settimeout(None)
    csock.connect(lsock.getsockname())
    sock, _ = lsock.accept()
    data = os.urandom(10)
    # Send len of data

# Generated at 2022-06-22 09:33:34.746295
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    a1 = Socks5AddressType()
    assert a1.ATYP_IPV4 == 0x01
    assert a1.ATYP_DOMAINNAME == 0x03
    assert a1.ATYP_IPV6 == 0x04


# Generated at 2022-06-22 09:33:44.171093
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import socket
    mocks = [socket.socket(), sockssocket()]
    for mock in mocks:
        mock.recv = lambda x: b'a' * x
        mock.close = lambda: None
        assert mock.recvall(5) == b'aaaaa'
        mock.recv = lambda x: b''
        try:
            mock.recvall(5)
            if mock == sockssocket:
                assert False
        except EOFError:
            pass
        except Exception as e:
            assert False


if __name__ == '__main__':
    test_sockssocket_recvall()

# Generated at 2022-06-22 09:33:46.649959
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    e = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    msg = str(e)
    assert msg == 'general SOCKS server failure'

# Generated at 2022-06-22 09:33:51.203442
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(10)
    sock.connect(("192.168.1.1", 80))
    sock.sendall(b'GET / HTTP/1.0\r\n\r\n')
    data = b''
    while True:
        chunk = sock.recvall(5)
        if chunk:
            data += chunk
        else:
            break
    print(data)

# Generated at 2022-06-22 09:33:54.504844
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert isinstance(ProxyType.SOCKS4, int)
    assert isinstance(ProxyType.SOCKS4A, int)
    assert isinstance(ProxyType.SOCKS5, int)

# Generated at 2022-06-22 09:33:56.734423
# Unit test for constructor of class sockssocket
def test_sockssocket():
    new_socket = sockssocket()
    return new_socket

# Convenience function for testing

# Generated at 2022-06-22 09:33:57.649599
# Unit test for constructor of class sockssocket
def test_sockssocket():
    pass

# Generated at 2022-06-22 09:34:04.588586
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert (Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF)
    assert (Socks5Auth.AUTH_USER_PASS == 0x02)
    assert (Socks5Auth.AUTH_GSSAPI == 0x01)
    assert (Socks5Auth.AUTH_NONE == 0x00)

# Generated at 2022-06-22 09:34:12.539916
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    def error_code(code):
        return Socks5Error(code)
    # test for valid error codes
    for error_code_value in (0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0xFE, 0xFF):
        assert error_code(error_code_value).args == (error_code_value, Socks5Error.CODES[error_code_value])
    # test for invalid error codes
    assert error_code(-1).args == (None, 'unknown error')
    assert error_code(256).args == (None, 'unknown error')

test_Socks5Error()

# Generated at 2022-06-22 09:34:16.283150
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    r = s.connect_ex(('www.youtube.com', 80))
    s.close()
    assert r == 0

# Generated at 2022-06-22 09:34:24.697665
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(5, 'An error message')
    except ProxyError as e:
        assert e.errno == 5
        assert e.strerror == 'An error message'


# Generated at 2022-06-22 09:34:26.232293
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    sockssocket.setproxy(ProxyType.SOCKS4, 'proxy.example.com', 1080)

# Generated at 2022-06-22 09:34:28.154429
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert (Socks5AddressType.ATYP_IPV4 == 0x01)
    assert (Socks5AddressType.ATYP_DOMAINNAME == 0x03)
    assert (Socks5AddressType.ATYP_IPV6 == 0x04)


# Generated at 2022-06-22 09:34:35.811112
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    error = Socks4Error()
    assert error.args[0] is None
    assert error.args[1] is None

    error = Socks4Error(None, "123456")
    assert error.args[0] is None
    assert error.args[1] == "123456"

    error = Socks4Error(91, None)
    assert error.args[0] == 91
    assert error.args[1] == "request rejected or failed"


# Generated at 2022-06-22 09:34:37.477815
# Unit test for constructor of class ProxyType
def test_ProxyType():
    # Check that calling constructor without arguments doesn't fail
    ProxyType()


# Generated at 2022-06-22 09:34:41.148912
# Unit test for constructor of class sockssocket
def test_sockssocket():
    try:
        s = sockssocket.__new__(sockssocket)
        s.__init__()
        print(s)
    except Exception as e:
        print('Unexpected exception: %s' % e)
    return



# Generated at 2022-06-22 09:34:43.001678
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    assert 1 == sockssocket().connect_ex(('127.0.0.1', 80))


# Generated at 2022-06-22 09:34:55.222968
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        from unittest import mock
    except ImportError:
        try:
            import mock
        except ImportError:
            print('test_Socks4Error skipped: no unittest.mock or mock installed')
            return
    with mock.patch('socket.socket.connect') as connect_mock:
        connect_mock.return_value = None
        sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
        # test with code
        try:
            raise Socks4Error(91)
        except Exception as e:
            assert 'request rejected or failed' in e.args[1]
        # test with msg
        try:
            raise Socks4Error(msg='test')
        except Exception as e:
            assert 'test' in e.args[1]

# Generated at 2022-06-22 09:35:00.761248
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    sock = sockssocket()
    # check that we can set SOCKS4 and SOCKS5 proxy
    sock.setproxy(ProxyType.SOCKS4, 'localhost', 8080)
    sock.setproxy(ProxyType.SOCKS5, 'localhost', 8080)
    # check that we cannot set other types
    try:
        sock.setproxy(3, 'localhost', 8080)
    except AssertionError:
        pass
    else:
        raise Exception('The proxy type must be checked')

# Generated at 2022-06-22 09:35:04.669533
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    err = Socks5Error(Socks5Auth.AUTH_NO_ACCEPTABLE)
    assert type(err) == Socks5Error
    assert err.args[0] == Socks5Auth.AUTH_NO_ACCEPTABLE
    assert err.args[1] == 'all offered authentication methods were rejected'


# Generated at 2022-06-22 09:35:19.492741
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_IPV6 == 0x04
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03

# Generated at 2022-06-22 09:35:24.381018
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    class SockssocketRecvallTest(unittest.TestCase):
        def test_recvall(self):
            s = sockssocket()
            s.connect(('127.0.0.1', 12345))
            self.assertRaises(EOFError, s.recvall, 1)

    unittest.main(module=__name__, exit=False, verbosity=2)

if __name__ == '__main__':
    test_sockssocket_recvall()

# Generated at 2022-06-22 09:35:30.233902
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    command = Socks4Command()
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:35:33.900309
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(1, 2)
    except InvalidVersionError as e:
        assert e.args == (0, 'Invalid response version from server. Expected 01 got 02')


# Generated at 2022-06-22 09:35:36.706177
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    error = InvalidVersionError(0, 0)
    assert error.errno == 0
    assert error.strerror == 'Invalid response version from server. Expected 00 got 00'



# Generated at 2022-06-22 09:35:41.527982
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    socks_proxy = {
        'host': '127.0.0.1',
        'port': 1080,
    }
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    ss.setproxy(ProxyType.SOCKS5, socks_proxy['host'], socks_proxy['port'])
    res = ss.connect_ex(('localhost', 8080))
    assert res == 0
    assert ss.getpeername() == ('127.0.0.1', 8080)
    ss.close()



# Generated at 2022-06-22 09:35:45.196902
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        InvalidVersionError(3, 1)
    except InvalidVersionError as e:
        assert e.args[0] == 3
        assert e.args[1] == 1


# Generated at 2022-06-22 09:35:57.405934
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import sys
    import ssl
    from .config import SOCKS_CONFIG


# Generated at 2022-06-22 09:36:01.021287
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-22 09:36:03.205569
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:36:32.856746
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    s = sockssocket.socket()
    s.setproxy(sockssocket.SOCKS5, '127.0.0.1', 1081)
    #s.setproxy(sockssocket.SOCKS4, '127.0.0.1', 1081)
    #s.setproxy(sockssocket.SOCKS4A, '127.0.0.1', 1081)
    s.connect(('127.0.0.1', 80))
    s.sendall(b'GET / HTTP/1.1\r\n\r\n')
    print(s.recv(10240))
    s.close()

# Generated at 2022-06-22 09:36:38.012057
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sock = sockssocket()
    host = '0.0.0.0'
    port = 0
    sock.connect((host, port))

if __name__ == '__main__':
    test_sockssocket_connect()

# Generated at 2022-06-22 09:36:38.652593
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket()

# Generated at 2022-06-22 09:36:46.124623
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    from .compat import (
        compat_struct_pack,
        compat_struct_unpack,
    )
    from .debug import socket_debug
    from .util import (
        random_string,
        random_string_numeric,
        random_string_alpha
    )

    port = random_string_numeric(4)
    port = int(port)

    test_sock = sockssocket()
    test_sock.settimeout(10)
    test_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    test_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
    test_sock.bind(('', port))
    test_sock.listen(5)


# Generated at 2022-06-22 09:36:50.608438
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error(0x01)
    except Socks5Error as e:
        assert e.errno, 0x01
        assert e.strerror, Socks5Error.CODES[0x01]

# Generated at 2022-06-22 09:36:51.896615
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)

# Generated at 2022-06-22 09:36:55.110628
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError()
    except TypeError:
        pass
    try:
        raise InvalidVersionError(0x03, 0x03)
    except InvalidVersionError as e:
        assert e.code == 0
        assert str(e) == 'Invalid response version from server. Expected 00 got 03'

# Generated at 2022-06-22 09:36:58.371945
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS5 == 2
    assert ProxyType.SOCKS5 == Socks5Command.CMD_CONNECT
    assert ProxyType.SOCKS4 == Socks4Command.CMD_CONNECT
    assert ProxyType.SOCKS4A == ProxyType.SOCKS4

# Generated at 2022-06-22 09:37:08.917101
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
  sock = sockssocket()
  sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
  sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM, socket.SOL_TCP)
  sock = sockssocket(socket.AF_INET, socket.SOCK_DGRAM, socket.SOL_TCP)
  sock = sockssocket(socket.AF_INET, socket.SOCK_RAW, socket.SOL_TCP)
  sock = sockssocket(socket.AF_INET6, socket.SOCK_STREAM)
  sock = sockssocket(socket.AF_INET6, socket.SOCK_DGRAM)
  sock = sockssocket(socket.AF_INET6, socket.SOCK_RAW)

# Generated at 2022-06-22 09:37:11.383714
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-22 09:37:56.878123
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:38:00.166397
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    e = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    assert e.errno == Socks5Error.ERR_GENERAL_FAILURE
    assert e.strerror == 'general SOCKS server failure'

# Generated at 2022-06-22 09:38:02.562272
# Unit test for constructor of class ProxyType
def test_ProxyType():
    ProxyType.SOCKS4
    ProxyType.SOCKS4A
    ProxyType.SOCKS5


# Generated at 2022-06-22 09:38:11.045336
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    ex = Socks4Error(Socks4Error.ERR_SUCCESS)
    assert ex.args[0] == Socks4Error.ERR_SUCCESS
    assert ex.args[1] == 'request rejected or failed'
    ex = Socks4Error(0xFF)
    assert ex.args[0] == 0xFF
    assert ex.args[1] == 'unknown error'
    ex = Socks4Error(0x00, 'message')
    assert ex.args[0] == 0x00
    assert ex.args[1] == 'message'

# Generated at 2022-06-22 09:38:20.512255
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    # This test requires a proxy server
    host = 'localhost'
    port = 2142

    with sockssocket() as s:
        s.setproxy(ProxyType.SOCKS5, host, port, False)
        s.connect(('google.com', 80))
        assert(s.getpeername()[0] == '74.125.224.72')
        s.close()

        s.setproxy(ProxyType.SOCKS4, host, port, False)
        s.connect(('google.com', 80))
        assert(s.getpeername()[0] == '74.125.224.72')
        s.close()

        s.setproxy(ProxyType.SOCKS4A, host, port, False)
        s.connect(('google.com', 80))

# Generated at 2022-06-22 09:38:24.100110
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 1
    assert Socks4Command.CMD_BIND == 2



# Generated at 2022-06-22 09:38:30.185457
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS5, '127.0.0.1', 1080, 'username', 'password')
    assert type(proxy.type) is int
    assert proxy.host == '127.0.0.1'
    assert type(proxy.port) is int
    assert proxy.username == 'username'
    assert proxy.password == 'password'


# Generated at 2022-06-22 09:38:37.092853
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    assert s._proxy is None
    s.setproxy(ProxyType.SOCKS5, "127.0.0.1", 8080)
    assert s._proxy.type == ProxyType.SOCKS5
    assert s._proxy.host == "127.0.0.1"
    assert s._proxy.port == 8080
    assert s._proxy.username is None
    assert s._proxy.password is None
    assert s._proxy.remote_dns is True

# Generated at 2022-06-22 09:38:40.046347
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    guid_url = 'https://www.youtube.com'
    sockssocket_object = sockssocket()
    sockssocket_object.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 9050)
    #print(sockssocket_object.connect_ex((guid_url, 443)))
    return sockssocket_object.connect_ex((guid_url, 443))

# Generated at 2022-06-22 09:38:43.014004
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:40:31.643340
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    try:
        socks_host = '127.0.0.1'
        socks_port = '1080'
        socks_username = ''
        socks_password = 'password'

        socks_socket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
        socks_socket.setproxy(ProxyType.SOCKS5, socks_host, socks_port, username=socks_username, password=socks_password)
        socks_socket.connect((socks_host, int(socks_port)))
    except Socks5Error as err:
        raise RuntimeError('Failed to connect to SOCKS5 server: {0} (error code {1})'.format(err.args[1], err.args[0]))
    except:
        raise RuntimeError('Failed to connect to SOCKS5 server')

# Generated at 2022-06-22 09:40:43.688258
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    s = sockssocket()

    # Use SOCKS5 proxy server, without authentication
    s.setproxy(sockssocket.PROXY_TYPE_SOCKS5, '192.168.100.100', 8080)

    # Use SOCKS5 proxy server, with authentication
    s.setproxy(sockssocket.PROXY_TYPE_SOCKS5, '192.168.100.100', 8080,
               username='foo', password='bar')

    # Use SOCKS4 proxy server, without authentication
    s.setproxy(sockssocket.PROXY_TYPE_SOCKS4, '192.168.100.100', 8080)

    # Use SOCKS4A proxy server, without authentication, but with remote DNS

# Generated at 2022-06-22 09:40:46.519540
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 1
    assert Socks5AddressType.ATYP_DOMAINNAME == 3
    assert Socks5AddressType.ATYP_IPV6 == 4

# Generated at 2022-06-22 09:40:50.628360
# Unit test for constructor of class sockssocket
def test_sockssocket():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        assert not hasattr(s, '_proxy')
    finally:
        s.close()



# Generated at 2022-06-22 09:41:02.354339
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Create a listening socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('127.0.0.1', 0))
    addr, bind_port = sock.getsockname()
    sock.listen(1)

    # Connect to listening socket

# Generated at 2022-06-22 09:41:03.857148
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    ss = sockssocket.connect("www.baidu.com",80)
    print(ss)
if __name__ == '__main__':
    test_sockssocket_connect()

# Generated at 2022-06-22 09:41:05.487404
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:41:11.336106
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-22 09:41:18.086371
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    if not isinstance(Socks5Command.CMD_CONNECT, int):
        raise ValueError('Socks5Command.CMD_CONNECT is not integer')
    if not isinstance(Socks5Command.CMD_BIND, int):
        raise ValueError('Socks5Command.CMD_BIND is not integer')
    if not isinstance(Socks5Command.CMD_UDP_ASSOCIATE, int):
        raise ValueError('Socks5Command.CMD_UDP_ASSOCIATE is not integer')

# Generated at 2022-06-22 09:41:23.207865
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(SOCKS4_REPLY_VERSION, SOCKS4_VERSION)
    except InvalidVersionError as e:
        assert e.errno == 0
        assert str(e) == ('Invalid response version from server. Expected 00 got '
                          '04')