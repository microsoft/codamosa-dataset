

# Generated at 2022-06-22 09:31:45.801561
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType().ATYP_IPV4 == 0x01
    assert Socks5AddressType().ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType().ATYP_IPV6 == 0x04

# Generated at 2022-06-22 09:31:52.109291
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    e = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    assert e.c == Socks5Error.ERR_GENERAL_FAILURE
    assert e.strerror == 'general SOCKS server failure'

# Generated at 2022-06-22 09:31:54.446306
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0, 1)
    except Exception as e:
        assert e.args[0] == 0
        assert isinstance(e, InvalidVersionError)

# Generated at 2022-06-22 09:31:58.134445
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02

# Generated at 2022-06-22 09:32:00.290322
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2

# Generated at 2022-06-22 09:32:05.881586
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    err = Socks5Error()
    assert err.code == None
    assert err.msg == None

    err = Socks5Error(0x01, 'general SOCKS server failure')
    assert err.code == 0x01
    assert err.msg == 'general SOCKS server failure'

    err = Socks5Error(0x01)
    assert err.code == 0x01
    assert err.msg == 'general SOCKS server failure'

# Generated at 2022-06-22 09:32:10.279252
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS5, 'localhost',
                  1080, username='username', password='password')
    assert proxy.type == ProxyType.SOCKS5
    assert proxy.host == 'localhost'
    assert proxy.port == 1080
    assert proxy.username == 'username'
    assert proxy.password == 'password'
    assert proxy.remote_dns is True
    proxy = Proxy(ProxyType.SOCKS5, 'localhost',
                  1080, username='username', password='password', remote_dns=False)
    assert proxy.type == ProxyType.SOCKS5
    assert proxy.host == 'localhost'
    assert proxy.port == 1080
    assert proxy.username == 'username'
    assert proxy.password == 'password'
    assert proxy.remote_dns is False



# Generated at 2022-06-22 09:32:12.978411
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:32:23.329201
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF

if __name__ == '__main__':
    test_Socks5Auth()
    conn = sockssocket()
    conn.setproxy(ProxyType.SOCKS4, 'socks4.a-socks.com', 1080)
    conn.connect(('1.1.1.1', 22))
    conn.close()

    print("PASS")

# Generated at 2022-06-22 09:32:30.976090
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    socks = sockssocket()
    socks.bind(('127.0.0.1', 0))
    socks.connect(('www.google.com', 80))
    socks.sendall(b'GET / HTTP/1.0\r\n\r\n')
    headers = b''
    while b'\r\n\r\n' not in headers:
        headers += socks.recvall(128)
    assert headers.startswith(b'HTTP/1.0')
    assert b'Host: www.google.com' in headers

if __name__ == '__main__':
    test_sockssocket_recvall()

# Generated at 2022-06-22 09:33:44.702124
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error()
        assert (False)
    except Socks4Error as e:
        assert (e.args[0] == 0)
        assert (e.args[1] == 'unknown error')
    try:
        raise Socks4Error(91)
        assert (False)
    except Socks4Error as e:
        assert (e.args[0] == 91)
        assert (e.args[1] == 'request rejected or failed')


# Generated at 2022-06-22 09:33:48.952226
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:33:51.393744
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    ss.setproxy(ProxyType.SOCKS5, 'localhost', 1080)
    try:
        ss.connect(('www.google.com', 80))
    finally:
        ss.close()

# Generated at 2022-06-22 09:33:53.400833
# Unit test for constructor of class sockssocket
def test_sockssocket():
    return sockssocket(socket.AF_INET, socket.SOCK_STREAM)


# Generated at 2022-06-22 09:33:57.447614
# Unit test for constructor of class ProxyType
def test_ProxyType():
    # Arrange
    # Act
    # Assert
    assert(ProxyType.SOCKS4 == 0)
    assert (ProxyType.SOCKS4A == 1)
    assert (ProxyType.SOCKS5 == 2)



# Generated at 2022-06-22 09:34:05.758785
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03
    assert Socks5Command.CMD_CONNECT == Socks4Command.CMD_CONNECT
    assert Socks5Command.CMD_BIND == Socks4Command.CMD_BIND


# Generated at 2022-06-22 09:34:11.851329
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    proxy = Proxy(ProxyType.SOCKS4, "127.0.0.1", 1080)
    proxy_setting = [proxy, proxy, proxy]
    for p in proxy_setting:
        test_sockssocket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
        test_sockssocket.setproxy(p.type, p.host, p.port, rdns=p.remote_dns, username=p.username, password=p.password)


# Generated at 2022-06-22 09:34:14.831913
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    obj = Socks5Command()
    assert obj.CMD_CONNECT == 0x01
    assert obj.CMD_BIND == 0x02
    assert obj.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-22 09:34:18.194410
# Unit test for constructor of class ProxyError
def test_ProxyError():
    assert ProxyError().msg == None
    #assert ProxyError(code=0x01, msg='test').msg == 'test'
    assert ProxyError(code=0x02).msg == 'unknown error'
    assert ProxyError(code=0x00, msg='test').msg == 'test'


# Generated at 2022-06-22 09:34:19.712781
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2

# Generated at 2022-06-22 09:34:46.304398
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import random

    CNT = 16
    class MockSock(object):
        def __init__(self, cnt):
            self.data = b''
            for _ in range(cnt):
                self.data += compat_struct_pack('!B', random.randint(0, 255))

        def recv(self, cnt):
            cur = self.data[:cnt]
            self.data = self.data[cnt:]
            if not cur:
                raise EOFError()
            return cur

    mock_sock = MockSock(CNT)
    ss = sockssocket()
    ss.recv = mock_sock.recv
    data = ss.recvall(CNT)
    assert len(data) == CNT
    assert data == mock_sock.data

# Generated at 2022-06-22 09:34:50.908446
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        InvalidVersionError(expected_version=3, got_version=2)
    except InvalidVersionError as e:
        msg = 'Invalid response version from server. Expected 03 got 02'
        assert e.args[0] == 0 and e.args[1] == msg


# Generated at 2022-06-22 09:34:53.223365
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    cmd=Socks4Command()
    print(cmd.CMD_CONNECT)
    print(cmd.CMD_BIND)


# Generated at 2022-06-22 09:35:02.487436
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error(code=0)
    except ProxyError as e:
        assert e.strerror == 'unknown error'

    try:
        raise Socks4Error(code=91)
    except ProxyError as e:
        assert e.strerror == 'request rejected or failed'

    try:
        raise Socks4Error(code=92)
    except ProxyError as e:
        assert e.strerror == 'request rejected because SOCKS server cannot connect to identd on the client'

    try:
        raise Socks4Error(code=93)
    except ProxyError as e:
        assert e.strerror == 'request rejected because the client program and identd report different user-ids'


# Generated at 2022-06-22 09:35:04.157271
# Unit test for constructor of class sockssocket
def test_sockssocket():
    cls = sockssocket
    socket_instance = cls()
    assert isinstance(socket_instance, cls)



# Generated at 2022-06-22 09:35:07.315074
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-22 09:35:13.023894
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    # Instance of class Socks4Command
    cmd_4 = Socks4Command()
    assert cmd_4.CMD_CONNECT == 0x01
    assert cmd_4.CMD_BIND == 0x02

    # Instance of class Socks5Command
    cmd_5 = Socks5Command()
    assert cmd_5.CMD_CONNECT == 0x01
    assert cmd_5.CMD_BIND == 0x02
    assert cmd_5.CMD_UDP_ASSOCIATE == 0x03


# Generated at 2022-06-22 09:35:17.432557
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 1
    assert Socks5AddressType.ATYP_DOMAINNAME == 3
    assert Socks5AddressType.ATYP_IPV6 == 4

# Generated at 2022-06-22 09:35:22.648338
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    # Create test socket
    proxy = Proxy(ProxyType.SOCKS5, '127.0.0.1', 8118, None, None, None)
    s = sockssocket()
    s.setproxy(proxy.type, proxy.host, proxy.port, proxy.remote_dns)
    # Test connection to Google DNS servers
    assert s.connect_ex(('8.8.8.8', 53)) == 0
    # Close connection
    s.close()

# Generated at 2022-06-22 09:35:24.813671
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    Socks5Command()
    assert True


# Generated at 2022-06-22 09:36:20.879240
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error(0x01)
    except Exception as e:
        assert isinstance(e, ProxyError)
        assert e.args[0] == 0x01
        assert e.args[1] == 'general SOCKS server failure'

# Generated at 2022-06-22 09:36:31.171015
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    from .compat import (
        compat_urllib_request,
        compat_urlparse,
    )
    from .http import get_server_socket

    server_socket = get_server_socket()
    server_url = 'http://%s:%d' % server_socket.getsockname()
    # This covers the test case when there are several data being received in
    # single recv() call.
    content = 'ABCDEFGH' * 1024
    server_socket.listen(1)
    connections = []

# Generated at 2022-06-22 09:36:34.331078
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    exc = InvalidVersionError(1, 0)
    assert exc.args == (0, 'Invalid response version from server. Expected 01 got 00')
    assert str(exc) == 'Invalid response version from server. Expected 01 got 00'

# Generated at 2022-06-22 09:36:43.053994
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    '''
    >>> try:
    ...     raise InvalidVersionError(SOCKS4_REPLY_VERSION, SOCKS4_REPLY_VERSION)
    ... except InvalidVersionError as e:
    ...     print(e)
    Traceback (most recent call last):
        ...
    __main__.InvalidVersionError: Invalid response version from server. Expected 00 got 00

    >>> try:
    ...     raise InvalidVersionError(SOCKS4_REPLY_VERSION, 3)
    ... except InvalidVersionError as e:
    ...     print(e)
    Traceback (most recent call last):
        ...
    __main__.InvalidVersionError: Invalid response version from server. Expected 00 got 03
    '''

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 09:36:50.402425
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError()
        raise ProxyError(msg='custom message')
        raise ProxyError(Socks4Error.ERR_SUCCESS)
        raise ProxyError(code=Socks4Error.ERR_SUCCESS, msg='custom message')
    except ProxyError as e:
        assert e.errno == 0


# Generated at 2022-06-22 09:36:51.605944
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03

# Generated at 2022-06-22 09:36:57.098022
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF

# Generated at 2022-06-22 09:37:02.658041
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    class_object=Socks5Auth()
    assert class_object.AUTH_NONE==0x00
    assert class_object.AUTH_GSSAPI==0x01
    assert class_object.AUTH_USER_PASS==0x02
    assert class_object.AUTH_NO_ACCEPTABLE==0xFF
    assert class_object.ERR_SUCCESS==0x00


# Generated at 2022-06-22 09:37:08.130548
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    got_version=0
    expected_version=0
    msg = ('Invalid response version from server. Expected {0:02x} got '
              '{1:02x}'.format(expected_version, got_version))
    e = InvalidVersionError(0, msg)
    assert e.args[0] == msg
    e = InvalidVersionError(0, 0)
    assert e.args[1] == msg



# Generated at 2022-06-22 09:37:12.808786
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    c = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    c.setproxy(ProxyType.SOCKS5, '127.0.0.1', 7070)
    #c.settimeout(5)
    c.connect(('testmyip.com', 80))
    c.sendall(b"GET / HTTP/1.1\r\nHost: testmyip.com\r\n\r\n")
    print(c.recv(1024))
    c.close()


# Generated at 2022-06-22 09:38:47.784821
# Unit test for constructor of class sockssocket

# Generated at 2022-06-22 09:38:50.320978
# Unit test for constructor of class sockssocket
def test_sockssocket():
    def socket_constructor():
        print(type(sockssocket()))
    socket_constructor()


# Generated at 2022-06-22 09:38:51.574685
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    print(Socks4Command.__dict__)


# Generated at 2022-06-22 09:38:55.285129
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(4, 5)
    except InvalidVersionError as e:
        assert e.args[0] == 0
        assert e.args[1] == 'Invalid response version from server. Expected 04 got 05'

# Generated at 2022-06-22 09:38:57.887221
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 0x01
    assert Socks5Command.CMD_BIND == 0x02
    assert Socks5Command.CMD_UDP_ASSOCIATE == 0x03

# Generated at 2022-06-22 09:39:00.223837
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:39:02.173157
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:39:05.713145
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    try:
        raise Socks4Error(91)
    except Socks4Error as e:
        assert e.errno == 91
        assert str(e) == 'request rejected or failed'
        assert e.args[0] == 91
        assert e.args[1] == 'request rejected or failed'
    else:
        raise AssertionError('Socks4Error was not thrown')

# Generated at 2022-06-22 09:39:07.284131
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:39:11.743035
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2