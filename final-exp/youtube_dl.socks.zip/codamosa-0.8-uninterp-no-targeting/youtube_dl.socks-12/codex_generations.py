

# Generated at 2022-06-22 09:31:50.797772
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:31:53.063060
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    c = Socks4Command()
    assert c.CMD_CONNECT == 0x01
    assert c.CMD_BIND == 0x02


# Generated at 2022-06-22 09:31:54.869134
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket()
    sock.connect(('www.google.de', 80))
    assert len(sock.recvall(50)) == 50
    sock.close()


# Generated at 2022-06-22 09:32:05.547033
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    socks5_proxy_address = '127.0.0.1'
    socks5_proxy_port = 9999
    socks5_auth = ('user', '$2b$10$Q2FXTL/NcgidxNxWb078ruvAaFnr/aD/mmCX.z9Tv.R56Pc7JZLhq')
    socks5_proxy = sockssocket()
    socks5_proxy.setproxy(ProxyType.SOCKS5, socks5_proxy_address, socks5_proxy_port, username='user', password='123456')
    result = socks5_proxy.connect_ex((socks5_proxy_address, socks5_proxy_port))
    print('connect_ex result = {}'.format(result))

# Generated at 2022-06-22 09:32:12.728528
# Unit test for constructor of class ProxyError
def test_ProxyError():
    error = ProxyError(code=1)
    assert error.args[0] == 1 and error.args[1] == 'unknown error'
    error = ProxyError(code=1, msg='error')
    assert error.args[0] == 1 and error.args[1] == 'error'
    error = ProxyError(code=None, msg='error')
    assert error.args[0] is None and error.args[1] == 'error'

if __name__ == '__main__':
    test_ProxyError()

# Generated at 2022-06-22 09:32:16.838415
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF


# Generated at 2022-06-22 09:32:19.397077
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    cmd = Socks4Command()
    assert cmd.CMD_CONNECT == 1
    assert cmd.CMD_BIND == 2


# Generated at 2022-06-22 09:32:26.033328
# Unit test for constructor of class Proxy
def test_Proxy():
    p = Proxy(1, '127.0.0.1', 8118, 'myname', 'mypassword', True)
    assert p.type == 1
    assert p.host == '127.0.0.1'
    assert p.port == 8118
    assert p.username == 'myname'
    assert p.password == 'mypassword'
    assert p.remote_dns == True


# Generated at 2022-06-22 09:32:31.355005
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError
    except ProxyError:
        pass
    try:
        raise ProxyError(1)
    except ProxyError:
        pass
    try:
        raise ProxyError(1, 'some message')
    except ProxyError:
        pass

# Generated at 2022-06-22 09:32:35.128710
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04
