

# Generated at 2022-06-22 09:31:46.862540
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    s.recvall(1)

# Generated at 2022-06-22 09:31:49.875257
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    assert Socks5Command.CMD_CONNECT == 1
    assert Socks5Command.CMD_BIND == 2
    assert Socks5Command.CMD_UDP_ASSOCIATE == 3



# Generated at 2022-06-22 09:31:56.979485
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    sockscommand = Socks5Command()
    assert sockscommand.CMD_CONNECT == sockscommand.CMD_CONNECT
    assert sockscommand.CMD_BIND == sockscommand.CMD_BIND
    assert sockscommand.CMD_UDP_ASSOCIATE == sockscommand.CMD_UDP_ASSOCIATE
    assert sockscommand.CMD_CONNECT != sockscommand.CMD_BIND
    assert sockscommand.CMD_CONNECT != sockscommand.CMD_UDP_ASSOCIATE
    assert sockscommand.CMD_BIND != sockscommand.CMD_UDP_ASSOCIATE


# Generated at 2022-06-22 09:32:02.254709
# Unit test for constructor of class ProxyError
def test_ProxyError():
    exception = ProxyError(0)
    assert exception.args[0] == 0
    assert exception.args[1] == 'unknown error'

    exception = ProxyError(ProxyError.ERR_SUCCESS)
    assert exception.args[1] == 'request granted'

    exception = ProxyError(1, 'test')
    assert exception.args[1] == 'test'

# Generated at 2022-06-22 09:32:05.077782
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    cmd = Socks4Command()
    assert cmd.CMD_CONNECT == 0x01
    assert cmd.CMD_BIND == 0x02


# Generated at 2022-06-22 09:32:09.841293
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    exc = Socks5Error()
    assert not isinstance(exc, ProxyError)
    assert isinstance(exc, Socks5Error)
    assert isinstance(exc, socket.error)
    assert not isinstance(exc, Socks4Error)


# Generated at 2022-06-22 09:32:14.081908
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    e = InvalidVersionError(1,2)
    assert type(e).__name__ == ProxyError.__name__
    assert e.code == 0
    assert e.errno == 0
    assert e.strerror == 'Invalid response version from server. Expected 01 got 02'


# Generated at 2022-06-22 09:32:22.389585
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    except Socks5Error as e:
        if e.args[0] != Socks5Error.ERR_GENERAL_FAILURE:
            raise AssertionError('Exception\'s argument error: {0}'.format(e.args[0]))
        if e.args[1] != Socks5Error.CODES.get(Socks5Error.ERR_GENERAL_FAILURE):
            raise AssertionError('Exception\'s argument error: {0}'.format(e.args[1]))
    else:
        raise AssertionError('Exception Socks5Error does\'nt raise')

# Generated at 2022-06-22 09:32:29.766461
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    import socket
    import socks5man
    from socks5man.sockssocket import sockssocket
    from socks5man.socks5 import SOCKS5
    from socks5man.socks4 import SOCKS4
    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    # Testing SOCKS5
    ss.setproxy(SOCKS5, '192.168.0.1', 1080)
    assert ss._proxy.type == 2
    assert ss._proxy.host == '192.168.0.1'
    assert ss._proxy.port == 1080
    # Testing SOCKS4A
    ss.setproxy(SOCKS4, '192.168.0.1', 1080)
    assert ss._proxy.type == 1

# Generated at 2022-06-22 09:32:34.366102
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    at = Socks5AddressType()
    assert at.ATYP_IPV4 == 0x01
    assert at.ATYP_DOMAINNAME == 0x03
    assert at.ATYP_IPV6 == 0x04


# Generated at 2022-06-22 09:32:50.166132
# Unit test for constructor of class Proxy
def test_Proxy():
    p = Proxy(ProxyType.SOCKS4, 'host', 1234, 'user', 'pass', True)
    assert p.type == ProxyType.SOCKS4
    assert p.host == 'host'
    assert p.port == 1234
    assert p.username == 'user'
    assert p.password == 'pass'
    assert p.remote_dns

# Generated at 2022-06-22 09:33:02.218079
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Python 2
    if hasattr(socket, '_fileobject'):
        import fileobject
        _sockssocket = fileobject.FileObject
    else:
        _sockssocket = socket._fileobject
    class TestSocket(sockssocket, _sockssocket):
        def __init__(self, *args, **kwargs):
            sock = args[0]
            self._sock = sock._sock
            self._rbuf = bytearray()
            self._wbuf = bytearray()
            self._rbufsize = -1
            self._wbufsize = socket._BUFSIZE
            self.mode = 'b'
            self.bufsize = -1
            self._close = 0
            self._close_conn = 0
            self._did_close_socket = False
            self._did_close

# Generated at 2022-06-22 09:33:04.242769
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04
    print("Test case for constructor of class Socks5AddressType: pass")


# Generated at 2022-06-22 09:33:05.685076
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    error = InvalidVersionError(0x00, 0xff)
    assert error.args[0] == 0x00
    assert 'Invalid response version from server. Expected 00 got ff' in str(error)

# Generated at 2022-06-22 09:33:09.581521
# Unit test for constructor of class ProxyError
def test_ProxyError():
    msg = 'Test message'
    pe = ProxyError(1, msg)
    assert pe.errno == 1
    assert pe.strerror == msg

    pe = ProxyError(11)
    assert pe.errno == 11
    assert pe.strerror == 'unknown error'

    pe = ProxyError('Test message')
    assert pe.errno is None
    assert pe.strerror == 'Test message'

# Generated at 2022-06-22 09:33:10.814648
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sock = sockssocket()
    assert sock == socket.socket()
    assert sock._proxy is None


# Generated at 2022-06-22 09:33:15.352938
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:33:16.927408
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error(0x00).msg == 'success'

# Generated at 2022-06-22 09:33:26.064614
# Unit test for constructor of class ProxyError
def test_ProxyError():
    # without code
    assert ProxyError().args == (-1, 'unknown error')
    assert ProxyError().args[0] == -1
    assert ProxyError().args[1] == 'unknown error'
    # with code
    assert ProxyError(code=1).args == (1, 'unknown error')
    assert ProxyError(code=1).args[0] == 1
    assert ProxyError(code=1).args[1] == 'unknown error'
    assert ProxyError(code=Socks4Error.ERR_SUCCESS).args == (Socks4Error.ERR_SUCCESS, 'request rejected or failed')
    assert ProxyError(code=Socks4Error.ERR_SUCCESS).args[0] == Socks4Error.ERR_SUCCESS

# Generated at 2022-06-22 09:33:28.420285
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    with assert_raises(Socks4Error) as err:
        raise Socks4Error(92)
    assert_equal(err.code, 92)

# Generated at 2022-06-22 09:33:40.228331
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(3, 4)
    except InvalidVersionError as e:
        assert e.args == (0, 'Invalid response version from server. Expected 03 got 04')

# Generated at 2022-06-22 09:33:49.815878
# Unit test for constructor of class Proxy
def test_Proxy():
    assert Proxy(1, 2, 3, 4, 5, 6) == Proxy(ProxyType.SOCKS4, 2, 3, 4, 5, 6)
    assert Proxy(1, 2, 3, 4, 5, 6) == Proxy(1, 2, 3, 4, 5, 6)
    assert Proxy(1, 2, 3, 4, 5, 6) != Proxy(1, 2, 3, 4, 6, 6)
    assert Proxy(1, 2, 3, 4, 5, 6) != Proxy(1, 2, 4, 4, 5, 6)
    assert Proxy(1, 2, 3, 4, 5, 6) != Proxy(1, 3, 3, 4, 5, 6)


# Generated at 2022-06-22 09:33:59.546517
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    try:
        raise Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    except Socks5Error as e:
        assert e.args[1] == 'general SOCKS server failure'
    else:
        raise AssertionError('Test failed!')


if __name__ == '__main__':
    import sys

    # Test IPv4
    # with sockssocket() as s:
    #     s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080)
    #     s.connect((sys.argv[1], int(sys.argv[2])))
    #     s.sendall(b'GET / HTTP/1.0\r\n\r\n')
    #     print(s.recv(1024).decode('utf

# Generated at 2022-06-22 09:34:05.001319
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    expected_version = 1
    got_version = 2
    test_obj = InvalidVersionError(expected_version, got_version)

    assert test_obj.code is None
    assert test_obj.msg == 'Invalid response version from server. Expected 01 got 02'

# Generated at 2022-06-22 09:34:14.419417
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    import random

    class Test_sockssocket_recvall(unittest.TestCase):
        def test_recvall(self):
            # Test data length is set as a power of 2
            for l in [2**i for i in range(10, 14)]:

                # Randomly generate test data of length l
                # using ASCII code between 32 and 126
                test_data = bytes(random.randrange(32, 126) for i in range(l))
                test_socket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
                test_socket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8080)

                # Use the following code to test sockssocket.recvall method
                # test_socket.connect(('example.com

# Generated at 2022-06-22 09:34:17.935222
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF

# Generated at 2022-06-22 09:34:19.430278
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 1
    assert Socks4Command.CMD_BIND == 2



# Generated at 2022-06-22 09:34:23.957970
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:34:27.178917
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03 and Socks5AddressType.ATYP_DOMAINNAME == Socks5AddressType.ATYP_IPV6 - 1
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-22 09:34:31.034160
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    print("Testing Socks4Error")
    code=91
    msg=Socks4Error.CODES[code]
    err=Socks4Error(code, msg)

# Generated at 2022-06-22 09:34:39.459941
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    Socks5Error(1)

# Generated at 2022-06-22 09:34:41.760980
# Unit test for constructor of class Proxy
def test_Proxy():
    try:
        assert Proxy(1, 'foo', 80, 'user', 'password', False)
        assert Proxy(2, 'bar', 8080, 'user', 'password', True)
        assert Proxy(3, 'baz', 8888, 'user', 'password', False)
    except:
        print('Incorrect constructor.')
        raise


# Generated at 2022-06-22 09:34:45.247347
# Unit test for constructor of class ProxyType
def test_ProxyType():
    """Test SOCKS proxy implementation."""
    try:
        s = sockssocket()
        s.setproxy(ProxyType.SOCKS4A, "8.8.8.8", 1080)
        s.connect(("example.org", 80))
    except ProxyError as e:
        print("Error connecting to proxy:", e)

    try:
        s = sockssocket()
        s.setproxy(ProxyType.SOCKS5, "localhost", 1080)
        s.connect(("example.org", 80))
    except ProxyError as e:
        print("Error connecting to proxy:", e)

if __name__ == '__main__':
    test_ProxyType()

# Generated at 2022-06-22 09:34:55.890856
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    import logging
    logging.basicConfig(level=logging.DEBUG)

    ss = sockssocket()
    try:
        # It should raise ProxyError with code 91 if fail to connect
        ss.setproxy(proxytype=ProxyType.SOCKS5, addr='wrong_addr', port=8)
        ss.connect_ex(address=('www.baidu.com', 80))
    except Socks5Error as e:
        if e.errno == 91:
            pass
        else:
            raise e
    # It should raise ProxyError with code 92 if fail to connect
    ss.setproxy(proxytype=ProxyType.SOCKS4A, addr='wrong_addr', port=8)

# Generated at 2022-06-22 09:35:00.390136
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    error = Socks5Error()
    assert error.args[0] == 0
    assert str(error) == 'unknown error'

    error = Socks5Error(Socks5Error.ERR_GENERAL_FAILURE)
    assert error.args[0] == Socks5Error.ERR_GENERAL_FAILURE
    assert str(error) == 'general SOCKS server failure'



# Generated at 2022-06-22 09:35:02.558209
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    print(Socks5Command.CMD_CONNECT)
    print(Socks4Command.CMD_CONNECT)


# Generated at 2022-06-22 09:35:04.515700
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
	s = Socks5Error(1)
	assert s.args == (1, 'general SOCKS server failure')


# Generated at 2022-06-22 09:35:06.402720
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02



# Generated at 2022-06-22 09:35:08.641198
# Unit test for constructor of class sockssocket
def test_sockssocket():
    ss = sockssocket()
    assert(ss.family == socket.AF_INET)
    assert(ss.type == socket.SOCK_STREAM)



# Generated at 2022-06-22 09:35:10.403207
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01
    assert Socks4Command.CMD_BIND == 0x02


# Generated at 2022-06-22 09:35:40.442061
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    ss = sockssocket()
    try:
        ss.setproxy()
        assert False
    except AssertionError:
        pass
    try:
        ss.setproxy(1,1)
        assert False
    except AssertionError:
        pass
    try:
        ss.setproxy(1,1,1)
        assert False
    except AssertionError:
        pass
    ss.setproxy(1,1,1,1)
    assert ss._proxy.type == 1
    assert ss._proxy.host == 1
    assert ss._proxy.port == 1
    assert ss._proxy.rdns == 1
    assert ss._proxy.username == None
    assert ss._proxy.password == None
    ss.setproxy(1,1,1,1,'x','y')

# Generated at 2022-06-22 09:35:48.798210
# Unit test for constructor of class ProxyType
def test_ProxyType():
    try:
        # ProxyType(0, 'localhost', 1080, 'socks', 'socks')
        proxy = ProxyType.SOCKS4
        host = 'localhost'
        port = 1080
        username = 'socks'
        password = 'socks'
        print('type', proxy.type, ' username ', username, 'password ', password)
        socks5 = Proxy(proxy, host, port, username, password, True)
        pass
    except:
        print('test_ProxyType FAILED')
    return socks5



# Generated at 2022-06-22 09:35:54.264370
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    sock = sockssocket()
    sock.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8080)
    sock.connect(('127.0.0.1', 8080))
    print("OK")

if __name__ == '__main__':
    test_sockssocket_connect()

# Generated at 2022-06-22 09:35:56.985158
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket()
    try:
        sock.recvall(1)
    except EOFError:
        return True
    return False


# Generated at 2022-06-22 09:35:59.773423
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    # Test default
    socks5erro = Socks5Error(code=0x01)
    assert socks5erro.args == (0x01, 'general SOCKS server failure')

# Generated at 2022-06-22 09:36:08.283545
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    # For bound variables of constructor, no exceptions should be raised
    socks5_error = Socks5Error(1, 'General SOCKS server failure')
    assert socks5_error.args == (1, 'General SOCKS server failure')
    socks5_error = Socks5Error(None, 'General SOCKS server failure')
    assert socks5_error.args == (None, 'General SOCKS server failure')
    socks5_error = Socks5Error(1, None)
    assert socks5_error.args == (1, 'unknown error')
    socks5_error = Socks5Error(None, None)
    assert socks5_error.args == (None, 'unknown error')
    # For unbound variables of constructor, exceptions should be raised
    # KeyError: 1

# Generated at 2022-06-22 09:36:20.343609
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    proxy = Proxy(ProxyType.SOCKS5, '127.0.0.1', 8080)
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8080)
    assert s._proxy == proxy
    s.close()
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    proxy = Proxy(ProxyType.SOCKS5, '127.0.0.1', 8080, 'jesus', '123')
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8080, username='jesus', password='123')
    assert s._proxy == proxy
    s.close()

# Generated at 2022-06-22 09:36:23.888045
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(expected_version=1, got_version=0)
    except socket.error as e:
        assert e.errno == 0
        assert e.strerror == 'Invalid response version from server. Expected 01 got 00'
        return

# Generated at 2022-06-22 09:36:29.492722
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy(ProxyType.SOCKS4, '127.0.0.1', 9050, 'user', 'pass', False)
    assert(proxy.type == ProxyType.SOCKS4)
    assert(proxy.host == '127.0.0.1')
    assert(proxy.port == 9050)
    assert(proxy.username == 'user')
    assert(proxy.password == 'pass')
    assert(not proxy.remote_dns)

# Generated at 2022-06-22 09:36:37.530003
# Unit test for constructor of class Proxy
def test_Proxy():
    # Test by creating Proxy object with valid and invalid parameters
    # Valid parameters
    proxy = Proxy(ProxyType.SOCKS5, '127.0.0.1', 8080, None, None, True)
    assert isinstance(proxy, Proxy)
    # Invalid parameters - value should be valid enum ProxyType
    try:
        Proxy(4, '127.0.0.1', 8080, None, None, True)
    except AssertionError:
        raise AssertionError('test_Proxy() failed')
    except:
        pass
    else:
        raise AssertionError('test_Proxy() failed')


if __name__ == '__main__':
    test_Proxy()

# Generated at 2022-06-22 09:37:16.676363
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 1
    assert Socks5AddressType.ATYP_DOMAINNAME == 3
    assert Socks5AddressType.ATYP_IPV6 == 4


# Generated at 2022-06-22 09:37:17.998394
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    print(Socks4Error(91))


# Generated at 2022-06-22 09:37:24.036250
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0x00, 0x01)
    except InvalidVersionError as e:
        assert e.args[0] == 0
        assert e.args[1] == ('Invalid response version from server. Expected 00 got 01')
    else:
        assert False


# Generated at 2022-06-22 09:37:27.758910
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    Socks5Command()
    Socks5Command.CMD_BIND
    Socks5Command.CMD_CONNECT
    Socks5Command.CMD_UDP_ASSOCIATE

# Generated at 2022-06-22 09:37:31.521755
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(3, 5)  # Expected version and got version
    except InvalidVersionError:
        pass
    except:
        assert 0  # Incorrect exception raised


# Generated at 2022-06-22 09:37:33.841625
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-22 09:37:37.607890
# Unit test for constructor of class sockssocket
def test_sockssocket():
    sock = sockssocket()
    assert sock.family == socket.AF_INET
    assert sock.type == socket.SOCK_STREAM
    assert sock.proto == 0
    assert sock.fileno() > 0
    assert sock._proxy is None


# Generated at 2022-06-22 09:37:40.352272
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    T = Socks5AddressType()
    assert T.ATYP_IPV4 == 0x01
    assert T.ATYP_DOMAINNAME == 0x03
    assert T.ATYP_IPV6 == 0x04

# Generated at 2022-06-22 09:37:49.470832
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    # Method test_sockssocket_setproxy of class sockssocket should set the _proxy attribute
    socks = sockssocket()
    socks.setproxy(ProxyType.SOCKS4, '127.0.0.1', 1234)
    assert socks._proxy.type == ProxyType.SOCKS4
    assert socks._proxy.host == '127.0.0.1'
    assert socks._proxy.port == 1234
    assert socks._proxy.username == None
    assert socks._proxy.password == None
    assert socks._proxy.remote_dns == True


# Generated at 2022-06-22 09:37:51.854256
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    Socks4Command.CMD_CONNECT == 0x01
    Socks4Command.CMD_BIND == 0x02

test_Socks4Command()


# Generated at 2022-06-22 09:39:20.199797
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    with sockssocket() as sock:
        sock.setproxy(socks.SOCKS4, "127.0.0.1", 12345)
        assert sock.getpeername() == ("127.0.0.1", 12345)

# Generated at 2022-06-22 09:39:27.274259
# Unit test for method connect of class sockssocket
def test_sockssocket_connect():
    proxy = Proxy(ProxyType.SOCKS4, 'localhost', 1080)
    client = sockssocket()
    client.setproxy(*proxy)
    try:
        client.connect(('www.socksproxychecker.com', 80))
        client.sendall(b'GET / HTTP/1.1\r\n\r\n')
        print(client.recv(1024))
    finally:
        client.close()


if __name__ == '__main__':
    test_sockssocket_connect()

# Generated at 2022-06-22 09:39:29.677556
# Unit test for method connect_ex of class sockssocket
def test_sockssocket_connect_ex():
    print("test_sockssocket_connect_ex:")
    p = sockssocket()
    p.setproxy(ProxyType.SOCKS5, 'proxy.example.com', 1080)
    p.connect_ex(('www.google.com', 80))

# Generated at 2022-06-22 09:39:34.150170
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(1, 2)
        assert False, 'InvalidVersionError constructor should have thrown'
    except InvalidVersionError as e:
        assert type(e) == InvalidVersionError
        assert e.args[0] == 1
        assert e.args[1] == 2
        assert str(e) == 'Invalid response version from server. Expected 01 got 02'


# Generated at 2022-06-22 09:39:37.945824
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:39:41.434766
# Unit test for constructor of class ProxyType
def test_ProxyType():
    assert ProxyType.SOCKS4 == 0
    assert ProxyType.SOCKS4A == 1
    assert ProxyType.SOCKS5 == 2


# Generated at 2022-06-22 09:39:48.916652
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = socksocket.__new__(sockssocket)
    s.setproxy(ProxyType.SOCKS4, '123.123.123.123', 1080, False, None, None)
    assert s._proxy.type == ProxyType.SOCKS4
    assert s._proxy.host == '123.123.123.123'
    assert s._proxy.port == 1080
    assert s._proxy.username is None
    assert s._proxy.password is None
    assert s._proxy.remote_dns is False



# Generated at 2022-06-22 09:39:50.551953
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS4, '127.0.0.1', 80)
    s.close()

# Generated at 2022-06-22 09:40:01.559776
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import struct
    from select import select
    from SocketServer import BaseRequestHandler, TCPServer

    server = None
    client_socket = None

    def _start_server():
        class _Handler(BaseRequestHandler):
            def handle(self):
                self.request.sendall(struct.pack('!B', 1) + b'A' * 10)
        global server
        global client_socket
        server = TCPServer(('', 0), _Handler)
        client_socket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.settimeout(0.5)
        client_socket.connect((server.server_address[0], server.server_address[1]))

    def _stop_server():
        global server
        server.server_close()
        server.shutdown()

# Generated at 2022-06-22 09:40:09.648523
# Unit test for constructor of class sockssocket
def test_sockssocket():
    import sys
    import os
    import mock
    # with mock.patch.object(sys, 'argv', ['sockssocket', '0']):
    #    assert sockssocket.sockssocket.__init__()
    with mock.patch.object(sys, 'argv', ['sockssocket.py', '1']):
        assert sockssocket.sockssocket.__init__()
    with mock.patch.object(sys, 'argv', ['sockssocket.py', '2']):
        assert sockssocket.sockssocket.__init__()