

# Generated at 2022-06-12 19:20:36.607380
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(sockssocket.PROXY_TYPE_SOCKS5, "localhost", 3128)
    s.connect(("google.com",80))


# Generated at 2022-06-12 19:20:48.588362
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    tests_results = []

    # Create a new socket to test recvall method
    s = socket.socket()
    s.bind(('localhost', 0))
    s.listen(1)
    s_addr = s.getsockname()
    s.setblocking(0)

    # Test recvall method
    try:
        # Create socket client
        c = sockssocket()
        c.bind(('localhost', 0))
        c.connect(s_addr)
        c_addr = c.getsockname()

        result_recvall = True

        # Check behavior of recvall method when closing sockets
        s.close()
        c.close()
        tests_results.append(result_recvall)
    except EOFError:
        result_recvall = False

# Generated at 2022-06-12 19:20:52.260851
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    exception = InvalidVersionError(SOCKS4_REPLY_VERSION, SOCKS4_REPLY_VERSION)
    code, msg = exception.args
    assert code is None
    assert msg is None



# Generated at 2022-06-12 19:20:54.910780
# Unit test for constructor of class ProxyError
def test_ProxyError():
    ProxyError(1)
    ProxyError(1, 'test message')
    ProxyError(msg='test message')
    with pytest.raises(TypeError):
        ProxyError(1, msg='test message')

# Generated at 2022-06-12 19:21:04.027900
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import struct
    import time

    def send_data(sock, data):
        data_len = len(data)
        for i in range(data_len):
            time.sleep(0.001)
            sock.send(struct.pack('!B', data[i]))

    s = sockssocket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(('127.0.0.1', 0))
    s.listen(1)
    sock, _ = s.accept()

    send_data(sock, [1, 2, 3])
    assert s.recvall(3) == b'\x01\x02\x03'


# Generated at 2022-06-12 19:21:13.878411
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    server_addr = ('localhost', 8888)
    server = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(server_addr)
    server.listen(1)
    client = sockssocket(socket.AF_INET, socket.SOCK_STREAM)

    # connect
    try:
        client.connect(server_addr)
    except socket.error as err:
        if err.errno == socket.errno.ECONNREFUSED:
            pass

    server_conn, _ = server.accept()
    server_conn.sendall(compat_struct_pack('!HHH', 42, 43, 44))

# Generated at 2022-06-12 19:21:25.680133
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    import os
    import sys

    SOCKS4_PROXY_ADDR = os.environ.get('SOCKS4_PROXY_ADDR') or '127.0.0.1'
    SOCKS4_PROXY_PORT = int(os.environ.get('SOCKS4_PROXY_PORT') or '9050')
    SOCKS5_PROXY_ADDR = os.environ.get('SOCKS5_PROXY_ADDR') or '127.0.0.1'
    SOCKS5_PROXY_PORT = int(os.environ.get('SOCKS5_PROXY_PORT') or '9050')


# Generated at 2022-06-12 19:21:34.019888
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    from .compat import compat_urllib_request
    url = 'http://ip.jsontest.com/'
    proxy = Proxy(
        proxy_type=ProxyType.SOCKS5,
        host='127.0.0.1',
        port=1081,
        username='username',
        password='password',
        remote_dns=True
    )
    opener = compat_urllib_request.build_opener(
        compat_urllib_request.ProxyHandler({'http': proxy}),
        compat_urllib_request.HTTPHandler())
    response = opener.open(url, timeout=3)
    result = response.read()
    print(result)

if __name__ == '__main__':
    test_sockssocket_recvall()

# Generated at 2022-06-12 19:21:36.442079
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    assert InvalidVersionError(0x00, 0xFF).errno == 0
    assert InvalidVersionError(0, 'unknown error').errno == 0


# Generated at 2022-06-12 19:21:44.475777
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    socket.socket.recvall = sockssocket.recvall

    #
    # Test method with a small content
    #
    _sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    _sock.settimeout(1)
    _sock.connect(('127.0.0.1', 80))
    _sock.recvall(6)
    _sock.close()

    #
    # Test method with a large content
    #
    _sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    _sock.settimeout(1)
    _sock.connect(('127.0.0.1', 80))
    _sock.recvall(200000)
    _sock.close()


# Run

# Generated at 2022-06-12 19:22:00.790010
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    socks = sockssocket()
    socks.setproxy(ProxyType.SOCKS5, 'foo.bar', 8888, True, 'username', 'password')
    assert socks._proxy.type == ProxyType.SOCKS5
    assert socks._proxy.host == 'foo.bar'
    assert socks._proxy.port == 8888
    assert socks._proxy.remote_dns
    assert socks._proxy.username == 'username'
    assert socks._proxy.password == 'password'



# Generated at 2022-06-12 19:22:04.580147
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    s.connect(('127.0.0.1', 4444))
    s.sendall(b'Hello sockssocket')
    assert s.recvall(5) == b'Hello'


# Generated at 2022-06-12 19:22:11.619295
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    nsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    nsock.bind(('0.0.0.0', 0))
    nsock_addr = nsock.getsockname()
    assert nsock_addr[0] != '0.0.0.0'
    nsock.listen(1)
    try:
        assert sock.recvall(10)
    except EOFError:
        pass
    else:
        assert False
    try:
        assert sock.recvall(10)
    except socket.error:
        pass
    else:
        assert False
    sock.connect(nsock_addr)
    assert sock.recvall(10)

# Generated at 2022-06-12 19:22:21.787189
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import select
    recv_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    recv_socket.bind(('127.0.0.1', 0))
    recv_socket.listen(1)

    # testing sockssocket recvall
    test_passed = True
    test_socket = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    test_socket.connect(recv_socket.getsockname())
    recv_socket.settimeout(1)
    (conn_socket, _) = recv_socket.accept()
    conn_socket.settimeout(1)
    conn_socket.send(b'abc')
    conn_socket.close()

# Generated at 2022-06-12 19:22:27.371810
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    assert(s._proxy is None)
    s.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 12345, rdns=False, username='testuser')
    assert(s._proxy.type == ProxyType.SOCKS4A)
    assert(s._proxy.host == '127.0.0.1')
    assert(s._proxy.port == 12345)
    assert(s._proxy.remote_dns == False)
    assert(s._proxy.username == 'testuser')
    assert(s._proxy.password is None)
    s.setproxy(ProxyType.SOCKS5, '1.2.3.4', 54321, rdns=True, username='testuser', password='testpass')

# Generated at 2022-06-12 19:22:35.816668
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.setproxy(ProxyType.SOCKS5, '1.2.3.4', 1080)

    def get_socket_mock(sock):
        def recv(*_):
            return b'ab'[len(recv.buff)]

        recv.buff = b''

        def _recv(*args):
            recv.buff += recv(*args)
            return recv.buff

        sock.recv = _recv
        return sock

    s = get_socket_mock(s)
    assert s.recvall(2) == b'ab'

# Generated at 2022-06-12 19:22:40.286204
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket()
    sock.connect(('google.com', 80))
    sock.sendall(b'GET / HTTP/1.0\n\n')
    buf = sock.recvall(4096)
    assert len(buf) > 0
    # print(buf)
    sock.close()


socksocket = sockssocket

# Generated at 2022-06-12 19:22:46.871639
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(('www.google.com', 80))
    sock.sendall(b'GET / HTTP/1.0\r\n\r\n')
    head = sock.recvall(100)
    print(head)


if __name__ == '__main__':
    test_sockssocket_recvall()

# Generated at 2022-06-12 19:22:55.507568
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    global sockssocket
    proxytype = ProxyType.SOCKS5
    addr = "127.0.0.1"
    port = 8090
    username = ""
    password = ""

    sock = sockssocket()
    sock.setproxy(proxytype, addr, port, True, username, password)

    print(repr(sock))
    print(type(sock))
    print(sock.family)
    print(sock.type)
    print(sock.proto)
    print(sock._proxy)


# Generated at 2022-06-12 19:23:04.829228
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    test_data = (
        (b'abcdefg', 0),
        (b'abcdefg', 1),
        (b'abcdefg', 2),
        (b'abcdefg', 5),
        (b'abcdefg', 7),
    )

    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)

    for data, cnt in test_data:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_RCVTIMEO, 1)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_SNDTIMEO, 1)
        s.listen(1)
        client = sockssocket(socket.AF_INET, socket.SOCK_STREAM)

# Generated at 2022-06-12 19:28:17.557388
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    # Verify the inheritance of class sockssocket from class socket.socket
    assert issubclass(sockssocket, socket.socket)

    test_sockssocket = sockssocket()

    # Verify that the instance test_sockssocket of class sockssocket can invoke the method setproxy
    test_sockssocket.setproxy(1, '127.0.0.1', 1080)

    # Verify that the instance test_sockssocket of class sockssocket can invoke the method connect
    test_sockssocket.connect(('127.0.0.1', 1080))


# Generated at 2022-06-12 19:28:22.236112
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    print("[+] Testing setproxy...")
    ss = sockssocket()
    ss.setproxy(ProxyType.SOCKS5, "127.0.0.1", 1086)
    print("[+] setproxy success...")
    print("[+] Done.")

if __name__ == '__main__':
    test_sockssocket_setproxy()

# Generated at 2022-06-12 19:28:25.291581
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    socket.socksocket.setproxy(ProxyType.SOCKS5, '127.0.0.1', 8080)
    assert socket.socksocket._proxy == Proxy(ProxyType.SOCKS5, '127.0.0.1', 8080, None, None, True)

# Generated at 2022-06-12 19:28:31.921719
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    ss = sockssocket()
    ss.setproxy(ProxyType.SOCKS4, '127.0.0.1', 9656)
    ss.connect(('www.google.com', 80))
    ss.setproxy(ProxyType.SOCKS4, '127.0.0.1', 9656, username='user', password='pass')
    ss.connect(('www.google.com', 80))
    ss.setproxy(ProxyType.SOCKS4A, '127.0.0.1', 9656, username='user', password='pass')
    ss.connect(('www.google.com', 80))
    ss.setproxy(ProxyType.SOCKS5, '127.0.0.1', 9656)
    ss.connect(('www.google.com', 80))

# Generated at 2022-06-12 19:28:36.056887
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    # Arrange
    ss = sockssocket()

    # Act
    ss.setproxy(ProxyType.SOCKS4, 'localhost', 8080)
    ss.setproxy(ProxyType.SOCKS4A, 'localhost', 8080)
    ss.setproxy(ProxyType.SOCKS5, 'localhost', 8080)

    # Assert
    assert ss._proxy.type == ProxyType.SOCKS5

# Generated at 2022-06-12 19:28:42.551062
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    def _print_result(result, expected):
        print('Result is: ' + str(result))
        print('Expected is: ' + str(expected))
        if(result == expected):
            print('Setproxy test case: OK!')
        else:
            print('Setproxy test case: Failed!')

    # value proxytype
    s = sockssocket()
    _print_result(s.setproxy('socks4', '192.168.0.1', 80), 'Error: proxy type invalid')
    _print_result(s.setproxy(4, '192.168.0.1', 80), 'Error: proxy type invalid')
    _print_result(s.setproxy(ProxyType.SOCKS4, '192.168.0.1', 80), 'Error: proxy type invalid')

# Generated at 2022-06-12 19:28:47.965399
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    try:
        s = sockssocket()
        s.setproxy(ProxyType.SOCKS4, "10.10.10.10", 1080)
        msg = "test_sockssocket_setproxy ok"
    except Exception as e:
        msg = "test_sockssocket_setproxy error: {0}".format(e)
    print(msg)


# Generated at 2022-06-12 19:28:51.033201
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    print(dir(sockssocket))
    '''
    assert sockssocket._proxy.type == 4
    assert sockssocket._proxy.host == '127.0.0.1'
    assert sockssocket._proxy.port == 1080
    assert sockssocket._proxy.username == None
    assert sockssocket._proxy.password == None
    '''



# Generated at 2022-06-12 19:29:00.917547
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    test_remote_dns = True
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, username='test', password='test', remote_dns=test_remote_dns)
    if s._proxy.type != ProxyType.SOCKS5:
        print(s._proxy.type)
        assert False
    if s._proxy.host != '127.0.0.1':
        print(s._proxy.host)
        assert False
    if s._proxy.port != 1080:
        print(s._proxy.port)
        assert False
    if s._proxy.username != 'test':
        print(s._proxy.username)
        assert False
    if s._proxy.password != 'test':
        print(s._proxy.password)


# Generated at 2022-06-12 19:29:08.296341
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    host='127.0.0.1'
    port=9090
    auth=b'authuser:authpass\x00'
    auth_len=len(auth)
    auth_len_encoded=compat_struct_pack('!B', auth_len)
    socks5_version=5
    socks5_version_encoded=compat_struct_pack('!B', socks5_version)
    username=b'user\x00'

    socks=sockssocket(socket.AF_INET,socket.SOCK_STREAM)

    socks.setproxy(ProxyType.SOCKS4,'localhost',9090)
    assert socks._proxy.type==0, 'socks._proxy.type erroneously set'
    assert socks._proxy.host=='localhost'
    assert socks._proxy.port==9090
   

# Generated at 2022-06-12 19:29:49.798204
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    assert InvalidVersionError(b'a', 1).args == (0, 'Invalid response version from server. Expected 61 got 01')


if __name__ == '__main__':
    for x in ('4a', '4', '5'):
        print('Testing SOCKS{0}'.format(x))
        s = sockssocket()
        # proxy = ('proxy.example.com', 3128)
        proxy = ('localhost', 1080)
        if x == '4a':
            s.setproxy(ProxyType.SOCKS4A, *proxy)
        elif x == '4':
            s.setproxy(ProxyType.SOCKS4, *proxy)
        else:
            s.setproxy(ProxyType.SOCKS5, *proxy)
        s.settimeout(2)

# Generated at 2022-06-12 19:29:50.754209
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    pass



# Generated at 2022-06-12 19:29:53.905797
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    command = Socks5Command()
    assert command.CMD_CONNECT == 0x01
    assert command.CMD_BIND == 0x02
    assert command.CMD_UDP_ASSOCIATE == 0x03

# Generated at 2022-06-12 19:29:59.278930
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    # Test setting/getting of all attributes of a "Proxy" namedtuple
    proxy_type = ProxyType.SOCKS5
    host = 'localhost'
    port = 1234
    username = 'socksuser'
    password = 'somepass'
    remote_dns = True
    ss = sockssocket()
    ss.setproxy(proxy_type, host, port, remote_dns, username, password)
    assert ss._proxy.type == proxy_type
    assert ss._proxy.host == host
    assert ss._proxy.port == port
    assert ss._proxy.username == username
    assert ss._proxy.password == password
    assert ss._proxy.remote_dns == remote_dns

    # Test setting/getting of all attributes of a "Proxy" namedtuple
    # without optional arguments
    proxy_type = ProxyType

# Generated at 2022-06-12 19:30:02.533043
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04


# Generated at 2022-06-12 19:30:06.504210
# Unit test for constructor of class Socks5Auth
def test_Socks5Auth():
    assert Socks5Auth.AUTH_NONE == 0x00
    assert Socks5Auth.AUTH_GSSAPI == 0x01
    assert Socks5Auth.AUTH_USER_PASS == 0x02
    assert Socks5Auth.AUTH_NO_ACCEPTABLE == 0xFF



# Generated at 2022-06-12 19:30:11.126234
# Unit test for constructor of class Proxy
def test_Proxy():
    proxy = Proxy('testtype', 'testhost', 'testport', 'testusername', 'testpassword', 'testremote_dns')
    assert proxy.type == 'testtype'
    assert proxy.host == 'testhost'
    assert proxy.port == 'testport'
    assert proxy.username == 'testusername'
    assert proxy.password == 'testpassword'
    assert proxy.remote_dns == 'testremote_dns'


if __name__ == "__main__":
    test_Proxy()

# Generated at 2022-06-12 19:30:13.260123
# Unit test for constructor of class Socks5AddressType
def test_Socks5AddressType():
    assert Socks5AddressType.ATYP_IPV4 == 0x01
    assert Socks5AddressType.ATYP_DOMAINNAME == 0x03
    assert Socks5AddressType.ATYP_IPV6 == 0x04

# Generated at 2022-06-12 19:30:14.982606
# Unit test for constructor of class Socks4Command
def test_Socks4Command():
    assert Socks4Command.CMD_CONNECT == 0x01


# Generated at 2022-06-12 19:30:16.958345
# Unit test for constructor of class Socks5Command
def test_Socks5Command():
    command = Socks5Command()
    assert command.CMD_CONNECT == 0x01
    assert command.CMD_BIND == 0x02
    assert command.CMD_UDP_ASSOCIATE == 0x03