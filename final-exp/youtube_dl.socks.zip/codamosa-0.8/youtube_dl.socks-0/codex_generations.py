

# Generated at 2022-06-12 19:20:35.396744
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(expected_version=1, got_version=2)
    except InvalidVersionError as ex:
        assert ex.args[0] == 1
        assert ex.args[1] == 'Invalid response version from server. Expected 01 got 02'



# Generated at 2022-06-12 19:20:39.242095
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import pytest

    s = sockssocket()
    s.bind(('', 0))
    with pytest.raises(EOFError):
        s.recvall(1)

# Generated at 2022-06-12 19:20:44.659423
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    s.setblocking(False)
    try:
        s.recvall(1)
    except EOFError as e:
        if e.message == '1 bytes missing':
            return True
        else:
            return False


# Generated at 2022-06-12 19:20:46.356572
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    s.recvall(10)
    return True

# Generated at 2022-06-12 19:20:50.020552
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    print('Testing sockssocket.recvall...')

    # Create the test object (a string)
    test_obj = 'test_string'

    def mock_recv(cnt):
        # Get first `cnt` chars of the string
        str_cnt = test_obj[0:cnt]
        # Cut the string
        test_obj = test_obj[cnt:]
        return str_cnt

    # Patch the object
    sockssocket.recv = mock_recv

    # Run the tested method
    received_str = sockssocket.recvall(len(test_obj))

    # Assert it's correct
    assert received_str == test_obj
    print('Passed')


# Generated at 2022-06-12 19:20:57.330339
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import pytest
    ss = sockssocket()
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        s.connect(s.getsockname())
        ss.setproxy(ProxyType.SOCKS5, '127.0.0.1', s.getsockname()[1])
        ss.connect(('8.8.8.8', 80))
        ss.sendall(b'GET / HTTP/1.1\r\n\r\n')
        import time
        time.sleep(0.1)
        from pprint import pprint
        pprint(ss.recvall(1024))


# Generated at 2022-06-12 19:21:02.364302
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, "localhost", 1080, rdns=True, username="test", password="test")
    assert s._proxy.type == ProxyType.SOCKS5
    assert s._proxy.username == "test"
    assert s._proxy.password == "test"
    assert s._proxy.remote_dns == True

# Generated at 2022-06-12 19:21:11.532537
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(0)
    except ProxyError as e:
        assert e.errno == 0
        assert e.strerror == 'unknown error'

    try:
        raise ProxyError(0xab, 'strerrormy')
    except ProxyError as e:
        assert e.errno == 0xab
        assert e.strerror == 'strerrormy'

    try:
        raise ProxyError(0xab)
    except ProxyError as e:
        assert e.errno == 0xab
        assert e.strerror == 'unknown error'



# Generated at 2022-06-12 19:21:17.193605
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    ss = sockssocket()
    ss.sendall('abcdefgh')
    assert ss.recvall(5) == 'abcde'
    assert ss.recvall(5) == 'fgh'
    ss.close()

if __name__ == '__main__':
    test_sockssocket_recvall()

# Generated at 2022-06-12 19:21:23.041689
# Unit test for constructor of class InvalidVersionError
def test_InvalidVersionError():
    try:
        raise InvalidVersionError(0x04, 0x05)
    except InvalidVersionError as e:
        assert e.errno == 0
        assert(e.strerror == 'Invalid response version from server. Expected 04 got 05')
    except Exception as e:
        assert False, 'InvalidVersionError failed'
    finally:
        print('InvalidVersionError test passed')


# Generated at 2022-06-12 19:22:04.064345
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    from .compat import compat_unichr
    socks = sockssocket()
    assert socks._proxy is None
    socks.setproxy(0, '10.2.2.2', 1234)
    assert socks._proxy.type == 0
    assert socks._proxy.host == '10.2.2.2'
    assert socks._proxy.port == 1234
    assert socks._proxy.username is None
    assert socks._proxy.password is None
    assert socks._proxy.remote_dns is True
    socks.setproxy(0, '10.2.2.2', 1234, False, '\u00e6', '\u00e7')
    assert socks._proxy.type == 0
    assert socks._proxy.host == '10.2.2.2'
    assert socks._proxy.port == 1234
    assert socks

# Generated at 2022-06-12 19:22:08.697905
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, "123.123.123.123", 123, username="user", password="pass")
    try:
        s.setproxy(ProxyType.SOCKS5, "123.123.123.123", 123, username="user")
    except Exception:
        pass
    s.setproxy(ProxyType.SOCKS5, "123.123.123.123", 123, username="user", password="")

# Generated at 2022-06-12 19:22:15.213651
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    error_code = Socks5Error.ERR_GENERAL_FAILURE
    try:
        raise Socks5Error(error_code)
    except ProxyError as e:
        assert e.errno == error_code
        assert e.msg == 'general SOCKS server failure'


# Generated at 2022-06-12 19:22:18.752864
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Use a local SOCKS5 proxy
    sockssocket.setproxy(ProxyType.SOCKS5, 'localhost', 9999, remote_dns=False)
    s = sockssocket()

    # Try to connect to a SOCKS5 server that simply echoes back what it received
    s.connect(('localhost', 8080))

    # Send 5 bytes of data
    test_str = b"abcde"
    s.sendall(test_str)

    # We should get 5 bytes of data
    assert s.recvall(5) == test_str

# Generated at 2022-06-12 19:22:20.504960
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    print('Testing method setproxy of class sockssocket ...')
    # TODO: create unit test
    print('OK')


# Generated at 2022-06-12 19:22:24.269627
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    socks = sockssocket()
    socks.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, rdns=True, username='username', password='password')
    assert socks._proxy.type == ProxyType.SOCKS5
    assert socks._proxy.host == '127.0.0.1'
    assert socks._proxy.port == 1080
    assert socks._proxy.username == 'username'
    assert socks._proxy.password == 'password'
    assert socks._proxy.remote_dns == True


# Generated at 2022-06-12 19:22:34.649930
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    s.send_data = b'1234567890ABC'
    def my_recv(size):
        return s.send_data[:size]
    s.recv = my_recv
    assert s.recvall(5) == b'12345'
    assert s.recvall(100) == b'67890ABC'
    s.send_data = b'123'
    s.my_recv = my_recv
    assert s.recvall(4) == b'123'
    s.recv = lambda size: b''
    try:
        s.recvall(1)
        assert False, 'recvall should raise error'
    except EOFError:
        pass

# Generated at 2022-06-12 19:22:38.597289
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    ss = sockssocket()
    ss.connect(('127.0.0.1', 9090))
    ss.settimeout(3)
    data = ss.recvall(4)
    for i in range(4):
        assert compat_ord(data[i]) == i+1




# Generated at 2022-06-12 19:22:39.402907
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    assert Socks5Error(0) is not None


# Generated at 2022-06-12 19:22:43.688957
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    ss = sockssocket()
    ss.setproxy(ProxyType.SOCKS4, "127.0.0.1", 9050)
    ss.connect(("127.0.0.1", 9050))
    print('connect_ex test passed!')

# Generated at 2022-06-12 19:23:45.476972
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect(('www.google.com', 80))
    data = b'GET / HTTP/1.1\r\n\r\n'
    sock.sendall(data)
    response = sock.recvall(12)
    assert response == b'HTTP/1.1 200'

if __name__ == '__main__':
    test_sockssocket_recvall()

# Generated at 2022-06-12 19:23:50.935110
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # test successful pass
    test_sock = sockssocket()
    test_sock.test_recv = b"12345"
    test_sock.recv = lambda x: test_sock.test_recv[:x]
    test_result = test_sock.recvall(5)
    assert test_result == b"12345"

    # test EOFError raise
    test_sock = sockssocket()
    test_sock.test_recv = b""
    test_sock.recv = lambda x: test_sock.test_recv[:x]
    try:
        test_result = test_sock.recvall(1)
    except EOFError:
        pass
    else:
        assert False, "EOFError raise expected"



# Generated at 2022-06-12 19:24:02.830540
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import socket
    # Create a TCP/IP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setblocking(False)

    # Connect the socket to the port where the server is listening
    server_address = ('localhost', 10000)
    print(('connecting to %s port %s' % server_address))
    sock.connect(server_address)

    # Create a proxy based on the just created socket
    sks = sockssocket(sock=sock)
    sks._proxy = Proxy(ProxyType.SOCKS4, 'host', 12345, 'username', 'password', True)

    # Send data
    message = b'this is the message.  it will be repeated.'
    print(('sending {0}'.format(message)))
    sks.sendall

# Generated at 2022-06-12 19:24:08.543409
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    s.setblocking(True)
    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 9050)
    s.connect_ex(('127.0.0.1', 9050))
    s.sendall(b'GET / HTTP/1.1\nHost: 127.0.0.1\n\n')
    print(s.recvall(13))

if __name__ == '__main__':
    test_sockssocket_recvall()

# Generated at 2022-06-12 19:24:14.067604
# Unit test for constructor of class Socks5Error
def test_Socks5Error():
    Socks5Error(0x01)
    Socks5Error(0xFF)

    try:
        Socks5Error(0x02)
    except Socks5Error as e:
        assert e.code == 0x02
    else:
        assert False

    try:
        Socks5Error(0x0F)
    except Socks5Error as e:
        assert e.code == 0x0F
    else:
        assert False


# Generated at 2022-06-12 19:24:16.506272
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise ProxyError(None, None)
    except ProxyError as err:
        pass

    return True


# Generated at 2022-06-12 19:24:18.756292
# Unit test for constructor of class Socks4Error
def test_Socks4Error():
    assert Socks4Error(code = 91).__str__() == ('request rejected or failed'
                                                '[Errno 91]')

# Generated at 2022-06-12 19:24:26.109045
# Unit test for constructor of class ProxyError
def test_ProxyError():
    try:
        raise Socks4Error(0, 'TestException')
        assert False
    except ProxyError as e:
        assert e.errno == 0
        assert e.strerror == 'TestException'
    try:
        raise ProxyError()
        assert False
    except Socks4Error as e:
        assert e.errno == 0
        assert e.strerror == 'unspecified error'
    try:
        raise ProxyError(12)
        assert False
    except Socks5Error as e:
        assert e.errno == 12
        assert e.strerror == 'unknown error'


if __name__ == '__main__':
    test_ProxyError()

# Generated at 2022-06-12 19:24:30.463012
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    s.connect(('1.1.1.1', 80))
    try:
        s.recvall(8)
        raise Exception('Should raise EOFError')
    except EOFError:
        pass


# Generated at 2022-06-12 19:24:38.064928
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Create a socket (SOCK_STREAM means a TCP socket)
    sock = sockssocket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        # Connect to server and send data
        sock.connect(("127.0.0.1",8080))
        sock.sendall(b"Hello, world")

        # Receive data from the server and shut down
        received = str(sock.recvall(1024), "utf-8")
    finally:
        sock.close()

    print("Sent:     {}".format("Hello, world"))
    print("Received: {}".format(received))
