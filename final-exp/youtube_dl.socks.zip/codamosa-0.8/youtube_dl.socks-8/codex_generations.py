

# Generated at 2022-06-12 19:20:53.488739
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    from .compat import compat_str
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        tmpdir = compat_str(tmpdir)
        sock_path = tmpdir + '/sock'

        bind_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        bind_socket.bind(sock_path)
        bind_socket.listen(1)

        connect_socket = sockssocket(socket.AF_UNIX)
        connect_socket.connect(sock_path)

        bind_socket.accept()

        # Case success
        test_string = 'test_string'
        connect_socket.sendall(test_string)
        recv_data = connect_socket.recvall(len(test_string))
        assert recv_data == test_

# Generated at 2022-06-12 19:21:03.254735
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    from .compat import compat_bytes
    from .compathttp import SOCKS5_PROXY_HOST, SOCKS5_PROXY_PORT

    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, SOCKS5_PROXY_HOST, SOCKS5_PROXY_PORT)
    s.connect(('127.0.0.1', 80))

    req = compat_bytes(
        'GET /test HTTP/1.1\r\n'
        'Host: 127.0.0.1\r\n'
        'Connection: close\r\n'
        '\r\n',
        'utf-8')
    s.sendall(req)

    r = compat_bytes(s.recvall(4096), 'utf-8')
    assert r

# Generated at 2022-06-12 19:21:13.579294
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    import unittest
    import sys
    if sys.version_info >= (3, 0):
        raise unittest.SkipTest('Not applicable to Python 3')
    # setproxy(self, proxytype, addr, port, rdns=True, username=None, password=None):
    def test_setproxy(proxytype, addr, port, rdns, username, password):
        ss = sockssocket()
        ss.setproxy(proxytype, addr, port, rdns, username, password)
        try:
            ss.connect(('httpbin.org', 80))
        except socket.error as e:
            print('Test setproxy: ', e)
            ss.close()
        else:
            ss.close()

# Generated at 2022-06-12 19:21:25.419552
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import unittest
    data = b'12345678'
    data_len = len(data)
    # mock a socket
    class DummySocket(object):
        def __init__(self):
            self.expect = [data[i:i+1] for i in range(data_len)]
            self.received = b''
        def recv(self, count):
            if len(self.expect) == 0:
                return False
            bytes = self.expect.pop(0)
            self.received += bytes
            return bytes
    dummy_socket = DummySocket()
    # test
    s = sockssocket(socket.AF_INET)
    s.__dict__['_sock'] = dummy_socket
    recv_data = s.recvall(data_len)
    assert recv

# Generated at 2022-06-12 19:21:33.879731
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import random
    s = sockssocket()
    s.bind(('localhost', 0))
    s.listen(1)
    s.settimeout(0.1)
    datas = []
    def recvall(s, cnt):
        to_recv = list(range(cnt))
        while True:
            try:
                data = s.recv(1)
                recv = random.choice(to_recv)
                del to_recv[to_recv.index(recv)]
                data = bytes([recv])
                datas.append(data)
                if len(to_recv) == 0:
                    return bytes(datas)
            except socket.timeout:
                pass
    s2 = sockssocket()
    s2.connect(s.getsockname())

# Generated at 2022-06-12 19:21:41.065037
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    try:
        socket.setdefaulttimeout(0.5)
        s = sockssocket(socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP)
        s.setproxy(ProxyType.SOCKS5, 'localhost', 1080, rdns=False)
        s.connect(('bbc.com', 80))
        s.close()
    except:
        print("[-] sockssocket.setproxy()")
    else:
        print("[+] sockssocket.setproxy()")

if __name__ == "__main__":
    test_sockssocket_setproxy()

# Generated at 2022-06-12 19:21:47.402804
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import random
    import string
    def randomString(stringLength=10):
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(stringLength))

    ss = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    host = "<your host>"

# Generated at 2022-06-12 19:21:53.084955
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    """sockssocket.Proxy has all fields"""
    try:
        sockssocket().setproxy(ProxyType.SOCKS4A, '', 0,
                               username='username', password='password')
    except AttributeError:
        # skip test on old Python
        return

    assert Proxy._fields == (
        'type', 'host', 'port', 'username', 'password', 'remote_dns')

# Generated at 2022-06-12 19:22:04.503031
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    assert s._proxy is None

    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, True, 'foo', 'bar')
    assert s._proxy.type is ProxyType.SOCKS5
    assert s._proxy.host == '127.0.0.1'
    assert s._proxy.port == 1080
    assert s._proxy.remote_dns is True
    assert s._proxy.username == 'foo'
    assert s._proxy.password == 'bar'

    s.setproxy(ProxyType.SOCKS5, '127.0.0.1', 1080, False, None, None)
    assert s._proxy.type is ProxyType.SOCKS5

# Generated at 2022-06-12 19:22:08.295746
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    assert [0, 0] == compat_struct_unpack('!2B', b'\x00\x00')
    assert [10, 11] == compat_struct_unpack('!2B', b'\n\x0b')
    assert [255, 255] == compat_struct_unpack('!2B', b'\xff\xff')


# Generated at 2022-06-12 19:22:25.395966
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    s.recvall(4)
    s.recvall(1)
    s.recvall(1)
    s.recvall(1)
    s.recvall(1)
    s.recvall(1)
    s.recvall(1)
    s.recvall(1)
    s.recvall(1)
    s.recvall(1)
    s.recvall(1)

# Generated at 2022-06-12 19:22:26.638402
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    s = sockssocket()
    s.setproxy(socks.PROXY_TYPE_SOCKS4, '127.0.0.1', 8080)

# Generated at 2022-06-12 19:22:36.387897
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import os
    import tempfile
    from .compat import compat_open

    try:
        os.remove('sockssocket_recvall_test.txt')
    except OSError:
        pass

    # write file
    f = compat_open('sockssocket_recvall_test.txt', 'w')
    f.write('Test 123456789\n')
    f.close()

    # open file
    f = compat_open('sockssocket_recvall_test.txt', 'r')

    # read and write via socket
    s = sockssocket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect(f.fileno())

    # try to read buffer size
    test_data = s.recvall(13)

    s.close()

    os

# Generated at 2022-06-12 19:22:42.431430
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket()
    s.connect(('127.0.0.1', 1080))
    s.setblocking(False)
    assert(b'\x05\x01\x00' == s.recvall(3))
    assert(b'\x05\x00\x03\x05\x03\x00\x01\x02\x03\x04\x80' == s.recvall(11))
    assert(b'Hello, from ' == s.recvall(14))
    # Testing with chunk size
    assert(b'Hello, from ' == s.recvall(11, 3))
    assert(b'Hello, from ' == s.recvall(3, 1))
    assert(b'Hello, from ' == s.recvall(2, 1))

# Generated at 2022-06-12 19:22:48.863509
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    s = sockssocket(socket.AF_INET, socket.SOCK_STREAM)
    address = ('172.217.19.174', 80)
    s.connect(address)
    url = "/"
    request = "GET " + url + " HTTP/1.1\r\n"
    request += "Host: " + address[0] + ":" + str(address[1]) + "\r\n"
    request += "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0\r\n"
    request += "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n"

# Generated at 2022-06-12 19:22:54.304396
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    try:
        sockssocket().setproxy(ProxyType.SOCKS4, 'localhost', 8080)
        sockssocket().setproxy(ProxyType.SOCKS4A, 'localhost', 8080)
        sockssocket().setproxy(ProxyType.SOCKS5, 'localhost', 8080)
    except:
        pass

# Generated at 2022-06-12 19:23:04.378268
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    import select
    import time
    import random

    def recv(socket, count):
        socket.setblocking(0)
        timeout = 1
        data = b''
        while len(data) < count:
            ready = select.select([socket], [], [], timeout)
            if ready[0]:
                data += socket.recv(count - len(data))
            else:
                timeout = 0
                break
        return data

    # Test to ensure that recvall method will not timeout
    count = random.randint(1, 100)
    data = b''
    for i in range(count):
        data += compat_struct_pack('!B', i)
    sockssocket = sockssocket()

# Generated at 2022-06-12 19:23:12.739428
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    # Host used in unit tests
    host = 'www.youtube.com'

    # Create a socket object
    s = sockssocket()

    # Connect to a server
    s.connect((host, 80))

    # Send data
    request = 'GET / HTTP/1.0\r\nHost: %s\r\n\r\n' % host
    s.sendall(request.encode('utf-8'))

    # Receive response
    response = s.recvall(1024)

    # Close socket
    s.close()

    # Check if response is valid
    assert response.startswith(b'HTTP/1.0') or response.startswith(b'HTTP/1.1')


# Generated at 2022-06-12 19:23:21.474523
# Unit test for method recvall of class sockssocket
def test_sockssocket_recvall():
    test_socket = sockssocket()
    test_socket.connect(('time.nist.gov', 13))
    data = test_socket.recvall(64)
    assert len(data) == 64
    assert data[-1] == 32

if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('target', metavar='host:port')
    parser.add_argument('--proxy', metavar='host:port')
    args = parser.parse_args()

    host, port = (args.proxy or '').rsplit(':', 1)
    port = int(port) if port else 1080

    s = sockssocket()
    s.setproxy(ProxyType.SOCKS5, host, port)

# Generated at 2022-06-12 19:23:27.539924
# Unit test for method setproxy of class sockssocket
def test_sockssocket_setproxy():
    import os, sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from utils import parse_proxy_str
    proxy = parse_proxy_str('socks5://coding:password@127.0.0.1:9050/')
    assert proxy == Proxy(ProxyType.SOCKS5, '127.0.0.1', 9050, 'coding', 'password', True)