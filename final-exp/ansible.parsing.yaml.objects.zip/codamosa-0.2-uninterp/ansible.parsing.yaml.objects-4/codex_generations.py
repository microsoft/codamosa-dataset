

# Generated at 2022-06-17 06:44:09.592479
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACSha256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256CBCHMAC
    from ansible.parsing.vault import VaultAES256CBCHMACSha256
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMSha256

# Generated at 2022-06-17 06:44:20.816859
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test with a slice that is within the string
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu[1:3] == 'bc'

    # Test with a slice that is outside the string
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu[1:100] == 'bcdef'

    # Test with a slice that is outside the string
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu[-100:3] == 'abc'

    # Test with a slice that is outside the string
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu[-100:100] == 'abcdef'

    # Test with a slice that is outside the string
    avu = AnsibleV

# Generated at 2022-06-17 06:44:30.192800
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'abcdefghijklmnopqrstuvwxyz'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu[0:10] == 'abcdefghij'
    assert avu[10:20] == 'klmnopqrst'
    assert avu[20:26] == 'uvwxyz'
    assert avu[20:27] == 'uvwxyz'
    assert avu[20:28] == 'uvwxyz'
    assert avu[20:29] == 'uvwxyz'


# Generated at 2022-06-17 06:44:33.679734
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'not plaintext'


# Generated at 2022-06-17 06:44:42.778125
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode('test')
    assert avu != AnsibleVaultEncryptedUnicode(vault.encrypt('test', secret))
    assert avu != AnsibleVaultEncryptedUnicode(vault.encrypt('test2', secret))

# Generated at 2022-06-17 06:44:49.542421
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:44:56.422705
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.__gt__('ab')
    assert not avu.__gt__('abc')
    assert not avu.__gt__('abcd')

    # Test with an AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('ab')
    assert avu.__gt__(avu2)
    avu2 = AnsibleVaultEncryptedUnicode('abc')
    assert not avu.__gt__(avu2)
    avu2 = AnsibleVaultEncryptedUnicode('abcd')
    assert not avu.__gt__(avu2)


# Generated at 2022-06-17 06:45:03.301553
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:45:15.896651
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu == 'test'
    assert avu != 'test1'
    assert avu != 'tes'
    assert avu != 'est'
    assert avu != 'tst'
    assert avu != 'tet'
    assert avu != 'tes'
    assert avu != 'tet'
    assert avu != 'tst'
    assert avu != 'est'
    assert avu != 'tes'
    assert avu != 'tet'
    assert avu != 'tst'
    assert avu != 'est'
    assert avu != 'tet'

# Generated at 2022-06-17 06:45:28.210508
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256CFB8
    from ansible.parsing.vault import VaultAES256CTS


# Generated at 2022-06-17 06:45:39.247394
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:45:41.759899
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'
    avu.vault = 'test'
    assert avu != 'test'


# Generated at 2022-06-17 06:45:53.348036
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:46:05.057294
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test with both PY2 and PY3
    if sys.version_info[0] == 2:
        # PY2
        assert AnsibleVaultEncryptedUnicode('foo') + AnsibleVaultEncryptedUnicode('bar') == 'foobar'
        assert AnsibleVaultEncryptedUnicode('foo') + 'bar' == 'foobar'
        assert 'foo' + AnsibleVaultEncryptedUnicode('bar') == 'foobar'
    else:
        # PY3
        assert AnsibleVaultEncryptedUnicode('foo') + AnsibleVaultEncryptedUnicode('bar') == 'foobar'
        assert AnsibleVaultEncryptedUnicode('foo') + 'bar' == 'foobar'
        assert 'foo' + AnsibleVaultEncryptedUnicode('bar')

# Generated at 2022-06-17 06:46:15.719341
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test for negative start and end
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu[-1:] == 'f'
    assert avu[-2:] == 'ef'
    assert avu[-3:] == 'def'
    assert avu[-4:] == 'cdef'
    assert avu[-5:] == 'bcdef'
    assert avu[-6:] == 'abcdef'
    assert avu[-7:] == 'abcdef'

    assert avu[:-1] == 'abcde'
    assert avu[:-2] == 'abcd'
    assert avu[:-3] == 'abc'
    assert avu[:-4] == 'ab'
    assert avu[:-5] == 'a'
    assert avu[:-6] == ''

# Generated at 2022-06-17 06:46:25.609410
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode('test')


# Generated at 2022-06-17 06:46:30.721643
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:46:37.001355
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu + plaintext == plaintext + plaintext
    assert avu + avu == plaintext + plaintext
    assert avu + ciphertext == plaintext + plaintext
    assert avu + 'test' == plaintext + plaintext
    assert avu + b'test' == plaintext + plaintext
    assert avu + 1 == plaintext + plaintext
    assert avu + 1.0 == plaintext + plaintext
    assert avu + 1.0j == plaintext + plaintext


# Generated at 2022-06-17 06:46:47.095725
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:46:51.700094
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu == 'foo'
    assert avu != 'bar'
    assert not (avu == 'bar')
    assert not (avu != 'foo')


# Generated at 2022-06-17 06:47:07.402410
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:47:13.955782
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != 'baz'


# Generated at 2022-06-17 06:47:22.828949
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:47:31.730735
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC

    # Create a VaultLib object
    vault = VaultLib([VaultAES256(), VaultAES256CBC()])

    # Create a VaultSecret object
    secret = VaultSecret('secret')

    # Create a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)

    # Create a AnsibleVaultEncryptedUnicode object
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)

    # Create a Ansible

# Generated at 2022-06-17 06:47:41.843175
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test with a negative start
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.__getslice__(-1, -1) == 'f'
    assert avu.__getslice__(-1, None) == 'f'
    assert avu.__getslice__(-1, 5) == 'f'
    assert avu.__getslice__(-1, 6) == 'f'
    assert avu.__getslice__(-1, 7) == 'f'
    assert avu.__getslice__(-1, -1) == 'f'
    assert avu.__getslice__(-1, -2) == 'ef'
    assert avu.__getslice__(-1, -3) == 'def'
    assert avu.__getslice

# Generated at 2022-06-17 06:47:50.309397
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:48:00.993936
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')


# Generated at 2022-06-17 06:48:05.597211
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()


# Generated at 2022-06-17 06:48:09.659338
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    assert avu == plaintext
    assert avu != 'other'


# Generated at 2022-06-17 06:48:18.048415
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode('test')
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEnc

# Generated at 2022-06-17 06:48:32.261380
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:48:36.178295
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:48:42.381439
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:48:49.664396
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault, 'secret')
    assert avu.is_encrypted()


# Generated at 2022-06-17 06:48:54.686371
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'


# Generated at 2022-06-17 06:48:58.542848
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext


# Generated at 2022-06-17 06:49:02.380726
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib('mysecret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('mysecret', vault, 'mysecret')
    assert avu == 'mysecret'
    assert avu != 'mysecret2'


# Generated at 2022-06-17 06:49:13.498771
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test1'


# Generated at 2022-06-17 06:49:28.994010
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')

# Generated at 2022-06-17 06:49:41.213907
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:49:57.685912
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:05.558288
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a vault object
    vault = vaultlib.VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu == 'test'
    assert avu != 'test2'
    assert avu != 'test '
    assert avu != ' test'
    assert avu != 'test\n'
    assert avu != 'test\r'
    assert avu != 'test\r\n'
    assert avu != 'test\t'
    assert avu != 'test\x00'

    # Test without a vault object
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'
    assert avu != 'test2'
    assert avu != 'test '
    assert av

# Generated at 2022-06-17 06:50:16.165947
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    seq = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', VaultLib('test2'), secret)
    assert avu != AnsibleVaultEncrypted

# Generated at 2022-06-17 06:50:23.666701
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:50:30.738892
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:50:36.043942
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:50:45.017334
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:51.665996
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu == 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')


# Generated at 2022-06-17 06:51:05.267742
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import unittest
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    class TestAnsibleVaultEncryptedUnicode(unittest.TestCase):
        def test_AnsibleVaultEncryptedUnicode___eq__(self):
            vault = VaultLib(VaultSecret('secret'))
            avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')
            self.assertTrue(avu == 'foo')
            self.assertFalse(avu == 'bar')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestAnsibleVaultEncryptedUnicode)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Unit

# Generated at 2022-06-17 06:51:10.314291
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:51:26.094924
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:51:29.300929
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    # Test with a non-encrypted string
    avu = AnsibleVaultEncryptedUnicode('hello')
    assert not avu.is_encrypted()
    # Test with an encrypted string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault, 'secret')
    assert avu.is_encrypted()


# Generated at 2022-06-17 06:51:38.752807
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('mysecret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('mysecret', vault, 'mysecret')
    assert avu != 'mysecret'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('mysecret', vault, 'mysecret')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('mysecret', vault, 'wrongsecret')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('wrongsecret', vault, 'mysecret')


# Generated at 2022-06-17 06:51:46.604375
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMNoPadding
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CF

# Generated at 2022-06-17 06:51:51.168664
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:51:59.910518
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:52:07.081749
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test if __ne__ returns True if the data is not equal
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test1'

    # Test if __ne__ returns False if the data is equal
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test if __ne__ returns False if the data is equal and the other is a AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('test')
    avu2 = AnsibleVaultEncryptedUnicode('test')
    assert avu != avu2

    # Test if __ne__ returns True if the data is not equal and the other is a AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnic

# Generated at 2022-06-17 06:52:11.045918
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:52:17.817413
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu.__ne__('test')
    assert not avu.__ne__(avu)


# Generated at 2022-06-17 06:52:28.925037
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('mypassword')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('mypassword', vault, 'mypassword')
    assert avu != 'mypassword'
    assert avu != 'mypassword'
    assert avu != 'mypassword'
    assert avu != 'mypassword'
    assert avu != 'mypassword'
    assert avu != 'mypassword'
    assert avu != 'mypassword'
    assert avu != 'mypassword'
    assert avu != 'mypassword'
    assert avu != 'mypassword'
    assert avu != 'mypassword'
    assert avu != 'mypassword'
    assert avu != 'mypassword'
    assert avu != 'mypassword'

# Generated at 2022-06-17 06:52:53.182495
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:53:01.757377
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:53:08.122153
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:53:17.367933
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', None, secret)

# Generated at 2022-06-17 06:53:23.273120
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu == 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')


# Generated at 2022-06-17 06:53:27.019628
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test1'


# Generated at 2022-06-17 06:53:38.522661
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:53:50.519994
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode