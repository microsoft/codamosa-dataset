

# Generated at 2022-06-17 06:43:57.493394
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('def')
    assert avu1 < avu2
    assert avu1 < 'def'
    assert 'abc' < avu2


# Generated at 2022-06-17 06:44:08.544676
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.rfind('t') == 2
    assert avu.rfind('t', 0, 1) == -1
    assert avu.rfind('t', 0, 2) == 1
    assert avu.rfind('t', 0, 3) == 2
    assert avu.rfind('t', 0, 4) == 2
    assert avu.rfind('t', 0, -1) == 1
    assert avu.rfind('t', 0, -2) == 1

# Generated at 2022-06-17 06:44:20.416464
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test with a slice of the whole string
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu[:] == 'abc'

    # Test with a slice of the whole string
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu[0:3] == 'abc'

    # Test with a slice of the whole string
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu[0:4] == 'abc'

    # Test with a slice of the whole string
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu[0:5] == 'abc'

    # Test with a slice of the whole string
    avu = AnsibleVaultEncryptedUnicode('abc')

# Generated at 2022-06-17 06:44:26.000921
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test with a unicode string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu + 'test' == 'testtest'
    assert 'test' + avu == 'testtest'
    assert avu + avu == 'testtest'

    # Test with a byte string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu + b'test' == 'testtest'
    assert b'test' + avu == 'testtest'
    assert avu + avu == 'testtest'


# Generated at 2022-06-17 06:44:38.324811
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu[1:2] == 'b'
    assert avu[1:1] == ''
    assert avu[1:0] == ''
    assert avu[1:-1] == 'b'
    assert avu[1:-2] == ''
    assert avu[-2:1] == ''
    assert avu[-2:2] == 'b'
    assert avu[-2:3] == 'bc'
    assert avu[-2:-1] == 'b'
    assert avu[-2:-2] == ''
    assert avu[-2:-3] == ''
    assert avu[-3:-2] == 'b'
    assert avu[-3:-3] == ''

# Generated at 2022-06-17 06:44:45.041339
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')


# Generated at 2022-06-17 06:44:54.201102
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.rfind('a') == 0
    assert avu.rfind('b') == 1
    assert avu.rfind('c') == 2
    assert avu.rfind('d') == -1
    assert avu.rfind('a', 0, 1) == 0
    assert avu.rfind('a', 0, 2) == 0
    assert avu.rfind('a', 0, 3) == 0
    assert avu.rfind('a', 0, 4) == 0
    assert avu.rfind('a', 1, 1) == -1
    assert avu.rfind('a', 1, 2) == -1
    assert avu.rfind('a', 1, 3) == 0

# Generated at 2022-06-17 06:45:02.603841
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, secret)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('def', vault, secret)
    avu3 = avu1 + avu2
    assert avu3.data == 'abcdef'
    assert avu3.is_encrypted()


# Generated at 2022-06-17 06:45:15.339048
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:45:22.908840
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu[0:1] == 'a'
    assert avu[0:2] == 'ab'
    assert avu[0:3] == 'abc'
    assert avu[1:2] == 'b'
    assert avu[1:3] == 'bc'
    assert avu[2:3] == 'c'
    assert avu[2:4] == 'c'
    assert avu[3:4] == ''
    assert avu[3:5] == ''
    assert avu[4:5] == ''
    assert avu[5:6] == ''



# Generated at 2022-06-17 06:45:43.742798
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:45:52.090753
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu + avu == plaintext + plaintext
    assert avu + plaintext == plaintext + plaintext
    assert plaintext + avu == plaintext + plaintext


# Generated at 2022-06-17 06:46:03.486937
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:46:07.227905
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu < 'test'
    assert avu < AnsibleVaultEncryptedUnicode('test')
    assert not avu < 'test1'
    assert not avu < AnsibleVaultEncryptedUnicode('test1')


# Generated at 2022-06-17 06:46:16.747671
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    assert AnsibleVaultEncryptedUnicode('a') < AnsibleVaultEncryptedUnicode('b')
    assert AnsibleVaultEncryptedUnicode('a') < 'b'
    assert 'a' < AnsibleVaultEncryptedUnicode('b')
    assert AnsibleVaultEncryptedUnicode('a') < 'b'
    assert AnsibleVaultEncryptedUnicode('a') < 'a'
    assert 'a' < AnsibleVaultEncryptedUnicode('a')
    assert AnsibleVaultEncryptedUnicode('a') < 'a'
    assert AnsibleVaultEncryptedUnicode('a') < 'a'


# Generated at 2022-06-17 06:46:21.229041
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu + 'test' == 'testtest'
    assert 'test' + avu == 'testtest'


# Generated at 2022-06-17 06:46:28.317894
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # Test with a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.__lt__(AnsibleVaultEncryptedUnicode('test')) == False
    assert avu.__lt__(AnsibleVaultEncryptedUnicode('test2')) == True
    assert avu.__lt__(AnsibleVaultEncryptedUnicode('test1')) == False
    # Test with a string
    assert avu.__lt__('test') == False
    assert avu.__lt__('test2') == True
    assert avu.__lt__('test1') == False


# Generated at 2022-06-17 06:46:33.204456
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    plaintext = 'this is a test'
    ciphertext = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:46:45.132735
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test with a AnsibleVaultEncryptedUnicode object
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('def')
    assert avu1 + avu2 == 'abcdef'

    # Test with a string
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + 'def' == 'abcdef'

    # Test with a unicode string
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + u'def' == 'abcdef'

    # Test with a byte string
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + b'def' == 'abcdef'

    # Test with a integer


# Generated at 2022-06-17 06:46:51.647845
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:47:02.889607
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a vault object
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault=None, secret='secret')
    assert avu == 'test'
    assert avu != 'test2'

    # Test without a vault object
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'
    assert avu != 'test2'


# Generated at 2022-06-17 06:47:09.936082
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu + avu == 'testtest'
    assert avu + 'test' == 'testtest'
    assert 'test' + avu == 'testtest'


# Generated at 2022-06-17 06:47:14.789616
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()



# Generated at 2022-06-17 06:47:25.494006
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test with AnsibleVaultEncryptedUnicode
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('def')
    assert avu1 + avu2 == 'abcdef'

    # Test with text_type
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + 'def' == 'abcdef'
    assert 'abc' + avu1 == 'abcabc'

    # Test with str
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + b'def' == 'abcdef'
    assert b'abc' + avu1 == 'abcabc'



# Generated at 2022-06-17 06:47:38.282512
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1
    from ansible.parsing.vault import VaultAES256CFB8

# Generated at 2022-06-17 06:47:46.778323
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.__add__(plaintext) == plaintext + plaintext
    assert avu.__add__(avu) == plaintext + plaintext
    assert avu.__radd__(plaintext) == plaintext + plaintext
    assert avu.__radd__(avu) == plaintext + plaintext


# Generated at 2022-06-17 06:47:50.222120
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:47:59.637922
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')


# Generated at 2022-06-17 06:48:04.810586
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test when self.vault is None
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.__ne__('test') == True
    assert avu.__ne__('test2') == True

    # Test when self.vault is not None
    avu.vault = 'test'
    assert avu.__ne__('test') == False
    assert avu.__ne__('test2') == True


# Generated at 2022-06-17 06:48:13.768638
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test for method __ne__ (__ne__ of class AnsibleVaultEncryptedUnicode)
    # This test is needed because the method __ne__ is not defined in the
    # class AnsibleVaultEncryptedUnicode but is inherited from the class
    # Sequence.
    # The method __ne__ of class Sequence is not implemented correctly.
    # It returns True if the other object is not a Sequence.
    # This test checks that the method __ne__ of class AnsibleVaultEncryptedUnicode
    # returns False if the other object is not a AnsibleVaultEncryptedUnicode.
    avu = AnsibleVaultEncryptedUnicode(b'abc')
    assert avu != 'abc'


# Generated at 2022-06-17 06:48:21.999916
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True
    plaintext = avu.data
    avu = AnsibleVaultEncryptedUnicode(plaintext)
    avu.vault = vault
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:48:30.542809
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test with a AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('test')
    assert avu != avu2

    # Test with a AnsibleVaultEncryptedUnicode with the same value
    avu2 = AnsibleVaultEncryptedUnicode('test')
    avu2.vault = avu.vault
    assert avu != avu2


# Generated at 2022-06-17 06:48:40.643420
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault=None, secret=None)
    assert avu == 'test'
    assert avu != 'test2'

    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault=None, secret=None)
    assert avu == avu2
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault=None, secret=None)
    assert avu != avu2


# Generated at 2022-06-17 06:48:49.845741
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu.is_encrypted() == True
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:48:56.667092
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')

# Generated at 2022-06-17 06:49:00.830013
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:49:15.468746
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu + 'test' == 'testtest'
    assert 'test' + avu == 'testtest'
    assert avu + AnsibleVaultEncryptedUnicode(ciphertext) == 'testtest'
    assert AnsibleVaultEncryptedUnicode(ciphertext) + avu == 'testtest'


# Generated at 2022-06-17 06:49:27.307993
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    vault.update({'password': 'test'})
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'test')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'test')
    assert avu1 + avu2 == 'foobar'
    assert avu1 + 'bar' == 'foobar'
    assert 'foo' + avu2 == 'foobar'


# Generated at 2022-06-17 06:49:34.984098
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert avu.data == plaintext
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:49:44.025679
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')
    assert avu + avu2 == 'foobar'
    assert avu + 'bar' == 'foobar'
    assert 'foo' + avu2 == 'foobar'
    assert avu + b'bar' == 'foobar'
    assert b'foo' + avu == 'foobar'


# Generated at 2022-06-17 06:50:01.236858
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode('test')
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEnc

# Generated at 2022-06-17 06:50:11.520819
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:14.877586
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleUnicode(plaintext)
    assert avu != AnsibleUnicode(ciphertext)


# Generated at 2022-06-17 06:50:20.105518
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.data == plaintext
    assert avu + plaintext == plaintext + plaintext
    assert avu + avu == plaintext + plaintext
    assert plaintext + avu == plaintext + plaintext


# Generated at 2022-06-17 06:50:25.892832
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault, 'password')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('hello')
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:50:32.552985
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test1'


# Generated at 2022-06-17 06:50:39.484837
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    Test method __ne__ of class AnsibleVaultEncryptedUnicode
    """
    # Test with a AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:45.944178
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:54.372786
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')


# Generated at 2022-06-17 06:50:57.907837
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a vault that is not set
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test with a vault that is set
    import ansible.parsing.vault as vault
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu != 'test'



# Generated at 2022-06-17 06:51:26.064344
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avu == plaintext
    assert avu != ciphertext
    assert avu != 'test'


# Generated at 2022-06-17 06:51:32.473600
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:51:37.353916
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:51:45.685160
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.data == plaintext
    assert avu + 'suffix' == plaintext + 'suffix'
    assert 'prefix' + avu == 'prefix' + plaintext
    assert avu + avu == plaintext + plaintext
    assert avu + AnsibleVaultEncryptedUnicode(ciphertext) == plaintext + plaintext


# Generated at 2022-06-17 06:51:57.379855
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:51:59.710347
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:52:06.603899
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:52:10.633198
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test with AnsibleVaultEncryptedUnicode
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('def')
    assert avu1 + avu2 == 'abcdef'

    # Test with string
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + 'def' == 'abcdef'

    # Test with bytes
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + b'def' == 'abcdef'


# Generated at 2022-06-17 06:52:21.437510
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC

    # Create a vault object
    vault_secret = VaultSecret('test')
    vault_aes256 = VaultAES256(vault_secret)
    vault_aes256cbc = VaultAES256CBC(vault_aes256)
    vault = VaultLib([vault_aes256cbc])

    # Create an encrypted string
    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, vault_secret)

    # Test is_encrypted
    assert encrypted_string.is_encrypted() == True

    # Create

# Generated at 2022-06-17 06:52:29.973971
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = '$ANSIBLE_VAULT;1.1;AES256\n39303535646637383533373565383336353766353735303664376565373936393430353365363066\n3933646637656466383564373337663564376537353036643765653739363934303533653630663564\n'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu + 'test' == 'testtest'
    assert 'test' + avu == 'testtest'


# Generated at 2022-06-17 06:53:13.846730
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:53:25.125311
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')


# Generated at 2022-06-17 06:53:37.297121
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:53:41.693278
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()
