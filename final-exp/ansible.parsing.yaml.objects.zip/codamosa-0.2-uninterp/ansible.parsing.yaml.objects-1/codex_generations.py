

# Generated at 2022-06-17 06:44:02.563819
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.find('e') == 1
    assert avu.find('e', 2) == -1
    assert avu.find('e', 2, 3) == -1
    assert avu.find('e', 2, 2) == -1
    assert avu.find('e', 2, 1) == -1
    assert avu.find('e', 0, 1) == 1
    assert avu.find('e', 0, 2) == 1

# Generated at 2022-06-17 06:44:11.167729
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256ECB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-17 06:44:20.927230
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'not test'


# Generated at 2022-06-17 06:44:26.212938
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu > 'bar'
    assert not avu > 'foo'
    assert not avu > 'foobar'


# Generated at 2022-06-17 06:44:35.204700
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu >= 'abc'
    assert not avu >= 'abcd'

    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('abc')
    assert avu >= avu2
    avu2 = AnsibleVaultEncryptedUnicode('abcd')
    assert not avu >= avu2


# Generated at 2022-06-17 06:44:44.050410
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu.__gt__('test') == False
    assert avu.__gt__('test1') == False
    assert avu.__gt__('test2') == False
    assert avu.__gt__('test3') == False
    assert avu.__gt__('test4') == False
    assert avu.__gt__('test5') == False
    assert avu.__gt__('test6') == False
    assert avu.__gt__('test7') == False
    assert avu.__gt__('test8') == False
    assert avu.__gt__

# Generated at 2022-06-17 06:44:52.995553
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu1 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu1.vault = vault
    avu2 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu2.vault = vault
    assert avu1 <= avu2
    assert avu1 <= plaintext
    assert avu1 <= ciphertext
    assert not avu1 <= 'test1'
    assert not avu1 <= 'test2'
    assert not avu1 <= 'test3'


# Generated at 2022-06-17 06:45:04.329430
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultChaCha20
   

# Generated at 2022-06-17 06:45:16.571837
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:45:26.094648
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu + avu == plaintext + plaintext
    assert avu + plaintext == plaintext + plaintext
    assert plaintext + avu == plaintext + plaintext


# Generated at 2022-06-17 06:45:53.380612
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACSha256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256CBCHMAC
    from ansible.parsing.vault import VaultAES256CBCHMACSha256

    # Test with VaultLib

# Generated at 2022-06-17 06:46:00.763272
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:46:07.709377
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:46:16.807815
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, 'password')
    assert avu == 'abc'
    assert avu != 'abcd'
    assert avu != 'ab'
    assert avu != 'Abc'
    assert avu != 'ABC'
    assert avu != '123'
    assert avu != 123
    assert avu != 'abc '
    assert avu != ' abc'
    assert avu != ' abc '
    assert avu != 'abc\n'
    assert avu != '\nabc'
    assert avu != '\nabc\n'
    assert avu != '\tabc'
    assert avu != 'abc\t'

# Generated at 2022-06-17 06:46:24.232978
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:46:34.407693
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Test with a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.__gt__(AnsibleVaultEncryptedUnicode('test')) == False
    assert avu.__gt__(AnsibleVaultEncryptedUnicode('test1')) == False
    assert avu.__gt__(AnsibleVaultEncryptedUnicode('tes')) == True
    assert avu.__gt__(AnsibleVaultEncryptedUnicode('tes1')) == True

    # Test with a string object
    assert avu.__gt__('test') == False
    assert avu.__gt__('test1') == False
    assert avu.__gt__('tes') == True

# Generated at 2022-06-17 06:46:40.903719
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu == 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')


# Generated at 2022-06-17 06:46:45.223062
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test for method __eq__ (1st case)
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu == 'test'
    # Test for method __eq__ (2nd case)
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu == 'test1'


# Generated at 2022-06-17 06:46:49.319189
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a vault object
    vault = vaultlib.VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu == 'test'
    assert avu != 'test2'

    # Test without a vault object
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'
    assert avu != 'test2'



# Generated at 2022-06-17 06:46:57.514956
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test that __ne__ returns True when the data is not equal
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test1'

    # Test that __ne__ returns False when the data is equal
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test that __ne__ returns False when the data is equal
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != AnsibleVaultEncryptedUnicode('test')

    # Test that __ne__ returns True when the data is not equal
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != AnsibleVaultEncryptedUnicode('test1')



# Generated at 2022-06-17 06:47:11.964339
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:47:18.113635
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True
    avu.data = plaintext
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:47:25.883015
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test for method __ne__ (self, other)
    # of class AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode('foo')
    assert avu != AnsibleVaultEncryptedUnicode('bar')
    assert not (avu != 'foo')
    assert not (avu != AnsibleVaultEncryptedUnicode('foo'))


# Generated at 2022-06-17 06:47:33.809562
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:47:44.312576
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()

# Generated at 2022-06-17 06:47:51.819956
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'not_test'


# Generated at 2022-06-17 06:48:00.069911
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:48:05.103790
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    avu.data = plaintext
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:48:16.661144
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:48:23.009245
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, 'test2')


# Generated at 2022-06-17 06:48:42.914316
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:48:51.002684
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    avu2 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu2.vault = vault
    assert avu == avu2


# Generated at 2022-06-17 06:48:55.307857
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    ciphertext = vault.encrypt('test', secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode('test')
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:49:05.076432
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:49:17.731046
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    ciphertext = vault.encrypt('plaintext')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()

    avu = AnsibleVaultEncryptedUnicode('plaintext')
    avu.vault = vault
    assert not avu.is_encrypted()

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert not avu.is_encrypted()

    avu = AnsibleVaultEncryptedUnicode('plaintext')
    assert not avu.is_encrypted()



# Generated at 2022-06-17 06:49:27.345347
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('mypassword')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('mypassword', vault, 'mypassword')
    assert avu != 'mypassword'
    assert avu != 'mypassword2'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('mypassword2', vault, 'mypassword')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('mypassword', vault, 'mypassword2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('mypassword2', vault, 'mypassword2')

# Generated at 2022-06-17 06:49:34.596240
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('my secret', vault, 'secret')
    assert avu.is_encrypted() == True
    assert avu.data == 'my secret'
    assert avu.is_encrypted() == False
    assert avu.data == 'my secret'


# Generated at 2022-06-17 06:49:40.411064
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:49:48.849633
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:49:56.028783
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(vault.encrypt('test2', secret))


# Generated at 2022-06-17 06:50:25.046834
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC

    # Create a vault object
    vault = VaultLib([VaultSecret(VaultAES256CBC(VaultAES256()))])

    # Create a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')

    # Test __eq__
    assert avu == 'test'
    assert avu != 'test2'


# Generated at 2022-06-17 06:50:34.738264
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None)
    assert avu == 'test'

    # Test with a AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None)
    assert avu == avu2

    # Test with a different string
    assert avu != 'test2'

    # Test with a different AnsibleVaultEncryptedUnicode
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext('test2', None, None)
    assert avu != avu3



# Generated at 2022-06-17 06:50:41.620221
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('password', vault, 'password')
    assert avu != 'password'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('password', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('password', vault, 'password2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('password2', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('password2', vault, 'password2')
    assert avu != 'password2'


# Generated at 2022-06-17 06:50:47.624483
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == 'test'
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode('test2')
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data.encode()
    assert avu != AnsibleVaultEncryptedUnic

# Generated at 2022-06-17 06:50:54.662334
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu != 'foo'
    assert avu != 'bar'

    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('foo')
    assert avu != avu2
    avu2 = AnsibleVaultEncryptedUnicode('bar')
    assert avu != avu2


# Generated at 2022-06-17 06:51:06.312830
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test for equality with a string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None)
    assert avu == 'test'

    # Test for equality with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None)
    assert avu == avu2

    # Test for inequality with a string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None)
    assert avu != 'test2'

    # Test for inequality with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test2', None, None)
    assert avu != avu2


# Unit

# Generated at 2022-06-17 06:51:12.631487
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'not_test'


# Generated at 2022-06-17 06:51:18.648646
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() is True
    assert avu.data == plaintext
    assert avu.is_encrypted() is False


# Generated at 2022-06-17 06:51:27.598208
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:51:33.032693
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data.encode()
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data.encode('utf-8')
    assert avu != AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:52:11.481579
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:52:21.443356
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == 'test'
    assert avu != 'test2'


# Generated at 2022-06-17 06:52:27.730130
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a non-encrypted string
    avu = AnsibleVaultEncryptedUnicode('hello')
    assert avu != 'hello'

    # Test with an encrypted string

# Generated at 2022-06-17 06:52:36.491382
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)


# Generated at 2022-06-17 06:52:42.850491
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data
    assert avu != AnsibleVaultEncryptedUnicode(plaintext)
    assert avu != AnsibleVaultEncryptedUnicode(plaintext).data
    assert avu != AnsibleUnicode(plaintext)

# Generated at 2022-06-17 06:52:51.669801
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode('test')
    assert avu != AnsibleUnicode('test')
    assert avu != 'test'
    assert avu != AnsibleUnicode(ciphertext)
    assert avu != AnsibleUnicode('test')
    assert avu != AnsibleUnicode(ciphertext)
   

# Generated at 2022-06-17 06:52:57.741832
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avu == plaintext


# Generated at 2022-06-17 06:53:05.183522
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a non-encrypted string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu == 'test'

    # Test with an encrypted string

# Generated at 2022-06-17 06:53:11.950287
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:53:19.705821
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, 'password')
    assert avu == 'abc'
    assert avu != 'abcd'
