

# Generated at 2022-06-17 06:44:05.139972
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(['--vault-password-file', 'test/ansible-vault/test_vault.txt'])
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('this is a test', vault, 'test')
    assert avu.rfind('is') == 5
    assert avu.rfind('is', 0, 4) == -1
    assert avu.rfind('is', 5, 6) == 5
    assert avu.rfind('is', 6, 7) == -1
    assert avu.rfind('is', 6, 8) == 5
    assert avu.rfind('is', 0, 6) == 5
    assert avu.rfind('is', 0, 7) == 5
    assert avu

# Generated at 2022-06-17 06:44:09.734599
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:44:16.547586
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test1'


# Generated at 2022-06-17 06:44:28.546818
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.count('t') == 2
    assert avu.count('t', 1, 2) == 1
    assert avu.count('t', 1, 1) == 0
    assert avu.count('t', 1, 0) == 0
    assert avu.count('t', -1, -1) == 0
    assert avu.count('t', -1, -2) == 1
    assert avu.count('t', -1, -3) == 2
    assert av

# Generated at 2022-06-17 06:44:36.231248
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu > plaintext
    assert not avu > 'test2'


# Generated at 2022-06-17 06:44:42.660589
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.__le__('abc')
    assert not avu.__le__('abcd')

    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('abc')
    assert avu.__le__(avu2)
    avu2 = AnsibleVaultEncryptedUnicode('abcd')
    assert not avu.__le__(avu2)



# Generated at 2022-06-17 06:44:51.923892
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', None, secret)

# Generated at 2022-06-17 06:45:03.547270
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:45:16.071596
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.__lt__('test') == False
    assert avu.__lt__('test1') == True
    assert avu.__lt__('test2') == True
    assert avu.__lt__('test3') == True
    assert avu.__lt__('test4') == True
    assert avu.__lt__('test5') == True
    assert avu.__lt__('test6') == True
    assert avu.__lt__('test7') == True
    assert avu.__lt__('test8') == True
    assert avu.__lt__('test9') == True
    assert avu.__lt__('test10') == True

# Generated at 2022-06-17 06:45:28.313289
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.rfind('a') == 0
    assert avu.rfind('b') == 1
    assert avu.rfind('c') == 2
    assert avu.rfind('d') == -1
    assert avu.rfind('a', 0, 1) == 0
    assert avu.rfind('a', 0, 2) == 0
    assert avu.rfind('a', 0, 3) == 0
    assert avu.rfind('a', 0, 4) == 0
    assert avu.rfind('a', 1, 2) == -1
    assert avu.rfind('a', 1, 3) == -1
    assert avu.rfind('a', 1, 4) == -1
    assert avu.rfind

# Generated at 2022-06-17 06:45:50.303784
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu != 'foo'

    # Test with a AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu2 = AnsibleVaultEncryptedUnicode('foo')
    assert avu != avu2

    # Test with a AnsibleVaultEncryptedUnicode with a different value
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu2 = AnsibleVaultEncryptedUnicode('bar')
    assert avu != avu2



# Generated at 2022-06-17 06:45:55.757053
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(['--vault-password-file', 'test/ansible-vault/test_vault.txt'])
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:46:05.993943
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:46:10.009263
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu.count('t') == 2


# Generated at 2022-06-17 06:46:18.674591
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    # Test case 1:
    #   input:
    #       - self.data = 'abc'
    #       - sub = 'a'
    #       - start = 0
    #       - end = 3
    #   expected:
    #       1
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.count('a', 0, 3) == 1

    # Test case 2:
    #   input:
    #       - self.data = 'abc'
    #       - sub = 'a'
    #       - start = 0
    #       - end = 2
    #   expected:
    #       1
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.count('a', 0, 2) == 1

    # Test case 3:
    #

# Generated at 2022-06-17 06:46:25.309675
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avu == 'test'
    assert avu != 'test2'


# Generated at 2022-06-17 06:46:32.651960
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abcabcabc', vault, 'password')
    assert avu.count('a') == 3
    assert avu.count('b') == 3
    assert avu.count('c') == 3
    assert avu.count('d') == 0
    assert avu.count('a', 1) == 2
    assert avu.count('a', 1, 3) == 1
    assert avu.count('a', 1, -1) == 2
    assert avu.count('a', -1, -1) == 0
    assert avu.count('a', -1, -2) == 1
    assert avu.count('a', -1, -3)

# Generated at 2022-06-17 06:46:45.087322
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:46:51.547381
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with different types of objects
    assert AnsibleVaultEncryptedUnicode('test') == 'test'
    assert AnsibleVaultEncryptedUnicode('test') == AnsibleVaultEncryptedUnicode('test')
    assert AnsibleVaultEncryptedUnicode('test') != 'test2'
    assert AnsibleVaultEncryptedUnicode('test') != AnsibleVaultEncryptedUnicode('test2')
    assert AnsibleVaultEncryptedUnicode('test') != 1
    assert AnsibleVaultEncryptedUnicode('test') != [1, 2, 3]
    assert AnsibleVaultEncryptedUnicode('test') != {'a': 1, 'b': 2}
    assert AnsibleVaultEncryptedUnicode('test') != None



# Generated at 2022-06-17 06:47:03.377248
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    assert AnsibleVaultEncryptedUnicode('abc').count('a') == 1
    assert AnsibleVaultEncryptedUnicode('abc').count('a', 0, 1) == 1
    assert AnsibleVaultEncryptedUnicode('abc').count('a', 0, 2) == 1
    assert AnsibleVaultEncryptedUnicode('abc').count('a', 0, 3) == 1
    assert AnsibleVaultEncryptedUnicode('abc').count('a', 0, 4) == 1
    assert AnsibleVaultEncryptedUnicode('abc').count('a', 0, 5) == 1
    assert AnsibleVaultEncryptedUnicode('abc').count('a', 0, 6) == 1
    assert AnsibleVaultEncryptedUnicode('abc').count('a', 0, 7) == 1
    assert Ans

# Generated at 2022-06-17 06:47:25.524372
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:47:33.758543
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:47:38.132166
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu == 'test'
    assert avu != 'test2'


# Generated at 2022-06-17 06:47:44.490956
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext, 'AnsibleVaultEncryptedUnicode.__eq__() failed'


# Generated at 2022-06-17 06:47:52.694682
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a vault object
    vault = vaultlib.VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu == 'foo'
    assert avu != 'bar'

    # Test without a vault object
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;foo\nbar\n')
    assert avu != 'foo'
    assert avu != 'bar'


# Generated at 2022-06-17 06:48:04.303211
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')

# Generated at 2022-06-17 06:48:09.597118
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avu.__ne__(plaintext)
    assert avu.__ne__(AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret))
    assert not avu.__ne__(avu)


# Generated at 2022-06-17 06:48:14.985831
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'my plaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:48:22.730250
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:48:25.462320
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test for method __ne__ (__ne__ of class AnsibleVaultEncryptedUnicode)
    # This method is not implemented
    pass


# Generated at 2022-06-17 06:48:38.774381
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:48:43.384063
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'


# Generated at 2022-06-17 06:48:46.480376
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()


# Generated at 2022-06-17 06:48:57.000852
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = '$ANSIBLE_VAULT;1.1;AES256\n'
    secret += '6332633263326332633263326332633263326332633263326332633263326332633263326332633263326\n'
    secret += '33263326332633263326332633263326332633263326332633263326332633263326332633263326332633\n'
    secret += '26332633263326332633263326332633263326332633263326332633263326332633263326332633263326\n'


# Generated at 2022-06-17 06:49:01.124615
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    plaintext = 'foo'
    ciphertext = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode('foo').is_encrypted()


# Generated at 2022-06-17 06:49:16.979338
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('mysecret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('mysecret', vault, 'mysecret')
    assert avu == 'mysecret'
    assert avu != 'mysecret2'
    assert avu != 'mysecret2'
    assert avu != 'mysecret2'
    assert avu != 'mysecret2'
    assert avu != 'mysecret2'
    assert avu != 'mysecret2'
    assert avu != 'mysecret2'
    assert avu != 'mysecret2'
    assert avu != 'mysecret2'
    assert avu != 'mysecret2'
    assert avu != 'mysecret2'
    assert avu != 'mysecret2'
    assert av

# Generated at 2022-06-17 06:49:27.133200
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test case 1:
    #   - vault is not set
    #   - other is not a AnsibleVaultEncryptedUnicode
    #   - other is not equal to data
    #   - expected result: True
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.__ne__('test1')

    # Test case 2:
    #   - vault is not set
    #   - other is not a AnsibleVaultEncryptedUnicode
    #   - other is equal to data
    #   - expected result: False
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.__ne__('test')

    # Test case 3:
    #   - vault is not set
    #   - other is a AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:49:39.541403
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string that is not encrypted
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test with a string that is encrypted

# Generated at 2022-06-17 06:49:48.414271
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, 'test')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')

# Generated at 2022-06-17 06:49:54.070159
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert not (avu != 'test')


# Generated at 2022-06-17 06:50:05.676020
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:11.041109
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:50:19.090430
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMNoPadding
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFBNoPadding
    from ansible.parsing.vault import VaultA

# Generated at 2022-06-17 06:50:25.966878
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu.is_encrypted() == True
    avu.vault = vault
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:50:32.552874
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test1'


# Generated at 2022-06-17 06:50:42.704995
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', VaultLib('test2'), secret)


# Generated at 2022-06-17 06:50:54.977488
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode('test2')
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)


# Generated at 2022-06-17 06:51:04.243413
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''
    Test method __ne__ of class AnsibleVaultEncryptedUnicode
    '''
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, 'test')


# Generated at 2022-06-17 06:51:12.180771
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test that __ne__ returns True when the decrypted value is not equal to the other value
    # and False when the decrypted value is equal to the other value
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.__ne__('test') == False
    assert avu.__ne__('test2') == True


# Generated at 2022-06-17 06:51:17.561954
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:51:29.873503
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:51:39.938656
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', None, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')


# Generated at 2022-06-17 06:51:45.459091
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')


# Generated at 2022-06-17 06:51:57.352111
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:51:59.783687
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu.is_encrypted() is True
    assert avu.data == 'test'
    assert avu.is_encrypted() is False


# Generated at 2022-06-17 06:52:05.292770
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu == 'test'

    # Test with a AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('test')
    assert avu == avu2

    # Test with a different string
    assert avu != 'test2'

    # Test with a different AnsibleVaultEncryptedUnicode
    avu3 = AnsibleVaultEncryptedUnicode('test2')
    assert avu != avu3


# Generated at 2022-06-17 06:52:10.536080
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a non-vault object
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.__eq__('test') is False

    # Test with a vault object
    avu = AnsibleVaultEncryptedUnicode('test')
    avu.vault = 'test'
    assert avu.__eq__('test') is True



# Generated at 2022-06-17 06:52:21.435375
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:52:27.234635
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test1'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data


# Generated at 2022-06-17 06:52:38.435472
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB

    # Create a vault object
    vault = VaultLib([VaultSecret('secret'), VaultAES256()])
    # Create an encrypted string
    encrypted_string = vault

# Generated at 2022-06-17 06:53:09.449985
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')


# Generated at 2022-06-17 06:53:15.072598
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test1'


# Generated at 2022-06-17 06:53:23.148467
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode('test')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)


# Generated at 2022-06-17 06:53:28.476824
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    class MockVault(object):
        def __init__(self, is_encrypted_return_value):
            self.is_encrypted_return_value = is_encrypted_return_value

        def is_encrypted(self, ciphertext):
            return self.is_encrypted_return_value

    # Test when the vault is not encrypted
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu.vault = MockVault(False)
    assert avu != 'foo'

    # Test when the vault is encrypted
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu.vault = MockVault(True)
    assert avu != 'foo'



# Generated at 2022-06-17 06:53:35.646447
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:53:43.635626
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')
