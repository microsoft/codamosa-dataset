

# Generated at 2022-06-17 06:44:02.517267
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:44:07.905938
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu <= plaintext


# Generated at 2022-06-17 06:44:15.254001
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu <= plaintext
    assert not (avu <= 'not_test')


# Generated at 2022-06-17 06:44:24.313335
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:44:36.377359
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    # Test with a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.rfind('a') == 0
    assert avu.rfind('b') == 1
    assert avu.rfind('c') == 2
    assert avu.rfind('d') == -1
    # Test with a string
    assert avu.rfind('a', 0, 1) == 0
    assert avu.rfind('b', 0, 1) == -1
    assert avu.rfind('c', 0, 1) == -1
    assert avu.rfind('d', 0, 1) == -1
    # Test with a AnsibleVaultEncryptedUnicode object
    avu2 = AnsibleVaultEncryptedUnicode('b')
   

# Generated at 2022-06-17 06:44:44.842513
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    import unittest
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACEnvelope
    from ansible.parsing.vault import VaultAES256Envelope

    class TestAnsibleVaultEncryptedUnicode(unittest.TestCase):
        def test_AnsibleVaultEncryptedUnicode___le__(self):
            vault = VaultLib([VaultAES256(), VaultAES256HMAC(), VaultAES256Envelope(), VaultAES256HMACEnvelope()])

# Generated at 2022-06-17 06:44:54.436626
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.replace('t', 'T') == 'TesT'
    assert avu.replace('t', 'T', 1) == 'TesT'
    assert avu.replace('t', 'T', 2) == 'TesT'
    assert avu.replace('t', 'T', 3) == 'TesT'
    assert avu.replace('t', 'T', 4) == 'TesT'
    assert avu.replace('t', 'T', 5) == 'TesT'

# Generated at 2022-06-17 06:45:04.330153
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.replace('t', 'T') == 'TesT'
    assert avu.replace(avu, 'T') == 'TesT'
    assert avu.replace('t', avu) == 'TesT'
    assert avu.replace(avu, avu) == 'TesT'


# Generated at 2022-06-17 06:45:15.940989
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.__gt__('ab')
    assert not avu.__gt__('abc')
    assert not avu.__gt__('abcd')

    # Test with an AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('ab')
    assert avu.__gt__(avu2)
    avu2 = AnsibleVaultEncryptedUnicode('abc')
    assert not avu.__gt__(avu2)
    avu2 = AnsibleVaultEncryptedUnicode('abcd')
    assert not avu.__gt__(avu2)


# Generated at 2022-06-17 06:45:24.394751
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:45:52.347060
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:46:00.351989
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:46:10.056183
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = '$ANSIBLE_VAULT;1.1;AES256'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu + avu == plaintext + plaintext
    assert avu + plaintext == plaintext + plaintext
    assert plaintext + avu == plaintext + plaintext
    assert avu + ciphertext == plaintext + ciphertext
    assert ciphertext + avu == ciphertext + plaintext


# Generated at 2022-06-17 06:46:18.714465
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test that __eq__ returns True when the data is equal
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 == avu2

    # Test that __eq__ returns False when the data is not equal
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('abcd')
    assert avu1 != avu2

    # Test that __eq__ returns False when the data is not equal
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('abcd')
    assert avu1 != avu2

    # Test that __eq__ returns False when the data

# Generated at 2022-06-17 06:46:26.291493
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('mysecret')
    secret = 'mysecret'
    plaintext = 'myplaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:46:33.498644
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:46:40.224556
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:46:49.316606
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC

    vault_secret = VaultSecret('secret')
    vault_aes256 = VaultAES256(vault_secret)
    vault_aes256cbc = VaultAES256CBC(vault_secret)
    vault_lib = VaultLib([vault_aes256, vault_aes256cbc])

    # Test with a string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault_lib, vault_secret)
    assert avu != 'test'

    # Test with a unicode
    avu = Ansible

# Generated at 2022-06-17 06:46:53.798068
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.__lt__('abd')

    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('abd')
    assert avu.__lt__(avu2)


# Generated at 2022-06-17 06:46:57.735002
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:47:10.687578
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test with AnsibleVaultEncryptedUnicode
    avu1 = AnsibleVaultEncryptedUnicode('test1')
    avu2 = AnsibleVaultEncryptedUnicode('test2')
    assert avu1 + avu2 == 'test1test2'

    # Test with text_type
    avu1 = AnsibleVaultEncryptedUnicode('test1')
    assert avu1 + 'test2' == 'test1test2'

    # Test with bytes
    avu1 = AnsibleVaultEncryptedUnicode('test1')
    assert avu1 + b'test2' == 'test1test2'


# Generated at 2022-06-17 06:47:16.667435
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test case 1:
    #   AnsibleVaultEncryptedUnicode + AnsibleVaultEncryptedUnicode
    #   Expected result:
    #       The concatenation of the two AnsibleVaultEncryptedUnicode objects
    #       as a AnsibleVaultEncryptedUnicode object
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('def')
    assert avu1 + avu2 == AnsibleVaultEncryptedUnicode('abcdef')

    # Test case 2:
    #   AnsibleVaultEncryptedUnicode + str
    #   Expected result:
    #       The concatenation of the AnsibleVaultEncryptedUnicode object and
    #       the str object as a AnsibleVaultEnc

# Generated at 2022-06-17 06:47:24.959398
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test with AnsibleVaultEncryptedUnicode
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('def')
    assert avu1 + avu2 == 'abcdef'
    # Test with string
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + 'def' == 'abcdef'
    # Test with bytes
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + b'def' == 'abcdef'


# Generated at 2022-06-17 06:47:34.916925
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu + avu == plaintext + plaintext
    assert avu + plaintext == plaintext + plaintext
    assert plaintext + avu == plaintext + plaintext


# Generated at 2022-06-17 06:47:45.381702
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string that is not encrypted
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.__ne__('test')

    # Test with a string that is encrypted

# Generated at 2022-06-17 06:47:51.323520
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:48:02.806302
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test with a AnsibleVaultEncryptedUnicode object
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('def')
    assert avu1 + avu2 == 'abcdef'

    # Test with a unicode object
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = 'def'
    assert avu1 + avu2 == 'abcdef'

    # Test with a byte string
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = b'def'
    assert avu1 + avu2 == 'abcdef'



# Generated at 2022-06-17 06:48:06.834312
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext


# Generated at 2022-06-17 06:48:11.128611
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu == 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')
    assert avu == AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')


# Generated at 2022-06-17 06:48:18.375876
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.data == plaintext
    assert avu + 'test' == plaintext + 'test'
    assert 'test' + avu == 'test' + plaintext
    assert avu + avu == plaintext + plaintext
    assert avu + AnsibleVaultEncryptedUnicode(ciphertext) == plaintext + plaintext


# Generated at 2022-06-17 06:48:30.620595
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:48:39.015808
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)


# Generated at 2022-06-17 06:48:45.548983
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext


# Generated at 2022-06-17 06:48:54.388170
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')


# Generated at 2022-06-17 06:48:57.515499
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:49:12.333139
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test for equality with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu == 'test'

    # Test for equality with a AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('test')
    assert avu == avu2

    # Test for equality with a AnsibleVaultEncryptedUnicode with a different value
    avu3 = AnsibleVaultEncryptedUnicode('test2')
    assert avu != avu3

    # Test for equality with a AnsibleVaultEncryptedUnicode with a different value
    avu4 = AnsibleVaultEncryptedUnicode('test')
    avu4.vault = None
    assert avu != avu4



# Generated at 2022-06-17 06:49:28.740873
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    assert avu != plaintext
    assert avu != ciphertext
    assert avu != 'test'
    assert avu != 'test'
    assert avu != 'test'
    assert avu != 'test'
    assert avu != 'test'
    assert avu != 'test'
    assert avu != 'test'
    assert avu != 'test'
    assert avu != 'test'
    assert avu != 'test'
    assert avu != 'test'

# Generated at 2022-06-17 06:49:36.428588
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avu == plaintext
    assert avu != ciphertext
    assert avu != 'not_test'


# Generated at 2022-06-17 06:49:40.128427
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:49:44.718608
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode('test').is_encrypted()


# Generated at 2022-06-17 06:49:57.872669
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:50:04.065030
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True
    assert avu.data == plaintext
    assert avu.is_encrypted() == False
    assert avu.data == plaintext
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:50:13.992288
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    import ansible.parsing.yaml.objects as objects
    import ansible.parsing.yaml.loader as loader

    # Create a vault object
    vault_obj = vault.VaultLib('test')

    # Create a AnsibleVaultEncryptedUnicode object
    avu = objects.AnsibleVaultEncryptedUnicode.from_plaintext('test', vault_obj, 'test')

    # Test __eq__
    assert avu == 'test'
    assert avu == avu
    assert not avu == 'test2'
    assert not avu == None


# Generated at 2022-06-17 06:50:19.899691
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu == 'test'
    assert avu != 'test2'

    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('test')
    assert avu == avu2
    avu2 = AnsibleVaultEncryptedUnicode('test2')
    assert avu != avu2

    # Test with a non-string
    assert avu != 1
    assert avu != 1.0
    assert avu != True
    assert avu != None


# Generated at 2022-06-17 06:50:26.940208
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'not_test'
    assert avu != AnsibleVaultEncryptedUnicode('not_test')


# Generated at 2022-06-17 06:50:31.758478
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:50:37.178582
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avu != plaintext


# Generated at 2022-06-17 06:50:40.391708
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode("test")
    assert avu != "test"

    # Test with an AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode("test")
    assert avu != avu2


# Generated at 2022-06-17 06:50:44.671051
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:50:55.635590
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault as vault
    import ansible.parsing.vaultlib as vaultlib
    import ansible.parsing.yaml.objects as objects

    # Create a vault object
    vault_secret = 'secret'
    vault_password = vault.VaultSecret(vault_secret)
    vault_obj = vaultlib.VaultLib([vault_password])

    # Create an AnsibleVaultEncryptedUnicode object
    plaintext = 'plaintext'
    ciphertext = vault_obj.encrypt(plaintext)
    avu = objects.AnsibleVaultEncryptedUnicode(ciphertext)

    # Test is_encrypted()
    assert avu.is_encrypted() == True

    # Test is_encrypted() with a plaintext string
    plaintext = 'plaintext'

# Generated at 2022-06-17 06:51:16.161913
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:51:23.306312
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)


# Generated at 2022-06-17 06:51:31.674286
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly130

# Generated at 2022-06-17 06:51:41.205608
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test1', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test1')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', None, secret)

# Generated at 2022-06-17 06:51:53.115795
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    vault_obj = vault.VaultLib('test')
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault_obj, 'test')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault_obj, 'test')
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault_obj, 'test')
    avu4 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault_obj, 'test')
    avu5 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault_obj, 'test')

# Generated at 2022-06-17 06:51:59.410115
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test1'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data


# Generated at 2022-06-17 06:52:03.788301
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:52:12.855663
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, 'test')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, 'test2')

# Generated at 2022-06-17 06:52:19.891481
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode('test2')


# Generated at 2022-06-17 06:52:29.712707
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('test')
    assert avu != avu2

    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('test')
    assert avu != avu2

    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test with another AnsibleVaultEncryptedUnicode
   

# Generated at 2022-06-17 06:53:16.491765
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode('test2')
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data.encode()
    assert avu != AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:53:26.247989
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:53:28.902903
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test for method __ne__ (__ne__ of class AnsibleVaultEncryptedUnicode)
    # This method is not tested because it is not implemented.
    pass


# Generated at 2022-06-17 06:53:36.670261
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu == 'test'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test2'


# Generated at 2022-06-17 06:53:42.733348
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'
    assert avu != 'test1'
    assert avu != AnsibleVaultEncryptedUnicode('test1')
    assert avu != AnsibleVaultEncryptedUnicode('test')
