

# Generated at 2022-06-17 06:44:06.865723
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode('foo')
    assert avu != AnsibleVaultEncryptedUnicode('bar')


# Generated at 2022-06-17 06:44:19.139588
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    ciphertext = vault.encrypt('abcdefghijklmnopqrstuvwxyz', 'test')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.find('abc') == 0
    assert avu.find('abc', 1) == -1
    assert avu.find('abc', 0, 10) == 0
    assert avu.find('abc', 0, 2) == -1
    assert avu.find('def') == 3
    assert avu.find('def', 4) == -1
    assert avu.find('def', 3, 6) == 3
    assert avu.find('def', 3, 5) == -1

# Generated at 2022-06-17 06:44:29.632099
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    class MockVault(object):
        def __init__(self):
            pass

        def decrypt(self, ciphertext, obj=None):
            return ciphertext

        def is_encrypted(self, ciphertext):
            return True

    ciphertext = b'ciphertext'
    vault = MockVault()
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    assert avu.rfind(b'ciphertext') == 0
    assert avu.rfind(b'cipher') == 0
    assert avu.rfind(b'cipher', 0, 5) == 0
    assert avu.rfind(b'cipher', 0, 4) == 0
    assert avu.rfind(b'cipher', 0, 3) == -1

# Generated at 2022-06-17 06:44:40.990314
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:44:49.296108
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode("abcdef")
    assert avu.rfind("cde") == 2
    assert avu.rfind("cde", 0, 2) == -1
    assert avu.rfind("cde", 0, 3) == 2
    assert avu.rfind("cde", 0, 4) == 2
    assert avu.rfind("cde", 0, 5) == 2
    assert avu.rfind("cde", 0, 6) == 2
    assert avu.rfind("cde", 0, 7) == 2
    assert avu.rfind("cde", 0, 8) == 2
    assert avu.rfind("cde", 0, 9) == 2
    assert avu.rfind("cde", 0, 10)

# Generated at 2022-06-17 06:44:58.463820
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()

    plaintext = 'plaintext'
    avu = AnsibleVaultEncryptedUnicode(plaintext)
    avu.vault = vault
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:45:03.886387
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:45:16.036625
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', None, secret)
    assert avu != None


# Generated at 2022-06-17 06:45:28.003661
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None)
    assert avu == 'test'

    # Test with an AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None)
    assert avu == avu2

    # Test with a different AnsibleVaultEncryptedUnicode
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext('test2', None, None)
    assert avu != avu3

    # Test with a different string
    assert avu != 'test2'

    # Test with a different type
    assert avu != 1



# Generated at 2022-06-17 06:45:33.876775
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:45:43.667302
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()


# Generated at 2022-06-17 06:45:54.757369
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a non-encrypted string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test with an encrypted string

# Generated at 2022-06-17 06:46:05.895075
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test for method __ne__ (__ne__ of class AnsibleVaultEncryptedUnicode)
    # This test is needed because the __ne__ method was added in Ansible 2.4
    # and we want to make sure it works as expected on older versions of Python
    # where it is not implemented by default.
    #
    # The __ne__ method is implemented in Python 3.0 and later.
    #
    # This test is not run on Python 3.0 and later because it is not needed.
    if _sys.version_info[0] >= 3:
        return

    # Create a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode('test')

    # Test that __ne__ returns True when the object is compared to a string
    # that is different from the object's data.

# Generated at 2022-06-17 06:46:16.676247
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:46:27.043108
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('mysecret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('mysecret', vault, 'mysecret')
    assert avu != 'mysecret'
    assert avu != 'mysecret2'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('mysecret2', vault, 'mysecret')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('mysecret', vault, 'mysecret2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('mysecret2', vault, 'mysecret2')


# Generated at 2022-06-17 06:46:34.107523
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    # Test find with a string
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.find('b') == 1
    assert avu.find('b', 2) == -1
    assert avu.find('b', 2, 3) == -1
    assert avu.find('b', 2, 2) == -1
    assert avu.find('b', 2, 1) == -1
    assert avu.find('b', -3, -2) == 1
    assert avu.find('b', -3, -3) == 1
    assert avu.find('b', -3, -4) == -1
    assert avu.find('b', 0, -1) == 1
    assert avu.find('b', 0, 4) == 1

# Generated at 2022-06-17 06:46:41.929248
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''
    Test method __ne__ of class AnsibleVaultEncryptedUnicode
    '''
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu != 'foo'

    # Test with a AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu2 = AnsibleVaultEncryptedUnicode('foo')
    assert avu != avu2


# Generated at 2022-06-17 06:46:50.760863
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMNoPadding
    from ansible.parsing.vault import VaultAES256CBCHMACSHA256
    from ansible.parsing.vault import VaultAES256GCMNoPaddingHMACSHA256
    from ansible.parsing.vault import VaultAES256GCMHMACSHA256
    from ansible.parsing.vault import VaultAES256CBCHMACSHA512


# Generated at 2022-06-17 06:46:54.451986
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu == 'test'
    assert avu != 'test2'


# Generated at 2022-06-17 06:47:02.171681
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')
    assert avu == 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'secret')
    assert avu == AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')


# Generated at 2022-06-17 06:47:18.301441
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    # Test case 1:
    #   - sub is a AnsibleVaultEncryptedUnicode
    #   - sub is found
    #   - start is 0
    #   - end is _sys.maxsize
    #   - expected result is 0
    avu = AnsibleVaultEncryptedUnicode('abc')
    sub = AnsibleVaultEncryptedUnicode('a')
    start = 0
    end = _sys.maxsize
    expected_result = 0
    actual_result = avu.rfind(sub, start, end)
    assert actual_result == expected_result

    # Test case 2:
    #   - sub is a AnsibleVaultEncryptedUnicode
    #   - sub is found
    #   - start is 1
    #   - end is _sys.maxsize
    #   -

# Generated at 2022-06-17 06:47:26.626588
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')


# Generated at 2022-06-17 06:47:38.423151
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    ciphertext = vault.encrypt('test', secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.rfind('t') == 2
    assert avu.rfind('t', 0, 1) == -1
    assert avu.rfind('t', 0, 2) == 1
    assert avu.rfind('t', 0, 3) == 2
    assert avu.rfind('t', 0, 4) == 2
    assert avu.rfind('t', 0, 5) == 2
    assert avu.rfind('t', 0, 6) == 2

# Generated at 2022-06-17 06:47:48.103627
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a non-encrypted string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test with an encrypted string

# Generated at 2022-06-17 06:47:52.176085
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:47:58.504850
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:48:07.753912
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.rfind('t') == 2
    assert avu.rfind('e') == 1
    assert avu.rfind('s') == 3
    assert avu.rfind('x') == -1
    assert avu.rfind('t', 0, 2) == 2
    assert avu.rfind('t', 0, 1) == -1
    assert avu.rfind('t', 0, 0) == -1

# Generated at 2022-06-17 06:48:10.516040
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:48:18.596923
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data.encode()
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data.encode('utf-8')
    assert avu != AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:48:24.319870
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.rfind('c') == 2
    assert avu.rfind('c', 0, 3) == 2
    assert avu.rfind('c', 0, 2) == -1
    assert avu.rfind('c', 0, 1) == -1
    assert avu.rfind('c', 0, 0) == -1
    assert avu.rfind('c', 0, -1) == -1
    assert avu.rfind('c', 0, -2) == -1
    assert avu.rfind('c', 0, -3) == -1
    assert avu.rfind('c', 0, -4) == -1

# Generated at 2022-06-17 06:48:40.168587
# Unit test for method find of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:48:49.755771
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:48:56.575637
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'secret'
    plaintext = 'hello world'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.find('hello') == 0
    assert avu.find('world') == 6
    assert avu.find('foo') == -1
    assert avu.find('hello', 1) == -1
    assert avu.find('hello', 0, 5) == -1
    assert avu.find('hello', 0, 6) == 0
    assert avu.find('world', 0, 6) == -1
    assert avu.find('world', 6) == 6


# Generated at 2022-06-17 06:49:03.465923
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.find('t') == 0
    assert avu.find('t', 1) == 1
    assert avu.find('t', 2) == 2
    assert avu.find('t', 3) == 3
    assert avu.find('t', 4) == -1
    assert avu.find('t', -1) == 3
    assert avu.find('t', -2) == 2
    assert avu.find('t', -3) == 1
    assert av

# Generated at 2022-06-17 06:49:18.632959
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode("abc")
    assert avu.find("a") == 0
    assert avu.find("b") == 1
    assert avu.find("c") == 2
    assert avu.find("d") == -1
    assert avu.find("ab") == 0
    assert avu.find("bc") == 1
    assert avu.find("cd") == -1
    assert avu.find("abc") == 0
    assert avu.find("bcd") == -1
    assert avu.find("") == 0
    assert avu.find("", 1) == 1
    assert avu.find("", 2) == 2
    assert avu.find("", 3) == 3

    # Test with another AnsibleVaultEncryptedUnic

# Generated at 2022-06-17 06:49:23.080537
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test1'


# Generated at 2022-06-17 06:49:29.737867
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:49:35.525342
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    plaintext = 'hello world'
    ciphertext = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()



# Generated at 2022-06-17 06:49:46.020162
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.find('b') == 1
    assert avu.find('b', 2) == -1
    assert avu.find('b', 2, 3) == -1
    assert avu.find('b', 2, 2) == -1
    assert avu.find('b', 2, 1) == -1
    assert avu.find('b', 0, 3) == 1
    assert avu.find('b', -3, 3) == 1
    assert avu.find('b', -4, 3) == 1
    assert avu.find('b', -4, 2) == -1
    assert avu.find('b', -4, -3) == -1

# Generated at 2022-06-17 06:49:52.488096
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:50:04.396207
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu != 'foo'

    # Test with an AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu2 = AnsibleVaultEncryptedUnicode('foo')
    assert avu != avu2

    # Test with a different AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu2 = AnsibleVaultEncryptedUnicode('bar')
    assert avu != avu2


# Generated at 2022-06-17 06:50:08.922980
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext


# Generated at 2022-06-17 06:50:18.975728
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('mysecret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('mysecret', vault, 'mysecret')
    assert avu == 'mysecret'
    assert avu != 'mysecret2'
    assert avu != 'mysecret\n'
    assert avu != 'mysecret\r'
    assert avu != 'mysecret\r\n'
    assert avu != 'mysecret\r\n\r\n'
    assert avu != 'mysecret\r\n\r\n\r\n'
    assert avu != 'mysecret\r\n\r\n\r\n\r\n'

# Generated at 2022-06-17 06:50:26.798741
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')


# Generated at 2022-06-17 06:50:32.665579
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'other'


# Generated at 2022-06-17 06:50:40.717332
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode('test')


# Generated at 2022-06-17 06:50:45.884704
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    ciphertext = vault.encrypt('test', secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleUnicode('test')
    assert avu != 'test'


# Generated at 2022-06-17 06:50:56.091983
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test1'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode('test')
    assert avu != AnsibleUnicode('test')
    assert avu != 'test'
    assert avu != AnsibleUnicode(ciphertext)


# Generated at 2022-06-17 06:51:03.218147
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:51:08.072010
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu == 'test'
    assert avu != 'test2'


# Generated at 2022-06-17 06:51:23.812563
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:51:28.928394
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')


# Generated at 2022-06-17 06:51:37.353568
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'secret')


# Generated at 2022-06-17 06:51:46.585674
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('hello')
    assert avu.__ne__('hello')

    # Test with a AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('hello')
    assert avu.__ne__(avu2)

    # Test with a AnsibleVaultEncryptedUnicode with a different value
    avu2 = AnsibleVaultEncryptedUnicode('world')
    assert avu.__ne__(avu2)

    # Test with a AnsibleVaultEncryptedUnicode with a different value
    avu2 = AnsibleVaultEncryptedUnicode('world')
    assert avu.__ne__(avu2)

    # Test with a AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:51:54.616915
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()


# Generated at 2022-06-17 06:52:01.534647
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, 'test')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    avu.data = plaintext
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:52:05.202045
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:52:10.138596
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;foo\nbar\n')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:52:17.919134
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu == 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')


# Generated at 2022-06-17 06:52:28.954185
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:52:55.941268
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test case 1
    # Test case 1.1
    avu1 = AnsibleVaultEncryptedUnicode('test')
    avu1.vault = None
    avu2 = AnsibleVaultEncryptedUnicode('test')
    avu2.vault = None
    assert avu1 != avu2

    # Test case 1.2
    avu1 = AnsibleVaultEncryptedUnicode('test')
    avu1.vault = None
    avu2 = AnsibleVaultEncryptedUnicode('test')
    avu2.vault = 'test'
    assert avu1 != avu2

    # Test case 1.3
    avu1 = AnsibleVaultEncryptedUnicode('test')
    avu1.vault = 'test'

# Generated at 2022-06-17 06:53:00.453522
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu.is_encrypted() == True
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:53:12.738990
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', VaultLib('test2'), secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plain

# Generated at 2022-06-17 06:53:17.305933
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'not_test'


# Generated at 2022-06-17 06:53:25.837685
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test1', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test1')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', None, secret)


# Generated at 2022-06-17 06:53:33.833359
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    plaintext = 'hello world'
    ciphertext = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:53:41.624016
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != ciphertext
