

# Generated at 2022-06-17 06:44:04.750297
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:44:16.139478
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.data == plaintext
    assert avu <= plaintext
    assert avu <= avu
    assert avu <= AnsibleVaultEncryptedUnicode(ciphertext)
    assert not avu <= 'test1'
    assert not avu <= AnsibleVaultEncryptedUnicode(vault.encrypt('test1', secret))


# Generated at 2022-06-17 06:44:24.094853
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:44:36.185669
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'this is a test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.count('t') == 3
    assert avu.count('t', 0, 10) == 3
    assert avu.count('t', 0, 9) == 2
    assert avu.count('t', 0, 8) == 1
    assert avu.count('t', 0, 7) == 0
    assert avu.count('t', 0, 6) == 0
    assert avu.count('t', 0, 5) == 0
    assert avu.count

# Generated at 2022-06-17 06:44:42.928626
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.data == plaintext
    assert avu <= plaintext
    assert avu <= avu
    assert not avu <= 'not_test'
    assert not avu <= AnsibleVaultEncryptedUnicode('not_test')


# Generated at 2022-06-17 06:44:51.730138
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')


# Generated at 2022-06-17 06:45:03.342500
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)


# Generated at 2022-06-17 06:45:15.941278
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    # Test when self.vault is None
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.__le__('test') == False
    assert avu.__le__('test2') == False
    assert avu.__le__('test1') == False
    assert avu.__le__('tes') == False
    assert avu.__le__('tes1') == False
    assert avu.__le__('tes2') == False
    assert avu.__le__('tes3') == False

    # Test when self.vault is not None
    avu.vault = 'test'
    assert avu.__le__('test') == True
    assert avu.__le__('test2') == True
    assert avu.__le__('test1') == True
   

# Generated at 2022-06-17 06:45:18.596838
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode('test') != 'test'


# Generated at 2022-06-17 06:45:29.229022
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'secret'
    plaintext = 'abcdef'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.count('a') == 1
    assert avu.count('a', 1) == 0
    assert avu.count('a', 1, 2) == 0
    assert avu.count('a', 1, 3) == 1
    assert avu.count('a', 1, 4) == 1
    assert avu.count('a', 1, 5) == 1
    assert avu.count('a', 1, 6) == 1

# Generated at 2022-06-17 06:45:40.608940
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:45:47.761986
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    avu.data = plaintext
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:45:53.504279
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode('foo') != 'foo'
    assert AnsibleVaultEncryptedUnicode('foo') != AnsibleVaultEncryptedUnicode('foo')
    assert AnsibleVaultEncryptedUnicode('foo') != 'bar'
    assert AnsibleVaultEncryptedUnicode('foo') != AnsibleVaultEncryptedUnicode('bar')


# Generated at 2022-06-17 06:45:58.117397
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)


# Generated at 2022-06-17 06:46:05.142787
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'foo'


# Generated at 2022-06-17 06:46:12.660493
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'secret')
    assert avu1 == 'foo'
    assert avu1 == avu2
    assert avu1 != avu3
    assert avu1 != 'bar'


# Generated at 2022-06-17 06:46:20.400367
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode('test').is_encrypted()


# Generated at 2022-06-17 06:46:28.439458
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:46:35.667399
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import unittest
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1
    from ansible.parsing.vault import Vault

# Generated at 2022-06-17 06:46:46.609546
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test1'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).vault
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).ansible_pos
    assert avu != AnsibleVaultEncryptedUn

# Generated at 2022-06-17 06:46:58.372313
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data
    assert avu != AnsibleUnicode(ciphertext)
    assert avu != AnsibleUnicode(ciphertext).data
    assert avu != 'test'
    assert avu != AnsibleUnicode('test')

# Generated at 2022-06-17 06:47:06.359492
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu == 'test'

    # Test with a AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('test')
    assert avu == avu2

    # Test with a AnsibleVaultEncryptedUnicode with a different value
    avu2 = AnsibleVaultEncryptedUnicode('test2')
    assert avu != avu2



# Generated at 2022-06-17 06:47:18.587762
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:47:24.783394
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:47:32.748228
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:47:39.665995
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:47:46.203222
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')


# Generated at 2022-06-17 06:47:54.195076
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # create a vault object
    vault_obj = VaultLib([])
    vault_obj.update_password('test')

    # create a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault_obj, 'test')
    avu.vault = vault_obj

    # test __eq__
    assert avu == 'test'
    assert avu != 'test1'


# Generated at 2022-06-17 06:48:02.761325
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != 'test2'


# Generated at 2022-06-17 06:48:07.593328
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    avu.data = plaintext
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:48:21.433883
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu == 'test'
    assert avu != 'test2'
    assert avu != 'test '
    assert avu != ' test'
    assert avu != 'test\n'
    assert avu != '\ntest'
    assert avu != 'test\r'
    assert avu != '\rtest'
    assert avu != 'test\r\n'
    assert avu != '\r\ntest'
    assert avu != 'test\t'
    assert avu != '\ttest'
    assert avu != 'test\x00'
   

# Generated at 2022-06-17 06:48:31.384761
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    import ansible.parsing.vaultlib as vaultlib
    import ansible.parsing.yaml.objects as objects

    vault_password = 'vault_password'
    vault_secret = vault.VaultSecret(vault_password)
    vault_obj = vaultlib.VaultLib(vault_secret)

    plaintext = 'plaintext'
    ciphertext = vault_obj.encrypt(plaintext, vault_secret)
    avu = objects.AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault_obj

    assert avu == plaintext
    assert avu != 'not_plaintext'


# Generated at 2022-06-17 06:48:42.867630
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACEnv
    from ansible.parsing.vault import VaultAES256Env
    from ansible.parsing.vault import VaultAES256File
    from ansible.parsing.vault import VaultAES256HMACFile
    from ansible.parsing.vault import VaultAES256FileEnv
    from ansible.parsing.vault import VaultAES256HMACFileEnv
    from ansible.parsing.vault import Vault

# Generated at 2022-06-17 06:48:49.851087
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')


# Generated at 2022-06-17 06:48:52.110840
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:48:57.402800
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test with an AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('test')
    assert avu != avu2

    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test with an AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('test')
    assert avu != avu2



# Generated at 2022-06-17 06:49:01.190409
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    v = VaultLib('test')
    ciphertext = v.encrypt('test')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = v
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode('test').is_encrypted()


# Generated at 2022-06-17 06:49:11.309235
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a non-vault object
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test with a vault object
    avu = AnsibleVaultEncryptedUnicode('test')
    avu.vault = True
    assert avu != 'test'


# Generated at 2022-06-17 06:49:27.453973
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    ciphertext = vault.encrypt('test', secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode('test2')
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(vault.encrypt('test2', secret))


# Generated at 2022-06-17 06:49:32.957071
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu == 'foo'
    assert avu != 'bar'


# Generated at 2022-06-17 06:49:39.841798
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'other'


# Generated at 2022-06-17 06:49:45.091965
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu == 'foo'
    assert avu != 'bar'


# Generated at 2022-06-17 06:49:49.717955
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'


# Generated at 2022-06-17 06:49:58.654667
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'not_test'


# Generated at 2022-06-17 06:50:02.443307
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu == 'foo'
    assert avu != 'bar'


# Generated at 2022-06-17 06:50:15.054079
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:50:22.600873
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:34.442303
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256CFB8
    from ansible.parsing.vault import VaultAES256CFB1

# Generated at 2022-06-17 06:50:37.437589
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'


# Generated at 2022-06-17 06:50:41.681990
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:50:55.942679
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:51:02.612340
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None)
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', None, None)


# Generated at 2022-06-17 06:51:07.859831
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()



# Generated at 2022-06-17 06:51:16.200692
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu != 'foo'

    # Test with an AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('foo')
    assert avu != avu2

    # Test with a string that is not equal
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu != 'bar'

    # Test with an AnsibleVaultEncryptedUnicode that is not equal
    avu2 = AnsibleVaultEncryptedUnicode('bar')
    assert avu != avu2



# Generated at 2022-06-17 06:51:21.098528
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext


# Generated at 2022-06-17 06:51:25.869485
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:51:33.801304
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True
    assert avu.data == plaintext
    assert avu == plaintext
    assert avu != ciphertext
    assert avu.__str__() == plaintext
    assert avu.__unicode__() == plaintext
    assert avu.encode() == plaintext.encode()
    assert avu.__repr__() == plaintext.__repr__()
    assert avu.__int__() == plaintext.__int__

# Generated at 2022-06-17 06:51:38.493473
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:51:44.041963
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:51:48.233594
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu != 'foo'
    assert avu != AnsibleVaultEncryptedUnicode('foo')
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode('bar')


# Generated at 2022-06-17 06:51:58.283404
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:52:07.973170
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test for method __ne__ (self, other)
    # of class AnsibleVaultEncryptedUnicode
    #
    # This test is for the case where the vault is not set
    #
    # The __ne__ method should return True if the vault is not set
    #
    # The __ne__ method should return False if the vault is set
    # and the value of the AnsibleVaultEncryptedUnicode is equal to the other object
    #
    # The __ne__ method should return True if the vault is set
    # and the value of the AnsibleVaultEncryptedUnicode is not equal to the other object

    # Create an AnsibleVaultEncryptedUnicode object with a vault that is not set
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.vault is None

# Generated at 2022-06-17 06:52:14.550763
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    assert avu == plaintext
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode('test2')
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)


# Generated at 2022-06-17 06:52:24.252552
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    avu.data = plaintext
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:52:27.994920
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:52:36.359553
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password='secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'secret')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')


# Generated at 2022-06-17 06:52:42.512025
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:52:48.884139
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')


# Generated at 2022-06-17 06:52:55.915916
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(plaintext)
    assert avu != AnsibleUnicode(plaintext)
    assert avu != AnsibleUnicode(ciphertext)


# Generated at 2022-06-17 06:53:00.413939
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()


# Generated at 2022-06-17 06:53:21.951457
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:53:25.985216
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:53:34.410700
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:53:43.476277
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')
