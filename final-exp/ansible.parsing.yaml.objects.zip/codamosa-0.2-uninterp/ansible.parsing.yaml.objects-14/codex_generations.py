

# Generated at 2022-06-17 06:43:59.782809
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test with a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode("test")
    assert avu.__add__(avu) == "testtest"

    # Test with a string
    assert avu.__add__("test") == "testtest"

    # Test with a unicode
    assert avu.__add__(u"test") == "testtest"

    # Test with a byte string
    assert avu.__add__(b"test") == "testtest"


# Generated at 2022-06-17 06:44:09.160202
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.data == plaintext
    assert avu <= plaintext
    assert not avu <= 'other'
    assert not avu <= AnsibleVaultEncryptedUnicode(ciphertext)
    assert not avu <= AnsibleVaultEncryptedUnicode('other')
    assert not avu <= AnsibleVaultEncryptedUnicode(vault.encrypt('other', secret))


# Generated at 2022-06-17 06:44:18.601211
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None)
    assert avu == 'foo'
    assert avu != 'bar'

    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None)
    assert avu == avu2
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('bar', None, None)
    assert avu != avu2

    # Test with a non-string
    assert avu != 1


# Generated at 2022-06-17 06:44:23.515616
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:44:26.406019
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu <= 'foo'
    assert not avu <= 'bar'


# Generated at 2022-06-17 06:44:34.176683
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu <= 'test'
    assert not avu <= 'test2'

    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('test2')
    assert avu <= avu2
    assert not avu2 <= avu


# Generated at 2022-06-17 06:44:42.234865
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # Test with a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.__lt__(AnsibleVaultEncryptedUnicode('test')) == False
    assert avu.__lt__(AnsibleVaultEncryptedUnicode('test1')) == True
    assert avu.__lt__(AnsibleVaultEncryptedUnicode('test2')) == True

    # Test with a string object
    assert avu.__lt__('test') == False
    assert avu.__lt__('test1') == True
    assert avu.__lt__('test2') == True


# Generated at 2022-06-17 06:44:47.609661
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:44:52.877476
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    assert avu == plaintext
    assert avu != 'other'


# Generated at 2022-06-17 06:45:00.209243
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:45:15.805293
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test1', vault, secret)


# Generated at 2022-06-17 06:45:23.686744
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'secret')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:45:27.668932
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:45:40.155298
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:45:47.866847
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a vault object
    vault = vaultlib.VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu == 'test'
    assert avu != 'test2'

    # Test without a vault object
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'
    assert avu != 'test2'


# Generated at 2022-06-17 06:45:56.813999
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', VaultLib('test2'), secret)


# Generated at 2022-06-17 06:46:08.000720
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    avu = AnsibleVaultEncryptedUnicode("abc")
    assert avu[0:1] == "a"
    assert avu[0:2] == "ab"
    assert avu[0:3] == "abc"
    assert avu[0:4] == "abc"
    assert avu[0:-1] == "ab"
    assert avu[0:-2] == "a"
    assert avu[0:-3] == ""
    assert avu[0:-4] == ""
    assert avu[1:1] == ""
    assert avu[1:2] == "b"
    assert avu[1:3] == "bc"
    assert avu[1:4] == "bc"
    assert avu[1:-1] == "b"

# Generated at 2022-06-17 06:46:17.071992
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a non-encrypted string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu == 'test'

    # Test with an encrypted string

# Generated at 2022-06-17 06:46:25.156200
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu == 'foo'
    assert avu != 'bar'
    assert avu != 'foobar'
    assert avu != 'barfoo'
    assert avu != 'foobarfoo'
    assert avu != 'barfoobar'
    assert avu != 'barbarbar'
    assert avu != 'foofoofoo'
    assert avu != 'barbarfoo'
    assert avu != 'foobarbar'
    assert avu != 'barfoofoo'
    assert avu != 'foofoobar'
    assert avu != 'barbarbar'

# Generated at 2022-06-17 06:46:30.367419
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()



# Generated at 2022-06-17 06:46:47.838894
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test with a slice that is not empty
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu[2:4] == 'cd'

    # Test with a slice that is empty
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu[2:2] == ''

    # Test with a slice that is out of bounds
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu[2:100] == 'cdef'

    # Test with a slice that is out of bounds
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu[100:200] == ''

    # Test with a slice that is out of bounds
    avu = AnsibleVaultEncryptedUnicode('abcdef')

# Generated at 2022-06-17 06:46:56.438958
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.__getslice__(0, 4) == plaintext
    assert avu.__getslice__(0, 3) == plaintext[0:3]
    assert avu.__getslice__(1, 3) == plaintext[1:3]
    assert avu.__getslice__(1, 2) == plaintext[1:2]
    assert avu.__getslice__(1, 1) == plaintext[1:1]

# Generated at 2022-06-17 06:47:03.606516
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:47:13.030106
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1
    from ansible.parsing.vault import VaultAES256CFB8

# Generated at 2022-06-17 06:47:19.966596
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    ciphertext = vault.encrypt('test', secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(vault.encrypt('test2', secret))


# Generated at 2022-06-17 06:47:22.809848
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:47:31.730643
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test for method __ne__ (__ne__ of class AnsibleVaultEncryptedUnicode)
    # This test is needed to ensure that the __ne__ method of
    # AnsibleVaultEncryptedUnicode returns the correct value
    # when the vault is not set.
    #
    # See https://github.com/ansible/ansible/issues/35894
    #
    # The __ne__ method of AnsibleVaultEncryptedUnicode
    # returns True if the vault is not set.
    #
    # The __ne__ method of AnsibleVaultEncryptedUnicode
    # returns False if the vault is set.

    # Create a AnsibleVaultEncryptedUnicode object
    # with a vault that is not set.
    avu = AnsibleVaultEncryptedUnicode("test")


# Generated at 2022-06-17 06:47:35.314900
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Create an AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode('test')
    # Check that it is not equal to the string 'test'
    assert avu != 'test'


# Generated at 2022-06-17 06:47:44.582249
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None)
    assert avu == 'test'

    # Test with an AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None)
    assert avu == avu2

    # Test with a different string
    assert avu != 'test2'

    # Test with a different AnsibleVaultEncryptedUnicode
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext('test2', None, None)
    assert avu != avu3



# Generated at 2022-06-17 06:47:54.791623
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test for method __getslice__ (0-argument case)
    # See if slice indices are handled correctly
    s = AnsibleVaultEncryptedUnicode('0123456789')
    assert s[:] == '0123456789'
    assert s[10:] == ''
    assert s[:0] == ''
    assert s[:-1] == '012345678'
    assert s[1:3] == '12'
    assert s[1:-1] == '12345678'
    assert s[-3:-1] == '78'
    assert s[-1:] == '9'
    assert s[:] == '0123456789'
    assert s[-1000:] == '0123456789'
    assert s[1000:] == ''

# Generated at 2022-06-17 06:48:10.144019
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data.encode()
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data.encode('utf-8')
    assert avu != AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:48:18.377103
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC

    # Create a VaultLib object
    vault_secret = VaultSecret('secret')
    vault_aes256 = VaultAES256(vault_secret)
    vault_aes256cbc = VaultAES256CBC(vault_aes256)
    vault_lib = VaultLib([vault_aes256cbc])

    # Create an AnsibleVaultEncryptedUnicode object
    ciphertext = vault_lib.encrypt('test')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

# Generated at 2022-06-17 06:48:21.667302
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:48:32.054123
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:48:38.915741
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:48:43.519982
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avu == plaintext


# Generated at 2022-06-17 06:48:52.756024
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.representer import AnsibleRepresenter

    # create a vault object
    vault = VaultLib([])
    secret = 'test'
    vault.update_password(secret)

    # create a AnsibleVaultEncryptedUnicode object
    plaintext = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)



# Generated at 2022-06-17 06:49:00.042603
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a non-encrypted string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test with an encrypted string

# Generated at 2022-06-17 06:49:15.899318
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a vault object
    vault = vaultlib.VaultLib(password='test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu == 'test'
    assert avu != 'test2'

    # Test without a vault object

# Generated at 2022-06-17 06:49:26.533084
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    avu.data = plaintext
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:49:45.131924
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test with a negative start
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu[-1:] == 'f'
    assert avu[-2:] == 'ef'
    assert avu[-3:] == 'def'
    assert avu[-4:] == 'cdef'
    assert avu[-5:] == 'bcdef'
    assert avu[-6:] == 'abcdef'
    assert avu[-7:] == 'abcdef'

    # Test with a negative end
    assert avu[:-1] == 'abcde'
    assert avu[:-2] == 'abcd'
    assert avu[:-3] == 'abc'
    assert avu[:-4] == 'ab'
    assert avu[:-5] == 'a'
    assert av

# Generated at 2022-06-17 06:49:49.974841
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()


# Generated at 2022-06-17 06:50:02.447905
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test with a non-negative start and a negative end
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.__getslice__(2, -2) == 'cd'

    # Test with a negative start and a non-negative end
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.__getslice__(-4, 4) == 'abcd'

    # Test with a negative start and a negative end
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.__getslice__(-4, -2) == 'ab'

    # Test with a non-negative start and a non-negative end
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.__getsl

# Generated at 2022-06-17 06:50:10.629478
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu.is_encrypted() == True
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:50:16.827382
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault, 'password')
    assert avu != 'hello'
    assert avu != 'world'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('world', vault, 'password')


# Generated at 2022-06-17 06:50:28.144082
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('secret', vault, 'secret')
    assert avu != 'secret'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('secret', vault, 'secret')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('secret', vault, 'secret2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('secret2', vault, 'secret')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('secret2', vault, 'secret2')

# Generated at 2022-06-17 06:50:37.950220
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(vault.encrypt('test2', secret))


# Generated at 2022-06-17 06:50:41.013747
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    vault.update_password('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu == 'test'
    assert avu != 'test2'


# Generated at 2022-06-17 06:50:45.081980
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode('test').is_encrypted()
    assert not AnsibleVaultEncryptedUnicode('').is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(None).is_encrypted()


# Generated at 2022-06-17 06:50:56.003141
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data
    assert avu != AnsibleUnicode(ciphertext)
    assert avu != AnsibleUnicode(ciphertext).data
    assert avu != AnsibleUnicode(plaintext)
    assert avu != AnsibleUnicode(plaintext).data
    assert av

# Generated at 2022-06-17 06:51:10.682226
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'not_test'


# Generated at 2022-06-17 06:51:18.833834
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode('test')
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEnc

# Generated at 2022-06-17 06:51:28.398469
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(vault.encrypt('test2', secret))


# Generated at 2022-06-17 06:51:33.720709
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True
    plaintext = 'test'
    ciphertext = plaintext
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:51:36.389722
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext


# Generated at 2022-06-17 06:51:42.415774
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:51:48.557194
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:51:54.434564
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    avu.data = plaintext
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:51:57.519225
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:52:05.049073
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:52:26.630046
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)


# Generated at 2022-06-17 06:52:32.467500
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test case 1:
    #   - vault is not initialized
    #   - other is not a AnsibleVaultEncryptedUnicode
    #   - other is not equal to data
    #   - expected result: True
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.__ne__('test1') == True

    # Test case 2:
    #   - vault is not initialized
    #   - other is not a AnsibleVaultEncryptedUnicode
    #   - other is equal to data
    #   - expected result: False
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.__ne__('test') == False

    # Test case 3:
    #   - vault is not initialized
    #   - other is a AnsibleVaultEncrypted

# Generated at 2022-06-17 06:52:40.281526
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')


# Generated at 2022-06-17 06:52:46.257683
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext


# Generated at 2022-06-17 06:52:50.910474
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:52:58.314935
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:53:03.655758
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')


# Generated at 2022-06-17 06:53:14.888599
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(plaintext)
    assert avu != AnsibleUnicode(plaintext)
    assert avu != AnsibleUnicode(ciphertext)
    assert avu != AnsibleUnicode(ciphertext)
    assert avu != AnsibleUnicode(plaintext)
    assert avu != AnsibleUn

# Generated at 2022-06-17 06:53:22.748036
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')
    assert avu == 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'secret')


# Generated at 2022-06-17 06:53:28.446769
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a non-encrypted string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu == 'test'
    assert avu != 'test2'

    # Test with an encrypted string