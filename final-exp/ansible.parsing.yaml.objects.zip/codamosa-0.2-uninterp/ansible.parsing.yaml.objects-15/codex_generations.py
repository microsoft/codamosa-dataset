

# Generated at 2022-06-17 06:43:56.042392
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test when self.vault is None
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test when self.vault is not None
    avu = AnsibleVaultEncryptedUnicode('test')
    avu.vault = 'test'
    assert avu != 'test'



# Generated at 2022-06-17 06:44:04.192929
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    # Test with a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode(b'abc')
    assert 'a' in avu
    assert 'b' in avu
    assert 'c' in avu
    assert 'd' not in avu

    # Test with a string
    assert 'a' in avu
    assert 'b' in avu
    assert 'c' in avu
    assert 'd' not in avu



# Generated at 2022-06-17 06:44:10.087218
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    # Test with AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.replace('t', 'T') == 'TesT'

    # Test with string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.replace('t', 'T') == 'TesT'

    # Test with unicode
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.replace(u't', u'T') == 'TesT'



# Generated at 2022-06-17 06:44:21.206842
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.__radd__('def') == 'defabc'

    # Test with a unicode
    avu = AnsibleVaultEncryptedUnicode(u'abc')
    assert avu.__radd__(u'def') == u'defabc'

    # Test with a AnsibleVaultEncryptedUnicode
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('def')
    assert avu1.__radd__(avu2) == 'defabc'

    # Test with a AnsibleVaultEncryptedUnicode
    avu1 = AnsibleVaultEncryptedUnicode(u'abc')
    av

# Generated at 2022-06-17 06:44:31.758316
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.find('t') == 0
    assert avu.find('e') == 1
    assert avu.find('s') == 2
    assert avu.find('t') == 3
    assert avu.find('t', 1) == 3
    assert avu.find('t', 2) == 3
    assert avu.find('t', 3) == 3
    assert avu.find('t', 4) == -1

# Generated at 2022-06-17 06:44:41.929652
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    avu.replace('o', 'a')
    assert avu.data == 'faa'
    avu.replace('a', 'b')
    assert avu.data == 'fbb'
    avu.replace('b', 'c')
    assert avu.data == 'fcc'
    avu.replace('c', 'd')
    assert avu.data == 'fdd'
    avu.replace('d', 'e')
    assert avu.data == 'fee'
    avu.replace('e', 'f')
    assert avu.data == 'fff'

# Generated at 2022-06-17 06:44:50.429157
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    # Test with a string
    a = AnsibleVaultEncryptedUnicode("abc")
    assert a.find("a") == 0
    assert a.find("b") == 1
    assert a.find("c") == 2
    assert a.find("d") == -1
    assert a.find("a", 1) == -1
    assert a.find("b", 1) == 1
    assert a.find("c", 1) == 2
    assert a.find("d", 1) == -1
    assert a.find("a", 1, 2) == -1
    assert a.find("b", 1, 2) == 1
    assert a.find("c", 1, 2) == -1
    assert a.find("d", 1, 2) == -1

# Generated at 2022-06-17 06:45:02.695554
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'this is a test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.find('this') == 0
    assert avu.find('is') == 2
    assert avu.find('a') == 5
    assert avu.find('test') == 8
    assert avu.find('test', 8) == 8
    assert avu.find('test', 9) == -1
    assert avu.find('test', -1) == 8
    assert avu.find('test', -2) == 8

# Generated at 2022-06-17 06:45:15.338748
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-17 06:45:27.433873
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.__radd__('test') == 'testtest'
    assert avu.__radd__(b'test') == 'testtest'
    assert avu.__radd__(u'test') == 'testtest'
    assert avu.__radd__(AnsibleVaultEncryptedUnicode(ciphertext)) == 'testtest'


# Generated at 2022-06-17 06:45:50.070968
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:45:56.496784
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)


# Generated at 2022-06-17 06:46:07.624357
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, 'test2')


# Generated at 2022-06-17 06:46:16.769696
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = '$ANSIBLE_VAULT;1.1;AES256\n'

# Generated at 2022-06-17 06:46:22.227136
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    ciphertext = vault.encrypt('test', secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(vault.encrypt('test2', secret))


# Generated at 2022-06-17 06:46:30.102320
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.count('t') == 2
    assert avu.count('t', 0, 1) == 1
    assert avu.count('t', 1, 2) == 1
    assert avu.count('t', 2, 3) == 0
    assert avu.count('t', 3, 4) == 0
    assert avu.count('t', 4, 5) == 0
    assert avu.count('t', 5, 6) == 0

# Generated at 2022-06-17 06:46:36.663801
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.count('t') == 2
    assert avu.count('t', 1) == 1
    assert avu.count('t', 1, 2) == 1
    assert avu.count('t', 1, 1) == 0
    assert avu.count('t', 1, 0) == 0
    assert avu.count('t', 1, -1) == 0
    assert avu.count('t', -1, -1) == 0

# Generated at 2022-06-17 06:46:47.057537
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-17 06:46:55.697689
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password2')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password2')

# Generated at 2022-06-17 06:47:07.217488
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test if method __ne__ of class AnsibleVaultEncryptedUnicode returns True
    # when the object is not encrypted
    avu = AnsibleVaultEncryptedUnicode(b'plaintext')
    assert avu.__ne__('plaintext')

    # Test if method __ne__ of class AnsibleVaultEncryptedUnicode returns False
    # when the object is encrypted

# Generated at 2022-06-17 06:47:19.543835
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB

    # Test with aes256-cbc
    vault = VaultLib([VaultSecret('secret'), VaultAES256(), VaultAES256CBC()])
    avu

# Generated at 2022-06-17 06:47:22.521161
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True
    avu.data = plaintext
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:47:31.636945
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.count('t') == 2
    assert avu.count('t', 1) == 1
    assert avu.count('t', 1, 2) == 1
    assert avu.count('t', 1, 1) == 0
    assert avu.count('t', 1, 0) == 0
    assert avu.count('t', 1, -1) == 0
    assert avu.count('t', -1, -1) == 0

# Generated at 2022-06-17 06:47:42.451672
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, 'secret')
    assert avu.find('a') == 0
    assert avu.find('b') == 1
    assert avu.find('c') == 2
    assert avu.find('d') == -1
    assert avu.find('a', 1) == -1
    assert avu.find('a', 0, 1) == 0
    assert avu.find('a', 0, 0) == -1
    assert avu.find('a', -1) == 0
    assert avu.find('a', -2) == 0
    assert avu.find('a', -3) == 0
    assert avu.find

# Generated at 2022-06-17 06:47:46.689822
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode('foo').is_encrypted()


# Generated at 2022-06-17 06:47:54.925199
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.count('t') == 2
    assert avu.count('t', 0, 1) == 1
    assert avu.count('t', 1, 2) == 1
    assert avu.count('t', 2, 3) == 0
    assert avu.count('t', 3, 4) == 0
    assert avu.count('t', 4, 5) == 0
    assert avu.count('t', 5, 6) == 0

# Generated at 2022-06-17 06:48:00.500189
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode("test")
    assert avu != "test"
    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode("test")
    assert avu != avu2


# Generated at 2022-06-17 06:48:08.666841
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.count('t') == 2
    assert avu.count('t', 0, 1) == 1
    assert avu.count('t', 1, 2) == 1
    assert avu.count('t', 2, 3) == 0
    assert avu.count('t', 3, 4) == 0
    assert avu.count('t', 4, 5) == 0
    assert avu.count('t', 5, 6) == 0

# Generated at 2022-06-17 06:48:17.731343
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.find('a') == 0
    assert avu.find('b') == 1
    assert avu.find('c') == 2
    assert avu.find('d') == -1
    assert avu.find('a', 1) == -1
    assert avu.find('a', 0, 1) == 0
    assert avu.find('a', 0, 2) == 0
    assert avu.find('a', 0, 3) == 0
    assert avu.find('a', 0, 4) == 0
    assert avu.find('a', 0, 0) == -1
    assert avu.find('a', 0, -1) == 0
    assert avu.find('a', 0, -2) == 0
    assert av

# Generated at 2022-06-17 06:48:28.046159
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')

# Generated at 2022-06-17 06:48:52.308192
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(plaintext)


# Generated at 2022-06-17 06:48:57.600778
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode("test")
    assert avu != "test"

    # Test with a AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode("test")
    avu2 = AnsibleVaultEncryptedUnicode("test")
    assert avu != avu2

    # Test with a AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode("test")
    avu2 = AnsibleVaultEncryptedUnicode("test2")
    assert avu != avu2


# Generated at 2022-06-17 06:49:12.795613
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import vault
    vault_obj = vault.VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault_obj, 'password')
    assert avu == 'test'
    assert avu != 'test1'
    assert avu != None
    assert avu != 1
    assert avu != True
    assert avu != False
    assert avu != []
    assert avu != {}
    assert avu != ()
    assert avu != set()
    assert avu != frozenset()
    assert avu != object()
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test1', vault_obj, 'password')

# Generated at 2022-06-17 06:49:28.792542
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC

    # Test with a VaultLib object
    vault = VaultLib([VaultAES256(), VaultAES256CBC()])
    secret = VaultSecret('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu.is_encrypted()

    # Test with a VaultAES256 object
    vault = VaultAES256()
    secret = VaultSecret('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)

# Generated at 2022-06-17 06:49:40.997159
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:49:51.298786
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:01.619050
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test for equality with a string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None)
    assert avu == 'test'

    # Test for equality with an AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None)
    assert avu == avu2

    # Test for inequality with a string
    assert avu != 'test2'

    # Test for inequality with an AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test2', None, None)
    assert avu != avu2


# Generated at 2022-06-17 06:50:11.522776
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:14.808497
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:50:19.047407
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:50:33.212832
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    avu.data = plaintext
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:50:40.052285
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC

    secret = VaultSecret('secret')
    vault = VaultLib(VaultAES256CBC(VaultAES256()))

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu == 'test'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test3'
    assert avu != 'test4'
    assert avu != 'test5'
    assert avu != 'test6'
    assert avu != 'test7'

# Generated at 2022-06-17 06:50:43.131457
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password='secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode('foo').is_encrypted()



# Generated at 2022-06-17 06:50:55.016819
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a non-encrypted string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test with an encrypted string

# Generated at 2022-06-17 06:51:03.432755
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')


# Generated at 2022-06-17 06:51:12.540563
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test for method __ne__ (__ne__ of class AnsibleVaultEncryptedUnicode)
    # This test is needed because the __ne__ method is not inherited from
    # the base class.
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu != 'foo'
    assert 'foo' != avu
    assert avu != AnsibleVaultEncryptedUnicode('foo')
    assert AnsibleVaultEncryptedUnicode('foo') != avu
    assert avu != AnsibleVaultEncryptedUnicode('bar')
    assert AnsibleVaultEncryptedUnicode('bar') != avu


# Generated at 2022-06-17 06:51:20.012832
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACSha256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256CBCHMACSha256
    from ansible.parsing.vault import VaultAES256CBCPKCS7
    from ansible.parsing.vault import VaultAES256CBCPKCS7HMACSha256

    # Test VaultAES256
    secret = VaultSecret('password')

# Generated at 2022-06-17 06:51:28.772610
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext + 'x')
    assert avu != 'x' + plaintext
    assert avu != 'x' + AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != 'x' + AnsibleVaultEncryptedUnicode(ciphertext + 'x')
    assert av

# Generated at 2022-06-17 06:51:35.371352
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:51:40.032447
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(plaintext)
    assert avu != AnsibleUnicode(plaintext)
    assert avu != AnsibleUnicode(ciphertext)
    assert avu != AnsibleUnicode(ciphertext)
    assert avu != AnsibleUnicode(plaintext)
    assert avu != AnsibleUn

# Generated at 2022-06-17 06:52:00.136808
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello world', vault, 'password')
    assert avu.is_encrypted()
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:52:05.354067
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode(vault.encrypt('test2', secret))


# Generated at 2022-06-17 06:52:10.012740
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'secret'
    plaintext = 'plaintext'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avu == plaintext


# Generated at 2022-06-17 06:52:21.107487
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:52:25.329097
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)


# Generated at 2022-06-17 06:52:30.165305
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Create a vault object
    vault = VaultLib([])

    # Create a vault secret
    secret = VaultSecret('secret')

    # Create a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)

    # Check if the object is encrypted
    assert avu.is_encrypted()

    # Decrypt the object
    avu.data

    # Check if the object is encrypted
    assert not avu.is_encrypted()



# Generated at 2022-06-17 06:52:39.914832
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:52:46.037910
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True
    avu.data = plaintext
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:52:54.652442
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1
    from ansible.parsing.vault import VaultAES256CFB8

# Generated at 2022-06-17 06:52:59.177335
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu == 'test'
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, 'password')
    assert avu == AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')


# Generated at 2022-06-17 06:53:23.181171
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True
    assert avu.data == plaintext
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:53:27.182006
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True
    assert avu.data == plaintext
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:53:35.646463
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    avu.data = plaintext
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:53:46.280779
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode