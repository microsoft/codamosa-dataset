

# Generated at 2022-06-17 06:43:57.271548
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'test')
    assert avu + 'bar' == 'foobar'
    assert 'bar' + avu == 'barfoo'
    assert avu + avu == 'foofoo'


# Generated at 2022-06-17 06:44:05.793521
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.__lt__(plaintext) == False
    assert avu.__lt__(ciphertext) == False
    assert avu.__lt__(avu) == False


# Generated at 2022-06-17 06:44:15.203974
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu + 'test' == 'testtest'
    assert 'test' + avu == 'testtest'
    assert avu + avu == 'testtest'


# Generated at 2022-06-17 06:44:21.129450
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    # Test a non-encrypted string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()
    # Test an encrypted string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu.is_encrypted()


# Generated at 2022-06-17 06:44:30.393521
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, 'secret')
    assert avu < 'abd'
    assert not avu < 'abc'
    assert not avu < 'abb'
    assert not avu < 'abcd'
    assert not avu < 'ab'
    assert not avu < 'a'
    assert not avu < 'b'
    assert not avu < 'c'
    assert not avu < 'd'
    assert not avu < 'e'
    assert not avu < 'abce'
    assert not avu < 'abcc'
    assert not avu < 'abbc'
    assert not avu < 'abdc'

# Generated at 2022-06-17 06:44:35.370545
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.count('t') == 2
    assert avu.count('t', 1) == 1
    assert avu.count('t', 1, 2) == 1
    assert avu.count('t', 1, 1) == 0
    assert avu.count('t', 1, 0) == 0
    assert avu.count('t', -1, -1) == 0
    assert avu.count('t', -1, -2) == 1

# Generated at 2022-06-17 06:44:40.742509
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    plaintext = 'hello world'
    ciphertext = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:44:49.113633
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256

    secret = VaultSecret('secret')
    vault = VaultLib([VaultAES256()], secret)

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, secret)
    assert avu.count('a') == 1
    assert avu.count('b') == 1
    assert avu.count('c') == 1
    assert avu.count('d') == 0
    assert avu.count('ab') == 0
    assert avu.count('bc') == 0
    assert avu.count('abc') == 0
    assert avu.count('bca') == 0
    assert avu

# Generated at 2022-06-17 06:45:01.292779
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.count('t') == 2
    assert avu.count('t', 1, 2) == 1
    assert avu.count('t', 1, 1) == 0
    assert avu.count('t', 1, 0) == 0
    assert avu.count('t', -1, -1) == 0
    assert avu.count('t', -1, -2) == 1
    assert avu.count('t', -1, -3) == 2
    assert av

# Generated at 2022-06-17 06:45:13.270197
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.__add__(plaintext) == plaintext + plaintext
    assert avu.__add__(avu) == plaintext + plaintext
    assert avu.__radd__(plaintext) == plaintext + plaintext
    assert avu.__radd__(avu) == plaintext + plaintext


# Generated at 2022-06-17 06:45:40.110307
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.data == plaintext
    assert avu + 'test' == plaintext + 'test'
    assert 'test' + avu == 'test' + plaintext
    assert avu + avu == plaintext + plaintext
    assert avu + AnsibleVaultEncryptedUnicode(ciphertext) == plaintext + plaintext
    assert AnsibleVaultEncryptedUnicode(ciphertext) + avu == plaintext + plaintext


# Generated at 2022-06-17 06:45:52.298855
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:46:03.194885
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    vault.update({'password': 'test'})
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu1 >= avu2
    assert avu1 >= 'test'
    assert avu1 >= u'test'
    assert avu1 >= b'test'
    assert not avu1 >= 'test1'
    assert not avu1 >= u'test1'
    assert not avu1 >= b'test1'


# Generated at 2022-06-17 06:46:13.691570
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with equal strings
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=None, secret=None)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=None, secret=None)
    assert avu1 == avu2

    # Test with different strings
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=None, secret=None)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault=None, secret=None)
    assert avu1 != avu2

    # Test with different types
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=None, secret=None)
    assert av

# Generated at 2022-06-17 06:46:21.571316
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test with AnsibleVaultEncryptedUnicode
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('def')
    assert avu1 + avu2 == 'abcdef'

    # Test with text_type
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + 'def' == 'abcdef'

    # Test with bytes
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + b'def' == 'abcdef'

    # Test with int
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + 1 == 'abc1'



# Generated at 2022-06-17 06:46:27.171513
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu + avu == plaintext + plaintext
    assert avu + plaintext == plaintext + plaintext
    assert plaintext + avu == plaintext + plaintext


# Generated at 2022-06-17 06:46:31.621381
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert not avu != 'foo'
    assert not avu != 'bar'


# Generated at 2022-06-17 06:46:36.065674
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, 'password')
    assert avu >= 'abc'
    assert avu >= AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, 'password')
    assert not avu >= 'abcd'
    assert not avu >= AnsibleVaultEncryptedUnicode.from_plaintext('abcd', vault, 'password')


# Generated at 2022-06-17 06:46:45.229269
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None)
    assert avu == 'test'
    assert 'test' == avu
    assert avu != 'test2'
    assert 'test2' != avu

    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None)
    assert avu == avu2
    assert avu2 == avu
    assert avu != avu2
    assert avu2 != avu


# Generated at 2022-06-17 06:46:50.319117
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu.is_encrypted() == True
    avu.vault = vault
    assert avu.is_encrypted() == True
    avu.data = plaintext
    assert avu.is_encrypted() == False
    avu.data = ciphertext
    assert avu.is_encrypted() == True


# Generated at 2022-06-17 06:47:07.974378
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault = VaultLib([])
    secret = VaultSecret('secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, secret)
    assert avu + 'bar' == 'foobar'
    assert 'bar' + avu == 'barfoo'
    assert avu + AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, secret) == 'foobar'
    assert AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, secret) + avu == 'barfoo'


# Generated at 2022-06-17 06:47:16.254276
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')
    avu3 = avu1 + avu2
    assert avu3.data == 'foobar'
    assert avu3.is_encrypted()
    assert avu3.vault == vault


# Generated at 2022-06-17 06:47:26.709411
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:47:33.492411
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    import ansible.parsing.yaml.objects as objects

    # Test case 1:
    #   - object 1: AnsibleVaultEncryptedUnicode object
    #   - object 2: AnsibleVaultEncryptedUnicode object
    #   - expected result: True
    #   - reason: object 1 and object 2 are the same object
    avu1 = objects.AnsibleVaultEncryptedUnicode.from_plaintext('test', vault.VaultLib('test'), 'test')
    avu2 = avu1
    assert avu1 == avu2

    # Test case 2:
    #   - object 1: AnsibleVaultEncryptedUnicode object
    #   - object 2: AnsibleVaultEncryptedUnicode object
    #

# Generated at 2022-06-17 06:47:39.905742
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'not_test'


# Generated at 2022-06-17 06:47:46.778646
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.data == plaintext
    assert avu + plaintext == plaintext + plaintext
    assert plaintext + avu == plaintext + plaintext
    assert avu + avu == plaintext + plaintext


# Generated at 2022-06-17 06:47:50.956288
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu == 'test'
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, 'test')


# Generated at 2022-06-17 06:48:00.340941
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')


# Generated at 2022-06-17 06:48:04.421596
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:48:14.584338
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACEnv
    from ansible.parsing.vault import VaultAES256Env
    from ansible.parsing.vault import VaultAES256File
    from ansible.parsing.vault import VaultAES256HMACFile
    from ansible.parsing.vault import VaultAES256FileEnv
    from ansible.parsing.vault import VaultAES256HMACFileEnv
    from ansible.parsing.vault import Vault

# Generated at 2022-06-17 06:48:36.250795
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:48:50.267829
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACEnv
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256CBCHMAC
    from ansible.parsing.vault import VaultAES256CBCHMACEnv

    # Test for VaultAES256
    secret = VaultSecret('test')
    vault = VaultAES256('test', secret)

# Generated at 2022-06-17 06:48:58.829063
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu == 'foo'

    # Test with a AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu2 = AnsibleVaultEncryptedUnicode('foo')
    assert avu == avu2

    # Test with a AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu2 = AnsibleVaultEncryptedUnicode('bar')
    assert avu != avu2

    # Test with a AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('foo')

# Generated at 2022-06-17 06:49:13.393509
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACEnv
    from ansible.parsing.vault import VaultAES256Env
    from ansible.parsing.vault import VaultAES256File
    from ansible.parsing.vault import VaultAES256HMACFile
    from ansible.parsing.vault import VaultAES256FileEnv
    from ansible.parsing.vault import VaultAES256HMACFileEnv

    # Test for method __ne__ of class AnsibleV

# Generated at 2022-06-17 06:49:26.079830
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.data == plaintext
    assert avu + plaintext == plaintext + plaintext
    assert avu + avu == plaintext + plaintext


# Generated at 2022-06-17 06:49:33.352468
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu.is_encrypted() == True
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:49:39.156311
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:49:44.296754
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:49:52.328607
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:50:01.104870
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test with a AnsibleVaultEncryptedUnicode object
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('def')
    assert avu1 + avu2 == 'abcdef'

    # Test with a string object
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + 'def' == 'abcdef'

    # Test with a bytes object
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + b'def' == 'abcdef'


# Generated at 2022-06-17 06:50:26.254348
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:32.590816
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:50:37.507864
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(vault.encrypt('test2', secret))


# Generated at 2022-06-17 06:50:41.518393
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    seq = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu != 'test'


# Generated at 2022-06-17 06:50:52.791879
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', None, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')


# Generated at 2022-06-17 06:51:01.833462
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True
    assert avu.data == plaintext
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:51:09.205100
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu == 'test'
    assert avu != 'test2'

    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('test')
    assert avu == avu2
    avu2 = AnsibleVaultEncryptedUnicode('test2')
    assert avu != avu2


# Generated at 2022-06-17 06:51:12.346946
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext


# Generated at 2022-06-17 06:51:17.733614
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with different types of arguments
    assert AnsibleVaultEncryptedUnicode('test') == 'test'
    assert AnsibleVaultEncryptedUnicode('test') == AnsibleVaultEncryptedUnicode('test')
    assert AnsibleVaultEncryptedUnicode('test') != 'test2'
    assert AnsibleVaultEncryptedUnicode('test') != AnsibleVaultEncryptedUnicode('test2')
    assert AnsibleVaultEncryptedUnicode('test') != None
    assert AnsibleVaultEncryptedUnicode('test') != 1
    assert AnsibleVaultEncryptedUnicode('test') != 1.0
    assert AnsibleVaultEncryptedUnicode('test') != [1, 2, 3]

# Generated at 2022-06-17 06:51:26.796907
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test for equality with a string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello', None, None)
    assert avu == 'hello'

    # Test for equality with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('hello', None, None)
    assert avu == avu2

    # Test for inequality with a string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello', None, None)
    assert avu != 'world'

    # Test for inequality with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('world', None, None)
    assert avu != avu2


# Generated at 2022-06-17 06:51:49.206450
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a vault object
    vault = vaultlib.VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu == 'test'
    assert avu != 'test2'

    # Test without a vault object
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'
    assert avu != 'test2'



# Generated at 2022-06-17 06:51:55.116867
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == 'test'
    assert avu != 'test2'


# Generated at 2022-06-17 06:51:58.271310
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:52:01.665457
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')
    assert avu == 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'secret')
    assert avu == AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')


# Generated at 2022-06-17 06:52:07.888822
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:52:14.488990
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:52:27.669852
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACSha256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256CBCHMAC
    from ansible.parsing.vault import VaultAES256CBCHMACSha256

    # Test with VaultLib
    vault = VaultLib([VaultSecret('secret'), VaultAES256()])

# Generated at 2022-06-17 06:52:32.683794
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')
    assert avu == 'foo'
    assert avu != 'bar'


# Generated at 2022-06-17 06:52:41.954447
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu == 'test'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test2'

# Generated at 2022-06-17 06:52:48.632670
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(plaintext)


# Generated at 2022-06-17 06:53:10.787778
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:53:16.720350
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    # Test that is_encrypted returns True when the object is encrypted
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu.is_encrypted()
    # Test that is_encrypted returns False when the object is not encrypted
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:53:23.396521
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    avu.data = plaintext
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:53:28.454827
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:53:34.909257
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    seq = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu != 'test'
