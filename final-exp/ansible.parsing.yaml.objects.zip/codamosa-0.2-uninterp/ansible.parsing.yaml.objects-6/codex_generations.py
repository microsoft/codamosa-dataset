

# Generated at 2022-06-17 06:44:00.030968
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    avu.data = plaintext
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:44:05.835833
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:44:15.202320
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.data == plaintext
    assert avu <= plaintext
    assert avu <= avu
    assert avu <= 'test'
    assert not avu <= 'test2'


# Generated at 2022-06-17 06:44:22.013667
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault, 'password')
    assert avu == 'hello'
    assert avu != 'world'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('world', vault, 'password')
    assert avu == AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault, 'password')


# Generated at 2022-06-17 06:44:27.077189
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, 'password')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('def', vault, 'password')
    assert avu1 > avu2


# Generated at 2022-06-17 06:44:38.955981
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:44:44.357604
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True
    assert avu.data == 'test'
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:44:53.774976
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:45:04.966332
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode('test')
    assert avu != AnsibleVaultEncryptedUnicode('test', vault=vault)
    assert avu != AnsibleVaultEncryptedUnicode('test', vault=vault, secret=secret)

# Generated at 2022-06-17 06:45:18.168609
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACSha256
    from ansible.parsing.vault import VaultAES256CBCHMACSha256
    from ansible.parsing.vault import VaultAES256CBCHMACSha256Tag
    from ansible.parsing.vault import VaultAES256CBCHMACSha256TagV2

    # Test that the is_encrypted method of AnsibleVaultEncryptedUnicode
    # returns True for encrypted strings and False for unencrypted strings.

    # Test

# Generated at 2022-06-17 06:45:38.191466
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:45:47.916008
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test with AnsibleVaultEncryptedUnicode
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('def')
    assert avu1 + avu2 == 'abcdef'

    # Test with unicode
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + 'def' == 'abcdef'

    # Test with str
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 + 'def' == 'abcdef'


# Generated at 2022-06-17 06:45:55.367623
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    import ansible.parsing.yaml.objects as objects
    import ansible.parsing.yaml.loader as loader

    # Create a vault object
    vault_obj = vault.VaultLib('test')
    vault_obj.update_password('test')

    # Create a AnsibleVaultEncryptedUnicode object
    avu = objects.AnsibleVaultEncryptedUnicode.from_plaintext('test', vault_obj, 'test')
    avu.vault = vault_obj

    # Create a AnsibleVaultEncryptedUnicode object
    avu2 = objects.AnsibleVaultEncryptedUnicode.from_plaintext('test', vault_obj, 'test')
    avu2.vault = vault_obj

    #

# Generated at 2022-06-17 06:46:05.547586
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import os
    import tempfile

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Create a VaultSecret object
    secret = VaultSecret(temp_path)

    # Create a VaultLib object
    vault = VaultLib(secret)

    # Create an AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)

    # Test is_encrypted method
    assert avu.is_encrypted()

    # Cleanup
    os.remove(temp_path)



# Generated at 2022-06-17 06:46:13.606138
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.data == plaintext
    assert avu + avu == plaintext + plaintext
    assert avu + plaintext == plaintext + plaintext
    assert plaintext + avu == plaintext + plaintext


# Generated at 2022-06-17 06:46:26.730848
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:46:34.341709
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('mysecret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('mysecret', vault, 'mysecret')
    assert avu == 'mysecret'
    assert avu != 'mysecret2'
    assert avu != None
    assert avu != 1
    assert avu != 1.0
    assert avu != True
    assert avu != False
    assert avu != []
    assert avu != {}
    assert avu != ()
    assert avu != set()
    assert avu != frozenset()
    assert avu != bytearray()
    assert avu != memoryview()


# Generated at 2022-06-17 06:46:40.797608
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()


# Generated at 2022-06-17 06:46:45.084440
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:46:48.470822
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:47:16.466541
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Create a vault object
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')

    # Create an AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')

    # Test __eq__
    assert avu == 'test'
    assert avu == AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, 'password')


# Generated at 2022-06-17 06:47:26.545063
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello', None, None)
    assert avu == 'hello'
    assert avu != 'world'

    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('hello', None, None)
    assert avu == avu2
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('world', None, None)
    assert avu != avu2

    # Test with a non-string
    assert avu != 1
    assert avu != 1.0
    assert avu != True
    assert avu != False
    assert avu != None


# Generated at 2022-06-17 06:47:38.423666
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string that is not encrypted
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.__ne__('test') is True

    # Test with a string that is encrypted

# Generated at 2022-06-17 06:47:45.911054
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test1'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode('test')


# Generated at 2022-06-17 06:47:54.872176
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACSha256
    from ansible.parsing.vault import VaultAES256CBCHMACSha256
    from ansible.parsing.vault import VaultAES256CBCHMACSha256Tag
    from ansible.parsing.vault import VaultAES256CBCHMACSha256TagV2
    from ansible.parsing.vault import VaultAES256CBCHMACSha256TagV2B64

# Generated at 2022-06-17 06:48:05.582803
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC

    # Create a vault object
    vault_password = VaultPassword(VaultSecret(VaultAES256CBC(VaultAES256())))
    vault = VaultLib(vault_password)

    # Create a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')

    # Test __ne__
    assert avu != 'foo'
    assert avu != 'bar'
    assert avu != Ans

# Generated at 2022-06-17 06:48:13.729754
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.VaultLib.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault.VaultLib(secret)
    assert avu == plaintext
    assert avu != 'not plaintext'


# Generated at 2022-06-17 06:48:27.088034
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1
    from ansible.parsing.vault import VaultAES256CFB8

# Generated at 2022-06-17 06:48:35.459633
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Check that the method returns True when the object is not encrypted
    avu = AnsibleVaultEncryptedUnicode('plaintext')
    assert avu.__ne__('plaintext')

    # Check that the method returns False when the object is encrypted
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    assert not avu.__ne__('plaintext')


# Generated at 2022-06-17 06:48:40.523470
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:48:57.490751
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode('test')
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEnc

# Generated at 2022-06-17 06:49:12.660578
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode('test')
    assert avu != AnsibleUnicode('test')
    assert avu != 'test'
    assert avu != AnsibleUnicode(ciphertext)
    assert avu != AnsibleUnicode('test')
    assert avu != AnsibleUnicode(ciphertext)
   

# Generated at 2022-06-17 06:49:23.195769
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:49:30.587466
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True
    assert avu.data == plaintext
    assert avu.is_encrypted() == False


# Generated at 2022-06-17 06:49:42.584281
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:49:52.111710
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256CFB1
    from ansible.parsing.vault import VaultAES256CFB8

# Generated at 2022-06-17 06:50:02.008155
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:07.931476
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu == 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')


# Generated at 2022-06-17 06:50:18.894051
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1
    from ansible.parsing.vault import VaultAES256CFB8

# Generated at 2022-06-17 06:50:25.591848
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True



# Generated at 2022-06-17 06:50:37.911052
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test1'
    assert avu != AnsibleVaultEncryptedUnicode('test1')
    assert avu != AnsibleVaultEncryptedUnicode(vault.encrypt('test1', secret))


# Generated at 2022-06-17 06:50:44.486406
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-17 06:50:55.456013
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    import ansible.parsing.yaml.objects as objects
    import ansible.parsing.yaml.loader as loader
    import ansible.parsing.yaml.dumper as dumper

    def test_eq(a, b, expected):
        assert (a == b) == expected
        assert (b == a) == expected

    def test_ne(a, b, expected):
        assert (a != b) == expected
        assert (b != a) == expected

    def test_eq_ne(a, b, expected):
        test_eq(a, b, expected)
        test_ne(a, b, not expected)


# Generated at 2022-06-17 06:51:00.517734
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu == 'test'
    assert avu != 'test1'


# Generated at 2022-06-17 06:51:11.817637
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:51:21.912350
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:51:28.725634
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('ansible')
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'other'


# Generated at 2022-06-17 06:51:35.786639
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'

    # Test with a AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('test')
    avu2 = AnsibleVaultEncryptedUnicode('test')
    assert avu != avu2


# Generated at 2022-06-17 06:51:41.953313
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode('test2')
    assert avu != 'test3'
    assert avu != AnsibleVaultEncryptedUnicode('test3')


# Generated at 2022-06-17 06:51:49.298441
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a vault object
    vault = vaultlib.VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu == 'test'
    assert avu != 'test2'

    # Test without a vault object
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'
    assert avu != 'test2'


# Generated at 2022-06-17 06:52:02.284285
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')


# Generated at 2022-06-17 06:52:11.913515
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n63316662323963346232623231323463323232323232323232323232323232323\n')
    assert avu != '$ANSIBLE_VAULT;1.1;AES256\n63316662323963346232623231323463323232323232323232323232323232323\n'

    # Test with another AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:52:22.516640
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:52:27.527908
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:52:38.635442
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES128
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-17 06:52:47.720524
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:52:55.416749
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    vault.update({'secret': 'test'})
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'secret')
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'secret')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'secret')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, 'secret')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, 'secret2')


# Generated at 2022-06-17 06:52:59.611146
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:53:12.316859
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:53:22.390540
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:53:43.059926
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(vault.encrypt('test2', secret))
