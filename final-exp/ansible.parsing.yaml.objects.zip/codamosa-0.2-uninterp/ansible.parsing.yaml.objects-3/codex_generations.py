

# Generated at 2022-06-17 06:44:04.286067
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    plaintext = 'hello world'
    ciphertext = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu.is_encrypted()
    avu.vault = vault
    assert not avu.is_encrypted()
    avu.data = 'hello world'
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:44:16.754607
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    import ansible.parsing.vaultlib as vaultlib
    import ansible.parsing.yaml.objects as objects

    # Create a vault object
    vault_password = 'test'
    vault_obj = vault.VaultLib(vault_password)

    # Create an AnsibleVaultEncryptedUnicode object
    plaintext = 'test'
    ciphertext = vault_obj.encrypt(plaintext, vault_password)
    avu = objects.AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault_obj

    # Test __eq__
    assert avu == 'test'
    assert avu != 'test2'
    assert avu != 'TEST'

# Generated at 2022-06-17 06:44:28.659113
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu[0:3] == 'abc'
    assert avu[3:6] == 'def'
    assert avu[0:6] == 'abcdef'
    assert avu[0:7] == 'abcdef'
    assert avu[0:0] == ''
    assert avu[0:1] == 'a'
    assert avu[0:2] == 'ab'
    assert avu[0:3] == 'abc'
    assert avu[0:4] == 'abcd'
    assert avu[0:5] == 'abcde'
    assert avu[0:6] == 'abcdef'
    assert avu[0:7] == 'abcdef'
    assert avu[0:8]

# Generated at 2022-06-17 06:44:36.328398
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'not_test'


# Generated at 2022-06-17 06:44:44.809942
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test for __getslice__
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu[1:3] == 'bc'
    assert avu[1:1] == ''
    assert avu[1:0] == ''
    assert avu[1:-1] == 'bcde'
    assert avu[1:-2] == 'bcd'
    assert avu[1:-3] == 'bc'
    assert avu[1:-4] == 'b'
    assert avu[1:-5] == ''
    assert avu[1:-6] == ''
    assert avu[-1:3] == ''
    assert avu[-1:1] == ''
    assert avu[-1:0] == ''
    assert avu[-1:-1] == ''

# Generated at 2022-06-17 06:44:54.063098
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:45:05.191459
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:45:18.328644
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:45:29.128715
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACSha256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256CBCHMACSha256
    from ansible.parsing.vault import VaultAES256CBCPKCS7
    from ansible.parsing.vault import VaultAES256CBCPKCS7HMACSha256

    # Test with VaultAES256
    vault = VaultLib([VaultAES256()])


# Generated at 2022-06-17 06:45:37.286210
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test1'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)


# Generated at 2022-06-17 06:45:56.223255
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    # Test with AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('test')
    assert 't' in avu
    assert 'e' in avu
    assert 's' in avu
    assert 'T' not in avu
    assert 'E' not in avu
    assert 'S' not in avu

    # Test with string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert 't' in avu
    assert 'e' in avu
    assert 's' in avu
    assert 'T' not in avu
    assert 'E' not in avu
    assert 'S' not in avu

    # Test with bytes
    avu = AnsibleVaultEncryptedUnicode(b'test')

# Generated at 2022-06-17 06:46:06.017726
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test with a negative start and end
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.__getslice__(-2, -1) == 'e'

    # Test with a negative start and positive end
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.__getslice__(-2, 4) == 'ef'

    # Test with a positive start and negative end
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.__getslice__(2, -1) == 'cd'

    # Test with a positive start and end
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.__getslice__(2, 4) == 'cd'

    # Test

# Generated at 2022-06-17 06:46:16.780797
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test with a negative start
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.__getslice__(-1, 3) == 'abc'

    # Test with a negative end
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.__getslice__(1, -1) == 'bcde'

    # Test with a negative start and end
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.__getslice__(-1, -1) == 'abcde'

    # Test with a negative start and end
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.__getslice__(-1, -2) == 'abcd'

    # Test with a

# Generated at 2022-06-17 06:46:24.885071
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test with a slice of the whole string
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu[:] == 'abc'

    # Test with a slice of the whole string
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu[0:] == 'abc'

    # Test with a slice of the whole string
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu[0:3] == 'abc'

    # Test with a slice of the whole string
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu[0:4] == 'abc'

    # Test with a slice of the whole string
    avu = AnsibleVaultEncryptedUnicode('abc')

# Generated at 2022-06-17 06:46:34.438842
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu[0:1] == 'a'
    assert avu[0:2] == 'ab'
    assert avu[0:3] == 'abc'
    assert avu[0:4] == 'abc'
    assert avu[0:5] == 'abc'
    assert avu[0:-1] == 'ab'
    assert avu[0:-2] == 'a'
    assert avu[0:-3] == ''
    assert avu[0:-4] == ''
    assert avu[0:-5] == ''
    assert avu[1:2] == 'b'
    assert avu[1:3] == 'bc'
    assert avu[1:4] == 'bc'

# Generated at 2022-06-17 06:46:40.902816
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True


# Generated at 2022-06-17 06:46:43.482479
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'test2'


# Generated at 2022-06-17 06:46:48.492356
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.VaultLib(password=secret).encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault.VaultLib(password=secret)
    assert avu == plaintext
    assert avu != 'other'


# Generated at 2022-06-17 06:46:53.199896
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu >= 'test'
    assert not avu >= 'test2'

    # Test with an AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('test2')
    assert avu >= avu2
    assert not avu2 >= avu


# Generated at 2022-06-17 06:47:05.162082
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:47:20.910768
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    ciphertext = vault.encrypt('test')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode('test').is_encrypted()


# Generated at 2022-06-17 06:47:28.342033
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'this is a test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.rfind('is') == 5
    assert avu.rfind('is', 0, 4) == -1
    assert avu.rfind('is', 5, 6) == 5
    assert avu.rfind('is', 6, 10) == -1
    assert avu.rfind('is', 1, 4) == 1
    assert avu.rfind('is', 1, 2) == -1

# Generated at 2022-06-17 06:47:34.616132
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:47:41.318977
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:47:49.940094
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.__ne__(plaintext)
    assert avu.__ne__(ciphertext)
    assert avu.__ne__(avu)
    assert avu.__ne__(None)
    assert avu.__ne__(1)
    assert avu.__ne__(1.0)
    assert avu.__ne__(1.0+1j)
    assert avu.__ne__([])
    assert avu.__ne__({})


# Generated at 2022-06-17 06:48:02.717787
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256OPENPGP

# Generated at 2022-06-17 06:48:07.560833
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    # Test with a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert 'a' in avu
    assert 'b' in avu
    assert 'c' in avu
    assert 'd' not in avu

    # Test with a string
    assert 'a' in avu
    assert 'b' in avu
    assert 'c' in avu
    assert 'd' not in avu



# Generated at 2022-06-17 06:48:11.884945
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256CFB8
    from ansible.parsing.vault import VaultAES256CTS


# Generated at 2022-06-17 06:48:26.554669
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:48:35.512448
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test case 1:
    #   - AnsibleVaultEncryptedUnicode object is not encrypted
    #   - other is a string
    #   - other is equal to the decrypted AnsibleVaultEncryptedUnicode object
    #   - expected result: True
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.__eq__('test')

    # Test case 2:
    #   - AnsibleVaultEncryptedUnicode object is not encrypted
    #   - other is a string
    #   - other is not equal to the decrypted AnsibleVaultEncryptedUnicode object
    #   - expected result: False
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.__eq__('test2')

    # Test case 3:
   

# Generated at 2022-06-17 06:48:49.374810
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu == 'foo'
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'password')


# Generated at 2022-06-17 06:48:56.253261
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:49:00.732399
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:49:04.305843
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True
    assert avu.data == plaintext


# Generated at 2022-06-17 06:49:15.359672
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(plaintext).is_encrypted()


# Generated at 2022-06-17 06:49:24.817761
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('secret', vault, 'secret')
    assert avu != 'secret'
    assert avu != 'notsecret'
    assert not avu != 'secret'
    assert not avu != 'notsecret'


# Generated at 2022-06-17 06:49:28.976060
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode('test2')


# Generated at 2022-06-17 06:49:35.204456
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:49:41.982430
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = 'secret'
    plaintext = 'plaintext'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'wrong'


# Generated at 2022-06-17 06:49:47.732283
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu != 'foo'
    assert avu != 'bar'

    # Test with a AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('foo')
    assert avu != avu2
    assert avu2 != avu
    avu2 = AnsibleVaultEncryptedUnicode('bar')
    assert avu != avu2
    assert avu2 != avu


# Generated at 2022-06-17 06:50:10.536395
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:50:18.919437
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:22.919188
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode('test').is_encrypted()


# Generated at 2022-06-17 06:50:30.301585
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX
    from ansible.parsing.vault import VaultAES256SIV
   

# Generated at 2022-06-17 06:50:34.802821
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    seq = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu == 'test'
    assert avu != 'test1'


# Generated at 2022-06-17 06:50:40.315913
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu != 'test'
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)


# Generated at 2022-06-17 06:50:46.641830
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:50:52.934934
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:51:05.892230
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu == 'test'

    # Test with a AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('test')
    assert avu == avu2

    # Test with a AnsibleVaultEncryptedUnicode that has a different value
    avu2 = AnsibleVaultEncryptedUnicode('test2')
    assert avu != avu2

    # Test with a AnsibleVaultEncryptedUnicode that has a different value
    avu2 = AnsibleVaultEncryptedUnicode('test2')
    assert avu != avu2

    # Test with a AnsibleVaultEncryptedUnicode that has a different value
    avu2 = AnsibleV

# Generated at 2022-06-17 06:51:15.995462
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu.__ne__('foo')
    assert avu.__ne__('bar')

    # Test with a AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu2 = AnsibleVaultEncryptedUnicode('foo')
    assert avu.__ne__(avu2)
    avu2 = AnsibleVaultEncryptedUnicode('bar')
    assert avu.__ne__(avu2)

    # Test with a AnsibleVaultEncryptedUnicode and a string
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu.__ne__('foo')
    assert avu.__ne__

# Generated at 2022-06-17 06:51:37.347438
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != plaintext
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data
    assert avu != AnsibleUnicode(ciphertext)
    assert avu != AnsibleUnicode(ciphertext).data
    assert avu != AnsibleUnicode(plaintext)
    assert avu != AnsibleUnicode(plaintext).data
    assert avu

# Generated at 2022-06-17 06:51:45.620516
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1
    from ansible.parsing.vault import VaultAES256CFB8

# Generated at 2022-06-17 06:51:55.028045
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')
    assert avu == 'test'
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, 'password')


# Generated at 2022-06-17 06:51:59.516744
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=None, secret=None)
    assert avu == 'foo'

    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=None, secret=None)
    assert avu == avu2

    # Test with a different AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault=None, secret=None)
    assert avu != avu2



# Generated at 2022-06-17 06:52:06.982160
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test for method __eq__ (__eq__) of class AnsibleVaultEncryptedUnicode
    # test for equality
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None)
    assert avu == 'foo'
    assert avu == avu
    assert avu == AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None)

    # test for inequality
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', None, None)


# Generated at 2022-06-17 06:52:13.168100
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    ciphertext = vault.encrypt('test', secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(vault.encrypt('test2', secret))
    assert avu != AnsibleVaultEncryptedUnicode(vault.encrypt('test', 'test2'))


# Generated at 2022-06-17 06:52:23.130659
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    avu.data = plaintext
    assert not avu.is_encrypted()


# Generated at 2022-06-17 06:52:26.972220
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'
    assert avu != 'test2'

    # Test with another AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode('test')
    assert avu != avu2
    avu2 = AnsibleVaultEncryptedUnicode('test2')
    assert avu != avu2


# Generated at 2022-06-17 06:52:31.616678
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    import ansible.parsing.vaultlib as vaultlib
    import ansible.parsing.yaml.objects as objects

    # Create a vault object
    vault_password = 'test'
    vault_obj = vault.VaultLib(vault_password)

    # Create a AnsibleVaultEncryptedUnicode object
    plaintext = 'test'
    ciphertext = vault_obj.encrypt(plaintext, vault_password)
    avu = objects.AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault_obj

    # Test __eq__
    assert avu == plaintext
    assert avu != 'test2'
    assert avu != 'test2'
    assert avu != 'test2'


# Generated at 2022-06-17 06:52:36.975254
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext


# Generated at 2022-06-17 06:53:05.363004
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')

# Generated at 2022-06-17 06:53:10.739606
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-17 06:53:18.108651
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('ansible')
    secret = 'ansible'
    plaintext = 'hello world'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext
    assert avu != 'hello'
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext).data.encode()


# Generated at 2022-06-17 06:53:23.994122
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a vault object
    vault = vaultlib.VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu == 'test'
    assert avu != 'test2'

    # Test without a vault object
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test'
    assert avu != 'test2'


# Generated at 2022-06-17 06:53:27.447713
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a non-AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu != 'bar'

    # Test with an AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu2 = AnsibleVaultEncryptedUnicode('bar')
    assert avu != avu2


# Generated at 2022-06-17 06:53:33.986013
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    seq = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu != 'test'


# Generated at 2022-06-17 06:53:44.619500
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu != 'test'
    assert avu != AnsibleVaultEncryptedUnicode('test')
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != AnsibleVaultEnc