

# Generated at 2022-06-11 09:26:02.805720
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    data = u'hello'
    # test with len(data) >= end
    end = 1
    start = 0
    result = AnsibleVaultEncryptedUnicode(data)[start:end]
    assert result == data[start:end]

    # test with len(data) < end
    end = 10
    start = 0
    result = AnsibleVaultEncryptedUnicode(data)[start:end]
    assert result == data[start:end]

    # test with len(data) < start
    start = 10
    end = 1
    result = AnsibleVaultEncryptedUnicode(data)[start:end]
    assert result == data[start:end]

    # test with start == end
    start = end = 1
    result = AnsibleVaultEncryptedUnicode(data)[start:end]


# Generated at 2022-06-11 09:26:14.740239
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import random
    from ansible_vault import Vault

    vault = Vault(get_vault_password())
    ciphertext = vault.encrypt(to_bytes('foo'))
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    yield assert_not_equal, avu, 'foo'
    yield assert_not_equal, avu, 'foo', "should be case sensitive"
    yield assert_not_equal, avu, 'fo' + 'o'
    yield assert_not_equal, avu, 'fo' + 'o' + 'o'
    yield assert_not_equal, avu, random.choice([True, False, None, {}])
    yield assert_not_equal, avu, random.randrange(0, 99999)

# Generated at 2022-06-11 09:26:27.498644
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    '''
    Test the method ``count`` of class ``AnsibleVaultEncryptedUnicode``
    '''
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('password')
    # Simple test
    password = u'password'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(password, vault, b'password')
    assert isinstance(avu, AnsibleVaultEncryptedUnicode)
    assert avu.count(password) == 1
    # Test with a wrong password
    password = u'password'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(password, vault, b'bad_password')
    assert isinstance(avu, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 09:26:40.314451
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    """
    AnsibleVaultEncryptedUnicode.__getslice__(self, i, j)
    
    Return self[max(i, 0):max(j, 0)]
    """
    class _TestSubcls(AnsibleVaultEncryptedUnicode):
        def __init__(self, initval=None, encoding=None, errors=None):
            AnsibleVaultEncryptedUnicode.__init__(self, initval)

    # case 01 -- input data is a str
    test_obj = _TestSubcls(b'abcdefgh')
    assert(test_obj.__getslice__(5, 7) == b'fg')
    # case 01 -- input data is a unicode
    test_obj = _TestSubcls(u'abcdefgh')

# Generated at 2022-06-11 09:26:49.675750
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from collections import Counter
    from test.support import run_unittest

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    from ansible.parsing.vault import VaultLib

    class Test_AnsibleVaultEncryptedUnicode_count(unittest.TestCase):
        def setUp(self):
            self.v = VaultLib(password=None)
            self.avu = AnsibleVaultEncryptedUnicode.from_plaintext(u'hello world', self.v, None)
            self.avu.vault = self.v

        def tearDown(self):
            del self.avu
            del self.v


# Generated at 2022-06-11 09:27:01.336080
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault as vaultlib
    salt = '23d8a7b0fc96'
    password = 'hunter2'
    secret = bytes(password)
    string = 'This is a test'
    unencrypted_string = string
    encrypted_string = vaultlib.VaultLib.encrypt(salt, secret, string)
    avue = AnsibleVaultEncryptedUnicode(encrypted_string)
    avu = AnsibleVaultEncryptedUnicode(unencrypted_string)
    if not avue.is_encrypted():
        raise Exception('Test Failed: %s is not encrypted' % encrypted_string)
    if avu.is_encrypted():
        raise Exception('Test Failed: %s is encrypted' % unencrypted_string)


# Generated at 2022-06-11 09:27:14.002168
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    aveu = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256\n63316337623963656466666533643566346438663762313239386466353934363730643264636666\n3064343565383334306666663537623661316163306134393632393663316163623766316533356562\n656537353939386566376533663362\n")
    aveu.vault = get_vault_instance(ask_vault_pass=lambda *_, **__: '')

    assert aveu == "bar"
    assert "bar" == aveu
    assert not aveu == "foo"
    assert not "foo" == aveu

# Generated at 2022-06-11 09:27:25.638827
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    class DummyVault(object):
        def encrypt(self, msg, secret):
            '''dummy encrypt function'''
            return "dummy encrypted"
        def decrypt(self, msg, secret):
            '''dummy decrypt function'''
            return "dummy decrypted"
        def is_encrypted(self, msg):
            return True

    my_dummy_vault = DummyVault()
    avueu = AnsibleVaultEncryptedUnicode.from_plaintext(to_bytes('plaintext'), my_dummy_vault, 'secret')

    # result
    result = avueu == 'plaintext'

    # eq operator will call __eq__ member function of AnsibleVaultEncryptedUnicode
    assert result == True


# Generated at 2022-06-11 09:27:29.322561
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert AnsibleVaultEncryptedUnicode.from_plaintext('', None, '').is_encrypted()
    assert not AnsibleVaultEncryptedUnicode.from_plaintext('', None, '').data


# Generated at 2022-06-11 09:27:39.016493
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    ciphertext = b'encrypted text'
    # class AnsibleVaultEncryptedUnicode.__init__ deals with conversion to byte string
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    # class AnsibleVaultEncryptedUnicode.__getslice__ deals with conversion to unicode
    assert avu.__getslice__(2, 8) == u'crypte'

    # verify that calling .__getslice__ directly returns byte string
    assert avu.__getslice__(2, 8) == ciphertext[2:8]


# Generated at 2022-06-11 09:27:55.553517
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    s = AnsibleVaultEncryptedUnicode(b'foo')
    assert (s != b'foo') # AnsibleVaultEncryptedUnicode is not decrypted


if yaml.__with_libyaml__:
    AnsibleVaultEncryptedUnicode.yaml_loader = yaml.CSafeLoader
    AnsibleVaultEncryptedUnicode.yaml_dumper = yaml.CSafeDumper
else:
    AnsibleVaultEncryptedUnicode.yaml_loader = yaml.SafeLoader
    AnsibleVaultEncryptedUnicode.yaml_dumper = yaml.SafeDumper



# Generated at 2022-06-11 09:28:05.522506
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    V = VaultLib(['--vault-password-file', '/dev/null'])
    plaintext = u'plaintext'
    ciphertext = V.encrypt(plaintext)
    assert ciphertext != plaintext
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = V
    assert avu.is_encrypted()
    avu.data = plaintext
    assert not avu.is_encrypted()


# Generated at 2022-06-11 09:28:09.530366
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    text = AnsibleVaultEncryptedUnicode("foo")
    assert text != "foo"
    assert text.__ne__("foo")
    assert "foo" != text
    assert "foo".__ne__(text)


# Generated at 2022-06-11 09:28:14.155211
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib

    secret = b'secret'

    # test non encrypted string
    string = b'foo'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(string, VaultLib(secret), secret)
    assert string != avu



# Generated at 2022-06-11 09:28:24.975134
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing import vault
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('standard_string',vault.AnsibleVaultAES256('password'))
    assert avu != 'standard_string'

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('password',vault.AnsibleVaultAES256('password'))
    assert avu != 'password'

    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;user26090972;password')
    assert avu != 'password'


# Generated at 2022-06-11 09:28:36.327701
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from .vaultlib import VaultLib
    vault = VaultLib('password')
    plaintext = 'This is a plaintext string that is not encrypted.'

# Generated at 2022-06-11 09:28:42.166731
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password='password')
    ciphertext = vault.encrypt(b'bar')
    obj = AnsibleVaultEncryptedUnicode(ciphertext)
    obj.vault = vault

    assert obj.is_encrypted() == True
    obj.data = b'foo'
    assert obj.is_encrypted() == False


# Generated at 2022-06-11 09:28:48.563311
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib

    # Generate a random password to use for testing
    import os
    import string
    import random
    password = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(24))

    # Create the Vault Lib object
    vault = VaultLib(password)

    # Create the test string
    test_string = "Test string 1: This is a test"

    # Encrypt the test string
    encrypted_test_string = AnsibleVaultEncryptedUnicode.from_plaintext(test_string, vault, password)

    # Now we test for equality
    assert encrypted_test_string == test_string
    assert encrypted_test_string == encrypted_test_string


# Generated at 2022-06-11 09:29:00.241571
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader

    vault = VaultLib({'password': 'password'})

    ciphertext_vault1 = vault.encrypt(b'This is plaintext')
    ciphertext_vault2 = vault.encrypt(b'This is plaintext2')

    # check if is_encrypted method works correctly
    encrypted_unicode_vault1 = AnsibleVaultEncryptedUnicode(ciphertext_vault1)
    assert encrypted_unicode_vault1.is_encrypted() is True

    encrypted_unicode_vault2 = AnsibleVaultEncryptedUnicode(ciphertext_vault2)


# Generated at 2022-06-11 09:29:02.997542
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert (AnsibleVaultEncryptedUnicode.from_plaintext('hello', 'password') == 'hello')


# Generated at 2022-06-11 09:29:19.957912
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-11 09:29:26.825383
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault_pass_file = '/Users/jeff.wode/.ansible/vault.pass'
    vault = VaultLib(password_file=vault_pass_file)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, vault_pass_file)
    assert avu.__ne__('test') == True, 'Expected avu.__ne__("test") to be True'


# Generated at 2022-06-11 09:29:38.684594
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # check if __ne__ returns True for unequal values
    for d in [
        AnsibleVaultEncryptedUnicode.from_plaintext("", None, "secret"),
        AnsibleVaultEncryptedUnicode("vault:secret"),
    ]:
        assert d != "vault:secret"

    # check if __ne__ returns True for equal values
    for d in [
        AnsibleVaultEncryptedUnicode("0"*32),
        AnsibleVaultEncryptedUnicode("0"*32),
    ]:
        assert d != "0"*32

    # references are checked by id
    assert d != d



# Generated at 2022-06-11 09:29:48.143341
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Create a AnsibleVaultEncryptedUnicode object with a valid vault
    import ansible.parsing.vault as vault
    secret = b'secret'
    plaintext = u'Blabla'
    vault_obj = vault.VaultLib(None)
    ciphertext = vault_obj.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault_obj
    assert avu.is_encrypted() == True

    # Create a AnsibleVaultEncryptedUnicode object with an invalid vault
    import ansible.parsing.vault as vault
    secret = b'secret'
    plaintext = u'Blabla'

# Generated at 2022-06-11 09:29:56.009291
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    class TestVault(object):
        def decrypt(self, ciphertext):
            return ciphertext

    ciphertext = 'abc'
    secret = 'secret'
    vault = TestVault()

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(ciphertext, vault, secret)
    avu.vault = vault
    assert (avu != 'abc')
    assert not (avu != 'abcd')



# Generated at 2022-06-11 09:30:07.089953
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from invoke.vendor.six import PY2, PY3
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    ciphertext = "It's encrypted."
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = None
    assert avu == ciphertext

    if PY3:
        avu = AnsibleVaultEncryptedUnicode(ciphertext)
        avu.vault = None
        assert avu == bytes(ciphertext, 'utf-8')

    if PY2:
        import __builtin__
        avu = AnsibleVaultEncryptedUnicode(ciphertext)
        avu.vault = None
        assert avu == __builtin__.unicode(ciphertext)



# Generated at 2022-06-11 09:30:15.454138
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib

    my_vault = VaultLib('test')

    tab = [
        (b'', b'', True),
        (b'foobar', b'foobar', True),
        (b'foo', b'bar', False),
        (b'foo', u'foo', True),
        (u'foo', b'foo', True),
        (u'foo', u'foo', True),
        (u'foo', u'bar', False)
    ]

    for (data1, data2, equal) in tab:
        # Create a few AnsibleVaultEncryptedUnicode objects, encrypted with the same 'test' password
        plaintext1 = to_bytes(data1, errors='surrogate_or_strict')

# Generated at 2022-06-11 09:30:27.273993
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass
    # If I need to test this class, I will test it here.
    # One test per method, one test per edge case.
    # The actual test conditions are commented out as a reminder.
    # However, leave the pass statement as it is
    #pass # assert testObj.?? == None
    #pass # assert testObj.?? == ""
    #pass # assert testObj.?? == "a"
    #pass # assert testObj.?? == "ab"
    #pass # assert testObj.?? == "abc"
    #pass # assert testObj.?? == "abc def"
    #pass # assert testObj.?? == "abc def\n"
    #pass # assert testObj.?? == "a\nb\nc\nd"
    #pass # assert testObj.?? == "a\rb\tc\td"
   

# Generated at 2022-06-11 09:30:30.582556
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    sub = AnsibleVaultEncryptedUnicode.from_plaintext('23', 'fake_vault', 'fake_secret')
    assert sub.__ne__('23')


# Generated at 2022-06-11 09:30:40.118194
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    """
    Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
    """

    # Should return True for two equal strings
    #   even if one of them is a AnsibleVaultEncryptedUnicode
    actual = (
        AnsibleVaultEncryptedUnicode("my plaintext string") ==
        "my plaintext string"
    )
    expected = True
    assert actual == expected

    # Should return False for two unequal strings
    #   even if one of them is a AnsibleVaultEncryptedUnicode
    actual = (
        AnsibleVaultEncryptedUnicode("your plaintext string") ==
        "my plaintext string"
    )
    expected = False
    assert actual == expected

    # Should return True for two equal AnsibleVaultEncryptedUnicode objects
    #   even

# Generated at 2022-06-11 09:30:53.951239
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib("test")
    vault.unlock("test")

    avu = AnsibleVaultEncryptedUnicode.from_plaintext("some data", vault, "test")
    assert avu.__eq__("some data")
    assert (not avu.__eq__("some other data"))

    vault = VaultLib("test")
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("some data", vault, "test")
    # avu doesn't have a vault so it will return False
    assert (not avu.__eq__("some data"))



# Generated at 2022-06-11 09:30:55.351352
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert ansible_vault_encrypted_unicode_obj != b'test'


# Generated at 2022-06-11 09:30:57.753214
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=None, secret=None)
    assert avu.__ne__('foo')

# Generated at 2022-06-11 09:31:02.571252
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    not_equal = AnsibleVaultEncryptedUnicode('foo')
    equal = AnsibleVaultEncryptedUnicode('foo')

    assert not_equal != 'foo'
    assert 'foo' != not_equal

    assert not_equal != equal
    assert equal != not_equal


# Generated at 2022-06-11 09:31:12.680410
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    test_string = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;ansible\n36343365306637623230373265393534336533303430316365376266623233386333346532653634\n3166343335333234653334646635333338346531363162383138663266396439393361343336356433\n6433373064353162346437393064333232383737366561663939663536376638346534316334346533\n383533393562\n')
    test_string.vault = AnsibleVaultLib()
    assert test_string.is_encrypted()



# Generated at 2022-06-11 09:31:25.750697
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import binascii

    # Test data, password and plaintext
    # Note that these data DO NOT contain a vault header
    password = 'secret'
    plaintext = 'abc123'
    # Create the secret object
    secret = VaultSecret(password.encode('utf-8'))
    # Create the vault object
    vault = VaultLib(secret)
    # Encrypt the plaintext
    ciphertext = vault.encrypt(plaintext)

    # Create the AnsibleVaultEncryptedUnicode object
    avu_obj = AnsibleVaultEncryptedUnicode(ciphertext)
    # Attach the vault object
    avu_obj.vault = vault

    # The AnsibleVault

# Generated at 2022-06-11 09:31:37.328315
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode.from_plaintext('12345', yaml.vault.Vault('password'), 'secret') == '12345'
    assert AnsibleVaultEncryptedUnicode.from_plaintext('12345', yaml.vault.Vault('password'), 'secret') != '123456'
    assert AnsibleVaultEncryptedUnicode.from_plaintext('12345', yaml.vault.Vault('password'), 'secret') != '2345'
    assert AnsibleVaultEncryptedUnicode.from_plaintext('12345', yaml.vault.Vault('password'), 'secret') != '1234'

# Generated at 2022-06-11 09:31:44.235421
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    # default behaviour when no decrypt is available
    x = AnsibleVaultEncryptedUnicode('data')
    assert x != 'data'
    assert 'data' != x

    # now with a usable vault
    x = AnsibleVaultEncryptedUnicode('data')
    x.vault = vaultlib.VaultLib()
    assert x != 'data'
    assert 'data' != x

    # and finally with the same value
    x.data = 'data'
    assert x == 'data'
    assert 'data' == x



# Generated at 2022-06-11 09:31:52.013766
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # create test vaul and encrypt data
    test_secret = "password"
    test_vault = VaultLib(password=test_secret)
    test_data = "test data"
    test_ciphertext = test_vault.encrypt(test_data, test_secret)

    # create encrypted AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode(test_ciphertext)
    avu.vault = VaultLib(password=test_secret)

# Generated at 2022-06-11 09:31:58.544902
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault
    vault = ansible.parsing.vault.VaultLib()
    # pylint: disable=bad-whitespace

# Generated at 2022-06-11 09:32:11.812789
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import AnsibleVaultError
    from ansible.parsing.vault import InvalidVaultPassword


# Generated at 2022-06-11 09:32:22.246784
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    """is_encrypted should return True for a AnsibleVaultEncryptedUnicode
    created by ``AnsibleVaultEncryptedUnicode.from_plaintext``, and False
    otherwise.

    """
    from ansible.parsing.vault import VaultLib

    vault = VaultLib()
    secret = 'secret'
    # 'str' created with `from_plaintext` method
    assert AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, secret).is_encrypted()
    # 'str' created with the `data` property setter
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu.vault = vault
    avu.data = 'foo'
    assert not avu.is_encrypted()


# Generated at 2022-06-11 09:32:28.241844
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(b"mypassword")
    test_vault_text = AnsibleVaultEncryptedUnicode.from_plaintext("abc", vault, "mypassword")
    assert("def" != test_vault_text)
    vault_text2 = AnsibleVaultEncryptedUnicode.from_plaintext("abc", vault, "mypassword")
    assert("abc" != vault_text2)


# Generated at 2022-06-11 09:32:29.969995
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    vault_text = AnsibleVaultEncryptedUnicode('foo')
    assert vault_text != 'foo'



# Generated at 2022-06-11 09:32:39.502491
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    class TestVault(object):
        def is_encrypted(self, obj):
            return True
        def decrypt(self, obj, secret=None, **kwargs):
            return "this is a secret"
    vault = TestVault()
    secret = "foo"
    plaintext = "this is plaintext"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)

    assert avu != plaintext
    assert avu != u'this is plaintext'

    avu.data = vault.encrypt(plaintext, secret)
    assert avu != plaintext
    assert avu != u'this is plaintext'

    avu.vault = None
    assert avu == plaintext

# Generated at 2022-06-11 09:32:49.074690
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    secret = b"foobar"

    avu_plaintext_py2 = AnsibleVaultEncryptedUnicode.from_plaintext(b"abc", VaultLib(None), secret)
    assert not avu_plaintext_py2.is_encrypted()

    avu_plaintext_py3 = AnsibleVaultEncryptedUnicode.from_plaintext("abc", VaultLib(None), secret)
    assert not avu_plaintext_py3.is_encrypted()

    avu_ciphertext_py2 = AnsibleVaultEncryptedUnicode(avu_plaintext_py2._ciphertext)
    assert avu_ciphertext_py2.is_encrypted()

    avu_ciphertext_py3 = AnsibleVaultEncrypted

# Generated at 2022-06-11 09:32:54.368872
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test equality of two equal AnsibleVaultEncryptedUnicode objects
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n' + 'a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6'
    avu1 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu2 = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu1 != avu2


# Generated at 2022-06-11 09:33:04.367084
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    def test_AnsibleVaultEncryptedUnicode___ne__(vault, secret, plaintext, other_plaintext):
        avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
        assert avu != other_plaintext
        assert avu == plaintext

    from ansible.parsing.vault import VaultLib
    vault = VaultLib("not so secret")

    test_AnsibleVaultEncryptedUnicode___ne__(vault, "secret", "plaintext", "other plaintext")



# Generated at 2022-06-11 09:33:16.763729
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import vault_decrypt
    vault_password = 's3cr3t'
    secret = 'API Key to access some service'
    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256\n3739633361633537306262633334313663653434663431613237616262613362366666393038316363\n6163306531646161366632336531633135313161366133323664306661666266646366326539346438\n643665333966343934633263633165\n'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault_decrypt(vault_password)

# Generated at 2022-06-11 09:33:20.778141
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    a = AnsibleVaultEncryptedUnicode('test')

    # test equality
    assert a == 'test'
    assert 'test' == a

    # test inequality
    assert not a == 'TEST'
    assert not 'TEST' == a

# Generated at 2022-06-11 09:33:32.069543
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avueu = AnsibleVaultEncryptedUnicode('123')
    # We should not crash
    assert(avueu == 'xyz')
    # We should not crash
    assert(avueu != 'xyz')


# Generated at 2022-06-11 09:33:37.862651
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault as vault
    txt = 'this is a new Vault'
    password = 'foo'
    v = vault.VaultLib(password)
    avu = AnsibleVaultEncryptedUnicode(v.encrypt(txt, password))
    assert avu.is_encrypted()
    avu.vault = v
    assert not avu.is_encrypted()



# Generated at 2022-06-11 09:33:46.402207
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(b'123')
    data = 'Hello world!'
    password = b'123'

    encrypted_data = AnsibleVaultEncryptedUnicode.from_plaintext(data, vault, password)
    assert encrypted_data == data


# Generated at 2022-06-11 09:33:50.775494
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Instantiating the class with valid parameters should succeed
    ciphertext = to_bytes("test")
    vault = None
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert not avu.__eq__("test")
    avu.vault = vault
    assert avu.__eq__("test")



# Generated at 2022-06-11 09:33:57.491637
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    other = AnsibleVaultEncryptedUnicode("This is a Test String.")
    assert other != 1234
    assert other != "This is a Test String."
    assert other != "other"
    assert other == "This is a Test String."
    assert 1234 != other
    other.vault = "Vault"
    assert other != 1234
    assert other != "This is a Test String."
    assert other != "other"
    assert other == "This is a Test String."
    assert 1234 != other


# Generated at 2022-06-11 09:34:07.721778
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import unittest
    from tests.unit.module_utils.parsing.utils.vault import VaultLib
    from ansible.module_utils import basic

    class TestVault(VaultLib):
        '''A TestVault that returns True from is_encrypted.'''
        def is_encrypted(self, ciphertext):
            return True

    vault = TestVault(None)
    basic._ANSIBLE_ARGS = None
    x = AnsibleVaultEncryptedUnicode.from_plaintext(to_bytes('Hello World', errors='surrogate_or_strict'), vault, 'secret')
    assert x.is_encrypted()
    x = AnsibleVaultEncryptedUnicode(to_bytes('Hello World', errors='surrogate_or_strict'))
    assert x.is_encrypted()


#

# Generated at 2022-06-11 09:34:17.262078
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    # initialize with valid vault
    vault = VaultLib(b'ansible')

# Generated at 2022-06-11 09:34:27.842089
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    secret = b'password'
    seq = b'ansible'
    ciphertext = b'$ANSIBLE_VAULT;1.2;AES256;default\r\n343136623137613332316262316437333864623166663361383335613762616334323238646637\r\n3932366362333961636236386662356435376365643339376435343861663164346363613562343\r\n634383361346535666238633863326133'

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vaultlib.VaultLib(secret)

    fake_avu = 'fake_avu'

# Generated at 2022-06-11 09:34:37.898606
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault as vaultlib
    plaintext = 'ansible-vault'

    # Act
    ciphertext_serialized_with_vault_id = vaultlib.VaultLib().encrypt(plaintext)
    ciphertext_serialized_with_no_vault_id = ciphertext_serialized_with_vault_id.replace('$ANSIBLE_VAULT;', '$ANSIBLE_VAULT|')
    ciphertext_serialized_with_invalid_vault_id = ciphertext_serialized_with_no_vault_id.replace('2.1;', '2.6;')
    ciphertext_deserialized = vaultlib.VaultLib().decrypt(ciphertext_serialized_with_vault_id, obj=None)
    ciphertext_native = ciphertext

# Generated at 2022-06-11 09:34:47.282688
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext("to be or not to be", None, None)

# Generated at 2022-06-11 09:35:07.302326
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Given
    text = 'this is a test'
    vault = 'Vaultlib'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(text, vault, 'secret')

    # When
    result = avu.__ne__(text)

    # Then
    assert result



# Generated at 2022-06-11 09:35:12.092066
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # create the encrypted object
    test_av = AnsibleVaultEncryptedUnicode()
    test_av.vault = vault.VaultLib([])

    # check if is_encrypted works as expected
    test_av.data = '$ANSIBLE_VAULT;1.2;AES256;'
    assert test_av.is_encrypted()

# Unit tests for method decode of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:35:21.010251
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Only need to test if the presence of the ENCRYPED tag indicates a
    # encrypted string as the tag is removed as part of the decryption
    # process.
    #
    # Assume ciphertext is base64 encoded
    iv_bytes = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    key = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    tag_bytes = b'\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-11 09:35:26.047322
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # is_encrypted is true if it starts with $ANSIBLE_VAULT
    avu = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT")
    assert(avu.is_encrypted())

    # is_encrypted is false if it starts with anything else
    for prefix in ("", ".", "!$ANSIBLE_VAULT"):
        avu = AnsibleVaultEncryptedUnicode(prefix)
        assert(not avu.is_encrypted())



# Generated at 2022-06-11 09:35:34.884014
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    test_values = [
        ('ciphertext1', 'ciphertext2', False),
        ('ciphertext1', 'ciphertext1', True),
        ('ciphertext1', 'plaintext1', False),
    ]

    from ansible.parsing.vault import VaultLib

    vault = VaultLib([], 1)
    secret = b'password'

    for ciphertext1, other, result in test_values:
        class _Vault(object):
            def decrypt(self, ciphertext, obj=None):
                return self.decrypt_text(ciphertext)

            def decrypt_text(self, ciphertext):
                if ciphertext == 'ciphertext1':
                    return 'plaintext1'
                return 'plaintext2'

            def encrypt(self, seq, secret):
                return seq

        vault