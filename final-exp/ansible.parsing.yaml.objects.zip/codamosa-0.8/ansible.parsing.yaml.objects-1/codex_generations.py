

# Generated at 2022-06-11 09:26:01.026455
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    # Test with a different type of object
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert not avu.__eq__(123)

    # Test if it is not encrypted and the __eq__ doesn't know the secret
    avu = AnsibleVaultEncryptedUnicode('abc')
    avu.vault = None
    assert not avu.__eq__('abc')

    # Test if it is not encrypted but the __eq__ knows the secret
    plaintext = 'abc'
    secret = 'test'
    vault = VaultLib([])
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    avu.vault = None

# Generated at 2022-06-11 09:26:13.531046
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    from ansible.parsing.vault import VaultLib
    from ansible.errors import AnsibleError
    import os

    try:
        vault_password = os.environ['ANSIBLE_VAULT_PASSWORD']
    except KeyError as e:
        print('ANSIBLE_VAULT_PASSWORD environment variable must be set')
        exit(1)

    vault = VaultLib(vault_password)
    secret = 'my secret'
    ciphertext = vault.encrypt(secret, secret)
    secret_u = AnsibleVaultEncryptedUnicode(ciphertext)
    secret_u.vault = vault

    if secret_u.find('secret') == -1:
        raise AnsibleError('test_AnsibleVaultEncryptedUnicode_find failed')

test_AnsibleVaultEnc

# Generated at 2022-06-11 09:26:16.387211
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    obj = AnsibleVaultEncryptedUnicode('test')
    assert obj.find('t') == 0, "Got unexpected result"
    assert obj.find('t', 1) == 2, "Got unexpected result"



# Generated at 2022-06-11 09:26:21.444288
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # If an AnsibleVaultEncryptedUnicode object is compared with a string
    # using the __gt__ comparison operator, the string results in being greater
    # than an AnsibleVaultEncryptedUnicode object.
    obj = AnsibleVaultEncryptedUnicode("")
    assert('a' > obj)



# Generated at 2022-06-11 09:26:35.923124
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Both strings are encrypted with the same vault.
    avu1 = AnsibleVaultEncryptedUnicode._from_plaintext("bar", vault="vault1", secret="secret")
    avu2 = AnsibleVaultEncryptedUnicode._from_plaintext("baz", vault="vault1", secret="secret")
    assert(avu1 != avu2)

    # Both strings are encrypted with different vaults.
    avu1 = AnsibleVaultEncryptedUnicode._from_plaintext("bar", vault="vault1", secret="secret")
    avu2 = AnsibleVaultEncryptedUnicode._from_plaintext("bar", vault="vault2", secret="secret")
    assert(avu1 != avu2)

    # First string is encrypted and second string is plaintext.
    avu1

# Generated at 2022-06-11 09:26:46.482326
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    try:
        from unittest import mock
    except ImportError:
        import mock
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secret = VaultSecret('secret')
    vault = VaultLib(vault_secret)

    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, vault_secret)
    encrypted_equal = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, vault_secret)
    encrypted_other = AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, vault_secret)

    # encrypted < 'test' will always be false as 'test' will be cast to a AnsibleVaultEncryptedUnicode object
    # and it will evalute

# Generated at 2022-06-11 09:26:51.445217
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    from ansible.parsing.vault import VaultLib
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    # Test for not matching string
    match_string = 'ansible'
    match_searched = 'ansible'
    encrypted_string = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256;foo;12345678901234567890123456789012')
    with patch.object(VaultLib, 'is_encrypted', lambda x, y: True):
        assert encrypted_string.replace(match_searched, match_string) == match_searched

    # Test for matching string calling replace multiple times
    match_string = 'ansible'

# Generated at 2022-06-11 09:27:02.385094
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:27:03.018335
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    assert True

# Generated at 2022-06-11 09:27:15.907761
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:27:29.321748
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    val_1 = AnsibleVaultEncryptedUnicode('test data')
    val_2 = AnsibleVaultEncryptedUnicode('test data')
    assert (val_1 > val_2) is False
    assert (val_2 > val_1) is False
    val_3 = AnsibleVaultEncryptedUnicode('test data ')
    assert (val_1 > val_3) is False
    assert (val_3 > val_1) is True


# Generated at 2022-06-11 09:27:42.743316
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Test to verify fix for bug #27928
    import vaultlib

    a = AnsibleVaultEncryptedUnicode.from_plaintext("a", vaultlib.VaultLib("password"), "password")
    b = AnsibleVaultEncryptedUnicode("b")
    b.vault = vaultlib.VaultLib("password")
    if a > b:
        print("method __gt__ of class AnsibleVaultEncryptedUnicode works as expected")
    else:
        print("method __gt__ of class AnsibleVaultEncryptedUnicode does not work as expected")

if __name__ == '__main__':
    # unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
    test_AnsibleVaultEncryptedUnicode___gt__()


# Generated at 2022-06-11 09:27:46.050560
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    avu = AnsibleVaultEncryptedUnicode(u'foo')
    assert avu < u'bar'
    assert avu < AnsibleVaultEncryptedUnicode(u'bar')



# Generated at 2022-06-11 09:27:55.277600
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Create a AnsibleVaultEncryptedUnicode object
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n' + \
        '662d3365313632633062393135613361323065356663643938303435633034623339303735336238\n' + \
        '6663356131303633363766353930663132653762346462326639393965633166367a0a3639303533\n' + \
        '66383439613630653732393938336262616338616564663761333431613266626363666162356164\n' + \
        '346564323232656637\n'
    avu = AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:27:59.541633
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    a = AnsibleVaultEncryptedUnicode("a")
    b = AnsibleVaultEncryptedUnicode("b")
    assert a.__gt__(b) is False


# Generated at 2022-06-11 09:28:09.087177
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # patch out VaultLib so we use our mocked version
    import ansible.parsing.vault
    from ansible.parsing.vault import VaultLib
    ansible.parsing.vault.VaultLib = VaultLib

    vault = VaultLib('test_vault_password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("the plaintext", vault, "the secret")
    assert avu.is_encrypted()

    # restore VaultLib
    ansible.parsing.vault.VaultLib = VaultLib



# Generated at 2022-06-11 09:28:13.777116
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Verify behavior of __eq__
    avu_obj = AnsibleVaultEncryptedUnicode('abcdefg')
    assert avu_obj == 'abcdefg'
    assert not avu_obj == 'abcdefgh'
    assert not avu_obj == 12345


# Generated at 2022-06-11 09:28:27.098233
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    test_ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n33393962333935386466373131666234346466383664663663386436626535303865396230333536\n3034653836326138313431613733663437656635313266316234623061303861643736303337366639\n3261333037383531663966353364313965353039376237633931326433386238653862656532396562\n3361636566343630356431333736333930356434383334616365623962343861643763663632373139\n38386564\n'

# Generated at 2022-06-11 09:28:33.395663
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # pylint: disable=too-many-locals
    # NOTE: This test is designed to be run against all the vault formats
    # and will fail if the number of vault formats changes.
    vault_formats = VaultLib._VAULT_FORMATS.copy()

    # Add the deprecated HIGHEST format, but ignore it in the results
    # since we will be skipping it in the test below
    vault_formats['HIGHEST'] = vault_formats['1.1']

    result = dict()
    for vault_format in vault_formats:
        result[vault_format] = dict()

        plaintext = 'plaintext'
        password = 'password'

        secret = VaultSecret(password)



# Generated at 2022-06-11 09:28:44.160803
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Test with an empty object
    obj = AnsibleVaultEncryptedUnicode('')
    assert not obj.is_encrypted()

    obj = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    assert obj.is_encrypted()

    obj = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256')
    assert obj.is_encrypted()

    obj = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.0;AES256')
    assert not obj.is_encrypted()

    obj = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.0;DES3')
    assert not obj.is_encrypted()

    obj = AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:28:53.925877
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # when data is set
    test = AnsibleVaultEncryptedUnicode("test")
    test.data = "test"
    assert test != "test"
    # when data is not set
    test = AnsibleVaultEncryptedUnicode("test")
    assert test != "test"


# Generated at 2022-06-11 09:28:58.706669
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import vault
    vault_secret = "vault_secret"
    vault_password = vault.AnsibleVaultEncryptedUnicode.from_plaintext(vault_secret, vault.AnsibleVaultLib(vault_secret), vault_secret)
    assert vault_password.is_encrypted() is True


# Generated at 2022-06-11 09:29:06.800728
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    # Test that no exception is raised if the replacement value is a AnsibleVaultEncryptedUnicode object
    from ansible.parsing.vault import VaultLib
    vault_pass = 'testing'
    vault = VaultLib(vault_pass)
    ciphertext = to_bytes(vault.encrypt('Hello World', vault_pass))
    avu = AnsibleVaultEncryptedUnicode(ciphertext=ciphertext)
    avu.vault = vault
    avu.replace('Hello', AnsibleVaultEncryptedUnicode(ciphertext=ciphertext))

# Generated at 2022-06-11 09:29:11.830314
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    plain = 'abc'
    password = 'bar'

    # Non-vault string shouldn't be affected
    assert plain.replace(to_native(AnsibleVaultEncryptedUnicode(plain, password)), 'def') == 'def'

    # Vault string shouldn't be decrypted
    encrypted = AnsibleVaultEncryptedUnicode(plain, password)
    assert encrypted.replace(to_native(encrypted), 'def') == 'def'


# Generated at 2022-06-11 09:29:25.636852
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Positive test cases
    result = AnsibleVaultEncryptedUnicode('abcdefghijklmnopqrstuvwxyz').__getslice__(0, 20)
    assert result == 'abcdefghijklmnopqrst'
    result = AnsibleVaultEncryptedUnicode('abcdefghijklmnopqrstuvwxyz').__getslice__(0, -1)
    assert result == 'abcdefghijklmnopqrstuvwxy'
    result = AnsibleVaultEncryptedUnicode('abcdefghijklmnopqrstuvwxyz').__getslice__(-10, 20)
    assert result == 'opqrstuvwx'

# Generated at 2022-06-11 09:29:37.188991
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vaulted = AnsibleVaultEncryptedUnicode.from_plaintext('supersecret', VaultLib(), 'mypw')
    vaulted.data = vaulted.data.replace('mypw', 'other')
    assert vaulted.data == 'supersecret'
    vaulted.data = vaulted.data.replace('supersecret', 'other')
    print(vaulted.data)
    assert vaulted.data == 'other'


# Generated at 2022-06-11 09:29:44.775325
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    text_to_encrypt = 'the quick brown fox jumps over the lazy dog'
    vault_password = 'f00b4r'
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(text_to_encrypt, vault=yaml.load(open('vault.py', 'rb'))[0], secret=vault_password)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('abcdefg', vault=yaml.load(open('vault.py', 'rb'))[0], secret=vault_password)

    assert avu1.replace(avu2, '') == text_to_encrypt
    assert avu2.replace(avu1, '') == 'abcdefg'
    assert ''.replace(avu1, '') == ''

# Generated at 2022-06-11 09:29:56.802448
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    import ansible.parsing.vault
    vault = ansible.parsing.vault
    v = vault.VaultLib('pass')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(b'a', v, b'pass')
    s = 'a'
    other = AnsibleVaultEncryptedUnicode.from_plaintext(b'a', v, b'pass')
    other_1 = AnsibleVaultEncryptedUnicode.from_plaintext(b'b', v, b'pass')
    assert(avu.__lt__(s) == False)
    assert(avu.__lt__(other) == False)
    assert(avu.__lt__(other_1) == True)


# Generated at 2022-06-11 09:30:07.510916
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    assert AnsibleVaultEncryptedUnicode('qwerty').__getslice__(3,6) == 'ert'
    assert AnsibleVaultEncryptedUnicode('qwerty').__getslice__(5,5) == ''
    assert AnsibleVaultEncryptedUnicode('qwerty').__getslice__(1,7) == 'werty'
    assert AnsibleVaultEncryptedUnicode('qwerty').__getslice__(-2,6) == 'erty'
    assert AnsibleVaultEncryptedUnicode('qwerty').__getslice__(-3,-2) == 'rt'
    assert AnsibleVaultEncryptedUnicode('qwerty').__getslice__(20,30) == ''


# Generated at 2022-06-11 09:30:09.990054
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    y = AnsibleVaultEncryptedUnicode('!vault |$ANSIBLE_VAULT;12345;AES256\nYWJjZGVmZ2hpamtsbW5vcA==\n')
    y.vault = vaultlib.VaultLib([])
    x = 'abcdefghijklmnopq'
    assert y != x

# Generated at 2022-06-11 09:30:28.634671
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-11 09:30:33.563052
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    # define a test string
    test = AnsibleVaultEncryptedUnicode('test')
    # replace the string
    replace = test.replace('test', 'ing')
    # test if string is replaced
    assert isinstance(replace, AnsibleVaultEncryptedUnicode)
    assert replace.data == 'ing'


# Generated at 2022-06-11 09:30:39.866186
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import AnsibleVault
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext('encrypted string',vault, b'password')
    # should return True if equal
    assert encrypted_string == 'encrypted string' and encrypted_string != 'not encrypted string'
    # should return correct result if compare to different type
    assert encrypted_string != 'encrypted string' and encrypted_string != 0



# Generated at 2022-06-11 09:30:52.146152
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    '''
    Test that __eq__ returns False if it was unable to decrypt the value
    '''
    test_pw = 'ansible'
    test_vault = vaultlib.VaultLib(test_pw)
    test_t = "test"
    test_avu = AnsibleVaultEncryptedUnicode(test_t)

    # Should be false, since we never set the vault attribute
    if test_avu == test_t:
        return False

    test_avu.vault = test_vault
    # Should now be true
    if test_avu == test_t:
        return True

    # Should be false, since we didn't encrypt the value
    if test_t == test_avu:
        return False

    # Now encrypt the value
    test_avu_encrypted = Ansible

# Generated at 2022-06-11 09:30:56.196181
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault_password = 'password'
    vault = VaultLib(vault_password)
    secret = 'secret'
    value = 'value'
    encrypted_value = AnsibleVaultEncryptedUnicode.from_plaintext(value, vault, secret)

    assert encrypted_value == value
    assert encrypted_value != 'value2'
    assert encrypted_value != 123


# Generated at 2022-06-11 09:31:01.578140
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    text = "In cryptography, a vault is an encrypted file or database."
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(text, None, None)
    assert avu.__ne__("In cryptography, a vault is an encrypted file or database.")
    assert "In cryptography, a vault is an encrypted file or database." != avu


# Generated at 2022-06-11 09:31:07.533581
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    av = AnsibleVaultEncryptedUnicode('')
    assert(av != b'foo')
    assert(av != 'foo')
    assert(av != AnsibleVaultEncryptedUnicode('foo'))
    assert(b'foo' != av)
    assert('foo' != av)
    assert(AnsibleVaultEncryptedUnicode('foo') != av)


# Generated at 2022-06-11 09:31:12.229266
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    ansible_vault_encrypted_unicode_object = AnsibleVaultEncryptedUnicode("abc")
    assert ansible_vault_encrypted_unicode_object.data == "abc"
    assert ansible_vault_encrypted_unicode_object.replace("b", "B") == "aBc"


# Generated at 2022-06-11 09:31:14.026403
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    pass
# unit Testing
if __name__ == '__main__':
    test_AnsibleVaultEncryptedUnicode___ne__()

# Generated at 2022-06-11 09:31:20.595694
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader

    plaintext = "secret\n"
    ciphertext = VaultLib().encrypt(plaintext)

    # string-like objects to test against
    yaml_text = AnsibleUnsafeText(ciphertext)
    yaml_vault = AnsibleVaultEncryptedUnicode(ciphertext)

    assert yaml_text.is_encrypted() is False
    assert yaml_vault.is_encrypted() is True

# Replacing AnsibleUnsafeText with AnsibleVaultEncryptedUnicode for testing
# Enc

# Generated at 2022-06-11 09:31:39.042424
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    #
    # ansible/vars/vault.yml is encrypted with password foo
    #
    avue = AnsibleVaultEncryptedUnicode.from_plaintext("foo", AnsibleVaultLib.VaultLib("foo"), "foo")
    assert avue == to_text("foo", errors='surrogate_or_strict')
    assert avue == "foo"
    assert not (avue == "bar")
    assert not (avue != "foo")
    assert avue != "bar"
    assert not (avue != to_text("foo", errors='surrogate_or_strict'))
    #
    # ansible/vars/vault.yml is encrypted with password bar
    #

# Generated at 2022-06-11 09:31:44.734068
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    a = AnsibleVaultEncryptedUnicode(b'foo')
    assert a != 'foo'
    assert 'foo' != a
    import ansible.parsing.vault
    v = ansible.parsing.vault.VaultLib('password')
    a.vault = v
    assert a != 'foo'
    assert 'foo' != a


# End of AnsibleVaultEncryptedUnicode



# Generated at 2022-06-11 09:31:48.035077
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    class AnsibleVaultStub:
        def is_encrypted(text):
            return False

    avu = AnsibleVaultEncryptedUnicode("secret")
    avu.vault = AnsibleVaultStub
    assert avu != "secret"



# Generated at 2022-06-11 09:31:53.863379
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible_collections.ansible.community.plugins.vars.vault import VaultLib
    from ansible_collections.ansible.community.plugins.vars.vault import VaultSecret

    def _build_actual_and_expected(text1, text2, secret):
        ciphertext1 = VaultLib().encrypt(text1, secret)
        ciphertext2 = VaultLib().encrypt(text2, secret)
        avu1 = AnsibleVaultEncryptedUnicode(ciphertext1)
        avu2 = AnsibleVaultEncryptedUnicode(ciphertext2)
        avu1.vault = avu2.vault = VaultLib()
        return (avu1, avu2, text1, text2)


# Generated at 2022-06-11 09:31:57.322227
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode('abc') == 'abc'
    assert AnsibleVaultEncryptedUnicode('abc') == AnsibleVaultEncryptedUnicode('abc')
    assert AnsibleVaultEncryptedUnicode('abc') != 'a'
    assert AnsibleVaultEncryptedUnicode('abc') != AnsibleVaultEncryptedUnicode('a')


# Generated at 2022-06-11 09:32:04.987007
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Do a partial mock of the AnsibleVaultEncryptedUnicode class so that it doesn't
    # try to decrypt it and we can return a known string value
    class AVU(AnsibleVaultEncryptedUnicode):
        def __init__(self, value):
            super(AnsibleVaultEncryptedUnicode, self).__init__(value)
            self._plaintext_value = u"This is a plaintext value"

        def ansible_vault_decrypted_text(self):
            return self._plaintext_value

        def decode(self, *args, **kwargs):
            return self.data

        def __repr__(self):
            return u"%s:%s" % (self.__class__.__name__, self.data)


# Generated at 2022-06-11 09:32:13.118610
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import vaultlib
    vault = vaultlib.VaultLib('vault')
    secret = 'ansible'

    plaintext = 'foobar'
    avu_plaintext = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avu_plaintext == plaintext
    assert not avu_plaintext.is_encrypted()
    assert avu_plaintext.data == plaintext

    ciphertext = vault.encrypt(plaintext, secret)
    avu_ciphertext = AnsibleVaultEncryptedUnicode(ciphertext)
    avu_ciphertext.vault = vault
    assert avu_ciphertext != plaintext
    assert avu_ciphertext.is_encrypted()
    assert avu_ciphertext.data == plaintext

    # when the

# Generated at 2022-06-11 09:32:23.602104
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    secret = b"This is a secret"

    class vaultlib(object):
        def __init__(self, pwd):
            self.pwd = pwd

        def encrypt(self, bytes, secret):
            return bytes

        def decrypt(self, bytes, secret):
            if self.pwd == b"wrong":
                raise Exception("wrong password")
            return bytes

        def is_encrypted(self, bytes):
            return self.pwd == b"unlocked"

    class vaultlib_not_encryptable(object):
        def __init__(self, pwd):
            self.pwd = pwd

        def encrypt(self, bytes, secret):
            return bytes

        def decrypt(self, bytes, secret):
            if self.pwd == b"wrong":
                raise Exception("wrong password")
            return bytes



# Generated at 2022-06-11 09:32:25.462931
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode('VGVzdA==\n') != 'Test'



# Generated at 2022-06-11 09:32:34.683153
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import os
    from ansible.parsing.vault import VaultLib

    # Create a temporary vault password file, then create a VaultLib object with it
    vault_pass = os.path.join(tempfile.mkdtemp(), 'vault_pass')
    with open(vault_pass, 'w') as f:
        f.write('test_vault_password')
    vault = VaultLib(vault_pass)
    secret = 'test_secret'

    av1 = AnsibleVaultEncryptedUnicode.from_plaintext(secret, vault, vault_pass)
    assert_result = av1 != AnsibleVaultEncryptedUnicode.from_plaintext(secret, vault, vault_pass)

    assert assert_result == False


# Generated at 2022-06-11 09:32:47.057513
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:32:50.967946
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    a = AnsibleVaultEncryptedUnicode(b'!vault ' + b'hello')
    b = AnsibleVaultEncryptedUnicode(b'!vault ' + b'world')
    c = AnsibleVaultEncryptedUnicode(b'!vault ' + b'hello')
    assert a != b
    assert a != c


# Generated at 2022-06-11 09:32:56.933002
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.utils.vault as vault
    import ansible.parsing.dataloader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    ciphertext = '$ANSIBLE_VAULT;1.1;AES256;ansible_test\n6332313961623836366643333343864376138396665313833656237636564393864623737633830\n353764346333653734306435633662\n'
    secret = b'ansible'
    loader = Ans

# Generated at 2022-06-11 09:33:11.353725
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:33:16.979747
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    my_avue = AnsibleVaultEncryptedUnicode(b'abc')
    assert my_avue != 'abc'
    assert my_avue.__ne__('abc')
    assert my_avue != 'dcb'
    assert my_avue.__ne__('dcb')
    assert my_avue != b'dcb'
    assert my_avue.__ne__(b'dcb')


# Generated at 2022-06-11 09:33:29.662455
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    clear_text_value = 'clear text value'
    clear_text_value_as_unicode = to_text(clear_text_value)

    # Initialize an AnsibleVaultEncryptedUnicode object with a clear text value
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(clear_text_value, vault=None, secret=None)

    # Test that the AnsibleVaultEncryptedUnicode object is not equal to the clear text value
    assert avu != clear_text_value
    assert avu != clear_text_value_as_unicode

    # Test that a string object is not equal to the AnsibleVaultEncryptedUnicode object
    assert clear_text_value != avu
    assert clear_text_value_as_unicode != avu


# Generated at 2022-06-11 09:33:40.560359
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import ansible.parsing.vault as vault
    cipher = b'$ANSIBLE_VAULT;1.1;AES256\n65626263363934663730373463343266643863643261623862653863636234616166613530353835\n343833646161666533366135613162626362376630316337633330396633306239326136373061643\n6133343831313334303265\n'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("test", vault.VaultLib("foo"), "foo")
    avu._ciphertext = cipher
    print("type(avu) = %r" % type(avu))

# Generated at 2022-06-11 09:33:48.219319
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    secret = 'test'
    vault = VaultLib(secret)
    # Create a AnsibleVaultEncryptedUnicode object for which is_encrypted should return true
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    assert avu.is_encrypted() == True
    # Create a AnsibleVaultEncryptedUnicode object for which is_encrypted should return false
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.is_encrypted() == False
    # Create a AnsibleVaultEncryptedUnicode object for which is_encrypted should return true

# Generated at 2022-06-11 09:33:55.963400
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    """
    THIS TEST IS DISABLED FOR NOW UNTIL WE CONFIGURE SELFTESTS.
    """
    #from ansible.parsing.vault import VaultLib
    #v = VaultLib('password')
    #avu1 = AnsibleVaultEncryptedUnicode(v.encrypt('abc'))
    #avu2 = AnsibleVaultEncryptedUnicode(v.encrypt('abc'))
    #assert avu1 != avu2
    #avu1.vault = v
    #avu2.vault = v
    #assert avu1 == avu2
    pass



# Generated at 2022-06-11 09:34:06.292979
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    '''Test AnsibleVaultEncryptedUnicode.is_encrypted()'''
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    secret = VaultSecret('password')
    vault = VaultLib(secret)

    # Test for unencrypted string
    unencrypted_string_1 = 'abcdef'
    avue_1 = AnsibleVaultEncryptedUnicode.from_plaintext(unencrypted_string_1, vault, secret)
    assert (avue_1.is_encrypted() == False)

    # Test for decrypted string
    unencrypted_string_2 = '1234567'
    avue_2 = AnsibleVaultEncryptedUnicode.from_plaintext(unencrypted_string_2, vault, secret)

# Generated at 2022-06-11 09:34:28.760012
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    for decrypted_value in ('yes', 'no'):
        for other_value in ('yes', 'no'):
            avu = AnsibleVaultEncryptedUnicode('decrypted_value')
            avu2 = AnsibleVaultEncryptedUnicode('other_value')
            avu.data = decrypted_value
            avu2.data = other_value
            neb = (avu != avu2)
            assert neb == (decrypted_value != other_value)



# Generated at 2022-06-11 09:34:37.673543
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault as vault
    import ansible.parsing.yaml.objects as objects
    test_vault = vault.VaultLib(1, 'foo')

    # Test is_encrypted() with encrypted data
    avu = objects.AnsibleVaultEncryptedUnicode.from_plaintext('encrypted_text', test_vault, 'foo')
    assert(avu.is_encrypted() == True)

    # Test is_encrypted() with decrypted text
    avu = objects.AnsibleVaultEncryptedUnicode.from_plaintext('decrypted_text', test_vault, 'foo')
    assert(avu.is_encrypted() == False)


# Generated at 2022-06-11 09:34:47.047999
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing import vault
    ciphertext = to_bytes('$ANSIBLE_VAULT;1.1;AES256;foo\nbar\n')
    secret = 'password'
    vault_obj = vault.VaultLib(secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(ciphertext, vault_obj, secret)
    assert(avu.is_encrypted())
    # now try an encrypted and modified text
    ciphertext = to_bytes('$ANSIBLE_VAULT;1.1;AES256;baz\nbar\n.')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault_obj
    assert(avu.is_encrypted())
    # now try a not encrypted text
    cipher

# Generated at 2022-06-11 09:34:50.124127
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    vault_test = AnsibleVaultEncryptedUnicode.from_plaintext('ansible', vault=None, secret=None)
    assert("ansible" == vault_test)


# Generated at 2022-06-11 09:34:57.822194
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """Test method __ne__ of class AnsibleVaultEncryptedUnicode"""

    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = 'test'

    # Case 1:
    obj1 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    obj2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)

    assert obj1 != obj2

    # Case 2:
    obj1 = AnsibleVaultEncryptedUnicode.from_plaintext('test1', vault, secret)
    obj2 = AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, secret)

    assert obj1 != obj2

    # Case 3:
    obj1 = AnsibleVaultEnc

# Generated at 2022-06-11 09:35:06.199207
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    class MockVault:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def encrypt(self, plaintext, secret):
            return 'ENCRYPTED_' + plaintext

        def decrypt(self, plaintext, obj):
            return 'DECRYPTED_' + plaintext

        def is_encrypted(self, plaintext):
            if plaintext.startswith('ENCRYPTED_'):
                return True
            return False

    # Create vault objects.
    vault1 = MockVault(id='vault1')
    vault2 = MockVault(id='vault2')

    # Create encrypted strings using factories.

# Generated at 2022-06-11 09:35:11.439988
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    try:
        avu = AnsibleVaultEncryptedUnicode(b'vault(5.5.5)')
        avu.vault = None
        assert avu != 'vault(5.5.5)'
    except Exception as e:
        raise e

yaml.add_representer(AnsibleVaultEncryptedUnicode,
                     yaml.representer.SafeRepresenter.represent_str,
                     Dumper=yaml.SafeDumper)


# Generated at 2022-06-11 09:35:16.216405
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Given an AnsibleVaultEncryptedUnicode with an invalid vault
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    avu.vault = None

    # When I check if it isn't equal to any string
    # Then I should get "True"
    assert avu.__ne__('SomeString')


# Generated at 2022-06-11 09:35:18.260490
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode("test_str")
    assert avu != "test_str"


# Generated at 2022-06-11 09:35:22.637356
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None)
    assert avu.__ne__(None)
    assert avu.__ne__(1)
    assert avu.__ne__('foo') is False
    assert avu.__ne__(AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None)) is False
    assert avu.__ne__(AnsibleVaultEncryptedUnicode.from_plaintext('baz', None, None))
    avu = AnsibleVaultEncryptedUnicode(b'foo')
    assert avu.__ne__('foo')
    assert avu.__ne__(u'foo')

