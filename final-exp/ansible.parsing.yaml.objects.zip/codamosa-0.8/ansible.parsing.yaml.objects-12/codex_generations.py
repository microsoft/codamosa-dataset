

# Generated at 2022-06-11 09:25:56.145676
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    #create class
    test = AnsibleVaultEncryptedUnicode('test_string')
    # test count method
    assert test.count('string') == 1


# Generated at 2022-06-11 09:26:08.390024
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    data = 'this is a test'
    vault = VaultLib(None)
    secret = 'ansible'
    ciphertext = vault.encrypt(data, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    # Test with string
    assert avu != 'this is a test'
    assert avu != 'something else'

    # Test with AV string
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('this is a test', vault, secret)
    assert avu != avu2
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('something else', vault, secret)
    assert avu != avu2


# Generated at 2022-06-11 09:26:18.559874
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    password = ansible_python_bytes(b'ansible')
    secret = VaultSecret(password)
    vault = VaultLib(password)

    plaintext = ansible_python_bytes(b'foo')

    ciphertext = vault.encrypt(plaintext, secret)
    avu1 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu1.vault = vault

    assert avu1.data == plaintext
    assert avu1.data == avu1

    plaintext = ansible_python_bytes(b'bar')

    ciphertext = vault.encrypt(plaintext, secret)
    avu2 = AnsibleVaultEncryptedUnicode(ciphertext)


# Generated at 2022-06-11 09:26:23.852952
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode.from_plaintext('test_content', VaultLib(), 'ansible')
    assert ansible_vault_encrypted_unicode != 'test_content'


# Generated at 2022-06-11 09:26:33.629983
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from . import vault as vaultlib
    SECRET = b'secret'
    vault = vaultlib.VaultLib(SECRET)
    foo = vaultlib.AnsibleVaultEncryptedUnicode.from_plaintext(u'secret', vault, SECRET)
    assert foo == u'secret'
    assert not foo == u'gibberish'
    assert not foo == vaultlib.AnsibleVaultEncryptedUnicode.from_plaintext(u'gibberish', vault, SECRET)



# Generated at 2022-06-11 09:26:45.108792
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import UnsupportedVaultSecret

    # test AnsibleVaultEncryptedUnicode.__le__
    #
    # Arrange
    vault = VaultLib([VaultSecret('foobar')])

    avu0 = AnsibleVaultEncryptedUnicode.from_plaintext('abcdef', vault, 'foobar')
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('defghi', vault, 'foobar')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('abcdef', vault, 'foobar')

    # Act
    # Assert
    assert avu0 <= 'defghi'

# Generated at 2022-06-11 09:26:50.140227
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    seq = '!vault |$ANSIBLE_VAULT;1.1;AES256'
    avu = AnsibleVaultEncryptedUnicode(seq)
    avu.vault = vault
    assert avu.is_encrypted()

    seq = '!vault |' + vault.encrypt('plaintext')
    avu = AnsibleVaultEncryptedUnicode(seq)
    avu.vault = vault
    assert avu.is_encrypted()

    seq2 = vault.encrypt('plaintext')
    assert not AnsibleVaultEncryptedUnicode(seq2).is_encrypted()
    assert not AnsibleVaultEncryptedUnicode('plaintext').is_encrypted()


# Generated at 2022-06-11 09:26:58.560460
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1 <= avu2

    avu2 = AnsibleVaultEncryptedUnicode('abcd')
    assert avu1 <= avu2

    try:
        avu1 <= 1
    except TypeError:
        pass
    else:
        assert False,'TypeError not raised'



# Generated at 2022-06-11 09:27:03.647691
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode(ciphertext='a')
    assert(avu.__ne__('a') == True)
    avu.vault = 'test'
    assert(avu.__ne__('a') == False)


yaml.Loader.add_constructor(u'!vault', vault_constructor)
yaml.SafeLoader.add_constructor(u'!vault', vault_constructor)
yaml.SafeLoader.add_multi_constructor(u'!vault', vault_multi_constructor)

# Generated at 2022-06-11 09:27:07.495733
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    secret = 'testsecret'
    plaintext = 'plaintext'
    ciphertext = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert 'plaintext' != ciphertext, 'ciphertext is not equal to plaintext'

# Generated at 2022-06-11 09:27:23.007607
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    # ansible_vault.vault_cli module is not available in pytest environment
    # this is the reason why we are doing this import here and not at the file level
    from ansible_vault.vault_cli import VaultLib
    vault = VaultLib(["ansible-vault", "create"])

    plaintext = 'plaintext'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, 'secret')
    assert avu >= plaintext
    assert not avu >= 'plainxtext'
    assert not avu >= 'plaintexy'
    assert not avu >= 'xplaintext'



# Generated at 2022-06-11 09:27:33.117087
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:27:40.478377
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    plaintext = 'hello'
    ciphertext = b'!'

    class FakeVault():
        def decrypt(self, ciphertext, obj=None):
            return plaintext

    vault = FakeVault()
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(ciphertext, vault, 'secret')

    assert not encrypted.__ge__(ciphertext)



# Generated at 2022-06-11 09:27:44.072943
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu >= avu
    assert avu >= 'abcdef'
    assert avu >= 'abc'
    assert not avu >= 'abcdefg'


# Generated at 2022-06-11 09:27:54.141248
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert not (AnsibleVaultEncryptedUnicode('') != AnsibleVaultEncryptedUnicode(''))
    assert AnsibleVaultEncryptedUnicode('') != AnsibleVaultEncryptedUnicode('a')
    assert AnsibleVaultEncryptedUnicode('a') != AnsibleVaultEncryptedUnicode('')
    assert not (AnsibleVaultEncryptedUnicode('a') != AnsibleVaultEncryptedUnicode('a'))
    assert AnsibleVaultEncryptedUnicode('a') != 'a'
    assert AnsibleVaultEncryptedUnicode('') != 'a'
    assert AnsibleVaultEncryptedUnicode('a') != ''
    assert AnsibleVaultEncryptedUnicode('') != ''

# Generated at 2022-06-11 09:27:57.943699
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    c = AnsibleVaultEncryptedUnicode('test')
    c.data = 'test'
    assert c != 'test'
    assert c.__ne__('test')

# Generated at 2022-06-11 09:28:11.058084
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # assert AnsibleVaultEncryptedUnicode('test', vault, 'secret') == 'test'
    print('assert AnsibleVaultEncryptedUnicode(\'test\', vault, \'secret\') == \'test\'')
    print('test', 'test')
    print(AnsibleVaultEncryptedUnicode('test', vault, 'secret') == 'test')
    print()

    # assert AnsibleVaultEncryptedUnicode('test', vault, 'secret') == AnsibleVaultEncryptedUnicode('test', vault, 'secret')
    print('assert AnsibleVaultEncryptedUnicode(\'test\', vault, \'secret\') == AnsibleVaultEncryptedUnicode(\'test\', vault, \'secret\')')
    print('test', 'test')

# Generated at 2022-06-11 09:28:16.356033
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('we', AnsibleVaultLib(), 'password')
    avu2 = AnsibleVaultEncryptedUnicode('ASEKcx', lines=1)
    assert not avu2.is_encrypted()
    avu2.vault = AnsibleVaultLib()
    assert avu1 == avu2


# Generated at 2022-06-11 09:28:24.869188
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    x = AnsibleVaultEncryptedUnicode('abc')
    assert(x >= 'abc')
    assert(x >= AnsibleVaultEncryptedUnicode('abc'))
    assert(AnsibleVaultEncryptedUnicode('abc') >= x)
    assert(x >= 'abd' == False)
    assert(x >= AnsibleVaultEncryptedUnicode('abd') == False)
    assert(AnsibleVaultEncryptedUnicode('abd') >= x == False)


# Generated at 2022-06-11 09:28:33.744747
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib, VaultSecret

    plain_text = 'mytext'
    secret = VaultSecret('mysecret')
    vault = VaultLib(secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plain_text, vault, secret)

    # __ne__
    assert avu.is_encrypted()
    assert avu != plain_text
    avu.vault = None
    assert not avu.is_encrypted()
    assert avu != plain_text
    avu.vault = vault
    assert avu != 'my_other_text'


# Generated at 2022-06-11 09:28:46.574682
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import yaml
    from ansible.parsing import vault
    import os

    # Create test vault
    vault.VaultLib.password = 'test'
    v = vault.VaultLib('test')
    secret = 'hello'

    # Test encrypted
    ciphertext = v.encrypt(secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu.is_encrypted() is True

    # Test not encrypted
    avu = AnsibleVaultEncryptedUnicode(secret)
    assert avu.is_encrypted() is False

    # Test encrypted string in yml file
    # Create test yml file with encrypted string
    test_file = '/tmp/test_AnsibleVaultEncryptedUnicode_is_encrypted.yml'

# Generated at 2022-06-11 09:28:48.899364
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avueu = AnsibleVaultEncryptedUnicode("test")
    assert("test" != avueu)


# Generated at 2022-06-11 09:29:00.489122
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    if _sys.version_info < (2, 7): # Python2.6 does not have assertIsNot()
        return
    avu1 = AnsibleVaultEncryptedUnicode('123')
    avu2 = AnsibleVaultEncryptedUnicode('456')
    avu1.vault = 'fake'
    avu2.vault = 'fake'
    avu1.data = '123'
    avu2.data = '456'
    assert avu1 == '123'
    assert avu2 == '456'
    assert avu1 != '456'
    assert avu2 != '123'
    assert '123' == avu1
    assert '456' == avu2
    assert '123' != avu2
    assert '456' != avu1


# Generated at 2022-06-11 09:29:08.480276
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Python 2.7 uses __getslice__, 3.x uses __getitem__
    # This test is to ensure __getslice__ works as expected on all versions.
    ansible_vault_string = AnsibleVaultEncryptedUnicode(bytes(bytearray([i for i in range(0, 10)])))
    assert ansible_vault_string.__getslice__(2, 6) == ansible_vault_string[2:6]


# unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:29:14.388082
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import unittest

    class TestAnsibleVaultEncryptedUnicode___ne__(unittest.TestCase):
        def setUp(self):
            self.avu = AnsibleVaultEncryptedUnicode("ciphertext")
            self.avu.vault = None

        def test_empty(self):
            self.assertTrue(self.avu.__ne__("not ciphertext"))

        def test_equal(self):
            self.avu.vault = "my vault"
            self.assertFalse(self.avu.__ne__("ciphertext"))

    unittest.main()


# Generated at 2022-06-11 09:29:24.944325
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib()

    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('a_string', vault, 'secret')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('b_string', vault, 'secret')
    assert avu1.__ge__(avu1)
    assert not avu1.__ge__(avu2)
    assert not avu2.__ge__(avu1)
    assert avu2.__ge__(avu2)



# Generated at 2022-06-11 09:29:31.645944
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    vault = None
    secret = ' '
    vu = AnsibleVaultEncryptedUnicode.from_plaintext('a', vault, secret)
    assert vu is not None

    assert vu >= 'a'
    assert vu >= vu
    assert vu >= 'b' == False


# Generated at 2022-06-11 09:29:42.608245
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:29:49.822564
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    sys.stdout = mystdout = StringIO()
    with open("test/yaml/vault_enc_unicode___ne__.yaml") as stream:
        data = yaml.load(stream)
        assert data == "hello"
    assert sys.stdout.getvalue() == ""
    # restore stdout
    sys.stdout = sys.__stdout__


# Generated at 2022-06-11 09:29:57.351275
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    vault = AnsibleVaultLib()
    secret = 'password'
    plaintext = to_text("text")

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert (avu == plaintext)
    # the following is needed for python2, where dict.__eq__ is different from dict.__cmp__
    assert (avu != {'text': plaintext})



# Generated at 2022-06-11 09:30:14.030752
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    from textwrap import dedent
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor

    snippet = dedent(u'''
        ---
        foo: "{{ foo }}"
    ''').strip()

    # Create a vault at encryption version 1 and cipher aes
    vault = VaultLib([], 1, 'aes')

    # Create a vault encrypted file
    ve = VaultEditor(vault, b'secret')
    ve.write_data(snippet)
    ve.save_file('foo.yml')

    # Load vault encrypted file into AnsibleVaultEncryptedUnicode
    with open('foo.yml', 'rb') as f:
        avu = AnsibleVaultEncryptedUnicode(f.read())

    # Set vault

# Generated at 2022-06-11 09:30:24.406608
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    def test1(sec):
        text = b'blah'
        if isinstance(sec, string.Template):
            sec = sec.substitute(password='password')
        avu = AnsibleVaultEncryptedUnicode.from_plaintext(text, vault, sec)
        assert avu.is_encrypted()
        assert avu.data == u'blah'

    def test2(sec):
        text = b'AES256'
        if isinstance(sec, string.Template):
            sec = sec.substitute(password='password')
        avu = AnsibleVaultEncryptedUnicode(text)
        avu.vault = vault
        assert not avu.is_encrypted()


    import vaultlib
    if vaultlib._vault_version == 1:
        vault = vaultlib._v

# Generated at 2022-06-11 09:30:32.988242
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    When comparing an AnsibleVaultEncryptedUnicode with a string
    (ex: "test") the comparison should retuen False if the plaintext
    is "test" and True otherwise.
    """
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext("test", None, "secret")
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext("not test", None, "secret")

    assert "test" != avu1
    assert "not test" != avu2



# Generated at 2022-06-11 09:30:41.076705
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # This is a test case for AnsibleVaultEncryptedUnicode.is_encrypted.
    # Make sure that we get True for an encrypted ansible vault object,
    # and false for an unencrypted object.
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('mysecret')
    # First make sure that is_encrypted works
    # on a non encrypted object.
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu.is_encrypted() is False

    # Now, test on an encrypted ansible vault object
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'mysecret')
    assert avu.is_encrypted() is True


# Generated at 2022-06-11 09:30:53.223985
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # with plaintext produced by vault
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('abc', None, None)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('abc', None, None)
    assert avu1 == avu2
    assert not avu1 != avu2
    # with ciphertext produced by vault
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('abc', None, None)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('abc', None, None)

# Generated at 2022-06-11 09:31:00.180810
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert not avu.__eq__('foo')
    assert not avu.__eq__(b'foo')
    assert not avu.__eq__(str('foo'))
    assert not avu.__eq__(AnsibleVaultEncryptedUnicode('foo'))

    from ansible.parsing.vault import VaultLib
    vault = VaultLib('ansible')
    avu.vault = vault
    assert avu.__eq__('foo')
    assert avu.__eq__(b'foo')
    assert avu.__eq__(str('foo'))
    assert avu.__eq__(AnsibleVaultEncryptedUnicode(vault.encrypt('foo')))

    # Note: the AnsibleV

# Generated at 2022-06-11 09:31:11.513166
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import hashlib

    # test data
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n3353520r68672373h7a7431373268'
    ''' h822238336295h3323777s4444444444444444444444444444444444444444444444444444444444444444\n'''


# Generated at 2022-06-11 09:31:20.943959
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    # If is_encrypted() is called before calling decrypt(),
    # is_encrypted() should return True.
    test_string = VaultLib.encrypt(b'abc', b'123')
    avu = AnsibleVaultEncryptedUnicode(test_string)
    assert avu.is_encrypted() is True

    # If is_encrypted() is called after calling decrypt(),
    # is_encrypted() should return False.
    avu.data = b'abc'
    assert avu.is_encrypted() is False



# Generated at 2022-06-11 09:31:33.331773
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    vault = None
    s = AnsibleVaultEncryptedUnicode('foo', vault, 'secret')
    assert s != 'foo'

    vault = object()
    s = AnsibleVaultEncryptedUnicode('foo', vault, 'secret')
    assert s != 'foo'

    vault = None
    s = AnsibleVaultEncryptedUnicode(to_bytes('foo'), vault, 'secret')
    assert s != to_bytes('foo')

    vault = object()
    s = AnsibleVaultEncryptedUnicode(to_bytes('foo'), vault, 'secret')
    assert s != to_bytes('foo')

    s = AnsibleVaultEncryptedUnicode('foo', vault, 'secret')
    assert s == 'foo'


# Generated at 2022-06-11 09:31:42.327764
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib("ansible")

    clear = 'clear'
    encrypted = vault.encrypt(clear, 'secret')
    ansible_vault_obj = AnsibleVaultEncryptedUnicode(encrypted)
    assert ansible_vault_obj.is_encrypted()
    ansible_vault_obj.vault = vault

    # decrypt
    assert ansible_vault_obj.data == clear
    assert ansible_vault_obj.is_encrypted()

    # encrypt
    ansible_vault_obj.data = clear
    assert not ansible_vault_obj.is_encrypted()


# Generated at 2022-06-11 09:31:56.815635
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:32:04.112290
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    #  Test if AnsibleVaultEncryptedUnicode returns the same result as Unicode
    #  when using __getslice__.
    avu = AnsibleVaultEncryptedUnicode('test')
    assert to_native(avu.data[:]) == to_native(avu[:]) == to_native('test')
    assert to_native(avu.data[1:]) == to_native(avu[1:]) == to_native('est')
    assert to_native(avu.data[:1]) == to_native(avu[:1]) == to_native('t')
    assert to_native(avu.data[1:3]) == to_native(avu[1:3]) == to_native('es')

    assert to_native(avu.data[:2]) == to_

# Generated at 2022-06-11 09:32:11.814787
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    vault = get_vault_instance()
    first_text = 'test1'
    second_text = 'test2'

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(first_text, vault, vault.secrets['_ansible_vault'])
    assert avu.data == first_text
    assert avu.__eq__(first_text)

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(first_text, vault, vault.secrets['_ansible_vault'])
    assert avu.data == first_text
    assert not avu.__eq__(second_text)



# Generated at 2022-06-11 09:32:16.678178
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    vault = None
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("test1", vault, "test2")
    avu.vault = None
    assert avu.__eq__("test1") == True
    assert avu.__eq__("test2") == False


# Generated at 2022-06-11 09:32:26.710686
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

    data = 'foo\n'
    key = 'mysecret'
    ciphertext = vault.encrypt(data, key)

    if isinstance(ciphertext, bytes):
        ciphertext = ciphertext.decode()

    avu1 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu1.vault = vault

    avu2 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu2.vault = vault

    avu3 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu3.vault = vault

    assert avu1 == avu1.data
    assert avu1 == avu1
    assert avu1 != avu2


# Generated at 2022-06-11 09:32:34.418655
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    avu2 = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    # test that equals works with same class
    assert avu == avu2
    # test that equals works with different class and different string
    assert not avu == '$ANSIBLE_VAULT;1.1;AES256'
    # test that equals works with different class and same string
    assert not avu == '$ANSIBLE_VAULT;1.2;AES256'


# Generated at 2022-06-11 09:32:44.273787
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    secret = 'secret'
    vault = None

# Generated at 2022-06-11 09:32:52.274148
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    """
    Test that AnsibleVaultEncryptedUnicode.__eq__ returns True in the following cases:
    - Other is unicode and is equal to the data of the AnsibleVaultEncryptedUnicode object.
    - Other is another AnsibleVaultEncryptedUnicode object that is equal to the AnsibleVaultEncryptedUnicode object.

    Test that AnsibleVaultEncryptedUnicode.__eq__ returns False in the following cases:
    - Other is not unicode and is not equal to the data of the AnsibleVaultEncryptedUnicode object.
    - Other is another AnsibleVaultEncryptedUnicode object that is not equal to the AnsibleVaultEncryptedUnicode object.
    """

# Generated at 2022-06-11 09:32:57.803293
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # make a fake vault class that always decrypts to the same data
    class FakeVault:
        def decrypt(self, ciphertext, obj):
            return b"decrypted"
        def is_encrypted(self, ciphertext):
            return True

    class FakeVault1:
        def decrypt(self, ciphertext, obj):
            return b"decrypted1"
        def is_encrypted(self, ciphertext):
            return True

    avu1 = AnsibleVaultEncryptedUnicode(b'ciphertext')
    avu1.vault = FakeVault()
    assert avu1 != b"ciphe"
    assert avu1 != b"decrypted"
    assert avu1 != "decrypted"
    assert avu1 != u"decrypted"

    avu2 = AnsibleVaultEncryptedUn

# Generated at 2022-06-11 09:33:07.857999
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test123')
    test_txt = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test123')
    real_txt = AnsibleVaultEncryptedUnicode.from_plaintext('real', vault, 'test123')
    assert (test_txt != real_txt)
    assert (real_txt != test_txt)

# Test that AnsibleVaultEncryptedUnicode doesn't log the values of the class when
# its returned as part of an exception.

# Generated at 2022-06-11 09:33:23.099555
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test case: vault is not set
    # The method should return False
    avu = AnsibleVaultEncryptedUnicode('encrypted_data')
    assert avu == 'encrypted_data' == False
    # End of test case


# Generated at 2022-06-11 09:33:35.115255
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    '''
    Test case for method __getslice__ of class AnsibleVaultEncryptedUnicode
    '''
    assert AnsibleVaultEncryptedUnicode.__getslice__(AnsibleVaultEncryptedUnicode(u'foo'), 0, -1) == u'fo'
    assert AnsibleVaultEncryptedUnicode.__getslice__(AnsibleVaultEncryptedUnicode(u'foo'), 0, 10) == u'foo'
    assert AnsibleVaultEncryptedUnicode.__getslice__(AnsibleVaultEncryptedUnicode(u'foo'), -10, 10) == u'foo'

# Generated at 2022-06-11 09:33:44.592684
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    s = b'abc'
    t = b'abc'
    assert (s != t)
    s = b'abc'
    t = b'ABC'
    assert (s != t)
    s = b'abc'
    t = b'abcd'
    assert (s != t)
    s = b'abcd'
    t = b'abc'
    assert (s != t)
    s = AnsibleVaultEncryptedString(b'abc')
    t = b'abc'
    assert (s != t)
    s = b'abc'
    t = AnsibleVaultEncryptedString(b'abc')
    assert (s != t)
    s = AnsibleVaultEncryptedString(b'abc')
    t = AnsibleVaultEncryptedString(b'abc')

# Generated at 2022-06-11 09:33:54.907388
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    vault_password = b'password'

# Generated at 2022-06-11 09:34:04.106113
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    passphrase = 'test'
    secret = 'secret'

    vault = VaultLib(passphrase)

    # Test for non-encrypted
    plain = AnsibleUnicode(secret)
    assert plain.is_encrypted() == False

    # Test for encrypted
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(secret, vault, passphrase)
    assert encrypted.is_encrypted() == True

    encrypted2 = AnsibleVaultEncryptedUnicode.from_plaintext(secret, vault, passphrase)
    assert encrypted2.is_encrypted() == True

    # Test for equality
    assert encrypted == encrypted2



# Generated at 2022-06-11 09:34:08.353025
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    test_string = 'AnsibleVaultEncryptedUnicode'
    avueu = AnsibleVaultEncryptedUnicode.from_plaintext(test_string, VaultLib(password='password'), 'password')
    assert avueu.is_encrypted() is True


# Generated at 2022-06-11 09:34:18.038213
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    '''Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode'''
    # this test is here because of a bug in python 2.6.8 which segfaults
    # if the module importing this code is run as a unit test
    # ref: http://bugs.python.org/issue4866
    # NOTE: this test is useless and should be removed once 2.6.X is no longer supported
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-11 09:34:25.456340
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu1 = AnsibleVaultEncryptedUnicode('1')
    avu2 = AnsibleVaultEncryptedUnicode('2')

    assert avu1 == '1'
    assert avu2 != '1'

    avu1.vault = None
    avu2.vault = None

    assert avu1 == '1'
    assert avu2 != '1'

    avu1.vault = True
    avu2.vault = False

    assert avu1 == '1'
    assert avu2 != '1'



# Generated at 2022-06-11 09:34:28.804928
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu = AnsibleVaultEncryptedUnicode('ansible')
    avu.vault = 'foo'
    result = avu.__eq__('ansible')
    assert result == True


# Generated at 2022-06-11 09:34:34.826592
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import vaultlib

    s = AnsibleVaultEncryptedUnicode('foo')
    assert s.is_encrypted() == False

    s.vault = vaultlib.VaultLib('foobar')
    ciphertext = s.vault.encrypt('foo')
    s2 = AnsibleVaultEncryptedUnicode(ciphertext)
    assert s2.is_encrypted() == True



# Generated at 2022-06-11 09:34:54.658047
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Check1: If self.vault is none, then the string is not decrypted, and a false is returned
    avu = AnsibleVaultEncryptedUnicode('encrypted_string')
    assert avu.__ne__('encrypted_string') == True

    # Check2: If self.vault is not none, then the string is decrypted, and a comparison is performed with the decrypted string
    from ansible.parsing.vault import VaultLib
    vault_password = 'ansible'
    vault = VaultLib(vault_password)

    # Check2.1: For the case when compared object is a string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test_string_1', vault, vault_password)
    assert avu.__ne__('test_string_1') == False

   

# Generated at 2022-06-11 09:35:02.908468
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import unittest
    class Test__eq__(unittest.TestCase):
        def setUp(self):
            import getpass
            self.secret = getpass.getpass(prompt="Enter vault passphrase:")

        def test_encrypted_none(self):
            avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, self.secret)
            self.assertFalse(avu.__eq__(None))

        def test_encrypted_equals(self):
            avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, self.secret)
            self.assertTrue(avu.__eq__('foo'))

        def test_encrypted_non_equals(self):
            avu = AnsibleVaultEncryptedUnicode.from_plaintext

# Generated at 2022-06-11 09:35:06.725225
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    class Vault:
        @staticmethod
        def is_encrypted(s):
            return False
    o = AnsibleVaultEncryptedUnicode('')
    o.vault = Vault
    assert not o.is_encrypted()
    o.vault = None
    assert not o.is_encrypted()



# Generated at 2022-06-11 09:35:14.361528
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import unittest
    import ansible.parsing.vault

    class AnsibleVaultEncryptedUnicode_Test(unittest.TestCase):

        def test___ne__(self):
            self.assertEqual(AnsibleVaultEncryptedUnicode('ciphertext').__ne__(AnsibleVaultEncryptedUnicode('ciphertext')),False)
            self.assertEqual(AnsibleVaultEncryptedUnicode('ciphertext').__ne__('ciphertext'),False)
            self.assertEqual(AnsibleVaultEncryptedUnicode('ciphertext').__ne__(AnsibleVaultEncryptedUnicode('ciphertext2')),True)

# Generated at 2022-06-11 09:35:21.609129
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Check return value is not equal
    obj = AnsibleVaultEncryptedUnicode('ABC')
    obj.vault = 1
    value = AnsibleVaultEncryptedUnicode.__ne__(obj, 'ABC')
    if not value:
        raise AssertionError('__ne__() return value is equal')
    # Check return value is equal
    obj = AnsibleVaultEncryptedUnicode('ABC')
    obj.vault = None
    value = AnsibleVaultEncryptedUnicode.__ne__(obj, 'ABC')
    if value:
        raise AssertionError('__ne__() return value is not equal')


# Generated at 2022-06-11 09:35:26.311234
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():

    secret = b'helloyouyou'

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(b'Hello world', vault=None, secret=secret)

    assert avu.__getslice__(0, 3) == b'Hel'
    assert avu.__getslice__(3) == 'lo world'
    assert avu.__getslice__() == 'Hello world'



# Generated at 2022-06-11 09:35:31.130455
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    a = dict()
    a['b'] = 'hello'
    a['c'] = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault=None, secret='hello')
    assert a['b'] == a['c']
    assert a.get('b') == a.get('c')

test_AnsibleVaultEncryptedUnicode___eq__()

