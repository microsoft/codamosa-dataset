

# Generated at 2022-06-11 09:25:51.326730
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.plugins.vault as vault
    vault_obj = vault.VaultLib('secret')
    # Create two objects and compare them
    a = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault_obj, 'secret')
    b = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault_obj, 'secret')
    assert a == b
    # Create one object, compare it to a string
    a = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault_obj, 'secret')
    b = 'hello'
    assert a == b
    # Create one object, compare it to an AnsibleVaultEncryptedUnicode object that
    # is not encrypted

# Generated at 2022-06-11 09:25:53.736548
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    ''' test for method __le__ of class AnsibleVaultEncryptedUnicode '''
    assert True


# Generated at 2022-06-11 09:26:04.244141
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    vault_pass = VaultSecret("foobar")
    vault = VaultLib(vault_pass)
    foo = AnsibleVaultEncryptedUnicode.from_plaintext("foo", vault, vault_pass)
    bar = AnsibleVaultEncryptedUnicode.from_plaintext("bar", vault, vault_pass)
    f = foo == bar
    assert f is False
    g = foo == foo
    assert g is True
    h = foo >= foo
    assert h is True
    i = foo >= bar
    assert i is True


# Generated at 2022-06-11 09:26:13.263696
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    assert (AnsibleVaultEncryptedUnicode('a') >= AnsibleVaultEncryptedUnicode('a')
            and AnsibleVaultEncryptedUnicode('b') >= AnsibleVaultEncryptedUnicode('a')
            and AnsibleVaultEncryptedUnicode('a') >= 'a'
            and AnsibleVaultEncryptedUnicode('b') >= 'a')
    assert not (AnsibleVaultEncryptedUnicode('a') >= AnsibleVaultEncryptedUnicode('b')
                or AnsibleVaultEncryptedUnicode('b') >= 'c')


# Generated at 2022-06-11 09:26:21.455519
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode("123")
    print(ansible_vault_encrypted_unicode.__getslice__(0, 5))
    print(ansible_vault_encrypted_unicode.__getslice__(1, 5))
    print(ansible_vault_encrypted_unicode.__getslice__(-1, -1))
    print(ansible_vault_encrypted_unicode.__getslice__(-1, -3))
    print(ansible_vault_encrypted_unicode.__getslice__(1, -3))
    print(ansible_vault_encrypted_unicode.__getslice__(-1, 5))

# Generated at 2022-06-11 09:26:27.267188
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    plaintext = b'hello world'
    password = b'password'
    vault = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, password)
    assert vault == b'hello world'
    assert vault != b'hello worlds'


# Generated at 2022-06-11 09:26:40.109648
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.find('t') == 0
    assert avu.find('te') == 0
    assert avu.find('st') == 2
    assert avu.find('e') == 1
    assert avu.find('s') == 2
    assert avu.find('') == 0
    assert avu.find('ttt') == -1
    assert avu.find('tee') == -1
    assert avu.find('eet') == -1
    assert avu.find('ee') == -1
    assert avu.find('est') == -1
    assert avu.find('et') == -1
    assert avu.find('tet') == -1
    assert avu.find('tt') == -1

# Generated at 2022-06-11 09:26:49.537382
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib(password='test')
    ciphertext = vault.encrypt(b'hello world')

    # encrypted
    a = AnsibleVaultEncryptedUnicode(ciphertext)
    a.vault = vault
    assert a.is_encrypted() == True

    # encrypted, but not vault:
    a = AnsibleVaultEncryptedUnicode(ciphertext)
    assert a.is_encrypted() == True

    # not encrypted, but vault:
    a = AnsibleVaultEncryptedUnicode(b'hello world')
    a.vault = vault
    assert a.is_encrypted() == False

    # not encrypted and not vault:

# Generated at 2022-06-11 09:27:01.550685
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Test with different values of self.data and other.data
    test_cases = [
        {'self_data': 'aaa', 'other_data': 'aaa', 'expected': False},
        {'self_data': 'aaa', 'other_data': 'aab', 'expected': False},
        {'self_data': 'aab', 'other_data': 'aaa', 'expected': True},
        {'self_data': 'aab', 'other_data': 'aaba', 'expected': False},
        {'self_data': 'aaba', 'other_data': 'aab', 'expected': True},
        {'self_data': '', 'other_data': '', 'expected': False},
    ]


# Generated at 2022-06-11 09:27:07.563013
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    aveu = AnsibleVaultEncryptedUnicode('foo')
    assert aveu == 'foo'

    aveu.data = 'bar'
    assert aveu == 'bar'

    aveu2 = AnsibleVaultEncryptedUnicode('foo')
    res = aveu >= aveu2
    assert res is False

    res = aveu >= 'foo'
    assert res is False


# Generated at 2022-06-11 09:27:16.749823
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('abd')
    assert avu2 > avu1
    assert avu1 < avu2
    assert avu2 != avu1
    assert avu1 == 'abc'


# Generated at 2022-06-11 09:27:28.842298
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault = VaultLib([], 1)
    secret = VaultSecret('secret')
    correct_secret = VaultSecret('secret')
    wrong_secret = VaultSecret('wrong')
    test_string = u'test_string'
    encrypted_test_string = AnsibleVaultEncryptedUnicode.from_plaintext(test_string, vault, secret)

    assert not AnsibleVaultEncryptedUnicode(test_string).is_encrypted()
    assert encrypted_test_string.is_encrypted()
    assert encrypted_test_string.decrypt(correct_secret) == test_string
    assert encrypted_test_string.decrypt(wrong_secret) != test_string
    assert encrypted_test_string.decrypt

# Generated at 2022-06-11 09:27:35.181275
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    ''' This unit test is for the method rfind of class AnsibleVaultEncryptedUnicode.
        The method searches for the last occurrence of a substring in AnsibleVaultEncryptedUnicode.
        The test case is to check the string from its start to the end of the string.
    '''
    # Create a string for testing
    example_string = AnsibleVaultEncryptedUnicode('This is an AnsibleVaultEncryptedUnicode object')
    # Calculate the string length
    str_len = len('This is an AnsibleVaultEncryptedUnicode object')
    # Check if the return value is the same as the string length
    assert example_string.rfind(AnsibleVaultEncryptedUnicode('ob')) == str_len - 2



# Generated at 2022-06-11 09:27:47.777688
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    text = AnsibleVaultEncryptedUnicode("aaa")
    # Test 1.1 (check rfind without any argument)
    assert text.rfind() == 3
    # Test 1.2 (check rfind with the "sub" argument)
    assert text.rfind("a") == 2
    assert text.rfind("b") == -1
    assert text.rfind("aa") == 0
    # Test 1.3 (check rfind with the "start" argument)
    assert text.rfind("a", 1) == 1
    assert text.rfind("a", 3) == 2
    assert text.rfind("a", 0) == 0
    # Test 1.4 (check rfind with the "end" argument)
    assert text.rfind("a", 0, 2) == 0

# Generated at 2022-06-11 09:27:56.172986
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # test 1
    avu1 = AnsibleVaultEncryptedUnicode("Hallo")
    avu2 = AnsibleVaultEncryptedUnicode("Hallo")
    assert avu1 is not avu2
    assert avu1 != avu2
    assert avu2 != avu1

    # test 2
    avu3 = AnsibleVaultEncryptedUnicode("Welt")
    avu4 = AnsibleVaultEncryptedUnicode("Welt")
    assert avu3 is not avu4
    assert avu3 != avu4
    assert avu4 != avu3

    # should be equal
    assert avu1 is not avu4
    assert not avu1 == avu4
    assert not avu4 == avu1
    assert avu1 != avu4

# Generated at 2022-06-11 09:28:01.202015
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    The __ne__ test
    """
    avueu1 = AnsibleVaultEncryptedUnicode("ABC")
    avueu2 = AnsibleVaultEncryptedUnicode("ABC")
    assert avueu1 != avueu2

# Generated at 2022-06-11 09:28:05.686352
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    seq = 'mystring'
    avu = AnsibleVaultEncryptedUnicode(seq)
    assert avu.is_encrypted() is False


# Unit test AnsibleVaultEncryptedUnicode.from_plaintext

# Generated at 2022-06-11 09:28:16.470219
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    s_ascii = AnsibleVaultEncryptedUnicode('abc')
    s_utf8 = AnsibleVaultEncryptedUnicode('ábc')
    s_utf8_2 = AnsibleVaultEncryptedUnicode('ábc')

    assert s_ascii >= 'abc'
    assert 'abc' >= s_ascii
    assert s_ascii >= s_ascii
    assert not s_ascii >= 'abcd'
    assert not s_ascii >= 'xyz'
    assert not s_ascii >= 'ábc'
    assert not s_ascii >= s_utf8

    assert s_utf8 >= 'ábc'
    assert s_utf8 >= s_utf8_2
    assert 'ábc' >= s_utf8
    assert not s_

# Generated at 2022-06-11 09:28:29.076220
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:28:34.220063
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password='test',
                loader=None,
                method='sha256')
    u = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert u.find('test') == 0
    assert u.find('tes') == 0
    assert u.find('est') == 1
    assert u.find('es') == 1
    assert u.find('es', 1) == 1
    assert u.find('es', 2) == -1
    assert u.find('es', 0, 1) == -1


# Generated at 2022-06-11 09:28:41.770181
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test for ciphertext not equal to given string and equal to given string
    avu = AnsibleVaultEncryptedUnicode('ciphertext')

    assert avu != "random string"
    assert avu == "ciphertext"

# Generated at 2022-06-11 09:28:51.459627
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    # test if find method from python string class is overriden successfully in
    # AnsibleVaultEncryptedUnicode class
    avu = AnsibleVaultEncryptedUnicode('this.is.a.test')
    avu.find('is')
    assert avu.find('is') == avu.data.find('is')

    avu = AnsibleVaultEncryptedUnicode('this.is.a.test')
    avu.find('is', 4)
    assert avu.find('is', 4) == avu.data.find('is', 4)

    avu = AnsibleVaultEncryptedUnicode('this.is.a.test')
    avu.find('is', 4, 7)

# Generated at 2022-06-11 09:29:02.604567
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    class DummyVault(object):
        def is_encrypted(self, data):
            return '__ENCRYPTED__' in data

        def decrypt(self, ciphertext):
            return ciphertext.replace('__ENCRYPTED__', '')

    avu_1 = AnsibleVaultEncryptedUnicode('foo__ENCRYPTED__')
    avu_1.vault = DummyVault()

    result = {
        (avu_1, avu_1): False,
        (avu_1, 'foo'): False,
        ('foo', avu_1): True,
        (avu_1, 'bar'): False,
        ('bar', avu_1): True,
    }


# Generated at 2022-06-11 09:29:09.923964
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.2;AES256;test\n324234782374982347234823423423423423434\n3423423482342342342342347234723472342347\n2342348234782347234723472348234234234723\n4823472347234823723472347234723782374823\n7823748237482374283472347234723472347234').is_encrypted()


# Generated at 2022-06-11 09:29:24.285447
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret = 'plaintext password'
    secret_vault = VaultLib(password=secret, vault_password_file=None)

    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256;user\n' + secret_vault.encrypt(b'plaintext message') + b'\n'

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = secret_vault

    assert avu.is_encrypted() == True

    plaintext = avu.data

    avu_plaintext = AnsibleVaultEncryptedUnicode(plaintext)


# Generated at 2022-06-11 09:29:32.745579
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode('123') != AnsibleVaultEncryptedUnicode('124')


## -------------- AnsibleVaultEncryptedUnicode Dumper and Loader -------------- ##
# Below are the loader and dumper for the custom yaml tag !vault
# Exceptions are not caught/handled in these, they are handled and logged
# in the calling methods.


# Generated at 2022-06-11 09:29:43.127429
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    # FIXME: this should be in the test code
    vault_file  = '/tmp/vault-password-file'
    vault_pass1 = 'secret1'
    vault_pass2 = 'secret2'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('ansible', VaultLib(vault_pass1), vault_pass1)
    with open(vault_file, 'wt') as f:
        f.write(vault_pass2)

    # case 1: use the same password for encrypting and decrypting
    err = None
    try:
        assert avu.vault.is_encrypted(avu.data)
        assert avu.is_encrypted()
    except Exception as e:
        err = e

# Generated at 2022-06-11 09:29:55.461238
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    import unittest
    import textwrap
    class TestAnsibleVaultEncryptedUnicode___gt__(unittest.TestCase):
        def test_equal(self):
            ansible_vue = AnsibleVaultEncryptedUnicode.from_plaintext('abcd\nabcd', None, None)
            self.assertFalse(textwrap.dedent('''
                abcd
                abcd''') > ansible_vue)
        def test_less(self):
            ansible_vue = AnsibleVaultEncryptedUnicode.from_plaintext('abcd\nabcd', None, None)
            self.assertFalse(textwrap.dedent('''
                abcd
                abc''') > ansible_vue)
        def test_greater(self):
            ansible

# Generated at 2022-06-11 09:30:06.692604
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    # setup an existing string
    existing = to_unicode(b"sometext", errors='surrogate_or_strict')
    avue = AnsibleVaultEncryptedUnicode.from_plaintext(existing, None, None)
    # test correct find
    sub = to_unicode(b"t", errors='surrogate_or_strict')
    assert avue.find(sub) == 2
    assert avue.find(sub, start=1) == 2
    assert avue.find(sub, start=1, end=9) == 2
    assert avue.find(sub, start=1, end=3) == 2

    sub = to_unicode(b"s")
    assert avue.find(sub) == 0
    assert avue.find(sub, start=0) == 0
   

# Generated at 2022-06-11 09:30:11.987185
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    Check that __ne__()  method of class AnsibleVaultEncryptedUnicode correctly
    returns True or False.
    """
    s1 = AnsibleVaultEncryptedUnicode("abc")
    s2 = s1
    s3 = AnsibleVaultEncryptedUnicode("abc")
    assert (s1 != s2) is False
    assert (s1 != s3) is False


# Generated at 2022-06-11 09:30:27.549526
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    class MockVault:
        def __init__(self, secret):
            self.secret = secret

        def encrypt(self, plaintext, secret):
            return "encrypted"

        def decrypt(self, ciphertext, obj):
            if self.secret == '':
                raise Exception()
            return self.secret

        def is_encrypted(self, plaintext):
            return False

    def test(plaintext, sub, start, end, secret, expected):
        mockvault = MockVault(secret)
        cipher_text = AnsibleVaultEncryptedUnicode.from_plaintext(
            plaintext,
            mockvault,
            secret
        )

        # validate
        assert cipher_text.data == expected, "cipher_text.data: {}".format(cipher_text.data)

        result = cipher_text

# Generated at 2022-06-11 09:30:38.101516
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avue_u = AnsibleVaultEncryptedUnicode(ciphertext=u"x\xa4\x912\x99\x1a\x1b2\x0f\x84\n")
    assert avue_u != AnsibleVaultEncryptedUnicode(ciphertext=u"x\xa4\x912\x99\x1a\x1b2\x0f\x84\n")
    assert avue_u == AnsibleVaultEncryptedUnicode(ciphertext=u"x\xa4\x912\x99\x1a\x1b2\x0f\x84\n")
    assert avue_u != u"y\xf0\x04\x1bx\x19\xef\x9c\xa6\x18"

# Generated at 2022-06-11 09:30:50.168371
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib, VaultSecret

    if VaultLib.yaml is None:
        VaultLib.yaml = yaml
    vault = VaultLib(VaultSecret('test'))
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('mydata', vault, 'test')
    assert avu.is_encrypted()

    avu_bytes = AnsibleVaultEncryptedUnicode(avu._ciphertext)
    assert avu_bytes.is_encrypted()

    avu_bytes._ciphertext = 'mydata'
    assert not avu_bytes.is_encrypted()

    avu_bytes._ciphertext = '{plain}'
    assert not avu_bytes.is_encrypted()


# Generated at 2022-06-11 09:30:55.022479
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    secret = 'foo'
    aveu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault=None, secret=secret)
    aveu.data = 'test'
    assert aveu.find('t') == 0

if __name__ == "__main__":
    test_AnsibleVaultEncryptedUnicode_find()

# Generated at 2022-06-11 09:31:05.727279
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    class test_vault:
        def __init__(self):
            self.sub_method_call_count = 0

        def decrypt(self, encrypted_string, obj):
            self.sub_method_call_count += 1
            return "this is a test string"

    vault = test_vault()
    ciphertext = "this is the encrypted string"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("this is a test string", vault, "secret")
    assert 4 == avu.find("is")
    assert 4 == vault.sub_method_call_count
    # Check that we do not try to decrypt with a different ciphertext
    assert -1 == avu.find("is", ciphertext="test")
    assert 4 == vault.sub_method_call_count

    # Check that we do not

# Generated at 2022-06-11 09:31:10.262223
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    '''
    This should run without any exception
    '''
    try:
        a = AnsibleVaultEncryptedUnicode('this is a text')
        a1 = AnsibleVaultEncryptedUnicode('this is a text')
        assert a == a1
    except:
        raise


# Generated at 2022-06-11 09:31:15.919110
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import vaultlib

    seq = 'MY SECRET'
    secret = 'mypassword'

    vault = vaultlib.VaultLib(secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu.is_encrypted() == True

    seq = 'vault | AES256'
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu2.is_encrypted() == False


# Generated at 2022-06-11 09:31:20.534277
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    a = AnsibleVaultEncryptedUnicode("foo")
    b = AnsibleVaultEncryptedUnicode("bar")
    assert a != b
    assert b != a

# vim: set ts=4 sw=4 et:

# Generated at 2022-06-11 09:31:22.752718
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode('bar') == 'bar'


# Generated at 2022-06-11 09:31:34.429795
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import vault
    import sys

    # Test is_encrypted() for a valid vault
    secret = vault.get_vault_password(ask_vault_pass=False)
    vault_text=u"$ANSIBLE_VAULT;1.1;AES256"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(vault_text, vault, secret)
    assert avu.is_encrypted()

    # Test is_encrypted() for an invalid vault
    vault_text=u"$ANSIBLE_VAULT;1.0;AES256"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(vault_text, vault, secret)
    assert avu.is_encrypted()

    # Test is_encrypted() for a valid vault, with a wrong secret
    secret = vault

# Generated at 2022-06-11 09:31:47.363968
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ciphertext = "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;ansible_collections_michael_dehaan_core_0\n          63656435373864393066646562366265656361356439316631393638356262663463636238613235\n          333866313438343964633166383639336536336561306330366565363938360a\n          63646232306639326334343736333937666637633161346262633861316537316564353739336532\n          63363736653964356565643739626261323538643837653130363635366337\n          "
    avu = AnsibleVaultEncrypted

# Generated at 2022-06-11 09:31:50.765056
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.vault import VaultLib

    # Default vault object is not encrypted
    avu = AnsibleVaultEncryptedUnicode('my secret')
    assert not avu.is_encrypted()

    # We have to provide a vault object
    avu.vault = VaultLib('password', 0)
    assert avu.is_encrypted()

    # Test also with a custom cipher
    avu.vault.set_cipher('AES256')
    assert avu.is_encrypted()



# Generated at 2022-06-11 09:31:57.069330
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    class AnsibleVaultDummyTest():
        pass

    #  data
    data1 = 'data1'
    data2 = 'data2'

    # avu1 (AnsibleVaultEncryptedUnicode)
    avu1 = AnsibleVaultEncryptedUnicode(data1)
    avu1.vault = AnsibleVaultDummyTest()

    # avu2 (AnsibleVaultEncryptedUnicode) is !encrypted
    avu2 = AnsibleVaultEncryptedUnicode(data1)

    # avu3 (AnsibleVaultEncryptedUnicode) is !encrypted
    avu3 = AnsibleVaultEncryptedUnicode(data2)

    # avu4 (AnsibleVaultEncryptedUnicode)
    avu4 = AnsibleVaultEnc

# Generated at 2022-06-11 09:32:04.584651
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    # check if the method returns the correct value for
    # a few different cases
    assert AnsibleVaultEncryptedUnicode("test").__ne__("test")

    from ansible.parsing.vault import VaultLib
    vault1 = VaultLib([])
    vault1.password = "123"
    secret1 = vault1.secrets[0]
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext("test", vault1, secret1)
    assert avu1.__ne__("test")

    vault2 = VaultLib([])
    vault2.password = "123"
    secret2 = vault2.secrets[0]
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext("test", vault2, secret2)
    assert avu2.__ne__

# Generated at 2022-06-11 09:32:09.905932
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    '''
    The method find of class AnsibleVaultEncryptedUnicode doesn't raise errors when
    the parameter sub is a AnsibleVaultEncryptedUnicode object
    '''
    vault_str = AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None)
    assert isinstance(vault_str.find(vault_str), int)



# Generated at 2022-06-11 09:32:20.383858
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:32:23.752366
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    # Given
    target = AnsibleVaultEncryptedUnicode(b'aabbccddeeffgghhiijj')
    # When
    actual = target.find(b'hi')
    # Then
    assert actual == 14


# Generated at 2022-06-11 09:32:31.380967
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault = VaultLib([])

    # Check that the encrypted string is not decrypted
    if vault:
        secret = 'secret'
        plaintext = 'Hello World'

        ciphertext = vault.encrypt(plaintext, secret)
        avu = AnsibleVaultEncryptedUnicode(ciphertext)
        avu.vault = vault
        assert avu.is_encrypted() is True

        # decrypt and test plaintext
        decrypted = vault.decrypt(ciphertext, secret)
        assert decrypted == plaintext

        # loader test

# Generated at 2022-06-11 09:32:38.003747
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Setup the vault instance, and register it
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError
    secret_key = to_bytes('test')
    vault = VaultLib(password=secret_key)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(to_bytes('my_string'), vault, secret_key)
    assert avu == 'my_string'
    assert 'my_string' == avu


# Generated at 2022-06-11 09:32:46.718024
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert str("hallo") == AnsibleVaultEncryptedUnicode("hallo")
    assert str("hallo") != AnsibleVaultEncryptedUnicode("hallo")
    assert AnsibleVaultEncryptedUnicode("hallo") == "hallo"
    assert AnsibleVaultEncryptedUnicode("halle") == AnsibleVaultEncryptedUnicode("halle")
    assert AnsibleVaultEncryptedUnicode("halle") != AnsibleVaultEncryptedUnicode("halleo")
    assert "halle" == AnsibleVaultEncryptedUnicode("halle")
    assert "halle" != AnsibleVaultEncryptedUnicode("halleo")



# Generated at 2022-06-11 09:32:53.512185
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('123')
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext('secret', vault, '123')
    assert unicode(encrypted) == u'secret'
    assert encrypted == u'secret'
    assert not encrypted == u'foo'

# Generated at 2022-06-11 09:33:07.012506
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    print("Testing AnsibleVaultEncryptedUnicode.is_encrypted()")
    passphrase = b'password'
    vault = vaultlib.VaultLib(passphrase)

    # Test 1: empty input
    data = u''
    encrypted_data = vault.encrypt(data, passphrase)
    avu = AnsibleVaultEncryptedUnicode(encrypted_data)
    avu.vault = vault
    if not avu.is_encrypted():
        print("Test 1 FAILED: expected is_encrypted() to return True")
        return False

    # Test 2: non empty input
    data = u'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(data, vault, passphrase)

# Generated at 2022-06-11 09:33:18.124010
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """Test AnsibleVaultEncryptedUnicode.__ne__()."""

    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.parsing.vault import VaultLib

    plaintext = b'Some text that is encrypted'
    plaintext_unicode = to_text(plaintext, errors='surrogate_or_strict')

    # make a temp directory for the vault secrets
    secrets_dir = mkdtemp()


# Generated at 2022-06-11 09:33:23.193589
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abc123', vault, secret)
    assert avu.__ne__('abc123') == False
    assert avu.__ne__('abc124') == True


# Generated at 2022-06-11 09:33:33.612616
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    import os

    # Create a VaultLib object
    vault_password = '12345'
    vault_id = '1'
    vault_path = os.path.join(os.path.dirname(__file__), 'data/password')
    vault_ob = VaultLib(vault_password, vault_id, False, None)

    # Create a AnsibleVaultEncryptedUnicode object
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('hello world', vault=vault_ob, secret=vault_password)

    result = avu1 == 'hello world'
    assert result == True


# Generated at 2022-06-11 09:33:37.536197
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ciphertext = 'ansible-vault encrypt_string "foo"'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert not (avu.__ne__('foo')) and not (avu != 'foo')

# Generated at 2022-06-11 09:33:46.182145
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    # test data values to use when running the test

# Generated at 2022-06-11 09:33:52.052301
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    """Should return True if data atrribute is equal to other"""
    # A string
    avu = AnsibleVaultEncryptedUnicode('password')
    assert avu.__eq__('password')

    # A AnsibleVaultEncryptedUnicode
    avu1 = AnsibleVaultEncryptedUnicode('password')
    avu2 = AnsibleVaultEncryptedUnicode('password')
    assert avu1.__eq__(avu2)


# Generated at 2022-06-11 09:34:02.276045
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vaultlib
    import textwrap

    secret = 'password'
    vault = vaultlib.VaultLib(secret=secret)

    # Test 1: This breaks vault, do not define it, we cannot satisfy this
    # Test that when the object is not encrypted, which is the same as the other object is encrypted.
    # The assertion error is for the __ne__ function.
    # avu = AnsibleVaultEncryptedUnicode("plaintext")
    # other = AnsibleVaultEncryptedUnicode("ciphertext").from_plaintext("plaintext", vault, secret)
    # assert (avu == other)
    # assert (avu is not other)

    # Test 2: Test that when both objects are not encrypted, but one is a regular unicode string.
    avu = Ansible

# Generated at 2022-06-11 09:34:06.009465
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    aveu = AnsibleVaultEncryptedUnicode('foo')
    assert aveu != 'foo'

if __name__ == '__main__':
    test_AnsibleVaultEncryptedUnicode___ne__()
    print('All tests passed')

# Generated at 2022-06-11 09:34:12.361907
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode(123)
    assert avu.__ne__(123) is True
    assert avu.__ne__(321) is False
    assert avu.__ne__('123') is False

# Generated at 2022-06-11 09:34:22.803035
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    import os
    import tempfile

    try:
        # Python 3.4+
        from pathlib import Path
    except ImportError:
        from pathlib2 import Path

    def tmp_path(filename):
        return Path(tmpdir).joinpath(filename)

    # Create temp dir, and write key as a file.
    tmpdir = tempfile.TemporaryDirectory().name
    key1 = VaultLib('password1')._create_key()
    key2 = VaultLib('password2')._create_key()
    kf_path1 = tmp_path('keyfile1')
    kf_path1.write_bytes(key1)
    kf_path2 = tmp_path('keyfile2')
    kf_path2.write_bytes(key2)

# Generated at 2022-06-11 09:34:31.149333
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

    plain_text = AnsibleUnicode("This is plain text")
    plain_text.ansible_pos = __file__, 1, 0
    vault = VaultLib("password")
    cipher_text = plain_text.copy(vault, "secret")
    if cipher_text.is_encrypted():
        return True
    else:
        return False


# Generated at 2022-06-11 09:34:36.252435
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    avu1 = AnsibleVaultEncryptedUnicode("Secret")
    avu2 = AnsibleVaultEncryptedUnicode("Secret")

    # Test case 1: True is returned
    assert avu1.__ne__("Secret") == True

    # Test case 2: True is returned
    assert avu1.__ne__(avu2) == True


# Generated at 2022-06-11 09:34:41.456332
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault
    try:
        ansible_vault = ansible.parsing.vault.VaultLib([])
    except ansible.parsing.vault.AnsibleVaultError as e:
        print("Error creating VaultLib: %s " % e)
        return 1
    encrypted_str = ansible_vault.encrypt("foo")
    decrypted_str = ansible_vault.decrypt(encrypted_str)
    # is_encrypted: str
    assert(AnsibleVaultEncryptedUnicode(encrypted_str).is_encrypted())
    assert(not AnsibleVaultEncryptedUnicode(decrypted_str).is_encrypted())
    # is_encrypted: unicode

# Generated at 2022-06-11 09:34:51.335345
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    assert AnsibleVaultEncryptedUnicode("\x1c") == "\x1c"
    assert AnsibleVaultEncryptedUnicode("\x1c", vault=1) == "\x1c"

    assert AnsibleVaultEncryptedUnicode("\x1c", vault=1) != "\04"
    assert AnsibleVaultEncryptedUnicode("\x1c", vault=1) != u"\04"
    assert AnsibleVaultEncryptedUnicode("\x1c", vault=1) != b"\04"
    assert AnsibleVaultEncryptedUnicode("\x1c", vault=1) != AnsibleVaultEncryptedUnicode("\04", vault=1)
    assert AnsibleVaultEncryptedUnicode("\x1c", vault=1) != AnsibleV

# Generated at 2022-06-11 09:34:55.739399
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import ansible.plugins.vault

    # ValueError: ansible_pos can only be set with a tuple/list of three values: source, line number, column number
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("password", ansible.plugins.vault.VaultLib("foo"), "bar")
    avu.ansible_pos = 'foo'

    try:
        assert False
    except AssertionError:
        pass



# Generated at 2022-06-11 09:34:57.994800
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;')
    avu.vault = vaultlib.VaultLib('test')
    assert(avu == 'test')



# Generated at 2022-06-11 09:35:06.464602
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''
    Test that __ne__ does not auto-decrypt
    '''
    v = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256\r\n3939653737656633633165323531656261336138393936613865363835393432613366313462376\r\n3336316163663461373430646134616139386430396535663333633337316236633537316661633\r\n33366563303039653338353939303736626233616663376366636337373462623336616164383564\r\n3062316333393932643965\r\n')
    assert 'plaintext' != v


# Generated at 2022-06-11 09:35:12.506354
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ctext = '$ANSIBLE_VAULT;1.1;AES256\n39346563633338636231346138623361333831356637646239613539633538616331353832626562373\n393563353365363961363264326565663038633662383232323062316562636139626565396335613636\n39653661376232316665\n'
    avu = AnsibleVaultEncryptedUnicode(ctext)
    assert avu.is_encrypted() == True

# Generated at 2022-06-11 09:35:21.859879
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test that the __ne__ method returns False in the case where
    # self.vault is None.
    # The __ne__ method is defined using the __eq__ method, so
    # testing __ne__ is enough to prove that the __eq__ method
    # works when self.vault is None.
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    assert AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret') != 'foo'

# Generated at 2022-06-11 09:35:27.531285
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    secret = 'testsecret'
    vault_str = AnsibleVaultEncryptedUnicode.from_plaintext("test", vault, secret)
    assert vault_str != "test"
    assert "test" != vault_str
    assert vault_str == "test"
    assert "test" == vault_str

if __name__ == '__main__':
    test_AnsibleVaultEncryptedUnicode___ne__()

