

# Generated at 2022-06-11 09:25:54.657902
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # 1.
    passwords = ["ansible", "Ansible", "ANSIBL1"]

    vault = vault_bin.VaultLib('foo')

    for pw in passwords:
        pw1 = AnsibleVaultEncryptedUnicode.from_plaintext(pw, vault, 'foo')
        pw2 = AnsibleVaultEncryptedUnicode.from_plaintext(pw, vault, 'foo')
        assert pw1 is not pw2
        assert pw1 != pw2
        assert pw1 == pw1
        assert pw1 == pw
        assert pw1 != 123

    assert pw1 == pw1
    assert pw1 == pw2
    assert pw2 == pw1
    assert pw1 == pw
    assert pw1 != 123



# Generated at 2022-06-11 09:25:58.869819
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    x = AnsibleVaultEncryptedUnicode('test')
    y = AnsibleVaultEncryptedUnicode('test')
    # Check if x and y are different objects
    assert id(x) != id(y)
    assert x != y


# Generated at 2022-06-11 09:26:11.755343
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    text = AnsibleVaultEncryptedUnicode('toto')
    assert (text.rfind('t', 0, 3) == 2)
    assert (text.rfind('t', 0, 1) == 0)
    assert (text.rfind('t', 0, 2) == 2)
    assert (text.rfind('o', 2) == 2)
    assert (text.rfind('o', 2, 1) == -1)
    assert (text.rfind('o', 1, 3) == 2)
    assert (AnsibleVaultEncryptedUnicode('ototot', 4).rfind('o', 2) == 2)
    assert (AnsibleVaultEncryptedUnicode('ototot', 4).rfind('o', 3) == 3)

# Generated at 2022-06-11 09:26:20.591108
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    plaintext = 'Password: "password"'

# Generated at 2022-06-11 09:26:24.544969
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('YQ==', vault=None, secret='foo')
    assert avu != 'a'


# Generated at 2022-06-11 09:26:38.372228
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    def assert_add(data1, data2, expected):
        avu1 = AnsibleVaultEncryptedUnicode(data1)
        avu2 = AnsibleVaultEncryptedUnicode(data2)
        assert avu1 + avu2 == expected
        assert avu2 + avu1 == expected

    yield assert_add, 'a', 'b', 'ab'
    yield assert_add, 'a', 'b', 'ab'
    yield assert_add, '1', '2', '12'


YAML_LOADER = yaml.SafeLoader

#
# Now add our extensions to the YAML_LOADER.
#
YAML_LOADER.add_constructor(u'!include', YAML_LOADER.include)  # pylint: disable=no-member
YAM

# Generated at 2022-06-11 09:26:40.603086
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    assert AnsibleVaultEncryptedUnicode('aircraft_carrier').__getslice__(3,10) == 'craft_'


# Generated at 2022-06-11 09:26:48.132366
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    # Test for 2 byte unicode char
    text = "\u00E4"
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(text, vault=None, secret=None)

    assert encrypted.count(text) == 1

    # Test for 4 byte unicode char
    text = "\U0001F44D"
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(text, vault=None, secret=None)

    assert encrypted.count(text) == 1
    assert encrypted.count(text, 0, 1) == 1

# Class for string containing secret info for vault

# Generated at 2022-06-11 09:26:58.968386
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    class FakeVault:
        def __init__(self):
            self.decrypted_val = False
        def decrypt(self, val, obj=None):
            self.decrypted_val = True
            return "hoge".encode('utf-8')

    search = "hoge"
    input = "hoge".encode('utf-8')
    vault = FakeVault()
    avu = AnsibleVaultEncryptedUnicode(input)
    avu.vault = vault
    assert avu.__gt__(search) == True
    assert vault.decrypted_val == True

# Generated at 2022-06-11 09:27:02.951202
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu = AnsibleVaultEncryptedUnicode("test_AnsibleVaultEncryptedUnicode__eq__")
    assert avu.__eq__("test_AnsibleVaultEncryptedUnicode__eq__") == True
    assert avu.__eq__("Something else") == False


# Generated at 2022-06-11 09:27:29.973563
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.vault import VaultLib
    vault = VaultLib('password')

    # Test case 1 : eq
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello world', vault, 'password')
    assert (avu == 'hello world')

    # Test case 2 : eq
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello world', vault, 'password')
    assert (avu == AnsibleVaultEncryptedUnicode.from_plaintext('hello world', vault, 'password'))

    # Test case 3 : neq
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello world', vault, 'password')
    assert (avu != 'hello')


# Generated at 2022-06-11 09:27:41.331138
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault as vault
    plaintext = b'foobar'
    ciphertext = vault.VaultLib().encrypt(plaintext, b'foo')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu.is_encrypted() == True

    # Encrypt with vault and then decrypt with vault
    ciphertext = vault.VaultLib().encrypt(plaintext, b'foo')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault.VaultLib()
    assert avu.is_encrypted() == False



# Generated at 2022-06-11 09:27:46.508563
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('test123')
    alice_plaintext = 'alice plaintext'
    alice_vault = AnsibleVaultEncryptedUnicode.from_plaintext(alice_plaintext, vault, vault.secrets[0])
    alice_plaintext = 'alice plaintext'
    bob_plaintext = 'bob plaintext'
    assert(alice_vault == alice_plaintext)
    assert(alice_vault != bob_plaintext)



# Generated at 2022-06-11 09:27:54.674537
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''Unit test for AnsibleVaultEncryptedUnicode.__ne__

    Assert plaintext == ciphertext fails.
    '''
    from ansible.parsing.vault import VaultLib

    plaintext = 'foo'
    vault = VaultLib([])
    secret = 'bar'
    ciphertext = vault.encrypt(plaintext, secret)
    avu_ciphertext = AnsibleVaultEncryptedUnicode.from_plaintext(ciphertext, vault, secret)
    avu_plaintext = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avu_ciphertext.__ne__(avu_plaintext)



# Generated at 2022-06-11 09:28:08.354355
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    try:
        import vaultlib
    except ImportError:
        raise ImportError('You need to install vaultlib to run this unit test')
    print("Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode")
    # Init data

# Generated at 2022-06-11 09:28:18.083826
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    """This is a test for the ``__eq__`` method of class ``AnsibleVaultEncryptedUnicode``.
    """
    from ansible.parsing.vault import VaultLib

    # create a ansible vault
    vault = VaultLib(
        password='$ANSIBLE_VAULT;1.2;AES256',
        path='<string>',
        data=''
    )

    aveu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'secret')

    # None != 'test'
    assert aveu != None

    # '' != 'test'
    assert aveu != ''

    # 'other' != 'test'
    assert aveu != 'other'

    # 'test' == 'test'
    assert aveu == 'test'

   

# Generated at 2022-06-11 09:28:30.360655
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import ansible.parsing.vault

    bytes = b'$ANSIBLE_VAULT;1.1;AES256\n' \
            b'613430616562353534386132393038653537383532633163656235323265363664616566333463\n' \
            b'353964623563353664653661353933313766643735623764363733643935666437653061303538\n' \
            b'646236656166346636326637383130373037326331633437306339623665656436303964356537\n' \
            b'64383737643561\n'

    vault_avu = AnsibleVaultEncryptedUnicode(bytes)
   

# Generated at 2022-06-11 09:28:36.533672
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    # Create an encrypted string
    password = 'secret'
    vault = VaultLib(password)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('tomcat', vault, password)

    # Verify it's encrypted
    assert avu.is_encrypted()

    # Verify the string got encrypted
    assert avu != 'tomcat'


# Generated at 2022-06-11 09:28:41.316506
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    class vault_mock(object):
        def decrypt(self, text, obj=None):
            return 'decrypted'

    avue = AnsibleVaultEncryptedUnicode('test')
    avue.vault = vault_mock()
    assert avue == 'decrypted'



# Generated at 2022-06-11 09:28:50.655411
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import UnsafeVaultSecret
    from ansible.parsing.vault import get_file_vault_secret

    vault = VaultLib(secrets=[UnsafeVaultSecret('secret')])

    plain_avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault, 'password')
    assert plain_avu.is_encrypted() is False

    plain_avu_bytes = AnsibleVaultEncryptedUnicode('hello')
    assert plain_avu_bytes.is_encrypted() is False

    plain_avu_bytes.vault = vault
    assert plain_avu_bytes.is_encrypted() is False


# Generated at 2022-06-11 09:29:02.945816
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu1 = AnsibleVaultEncryptedUnicode('abc123')
    assert avu1 == 'abc123'

    avu2 = 'abc123'
    assert avu1 == avu2

    avu3 = AnsibleVaultEncryptedUnicode('abc123')
    assert avu1 == avu3


# Generated at 2022-06-11 09:29:12.260070
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Create a vault encrypted string
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\na2V5Cg==\n'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)

    # Assert that the ciphertext is equal to itself
    assert_equal(avu, ciphertext)

    # Using a unicode string, we should get the same result
    assert_equal(avu, u'$ANSIBLE_VAULT;1.1;AES256\na2V5Cg==\n')

    # But when we use an AnsibleVaultEncryptedUnicode object with the same
    # ciphertext, we can only say that they are not equal.
    #
    # We cannot say that they are equal, because the encryption key is not
    # available
    assert_false

# Generated at 2022-06-11 09:29:25.838312
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # First, we need a valid vault object
    sample_vault = yaml.YAML(typ='safe')

# Generated at 2022-06-11 09:29:39.707470
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:29:43.539422
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    secret = 'hunter2'
    cleartext = 'blah blah blah'
    compare_against = 'blah blah blah'
    vault = get_vault_instance(secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(cleartext, vault, secret)
    assert avu == compare_against


# Generated at 2022-06-11 09:29:48.833147
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    Test for method __ne__ of class AnsibleVaultEncryptedUnicode
    """
    # Create some objects
    vault = None
    plaintext = 'test'
    secret = 'secret'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avu != 'test'


# Generated at 2022-06-11 09:29:59.538155
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import unittest

    a = AnsibleVaultEncryptedUnicode("ciphertext")
    a.data = "data"
    class fakevault:
        def decrypt(self,data,obj=None):
            return data
        def encrypt(self,data,obj=None):
            return data
    a.vault = fakevault()
    b = AnsibleVaultEncryptedUnicode("ciphertext")
    b.data = "datA"

    class TestAnsibleVaultEncryptedString(unittest.TestCase):
        def test_eq(self):
            self.assertNotEqual(a, b)

    unittest.main()



# Generated at 2022-06-11 09:30:08.723159
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib

    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultEditor
    data = 'foo'*1024
    secret = 'bar'
    vault = VaultLib(VaultEditor(password=secret))
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(data, vault, secret)
    # The Vaulted data is present so the value should not be equal
    assert data != encrypted
    # The Vaulted data is not present so the value should be equal
    assert data == AnsibleVaultEncryptedUnicode.from_plaintext(data, None, 'no-secret')

# Generated at 2022-06-11 09:30:14.832756
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    # test case for surgested solution for AnsibleVaultEncryptedUnicode
    plaintext = 'this_text_should_be_encrypted'
    ciphertext = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    avu.data = plaintext
    assert not avu.is_encrypted()


# Generated at 2022-06-11 09:30:17.556615
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault='vault', secret='secret')
    assert avu == 'foo'
    assert not avu == 'bar'


# Generated at 2022-06-11 09:30:40.630410
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256

    def get_vault_text(content, secret, version=1):
        return '$ANSIBLE_VAULT;{};{}\n{}\n'.format(version, secret.vault_identifier, content)

    vault_secret = VaultSecret('my_abs_path')
    vault_aes_256 = VaultAES256(vault_secret)

    plaintext = "my plaintext"
    encrypted = vault_aes_256.encrypt(plaintext)
    encrypted_text = get_vault_text(encrypted, vault_secret)

    avu = AnsibleVaultEncryptedUnicode(encrypted_text)
   

# Generated at 2022-06-11 09:30:52.956627
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    import os

    # Test with a key of 16 bytes
    password = b'A' * 16
    vault = VaultLib(password)
    key = vault.get_binary_key()
    from ansible.parsing.vault import VaultEditor
    with VaultEditor(b'A' * 16, key) as ve:
        ve.append(b'B' * 16)
        line = ve.get_unencrypted_text()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(line, vault, password)
    assert avu.is_encrypted()

    # Test with a key of 32 bytes
    password = b'A' * 32
    vault = VaultLib(password)
    key = vault.get_binary_key()

# Generated at 2022-06-11 09:30:54.517068
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode('enc:null') != 'hello'


# Generated at 2022-06-11 09:31:05.077859
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    # This test is not a Vault object from AnsibleVaultEncryptedUnicode
    plain_text = "This is in plain text."
    plain_text_bytes = plain_text.encode('utf-8')
    plain_text_unicode = AnsibleVaultEncryptedUnicode(plain_text_bytes)
    plain_text_unicode_ = AnsibleVaultEncryptedUnicode(plain_text)
    assert plain_text_unicode.is_encrypted() == False
    assert plain_text_unicode_.is_encrypted() == False

    # This test is a Vault object from AnsibleVaultEncryptedUnicode
    secret = "password"
    vault = VaultLib(secret)

# Generated at 2022-06-11 09:31:10.461393
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''
    Test __ne__ overload method to ensure it works properly
    '''

    string1 = AnsibleVaultEncryptedUnicode('foo')
    string2 = AnsibleVaultEncryptedUnicode('foo')
    string3 = AnsibleVaultEncryptedUnicode('bar')

    assert string1 != string3
    assert not string1 != string2



# Generated at 2022-06-11 09:31:19.587704
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    vault_id = 'test'
    secret = 'secret'

    vault = vaultlib.VaultLib(vault_id, secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, secret)

    assert(avu == 'foo')
    assert(avu != 'bar')

    assert(avu != AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, secret))
    assert(avu != AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, secret))



# Generated at 2022-06-11 09:31:22.701926
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode("foo")
    assert avu.__ne__("foo") == True


# Generated at 2022-06-11 09:31:34.340006
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import os
    import tempfile
    import unittest
    from ansible.parsing.vault.VaultLib import VaultLib

    def assert_encrypted(avu):
        assert avu.is_encrypted()

    def assert_not_encrypted(avu):
        assert not avu.is_encrypted()

    class AnsibleVaultEncryptedUnicode_test(unittest.TestCase):
        def setUp(self):
            self._fd, self._path = tempfile.mkstemp()

        def tearDown(self):
            os.remove(self._path)

        def test_is_encrypted(self):
            '''Test whether is_encrypted() works'''

# Generated at 2022-06-11 09:31:40.932384
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(b'encrypteddata', vault=None, secret='somevaultsecret')
    if avu == 'some data':
        raise AssertionError('__ne__ method of AnsibleVaultEncryptedUnicode did not return True when it should!')
    if not (avu != 'some data'):
        raise AssertionError('__ne__ method of AnsibleVaultEncryptedUnicode did not return False when it should!')



# Generated at 2022-06-11 09:31:49.858009
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''
    Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
    '''
    import ansible.parsing.vault as vault

    def create_func(seq, vault, secret):
        return AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)

    def return_func(avu):
        return avu

    def check_ne_func(avu, other):
        return avu != other

    def check_true_func(avu, other):
        return avu == other

    def return_other_func(avu):
        return other

    def check_other_ne_func(avu, other):
        return other != avu

    def check_other_true_func(avu, other):
        return other == avu

   

# Generated at 2022-06-11 09:32:08.789638
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('ansible')
    vault.update(dict(version=1, secret='foo'))

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault, secret='foo')
    assert avu == 'hello'
    assert not avu == 'world'


# Generated at 2022-06-11 09:32:11.565740
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("my_content", None, None)
    avu.data = "my_content"
    assert "my_content" != avu



# Generated at 2022-06-11 09:32:22.336343
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    # TODO:
    # ansible.parsing.vault.decrypt_text(b'?B\x03\x03\x03\x04\x07\x0b', passphrase='test_123')
    # ansible.parsing.vault.encrypt_text(b'hello', passphrase='test_123')
    # ansible.parsing.vault.VaultLib(b'$ANSIBLE_VAULT;1.1;AES256\n633534326465333866636136383431306263616363643530643337376461303038343733623233360a\n', b'test_123')

    # The return of vault.is_encrypted() is True
    v = VaultLib

# Generated at 2022-06-11 09:32:30.638552
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # AnsibleVaultEncryptedUnicode is equal to AnsibleVaultEncrypted
    # object with same data
    class MockVault(object):
        def __init__(self, is_encrypted, decrypt):
            self.is_encrypted = is_encrypted
            self.decrypt = decrypt
        def encrypt(self, data, secret):
            return data.encode('utf-8')

    def is_encrypted(data):
        return True
    def decrypt(data, secret):
        return data

# Generated at 2022-06-11 09:32:40.434078
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(b'password')

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('Hello world', vault, b'password')
    assert not avu.vault

    avu.vault = vault
    assert avu == 'Hello world'

    s = 'Hello world'
    assert avu == s
    assert s == avu

    s2 = AnsibleVaultEncryptedUnicode.from_plaintext('Hello world', vault, b'password')
    assert avu == s2
    assert s2 == avu

    assert avu != 'Something else'
    assert avu != 0
    assert avu != None

# Generated at 2022-06-11 09:32:49.647550
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    secret = "thisisalongsecretstring"
    data = "this is the plaintext"
    avu_obj = AnsibleVaultEncryptedUnicode.from_plaintext(data, VaultLib(password=secret), secret)
    assert(avu_obj == data)
    assert(data == avu_obj)
    assert(avu_obj.is_encrypted())
    assert(avu_obj != "this is not the plaintext")
    assert("this is not the plaintext" != avu_obj)

# Emit a deprecation warning when AnsibleVaultEncryptedUnicode.__UNSAFE__ is set to false.

# Generated at 2022-06-11 09:32:56.154440
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n' \
                 '6332316164653161316364313231623235616631303364306665643766633531666237373363306230\n' \
                 '3033633461653031343463343466643661062064656631376435323161326330373965366432373062\n' \
                 '3937373662633066333732323266353038313934386261323132316332376132303064663935336610\n' \
                 '373336343061\n'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu.is_encrypted() is True
   

# Generated at 2022-06-11 09:33:01.336779
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode(to_bytes('cipher1')) == to_text('decipher1')
    assert not AnsibleVaultEncryptedUnicode(to_bytes('cipher1')) == to_text('decipher2')


# Generated at 2022-06-11 09:33:05.853684
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Given
    test_data = 'abc'
    avu = AnsibleVaultEncryptedUnicode(test_data)
    # When
    result = avu == test_data
    # Then
    assert result



# Generated at 2022-06-11 09:33:11.115055
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu.__ne__('bar') is True
    avu.data='bar'
    assert avu.__ne__('bar') is False


# Generated at 2022-06-11 09:33:36.528741
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError
    import os

    tmpfile = '/tmp/test_AnsibleVaultEncryptedUnicode_1.txt'
    password = 'mypassword'
    vault = VaultLib([])

    seq = 'mytext\n'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, password)
    with open(tmpfile, 'w') as f:
        f.write(to_text(avu))
    with open(tmpfile, 'r') as f:
        avu2 = yaml.safe_load(f)

    assert avu2 == 'mytext\n'
    assert avu2 != seq


# Generated at 2022-06-11 09:33:42.535704
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault_secret = "foo"
    vault_obj = VaultLib(vault_secret)
    test_string = AnsibleVaultEncryptedUnicode(vault_obj.encrypt("hello world"))
    test_string.vault = vault_obj

    assert not (test_string != "hello world")
    assert not (test_string != u"hello world")
    assert test_string != "hello"


# Generated at 2022-06-11 09:33:48.918005
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:33:58.746793
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible_collections.ansible.modules.plugins.vault import vaultlib
    from ansible_collections.ansible.modules.plugins.vault.vaultlib import VaultLib
    from base64 import standard_b64encode
    from os import urandom

    # Create a vault lib class
    vault_lib = VaultLib(None, None)

    # Create a class object of type AnsibleVaultEncryptedUnicode
    p = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')

    # Test the method __ne__. Test 1 when the same object is passed as input
    assert not (p != p)

    # Test the method __ne__. Test 2 when a different object of same type is passed as input

# Generated at 2022-06-11 09:34:08.716012
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    plaintext = 'ansible_test'
    secret = 'ansible_secret'

# Generated at 2022-06-11 09:34:09.285938
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    pass

# Generated at 2022-06-11 09:34:15.429902
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    cleartext = b'foo bar'
    secret = b'bar'

    # Encrypt
    ciphertext = vault.encrypt(cleartext, secret)
    # Create class instancce
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    # Set vault property
    avu.vault = vault

    assert avu.is_encrypted()



# Generated at 2022-06-11 09:34:20.278140
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    vault = get_vault_instance()
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'password')
    assert avu1 == avu2


# Generated at 2022-06-11 09:34:29.486814
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    v = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;test12345\n363933373431303966303337613261336638303866393338356539633163323936353361306533\n3839386566653330663765333265373137654136\n', vault=v)
    n = 'h_e_l_l_o'
    assert n != avu.data
    assert n != avu
    assert avu.__ne__(n)



# Generated at 2022-06-11 09:34:35.528212
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    with vault.VaultLib("xyz") as v:
        av = AnsibleVaultEncryptedUnicode.from_plaintext("xyz", v, "secret")
        assert not av == "xyz"
        assert av == "xyz"
        assert "xyz" == av
        assert "xyz" == av.data
        assert av.data == "xyz"


# Generated at 2022-06-11 09:34:58.026626
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import vault

    # String isn't encrypted
    assert(AnsibleVaultEncryptedUnicode('string1') != AnsibleVaultEncryptedUnicode('string2'))

    def test_ciphertext_with_vault(vault, password):
        # Same ciphertext and same password
        ciphertext = vault.encrypt('string1', password)
        assert(AnsibleVaultEncryptedUnicode.from_plaintext('string1', vault, password) !=
               AnsibleVaultEncryptedUnicode.from_plaintext('string2', vault, password))
        # Same ciphertext, different password

# Generated at 2022-06-11 09:35:04.845725
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible_collections.notstdlib.moveitallout.plugins.vault import VaultLib
    vault = VaultLib(b'123', b'123')

    value = AnsibleVaultEncryptedUnicode.from_plaintext('secret', vault, 'password')
    assert value == 'secret'
    assert value == AnsibleUnicode('secret')
    assert not value == 'not_secret'
    assert value != 'not_secret'
    assert value != AnsibleUnicode('not_secret')
    assert not value == AnsibleVaultEncryptedUnicode.from_plaintext('not_secret', vault, 'password')


# Generated at 2022-06-11 09:35:11.806436
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from . import vaultlib
    class FakeVault(vaultlib.VaultLib):
        def encrypt(self, data, secret=None, key=None, new_vault=False, salt=None,
                    iv=None, ident=None, hmac=None, yaml_data=None,
                    cipher=None, keys_to_encrypt=None):
            return data
    fv = FakeVault()
    vault_data = b'foobar'
    s = AnsibleVaultEncryptedUnicode.from_plaintext(vault_data, fv, None)
    assert s == 'foobar'



# Generated at 2022-06-11 09:35:20.749845
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # If we try `vault_encrypted == 'changeme'` it will raise an exception trying to get the value of the ciphertext.
    # This test verifies that we handle the case where the other hand of == is not an instance of AnsibleVaultEncryptedUnicode
    from ansible.vault.vault import VaultLib
    vault = VaultLib([])
    vault_encrypted = AnsibleVaultEncryptedUnicode.from_plaintext('changeme', vault=vault, secret='secret')
    assert not (vault_encrypted == 'changeme')
    assert vault_encrypted == AnsibleVaultEncryptedUnicode.from_plaintext('changeme', vault=vault, secret='secret')

# Generated at 2022-06-11 09:35:26.495259
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''
    Ensure that the __ne__ method of class AnsibleVaultEncryptedUnicode works as expected.

    Expected result is that ``__ne__`` will return false if the ciphertext
    is empty in the class, or for a true/false comparison.
    '''

    assert AnsibleVaultEncryptedUnicode('') != 1
    assert AnsibleVaultEncryptedUnicode('') != '1'
    assert AnsibleVaultEncryptedUnicode('1') != ''
    assert AnsibleVaultEncryptedUnicode('1') != None



# Generated at 2022-06-11 09:35:32.701745
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault as vault
    secret = 'password'
    plaintext = 'this is plain text'

    # Create ciphertext
    vault_secret = vault.VaultSecret(secret)
    ciphertext = vault_secret.encrypt(plaintext)

    # Create AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault_secret

    assert avu.is_encrypted() is True

## TODO: move the following to a test module
