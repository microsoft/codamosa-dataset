

# Generated at 2022-06-11 09:25:48.379435
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n63643061303037353431316266623761336363306130666665363361333262383934303362313736\n663065663533393534366534363430353838633361326137650a6336623930336630666235663839\n63316562663865306635303561326362643863323431633666623661643365393966326465343932\n3733386563313162626539\n'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)

    # Test with unicode strings
    sub = 'o'
    assert sub in avu

# Generated at 2022-06-11 09:26:00.926746
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    # Only run unit tests if ansible_collections is available
    import unittest

    class TestSequenceFunctions(unittest.TestCase):
        def setUp(self):
            pass
        
        def test_rstrip(self):
            avu = AnsibleVaultEncryptedUnicode('testing white space ')
            self.assertEqual(avu.rstrip(), 'testing white space')
            avu = AnsibleVaultEncryptedUnicode('a\nb\nc\n')
            self.assertEqual(avu.rstrip(), 'a\nb\nc')
            avu = AnsibleVaultEncryptedUnicode('a\nb\nc\n')
            self.assertEqual(avu.rstrip('\n'), 'a\nb\nc')
            avu = AnsibleVaultEnc

# Generated at 2022-06-11 09:26:13.429812
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # following string is not encrypted, just base64 encoded
    ciphertext = b'MTIzNDU2Nzg5MDEyMzQ1Njc4OTAxMjM0NTY3ODkwMTIzNDU2Nzg5MDEyMzQ1Njc4OTAxMjM0NTY3ODkwMTIzNDU2Nzg5MD\n' \
                 b'EyMzQ1Njc4OTAxMjM0NTY3ODkwMTIzNDU2Nzg5MDEyMjI=\n'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert not avu.is_encrypted()


# Generated at 2022-06-11 09:26:19.201532
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('ansible')
    text = 'test'
    secret = ''
    ciphertext = vault.encrypt(text, secret)
    encrypted_text = AnsibleVaultEncryptedUnicode(ciphertext)
    encrypted_text.vault = vault
    assert encrypted_text.is_encrypted()
    assert not encrypted_text.find('test')
    assert encrypted_text.find(text)


# Generated at 2022-06-11 09:26:27.530194
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    my_vault = vault.VaultLib('my_vault_password')
    evu = AnsibleVaultEncryptedUnicode.from_plaintext('This is a test', my_vault, b'my_vault_password')
    if not evu.__contains__('is'):
        raise AssertionError
    if evu.__contains__('not'):
        raise AssertionError


# Generated at 2022-06-11 09:26:30.226868
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    s = AnsibleVaultEncryptedUnicode('foo')
    assert (s >= 'foo')


# Generated at 2022-06-11 09:26:41.814967
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    avue = AnsibleVaultEncryptedUnicode("")
    assert avue.rstrip() == ""

    avue = AnsibleVaultEncryptedUnicode("\n")
    assert avue.rstrip() == ""

    avue = AnsibleVaultEncryptedUnicode("abc")
    assert avue.rstrip() == "abc"

    avue = AnsibleVaultEncryptedUnicode("abc\n")
    assert avue.rstrip() == "abc"

    avue = AnsibleVaultEncryptedUnicode("abc\n\t")
    assert avue.rstrip() == "abc"

    avue = AnsibleVaultEncryptedUnicode("abc\n\t\n")
    assert avue.rstrip() == "abc"


# Generated at 2022-06-11 09:26:50.526556
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    from ansible.parsing.vault import VaultLib

    assert (AnsibleVaultEncryptedUnicode("HELLO") > AnsibleVaultEncryptedUnicode("WORLD")) == True
    assert (AnsibleVaultEncryptedUnicode("HELLO") > "WORLD") == True
    assert (AnsibleVaultEncryptedUnicode("WORLD") > "HELLO") == False
    assert (AnsibleVaultEncryptedUnicode("HELLO") > "hello") == True
    assert (AnsibleVaultEncryptedUnicode(u"HELLO") > u"WORLD") == True
    assert (AnsibleVaultEncryptedUnicode(u"HELLO") > u"world") == True
    # It is not possible to pass bytes to __gt__, because

# Generated at 2022-06-11 09:27:01.444077
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test with __add__(AnsibleVaultEncryptedUnicode)
    #
    s = AnsibleVaultEncryptedUnicode('abc')
    t = AnsibleVaultEncryptedUnicode('def')
    ans = s + t
    assert ans == 'abcdef'

    # Test with __add__(str)
    #
    s = AnsibleVaultEncryptedUnicode('abc')
    t = 'def'
    ans = s + t
    assert ans == 'abcdef'

    # Test with __add__(bytes)
    #
    s = AnsibleVaultEncryptedUnicode('abc')
    t = b'def'
    ans = s + t
    assert ans == 'abcdef'



# Generated at 2022-06-11 09:27:12.042212
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    plaintext = "\n".join([
        "[all:vars]",
        "ansible_connection=ssh",
        "ansible_ssh_user=root",
        "ansible_ssh_pass=password",
        "",
        "[dbservers]",
        "192.168.0.1",
        "192.168.0.2",
        "192.168.0.3"
    ]);
    from ansible.parsing.vault import VaultLib
    vault = VaultLib({})
    v = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, 'secret')
    assert v <= plaintext


# Generated at 2022-06-11 09:27:32.605029
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    from ansible.parsing.vault import VaultLib

    # This is the secret password
    import os
    vault_password = os.environ['ANSIBLE_VAULT_PASSWORD']

    # This list will have 2 AnsibleVaultEncryptedUnicode objects
    # The first  object has an unencrypted "A"
    # The second object has an encrypted "A"
    ansible_vault_encrypted_unicode_list = [ ]

    # Create the first AnsibleVaultEncryptedUnicode object
    avu1 = AnsibleVaultEncryptedUnicode('A')
    avu1.vault = VaultLib(vault_password)
    ansible_vault_encrypted_unicode_list.append(avu1)

    # Create the second AnsibleVaultEncryptedUnicode object
    av

# Generated at 2022-06-11 09:27:42.796444
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    x = AnsibleVaultEncryptedUnicode('!vault |$ANSIBLE_VAULT;1.1;AES256')
    y = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')

    if to_text(x > y) != to_text("$ANSIBLE_VAULT;1.1;AES256" > "!vault |$ANSIBLE_VAULT;1.1;AES256"):
        raise AssertionError("AnsibleVaultEncryptedUnicode __gt__ not working")


# Generated at 2022-06-11 09:27:48.781051
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    assert 'a' > 'b'
    assert 'b' > 'a'
    assert not ('a' > 'a')
    assert ' ' > ''
    assert not (' ' > ' ')
    assert '1' > '0'
    assert '0' > '9'
    assert not ('0' > '0')
    assert ' ' > ''
    assert not (' ' > ' ')



# Generated at 2022-06-11 09:27:56.730564
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:28:09.192848
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    '''
    Test __contains__ of AnsibleVaultEncryptedUnicode
    '''
    # Create unencrypted string "Test".
    # | GIVEN |
    unencrypted = "Test"

    # Create encrypted string "Vault(Test)".
    # | GIVEN |
    encrypted = AnsibleVaultEncryptedUnicode("Vault(Test)")

    # Check that encrypted string contains the unencrypted string.
    # | THEN |
    assert unencrypted in encrypted

    # Check that encrypted string does not contain empty string.
    # | THEN |
    assert '' not in encrypted

    # Check that encrypted string does not contain string "Test123".
    # | THEN |
    assert 'Test123' not in encrypted



# Generated at 2022-06-11 09:28:18.051518
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Test with two AnsibleVaultEncryptedUnicode objects.
    avu1 = AnsibleVaultEncryptedUnicode('aaaa')
    avu1.vault = True
    avu2 = AnsibleVaultEncryptedUnicode('abbb')
    avu2.vault = False
    assert avu1 >= avu2
    # Test with one AnsibleVaultEncryptedUnicode and one string object.
    avu3 = AnsibleVaultEncryptedUnicode('cccc')
    avu3.vault = False
    assert avu1 >= 'bbbb'
    # Test with one AnsibleVaultEncryptedUnicode and one int object.
    assert avu1 >= 33


# Generated at 2022-06-11 09:28:29.555751
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault.VaultLib
    # instantiate a simple decrypting vault
    vault = ansible.parsing.vault.VaultLib.VaultLib(
        to_bytes('supersecure'),
        to_bytes('ExampleAES256Key1234'))
    # encrypt a string
    ciphertext = vault.encrypt(to_bytes('my secret data'), to_bytes('ExampleAES256Key1234'))
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    # add the vault to the AnsibleVaultEncryptedUnicode object
    avu.vault = vault
    # test the is_encrypted method, this should return True
    assert(avu.is_encrypted())


# Generated at 2022-06-11 09:28:35.473010
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib

    value = u'test'
    secret = b'test'
    vault = VaultLib([])

    evu1 = AnsibleVaultEncryptedUnicode.from_plaintext(value, vault, secret)
    evu1.ansible_pos = ('my_file', 10, 10)
    evu2 = AnsibleVaultEncryptedUnicode.from_plaintext(value, vault, secret)

    # test that normal comparison works
    assert(evu1 == evu2)

    plaintext = u"plain"
    evu3 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)

    # test that plaintext comparison works
    assert(evu1 == plaintext)

# Generated at 2022-06-11 09:28:36.135832
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    pass



# Generated at 2022-06-11 09:28:45.803282
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    key_and_iv = b'1234567890abcdef'
    test_value = u'test value'
    test_value_bytes = to_bytes(test_value)
    test_value_ciphertext = b'$ANSIBLE_VAULT;1.1;AES256\n31353735616235656130353665396534313533363835613734613761313737663534366636323939\n6136353833363935393765343665393231326532653235316236313831653934366536353637373939\n38366231643137663464376636643831633464336630643238626432646239\n'
    # Create a AnsibleVaultEncryptedUnicode by encrypting the

# Generated at 2022-06-11 09:29:01.079845
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Test method __gt__ of class AnsibleVaultEncryptedUnicode
    # when the input string is not an instance of AnsibleVaultEncryptedUnicode.
    input_string_1 = "a"
    encrypted_string_1 = AnsibleVaultEncryptedUnicode("b")
    result = encrypted_string_1.__gt__(input_string_1)
    assert result == True
    # when the input string is an instance of AnsibleVaultEncryptedUnicode
    # and the decrypted string is alphabetically lower than the input string
    encrypted_string_2 = AnsibleVaultEncryptedUnicode("b")
    encrypted_string_2.data = "b"
    input_string_2 = "c"
    encrypted_string_2.__gt__(input_string_2)

# Generated at 2022-06-11 09:29:11.027999
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    import ansible.parsing.vault
    secret = 'ansible'
    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256\n653464366639373236656361396335643430323231393735643833386436626232660a6630633366613762366133633533333263363038643035333731643064333635620a343966353332626264323231356136343330366534653861636361373039653634\n'
    vault = ansible.parsing.vault.VaultLib(secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

# Generated at 2022-06-11 09:29:25.096927
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    """
    This is a demonstration of the feature of the __contains__ method
    of the AnsibleVaultEncryptedUnicode class. Without this method, the
    default behavior will be to use the method of the parent class
    "collections.MutableSequence", which will return True if the argument
    is an item in the list.  The implementation of AnsibleVaultEncryptedUnicode
    will take two different AnsibleVaultEncryptedUnicode objects, and if either
    contains the same (decrypted) string, will return a True result to the
    __contains__ method.
    """
    host1 = '192.168.56.101'
    host2 = '192.168.56.102'

# Generated at 2022-06-11 09:29:33.409541
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib

    pwd = 'secret'
    vault = VaultLib(password=pwd)

    data = 'secret data to encrypt'
    encrypted_data = AnsibleVaultEncryptedUnicode.from_plaintext(data, vault, pwd)
    assert encrypted_data != data
    assert encrypted_data != None
    assert encrypted_data != ''


# Generated at 2022-06-11 09:29:42.670239
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # setup data
    vault = AnsibleVaultLib()
    plain_text = "this is my secret text"
    secret = "vault_secret"
    encrypted_unicode = AnsibleVaultEncryptedUnicode.from_plaintext(plain_text, vault, secret)
    wrong_text = "this is wrong"
    wrong_unicode = AnsibleVaultEncryptedUnicode.from_plaintext(wrong_text, vault, secret)

    # test if equal
    assert(encrypted_unicode == plain_text)
    assert(encrypted_unicode == encrypted_unicode)
    assert(encrypted_unicode != wrong_text)
    assert(encrypted_unicode != wrong_unicode)



# Generated at 2022-06-11 09:29:55.015669
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    input1 = AnsibleVaultEncryptedUnicode('Hello World')
    assert input1 != 'Hello World'
    input2 = AnsibleVaultEncryptedUnicode('Hello World')
    input2.vault = yaml
    assert input2 != 'Hello World'

resolver_base = yaml.SafeLoader.yaml_implicit_resolvers

resolver_mapping = {}
for first_key in resolver_base:
    if first_key not in resolver_mapping:
        resolver_mapping[first_key] = []

# Generated at 2022-06-11 09:30:03.215949
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    secret = b'secret'
    test_string = b'a test string'

    from ansible.parsing.vault import VaultAES256
    vault = VaultAES256(secret)

    encrypted_test_string = AnsibleVaultEncryptedUnicode.from_plaintext(test_string, vault, secret)
    assert encrypted_test_string.__ne__(test_string)
    assert not encrypted_test_string.__ne__(vault.decrypt(encrypted_test_string, obj=encrypted_test_string))


# Generated at 2022-06-11 09:30:12.975730
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:30:23.111434
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    fail = False
    fail_msg = ""

# Generated at 2022-06-11 09:30:26.061356
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    assert AnsibleVaultEncryptedUnicode(b'a').__contains__('a') == True


# Generated at 2022-06-11 09:30:41.298224
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # if the plaintext of the encrypted text is not equal to
    # the plaintext of the other object, then the object is not equal to
    # the other object
    plaintext = "foo"
    avu = AnsibleVaultEncryptedUnicode(plaintext)
    assert avu != "bar"
    assert "bar" != avu

    # if the plaintext of the encrypted text is equal to
    # the plaintext of the other object, then the object is not equal to
    # the other object
    plaintext = "foo"
    avu = AnsibleVaultEncryptedUnicode(plaintext)
    assert avu != "foo"
    assert "foo" != avu


# Generated at 2022-06-11 09:30:50.450350
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''Test whether __ne__ method of AnsibleVaultEncryptedUnicode class is working properly'''
    #############
    # Call test #
    #############
    test_obj = AnsibleVaultEncryptedUnicode('This is a test string')
    ret1 = test_obj.__ne__('This is not a test string')
    ret2 = test_obj.__ne__('This is a test string')
    #############
    # Assertion #
    #############
    assert ret1 == True
    assert ret2 == False


# Generated at 2022-06-11 09:30:58.868161
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import sys
    assert not (AnsibleVaultEncryptedUnicode(b'foo') == 'foo')

# Generated at 2022-06-11 09:31:10.460691
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    from ansible.parsing.vault import VaultLib

    secret = '$ANSIBLE_VAULT;1.1;AES256'

# Generated at 2022-06-11 09:31:23.368193
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError

    # Check error raised if password file is not found
    err_msg = "ERROR! Encrypted vault password file not found at: " \
              "/this/is/not/a/real/path"
    with _sys.stderr as old_stderr:
        _sys.stderr = open("/dev/null", "w")
        try:
            v = VaultLib("/this/is/not/a/real/path")
        except AnsibleVaultError:
            pass
    with _sys.stderr as new_stderr:
        assert _sys.stderr.tell() > 0
        _sys.stderr = old_stderr
        assert err_

# Generated at 2022-06-11 09:31:34.966596
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    a = AnsibleVaultEncryptedUnicode('test')
    a.vault = vaultlib.VaultLib('test')
    b = 'test'
    c = 'test2'
    d = AnsibleVaultEncryptedUnicode('test2')
    d.vault = vaultlib.VaultLib('test')
    e = AnsibleVaultEncryptedUnicode('test')
    e.vault = vaultlib.VaultLib('test2')
    f = AnsibleVaultEncryptedUnicode('test')

    assert(a==b)
    assert(not (a==c))
    assert(not (a==d))
    assert(not (a==e))
    assert(not (a==f))

if __name__ == '__main__':
    import vaultlib
    test_Ans

# Generated at 2022-06-11 09:31:39.706920
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    testvault = VaultLib('VaultPassword')
    testvaule = AnsibleVaultEncryptedUnicode.from_plaintext('test', testvault, 'VaultPassword')
    assert testvaule.is_encrypted() == True


# Generated at 2022-06-11 09:31:43.812392
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    class MyVault(object):
        def is_encrypted(self, ciphertext):
            return True
        def decrypt(self, ciphertext, obj=None):
            return to_text('test')

    # Create a ciphertext of the value 'test'
    encrypted_text = MyVault().encrypt('test', 'password')

    # Create the AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode(encrypted_text)
    avu.vault = MyVault()

    # Expect these to return False because 'x' is not equal to 'test'
    assert avu != 'x'
    assert avu != AnsibleVaultEncryptedUnicode('x')
    assert avu != AnsibleVaultEncryptedUnicode(MyVault().encrypt('x', 'password'))

# Generated at 2022-06-11 09:31:47.877890
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256\nfooooooooooooooooooooooooooooooooooooooooooooooooooooooo\n')
    avu.vault = FakeVault()
    assert avu is not None
    assert avu.data == 'bar'
    assert avu != 'baz'


# Generated at 2022-06-11 09:31:54.205587
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    yamldata = """
vars:
  admin_user: !vault |
        $ANSIBLE_VAULT;1.1;AES256
        643661343766376434356564333930643835376433343064373133336232653533653361383134316339
        356438396662613330663737623663356164663437643331346135613665646535323337313536626362
        646165306439663664
"""
    secret = 'devops-infra'

# Generated at 2022-06-11 09:32:11.448702
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import unittest
    from collections import Sequence
    from ansible.module_utils.six import text_type

    class TestCase(unittest.TestCase):
        def test_1(self):
            s = text_type(u"ansible_vault")
            self.assertEqual(isinstance(s, text_type), True)
            self.assertEqual(isinstance(s, Sequence), True)
            self.assertEqual(isinstance(s, AnsibleVaultEncryptedUnicode), False)
            self.assertEqual(isinstance(s, basestring), True)
            self.assertEqual(text_type(s), text_type(u"ansible_vault"))
            self.assertEqual(s == text_type(u"ansible_vault"), True)

# Generated at 2022-06-11 09:32:18.800670
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('$ANSIBLE_VAULT;1.1;AES256')
    text = 'secret'
    ciphertext = vault.encrypt(text)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    assert avu.is_encrypted()

    # Inverse
    avu.data = text
    assert not avu.is_encrypted()



# Generated at 2022-06-11 09:32:24.514610
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    method = AnsibleVaultEncryptedUnicode.__ne__
    instance = AnsibleVaultEncryptedUnicode('test')
    assert method(instance, AnsibleVaultEncryptedUnicode('test')) is False
    assert method(instance, 'test') is False
    assert method(instance, AnsibleVaultEncryptedUnicode('foo')) is True
    assert method(instance, 'foo') is True


# Generated at 2022-06-11 09:32:30.695097
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test 1: try if objects are not equal
    vault = None
    plaintext = "some plain text"
    secret = "s3cr3t"
    vault_obj = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    text2 = "some plain text"
    assert text2 != vault_obj
    assert vault_obj != text2
    assert vault_obj != text2

    # Test 2: try if objects are equal
    text2 = "some plain text"
    assert text2 == vault_obj
    assert vault_obj == text2
    assert vault_obj == text2


# Generated at 2022-06-11 09:32:34.896234
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test when object equal
    av = AnsibleVaultEncryptedUnicode("foo")
    av.vault = "bar"
    assert av == "foo"

    # Test when object non equal
    av = AnsibleVaultEncryptedUnicode("foo")
    av.vault = "bar"
    assert not av == False


# Generated at 2022-06-11 09:32:39.324407
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    result0 = AnsibleVaultEncryptedUnicode.from_plaintext("foo", vault, secret).is_encrypted()
    result1 = AnsibleVaultEncryptedUnicode.from_plaintext("", vault, secret).is_encrypted()

    if not result0 or result1:
        # TODO: Raise an exception
        pass


# Generated at 2022-06-11 09:32:47.994477
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing import vault
    vault_password = 'vault_pwd'
    test_str = 'abc'
    vault_obj = vault.VaultLib(vault_password)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(test_str, vault_obj, vault_password)
    # Check the encrypted object
    assert avu.is_encrypted()

    # Check decrypted
    ciphertext = vault_obj.decrypt(avu._ciphertext, obj=avu)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = None
    assert not avu.is_encrypted()



# Generated at 2022-06-11 09:32:50.999698
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    AVU_obj = AnsibleVaultEncryptedUnicode('ENC[AES256_CBC,base64]XhkLjKehPZo8nYVaY1BdzMw==\n')
    AVU_obj.vault = None
    assert AVU_obj != 'ANSIBLE'


# Generated at 2022-06-11 09:32:59.295816
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    v = vaultlib.VaultLib("secret")
    s1 = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256\n<BASE64 ENCODED DATA>");
    s1.vault = v

    s2 = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256\n<BASE64 ENCODED DATA>");
    s2.vault = v

    assert (s1 == "decrypted data")
    assert (s1 == s2)



# Generated at 2022-06-11 09:33:12.355108
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    try:
        from ansible.parsing.vault import VaultLib
    except ImportError:
        raise AssertionError('Cannot test AnsibleVaultEncryptedUnicode in this environment')

    vault = VaultLib('password')
    encrypted_text = vault.encrypt('Hello World!')
    unencrypted_text = 'I am not encrypted!'

    avu1 = AnsibleVaultEncryptedUnicode(encrypted_text)
    avu1.vault = vault
    avu2 = AnsibleVaultEncryptedUnicode(unencrypted_text)
    avu2.vault = vault

    assert avu1.is_encrypted() == True
    assert avu2.is_encrypted() == False



# Generated at 2022-06-11 09:33:25.671982
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode.from_plaintext('hello', None, None) == 'hello'
    assert AnsibleVaultEncryptedUnicode.from_plaintext('hello', None, None) != 'world'


# Generated at 2022-06-11 09:33:36.831813
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:33:44.630100
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleVaultEncryptedUnicode_representer
    from ansible.parsing.yaml.dumper import AnsibleVaultEncryptedUnicode_constructor
    import yaml

    v = VaultLib('secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('password', v, 'secret')

    # without the fix, this would raise '' != password'
    assert avu != 'password'



# Generated at 2022-06-11 09:33:51.503861
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import unittest

    # Create the class
    class Test(AnsibleVaultEncryptedUnicode):
        pass

    # Create the test
    class MyTest(unittest.TestCase):
        def test(self):
            # Test 1
            self.assertEqual(Test(u'test') == u'1', False)

            # Test 2
            self.assertEqual(Test(u'test') == u'1', False)

    unittest.main()

# Generated at 2022-06-11 09:33:55.536865
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    with pytest.raises(Exception) as excinfo:
        avu = AnsibleVaultEncryptedUnicode('whatever')
        avu.__eq__('hello')

    assert excinfo.value.message == 'Error creating AnsibleVaultEncryptedUnicode, invalid vault (None) provided'



# Generated at 2022-06-11 09:33:58.586915
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    strA = AnsibleVaultEncryptedUnicode('hello world')
    strB = AnsibleVaultEncryptedUnicode('hello world')
    assert not (strA == strB)



# Generated at 2022-06-11 09:34:03.034555
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Init the secure vault
    secure_vault = AnsibleVaultEncryptedUnicode.from_plaintext("abc", vault=None, secret="bla")
    assert secure_vault.__ne__("test") == True
    assert secure_vault.__ne__("abc") == False



# Generated at 2022-06-11 09:34:12.262610
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import os
    import vaultlib
    BIN_ENC = 'ascii'
    FILE_ENC = 'utf-8'
    SCRATCH_DIR = '/tmp/test_ansible_vault_scratch'
    SCRATCH_PASSWORD = 'test_password'
    SCRATCH_VAULT_ID = 'test_ansible_vault'
    SCRATCH_FILE_PATH = os.path.join(SCRATCH_DIR, 'test_file.yml')
    TEST_STRING = u'This is a test string'

    if os.path.isdir(SCRATCH_DIR):
        raise AssertionError('%s already exists, remove it and try again' % SCRATCH_DIR)
    os.makedirs(SCRATCH_DIR)

    # Generate a new vault secret


# Generated at 2022-06-11 09:34:16.542596
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultEditor
    text = u'abc'
    vault = VaultEditor('abc')
    avue = AnsibleVaultEncryptedUnicode.from_plaintext(text, vault, 'blah')
    assert avue.is_encrypted() == True


# Generated at 2022-06-11 09:34:27.049299
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader

    vault = VaultLib([], [], '', None)

    current_yaml = '!vault |\n          $ANSIBLE_VAULT;1.2;AES256;ansible\n          633663346662633261616430336161396132313631376232626463386266646665343763336535\n          306430386364396139623761346262326337633037396665343236620a'

    # We have to use AnsibleLoader as this is the Loader that is
    # used in VaultLib

# Generated at 2022-06-11 09:34:53.221120
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ''' Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode '''
    assert AnsibleVaultEncryptedUnicode('') != AnsibleVaultEncryptedUnicode('')
    assert AnsibleVaultEncryptedUnicode('b') != AnsibleVaultEncryptedUnicode('a')
    assert AnsibleVaultEncryptedUnicode('a') != AnsibleVaultEncryptedUnicode('b')
    assert AnsibleVaultEncryptedUnicode('ab') != AnsibleVaultEncryptedUnicode('a')
    assert AnsibleVaultEncryptedUnicode('abc') != AnsibleVaultEncryptedUnicode('ac')
    assert AnsibleVaultEncryptedUnicode('bb') != AnsibleVaultEncryptedUnicode('b')
    assert AnsibleVaultEnc

# Generated at 2022-06-11 09:34:54.417089
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avue = AnsibleVaultEncryptedUnicode("test")
    assert avue != "test"



# Generated at 2022-06-11 09:34:59.404644
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Setup
    avu = AnsibleVaultEncryptedUnicode(to_bytes('2w0BY3q7v2QWkr0y9XeOiA==\n'))
    setattr(avu, 'vault', None)

    # Exercise
    result = avu == 'Hi!'

    # Verify
    assert result == False


# Generated at 2022-06-11 09:35:07.962270
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib([])
    # Declare true test string
    teststring = "This is a test string."
    # Declare encrypted unicode object created with the vault
    uniencrypted = AnsibleVaultEncryptedUnicode.from_plaintext(teststring, vault, "password")
    # Declare unencrypted unicode object
    unicodeobj = u"This is a test string 2"
    # Test that True != True
    assert uniencrypted != unicodeobj
    # Test True != None
    assert uniencrypted != None
    # Test None != True
    assert None != uniencrypted


# Generated at 2022-06-11 09:35:15.055845
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ''' if we pass an AnsibleVaultEncryptedUnicode object that
        has not been initialized with a vault, a call to is_encrypted()
        will fail with an exception
    '''
    avu = AnsibleVaultEncryptedUnicode('')
    try:
        avu.is_encrypted()
        raise AssertionError('is_encrypted on an uninitialized object should not have succeeded')
    except Exception:
        pass


# in Py3, the yaml parser returns a bytes object, so we need
# to convert it to Unicode.
# unfortunately, yaml.safe_load returns unicode strings if the
# YAML it is parsing contains unicode strings, but it returns the
# raw string value if it contains non-unicode strings, so we can't
# use the same trick to convert all values to unicode regardless of


# Generated at 2022-06-11 09:35:18.463608
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert not AnsibleVaultEncryptedUnicode(to_bytes('not encrypted')).is_encrypted()
    assert AnsibleVaultEncryptedUnicode(to_bytes('$ANSIBLE_VAULT;1.1;AES256')).is_encrypted()



# Generated at 2022-06-11 09:35:24.344702
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test that __eq__ works when the vault is not set
    a = AnsibleVaultEncryptedUnicode('test')
    assert a == 'test'
    assert a != 'test1'
    assert a != ''

    # Try setting the vault, which should fail
    try:
        a.vault = 'test'
        assert False
    except vault.AnsibleVaultError as e:
        assert True

    # Try setting the vault and test __eq__ again
    a.vault = vault.VaultLib('test')
    assert a == 'test'
    assert a != 'test1'
    assert a != ''


# Generated at 2022-06-11 09:35:29.852289
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    
    class Test1:
        pass
    
    class Test2:
        pass
    
    class Test3:
        pass
    
    class Test4:
        pass
    
    class Test5:
        pass
    
    class Test6:
        pass
    
    class Test7:
        pass
    
    def list_comprehension_001(x):
        return [a for a in x]
    
    def list_comprehension_002(x):
        return [a for a in x]
    
    def list_comprehension_003(x):
        return [a for a in x]
    
    def list_comprehension_004(x):
        return [a for a in x]
    