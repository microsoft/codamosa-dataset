

# Generated at 2022-06-11 09:26:02.854252
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    assert AnsibleVaultEncryptedUnicode('foo')[0:2] == 'fo'
    assert AnsibleVaultEncryptedUnicode('foo')[0:1] == 'f'


'''
classes to extend the yaml objects used by pyyaml
'''

AnsibleMapping.add_yaml_constructor('!unsafe', AnsibleMapping.add_yaml_constructor('!secret', AnsibleMapping))
AnsibleUnicode.add_yaml_constructor('!unsafe', AnsibleUnicode.add_yaml_constructor('!secret', AnsibleUnicode))
AnsibleSequence.add_yaml_constructor('!unsafe', AnsibleSequence.add_yaml_constructor('!secret', AnsibleSequence))


# Generated at 2022-06-11 09:26:14.728574
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    assert "".__lt__("1") == True
    assert "0".__lt__(None) == False
    assert "0".__lt__(1) == False
    assert "1".__lt__(2) == True
    assert "2".__lt__(1) == False
    assert "a".__lt__("z") == True
    assert "z".__lt__("a") == False
    assert "ab".__lt__("ac") == True
    assert "ac".__lt__("ab") == False
    assert "ac".__lt__("ac") == False

    assert "".__le__("1") == True
    assert "0".__le__(None) == False
    assert "0".__le__(1) == False
    assert "1".__le__(2) == True

# Generated at 2022-06-11 09:26:23.070724
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    testcases = [
        (
            '# hello',
            '# world',
            False
        ),
        (
            'world',
            '# world',
            True
        ),
        (
            '# world',
            'world',
            False
        ),
        (
            'world',
            'hello',
            True
        )
    ]
    for testcase in testcases:
        avu = AnsibleVaultEncryptedUnicode(testcase[0])
        assert avu.__gt__(testcase[1]) == testcase[2]



# Generated at 2022-06-11 09:26:25.001512
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault_pass = 'mypassword'
    vault = VaultLib(vault_pass)
    v = AnsibleVaultEncryptedUnicode.from_plaintext('string', vault, vault_pass)
    assert v != 'string'



# Generated at 2022-06-11 09:26:33.630249
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib  # FIXME: Is this the best way to get VaultLib instance for testing?
    vault = VaultLib({'password': 'secret'})
    avu_1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=vault, secret='secret')
    assert avu_1.__ne__('foo') is False
    assert avu_1.__ne__('bar') is True

# Generated at 2022-06-11 09:26:34.310721
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass

# Generated at 2022-06-11 09:26:40.366505
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = "secret"
    seq = 'test'
    encrypted_seq = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert encrypted_seq == seq
    assert encrypted_seq != 'tset'


# Generated at 2022-06-11 09:26:49.709499
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    # Test method
    aveu = AnsibleVaultEncryptedUnicode('test')
    assert '1' + aveu == '1test'
    assert aveu + '1' == 'test1'
    assert 1 + aveu == '1test'
    assert aveu + 1 == 'test1'
    assert 1.5 + aveu == '1.5test'
    assert aveu + 1.5 == 'test1.5'
    try:
        assert bytearray([0xff]) + aveu
    except TypeError:
        pass
    else:
        assert False, 'bytearray + AnsibleVaultEncryptedUnicode should raise TypeError'

test_AnsibleVaultEncryptedUnicode___radd__.pytestmark = pytest.mark.incremental

# Generated at 2022-06-11 09:27:01.080833
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    ciphertext = 'GlX9gHf0JQDlHUbgFmU6LwB6m3hq3oU6'
    vault = AnsibleVaultEncryptedUnicode(ciphertext)
    vault.vault = AnsibleVaultUnsafe(None, 'mysecret')

    assert vault.data == 'mysecret'
    assert vault[:] == 'mysecret'
    assert vault[2:] == 'secret'
    assert vault[:2] == 'my'
    assert vault[:-3] == 'mysec'
    assert vault[-3:] == 'ret'
    assert vault[-3:10] == 'ret'
    assert vault[2:5] == 'sec'


# Generated at 2022-06-11 09:27:13.578714
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    aveu1 = AnsibleVaultEncryptedUnicode('encrypted')
    aveu2 = AnsibleVaultEncryptedUnicode('encrypted')
    aveu3 = AnsibleVaultEncryptedUnicode('encrypted2')
    normal_str1 = 'encrypted'
    normal_str2 = 'encrypted'
    normal_str3 = 'encrypted2'

    assert aveu1 < aveu3, '''AnsibleVaultEncryptedUnicode objects are sorted by its
                            decrypted text using __lt__.'''
    assert normal_str1 < aveu3, '''A string object is sorted by its value
                                  compared to the decrypted text of
                                  AnsibleVaultEncryptedUnicode object.'''

# Generated at 2022-06-11 09:27:29.064049
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib([])

    # Test equal case
    ansible_obj = AnsibleVaultEncryptedUnicode.from_plaintext(u"mysecret", vault, u"secret")
    assert u"mysecret" == ansible_obj
    assert ansible_obj == u"mysecret"

    # Test not equal case
    ansible_obj = AnsibleVaultEncryptedUnicode.from_plaintext(u"mysecret1", vault, u"secret")
    assert u"mysecret" != ansible_obj
    assert ansible_obj != u"mysecret"



# Generated at 2022-06-11 09:27:42.588902
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    class vaultlib:
        # The following function is used by the method AnsibleVaultEncryptedUnicode.__init__
        def is_encrypted(self, data):
            return False

        # The following function is used by the method AnsibleVaultEncryptedUnicode.__init__
        def decrypt(self, data, obj):
            return(u'hello')

    # vlt represents a AnsibleVaultEncryptedUnicode object (using the constructor AnsibleVaultEncryptedUnicode([...],vault,[...])
    vlt=AnsibleVaultEncryptedUnicode.from_plaintext('hello', vaultlib(), 'hello')
    vlt.vault=vaultlib()
    assert vlt.count('l') == 2
    assert vlt.count('ll') == 1

# Generated at 2022-06-11 09:27:53.005458
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    avu_text = AnsibleVaultEncryptedUnicode.from_plaintext(u'ababab', None, 'abc')
    # Test case and sub are both unicode
    sub = u'a'
    assert avu_text.count(sub) == 3
    # Test case and sub are both AnsibleVaultEncryptedUnicode
    sub = AnsibleVaultEncryptedUnicode.from_plaintext(u'a', None, 'abc')
    assert avu_text.count(sub) == 3

    avu_text = AnsibleVaultEncryptedUnicode.from_plaintext(u'12345', None, 'abc')
    # Test case is unicode, sub is AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:28:05.192596
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    role_dir = "."
    fake_vault = vaultlib.VaultLib(dict())
    fake_vault.role_path = role_dir
    value = AnsibleVaultEncryptedUnicode.from_plaintext("test",fake_vault, "test")
    other = AnsibleVaultEncryptedUnicode.from_plaintext("test2",fake_vault, "test")
    assert sys.version_info[0] > 2
    assert value.__gt__(other)
    assert not value.__gt__(value)
    other = "test2"
    assert value.__gt__(other)
    assert not value.__gt__(value)


# Generated at 2022-06-11 09:28:13.223705
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    vault = vaultlib.VaultLib('test')

    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('mysecret', vault, None)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('mysecret', vault, None)
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext('mysecret2', vault, None)

    assert_true(avu1 < avu3)
    assert_false(avu1 < avu2)


# Generated at 2022-06-11 09:28:18.305529
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    """AnsibleVaultEncryptedUnicode.__eq__() test case"""
    secret = b'my secret password'
    vault = VaultLib(_sys.stdin.buffer)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(secret, vault, 'ansible')
    assert not avu.vault
    avu.vault = vault
    assert avu == secret
    assert avu != 'hello world'
    return



# Generated at 2022-06-11 09:28:21.597876
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    '''
    Test the method __gt__ of class AnsibleVaultEncryptedUnicode
    '''
    pass


# Generated at 2022-06-11 09:28:24.062716
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    k = AnsibleVaultEncryptedUnicode("hello world")
    assert k.count("o") == 2



# Generated at 2022-06-11 09:28:29.669514
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:28:41.126060
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:28:57.923788
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''
    test for:
    class AnsibleVaultEncryptedUnicode
      method __ne__
    '''
    vault = AnsibleVaultEncryptedUnicode.from_plaintext("", None, "")
    vu = AnsibleVaultEncryptedUnicode("")
    assert vu.__ne__(vault) == True
    return True


# Generated at 2022-06-11 09:29:08.750101
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing import vault

    # V1 vault
    # Test a vault encrypted string
    secret = 'secret123'
    plaintext = "This is a secret"
    vault_password = 'vault'
    vault_1 = vault.VaultLib(vault_password)
    encrypted_string_1 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault_1, secret)
    assert encrypted_string_1.is_encrypted() is True

    # Test a not vault encrypted string
    plaintext_2 = "This is not secret"
    encrypted_string_2 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext_2, vault_1, secret)
    assert encrypted_string_2.is_encrypted() is False

    # V2 vault
    # Test a

# Generated at 2022-06-11 09:29:15.487316
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:29:21.622401
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    An AnsibleVaultEncryptedUnicode is never equal to an AnsibleVaultEncryptedUnicode
    """
    a1 = AnsibleVaultEncryptedUnicode('foo')
    a2 = AnsibleVaultEncryptedUnicode('foo')
    assert a1 != a2


# Generated at 2022-06-11 09:29:25.799870
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    with VaultLib('foo') as vault:
        s = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault, 'foo')
        assert(s != 'hello')


# Generated at 2022-06-11 09:29:39.664523
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    import sys
    suite = unittest.TestSuite()
    suite.addTest(AnsibleVaultEncryptedUnicode_TestCase("test___eq___returns_true_when_string_and_data_are_equal"))
    suite.addTest(AnsibleVaultEncryptedUnicode_TestCase("test___eq___returns_false_when_string_and_data_are_not_equal"))
    suite.addTest(AnsibleVaultEncryptedUnicode_TestCase("test___eq___returns_false_when_obj_is_not_instance_of_AnsibleVaultEncryptedUnicode"))
    runner = unittest.TextTestRunner(descriptions=True, stream=sys.stdout, verbosity=2)

# Generated at 2022-06-11 09:29:41.619608
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    assert AnsibleVaultEncryptedUnicode('abc')[1:] == "bc"


# unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:29:48.039375
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'foo'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('secret', vault, secret)
    assert avu == 'secret'
    assert 'secret' == avu
    assert avu != 'not secret'
    assert 'not secret' != avu
    assert avu != 123
    assert 123 != avu


# Generated at 2022-06-11 09:29:58.824299
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    # VaultLib.encrypt only accepts unicode.
    # Since the __eq__ method has the same restriction, we test it with a unicode object.
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode.from_plaintext(u'first_string', VaultLib(password_file=None), None)
    assert ansible_vault_encrypted_unicode == u'first_string'
    assert ansible_vault_encrypted_unicode != u'second_string'


# FIXME: we should not be using the PyYAML API directly as it may change without notice

# Generated at 2022-06-11 09:30:09.519437
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # With a vault, this is a decrypted string.
    avu = AnsibleVaultEncryptedUnicode('hello world')
    # This is a mock vault.
    avu.vault = MockVault(False)
    assert avu.is_encrypted() is False
    # With a vault, this is an encrypted string.
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    # This is a mock vault.
    avu.vault = MockVault(False)
    assert avu.is_encrypted() is True
    # With no vault, this is a string containing the text 'encrypt'.
    avu = AnsibleVaultEncryptedUnicode('encrypt')
    assert avu.is_encrypted() is False
    # With no vault,

# Generated at 2022-06-11 09:30:31.091302
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import os

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultKeyError
    vault = VaultLib([os.urandom(32)])
    secret = VaultSecret(os.urandom(32))
    m_cls = lambda: AnsibleVaultEncryptedUnicode.from_plaintext("dummy plaintext", vault, secret)
    m = m_cls()
    assert m == "dummy plaintext"
    assert not m != "dummy plaintext"


# Generated at 2022-06-11 09:30:40.437591
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'hunter2')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'hunter2')
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'hunter2')
    # VaultEncryptedUnicode should be equal to plaintext
    assert avu1 == 'bar'
    assert 'bar' == avu1
    # VaultEncryptedUnicode should compare against other
    # VaultEncryptedUnicode
    assert avu1 == avu2
    assert avu2 == avu1
    assert avu1 != avu3

# Generated at 2022-06-11 09:30:51.633375
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('myvaultpassword')
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('data', vault, 'vault secret')
    assert avu1.data == 'data'
    assert avu1 == 'data'
    assert avu1 != 'not data'
    assert avu1 != 'not data'
    assert avu1 == avu1

    # Test that we don't crash when the vault is not set
    avu2 = AnsibleVaultEncryptedUnicode('my encrypted data')
    assert avu2 != 'data'
    assert avu2 != 'data'



# Generated at 2022-06-11 09:30:59.376665
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.vault import get_vault_secret

    # create vaultobj
    vault_secret = get_file_vault_secret(None, None)
    vaultobj = VaultLib(vault_secret)

    # data which is not encrypted
    avu1 = AnsibleVaultEncryptedUnicode('this is not encrypted')
    avu1.vault = vaultobj
    assert avu1.is_encrypted() == False

    # encrypt data
    ciphertext = vaultobj.encrypt('this is encrypted', vault_secret)

    # create AnsibleVaultEncryptedUnicode object

# Generated at 2022-06-11 09:31:10.957359
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    def assert_equals(expected, actual):
        return actual == expected

    def test(a, b):
        avu_a = AnsibleVaultEncryptedUnicode(a)
        avu_a.vault = AvVault(None)
        avu_b = AnsibleVaultEncryptedUnicode(b)
        avu_b.vault = AvVault(None)
        return avu_a.__eq__(avu_b)

    def test_scenario(scenario):
        actual = test(scenario['a'], scenario['b'])
        expected = scenario['expected']
        message = scenario['message']
        try:
            assert_equals(expected, actual)
        except Exception:
            return False, message

        return True, message

    # setup
    PASS = True


# Generated at 2022-06-11 09:31:23.839075
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    avu = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256\n39396234656339353965313665346561653565346334326539643030386436326139613232346431\n37633862323234333864393439323538333637616463386166316434346339653966643332373864\n34373462646330306339376434363764303839646662666666623933\n")
    avu.vault = VaultLib("testpassword")
    assert avu.is_encrypted()
    avu = AnsibleVaultEncryptedUnicode("foo")
    assert not avu.is_encrypted()

# Generated at 2022-06-11 09:31:34.334051
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode(ciphertext='a')
    assert avu != ''
    assert not (avu != 'a')
    assert avu != u'a'
    assert not (avu != AnsibleVaultEncryptedUnicode(ciphertext='a'))
    assert not (avu != avu)
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext=b'a')
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext='b')
    assert avu != AnsibleVaultEncryptedUnicode(ciphertext='a'*10)
    assert avu.vault is None


# Generated at 2022-06-11 09:31:44.465075
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test for vault password validity and for correct decryption of secret data
    avu_good_password = AnsibleVaultEncryptedUnicode.from_plaintext(
        'topsecret',
        vault=vaultlib.VaultLib(b'goodpassword'),
        secret=vaultlib.VaultSecret(b'goodpassword')
    )
    assert avu_good_password == 'topsecret'
    assert avu_good_password != 'top_secret' #pylint: disable=comparison-with-itself

    # Test for vault password validity and for correct decryption of secret data

# Generated at 2022-06-11 09:31:51.918203
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    test_input = AnsibleVaultEncryptedUnicode(u'YmFkIHBhc3N3b3Jk')
    class mockVault(object):
        def __init__(self, ciphertext):
            self.decrypt_obj = (ciphertext)
            self.decrypt(self.decrypt_obj)
        def decrypt(self, obj):
            return 'bad password'
    mock_vault = mockVault(test_input)
    test_input.vault = mock_vault
    expected_output = True
    actual_output = (test_input != 'bad password')
    assert actual_output == expected_output, 'Expected : %s, Actual : %s' % (expected_output, actual_output)


# Generated at 2022-06-11 09:31:54.136737
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode("test")
    other = "test"
    assert ansible_vault_encrypted_unicode.__ne__(other) == False


# Generated at 2022-06-11 09:32:19.112753
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Testing empty string
    ciphertext = ""

    # Testing vault (shamir)
    import vault_csr
    vault = vault_csr.Vault()
    secret = "secret"

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(ciphertext, vault, secret)
    empty_string = ""
    assert(avu == empty_string)

    # Testing unicode string
    unicode_string = u'\u1234'
    assert(avu == unicode_string)

    # Testing bytestring
    bytestring = b"\xDE\xAD\xC0\xDE"
    assert(avu == bytestring)

    # Testing non-empty string
    ciphertext = "abc"
    avu = AnsibleVaultEncryptedUnicode.from_

# Generated at 2022-06-11 09:32:28.463277
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    class VaultDummy:
        def decrypt(self, seq):
            return seq[::-1]
        def encrypt(self, seq):
            return seq[::-1]
        def is_encrypted(self, seq):
            return True

    # a check for the case of non-existing vault (should fail)
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu.vault = None
    try:
        ans = avu != 'bar'
        raise AssertionError('AnsibleVaultEncryptedUnicode __ne__ with non-existing vault should fail')
    except:
        pass
    # a check for the case when string is not encrypted
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu.vault = VaultDummy()

# Generated at 2022-06-11 09:32:38.090071
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    '''
    Test the AnsibleVaultEncryptedUnicode __eq__ method
    '''
    # None vault is false
    avu_none_vault = AnsibleVaultEncryptedUnicode.from_plaintext("test", None, "secret")
    assert not (avu_none_vault == "test")

    # valid vault
    from ansible.parsing.vault import VaultLib
    avu_vault = AnsibleVaultEncryptedUnicode.from_plaintext("test", VaultLib("secret"), "secret")

    assert avu_vault == "test"

    # check that the secret for the vault matches
    with pytest.raises(VaultLib.AnsibleVaultError):
        assert avu_vault == "test"



# Generated at 2022-06-11 09:32:45.643378
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test if string comparison between AnsibleVaultEncryptedUnicode object and a normal string works correctly
    plaintext = 'secret'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, None, None)
    assert (avu.data == plaintext)
    # Test if string comparison between AnsibleVaultEncryptedUnicode object and another AnsibleVaultEncryptedUnicode object works correctly
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, None, None)
    assert (avu2.data == plaintext)


# Generated at 2022-06-11 09:32:48.401825
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    obj1 = AnsibleVaultEncryptedUnicode('test')
    obj2 = AnsibleVaultEncryptedUnicode('test')
    assert(obj1 != obj2)



# Generated at 2022-06-11 09:32:54.435912
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Create a AnsibleVaultEncryptedUnicode holding the same value as a
    # unicode object would
    avu_unicode = AnsibleVaultEncryptedUnicode(u'abc')
    # Compare for equality
    assert (avu_unicode == u'abc')
    assert (u'abc' != avu_unicode)
    assert (avu_unicode != u'xyz')
    assert (u'xyz' != avu_unicode)
    # Fail if the vault attribute is not set
    avu_bytes = AnsibleVaultEncryptedUnicode(b'ZWNobwo=')
    assert (not avu_bytes == b'echo\n')
    assert (not b'echo\n' == avu_bytes)



# Generated at 2022-06-11 09:33:07.644502
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password='foo')
    password_plaintext = to_bytes('secretpassword')
    password_vault = AnsibleVaultEncryptedUnicode.from_plaintext(password_plaintext, vault, 'foo')

    # Test when password_vault is not decrypted
    assert(password_plaintext != password_vault)
    assert(password_vault != password_plaintext)

    # Test when password_vault is decrypted
    password_vault2 = password_vault
    password_vault2.vault = vault
    assert(password_plaintext == password_vault2)
    assert(password_vault2 == password_plaintext)


# Generated at 2022-06-11 09:33:18.392719
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # ensure that the is_encrypted method returns false for a unicode object
    # created from a plaintext string
    assert not AnsibleUnicode('hello world').is_encrypted()

    # ensure that the is_encrypted method returns false for a unicode object
    # created from a plaintext string
    assert not AnsibleUnicode('hello world').is_encrypted()

    # ensure that the is_encrypted method returns true for a unicode object
    # created from a ciphertext string

# Generated at 2022-06-11 09:33:31.518650
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secret = VaultSecret('some secret')
    vault = VaultLib(vault_secret)

    plaintext = 'hello there'

    # not encrypted
    avu = AnsibleVaultEncryptedUnicode(plaintext)
    assert not avu.is_encrypted()
    avu.vault = vault
    assert not avu.is_encrypted()

    # is encrypted
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, vault_secret)
    assert avu.is_encrypted()

    # is encrypted, but no vault set
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, vault_secret)

# Generated at 2022-06-11 09:33:38.136844
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    # Scenario: Test encrypted string
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test_password', vault, 'test')
    assert avu.is_encrypted()

    # Scenario: Test unencrypted string
    avu = AnsibleVaultEncryptedUnicode('test_password')
    assert not avu.is_encrypted()



# Generated at 2022-06-11 09:34:02.780026
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    encrypt_bytes = b'bG9zaGkK'
    # Cannot use 'password' as password because this is not a unicode string
    my_vault = vaultlib.VaultLib('ansible', 'password ')
    my_string = AnsibleVaultEncryptedUnicode.from_plaintext('AnsibleVaultEncryptedUnicode', my_vault, 'password')
    # my_string.data is not defined
    assert my_string == 'AnsibleVaultEncryptedUnicode' is False
    # my_string.data is defined
    my_string.data = encrypt_bytes
    assert my_string == 'AnsibleVaultEncryptedUnicode' is True

    # Test the case where other is an AnsibleVaultEncryptedUnicode
    # Cannot use 'password' as password because this

# Generated at 2022-06-11 09:34:08.592249
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Create a vault so we can not hit an exception
    from ansible.errors import AnsibleVaultError
    from ansible.parsing.vault import VaultLib
    vault_password = 'ansible'
    vault = VaultLib(vault_password)

    # Create the object
    aveu = AnsibleVaultEncryptedUnicode.from_plaintext('123', vault, vault_password)
    assert aveu.__ne__(123) == False



# Generated at 2022-06-11 09:34:18.342104
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:34:28.942865
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('dummy')

    secret = b'password'
    ciphertext = vault.encrypt(b'elem', secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert not (avu != 'elem')
    assert avu != 'elem1'

    ciphertext = vault.encrypt(b'', secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert not (avu != '')
    assert avu != 'elem'


# Generated at 2022-06-11 09:34:38.513464
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    test_string = 'test string'
    test_ciphertext = 'test ciphertext'

    class myVault(object):
        def __init__(self):
            self.decrypt_count = 0

        def decrypt(self, ciphertext):
            self.decrypt_count += 1
            if ciphertext == test_ciphertext:
                return test_string
            return ''

    vault = myVault()
    avu = AnsibleVaultEncryptedUnicode(test_ciphertext)
    avu.vault = vault

    if test_string != avu:
        raise AssertionError("test_AnsibleVaultEncryptedUnicode___ne__: expected %s, got %s" % (test_string, avu))

    if avu.decrypt_count < 1:
        raise Assert

# Generated at 2022-06-11 09:34:48.149347
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib

    # Test with different modes

# Generated at 2022-06-11 09:34:53.142985
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    secret = VaultSecret('foo')

    vault = VaultLib(secret)

    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, secret)

    assert encrypted_string == 'foo'
    assert not encrypted_string == 'bar'


# Generated at 2022-06-11 09:35:00.256967
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    """
    The AnsibleVaultEncryptedUnicode.__eq__ method returns False if either
    the object or the other object we're comparing to is not decryptable.
    """
    # We're assuming we have a object that can
    # decrypt the string "secret"
    vault = mock.MagicMock()
    vault.decrypt.return_value = "secret"
    secret = "password"
    ciphertext = "sdq:34"

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    # None is always not equal to anything
    assert avu != None

    # "secret" should be equal to avu, as it will compare the decrypted
    # value to the other object
    assert avu == "secret"

    # "foobar" should not be equal

# Generated at 2022-06-11 09:35:09.248531
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test that AnsibleVaultEncryptedUnicode.__ne__ returns False if the other object is an
    # AnsibleVaultEncryptedUnicode with the same data.
    tmp = AnsibleVaultEncryptedUnicode('foo')
    assert tmp != 'foo'
    tmp = AnsibleVaultEncryptedUnicode('foo')
    tmp2 = AnsibleVaultEncryptedUnicode(tmp)
    assert tmp != tmp2
    tmp = AnsibleVaultEncryptedUnicode('foo')
    tmp2 = AnsibleVaultEncryptedUnicode(tmp)
    tmp2.ansible_pos = ('foo', 1, 1)
    assert tmp != tmp2
    # Test that AnsibleVaultEncryptedUnicode.__ne__ returns True if other is not an
    # AnsibleVaultEncryptedUnic

# Generated at 2022-06-11 09:35:18.011769
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test the AnsibleVaultEncryptedUnicode.__ne__ method
    # See test_AnsibleVaultEncryptedUnicode__ne__ for the description of the test
    # Case 1: str1 and str2 have the same value. They should return False
    # Case 2: str1 and str2 are not equal. They should return True
    # Case 3: str1 is None, str2 is not. They should return True.
    # Case 4: str1 is not None, str2 is None. They should return True.
    # Case 5: str1 and str2 are both None. They should return False

    # Case 1
    # input_str1 and input_str2 have the same value.
    # They should return False.
    input_str1 = 'same_value'
    input_str2 = 'same_value'
