

# Generated at 2022-06-11 09:26:00.963361
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    class AVEU(AnsibleVaultEncryptedUnicode):
        def __init__(self, data):
            super(AVEU, self).__init__(data)

        def _raw_data(self):
            return self._ciphertext

    a = "foo"
    b = "bar"
    c = AVEU(b"foo")
    d = AVEU(b"bar")
    c.vault = d.vault = None

    if a.replace(a, b) != c.replace(c, d):
        raise AssertionError
    c.vault = d.vault = None
    if a.replace(a, b, 1) != c.replace(c, d, 1):
        raise AssertionError
    c.vault = d.vault = None
   

# Generated at 2022-06-11 09:26:13.481311
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # Test with vault
    vault = vaultlib.VaultLib('ansible')
    secret = 'ansible'
    cipher = '$ANSIBLE_VAULT;1.1;AES256'
    plain = 'original plain text that will be encrypted'
    ansible_vault_cipher = ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode.from_plaintext(plain, vault, secret)
    assert ansible_vault_cipher is not None
    assert ansible_vault_cipher.data == plain
    assert ansible_vault_cipher.vault is vault
    assert ansible_vault_cipher.is_encrypted()
    assert cipher == ansible_vault_cipher

    plain_2 = 'original plain text that will be encrypted 2'
    ansible

# Generated at 2022-06-11 09:26:16.680680
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    avu = AnsibleVaultEncryptedUnicode("value")
    assert 'v' in avu

if __name__ == "__main__":
    test_AnsibleVaultEncryptedUnicode___contains__()

# Generated at 2022-06-11 09:26:23.419564
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    assert to_text(AnsibleVaultEncryptedUnicode('abcde')) == 'abcde'
    assert to_text(AnsibleVaultEncryptedUnicode('abcde')[:]) == 'abcde'
    assert to_text(AnsibleVaultEncryptedUnicode('abcde')[2:]) == u'cde'
    assert to_text(AnsibleVaultEncryptedUnicode('abcde')[:-2]) == u'ab'
    assert to_text(AnsibleVaultEncryptedUnicode('abcde')[2:-2]) == u'c'
    assert to_text(AnsibleVaultEncryptedUnicode('abcde')[::2]) == u'ace'

# Generated at 2022-06-11 09:26:37.544673
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    a = AnsibleVaultEncryptedUnicode("1234567890")
    from ansible.parsing.vault import VaultLib
    a.vault = VaultLib('mysecret')
    assert a[:] == '1234567890'
    assert a[1:] == '234567890'
    assert a[:9] == '123456789'
    assert a[1:9] == '23456789'
    assert a[1:9:2] == '245689'
    assert a[-1:] == '0'
    assert a[-9:-1] == '23456789'
    assert a[-1:] == '0'
    assert a[-9:-1] == '23456789'
    assert a[::-1] == '0987654321'
    assert a

# Generated at 2022-06-11 09:26:44.409787
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    key = b'0123456789abcdef'
    vault = AnsibleVaultLib(key)
    plaintext = 'Hello, World'
    ciphertext = vault.encrypt(plaintext, None)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    x = 1
    assert avu != x

    y = 'Hello, World'
    assert avu != y

    z = avu
    assert avu != z



# Generated at 2022-06-11 09:26:49.325707
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    # Set up the following two encrypted strings using default cipher:
    #   password: aaa
    #   secret: bbb
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault_password = 'aaa'
    vault = VaultLib(vault_password)

    s = AnsibleVaultEncryptedUnicode.from_plaintext('bbb', vault, vault_password)
    assert s.__ge__(s)
    # Test the following two conditions to be >=
    #   1. AnsibleVaultEncryptedUnicode >= AnsibleVaultEncryptedUnicode
    #   2. AnsibleVaultEncryptedUnicode >= String

# Generated at 2022-06-11 09:26:51.712226
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    assert AnsibleVaultEncryptedUnicode.__add__('a', 'b') == 'ab'


# Generated at 2022-06-11 09:27:02.525531
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError

    #initialize a vault object and encrypt some data
    vault = VaultLib([])
    secret = "testdata"
    encrypted_data = AnsibleVaultEncryptedUnicode.from_plaintext(secret, vault, secret)

    # decimal slice
    assert encrypted_data[:] == secret
    assert encrypted_data[1:] == secret[1:]
    assert encrypted_data[:-1] == secret[:-1]
    assert encrypted_data[1:-1] == secret[1:-1]
    assert encrypted_data[:-2] == secret[:-2]
    assert encrypted_data[2:] == secret[2:]

    # slice with step
    assert encrypted_data[::] == secret
   

# Generated at 2022-06-11 09:27:15.478614
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    class FakeVaultClass(object):

        def decrypt(self, s, obj=None):
            return to_text(s)

        def is_encrypted(self, s):
            return True

        def encrypt(self, s, secret):
            return s

    def check_ne(s1, s2):
        v1 = AnsibleVaultEncryptedUnicode(s1)
        v1.vault = fv
        v2 = AnsibleVaultEncryptedUnicode(s2)
        v2.vault = fv
        assert v1 != v2
        assert v2 != v1

    def check_eq(s1, s2):
        v1 = AnsibleVaultEncryptedUnicode(s1)
        v1.vault = fv
        v2 = AnsibleVaultEncryptedUn

# Generated at 2022-06-11 09:27:34.804803
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    secret = 'secret'
    vault = vaultlib.VaultLib('test', log_only=True)
    avu = AnsibleVaultEncryptedUnicode(secret)
    avu.vault = vault
    assert avu.data == secret
    assert avu == secret


# backwards compatiblity for jinja2 templating

# Generated at 2022-06-11 09:27:39.369568
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    assert not AnsibleVaultEncryptedUnicode('foo') >= 'bar'
    assert AnsibleVaultEncryptedUnicode('foo') >= 'foo'
    assert AnsibleVaultEncryptedUnicode('foo') >= 'bar'


# Generated at 2022-06-11 09:27:48.783709
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from .vault import VaultLib
    from .vault import VaultSecret

    secret = VaultSecret(password='password')
    vault = VaultLib(secret)

    value1 = AnsibleVaultEncryptedUnicode.from_plaintext('value', vault, secret)
    value2 = AnsibleVaultEncryptedUnicode.from_plaintext('value', vault, secret)

    assert value1 == value2
    assert value1 != 'value'
    assert not value1 == 'value'
    assert not value1 != value2

# For backward compatibility
AnsibleVaultSecret = AnsibleVaultEncryptedUnicode



# Generated at 2022-06-11 09:27:49.990830
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    avu = AnsibleVaultEncryptedUnicode(None)
    assert not avu.__ge__(None)



# Generated at 2022-06-11 09:28:02.480529
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    data_cases_encoded = [
        ["====\nVzMvNjU6Wm0xT3IxM2hvMg==", ['Zm9v', 'f00']],
        ["====\nVzMvNjU6Yml6TlBPdz09", ['Zm9v', 'baz']],
        ["====\nVzMvNjU6aXoyblV2Q2c9PQ==", ['bar', 'b0f']],
    ]
    for case_encoded, case in data_cases_encoded:
        data = AnsibleVaultEncryptedUnicode.from_plaintext(case[0], vaultlib.VaultLib(None), case[1])
        assert(data.data >= 'a')

# Generated at 2022-06-11 09:28:14.109437
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    # We try to instantiate two AnsibleVaultEncryptedUnicode
    # objects and test __ge__
    if AnsibleVaultEncryptedUnicode.__ge__ is not None:
        b = AnsibleVaultEncryptedUnicode('b')
        b.data = 'b'
        c = AnsibleVaultEncryptedUnicode('c')
        c.data = 'c'
        raise Exception('AnsibleVaultEncryptedUnicode.__ge__ is not None')
    elif AnsibleVaultEncryptedUnicode.__ge__ is not None:
        b = AnsibleVaultEncryptedUnicode('b')
        b.data = 'b'
        raise Exception('AnsibleVaultEncryptedUnicode.__ge__ is not None')

# Generated at 2022-06-11 09:28:20.818270
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import unittest

    class TestAnsibleVaultEncryptedUnicode___ne__(unittest.TestCase):

        def setUp(self):
            self.vault = VaultLib('test')
            self.plain_text = 'vault_test'
            self.cipher_text = self.vault.encrypt(self.plain_text, None)

        def test__ne__whenAVUStringNotEqualToAVUAndVaultHasNoSecret(self):
            avu = AnsibleVaultEncryptedUnicode(self.cipher_text)
            avu.vault = self.vault

            avu2 = AnsibleVaultEnc

# Generated at 2022-06-11 09:28:27.151540
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    cls = AnsibleVaultEncryptedUnicode
    class TestVault:
        def decrypt(self, ciphertext, obj=None):
            return 'bar'
    vault = TestVault()
    avu = cls.from_plaintext('foo', vault, 'secret')
    assert avu != 'foo'
    assert avu == 'bar'



# Generated at 2022-06-11 09:28:31.022913
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('secret', vault=None, secret='secret')
    res = avu + 'plain'
    expected_res = 'secretplain'
    assert to_text(res) == expected_res


# Generated at 2022-06-11 09:28:41.680747
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test for failure with AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256")
    avu2 = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256")
    with pytest.raises(AnsibleVaultError):
        print(avu + avu2)

    avu = AnsibleVaultEncryptedUnicode("something")
    assert avu + avu2 == "somethingsomething"
    assert avu + "something" == "somethingsomething"
    assert "something" + avu == "somethingsomething"


# Generated at 2022-06-11 09:28:53.773999
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    seq = 'foobar'
    secret = 'secret'
    vault = vaultlib.VaultLib(password='$ANSIBLE_VAULT;1.1;AES256')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu == seq


# Generated at 2022-06-11 09:28:59.008435
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    class vault(object):
        pass
    avueu = AnsibleVaultEncryptedUnicode.from_plaintext(u'x', vault, b'y')
    avueu.data = u'x'
    assert(avueu.__ne__(u'y'))
    assert(not avueu.__ne__(u'x'))


# Generated at 2022-06-11 09:29:09.759798
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import ansible.parsing.vault
    class Vault(object):
        def __init__(self, secret):
            self.secret = secret
        def encrypt(self, plaintext, secret=None):
            if secret is None:
                secret = self.secret
            return plaintext + ' ' + secret
        def decrypt(self, ciphertext, obj=None):
            return ciphertext.split()[0]
        def is_encrypted(self, ciphertext):
            return len(ciphertext) > 0

    vault = Vault('secret')
    val = 'value'
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(val, vault, vault.secret)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(val, vault, vault.secret)
    avu

# Generated at 2022-06-11 09:29:23.977855
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    plain_text = AnsibleVaultEncryptedUnicode(to_bytes('foo', errors='surrogate_or_strict'))
    assert plain_text.is_encrypted() is False

    plain_text_v1 = AnsibleVaultEncryptedUnicode(to_bytes('$ANSIBLE_VAULT;1.1;AES256;foo\nbar\n'))
    assert plain_text_v1.is_encrypted() is False

    plain_text_v2 = AnsibleVaultEncryptedUnicode(to_bytes('$ANSIBLE_VAULT;2.0;AES256;foo\nbar\n'))
    assert plain_text_v2.is_encrypted() is False

    plain_text_v3 = AnsibleVaultEnc

# Generated at 2022-06-11 09:29:29.494267
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test for __ne__ method defined in class AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    vault_password = "VaultPassword"
    vault = VaultLib([vault_password])
    value1 = AnsibleVaultEncryptedUnicode.from_plaintext('secret', vault, vault_password)
    value2 = AnsibleVaultEncryptedUnicode.from_plaintext('secret', vault, vault_password)
    # string equality
    assert(value1 != value2)
    # byte sequence equality
    assert(value1.encode() != value2.encode())


# Generated at 2022-06-11 09:29:41.619556
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test cases covering the first half of the commented out if statement that checks
    # if __ne__ and __eq__ are symmetric, as they should be.
    # Tests that ensure that the two functions return opposite results and that they
    # both return the expected result.
    # Test zero case
    vault = None
    secret = 'test'
    test_obj = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
    test_obj_2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)

# Generated at 2022-06-11 09:29:52.857312
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.vault import get_vault_secret
    import os
    import tempfile
    import unittest

    class AnsibleVaultEncryptedUnicode___eq__TestCase(unittest.TestCase):

        def test_encrypt_decrypt(self):
            vault = VaultLib(get_file_vault_secret(['./group_vars/vault.key']))
            self.assertEqual(vault.is_encrypted(to_bytes('This is encrypted', errors='surrogate_or_strict')), False)

            avu = AnsibleVaultEncrypted

# Generated at 2022-06-11 09:30:02.367866
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib, VaultSecret
    import os

    vault = VaultLib([])
    secret = VaultSecret(os.environ.get('VAULT_PASSWD'))

    s = u'123'
    av = AnsibleVaultEncryptedUnicode.from_plaintext(s, vault, secret)

    assert av == s
    assert av == u'123'
    assert av == '123'
    assert not (av == '1234')
    assert not (av == u'1234')
    assert not (av == 123)


# Generated at 2022-06-11 09:30:11.669777
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    if _sys.version_info < (3, 0):
        str_class = str
    else:
        str_class = bytes
    avue = AnsibleVaultEncryptedUnicode('abc')
    assert isinstance(avue.__getslice__(0, 1), str_class)
    assert avue.__getslice__(0, 1) == 'a'
    assert isinstance(avue.__getslice__(1, 2), str_class)
    assert avue.__getslice__(1, 2) == 'b'
    assert isinstance(avue.__getslice__(2, 3), str_class)
    assert avue.__getslice__(2, 3) == 'c'


# Generated at 2022-06-11 09:30:14.494329
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Setup
    vault_string = '12345678901234567801234567'
    secret = 'NA'
    vault = vaultlib.VaultLib(secret)

    # Execution
    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext(vault_string, vault, secret)

    # Verification
    assert encrypted_string == vault_string



# Generated at 2022-06-11 09:30:31.141857
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import unittest
    import ansible.utils.vault as ansivault
    secret = 's3cr3t'
    iv = AnsibleVaultEncryptedUnicode.from_plaintext(secret, vault=ansivault.AESVault(b'aaaaaaaaaaaaaaaa'), secret=secret)
    iv.vault = ansivault.AESVault(b'bbbbbbbbbbbbbbbb')
    class AnsibleVaultEncryptedUnicode_test(unittest.TestCase):
        def test___ne__NotEqual(self):
            self.assertTrue(iv.__ne__(secret))
        def test___ne__Equal(self):
            self.assertFalse(iv.__ne__(iv))
    unittest.main(exit=False, module=__name__)

test_

# Generated at 2022-06-11 09:30:40.471342
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:30:48.686491
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    '''
    Test method __eq__ of AnsibleVaultEncryptedUnicode.
    When the data from the object is equal to the string,
    then the result is true.

    >>> import ansible.parsing.vault
    >>> vault = ansible.parsing.vault.VaultLib('my_password')
    >>> avu = AnsibleVaultEncryptedUnicode('foo')
    >>> avu.vault = vault
    >>> avu == 'foo'
    True
    '''


# Generated at 2022-06-11 09:30:58.155308
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    '''Test AnsibleVaultEncryptedUnicode__eq__'''

    import tempfile
    import os

    # this is needed to load the fixtures used in these tests
    test_dir = os.path.dirname(__file__)

    def make_temp_file(content, filename=""):
        fd, path = tempfile.mkstemp(text=True, prefix='ansible_vault_unit_test_utils_', suffix=filename)
        if content:
            with os.fdopen(fd, 'w') as tmp:
                tmp.write(content)
        return path

    try:
        import ansible.parsing.vault as vault
    except ImportError as e:
        print(e)
        print("skipping since python module ansible.parsing.vault is not installed")
        return

# Generated at 2022-06-11 09:31:09.669021
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:31:17.699558
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    # set up everything for test
    vault_password = "vault_password"
    vault_id = b"$ANSIBLE_VAULT;1.1;AES256"
    # create a vault object
    vault = VaultLib(vault_password)
    # create an encrypted ansible vault object
    content = "password"
    encrypted_avu = AnsibleVaultEncryptedUnicode.from_plaintext(content, vault, vault_password)
    encrypted_avu.vault = vault
    # test encrypted ansible vault object
    # - should be encrypted
    assert encrypted_avu.is_encrypted() is True
    # create an non-encrypted ansible vault object
    avu = AnsibleVaultEncryptedUnicode(vault_id)
    #

# Generated at 2022-06-11 09:31:30.071189
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(['--encrypt-vault-id', 'test@prompt'])
    password = b'password'

    # Test dict with string containing "ANSIBLE_VAULT",
    # which is the only test that matters
    data = vault.encrypt(r'$ANSIBLE_VAULT;1.1;AES256;prompt', password)
    avue = AnsibleVaultEncryptedUnicode(data)
    avue.vault = vault
    assert(avue.is_encrypted() is True)

    # Test string not containing "ANSIBLE_VAULT", which
    # should work, but is just a form of a negative test
    data = vault.encrypt(r'hello world', password)
    avue = AnsibleVaultEncrypted

# Generated at 2022-06-11 09:31:40.824012
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib

    secret = b'foo'
    plaintext = b'bar'
    ciphertext = VaultLib.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = VaultLib(secret)

    assert avu == plaintext
    assert avu != ciphertext
    assert avu != "bar"
    assert avu != b"bar"


# Generated at 2022-06-11 09:31:48.595219
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    vault_password = 'vault-password'
    v = vault.VaultLib(vault_password)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("foo", v, vault_password)
    assert avu == 'foo'
    assert avu != 'bar'
    assert avu == AnsibleVaultEncryptedUnicode.from_plaintext("foo", v, vault_password)
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext("bar", v, vault_password)
    assert avu != AnsibleUnicode("foo")



# Generated at 2022-06-11 09:31:50.519141
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    tst = AnsibleVaultEncryptedUnicode.from_plaintext('simple plain text', MockVaultLib(), 'mypassword')
    assert tst == 'simple plain text'
    assert tst != 'simple plain text not'



# Generated at 2022-06-11 09:32:02.485429
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    sl = 'foo'
    secret = 'password'
    vault = VaultLib('sha1', secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(sl, vault, secret)
    assert avu == sl
    # test when vault is None
    avu.vault = None
    assert avu == avu._ciphertext


# Generated at 2022-06-11 09:32:11.841437
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.utils import overrides

    # Create a Vault object. We will later assign this Vault object to the
    # .vault attribute of the AnsibleVaultEncryptedUnicode object.

    # BytesIO doesn't have a name attribute. We can't assign a name to
    # sys.stdin, so we just use a plain file object as our input.
    input_f = open('/dev/null')

    # The Vault object will not actually read a password from the input
    # stream that we supply. It just needs a stream.
    vault = overrides.vault.VaultLib('password', input_f)

    # Create an AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode("test_string")
    avu.vault = vault

    # Test if __ne__ behaves

# Generated at 2022-06-11 09:32:19.626709
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault
    import os

    vault = ansible.parsing.vault.VaultLib(format=ansible.parsing.vault.VAULT_FORMAT_2_0)

    ciphertext = vault.encrypt(os.urandom(16), b'hello')

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    assert avu.is_encrypted()

    del vault
    del ciphertext
    del avu


# Generated at 2022-06-11 09:32:27.068537
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Need a test case for the vault not being encrypted, but this is
    # the case where the vault is encrypted, and the other object is not
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = '123'
    plaintext = 'this is plaintext'
    ciphertext = vault._encrypt(to_bytes(plaintext), secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    avu.vault = vault
    assert(avu != ciphertext)


# Generated at 2022-06-11 09:32:27.777410
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    pass



# Generated at 2022-06-11 09:32:37.338046
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    try:
        from ansible.parsing.vault import VaultLib
    except ImportError:
        raise AssertionError('Test failure: ansible-vault is not installed')

    vault0 = VaultLib(password='foobar')
    vault1 = VaultLib(password='barfoo')

    ciphertext0a = vault0.encrypt('foo')
    ciphertext0b = vault0.encrypt('foo')
    ciphertext1  = vault1.encrypt('foo')

    a = AnsibleVaultEncryptedUnicode(ciphertext0a)
    b = AnsibleVaultEncryptedUnicode(ciphertext0b)
    c = AnsibleVaultEncryptedUnicode(ciphertext1)

    a.vault = vault0
    b.vault = vault0

# Generated at 2022-06-11 09:32:47.114107
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    '''
    This function will be used as part of unit test, to test method __eq__
    of class AnsibleVaultEncryptedUnicode.
    '''
    from ansible.parsing.vault import VaultLib
    secret = u'!v3ry$3cr3t'
    m_plaintext = u'hello'
    m_vault = VaultLib(secret)
    m_ciphertext = m_vault.encrypt(m_plaintext, secret)
    m_avu = AnsibleVaultEncryptedUnicode(m_ciphertext)
    m_avu.vault = m_vault
    print("m_avu.vault = ", m_avu.vault)
    print("m_avu = ", m_avu)

# Generated at 2022-06-11 09:32:51.072628
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = 'secret'

    plaintext = 'the quick brown fox'
    plain = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert not plain.is_encrypted()

    ciphertext = vault.encrypt(plaintext, secret)
    cipher = AnsibleVaultEncryptedUnicode(ciphertext)
    assert cipher.is_encrypted()


# Generated at 2022-06-11 09:33:03.018690
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.utils import vault
    from ansible.parsing.vault import VaultLib

    vault_password = 'password'
    string_actual = "string_actual"
    string_different = "string_different"

    # When password is given
    ansible_vault = VaultLib([vault_password])
    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext(string_actual, ansible_vault, 'password')
    encrypted_string.vault = ansible_vault
    encrypted_string_different = AnsibleVaultEncryptedUnicode.from_plaintext(string_different, ansible_vault, 'password')
    encrypted_string_different.vault = ansible_vault

    # When the two strings are different

# Generated at 2022-06-11 09:33:08.762223
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    if _sys.version_info[0] == 2:
        plaintext = u'foo'
    else:
        plaintext = u'foo'.encode('utf-8')

    avu = AnsibleVaultEncryptedUnicode(plaintext)
    assert not avu.is_encrypted()


# Generated at 2022-06-11 09:33:29.616323
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    try:
        import ansible.parsing.vault
        try:
            vault = ansible.parsing.vault.VaultLib([])
        except ansible.parsing.vault.AnsibleVaultError:
            # FIXME: this is a horrible hack to prevent import errors from
            # occuring outside of the ansible source tree, to fix this we need to
            # use ansible.parsing.vault.Vault
            vault = None
    except ImportError:
        vault = None

    # Test with a plain string
    plain_str = 'plain string'
    avu1 = AnsibleVaultEncryptedUnicode(plain_str)
    assert not avu1.is_encrypted()

    # Test with an encrypted string is not
    if vault is None:
        return
    encrypted_

# Generated at 2022-06-11 09:33:40.559580
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:33:47.860706
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    class Vault:
        def __init__(self):
           self._is_encrypted = False
        def is_encrypted(self, data):
            return self._is_encrypted
        def decrypt(self, data, obj):
            return data
        def encrypt(self, data, obj):
            return data

    vault = Vault()
    secret = ""
    obj1 = AnsibleVaultEncryptedUnicode.from_plaintext("some text", vault, secret)
    obj2 = AnsibleVaultEncryptedUnicode.from_plaintext("some text", vault, secret)
    obj3 = AnsibleVaultEncryptedUnicode.from_plaintext("some other text", vault, secret)

    if not (obj1 == obj1):
        raise AssertionError("Test 1 failed")

# Generated at 2022-06-11 09:33:50.685066
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    x = AnsibleVaultEncryptedUnicode(b'abc')
    y = AnsibleVaultEncryptedUnicode(b'abc')
    assert(x == y)


# Generated at 2022-06-11 09:33:55.801340
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    Test the __ne__ method of AnsibleVaultEncryptedUnicode
    """
    avu = AnsibleVaultEncryptedUnicode(None)

    # Test if the __ne__ method returns True if the vault is not set
    if avu.__ne__('foo'):
        print("__ne__: OK")
    else:
        print("__ne__: KO")


# Generated at 2022-06-11 09:34:00.186569
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Set up test fixtures
    avu = AnsibleVaultEncryptedUnicode('test')
    avu.vault = 'TEST'

    # Exercise code under test
    # This should not raise a AttributeError
    result = avu != 'test'

    # Verify
    assert result == True



# Generated at 2022-06-11 09:34:04.153582
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode('test_test')
    try:
        avu.vault = MockVault()
    except Exception:
        pass
    assert avu != 'test'
    assert avu != 'test_test'


# Generated at 2022-06-11 09:34:13.244522
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # test valid output for vault id (Vault 1.0)
    assert AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.0;AES256;dGVzdA==\nYnl0ZSBzdHJpbmc=\n').is_encrypted() == True
    # test valid output for vault id (Vault 2.0)
    assert AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;2.0;AES256;dGVzdA==;3d2ca2d08eba9b5c5d5227b0eaecac1c\nYnl0ZSBzdHJpbmc=\n').is_encrypted() == True
    # test valid output for vault id (Vault 2.0)
    assert AnsibleVaultEncryptedUnic

# Generated at 2022-06-11 09:34:23.043813
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu == 'test'

    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu == AnsibleVaultEncryptedUnicode('test')

    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'est'

    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != AnsibleVaultEncryptedUnicode('est')

    from ansible.parsing.vault import VaultLib
    v = VaultLib()
    avu = AnsibleVaultEncryptedUnicode('test', vault=v, secret='test')
    assert avu == 'test'


# Generated at 2022-06-11 09:34:29.747078
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import ansible.parsing.vault
    secret = 'test'
    plaintext = b"plaintext"
    vault_plaintext = ansible.parsing.vault.AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, ansible.parsing.vault.VaultLib(1), secret)
    assert not vault_plaintext.__ne__(plaintext)
    assert vault_plaintext.__ne__(b'xxx')


# Generated at 2022-06-11 09:34:47.904138
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # While this is not unit test, this tests the ne implementation
    # that is the cause of a bug in ansible-test.
    #
    # To execute this you can run this script by hand.
    #

    # initialize the vault object
    #
    # just use the default vault we use to run the Ansible tests
    from ansible.parsing.vault import VaultLib as AnsibleVault

    vault = AnsibleVault('/home/ansitest/.vault_pass.txt')

    # test 1:
    #
    # just a simple string
    txt1 = AnsibleUnicode(u"plain text")

    # test 2:
    #
    # Use the from_plaintext function.

# Generated at 2022-06-11 09:34:56.483080
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'somesecret')
    assert avu.is_encrypted()

    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;test\n633366376530663465333664343866653737666433353364373730646461633537386165376436\n64383430646462653364346639316130646532323033633066643266').data
    assert avu.is_encrypted()

    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()



# Generated at 2022-06-11 09:35:03.903092
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY2, PY3
    vault = VaultLib(['ansible-vault', 'view', '--vault-password-file=./.vault_pass.txt'])
    secret = vault.read_vault_secret('/.vault_pass.txt')

    # password is ``'ansible'``

# Generated at 2022-06-11 09:35:12.444169
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:35:15.224660
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    u1 = AnsibleVaultEncryptedUnicode(b'foo')
    u2 = AnsibleVaultEncryptedUnicode(b'ba')
    assert u1 != u2


# Generated at 2022-06-11 09:35:23.356475
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:35:31.758598
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    import unittest
    # For python 2.6 we need to implement load_tests from unittest.TestLoader
    if not hasattr(unittest.TestLoader, 'load_tests'):
        from ansible.utils.py26_compat import load_tests

    class TestAnsibleVaultEncryptedUnicode(unittest.TestCase):
        def setUp(self):
            self.password = 'ansible'
            self.vault = VaultLib(self.password)
            self.clear_texts = [
                'This is a clear text',
                'This is a clear text',
                'This is a clear text'
            ]