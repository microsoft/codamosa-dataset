

# Generated at 2022-06-11 09:25:57.149052
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    password = 'secret'
    plain = 'password'
    vault = VaultLib(['--vault-password-file', '.vault_pass'])
    obj = AnsibleVaultEncryptedUnicode.from_plaintext(plain, vault, password)

    # test non-equal:
    assert obj.__ne__('password')
    assert obj.__ne__('pass')

    # test equal:
    assert not obj.__ne__(plain)


# Generated at 2022-06-11 09:26:09.185572
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    class MockVault(object):
        def __init__(self):
            self.secrets = {}

        def is_encrypted(self, data):
            return 'encrypted' in data

        def encrypt(self, data, secret):
            self.secrets[secret] = data
            return secret

        def decrypt(self, data, obj):
            return self.secrets[data]

    secret = 'secret'
    mock_vault = MockVault()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('encrypted', mock_vault, secret)

    assert avu.data == 'encrypted'
    assert avu.find(secret) == -1
    assert avu.find('encrypt') != -1

# Generated at 2022-06-11 09:26:13.671688
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    #This is not a real test, it just exists to demonstrate the use of the method being tested.
    obj = AnsibleVaultEncryptedUnicode(ciphertext=b"test")
    obj.data = b"test"
    print(obj.__ge__('test'))


# Generated at 2022-06-11 09:26:23.785693
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    from ansible.utils.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    import os
    import pytest
    try:
        from ansible.plugins.loader import vault_secret_service
    except ImportError:
        pytest.skip('vault_secret_service not available')

    text = 'some sample text'
    secret = 'secret'
    vault = VaultLib([], 'test')
    # Make sure that the file is output in binary mode, so there are no
    # unexpected newlines.
    tmp_filename = '/tmp/test.vault'
    with open(tmp_filename, 'wb') as f:
        f.write(vault.encrypt(text, secret))
        # Demonstrate that reading the file with the wrong password

# Generated at 2022-06-11 09:26:33.580168
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    a = AnsibleVaultEncryptedUnicode(to_bytes('123445'))
    b = AnsibleVaultEncryptedUnicode(to_bytes('123455'))
    c = AnsibleVaultEncryptedUnicode(to_bytes('123444'))
    d = '123444'
    e = 123444

    assert a.__le__(b)
    assert c.__le__(a)
    assert c.__le__(d)
    assert c.__le__(e)


# Generated at 2022-06-11 09:26:45.059704
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Different types
    assert AnsibleVaultEncryptedUnicode('hello') != 5
    assert AnsibleVaultEncryptedUnicode('hello') != 'hello'
    assert AnsibleVaultEncryptedUnicode('hello') != b'hello'

    # Different values
    assert AnsibleVaultEncryptedUnicode('hello') != AnsibleVaultEncryptedUnicode('world')
    assert AnsibleVaultEncryptedUnicode('hello') != AnsibleVaultEncryptedUnicode('hello ')
    assert AnsibleVaultEncryptedUnicode('hello ') != AnsibleVaultEncryptedUnicode('hello')

    # Same values
    assert not AnsibleVaultEncryptedUnicode('hello') != AnsibleVaultEncryptedUnicode('hello')

    # Not encrypted
    assert not AnsibleVaultEnc

# Generated at 2022-06-11 09:26:46.155546
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avue = AnsibleVaultEncryptedUnicode("abc")
    assert(avue != "abc")


# Generated at 2022-06-11 09:26:47.957584
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    assert AnsibleVaultEncryptedUnicode('foobar').find('o', 0, 100) == 1
    assert AnsibleVaultEncryptedUnicode('foobar').find('z', 0, 100) == -1


# Generated at 2022-06-11 09:26:52.341157
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    import pytest
    obj1 = AnsibleVaultEncryptedUnicode('testing')
    obj2 = AnsibleVaultEncryptedUnicode('testing')
    assert obj1.__ge__(obj2)

# Generated at 2022-06-11 09:26:55.038340
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    # create vault
    vault = VaultLib([])
    vault.open_or_create()
    # create ciphertext
    plaintext = 'test'
    ciphertext = vault.encrypt(plaintext, 'test')
    # create object
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    # test
    assert avu.is_encrypted()



# Generated at 2022-06-11 09:27:04.025264
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Arrange
    import ansible.parsing.vault
    vault = ansible.parsing.vault.AnsibleVaultLib(password='ansible')
    ciphertext = vault.encrypt("string")
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    # Assert
    assert avu.is_encrypted()


# Generated at 2022-06-11 09:27:15.735704
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    import re
    def find (self, pattern, start=0, end=0):
        if isinstance(pattern, AnsibleVaultEncryptedUnicode):
            pattern = pattern.data
        pattern = re.escape(pattern)

        p = re.compile(pattern)
        str = self.data[start:end]
        res = p.search(str)
        if res is not None:
            return res.start() + start
        else:
            return -1
    AnsibleVaultEncryptedUnicode.find = find


AnsibleVaultEncryptedUnicode.test_AnsibleVaultEncryptedUnicode_find = test_AnsibleVaultEncryptedUnicode_find



# Generated at 2022-06-11 09:27:19.180287
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    av1 = AnsibleVaultEncryptedUnicode('1')
    av2 = AnsibleVaultEncryptedUnicode('2')
    assert av1 != av2
    assert not(av1 != av1)



# Generated at 2022-06-11 09:27:30.765916
# Unit test for method find of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:27:31.948987
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    pass


# Generated at 2022-06-11 09:27:44.684901
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    assert AnsibleVaultEncryptedUnicode("aaa:bbb").find("aaa") == 0, "AnsibleVaultEncryptedUnicode('aaa:bbb').find('aaa') != 0"
    assert AnsibleVaultEncryptedUnicode("aaa:bbb").find(":") == 3, "AnsibleVaultEncryptedUnicode('aaa:bbb').find(':') != 3"
    assert AnsibleVaultEncryptedUnicode("aaa:bbb").find("ccc") == -1, "AnsibleVaultEncryptedUnicode('aaa:bbb').find('ccc') != -1"
    assert AnsibleVaultEncryptedUnicode("").find("") == 0, "AnsibleVaultEncryptedUnicode('').find('') != 0"
    assert AnsibleVaultEnc

# Generated at 2022-06-11 09:27:52.283508
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    string_to_encrypt = "testing"
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(string_to_encrypt, '$ANSIBLE_VAULT;1.2;AES256;ansible', 'asdfaefawe')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(string_to_encrypt, '$ANSIBLE_VAULT;1.2;AES256;ansible', 'asdfaefawe')
    res = avu1 == avu2
    assert res

# Generated at 2022-06-11 09:28:02.708807
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    message = 'test __ne__'
    secret = 'secret'
    vault = vaultlib.VaultLib('newvaultpassword')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(message, vault, secret)
    assert message != avu, 'fails __ne__ comparison with plaintext'
    avu2 = AnsibleVaultEncryptedUnicode(vault.encrypt(message, secret))
    avu2.vault = vault
    assert avu != avu2, 'fails __ne__ comparison with different ciphertext'



# Generated at 2022-06-11 09:28:14.246267
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # these are the base64 encoded versions of the cleartext
    # vault passwords used in examples in the VaultAES class
    cleartext_passwords = (
        b'\xaa\xaa\xaa\xaa\xaa\xaa\xaa\xaa',
        b'\x44\x44\x44\x44\x44\x44\x44\x44',
        b'\x00\x00\x00\x00\x00\x00\x00\x00',
    )

# Generated at 2022-06-11 09:28:27.477303
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test when object is not encrypted
    ####################################################################################

    # Create object
    try:
        ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode.from_plaintext('not_encrypted', vault=None, secret='not_used')
    except Exception as e:
        raise AssertionError('Error creating not_encrypted AnsibleVaultEncryptedUnicode')
    assert(ansible_vault_encrypted_unicode != None)

    # Test when argument is different than the plaintext
    assert(ansible_vault_encrypted_unicode != 'encrypted')
    assert(ansible_vault_encrypted_unicode != b'encrypted')

    # Test when argument is the same as the plaintext
    assert(ansible_vault_encrypted_unicode != 'not_encrypted')

    # Test

# Generated at 2022-06-11 09:28:35.754297
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # test __eq__ for class AnsibleVaultEncryptedUnicode
    obj = AnsibleVaultEncryptedUnicode(to_bytes("foo"))
    result = obj.__eq__(to_bytes("foo"))
    assert result == False



# Generated at 2022-06-11 09:28:37.819313
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode('encrypted_data') != 'encrypted_data'


# Generated at 2022-06-11 09:28:46.693404
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256

    secret = VaultSecret('secret')
    aes256 = VaultAES256(secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('Hello World', aes256, secret)

    assert 0 == avu.find('H', 0, len(avu))
    assert 1 == avu.find('e', 1, len(avu))
    assert 6 == avu.find('W', 6, len(avu))

    assert -1 == avu.find('Z')
    assert -1 == avu.find('H', 1, len(avu))

# Generated at 2022-06-11 09:28:52.519837
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    vs = VaultSecret('notasecret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', VaultLib(), vs)
    assert avu != 'foo'
    return


# Generated at 2022-06-11 09:29:03.641359
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault as vault


# Generated at 2022-06-11 09:29:10.406245
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    #arrange
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;9.9;AES256\n3332313332313331')
    #act
    is_encrypted = avu.is_encrypted()
    #assert
    assert is_encrypted == True

    #arrange
    avu1 = AnsibleVaultEncryptedUnicode('Test')
    #act
    is_encrypted1 = avu1.is_encrypted()
    #assert
    assert is_encrypted1 == False


# Generated at 2022-06-11 09:29:12.021781
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass



# Generated at 2022-06-11 09:29:25.679032
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    testString = AnsibleVaultEncryptedUnicode('foo')
    assert testString.find('o') == 1 
    assert testString.find('o', 1) == 1
    assert testString.find('o', 1, 2) == 1
    assert testString.find('x') == -1
    assert testString.find('o', 2) == -1
    assert testString.find('foo', 1, 3) == -1
    assert testString.find(AnsibleVaultEncryptedUnicode('o')) == 1
    assert testString.find(AnsibleVaultEncryptedUnicode('o'), 1) == 1
    assert testString.find(AnsibleVaultEncryptedUnicode('o'), 1, 2) == 1

# Generated at 2022-06-11 09:29:39.251157
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    s1 = b'abc'
    s1_encrypted = AnsibleVaultEncryptedUnicode(s1)
    s2 = b'abc'
    s2_encrypted = AnsibleVaultEncryptedUnicode(s2)

    # When both strings are encrypted, then test looks like this
    # (the unencrypted string is used for the test)
    assert s1_encrypted == s2_encrypted

    # When one of the strings is encrypted, then test looks like this
    assert s1_encrypted == s2

    # When both strings are unencrypted, then test looks like this
    assert s1 == s2

    # But not these!
    assert not (s1 == s2_encrypted)
    assert not (s1_encrypted == s2_encrypted)


# Generated at 2022-06-11 09:29:44.624905
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
  from ansible.parsing.vault import VaultLib
  f = open('/home/nandita/ansible/.vault-pass', 'r')
  vault = VaultLib('/home/nandita/ansible/.vault-pass')
  plaintext = "pswd123,pswd234"
  ciphertext = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext,vault,f.read())
  res = ciphertext.find('s')
  assertEqual(res,0)
  res = ciphertext.find('45')
  assertEqual(res, -1)


# Generated at 2022-06-11 09:29:56.323519
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ''' Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode'''
    assert AnsibleVaultEncryptedUnicode(to_bytes('test')).__eq__('test')
    assert not AnsibleVaultEncryptedUnicode(to_bytes('test')).__eq__('test2')
    assert AnsibleVaultEncryptedUnicode(to_bytes('test')).__ne__('test2')


# Generated at 2022-06-11 09:30:07.419549
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:30:13.207316
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode('123').__eq__('123') == True
    assert AnsibleVaultEncryptedUnicode('123').__eq__('456') == False
    assert AnsibleVaultEncryptedUnicode('123').__eq__(AnsibleVaultEncryptedUnicode('123')) == True
    assert AnsibleVaultEncryptedUnicode('123').__eq__(AnsibleVaultEncryptedUnicode('456')) == False


# Generated at 2022-06-11 09:30:23.395967
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    secret = u'password'
    plaintext = u'This is plaintext'
    vaultlib = vault.VaultLib(secret=secret)

    # Test if same plaintext returns true
    ciphertext1 = vaultlib.encrypt(plaintext, secret=secret)
    ciphertext2 = vaultlib.encrypt(plaintext, secret=secret)
    avu1 = AnsibleVaultEncryptedUnicode(ciphertext1)
    avu2 = AnsibleVaultEncryptedUnicode(ciphertext2)
    avu1.vault = vaultlib
    avu2.vault = vaultlib
    assert(avu1 == avu2)

    # Test if different plaintext returns false
    plaintext1 = u'This is plaintext 1'
    plain

# Generated at 2022-06-11 09:30:32.733031
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible import vault

    secret = to_bytes('test')
    vault_pass = to_bytes('test')
    encrypted_text = vault.encrypt(secret, vault_pass)
    avu = AnsibleVaultEncryptedUnicode(encrypted_text)
    vault_object = vault.VaultLib(vault_pass)
    avu.vault = vault_object
    assert avu.is_encrypted() == True
    assert avu.data == secret
    assert avu.is_encrypted() == False
    assert avu.data == secret


# Generated at 2022-06-11 09:30:41.360493
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    # test with old password

# Generated at 2022-06-11 09:30:51.634642
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    secureKey = "testkey"
    vault = VaultLib("testvault", secureKey)
    secret = b"testsecret"
    plaintext = "testplaintext"
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    nonmatchingplaintext = "testplaintextnotmatching"
    nonmatchingavu = AnsibleVaultEncryptedUnicode.from_plaintext(nonmatchingplaintext, vault, secret)

    assert (avu != nonmatchingavu)


# Generated at 2022-06-11 09:30:54.038090
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    a = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None)
    assert a == 'test'
    assert not (a != 'test')



# Generated at 2022-06-11 09:31:04.246120
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

    def _test_encrypted_equality(encrypted_object, other):
        if type(other) == text_type:
            return encrypted_object == other
        return False

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(u'password1234', vault, u'vault')
    assert _test_encrypted_equality(avu, u'password1234')
    assert _test_encrypted_equality(avu, u'password123') is False
    assert avu == u'password1234'
    assert avu != u'password123'

    # If vault is not set, eq returns false
    avu = AnsibleVaultEncryptedUnicode(u'password1234')

# Generated at 2022-06-11 09:31:14.225754
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    import random
    import string
    import unittest
    # TODO: use the vault unit test here
    # This is a very basic test, to verify the VaultEncryptedUnicode object
    # can be used in a expected way.
    # It would be nice to have a full test of the object as a whole
    #
    #  1. Create a random string
    #  2. Create a AnsibleVaultEncryptedUnicode object
    #  3. Ensure it does not match the plaintext string
    #  4. Ensure the two objects do compare equal

# Generated at 2022-06-11 09:31:33.891668
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import AESMode
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAEADCipher

    password = VaultSecret('ansible')
    user_id = 'user3'
    password2 = VaultSecret('ansible2')
    user_id2 = 'user32'

    cipher = VaultAEADCipher(VaultAES256GCM())


# Generated at 2022-06-11 09:31:38.509587
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    secret = "test_secret"
    vault = VaultLib(secret)

    seq = "test_data"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert(avu.is_encrypted())


# Generated at 2022-06-11 09:31:48.083472
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([], None)

# Generated at 2022-06-11 09:31:53.923502
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import random

    from ansible.parsing.vault import VaultLib

    alph = string.ascii_letters + string.digits
    str1 = ''.join(random.choice(alph) for _ in range(100))
    str2 = ''.join(random.choice(alph) for _ in range(100))

    vault = VaultLib('test')
    vault.update({
        'decrypt_method': 'plaintext',
        'password': 'test'
    })

    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(str1, vault, 'test')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(str1, vault, 'test')

# Generated at 2022-06-11 09:32:00.438607
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret
    vault_password_filename = '~/.vault_password.txt'

    # Create un-encrypted text
    data = 'text to encrypt'
    # Create encrypted text
    vault = VaultLib(get_file_vault_secret([vault_password_filename]))
    ciphertext = vault.encrypt(data, None)
    # Create AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    # Test is_encrypted
    assert avu.is_encrypted() == True

    # Create un-encrypted AnsibleVaultEncryptedUnicode object

# Generated at 2022-06-11 09:32:02.068896
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode("foo")
    assert avu.__ne__("foo") == True


# Generated at 2022-06-11 09:32:11.480256
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    def create_avu(seq, vault):
        avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
        avu.vault = vault
        return avu

    vault = vault.VaultLib('password')
    secret = 'password'

    # Check that __eq__ is defined
    avu_a = create_avu('a', vault)
    avu_b = create_avu('b', vault)
    assert '__eq__' in dir(avu_a)
    assert '__eq__' in dir(avu_b)

    # Check that 'a' equals 'a'
    assert avu_a == 'a'

    # Check that 'a' does not equal 'b'
    assert avu_a != 'b'

    # Check comparing two Ans

# Generated at 2022-06-11 09:32:17.499786
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    import ansible.parsing.vault as vault

    # test two same plaintext data
    plaintext = 'plain text'
    ciphertext = vault.VaultLib().encrypt(plaintext)
    avu1 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu2 = AnsibleVaultEncryptedUnicode(ciphertext)

    assert avu1 == avu2



# Generated at 2022-06-11 09:32:27.347355
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    ansible_vault = VaultLib('test')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode.from_plaintext('test', ansible_vault, 'test')
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', ansible_vault, 'test')
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode.from_plaintext('test_x', ansible_vault, 'test')
    assert ansible_vault_encrypted_unicode_1 == ansible_vault_encrypted_unicode_2
    assert ansible_vault_encrypted_unicode_1 != ansible_

# Generated at 2022-06-11 09:32:30.946693
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    a1 = AnsibleVaultEncryptedUnicode('A')
    a2 = AnsibleVaultEncryptedUnicode('A')
    assert not (a1 != a2)
    a2.data = 'B'
    assert (a1 != a2)


# Generated at 2022-06-11 09:32:48.482391
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    iv = b'\xb6\xa1\x88\x99*\x8d\xdb\xa2\xd2\xde\xa0\xeb\xfc\x17\x9c\x02'
    salt = b'\xb4\xc4=\xe4\xcc\xdc\x0e\x9d\xe8\xdd\xf0\xfe\xc0\xb2\xbe\x00\x11\xfe\x87\x03u\xe1\x7f'
    key = b'\xe3\xa2\x9c9\xbb\x98\xd5y\x00\xee\xe5\x02\x86\x04\x9f\x1d\xcd'

# Generated at 2022-06-11 09:32:53.732446
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    # create encrypted string
    from ansible.parsing.vault import VaultLib
    password = 'secret'
    salt = VaultLib.salt()
    aveu = AnsibleVaultEncryptedUnicode.from_plaintext('mypassword', VaultLib(password, salt), password)

    # test for equal encrypted strings
    assert (aveu == aveu)

    # test for unequal encrypted strings
    aveu1 = AnsibleVaultEncryptedUnicode.from_plaintext('mypassword1', VaultLib(password, salt), password)
    assert (aveu != aveu1)



# Generated at 2022-06-11 09:32:55.891035
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    u1=AnsibleVaultEncryptedUnicode('non-empty')
    u2=AnsibleVaultEncryptedUnicode('non-empty')
    assert u1 != 'non-empty'
    assert u1 != u2
    assert 'non-empty' != u1


# Generated at 2022-06-11 09:33:03.654553
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    secret = 'foo'
    data1 = 'mysecret'
    data2 = 'myseccret'

    # create vault
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(secret)
    # create object
    obj = AnsibleVaultEncryptedUnicode(vault.encrypt(data1, secret))
    obj.vault = vault
    # compare
    assert obj != data2


# Generated at 2022-06-11 09:33:16.401081
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test 1 of method __ne__
    # Situation: A string is compared with a vault encrypted string with different contents.
    # Expected: The strings aren't equal.
    test1_string = AnsibleVaultEncryptedUnicode.from_plaintext('a string', None, None)
    test1_other = 'a stringy'
    assert test1_string.__ne__(test1_other) is True

    # Test 2 of method __ne__
    # Situation: A string is compared with a vault encrypted string containing the same contents.
    # Expected: The strings are equal.
    test2_string = AnsibleVaultEncryptedUnicode.from_plaintext('a string', None, None)
    test2_other = 'a string'
    assert test2_string.__ne__(test2_other) is False



# Generated at 2022-06-11 09:33:24.920917
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib

    plaintext = text_type('hello world!')
    vault = VaultLib('MySecret')

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, 'MySecret')
    assert avu != 'foo'
    assert avu != text_type('foo')
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext(text_type('foo'), vault, 'MySecret')


# Generated at 2022-06-11 09:33:36.153313
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader

    from ansible.compat.tests import unittest


# Generated at 2022-06-11 09:33:45.268331
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    from ansible.parsing.vault import VaultLib
    vault = VaultLib('vaultSecret')

    data = 'testString'
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(data, vault, 'mySecret')
    assert avu1.data == data
    assert avu1.is_encrypted() == True
    assert avu1.vault == vault
    assert len(avu1)

    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(data, vault, 'mySecret')
    assert avu1 == avu2

    avu3 = AnsibleVaultEncryptedUnicode(b'123')
    assert avu3 is not None
    assert avu3 != data
    assert avu3 != avu1
    assert avu3 != av

# Generated at 2022-06-11 09:33:50.730277
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    clear_text = "ansible"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(clear_text, vaults['AES256'], secret='mysecrete')
    assert(avu != clear_text)
    assert(avu != "ansibl")
    assert(clear_text != avu)
    assert("ansibl" != avu)


# Generated at 2022-06-11 09:33:54.770645
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.vault import VaultLib
    vault = VaultLib('secret')
    seq = u'foo'
    secret = 'secret'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu == seq


# Generated at 2022-06-11 09:34:08.187553
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    v = vault.VaultLib(password='ansible')

    # Tests with vault
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('abc', v, 'secret')
    assert avu1 == 'abc'
    assert avu1 != 'def'

    # Tests without vault
    avu2 = AnsibleVaultEncryptedUnicode('abc')

    assert avu2 == 'abc'
    assert avu2 != 'def'


# Generated at 2022-06-11 09:34:17.852408
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    data = "my_pass"
    my_vault = vault.VaultLib("my_pass")
    result = AnsibleVaultEncryptedUnicode(my_vault.encrypt("my_pass"))
    result.vault = my_vault
    assert result.data == "my_pass"

    result = AnsibleVaultEncryptedUnicode("fdsafdsafasdfdsa")
    assert not result.__ne__("fdsafdsafasdfdsa")

    result = AnsibleVaultEncryptedUnicode("fdsafdsafasdfdsa")
    assert result.__ne__("fdsafdsafasdfasdf")

    result = AnsibleVaultEncryptedUnicode(my_vault.encrypt("my_pass"))
    result.vault = my_vault



# Generated at 2022-06-11 09:34:28.396905
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    Create an AnsibleVaultEncryptedUnicode class from a string.
    The string will not be evaluated (decrypted) until it needs to be.
    """
    from ansible.vault import VaultLib
    my_vault = VaultLib('pass')
    password = 'pass'
    my_data = 'my data'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(my_data, my_vault, password)
    avu.ansible_pos = ('foo', 1, 1)

    # In Python 2, when comparing against a unicode result of __ne__ is always False
    # so, no need to test against it.
    # In Python 3, this is not an issue.

# Generated at 2022-06-11 09:34:36.552782
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    # Testcase 1: permutation with ciphertext
    # 1.1 define method variables
    test_method = AnsibleVaultEncryptedUnicode.__eq__
    ciphertext = b'test_ciphertext_1'
    # 1.2 create objects
    obj = AnsibleVaultEncryptedUnicode(ciphertext)
    # 1.3 define expected results
    expected_result = False
    # 1.4 actual result
    actual_result = test_method(obj, ciphertext)
    # 1.5 compare expected result with actual result
    assert expected_result == actual_result


# Generated at 2022-06-11 09:34:45.273231
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:34:54.585566
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:35:02.918367
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    # assert is_encrypted is correct when initialized with a non-encrypted value
    avu = AnsibleVaultEncryptedUnicode('my_value')
    assert not avu.is_encrypted()

    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    assert avu.is_encrypted()

    # assert is_encrypted is correct when initialized with an encrypted value
    from ansible.plugins.vault.VaultLib import VaultLib
    from ansible.utils.vault import VaultSecret

    vault = VaultLib('my_password', 'my_salt', 1, ['my_hmac'], 'my_cipher')
    secret = VaultSecret('my_password')

# Generated at 2022-06-11 09:35:07.489962
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('mypassword')
    data_to_encrypt = 'test'
    encrypted_data = vault.encrypt(data_to_encrypt, secret='mypassword')
    avu = AnsibleVaultEncryptedUnicode(encrypted_data)
    assert avu.is_encrypted() is True



# Generated at 2022-06-11 09:35:13.633399
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    avue = AnsibleVaultEncryptedUnicode("\n$ANSIBLE_VAULT;1.1;AES256\n36636162326266663631356165373532346664373966306538666430323661663238313166646365\n66616464333639643765306633396537653739663932666533393931316265353336343061326130\n3866383134\n")
    assert avue.is_encrypted()

if __name__ == "__main__":
    test_AnsibleVaultEncryptedUnicode_is_encrypted()

# Generated at 2022-06-11 09:35:19.617809
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Given some text and a vault
    text=b'My secret text'
    vault=yaml.vault.VaultLib('My secret password')
    # When I create a AnsibleVaultEncryptedUnicode instance with the text
    # and I set the vault
    avu = AnsibleVaultEncryptedUnicode(text)
    avu.vault = vault
    # Then the avu is not equal to the text
    assert avu != text

# Convert the object to a string so that it can be used in common error messages.

# Generated at 2022-06-11 09:35:34.507045
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    text_to_encrypt = 'secret text'
    encrypted_text = vault.encrypt(text_to_encrypt)
    avu = AnsibleVaultEncryptedUnicode(encrypted_text)
    assert avu.is_encrypted() is True
    text_to_encrypt = 'secret text'
    avu = AnsibleVaultEncryptedUnicode(text_to_encrypt)
    assert avu.is_encrypted() is False
