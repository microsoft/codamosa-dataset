

# Generated at 2022-06-11 09:26:02.068606
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    ascii_string = 'foo'
    unicode_string = 'baz'
    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256\n30363263373765376366333664313166656362646633626261303935346666303733316366323265\n61323633356664343762623464633137643738326534396539326430383536646233646530393337\n34393066376437663663376537353530636164377d0a0e'
    vault = VaultLib([])
    secret = VaultSecret('foo')

# Generated at 2022-06-11 09:26:14.210315
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    # Ensure the count method of AnsibleVaultEncryptedUnicode instances
    # that have no vault attribute behave like the count method of
    # str instances.

    # Determine the expected behavior of the str.count method
    observed = []
    observed.append( '%d' % 'abcd'.count('a') )
    observed.append( '%d' % 'abcd'.count('bc') )
    observed.append( '%d' % 'abcd'.count('cd') )
    observed.append( '%d' % 'abcd'.count('de') )
    observed.append( '%d' % 'abcd'.count('c', -1) )
    observed.append( '%d' % 'abcd'.count('b', 0, -1) )
    expected = '0 1 1 0 1 0'.split()



# Generated at 2022-06-11 09:26:22.098509
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    '''Test method count of class AnsibleVaultEncryptedUnicode'''

    from ansible.parsing.vault import VaultLib
    vault_pass = 'test_vault_pass'
    secret = 'test_secret'

    def encrypt_string(string, vault_pass=None, secret=None):
        if vault_pass is None:
            return string
        data = string + '\n'
        vault = VaultLib(vault_pass)
        return to_text(AnsibleVaultEncryptedUnicode.from_plaintext(
            data, vault, secret))

    # test that the encrypted string returns the number of characters
    data = encrypt_string(secret, vault_pass, secret)
    assert data.count(secret) == 1, 'count must return 1'

# Generated at 2022-06-11 09:26:36.509741
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    '''
    Test AnsibleVaultEncryptedUnicode.is_encrypted()
    '''
    from ansible.parsing.vault import VaultLib
    secret = b"test_secret"
    vault_id = "vault_test_id"
    vault_pass = b'vault_test_password'
    ciphertext_sample_unencrypted = b'$ANSIBLE_VAULT;1.1;'
    ciphertext_sample_encrypted = b'$ANSIBLE_VAULT;1.1;AES256'
    vault_object = VaultLib(vault_id, vault_pass)
    avu_encrypted_object = AnsibleVaultEncryptedUnicode.from_plaintext(ciphertext_sample_encrypted, vault_object, secret)
    avu_unencrypted_object = AnsibleVaultEnc

# Generated at 2022-06-11 09:26:46.827577
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    avue = AnsibleVaultEncryptedUnicode("abcdefghijklm")
    assert avue[:] == "abcdefghijklm"
    assert avue[3:-3] == "defghi"
    assert avue[2:-2] == "cdefgh"
    assert avue[2:-2:2] == "ceg"
    assert avue[3:-3:2] == "dfh"
    assert avue[:5] == "abcde"
    assert avue[:-5] == "abcdefghi"
    assert avue[5:] == "fghijklm"
    assert avue[-5:] == "fghijklm"
    assert avue[2:100] == "cdefghijklm"
    assert avue[100:] == ''
    assert av

# Generated at 2022-06-11 09:26:49.772493
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    print('')
    print('=== Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode ===')
    avu = AnsibleVaultEncryptedUnicode('0123456789ABCDEF')
    assert avu.is_encrypted() == False


# Generated at 2022-06-11 09:26:56.261682
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    str = AnsibleVaultEncryptedUnicode("foobar")
    assert str[1:3] == 'oo'
    assert str[1:1] == ''
    assert str[1:10] == 'oobar'
    assert str[-1:-5] == ''
    assert str[1:-2] == 'ooba'



# Generated at 2022-06-11 09:27:00.308004
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    """
    Test count method of AnsibleVaultEncryptedUnicode object.
    """
    ciphertext = 'dummy data'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu.count('data') == 0


# Generated at 2022-06-11 09:27:12.635196
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avueu = AnsibleVaultEncryptedUnicode('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    assert (avueu == avueu)
    assert (avueu == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    assert ('ABCDEFGHIJKLMNOPQRSTUVWXYZ' == avueu)
    assert (avueu == b'ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    assert (b'ABCDEFGHIJKLMNOPQRSTUVWXYZ' == avueu)
    assert (avueu != 'aaaaa')
    assert ('aaaaa' != avueu)
    assert (avueu != b'aaaaa')
    assert (b'aaaaa' != avueu)
   

# Generated at 2022-06-11 09:27:24.483247
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    class MockVaultLib(object):
        # Define a mock vaultlib class
        def __init__(self):
            self.magic = b'MAGIC'

        def is_encrypted(self, data):
            # If data starts with magic, then it's encrypted
            return (data.startswith(self.magic))

    # First object is not encrypted
    s1 = AnsibleVaultEncryptedUnicode('123')
    assert not s1.is_encrypted()

    s2 = AnsibleVaultEncryptedUnicode('456')
    # Create a MockVaultLib object
    vault = MockVaultLib()
    # Set Vault attribute of s2 to the mock vaultlib object we created
    s2.vault = vault
    # Now, since mock is_encrypted method will return True if data starts
    # with 'MAGIC

# Generated at 2022-06-11 09:27:35.349841
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    # Test for case where AnsibleVaultEncryptedUnicode _ciphertext is empty
    avu = AnsibleVaultEncryptedUnicode('hello')
    assert avu.find('hello') == 0, 'Should be 0'
    assert avu.find('') == 0, 'Should be 0'
    assert avu.find('', -1) == 5, 'Should be 5'
    assert avu.find('', -20) == 0, 'Should be 0'
    assert avu.find('', 100) == 5, 'Should be 5'
    assert avu.find('h') == 0, 'Should be 0'
    assert avu.find('H') == -1, 'Should be -1'
    assert avu.find('h', 1) == -1, 'Should be -1'

# Generated at 2022-06-11 09:27:47.938430
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vault_secret = 'foo'
    vault_password_file = loader.set_vault_password(vault_secret)
    vault = VaultLib(vault_password_file)

    yaml_str = '''
foo:
  - one: ENC[AES256_CBC,data:lOq3yfKi9xHa2QH+OoNzDG4P/o/zI4FC0AaS1yiS/pM=]
'''


# Generated at 2022-06-11 09:27:56.293814
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    # Test function AnsibleVaultEncryptedUnicode_find
    # Input arguments
    #   str1 = string to be searched
    #   str2 = string to search within str1
    #   idx1 = the first character position within str1 to start the search
    #   idx2 = the last character position within str1 to perform the search
    # Expected results
    #    if str2 is found, returns the index of the first character position of str2 in str1
    #    if str2 is not found, returns -1
    # Test case 1: str1 = "abc", str2 = "b", idx1 = 0, idx2 = 2
    str1 = "abc"
    str2 = "b"
    idx1 = 0
    idx2 = 2

# Generated at 2022-06-11 09:28:09.766916
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    test_data = []

    # [0] - Tests with AnsibleVaultEncryptedUnicode object as RHS

# Generated at 2022-06-11 09:28:18.838133
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:28:31.077443
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test with no wrapping class
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("x" * 100, None, None)
    assert avu[:].data == "x" * 100
    assert avu[0:100].data == "x" * 100
    assert avu[0:0].data == ""
    assert avu[0:1].data == "x"
    assert avu[10:20].data == "x" * 10
    assert avu[20:10].data == ""
    assert avu[100:200].data == ""
    assert avu[:10].data == "x" * 10
    assert avu[10:].data == "x" * 90
    assert avu[-10:].data == "x" * 10

# Generated at 2022-06-11 09:28:42.425234
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    methodName = 'test_AnsibleVaultEncryptedUnicode_find'

# Generated at 2022-06-11 09:28:44.516907
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """Test method AnsibleVaultEncryptedUnicode.__ne__ on positive case."""
    avu = AnsibleVaultEncryptedUnicode("test")
    assert avu != "test"


# Generated at 2022-06-11 09:28:49.062903
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert not AnsibleVaultEncryptedUnicode("abc") == "abc"
    assert not AnsibleVaultEncryptedUnicode("abc") == 'abc'
    assert AnsibleVaultEncryptedUnicode("abc").data == "abc"
    assert AnsibleVaultEncryptedUnicode("abc").data == 'abc'



# Generated at 2022-06-11 09:29:00.821296
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from six import StringIO

    # Setup the Vault
    secret = 'password'
    vault = VaultLib(['--vault-password-file', '-'])
    vault_password_file = StringIO(secret + '\n')

    # Encrypted input
    plaintext = 'very important data'
    ciphertext = vault.encrypt(plaintext, secret)

    # Unencrypted input
    plaintext2 = 'very different data'

    # Encrypted data
    ciphertext_obj = AnsibleVaultEncryptedUnicode(ciphertext)
    ciphertext_obj.vault = vault

    # Unencrypted data
    plaintext_obj = AnsibleUnicode(plaintext2)

    # Unit test
    assert plaintext_obj != ciphertext_obj

#

# Generated at 2022-06-11 09:29:10.681182
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    from ansible.parsing.vault import VaultLib
    vault_password = 'foo'
    value = 'bar'

    vault = VaultLib(vault_password)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(value, vault, vault_password)

    assert avu.replace(value, value + 'baz') == value + 'baz'
    assert avu.replace(avu.data, avu.data + 'baz') == value + 'baz'



# Generated at 2022-06-11 09:29:24.943913
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:29:31.049405
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ciphertext = to_bytes('$ANSIBLE_VAULT;1.1;AES256', encoding='utf-8')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert(avu.is_encrypted())



# Generated at 2022-06-11 09:29:35.491807
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # AnsibleVaultEncryptedUnicode values are not equal
    assert AnsibleVaultEncryptedUnicode.from_plaintext('my secret', None, 'my secret') != 'my secret'


# Generated at 2022-06-11 09:29:44.157641
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    from ansible.parsing.vault import VaultLib

    s = u'xxx\u1234xxx'
    x = AnsibleVaultEncryptedUnicode.from_plaintext(
        u'xxx\u1234xxx', VaultLib(b'ansible'), b'ansible'
    )
    assert x.replace(u'\u1234', u'\u4321') == s.replace(u'\u1234', u'\u4321')
    assert x.replace(u'\u1234', u'\u4321', 1) == s.replace(u'\u1234', u'\u4321', 1)

# Generated at 2022-06-11 09:29:54.598337
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avueu = AnsibleVaultEncryptedUnicode(b'foo')

    try:
        from ansible_vault import Vault
    except ImportError:
        from ansible.parsing.vault import Vault
    avueu.vault = Vault('12345')

    # Here we test the second call to __ne__(), this is the one that
    # actually returns.  The first call to __ne__() is caused by the
    # 'if self.vault:' statement, it causes __eq__ to be called and
    # then __ne__ will be called with the result of 'other == self.data'
    assert not (avueu != 'foo')



# Generated at 2022-06-11 09:30:03.883957
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib("secret")
    s = AnsibleVaultEncryptedUnicode.from_plaintext("hello", vault, "secret")
    assert s.data == "hello"
    assert not (s == "hi")
    # assert not (s != "hello")
    assert (s != "hi")
    t = AnsibleVaultEncryptedUnicode.from_plaintext("hello", vault, "secret")
    assert s == t
    assert s == s
    assert s != vault
    assert s != 1
    assert s != "hello"


# Generated at 2022-06-11 09:30:13.362866
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Python < 2.7.12 or Python >= 3.4.4 don't have ``importlib.util.module_from_spec()``
    # and earlier version of Python don't have ``importlib.util.find_spec()``
    # this is the only way to get access to the unittest code
    # Specify the test cases to run with:
    #     python -m unittest test_AnsibleVault_YAML
    import unittest

    class TestAnsibleVaultEncryptedUnicode___ne__(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_ne_AnsibleVaultEncryptedUnicode(self):
            avu1 = AnsibleVaultEncryptedUnicode('thesecret')
           

# Generated at 2022-06-11 09:30:23.558076
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    # Custom cipher
    vault = VaultLib('1234567890123456789012345')

    # test not encrypted
    avu = AnsibleVaultEncryptedUnicode('some data')
    avu.vault = vault
    assert avu.is_encrypted() is False

    # test encrypted
    avu = vault.encrypt('some data', 'any')
    assert avu.is_encrypted() is True

    # test encrypted with none vault

# Generated at 2022-06-11 09:30:29.414970
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Given
    vault_str_1 = AnsibleVaultEncryptedUnicode('Data')
    vault_str_2 = AnsibleVaultEncryptedUnicode('Data')
    # When
    result = vault_str_1 != vault_str_2

    # Then
    assert result is False


# Generated at 2022-06-11 09:30:41.793324
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avue = AnsibleVaultEncryptedUnicode("foo")
    assert avue != "foo"
    assert "foo" != avue
    assert avue != AnsibleVaultEncryptedUnicode("foo")
    assert AnsibleVaultEncryptedUnicode("foo") != avue


# Generated at 2022-06-11 09:30:53.435702
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert not AnsibleVaultEncryptedUnicode("not encrypted").is_encrypted()

    class FakeVault():
        def is_encrypted(self, string):
            return False

    avue = AnsibleVaultEncryptedUnicode("not encrypted")
    avue.vault = FakeVault()
    assert not avue.is_encrypted()

    class RealVault():
        def is_encrypted(self, string):
            return True

    avue = AnsibleVaultEncryptedUnicode("not encrypted")
    avue.vault = RealVault()
    try:
        avue.is_encrypted()
    except vault.AnsibleVaultError as e:
        pass
    else:
        assert False, "AnsibleVaultException not raised"


# Generated at 2022-06-11 09:30:56.537496
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode('test') == 'test'
    assert AnsibleVaultEncryptedUnicode('test') != ''
    assert AnsibleVaultEncryptedUnicode('test') != 'Test'
    assert AnsibleVaultEncryptedUnicode('test') != 'other'


# Generated at 2022-06-11 09:31:07.773653
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault

    plaintext = AnsibleVaultEncryptedUnicode.from_plaintext('a', vault, b'password')
    str_eq = AnsibleVaultEncryptedUnicode.from_plaintext('a', vault, b'password')
    str_ne = AnsibleVaultEncryptedUnicode.from_plaintext('b', vault, b'password')
    bytes_eq = AnsibleVaultEncryptedUnicode.from_plaintext('a', vault, b'password')
    bytes_ne = AnsibleVaultEncryptedUnicode.from_plaintext('b', vault, b'password')

    # make sure eq works per normal
    assert (plaintext == 'a')
    assert (plaintext == b'a')
    # make sure ne works per normal

# Generated at 2022-06-11 09:31:13.275338
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.vault import Vault, VaultLib
    plaintext = 'asdf'
    ciphertext = VaultLib().encrypt(plaintext, b'a secret')

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = Vault()

    assert avu == plaintext
    assert plaintext == avu
    assert avu == avu.data
    assert avu.data == avu



# Generated at 2022-06-11 09:31:20.122674
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib, VaultEditor
    from ansible.parsing.vault import VaultSecret

    avue = AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:31:32.478124
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # This unit test is a copy of Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
    # with an additional negation on the assert statement
    import tempfile
    wav_file = tempfile.NamedTemporaryFile(delete=False)
    wav_file.write(b"Hello world!")
    wav_file.close()

    with open(wav_file.name, "rb") as f:
        content = f.read()

    assert type(content) is bytes
    assert isinstance(content, bytes)
    assert not isinstance(content, text_type)

    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    vault.raw_bytes = True
    password = "hunter2"
    encrypted = vault.encrypt(content, password)



# Generated at 2022-06-11 09:31:42.751348
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault as vault

    secret = 'dummysecret'
    plaintext = 'dummyplaintext'
    plaintext_list = [plaintext]
    plaintext_tuple = (plaintext,)
    plaintext_dict_v1 = dict(key=plaintext)
    plaintext_dict_v2 = {'key': plaintext}
    plaintext_dict_v3 = {'key': [plaintext]}

    vault = vault.VaultLib(secret)

    # encrypt plaintext
    plaintext_encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    plaintext_list_encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext_list, vault, secret)
    plaintext_tuple_encrypted = Ans

# Generated at 2022-06-11 09:31:48.557351
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    a = AnsibleVaultEncryptedUnicode.from_plaintext(u'foo', None, None)
    b = AnsibleVaultEncryptedUnicode.from_plaintext(u'foo', None, None)
    c = AnsibleVaultEncryptedUnicode.from_plaintext(u'bar', None, None)
    d = u'foo'

    assert a.__ne__(b)
    assert a.__ne__(c)
    assert a.__ne__(d)



# Generated at 2022-06-11 09:31:54.513207
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    '''Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode.
    '''
    avu_hello = AnsibleVaultEncryptedUnicode(b'hello')
    avu_world = AnsibleVaultEncryptedUnicode(b'world')
    assert avu_hello != avu_world
    avu_plain_hello = AnsibleVaultEncryptedUnicode('hello')
    avu_plain_world = AnsibleVaultEncryptedUnicode('world')
    assert avu_plain_hello != avu_plain_world
    avu_empty = AnsibleVaultEncryptedUnicode('')
    avu_empty_equal = AnsibleVaultEncryptedUnicode('')
    assert avu_empty == avu_empty_equal
    assert avu_hello

# Generated at 2022-06-11 09:32:16.971205
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault

    vault = ansible.parsing.vault.VaultLib({'vault_password_file': 'ansible.cfg'})

    plaintext = u'an unicode string'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, u'test')

    assert avu == plaintext
    assert avu == avu
    assert avu != u'another unicode string'
    assert avu != 4
    assert avu != 4.0
    assert avu != (1, 2, 3)
    assert avu != True



# Generated at 2022-06-11 09:32:23.197710
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # setup
    pwd = 'top_secret_pwd'
    vault = vaultlib.VaultLib(pwd)
    encrypted_text = AnsibleVaultEncryptedUnicode.from_plaintext('some text',
                                                                vault,
                                                                pwd)
    # test
    result = encrypted_text == 'some text'
    assert result

    # test
    result = encrypted_text == 'another text'
    assert not result


# Generated at 2022-06-11 09:32:31.111729
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import vault
    vault_password = b'$ecret'
    vault_obj = vault.VaultLib(vault_password)

    plaintext_1 = b'test_AnsibleVaultEncryptedUnicode___eq__'
    encrypted_1 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext_1, vault_obj, vault_password)

    # compare with plaintext
    assert encrypted_1 == plaintext_1
    # compare with encrypted value
    assert encrypted_1 == encrypted_1

    # test with different vault object
    encrypted_2 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext_1, vault_obj, vault_password)
    assert encrypted_1 != encrypted_2

    # test with different password
    encrypted_3 = AnsibleVaultEncryptedUnic

# Generated at 2022-06-11 09:32:34.639469
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode.from_plaintext('foo', 'bar', 'baz') == 'foo'
    assert AnsibleVaultEncryptedUnicode.from_plaintext('foo', 'bar', 'baz') != 'bar'



# Generated at 2022-06-11 09:32:39.931863
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import ansible.parsing.vault as vault
    vaultlib = vault.VaultLib('TestVaultSecret', 1)
    seq = 'string'
    ansible_encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vaultlib, 'TestVaultSecret')
    plaintext = 'string'
    assert ansible_encrypted != plaintext
    assert seq == plaintext


# Generated at 2022-06-11 09:32:42.521713
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    a = AnsibleVaultEncryptedUnicode('666')
    b = AnsibleVaultEncryptedUnicode('777')

    assert(a != b)



# Generated at 2022-06-11 09:32:51.187284
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    """Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
    """
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    import ansible.plugins.vault.VaultLib

    # clear text, not encrypted
    ciphertext = "foobar"
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert not avu.is_encrypted()

    # encrypted, which is different from the clear text
    vaultfile = os.path.join(os.path.dirname(__file__), "vault_test.yml")
    password = "test"
    vault = ansible.plugins.vault.VaultLib.VaultLib(password, vaultfile)

# Generated at 2022-06-11 09:33:03.059015
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault

# Generated at 2022-06-11 09:33:14.535467
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    secret = 'password'
    vault = VaultLib([secret])

    assert AnsibleVaultEncryptedUnicode.is_encrypted(None) == False

    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext('my_password', vault, secret)
    assert encrypted.is_encrypted() == True

    assert AnsibleVaultEncryptedUnicode.is_encrypted(encrypted) == True

    decrypted = vault.decrypt(encrypted, secret)
    assert AnsibleVaultEncryptedUnicode.is_encrypted(decrypted) == False


# Generated at 2022-06-11 09:33:27.865415
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Test for a non-encryptd string
    non_encrypt_str = AnsibleVaultEncryptedUnicode('abcdef')
    if non_encrypt_str.is_encrypted():
        raise AssertionError('Non-encrypted string is reported encrypted')

    # Test for an encrypted string
    from ansible.parsing import vault as vaultlib
    from ansible.parsing.vault import VaultLib
    vault = VaultLib("ansible")
    encrypt_str = AnsibleVaultEncryptedUnicode.from_plaintext("abcdef", vault, "ansible")
    if not encrypt_str.is_encrypted():
        raise AssertionError('Encrypted string is not reported encrypted')

    # Test for a non-string object

# Generated at 2022-06-11 09:33:43.863868
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(u'b', vault, b'a')
    assert not u'a' != avu



# Generated at 2022-06-11 09:33:54.017511
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    non_vault = AnsibleUnicode("plain text")
    vault = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256\n363530343038643865313336653963356262393531653136616432386630653833353638333238\n306461633962316230306438333864393930666537376466316537313737393337316563613239\n")

# Generated at 2022-06-11 09:33:57.644530
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode('cipher') != 'plain'
    assert 'plain' != AnsibleVaultEncryptedUnicode('cipher')


# Override dictionary creation to add the ansible_pos attribute to all dictionaries
# to preserve yaml loading pipeline position

# Generated at 2022-06-11 09:34:07.846557
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx=\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx=\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx=\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx=\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx=\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx=\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx=\nxxxxxxxxxxxx\n').is_encrypted()
    assert AnsibleVaultEncryptedUnicode('').is_encrypted() == False

# Generated at 2022-06-11 09:34:17.452284
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bad_vault = None
    data = 'this is some data'
    secret = 'this is some password'
    # create an AnsibleVaultEncryptedUnicode object from a string
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(secret)
    # create an AnsibleVaultEncryptedUnicode object from a string
    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext(data, vault, secret)

    # This should return False, since it is the same data
    assert encrypted_string.__ne__(data) == False

    # This should return True, since it is the same data
    assert encrypted_string.__ne__('this is some other data') == True

    # This should return True, since it is the same data
    assert encrypted_string.__ne

# Generated at 2022-06-11 09:34:25.317238
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu1 = AnsibleVaultEncryptedUnicode('foo')
    avu2 = AnsibleVaultEncryptedUnicode('foo')
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', 'bar')
    avu4 = AnsibleVaultEncryptedUnicode('bar')

    assert not (avu1 != avu2)
    assert not (avu2 != avu1)
    assert avu1 != avu3
    assert avu3 != avu1
    assert avu1 != avu4
    assert avu4 != avu1


# Generated at 2022-06-11 09:34:36.328165
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    encrypted_str = b"$ANSIBLE_VAULT;1.1;AES256"
    encrypted_str += b"\n366263633038623065303666343361346131626162323863303064386161343538393364353432\n"
    encrypted_str += b"303332633232643737346535653561373339376435303764656538343836396566623064663563\n"
    encrypted_str += b"613932366139363738636239306633373666383161623038393163653564333634636433356461\n"

# Generated at 2022-06-11 09:34:44.838416
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib

    vault_secret = 'secret'
    plaintext = 'some plaintext'
    ciphertext = VaultLib('!v1.5').encrypt(plaintext, vault_secret)
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)

    assert (plaintext != encrypted_unicode) # This should not decrypt the encrypted string
    assert (encrypted_unicode != plaintext) # This should not decrypt the encrypted string


yaml.add_representer(text_type,
                     yaml.representer.SafeRepresenter.represent_unicode)

yaml.add_representer(AnsibleVaultEncryptedUnicode,
                     yaml.representer.SafeRepresenter.represent_unicode)

#
# This is required for the Ansible

# Generated at 2022-06-11 09:34:54.208388
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import unittest
    class AnsibleVaultEncryptedUnicode___ne__TestCase(unittest.TestCase):
        '''unit test for method __ne__ of class AnsibleVaultEncryptedUnicode'''
        def setUp(self):
            class _Vault(object):
                def decrypt(self, ciphertext):
                    return 'plaintext'
                def is_encrypted(self, ciphertext):
                    return True
            self.vault = _Vault()
            self.avu = AnsibleVaultEncryptedUnicode('ciphertext')
            self.avu.vault = self.vault

        def test_not_encrypted1(self):
            '''__ne__ should return False if this is not encrypted.'''
            ciphertext = 'not_encrypted_ciphertext'
            avu = Ans

# Generated at 2022-06-11 09:35:02.647804
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import os
    import ansible.parsing.vault
    vault = ansible.parsing.vault.VaultLib('$ANSIBLE_VAULT;1.1;AES256', open_stdin=False)

    # Test if a non encrypted string is a false
    non_encrypted_str = to_bytes('not encrypted string')
    non_encrypted_str_avu = AnsibleVaultEncryptedUnicode(non_encrypted_str)
    assert non_encrypted_str_avu.is_encrypted() is False

    # Test if a encrypted string is a true
    secret = to_bytes(os.urandom(16))
    ciphertext = vault.encrypt('encrypted string', secret)
    ciphertext_avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert ciphertext_avu