

# Generated at 2022-06-11 09:26:01.165765
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

    # Test with a regular string
    plaintext = 'string-to-encrypt'
    encrypted = vault.encrypt(plaintext)
    encrypted_unicode = AnsibleVaultEncryptedUnicode(encrypted)
    assert encrypted_unicode.is_encrypted()

    # Test with an integer
    plaintext = 42
    encrypted = vault.encrypt(plaintext)
    encrypted_unicode = AnsibleVaultEncryptedUnicode(encrypted)
    assert encrypted_unicode.is_encrypted()

    # Test with a list
    plaintext = ['a', 'b', 'c']
    encrypted = vault.encrypt(plaintext)
    encrypted_unicode = AnsibleVaultEncryptedUnicode(encrypted)
    assert encrypted_

# Generated at 2022-06-11 09:26:13.631967
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    item = AnsibleVaultEncryptedUnicode('artificial')
    assert(item.rfind('fici') == 4)
    assert(item.rfind('fici', start=0, end=6) == 4)
    assert(item.rfind('fici', start=5, end=6) == -1)
    assert(item.rfind('art', start=0, end=9) == 0)

    # Test the case where the substring is class AnsibleVaultEncryptedUnicode
    item2 = AnsibleVaultEncryptedUnicode('fici')
    assert(item.rfind(item2) == 4)
    assert(item.rfind(item2, start=0, end=6) == 4)

# Generated at 2022-06-11 09:26:21.674385
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # FIXME: This test is only a smoke test. It need to be more complete.
    def assertEncrypted(result):
        assert result
    def assertNotEncrypted(result):
        assert not result

    # set ansible vault to be used by AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('abcdefgh')

    # create a encrypted string

# Generated at 2022-06-11 09:26:36.192531
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    my_vault_text = "vault encrypted string"
    vault_password = "my_secret"
    sampledata = "this is some sample data that we'll store in the vault"
    my_vault = VaultLib(vault_password)
    my_ciphertext = my_vault.encrypt(sampledata)
    print(my_ciphertext)
    my_vault_object = AnsibleVaultEncryptedUnicode(my_ciphertext)
    my_vault_object.vault = my_vault
    string_to_compare = AnsibleVaultEncryptedUnicode(my_vault_text)
    string_to_compare.vault = my_vault
    results = string_to_compare.__

# Generated at 2022-06-11 09:26:46.657919
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError

    vault = VaultLib()
    k = "hunter2"
    p = 'a secret'
    c = vault.encrypt(p, k)
    wrap = AnsibleVaultEncryptedUnicode(c)
    wrap.vault = vault

    cnt = wrap.count(wrap)
    assert cnt == 1, "count of self should be 1"

    cnt = wrap.count('secret')
    assert cnt == 1, "count of sub string should be 1"

    c = vault.encrypt('a secret a secret', k)
    wrap = AnsibleVaultEncryptedUnicode(c)
    wrap.vault = vault

    cnt = wrap.count(wrap)


# Generated at 2022-06-11 09:26:51.602348
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    ansible_vault_encrypted_unicode_obj = AnsibleVaultEncryptedUnicode("abcdefg")
    assert (ansible_vault_encrypted_unicode_obj[0:5]) == "abcde"
    assert (ansible_vault_encrypted_unicode_obj[0:0]) == ""
    assert(ansible_vault_encrypted_unicode_obj[0:-1]) == "abcdef"
    assert(ansible_vault_encrypted_unicode_obj[0:-2]) == "abcde"
    # Get out of range sliced value as a string
    assert (ansible_vault_encrypted_unicode_obj[0:15]) == "abcdefg"
    assert (ansible_vault_encrypted_unicode_obj[0:-15]) == ""


# Generated at 2022-06-11 09:27:01.779883
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault
    vault = ansible.parsing.vault.AnsibleVaultSecret()

    # Create a new encrypted string
    original_value = 'foo'
    ciphertext = vault.encrypt(original_value, 'password')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    # The method __eq__ should return True even if the parameter is not an instance
    # of AnsibleVaultEncryptedUnicode
    assert avu.__eq__('foo') == True

if __name__ == '__main__':
    test_AnsibleVaultEncryptedUnicode___eq__()

# Generated at 2022-06-11 09:27:14.892594
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    # Test Unicode string
    avu = AnsibleVaultEncryptedUnicode('abcABCabc')
    assert avu.rfind('b', 0, -1) == 6
    assert avu.rfind('b', 0, -2) == 6
    assert avu.rfind('b', 0, -3) == 3
    assert avu.rfind('b', 0, -5) == 3
    assert avu.rfind('b', 0, -9) == -1
    assert avu.rfind('b', 0, -10) == -1
    assert avu.rfind('b', 0, -11) == -1
    assert avu.rfind('b', 0, -12) == -1

    # Test AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnic

# Generated at 2022-06-11 09:27:26.736447
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # create encrypted string
    test_string = AnsibleVaultEncryptedUnicode.from_plaintext('hello', None, 'world')

    # test case 1, compare to a string smaller than test_string
    assert test_string.__gt__('hello') == False

    # test case 2, compare to a string larger than test_string
    assert test_string.__gt__('world') == True

    # test case 3, compare to a encrypted string smaller than test_string
    test_other_string = AnsibleVaultEncryptedUnicode.from_plaintext('world', None, 'world')
    assert test_string.__gt__(test_other_string) == True

    # test case 4, compare to a encrypted string larger than test_string
    test_other_string = AnsibleVaultEncryptedUnicode.from_plain

# Generated at 2022-06-11 09:27:34.243759
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password='test')
    import random
    iv = random.randint(0, 1000000)
    ciphertext = vault.encrypt(repr(iv), 'test')
    ciphertext = ''.join(ciphertext.split())
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    #The following test case is to fail on !vault &!vaultscript TypeError exception
    rfind = avu.rfind('$ANSIBLE_VAULT;',0,-1)
    assert rfind == -1

if __name__ == "__main__":
    test_AnsibleVaultEncryptedUnicode_rfind()



# Generated at 2022-06-11 09:27:42.481848
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode("bar")
    assert avu != None, "It should not be equal to None"


# Generated at 2022-06-11 09:27:45.795461
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    assert (
        'Here\'s a string: '
        == AnsibleVaultEncryptedUnicode('Here\'s a string: ')
        + 'Here\'s a string: '
    )


# Generated at 2022-06-11 09:27:55.090065
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultSecret

    # platform check: we are not on windows, so this test should be executed
    if _sys.platform.lower().startswith('win'):
        return

    # create vault secrets object
    vault_secret = VaultSecret(password='pass')

    # create vault object
    vault = VaultLib([vault_secret])

    # create an AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello world', vault, vault_secret)

    # ensure avu is encrypted
    assert avu.is_encrypted()

    # ensure avu is not

# Generated at 2022-06-11 09:28:08.663979
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    vault_a = _DummyVault()
    avu_a = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault_a, 'secret')
    assert avu_a.__ne__('test')
    assert avu_a.__ne__('')

    vault_b = _DummyVault()
    avu_b = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault_b, 'secret')
    assert avu_a.__ne__(avu_b)
    assert avu_b.__ne__(avu_a)

    avu_c = AnsibleVaultEncryptedUnicode.from_plaintext('', vault_b, 'secret')
    assert avu_a.__ne__(avu_c)
    assert avu

# Generated at 2022-06-11 09:28:18.274558
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Given
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n3566633964393234663435396535656338323465616136643233613334336636635656639643534\n34633963343532336231656333616136666136653735333937336234386666653366353361613065\n66393734336563\n'

# Generated at 2022-06-11 09:28:30.547578
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    # failed for case of empty AnsibleVaultEncryptedUnicode
    assert AnsibleVaultEncryptedUnicode("").count("") == 0
    assert AnsibleVaultEncryptedUnicode("").count("a") == 0
    assert AnsibleVaultEncryptedUnicode("a").count("") == 1
    assert AnsibleVaultEncryptedUnicode("a").count("a") == 1
    assert AnsibleVaultEncryptedUnicode("a").count("b") == 0

    # failed for case of AnsibleVaultEncryptedUnicode and sub is not AnsibleVaultEncryptedUnicode
    assert AnsibleVaultEncryptedUnicode("a").count("a", 0, 1) == 1

# Generated at 2022-06-11 09:28:36.326929
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'test'
    seq = 'this is test string'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert (avu.data == seq)
    assert (avu != seq)


# Generated at 2022-06-11 09:28:41.056524
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import u
    secret = u("um i'll take a large cup of coffee please")
    password = secret * 3
    vault = VaultLib(password)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("Hello World", vault, password)
    assert((avu + "!").data == "Hello World!")
    assert(("Hello " + avu).data == "Hello Hello World")
    assert(("Hello " + avu + "!").data == "Hello Hello World!")
    assert((avu + u("!")).data == "Hello World!")
    assert((u("Hello ") + avu).data == "Hello Hello World")

# Generated at 2022-06-11 09:28:48.150223
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    data = '0123456789'
    unicode_data = AnsibleVaultEncryptedUnicode(data)

    # Before start
    assert unicode_data.__getslice__(-1, -1) == data[-1:-1]
    assert unicode_data.__getslice__(-1, 0) == data[-1:0]
    assert unicode_data.__getslice__(-1, 1) == data[-1:1]
    assert unicode_data.__getslice__(-1, 10) == data[-1:10]
    assert unicode_data.__getslice__(-1, 11) == data[-1:11]
    assert unicode_data.__getslice__(-1) == data[-1:]

    # Start

# Generated at 2022-06-11 09:28:49.274758
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass



# Generated at 2022-06-11 09:28:58.340641
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('test')
    avue = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert 'testtest' == avue + avue
    assert 'testtest' == avue + 'test'
    assert 'testtest' == 'test' + avue



# Generated at 2022-06-11 09:29:09.148257
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    def assert_gt(expected_result, avu1, avu2):
        actual_result = avu1 > avu2
        assert actual_result == expected_result, "%s > %s expected %s but got %s" % (avu1, avu2, expected_result, actual_result)
    assert_gt(False, AnsibleVaultEncryptedUnicode("a"), AnsibleVaultEncryptedUnicode("a"))
    assert_gt(True, AnsibleVaultEncryptedUnicode("b"), AnsibleVaultEncryptedUnicode("a"))
    assert_gt(False, AnsibleVaultEncryptedUnicode("a"), AnsibleVaultEncryptedUnicode("b"))
    assert_gt(False, AnsibleVaultEncryptedUnicode("a"), "a")

# Generated at 2022-06-11 09:29:23.246203
# Unit test for method count of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:29:23.990276
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    pass

# Generated at 2022-06-11 09:29:39.297420
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''
    We need to have an encrypted string to generate one of our objects
    so we can test it. Therefore we create an empty temporary vault.
    '''
    try:
        # We are importing vaultlib here so as to not create an import time circular dependency.
        from ansible.parsing.vault import VaultLib
    except ImportError:
        print("\nFAILED: Cannot import AnsibleVaultEncryptedUnicode. Skipping test.\n")
        return
    from ansible.parsing.vault import AnsibleVaultError
    try:
        vault = VaultLib([], 'password')
    except AnsibleVaultError:
        print("\nError creating temporary vault for testing. Skipping test.\n")
        return

    plain = 'The United States'

# Generated at 2022-06-11 09:29:47.726879
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    data = to_bytes('my password')
    avu = AnsibleVaultEncryptedUnicode(data)
    avu.vault = None
    try:
        avu.ansible_pos = (None, 1, 2)
    except AssertionError:
        # We should be unable to set ansible_pos without a
        # vault, since this means that we don't have any
        # information about how to decrypt the data
        pass
    else:
        assert False, "Setting ansible_pos without a Vault should raise AssertionError"
    assert not avu.is_encrypted()
    assert avu == 'my password'
    assert avu != 'my passwd'



# Generated at 2022-06-11 09:29:56.373861
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    secret = b'$1$some salt'
    plaintext = b'original plaintext'

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)

    # Assert that the ciphertext is encrypted
    assert avu.is_encrypted()
    # Assert that the plaintext is not encrypted
    assert not avu.data.is_encrypted()



# Generated at 2022-06-11 09:30:07.466422
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    class vaultMock(object):
        def __init__(self, crypted_string):
            self.crypted_string = crypted_string

        def decrypt(self, value, obj=None):
            return str(value, 'utf-8')

    decrypted_value = b'the test string'
    sub_string = 'test'
    vault_obj = vaultMock(decrypted_value)

    ansible_vault_unicode_obj = AnsibleVaultEncryptedUnicode(decrypted_value)
    ansible_vault_unicode_obj.vault = vault_obj

    assert ansible_vault_unicode_obj.count(sub_string) == 1
    assert ansible_vault_unicode_obj.count(sub_string, 1) == 1
    assert ansible_vault_

# Generated at 2022-06-11 09:30:15.674954
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.lookup import LookupBase

    class FakeVaultLib(object):
        def __init__(self):
            self.password = 'passwd'

        def is_encrypted(self, ciphertext):
            return True

        def encrypt(self, plaintext, secret):
            return '{%s}'.format(plaintext)

        def decrypt(self, ciphertext, obj):
            return ciphertext

    #decrypted value is 1
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(b'1', FakeVaultLib(), 'passwd')
    assert avu.__gt__(2) == False

# Unit

# Generated at 2022-06-11 09:30:27.548082
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # get a vault obj

    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')

    # create a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('password', vault, 'test')

    # test equal
    assert avu == 'password'

    # test not equal
    assert avu != 'passwoord'

    # test equal
    assert avu == avu

    # test none equal
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('password', vault, 'test')
    assert avu != avu2

    # test equal
    assert avu == AnsibleVaultEncryptedUnicode(avu2._ciphertext)



# Generated at 2022-06-11 09:30:40.504551
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """Check ``__ne__`` method of ``AnsibleVaultEncryptedUnicode`` works correctly."""
    # Test for ``ne`` operator over AnsibleVaultEncryptedUnicode object and AnsibleVaultEncryptedUnicode object
    ciphertext = b'ANSIBLE_VAULT;1.1;AES256;testcase01\nansible_test_ciphertext\n'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = getattr(sys.modules['ansible.parsing.vault'], 'VaultLib', None)
    assert avu != 'ansible_test_plaintext'
    assert not (avu != 'ansible_test_ciphertext')
    # Test for ``ne`` operator over AnsibleVaultEncryptedUnicode object

# Generated at 2022-06-11 09:30:41.688783
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass



# Generated at 2022-06-11 09:30:50.450646
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    class Vault:
        def __init__(self, secret):
            self.secret = secret

        def encrypt(self, plaintext, secret):
            return plaintext.replace(secret, '**')

        def decrypt(self, ciphertext, secret):
            return ciphertext.replace('**', secret)

    vault = Vault('secret')

    av = AnsibleVaultEncryptedUnicode.from_plaintext('plaintext', vault, 'secret')

    assert av == 'plaintext'
    assert av != 'noplaintext'


# Generated at 2022-06-11 09:30:58.867787
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    class vault:
        def __init__(self):
            self.secret = "foobar"

        def encrypt(self, decrypted_data):
            return to_bytes("encrypted-" + decrypted_data)

        def decrypt(self, encrypted_data):
            if "encrypted-" in encrypted_data:
                return to_bytes("decrypted-" + encrypted_data[10:])
            else:
                return to_bytes(encrypted_data)

    def assertNotEqual(a, b, msg=None):
        if (not (a != b)):
            if not msg:
                msg = '%r == %r' % (a, b)
            raise AssertionError(msg)

    assertNotEqual(AnsibleVaultEncryptedUnicode("encrypted-hello", vault()), "hello")
    assertNotEqual

# Generated at 2022-06-11 09:31:10.460382
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # This function tests AnsibleVaultEncryptedUnicode.__ne__

    from ansible.parsing.vault import VaultLib
    import base64
    x = AnsibleVaultEncryptedUnicode('AAAAFQByAHMAcwB3AG8AcgBkAAAACnByb2plY3Qta2V5Cg==')
    x.vault = VaultLib()
    assert x.__ne__('AAAByAHMAcwB3AG8AcgBkAAAACnByb2plY3Qta2V5Cg==')
    x._ciphertext = base64.b64decode('AAAAFQByAHMAcwB3AG8AcgBkAAAACnByb2plY3Qta2V5Cg==')

# Generated at 2022-06-11 09:31:23.367634
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    try:
        from ansible.parsing.vault import VaultLib
    except ImportError:
        return
    import tempfile
    secret = 'secret'
    plaintext = 'password'
    pw_file = None
    try:
        with tempfile.NamedTemporaryFile(delete=False) as f:
            pw_file = f.name
            f.write(secret)
        vault = VaultLib(pw_file)
        ciphertext = vault.encrypt(plaintext, secret)
        avu = AnsibleVaultEncryptedUnicode(ciphertext)
        avu.vault = vault
        assert(avu.is_encrypted() == True)
    finally:
        _sys.stdout.flush()
        if pw_file:
            _sys.stdout.flush()
           

# Generated at 2022-06-11 09:31:34.966591
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n34623462346234623462346234623462346234623462346234623466666666666666666666666666666666666666666666666666666666666663323\n')
    avu.vault = vaultlib.VaultLib('test')
    assert avu == 'abc'
    assert not avu == 'def'
    assert avu == AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n34623462346234623462346234623462346234623462346234623466666666666666666666666666666666666666666666666666666666666663323\n')

# Generated at 2022-06-11 09:31:39.707581
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('yay')
    s = 'yay'
    encrypted_s = AnsibleVaultEncryptedUnicode.from_plaintext(s, vault, 'yay')

    assert encrypted_s.is_encrypted() == True


# Generated at 2022-06-11 09:31:47.064304
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # A AnsibleUnicode with a Vault attribute that can decrypt it.

    #: ciphertext is a byte string (str on PY2, bytestring on PY3).

    #: The .data attribute is a property that returns the decrypted plaintext
    #: of the ciphertext as a PY2 unicode or PY3 string object.
    #assert False, "Test if the test_AnsibleVaultEncryptedUnicode___add__() function is implemented"
    assert True, "Test if the test_AnsibleVaultEncryptedUnicode___add__() function is implemented"


# Generated at 2022-06-11 09:31:52.375304
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import vault_encrypted_bytes_to_bytes

    vault_data = '$ANSIBLE_VAULT;1.1;AES256\n38633564646631653562613766646162353564333165313762653864333866623437373039353339\n35326261333234636565303638316462376631633833663337306135396135393530393133313365\n36396163356264663133396239656232356634653736383536373937353931383537613633366639\n6638333961373730333762626265353736363730393935383437366666323137\n'

# Generated at 2022-06-11 09:31:58.948971
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # __gt__() has been implemented to support working with Python 3.6+
    a = AnsibleVaultEncryptedUnicode('foo')
    assert (a != 'bar') == True
    assert (a != 'foo') == False
    assert (a == 'foo') == True
    assert (a == 'bar') == False


# Generated at 2022-06-11 09:32:01.805071
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    a = AnsibleVaultEncryptedUnicode("abc")
    b = AnsibleVaultEncryptedUnicode("bcd")
    c = AnsibleVaultEncryptedUnicode("bcd")
    d = "bcd"

    assert a < b
    assert b == c
    assert b > d

# Generated at 2022-06-11 09:32:11.200556
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml import AnsibleUnicode

    vault_password = "ansible"

    vault = VaultLib(vault_password)
    vault_secret = VaultSecret(vault_password)

    avu = AnsibleVaultEncryptedUnicode.from_plaintext("val", vault, vault_secret)
    au = AnsibleUnicode('val')

    assert(avu.__eq__(au))
    assert(au.__eq__(avu))


# Generated at 2022-06-11 09:32:19.672747
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """Check that AnsibleVaultEncryptedUnicode.__ne__ behave as expected"""
    from ansible.parsing.vault import VaultLib
    secret = "supersecret"
    plain_text = "The secret is very secret !"
    plain_text2 = "The secret is a different secret !"
    vault = VaultLib(password="supersecret")
    obj = AnsibleVaultEncryptedUnicode.from_plaintext(plain_text, vault, secret)
    assert obj != plain_text2
    assert obj != AnsibleVaultEncryptedUnicode(plain_text)


# Generated at 2022-06-11 09:32:28.896625
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:32:38.462008
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # a1 is a AnsibleVaultEncryptedUnicode object
    # a2 is a AnsibleVaultEncryptedUnicode object
    # a3 is a AnsibleVaultEncryptedUnicode object
    # a4 is a AnsibleVaultEncryptedUnicode object
    # s1 is a str object
    # u1 is a unicode object
    a1 = AnsibleVaultEncryptedUnicode(b'abc')
    a2 = AnsibleVaultEncryptedUnicode(b'def')
    a3 = AnsibleVaultEncryptedUnicode(b'ghi')
    a4 = AnsibleVaultEncryptedUnicode(u'jkl')
    s1 = 'mno'
    u1 = u'pqr'

    # case 1: Both operands are AnsibleVaultEnc

# Generated at 2022-06-11 09:32:48.200746
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    AnsibleVaultEncryptedUnicode.__ne__(AnsibleVaultEncryptedUnicode) test cases

    """
    # Compare an encrypted string:

# Generated at 2022-06-11 09:32:54.337080
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
  # Open a file
  fo = open("test_data/test_AnsibleVaultEncryptedUnicode___ne___in.yml", "r+")
  expected_fo = open("test_data/test_AnsibleVaultEncryptedUnicode___ne___out.yml", "r+")
  content = fo.read()
  expected = expected_fo.read()

  # Create AnsibleVaultEncryptedUnicode
  val = AnsibleVaultEncryptedUnicode(content)

  # Perform test
  result = val.__ne__(expected)

  # Close opened files
  fo.close()
  expected_fo.close()

  # Assertions
  assert result == False


# Generated at 2022-06-11 09:33:08.142823
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # test with empty string
    avue = AnsibleVaultEncryptedUnicode('')
    assert avue > ""
    avue = AnsibleVaultEncryptedUnicode('a')
    assert avue > ""
    # test with single-chars
    assert not AnsibleVaultEncryptedUnicode('a') > 'a'
    assert AnsibleVaultEncryptedUnicode('a') > 'b'
    assert AnsibleVaultEncryptedUnicode('b') > 'a'
    assert not AnsibleVaultEncryptedUnicode('b') > 'b'
    assert AnsibleVaultEncryptedUnicode('a') > 'A'
    assert AnsibleVaultEncryptedUnicode('A') > 'a'
    assert not AnsibleVaultEncryptedUnicode('A') > 'A'

# Generated at 2022-06-11 09:33:14.291219
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    fail = False
    avu = AnsibleVaultEncryptedUnicode('ciphertext')
    avu.data = "abc"
    if avu > "abc":
        fail = True
    if avu > avu:
        fail = True
    assert not fail


# Generated at 2022-06-11 09:33:33.705202
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.vault import is_encrypted

    s1 = "this is a test string"
    s2 = "this is another test string"

    vault = VaultLib([])
    secret = "hunter2"
    encrypted_s1 = AnsibleVaultEncryptedUnicode.from_plaintext(s1, vault, secret)
    encrypted_s2 = AnsibleVaultEncryptedUnicode.from_plaintext(s2, vault, secret)

    assert(encrypted_s1 == s1)
    assert(encrypted_s2 == s2)


# Generated at 2022-06-11 09:33:40.109801
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    try:
        with open('setup.cfg') as f:
            lines = f.readlines()
            avu = AnsibleVaultEncryptedUnicode.from_plaintext(lines, vault=None, secret='secret')
            out = avu.data
            assert lines == out
            assert len(lines) == len(out)
            assert lines > 'foo'
            assert lines < avu
    except IOError:
        pass


# Generated at 2022-06-11 09:33:47.603981
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    from ansiblevault import Vault
    sample_pass = 't3stp@$$'
    sample_plain = 'lorem ipsum'

# Generated at 2022-06-11 09:33:50.866278
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode("This is a dummy test string")
    assert ansible_vault_encrypted_unicode.__eq__("This is a dummy test string") == False


# Generated at 2022-06-11 09:33:57.186334
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    """
    check method __eq__ of class AnsibleVaultEncryptedUnicode
    """
    import ansible.vault as vault
    tvault = vault.VaultLib('test')
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', tvault, 'password')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', tvault, 'password')

    assert(avu1 == avu2)



# Generated at 2022-06-11 09:34:02.830992
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    """
    The __add__ method of AnsibleVaultEncryptedUnicode should return
    the concatenation of the plaintext and the unicode string passed
    in.
    """
    avu = AnsibleVaultEncryptedUnicode(b'VGVzdA==\n')
    avu.vault = None
    assert avu + "test" == "Testtest"


# Generated at 2022-06-11 09:34:08.632478
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    text = "this is a sample string"
    secret = "secret"
    # yaml object representation of text
    yaml_obj = yaml.load(text)

    # create a vault object using the secret
    vault = AnsibleVaultEncryptedUnicode.from_plaintext(text, vault=VaultLib(secret), secret=secret)

    # assert that the is_encrypted method of vault returns True
    assert vault.is_encrypted()


# Generated at 2022-06-11 09:34:17.949093
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from .vault import VaultLib
    vault = VaultLib('test')
    test_string = 'some string'
    encrypted_test_string = AnsibleVaultEncryptedUnicode.from_plaintext(test_string, vault, '123')
    assert test_string == encrypted_test_string
    assert encrypted_test_string == test_string
    assert AnsibleVaultEncryptedUnicode('some string') == test_string
    assert test_string != AnsibleVaultEncryptedUnicode('some strings')
    assert AnsibleVaultEncryptedUnicode('some string') == AnsibleVaultEncryptedUnicode('some string')
    assert AnsibleVaultEncryptedUnicode('some string') != AnsibleVaultEncryptedUnicode('some strings')


# Generated at 2022-06-11 09:34:23.555736
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    vault_secret = 'thisismysecret'
    vault_id = 'testvault'
    vault = vaultlib.VaultLib(vault_secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello world', vault, vault_secret)
    assert avu == 'hello world'
    assert avu != 'hello world!'
    assert avu != 'Hello world'


# Generated at 2022-06-11 09:34:28.806239
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(
        'foo', None, None)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(
        'foo', None, None)
    assert(avu1 == avu2)
    assert(avu1 != 'bar')


# Generated at 2022-06-11 09:34:53.822940
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('888888')

# Generated at 2022-06-11 09:34:54.270909
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    pass



# Generated at 2022-06-11 09:35:01.209028
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    valid = AnsibleVaultEncryptedUnicode.from_plaintext('world', object(), 'secret')
    valid_ne = AnsibleVaultEncryptedUnicode.from_plaintext('world', object(), 'notasecret')
    string = AnsibleVaultEncryptedUnicode.from_plaintext('world', object(), 'secret')
    string_ne = 'world'
    assert valid != valid_ne
    assert valid != string
    assert valid != string_ne
    assert string != valid_ne
    assert string != string_ne
    assert string_ne != valid_ne


# Generated at 2022-06-11 09:35:03.855383
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    u1 = AnsibleVaultEncryptedUnicode(b'vault data')
    u2 = AnsibleVaultEncryptedUnicode(b'vault data')
    assert u1 != u2



# Generated at 2022-06-11 09:35:09.079616
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('ansible')
    ciphertext = vault.encrypt('foo', 'password')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    assert avu == avu
    assert not (avu == 'bar')
    assert not (avu != avu)
    assert avu != 'bar'


# Generated at 2022-06-11 09:35:17.719151
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-11 09:35:25.001491
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from vault import VaultLib

    content = 'my secret'
    password = 'secret'
    encrypted_content = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          37636433626532353137613531383164366630626534646536346466663937636530373933323935\n          33396463386438310a64653039646130303135336332396435386639623862656131623236383265\n          3538513734373262623561386435316530633562353139610a643037343730622d62336538373062\n          337a3230303134373932323132313a64323766333832383739303734343239"

    vault = Vault

# Generated at 2022-06-11 09:35:33.542670
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    test_values = [
        # Value      Encrypted?
        [b'YWJjZA==\n',          True],
        [b'$ANSIBLE_VAULT;1.1;AES256\nYWJjZA==\n', False],
        [VaultLib.VAULT_HEADER_MARKER + b'1.1;AES256\nYWJjZA==\n', False],
        [b'abc',                 False],
        [b'\n',                  False],
        [b'',                    False],
    ]
    for value, expected_result in test_values:
        avu = AnsibleVaultEncryptedUnicode(value)
        avu.vault = vault
