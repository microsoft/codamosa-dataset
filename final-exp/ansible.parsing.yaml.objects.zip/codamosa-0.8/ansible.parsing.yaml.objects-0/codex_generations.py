

# Generated at 2022-06-11 09:25:45.855978
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    import ansible.parsing.vault
    vault = ansible.parsing.vault.AnsibleVault(b'abcdefgh')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'test')
    assert avu + 'bar' == 'foobar'

# Generated at 2022-06-11 09:25:54.030717
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.plugins.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from pbkdf2 import PBKDF2
    import binascii

    plaintext = 'abcde'
    password = 'password'
    salt = 'mySalt'

# Generated at 2022-06-11 09:26:01.085123
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu_str_0 = AnsibleVaultEncryptedUnicode.from_plaintext('hello', None, None)
    avu_str_1 = AnsibleVaultEncryptedUnicode.from_plaintext('goodbye', None, None)

    assert(avu_str_0 != 'hello')
    assert(avu_str_1 != 'goodbye')
    assert(avu_str_0 != avu_str_1)


# Generated at 2022-06-11 09:26:13.577983
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Make a Vault object and an encrypted object
    vault = VaultLib("hunter2")
    data = AnsibleVaultEncryptedUnicode.from_plaintext("hello world", vault, "hunter2")
    # Make a copy of the encrypted object and compare it to the encrypted object
    d_copy = AnsibleVaultEncryptedUnicode.from_plaintext("hello world", vault, "hunter2")

# Generated at 2022-06-11 09:26:21.201149
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    # What we are counting
    toSearch = 'abracadabra'

    # Fake vault lib
    class FakeVault(object):
        def __init__(self):
            self.secret = 'secret'
        def is_encrypted(self, value):
            return True
        def decrypt(self, value, obj=None):
            return toSearch

    # Fake vault object
    fakeVault = FakeVault()

    # Fake secure string
    secureString = AnsibleVaultEncryptedUnicode.from_plaintext(toSearch, fakeVault, fakeVault.secret)

    # Determine if the count works
    assert secureString.count(toSearch) == 1

# Test case for methods which inherit from collections.Sequence

# Generated at 2022-06-11 09:26:24.411468
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    assert not AnsibleVaultEncryptedUnicode('foo').find('bar'), \
        'empty vault failed to find sub string'


# Generated at 2022-06-11 09:26:38.266522
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """Test AnsibleVaultEncryptedUnicode.__ne__"""
    # The following check fail because of the
    # check `if self.vault` in the method
    # We do not check all methods here because
    # the between all of them and `__ne__`,
    # they all have the same issue.
    #
    # assert "foobar" != AnsibleVaultEncryptedUnicode("foobar")
    #
    # Since the logic of the method `__ne__` is similar to
    # `__eq__`, we can use `__eq__` to test the `__ne__`.
    # We do not check `__eq__` because the `__eq__` is fairly
    # simple.
    obj_foobar = AnsibleVaultEncryptedUnicode("foobar")
    obj_foobar.v

# Generated at 2022-06-11 09:26:48.213981
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    vault_pass = u'foo'
    vault = VaultLib(vault_pass)
    plaintext = u'foobar'
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, vault_pass)
    plaintext = u'123'
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, vault_pass)
    assert isinstance(avu1.data, text_type)
    assert isinstance(avu2.data, text_type)
    assert isinstance(avu1, Sequence)
    assert isinstance(avu2, Sequence)

# Generated at 2022-06-11 09:27:00.665053
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    my_data = "123"
    my_ciphertext = b"U2FsdGVkX1/vpRmJlVZ+dkAgX9QBqibjJqE3+wmi"
    vault = "fake_vault"
    secret = "secret"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(my_data, vault, secret)
    assert avu.data == my_data
    assert avu._ciphertext == my_ciphertext
    assert avu == my_data
    assert not avu != my_data
    assert not avu > my_data
    assert not avu >= my_data
    assert avu < my_data
    assert avu <= my_data


# Generated at 2022-06-11 09:27:12.988622
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Arrange
    a = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256')
    b = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256')
    c = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256')
    d = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256')
    a.data = b'foo'
    b.data = b'bar'
    c.data = b'foo'
    d.data = b'foo'

    # Act & Assert
    assert a != b
    assert a != c
    assert a == d


# Generated at 2022-06-11 09:27:28.421893
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    plaintext = 'abc'
    vault = AnsibleVault(password='password')

    # encrypted
    encrypted = AnsibleVaultEncryptedUnicode(vault.encrypt(plaintext, 'secret'))
    encrypted.vault = vault

    # unencrypted
    unencrypted = AnsibleVaultEncryptedUnicode(plaintext)
    unencrypted.vault = vault

    # test
    assert encrypted == plaintext
    assert unencrypted != plaintext


# Generated at 2022-06-11 09:27:41.981416
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_config_file = "test/ansible/lib/ansible/test/test_vault_config.yml"

    vault = VaultLib(config_file=vault_config_file)
    secret = VaultSecret('password')

    avue_text = AnsibleVaultEncryptedUnicode(vault.encrypt('foobar', secret))
    avue_text.vault = vault

    avue_text2 = AnsibleVaultEncryptedUnicode(vault.encrypt('foobar', secret))
    avue_text2.vault = vault

    avue_text3 = AnsibleVaultEncryptedUnicode(vault.encrypt('blah', secret))
    av

# Generated at 2022-06-11 09:27:52.591236
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from unittest import skipIf, skipUnless, TestCase
    from ansible.module_utils.six import u
    from ansible.parsing.vault import VaultLib
    import os


# Generated at 2022-06-11 09:28:06.348898
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    """
    Test method AnsibleVaultEncryptedUnicode.__eq__()
    """
    my_str = 'secret info'
    password = 'password'
    secret = 'secret'

    # Create a new vault lib object
    vault = vaultlib.VaultLib(password)

    # Construct a vault object
    avue = AnsibleVaultEncryptedUnicode.from_plaintext(my_str, vault, secret)

    # Test that the AnsibleVaultEncryptedUnicode object is equal to the plaintext version
    assert avue == my_str
    # Test that the AnsibleVaultEncryptedUnicode object is equal to another AnsibleVaultEncryptedUnicode
    # object with the same plaintext

# Generated at 2022-06-11 09:28:16.201587
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert not AnsibleVaultEncryptedUnicode('bar').is_encrypted()
    assert not AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;ansible\n66366433066138633138356262646338643338306439336666353361316564646363384661333364\n3931663237653864616235653132396339393363380a373936303536323164343766303534396633\n61373730636239626637613034383066656330653263313661366565666462336230633962356366\n6338376130\n').is_encrypted()


# Generated at 2022-06-11 09:28:27.201169
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    avu = AnsibleVaultEncryptedUnicode('123xx')
    assert(avu.rfind('x') == 4)
    assert(avu.rfind('x', 0, 4) == 2)
    assert(avu.rfind('x', 0, 3) == 2)
    assert(avu.rfind('x', 0, 2) == -1)
    assert(avu.rfind('x', 0, 1) == -1)
    assert(avu.rfind('x', 1) == 2)
    assert(avu.rfind('x', 4) == 4)
    assert(avu.rfind('x', 5) == -1)



# Generated at 2022-06-11 09:28:33.525254
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:28:44.237913
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode("12345")
    assert ansible_vault_encrypted_unicode.rfind("12") == 0
    assert ansible_vault_encrypted_unicode.rfind("45") == 3
    assert ansible_vault_encrypted_unicode.rfind("3") == 2
    assert ansible_vault_encrypted_unicode.rfind("123") == 0
    assert ansible_vault_encrypted_unicode.rfind("4567") == -1
    assert ansible_vault_encrypted_unicode.rfind("345") == 1

# Register vault_class to load when yaml tag !vault is encountered

# Generated at 2022-06-11 09:28:47.692613
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    secret = b'X'
    vault = AnsibleVault(password=secret)
    plaintext = b'test'
    avue = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avue == plaintext


# Generated at 2022-06-11 09:28:59.439991
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    import vaultlib
    v = vaultlib.VaultLib('password')

    plain_text = u'test_AnsibleVaultEncryptedUnicode___gt__'
    plain_text2 = u'1234'
    plain_text3 = u'_gt__'
    plain_text4 = u'gt__'

    encrypted_text = AnsibleVaultEncryptedUnicode.from_plaintext(plain_text, v, secret='password')
    encrypted_text2 = AnsibleVaultEncryptedUnicode.from_plaintext(plain_text2, v, secret='password')
    encrypted_text3 = AnsibleVaultEncryptedUnicode.from_plaintext(plain_text3, v, secret='password')

# Generated at 2022-06-11 09:29:12.796525
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secrete = 'test'

    avue = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secrete)

    assert avue == 'test'
    assert avue == u'test'

    assert avue != 'Test'
    assert avue != u'Test'

    assert avue != 'test\n'
    assert avue != u'test\n'

    avue2 = AnsibleVaultEncryptedUnicode.from_plaintext('test\n', vault, secrete)

    assert avue != avue2



# Generated at 2022-06-11 09:29:24.100385
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    v = VaultLib('ansible')
    with open('/usr/share/dict/american-english', 'rb') as f:
        plaintext = f.read()
    assert plaintext is not None

    ciphertext = v.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu is not None
    avu.vault = v
    assert avu.vault is not None

    assert avu.is_encrypted() == True
    assert avu.data == plaintext


# Generated at 2022-06-11 09:29:30.471815
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    # Test the most common case: where data is a string
    def test_AnsibleVaultEncryptedUnicode___ne__str_data():
        # data of class str
        ciphertext = 'ciphertext'
        avu = AnsibleVaultEncryptedUnicode(ciphertext)
        # We don't care about the secret here
        avu.vault = 'vault'
        # data is a string
        data = 'ciphertext'
        assert (avu.__ne__(data))

    # Test the most common case: where data is a string
    def test_AnsibleVaultEncryptedUnicode___ne__str_data():
        # data of class str
        ciphertext = 'ciphertext'
        avu = AnsibleVaultEncryptedUnicode(ciphertext)
        # We

# Generated at 2022-06-11 09:29:37.136412
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    '''Is __gt__ implemented correctly?'''
    test_string = 'hello world'
    plaintext = AnsibleVaultEncryptedUnicode(test_string)
    ciphertext = AnsibleVaultEncryptedUnicode('i'*len(test_string))

    assert plaintext < ciphertext
    assert ciphertext > plaintext


# Generated at 2022-06-11 09:29:44.750524
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password='test')

    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test')
    assert avu1 == avu2

    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test1')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'test2')
    assert avu1 != avu2

# this is the class we use when a dictionary key is not a python built-in
# type, since we are using those as subclasses above

# Generated at 2022-06-11 09:29:49.938125
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    try:
        assert AnsibleVaultEncryptedUnicode('ciphertext') > 'plaintext'
    except AnsibleVaultError:
        failed = True
    else:
        failed = False
    assert failed, 'AnsibleVaultEncryptedUnicode(\'ciphertext\') > \'plaintext\' should have failed.'



# Generated at 2022-06-11 09:30:02.274433
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock

    # Set up
    ciphertext = to_bytes('deadbeef')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = MagicMock()

    # Test for the case where the hasher found the password.
    # and decrypted the ciphertext
    avu.vault.decrypt = MagicMock(return_value=to_bytes('Hello'))
    result = avu.__ne__(to_bytes('Hello'))
    assert result is False

    # Test for the case where the password has not been found yet
    # but the decrypt method was called nevertheless
    avu.vault.decrypt = MagicMock(return_value=None)

# Generated at 2022-06-11 09:30:09.772018
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib, VaultSecret
    vault = VaultLib(VaultSecret('abcdef'))
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'abcdef')
    assert avu != 'test'

if __name__ == '__main__':
    import sys
    print('Testing AnsibleVaultEncryptedUnicode')
    test_AnsibleVaultEncryptedUnicode___ne__()
    print('All tests pass')
    sys.exit(0)



# Generated at 2022-06-11 09:30:16.977726
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Test 1
    # Test if __gt__ is implemented correctly
    # Test the first __gt__ condition
    assert(AnsibleVaultEncryptedUnicode('123') > AnsibleVaultEncryptedUnicode('234'))
    # Test the second __gt__ condition
    assert(AnsibleVaultEncryptedUnicode('123') > '234')
    # Test the third __gt__ condition
    assert(AnsibleVaultEncryptedUnicode('123') > '123' == False)

    # Test 2
    # Test the string comparison is case sensitive
    assert(AnsibleVaultEncryptedUnicode('Abc') > AnsibleVaultEncryptedUnicode('abc'))
    assert(AnsibleVaultEncryptedUnicode('Abc') > 'abc' == False)



# Generated at 2022-06-11 09:30:21.492044
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    val1 = AnsibleVaultEncryptedUnicode(u'hello')
    val2 = AnsibleVaultEncryptedUnicode(u'hello')
    val3 = AnsibleVaultEncryptedUnicode(u'world')
    assert not (val1 == val2)
    assert val1 != val3


# Generated at 2022-06-11 09:30:37.078179
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    avu1=AnsibleVaultEncryptedUnicode("a")
    avu2=AnsibleVaultEncryptedUnicode("b")
    avu3=AnsibleVaultEncryptedUnicode("a")
    assert(avu1.__gt__("b"))
    assert(not avu1.__gt__("a"))
    assert(avu1.__gt__("c"))
    assert(not avu1.__gt__("aa"))
    assert(not avu1.__gt__("ab"))
    assert(not avu1.__gt__("A"))
    assert(not avu1.__gt__("B"))

    assert(not avu3.__gt__("b"))
    assert(not avu3.__gt__("a"))

# Generated at 2022-06-11 09:30:48.838683
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    class FakeVault(object):
        def __init__(self, data):
            self._data = data

        @property
        def data(self):
            return self._data

        def is_encrypted(self, blob):
            return False

    data_seq = '$ANSIBLE_VAULT;1.1;AES256;my_user_name@my_local_machine;1;my_user_name@my_local_machine;3;a'

    # In the following tests, we are not checking the __eq__ method
    # So we can make the vault a string for testing purposes

    # We do not fail when the other string is not a vault
    avu = AnsibleVaultEncryptedUnicode(data_seq)
    avu.vault = FakeVault(data='my_password')

# Generated at 2022-06-11 09:30:51.824894
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # SUT
    # Create a new AnsibleVaultEncryptedUnicode object.
    # _from_string() tests are covered elsewhere, so no need to repeat it here
    avu1 = AnsibleVaultEncryptedUnicode._from_string(u'abc')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(u'abc', vaultlib.VaultLib(), 'secret')

    # Verify
    assert avu1 != avu2
    assert avu1 != u'abc'
    assert avu1 != 123


# Generated at 2022-06-11 09:30:59.272590
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    vault = VaultLib('secret')
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')
    assert avu1.__eq__(avu2) == True

    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'secret')
    assert avu1.__eq__(avu2) == False

    vault = VaultLib('secret1')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret2')
    assert avu1.__eq__(avu2) == False


# Generated at 2022-06-11 09:31:01.670627
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Right now, I don't know how to test this method.
    pass


# Generated at 2022-06-11 09:31:04.290154
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    v = 'SampleText'
    ave = AnsibleVaultEncryptedUnicode(v)
    assert ave > 'Sample'


# Generated at 2022-06-11 09:31:14.262377
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    from . import vault
    from .vault import VaultLib
    from .vault import vault_manager
    from .vault import VaultSecret
    from .vault import VaultPassword

    myVault = vault.VaultLib('ansible', password='ansible')

    assert myVault.is_encrypted('$ANSIBLE_VAULT;1.1;AES256')
    assert myVault.is_encrypted(b'$ANSIBLE_VAULT;1.1;AES256')
    assert myVault.is_encrypted(
        to_bytes(AnsibleVaultEncryptedUnicode.yaml_tag)
    )
    assert not myVault.is_encrypted('test')
    assert not myVault.is_encrypted(b'test')

# Generated at 2022-06-11 09:31:26.454092
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert not AnsibleVaultEncryptedUnicode("hello world").is_encrypted()
    assert AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256;myusername\n32653139376536643163313230376538643335376434383332333265336262663135643633\n303433646439656564333332633031336363313838346565623262630a653534666230323266\n3936353462613237643633353636613764386630356466393335313830346433633536323363\n3435636132333462386165623661646565663439\n").is_encrypted()


# Generated at 2022-06-11 09:31:38.033103
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test decrypting string that's not encrypted
    avu = AnsibleVaultEncryptedUnicode('test')
    assert not avu.is_encrypted()
    assert avu == 'test'

    # Test encrypting string that's not encrypted
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vaultlib.VaultLib('test'), 'test')
    assert avu2.is_encrypted()
    assert avu2 == 'test'
    assert avu == avu2
    assert avu2 == avu

    # Test decrypting string that's encrypted

# Generated at 2022-06-11 09:31:44.971435
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    # Make a dummy class that behaves like the vault module
    class DummyVault:
        def encrypt(self, plaintext, secret):
            return plaintext

        def decrypt(self, ciphertext, obj=None):
            return ciphertext

        def is_encrypted(self, ciphertext):
            return True

    avu = AnsibleVaultEncryptedUnicode(to_bytes("Secret string"))
    avu.vault = DummyVault()
    assert "Secret string" == avu
    assert avu == "Secret string"



# Generated at 2022-06-11 09:31:52.112721
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    class MyVault:
        def decrypt(self, s):
            return s

    ciphertext='ABC'
    avu=AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault=MyVault()
    assert 'B' in avu


# Generated at 2022-06-11 09:31:58.605227
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    import binascii

    password = b'$ecret'
    bad_password = b'WrongP@ssw0rD'
    data = b'This is test data'

    password_file = '/tmp/test_AnsibleVaultEncryptedUnicode_is_encrypted'
    with open(password_file, 'w') as f:
        f.write(password)

    # First, we test a valid password
    crypt = VaultLib(password_file)
    ciphertext = crypt.encrypt(data, obj=None)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = crypt
    del crypt

    assert avu.is_encrypted() is True

    # Then, we test a bad

# Generated at 2022-06-11 09:32:00.592797
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    v = 'mysecret'
    s = AnsibleVaultEncryptedUnicode(v)
    assert s == v
    assert s == 'mysecret'
    assert s == s



# Generated at 2022-06-11 09:32:07.608819
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    plaintext = 'hello'
    secret = 'password'
    vault_obj = VaultLib(secret=secret)
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault_obj, secret)
    assert (avu1 != plaintext)
    plaintext = 'hello'
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault_obj, secret)
    assert (avu1 != avu2)


# Generated at 2022-06-11 09:32:12.230724
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode.__eq__(None, "", "") == False, "Should be false"
    assert AnsibleVaultEncryptedUnicode.__eq__(None, "abc", "abc") == True, "Should be true"
    assert AnsibleVaultEncryptedUnicode.__eq__(None, "abc", "def") == False, "Should return false"


# Generated at 2022-06-11 09:32:23.141081
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''
    Test AnsibleVaultEncryptedUnicode.__ne__() method.
    '''
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('dummy_plaintext', None, None)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('other_dummy_plaintext', None, None)
    assert avu.__ne__(avu2) is True
    assert avu.__ne__('dummy_plaintext') is True
    avu.data = 'dummy_plaintext'
    avu2.data = 'dummy_plaintext'
    assert avu.__ne__(avu2) is False
    assert avu.__ne__('dummy_plaintext') is False


# Generated at 2022-06-11 09:32:28.860404
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    """
    Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
    """
    str1 = 'abc'
    str2 = 'abc'
    str3 = 'abc'
    str4 = 'abc'
    ans = AnsibleVaultEncryptedUnicode(str1)
    ans.vault = MockVault()
    assert str1 in ans
    assert str2 not in ans
    assert str3 in ans
    assert str4 not in ans


# Generated at 2022-06-11 09:32:38.411300
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    import vaultlib
    vault = vaultlib.VaultLib("test")
    plainstr = "test"
    cipherstr = vault.encrypt(plainstr, secret="test")
    cipherstr_utf8 = cipherstr.decode("utf-8")

    # Test case when both objects are ciphertext
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(cipherstr, vault, secret = "test")
    avu2 = AnsibleVaultEncryptedUnicode(cipherstr)
    avu2.vault = vault
    assert avu1.__gt__(avu2) == False
    assert avu2.__gt__(avu1) == False

    # Test case when first object is plaintext and second object is ciphertext
    avu1 = AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:32:44.489244
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    secret = to_bytes('ansible-vault-test')
    vault = VaultLib(secret)
    test_s = 'test'
    test_v = AnsibleVaultEncryptedUnicode.from_plaintext(test_s, vault=vault, secret=secret)
    assert test_s != test_v
    test_v.vault = vault
    assert test_s != test_v


# Generated at 2022-06-11 09:32:45.821002
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    string1 = AnsibleVaultEncryptedUnicode()



# Generated at 2022-06-11 09:33:15.841948
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault.VaultLib
    from ansible.parsing.vault import VaultLib

    secret = b'$ecret'

    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(b'$ecret', VaultLib.VaultLib(b'$ecret'), secret)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(b'$ecret', VaultLib.VaultLib(b'$ecret'), secret)

    assert avu1.vault == avu2.vault

    assert avu1.is_encrypted()
    assert avu1.vault.is_encrypted(avu1._ciphertext)

    assert avu1.data == avu2.data
    assert avu1.data == secret

   

# Generated at 2022-06-11 09:33:28.754871
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    '''
    Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
    '''
    class CustomVault(object):
        def __init__(self):
            self.secret = 'password'

        def encrypt(self, value, secret):
            assert value[0] == '$'
            assert value[-1] == '$'
            return 'encrypted({},{})'.format(value, secret)

        def decrypt(self, ciphertext, obj=None):
            assert ciphertext[0] == 'e'
            assert ciphertext[-1] == ')'.format(self.secret)
            return '$decrypted$'

        def is_encrypted(self, value):
            assert value[0] == 'e'
            assert value[-1] == ')'
            return True

    #

# Generated at 2022-06-11 09:33:39.616788
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vlt = VaultLib([])
    func = vlt.encrypt
    base10 = 'abcdefghijklmnopqrstuvwxyz'
    if sys.version_info[0] == 2:
        base10 = base10.encode('utf-8')

# Generated at 2022-06-11 09:33:47.374868
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:33:54.816228
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault
    obj = ansible.parsing.vault.VaultLib("test")
    assert not AnsibleVaultEncryptedUnicode("test").is_encrypted()
    assert not AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.2;AES256;test", obj).is_encrypted()
    assert AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.2;AES256;test" + obj.CIPHER_BLOCK_SIZE * "\x00", obj).is_encrypted()


# Generated at 2022-06-11 09:34:05.142077
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    # test for python 2.7
    for sys_version in ['2.7.3', '2.7.4', '2.7.5', '2.7.6', '2.7.7']:
        sys.version_info = tuple([int(i) for i in sys_version.split('.')])
        assert AnsibleVaultEncryptedUnicode(b"$ANSIBLE_VAULT;1.1;AES256\n36333636323233326564393433383465656637356563353465323033373862623532\n623035383631653361613862623732373437396234653430633039653833\n").is_encrypted()
        assert not AnsibleVaultEncryptedUnicode(b"test").is_encrypted()

   

# Generated at 2022-06-11 09:34:14.268803
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    Test for method __ne__ of class AnsibleVaultEncryptedUnicode
    """
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode, VaultLib
    vault = VaultLib([])
    secret = 'asdf'

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test content', vault, secret)
    assert avu != 'test content'
    assert not (avu != avu)
    assert (avu != 'other_content')

    assert not (avu != AnsibleVaultEncryptedUnicode.from_plaintext('test content', vault, secret))
    assert avu != AnsibleVaultEncryptedUnicode.from_plaintext('other_content', vault, secret)

# Generated at 2022-06-11 09:34:24.765533
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    # type: () -> None
    #
    # NOTE: This unit test is a partial Python 3.5 migration test.
    # It is here to catch regressions with Python 2.7
    #
    # The __contains__ method is reimplemented by the class
    # AnsibleVaultEncryptedUnicode to return False for any value
    # as long as the ciphertext is not empty ('0' for instance).
    # If the vault is not set (no decryption method available)
    # the method will never return True.

    # This is the behavior for Python 2.7
    vault = AnsibleVaultEncryptedUnicode('0')
    assert not 'x' in vault
    assert not b'x' in vault
    assert not '0' in vault

    # This is the behavior for Python 3.5 with an empty ciphertext
   

# Generated at 2022-06-11 09:34:35.862182
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test for equality to another AnsibleVaultEncryptedUnicode
    class FakeVault(object):
        def decrypt(self, ciphertext, obj=None):
            return 'This is a decrypted string'

        def is_encrypted(self, ciphertext):
            return True


# Generated at 2022-06-11 09:34:37.487432
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert not (AnsibleVaultEncryptedUnicode('foo') != 'foo')
    assert AnsibleVaultEncryptedUnicode('foo') != 'bar'


# Generated at 2022-06-11 09:34:58.825459
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    vault_text = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'password')

    assert vault_text.is_encrypted()

    clear_text = AnsibleVaultEncryptedUnicode('test')

    assert not clear_text.is_encrypted()



# Generated at 2022-06-11 09:35:07.672856
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    s = VaultLib()

    # Test with a ciphertext
    avu = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256")
    assert avu.is_encrypted()
    assert not avu.vault

    # Test with plaintext
    avu = AnsibleVaultEncryptedUnicode("test is not encrypted")
    assert not avu.is_encrypted()
    assert not avu.vault

    # Test with a ciphertext
    avu = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256")
    assert avu.is_encrypted()
    assert not avu.vault

    # Test with a ciphertext and vault set
    avu = Ans

# Generated at 2022-06-11 09:35:13.519624
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("hello", None, None)
    assert not avu.__eq__("world"), "Failed asserting that AnsibleVaultEncryptedUnicode object is not equal to 'hello'"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("hello", None, None)
    assert not avu.__eq__(AnsibleVaultEncryptedUnicode.from_plaintext("world", None, None)), "Failed asserting that AnsibleVaultEncryptedUnicode object is equal to 'world'"


# Generated at 2022-06-11 09:35:17.844764
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    plaintext = 'plaintext'
    ciphertext = VaultLib.encrypt(text_type(plaintext).encode('utf-8'), password='secret')
    assert AnsibleVaultEncryptedUnicode(ciphertext).is_encrypted()


# class used to capture errors and display them later

# Generated at 2022-06-11 09:35:24.882740
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault_pass = 'test_AnsibleVaultEncryptedUnicode___ne__'
    plaintext = 'test_AnsibleVaultEncryptedUnicode___ne__'
    vault = VaultLib(vault_pass)
    ciphertext = vault.encrypt(plaintext)
    avu1 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu1.vault = vault
    avu2 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu2.vault = vault
    assert avu1 != avu2
    assert avu1 != avu1.data
    assert avu2 != avu2.data


# Generated at 2022-06-11 09:35:33.360952
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import unittest

    class testAnsibleVaultEncryptedUnicode(unittest.TestCase):
        def test_equality(self):
            from ansible.parsing.vault import VaultLib
            from base64 import b64decode
            from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

            vault = VaultLib(password=b'secret')
            plaintext = b"test string"
            ciphertext = vault.encrypt(plaintext)
            avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, b'secret')
            self.assertEqual(ciphertext, avu._ciphertext)
            self.assertEqual(plaintext, avu.data)
            # Test equality with the same string