

# Generated at 2022-06-11 09:26:00.963875
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    from ansible.constants import VAULT_PASSWORD_FILE
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    import tempfile

    def do_test(yaml_text, vault_text):
        # Create temp file and write the vault data to it
        vault_file = tempfile.NamedTemporaryFile()
        vault_file.write(to_bytes(vault_text))
        vault_file.flush()

        # Run constructor
        yaml_obj = yaml.load(yaml_text, Loader=AnsibleConstructor)
        vault = VaultLib(filename=vault_file.name)

        # Compare the two objects

# Generated at 2022-06-11 09:26:13.480632
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    class FakeVaultLib(object):
        def is_encrypted(self, ciphertext):
            return True

        def decrypt(self, ciphertext, obj=None):
            if isinstance(ciphertext, AnsibleVaultEncryptedUnicode):
                ciphertext = ciphertext._ciphertext
            return ciphertext.decode('utf-8')

        def encrypt(self, plaintext, secret):
            return plaintext

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    fake_vault_lib = FakeVaultLib()
    s = AnsibleVaultEncryptedUnicode.from_plaintext('foo bar', fake_vault_lib, 'secret')

    assert s.find('foo') == 0
    assert s.find('baz') == -1

# Generated at 2022-06-11 09:26:23.018778
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Create some objects to test against
    avu_a = AnsibleVaultEncryptedUnicode('a')
    avu_d = AnsibleVaultEncryptedUnicode('d')
    avu_e = AnsibleVaultEncryptedUnicode('e')
    avu_f = AnsibleVaultEncryptedUnicode('f')
    avu_g = AnsibleVaultEncryptedUnicode('g')
    avu_h = AnsibleVaultEncryptedUnicode('h')
    avu_i = AnsibleVaultEncryptedUnicode('i')
    # Unicode
    avu_z = AnsibleVaultEncryptedUnicode('z')
    # AnsibleVaultEncryptedUnicode
    avu_z_u = AnsibleVaultEncryptedUnicode('z')
   

# Generated at 2022-06-11 09:26:31.150716
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    avu = AnsibleVaultEncryptedUnicode()
    avu.data = 'ansible'
    assert not avu > 'ansible'
    assert avu > 'ans'
    avu2 = AnsibleVaultEncryptedUnicode()
    avu2.data = 'ans'
    assert avu > avu2
    assert not avu > 'ansible'


# Generated at 2022-06-11 09:26:42.931407
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    # A AnsibleVaultEncryptedUnicode with a Vault attribute that can decrypt it.
    avu = AnsibleVaultEncryptedUnicode(b'blahblah')

    # isinstance
    assert False == isinstance(avu, text_type)
    assert True == isinstance(avu, AnsibleVaultEncryptedUnicode)
    assert True == isinstance(avu, AnsibleVaultEncryptedUnicode)
    assert False == isinstance(1, AnsibleVaultEncryptedUnicode)

    # len
    assert 4 == len(avu)

    # The .data attribute is a property that returns the decrypted plaintext
    # of the ciphertext as a PY2 unicode or PY3 string object.
    assert 'blahblah' == avu.data

    # __eq__
   

# Generated at 2022-06-11 09:26:51.028786
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    secret = u'$ecret'
    # Create some examples
    print(u'Test for AnsibleVaultEncryptedUnicode class')
    print(u'  Test for method count')
    print
    print
    plaintext = u'abcabcabcabcabcabc'
    ciphertext = u'$ANSIBLE_VAULT;1.1;AES256\n%s\n' % plaintext.encode('base64')
    print('string: %s' % ciphertext)
    vault = VaultLib(secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    print('  count: %s' % avu.count('ab'))
    # Asserts

# Generated at 2022-06-11 09:27:02.180235
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    # We need a vault lib to do this test.
    vault = VaultLib([])

    # Test empty string, should return false
    avu = AnsibleVaultEncryptedUnicode(ciphertext=b'')
    avu.vault = vault
    assert not avu.is_encrypted()

    # Test encrypted empty string, should return true
    ciphertext = vault.encrypt(u'', password='secret')
    avu = AnsibleVaultEncryptedUnicode(ciphertext=ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()

    # Test encrypted empty string, with vault key, should return true

# Generated at 2022-06-11 09:27:15.255674
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:27:27.289412
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    class Callback:
        def __init__(self, callback):
            self.callback = callback

        def __call__(self, *args, **kwargs):
            return self.callback(*args, **kwargs)

    class MockedVault:
        def __init__(self, vault_id, return_value=None):
            self.vault_id = vault_id
            self.return_value = return_value
            self.is_encrypted_called = False
            self.decrypt_called = False

        def is_encrypted(self, *args, **kwargs):
            self.is_encrypted_called = True
            return True

        def decrypt(self, *args, **kwargs):
            self.decrypt_called = True
            return self.return_value


# Generated at 2022-06-11 09:27:30.508465
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with strings
    assert(AnsibleVaultEncryptedUnicode('secret') != 'secret')
    assert(AnsibleVaultEncryptedUnicode('secret') != AnsibleVaultEncryptedUnicode('secret'))


# Generated at 2022-06-11 09:27:39.015136
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
  # Test if the __ne__ method work when the value is not encrypted"
  a = AnsibleVaultEncryptedUnicode('plaintext')
  assert a == 'plaintext'
  assert a != 'ciphertext'


# Generated at 2022-06-11 09:27:49.408386
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    vault=MockVault("")
    secret="hello"
    secret_guess="world"

    a=AnsibleVaultEncryptedUnicode.from_plaintext("a", vault, secret)
    b=AnsibleVaultEncryptedUnicode.from_plaintext("a", vault, secret)
    c=AnsibleVaultEncryptedUnicode.from_plaintext("b", vault, secret)
    d=AnsibleVaultEncryptedUnicode.from_plaintext("a", vault, secret_guess)

    assert(a==b)
    assert(a!=c)
    assert(a!=d)
    assert(d!=c)


# Generated at 2022-06-11 09:27:57.040179
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import os
    import tempfile

    from ansible.parsing.vault import VaultLib

    vault_password = 'password'
    vault_files = []
    plaintext = 'hello world'

# Generated at 2022-06-11 09:28:10.325349
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    # Simple test
    a = AnsibleVaultEncryptedUnicode('foo bar')
    b = AnsibleVaultEncryptedUnicode('foo')
    assert a.find(b) == 0
    try:
        a.find(b, 1)
        assert False
    except ValueError:
        assert True
    assert a.find(b, 0, 6) == 0
    assert a.find(b, 1, 6) == -1
    # Test of in.find(not in)
    assert a.find(b + 'a') == -1
    # Test of not in.find(in)
    assert (b + 'a').find(a) == -1
    # Test of search with in.find(in)
    assert (a * 2).find(a) == 0
    # Test of search with start and end

# Generated at 2022-06-11 09:28:15.196168
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    key_file = "test_file"
    password = "test_passwd"
    vault = VaultLib(key_file, password)

    seq = "test_sequence"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, password)
    assert(avu.__eq__(seq))


# Generated at 2022-06-11 09:28:22.972955
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    v = AnsibleVaultEncryptedUnicode('123')
    assert v.find('2') == 1
    assert v.find('4') == -1

    v = AnsibleVaultEncryptedUnicode('123')
    assert v.find(AnsibleVaultEncryptedUnicode('2')) == 1
    assert v.find(AnsibleVaultEncryptedUnicode('4')) == -1


# Generated at 2022-06-11 09:28:34.228088
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    class Test:
        def __init__(self, value):
            self.value = value

        def decrypt(self, ciphertext, obj=None):
            return self.value
    # test with string
    test = AnsibleVaultEncryptedUnicode("test")
    test.vault = Test("test")
    assert test.count("test") == 1
    test.vault = Test("testtest")
    assert test.count("test") == 2
    # test with AnsibleVaultEncryptedUnicode
    test2 = AnsibleVaultEncryptedUnicode("test")
    test.vault = Test("test")
    assert test.count(test2) == 1
    test.vault = Test("testtest")
    assert test.count(test2) == 2


# Generated at 2022-06-11 09:28:44.771590
# Unit test for method count of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:28:46.878563
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avue = AnsibleVaultEncryptedUnicode(b'asdf')
    assert avue != 'asdf'


# Generated at 2022-06-11 09:28:58.604489
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    str_value = to_text('xyz')
    vault_value = AnsibleVaultEncryptedUnicode('xyz')
    assert(str_value.__getslice__(0,3)=='xyz')
    assert(vault_value.__getslice__(0,3).data=='xyz')


    str_value = 'xyz'
    vault_value = AnsibleVaultEncryptedUnicode('xyz')
    assert(str_value.__getslice__(0,3)=='xyz')
    assert(vault_value.__getslice__(0,3).data=='xyz')

    # Test fix for ANSIBLE-2648

    str_value = 'xyz'
    vault_value = AnsibleVaultEncryptedUnicode('xyz')


# Generated at 2022-06-11 09:29:13.267016
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    my_vault = vault_loader.load_vault_from_file('test/fixtures/vault_test_password')
    my_secret = 'vault_test_secret'
    my_str = 'sensitive info'
    my_avu = AnsibleVaultEncryptedUnicode.from_plaintext(my_str, my_vault, my_secret)
    assert my_str == my_avu


# Generated at 2022-06-11 09:29:24.528860
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # A simple test to show how to encrypt and use AnsibleVaultEncryptedUnicode
    # with the default vault
    from ansible.parsing.vault import VaultLib

    plaintext = u'This is the plaintext to be encrypted'
    secret = u'This is the secret phrase used to encrypt the plaintext'
    vault = VaultLib()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)

    # __eq__ is used in ansible-playbook to detect encrypted variables
    result = avu.__eq__(plaintext)
    assert result == True


# Generated at 2022-06-11 09:29:39.344951
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    if sys.version_info.major == 3:
        unicode_type = str
    else:
        unicode_type = unicode
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(unicode_type('string1'), vault=None, secret='1234')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(unicode_type('string2'), vault=None, secret='1234')
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext(unicode_type('string2'), vault=None, secret='1234')
    if avu1 != 'string1':
        raise ValueError('Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode fails')
    if 'string1' != avu1:
        raise

# Generated at 2022-06-11 09:29:44.069670
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    class AnsibleVaultEncryptedUnicode
        def __ne__(self, other):
            if self.vault:
                return other != self.data
            return True
    """
    assert AnsibleVaultEncryptedUnicode('test').__ne__('test')
    assert not AnsibleVaultEncryptedUnicode('test').__ne__('test2')


# Generated at 2022-06-11 09:29:56.522928
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:30:01.654090
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode("test") == AnsibleVaultEncryptedUnicode("test")
    assert not (AnsibleVaultEncryptedUnicode("test") == AnsibleVaultEncryptedUnicode("test2"))
    assert not (AnsibleVaultEncryptedUnicode("test") == "test")



# Generated at 2022-06-11 09:30:06.277584
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    a = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    # is_encrypted returns always False because it cant properly decrypt the object
    assert a.is_encrypted() == True, 'AnsibleVaultEncryptedUnicode object should always be encrypted'



# Generated at 2022-06-11 09:30:07.581793
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode('some text')
    avu2 = AnsibleVaultEncryptedUnicode('some text')
    assert avu != avu2


# Generated at 2022-06-11 09:30:12.346971
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible_vault import VaultLib
    import binascii

    vault = VaultLib('secret')

    # Vault not set
    avu = AnsibleVaultEncryptedUnicode('\x1a\xe1\x8f\x93\xfa\x04\x08\x890\x9d\x1a\xc1\x01 \xfe\xdf\xf4\x01\x17\x8c\xf1\xfb\xb6\x98\xca\x16\x13\x0e>\x95\xb1|\x9a\xc9\xbd\xf8\x8d')
    assert avu.is_encrypted() is False

    # Vault set
    avu.vault = vault
    assert avu.is_encrypted() is True

    #

# Generated at 2022-06-11 09:30:15.517553
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test when self.vault is not None
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=MockVault(), secret='secret')
    assert avu.__ne__('bar')
    assert not avu.__ne__('foo')

    # Test when self.vault is None
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu.__ne__('bar')
    assert not avu.__ne__('foo')


# Generated at 2022-06-11 09:30:32.175245
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Create a AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode(b"value")

    # Set its vault attribute
    avu.vault = "mock_vault"

    # Create a second AnsibleVaultEncryptedUnicode
    avu2 = AnsibleVaultEncryptedUnicode(b"value")
    avu2.vault = "mock_vault"

    # Check that avu is equal to avu2
    assert avu == avu2


# Generated at 2022-06-11 09:30:41.078140
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault
    import ansible.parsing.yaml
    import os
    import tempfile

    # Create a temporary file to use as the vault secret
    secret_file = tempfile.NamedTemporaryFile(delete=False)
    secret_file.write(b'password')
    secret_file.close()

    # Create a vault object, an encrypted AnsibleVaultEncryptedUnicode,
    # and some string and int data to test
    vault = ansible.parsing.vault.VaultLib(password_file=secret_file.name)
    encrypted_data = ansible.parsing.yaml.AnsibleVaultEncryptedUnicode.from_plaintext('secret', vault, secret_file.name)
    plain_data = 'secret'
    plain_bytes

# Generated at 2022-06-11 09:30:48.388888
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    ciphertext = vault.encrypt('plaintext', password='secret')
    avue = AnsibleVaultEncryptedUnicode(ciphertext)
    avue.vault = vault
    assert avue == 'plaintext'
    assert avue != 'wrong_plaintext'
    assert avue != AnsibleVaultEncryptedUnicode('wrong_ciphertext')


# Generated at 2022-06-11 09:30:51.098330
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode('hi') != 'hi'


# Generated at 2022-06-11 09:30:53.309333
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    encrypted_string = AnsibleVaultEncryptedUnicode(encrypted_data)

    assert(encrypted_string != decrypted_data)


# Generated at 2022-06-11 09:30:54.829456
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode('abc') != 'abc'



# Generated at 2022-06-11 09:31:03.221237
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    class MyAV(AnsibleVaultEncryptedUnicode):
        pass

    a = 'abcdef'
    b = 'abcdefg'

    av_a = MyAV.from_plaintext(a, None, None)
    av_b = MyAV.from_plaintext(b, None, None)

    assert a == av_a
    assert b == av_b
    assert av_a == a
    assert av_b == b
    assert av_a == av_a
    assert av_b == av_b
    assert av_a != av_b
    assert av_b != av_a


# Generated at 2022-06-11 09:31:09.618810
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(None)
    plaintext = u'foo'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, 'secret')
    assert avu == plaintext
    assert avu == avu.data
    assert avu != 'bar'
    assert avu != AnsibleVaultEncryptedUnicode('bar')


# Generated at 2022-06-11 09:31:17.666636
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.constructor import AnsibleVaultUnsupportedVersion

    # This is taken from the ansible vault documentation
    # https://docs.ansible.com/ansible/2.4/vault.html#how-vault-works

# Generated at 2022-06-11 09:31:23.673909
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    secret = 'secret'
    s = 'secure string'
    vault = VaultLib([])

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(s, vault, secret)

    assert(avu.is_encrypted())


# Generated at 2022-06-11 09:31:41.385994
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    obj = type('', (), {'data':'test123'})()
    obj.data = 'test123'
    assert obj.__eq__('test123')


# Generated at 2022-06-11 09:31:44.734253
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import datetime
    a = AnsibleVaultEncryptedUnicode(
        "---\nfoo: 'bar'\nbar: {a: 2, b: 3}\n")
    assert a != datetime.datetime.now()


# Generated at 2022-06-11 09:31:46.616637
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault
    vault = ansible.parsing.vault.AnsibleVaultLib(None)
    unencrypted = 'I love milk'
    avu = AnsibleVaultEncryptedUnicode(unencrypted)
    avu.vault = vault
    assert not avu.is_encrypted()



# Generated at 2022-06-11 09:31:53.460281
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """Test __ne__ method for AnsibleVaultEncryptedUnicode class.

    Specifically, we want to test that __ne__ returns a boolean result.
    """
    import ansible.parsing.vault
    vault = ansible.parsing.vault. VaultLib('secret')
    ciphertext = vault.encrypt('plaintext', 'password')

    #()
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    # Test with ciphertext as input
    assert isinstance(avu != ciphertext, bool)

    # Test with unicode as input
    assert isinstance(avu != u'plaintext', bool)

    # Test with bytestring as input
    assert isinstance(avu != b'plaintext', bool)

    # Test with string as

# Generated at 2022-06-11 09:31:59.961304
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    # Test case 1:
    # Encrypted data comparison
    secret = 'this is a secret'
    decrypted_data = 'Hello World'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(decrypted_data, vaultlib.VaultLib(password='ansible'), secret)
    other_avu = AnsibleVaultEncryptedUnicode.from_plaintext(decrypted_data, vaultlib.VaultLib(password='ansible'), secret)
    assert (avu != other_avu)

    # Test case 2:
    # Encrypted data comparison
    secret = 'this is a secret'
    decrypted_data = 'Hello World'

# Generated at 2022-06-11 09:32:09.240609
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import unittest
    import operator
    import string
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml import VaultAwareDumper
    import sys

    if sys.hexversion < 0x02070000:
        raise unittest.SkipTest("vault features not available in python < 2.7")

    # Create a random password
    password = ''.join(
        random.SystemRandom().choice(
            string.ascii_letters + string.digits
        ) for _ in range(20)
    )

    # Create a vault object
    vault = VaultLib([password])

    # Create a AnsibleVaultEncryptedUnicode object
    av1 = AnsibleVault

# Generated at 2022-06-11 09:32:19.581074
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:32:25.321955
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.utils.vault as vaultlib
    password = "test_password"
    secret = "hello"
    vault = vaultlib.VaultLib(password)
    encrypted_secret = vaultlib.VaultLib.encrypt(vault, secret, password)
    avu_secret = AnsibleVaultEncryptedUnicode(encrypted_secret)
    avu_secret.vault = vault

    assert avu_secret == secret


# Generated at 2022-06-11 09:32:27.605155
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avue_u = AnsibleVaultEncryptedUnicode(u'?')
    assert avue_u != u'?'


# Generated at 2022-06-11 09:32:37.136369
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing import vault
    class MockVault(object):
        def __eq__(self, other): return True
        def is_encrypted(self, data): return True
        def is_encrypted_data(self, data): return True
        def encrypt(self, data, secret): return data
        def decrypt(self, data, secret, obj=None): return data

    vault = MockVault()
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, None)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, None)

    assert avu1 == 'foo'
    assert avu2 == 'bar'
    assert avu1 == avu2
    assert not (avu1 == 'bar')

# Generated at 2022-06-11 09:33:17.574968
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(None)
    vault.decrypt = lambda v, i: v

    a = AnsibleVaultEncryptedUnicode.from_plaintext(u"a", vault, u"foo")
    b = AnsibleVaultEncryptedUnicode.from_plaintext(u"b", vault, u"foo")
    c = AnsibleVaultEncryptedUnicode.from_plaintext(u"c", vault, u"bar")

    assert a != b
    assert a != "b"
    assert a != None

    with pytest.raises(vault.AnsibleVaultError):
        assert a != c



# Generated at 2022-06-11 09:33:30.821624
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    class FakeVault(object):
        def is_encrypted(self, ciphertext):
            return False

        def decrypt(self, ciphertext, obj=None):
            return to_bytes('abc')

    # Equal keys
    a1 = AnsibleVaultEncryptedUnicode(to_bytes('abc'))
    a1.vault = FakeVault()
    a2 = AnsibleVaultEncryptedUnicode(to_bytes('abc'))
    a2.vault = FakeVault()
    assert a1 != a2

    # Equal values
    a1 = AnsibleVaultEncryptedUnicode(to_bytes('abc'))
    a1.vault = FakeVault()
    a2 = AnsibleVaultEncryptedUnicode(to_bytes('abc'))
    a2.vault = FakeV

# Generated at 2022-06-11 09:33:41.440332
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('123')
    text_not_encrypted = 'some text'
    text_encrypted = vault.encrypt(text_not_encrypted)
    text_foo = "foo"
    # not initialized
    assert AnsibleVaultEncryptedUnicode(text_encrypted).is_encrypted() == False
    # initialized but wrong vault class
    avu = AnsibleVaultEncryptedUnicode(text_encrypted)
    avu.vault = text_foo
    assert avu.is_encrypted() == False
    # initialized and correct vault class
    avu = AnsibleVaultEncryptedUnicode(text_encrypted)
    avu.vault = VaultLib('123')
    assert avu.is_encrypted() == True
    avu = AnsibleV

# Generated at 2022-06-11 09:33:47.405221
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # initialize a AnsibleVaultEncryptedUnicode class with some non-encrypted data
    foo = AnsibleVaultEncryptedUnicode.from_plaintext('unencrypted', None, None)
    foo.vault = None

    # initialize a AnsibleVaultEncryptedUnicode class with some encrypted data
    # foo_crypt = AnsibleVaultEncryptedUnicode.from_plaintext('encrypted', vault, None)
    # foo_crypt.vault = vault

    assert foo.is_encrypted() == False
    # assert foo_crypt.is_encrypted() == True


# Generated at 2022-06-11 09:33:57.086522
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    VAULT_SECRET_FILE = 'ansible_vault_secrets.txt'
    vault_secret = VaultSecret(VAULT_SECRET_FILE)
    vault = VaultLib(vault_secret)

    clear_text_string = 'clear_text_string'
    ansible_vault = AnsibleVaultEncryptedUnicode.from_plaintext(
        clear_text_string,
        vault,
        vault_secret)
    assert isinstance(ansible_vault, AnsibleVaultEncryptedUnicode)
    assert ansible_vault.is_encrypted()

    another_vault_secret = VaultSecret(VAULT_SECRET_FILE)
    another_vault = Vault

# Generated at 2022-06-11 09:34:01.009040
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    data = 'test'
    plain_data = AnsibleVaultEncryptedUnicode.from_plaintext(data, None, None)
    plain_data.data = data

    assert data != plain_data
    assert plain_data != data


# Generated at 2022-06-11 09:34:10.724026
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:34:14.176142
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    Tests that __ne__ returns True if the plaintext of it's argument is not equal to the plaintext of self.
    """
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu != 'test1'


# Generated at 2022-06-11 09:34:24.671854
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # The purpose of this test is to make sure that the is_encrypted()
    # method of the AnsibleVaultEncryptedUnicode class returns True when
    # the data is encrypted and False when not encrypted.
    test_str = AnsibleVaultEncryptedUnicode('test')
    assert not test_str.is_encrypted()

    # create a vault object and use it to encrypt test_str
    test_vault = yaml.YAMLVaultLoader('', 'yaml')
    test_vault.vault.start_session()
    test_vault.vault.update_secret('secret')
    test_str.data = test_vault.vault.encrypt(test_str.data, test_vault.vault.secret)
    test_str.vault = test_vault.vault


# Generated at 2022-06-11 09:34:28.391877
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    a = AnsibleVaultEncryptedUnicode('test')
    b = AnsibleVaultEncryptedUnicode('test')

    assert a != b
    assert b != a

    assert a != 'test'
    assert 'test' != a

