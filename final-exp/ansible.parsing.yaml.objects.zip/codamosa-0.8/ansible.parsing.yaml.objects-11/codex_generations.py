

# Generated at 2022-06-11 09:26:02.144333
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Variables
    ciphertext = '!vault |$ANSIBLE_VAULT;1.1;AES256\n33303565643666633332653065666633396566346234323163323661626261356233323830336664\n38353030326134363934353336663635386635323236363035383464623834653035336131393031\n3265396462336538303534626639666636348\n'
    password = 'test'
    secret = 'test'
    data = 'test'

    # Mock AnsibleVault
    av = None

# Generated at 2022-06-11 09:26:14.256499
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # Create a new object and assign it to a variable
    # This should work correctly
    test_string = "Hello World"
    avueu1 = AnsibleVaultEncryptedUnicode(test_string)
    avueu1.vault = True

    assert "Hello World" == avueu1

    # Comparing it to a string should work as long as it is not an AnsibleVaultEncryptedUnicode
    assert avueu1 < test_string

    # Comparing it to an AnsibleVaultEncryptedUnicode with the same data should return False
    test_string2 = "Hello World"
    avueu2 = AnsibleVaultEncryptedUnicode(test_string2)
    avueu2.vault = True
    assert avueu1 == avueu2

# Generated at 2022-06-11 09:26:22.139804
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import ansible.parsing.vault as vault
    import ansible.parsing.vault.util as vault_util
    v = vault.VaultLib(password=to_text(vault_util.generate_result_unicode_password()))
    my_text = u'this is my text'
    vault_unicode1 = AnsibleVaultEncryptedUnicode.from_plaintext(my_text, v, secret=None)
    vault_unicode2 = AnsibleVaultEncryptedUnicode.from_plaintext(my_text, v, secret=None)
    # test equal
    assert vault_unicode1.__ne__(my_text)
    assert vault_unicode1.__ne__(vault_unicode2)
    # test not equal
    vault_unicode2 = Ans

# Generated at 2022-06-11 09:26:32.780453
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    vault = None
    secret = 'secret'

    encrypted_a = AnsibleVaultEncryptedUnicode.from_plaintext('a', vault, secret)
    encrypted_b = AnsibleVaultEncryptedUnicode.from_plaintext('b', vault, secret)
    encrypted_aa = AnsibleVaultEncryptedUnicode.from_plaintext('aa', vault, secret)

    assert encrypted_a == 'a'
    assert 'a' == encrypted_a
    assert encrypted_a != encrypted_b
    assert encrypted_a != encrypted_aa


# Generated at 2022-06-11 09:26:37.128687
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib()

    avu_text = 'this is a string'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(avu_text, vault, 'secret')

    #assert that the vaulted object is encrypted
    assert avu.is_encrypted()

    #assert that the vaulted object is not encrypted
    avu_text = 'this is a string'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(avu_text, None, 'secret')
    assert not avu.is_encrypted()


# Generated at 2022-06-11 09:26:44.346083
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    """
    Call v.__lt__(w) and v.__lt__(s)
    where v is AnsibleVaultEncryptedUnicode, w is AnsibleVaultEncryptedUnicode, 
    and s is string.
    """
    v = AnsibleVaultEncryptedUnicode("password")
    w = AnsibleVaultEncryptedUnicode("password_")
    s = "password"
    assert v.__lt__(w)
    assert v.__lt__(s)


# Generated at 2022-06-11 09:26:50.552728
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    avu = AnsibleVaultEncryptedUnicode('hello world')
    assert avu < 'hello world'
    assert avu == 'hello world'
    assert avu >= 'hello world'
    assert not (avu < 'hello')
    assert avu > 'hello'
    assert not (avu <= 'hello')
    assert avu >= 'hello'
    assert not (avu < 'hello there')
    assert avu > 'hello there'
    assert avu != 'hello there'
    assert not (avu <= 'hello there')
    assert not (avu == 'hello there')


# Generated at 2022-06-11 09:27:01.997956
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # Setup
    ciphertext = b"089"
    vault = VaultLib('AnsibleVaultEncryptedUnicode__lt__', 1)
    ciphertext = vault.encrypt(ciphertext, vault.secrets)
    plaintext = vault.decrypt(ciphertext, obj=None)
    plaintext = AnsibleVaultEncryptedUnicode(plaintext)
    plaintext.vault = vault
    plaintext_data = plaintext.data
    plaintext_data = ' ' + plaintext_data
    plaintext = plaintext_data
    compare_result = plaintext < ciphertext

    # Exercise
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    avu_data = avu.data
    avu_data = ' ' + avu

# Generated at 2022-06-11 09:27:03.166924
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    pass


# Generated at 2022-06-11 09:27:05.043193
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    assert AnsibleVaultEncryptedUnicode('1') < AnsibleVaultEncryptedUnicode('2')



# Generated at 2022-06-11 09:27:21.098672
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Check equality of two same object
    encrypted = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;user\n63313237373032363366373235633031346464623735393934316436363335643631353464333135\n65303864373930323331663263653932353235316331643635643738396434\n') # noqa
    result = (encrypted != encrypted)
    assert result == False

    # Check with an object of different type

# Generated at 2022-06-11 09:27:25.549734
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode(b'ciphertxt')
    avu.vault = None

    assert (avu != 'plaintext') is True


# Generated at 2022-06-11 09:27:29.954830
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode.__ne__(b'abc', 'abc')
    assert AnsibleVaultEncryptedUnicode.__ne__(b'abc', u'abc')
    assert AnsibleVaultEncryptedUnicode.__ne__(u'abc', 'abc')


# Generated at 2022-06-11 09:27:43.406323
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Create a temporary YAML file to read
    import tempfile
    import shutil

    dirname = tempfile.mkdtemp()
    filename = dirname + '/test.yaml'
    with open(filename, 'w') as f:
        f.write('foo: !vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  30386237616535363062363763366138386466653064333663646634376232313864386165363033\n  616237376432666134303363396163623166323038376362370a')

    # Create a temporary vault file
    vault_dirname = tempfile.mkdtemp()
    vault_filename = vault_dirname + '/vault_fukushima.yaml'


# Generated at 2022-06-11 09:27:48.585956
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    a = AnsibleVaultEncryptedUnicode('foo')
    # This is the same implementation as the __ne__
    # method of AnsibleUnicode
    if a != text_type(a):
        raise AssertionError('AnsibleVaultEncryptedUnicode.__ne__() failed')



# Generated at 2022-06-11 09:27:56.715069
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import \
        VAULT_VERSION_1, VAULT_VERSION_2, VAULT_VERSION_3
    import pytest

    vault_password = b'password'
    vault_password_new = b'password_new'

    basic_plaintext = (
        b'The quick brown fox jumps over the lazy dog\n'
        b'The quick brown fox jumps over the lazy dog\n'
        b'The quick brown fox jumps over the lazy dog\n'
        b'The quick brown fox jumps over the lazy dog\n'
        b'The quick brown fox jumps over the lazy dog\n'
    )


# Generated at 2022-06-11 09:28:07.451861
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    c = 'gAAAAABaSwN2QDhZ4zJj6Rm-Lzvi62G1--yS0m0mXdo3qmfLsjGpWp7-n_P3qw_kw2llxCnV8T9RnFgJ7IkHnjFZ1g2tNHwYtEg=='
    b = AnsibleVaultEncryptedUnicode(c)
    assert b != 'foo'
    assert b != ['f', 'o', 'o']
    assert b != dict(a=1)



# Generated at 2022-06-11 09:28:17.493283
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:28:29.788662
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.errors import AnsibleError

    data = 'test_value'
    secret = 'secret'

# Generated at 2022-06-11 09:28:35.609452
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    try:
        # PY2
        from StringIO import StringIO
    except ImportError:
        # PY3
        from io import StringIO

    from ansible.parsing.vault import VaultLib  # pip install ansible
    from ansible.module_utils.yaml import AnsibleVaultEncryptedUnicode

    # create a vault
    vault = VaultLib(password='test')
    # read a test file
    with open('__FILE__.yml') as f:
        data = f.read()

    # read the test file and replace all the texts
    # with encrypted bytes
    ciphertext = vault.encrypt_bytes(data, encoding='utf-8')
    # create a file-like object
    sio = StringIO(ciphertext)

    # load the decrypted bytes
    plaintext, __

# Generated at 2022-06-11 09:28:47.097511
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ac = AnsibleVaultEncryptedUnicode.from_plaintext
    assert(ac('abc', None, None) == 'abc')
    assert(ac('abc', None, None) == ac('abc', None, None))
    assert(ac('abc', None, None) != ac('def', None, None))



# Generated at 2022-06-11 09:28:58.901471
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import binascii

    # Create a simple ciphertext string
    plaintext = b'hello world'
    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256\n' + binascii.b2a_base64(plaintext)[:-1]
    avu = AnsibleVaultEncryptedUnicode(ciphertext)

    assert avu.is_encrypted()

    # Create a simple ciphertext string
    plaintext = b'hello world'
    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256\n' + binascii.b2a_base64(plaintext)[:-1]
    avu = AnsibleVaultEncryptedUnicode(ciphertext)

    assert avu.is_encrypted()

    # Create a valid header string
    header

# Generated at 2022-06-11 09:29:09.633301
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # This is a bit of a hack, but we have to have a way to test
    # implementation details without burdening the user
    from ansible.parsing import vault
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    plaintext = 'Hello World!'
    secret = '1234567890'
    password = 'password'

# Generated at 2022-06-11 09:29:23.724940
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    try:
        from ansible.utils.vault import VaultLib
    except ImportError:
        raise AssertionError('Failed to import VaultLib')

    import base64
    from ansible.parsing.yaml.loader import AnsibleLoader
    example_value = 'example_value'
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(example_value, vault, secret='test')
    ciphertext = avu.encode()
    print('Encrypted value: %s' % (ciphertext))

    # ansible_loader.get_single_data should preserve the AnsibleVaultEncryptedUnicode object
    ansible_loader = AnsibleLoader(data=ciphertext, vault_password='test')

# Generated at 2022-06-11 09:29:30.344062
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # AnsibleVaultEncryptedUnicode != AnsibleVaultEncryptedUnicode
    seq = u'test'
    secret = b'test_secret'
    vault = vaultlib.VaultLib(secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    avu_ = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu != avu_

    # AnsibleVaultEncryptedUnicode != AnsibleUnicode
    seq = u'test'
    secret = b'test_secret'
    vault = vaultlib.VaultLib(secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu != seq

    #

# Generated at 2022-06-11 09:29:42.053691
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Assume (unencrypted) plaintext
    msg = "Hello Vaulted World"
    b_msg = to_bytes(msg)
    avu = AnsibleVaultEncryptedUnicode(b_msg)
    assert(not avu.is_encrypted())

    # Assume (encrypted) ciphertext
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    secret = VaultSecret(b'1234')
    vault = VaultLib(secret)

    ciphertext = vault.encrypt(b_msg, secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(b_msg, vault, secret)
    assert(avu.is_encrypted())

    # Assume (unencrypted) plaintext
    plaintext = vault.decrypt

# Generated at 2022-06-11 09:29:53.310665
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    if sys.version_info.major >= 3:
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock

    vault = MagicMock()
    secret = 'some secret'

# Generated at 2022-06-11 09:30:05.531956
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
    #
    #     def __ne__(self, other):
    #         if self.vault:
    #             return other != self.data
    #         return True
    #
    # test case 1:
    #   if self.vault, return other != self.data
    ansible_vault_encrypted_unicode_instance = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    ansible_vault_encrypted_unicode_instance.vault = None
    result = ansible_vault_encrypted_unicode_instance.__ne__('$ANSIBLE_VAULT;1.1;AES256')

# Generated at 2022-06-11 09:30:14.467134
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib as vaultlib
    vault = vaultlib(b'$ANSIBLE_VAULT;1.1;AES256')

    # As this was originally a subclass of 'unicode' we are testing str method equivalence
    # The '__ne__' on 'unicode' is basically identical to the '!==' C-operator on strings.
    # That is basically identical to 'str.__ne__'

    # As we are basically testing a string method, we don't need to test Python 2.
    # It is not unicode specific and the same applies to
    #   Python 3.5.1 (default, Dec  7 2015, 12:58:09)
    #   [GCC 5.2.1 20151010] on linux

    # we are basically testing a string method, we don't need to

# Generated at 2022-06-11 09:30:25.380058
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault=object(), secret='test')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault=object(), secret='test2')
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault=object(), secret='test')
    avu4 = AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault=object(), secret='test')

# Generated at 2022-06-11 09:30:38.141924
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # assert 'abc' == AnsibleVaultEncryptedUnicode('abc')
    assert not ('abc' == AnsibleVaultEncryptedUnicode('xyz'))
    assert AnsibleVaultEncryptedUnicode('abc') != 'xyz'
    assert not (AnsibleVaultEncryptedUnicode('abc') != 'abc')


# Generated at 2022-06-11 09:30:41.193479
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert hasattr(AnsibleVaultEncryptedUnicode, '__ne__') and callable(getattr(AnsibleVaultEncryptedUnicode, '__ne__'))



# Generated at 2022-06-11 09:30:53.310383
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import sys

    if sys.version_info[0] < 3: # 'str' does not exist in Python 3
        from collections import MutableSequence
        class MyVault(MutableSequence):
            def __init__(self):
                self.data = []

            def __len__(self):
                return len(self.data)

            def __getitem__(self, index):
                return self.data[index]

            def __delitem__(self, index):
                del self.data[index]

            def __setitem__(self, index, value):
                self.data[index] = value

            def insert(self, index, value):
                self.data.insert(index, value)

            def decrypt(self, text):
                return text

            def is_encrypted(self, text):
                return False

# Generated at 2022-06-11 09:30:58.836195
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib, VaultEditor
    vault = VaultLib('password')
    vault_editor = VaultEditor(vault)
    secret = 'foo'
    plaintext = u'secret string'
    ciphertext = vault_editor.encrypt(plaintext)
    vault_encrypted_string = AnsibleVaultEncryptedUnicode(ciphertext)
    vault_encrypted_string.vault = vault
    assert vault_encrypted_string != u'secret string'
    assert vault_encrypted_string.is_encrypted()


# Generated at 2022-06-11 09:31:10.414219
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    """
    Test that `AnsibleVaultEncryptedUnicode.__eq__` returns the correct value
    """
    from ansible_vault import VaultLib
    seq1 = "test1"
    seq2 = "test2"
    # create vault objects
    vault = VaultLib("ansible")
    secret = "vaultsecret"
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(seq1, vault, secret)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(seq2, vault, secret)
    # test that avu's are equal to their original byte sequence
    assert avu1 == seq1
    assert avu2 == seq2
    # test that avu's are not equal to other byte sequences
    assert avu1 != seq2

# Generated at 2022-06-11 09:31:18.173882
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secret = VaultSecret('pass')
    vault = VaultLib(vault_secret)

    # Test with a string (type str)
    ciphertext = vault.encrypt('abcd', vault_secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()
    assert avu != 'abcd'
    assert avu == 'abcd'

    # Test with a string (type AnsibleVaultEncryptedUnicode)
    ciphertext = vault.encrypt('abcd', vault_secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault


# Generated at 2022-06-11 09:31:23.839401
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    secret = "My Secret Password"
    vault = vaultlib.VaultLib(["--vault-password-file", "/dev/null"])

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(secret, vault, secret)
    assert avu.is_encrypted()


# Generated at 2022-06-11 09:31:33.139591
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    secret = b'$ecretpas5w0rd'
    content = b'unsafe'
    safe = AnsibleVaultEncryptedUnicode.from_plaintext(content, vault=None, secret=None)
    crypt = AnsibleVaultEncryptedUnicode.from_plaintext(content, vault=None, secret=secret)

    assert not extra_vars.__eq__(secret)
    assert safe.__eq__(content)
    assert not safe.__eq__(secret)
    assert crypt.__eq__(content)
    assert not crypt.__eq__(safe)



# Generated at 2022-06-11 09:31:41.666990
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    passwd = 'test'
    vault = VaultLib(passwd)
    input = 'this is a test string'
    avu = AnsibleVaultEncryptedUnicode(vault.encrypt(input, passwd))
    assert avu.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode('string').is_encrypted()
    assert not AnsibleVaultEncryptedUnicode(b'\xde\xad\xbe\xef').is_encrypted()


_CONSTRUCTOR_CACHE = {}

try:
    from __main__ import display
except ImportError:
    from ansible.utils.display import Display
    display = Display()


# Generated at 2022-06-11 09:31:45.317197
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    my_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode("test")
    assert my_vault_encrypted_unicode != 'test'
    assert my_vault_encrypted_unicode.__ne__('test')


# Generated at 2022-06-11 09:31:59.681902
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:32:08.836448
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([], 'password1234')
    seq = u'foo bar\n'
    secret = u'password1234'
    assert AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret).is_encrypted() is True
    assert AnsibleVaultEncryptedUnicode.from_plaintext(u'', vault, secret).is_encrypted() is True
    assert AnsibleVaultEncryptedUnicode.from_plaintext(u'', vault, secret).is_encrypted() is True
    assert AnsibleVaultEncryptedUnicode.from_plaintext(u'\n', vault, secret).is_encrypted() is True

# Generated at 2022-06-11 09:32:15.971458
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    plaintext = '123'
    vault = vaultlib.VaultLib('test')
    secret = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    avu1 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu1.vault = vault
    avu2 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu2.vault = vault
    assert avu1 == plaintext
    assert avu2 == avu1
    assert avu1 != 'abcd'


# Generated at 2022-06-11 09:32:26.289399
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Setup the plaintext that we'll encrypt
    plaintext = u'This is plaintext'

    # Setup the secrets
    secret = u'b00t1337'

# Generated at 2022-06-11 09:32:32.578075
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # is_encrypted without being encrypted
    avu = AnsibleVaultEncryptedUnicode(b"foo bar")
    assert avu.is_encrypted() == False

    # is_encrypted after encrypting and passing a secret
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('AES256')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(b"foo bar", vault, b'password')
    assert avu.is_encrypted() == True

# Generated at 2022-06-11 09:32:42.478020
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('secret',
                                                       ansible.parsing.vault.VaultLib('ansible'),
                                                       b'secret')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('secret',
                                                       ansible.parsing.vault.VaultLib('ansible'),
                                                       b'secret')
    assert(avu1.__eq__(avu2))
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext('not secret',
                                                       ansible.parsing.vault.VaultLib('ansible'),
                                                       b'not secret')

# Generated at 2022-06-11 09:32:50.360090
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test equality when vault is not initialized
    avu1 = AnsibleVaultEncryptedUnicode("foo")
    avu2 = AnsibleVaultEncryptedUnicode("foo")
    assert avu1 != avu2
    # Test equality when vault is initialized
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    secret = VaultSecret('vaultpassword')
    vault = VaultLib(secret)
    avu1.vault = vault
    avu2.vault = vault
    assert avu1 == avu2

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 09:32:52.556393
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    v = AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None)
    assert v == 'foo'
    assert v != 'bar'
    assert v != 'f'
    assert v != 'foobar'

# Generated at 2022-06-11 09:32:58.292701
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault as vault
    v = vault.VaultLib('test')
    secret = 'secret'
    seq = 'text'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, v, secret)
    assert avu.is_encrypted() == True


# Generated at 2022-06-11 09:33:06.351352
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    seq = "test"
    vault_class = None
    klass = AnsibleVaultEncryptedUnicode
    secret = None

    try:
        # This is the method we are testing
        avu = klass.from_plaintext(seq, vault_class, secret)
    except:
        pass
    else:
        # This is the method we are testing
        assert klass.__ne__(avu, seq)



# Generated at 2022-06-11 09:33:34.109139
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''
    Test method __ne__ of class AnsibleVaultEncryptedUnicode
    '''
    from ansible.parsing.vault import VaultLib

    password = "A secret string to encrypt"
    plaintext = "A plain text string"
    euv = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, VaultLib(password), password)
    result = euv.data
    assert result == plaintext
    assert (euv != 'A plain text string')
    assert (euv != AnsibleVaultEncryptedUnicode.from_plaintext('A plain text string', VaultLib(password), password))
    assert (euv == 'A plain text string') == False
    assert (euv != 'A plain text string') == True

# Generated at 2022-06-11 09:33:44.143028
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    from ansible.parsing import vault

    # Create vault
    vaultfile = open('vault.test.yml', 'w')
    vaultfile.write('$ANSIBLE_VAULT;1.1;AES256\n')
    vaultfile.write('633266313234663465616662373937623230313139643233623935653033643635376265383130\n')
    vaultfile.write('323937643231643862623331663234386530653535613333316666383266343036636631313066\n')
    vaultfile.write('396133656564636430653133\n')
    vaultfile.close()

    # Load vault
    vault_pass = open('vault.pass.test.yml', 'w')
   

# Generated at 2022-06-11 09:33:49.807836
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Note: The vault below is just a dummy vault without a password that always succeeds
    class DummyVault(object):
        type = 'dummy_vault'

        def __init__(self):
            pass

        def encrypt(self, data, secret):
            return data

        def encrypt_bytes(self, data, secret):
            return data

        def encrypt_text(self, data, secret):
            return data

        def decrypt(self, data, secret, obj=None):
            return data

        def decrypt_bytes(self, data, secret):
            return data

        def decrypt_text(self, data, secret):
            return data

        def is_encrypted(self, data):
            return True

    plaintext = "Here is some plaintext to encrypt"

    # Test with a dummy vault, see above
    dummy_vault

# Generated at 2022-06-11 09:33:59.798196
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(None)

    # __ne__ should return False if we're comparing an AnsibleVaultEncryptedUnicode to itself
    plain_text_string = "This is a plain text string"
    plain_text_avu = AnsibleVaultEncryptedUnicode.from_plaintext(plain_text_string, vault, 'secret')
    plain_text_avu.vault = vault
    assert plain_text_avu.__ne__(plain_text_avu) == False

    # __ne__ should return True if we're comparing an AnsibleVaultEncryptedUnicode to a plain text string
    assert plain_text_avu.__ne__(plain_text_string) == True

    # __ne__ should return True if we're comparing two

# Generated at 2022-06-11 09:34:09.536163
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:34:17.801460
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible_test
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(password='ansible')

    # Test encrypted string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'secret')
    assert(avu.is_encrypted())

    # Test unencrypted string
    avu = AnsibleVaultEncryptedUnicode(avu.data)
    assert(not avu.is_encrypted())


'''
This function returns a yaml loader object.  It is intended to
be used by modules and the template lookup plugin to load and parse
yaml data.
'''

# Generated at 2022-06-11 09:34:21.909364
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode(b"dGVzdA==\n") != "test"


# ----------------------------------------------------------------------------------------------------------------------
# common code for _get_scalar_type, _get_data_impl and _get_representer_impl
# ----------------------------------------------------------------------------------------------------------------------

# Generated at 2022-06-11 09:34:27.380891
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    v = AnsibleVaultEncryptedUnicode.from_plaintext('secret', vault=None, secret='vaultpassword')
    assert(v == 'secret')
    assert(v != 'random')
    v = AnsibleVaultEncryptedUnicode.from_plaintext(None, vault=None, secret=None)
    assert(v != 'secret')
    assert(v != 'random')



# Generated at 2022-06-11 09:34:35.061432
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault
    assert AnsibleVaultEncryptedUnicode.from_plaintext('hello',
                                                       ansible.parsing.vault.VaultLib({'password': 'secret'}),
                                                       'secret') == 'hello'
    assert AnsibleVaultEncryptedUnicode.from_plaintext('hello',
                                                       ansible.parsing.vault.VaultLib({'password': 'secret'}),
                                                       'secret') != 'world'


# Generated at 2022-06-11 09:34:39.852771
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # load this so the vaultyamlconstructor can register the vault type
    from ansible.parsing.vault import VaultLib

    test = AnsibleVaultEncryptedUnicode.from_plaintext('foo', VaultLib(VaultLib.new()), 'secret')
    assert test.is_encrypted()

    test = AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, 'secret')
    assert not test.is_encrypted()

    test = AnsibleVaultEncryptedUnicode('foo')
    assert not test.is_encrypted()



# Generated at 2022-06-11 09:35:18.898014
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    plaintext = "abc"
    vault = VaultLib('test')
    secret = 'secret'
    to_compare = "abc"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avu != to_compare

    to_compare = "xyz"
    assert avu != to_compare


# Generated at 2022-06-11 09:35:25.785433
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    class FakeVault:
        '''A Vault for testing the AnsibleVaultEncryptedUnicode

        The .decrypt() method is overriden with a test method
        to eliminate needing to provide real secrets to the
        AnsibleVaultEncryptedUnicode
        '''
        def decrypt(self, ciphertext, obj=None):
            '''Decrypts the passed in ciphertext'''
            return to_text(ciphertext, errors='surrogate_or_strict')

    def assert_equals(expected, actual, msg=None):
        '''A wrapper around assertEquals in Python 2.6'''
        if _sys.version_info < (2, 7, 0):
            _sys.modules['unittest'].TestCase.assertEquals(expected, actual, msg)
        else:
            _sys

# Generated at 2022-06-11 09:35:34.584966
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib

    # $ANSIBLE_VAULT;1.1;AES256
    # 34313236333162376237356431633836623566316635643166623235373933643966646336323665
    # 37633337303237316238626164316465663531633964363839643431666564386261386137313663
    # 383239616332613766346131386633646138393730