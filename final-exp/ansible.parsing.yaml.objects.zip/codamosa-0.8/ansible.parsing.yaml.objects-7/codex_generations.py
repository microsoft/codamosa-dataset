

# Generated at 2022-06-11 09:25:53.762304
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Test #1 - 'avu' is a AnsibleVaultEncryptedUnicode object, 'other' is a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode('abc')
    avu.vault = True
    other = AnsibleVaultEncryptedUnicode('aaa')
    other.vault = True
    assert avu.__gt__(other)

    # Test #2 - 'avu' is a AnsibleVaultEncryptedUnicode object, 'other' is a text_type object
    avu = AnsibleVaultEncryptedUnicode('abc')
    avu.vault = True
    other = 'aaa'
    assert avu.__gt__(other)



# Generated at 2022-06-11 09:26:00.307361
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    vault_secret = VaultSecret('my_vault_password')
    vault = VaultLib(vault_secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('Hello World', vault, vault_secret)
    assert(avu.__ne__('Hello World')) == True


# Generated at 2022-06-11 09:26:09.469085
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
  msg = 'This is a secret message'
  avu = AnsibleVaultEncryptedUnicode.from_plaintext(msg, vault, secret)
  if avu > 'This is a secret message':
    pass
  if avu > AnsibleVaultEncryptedUnicode.from_plaintext('This is a secret message', vault, secret):
    pass
  if avu > 'This is a secret':
    raise Exception("FAIL: AnsibleVaultEncryptedUnicode __gt__ did not raise expected exception")


# Generated at 2022-06-11 09:26:17.605170
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    from ansible.parsing.vault import VaultLib
    vault_pw = "ansible"
    with open("tests/vault_test_data.yml", "rb") as f:
        test_data = f.read()
    x = AnsibleVaultEncryptedUnicode.from_plaintext(to_bytes(test_data), vault=VaultLib(password=vault_pw), secret=vault_pw)
    y = AnsibleVaultEncryptedUnicode._ciphertext = x._ciphertext

    assert (y > x) == (y.data > x.data)



# Generated at 2022-06-11 09:26:31.632386
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    class FakeVault(object):
        def decrypt(self, text, obj=None):
            return text
        def is_encrypted(self, text):
            return text.strip().startswith('$ANSIBLE_VAULT')

    # Create a FakeVault object and a AnsibleVaultEncryptedUnicode object
    vault = FakeVault()

# Generated at 2022-06-11 09:26:43.259524
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:26:46.910936
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    my_vault = vault.VaultLib('secret')
    my_vault_string = AnsibleVaultEncryptedUnicode.from_plaintext(u'b', my_vault, 'secret')
    assert my_vault_string > u'a'


# Generated at 2022-06-11 09:26:50.136892
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    text = 'abc'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(text, vault, secret)
    decode(avu)
    assert(not avu > 'abc')
    assert(avu > 'ab')
    assert(not avu > 'abcd')


# Generated at 2022-06-11 09:27:01.812544
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    '''AnsibleVaultEncryptedUnicode.rfind()'''
    # empty search, not found
    avu = AnsibleVaultEncryptedUnicode('abc')
    search = to_bytes('')
    # default start and end
    assert avu.rfind(search) == -1
    # find at start
    assert avu.rfind(search, 0, 3) == -1
    # find in middle
    assert avu.rfind(search, 1, 3) == -1

    # non-empty search, not found
    search = to_bytes('defgh')
    # find at start
    assert avu.rfind(search, 0, 3) == -1
    # find in middle
    assert avu.rfind(search, 1, 3) == -1

    # non-empty search

# Generated at 2022-06-11 09:27:03.004686
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    pass


# Generated at 2022-06-11 09:27:22.137932
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    Make sure that AnsibleVaultEncryptedUnicode.__ne__ works with the string types
    """
    body_contents = [
        "data: '{{ lookup('file', 'some_vault_encrypted_file') }}'",
        "data: {{ lookup('file', 'some_vault_encrypted_file') }}",
        "data: {{ '{{ lookup('file', 'some_vault_encrypted_file') }}' }}",
    ]
    for body_content in body_contents:
        assert AnsibleVaultEncryptedUnicode(body_content) != body_content


# Generated at 2022-06-11 09:27:29.280042
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu_1 = AnsibleVaultEncryptedUnicode.from_plaintext('my secret', None, None)
    result = avu_1 != 'my secret'
    assert False == result

    avu_2 = AnsibleVaultEncryptedUnicode.from_plaintext('your secret', None, None)
    result = avu_1 != avu_2
    assert True == result


# Generated at 2022-06-11 09:27:32.604521
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    secret = "mypassword"
    password = "thisisnotmypassword"
    expected = False
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("thisisnotmypassword", vault=None, secret=secret)
    actual = avu.__ne__(password)
    assert actual == expected


# Generated at 2022-06-11 09:27:39.220656
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    avu = AnsibleVaultEncryptedUnicode(b'foo')
    assert avu.find(AnsibleVaultEncryptedUnicode(b'f')) == 0
    assert avu.find(b'f') == 0
    # This fails with vault, I cannot explain why
    assert avu.find(b'o') == 1


# Generated at 2022-06-11 09:27:50.677033
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    plain_text_0 = u"my_password"

    secret_0 = VaultSecret('my_password', None, None)
    secret_1 = VaultSecret('my_password', None, None)

    vault_0 = VaultLib(secret_0)
    cipher_text_0 = vault_0.encrypt(plain_text_0)
    cipher_text_1 = vault_0.encrypt(plain_text_0)

    assert cipher_text_0 == cipher_text_1


# Generated at 2022-06-11 09:27:59.089425
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    passwd = b'$1$tEFzTt2L$LOoBPC8dvfOUjjZ1h4l4i.'

    vault = vaultlib.VaultLib(passwd)

    plain = u'foo'
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(plain, vault, passwd)

    assert encrypted.find(encrypted) == 0
    assert encrypted.find(plain) == 0
    assert encrypted.find(encrypted.data) == 0
    assert encrypted.find(plain.data) == 0



# Generated at 2022-06-11 09:28:12.085502
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import unittest
    import os
    import tempfile
    import sys
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    from ansible.module_utils.hashivault import vaultlib

    class TestAnsibleVaultEncryptedUnicode___eq__(unittest.TestCase):
        def test_vault_key_missing(self):
            kwargs = {'vault_password_file': None, 'ask_vault_pass': False}
            vault = vaultlib.VaultLib(**kwargs)

            # Check that we return False if the vault isn't initialized.
            plaintext = 'plaintext'
            ciphertext = vault.encrypt(plaintext)
            avueu = AnsibleVaultEncrypted

# Generated at 2022-06-11 09:28:18.838444
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    class AnsibleVault:
        def is_encrypted(self, ciphertext):
            return False
        def encrypt(self, seq, secret):
            return b'ciphertext'
        def decrypt(self, ciphertext, obj=None):
            return b'plaintext'

    av = AnsibleVaultEncryptedUnicode.from_plaintext(b'plaintext', AnsibleVault(), secret=b'secret')
    assert av == 'plaintext'
    assert av != 'another plaintext'
    assert av != AnsibleUnicode('another plaintext')
    assert av != AnsibleVaultEncryptedUnicode('ciphertext')


# Generated at 2022-06-11 09:28:27.885047
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test for method AnsibleVaultEncryptedUnicode._ne__(self, ) (Unicode-specific method)
    # Test that _ne__ is properly called when the __ne__ of plaintext is invoked.
    # this test is only needed to ensure we don't raise NotImplemented
    avue = AnsibleVaultEncryptedUnicode('the cat jumped over the dog')
    assert(avue != 'the cat jumped over the cow')
    assert(avue != b'the cat jumped over the cow')



# Generated at 2022-06-11 09:28:39.395420
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    unencrypted = AnsibleVaultEncryptedUnicode("This is the plaintext")
    assert not unencrypted.is_encrypted()

    from ansible.parsing.vault import VaultLib
    from tempfile import NamedTemporaryFile
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    vault_password_file = NamedTemporaryFile()
    vault_password_file.write(b'vault_password_file_password')
    vault_password_file.flush()

    vault_secret = VaultSecret('vault_password_file=%s' % vault_password_file.name)
    vault = VaultLib([vault_secret])

    ciphertext = vault.encrypt(unencrypted.data, vault_password_file.name)

# Generated at 2022-06-11 09:28:53.823367
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    # encrypted

# Generated at 2022-06-11 09:29:03.994941
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    fake_vault = VaultLib('Z')

    unencrypted_string = AnsibleVaultEncryptedUnicode('not encrypted')
    unencrypted_string.vault = fake_vault

    assert(False == unencrypted_string.is_encrypted())
    unencrypted_string.data = 'this should be encrypted'
    assert(False == unencrypted_string.is_encrypted())

    encrypted_string = AnsibleVaultEncryptedUnicode(fake_vault.encrypt('this is encrypted'))
    assert(True == encrypted_string.is_encrypted())
    encrypted_string.data = 'this should be encrypted'
    assert(True == encrypted_string.is_encrypted())



# Generated at 2022-06-11 09:29:09.377459
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    seq = 'lorem ipsum'
    vault = VaultLib(password='test', salt='test', iterations=1000)
    secret = 'test'
    encrypted_seq = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert encrypted_seq == seq
    assert encrypted_seq != 'test'
    assert encrypted_seq != seq + 'test'


# Generated at 2022-06-11 09:29:19.652038
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    '''test_AnsibleVaultEncryptedUnicode___eq__()'''
    iv = AnsibleVaultEncryptedUnicode('123456')
    assert iv == '123456'
    # for a mathcing string, data is not decrypted
    assert iv._ciphertext == '123456'
    iv = AnsibleVaultEncryptedUnicode('123456')
    assert iv == '12345'
    # for a non-mathcing string, data is not decrypted
    assert iv._ciphertext == '123456'



# Generated at 2022-06-11 09:29:27.628010
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''
    Test case for method __ne__ of class AnsibleVaultEncryptedUnicode.
    Test case for case, when encrypted values are compared.
    '''
    # Test case for non encrypted values.
    assert AnsibleVaultEncryptedUnicode("") != ""
    # Test case for encrypted values
    a1 = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;9.9;AES256;test")
    a2 = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;9.9;AES256;test")
    assert a1 != a2


# Generated at 2022-06-11 09:29:33.956542
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    a = AnsibleVaultEncryptedUnicode('encrypted text')
    assert a == 'encrypted text'
    assert a == AnsibleVaultEncryptedUnicode('encrypted text')
    assert not a == 'plain text'
    assert not a == AnsibleVaultEncryptedUnicode('plain text')


# Generated at 2022-06-11 09:29:42.588181
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Create an object of class AnsibleVaultEncryptedUnicode
    avueu = AnsibleVaultEncryptedUnicode()
    avueu.data = "something"

    # Test whether the first argument is an AnsibleVaultEncryptedUnicode object
    # Expecting False if the given argument is not an AnsibleVaultEncryptedUnicode object
    assert_equal(avueu != "something else", True)

    # Test whether the first argument is an AnsibleVaultEncryptedUnicode object
    # Expecting True if and only if the two objects have the same content
    assert_equal(avueu != "something", False)


# Generated at 2022-06-11 09:29:54.746989
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.constants as C
    from ansible.parsing.vault import VaultLib
    import pytest
    vault = VaultLib(password='hunter', salt_size=C.DEFAULT_VAULT_SALT_SIZE)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'hello')
    # When vault contains data
    assert avu == 'foo'
    assert avu == b'foo'
    assert not (avu == 'bar')
    assert not (avu == b'bar')
    with pytest.raises(TypeError):
        avu == 1234 # Different type
    # When vault does not contain data
    avu.vault = None
    assert not (avu == 'foo')
    assert not (avu == b'foo')

#

# Generated at 2022-06-11 09:30:06.175156
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible import vault
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.dumper import AnsibleDumper

    secret_one = VaultSecret('my_vault_password_one', 'my_new_vault_password_one')
    secret_two = VaultSecret('my_vault_password_two', 'my_new_vault_password_two')

    v = vault.VaultLib(**secret_one.unlock())

    # encrypted text in unicode
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test_AnsibleVaultEncryptedUnicode_is_encrypted', v, secret_one)
    assert avu.is_encrypted()

    # encrypted text in str
    avu = AnsibleVaultEncryptedUn

# Generated at 2022-06-11 09:30:14.899805
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError

# Generated at 2022-06-11 09:30:30.838960
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import AnsibleVaultError

    plaintext = b"The quick brown fox"
    password = "ansible"
    secret = VaultSecret(password)
    vault = VaultLib(password)


    def check(expected, message, obj):
        got = obj.is_encrypted()
        if expected:
            assert got, "%s Expected is_encrypted() to return True" % message
        else:
            assert not got, "%s Expected is_encrypted() to return False" % message
        return

    assert vault, "Error creating vault"

    # make sure we can only decrypt the ciphertext
    ciphertext = vault.encrypt(plaintext, secret)
    avu

# Generated at 2022-06-11 09:30:40.296235
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault as vault

    # Test is_encrypted() with a valid encrypted string
    # =================================================
    # Test with a valid vault encrypted string (without vault-id)

# Generated at 2022-06-11 09:30:42.876772
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
	s = AnsibleVaultEncryptedUnicode()
	s.data = "T"
	return s.__ne__("R")

# Generated at 2022-06-11 09:30:47.415692
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n567890\n')
    avu.vault=MockVault()

    assert avu != '1234'


# Generated at 2022-06-11 09:30:53.048511
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    v = VaultLib('dummy')
    a = AnsibleVaultEncryptedUnicode.from_plaintext('bar', v, 'baz')
    assert a == 'bar'
    assert a != 'baz'

# add the new classes to the yaml classes

# Generated at 2022-06-11 09:31:00.073360
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Tests for equality when eq of unencrypted data is True
    assert AnsibleVaultEncryptedUnicode.from_plaintext('hi', None, 'secret') == AnsibleVaultEncryptedUnicode.from_plaintext('hi', None, 'secret')
    assert AnsibleVaultEncryptedUnicode.from_plaintext('hi', None, 'secret') == 'hi'
    assert AnsibleVaultEncryptedUnicode.from_plaintext('hi', None, 'secret') == AnsibleUnicode('hi')

    # Tests for equality when eq of unencrypted data is False
    assert not (AnsibleVaultEncryptedUnicode.from_plaintext('hi', None, 'secret') == AnsibleVaultEncryptedUnicode.from_plaintext('bye', None, 'secret'))

# Generated at 2022-06-11 09:31:11.471225
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Create fake vault
    class FakeVault(object):
        def encrypt(self, text, password):
            return text

        def decrypt(self, text, password):
            return text

    class FakeVaultLib(object):
        def __init__(self):
            self.vault_password = 'hunter2'

        def is_encrypted(self, text):
            return True

        def load(self, filename, password=None):
            return FakeVault(self)

    # Create objects to compare
    vault = FakeVaultLib()
    aveu1 = AnsibleVaultEncryptedUnicode.from_plaintext('hunter2', vault, vault.vault_password)
    aveu2 = AnsibleVaultEncryptedUnicode.from_plaintext('hunter2', vault, vault.vault_password)
   

# Generated at 2022-06-11 09:31:21.463345
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # First 128 ASCII characters
    # (as of PEP 393 strings are code points, not bytes)
    input_str = "".join(chr(i) for i in range(128))
    assert input_str == bytes(i for i in range(128)).decode("ascii")
    ciphertext = to_bytes("vault(ASYMX2NvbXBhc3Npb24ta2V5)", errors='surrogate_or_strict')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu != input_str


# Generated at 2022-06-11 09:31:33.648537
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-11 09:31:43.825407
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault_file = 'tests/test_vault.yml'
    vault_pass = get_file_vault_secret(vault_file)
    vault = VaultLib([vault_pass])
    s = 'Hello World!'
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(s, vault, vault_pass)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(s, vault, vault_pass)

# Generated at 2022-06-11 09:31:54.481735
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test when AnsibleVaultEncryptedUnicode is initialized with
    # valid parameters
    ciphertext = 'fkdgfkdfjg'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert not avu.__eq__(None)

    # Test when AnsibleVaultEncryptedUnicode is initialized with
    # invalid parameters
    avu = AnsibleVaultEncryptedUnicode(None)
    assert not avu.__eq__(None)



# Generated at 2022-06-11 09:31:56.197368
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode(b'asdf')
    assert avu != 'test'
    assert avu != 'asdf'


# Generated at 2022-06-11 09:31:58.193160
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_enc_unicode = AnsibleVaultEncryptedUnicode()

    # success case
    assert ansible_vault_enc_unicode.__eq__('') == False


# Generated at 2022-06-11 09:32:01.231137
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib

    vault_sectret = VaultLib(password='password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('myplaintext', vault_sectret, 'password')

    assert avu != 'myplaintext'
    assert not (avu != 'myplaintext')

# Generated at 2022-06-11 09:32:10.731407
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:32:21.380549
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:32:30.019395
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    v = vaultlib.VaultLib("test")

    class MyVault(vaultlib.VaultLib):
        def __init__(self, *args, **kwargs):
            super(MyVault, self).__init__(*args, **kwargs)
            self.__decrypted = False

        def decrypt(self, *args, **kwargs):
            self.__decrypted = True
            return super(MyVault, self).decrypt(*args, **kwargs)

        @property
        def decrypted(self):
            return self.__decrypted

    # Both strings are of same value
    # ------------------------------
    avu = AnsibleVaultEncryptedUnicode("something")
    assert(not avu.is_encrypted())
    assert("something" == avu)
    assert("different" != avu)



# Generated at 2022-06-11 09:32:33.576035
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    s = AnsibleVaultEncryptedUnicode.from_plaintext('secret', vault, 'password')
    assert s.is_encrypted()



# Generated at 2022-06-11 09:32:36.866677
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    obj = AnsibleVaultEncryptedUnicode('')
    assert obj.__ne__('') == True
    obj.data = 'Test string'
    assert obj.__ne__('Test string') == False


# Generated at 2022-06-11 09:32:45.507814
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert(AnsibleUnicode("") != AnsibleVaultEncryptedUnicode(""))
    assert(AnsibleUnicode("1") != AnsibleVaultEncryptedUnicode("1"))
    assert(AnsibleVaultEncryptedUnicode("1") != AnsibleUnicode("2"))
    # FIXME: the below line asserts
    # assert(AnsibleVaultEncryptedUnicode("") != AnsibleUnicode(""))
    # assert(AnsibleVaultEncryptedUnicode("1") != AnsibleUnicode("2"))
    # assert(AnsibleUnicode("1") != AnsibleVaultEncryptedUnicode("2"))


# Generated at 2022-06-11 09:33:05.607157
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Create an instance of AnsibleVaultEncryptedUnicode without
    # passing a vault reference.  This should be treated as plaintext.
    # AnsibleVaultEncryptedUnicode instances without a vault should
    # never pass any checks.
    avu = AnsibleVaultEncryptedUnicode("foobar")

    assert avu.__ne__("foobar"), 'Expected the AnsibleVaultEncryptedUnicode kind of foobar ' \
               'not to be equal to the string foobar but it is.'

    assert not avu.__ne__("not_equal"), 'Expected the AnsibleVaultEncryptedUnicode kind of ' \
               'foobar to not be equal to not_equal but it is.'

# Unit tests for AnsibleVaultEncryptedUnicode.is_encrypted()

# Generated at 2022-06-11 09:33:12.439838
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    if sys.version_info[0] == 3:
        s = bytes('hello', 'utf-8')
    elif sys.version_info[0] == 2:
        s = 'hello'
    v = AnsibleVaultEncryptedUnicode(s)
    assert v != 'hello'
    assert v != u'hello'


# Generated at 2022-06-11 09:33:18.393069
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('bar', None, None)
    assert avu1 != avu2

    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('bar', None, None)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('bar', None, None)
    assert not avu1 != avu2


# Generated at 2022-06-11 09:33:31.519042
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    #
    # Set up vault to use and secret to encrypt test data with.
    #
    vault = VaultLib('1234')
    secret = 'abcd'
    #
    # Create the AnsibleVaultEncryptedUnicode to test
    #
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("foo", vault, secret)
    #
    # Compare the AnsibleVaultEncryptedUnicode to a couple of different data types
    #
    assert avu.__eq__("foo")
    assert avu.__eq__(u'foo')
    #
    # Same as above, but with a Vault encrypted text
    #

# Generated at 2022-06-11 09:33:42.059775
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # If a AnsibleVaultEncryptedUnicode object is initialized with ciphertext
    # that is not encrypted, but with data that is not a string, the __ne__
    # method will return False, even if the object is not equal.
    avu1 = AnsibleVaultEncryptedUnicode(to_bytes('Hello World!'))

    assert avu1 != 'Goodbye World!'

    # This is true because it is not equal, but __ne__ always returns True.
    assert id(avu1) != 'Goodbye World!'

    # If a AnsibleVaultEncryptedUnicode object is initialized with data
    # that is not a string, the __ne__ method will return False, even if
    # the object is not equal.
    avu2 = AnsibleVaultEncryptedUnicode(123456789)


# Generated at 2022-06-11 09:33:47.215561
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    passwd = 'secret'
    vault = VaultLib(passwd)
    plaintext1 = 'eof'
    plaintext2 = 'eo'
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext1, vault, passwd)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext2, vault, passwd)
    assert avu1 == avu1
    assert avu1 != avu2

# Generated at 2022-06-11 09:33:51.894358
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    vault = vaultlib.VaultLib('test')
    instance = AnsibleVaultEncryptedUnicode.from_plaintext('plaintext', vault, 'test')
    assert instance == 'plaintext'
    assert instance != 'not-plaintext'
    assert not (instance == 'not-plaintext')
    assert not (instance != 'plaintext')


# Generated at 2022-06-11 09:34:02.107070
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import AnsibleVaultError
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultSecret

    def mocked_encrypt(s, secret):
        return s

    def mocked_decrypt(s, secret):
        return secret.secret

    def mocked_is_encrypted(c):
        return True

    text_to_encrypt = 'foo'

    vault_secret = AnsibleVaultSecret('baz')

    mocked_vault = VaultLib()
    mocked_vault.encrypt = mocked_encrypt
    mocked_vault.decrypt = mocked_decrypt
    mocked_vault.is_

# Generated at 2022-06-11 09:34:03.956289
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode("test").__ne__("test") #diferent types


# Generated at 2022-06-11 09:34:06.054124
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    blank_text = ' '
    assert AnsibleVaultEncryptedUnicode(blank_text) != 'a'


# Generated at 2022-06-11 09:34:23.555732
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # string argument
    try:
        assert AnsibleVaultEncryptedUnicode("test").__eq__('test') is True
        assert AnsibleVaultEncryptedUnicode("test").__eq__('foo') is False
    except AssertionError as e:
        print("Assertion failed: {}".format(e))
        raise

    # AnsibleVaultEncryptedUnicode argument
    try:
        assert AnsibleVaultEncryptedUnicode("test").__eq__(AnsibleVaultEncryptedUnicode("test")) is True
        assert AnsibleVaultEncryptedUnicode("test").__eq__(AnsibleVaultEncryptedUnicode("foo")) is False
    except AssertionError as e:
        print("Assertion failed: {}".format(e))
        raise

    # non

# Generated at 2022-06-11 09:34:34.632117
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib

    vaulted_text = to_bytes('$ANSIBLE_VAULT;1.1;AES256\n35376433663864376665643936356537306564363365623865653734353164353838626436623233\n33306137666439653463303439353763386363396463666538336530623339353165343135616662\n6639653534353563616432633439363661306665633465383562353236333764\n')

    secret = to_bytes('my-secret-password')
    vault = VaultLib(password=secret)


# Generated at 2022-06-11 09:34:42.176078
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import os
    import tempfile
    import unittest
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vaultlib import VaultLib

    class TestAnsibleVaultEncryptedUnicodeMethod__ne__(unittest.TestCase):
        def setUp(self):
            self.tmp_file = tempfile.NamedTemporaryFile(mode='w+', delete=False)
            self.password = '$ecr3t'
            self.editor = VaultEditor(password=self.password)
            self.editor.create_file(self.tmp_file)

        def tearDown(self):
            self.tmp_file.close()
            os.remove(self.tmp_file.name)


# Generated at 2022-06-11 09:34:52.014779
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    # test vault == vault
    plaintext = u'ABCDEF'
    password = u'12345'
    vault = VaultLib(password)
    vault_content = vault.encrypt(plaintext, password)
    avu = AnsibleVaultEncryptedUnicode(vault_content)
    avu.vault = vault
    assert avu == plaintext

    # test vault != vault
    plaintext = u'ABCDEF'
    password = u'12345'
    vault = VaultLib(password)
    vault_content = vault.encrypt(plaintext, password)
    avu = AnsibleVaultEncryptedUnicode(vault_content)
    avu.vault = vault
    assert avu != u'ZYXWVU'



# Generated at 2022-06-11 09:34:53.259333
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode("foo") != "bar"


# Generated at 2022-06-11 09:34:57.010429
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Testing __eq__ value=True
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('plaintext', None, None)
    assert (avu == 'plaintext') == True
    # Testing __eq__ value=False
    assert (avu == 'plaintext2') == False


# Generated at 2022-06-11 09:34:59.327747
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault=None, secret=None)
    assert 'abc' != avu


# Generated at 2022-06-11 09:35:04.232847
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    class Foo:
        # from https://doctest.readthedocs.io/en/latest/doctest.html#how-doctests-work
        def __eq__(self, other):
            return True

    avu = AnsibleVaultEncryptedUnicode('secret')
    try:
        assert avu != Foo()
    except AssertionError:
        exit(1)
    exit(0)


# Generated at 2022-06-11 09:35:12.696521
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes

    vault_pass = StringIO(to_bytes("password\n"))

    cleartext = "\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\xff\x06\x00\x42\x43\x02\x00\x1b\x00\x03\x00\x00\x00\x00\x00\x00\x00\x00\x00"

    vault = VaultLib(vault_pass)
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(cleartext, vault, None)

# Generated at 2022-06-11 09:35:21.573250
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    vault = FakeVault()
    avu_utf8_unicode_good = AnsibleVaultEncryptedUnicode.from_plaintext(b'this is a test', vault, b'secret')
    avu_unicode_good = AnsibleVaultEncryptedUnicode.from_plaintext(u'this is a test', vault, b'secret')
    avu_utf8_unicode_bad = AnsibleVaultEncryptedUnicode.from_plaintext(b'bad!', vault, b'secret')
    avu_unicode_bad = AnsibleVaultEncryptedUnicode.from_plaintext(u'bad!', vault, b'secret')
    avu_unicode_none = AnsibleVaultEncryptedUnicode(b'')
    avu_unicode_none.v