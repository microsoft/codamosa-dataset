

# Generated at 2022-06-21 00:01:25.894442
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    import crypt.vaultlib
    # This value is the unencrypted value of the string "foo"
    # encrypted with our test vault.

# Generated at 2022-06-21 00:01:31.514901
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('correct-horse-battery-staple')
    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext('My String', vault, 'correct-horse-battery-staple')
    assert(encrypted_string.upper() == 'MY STRING')


# Generated at 2022-06-21 00:01:43.188066
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    # tests for str/bytes (single line strings)
    assert AnsibleVaultEncryptedUnicode('str').encode() == b'str'
    assert AnsibleVaultEncryptedUnicode('str').encode(encoding='ascii') == b'str'
    assert AnsibleVaultEncryptedUnicode('str').encode(encoding='utf-8') == b'str'
    assert AnsibleVaultEncryptedUnicode('str').encode(encoding='utf-8') == b'str'
    assert AnsibleVaultEncryptedUnicode('str').encode(errors='strict') == b'str'
    assert AnsibleVaultEncryptedUnicode('str').encode(encoding='ascii', errors='strict') == b'str'
    assert AnsibleVaultEncryptedUnic

# Generated at 2022-06-21 00:01:48.680514
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    from ansible.parsing.yaml.objects import AnsibleMapping
    tdict = AnsibleMapping()
    tdict.ansible_pos = ('somefile', 123, 12)
    assert (tdict._data_source == 'somefile')
    assert (tdict._line_number == 123)
    assert (tdict._column_number == 12)

    tdict.ansible_pos = (3, 12, 13)
    assert (tdict._data_source == 3)
    assert (tdict._line_number == 12)
    assert (tdict._column_number == 13)

    tdict.ansible_pos = ('otherfile', 456, 34)
    assert (tdict._data_source == 'otherfile')
    assert (tdict._line_number == 456)

# Generated at 2022-06-21 00:01:50.871564
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    assert AnsibleVaultEncryptedUnicode('1+2j').__complex__() == complex('1+2j')


# Generated at 2022-06-21 00:02:03.515433
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    import os
    import hashlib
    import utils.vault as vault

    # Generate secret key
    test_key = os.urandom(64)

    # Create a vault
    vault_obj = vault.VaultLib(test_key, b'vault-id-to-be-overwritten')

    # Create vault string
    vault_string = u'Hello world!'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(vault_string, vault_obj, test_key)
    assert avu[:] == vault_string, 'Unable to use [:] on encrypted string'

    # Create vault string
    vault_string = u'Hello world!'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(vault_string, vault_obj, test_key)
   

# Generated at 2022-06-21 00:02:14.484975
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    '''
    Testing AnsibleVaultEncryptedUnicode.casefold()

    The result of casefold must be a new AnsibleVaultEncryptedUnicode with the same .vault and .data properties as the original object
    except for the new .data property being the casefolded text.

    The operation must not modify the original object.
    '''
    test1_plaintext = 'Hello World!'
    test1_vault = AnsibleVaultLib('password')
    test1_avu = AnsibleVaultEncryptedUnicode.from_plaintext(test1_plaintext, test1_vault, 'password')

    test1_avu_casefold = test1_avu.casefold()

    assert isinstance(test1_avu_casefold, AnsibleVaultEncryptedUnicode)
    assert test

# Generated at 2022-06-21 00:02:26.588233
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    # Check hash with different ansible_pos
    v1 = AnsibleVaultEncryptedUnicode(u'123')
    v2 = AnsibleVaultEncryptedUnicode(u'123')
    v3 = AnsibleVaultEncryptedUnicode(u'123')
    v4 = AnsibleVaultEncryptedUnicode(u'123')
    v1.ansible_pos = 'a'
    v2.ansible_pos = 'b'
    v3.ansible_pos = 'c'
    v4.ansible_pos = 'd'
    assert(hash(v1) == hash(v2))
    assert(hash(v1) == hash(v3))
    assert(hash(v1) == hash(v4))
    assert(hash(v2) == hash(v3))


# Generated at 2022-06-21 00:02:37.509866
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    s = AnsibleVaultEncryptedUnicode("543_4")
    assert(s.isidentifier() == False)
    s = AnsibleVaultEncryptedUnicode("_543_4")
    assert(s.isidentifier() == False)
    s = AnsibleVaultEncryptedUnicode("543_4_")
    assert(s.isidentifier() == False)
    s = AnsibleVaultEncryptedUnicode("_543_4_")
    assert(s.isidentifier() == True)
    s = AnsibleVaultEncryptedUnicode("_543_4_4")
    assert(s.isidentifier() == True)

AnsibleBaseYAMLObject.register(AnsibleUnicode)

# Generated at 2022-06-21 00:02:49.338831
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    # assert that we can create an AnsibleMapping object with no args
    mymap = AnsibleMapping()
    # assert that we have the right type
    assert isinstance(mymap, AnsibleMapping)
    # assert that we can access and set the ansible_pos
    mymap.ansible_pos = (1, 2, 3)
    mymap.ansible_pos = (1, 2, 3)
    # and assert that we can use the object as a dictionary
    mymap["bar"] = "baz"

    # assert that we can create an AnsibleMapping object with a dict
    mymap = AnsibleMapping({"foo": "bar"})
    # assert that we have the right type
    assert isinstance(mymap, AnsibleMapping)
    # assert that we can access and set the ansible_pos


# Generated at 2022-06-21 00:03:09.111160
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    import unittest

    class testAnsibleVaultEncryptedUnicode(unittest.TestCase):
        def test_isspace(self):
            ae = AnsibleVaultEncryptedUnicode(b' ')
            self.assertTrue(ae.isspace())

            ae = AnsibleVaultEncryptedUnicode(b'\t')
            self.assertTrue(ae.isspace())

            ae = AnsibleVaultEncryptedUnicode(b'\n')
            self.assertTrue(ae.isspace())

            ae = AnsibleVaultEncryptedUnicode(b'\r')
            self.assertTrue(ae.isspace())

            ae = AnsibleVaultEncryptedUnicode(b'\r\n')
            self.assertFalse(ae.isspace())



# Generated at 2022-06-21 00:03:19.479959
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(['--vault-password-file', 'test/vault_pass.txt'])
    password = '$ANSIBLE_VAULT;1.1;AES256\n33353337343035343063623336323966663432346666363965663438373537653762356537343736\n39343637376139386231656132383339376639316136613531363734366466333261633339336461\n30393437643262646335383432343338376365346565366237336261666434333065316231636235\n383334396439316661333000\n'

# Generated at 2022-06-21 00:03:31.612415
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:03:40.923885
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    if sys.version_info[0] < 3:
        # In python 2, isidentifier does not exist and isalpha is implemented for strings and unicode
        # So testing isidentifier does not make sense
        return
    # This test is taken from http://hg.python.org/cpython/file/3.4/Lib/test/test_unicode.py:
    # Tests for str.isidentifier
    ids = [
    'a', 'z', 'A', 'Z', 'd',
    'with_underscore',
    '_with_underscore_leading',
    'with_underscore_trailing_',
    '_',
    '__________',
    'a0', '0a', 'a0_', '0a_',
    ]

# Generated at 2022-06-21 00:03:52.895505
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import UnsafeText
    import ansible.vars.unsafe_proxy as unsafe_proxy

    # vault_password_file is needed to decrypt vault encrypted strings
    vault_pass_file = './test_ansible_vault_pass.txt'
    vault = VaultLib(vault_pass_file)

    assert(unsafe_proxy._getproxiedobj(UnsafeText(u'a')) is str)
    assert(unsafe_proxy._getproxiedobj(UnsafeText(u'a')) is not text_type)


    # When:
    #   - calling __le__ with a string
    #   - calling __le__ with a AnsibleVaultEncryptedUnicode
    # Then:

# Generated at 2022-06-21 00:04:03.890668
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    a = AnsibleVaultEncryptedUnicode(u"test")
    assert a.center(0) == a
    assert a.center(1) == a
    assert a.center(2) == a
    assert a.center(3) == a
    assert a.center(4) == u"test"
    assert a.center(5) == u"test "
    assert a.center(6) == u" test "
    assert a.center(7) == u" test  "
    assert a.center(8) == u"  test  "
    assert a.center(9) == u"  test   "
    a = AnsibleVaultEncryptedUnicode(u"test test")
    assert a.center(4) == a
    assert a.center(5) == a

# Generated at 2022-06-21 00:04:08.197071
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    am = AnsibleMapping()
    am["hello"] = "world"
    assert am["hello"] == "world"
    assert isinstance(am["hello"], AnsibleUnicode)



# Generated at 2022-06-21 00:04:16.933131
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    expected = '   x'
    avu = AnsibleVaultEncryptedUnicode(b'x')
    assert avu.rjust(4) == expected
    assert avu.rjust(4, ' ') == expected
    assert avu.ljust(4) == expected
    assert avu.ljust(4, ' ') == expected
    assert avu.lstrip(4) == expected
    assert avu.lstrip(4, ' ') == expected
    assert avu.rstrip(4) == expected
    assert avu.rstrip(4, ' ') == expected


# Generated at 2022-06-21 00:04:27.468349
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    """Test case for method zfill.

    This testcase covers the following method in AnsibleVaultEncryptedUnicode:
    - zfill
    """

    avue = AnsibleVaultEncryptedUnicode("123")
    assert avue.zfill(5) == "00123"

    # string is already the right length
    avue = AnsibleVaultEncryptedUnicode("12345")
    assert avue.zfill(5) == "12345"

    # string is too long
    avue = AnsibleVaultEncryptedUnicode("123450")
    assert avue.zfill(5) == "123450"

    # string is a float
    avue = AnsibleVaultEncryptedUnicode("-1.25")

# Generated at 2022-06-21 00:04:29.362062
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    x = AnsibleVaultEncryptedUnicode('hello')
    assert x.upper() == 'HELLO'



# Generated at 2022-06-21 00:04:43.285511
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    encrypted = AnsibleVaultEncryptedUnicode("AB!CD")
    encrypted.vault = vaultlib.VaultLib("password")
    assert(encrypted == "AB!CD")
    assert(encrypted != "AB!CG")

if __name__ == '__main__':
    from ansible.module_utils.ansible_vault import VaultLib
    test_AnsibleVaultEncryptedUnicode___eq__()

# Generated at 2022-06-21 00:04:49.876258
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password="test")
    text1 = AnsibleVaultEncryptedUnicode.from_plaintext("foo bar", vault=vault, secret="test")
    text2 = "baz"
    assert (text1 + text2) == "foo barbaz"
    assert (text2 + text1) == "bazfoo bar"



# Generated at 2022-06-21 00:04:54.570465
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    # Create a vault using ansible-vault.
    # I use the object AnsibleUnsafeText because it can contain any ASCII characters.
    vault = vaultlib.VaultEditor('myPassword')

    # Encrypt a string.
    ciphertext = vault.encrypt('foo', secret=b'bar')

    # Create a AnsibleVaultEncryptedUnicode object.
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    # Create an AnsibleUnsafeText.
    aut = AnsibleUnsafeText('bar')

    # Checking the result of the expression aut + avu.
    assert to_text(aut + avu) == 'barfoo'


# Generated at 2022-06-21 00:05:03.262696
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    s = 'p\ra\ns\te\nd\n'
    r = AnsibleVaultEncryptedUnicode(s)
    assert r.splitlines() == ['p\ra\ns\te\nd', '']

# Loader based on PyYAML's unsafe loader.
# https://github.com/yaml/pyyaml/blob/3.11/lib3/yaml/constructor.py#L74
#
# See https://yaml.readthedocs.io/en/latest/faq.html#why-there-is-no-unsafe-loader-function-like-load
# for details.

# Generated at 2022-06-21 00:05:14.505902
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    TEST_DATA_A = 'test data'
    TEST_DATA_A_LEN = len(TEST_DATA_A)
    TEST_DATA_B = '多元测试数据'
    TEST_DATA_B_LEN = len(TEST_DATA_B)

    seq = AnsibleVaultEncryptedUnicode(TEST_DATA_A)
    if seq.__len__() != TEST_DATA_A_LEN:
        raise AssertionError("AnsibleVaultEncryptedUnicode.__len__() %s should be %s" % (str(seq.__len__()), str(TEST_DATA_A_LEN)) )

    seq = AnsibleVaultEncryptedUnicode(TEST_DATA_B)

# Generated at 2022-06-21 00:05:23.435820
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    '''
    This method ensures that AnsibleVaultEncryptedUnicode objects can be converted to int successfully
    '''
    from tempfile import mkstemp
    import os

    try:
        from ansible.parsing.vault import VaultEditor
    except ImportError:
        print("ansible.parsing.vault not found. Skipping AnsibleVaultEncryptedUnicode tests.")
        return

    # Create a temp file for testing vault object
    (fd, test_file) = mkstemp()
    os.close(fd)

    # Create Vault object
    vault = VaultEditor(passwords=[''])
    vault.create_file(test_file)

    # Calculate expected int value of plaintext and ciphertext
    plaintext = "test_string"

# Generated at 2022-06-21 00:05:27.121605
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    a = AnsibleVaultEncryptedUnicode.from_plaintext('foo', VaultLib({}), b'bar')
    b = AnsibleVaultEncryptedUnicode.from_plaintext('foo', VaultLib({}), b'bar')

    assert a == b
    assert b == a
    assert a == 'foo'
    assert 'foo' == a
    assert a != 'bar'
    assert 'bar' != a


# Generated at 2022-06-21 00:05:32.066102
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    # See https://github.com/ansible/ansible/issues/5320
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password='secret')
    s = vault.encrypt(u'foo : bar')
    avu = AnsibleVaultEncryptedUnicode(s)
    assert avu.split(' : ') == [u'foo', u'bar']


# Generated at 2022-06-21 00:05:42.156932
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    # test unicode string
    left = AnsibleVaultEncryptedUnicode('foo')
    right = AnsibleVaultEncryptedUnicode('foo')
    assert left.__le__(right)

    right = AnsibleVaultEncryptedUnicode('bar')
    assert left.__le__(right) is False

    right = AnsibleVaultEncryptedUnicode('foobar')
    assert left.__le__(right)

    # test string
    try:
        right = right.encode()
        assert left.__le__(right)
    except TypeError:
        # this will happen when string is not a supported type
        # (i.e. PY2)
        assert False

    right = 'foobar'
    assert left.__le__(right)

    # test bytes

# Generated at 2022-06-21 00:05:44.613027
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    assert type(AnsibleSequence()) == AnsibleSequence


# Generated at 2022-06-21 00:05:55.015605
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    assert isinstance(AnsibleVaultEncryptedUnicode(u'123ABC').capitalize().data, text_type)


# Generated at 2022-06-21 00:06:04.664022
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    from ansible.parsing.vault import VaultLib
    from test.unit.ansible.modules.vault._test_vault import vault_password
    # empty string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('', VaultLib(vault_password), vault_password)
    assert hash('') == hash(avu)
    # non-empty string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('non-empty string', VaultLib(vault_password), vault_password)
    assert hash('non-empty string') == hash(avu)


# Generated at 2022-06-21 00:06:15.785290
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    class vault(object):
        def __init__(self, password):
            self.password = password

        def encrypt(self, data, secret=None):
            return data

        def decrypt(self, ciphertext, secret=None):
            return ciphertext

    v = vault("test")
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("test: ", v, None)
    assert avu.data == "test: "
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("test", v, None)
    assert avu.data == "test"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("", v, None)
    assert avu.data == ""

    # Passing in a list of AnsibleVaultEncryptedUnicode objects
    av

# Generated at 2022-06-21 00:06:17.643397
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    avu = AnsibleVaultEncryptedUnicode("test")
    assert avu.isupper() == False



# Generated at 2022-06-21 00:06:29.656652
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    class FakeVault():
        def decrypt(self, s, obj=None):
            assert isinstance(s, bytes)
            if s==b'encryptme':
                return b'foo,bar'
            elif s==b'encryptme,too':
                return b'foo,bar,baz'
            else:
                raise ValueError('Invalid test ciphertext %r' % (s,))
        def encrypt(self, s, secret):
            assert isinstance(s, bytes)
            if s==b'foo,bar':
                return b'encryptme'
            elif s==b'foo,bar,baz':
                return b'encryptme,too'
            else:
                raise ValueError('Invalid test plaintext %r' % (s,))

# Generated at 2022-06-21 00:06:33.268330
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    """
    Test if AnsibleVaultEncryptedUnicode's islower method works

    :return:
    """
    avu = AnsibleVaultEncryptedUnicode(b"a")
    return avu.islower()

# Generated at 2022-06-21 00:06:41.831195
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    try:
        from ansible.parsing.vault import VaultLib
    except ImportError:
        _sys.stderr.write('skipping test_AnsibleVaultEncryptedUnicode_encode since vault lib is not installed\n')
        return

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    plaintext = '# this is an encrypted unicode string'
    ciphertext = vault.encrypt(plaintext)

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    # Test that encode returns a byte string
    assert isinstance(avu.encode(), bytes)

    # Test that encode can take in a unicode string for the encoding parameter

# Generated at 2022-06-21 00:06:45.807459
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    from ansible.utils.vault import VaultLib

    vault = VaultLib(password='secret')
    vault.is_encrypted(True)

    plaintext = 'Hello World!'
    encrypted = vault.encrypt(plaintext)
    avu = AnsibleVaultEncryptedUnicode(encrypted)

    assert avu.isprintable() == False
    assert avu.isprintable() == False
    assert avu.data == plaintext

    assert avu.isprintable() == True
    assert avu.isprintable() == True # checks if string is cached?



# Generated at 2022-06-21 00:06:54.593217
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    string = "STRING"
    assert AnsibleVaultEncryptedUnicode(string).isupper() == string.isupper()
    string = "string"
    assert AnsibleVaultEncryptedUnicode(string).isupper() == string.isupper()
    string = "1223"
    assert AnsibleVaultEncryptedUnicode(string).isupper() == string.isupper()
    string = "---"
    assert AnsibleVaultEncryptedUnicode(string).isupper() == string.isupper()
    string = "AAA"
    assert AnsibleVaultEncryptedUnicode(string).isupper() == string.isupper()
    string = "123"
    assert AnsibleVaultEncryptedUnicode(string).isupper() == string.isupper()
    string = "!@#%"
    assert Ans

# Generated at 2022-06-21 00:07:06.725097
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:07:18.617770
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    assert not AnsibleVaultEncryptedUnicode(' \t\n').isspace()
    assert AnsibleVaultEncryptedUnicode(" \t\n ").isspace()
    assert not AnsibleVaultEncryptedUnicode("\u2000\u2001\u2002").isspace()
    assert not AnsibleVaultEncryptedUnicode("\u200b").isspace()
    assert not AnsibleVaultEncryptedUnicode("\u3000").isspace()



# Generated at 2022-06-21 00:07:29.703332
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    avu = AnsibleVaultEncryptedUnicode('123')
    assert True == avu.isnumeric()
    avu = AnsibleVaultEncryptedUnicode('123.1')
    assert False == avu.isnumeric()
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert False == avu.isnumeric()
    avu = AnsibleVaultEncryptedUnicode('123abc')
    assert False == avu.isnumeric()
    avu = AnsibleVaultEncryptedUnicode('abc123')
    assert False == avu.isnumeric()


_CONSTRUCTORS = {}


# Generated at 2022-06-21 00:07:41.095531
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    s = AnsibleVaultEncryptedUnicode("this is a test")

    # string is found
    assert s.rindex("t") == 10
    assert s.rindex("t", 0, 11) == 10
    assert s.rindex("t", 0, 10) == 8
    assert s.rindex("t", 0, 9) == 8
    assert s.rindex("t", 0, 8) == 8
    assert s.rindex("t", 0, 7) == -1

    # string isn't found
    try:
        s.rindex("T")
        assert False, "rindex did not raise Exception"
    except ValueError:
        assert True
    except:
        assert False, "rindex raised unexpected Exception"

    # slice too small

# Generated at 2022-06-21 00:07:44.705330
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    # Create the object
    obj = AnsibleVaultEncryptedUnicode("This is a test")
    # Check the result of calling __repr__
    assert obj.__repr__() == repr("This is a test")



# Generated at 2022-06-21 00:07:56.184978
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    from ansible.plugins.vars.vault import VaultLib
    # check without parameters
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('Hello', VaultLib(password='pwd'), b'pwd')
    assert avu.format() == 'Hello'
    # check with one parameter
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('Hello {}', VaultLib(password='pwd'), b'pwd')
    assert avu.format('World') == 'Hello World'
    # check with multiple parameters
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('{2} {1} {0}', VaultLib(password='pwd'), b'pwd')
    assert avu.format("Hello", "World", "!") == "! World Hello"


# Generated at 2022-06-21 00:08:04.855370
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():

    parser = yaml.SafeLoader(stream=open('test.yml'))
    parser.add_constructor(
        u'!vault', AnsibleVaultEncryptedUnicode.from_vault_text
    )
    data = parser.get_single_data()

    assert isinstance(data['data'], AnsibleVaultEncryptedUnicode)
    assert data['data'] == 'this is the password'

    assert isinstance(str(data['data']), str)
    assert data['data'].rindex('the') == 14
    assert hash('the') == hash(data['data'].rindex('the'))

# Generated at 2022-06-21 00:08:08.986586
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    alist = {'a': 'apple', 'b': 'banana', 'c': 'cranberry'}
    amap = AnsibleMapping(alist)
    assert isinstance(amap, dict)
    assert amap.a == 'apple'
    assert amap.b == 'banana'
    assert amap.c == 'cranberry'



# Generated at 2022-06-21 00:08:10.858944
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    assert AnsibleVaultEncryptedUnicode('012').isdigit()
    assert not AnsibleVaultEncryptedUnicode('0x2').isdigit()


# Generated at 2022-06-21 00:08:15.134842
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    text = 'This is a test line in upper case'
    result = AnsibleVaultEncryptedUnicode(text).swapcase()
    assert text.swapcase() == result



# Generated at 2022-06-21 00:08:21.582935
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    from ansible_collections.ansible.community.plugins.module_utils.vault import VaultLib
    vault = VaultLib(b'hunter42')
    data = to_bytes('MyVaultString')
    secret = to_bytes('hunter42')
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(data, vault, secret)
    assert encrypted.capitalize() == 'Myvaultstring'



# Generated at 2022-06-21 00:08:35.115063
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    try:
        from ansible_vault import Vault
    except ImportError:
        # ansible-vault not installed, so skip this AnsibleVaultEncryptedUnicode-specific test
        return
    secret = 'mysecret'
    plaintext = 'foobar'

# Generated at 2022-06-21 00:08:36.440808
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    assert int(AnsibleVaultEncryptedUnicode.from_plaintext('1', None, None)) == 1


# Generated at 2022-06-21 00:08:39.452078
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    msg = AnsibleVaultEncryptedUnicode(b'TheQuickBrownFoxJumpsOverTheLazyDog')
    assert msg.casefold() == u'thequickbrownfoxjumpsoverthelazydog'



# Generated at 2022-06-21 00:08:42.474429
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    seq = AnsibleVaultEncryptedUnicode.from_plaintext(u"hello", vault=None, secret=None)
    assert isinstance(seq.__reversed__(), text_type)

# Generated at 2022-06-21 00:08:47.585066
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test if AnsibleVaultEncryptedUnicode.__ne__()
    # returns False when data is properly decrypted.
    def check_decryption(avu, secret):
        # create a dummy vault to test decryption
        class MyVault:
            def decrypt(self, ciphertext, obj):
                assert obj is avu
                return to_bytes(secret)
        avu.vault = MyVault()
        # check that decryption returns the correct value
        return avu != secret

    assert check_decryption(AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, 'secret'), 'secret')

    # Test if AnsibleVaultEncryptedUnicode.__ne__()
    # returns True when there is an error decrypting the data.

# Generated at 2022-06-21 00:08:58.509001
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    def create_ascii_str(length):
        # create a string with length with only printable ascii characters
        return ''.join(chr(j) for j in range(32,127))[:length]

    # create a list of ascii strings
    ascii_strings = [create_ascii_str(j) for j in range(256)]
    
    # create AnsibleVaultEncryptedUnicode object from all ascii strings 
    avu_objects = map(lambda x: AnsibleVaultEncryptedUnicode(x), ascii_strings)

    # check that all the AnsibleVaultEncryptedUnicode objects return True for method isascii
    assert(all(map(lambda x: x.isascii(), avu_objects)))


# Generated at 2022-06-21 00:09:11.020794
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    # Test once with center() and another time with format(), as
    # format() calls center() inside but needs to convert different
    # types (in particular, when width is an int).
    seq = AnsibleVaultEncryptedUnicode('abcdef')
    assert seq.center(20) == '       abcdef        '
    assert seq.center(20, '#') == '#######abcdef#######'
    assert seq.center(20, '#', True) == '#######abcdef#######'
    assert seq.center(20, '#', False) == '###########abcdef###########'
    assert seq.format('<20') == '       abcdef        '
    assert seq.format('#<20') == '#######abcdef#######'

# Generated at 2022-06-21 00:09:15.886045
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    assert isinstance(AnsibleVaultEncryptedUnicode(''), AnsibleVaultEncryptedUnicode)
    assert isinstance(AnsibleVaultEncryptedUnicode('foo'), AnsibleVaultEncryptedUnicode)
    assert isinstance(AnsibleVaultEncryptedUnicode('foo').data, str)



# Generated at 2022-06-21 00:09:19.253541
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    s = AnsibleVaultEncryptedUnicode("teststring")
    old = "test"
    new = "pass"
    assert s.replace(old, new) == "passstring"


# Generated at 2022-06-21 00:09:27.202335
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    from ansible.parsing.vault import VaultEditor

    vault_password = b'$2b$10$MnU4pNM.SV.PdNhKomDz1eEhgCvL9WYpbsHLHaxaAJmfPwV8EygHm'
    vault = VaultEditor(vault_password)
    plaintext = b'hello, this is a secret'

# Generated at 2022-06-21 00:09:45.489266
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    try:
        AnsibleBaseYAMLObject(1)
        assert False
    except TypeError:
        pass
    except:
        assert False

    try:
        AnsibleBaseYAMLObject(1, 2)
        assert False
    except TypeError:
        pass
    except:
        assert False

    try:
        AnsibleBaseYAMLObject(a=2)
        assert False
    except TypeError:
        pass
    except:
        assert False


# Generated at 2022-06-21 00:09:51.971150
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    from math import pi
    from ansible.parsing.vault import VaultLib

    secret_string = 'fishhook'
    vault = VaultLib([])

    encrypted_message = AnsibleVaultEncryptedUnicode.from_plaintext(secret_string, vault, secret_string)
    encrypted_message.vault = vault
    assert encrypted_message.zfill(len(secret_string)) == secret_string
    assert encrypted_message.zfill(len(secret_string) - 1) == '0' + secret_string



# Generated at 2022-06-21 00:09:58.749228
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    data = 'hello world'
    # initialize
    avu = AnsibleVaultEncryptedUnicode(data)
    assert data[::-1] == avu.__reversed__()
    # try something different
    data = u'hello world'
    # initialize
    avu = AnsibleVaultEncryptedUnicode(data)
    assert data[::-1] == avu.__reversed__()

if __name__ == '__main__':
    test_AnsibleVaultEncryptedUnicode___reversed__()


# Generated at 2022-06-21 00:10:09.936463
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    for encoding in ('utf-8', 'latin-1', 'ascii', 'cp1252', 'x-mac-cyrillic'):
        for text in ('Текст на русском', 'Text en français', 'Text in English', 'text in türkisцh', 'Τεκστ εν Ελληνικά', 'サトウキビ'):

            # Create an AnsibleVaultEncryptedUnicode object encoded to the target encoding
            avu = AnsibleVaultEncryptedUnicode.from_plaintext(text, None, 'ansible')
            # Decode using the target encoding
            avu.data = avu.data.encode(encoding=encoding)

            #Ensure that we can

# Generated at 2022-06-21 00:10:14.593711
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    avu = AnsibleVaultEncryptedUnicode('abcabcabcabc')
    assert avu.rindex('abc') == 12
    assert avu.rindex('abc', 1) == 12
    assert avu.rindex('abc', 0, 8) == 6


# Generated at 2022-06-21 00:10:25.693169
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.vault import VaultAware
    from ansible.compat.tests import unittest

    class TestVault(VaultLib):

        def decrypt(self, _ciphertext, **kwargs):
            ''' override this to test the AnsibleVaultEncryptedUnicode '''
            return _ciphertext

        def encrypt(self, _plaintext, **kwargs):
            ''' override this to test the AnsibleVaultEncryptedUnicode '''
            return _plaintext

        def is_encrypted(self, _plaintext):
            ''' override this to test the AnsibleVaultEncryptedUnicode '''
            return True


# Generated at 2022-06-21 00:10:35.163143
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    # test a string with LF line endings

    # define a string to create an AnsibleVaultEncryptedUnicode object with
    line = 'this is a long line of text\n'
    password = 'test1234'
    vault = yaml.ansible_vault.AnsibleVault(password)

    # create the AnsibleVaultEncryptedUnicode object
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(line, vault, password)

    # use the splitlines method of the AnsibleVaultEncryptedUnicode object
    result = encrypted.splitlines()

    # check the result
    assert isinstance(result, list)
    assert len(result) == 2
    assert result[0] == 'this is a long line of text'
    assert result[1] == ''

    # test a

# Generated at 2022-06-21 00:10:46.965108
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    from ansible.plugins.vault import VaultLib

    avu = AnsibleVaultEncryptedUnicode.from_plaintext("data", VaultLib('secret'), 'secret')

    # Test that encode retrieves plaintext
    assert avu.encode() == b"data"

    # Test that encode retrieves plaintext with given encoding
    assert avu.encode(encoding='utf-8') == b"data"
    assert avu.encode(encoding='utf-8', errors='surrogateescape') == b"data"
    assert avu.encode(errors='surrogateescape') == b"data"

    # Test that encode treats string as plaintext
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("data", VaultLib('secret1'), 'secret1')

    assert avu.en

# Generated at 2022-06-21 00:10:48.070313
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Initialize the class
    pass


# Generated at 2022-06-21 00:10:57.242087
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    assert int(AnsibleVaultEncryptedUnicode.from_plaintext('1', None, None)) == 1
    assert int(AnsibleVaultEncryptedUnicode.from_plaintext('2', None, None), base=2) == 2
    assert int(AnsibleVaultEncryptedUnicode.from_plaintext('3', None, None), base=3) == 3
    assert int(AnsibleVaultEncryptedUnicode.from_plaintext('4', None, None), base=4) == 4
    assert int(AnsibleVaultEncryptedUnicode.from_plaintext('5', None, None), base=5) == 5
    assert int(AnsibleVaultEncryptedUnicode.from_plaintext('6', None, None), base=6) == 6