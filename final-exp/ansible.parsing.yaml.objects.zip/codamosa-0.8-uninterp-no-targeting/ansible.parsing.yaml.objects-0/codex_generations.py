

# Generated at 2022-06-21 00:01:26.652748
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    '''
    # issue: https://github.com/ansible/ansible/issues/12703
    None of the AnsibleUnicode cases that strip whitespace should strip
    whitespace from the end of the string.

    In most cases this "just works", with the one exception of lstrip().
    lstrip() should only strip whitespace from the beginning.
    '''
    avu = AnsibleVaultEncryptedUnicode("  spam")
    assert avu.lstrip() == "spam"

    avu = AnsibleVaultEncryptedUnicode("spam  ")
    assert avu.lstrip() == "spam  "

# end of unit test



# Generated at 2022-06-21 00:01:34.133785
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    assert AnsibleVaultEncryptedUnicode('').isnumeric() == False
    assert AnsibleVaultEncryptedUnicode('0').isnumeric() == True
    assert AnsibleVaultEncryptedUnicode('1').isnumeric() == True
    assert AnsibleVaultEncryptedUnicode('2').isnumeric() == True
    assert AnsibleVaultEncryptedUnicode('42').isnumeric() == True
    assert AnsibleVaultEncryptedUnicode('a').isnumeric() == False


# Generated at 2022-06-21 00:01:44.757282
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    from ansible.parsing.vault import VaultLib
    class TmpVaultLib(VaultLib):
        def is_encrypted(self, block_text):
            return False
        def load_secret(self):
            pass
        def encrypt(self, block_text, secret):
            pass
        def decrypt(self, block_text, secret):
            return to_bytes(block_text)
    block_text = '---\nfoo: bar\n'
    vault = TmpVaultLib(None, b'', b'')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(block_text, vault, None)
    assert avu.isalnum()


# Generated at 2022-06-21 00:01:51.487808
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test_password')
    value = AnsibleVaultEncryptedUnicode.from_plaintext('0123456',
                                                        vault,
                                                        'test_password')
    # The lstrip method needs to pass a function to `all`
    value = wrap_var(value)
    assert value.lstrip('012') == '3456'



# Generated at 2022-06-21 00:01:57.896973
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    if _sys.version_info[0] < 3:
        # Python 2.7
        with _sys.version_info as version_info:
            assert version_info == (2, 7)
        # Test for AnsibleVaultEncryptedUnicode In case of string
        str_ = "sample"
        ansible_vault_encrypted_string = AnsibleVaultEncryptedUnicode(str_.decode("utf-8"))
        search_string = "a"
        result = ansible_vault_encrypted_string.rfind(search_string)
        assert result == str_.rfind(search_string)
        # Test for AnsibleVaultEncryptedUnicode In case of string with start value
        search_string = "a"
        start = 1
        result = ansible_vault_encrypted_string.rfind

# Generated at 2022-06-21 00:02:01.287052
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    avu = AnsibleVaultEncryptedUnicode('Test')
    assert avu.ljust(10, '.') == 'Test......'


# Generated at 2022-06-21 00:02:12.686538
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    # setup
    ciphertext = '!vault |$ANSIBLE_VAULT;1.1;AES256'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)

    # startswith with AnsibleVaultEncryptedUnicode
    prefix = AnsibleVaultEncryptedUnicode('!vault |')
    assert avu.startswith(prefix)

    # startswith with base string
    prefix = '!vault |'
    assert avu.startswith(prefix)

    # startswith with base string
    prefix = '!vault |$ANSIBLE_VAULT;1.1;AES256'
    assert avu.startswith(prefix)

    # startswith with another string, fails

# Generated at 2022-06-21 00:02:24.578890
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    # test the format method
    from ansible.parsing import vault

    for vault_password in (_sys.argv[1], _sys.argv[2]):
        if not vault_password:
            raise ValueError('no vault password provided')

        my_vault = vault.VaultLib(vault_password)

        my_str = AnsibleVaultEncryptedUnicode.from_plaintext('hello', my_vault, vault_password='vault_password')
        # test basic string
        assert my_str.data == 'hello'
        # test format of ansible variable
        assert my_str.format('{0}') == 'hello'
        # test format of int
        assert my_str.format('{0:d}', 5) == 'hello5'
        # test format of float
        assert my

# Generated at 2022-06-21 00:02:29.257929
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    assert AnsibleVaultEncryptedUnicode('abc').isupper() == False
    assert AnsibleVaultEncryptedUnicode('ABC').isupper() == True
    assert AnsibleVaultEncryptedUnicode('aBc').isupper() == False


# Generated at 2022-06-21 00:02:38.908695
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    # Test various code paths of method AnsibleVaultEncryptedUnicode.__str__
    import ansible.parsing.vault
    import ansible.parsing.yaml.objects

    def test_AnsibleVaultEncryptedUnicode(self):
        avu = AnsibleVaultEncryptedUnicode('str with no vault')
        self.assertEqual('str with no vault', avu.__str__())
        avu = ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode.from_plaintext('str with vault', ansible.parsing.vault.VaultLib({}), 'ansible')
        avu.vault = ansible.parsing.vault.VaultLib({})

# Generated at 2022-06-21 00:03:02.012689
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    assert AnsibleVaultEncryptedUnicode('HelloWorld').rindex('o')==7
    assert AnsibleVaultEncryptedUnicode('HelloWorld').rindex('o',0)==7
    assert AnsibleVaultEncryptedUnicode('HelloWorld').rindex('o',8)==7
    assert AnsibleVaultEncryptedUnicode('HelloWorld').rindex('o',0,8)==4
    assert AnsibleVaultEncryptedUnicode('HelloWorld').rindex('o',0,5)==4
    assert AnsibleVaultEncryptedUnicode('HelloWorld').rindex('o',0,4)==4
    assert AnsibleVaultEncryptedUnicode('HelloWorld').rindex('o',0,3)==ValueError


# Generated at 2022-06-21 00:03:05.522008
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    # AnsibleVaultEncryptedUnicode inherits from AnsibleUnicode
    # Use AnsibleVaultEncryptedUnicode to test the constructor of AnsibleUnicode
    # because AnsibleVaultEncryptedUnicode has a constructor.
    AnsibleVaultEncryptedUnicode('test')


# Generated at 2022-06-21 00:03:16.056917
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    v = '$ANSIBLE_VAULT;1.1;AES256\n633236633231303964316434663530336365643763356237363666316230656664303362376437623\n3330356634666266626131376639633139643862323435316162333332616266363935303866343965\n61333566373533663135303461306335\n'
    u = AnsibleVaultEncryptedUnicode.from_plaintext(v, yaml.vault.VaultLib(), 'password')
    assert u.startswith("$ANSIBLE_VAULT;1.1;AES256\n")



# Generated at 2022-06-21 00:03:22.924931
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():

    class TestVault(object):

        @staticmethod
        def decrypt(ciphertext, obj=None):
            return to_text(ciphertext, errors='surrogate_or_strict')

        @staticmethod
        def is_encrypted(plaintext):
            return False

    av = AnsibleVaultEncryptedUnicode.from_plaintext(b'ansible', TestVault, secret='test-vault')
    assert av.rstrip() == u'ansible'

    av = AnsibleVaultEncryptedUnicode.from_plaintext(b'ansible  ', TestVault, secret='test-vault')
    assert av.rstrip() == u'ansible'


# Generated at 2022-06-21 00:03:34.721727
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    avu = AnsibleVaultEncryptedUnicode('abcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabc')
    assert avu.find('a') == 0
    assert avu.find('a', 1) == 1
    assert avu.find('a', 2) == 2
    assert avu.find('a', 3) == 3
    assert avu.find('a', 4) == 4
    assert avu.find('a', 5) == 5
    assert avu.find('a', 6) == 6


# Generated at 2022-06-21 00:03:41.150877
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    from ansible.parsing.vault import VaultLib

    # Create an encrypted AnsibleVaultEncryptedUnicode object
    vault_text = '$ANSIBLE_VAULT;9.9;AES256'
    vault_text += '\n39333333333333333333333333333333333333333333333333333333333333333333333333333'
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode(vault_text)
    avu.vault = vault
    # The translate function works
    assert avu.translate(None, '0') == '\n'


# Generated at 2022-06-21 00:03:51.209038
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib
    #This text is exactly 32 bytes.
    txt = to_bytes('yum install -y ansible-vault')
    vault = VaultLib([], 1, 'ansible')
    ciphertext = vault.encrypt(txt, 'ansible')
    avu_left = AnsibleVaultEncryptedUnicode(ciphertext)
    avu_left.vault = vault

    avu_right = AnsibleVaultEncryptedUnicode(ciphertext)
    avu_right.vault = vault

    assert(avu_left.__le__(avu_right))

# Generated at 2022-06-21 00:04:02.460287
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    # Testing when argument is not integer
    for i in [0.1, '1', 1.1, [1, 2], {'a': 1}]:
        result = len(AnsibleVaultEncryptedUnicode('a'))
        assert result == 0, "AnsibleVaultEncryptedUnicode.__mul__() when the argument is not integer"

    # Testing when argument is an invalid integer
    for i in [-1, -0.1, -0.000000000001]:
        result = len(AnsibleVaultEncryptedUnicode('a'))
        assert result == 0, "AnsibleVaultEncryptedUnicode.__mul__() when the argument is invalid integer"

    # Testing when argument is a valid integer
    for i in [0, 1, 2, 1000000000000]:
        result = len

# Generated at 2022-06-21 00:04:14.754881
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    assert to_text(AnsibleVaultEncryptedUnicode('abc')) == 'abc'
    assert to_text(AnsibleVaultEncryptedUnicode('abc') * 3) == 'abcabcabc'
    assert to_text(AnsibleVaultEncryptedUnicode('abc') + 'def') == 'abcdef'
    assert to_text('def' + AnsibleVaultEncryptedUnicode('abc')) == 'defabc'
    assert to_text(3 * AnsibleVaultEncryptedUnicode('abc')) == 'abcabcabc'
    assert to_bytes(AnsibleVaultEncryptedUnicode('abc')) == b'abc'
    assert to_bytes(AnsibleVaultEncryptedUnicode('abc') * 3) == b'abcabcabc'
    assert to_

# Generated at 2022-06-21 00:04:25.703761
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password='secret')

# Generated at 2022-06-21 00:04:42.032619
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    try:
        import vaultlib
    except ImportError:
        # skip if vaultlib is absent
        return

    vault = vaultlib.VaultLib('mysecretkey')
    assert AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'mysecretkey')

# yaml does not support serializing native objects, so we
# must represent them as strings. This can cause problems
# when a dictionary is supposed to contain array data,
# or integer data.

private_loader = yaml.SafeLoader
#private_dump   = yaml.dump
private_dump   = lambda data, **kwargs: yaml.SafeDumper(**kwargs).dump(data)
private_class_loader = yaml.SafeLoader
private_class_dump   = yaml.SafeDumper

# these are the kinds of classes we

# Generated at 2022-06-21 00:04:52.436256
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    from ansible.parsing.vault import VaultLib, VaultEditor
    vault = VaultLib()
    vault_password = 'vault_password'
    vault_data = vault.encrypt('vault_data')
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(vault_data)
    ansible_vault_encrypted_unicode.vault = vault
    len(ansible_vault_encrypted_unicode) == len('vault_data')
    ansible_vault_encrypted_unicode.data = 'password_data'
    len(ansible_vault_encrypted_unicode) == len('password_data')



# Generated at 2022-06-21 00:05:03.261274
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import UnicodeVaultSecret

    DECRYPTED_TEXT = "this is some plaintext"
    PASSWORD = "password"
    SECRET = UnicodeVaultSecret(PASSWORD)
    VAULT_ID = "1234567890"
    VAULT = VaultLib(SECRET, VAULT_ID)

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(DECRYPTED_TEXT, VAULT, SECRET)

    # test format function with named arguments
    named_values = {"name" : "value"}
    assert avu == DECRYPTED_TEXT, \
           "AnsibleVaultEncryptedUnicode object and the corresponding plaintext should be equal"

# Generated at 2022-06-21 00:05:14.493913
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    class dummyVault(object):
        def decrypt(self, data, obj=None):
            return 'b' + data.decode('utf-8')
    s = AnsibleVaultEncryptedUnicode(b'a')
    s.vault = dummyVault()
    assert(s.replace(b'a', b'b') == 'bb')
    assert(s.replace(b'a', AnsibleVaultEncryptedUnicode(b'c')) == 'bc')
    assert(s.replace(AnsibleVaultEncryptedUnicode(b'a'), b'd') == 'bd')
    assert(s.replace(AnsibleVaultEncryptedUnicode(b'a'), AnsibleVaultEncryptedUnicode(b'e')) == 'be')



# Generated at 2022-06-21 00:05:18.330536
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    avu = AnsibleVaultEncryptedUnicode("ASCII")
    assert avu.isascii()

    avu = AnsibleVaultEncryptedUnicode("váśťîě")
    assert not avu.isascii()


# Generated at 2022-06-21 00:05:23.161692
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    plaintext = u''
    for char in string.ascii_lowercase + string.digits:
        assert AnsibleVaultEncryptedUnicode.from_plaintext(char, None, None).isalnum() == char.isalnum()
        assert AnsibleVaultEncryptedUnicode.from_plaintext(char * 2, None, None).isalnum() == (char * 2).isalnum()


# Generated at 2022-06-21 00:05:28.569344
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():

    def assert_partition(source, sep, result):
        avu = AnsibleVaultEncryptedUnicode(source)
        partition = avu.partition(sep)
        assert partition == result

    test_values = [
        ("foo", ":", ("foo", "", "")),
        ("foo:bar", ":", ("foo", ":", "bar")),
        (":bar", ":", ("", ":", "bar")),
        ("foo:", ":", ("foo", ":", "")),
    ]

    for source, sep, result in test_values:
        assert_partition(source, sep, result)


if __name__ == "__main__":
    # Run unit tests of AnsibleVaultEncryptedUnicode_partition
    test_AnsibleVaultEncrypted

# Generated at 2022-06-21 00:05:34.826550
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    print("--> AnsibleVaultEncryptedUnicode.upper()")
    data = 'abc'
    ciphertext = to_bytes(data)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vaultlib.VaultLib('mystring', vaultlib.VAULT_VERSION_1)
    assert avu.upper() == to_text(avu.data.upper())
    print("All tests passed")


# Generated at 2022-06-21 00:05:39.988543
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    func = AnsibleVaultEncryptedUnicode.isdigit
    assert func(AnsibleVaultEncryptedUnicode('123')), 'Expected isdigit to return True.'
    assert not func(AnsibleVaultEncryptedUnicode('123a')), 'Expected isdigit to return False.'


# Generated at 2022-06-21 00:05:46.614413
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    import ansible.vault
    vault_lib = ansible.vault.VaultLib(['password'])
    key = 'password'
    ciphertext = vault_lib.encrypt(u'01234', key)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault_lib
    assert avu.isdigit() == True


# Generated at 2022-06-21 00:06:16.793647
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    # Works the same as the strip method for strings
    assert AnsibleVaultEncryptedUnicode('  abc  ').strip() == 'abc'

    # Strings with padding of different kinds
    assert AnsibleVaultEncryptedUnicode('\t abc \n').strip() == 'abc'
    assert AnsibleVaultEncryptedUnicode('\t\t\t abc \n\n\n').strip() == 'abc'
    assert AnsibleVaultEncryptedUnicode('\x0cabc\x0c').strip() == 'abc'
    assert AnsibleVaultEncryptedUnicode('\x0babc\x0b').strip() == 'abc'
    assert AnsibleVaultEncryptedUnicode('\x0cabc\x0b').strip() == 'abc'

    # Strip until something

# Generated at 2022-06-21 00:06:29.049820
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import to_unsafe
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib([])
    secret = 'ansible'
    obj = to_unsafe(vault, AnsibleVaultEncryptedUnicode.from_plaintext('ip: 192.168.20.10', vault, secret))
    assert obj.__hash__() == obj.__hash__()
    assert hash(obj) == hash(obj)
    assert hash(obj) == hash(None)
    assert hash(obj.data) == hash(obj.data)
    assert hash(obj) == hash(obj.data)

# Generated at 2022-06-21 00:06:32.048469
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    # Testing with german eszett and capital I and small dot
    seq = "ßIi."
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault=None, secret=None)
    assert isinstance(avu.casefold(), AnsibleVaultEncryptedUnicode)
    assert avu.casefold() == "ssi."


# Generated at 2022-06-21 00:06:41.154182
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    import ansible.utils.vault as vault

    password = vault.gen_password(8)
    test_data = u'abc'
    test_object = AnsibleVaultEncryptedUnicode.from_plaintext(test_data, vault.VaultLib(password), password)

    assert test_object.split() == ['abc']
    assert test_object.split(sep=',') == ['abc']
    assert test_object.split(maxsplit=1) == ['abc']
    assert test_object.split(sep=',', maxsplit=1) == ['abc']
    assert test_object.split(sep='b') == ['a', 'c']
    assert test_object.split(maxsplit=1) == ['abc']

# Generated at 2022-06-21 00:06:45.911992
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    assert(not AnsibleVaultEncryptedUnicode("1213").isalnum())
    assert(AnsibleVaultEncryptedUnicode("1213").data.isalnum())


# Generated at 2022-06-21 00:06:50.907693
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    assert AnsibleVaultEncryptedUnicode("test", vault=vault).data == "test"

_mutable_tag_prefixes = frozenset(('tag:yaml.org,2002:', '!'))



# Generated at 2022-06-21 00:06:53.969075
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    avue = AnsibleVaultEncryptedUnicode('test!')
    assert avue.center(10) == '   test!   '
    assert avue.center(2) == 'test!'



# Generated at 2022-06-21 00:06:56.661812
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    assert list(reversed(AnsibleVaultEncryptedUnicode('abc'))) == ['c', 'b', 'a']



# Generated at 2022-06-21 00:07:08.212386
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing import vault

    # Test is_encrypted with a provided vault password
    # This is used in unittests when loading vault content
    # directly from files.
    secret = 'testvaultpass'
    plaintext = 'this is a test string'
    ciphertext = vault.encrypt(plaintext, secret)
    encrypted = AnsibleVaultEncryptedUnicode(ciphertext)
    encrypted.vault = vault.VaultLib(password=secret)
    assert encrypted.is_encrypted()
    # Confirm that decrypt works
    assert encrypted.data == plaintext

    # Test is_encrypted without a vault password
    # This is what we do during runtime when the
    # AnsibleVaultEncryptedUnicode is being read from
    # playbooks.
    secret_2 = 'secretvaultpass'


# Generated at 2022-06-21 00:07:18.797260
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    vault = VaultLib(password_file='test/test_pw_file')
    loader = AnsibleLoader(AnsibleConstructor(AnsibleVaultEncryptedUnicode.from_plaintext))

# Generated at 2022-06-21 00:07:45.433808
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    assert AnsibleVaultEncryptedUnicode('abc', {'secret': 'test'}).center(5) == ' abc '
    assert AnsibleVaultEncryptedUnicode('abc', {'secret': 'test'}).center(5, 'x') == 'xabcx'
    assert AnsibleVaultEncryptedUnicode('abc', {'secret': 'test'}).center(6, 'x') == 'xabcxx'
    assert AnsibleVaultEncryptedUnicode('abc', {'secret': 'test'}).center(7, 'x') == 'xxabcxxx'
    assert AnsibleVaultEncryptedUnicode('abc', {'secret': 'test'}).center(3) == 'abc'



# Generated at 2022-06-21 00:07:51.164414
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    a = AnsibleVaultEncryptedUnicode("foobar")
    assert not a.isupper()
    a = AnsibleVaultEncryptedUnicode("FOOBAR")
    assert a.isupper()
    a = AnsibleVaultEncryptedUnicode("FOO BAR")
    assert not a.isupper()
    a = AnsibleVaultEncryptedUnicode("FOobar")
    assert not a.isupper()


# Generated at 2022-06-21 00:08:01.943755
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n63633563396537343664343665333063646465346664303062396434626532373032373762376335320a363864393735313331343265383038663262323337626234643333616162343432316463613434660a33626636353433383439303366333965313865306437333436326561343735376438623230373965\n')
    assert avu.is_encrypted() == True


# Generated at 2022-06-21 00:08:10.401377
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    from collections import UserString
    from copy import copy

    import string
    import sys

    class MyString(UserString):
        def translate(self, *args):
            # The original implementation of translate in UserString is flawed:
            # it doesn't use the type of self.data to decide the type for the return value.
            # Adding this method fixes it.
            data = self.data
            if isinstance(data, str):
                return str(data).translate(*args)
            elif isinstance(data, bytes):
                return bytes(data).translate(*args)
            else:
                raise TypeError('translate() expected a string or bytes-like object, '
                        'got %s' % type(data))

    class TestString(MyString):
        yaml_tag = u'!test'

    yaml.add_

# Generated at 2022-06-21 00:08:17.022007
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    assert ('FOO'.isupper() ==
            AnsibleVaultEncryptedUnicode.from_plaintext('FOO',
                                                        vault='placeholder',
                                                        secret='secret').isupper())
    assert ('foo'.isupper() ==
            AnsibleVaultEncryptedUnicode.from_plaintext('foo',
                                                        vault='placeholder',
                                                        secret='secret').isupper())


# Generated at 2022-06-21 00:08:27.676565
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    unicode_string = 'äöü'
    encrypted_string = to_bytes(b'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3565303338343363656136323963356636646336616261366132393165616362396265356430326366\n          6666306138666436623565643938643239366534643665653533353564653038326336393162353366\n          61363131633232356265643866333035\n          ')
    avu = AnsibleVaultEncryptedUnicode(encrypted_string)
    assert avu.__unicode__() == unicode_string


# Generated at 2022-06-21 00:08:32.597938
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    my_str = AnsibleVaultEncryptedUnicode.from_plaintext('abcd', None, None)
    assert my_str.lstrip('ac') == 'bcd'
    assert my_str.lstrip('a') == 'bcd'
    assert my_str.lstrip('') == 'abcd'
    assert my_str.lstrip() == 'abcd'

# Generated at 2022-06-21 00:08:36.382059
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    vault = AnsibleVaultEncryptedUnicode('alpha')
    assert vault.title() == 'Alpha'

# end of AnsibleVaultEncryptedUnicode


# Generated at 2022-06-21 00:08:43.759331
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    # Test that AnsibleVaultEncryptedUnicode.join works with a sequence of AnsibleVaultEncryptedUnicodes
    fst = AnsibleVaultEncryptedUnicode.from_plaintext('file1', vault=None, secret=None)
    snd = AnsibleVaultEncryptedUnicode.from_plaintext('file2', vault=None, secret=None)
    arr = (fst, snd)
    result = ':'.join(arr)
    assert result == 'file1:file2'
    assert isinstance(result, text_type)

# Generated at 2022-06-21 00:08:49.484661
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    secret = 'mysecret'
    plaintext = 'hello world'
    encrypted_obj = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, sys.modules[vault_mod].VaultLib(password=secret), secret)
    assert encrypted_obj.islower()


# Generated at 2022-06-21 00:09:09.882385
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    import vault
    _vault = vault.VaultLib('123')
    assert isinstance(str(AnsibleVaultEncryptedUnicode.from_plaintext(
        'abc', _vault, '123'))+'123', str)



# Generated at 2022-06-21 00:09:12.356800
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    avu_obj = AnsibleVaultEncryptedUnicode('foo')
    assert avu_obj.title() == 'Foo'


# Generated at 2022-06-21 00:09:13.684273
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    assert AnsibleVaultEncryptedUnicode("abc%d") % (123,) == "abc123"



# Generated at 2022-06-21 00:09:24.136870
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret
    vault_secret = get_file_vault_secret(None)
    vault = VaultLib(vault_secret)
    plaintext = "Plaintext"
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, vault_secret)
    assert plaintext == encrypted.lower()

# make sure that the object matches a unicode string
assert text_type('') == ''

# these are the types we'll try to coerce
try:
    import decimal
    decimal_type = decimal.Decimal
except ImportError:
    decimal_type = float


# Generated at 2022-06-21 00:09:33.384437
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    from ansible.parsing.vault import VaultLib
    m = VaultLib(password='testpassword')

# Generated at 2022-06-21 00:09:42.600404
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    class TestAvu(AnsibleVaultEncryptedUnicode):
        def __init__(self, string, width, fillchar=' '):
            AnsibleVaultEncryptedUnicode.__init__(self, string)
            self.width = width
            self.fillchar = fillchar

    avu = TestAvu('  ')

    avu = TestAvu('  ', 5)
    assert avu.rjust()        == '     '

    avu = TestAvu('  ', 5, '0')
    assert avu.rjust()        == '0000 '

    avu = TestAvu('', 5, '0')
    assert avu.rjust()        == '00000'

    avu = TestAvu('', 0, '0')
    assert avu.rjust()        == ''

    av

# Generated at 2022-06-21 00:09:53.385813
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    '''
    Test method __getitem__ of class AnsibleVaultEncryptedUnicode.
    '''

    class Test:
        '''
        Test class to test the AnsibleVaultEncryptedUnicode class.
        '''

        def test_AnsibleVaultEncryptedUnicode___getitem__(self, value, index, expected):
            '''
            Test method __getitem__ for class AnsibleVaultEncryptedUnicode.
            '''
            avu = AnsibleVaultEncryptedUnicode(value)
            assert avu[index] == expected


# Generated at 2022-06-21 00:09:57.412267
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    from ansible.parsing.vault import VaultLib

    secret = 'AnsibleVaultEncryptedUnicode_isupper'
    vault = VaultLib([])
    enc_str = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, secret)
    assert enc_str.isupper() is False



# Generated at 2022-06-21 00:10:09.336677
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    test_data = [
        ('Hello world !', 'Hello world !'),
        ('Hello world !', 'This is not Hello world !'),
        ('You can\'t see this, this is encrypted!', 'This too'),
    ]
    for (clear_data, test_val) in test_data:
        assert AnsibleVaultEncryptedUnicode(clear_data).__ne__(test_val) == True
        assert AnsibleVaultEncryptedUnicode(clear_data).__ne__(AnsibleVaultEncryptedUnicode(test_val)) == True
        assert AnsibleVaultEncryptedUnicode(clear_data).__eq__(clear_data) == True

# Generated at 2022-06-21 00:10:15.575613
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    """
    Test method __len__ of class AnsibleVaultEncryptedUnicode
    """
    # string = 'a b c'
    # class_instance = AnsibleVaultEncryptedUnicode(string)
    # assert isinstance(class_instance, AnsibleVaultEncryptedUnicode)
    # assert len(class_instance) == len(string)
    pass


# Generated at 2022-06-21 00:10:37.969273
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.rjust(5, '@') == '@@@test'


# Generated at 2022-06-21 00:10:45.924381
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    from ansible.parsing.vault import VaultLib
    secret = b'c' * 16
    vault = VaultLib([secret])
    password = vault.new_password()
    encrypted_text = AnsibleVaultEncryptedUnicode.from_plaintext("This is a test", vault, secret)
    encrypted_text.vault = vault
    assert str(encrypted_text.__radd__("Reverse add")) == "Reverse add" + str(encrypted_text.data)



# Generated at 2022-06-21 00:10:50.758279
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    # Python 2 and 3 both have str.center which returns a str type
    # but the Python 2 version does not accept a keyword argument
    avu = AnsibleVaultEncryptedUnicode('')
    assert avu.center(5, fillchar='-') == '-----'


# Generated at 2022-06-21 00:10:59.982728
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    from ansible.parsing.vault import VaultLib
    vault_obj = VaultLib(password='ansible')
    test_str = "abcdefg"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(test_str, vault_obj, None)
    try:
        assert avu.index("ab") == 0
        assert avu.index("fg") == 5
    except Exception:
        assert False
    try:
        idx = avu.index("z")
    except ValueError:
        pass
    except Exception:
        assert False
    assert avu.index("ab", 0, 2) == 0
    assert avu.index("ab", 0, 2) == 0
    assert avu.index("ab", 1, 2) == -1
