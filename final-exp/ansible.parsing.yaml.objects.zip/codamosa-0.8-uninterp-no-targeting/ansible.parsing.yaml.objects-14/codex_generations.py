

# Generated at 2022-06-21 00:01:19.721683
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    assert AnsibleBaseYAMLObject()


# Generated at 2022-06-21 00:01:27.957893
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    class MockVault(object):
        def __init__(self):
            self.is_encrypted = lambda x: False
            self.decrypt = lambda x: x
            self.encrypt = lambda x, y: x
            self.is_encrypted = lambda x: False
            self.is_binary_file = lambda x: False

    secret = 'secret'
    not_numeric_strings = ['1,3', '1.3', "1'3", '1+3', '-1', '1-', '1_3', ]

# Generated at 2022-06-21 00:01:38.889251
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # This test case is just to help translator and py3-compatible
    plaintext = 'a'
    ciphertext = 'b'

    avu1 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu2 = AnsibleVaultEncryptedUnicode(ciphertext)

    # avu1 + avu2
    assert (isinstance(avu1 + avu2, AnsibleVaultEncryptedUnicode) == True)

    # avu1 + plaintext
    assert (isinstance(avu1 + plaintext, AnsibleVaultEncryptedUnicode) == True)

    # plaintext + avu1
    assert (isinstance(plaintext + avu1, AnsibleVaultEncryptedUnicode) == True)


# Generated at 2022-06-21 00:01:48.073408
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    from ansible.parsing.vault import VaultLib
    encobj = AnsibleVaultEncryptedUnicode.from_plaintext('foo', VaultLib(), 'vault_password')
    assert encobj.lstrip('f') == 'oo'
    assert encobj.lstrip('o') == 'foo'
    assert encobj.lstrip('fo') == 'o'
    assert encobj.lstrip('g') == 'foo'
    assert encobj.lstrip('foo') == ''
    assert encobj.lstrip('') == 'foo'
    assert encobj.lstrip('z') == 'foo'


# Generated at 2022-06-21 00:01:52.721931
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    assert (AnsibleVaultEncryptedUnicode('abc').capitalize() == text_type('Abc'))
    assert (AnsibleVaultEncryptedUnicode('abc').capitalize() != text_type('abc'))
    assert (AnsibleVaultEncryptedUnicode('1bc').capitalize() == text_type('1bc'))


# Generated at 2022-06-21 00:01:54.884244
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    s = AnsibleVaultEncryptedUnicode("test")
    actual_result = s.ljust(10, "A")
    assert actual_result == "testAAAAA"


# Generated at 2022-06-21 00:02:03.262818
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    test_class = AnsibleVaultEncryptedUnicode("foo")
    actual = test_class.rjust(5, "*")
    expected = "**foo"
    assert actual == expected


_DEFAULT_SCALAR_TAG = u'tag:yaml.org,2002:str'
_DEFAULT_SEQUENCE_TAG = u'tag:yaml.org,2002:seq'
_DEFAULT_MAPPING_TAG = u'tag:yaml.org,2002:map'


# Generated at 2022-06-21 00:02:14.327497
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    # pylint: disable=missing-docstring
    from ansible import errors
    from ansible.parsing.vault import VaultLib, VaultEditor

    class FakeVaultLib(VaultLib):

        class FakeVaultEditor(VaultEditor):

            def __init__(self):
                pass

            def __enter__(self):
                return self

            def __exit__(self, type, value, traceback):
                pass

        def __init__(self, password=None):
            cipher = 'AES256'
            version = 1
            self._key = '123456'

        def _open_write(self):
            return self.FakeVaultEditor()

        def _open_read(self):
            return self.FakeVaultEditor()


# Generated at 2022-06-21 00:02:17.546687
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    ciphertext = 'test'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu.rindex('t', 0, 2) == 0


# Generated at 2022-06-21 00:02:29.975236
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    ansible_vault_password = 'testpassword'
    plaintext = ''
    for i in range(1, 1000):
        plaintext += '%d ' % i
    avueu = AnsibleVaultEncryptedUnicode.from_plaintext(to_bytes(plaintext), yaml.vault.VaultLib(ansible_vault_password), ansible_vault_password)
    # Transform integer numbers from 0 to 100 to Z
    ciphertext = avueu.replace('0', 'Z')
    for i in range(1, 100):
        ciphertext = ciphertext.replace('%d' % i, 'Z')
    # Transform integer numbers from 101 to 998 to z
    for i in range(101, 999):
        ciphertext = ciphertext.replace('%d' % i, 'z')
    #

# Generated at 2022-06-21 00:02:41.715003
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    '''
    isalpha test.
    '''

    # ansible_vault_password_file = '/home/mike/ansible-vault-password'
    # vault = ansibleVaultLib.VaultLib(password_file=ansible_vault_password_file)

    # ciphertext = vault.encrypt('abcdefghijklmnopqrstuvwxyz\n', 'password123')
    # ciphertext = vault.encrypt('ABCDEFGHIJKLMNOPQRSTUVXYZ\n', 'password123')

    # ciphertext = vault.encrypt('abcdefghijklmnopqrstuvwxyz\nABCDEFGHIJKLMNOPQRSTUVXYZ\n', 'password123')

    ciphertext = vault.encrypt('abc \n', 'password123')

# Generated at 2022-06-21 00:02:53.680265
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    from ansible.parsing.vault import VaultLib
    _secret = '$ecret'
    _vault = VaultLib(_secret)
    as_text = '''\
    line1
    line2
    line3'''
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(as_text, _vault, _secret)
    lines = avu.splitlines()
    assert len(lines) == 3
    assert lines[0] == 'line1'
    assert lines[1] == 'line2'
    assert lines[2] == 'line3'

    as_text = '''\
    line1
    line2
    line3
    '''

# Generated at 2022-06-21 00:03:03.291736
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    # It is reasonable to expect that this method always returns the data as
    # a string by default without having to pass in the encoding:
    plaintext = 'this is a plaintext string'
    secret = 'password'

# Generated at 2022-06-21 00:03:10.946904
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    from ansible.parsing.vault import VaultLib
    # Create a vault and load the vault password
    vault = VaultLib('qwertyuiop')
    # Create a AnsibleVaultEncryptedUnicode object and assign the vault
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello world', vault, 'qwertyuiop')
    # test the lstrip method
    assert avu.lstrip() == 'hello world'

# Generated at 2022-06-21 00:03:19.864607
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    secret = "testsecret"
    vault = VaultLib(password=secret)

    plaintext1 = "1.0"
    plaintext2 = "1.0+2.0j"
    plaintext3 = "1.0-2.0j"

    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext1, vault, secret)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext2, vault, secret)
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext3, vault, secret)

    assert complex(avu1) == complex(plaintext1)

# Generated at 2022-06-21 00:03:25.470201
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(None)
    with vault.lotsa_secrets(1) as secret:
        av = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, secret)
        assert 'foo' == av.__unicode__()


# Generated at 2022-06-21 00:03:36.832268
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    class MyAnsibleYAMLObject(AnsibleBaseYAMLObject):
        pass

    # Verify empty object
    obj = MyAnsibleYAMLObject()
    assert obj._data_source is None
    assert obj._line_number == 0
    assert obj._column_number == 0
    assert obj.ansible_pos is None

    # Verify that setting ansible_pos also sets _data_source, _line_number,
    # and _column_number
    obj.ansible_pos = ('file', 5, 10)
    assert obj._data_source == 'file'
    assert obj._line_number == 5
    assert obj._column_number == 10
    assert obj.ansible_pos == ('file', 5, 10)


# Generated at 2022-06-21 00:03:40.251166
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    ss = AnsibleVaultEncryptedUnicode("ciphertext")
    if ss.count("a") != 0:
        raise Exception("AnsibleVaultEncryptedUnicode string count error")



# Generated at 2022-06-21 00:03:52.520791
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    assert AnsibleVaultEncryptedUnicode(b'a').rfind(b'a') == 0
    assert AnsibleVaultEncryptedUnicode(b'a').rfind(b'b') == -1
    assert AnsibleVaultEncryptedUnicode(b'a').rfind(b'a', 1) == -1
    assert AnsibleVaultEncryptedUnicode(b'a').rfind(b'a', 0, 1) == 0
    assert AnsibleVaultEncryptedUnicode(b'a').rfind(b'b', 1) == -1
    assert AnsibleVaultEncryptedUnicode(b'ab').rfind(b'a') == 0
    assert AnsibleVaultEncryptedUnicode(b'ab').rfind(b'ab') == 0
    assert AnsibleVault

# Generated at 2022-06-21 00:03:59.827816
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    class A(object):
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
    a = A("A", "B", "C")
    result = AnsibleVaultEncryptedUnicode("{a}:{b}:{c}").format_map(vars(a))
    assert result == 'A:B:C'


# Generated at 2022-06-21 00:04:23.629850
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    # build a mock object to test with
    test_object = type('',(object,),{})()
    test_object.decrypt = lambda x: x
    test_object.is_encrypted = lambda x: False

    # ansible_vault_text is an AnsibleVaultEncryptedUnicode that is unencrypted
    ansible_vault_text = AnsibleVaultEncryptedUnicode(ciphertext=u'hüllo')
    ansible_vault_text.vault = test_object

    # rjust should pad to the left with the given string
    assert '  hüllo' == ansible_vault_text.rjust(7, u' ')
    # rjust should pad to the left with spaces if no fillchar is given
    assert '  hüllo' == ansible_vault_text

# Generated at 2022-06-21 00:04:34.375307
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''
    Test method __ne__ of class AnsibleVaultEncryptedUnicode
    '''
    # xxx: Test only compares unicode string,
    # xxx: Must add more type to compare.
    test_var_name = ['qqq', u'qqq', 'www', u'www']

    avue = AnsibleVaultEncryptedUnicode('xxx')
    avue.vault = 'xxx'
    avue.vault.is_encrypted = lambda c: True
    avue.vault.decrypt = lambda c: 'xxx'

    for var in test_var_name:
        assert avue.__ne__(var) == False, 'Failed to compare AnsibleVaultEncryptedUnicode with unicode string'


# Generated at 2022-06-21 00:04:41.901758
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    password = b'vault_password'
    plaintext_unicode = text_type('plaintext_unicode')

# Generated at 2022-06-21 00:04:46.699624
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    """test for __int__"""
    avu = AnsibleVaultEncryptedUnicode("1")
    i = int(avu)
    assert i == 1, 'should be 1'
    assert type(i) is int, 'should be int'



# Generated at 2022-06-21 00:04:58.433110
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    avu = AnsibleVaultEncryptedUnicode("this is ascii")
    assert avu.encode('utf8') == b"this is ascii"
    assert avu.encode('utf16') == b"\xff\xfet\x00h\x00i\x00s\x00 \x00i\x00s\x00 \x00a\x00s\x00c\x00i\x00i\x00"
    assert avu.encode('utf16', 'strict') == b"\xff\xfet\x00h\x00i\x00s\x00 \x00i\x00s\x00 \x00a\x00s\x00c\x00i\x00i\x00"

# Generated at 2022-06-21 00:05:03.785702
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = bytes(b'encryptme')
    ciphertext = vault.encrypt(u"hello world", secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.title() == u'Hello World'



# Generated at 2022-06-21 00:05:07.947554
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    avu_string = AnsibleVaultEncryptedUnicode(b'abc123')
    avu_empty = AnsibleVaultEncryptedUnicode(b'')
    assert(avu_string.isalnum() == 'abc123'.isalnum())
    assert(avu_empty.isalnum() == ''.isalnum())
    # This fails
    # assert(avu.isalnum() == b'abc123'.isalnum())


# Generated at 2022-06-21 00:05:10.780341
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    assert not AnsibleVaultEncryptedUnicode("36,").isdigit()
    assert AnsibleVaultEncryptedUnicode("36").isdigit()

# Generated at 2022-06-21 00:05:14.821888
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    a = AnsibleVaultEncryptedUnicode.from_plaintext('format test', vault=None, secret='secret')
    assert "format test" == a.format()
    assert "format test" == a.format("{}")


# Generated at 2022-06-21 00:05:18.299697
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    # test for method __float__()
    i = AnsibleVaultEncryptedUnicode("23.1")
    f = float(i)
    assert isinstance(f, float)
    assert f == 23.1


# Generated at 2022-06-21 00:05:36.103635
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    aveu = AnsibleVaultEncryptedUnicode('test')
    assert aveu.capitalize() == 'Test'


# Generated at 2022-06-21 00:05:48.064370
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    class TestVault:
        def is_encrypted(self, data):
            return True
        def decrypt(self, data):
            return b'foo'

    test_vault = TestVault()

    avue1 = AnsibleVaultEncryptedUnicode(b'foo')
    avue1.vault = test_vault

    avue2 = AnsibleVaultEncryptedUnicode(b'foo')
    avue2.vault = test_vault

    avue3 = AnsibleVaultEncryptedUnicode(b'foo2')
    avue3.vault = test_vault

    assert(avue1 >= avue2)
    assert(avue1 >= b'foo')
    assert(avue1 >= u'foo')
    assert(avue1 >= 'foo')

# Generated at 2022-06-21 00:05:57.997797
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    text = "hello %s"
    ansibleVaultEncryptedUnicode = AnsibleVaultEncryptedUnicode('hello')
    assert text % ansibleVaultEncryptedUnicode == 'hello hello'

    bytes = b'hello %s'
    ansibleVaultEncryptedUnicode = AnsibleVaultEncryptedUnicode('hello')
    assert bytes % ansibleVaultEncryptedUnicode == b'hello hello'

    text = 'hello %s'
    ansibleVaultEncryptedUnicode = AnsibleVaultEncryptedUnicode('hello')
    assert text % ansibleVaultEncryptedUnicode == 'hello hello'



# Generated at 2022-06-21 00:06:02.683249
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    # Arrange
    avu = AnsibleVaultEncryptedUnicode()
    avu.data = 'abc'
    expected = '-abc'
    width = 4
    actual = ''

    # Act
    actual = avu.zfill(width)

    # Assert
    assert actual == expected

# Generated at 2022-06-21 00:06:13.845111
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():

    import ansible.parsing.vault

    # Test that __radd__ works with text_type
    secret = b'A secret unicode string'
    password = b'ansible'
    ciphertext_bytes = ansible.parsing.vault.encrypt_bytes(secret, password)

    test_data = [
        u'foo',
        to_text(secret, errors='surrogate_or_strict'),
        to_text(ciphertext_bytes, errors='surrogate_or_strict'),
    ]

    for s in test_data:
        assert to_text(s) == AnsibleVaultEncryptedUnicode.from_plaintext(s, ansible.parsing.vault.VaultLib(password), None).data



# Generated at 2022-06-21 00:06:20.948674
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    import string
    import unittest.mock as mock
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import get_file_vault_secret
    import json

    def new_VaultLib():
        vault = VaultLib([])
        return vault

    def mock_get_file_vault_secret(secret_path):
        return get_file_vault_secret(secret_path)

    def mock_VaultSecret(secret):
        return VaultSecret(secret)

    def mock_decrypt(data, obj=None):
        return to_text(json.dumps(
            {"pwd": "password", "key": "value", "array": ["item1", "item2"]}))

   

# Generated at 2022-06-21 00:06:25.608381
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    am = AnsibleMapping(foo='bar', baz='boo')
    assert am == dict(foo='bar', baz='boo')

    assert am.foo == 'bar'
    assert am.baz == 'boo'



# Generated at 2022-06-21 00:06:36.140618
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    '''
    Test isdecimal method of the AnsibleVaultEncryptedUnicode class

    Did a case by case test to cover all the code

    '''
    # Case 1
    avue = AnsibleVaultEncryptedUnicode('dummy')
    avue.data = '00'
    assert(avue.isdecimal() == True)

    # Case 2
    avue.data = '00.00'
    assert(avue.isdecimal() == False)

    # Case 3
    avue.data = '00 00'
    assert(avue.isdecimal() == False)

    # Case 4
    avue.data = '0'
    assert(avue.isdecimal() == True)

    # Case 5
    avue.data = '0.0'

# Generated at 2022-06-21 00:06:37.985354
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    string = AnsibleVaultEncryptedUnicode("hello world")
    assert string.upper() == "HELLO WORLD"

# Generated at 2022-06-21 00:06:42.028867
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    from ansible.vault import VaultLib

    # Create a vault with a password
    vault = VaultLib('test')

    # Create a AnsibleVaultEncryptedUnicode
    encrypted_str = AnsibleVaultEncryptedUnicode.from_plaintext(' this is a test ', vault, 'test')

    # Test the strip behaviour
    assert encrypted_str.strip() == 'this is a test'


# Generated at 2022-06-21 00:07:01.171528
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    import crypt
    crypt_data = crypt.AnsibleVaultEncryptedUnicode('fOO')
    float_data = float(crypt_data)
    assert(float_data == float('fOO'))


# Generated at 2022-06-21 00:07:03.635877
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    u = AnsibleVaultEncryptedUnicode('Aa')
    assert u.lower() == 'aa'


# Generated at 2022-06-21 00:07:15.035765
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    class TestVault:
        def __init__(self):
            self.is_encrypted = lambda x, _: True
            self.decrypt = lambda x, _: x
            self.encrypt = lambda x, _: x
    test_vault = TestVault()
    test_enc = AnsibleVaultEncryptedUnicode.from_plaintext("test_enc", test_vault, "test_secret")
    test_plain = u"test_plain"

    #Add AnsibleVaultEncryptedUnicode to plain
    test_plain_add_enc = test_plain.__add__(test_enc)
    assert test_plain_add_enc == "test_plaintest_enc"

    #Add plain to AnsibleVaultEncryptedUnicode
    test_enc_add_plain = test_enc.__

# Generated at 2022-06-21 00:07:20.171158
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    class Uni(AnsibleBaseYAMLObject, text_type):
        pass
    a = Uni(u'a')
    a.ansible_pos = (u'host1', 1, 2)
    assert a._data_source == u'host1'
    assert a._line_number == 1
    assert a._column_number == 2
    assert a.ansible_pos == (u'host1', 1, 2)



# Generated at 2022-06-21 00:07:25.901515
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    assert AnsibleVaultEncryptedUnicode('').casefold() == ''
    assert AnsibleVaultEncryptedUnicode('ä').casefold() == 'ä'
    # German chars
    assert AnsibleVaultEncryptedUnicode('ß').casefold() == 'ss'
    assert AnsibleVaultEncryptedUnicode('äu').casefold() == 'äu'
    # dot bellow
    assert AnsibleVaultEncryptedUnicode('ḥ').casefold() == 'ḥ'
    # Greek chars

# Generated at 2022-06-21 00:07:32.112452
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:07:37.382027
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    string = 'the quick brown {0} jumped over the lazy {1}'.format
    test = AnsibleVaultEncryptedUnicode().from_plaintext('fox', None, None)
    test2 = AnsibleVaultEncryptedUnicode().from_plaintext('dog', None, None)
    assert string(test, test2) == string('fox', 'dog')

# Generated at 2022-06-21 00:07:42.080619
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    class DummyVault(object):

        def decrypt(self, *args, **kwargs):
            return "decrypted"

    avu = AnsibleVaultEncryptedUnicode("foo")
    avu.vault = DummyVault()
    assert avu.expandtabs(3).data == "decrypted"



# Generated at 2022-06-21 00:07:50.149803
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    '''
    Test the isprintable method of class AnsibleVaultEncryptedUnicode.
    '''
    # Test data:
    # The first list item is the string to be tested as is.
    # The second list item is the string to be tested after decoding from
    # UTF-8.
    # The third list item is the reference result for the unencoded string.
    # The fourth list item is the reference result for the encoded string.
    # The fifth list item is the expected string representation of the
    # encoded string.
    # References:
    # https://docs.python.org/3/library/stdtypes.html#str.isprintable
    # https://docs.python.org/2/library/stdtypes.html#str.isprintable

# Generated at 2022-06-21 00:08:02.670114
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    '''
    Verify correct operation of the constructor of class AnsibleBaseYAMLObject
    '''

    # Instantiate an instance of class AnsibleBaseYAMLObject
    a = AnsibleBaseYAMLObject()

    # Verify that a is an instance of AnsibleBaseYAMLObject
    if isinstance(a, AnsibleBaseYAMLObject):
        print('Test 1 passed.')
    else:
        print('Test 1 failed.')

    # Verify that a is an instance of object
    if isinstance(a, object):
        print('Test 2 passed.')
    else:
        print('Test 2 failed.')

    # Verify that a is not an an instance of str
    if isinstance(a, str):
        print('Test 3 failed.')
    else:
        print('Test 3 passed.')


# Unit

# Generated at 2022-06-21 00:09:03.649597
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    # create an AnsibleVaultEncryptedUnicode object with text "test"
    avu1 = AnsibleVaultEncryptedUnicode("test")
    # create an AnsibleVaultEncryptedUnicode object with text "test"
    avu2 = AnsibleVaultEncryptedUnicode("test")
    # create an AnsibleVaultEncryptedUnicode object with text "test"
    avu3 = AnsibleVaultEncryptedUnicode("test")

    # create a list of avu objects
    avu_list = [avu1, avu2, avu3]

    # join list with AnsibleVaultEncryptedUnicode object
    avu_joined_list = avu1.join(avu_list)

    # check if join correctly

# Generated at 2022-06-21 00:09:15.198086
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password='test')

    # Check if vaulted string can be stripped
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('Hello World ')
    avu.vault = vault
    assert avu.strip() == 'Hello World'

    # Check if constant can be stripped
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(' Hello World ')
    avu.vault = vault
    assert avu.strip(' ') == 'Hello World'

    # Check if variable can be stripped
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(' Hello World ')
    avu.vault = vault
    whitespace = ' '

# Generated at 2022-06-21 00:09:22.556355
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    if six.PY2:
        expected = u'\N{LATIN SMALL LETTER SHARP S}'
        avu = AnsibleVaultEncryptedUnicode(u'\u00df', vault)
        assert avu.casefold() == expected
    else:
        expected = u'\N{LATIN SMALL LETTER SHARP S}'
        avu = AnsibleVaultEncryptedUnicode('\u00df', vault)
        assert avu.casefold() == expected


# Generated at 2022-06-21 00:09:28.159814
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    s = AnsibleVaultEncryptedUnicode("this secret is sensitive to leading and trailing spaces.       \n")
    assert s.strip() == "this secret is sensitive to leading and trailing spaces.       \n"
    assert str(s) == "this secret is sensitive to leading and trailing spaces.       \n"
    assert s.startswith("this secret is sensitive to leading and trailing spaces.       \n")
    assert s.endswith("this secret is sensitive to leading and trailing spaces.       \n")
    assert s.startswith("this")

# Generated at 2022-06-21 00:09:35.353553
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib('test')
    secret = 'pass'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('password', vault, secret)
    assert avu.find('ord') == 3
    assert avu.find('pass') == 0
    assert avu.find('sspas') == -1


# Generated at 2022-06-21 00:09:43.118511
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    # Test for title() method.
    # Note: title() method does not work for unicode strings with some punctuation characters or non-english letters.
    # For these cases no test is required.
    avu = AnsibleVaultEncryptedUnicode(u'test')
    assert avu.title() == u'Test'
    avu = AnsibleVaultEncryptedUnicode(u'Test')
    assert avu.title() == u'Test'
    avu = AnsibleVaultEncryptedUnicode(u'test.test')
    assert avu.title() == u'Test.test'
    avu = AnsibleVaultEncryptedUnicode(u'test.TEST')
    assert avu.title() == u'Test.TEST'



# Generated at 2022-06-21 00:09:52.007193
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    """
    >>> unicode = "rA5r&"
    >>> type(unicode)
    <class 'str'>
    >>> secret = "youknowmysecret"
    >>> a = AnsibleVaultEncryptedUnicode.from_plaintext(unicode, vault=VaultLib(secret), secret=secret)
    >>> type(a)
    <class '__main__.AnsibleVaultEncryptedUnicode'>
    >>> type(a.data)
    <class 'str'>
    >>> a.index("r")
    2
    >>> a.index("&")
    5
    >>> a.index("A")
    Traceback (most recent call last):
    ...
    ValueError: substring not found
    """


# Generated at 2022-06-21 00:09:53.837564
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    value = AnsibleVaultEncryptedUnicode(b'test_value')
    return len(value) == len('test_value')


# Generated at 2022-06-21 00:09:55.870802
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    text = AnsibleVaultEncryptedUnicode('test')
    assert text.encode('utf-8') == b'test'


# Generated at 2022-06-21 00:10:07.798033
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    avu = AnsibleVaultEncryptedUnicode("\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09")
    if avu.count(AnsibleVaultEncryptedUnicode("\x00")) != 1:
        raise Exception("AnsibleVaultEncryptedUnicode method count failed")
    if avu.count(AnsibleVaultEncryptedUnicode("\x01")) != 1:
        raise Exception("AnsibleVaultEncryptedUnicode method count failed")
    if avu.count(AnsibleVaultEncryptedUnicode("\x02")) != 1:
        raise Exception("AnsibleVaultEncryptedUnicode method count failed")