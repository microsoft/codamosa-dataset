

# Generated at 2022-06-21 00:01:26.304912
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    from ansible.vault import VaultLib
    vault = VaultLib([])
    plaintext = u'I have {x} dollars in my {y} account'
    ciphertext = vault.encrypt(plaintext, 'mock password')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu == plaintext, 'Unsafe compare of AnsibleVaultEncryptedUnicode objects.'
    assert avu == AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, 'mock password'), 'Unsafe compare of AnsibleVaultEncryptedUnicode objects.'


# Generated at 2022-06-21 00:01:33.097875
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    class DummyVault(object):
        def encrypt(self, seq, secret):
            return seq
        def decrypt(self, ciphertext, obj=None):
            return ciphertext
        def is_encrypted(self, string):
            return False
    vault = DummyVault()
    avue1 = AnsibleVaultEncryptedUnicode.from_plaintext('123', vault, 0)
    assert to_text(avue1.zfill(5)) == '00123'

# Generated at 2022-06-21 00:01:39.735070
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    ciphertext = b'\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert int(avu) == 1

# Generated at 2022-06-21 00:01:50.828522
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    vault = AnsibleVaultEncryptedUnicode(b'the_vault')
    vault.vault = vault
    s = vault
    # test rpartition
    res = s.rpartition(b'_')
    assert isinstance(res, tuple)
    for e in res:
        assert isinstance(e, AnsibleVaultEncryptedUnicode)
    assert res == (b'the', b'_', b'vault')
    res = s.rpartition(b'_vault')
    assert res == (b'the', b'_vault', b'')
    res = s.rpartition(b'vault')
    assert res == (b'the_', b'vault', b'')
    res = s.rpartition(b'z')

# Generated at 2022-06-21 00:01:53.894093
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    assert AnsibleVaultEncryptedUnicode('abc') * 3 == 'abcabcabc'
    assert AnsibleVaultEncryptedUnicode('abc') * 0 == ''
    assert 3 * AnsibleVaultEncryptedUnicode('abc') == 'abcabcabc'


# Generated at 2022-06-21 00:02:03.200059
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    from ansible.parsing.vault import VaultLib
    import re

    vaultpassword = "ansible"
    secret = b'\x00' * 16
    vault = VaultLib(vaultpassword)

    teststring = b'HELLO'
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(teststring, vault, secret)

    myregex = re.compile(r"([A-Z])")

    assert(myregex.match(avu1) is not None)



# Generated at 2022-06-21 00:02:08.445593
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    """
    Tests if AnsibleVaultEncryptedUnicode().isspace corresponds with the behavior of
    unicode().isspace.
    """
    for char in string.printable:
        encrypted_char = AnsibleVaultEncryptedUnicode(char)
        assert encrypted_char.isspace() == char.isspace()



# Generated at 2022-06-21 00:02:17.574295
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():

    # Correct behavior for Args == None
    t = AnsibleVaultEncryptedUnicode("")
    r = t.isspace()
    assert(r==False)

    t = AnsibleVaultEncryptedUnicode(" ")
    r = t.isspace()
    assert(r==True)

    t = AnsibleVaultEncryptedUnicode("\t")
    r = t.isspace()
    assert(r==True)

    t = AnsibleVaultEncryptedUnicode("\n")
    r = t.isspace()
    assert(r==True)

    t = AnsibleVaultEncryptedUnicode("\v")
    r = t.isspace()
    assert(r==True)

    t = AnsibleVaultEncryptedUnicode("\f")

# Generated at 2022-06-21 00:02:21.002125
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    res = AnsibleVaultEncryptedUnicode(u'abc')
    res2 = res.join(text_type('def'))
    assert isinstance(res2, text_type)


# Generated at 2022-06-21 00:02:33.789697
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError
    from ansible.parsing.vault import VaultSecret

    vault_instance = VaultLib([])
    vault_secret = VaultSecret('secret')

    # Initialize AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(
        "hello", vault_instance, vault_secret
    )
    avu.vault = vault_instance

    # Compare two AnsibleVaultEncryptedUnicode
    other = AnsibleVaultEncryptedUnicode.from_plaintext(
        "world", vault_instance, vault_secret
    )
    other.vault = vault_instance
    assert str(avu) < str(other)

# Generated at 2022-06-21 00:02:43.300417
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    s = '_'*50
    s1 = AnsibleVaultEncryptedUnicode(s)
    s2 = AnsibleVaultEncryptedUnicode(s+'A')
    print(s1.rindex('_'))
    print(s2.rindex('_'))


# Generated at 2022-06-21 00:02:54.745960
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    """
    >>> v1 = AnsibleVaultEncryptedUnicode("This is a test")
    >>> v1.ljust(10)
    'This is a test    '
    >>> v1.ljust(10, 'a')
    'This is a testaaaaaa'
    >>> v1.ljust(10, 'ab')
    'This is a testaaaaaaaaaa'
    >>> v1.ljust(14, 'ab')
    'This is a testaaaaaaaabbbbabbabbabbabbabbabbabb'
    >>> v1.ljust(9)
    Traceback (most recent call last):
    ...
    ValueError: ljust argument 2 must be >= 0
    """


# Generated at 2022-06-21 00:02:58.821268
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    avu = AnsibleVaultEncryptedUnicode('test_string')
    assert avu.title() == 'Test_String'
    assert isinstance(avu.title(), AnsibleVaultEncryptedUnicode)

yaml.add_representer(AnsibleVaultEncryptedUnicode, lambda dumper, data: dumper.represent_scalar(data.yaml_tag, data.encode('utf-8'), style='>'))
yaml.add_constructor('!vault', lambda loader, node: AnsibleVaultEncryptedUnicode(to_text(loader.construct_scalar(node), errors='strict')))


# Generated at 2022-06-21 00:03:07.070410
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:03:18.503025
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    assert "1" in AnsibleVaultEncryptedUnicode.from_plaintext("1", None, None)
    assert "1" not in AnsibleVaultEncryptedUnicode.from_plaintext("2", None, None)
    assert AnsibleVaultEncryptedUnicode.from_plaintext("1", None, None) in "12"
    assert AnsibleVaultEncryptedUnicode.from_plaintext("2", None, None) not in "12"
    assert AnsibleVaultEncryptedUnicode.from_plaintext("1", None, None) not in AnsibleVaultEncryptedUnicode.from_plaintext("2", None, None)
    assert "1" not in AnsibleVaultEncryptedUnicode.from_plaintext("2", None, None)
    assert "2" not in Ansible

# Generated at 2022-06-21 00:03:27.936575
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    # Vault is not required for this test
    vault = None
    secret = ''
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext("", vault, secret)
    assert encrypted.__class__ == AnsibleVaultEncryptedUnicode
    assert encrypted.isspace() == False
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext("\t", vault, secret)
    assert encrypted.isspace() == True
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(" ", vault, secret)
    assert encrypted.isspace() == True


# Generated at 2022-06-21 00:03:29.464653
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    '''
    Test AnsibleVaultEncryptedUnicode.__mul__
    '''
    pass


# Generated at 2022-06-21 00:03:34.878951
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    """Test method __gt__ of class AnsibleVaultEncryptedUnicode"""
    s1 = AnsibleVaultEncryptedUnicode("abc")
    s2 = AnsibleVaultEncryptedUnicode("abd")
    assert s1 > "abd"
    assert not s1 > s2
    assert not s1 > "abc"



# Generated at 2022-06-21 00:03:42.486932
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    se = "teststring"
    secret = "hello"

# Generated at 2022-06-21 00:03:53.409279
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    join_strings = [
        u'el',
        u' phont',
        u' el',
        u' pheesha',
        u' yse',
        u' phont',
        u' el',
        u' pheesha',
        u' yse',
    ]

    # Unit test for method join of class AnsibleVaultEncryptedUnicode
    avueu = AnsibleVaultEncryptedUnicode('foo bar')
    join_strings[0] = avueu
    join_result = AnsibleVaultEncryptedUnicode('el phont el pheesha yse phont el pheesha yse')
    assert join_result == u''.join(join_strings)


# Generated at 2022-06-21 00:04:08.115663
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    # This is a separate unit test because the method format is overwritten as a class method
    # and not inherited from the super class (collections.UserString).
    # For that reason it needs special attention.

    from .vault import VaultLib
    vault = VaultLib([])

    strpassword = type(str("str password"))
    porder = [
        (strpassword, 'secret'),
        (AnsibleVaultEncryptedUnicode.from_plaintext(str("secret"), vault, str("secret")), 'secret'),
    ]

    # Test all types as positional arguments

# Generated at 2022-06-21 00:04:19.742897
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    avu = AnsibleVaultEncryptedUnicode('')
    assert avu.endswith('')
    assert not avu.endswith('a')
    avu.data = 'abc'
    assert avu.endswith('c')
    assert not avu.endswith('b')
    assert avu.endswith('')
    assert avu.endswith('abc')
    assert not avu.endswith('abcd')
    assert avu.endswith('BC', 1, 3)

    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1.endswith(avu2)
    avu2.data = 'b'
    assert not avu1

# Generated at 2022-06-21 00:04:29.177209
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    avu = AnsibleVaultEncryptedUnicode('blah\tblah\tblah')
    assert avu.expandtabs(10) == 'blah     blah     blah'


try:
    # On Python 3, ``collections.UserString`` doesn't implement the entire
    # ``collections.Sequence`` interface.  This can be removed when we drop
    # support for Python 3.4 (see ``AnsibleVaultEncryptedUnicode.__reversed__``)
    for method in ['index', 'count', '__getitem__']:
        setattr(AnsibleVaultEncryptedUnicode, method,
            getattr(Sequence, method))
except AttributeError:
    pass


# Generated at 2022-06-21 00:04:34.055379
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    obj = AnsibleVaultEncryptedUnicode(b"Hello world!")
    assert obj.rpartition(' ') == ('Hello world', ' ', '!')


# Generated at 2022-06-21 00:04:41.780974
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    # Since AnsibleVaultEncryptedUnicode.join is implemented similar to the
    # original str.join method, it should behave similar to str.join
    c1 = AnsibleVaultEncryptedUnicode
    c2 = str

    # Generate a random string
    import random
    s = ''.join(random.choice(string.ascii_letters) for _ in range(10))
    assert(c1(s).join(['foo', 'bar', 'baz']) == c2(s).join(['foo', 'bar', 'baz']))
    assert(c1(s).join(c1('foo'), c1('bar'), c1('baz')) == c2(s).join('foo', 'bar', 'baz'))

# Generated at 2022-06-21 00:04:54.569690
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    from ansible.parsing.vault import VaultLib

    secret = 'some secret'
    vault = VaultLib([])

    # Password 'some secret' will be used for encrypting and decrypting
    # '{msg}' is password
    # The same password will be used for encrypting and decrypting.

    avue = AnsibleVaultEncryptedUnicode.from_plaintext('{msg}', vault, secret)

    # Assertions for the success case
    # 1. The resultant object is a AnsibleVaultEncryptedUnicode
    # 2. The object can be formatted using format_map
    # 3. The object should be encrypted
    # 4. The object can be re-encrypted
    # 5. The object can be decrypted
    assert (isinstance(avue, AnsibleVaultEncryptedUnicode))
   

# Generated at 2022-06-21 00:05:04.984941
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():

    # Test no newline at end of string
    avu = AnsibleVaultEncryptedUnicode("first line\nsecond line")
    assert avu.data == "first line\nsecond line"
    assert avu.splitlines() == ["first line", "second line"]
    assert avu.splitlines(True) == ["first line\n", "second line"]

    # Test newline at end of string
    avu = AnsibleVaultEncryptedUnicode("first line\nsecond line\n")
    assert avu.data == "first line\nsecond line\n"
    assert avu.splitlines() == ["first line", "second line", ""]
    assert avu.splitlines(True) == ["first line\n", "second line\n", ""]


# Generated at 2022-06-21 00:05:07.971938
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    assert AnsibleVaultEncryptedUnicode("test case").upper() == \
        AnsibleVaultEncryptedUnicode("TEST CASE")



# Generated at 2022-06-21 00:05:11.356593
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    str1 = AnsibleVaultEncryptedUnicode('This is a TEST.')
    str2 = str1.data.lower()
    assert str1.lower() == str2


# Generated at 2022-06-21 00:05:15.275628
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    AnsibleSequence(['foo', 'bar'])
    try:
        AnsibleSequence('foo')
    except AssertionError:
        pass
    else:
        raise AssertionError("AnsibleSequence() failed")



# Generated at 2022-06-21 00:05:22.202720
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    assert AnsibleVaultEncryptedUnicode('abcdefg')[1:3] == 'bc'


# Generated at 2022-06-21 00:05:29.536629
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    # set up
    u1 = AnsibleVaultEncryptedUnicode('4567890')
    u2 = AnsibleVaultEncryptedUnicode('0x4567890')
    u3 = AnsibleVaultEncryptedUnicode(' 1A ')
    u4 = AnsibleVaultEncryptedUnicode('1A')

    # test
    assert int(u1) == 4567890
    assert int(u2, 16) == 0x4567890
    assert int(u3) == 1
    assert int(u3, 16) == 0x1a
    assert int(u4, 16) == 26



# Generated at 2022-06-21 00:05:38.166091
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    secrets_dir = './test/'
    vault_password = get_file_vault_secret(secrets_dir)
    vault = VaultLib(vault_password)

# Generated at 2022-06-21 00:05:43.043705
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    import tempfile
    import vaultlib

    # create a temp file
    temp_file = tempfile.NamedTemporaryFile()

    # write to it
    temp_file.write('my test file')
    temp_file.flush()

    # read from it
    with open(temp_file.name, 'rb') as f:
        content = f.read()

    # create a vault object, which is used to encrypt and decrypt
    vault = vaultlib.VaultLib('my secret')

    # encrypt the content
    ciphertext = vault.encrypt(content)

    # create a AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode(ciphertext)

    # set the vault object attribute
    avu.vault = vault

    # get decrypted content
    content2 = av

# Generated at 2022-06-21 00:05:43.609240
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    pass


# Generated at 2022-06-21 00:05:52.716648
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    '''
    Unit test for method partition of class AnsibleVaultEncryptedUnicode
    :return:
    '''
    class AVEC(AnsibleVaultEncryptedUnicode):
        '''
        Subclass of AnsibleVaultEncryptedUnicode;
        Only defined to override __getitem__ to allow testing
        '''
        def __getitem__(self, index):
            '''
            overrides __getitem__ to return the character at the given index
            :param index: index of character to return
            :return:
            '''
            return self.data[index]


# Generated at 2022-06-21 00:05:58.640847
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    x = AnsibleVaultEncryptedUnicode(to_text("this is a test"))
    assert(x.__ge__("this is a test") == True)
    assert(x.__ge__("this is a") == True)
    assert(x.__ge__("this is a test1") == False)


# Generated at 2022-06-21 00:06:10.475175
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    password = "password"
    secret_value = "val1:val2"

    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password)

    mystr = AnsibleVaultEncryptedUnicode.from_plaintext(secret_value, vault, password)

    # Split on ':'
    assert len(list(mystr.split(":"))) == 2
    assert len(list(mystr.split(":", maxsplit=1))) == 2
    assert len(list(mystr.split(":", maxsplit=0))) == 1
    assert len(list(mystr.split(":", maxsplit=2))) == 2
    assert len(list(mystr.split(":", maxsplit=3))) == 2

    # Split on ';'

# Generated at 2022-06-21 00:06:18.122924
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    assert(not AnsibleVaultEncryptedUnicode.from_plaintext('', None, None).isupper())
    assert(AnsibleVaultEncryptedUnicode.from_plaintext('A', None, None).isupper())
    assert(not AnsibleVaultEncryptedUnicode.from_plaintext('a', None, None).isupper())
    assert(not AnsibleVaultEncryptedUnicode.from_plaintext('1', None, None).isupper())
    assert(not AnsibleVaultEncryptedUnicode.from_plaintext('\t', None, None).isupper())
    assert(not AnsibleVaultEncryptedUnicode.from_plaintext(' ', None, None).isupper())

# Generated at 2022-06-21 00:06:30.103250
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    assert 1 == AnsibleVaultEncryptedUnicode('test')[0]
    assert 'a' == AnsibleVaultEncryptedUnicode('test')[-1]
    assert 't' == AnsibleVaultEncryptedUnicode('test')[2]
    assert 'st' == AnsibleVaultEncryptedUnicode('test')[2:4]
    assert 'es' == AnsibleVaultEncryptedUnicode('test')[-3:-1]
    assert 't' == AnsibleVaultEncryptedUnicode('test')[-1:-3]
    assert 'tes' == AnsibleVaultEncryptedUnicode('test')[0:3]
    assert 'es' == AnsibleVaultEncryptedUnicode('test')[1:-1]
    assert 't' == AnsibleVaultEncrypted

# Generated at 2022-06-21 00:06:37.463530
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    test_string = '\u0020\u0020'
    avu = AnsibleVaultEncryptedUnicode(test_string)
    assert avu.isspace() == test_string.isspace()

# Generated at 2022-06-21 00:06:44.429804
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml import AnsibleVaultError

    vault_secret = '$ANSIBLE_VAULT;1.1;AES256'
    vault = VaultLib(None)
    # Should not raise an exception
    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256\n3634353863623233313466653665663232636330613938316537316234333163613431393131663430\n3533373032363033383566306163666265366437303564383639636131643231346332316663366566\n646566386165323238396339333862336535643639\n'
    avu = Ansible

# Generated at 2022-06-21 00:06:53.896203
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    # Testing when right side is ansible vault
    left = AnsibleVaultEncryptedUnicode('abc')
    right = AnsibleVaultEncryptedUnicode('abc')
    assert(left.__le__(right) == True)
    right = AnsibleVaultEncryptedUnicode('abcd')
    assert(left.__le__(right) == True)
    right = AnsibleVaultEncryptedUnicode('ab')
    assert(left.__le__(right) == False)

    # Testing when right side is str
    left = AnsibleVaultEncryptedUnicode('abc')
    right = 'abc'
    assert(left.__le__(right) == True)
    right = 'abcd'
    assert(left.__le__(right) == True)
    right = 'ab'
   

# Generated at 2022-06-21 00:07:05.882365
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    PASSED = 0x1


# Generated at 2022-06-21 00:07:16.851941
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():

    def _test_casefold(src, expected):
        avu = AnsibleVaultEncryptedUnicode.from_plaintext(src, vault=None, secret=None)
        assert avu.casefold() == expected

    _test_casefold('Hello_World', 'hello_world')
    _test_casefold('Hello World', 'hello world')
    _test_casefold('HELLO_WORLD', 'hello_world')
    _test_casefold('HELLO WORLD', 'hello world')
    _test_casefold('Hello-World', 'hello-world')
    _test_casefold('İ', 'i̇')
    _test_casefold('İ', 'i̇')
    _test_casefold('I', 'i')
    _test_casefold('i', 'i')
   

# Generated at 2022-06-21 00:07:24.055620
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    plaintext = u'\x00\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f\x7f'

# Generated at 2022-06-21 00:07:28.774317
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    # String to search in
    search = AnsibleVaultEncryptedUnicode(ciphertext='123ABC')
    # String to search for
    search_for = AnsibleVaultEncryptedUnicode(ciphertext='abc')

    assert search.casefold().find(search_for.casefold()) != -1


# Generated at 2022-06-21 00:07:32.775400
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    # check that AnsibleVaultEncryptedUnicode.zfill(width) returns a string with width characters
    assert len(AnsibleVaultEncryptedUnicode.zfill(zfill, 10)) == 10


# Generated at 2022-06-21 00:07:40.781950
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    # Test with a string as argument
    str_obj = AnsibleVaultEncryptedUnicode("test")
    assert str_obj.ljust(10, "=") == "test======"
    # Test with a unicode object as argument
    unicode_obj = AnsibleVaultEncryptedUnicode("test")
    assert unicode_obj.ljust(10, "=") == "test======"
    # Test with an integer as argument
    int_obj = AnsibleVaultEncryptedUnicode("test")
    assert int_obj.ljust(10, "=") == "test======"


# Generated at 2022-06-21 00:07:49.438963
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    if _sys.version_info[0] == 2:
        avu = AnsibleVaultEncryptedUnicode('abc')
        s = avu.replace(t('abc', 'ascii'), t('xyz', 'ascii'))
        assert (s == t('xyz', 'ascii'))

        avu = AnsibleVaultEncryptedUnicode(t('abc', 'ascii'))
        s = avu.replace(t('abc', 'ascii'), t('xyz', 'ascii'))
        assert (s == t('xyz', 'ascii'))

        avu = AnsibleVaultEncryptedUnicode(t('abc', 'ascii'))

# Generated at 2022-06-21 00:08:07.836348
# Unit test for method find of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:08:15.190827
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    if not sys.version_info.major == 2:
        # This is not necessary in python 3, as the `isinstance` implementation can handle this type
        return
    from io import StringIO
    import crypt
    import vault

    uni_str = u'hello world'
    avu_str = AnsibleVaultEncryptedUnicode(crypt.encrypt(uni_str, 'test secret'))
    assert isinstance(avu_str.rstrip(), type(uni_str))


# Generated at 2022-06-21 00:08:17.773100
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    am = AnsibleMapping({'a': 'b'})
    assert isinstance(am, AnsibleMapping)
    assert isinstance(am, dict)


# Generated at 2022-06-21 00:08:28.665111
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    from ansible.parsing.vault import VaultLib
    # Test with format specifier
    vault_password = 'secret'
    secret = VaultLib(vault_password).encrypt(b'secure')  # on py2 needs to be a bytestring

    s = AnsibleVaultEncryptedUnicode.from_plaintext(b'secure', VaultLib(vault_password), secret)

    assert b'My plaintext password is secure' == b'My plaintext password is {}'.format(s)

    # Test without format specifier
    s = AnsibleVaultEncryptedUnicode.from_plaintext(b'secure', VaultLib(vault_password), secret)

    assert b'My plaintext password is secure' == b'My plaintext password is {}'.format(s)

    # Test with wrong vault password

# Generated at 2022-06-21 00:08:32.215505
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    # This test is to make sure __reversed__ returns a string not a generator
    # See https://github.com/ansible/ansible/issues/16242
    avu = AnsibleVaultEncryptedUnicode('test')
    assert type(avu.__reversed__()) is str
    assert avu.__reversed__() == 'tset'



# Generated at 2022-06-21 00:08:37.263216
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    # Test with non unicode object
    assert AnsibleVaultEncryptedUnicode('test')[0] == 't'

    # Test with unicode object
    assert AnsibleVaultEncryptedUnicode('test')[0] == 't'


# Generated at 2022-06-21 00:08:48.724089
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    assert str(AnsibleVaultEncryptedUnicode('dummy')) == 'dummy'
    assert unicode(AnsibleVaultEncryptedUnicode('dummy')) == u'dummy'
    assert repr(AnsibleVaultEncryptedUnicode('dummy')) == repr('dummy')

    with pytest.raises(TypeError):
        hash(AnsibleVaultEncryptedUnicode('dummy'))

    assert len(AnsibleVaultEncryptedUnicode('dummy')) == len('dummy')
    assert not AnsibleVaultEncryptedUnicode('dummy')
    assert AnsibleVaultEncryptedUnicode('dummy') == AnsibleVaultEncryptedUnicode('dummy')
    assert AnsibleVaultEncryptedUnicode('dummy') != Ansible

# Generated at 2022-06-21 00:08:59.386832
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    from binascii import unhexlify
    from ansible.parsing import vault


# Generated at 2022-06-21 00:09:11.622346
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    # Test when ciphertext is None
    avu = AnsibleVaultEncryptedUnicode(None)
    assert avu.is_encrypted() == False

    # Test when ciphertext is not None and vault is None
    avu = AnsibleVaultEncryptedUnicode("test")
    assert avu.is_encrypted() == False

    # Test when ciphertext is an encrypted string and vault is not None
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(b"ansible")
    ciphertext = vault.encrypt("test")
    # ciphertext is bytes
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() == True
    # ciphertext is a unicode object
    ciphertext = ciphertext

# Generated at 2022-06-21 00:09:22.427158
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu = AnsibleVaultEncryptedUnicode(u'hello')
    assert avu == 'hello'
    avu.vault = True
    assert avu == 'hello'
    avu.vault = None
    assert avu != 'hello'

yaml.SafeDumper.add_multi_representer(AnsibleVaultEncryptedUnicode,
    lambda dumper, data: dumper.represent_scalar(
        u'!vault', data.encode('utf-8'), style='|'))

yaml.SafeDumper.add_representer(AnsibleVaultEncryptedUnicode, lambda dumper, data: dumper.represent_scalar(
    u'!vault', data.encode('utf-8'), style='|'))


# Generated at 2022-06-21 00:09:42.077775
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    from vault import VaultLib
    if not VaultLib.HAVE_CRYPTOGRAPHY:
        return
    from ansible.parsing.vault import VaultSecret

    secret_value = VaultSecret(b'a secret value here')
    vault = VaultLib(secret_value)

    plaintext = '123'
    ciphertext = vault.encrypt(plaintext, secret_value)
    test_obj = AnsibleVaultEncryptedUnicode(ciphertext)
    test_obj.vault = vault
    assert int(test_obj) == 123

# The following tests are ported from python2.7/test_userstring.py
#
# The tests were modified to not use the UserString class since that is not
# available in python3.
#
# The tests were also modified to use AnsibleVaultEncryptedUnic

# Generated at 2022-06-21 00:09:49.474108
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    assert(AnsibleVaultEncryptedUnicode("1").center(2) == " 1 ")
    assert(AnsibleVaultEncryptedUnicode("1").center(2, AnsibleVaultEncryptedUnicode("A")) == "A1A")
    assert(AnsibleVaultEncryptedUnicode("12").center(2) == "12 ")
    assert(AnsibleVaultEncryptedUnicode("12").center(2, AnsibleVaultEncryptedUnicode("A")) == "12A")


# Generated at 2022-06-21 00:09:57.034431
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    if _sys.version_info < (3, 0):
        # the test works only with unicode strings
        # not with str (byte) strings
        return

    # define some unicode strings
    # lower case
    name = u'fran\u00E7ois'
    # upper case
    name_up = u'FRAN\u00C7OIS'
    # with diacritics
    name_diac = u'fran\u00E7ois ri\u00E8re'
    # with diacritics and upper case
    name_diac_up = u'FRAN\u00C7OIS RI\u00C8RE'

    # create an AnsibleVaultEncryptedUnicode from the strings
    avue = AnsibleVaultEncryptedUnicode(name)
    av

# Generated at 2022-06-21 00:10:09.050919
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test parameter isinstance.
    # Test parameter isinstance.
    try:
        test = AnsibleVaultEncryptedUnicode(b"foo")
        test2 = AnsibleVaultEncryptedUnicode(b"foo")
        test + test2
    except TypeError as e:
        print(e)

    # Test parameter not string.
    # Test parameter not string.
    try:
        test = AnsibleVaultEncryptedUnicode(b"foo")
        test2 = 1
        test + test2
    except TypeError as e:
        print(e)

    # Test parameter empty str.
    # Test parameter empty str.

# Generated at 2022-06-21 00:10:14.399970
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    # Testing empty string:
    value = AnsibleVaultEncryptedUnicode("")
    assert to_text(value.data) == to_text("")

    # Testing non-empty string:
    value = AnsibleVaultEncryptedUnicode("abc")
    assert to_text(value.data) == to_text("abc")


# Generated at 2022-06-21 00:10:25.561223
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    # Test endswith against a AnsibleVaultEncryptedUnicode
    assert AnsibleVaultEncryptedUnicode('abc').endswith(AnsibleVaultEncryptedUnicode('b'))
    assert not AnsibleVaultEncryptedUnicode('abc').endswith(AnsibleVaultEncryptedUnicode('B'))
    assert not AnsibleVaultEncryptedUnicode('abc').endswith(AnsibleVaultEncryptedUnicode('d'))
    # Test endswith against a text_type
    assert AnsibleVaultEncryptedUnicode('abc').endswith('b')
    assert not AnsibleVaultEncryptedUnicode('abc').endswith('B')
    assert not AnsibleVaultEncryptedUnicode('abc').endswith('d')
    # Test

# Generated at 2022-06-21 00:10:32.768177
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    if (sys.version_info < (3,)):
        assert isinstance(AnsibleVaultEncryptedUnicode('mystr').__str__(), str)
        assert isinstance(AnsibleVaultEncryptedUnicode(u'mystr').__str__(), str)
    else:
        assert isinstance(AnsibleVaultEncryptedUnicode('mystr').__str__(), str)
        assert isinstance(AnsibleVaultEncryptedUnicode(u'mystr').__str__(), str)


# Generated at 2022-06-21 00:10:35.541056
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    avue = AnsibleVaultEncryptedUnicode('supersecret')
    assert avue.endswith('secret')
    assert not avue.endswith('secret', 4)
    assert not avue.endswith('secret', 0, 4)


# Generated at 2022-06-21 00:10:47.492494
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # test_AnsibleVaultEncryptedUnicode___lt__: test method __lt__ of class AnsibleVaultEncryptedUnicode
    # Input: (u'admin', AnsibleVaultEncryptedUnicode('admin'))
    # Expected Output: False
    res = (u'admin', AnsibleVaultEncryptedUnicode('admin'))
    expected = False
    assert (res[0] < res[1]) == expected
    # test_AnsibleVaultEncryptedUnicode___lt__: test method __lt__ of class AnsibleVaultEncryptedUnicode
    # Input: (AnsibleVaultEncryptedUnicode('admin'), u'admin')
    # Expected Output: False
    res = (AnsibleVaultEncryptedUnicode('admin'), u'admin')

# Generated at 2022-06-21 00:10:55.766732
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    import unittest
    class TestAnsibleVaultEncryptedUnicode_isdecimal(unittest.TestCase):
        def test_isdecimal_expect_true_for_input_values_with_digits_only(self):
            self.assertTrue(AnsibleVaultEncryptedUnicode('123').isdecimal())

        def test_isdecimal_expect_false_for_input_values_with_non_digit_characters(self):
            self.assertFalse(AnsibleVaultEncryptedUnicode('123abc').isdecimal())

    if __name__ == '__main__':
        unittest.main()
