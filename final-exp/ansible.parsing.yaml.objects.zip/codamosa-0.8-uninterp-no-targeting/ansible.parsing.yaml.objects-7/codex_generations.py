

# Generated at 2022-06-21 00:01:34.265703
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    # GIVEN
    avu = AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\n393935396633623562333162333936643763313962653634333634653132626435376536393666\n346435366564383036643765336434303964653461306535366231653766373435663000a')
    avu.vault = vaultlib.VaultLib('password')

    # WHEN
    actual = avu.startswith(u'$ANSIBLE_VAULT;1.1;AES256\n')

    # THEN
    assert True == actual


# Generated at 2022-06-21 00:01:42.692455
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    avalue = AnsibleVaultEncryptedUnicode("%hostname%")
    assert avalue.partition("%") == ("", "%", "hostname%")
    assert avalue.partition("host") == ("%", "host", "name%")
    assert avalue.partition("x") == ("%hostname%", "", "")
    assert avalue.partition("h") == ("%", "h", "ostname%")
    assert avalue.partition(".") == ("%hostname%", "", "")


# Generated at 2022-06-21 00:01:50.141075
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    def _check(s, chars, out):
        data = AnsibleVaultEncryptedUnicode(s)
        assert data.strip(chars) == out

    _check(' text   ', None, 'text')
    _check('   text   ', None, 'text')
    _check('   text', None, 'text')
    _check('   text   ', ' ', 'text')
    _check('   text   ', 'xt', ' text   ')
    _check('   text   ', 'e', '   txt   ')


# Generated at 2022-06-21 00:01:57.187076
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    u"""
    Test for contains method of class AnsibleVaultEncryptedUnicode

    This test case test for the following condition:
    case 1:
    input string or AnsibleVaultEncryptedUnicode is a substring of plaintext data

    case 2:
    input string or AnsibleVaultEncryptedUnicode is not a substring of plaintext data

    case 3:
    input is a AnsibleVaultEncryptedUnicode and is not decrypted

    """
    # Arrange
    univar = AnsibleVaultEncryptedUnicode("abc")
    # Act
    case1 = "b" in univar
    case2 = "x" in univar
    case3 = AnsibleVaultEncryptedUnicode("b") in univar
    # Assert
    assert case1 is True
   

# Generated at 2022-06-21 00:02:09.328300
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    class MockVault(object):
        def decrypt(self, text, obj):
            return b'0123456789'

    ciphertext = b'wootwootwoot'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = MockVault()

    # test slice
    assert avu[:2] == '01'
    assert avu[1:3] == '12'
    assert avu[-2:] == '89'
    assert avu[1:-1] == '12345678'
    assert avu[2:-2] == '34567'
    assert avu[3:] == '3456789'
    assert avu[-2:-1] == '8'
    assert avu[-2:1] == ''

# Generated at 2022-06-21 00:02:14.031951
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    from vault import VaultLib
    vault = VaultLib('password123')
    secret = 'password123'
    ansible_vault_unicode = AnsibleVaultEncryptedUnicode.from_plaintext('0.12', vault, secret)
    assert float(ansible_vault_unicode) == 0.12


# Generated at 2022-06-21 00:02:25.973022
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    from ansible.parsing.vault import VaultLib, VaultSecret
    import base64
    cipher = u'$ANSIBLE_VAULT;1.1;AES256\n'
    cipher += base64.b64encode(b'\xd8\x1d\x18\x20\xf1\xda\x9e\x3a\x2e\xa8\xdc\x98\xc3\xea\x3e\xd1')
    cipher += u'\n'

# Generated at 2022-06-21 00:02:37.074685
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a string
    non_vault_string = u'foobar'
    # Test with an AnsibleVaultEncryptedUnicode object
    AnsibleVaultEncryptedUnicode_object = AnsibleVaultEncryptedUnicode(u'foobar')
    AnsibleVaultEncryptedUnicode_object.vault = None
    assert AnsibleVaultEncryptedUnicode_object != non_vault_string

#from ansible.compat.tests import unittest
from ansible.module_utils.ansible_vault.vault import Vault
from ansible.module_utils.ansible_vault.vault import VaultLib
from ansible.module_utils.pycompat24 import get_exception
from ansible.module_utils.six import PY3


# Generated at 2022-06-21 00:02:43.448538
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    from unittest import TestCase

    class MyTestCase(TestCase):
        def setUp(self):
            self.avu = AnsibleVaultEncryptedUnicode('Hello')
        def test_upper(self):
            self.assertTrue(self.avu.istitle())
    t = MyTestCase()
    t.setUp()
    t.test_upper()


# Generated at 2022-06-21 00:02:48.159465
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(None)
    obj = AnsibleVaultEncryptedUnicode.from_plaintext('hello world', vault=vault, secret='yeknom')
    assert repr(obj) == repr(obj.data)



# Generated at 2022-06-21 00:02:56.859375
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    # Test that AnsibleVaultEncryptedUnicode.expandtabs() works
    s = AnsibleVaultEncryptedUnicode(b'test\tstring')
    result = s.expandtabs()
    assert result == 'test    string'



# Generated at 2022-06-21 00:03:02.912498
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    a = AnsibleVaultEncryptedUnicode('abc\tdef\tghi')
    assert a.expandtabs(4) == 'abc    def    ghi'
    assert a.expandtabs(10) == 'abc        def        ghi'
    assert a.expandtabs(3) == 'abc  def  ghi'

yaml.add_multi_representer(AnsibleVaultEncryptedUnicode, lambda dumper, data: dumper.represent_str(data._ciphertext))



# Generated at 2022-06-21 00:03:06.587075
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    """
    Test to check translate method of class AnsibleVaultEncryptedUnicode is working or not
    """
    val = AnsibleVaultEncryptedUnicode("abc")
    new_val = val.translate({ord('a'): None})
    if new_val != "bc":
        sys.exit(1)


# Generated at 2022-06-21 00:03:12.249002
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    ciphertext = "This is a test string"
    expected_encrypted_output = "This is a test string"
    encrypted_text = AnsibleVaultEncryptedUnicode(ciphertext)
    encrypted_text.vault = "fake_vault_obj"
    assert encrypted_text.rfind("string") == expected_encrypted_output

# Generated at 2022-06-21 00:03:18.026743
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    # should not raise exception
    try:
        container = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
        container.__contains__(AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256'))
    except:
        assert False, '__contains__ raises exception'



# Generated at 2022-06-21 00:03:30.056386
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    import ansible.parsing.vault
    vault_e1 = AnsibleVaultEncryptedUnicode.from_plaintext('a', ansible.parsing.vault.VaultLib(), 'pass')
    assert not vault_e1.isupper()

    vault_e2 = AnsibleVaultEncryptedUnicode.from_plaintext('A', ansible.parsing.vault.VaultLib(), 'pass')
    assert vault_e2.isupper()

    vault_e3 = AnsibleVaultEncryptedUnicode.from_plaintext('AbC', ansible.parsing.vault.VaultLib(), 'pass')
    assert not vault_e3.isupper()


# Generated at 2022-06-21 00:03:35.528960
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    avu = AnsibleVaultEncryptedUnicode('foo bar baz')
    sub_strings = avu.split()
    if sub_strings[0] != 'foo' or sub_strings[1] != 'bar' or sub_strings[2] != 'baz':
        raise RuntimeError('The split method does not implement correctly')


# Generated at 2022-06-21 00:03:42.769097
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    # expected behaviour:
    # A printable character is a character that takes up space on the screen and is not a control character

    # Empty string
    assert AnsibleVaultEncryptedUnicode('').isprintable()

    # All valid alphabetical characters are printable
    # Upper case range
    for c in range(0x41, 0x5b):
        assert AnsibleVaultEncryptedUnicode(chr(c)).isprintable()
    # Lower case range
    for c in range(0x61, 0x7b):
        assert AnsibleVaultEncryptedUnicode(chr(c)).isprintable()

    # All valid numerical characters are printable
    # Decimal range

# Generated at 2022-06-21 00:03:47.919409
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    avue_f = AnsibleVaultEncryptedUnicode(b'2.5')
    if avue_f != 2.5:
        raise AssertionError('AnsibleVaultEncryptedUnicode.__float__() does not return the correct value')


# Generated at 2022-06-21 00:03:59.737198
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():

    # Test string wrappers for both py2 and py3
    string_wrapper_dict = {
        'str': '',
        'unicode': u'',
    }
    if _sys.version_info < (3, 0):
        string_wrapper_dict['bytes'] = b''
    else:
        string_wrapper_dict['bytes'] = bytes([])

    string_wrapper_dict['AnsibleVaultEncryptedUnicode'] = AnsibleVaultEncryptedUnicode(b'')

    vault_password = u'test-password'
    vault_secrets_dir = '/tmp/ansible-vault-test'
    vault_filename = u'vault-test-file'
    vault = vaultlib.VaultLib(vault_password, vault_secrets_dir)


# Generated at 2022-06-21 00:04:16.091178
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    testcases = [
        (u'abc', True),
        (u'\u0e00', False),
        (u'\u0000', False),
        (u'\u0007', False),
        (u'\u0080', False),
        (u'\u0019', False),
        (u'\u00A0', False),
        (u'\u000b', False),
        (u'\u000c', False),
        (u'\u007f', False),
        (u' \u000e\x10\x11\x12\x19\x1a\x1b\x1c\x1d\x1e\x1f', False),
    ]


# Generated at 2022-06-21 00:04:20.848245
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    avu = AnsibleVaultEncryptedUnicode()
    avu.data = u'a'
    if avu.rindex(u'1', 2, 3) != 0:
        raise Exception("avu.rindex(u'1', 2, 3) != 0")



# Generated at 2022-06-21 00:04:26.378348
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():

    # Create an AnsibleVaultEncryptedUnicode object from a string
    avu = AnsibleVaultEncryptedUnicode('test')

    # Create another AnsibleVaultEncryptedUnicode object from a string
    avu2 = AnsibleVaultEncryptedUnicode('test2')

    # Compare the two AnsibleVaultEncryptedUnicode objects
    assert avu.__gt__(avu2)


# Generated at 2022-06-21 00:04:27.771480
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    assert AnsibleVaultEncryptedUnicode('abclol').rstrip('lol') == 'abc'


# Generated at 2022-06-21 00:04:39.321155
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    u = AnsibleVaultEncryptedUnicode('hello\nthere\r\nmister\rworld')
    assert u.splitlines() == ['hello', 'there', 'mister', 'world']
    assert u.splitlines(keepends=True) == ['hello\n', 'there\r\n', 'mister\r', 'world']
    assert list(u.splitlines(keepends=False)) == ['hello', 'there', 'mister', 'world']
    assert list(u.splitlines(keepends=True)) == ['hello\n', 'there\r\n', 'mister\r', 'world']
    assert u.splitlines(True) == ['hello\n', 'there\r\n', 'mister\r', 'world']

# Generated at 2022-06-21 00:04:51.866017
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    import random
    import unittest
    import unit.ansible_test_utils as utils


# Generated at 2022-06-21 00:04:56.620004
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    if sys.version_info > (3,):
        plaintext = 'plaintext'
    else:
        plaintext = u'plaintext'
    with open('ansible/playbooks/vault.yaml') as password_file:
        try:
            vault_password = yaml.safe_load(password_file.read())
        except Exception as e:
            print("Error loading vault yaml file")
            print(e)
            return
    password = vault_password['vault_password']

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault=None, secret=password)


# Generated at 2022-06-21 00:04:58.943573
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    data = AnsibleVaultEncryptedUnicode(' ' * 1000 + 'abcd')
    assert len(data.lstrip()) == 4


# Generated at 2022-06-21 00:05:07.608972
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    # Issue #30778
    # Test that AnsibleVaultEncryptedUnicode objects in a dictionary
    # are correctly handled by method replace
    plain_string = 'test_AnsibleVaultEncryptedUnicode_replace'
    encrypted_string1 = AnsibleVaultEncryptedUnicode('test_AnsibleVaultEncryptedUnicode_replace')
    encrypted_string2 = AnsibleVaultEncryptedUnicode('test_AnsibleVaultEncryptedUnicode_replace')
    d = dict(key1=plain_string, key2=encrypted_string1)
    assert d['key1'].replace('_', '-') == plain_string.replace('_', '-')
    assert d['key2'].replace('_', '-') == encrypted_string2.replace('_', '-')




# Generated at 2022-06-21 00:05:18.572390
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    avu = AnsibleVaultEncryptedUnicode(b'0123456789')
    # The start and end indexes should be swapped when negative
    assert avu[-3:-6] == '789'    #  -3 < 0 <= -6
    assert avu[-12:-9] == '012'   # -12 < 0 <= -9
    assert avu[-12:-13] == '01'   # -12 < 0 <= -13
    assert avu[-12:-14] == '0'    # -12 < 0 <= -14
    assert avu[-12:-15] == ''     # -12 < 0 <= -15
    assert avu[-13:-15] == ''     # -13 < 0 <= -15
    assert avu[-14:-15] == ''     # -14 < 0 <= -15


# Generated at 2022-06-21 00:05:27.994353
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    avu = AnsibleVaultEncryptedUnicode("a")
    # Strings that are not "unicode" nor "AnsibleVaultEncryptedUnicode"
    # are always considered greater than encrypted strings
    assert avu < "b"


# Generated at 2022-06-21 00:05:30.137544
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    avu = AnsibleVaultEncryptedUnicode("test")

    try:
        unicode(avu)
    except UnicodeDecodeError:
        return False

    return True



# Generated at 2022-06-21 00:05:35.037407
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    # Setup
    v = vault.VaultLib('TestVault123')
    cyphertext = v.encrypt('this is a test')
    avu = AnsibleVaultEncryptedUnicode(cyphertext)
    avu.vault = v

    # Assert
    value = avu.rfind('is')
    assert value == 2


# Generated at 2022-06-21 00:05:47.034117
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    def test_splitlines_linesep(avu_string, expected):
        assert avu_string.splitlines() == expected

    def test_splitlines_keepends_linesep(avu_string, expected):
        assert avu_string.splitlines(keepends=True) == expected

    avu1 = AnsibleVaultEncryptedUnicode('ab c\n\nde fg\rkl\r\n')
    avu2 = AnsibleVaultEncryptedUnicode('ab c\nde fg\rkl')

    test_splitlines_linesep(avu1, ['ab c', '', 'de fg', 'kl'])
    test_splitlines_linesep(avu2, ['ab c', 'de fg', 'kl'])


# Generated at 2022-06-21 00:05:52.157078
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
   from ansible.parsing.vault import VaultLib
   vault = VaultLib('dummy')
   avue = AnsibleVaultEncryptedUnicode.from_plaintext('     '.encode('utf-8'), vault, 'dummy')
   assert avue.isspace() == True

   avue = AnsibleVaultEncryptedUnicode.from_plaintext(' a '.encode('utf-8'), vault, 'dummy')
   assert avue.isspace() == False

# Generated at 2022-06-21 00:05:57.638161
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    # Call method isascii with a string containing a non ASCII character
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('Test\xdb')
    assert not avu.isascii()

test_AnsibleVaultEncryptedUnicode_isascii()



# Generated at 2022-06-21 00:06:06.885051
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    test_strings = ['12345', '-12345', '12345.', '-12345.1', '123.42', '-123.42', '123E45', 'abcde', 'abcde',
                    '1234.5E67', '-1234.5E67', '-0.5E-3', '1.5E-3', '0e-3', '0e3', '0.0', '-0.0']
    for s in test_strings:
        c = AnsibleVaultEncryptedUnicode(s)
        assert (c.isdecimal() == s.isdecimal())




# Generated at 2022-06-21 00:06:17.288501
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    """Test AnsibleVaultEncryptedUnicode.__radd__."""
    # __radd__ will return an AnsibleUnicode
    #
    # If a AnsibleUnicode object is added with a AnsibleVaultEncryptedUnicode object,
    # the AnsibleUnicode object should be returned.
    aveu = AnsibleVaultEncryptedUnicode("something")
    au = AnsibleUnicode("Some ")
    assert aveu.__radd__(au) == au
    #
    # If a string object is added with a AnsibleVaultEncryptedUnicode,
    # AnsibleUnicode should be returned.
    assert aveu.__radd__("Some") == AnsibleUnicode("Some")
    #
    # If a integer is added with a AnsibleV

# Generated at 2022-06-21 00:06:20.116128
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    avu = AnsibleVaultEncryptedUnicode('Test', vault='/tmp/vault.key')
    assert(avu.upper()=='TEST')


# Generated at 2022-06-21 00:06:24.752235
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    u = AnsibleVaultEncryptedUnicode.from_plaintext('{x}', None, None)
    assert u.format_map({'x': 'y'}) == 'y', "format_map failed"



# Generated at 2022-06-21 00:06:38.950840
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    vault_secret = VaultSecret('password')
    vault = VaultLib(vault_secret)
    ciphertext = vault.encrypt(u'hello')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert u'{}'.format(avu) == 'hello'
    assert u'%s' % avu == 'hello'
    assert u'{} {}'.format(avu, 'world') == 'hello world'
    assert u'{} {}'.format(avu, u'world') == 'hello world'
    assert u'{} {}'.format('hello', avu) == 'hello hello'

# Generated at 2022-06-21 00:06:40.825495
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    print(AnsibleVaultEncryptedUnicode('a-z').upper())



# Generated at 2022-06-21 00:06:51.896420
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    ansibleVaultEncryptedUnicode = AnsibleVaultEncryptedUnicode('''$ANSIBLE_VAULT;1.1;AES256
37633231636137353662326230363939316437343135383038336664363566323139613664376339
643739366433613064363637643761653966333133323336
38666565303966613362363137353236353665383938306535303935333830346630373538623730
66303233356531396266366330353337''')
    assert not ansibleVaultEncryptedUnicode.islower()


# Generated at 2022-06-21 00:07:03.534817
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    uni = AnsibleVaultEncryptedUnicode(u'abc')
    assert uni.replace(u'abc', u'def') == u'def'
    assert uni.replace(u'abc', u'ABC') == u'ABC'
    assert uni.replace(u'abc', 'def') == u'def'
    assert uni.replace(u'abc', 'ABC') == u'ABC'
    assert uni.replace('abc', u'def') == u'def'
    assert uni.replace('abc', u'ABC') == u'ABC'
    assert uni.replace('abc', 'def') == u'def'
    assert uni.replace('abc', 'ABC') == u'ABC'

    uni = AnsibleVaultEncryptedUnicode(u'abc')
    other = Ansible

# Generated at 2022-06-21 00:07:14.924397
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.vault import VaultLib
    import logging

    logging.basicConfig(level=logging.DEBUG)
    vault = VaultLib(None)
    yaml = YAMLDumper(
        None,
        default_flow_style=False,
        vault_password_file=None,
        vault_identity='user@example.com',
        vault_version=1,
    )
    data = {
        'vault': AnsibleVaultEncryptedUnicode.from_plaintext('password', vault, 'secret')
    }
    result = yaml.represent_dict(data)
    assert result.startswith(u'vault: !vault |\n            $ANSIBLE_VAULT')



# Generated at 2022-06-21 00:07:22.445350
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    # if __name__ == '__main__':
    # args = sys.argv[1:]
    # if len(args) != 1:
    #     print('need one arguments')
    #     exit(1)
    # if args[0] == 'test':
    #     exit(0)
    text = to_bytes("foo bar baz quuz")
    # print(text.decode())
    print(text)
    val = AnsibleVaultEncryptedUnicode(text)
    # print(val.data.decode())
    print(val.data)
    print(val.partition(to_bytes("bar")))
    print(val.partition(to_bytes("baz")))



# Generated at 2022-06-21 00:07:28.570420
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    # Test invalid input
    avu = AnsibleVaultEncryptedUnicode(None)
    avu.vault = None
    value = avu.__reversed__()
    assert value == u''

    avu = AnsibleVaultEncryptedUnicode('')
    avu.vault = None
    value = avu.__reversed__()
    assert value == u''

    avu = AnsibleVaultEncryptedUnicode(u'abc')
    avu.vault = None
    value = avu.__reversed__()
    assert value == u'cba'

    avu = AnsibleVaultEncryptedUnicode(u'abcdef')
    avu.vault = None
    value = avu.__reversed__()

# Generated at 2022-06-21 00:07:33.029494
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    assert(False)

AnsibleVaultEncryptedUnicode.test_islower = test_AnsibleVaultEncryptedUnicode_islower


# This is not the full list of string methods, if you need one, add it above.

# Generated at 2022-06-21 00:07:39.713953
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    a = AnsibleVaultEncryptedUnicode(u'')
    b = AnsibleVaultEncryptedUnicode(u'')
    print(a.join([u'a',b,u'b']))
    print(repr(a.join([u'a',b,u'b'])))


# the following class was adapted from http://pyyaml.org/attachment/ticket/161/use_ruamel.yaml


# Generated at 2022-06-21 00:07:48.862355
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    vaultfile = "./vault.yaml"
    vault = AnsibleVault(vaultfile)

    plaintext = """
        this is a test
    """
    plaintext_lower = """
        this is a test
    """
    plaintext_upper = """
        THIS IS A TEST
    """
    plaintext_mixed = """
        This is a test
    """

    require.equal(vault.is_encrypted(plaintext), False)
    require.equal(vault.is_encrypted(plaintext_lower), False)
    require.equal(vault.is_encrypted(plaintext_upper), False)
    require.equal(vault.is_encrypted(plaintext_mixed), False)

    ciphertext = vault.encrypt(plaintext, secret="p@ssw0rd")
    ciphertext_lower

# Generated at 2022-06-21 00:07:57.351356
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    temp_vault = vault.VaultLib('password')
    vault_data = AnsibleVaultEncryptedUnicode.from_plaintext('test-data', temp_vault, 'password')
    assert(vault_data.title() == 'Test-Data')


# Generated at 2022-06-21 00:08:07.261519
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    a = AnsibleVaultEncryptedUnicode(u'text')
    b = AnsibleVaultEncryptedUnicode(u'bc')
    c = AnsibleVaultEncryptedUnicode(u'abc')
    
    assert a.rjust(5) == u' text'
    assert a.rjust(5, u'0') == u'00text'
    
    assert b.rjust(10, u'abc') == u'abcbccbccbcc'
    assert b.rjust(10, u'') == u'bc'
    
    assert c.rjust(5) == u'  abc'
    assert c.rjust(5, u'\uffff') == u'\uffff\uffff\uffffabc'



# Generated at 2022-06-21 00:08:17.862509
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    def test_ansible_vault(value):
        return AnsibleVaultEncryptedUnicode.from_plaintext(
            value,
            AnsibleVaultLib.get_vault('prompt'),
            b'1234'
        )

    def lstrip_test(string, chars, expected):
        if isinstance(string, six.text_type):
            string = test_ansible_vault(string)
        if chars and isinstance(chars, six.text_type):
            chars = test_ansible_vault(chars)
        if expected and isinstance(expected, six.text_type):
            expected = test_ansible_vault(expected)

        assert string.lstrip(chars) == expected


# Generated at 2022-06-21 00:08:28.741837
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    assert AnsibleVaultEncryptedUnicode(u'abc\ndef\r\nghi').splitlines() == [u'abc', u'def', u'ghi']
    assert AnsibleVaultEncryptedUnicode(u'abc\ndef\r\nghi\n').splitlines() == [u'abc', u'def', u'ghi']
    assert AnsibleVaultEncryptedUnicode(u'abc\ndef\r\nghi\n\n').splitlines() == [u'abc', u'def', u'ghi', u'']
    assert AnsibleVaultEncryptedUnicode(u'abc\ndef\r\nghi\n\n\n').splitlines() == [u'abc', u'def', u'ghi', u'', u'']

# Generated at 2022-06-21 00:08:33.624571
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    """
    This function will test the __len__ method from AnsibleVaultEncryptionUnicode
    """
    plaintext = 'hello'

    from ansible.parsing.vault import VaultLib
    vault = VaultLib()
    key = vault.change_password(None)
    encrypted_text = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, key)
    expected_length = len(plaintext)
    actual_lenght = len(encrypted_text)

    assert expected_length == actual_lenght


# Generated at 2022-06-21 00:08:45.090873
# Unit test for method strip of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:08:48.135746
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    test = b"test"
    test = AnsibleVaultEncryptedUnicode(test)
    assert test.isalnum()



# Generated at 2022-06-21 00:08:55.430028
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    expected_data_source = '/path/to/somefile.yml'
    expected_line_number = 42
    expected_column_number = 3

    ayo = AnsibleBaseYAMLObject()
    ayo.ansible_pos = (expected_data_source, expected_line_number, expected_column_number)
    assert ayo.ansible_pos == (expected_data_source, expected_line_number, expected_column_number)


# Generated at 2022-06-21 00:09:02.934674
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    test_data = dict(a=dict(b=1))
    test_yaml = yaml.dump(test_data)
    test_yaml = test_yaml.replace('a:', 'a:\n').replace('b: 1', 'b: 1\n')

    for Loader in [yaml.FullLoader, yaml.SafeLoader, yaml.Loader]:
        obj = yaml.load(test_yaml, Loader=Loader)
        assert(isinstance(obj, dict))
        assert(isinstance(obj['a'], AnsibleMapping))
        assert(isinstance(obj['a']['b'], int))
        assert(obj['a'].ansible_pos == (None, 2, 4))

    # test object instantiation

# Generated at 2022-06-21 00:09:08.655855
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    a = AnsibleVaultEncryptedUnicode('foo')
    assert a == 'foo'
    assert len(a) == 3
    assert a + 'bar' == 'foobar'
    assert 'foo' + a == 'foobar'
    assert a.startswith('fo')
    assert a.endswith('oo')


# Generated at 2022-06-21 00:09:17.895507
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    '''
    Test if the function is able to add two AnsibleVaultEncryptedUnicode objects
    and a AnsibleVaultEncryptedUnicode to a string.
    '''
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('secret')
    plaintext = 'some plaintext that should get encrypted'
    ciphertext = vault.encrypt(plaintext, None)
    plaintext_b = to_bytes(plaintext)
    ciphertext_b = to_bytes(ciphertext)
    assert_equal('secret' + ciphertext_b, AnsibleVaultEncryptedUnicode.__radd__('secret', AnsibleVaultEncryptedUnicode(ciphertext_b)))

# Generated at 2022-06-21 00:09:26.527274
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    ''' Unit test for endswith of AnsibleVaultEncryptedUnicode '''
    avu = AnsibleVaultEncryptedUnicode(to_bytes('aAaA'))
    assert avu.endswith(to_bytes('aAaA'))
    assert avu.endswith(to_bytes('AA'))
    assert avu.endswith(to_bytes('aAa'))
    assert not avu.endswith(to_bytes('aAaAA'))
    assert not avu.endswith(to_bytes('aAaAAAA'))
    assert not avu.endswith(to_bytes('aAa'))
    avu = AnsibleVaultEncryptedUnicode(to_bytes('abcd'))

# Generated at 2022-06-21 00:09:37.995376
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib("bar")
    seq = AnsibleVaultEncryptedUnicode.from_plaintext("foo bar", vault, "bar")
    assert seq.rfind("foo") == 0
    assert seq.rfind("bar") == 4
    assert seq.rfind("a") == -1
    assert seq.rfind("") == -1
    assert seq.rfind("foo", 2) == -1
    assert seq.rfind("foo", 0, 3) == 0
    assert seq.rfind("foo", maxsplit=1) == 0
    assert seq.rfind("foo", 7) == -1
    assert seq.rfind("foo", 7, 8) == -1

# Generated at 2022-06-21 00:09:48.785601
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    class test_vault():
        def __init__(self):
            self.version = 0
            self.algorithm = 'AES'
            self.blocksize = 16
            self._hash_name = 'sha256'

        def is_encrypted(self, value):
            return value.startswith(b'$ANSIBLE_VAULT;')

        def decrypt(self, value, obj=None):
            return ('\u0621\u0622\u0623').encode('utf-8')

    vault = test_vault()
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;AQAAAEdZ7BDfkzjEOV7YUPpzYs9GKABpvq8tqfA+ZoCbIo83iRQ2W')


# Generated at 2022-06-21 00:09:50.383610
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    assert AnsibleVaultEncryptedUnicode("abc").__reversed__() == "cba"


# Generated at 2022-06-21 00:09:53.886741
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    try:
        # Create an instance of AnsibleBaseYAMLObject, expecting no error
        ansible_baseyaml_object_instance = AnsibleBaseYAMLObject()
    except Exception as e:
        # The expected exception is not raised, we have failed the test
        raise Exception('Failed to create an instance of AnsibleBaseYAMLObject')



# Generated at 2022-06-21 00:09:55.781272
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    obj = AnsibleVaultEncryptedUnicode("test")
    assert repr(obj) == "test"


# Generated at 2022-06-21 00:10:04.012780
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    if not hasattr(string, 'istitle'):
        return 'Not supported on this python version'
    assert hasattr(AnsibleVaultEncryptedUnicode, 'istitle')
    test_string = u'HelloWorld'
    test_object = AnsibleVaultEncryptedUnicode(test_string)

    def _is_title(s):
        return all(c.istitle() or c.isspace() for c in s)

    assert test_object.istitle() is _is_title(test_string)



# Generated at 2022-06-21 00:10:12.284195
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    import copy
    import vault

    passphrase = 'secret'
    yaml_file = '''
        vars:
            - ansible_vault_encrypt: vvV8W3H1NuV7X9yN
            - ansible_vault_decrypt: vvV8W3H1NuV7X9yN
        tasks:
            - copy: content={{item.ansible_vault_decrypt}} dest={{item.ansible_vault_encrypt}}
              when: item.ansible_vault_decrypt <= item.ansible_vault_encrypt
        '''

# Generated at 2022-06-21 00:10:24.160963
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    avu = AnsibleVaultEncryptedUnicode('a')
    assert avu.expandtabs(tabsize=1) == 'a'
    assert avu.expandtabs(tabsize=2) == 'a'
    assert avu.expandtabs(tabsize=3) == 'a'
    assert avu.expandtabs(tabsize=4) == 'a'
    assert avu.expandtabs(tabsize=5) == 'a'
    assert avu.expandtabs(tabsize=6) == 'a'
    assert avu.expandtabs(tabsize=7) == 'a'
    assert avu.expandtabs(tabsize=8) == 'a'
    assert avu.expandtabs(tabsize=9) == 'a'

    av

# Generated at 2022-06-21 00:10:33.844099
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Note: For testing purposes, all methods of the AnsibleVault class are mocked with the noop
    # class, so the encryption/decryption does not occur.
    from ansible.parsing.vault import VaultLib
    vault = VaultLib

# Generated at 2022-06-21 00:10:43.769173
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('Secret123')

    avu0 = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;myhost;16\nrZN/1X0SpIpzABxlJRAh1Q==\r\n')
    avu0.data = '1+1j'
    avu0.vault = vault
    assert avu0.__complex__() == 1 + 1j

    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('1+1j', vault, 'Secret123')
    assert avu1.__complex__() == 1 + 1j

# Generated at 2022-06-21 00:10:54.880805
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    avu1 = AnsibleVaultEncryptedUnicode(u'abcd')
    avu2 = AnsibleVaultEncryptedUnicode(u'ABCD')

    # Python 2.x
    if _sys.version_info[0] < 3:
        assert avu1.__radd__('efgh') == 'efgh' + avu1.__str__()
        assert avu1.__radd__('EFGH') == 'EFGH' + avu1.__str__()
        assert avu2.__radd__('efgh') == 'efgh' + avu2.__str__()
        assert avu2.__radd__('EFGH') == 'EFGH' + avu2.__str__()
    # Python 3.x
    else:
        assert avu1.__r

# Generated at 2022-06-21 00:11:04.235418
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    # Test for the PY2 case
    if _sys.version_info < (3, 0):
        avueu = AnsibleVaultEncryptedUnicode.from_plaintext(u'hello', None, u'1234')
        assert(avueu.rindex('l') == 3)
    else:
        avueu = AnsibleVaultEncryptedUnicode.from_plaintext('hello', None, '1234')
        assert(avueu.rindex('l') == 3)

# End unit test for method rindex of class AnsibleVaultEncryptedUnicode
