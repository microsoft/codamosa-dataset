

# Generated at 2022-06-21 00:01:26.865943
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    """
    The following test case is to verify the fix for https://github.com/ansible/ansible/issues/11741
    """
    char_seq = "supercalifragilisticexpialidocious"
    avue_obj = AnsibleVaultEncryptedUnicode.from_plaintext(char_seq, 'asdf', 'asdfasdf')
    assert (avue_obj[2:5] == char_seq[2:5])


# Generated at 2022-06-21 00:01:33.205316
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    assert AnsibleVaultEncryptedUnicode('abc').ljust(5) == 'abc  '
    assert AnsibleVaultEncryptedUnicode('abc').ljust(5, '-') == 'abc--'
    assert AnsibleVaultEncryptedUnicode('abc').ljust(3) == 'abc'
    assert AnsibleVaultEncryptedUnicode('abc').ljust(3, '-') == 'abc'


# Generated at 2022-06-21 00:01:40.114391
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

    vault = VaultLib(loader=loader, password_file='/not/a/real/path')
    # Test the __lt__ method of AnsibleVaultEncryptedUnicode
    # The test is split into two sections:
    #   1. Test between an AnsibleVaultEncryptedUnicode and an AnsibleVaultEncryptedUnicode
    #   2. Test between an AnsibleVaultEncryptedUnicode and a non-AnsibleVaultEncryptedUnicode
    # Here are the test cases:
    #   1. A __lt__ B where A < B
    #   2. A __lt__ B where A > B
    #   3. A

# Generated at 2022-06-21 00:01:49.605419
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    assert AnsibleVaultEncryptedUnicode('foo\n').rstrip() == 'foo'
    assert AnsibleVaultEncryptedUnicode('foo\n').rstrip('\n') == 'foo'
    assert AnsibleVaultEncryptedUnicode('foo\n').rstrip('o') == 'fo'
    assert AnsibleVaultEncryptedUnicode('foo\n').rstrip('of') == 'fo'
    assert AnsibleVaultEncryptedUnicode('foo\n').rstrip('ofo') == 'f'
    assert AnsibleVaultEncryptedUnicode('foo\n').rstrip('ofox') == 'foo\n'


# Generated at 2022-06-21 00:01:56.915065
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:02:01.671635
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    obj = AnsibleVaultEncryptedUnicode("10")
    result = int(obj)
    assert result == 10
    obj = AnsibleVaultEncryptedUnicode("10")
    result = int(obj, base=2)
    assert result == 2


# Generated at 2022-06-21 00:02:07.883587
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    # Construct object
    input = 'unit_test_input'
    avu = AnsibleVaultEncryptedUnicode(input)
    avu.vault = True
    # Check that upper() returns the expected value
    expected = 'UNIT_TEST_INPUT'
    actual = avu.upper()
    # Check that assertion is as expected
    assert expected == actual


# Generated at 2022-06-21 00:02:16.777306
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    vault_pass = 'password'
    vault = VaultLib(vault_pass)
    # This test string has only one line break
    test_string = 'test string one\n'
    test_string_encrypted = vault.encrypt(test_string, vault_pass)
    assert isinstance(test_string_encrypted, bytes)

    test_avu = AnsibleVaultEncryptedUnicode(test_string_encrypted)
    test_avu.vault = vault

    # test without a parameter
    assert test_avu.splitlines() == test_string.splitlines()
    # test with keepends = True
    assert test_avu.splitlines(keepends=True) == test_string.splitlines(keepends=True)



# Generated at 2022-06-21 00:02:23.674334
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert (avu <= 'abc') == True
    assert (avu <= AnsibleVaultEncryptedUnicode('abc')) == True
    assert (avu <= 'abcd') == True
    assert (avu <= 'a') == False
    assert (le(avu, 'abcd')) == True
    assert (le('abcd', avu)) == False


# Generated at 2022-06-21 00:02:32.082458
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    # 123456789abcdef
    #     test1234
    # 123456test1234
    #    testtest12
    # 012345testtest
    x = AnsibleVaultEncryptedUnicode('test')
    print('123456789abcdef')
    print(x.rjust(12, ' '))
    print('123456' + x.rjust(6, ' '))
    print('   ' + x + x.rjust(6, ' '))
    print(x.rjust(10, '0'))



# Generated at 2022-06-21 00:02:41.896916
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    for plaintext in ['Hello world!', 'Hello {}', 1234567890]:
        v = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, None, None)
        assert v % 42 == plaintext % 42


# Generated at 2022-06-21 00:02:43.938537
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    assert AnsibleVaultEncryptedUnicode('HELLO').isupper()


# Generated at 2022-06-21 00:02:56.089486
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    u1 = AnsibleVaultEncryptedUnicode('1\n')
    assert u1.isdecimal() == False

    u2 = AnsibleVaultEncryptedUnicode('1.2\n')
    assert u2.isdecimal() == False

    u3 = AnsibleVaultEncryptedUnicode('1,2\n')
    assert u3.isdecimal() == False

    u4 = AnsibleVaultEncryptedUnicode('-\n')
    assert u4.isdecimal() == False

    u5 = AnsibleVaultEncryptedUnicode('+\n')
    assert u5.isdecimal() == False

    u6 = AnsibleVaultEncryptedUnicode('10\n')
    assert u6.isdecimal() == True

    u7 = AnsibleVaultEnc

# Generated at 2022-06-21 00:03:04.916328
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:03:16.652849
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(['--vault-password-file', 'dummy'])
    unencrypted = 'unencrypted'
    ciphertext = vault.encrypt(unencrypted, 'secret')  # the original string is encrypted to ciphertext
    enc_unicode = AnsibleVaultEncryptedUnicode(ciphertext)  # the ciphertext encrypts to enc_unicode
    enc_unicode.vault = vault  # the vault attribute is a VaultLib object
    assert enc_unicode >= unencrypted  # the enc_unicode object can be compared to an unencrypted string
    assert not (enc_unicode >= 'other string')  # the enc_unicode object can be compared to an unencrypted string
    assert enc_unicode >= enc_unicode  # the enc_unicode

# Generated at 2022-06-21 00:03:28.819147
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    from ansible.parsing.vault import VaultLib
    from six.moves.builtins import unicode

    plaintext = 'This is a plaintext'

# Generated at 2022-06-21 00:03:39.512776
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    obj = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;test\n63613632623831643337363933616662623336626261666138613235323765306539643134386264330\na')
    class AClass(object):
        pass
    a = AClass()
    a.__str__ = lambda self: "xxx"
    result = obj.__radd__(a)
    assert result == u'xxx$ANSIBLE_VAULT;1.1;AES256;test\n63613632623831643337363933616662623336626261666138613235323765306539643134386264330\na'


# Generated at 2022-06-21 00:03:51.927854
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    class DummyVault(object):
        def __init__(self):
            self.secret = "secret"
            self.iv = "iv"
            self.hmac_key = "hmac_key"
        def decrypt(self, ciphertext, obj=None):
            return "wee"
        def is_encrypted(self, ciphertext):
            return True

    # We pass in sys.getdefaultencoding() since that is
    # the normal encoding of the strings that come out of Babel.  If we fix it
    # to be 'utf8' then we will use the hard-coded initialization vector
    # '\x00' * 16, so we need to run the test with the default encoding as
    # well.
    encoding = sys.getdefaultencoding()

# Generated at 2022-06-21 00:03:55.088657
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    obj = AnsibleBaseYAMLObject()
    assert obj.ansible_pos is None
    obj.ansible_pos = ('data1', 1, 2)
    assert obj._data_source == 'data1'
    assert obj._line_number == 1
    assert obj._column_number == 2
    assert obj.ansible_pos == ('data1', 1, 2)

# unit test for the constructor of AnsibleUnicode

# Generated at 2022-06-21 00:03:58.459542
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    avue = AnsibleVaultEncryptedUnicode(u'\u212B')
    assert avue.casefold() == u'\u00e5'


# Generated at 2022-06-21 00:04:13.468302
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Construct a ansible vault
    vault = AnsibleVaultEncryptedUnicode.__new__(AnsibleVaultEncryptedUnicode)
    vault.__init__("bar bar")
    vault._ciphertext = "foo foo"
    vault.vault = None

    # Construct a ansible vault 2
    vault2 = AnsibleVaultEncryptedUnicode.__new__(AnsibleVaultEncryptedUnicode)
    vault2.__init__("bar bar")
    vault2.vault = None
    vault2.data = "foo foo"

    # Test to see that the method __add__ of class AnsibleVaultEncryptedUnicode returns without error
    vault + "foo"
    vault + vault2



# Generated at 2022-06-21 00:04:20.070573
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    import random

    test_pass = 0

    for i in range(1000):
        test_string = str(random.randint(1, 10000))

        enc_obj = AnsibleVaultEncryptedUnicode.from_plaintext(
            test_string,
            vault.VaultLib('test'),
            'test'
        )

        if enc_obj < 10:
            test_pass += 1

    assert test_pass == 1000


# Generated at 2022-06-21 00:04:22.488817
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    string = AnsibleVaultEncryptedUnicode("hello ansible")
    assert string.title() == "Hello Ansible"



# Generated at 2022-06-21 00:04:25.702187
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    avue = AnsibleVaultEncryptedUnicode('ansible_vault_encrypted_unicode')
    assert avue.rsplit('_') == ['ansible', 'vault', 'encrypted', 'unicode']



# Generated at 2022-06-21 00:04:31.279982
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    # This is a test for method __radd__ of class AnsibleVaultEncryptedUnicode
    # This is a test for method __radd__ of class AnsibleVaultEncryptedUnicode
    # This is a test for method __radd__ of class AnsibleVaultEncryptedUnicode
    AVEU = AnsibleVaultEncryptedUnicode
    try:
        AVEU.__radd__(True)
    except Exception as e:
        print(e)
        sys.exit(1)
    sys.exit(0)


# Generated at 2022-06-21 00:04:37.177157
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    avu = AnsibleVaultEncryptedUnicode("test")

    assert avu >= "t"
    assert avu >= None
    assert not avu >= "test"
    assert not avu >= AnsibleVaultEncryptedUnicode("t")
    assert not avu >= AnsibleVaultEncryptedUnicode("test")


# Generated at 2022-06-21 00:04:39.193184
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    u = AnsibleVaultEncryptedUnicode(u'123')
    assert u.__reversed__() == '321'



# Generated at 2022-06-21 00:04:47.811429
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    # Test without secret
    avu = AnsibleVaultEncryptedUnicode('fake_ciphertext')
    assert repr(avu) == to_text('fake_ciphertext')

    # Test with secret
    import vault
    fake_secret = 'secret'
    fake_vault = vault.VaultLib(fake_secret)
    avu = AnsibleVaultEncryptedUnicode('fake_ciphertext')
    avu.vault = fake_vault
    assert repr(avu) == to_text('SECRET')

# Generated at 2022-06-21 00:04:59.511914
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    not_eq = lambda ansible_vault_encrypted_unicode, other: ansible_vault_encrypted_unicode.__ne__(other)
    other_ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('foo')
    other_ansible_vault_encrypted_unicode.vault = True
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('foo')
    ansible_vault_encrypted_unicode.vault = True
    assert not not_eq(ansible_vault_encrypted_unicode, other_ansible_vault_encrypted_unicode)
    other_ansible_vault_encrypted_unicode = 'foo'

# Generated at 2022-06-21 00:05:03.260644
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    obj = AnsibleVaultEncryptedUnicode(b"")

    # Byte string
    assert obj.__radd__(b"abc") == b"abc"

    # Unicode
    assert obj.__radd__(u"def") == u"def"


# Generated at 2022-06-21 00:05:17.898273
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    from ansible.module_utils.ansible_vault import VaultLib
    from ansible_collections.ansible.community.plugins.module_utils.vault import VaultSecret
    vault_secret = VaultSecret('password')
    vault = VaultLib(vault_secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('AAsult', vault, 'password')
    assert avu.isalnum()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('1234', vault, 'password')
    assert avu.isalnum()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('1', vault, 'password')
    assert avu.isalnum()

# Generated at 2022-06-21 00:05:27.023554
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    a = AnsibleVaultEncryptedUnicode('secret')
    encrypted_a = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3437356364623161613436393738306536336637373561343134633337313762653938373330396535\n          6431343362313933396436316262623965331a38303634653166666433303563343139353961363034\n          3064333536646466306436363131643238636638353364386462366434356562386330623666363134\n          6265663733633064\n          "
    assert a * 5 == encrypted_a * 5



# Generated at 2022-06-21 00:05:36.286253
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    u = AnsibleVaultEncryptedUnicode('hello world')

    # test positive index
    assert u[1:3] == 'el'

    # test negative index
    assert u[-6:-4] == 'or'

    # test full slice
    assert u[:] == 'hello world'

    # test slice with out of range index
    assert u[100:1000] == ''

    # test one step slice
    assert u[1:2] == 'e'

    # test slice where start index is out of range
    assert u[100:1000] == ''

    # test step slice
    assert u[1:11:2] == 'el ol'

    # test step slice with out of range index
    assert u[1:100:2] == 'el ol'

    # test step slice with negative indexes, and out of range

# Generated at 2022-06-21 00:05:41.506959
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    # TODO: this code runs but have no tests
    avueu = AnsibleVaultEncryptedUnicode('test')
    assert repr(avueu) == '<AnsibleVaultEncryptedUnicode object>'
    assert repr(avueu) != '<AnsibleVaultEncryptedUnicode object '


# Generated at 2022-06-21 00:05:51.785754
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    import unittest

    class AnsibleVaultEncryptedUnicode_TestCase(unittest.TestCase):
        def test___gt__without_vault(self):
            """__gt__ should return False if vault is not set"""
            data = 'data'
            avu = AnsibleVaultEncryptedUnicode(data)
            self.assertFalse(avu.__gt__(data))

        def test___gt__with_vault_other_encrypted(self):
            """__gt__ should return False if vault is set and other is a vaulted string"""
            data = 'data'
            data2 = 'data2'
            vault = 'vault'
            avu = AnsibleVaultEncryptedUnicode(data)
            avu.vault = vault
            avu2 = AnsibleVaultEncryptedUn

# Generated at 2022-06-21 00:06:03.975195
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    # This tests a method that has the non-optional 'width' argument first,
    # and then an optional 'fillchar' argument at the end.
    # First we test with no 'fillchar' argument.
    password = AnsibleVaultEncryptedUnicode('hush')
    expected = 'hush'
    result = password.ljust(4)
    assert result == expected

    # Now we test with a 'fillchar' argument.
    password = AnsibleVaultEncryptedUnicode('hush')
    expected = 'hush!'
    result = password.ljust(5, '!')
    assert result == expected

    # Make sure the 'fillchar' argument is the correct type.
    password = AnsibleVaultEncryptedUnicode('hush')

# Generated at 2022-06-21 00:06:15.246032
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    try:
        assert AnsibleVaultEncryptedUnicode.from_plaintext('toto', None, None).isascii()
        assert not AnsibleVaultEncryptedUnicode.from_plaintext('toto\xe9', None, None).isascii()
    except:
        print('test_AnsibleVaultEncryptedUnicode_isascii() failed')
        raise

test_AnsibleVaultEncryptedUnicode_isascii()

try:
    # yaml is optional and may not be available
    import yaml
except ImportError:
    pass
else:
    def construct_ansible_vault(loader, node):
        ''' return a AnsibleVaultEncryptedUnicode '''
        value = loader.construct_scalar(node)
        return

# Generated at 2022-06-21 00:06:18.193397
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    s = AnsibleVaultEncryptedUnicode('Admission {price} {discount} {name}')
    mapping = {'price': '$25', 'discount': '0.9'}
    s.format_map(mapping)
    return s

# Generated at 2022-06-21 00:06:27.483790
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    assert not AnsibleVaultEncryptedUnicode('test') > 'test'
    assert AnsibleVaultEncryptedUnicode('test') > 'test123'
    assert not AnsibleVaultEncryptedUnicode('test123') > 'test'
    assert AnsibleVaultEncryptedUnicode('test') > AnsibleVaultEncryptedUnicode('test123')
    assert not AnsibleVaultEncryptedUnicode('test123') > AnsibleVaultEncryptedUnicode('test')
    # assert AnsibleVaultEncryptedUnicode('test') > 123  # this is not working for some reason


# Generated at 2022-06-21 00:06:37.778890
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:06:55.358978
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    avu = AnsibleVaultEncryptedUnicode('abc')
    avu.data = 'abc        '
    assert avu.rstrip() == 'abc'
    avu.data = 'abc\n'
    assert avu.rstrip() == 'abc\n'


yaml.add_constructor(u'tag:yaml.org,2002:str', AnsibleUnicode.yaml_constructor)
yaml.add_constructor(u'tag:yaml.org,2002:seq', AnsibleSequence.yaml_constructor)
yaml.add_constructor(u'tag:yaml.org,2002:map', AnsibleMapping.yaml_constructor)
yaml.add_representer(AnsibleUnicode, AnsibleUnicode.to_yaml)

# Generated at 2022-06-21 00:07:04.390374
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    vt = AnsibleVaultEncryptedUnicode("7-zW")
    vt.vault = 'yaml'
    vt.vault.should_decrypt = lambda x: x
    vt.vault.decrypt = lambda x, obj: "test_value"
    assert vt < 'test_value'
    assert vt < vt
    assert not vt < "test_valueX"
    assert not vt < AnsibleVaultEncryptedUnicode("7-zW")
    assert not vt < "test_value1"



# Generated at 2022-06-21 00:07:06.769819
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    avu = AnsibleVaultEncryptedUnicode("\n")
    assert avu.zfill(1) == "\n"



# Generated at 2022-06-21 00:07:14.609090
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('ansible-test-vault-password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(u'foo', vault, b'ansible-test-vault-password')
    # hash gives a different result depending if python is started with -OO or -O0
    # when hash is called from __eq__
    assert hash(avu) in [22785624, -44982364952349564]



# Generated at 2022-06-21 00:07:18.541500
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    a=AnsibleVaultEncryptedUnicode.from_plaintext("abc", vault, secret)
    b=AnsibleVaultEncryptedUnicode.from_plaintext("1", vault, secret)
    assert a.isalpha()
    assert not b.isalpha()


# Generated at 2022-06-21 00:07:24.967504
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    # invalid argument
    # float() argument must be a string or a number, not 'AnsibleVaultEncryptedUnicode'
    avu = AnsibleVaultEncryptedUnicode("a")
    with pytest.raises(TypeError) as excinfo:
        float(avu)
    assert 'float() argument must be a string or a number' in str(excinfo.value)

    # valid argument
    avu = AnsibleVaultEncryptedUnicode("3.14")
    assert float(avu) == 3.14

    # math.nan
    avu = AnsibleVaultEncryptedUnicode("nan")
    assert math.isnan(float(avu))

    # math.inf
    avu = AnsibleVaultEncryptedUnicode("inf")
    assert float(avu) == math

# Generated at 2022-06-21 00:07:33.907683
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    """
    AnsibleVaultEncryptedUnicode.__getitem__(key) method:
    Return self.data[key].  Raise TypeError if key is not an integer.
    """

    avueu = AnsibleVaultEncryptedUnicode('abc')

    assert avueu[0] == 'a'
    assert avueu[1] == 'b'
    assert avueu[2] == 'c'

    try:
        avueu['foo']
    except TypeError:
        pass
    else:
        raise AssertionError("Expected TypeError, but got no exception.")


# Generated at 2022-06-21 00:07:44.519159
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    # Setup
    s = 'abc %'
    t = 'abc %'
    v = 'abc'
    w = "%s"
    x = 'abc def %'
    y = 'abc def %'
    z = 'abc def'
    a = ["%s"]
    b = 'def %'

    # Exercise
    _s = AnsibleVaultEncryptedUnicode(s)
    _t = AnsibleVaultEncryptedUnicode(t)
    _v = AnsibleVaultEncryptedUnicode(v)
    _w = AnsibleVaultEncryptedUnicode(w)
    _x = AnsibleVaultEncryptedUnicode(x)
    _y = AnsibleVaultEncryptedUnicode(y)
    _z = AnsibleVaultEncryptedUnicode(z)


# Generated at 2022-06-21 00:07:55.936838
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    import ansible_test._internal.vault as vault_internal

    plaintext = 'Plaintext'

# Generated at 2022-06-21 00:08:06.375059
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    """ AnsibleVaultEncryptedUnicode extends the python builtin unicode, so
        I have to make sure that we don't break anything.
    """
    vault = 'test'
    secret = 'secret'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, secret)

    # Test with a AnsibleVaultEncryptedUnicode obj
    r1 = avu + avu
    s = 'foofoo'
    r2 = AnsibleVaultEncryptedUnicode.from_plaintext(s, vault, secret)
    assert s == r1
    assert r1 == r2

    # Test with a unicode obj
    s = 'bar'
    r1 = avu + s

# Generated at 2022-06-21 00:08:26.254468
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    """
    test case for isspace method of AnsibleVaultEncryptedUnicode
    """
    x = AnsibleVaultEncryptedUnicode(' ')
    assert x.isspace() is True
    x = AnsibleVaultEncryptedUnicode('\t')
    assert x.isspace() is True
    x = AnsibleVaultEncryptedUnicode('\n')
    assert x.isspace() is True
    x = AnsibleVaultEncryptedUnicode('\x0b')
    assert x.isspace() is True
    x = AnsibleVaultEncryptedUnicode('\x0c')
    assert x.isspace() is True
    x = AnsibleVaultEncryptedUnicode('\r')
    assert x.isspace() is True
    x = AnsibleVaultEncryptedUn

# Generated at 2022-06-21 00:08:32.460194
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    # test_AnsibleVaultEncryptedUnicode_isalnum_normal
    avu = AnsibleVaultEncryptedUnicode("password")
    assert avu.isalnum() is True

    # test_AnsibleVaultEncryptedUnicode_isalnum_empty
    avu = AnsibleVaultEncryptedUnicode("")
    assert avu.isalnum() is True

    # test_AnsibleVaultEncryptedUnicode_isalnum_spl_char
    avu = AnsibleVaultEncryptedUnicode("abc123$")
    assert avu.isalnum() is False



# Generated at 2022-06-21 00:08:43.758103
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    class FakeVault:
        def decrypt(self, txt, obj=None):
            return txt

    class FakeVaultError(Exception):
        pass

    def fake_exception_raiser(txt, obj=None):
        global _raised
        _raised = True
        raise FakeVaultError()

    ciphertext = 'foo'
    plaintext = 'bar'
    avue = AnsibleVaultEncryptedUnicode(ciphertext)

    fakevault = FakeVault()
    avue.vault = fakevault
    assert hash(avue) == hash(plaintext)

    _raised = False
    fakevault.decrypt = fake_exception_raiser
    assert hash(avue) == int(0xcafebabe)
    assert _raised

### BEGIN ANSIBLE VAULT CODE

# Generated at 2022-06-21 00:08:48.527966
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    '''
    >>> testobj = AnsibleVaultEncryptedUnicode('string')
    >>> result = testobj.ljust(5, '!')
    >>> assert result.data == 'string        '
    '''


# Generated at 2022-06-21 00:08:52.182622
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    obj = AnsibleMapping()
    assert isinstance(obj, dict)
    assert isinstance(obj, AnsibleMapping)
    assert isinstance(obj, AnsibleBaseYAMLObject)


# Generated at 2022-06-21 00:08:55.607831
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    test_str = AnsibleVaultEncryptedUnicode('abc123')
    assert test_str.isalnum() is True, "test_str.isalnum() should return True"


# Generated at 2022-06-21 00:09:04.127386
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    from vault import VaultLib
    vault = VaultLib()
    secret_password = "foobar"
    vault.secrets_mgr.store_secret(secret_password, our_secret=secret_password, is_encrypted=True)
    test_string = 'This Is A Test'
    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext(test_string, vault, secret_password)
    assert encrypted_string.istitle() == True
    test_string = 'this Is A Test'
    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext(test_string, vault, secret_password)
    assert encrypted_string.istitle() == False



# Generated at 2022-06-21 00:09:15.630027
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    try:
        from unittest import mock
    except ImportError:
        # Py2: unittest2 is not a normal dependency
        from ansible.compat.tests import mock
    from ansible.parsing.vault import VaultLib

    raw = 'password:  ansible'
    plaintext = b'password:  123456'
    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256\n63736564313766346666396630323163613264303839383639353861386164363464383934323862\n66336235643332333131386631303138353830356565646364326530393331303466333832666330\n'

    # If the secret parameter is missing, the isdigit method must return False

# Generated at 2022-06-21 00:09:17.589685
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    a = AnsibleVaultEncryptedUnicode("123")
    assert a.isnumeric()

# Generated at 2022-06-21 00:09:22.110377
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    avu = AnsibleVaultEncryptedUnicode(u'foo')
    assert isinstance(avu, AnsibleVaultEncryptedUnicode)
    assert isinstance(avu.__unicode__(), text_type)
    assert avu.__unicode__() == u'foo'


# Generated at 2022-06-21 00:09:40.580274
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:09:51.419587
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    # first test: sequence does not contain an AnsibleVaultEncryptedUnicode object
    seq = ['The', 'quick', 'brown', 'fox', 'jumps', 'over', 'the', 'lazy', 'dog']
    separator = AnsibleVaultEncryptedUnicode(' ')
    assert AnsibleVaultEncryptedUnicode.__radd__(separator, seq) == 'The quick brown fox jumps over the lazy dog'

    # second test: sequence contains an AnsibleVaultEncryptedUnicode object
    seq = ['The', 'quick', AnsibleVaultEncryptedUnicode('brown'), 'fox', 'jumps', 'over', 'the', 'lazy', 'dog']
    separator = AnsibleVaultEncryptedUnicode(' ')
    assert AnsibleVaultEncryptedUnicode.__radd

# Generated at 2022-06-21 00:10:00.648522
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    '''This unit test makes sure that the endswith method is working as expected
       when a prefix is provided'''
    # No need to consider the need to decrypt the instance because the endswith
    # method does not use the decrypted value
    # Create a AnsibleVaultEncryptedUnicode instance
    avu = AnsibleVaultEncryptedUnicode('foo')
    # Check the endswith method, it should be False because the provided
    # prefix is not at the end of the instance
    assert(not avu.endswith('f'))
    # Check the endswith method, it should be True because the provided
    # prefix is at the end of the instance
    assert(avu.endswith('o'))


# Generated at 2022-06-21 00:10:06.282883
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    # create instance of class AnsibleBaseYAMLObject
    host_vars = AnsibleBaseYAMLObject()
    # check of data_source, line_number and column_number are initialized as expected
    assert host_vars._data_source == None
    assert host_vars._line_number == 0
    assert host_vars._column_number == 0


# Generated at 2022-06-21 00:10:09.524081
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    avueu = AnsibleVaultEncryptedUnicode("abcde")
    avueu.vault = 'dummy'
    assert avueu.find("bc") == 1



# Generated at 2022-06-21 00:10:16.636525
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    class MockVault(object):
        def decrypt(self, ct, obj=None):
            return ct.decode('utf-8')

    v = MockVault()
    ct = 'vaulted_value'.encode('utf-8')
    avue = AnsibleVaultEncryptedUnicode(ct)
    avue.vault = v

    assert hash(avue) == hash(ct.decode('utf-8'))



# Generated at 2022-06-21 00:10:28.066060
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    print('Testing AnsibleVaultEncryptedUnicode.isidentifier()...')
    if AnsibleVaultEncryptedUnicode('test').isidentifier():
        print('FAILED: AnsibleVaultEncryptedUnicode(test).isidentifier() should be False')
    if AnsibleVaultEncryptedUnicode('TEST').isidentifier():
        print('FAILED: AnsibleVaultEncryptedUnicode(TEST).isidentifier() should be False')
    if not AnsibleVaultEncryptedUnicode('_test').isidentifier():
        print('FAILED: AnsibleVaultEncryptedUnicode(_test).isidentifier() should be True')

# Generated at 2022-06-21 00:10:36.039166
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    # Return a complex number constructed from a string or number.
    #
    # This uses the same algorithm as the built-in complex() constructor, but
    # returns the complex value stored in the AnsibleVaultEncryptedUnicode, rather than
    # creating a new object.
    #
    # Note:
    #
    # If a derived class defines __complex__(), then this method is not
    # accessible through the base class, as described in the Namespace
    # packages section of PEP 420.

    # Commented out because it is not used by the AnsibleTestCase
    # eval_complex = 1.j

    # This does not seem to be used by AnsibleVaultEncryptedUnicode
    # self_complex = self.data.__complex__()
    pass



# Generated at 2022-06-21 00:10:48.069011
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    '''
    Unit test for join from class AnsibleVaultEncryptedUnicode

    :return: None
    '''
    from ansible.parsing.vault import VaultLib
    vault_secret = 'ansible'
    vault_id = '$ANSIBLE_VAULT;8.3;AES256;test'

    # Run the test
    plain_text = "Hello World!"
    vault = VaultLib(vault_secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(
            plain_text, vault, vault_secret)
    avu_list = [avu]
    avu_join = avu.join(avu_list)
    avu_join = to_text(avu_join, errors='surrogate_or_strict')

    # Check the

# Generated at 2022-06-21 00:10:53.532614
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    ciphertext = to_bytes("hello world")
    aveu = AnsibleVaultEncryptedUnicode(ciphertext)
    aveu.vault = None
    assert aveu.replace(to_text("hello"), "") == to_text(" world")
    assert aveu.replace(to_text("hello"), to_text("foo")) == to_text("foo world")
