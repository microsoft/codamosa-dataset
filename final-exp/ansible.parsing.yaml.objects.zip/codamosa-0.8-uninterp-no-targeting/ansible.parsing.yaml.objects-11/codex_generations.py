

# Generated at 2022-06-21 00:01:30.020895
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    avu = AnsibleVaultEncryptedUnicode(u"abc123 ")
    expected = "abc123"
    actual = avu.rstrip()
    assert actual == expected, "Actual: %s, Expected: %s" % (actual, expected)
    assert actual == expected, "Actual: %r, Expected: %r" % (actual, expected)



# Generated at 2022-06-21 00:01:37.977407
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    # Copy the real string class to use here
    # so we can use the methods we are not
    # overriding
    class TestString(AnsibleUnicode):
        pass

    # These should all be equal (same as a string)
    s = TestString('foo')
    assert s == 'foo'
    assert s == s.data
    assert s == s.__class__('foo')
    assert 'foo' == s
    assert s == TestString('foo')
    assert s == u'foo'

    # These should all be not equal
    s = TestString('foo')
    assert s != 'bar'
    assert s != s.__class__('bar')
    assert 'bar' != s
    assert s != TestString('bar')
    assert s != u'bar'

    # These should still be methods we are not overriding

# Generated at 2022-06-21 00:01:49.420202
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    # strings
    assert to_text(b'    string  ').strip() == 'string'
    assert to_text(b'    string  ').lstrip() == 'string  '
    assert to_text(b'    string  ').rstrip() == '    string'
    assert to_text(b's   tring  ').strip(b' ') == 'string'
    assert to_text(b's   tring  ').lstrip(b' ') == 'tring  '
    assert to_text(b's   tring  ').rstrip(b' ') == 's   tring'

    # AnsibleVaultEncryptedUnicode without .vault
    avu = AnsibleVaultEncryptedUnicode(b'    string  ')

# Generated at 2022-06-21 00:01:56.997845
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    from ansible.parsing.vault import VaultLib
    secret = 'secret'
    vault = VaultLib([secret])
    assert AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, secret).zfill(3) == 'abc'
    assert AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, secret).zfill(4) == '0abc'
    assert AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, secret).zfill(5) == '00abc'



# Generated at 2022-06-21 00:02:00.396996
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    am = AnsibleMapping()
    assert isinstance(am, AnsibleBaseYAMLObject)
    assert isinstance(am, dict)


# Generated at 2022-06-21 00:02:07.029808
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    #
    # Test case #1
    #
    avu = AnsibleVaultEncryptedUnicode('TestString')
    other = 'TestString'

    assert avu.__ne__(other)

    #
    # Test case #2
    #
    avu = AnsibleVaultEncryptedUnicode('TestString')
    other = '7esTString'

    assert avu.__ne__(other)



# Generated at 2022-06-21 00:02:16.779057
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import os
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError
    try:
      dir_path = os.path.dirname(os.path.realpath(__file__))
      vault_pass_test_path = os.path.join(dir_path, 'vault_pass_test')
      vault_pass_test_path = os.path.abspath(vault_pass_test_path)
      v = VaultLib(vault_pass_test_path)
    except AnsibleVaultError as e:
      print(e)

    text = "qwerty"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(text, v, 'test_pass')

# Generated at 2022-06-21 00:02:24.800661
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    from ansible.errors import AnsibleError
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('', None)
    vault._secret = 'ansible'
    vault._has_ciphertext = True
    obj = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, vault._secret)
    t_obj = obj.data
    assert t_obj.startswith('test')
    assert not t_obj.startswith('test1')


# Generated at 2022-06-21 00:02:31.277271
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    from ansible.parsing.vault import VaultLib
    secret = "secret"
    vault = VaultLib(password=secret)

    test = AnsibleVaultEncryptedUnicode.from_plaintext("encrypted string: {}", vault, secret)
    assert test.vault
    assert test.is_encrypted()
    assert test.format("abcde") == "encrypted string: abcde"



# Generated at 2022-06-21 00:02:39.860849
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    # Test case: character strings
    avue = AnsibleVaultEncryptedUnicode("abc")
    assert avue.isprintable() is True
    avue = AnsibleVaultEncryptedUnicode("a\x81c")
    assert avue.isprintable() is False
    avue = AnsibleVaultEncryptedUnicode("abc\x81")
    assert avue.isprintable() is False

    # Test case: object
    obj = object()
    avue = AnsibleVaultEncryptedUnicode(obj)
    assert avue.isprintable() is False

    # Test case: text string
    avue = AnsibleVaultEncryptedUnicode("abc")
    assert avue.isprintable() is True

# Generated at 2022-06-21 00:03:00.424007
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    plaintext = 'foobarbaz'
    mock_vault = type('MockVault', (object, ),
                      {'encrypt': classmethod(lambda cls, s, secret: s),
                       'is_encrypted': classmethod(lambda cls, s: False),
                       'decrypt': classmethod(lambda cls, s, obj=None: to_bytes(s)),
                       })
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, mock_vault, secret='password')

    # Test backward slice
    slice_step = -1
    actual = to_text(''.join(avu[::slice_step]), errors='surrogate_or_strict')
    assert actual == 'zabraboof'



# Generated at 2022-06-21 00:03:07.953015
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    obj1 = AnsibleBaseYAMLObject()
    assert obj1.ansible_pos is None
    obj1.ansible_pos = ['my_source_file', 42, 27]
    assert obj1.ansible_pos == ('my_source_file', 42, 27)
    obj2 = AnsibleBaseYAMLObject()
    obj2._data_source = 'my_source_file'
    obj2._line_number = 42
    obj2._column_number = 27
    assert obj2.ansible_pos == ('my_source_file', 42, 27)



# Generated at 2022-06-21 00:03:14.545990
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    # Given a valid AnsibleVaultEncryptedUnicode object
    avueobject = AnsibleVaultEncryptedUnicode(b'123')
    # When call method __int__ with no arguments
    i = avueobject.__int__()
    # Then the result is a int
    assert isinstance(i, int)
    # And the result equal 123
    assert i == 123


# Generated at 2022-06-21 00:03:18.346594
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    '''
    Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
    '''
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert (avu * 2) == 'foofoo'
    return True



# Generated at 2022-06-21 00:03:30.421509
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:03:35.848741
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    from ansible.parsing.vault import VaultLib
    plaintext = b'Hello World'
    vault = VaultLib(None, 'password')
    value = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, 'password')
    assert value.index(plaintext) == 0


# Generated at 2022-06-21 00:03:39.619281
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    vault = vaultlib.VaultLib('test')
    secret = 'test'
    value = 'mytestvalue'
    enc_value = AnsibleVaultEncryptedUnicode.from_plaintext(value, vault, secret)
    assert 'test' == enc_value.rindex('test')



# Generated at 2022-06-21 00:03:42.164543
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    a = AnsibleVaultEncryptedUnicode('AAAA')
    assert a >= 'BBBB'



# Generated at 2022-06-21 00:03:46.556248
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    testValue = AnsibleVaultEncryptedUnicode.from_plaintext('test', 0, '')
    # The capitalize method returns the original string with first character capitalized.
    assert 'Test' == testValue.capitalize()


# Generated at 2022-06-21 00:03:51.363319
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    a = AnsibleVaultEncryptedUnicode(b'abc')
    assert repr(a) == repr('abc')

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# TODO: make this more generic, like copy() / deepcopy()

# Generated at 2022-06-21 00:04:34.120210
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    '''
    unit test method __repr__ of class AnsibleVaultEncryptedUnicode
    '''
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.__repr__() == "'test'"


# Generated at 2022-06-21 00:04:41.807126
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("top secret", None, None)
    print("Text instance is " + str(avu))
    assert avu.startswith("top s")
    assert avu.startswith("top ")
    assert avu.startswith("top")
    assert avu.startswith("t")

    avu = AnsibleVaultEncryptedUnicode.from_plaintext("top secret", None, None)
    print("\nText instance is " + str(avu))
    assert avu.startswith("top s")
    assert avu.startswith("top ")
    assert avu.startswith("top")
    assert avu.startswith("t")

if __name__ == "__main__":
    test_

# Generated at 2022-06-21 00:04:49.735286
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    u = AnsibleVaultEncryptedUnicode()
    assert not u.isalpha()
    u.data = 'a'
    assert u.isalpha()
    u.data = '\u0663'  # Arabic-Indic digit three
    assert not u.isalpha()
    u.data = '\u06F3'  # Extended Arabic-Indic digit three
    assert not u.isalpha()

test_AnsibleVaultEncryptedUnicode_isalpha()



# Generated at 2022-06-21 00:04:53.387546
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    assert AnsibleVaultEncryptedUnicode('abc') % 'abc' == 'abcabc'
    assert AnsibleVaultEncryptedUnicode('abc') % 1 == 'abc1'



# Generated at 2022-06-21 00:05:04.067182
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    if _sys.version_info[0] == 3:
        raise AssertionError("Not valid for Python 3")

    from ansible.parsing.vault import VaultLib

    # Build the test objects
    password = 'ansible'
    vault = VaultLib(password)
    string = '4'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(string, vault, password)

    # Test the object method under test
    try:
        avu__int__ = avu.__int__()
    except:
        raise AssertionError("Could not convert a AnsibleVaultEncryptedUnicode object to an integer")

# Generated at 2022-06-21 00:05:07.970892
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    obj = AnsibleVaultEncryptedUnicode('my test')
    assert repr(obj) == 'my test'


# Generated at 2022-06-21 00:05:18.802948
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__(): # noqa
    """ test method AnsibleVaultEncryptedUnicode.__ne__() """

    avu = AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\n383462353a6339396335323937626264623565336662326566363635663939643962383531666264\n39373764646134376333326263623233313661376136613232636266313163626438643965636235\n32663665633231626466313337306239636133623262373765343064353234396430633663653436\n366364646565663533\n')
    avu.vault = None

# Generated at 2022-06-21 00:05:25.657813
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    encrypted_text = AnsibleVaultEncryptedUnicode('\nMY_SECRET\n')
    plain_text = '\nMY_SECRET\n'
    assert encrypted_text.rstrip() == plain_text.rstrip()

    encrypted_text = AnsibleVaultEncryptedUnicode('\nMY_SECRET\n')
    plain_text = '\nMY_SECRET'
    assert encrypted_text.rstrip('\n') == plain_text.rstrip('\n')


# Generated at 2022-06-21 00:05:29.577354
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    # issue #23286
    x = AnsibleVaultEncryptedUnicode('helloworld')
    assert x.rfind('w') == len(x) - 2
    assert x.rfind('w') == x.rfind(AnsibleVaultEncryptedUnicode('w'))


# Generated at 2022-06-21 00:05:39.587961
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    assert AnsibleVaultEncryptedUnicode('test').zfill(5) == '0test'
    assert AnsibleVaultEncryptedUnicode('12345').zfill(5) == '12345'
    assert AnsibleVaultEncryptedUnicode('-12').zfill(5) == '-0012'
    assert AnsibleVaultEncryptedUnicode('+12').zfill(5) == '+0012'
    assert AnsibleVaultEncryptedUnicode('-0012').zfill(5) == '-0012'
    assert AnsibleVaultEncryptedUnicode('-00012').zfill(5) == '-00012'
    assert AnsibleVaultEncryptedUnicode('').zfill(5) == '00000'


# Generated at 2022-06-21 00:06:09.411372
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    ciphertext = b'asdfasdf'

    # Test for the positive case
    avueu = AnsibleVaultEncryptedUnicode(ciphertext)
    avueu.data = '123'
    assert avueu.isdigit() is True

    # Test for the negative case
    avueu = AnsibleVaultEncryptedUnicode(ciphertext)
    avueu.data = 'ABC'
    assert avueu.isdigit() is False


# Generated at 2022-06-21 00:06:16.375496
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    assert AnsibleVaultEncryptedUnicode('abc').startswith(AnsibleVaultEncryptedUnicode('a'))
    assert not AnsibleVaultEncryptedUnicode('abc').startswith(AnsibleVaultEncryptedUnicode('b'))
    assert not AnsibleVaultEncryptedUnicode('abc').startswith(AnsibleVaultEncryptedUnicode('c'))
    assert not AnsibleVaultEncryptedUnicode('abc').startswith(AnsibleVaultEncryptedUnicode('ab'))
    assert not AnsibleVaultEncryptedUnicode('abc').startswith(AnsibleVaultEncryptedUnicode('bc'))

# Generated at 2022-06-21 00:06:22.080213
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    """
    Tests the method 'rjust' of class AnsibleVaultEncryptedUnicode
    """
    string = "The quick brown fox jumps over the lazy dog"
    result = AnsibleVaultEncryptedUnicode(string).rjust(36, "=")
    assert( result == "===========The quick brown fox jumps over the lazy dog")


# Generated at 2022-06-21 00:06:33.729197
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():

    # This is the expected message when a non-tuple is passed in
    error_msg = "ansible_pos can only be set with a tuple/list of three values: source, line number, column number"

    # Test the init function with a non-tuple
    try:
        none_tuple = AnsibleSequence("test")
    except AssertionError as e:
        assert error_msg == to_text(e, nonstring='passthru')

    # Test the init function with two non-tuple
    try:
        none_tuple = AnsibleSequence("test", "test")
    except AssertionError as e:
        assert error_msg == to_text(e, nonstring='passthru')

    # Test the init function with a tuple
    test_tuple = ("file", 1, 10)
   

# Generated at 2022-06-21 00:06:38.401896
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    plaintext_data = "abc def ghi jkl"
    plaintext_data_expected = plaintext_data.rsplit(' ', 2)
    plaintext_data_rsplit = AnsibleVaultEncryptedUnicode(plaintext_data).rsplit(' ', 2)
    assert plaintext_data_rsplit == plaintext_data_expected



# Generated at 2022-06-21 00:06:50.648876
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    test_string = 'a' + chr(0x0d) + 'b' + chr(0x0a) + 'c' + chr(0x85)
    # 0x0d and 0x0a are the hex values for the line feed and carriage return characters
    # 0x85 is a unicode next line character
    avu = AnsibleVaultEncryptedUnicode(test_string)
    lines = avu.splitlines()
    assert lines[0] == 'a', 'First line wrong'
    assert lines[1] == 'b', 'Second line wrong'
    assert lines[2] == 'c', 'Third line wrong'
    assert len(lines) == 3, 'Number of lines wrong'

# End unit test


# Generated at 2022-06-21 00:06:52.217457
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    # Testing if function handles well the string
    pass

# Generated at 2022-06-21 00:06:57.355372
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    assert AnsibleVaultEncryptedUnicode('foo').ljust(5, '+') == 'foo++'
    assert AnsibleVaultEncryptedUnicode('foo').ljust(5) == 'foo  '
    assert AnsibleVaultEncryptedUnicode('foo').ljust(3, '+') == 'foo'


# Generated at 2022-06-21 00:07:05.276406
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    try:
        assert AnsibleVaultEncryptedUnicode('foo').center(10) == '   foo    '
        assert AnsibleVaultEncryptedUnicode('foo').center(10, '-') == '---foo----'
        assert AnsibleVaultEncryptedUnicode('foo').center(10, '=') == '===foo===='
    except AssertionError:
        print('test_AnsibleVaultEncryptedUnicode_center() failed.')


# Generated at 2022-06-21 00:07:16.308314
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    msg = '\n'.join(['foo', 'bar', '', '', '\n', 'baz'])
    avu = AnsibleVaultEncryptedUnicode(msg)

    lines = avu.splitlines()
    assert lines == ['foo', 'bar', '', '', '', 'baz']

    lines = avu.splitlines(True)
    assert lines == ['foo\n', 'bar\n', '\n', '\n', '\n', 'baz']

    msg = '\n'.join(['foo', 'bar', '\n', 'baz'])
    avu = AnsibleVaultEncryptedUnicode(msg)

    lines = avu.splitlines()
    assert lines == ['foo', 'bar', '', 'baz']


# Generated at 2022-06-21 00:07:44.036724
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    avu1 = AnsibleVaultEncryptedUnicode("45")
    avu2 = AnsibleVaultEncryptedUnicode("-45")
    avu3 = AnsibleVaultEncryptedUnicode("+45")
    avu4 = AnsibleVaultEncryptedUnicode("+4.5")
    avu5 = AnsibleVaultEncryptedUnicode("4.5")
    avu6 = AnsibleVaultEncryptedUnicode("45e3")
    avu7 = AnsibleVaultEncryptedUnicode("345.5")
    avu8 = AnsibleVaultEncryptedUnicode("45+")
    avu9 = AnsibleVaultEncryptedUnicode("0.45")
    avu10 = AnsibleVaultEncryptedUnicode("4e+05")
    av

# Generated at 2022-06-21 00:07:51.091853
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    class _Vault(object):
        def __init__(self, version, secret):
            self.version = version
            self.secret = secret

        def encrypt(self, data, secret):
            return 'vault("%s", b"%s")' % (secret, data)

        def decrypt(self, data, obj=None):
            secret = self.secret
            if obj and obj.vault:
                secret = obj.vault.secret
            return data + ':(' + secret

        def load(self, stream):
            return stream.data.strip(b'"')

        def is_encrypted(self, data):
            return 'vault(' in data

    vault_obj = _Vault(1, 'mysecret')
    ciphertext = b'foo'

# Generated at 2022-06-21 00:08:03.400487
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    assert AnsibleVaultEncryptedUnicode("foo").splitlines() == ["foo"]
    assert AnsibleVaultEncryptedUnicode("foo bar").splitlines() == ["foo bar"]
    assert AnsibleVaultEncryptedUnicode("foo\nbar").splitlines() == ["foo", "bar"]
    assert AnsibleVaultEncryptedUnicode("foo\nbar\n").splitlines() == ["foo", "bar"]
    assert AnsibleVaultEncryptedUnicode("foo\r\nbar\r\n").splitlines() == ["foo", "bar"]
    assert AnsibleVaultEncryptedUnicode("foo\r\nbar\n").splitlines() == ["foo", "bar"]

# Generated at 2022-06-21 00:08:09.254138
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    """unit test for AnsibleVaultEncryptedUnicode.__complex__ method

    Test case for existing __complex__ method
    """
    if not hasattr(AnsibleVaultEncryptedUnicode, "__complex__"):
        return

    avu = AnsibleVaultEncryptedUnicode("1.0e+00+1.0e+00j")
    result = avu.__complex__()
    assert isinstance(result, complex)
    assert result == 1.0e+00+1.0e+00j


# Generated at 2022-06-21 00:08:21.281052
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    s = AnsibleVaultEncryptedUnicode("foo")
    assert s.replace("oo", "a") == "fa"
    assert s.replace("o", "a") == "fa"
    assert s.replace("f", "a") == "ao"
    assert s.replace("o", AnsibleVaultEncryptedUnicode("a")) == "fa"
    assert s.replace("o", "a") == "fa"
    assert s.replace("o", AnsibleVaultEncryptedUnicode("a")) == "fa"
    assert s.replace("f", AnsibleVaultEncryptedUnicode("a")) == "ao"

    t = "abcd"
    assert s.replace("f", t) == "abcdoo"
    assert s.replace("o", t) == "fabcdabcd"


# Generated at 2022-06-21 00:08:26.627491
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    password = 'secret'
    vault = VaultLib(password)
    encdata = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, password)
    print(encdata)
    assert encdata.endswith('t')
    assert encdata.endswith('st')
    assert not encdata.endswith('l')


# Generated at 2022-06-21 00:08:37.773104
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    # This function tests join method of class AnsibleVaultEncryptedUnicode
    # Calling join with a list
    l = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    s = AnsibleVaultEncryptedUnicode('')
    aux = AnsibleVaultEncryptedUnicode('abcdefghijklmnopqrstuvwxyz')
    assert aux == s.join(l)
    # calling join with a string
    s = AnsibleVaultEncryptedUnicode('')
    aux = AnsibleVaultEncryptedUnicode('abcdefghijklmnopqrstuvwxyz')

# Generated at 2022-06-21 00:08:43.921872
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    # Arrange
    from ansible.parsing.vault import VaultLib
    plaintext = 'sekrit'
    secret = 'password'
    vault = VaultLib([secret])
    ciphertext = vault.encrypt(plaintext, secret)
    avueu = AnsibleVaultEncryptedUnicode(ciphertext)
    avueu.vault = vault

    # Act
    result = avueu.format()

    # Assert
    assert plaintext == result


# Generated at 2022-06-21 00:08:56.380888
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    # We only test with Python 2, because in Python 3 the __repr__() of
    # AnisbleVaultEncryptedUnicode is different from the one of Python 2
    if _sys.version_info.major != 2:
        return
    # AnsibleVaultEncryptedUnicode objects should appear in quotes
    # in the representation
    assert repr(AnsibleVaultEncryptedUnicode(u"outside")) == 'u"""outside"""'
    assert repr(AnsibleVaultEncryptedUnicode(u"inside \"\"\"")) == 'u"""inside \\""""'
    assert repr(AnsibleVaultEncryptedUnicode(u"inside \'\'\'")) == 'u"""inside \'\'\'"""'
    assert repr(AnsibleVaultEncryptedUnicode(u"inside \'\' and \"\""))

# Generated at 2022-06-21 00:09:03.485011
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    avu = AnsibleVaultEncryptedUnicode("foo")
    assert avu.lstrip("f") == "oo"
    assert avu.lstrip("o") == "foo"
    assert avu.lstrip("x") == "foo"
    avu = AnsibleVaultEncryptedUnicode("")
    assert avu.lstrip("x") == ""
    assert avu.lstrip("") == ""

    assert avu.lstrip("f") == ""
    assert avu.lstrip("fo") == ""
    assert avu.lstrip("foo") == ""
    assert avu.lstrip("xfoo") == ""

    avu = AnsibleVaultEncryptedUnicode("foobar")
    assert avu.lstrip("foo") == "bar"


# Generated at 2022-06-21 00:09:43.399118
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    test = AnsibleVaultEncryptedUnicode("Hello World", None)
    assert not test.isupper()


# Generated at 2022-06-21 00:09:48.434084
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    """
    Test of method AnsibleVaultEncryptedUnicode.zfill()
    """
    s = "foo"
    nb_char_added = 10
    expected_result = "0000000foo"

    result = AnsibleVaultEncryptedUnicode(s).zfill(len(s)+nb_char_added)

    assert result == expected_result


# Generated at 2022-06-21 00:09:50.549710
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    avu = AnsibleVaultEncryptedUnicode('VARIABLE')
    assert avu.capitalize() == 'VARIABLE'


# Generated at 2022-06-21 00:09:53.468838
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    avu = AnsibleVaultEncryptedUnicode(b'test')
    assert(len(avu) == 4)

    avu = AnsibleVaultEncryptedUnicode(b'')
    assert(len(avu) == 0)


# Generated at 2022-06-21 00:09:56.360424
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    v = AnsibleVaultEncryptedUnicode('abc')
    assert not v.isdecimal()
    v = AnsibleVaultEncryptedUnicode('1')
    assert v.isdecimal()


# Generated at 2022-06-21 00:10:08.376400
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    # This will fail because vault is not defined
    # The unit test Runner will do a git grep AnsibleVaultEncryptedUnicode and
    # then poaches these unit tests to run them so no real problem here
    vtext = AnsibleVaultEncryptedUnicode('aa:bb:cc')
    (before, sep, after) = vtext.rpartition(':')
    assert(':' == sep)
    assert('aa:bb' == before)
    assert('cc' == after)


# internal object to track the class names of last object generated by AnsibleBaseAnsibleYAMLObject
# used for warning only

ANSIBLESTD = {
    'Unicode': AnsibleUnicode,
    'Mapping': AnsibleMapping,
    'Sequence': AnsibleSequence,
}


# Generated at 2022-06-21 00:10:15.329275
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('vaultpass')
    itemA = AnsibleVaultEncryptedUnicode.from_plaintext(u'Hello', vault, u'vaultpass')
    assert itemA > u'Bye'
    itemB = AnsibleVaultEncryptedUnicode.from_plaintext(u'Bye', vault, u'vaultpass')
    assert not itemB > u'Hello'



# Generated at 2022-06-21 00:10:17.663837
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    assert to_text(AnsibleVaultEncryptedUnicode.from_plaintext(' a ', None, 'a').strip()) == 'a'



# Generated at 2022-06-21 00:10:29.206824
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    from ansible.module_utils.common._collections_compat import Mapping

    data = {
        'key1': 'value1',
        'key2': 2,
        'key3': True,
        'key4': None,
        'key5': [1, 2, 3],
        'key6': {
            'subkey1': 'subvalue1',
            'subkey2': 2,
            'subkey3': True,
            'subkey4': None,
            'subkey5': [1, 2, 3],
            'subkey6': {},
        },
    }
    # Test the constructor of the base class dict

    # keys, values and items are returned in YAML document order,
    # rather than in arbitrary order as they are in python dicts.
    # As a result, only the

# Generated at 2022-06-21 00:10:35.028764
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    s = AnsibleVaultEncryptedUnicode("abc")
    assert s >= "abc"
    assert not s >= "abcd"
    assert not s >= "ab"
    assert not s >= [1, 2, 3]

    s = AnsibleVaultEncryptedUnicode("[1,2,3]")
    assert s >= [1, 2, 3]
    assert not s >= [1, 2, 3, 4]
    assert not s >= [1, 2]
    assert not s >= "abc"

