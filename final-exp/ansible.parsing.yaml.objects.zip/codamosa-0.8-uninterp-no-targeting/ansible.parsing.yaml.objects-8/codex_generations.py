

# Generated at 2022-06-21 00:01:30.459162
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    # given
    data = '12345'
    avu = AnsibleVaultEncryptedUnicode(data.encode())
    # when
    result = avu.isdecimal()
    # then
    assert(result is True)



# Generated at 2022-06-21 00:01:37.977204
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    from ansible.parsing.vault import VaultLib

    secret = b'@ns1bl3'
    vault = VaultLib(secret)
    encrypted_text = AnsibleVaultEncryptedUnicode.from_plaintext(b'hello world', vault, secret)
    decrypted_text = vault.decrypt(encrypted_text._ciphertext, obj=encrypted_text)
    assert str(encrypted_text) == decrypted_text



# Generated at 2022-06-21 00:01:49.420394
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    a = AnsibleVaultEncryptedUnicode("The Test String")
    assert(a.istitle() == True)
    a = AnsibleVaultEncryptedUnicode("The Test string")
    assert(a.istitle() == False)
    a = AnsibleVaultEncryptedUnicode("The Test String ")
    assert(a.istitle() == False)
    a = AnsibleVaultEncryptedUnicode("\tThe Test String")
    assert(a.istitle() == False)
    a = AnsibleVaultEncryptedUnicode("\tThe Test \tString")
    assert(a.istitle() == False)
    a = AnsibleVaultEncryptedUnicode("The Test \tString\t")
    assert(a.istitle() == False)

test_AnsibleVault

# Generated at 2022-06-21 00:02:01.076881
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    object_class = AnsibleVaultEncryptedUnicode(to_bytes('John Doe'))
    assert object_class.swapcase() == 'jOHN dOE'
    object_class = AnsibleVaultEncryptedUnicode(to_bytes('John Doe'))
    object_class.vault = vault_object
    assert object_class.swapcase() == 'jOHN dOE'
    object_class = AnsibleVaultEncryptedUnicode(to_bytes('john Doe'))
    assert object_class.swapcase() == 'JOHN dOE'
    object_class = AnsibleVaultEncryptedUnicode(to_bytes('john Doe'))
    object_class.vault = vault_object
    assert object_class.swapcase() == 'JOHN dOE'
    object_class = AnsibleVault

# Generated at 2022-06-21 00:02:05.641610
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    s = AnsibleVaultEncryptedUnicode('a b c')
    assert(s.partition(' ') == ('a', ' ', 'b c'))
    assert(s.partition('x') == ('a b c', '', ''))



# Generated at 2022-06-21 00:02:09.485035
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    x = AnsibleVaultEncryptedUnicode.from_plaintext(u'{name}', None, None)
    d = {'name': 'Eric'}
    assert(x.format_map(d) == 'Eric')


# Generated at 2022-06-21 00:02:14.940846
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    from ansible import constants as C

    vault = C.DEFAULT_VAULT_ID_MATCH
    vault_pass = C.DEFAULT_VAULT_PASSWORD_FILE

    print("ansible vault test")
    f = open(vault_pass, "r")
    vault_pass = f.read().replace('\n', '')

    v = AnsibleVaultEncryptedUnicode.from_plaintext(
        "abc", vault, vault_pass)
    print(v)
    assert v.rindex('b') == 1
    assert v.rindex('c') == 2



# Generated at 2022-06-21 00:02:27.215374
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    from ansible.parsing.vault import VaultLib

    # If we encrypt "my secret" using the default password, we get the following

# Generated at 2022-06-21 00:02:37.882498
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret = VaultLib()._gen_secret()
    vault = VaultLib()


# Generated at 2022-06-21 00:02:44.461539
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    test_string = 'Test String\nascii\n中文\n'
    test_string_encrypted_bytes = to_bytes(test_string)
    avu = AnsibleVaultEncryptedUnicode(test_string_encrypted_bytes)
    assert(len(avu.splitlines()) == 3)
    assert(test_string.splitlines() == avu.splitlines())



# Generated at 2022-06-21 00:02:59.723340
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing import vault
    vault_password = 'vault_password'
    plain_text = b'foo'
    cipher_text = '$ANSIBLE_VAULT;1.1;AES256\n36613835663932316663633534613064363734303537613263346136646633356466353438323335360a35333231633938643831393532353162366435623339323132313831323764373935383636396339330a6464323737643965343635333935303061366534363135353836373464623865353338363863643436'

# Generated at 2022-06-21 00:03:07.952975
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    assert AnsibleVaultEncryptedUnicode("test").format() == "test"
    assert AnsibleVaultEncryptedUnicode("testX{}Xtest").format("1234") == "testX1234Xtest"
    assert AnsibleVaultEncryptedUnicode("X{}X{}X{}X").format("1", "2", "3") == "X1X2X3X"
    assert AnsibleVaultEncryptedUnicode("X{2}X{0}X{1}X").format("1", "2", "3") == "X3X1X2X"
    assert AnsibleVaultEncryptedUnicode("{l}_{f}_{n}").format(l="a", f="b", n="c") == "a_b_c"
    assert AnsibleVaultEncrypted

# Generated at 2022-06-21 00:03:19.103662
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault
    import ansible.parsing.vault as vault
    import ansible.parsing.vault_lib

    # ansible.constants.DEFAULT_VAULT_ID_MATCH = '$ANSIBLE_VAULT;'

# Generated at 2022-06-21 00:03:31.235975
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    # With py3k and utf8, the unvaulted string is the same as the vaulted string
    vaulted_string = b'\xe2\x98\x83'
    vault_string = u'\u2603'
    vault_obj = AnsibleVaultEncryptedUnicode(vaulted_string)
    assert vault_obj.encode() == vaulted_string
    # With py3k, when encoding to ascii, we get a surrogateescape error
    assert vault_obj.encode('ascii', 'surrogateescape') == b'?'
    # With py3k, when encoding to utf16, we get 4 bytes
    assert vault_obj.encode('utf-16') == b'\xff\xfe\x03&'
    # With py3k, when encoding to latin-

# Generated at 2022-06-21 00:03:39.790824
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    from ansible.parsing.vault import VaultLib
    secret = 'test'
    plaintext = 'test'
    vault = VaultLib([])

    avu_plaintext = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avu_plaintext.data == 'test'
    assert avu_plaintext.isidentifier()
    assert not AnsibleVaultEncryptedUnicode(plaintext).isidentifier() # without secret
    assert not AnsibleVaultEncryptedUnicode(plaintext).isidentifier()
    assert not AnsibleVaultEncryptedUnicode(None).isidentifier()

# Generated at 2022-06-21 00:03:52.156293
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    a = b"0123456789"
    b = AnsibleVaultEncryptedUnicode(a)
    assert str(b) == "0123456789"
    c = b.replace("01", "10")
    assert str(c) == "123456789"
    d = b.replace("01", "10", 1)
    assert str(d) == "123456789"
    e = b.replace(b"01", b"10", 1)
    assert str(e) == "123456789"
    f = b.replace(b, b"12")
    assert str(f) == "12"
    f = b.replace(b, AnsibleVaultEncryptedUnicode(b"12"))
    assert str(f) == "12"

# Generated at 2022-06-21 00:03:56.040864
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    test_veu = AnsibleVaultEncryptedUnicode(5)
    test_veu.data = 'method'
    result = test_veu.isidentifier()
    assert result == True



# Generated at 2022-06-21 00:04:01.558045
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    r'''>>> AnsibleVaultEncryptedUnicode('12345789').isalpha()
    False
    >>> AnsibleVaultEncryptedUnicode('abcdefg').isalpha()
    True
    >>> AnsibleVaultEncryptedUnicode('abc123').isalpha()
    False
    >>> AnsibleVaultEncryptedUnicode('abc 123').isalpha()
    False
    >>> AnsibleVaultEncryptedUnicode('!#%').isalpha()
    False
    '''
    pass


# Generated at 2022-06-21 00:04:10.396695
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    import unittest

    class Test(unittest.TestCase):
        msg = "Test for method lstrip of class AnsibleVaultEncryptedUnicode"
        def test_lstrip(self):
            inputs = ['test', "t\u0308est"]
            for input in inputs:
                expected = input[1:]
                actual = AnsibleVaultEncryptedUnicode(input).lstrip('t')
                self.assertEqual(expected, actual,
                                 msg=self.msg + '\nExpected: ' + expected + '\nActual: ' + actual)


# Generated at 2022-06-21 00:04:22.184371
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    test_cases_is_decimal = [
        (u'0', True),
        (u'0123456789', True),
        (u'0123456789.123', False),
        (u'0123456789,123', False),
        (u'', False),
        (u' ', False),
        (u'Doce', False),
        (u'O doce doce', False),
        (u'12 doce34', False),
        (u' doce1234 ', False),
        (u'\n', False),
        (u'\t', False),
    ]

    avu = AnsibleVaultEncryptedUnicode('')

# Generated at 2022-06-21 00:04:33.986676
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    avue = AnsibleVaultEncryptedUnicode("Hello, World!")
    assert avue.center(20) == "    Hello, World!    ", "left pad with spaces failed"
    assert avue.center(20, 'z') == "zzzzHello, World!zzzz", "left pad with z failed"
    assert avue.center(21, 'z') == "zzzzzHello, World!zzzzz", "left pad with z failed"


# Generated at 2022-06-21 00:04:41.755188
# Unit test for method center of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:04:49.157480
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    data = AnsibleVaultEncryptedUnicode(b'encrypted_data')
    assert not data.isalnum()
    # Encode the data
    data.data = 'Encrypted_data'
    assert not data.isalnum()
    # Encode the data
    data.data = 'Encrypted data'
    assert not data.isalnum()
    # Encode the data
    data.data = u'Encoded data 123'
    assert not data.isalnum()


# Generated at 2022-06-21 00:05:00.685072
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    assert AnsibleVaultEncryptedUnicode(u'abc').startswith(u'abc')
    assert not AnsibleVaultEncryptedUnicode(u'abc').startswith(u'def')
    assert AnsibleVaultEncryptedUnicode(u'abc').startswith(u'ab')
    assert not AnsibleVaultEncryptedUnicode(u'abc').startswith(u'bc')
    assert not AnsibleVaultEncryptedUnicode(u'abc').startswith(u'abcdef')
    assert AnsibleVaultEncryptedUnicode(u'abc').startswith(u'')
    assert AnsibleVaultEncryptedUnicode(u'abc').startswith(u'', 0)

# Generated at 2022-06-21 00:05:08.556055
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:05:11.476852
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    assert bool(AnsibleVaultEncryptedUnicode('test_data').islower()) == True

#Unit test for method isupper of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:05:20.799765
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    ciphertext = 'U2FsdGVkX1+Fn7G/1EgHV7nWoNGWpG+fRjIH5hv01a8='

    avue = AnsibleVaultEncryptedUnicode.from_plaintext(
        'Hello world', None, None
    )

    avue._ciphertext = ciphertext

    avue.vault = None
    assert avue.encode() == ciphertext
    assert avue.encode('latin-1') == ciphertext
    assert avue.encode(encoding='latin-1') == ciphertext
    assert avue.encode(errors='strict') == ciphertext
    assert avue.encode('latin-1', 'strict') == ciphertext

# Generated at 2022-06-21 00:05:29.079392
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    from ansible_vault import Vault

    secret = 'foobar'
    vault = Vault(secret)
    encrypted = vault.encrypt(b"foo")

    avue1 = AnsibleVaultEncryptedUnicode(encrypted)
    avue1.vault = vault

    # Compare avue1 to encrypted
    assert(avue1 != encrypted)

    # Compare avue1 to decrypted
    assert(avue1 != "foo")

    # Compare avue1 to avue2 with same decrypted value
    avue2 = AnsibleVaultEncryptedUnicode(encrypted)
    avue2.vault = vault
    assert(avue1 == avue2)

    # Compare avue1 to avue2 with different decrypted value
    encrypted = vault.encrypt(b"bar")
    avue2 = Ansible

# Generated at 2022-06-21 00:05:32.970133
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    assert AnsibleVaultEncryptedUnicode('FOO').casefold() == 'foo'
    assert AnsibleVaultEncryptedUnicode('foo').casefold() == 'foo'
    assert AnsibleVaultEncryptedUnicode('fOo').casefold() == 'foo'


# Generated at 2022-06-21 00:05:35.584347
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    assert AnsibleVaultEncryptedUnicode("abcdefgh").upper() == "ABCDEFGH"
    assert AnsibleVaultEncryptedUnicode("").upper() == ""


# Generated at 2022-06-21 00:05:54.629065
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    # __hash__ returns system default for immutable objects (str)
    a = AnsibleVaultEncryptedUnicode(u'jkl')
    a_hash = hash(a)
    b = u'jkl'
    b_hash = hash(b)
    assert(a_hash == b_hash)



# Generated at 2022-06-21 00:06:06.734636
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    class TestClass(object):
        def __init__(self, data, data_hash):
            self.data = data
            self.data_hash = data_hash

    TestClasses = [
            TestClass('hello', hash('hello')),
            TestClass('balloon', hash('balloon')),
            TestClass('banana', hash('banana')),
            TestClass('aaaaaaa', hash('aaaaaaa')),
            TestClass('aaaaaab', hash('aaaaaab')),
            TestClass('aaaaaac', hash('aaaaaac')),
            ]


# Generated at 2022-06-21 00:06:13.478788
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    '''
    The isspace method of class AnsibleVaultEncryptedUnicode is failing
    when used with a space character.
    '''

    # Create the object
    test_object = AnsibleVaultEncryptedUnicode(' ')

    # Get the value of the isspace method
    test_value = test_object.isspace()

    # Assert the test
    assert test_value == True


# Generated at 2022-06-21 00:06:18.193651
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(b'_')
    secret = b'secret'
    a = AnsibleVaultEncryptedUnicode.from_plaintext(b'foobarbaz', vault, secret)
    assert a.data == u'foobarbaz'
    assert a.is_encrypted()
    assert a.split() == [b'foobarbaz']



# Generated at 2022-06-21 00:06:30.158928
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    # Verify the method ljust of class AnsibleVaultEncryptedUnicode returns the expected value
    # when the length of pad is less than the specified width
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('$ANSIBLE_VAULT;1.1;AES256')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('poules', vault, 'vaultsecret')
    assert avu.ljust( width = 10, fillchar = '.' ) == 'poules....'
    # Verify the method ljust of class AnsibleVaultEncryptedUnicode returns the expected value
    # when the length of pad is greater than the specified width
    assert avu.ljust( width = 1, fillchar = '.' ) == 'poules'

# Generated at 2022-06-21 00:06:36.305861
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    class DummyVault:
        def encrypt(self, plaintext, secret):
            return plaintext
        def decrypt(self, ciphertext, obj=None):
            return ciphertext
        def is_encrypted(self, ciphertext):
            return True

    dummy_vault = DummyVault()

    avu = AnsibleVaultEncryptedUnicode.from_plaintext("test", dummy_vault, "test")
    assert avu.vault == dummy_vault
    assert avu.data == "test"
    avu.data = "test"
    assert isinstance(avu.data, str)
    assert avu.capitalize() == "Test"
    assert avu.data == "Test"



# Generated at 2022-06-21 00:06:39.291474
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    text_left = AnsibleVaultEncryptedUnicode('1')
    text_right = AnsibleVaultEncryptedUnicode('2')
    result = text_left + text_right
    assert result == '12'


# Generated at 2022-06-21 00:06:48.354307
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    txt = 'abcdef'
    vault = VaultLib(load=True)
    secret = vault.secrets[0]
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(txt, vault, secret)

    other_txt = 'abcdeg'
    other_avu = AnsibleVaultEncryptedUnicode.from_plaintext(other_txt, vault, secret)

    assert avu < other_avu


# Generated at 2022-06-21 00:06:55.649567
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():

    # Invalid Vault object
    try:
        AnsibleVaultEncryptedUnicode.from_plaintext('test', None, 'secret')
        assert False, 'Expected ValueError error'
    except ValueError as e:
        assert str(e) == 'Error creating AnsibleVaultEncryptedUnicode, invalid vault (None) provided', 'Unexpected error message: %s' % str(e)

    # Valid Vault
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('secret')
    try:
        AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'secret')
    except ValueError as e:
        assert False, 'Unexpected error: %s' % str(e)


# This monkey-patches the yaml module to use our own custom classes.
#

# Generated at 2022-06-21 00:07:07.960757
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    # Test with simple text
    test_text = 'hello world'
    avu = AnsibleVaultEncryptedUnicode(test_text)
    assert avu.data == test_text

    # Test with ascii and unicode mixed
    test_text = '\xe9 h\xe9llo world'
    avu = AnsibleVaultEncryptedUnicode(test_text)
    assert avu.data == test_text

    # Test with unicode only
    test_text = u'hello \U0001f44d world'
    avu = AnsibleVaultEncryptedUnicode(test_text)
    assert avu.data == test_text

    # Test with int and float
    test_text = 1234
    avu = AnsibleVaultEncryptedUnicode(test_text)
    assert to

# Generated at 2022-06-21 00:07:28.558965
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    test_data = 'this is a test string'
    vault = get_vault_instance()
    secret = 'vaultsecret'
    encrypted_test_data = vault.encrypt(test_data, secret=secret)

    avu = AnsibleVaultEncryptedUnicode(encrypted_test_data)
    avu.vault = vault

    assert avu.swapcase() == test_data.swapcase()


# Generated at 2022-06-21 00:07:31.606396
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    result = AnsibleVaultEncryptedUnicode("test       ").rstrip()
    assert len(result) == 4
    assert result == "test"



# Generated at 2022-06-21 00:07:35.204243
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    avue = AnsibleVaultEncryptedUnicode("this is the encrypted string")
    assert avue.partition("is") == ("th", "is", " is the encrypted string")



# Generated at 2022-06-21 00:07:45.229250
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    """
    Testing AnsibleVaultEncryptedUnicode isidentifier method
    """
    identifier = AnsibleVaultEncryptedUnicode('')

    # string with no special character
    string1 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    assert identifier.isidentifier(string1)
    # string with special character
    string2 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789$'
    assert not identifier.isidentifier(string2)
    # string with empty character
    string3 = ''
    assert not identifier.isidentifier(string3)



# Generated at 2022-06-21 00:07:56.833780
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    from ansible.parsing.vault import VaultLib
    from os import urandom
    from random import randrange
    from string import ascii_letters
    chars = ascii_letters # string.ascii_letters + string.digits + string.punctuation + string.whitespace
    charsize = len(chars) - 1
    lowerchars = set(ascii_letters[26:])
    l = []
    for _ in range(100):
        l.append(''.join(chars[randrange(charsize)] for _ in range(randrange(100000))))
    password = urandom(16)
    vault = VaultLib(password)
    cobj = vault.encrypt(l[0], obj=None)
    assert(cobj.data.lower() == l[0].lower())

# Generated at 2022-06-21 00:08:01.773786
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    # Test with a valid vault
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256', vault=MockVaultLib())
    assert avu.capitalize() == '$ansible_vault;1.1;aes256'



# Generated at 2022-06-21 00:08:06.682990
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    a = AnsibleVaultEncryptedUnicode('A')
    assert a.isupper()
    a = AnsibleVaultEncryptedUnicode('a')
    assert not a.isupper()
    a = AnsibleVaultEncryptedUnicode('B')
    assert not a.isupper()
    a = AnsibleVaultEncryptedUnicode('1')
    assert not a.isupper()


# Generated at 2022-06-21 00:08:11.208197
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    if str('A').isprintable() != AnsibleVaultEncryptedUnicode('A').isprintable():
        raise Exception("test_AnsibleVaultEncryptedUnicode_isprintable: unexpected result")
    if not str('\x00').isprintable() != AnsibleVaultEncryptedUnicode('\x00').isprintable():
        raise Exception("test_AnsibleVaultEncryptedUnicode_isprintable: unexpected result")



# Generated at 2022-06-21 00:08:15.444041
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    mystring = "THIS IS ALL CAPS"
    avs = AnsibleVaultEncryptedUnicode(mystring)
    assert avs.lower() == mystring.lower()


# Generated at 2022-06-21 00:08:26.581588
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    # This test is to make sure that the constructor works OK and that
    # the class is more or less compatible with python's unicode type
    # (a.k.a. basestring in PY2 and str in PY3).
    import tempfile
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    password = 'this_is_a_password'
    vault.create_file(password)
    plaintext = 'Hello World!'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, password)
    assert avu == plaintext
    assert len(avu) == 12
    assert avu[7] == 'W'
    assert avu[0:6] == 'Hello '
    assert avu[6:] == 'World!'


# Generated at 2022-06-21 00:08:46.404857
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    avu = AnsibleVaultEncryptedUnicode("  foo")
    assert avu.lstrip() == "foo"

    # python3 handles unicode different then python2
    if sys.version_info.major == 3:
        avu = AnsibleVaultEncryptedUnicode("  äöä")
        assert avu.lstrip() == "äöä"
    else:
        avu = AnsibleVaultEncryptedUnicode("  äöä")
        assert avu.lstrip() == "äöä"

    avu = AnsibleVaultEncryptedUnicode("  äöä")
    assert avu.lstrip("  ") == "äöä"



# Generated at 2022-06-21 00:08:53.140719
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    evu1 = AnsibleVaultEncryptedUnicode(b'abc')
    evu2 = AnsibleVaultEncryptedUnicode(b'def')
    assert evu1 >= 'abc'
    assert evu1 >= evu1
    assert not evu1 >= evu2
    print("test_AnsibleVaultEncryptedUnicode___ge__ finished succesfully")



# Generated at 2022-06-21 00:08:57.180975
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    # fix issue #17943
    string = AnsibleVaultEncryptedUnicode('{0} is {1}')
    assert string.format('Python', 'very good') == 'Python is very good'


import collections
from collections.abc import MutableMapping



# Generated at 2022-06-21 00:08:59.116367
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    ustr = AnsibleVaultEncryptedUnicode(' abc')
    assert ustr.lstrip() == ''


# Generated at 2022-06-21 00:09:10.259394
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    # test for AnsibleVaultEncryptedUnicode
    a = AnsibleVaultEncryptedUnicode("   aa   ")
    b = a.strip()
    assert b == "aa"

    # test for AnsibleVaultEncryptedUnicode with a vault
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes
    vault = VaultLib([to_bytes("123456789012345678901234")])
    a = AnsibleVaultEncryptedUnicode("123", vault=vault)
    b = a.strip()
    assert b == "123"
    # the vault has been cleared
    assert a.vault is None



# Generated at 2022-06-21 00:09:21.444588
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    if sys.version_info[0] == 2:
        assert AnsibleVaultEncryptedUnicode(b'foo').rfind('o') == 2
        assert AnsibleVaultEncryptedUnicode(b'foo').rfind(u'o') == 2
        assert AnsibleVaultEncryptedUnicode(b'foo').rfind(b'o') == 2

        assert AnsibleVaultEncryptedUnicode('foo').rfind('o') == 2
        assert AnsibleVaultEncryptedUnicode('foo').rfind(u'o') == 2
        assert AnsibleVaultEncryptedUnicode('foo').rfind(b'o') == 2

        assert AnsibleVaultEncryptedUnicode(u'foo').rfind('o') == 2

# Generated at 2022-06-21 00:09:26.527737
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    avu_inst1 = AnsibleVaultEncryptedUnicode('abcabcabc')
    assert avu_inst1.swapcase() == 'ABCABCABC'
    avu_inst2 = AnsibleVaultEncryptedUnicode('ABCABCABC')
    assert avu_inst2.swapcase() == 'abcabcabc'
    avu_inst3 = AnsibleVaultEncryptedUnicode('aBcAbCabc')
    assert avu_inst3.swapcase() == 'AbCaBcABC'


# Generated at 2022-06-21 00:09:38.000425
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    ciphertext = b'\x11\x94X\x0b\x1a\x18\x12\x0c\xe3\x14\xa4\x9f\x1e\x14\x14\r?\xae\x1b\xae\x1a\xfb\x8bo\xb3\xe5D\xed$\xdb\xc0\xa7\x99\xc5\x9e\xdd\x0e{\xd0\xb7\x1e\x19\xe0a\xf5\x1b\x8f\xbf\x15\xf2C\xe8\xdf\x1b\xa1\xcf\xfa\x9b\x08'
    secret = 'secret'
    vault = yaml.vault.Vault

# Generated at 2022-06-21 00:09:43.462463
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    # Create the object
    obj = AnsibleVaultEncryptedUnicode(' mytext ')
    # Call the method
    res = obj.strip()
    # Check the result
    exp = ansible_vault_decrypt('mytext')
    assert isinstance(res, AnsibleVaultEncryptedUnicode)
    assert res.data == exp



# Generated at 2022-06-21 00:09:46.940380
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    """
    Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
    """
    assert AnsibleVaultEncryptedUnicode('foo').__radd__(None) == 'Nonefoo', 'unexpected result'


# Generated at 2022-06-21 00:10:09.553212
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    avue1 = AnsibleVaultEncryptedUnicode("test1")
    avue2 = AnsibleVaultEncryptedUnicode("test2")
    assert (avue1 + avue2) == "test1test2"
    assert (avue1 + "test2") == "test1test2"
    assert ("test1" + avue2) == "test1test2"


# Generated at 2022-06-21 00:10:16.184948
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    from ansible.plugins.vault import VaultLib
    vault = VaultLib([])
    secret = 'ansible'
    plaintext = 'password: mysecretpassword'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert str(avu) == plaintext
    avu.vault = None
    assert str(avu) == to_text(plaintext)


# Generated at 2022-06-21 00:10:23.925369
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    # Didn't find a way to pass the isinstance check, since a_v_e_u isn't a string, so the isinstance check fails
    # This should work but doesn't work; Won't fix
    # assert isinstance(a_v_e_u, string.string)
    a_v_e_u = AnsibleVaultEncryptedUnicode("abc")
    assert a_v_e_u.isnumeric() is False

# These tests are derived from those in the collections module
import unittest


# Generated at 2022-06-21 00:10:33.864222
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    test = AnsibleSequence(['item 1', 'item 2'])
    assert test[0] == 'item 1'
    assert test[-1] == 'item 2'
    assert len(test) == 2
    for i, item in enumerate(test):
        assert item == test[i]
    assert 'item 1' in test
    assert 'no item' not in test
    assert AnsibleSequence(test) == test
    assert list(reversed(test)) == ['item 2', 'item 1']

    test.append('item 3')
    test.extend(['item 4', 'item 5'])
    assert test[2:] == ['item 3', 'item 4', 'item 5']
    assert test[:2] == ['item 1', 'item 2']

# Generated at 2022-06-21 00:10:45.671320
# Unit test for method upper of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:10:48.950748
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    avue = AnsibleVaultEncryptedUnicode(b'hello')
    print(avue.rpartition(b'l'))
    print(avue.rpartition(b'Z'))

# Generated at 2022-06-21 00:10:55.239701
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    '''
    Test unit for method casefold of class AnsibleVaultEncryptedUnicode.
    '''
    obj = AnsibleVaultEncryptedUnicode("""
    ---
    foo: bar
    baz: qux
    """)
    result = obj.casefold()
    assert result == "---\nfoo: bar\nbaz: qux\n"

# Generated at 2022-06-21 00:11:06.504320
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    ''' Test AnsibleVaultEncryptedUnicode.rpartition '''

    s = AnsibleVaultEncryptedUnicode('spam')
    v = b'V\x9fz\x0b\x9fDA\x1d\xc5\x0c\xae\x9e\xa9X\xe4\x0e\x1c\xb0\xeb\xd3\x08\x96\x15\x9e\xbb\xbd\xa0\xc0\x87\xcb\x98\xfb$\n'
    s.data = v
    assert s.data == v

    # test copy
    s2 = AnsibleVaultEncryptedUnicode(s)
    assert s2.data == v
