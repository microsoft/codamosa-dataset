

# Generated at 2022-06-21 00:01:26.658400
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # Test normal case
    val1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=None, secret='secret')
    val2 = AnsibleVaultEncryptedUnicode.from_plaintext('foo2', vault=None, secret='secret')
    assert val1 < val2

    # Test unequal objects
    val1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=None, secret='secret')
    val2 = 'foo'
    assert not val1 < val2

    # Test unequal instances
    val1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=None, secret='secret')
    val2 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=None, secret='secret2')
    assert not val

# Generated at 2022-06-21 00:01:37.989296
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    '''
    Test case for method __add__ of class AnsibleVaultEncryptedUnicode
    '''
    error = []
    tester = AnsibleVaultEncryptedUnicode('test string')
    # Check whether the method returns the correct output
    if tester.__add__('test') != 'test stringtest':
        error.append('Error in __add__')
    # Check whether the encrypted object can be added properly
    tester2 = AnsibleVaultEncryptedUnicode('test string')
    tester2.__add__(tester)
    if tester.__add__(tester2) != 'test stringtest string':
        error.append('Error in __add__ for class AnsibleVaultEncryptedUnicode')
    # Check whether the method handles unicode arguments properly

# Generated at 2022-06-21 00:01:42.584782
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    assert AnsibleVaultEncryptedUnicode('_').isidentifier()
    assert AnsibleVaultEncryptedUnicode('_0').isidentifier()
    assert AnsibleVaultEncryptedUnicode('__0').isidentifier()
    assert AnsibleVaultEncryptedUnicode('_0a').isidentifier()
    assert AnsibleVaultEncryptedUnicode('__0a').isidentifier()
    assert not AnsibleVaultEncryptedUnicode('__').isidentifier()
    assert not AnsibleVaultEncryptedUnicode('_0_').isidentifier()
    assert not AnsibleVaultEncryptedUnicode('__0_').isidentifier()
    assert not AnsibleVaultEncryptedUnicode('_0a_').isidentifier()
    assert not AnsibleVaultEncryptedUnic

# Generated at 2022-06-21 00:01:52.798404
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    # check error handling
    avu = AnsibleVaultEncryptedUnicode(u'foo')
    try:
        avu.encode()
    except UnicodeEncodeError:
        pass
    else:
        raise AssertionError('UnicodeEncodeError should have been raised')

    # encode with no errors
    avu1 = AnsibleVaultEncryptedUnicode(u'foo')
    encoded = avu1.encode()
    assert(isinstance(encoded, bytes))

    # encode with surrogate errors
    if _sys.version_info[0] == 2:
        avu2 = AnsibleVaultEncryptedUnicode(u'\ud800\ud800')
        encoded = avu2.encode('utf-8', errors='surrogateescape')

# Generated at 2022-06-21 00:01:57.112237
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    s = "abcd efghijk"
    avu = AnsibleVaultEncryptedUnicode(s)
    assert avu.endswith("ijk")

# Generated at 2022-06-21 00:02:09.319469
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    from base64 import b64decode
    from ansible.parsing.vault import VaultLib

    # Test case for unicode string (u'\u2665')
    # Python 2
    # u'\u2665'.encode('UTF-8').decode('UTF-8') == u'\u2665'
    # Python 3
    # u'\u2665'.encode('UTF-8') == b'\xe2\x99\xa5'
    # u'\u2665'.encode('UTF-8').decode('UTF-8') == u'\u2665'
    password = 'test'
    vault = VaultLib([])
    string = '\u2665'
    vaulted_string = vault.encrypt(string, password)
    avu = AnsibleVaultEncryptedUnic

# Generated at 2022-06-21 00:02:12.039990
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    asq = AnsibleSequence()
    assert isinstance(asq, AnsibleSequence)
    assert isinstance(asq, list)


# Generated at 2022-06-21 00:02:18.301659
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    s = b'X\xe7\u6c34'
    assert AnsibleVaultEncryptedUnicode(s).data[1] == ord(s[1:].decode('utf-8')[0])
    assert AnsibleVaultEncryptedUnicode(s).data[-2:] == s[-2:].decode('utf-8')
    assert AnsibleVaultEncryptedUnicode(s).data[1:3] == s[1:3].decode('utf-8')

if __name__ == '__main__':
    test_AnsibleVaultEncryptedUnicode___getitem__()

# Generated at 2022-06-21 00:02:20.502551
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    v = AnsibleVaultEncryptedUnicode("abc")
    assert repr(v) == "abc"



# Generated at 2022-06-21 00:02:33.441205
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    # Test with a valid secret
    sec = 'test_test_test_test_test_test_test_test_test'
    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256\n3338376162626333333666235653232656635333865316437306535393337343530386163636430\n32643866623130393566366561316365656131663338616666630a35383263386163656566356430\n333766356430653064613261326336636339389a\n'

    # Initialize vault
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(sec)

    #instanciate the AnsibleVaultEncryptedUnicode object
    av

# Generated at 2022-06-21 00:02:56.375822
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    # Test 1
    passwd = b'aRk7DU6wYbni7GTwfzQ2K3h1B6Uts7VZ'
    vault = vaultlib.VaultAES256()

    ciphertext = vault.encrypt(b'01234567890', passwd)
    avue = AnsibleVaultEncryptedUnicode(ciphertext)
    avue.vault = vault
    assert avue.isdecimal()

    # Test 2
    ciphertext = vault.encrypt(b'x', passwd)
    avue = AnsibleVaultEncryptedUnicode(ciphertext)
    avue.vault = vault
    assert not avue.isdecimal()

    # Test 3
    ciphertext = vault.encrypt(b'5.5', passwd)


# Generated at 2022-06-21 00:03:02.540300
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    '''Module unit test for class AnsibleVaultEncryptedUnicode and method __rmod__.'''
    import getpass
    hostname = getpass.getuser()
    pass_in = 'hello world'
    pass_out = 'This is a test, %s.' % pass_in
    pass_out_template = 'This is a test, %s.'

    avu = AnsibleVaultEncryptedUnicode(pass_in)
    assert pass_out == (pass_out_template % avu)
    return 0


# Generated at 2022-06-21 00:03:05.391859
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    assert hash('foo') == hash(AnsibleVaultEncryptedUnicode('foo'))


# Generated at 2022-06-21 00:03:17.112449
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    from ansible.constants import mk_boolean
    from ansible.parsing.vault import VaultLib
    import os
    import tempfile
    import pytest

    if not mk_boolean(os.environ.get('ANSIBLE_TEST_VAULT_ENCRYPTION', None)):
        pytest.skip('ANSIBLE_TEST_VAULT_ENCRYPTION not set, skipping vault testing')


# Generated at 2022-06-21 00:03:28.501248
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    string = 'my string'
    avu = AnsibleVaultEncryptedUnicode(string)
    assert avu.endswith('') is True
    assert avu.endswith(' ') is False
    assert avu.endswith('g') is True
    assert avu.endswith(string) is True
    assert avu.endswith('g ', 1, 9) is False
    assert avu.endswith('g ', 9, -1) is False
    assert avu.endswith('g ', 0, 2) is False
    assert avu.endswith('g ', 2, 9) is True
    assert avu.endswith('g ', 0, 10) is True



# Generated at 2022-06-21 00:03:33.485033
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    # Initialize the AnsibleSequence class
    AnsibleSequenceInst = AnsibleSequence([1,2])
    assert len(AnsibleSequenceInst) == 2
    # Check for the list items
    AnsibleSequenceInst[0] == 1
    AnsibleSequenceInst[1] == 2


# Generated at 2022-06-21 00:03:40.253527
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    from ansible.parsing.vault import VaultLib

    plaintext = u'test_str'
    secret = u'ansible'
    vault = VaultLib([])
    ciphertext = vault.encrypt(plaintext, secret)
    s = AnsibleVaultEncryptedUnicode(ciphertext)
    s.vault = vault

    assert plaintext == to_text(s.data)
    assert to_text(s) == to_text(s.data)
    assert to_text(s) == plaintext

    # Exit with success
    return True



# Generated at 2022-06-21 00:03:52.520578
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    """
    This test requires a vault password to be set in environment variable ANSIBLE_VAULT_PASSWORD_FILE.

    It tests for exception throwing for rpartition method.
    """
    import os
    import tempfile
    from ansible.parsing.vault import VaultLib

    # get the password from the environment variable
    password_path = os.environ['ANSIBLE_VAULT_PASSWORD_FILE']
    with open(password_path) as f:
        password = f.read().strip()

    # create a temporary file for vault
    fd, temp_path = tempfile.mkstemp()
    vault = VaultLib(password)
    encrypted_data = vault.encrypt(b'password_file')

    # write encrypted data to temporary file

# Generated at 2022-06-21 00:04:01.538816
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    from ansible.parsing.vault import VaultLib
    enc_string = 'helloworld'
    vault = VaultLib([])
    enc = AnsibleVaultEncryptedUnicode.from_plaintext(enc_string, vault, b"ansible")
    assert enc.is_encrypted()
    assert enc.index(enc_string) == 0
    assert enc.index(enc_string) == 0
    assert enc.index(enc_string) == 0
    # Verify that the id of the object is preserved
    assert id(enc) == id(enc.index(enc_string))


# Generated at 2022-06-21 00:04:05.552988
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    aveus = [
        AnsibleVaultEncryptedUnicode('abcdefg'),
        AnsibleVaultEncryptedUnicode('abc defg'),
        AnsibleVaultEncryptedUnicode(' abc defg '),
    ]

    for aveu in aveus:
        assert aveu.title() == aveu.data.title()



# Generated at 2022-06-21 00:04:20.904416
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    # Variables to be used in tests
    input_text = 'test'

# Generated at 2022-06-21 00:04:28.507959
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    # Test with string input
    assert AnsibleVaultEncryptedUnicode('test').__str__() == 'test'
    assert AnsibleVaultEncryptedUnicode('test').data == 'test'
    assert AnsibleVaultEncryptedUnicode(b'test').__str__() == 'test'
    assert AnsibleVaultEncryptedUnicode(b'test').data == 'test'
    # Test with AnsibleVaultEncryptedUnicode input
    assert AnsibleVaultEncryptedUnicode(AnsibleVaultEncryptedUnicode('test')).__str__() == 'test'
    assert AnsibleVaultEncryptedUnicode(AnsibleVaultEncryptedUnicode('test')).data == 'test'



# Generated at 2022-06-21 00:04:37.951829
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    str1 = AnsibleVaultEncryptedUnicode("this\tis\ta\ttest")
    str2 = "this   is a   test"
    if str1.expandtabs(4) != str2:
        raise Exception("Result of AnsibleVaultEncryptedUnicode.expandtabs() is wrong.\nExpecting %s\ngot %s" % (str2, str1.expandtabs(4)))
    else:
        print("Test AnsibleVaultEncryptedUnicode.expandtabs() pass")


# Generated at 2022-06-21 00:04:48.017687
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    if sys.version_info[0] == 2:
        import ansible.utils.vault as vault
        #create dummy vault object to permit testing
        class DummyVault:
            def decrypt(*args):
                return 'AAA'
            def is_encrypted(unused_self, data):
                return True
        myvault = DummyVault()
        testobj = AnsibleVaultEncryptedUnicode('AAA')
        testobj.vault = myvault
        assert testobj.isupper()
        testobj = AnsibleVaultEncryptedUnicode('aaa')
        testobj.vault = myvault
        assert not testobj.isupper()


# Generated at 2022-06-21 00:04:59.666639
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():

    # Test 1: Test that the partition method works correctly
    string = 'My Test String'
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('My Test String')
    partition_string = ansible_vault_encrypted_unicode.partition(' ')
    partition_ansible_vault_encrypted_unicode = ansible_vault_encrypted_unicode.partition(' ')
    assert partition_string == partition_ansible_vault_encrypted_unicode

    # Test 2: Test that the partition method works correctly with no separator
    string = 'My Test String'
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('My Test String')
    partition_string = ansible_vault_encrypted_unicode.partition('')
    partition_

# Generated at 2022-06-21 00:05:05.717093
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    vault = VaultLib('somesecret')
    foo = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'somesecret')
    bar = AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'somesecret')
    assert foo < bar
    assert foo < 'bar'
    assert foo < AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, 'somesecret')
    assert 'foo' < bar


# Generated at 2022-06-21 00:05:16.171006
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    aveu = AnsibleVaultEncryptedUnicode('Hello my name is AnsibleVaultEncryptedUnicode')

    # Negative tests
    try:
        assert aveu.rsplit(' ') == ['Hello', 'my', 'name', 'is', 'AnsibleVaultEncryptedUnicode']
    except:
        raise Exception("AnsibleVaultEncryptedUnicode.rsplit failed with no maxsplit value defined")

    try:
        assert aveu.rsplit(' ', 3) == ['Hello', 'my', 'name', 'is AnsibleVaultEncryptedUnicode']
    except:
        raise Exception("AnsibleVaultEncryptedUnicode.rsplit failed with a maxsplit value defined")





# Generated at 2022-06-21 00:05:24.748975
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    from ansible.vault.vault import VaultLib
    cipher_config = {'vault_password_file': 'test/test-vault-password.txt'}
    vault_secret = 'DEADBEEF'
    vault = VaultLib(**cipher_config)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(vault_secret, vault, 'test')
    assert avu.isalnum()

    ansible_secret = 'ansible'
    normal_unicode = to_unicode(ansible_secret)
    assert normal_unicode.isalnum()

    assert ansible_secret.isalnum()



# Generated at 2022-06-21 00:05:33.068412
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    """
    Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode.

    Test that AnsibleVaultEncryptedUnicode.__complex__ returns expected value.

    Return Value:
    None

    """
    assert AnsibleVaultEncryptedUnicode('1+1j').__complex__() == 1.0 + 1.0j
    assert AnsibleVaultEncryptedUnicode('1+1j').__complex__() == \
        AnsibleVaultEncryptedUnicode('1+1j').data
    try:
        AnsibleVaultEncryptedUnicode('1+j').__complex__()
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-21 00:05:36.811299
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    text = u'hello, world'
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    assert AnsibleVaultEncryptedUnicode.from_plaintext(text, vault, None).capitalize() == u'Hello, world'


# Generated at 2022-06-21 00:05:51.404542
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # The value in tests/vault/test_vault.yml is encrypted with the secret 'ansible'
    # so we use that vault to decrypt the value
    from ansible.parsing import vault
    myvault = vault.VaultLib('ansible')

# Generated at 2022-06-21 00:05:57.792393
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    val = AnsibleVaultEncryptedUnicode('12345')
    assert val.lstrip() == '12345'
    assert val.lstrip('12') == '345'
    assert val.lstrip('1234') == '5'
    assert val.lstrip('12345') == ''
    assert val.lstrip('012345') == '12345'



# Generated at 2022-06-21 00:06:03.402456
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    a = AnsibleVaultEncryptedUnicode('abc123')
    assert a.isalnum() is True
    a = AnsibleVaultEncryptedUnicode('abc 123')
    assert a.isalnum() is False
    a = AnsibleVaultEncryptedUnicode('abc\n123')
    assert a.isalnum() is False


# Generated at 2022-06-21 00:06:14.814817
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    import ansible.parsing.vault as vault_mod
    import os

    vault_file = os.path.join(os.path.dirname(__file__), u'vault_data.yml')
    vault = vault_mod.VaultLib([os.environ['ANSIBLE_VAULT_PASSWORD']], vault_file)

    # valid initialization
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(u'foo', vault, 'secret')
    assert avu.data == u'foo'
    assert avu.vault == vault

    # invalid initialization
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(u'foo', None, 'secret')
    assert avu.data == u'foo'

# Generated at 2022-06-21 00:06:19.943316
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    assert AnsibleVaultEncryptedUnicode("TEST").lower() == "test"
    assert AnsibleVaultEncryptedUnicode(b"TEST").lower() == "test"
    assert AnsibleVaultEncryptedUnicode("TEST", "something").lower() == "test"
    assert AnsibleVaultEncryptedUnicode(b"TEST", "something").lower() == "test"


# Generated at 2022-06-21 00:06:30.162737
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    text = '{a} {b} {b}'
    arguments = {'a': 'first', 'b': 'second'}
    # 1. Test with bytes on PY2 and string on PY3
    for arg in arguments:
        arguments[arg] = arguments[arg].encode()
    result = text.format_map(arguments)
    assert result == b'first second second'
    # 2. Test with unicode on PY2 and str on PY3
    for arg in arguments:
        arguments[arg] = arguments[arg].decode()
    result = text.format_map(arguments)
    assert result == 'first second second'


# Generated at 2022-06-21 00:06:37.507678
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import hashlib
    import ansible.constants as C
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(C.DEFAULT_VAULT_ID_MATCH)
    secret = 'my-secret'
    seq = 'This is the value which is to be encrypted'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu == seq
    assert avu == hashlib.sha256(seq.encode('utf-8')).digest()


# Generated at 2022-06-21 00:06:43.627509
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    tests = [
        "test",
        "Test",
        "TEST",
        "TESTTEST",
        "TEST TEST",
        "TEST TESt",
        "TEST.TESt",
        "TEST.\u1fff",
        "TEST\u1fffTESt",
        "TEST\u1fff TEST",
        "TEST \u1fff",
        "TEST \u1fff\u1fff",
    ]
    for test in tests:
        plaintext = AnsibleVaultEncryptedUnicode(test)
        assert plaintext.data.istitle() == plaintext.istitle()


# Generated at 2022-06-21 00:06:53.503446
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    from ansible.parsing.vault import VaultLib

    # Test with ansible_vault_password set as a string
    v = VaultLib(password=u'foo')
    e = AnsibleVaultEncryptedUnicode.from_plaintext(u'bar', vault=v, secret='foo')
    assert e.__unicode__() == u'bar'

    # Test with ansible_vault_password set as a AnsibleVaultEncryptedUnicode
    v = VaultLib(password=u'foo')
    e = AnsibleVaultEncryptedUnicode.from_plaintext(u'bar', vault=v, secret=u'foo')
    assert e.__unicode__() == u'bar'

    # Test with ansible_vault_password set as a AnsibleVaultEncryptedUnicode


# Generated at 2022-06-21 00:07:03.923043
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    # By default, method __unicode__ returns self._data
    actual = AnsibleVaultEncryptedUnicode(u'foo')
    assert u'foo' == actual

    # Will raise exception, if _data is not unicode
    try:
        actual = AnsibleVaultEncryptedUnicode(b'foo')
        assert False, 'UnicodeDecodeError not raised'
    except UnicodeDecodeError:
        pass

    # Will raise exception, if _data is not unicode
    try:
        actual = AnsibleVaultEncryptedUnicode(123)
        assert False, 'UnicodeDecodeError not raised'
    except UnicodeDecodeError:
        pass



# Generated at 2022-06-21 00:07:20.053241
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError

    vault_pass = "I'm a vault password!"
    ciphertext = b"$ANSIBLE_VAULT;1.1;AES256\n653532636231666331316466303633663438363933616532333162323433656337653862656563356166\n383631653536333465333066393463316339353730343230333737653061306133613665663937653763\n\n"

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    vault = VaultLib(vault_pass)
    avu.vault = vault

    # Check is encrypted
   

# Generated at 2022-06-21 00:07:25.091597
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu.zfill(8) == '000000foo'
    avu = AnsibleVaultEncryptedUnicode('foobar')
    assert avu.zfill(8) == '00000foobar'


# Generated at 2022-06-21 00:07:36.397761
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    import tempfile
    import os
    import shutil
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError

    # create a VaultLib object
    password = 'test'
    salt = b'8e3af2c67b1a49a7e9a9152d2ae0fdc3'
    vault = VaultLib([password], 1, salt=salt)

    # AnsibleVaultEncryptedUnicode object with a VaultLib object and an encrypted string

# Generated at 2022-06-21 00:07:39.167412
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    data=b''
    avu = AnsibleVaultEncryptedUnicode(data)
    assert (int(avu)==int(data))


# Generated at 2022-06-21 00:07:48.476416
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    assert AnsibleVaultEncryptedUnicode('123').swapcase() == '123'
    assert AnsibleVaultEncryptedUnicode('123').swapcase().swapcase() == '123'
    assert AnsibleVaultEncryptedUnicode('aBc').swapcase() == 'AbC'

# map the native python object to our sub classed object
# this allows the sub classed object to be used without
# having to modify the files which use it
yaml.add_representer(AnsibleBaseYAMLObject, yaml.BaseRepresenter.represent_object)
yaml.add_constructor(u'tag:yaml.org,2002:str', yaml.BaseConstructor.construct_yaml_str)

# Generated at 2022-06-21 00:07:56.387430
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    """Test rjust"""
    assert len(AnsibleVaultEncryptedUnicode('foo').rjust(5)) == 5
    assert AnsibleVaultEncryptedUnicode('foo').rjust(5) == '  foo'
    assert len(AnsibleVaultEncryptedUnicode('foo').rjust(5, '_')) == 5
    assert AnsibleVaultEncryptedUnicode('foo').rjust(5, '_') == '__foo'


# Generated at 2022-06-21 00:08:02.141247
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    s = "Java - tm pLatform se - Standard Edition 6"
    assert AnsibleVaultEncryptedUnicode("JAVA - TM PLATFORM SE - STANDARD EDITION 6") == s.casefold()

    s = "ßü"
    assert AnsibleVaultEncryptedUnicode("ßÜ") == s.casefold()


# Generated at 2022-06-21 00:08:10.529334
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    from ansible import errors
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    test_string = """
    _encrypted: !vault |
        $ANSIBLE_VAULT;1.1;AES256
        393537613763663639323630343438366539363037613661663133383565366638626538663863
        6438333732303231656637373436376164356664313864393336313466343361
        _ansible_variable_start: this_should_not_be_stripped
        _ansible_variable_end: this_should_not_be_stripped
    """

    vault = VaultLib()
    yaml_

# Generated at 2022-06-21 00:08:15.594009
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    # Create string with chars
    av = AnsibleVaultEncryptedUnicode("   ")
    # Create string with no chars
    av2 = AnsibleVaultEncryptedUnicode("")

    assert av.isspace() == av2.isspace()


# Generated at 2022-06-21 00:08:22.327025
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    print("start unit test for method __complex__ of class AnsibleVaultEncryptedUnicode")
    avu = AnsibleVaultEncryptedUnicode("")
    print(avu.__complex__())
    avu = AnsibleVaultEncryptedUnicode("2.3-4.6j")
    print(avu.__complex__())
    print("end unit test for method __complex__ of class AnsibleVaultEncryptedUnicode")


# Generated at 2022-06-21 00:08:33.768204
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    from ..vault import VaultLib

    vault = VaultLib('abc123')

    # byte string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(to_bytes('foo'), vault, secret='abc123')
    assert avu.__repr__() == "b'foo'"

    # unicode string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(to_text('foo'), vault, secret='abc123')
    assert avu.__repr__() == repr(to_text('foo'))

    # integer
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(1, vault, secret='abc123')
    assert avu.__repr__() == repr(1)

    # float
    avu = AnsibleVaultEncryptedUnic

# Generated at 2022-06-21 00:08:45.591846
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    import unittest
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.parsing.yaml import DataLoader
    from ansible.vault import VaultLib
    from six import string_types

    class TestAnsibleVaultEncryptedUnicode(unittest.TestCase):
        def test_split(self):
            # Data to test split methods of AnsibleVaultEncryptedUnicode
            test_data = [
                "TEST-KEY1",
                "TEST-KEY2",
                "TEST-KEY3",
            ]
            # Create Vault object
            vault = VaultLib('test_password')
            # Create the test object

# Generated at 2022-06-21 00:08:52.283778
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    from ansible.parsing.vault import VaultLib
    obj = 'VITAMIN C'
    obj = AnsibleVaultEncryptedUnicode.from_plaintext(obj, VaultLib([], 'ansible'), 'password')
    assert obj.lower() == 'vitamin c'
    assert obj.vault.decrypt(obj) == 'VITAMIN C'


# Generated at 2022-06-21 00:09:01.340399
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib()

    # Test with different types of other
    class TestObject:
        def __init__(self, value):
            self.value = value
        def __eq__(self, other):
            return self.value == other

    class TestError(Exception):
        pass

    for other in (None, 0, '', '0', True, False, TestObject('0'), TestObject(0), TestError, TestError()):
        avu = AnsibleVaultEncryptedUnicode.from_plaintext('0', vault, 'secret')
        assert avu == other
        assert other == avu
        avu.vault = None
        assert avu == other
        assert other == avu
        avu.vault = vault

# Generated at 2022-06-21 00:09:07.328306
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    # Test format of message
    assert(AnsibleVaultEncryptedUnicode('foo').zfill(5) == '00foo'), "error at AnsibleVaultEncryptedUnicode_zfill func"
    print('test_AnsibleVaultEncryptedUnicode_zfill passed!')

test_AnsibleVaultEncryptedUnicode_zfill()



# Generated at 2022-06-21 00:09:18.346533
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    import sys
    if sys.version_info >= (3, 6):
        assert AnsibleVaultEncryptedUnicode(b'ABC').isascii()
        assert not AnsibleVaultEncryptedUnicode(b'\xe9').isascii()
    else:
        # python between 3.0 and 3.5 support ascii but does not have the isascii method,
        # and is not a unicode type so isinstance(..., str) is false
        # try to add this method to the class
        from ansible.parsing.vault import VaultLib
        vault = VaultLib('test', 'password')
        avu = AnsibleVaultEncryptedUnicode.from_plaintext(b'ABC\xe9', vault, 'password')
        assert avu.isascii()

# Generated at 2022-06-21 00:09:19.606746
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    pass


# Generated at 2022-06-21 00:09:27.366996
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    class MockVaultLib:
        def __init__(self):
            self.decrypt_func = None
        def encrypt(self, data, obj):
            return 'encrypted %s' % data
        def decrypt(self, data, obj):
            assert self.decrypt_func is not None
            return self.decrypt_func(data, obj)
        def is_encrypted(self, data):
            return data.startswith('encrypted ')

    vaultlib = MockVaultLib()
    vaultlib.decrypt_func = lambda data, obj: data.replace('encrypted ', 'decrypted ')
    plaintext = 'plaintext'
    ciphertext = vaultlib.encrypt(plaintext, None)

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vaultlib

   

# Generated at 2022-06-21 00:09:38.603052
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    from .vault import VaultLib

# Generated at 2022-06-21 00:09:43.637293
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    v = VaultLib()
    avue = AnsibleVaultEncryptedUnicode.from_plaintext('secret_data', v, 'password')
    assert avue.__ne__(avue.data) == False


# Generated at 2022-06-21 00:09:57.253249
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    from ansible.parsing.vault import VaultLib
    result = VaultLib('test').encrypt('password')

    obj = AnsibleVaultEncryptedUnicode(result)
    (first, sep, last) = obj.partition('$')

    assert(sep == '$')
    assert(first == '')
    assert(last == '$ANSIBLE_VAULT;1.1;AES256\n')


# Generated at 2022-06-21 00:10:09.256448
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    # Test with non-encrypted string as template
    non_encrypted_template = 'This is a {what}'
    non_encrypted_replacement_dictionary = {'what': 'dog'}
    assert AnsibleVaultEncryptedUnicode(non_encrypted_template).format_map(non_encrypted_replacement_dictionary) == 'This is a dog'

    # Test with encrypted string as template
    encrypted_template = 'This is a {what}'
    secret = b'passphrase'
    vault = vaultlib.VaultLib(secret)
    encrypted_template = AnsibleVaultEncryptedUnicode.from_plaintext(encrypted_template, vault, secret)
    assert encrypted_template.is_encrypted() == True
    encrypted_replacement_dictionary = {'what': 'dog'}

# Generated at 2022-06-21 00:10:20.626014
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    from ansible.parsing.vault import VaultLib
    import crypt
    import random
    import string
    import pdb

    test_data = ''.join(random.choice(string.ascii_lowercase) for _ in range(256)) + '\n'
    test_password = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(random.randint(10, 20)))
    test_vault = VaultLib(password=test_password)
    test_vault_avu = AnsibleVaultEncryptedUnicode.from_plaintext(test_data, test_vault, test_password)
    #pdb.set_trace()
    test_vault_avu_str = str(test_vault_avu)
    test_vault

# Generated at 2022-06-21 00:10:23.142818
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    v = AnsibleVaultEncryptedUnicode('HELLOWORLD')
    assert v.isupper() == True


# Generated at 2022-06-21 00:10:28.806024
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    # This is a complex string
    s = u'((1+2j)*1j)'
    # Encrypt s
    ave = AnsibleVaultEncryptedUnicode.from_plaintext(s, None, None)
    # assert that the ave evaluates to the same as the original string
    assert(complex(ave) == complex(s))



# Generated at 2022-06-21 00:10:36.339922
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    # Check if True is returned for the default constructor
    def_const = AnsibleVaultEncryptedUnicode()
    assert def_const.isnumeric() == True

    # Check if False is returned for a string constructor
    str_const = AnsibleVaultEncryptedUnicode("hello")
    assert str_const.isnumeric() == False

    # Check if True is returned for a numeric constructor
    num_const = AnsibleVaultEncryptedUnicode("1")
    assert num_const.isnumeric() == True

    # Check if True is returned for a numeric constructor with a decimal value
    num_const_flt = AnsibleVaultEncryptedUnicode("1.0")
    assert num_const_flt.isnumeric() == True



# Generated at 2022-06-21 00:10:48.170757
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    # We need to load the module for this to work
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import InvalidVaultSecret

    # We need to load the module for this to work
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode

    vault = VaultLib([])

    # Empty password is not allowed
    vault.update_secret('')

    # Create the object to be used
    password = vault.get_password()
    text_to_encrypt = 'The quick brown fox jumps over the lazy dog'
    yaml_text = AnsibleVaultEncryptedUnicode.from_plaintext(text_to_encrypt, vault, password)

    # Test that __repr__ is called when printing the object
    assert text_to_

# Generated at 2022-06-21 00:10:53.621452
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    # GIVEN a string with tabs
    encrypted_string_with_tabs = AnsibleVaultEncryptedUnicode("a\tb\tc")
    # WHEN expandtabs is called
    expanded_string = encrypted_string_with_tabs.expandtabs()
    # THEN the string is expanded
    assert str(expanded_string) == "a       b       c"


# Generated at 2022-06-21 00:11:04.909439
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    import sys
    if sys.version_info[0] < 3:
        assert complex(AnsibleVaultEncryptedUnicode('-1+1j')) == (-1+1j)
        assert complex(AnsibleVaultEncryptedUnicode(u'-1+1j')) == (-1+1j)
    else:
        assert complex(AnsibleVaultEncryptedUnicode(b'-1+1j')) == (-1+1j)
        assert complex(AnsibleVaultEncryptedUnicode(u'-1+1j')) == (-1+1j)
        assert complex(AnsibleVaultEncryptedUnicode(b'1+1j')) == (1+1j)
        assert complex(AnsibleVaultEncryptedUnicode(u'1+1j'))