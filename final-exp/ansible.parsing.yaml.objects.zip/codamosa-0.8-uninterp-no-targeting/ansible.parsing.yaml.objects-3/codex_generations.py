

# Generated at 2022-06-21 00:01:25.644063
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    # Test 0
    # first use the constructor
    aveu = AnsibleVaultEncryptedUnicode('hello world')

    # make it a string
    aveu_as_string = str(aveu)

    # now use the method rindex as we would on any string
    aveu_rindex = aveu_as_string.rindex('o')

    # assert
    assert(aveu_rindex == 7)

    # Test 1
    # first use the constructor
    aveu = AnsibleVaultEncryptedUnicode('aabbaaa')

    # make it a string
    aveu_as_string = str(aveu)

    # now use the method rindex as we would on any string
    aveu_rindex = aveu_as_string.rindex('a')

    #

# Generated at 2022-06-21 00:01:29.495701
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    avu = AnsibleVaultEncryptedUnicode(b'a')
    assert avu.count(b'a') == 1
    assert avu.count(b'b') == 0
    assert avu.count(b'a', 1, 100) == 1
    assert avu.count(b'a', 1, 1) == 0
    assert avu.count(b'b', 1, 1) == 0


# Generated at 2022-06-21 00:01:41.009312
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    # Positive tests
    assert AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n', None, None).startswith('$ANSIBLE_VAULT;', 0)
    assert AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n', None, None).startswith('$ANSIBLE_VAULT;1.1;', 0)
    assert AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n', None, None).startswith('$ANSIBLE_VAULT;1.1;AES256\n', 0)
    # Negative tests

# Generated at 2022-06-21 00:01:50.021233
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():

    from ansible.parsing.vault import VaultLib
    # Create test data
    vault_string = '$ANSIBLE_VAULT;1.1;AES256'

    vault = VaultLib(None)
    secret = 'password'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(
        vault_string,
        vault,
        secret
    )

    rfind_avu = avu.rfind(AnsibleVaultEncryptedUnicode.from_plaintext(
        'AES256',
        vault,
        secret
    ))

    assert rfind_avu == 15



# Generated at 2022-06-21 00:01:51.696446
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    assert not AnsibleVaultEncryptedUnicode('\x00').isprintable()


# Generated at 2022-06-21 00:01:58.001322
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    ustring = u'This string needs to be swapped.'

# Generated at 2022-06-21 00:02:07.783289
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    # Tests that this object behaves like a text type object
    # when method expandtabs is called
    password = "qwerty"
    vault = vaultlib.VaultLib([password])
    fake_vault = vaultlib.VaultLib([password])
    # encrypt data
    encrypted1 = vault.encrypt(b'test \t tab \t expansion')
    obj_a = AnsibleVaultEncryptedUnicode(encrypted1)
    # set vault
    obj_a.vault = fake_vault
    obj_b = expan_t(obj_a)
    assert obj_b.vault == fake_vault



# Generated at 2022-06-21 00:02:11.225865
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():

    # set-up
    text = 'The ABCDEF'
    avu = AnsibleVaultEncryptedUnicode(text)

    # test
    assert avu.istitle() == True



# Generated at 2022-06-21 00:02:18.911552
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    import os
    import vars.vars
    import vault

    # TODO: figure out how to properly test the vars modules without
    # needing to call vault.vars.VaultVars.extract_vault_vars_from_file()
    passwd_file = os.path.join(os.path.dirname(__file__), "vault_password")
    vault_vars = vault.vars.VaultVars('common', 'secret.yml',
                                      vault_password_file=passwd_file)
    vault_vars.extract_vault_vars_from_file()
    vault = vault_vars._vault_passwords_dict['common']
    assert vault


# Generated at 2022-06-21 00:02:28.748039
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    # test data
    src = AnsibleVaultEncryptedUnicode("test")
    intab  = "aeiou"
    outtab = "12345"
    trantab = src.maketrans(intab, outtab)

    # expected result
    exp = "t2st"

    # test execution
    res = src.translate(trantab)

    # test result
    assert res == exp, "translate method of AnsibleVaultEncryptedUnicode failed"

# End of unit test for method translate of class AnsibleVaultEncryptedUnicode


# Generated at 2022-06-21 00:02:46.042697
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    s = 'foobar'
    avu = AnsibleVaultEncryptedUnicode(s)
    try:
        hash(avu)
    except TypeError as e:
        if "unhashable type: 'AnsibleVaultEncryptedUnicode'" in str(e):
            # ansible-unittest python 2.6 doesn't have assertRaisesRegex()
            return
    raise Exception('__hash__ should raise TypeError')


# Generated at 2022-06-21 00:02:57.761757
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    secret = 'toosecret'

    try:
        # TODO: make it work with pyca/cryptography or use backports.pbkdf2 on both py2 and py3
        import vaultlib
        vault = vaultlib.VaultLib(password=secret)
        avu = AnsibleVaultEncryptedUnicode.from_plaintext('toocryptic', vault, secret)
    except ImportError:
        vault = None
        avu = AnsibleVaultEncryptedUnicode.from_plaintext('toocryptic', vault, secret)
    assert avu.is_encrypted()
    assert avu == 'toocryptic'
    assert avu != 'toocryptic2'
    assert avu.is_encrypted()
    assert str(avu) == 'toocryptic'

    avu.v

# Generated at 2022-06-21 00:03:06.254317
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    """
    Unit test for methods title of class AnsibleVaultEncryptedUnicode
    """
    assert AnsibleVaultEncryptedUnicode("a").title() == "A"
    assert AnsibleVaultEncryptedUnicode("A").title() == "A"
    assert AnsibleVaultEncryptedUnicode("1").title() == "1"
    assert AnsibleVaultEncryptedUnicode("1A2B").title() == "1A2B"
    assert AnsibleVaultEncryptedUnicode("1a2b").title() == "1A2B"
    assert AnsibleVaultEncryptedUnicode("a b c").title() == "A B C"
    assert AnsibleVaultEncryptedUnicode("A b c").title() == "A B C"
    assert AnsibleVaultEncrypted

# Generated at 2022-06-21 00:03:17.859042
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    avu = AnsibleVaultEncryptedUnicode(b'A')
    assert avu.isalpha()
    avu = AnsibleVaultEncryptedUnicode(b'A1')
    assert not avu.isalpha()
    avu = AnsibleVaultEncryptedUnicode(b'A1!')
    assert not avu.isalpha()
    avu = AnsibleVaultEncryptedUnicode(b'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')
    assert avu.isalpha()
    avu = AnsibleVaultEncryptedUnicode(b'a1')
    assert not avu.isalpha()
    avu = AnsibleVaultEncryptedUnicode(b'a1!')

# Generated at 2022-06-21 00:03:22.303667
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode.from_plaintext("hoge", None, None)
    assert " hoge " == ansible_vault_encrypted_unicode.center(7)


# Generated at 2022-06-21 00:03:34.071325
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    class Vault(object):
        def decrypt(self, ciphertext):
            if ciphertext == b'a':
                return 'b'
            if ciphertext == b'ab':
                return 'cd'

    vault = Vault()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('a', vault, 'secret')
    avu_index = avu.rfind('a')
    assert(avu_index == 1)
    # No need to test for sub in multiple different types.
    # Unicode string (str on PY2) is only type used in AnsibleVaultEncryptedUnicode
    # that is not bytes or AnsibleVaultEncryptedUnicode.

    # test when sub is not found
    avu_index = avu.rfind('b')

# Generated at 2022-06-21 00:03:42.103133
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    import textwrap
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader

    vault = VaultLib('test')
    secret = 'thesecret'
    text = textwrap.dedent('''
        - vault:
            name: 'test'
            password_file: /path/to/password
        - vault:
            name: 'test2'
            password_file: /path/to/password
        ''')


# Generated at 2022-06-21 00:03:46.502103
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    a = AnsibleVaultEncryptedUnicode('hello%')
    assert a.isprintable() is False
    b = AnsibleVaultEncryptedUnicode('hello there')
    assert b.isprintable() is True



# Generated at 2022-06-21 00:03:58.774238
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    assert AnsibleVaultEncryptedUnicode(b'Hello World').startswith('Hello')
    assert AnsibleVaultEncryptedUnicode(b'Hello World').startswith('Hello', 0)
    assert not AnsibleVaultEncryptedUnicode(b'Hello World').startswith('Hello', 1)
    assert not AnsibleVaultEncryptedUnicode(b'Hello World').startswith('Heavens')
    assert ansible_unicode_startswith(AnsibleVaultEncryptedUnicode(b'Hello World'), 'Heavens', 1, 6)
    assert not ansible_unicode_startswith(AnsibleVaultEncryptedUnicode(b'Hello World'), 'Heavens', 1, 7)

# Generated at 2022-06-21 00:04:02.200733
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    a = AnsibleVaultEncryptedUnicode("Undecoded String")
    a.vault = None
    b = AnsibleVaultEncryptedUnicode("Undecoded String")
    b.vault = None
    assert a != b


# Generated at 2022-06-21 00:04:28.814174
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    # Test a short str
    short_str = 'abc'
    short_avu = AnsibleVaultEncryptedUnicode(short_str)
    assert short_avu.title == 'Abc'

    # Test a long str
    long_str = 'abcdefghijklmnopqrstuvwxyz'
    long_avu = AnsibleVaultEncryptedUnicode(long_str)
    assert long_avu.title == 'Abcdefghijklmnopqrstuvwxyz'

    # Test an empty str
    empty_str = ''
    empty_avu = AnsibleVaultEncryptedUnicode(empty_str)
    assert empty_avu.title == ''



# Generated at 2022-06-21 00:04:36.556689
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n12345678901234567890123456789012\n')
    assert avu.is_encrypted() == True

    avu = AnsibleVaultEncryptedUnicode('not encrypted')
    assert avu.is_encrypted() == False


# Generated at 2022-06-21 00:04:40.354659
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    s = 'LaPeTiteMaRiE'
    s1 = AnsibleVaultEncryptedUnicode(s)
    s2 = s1.swapcase()
    assert s2 == 'lApEtItEmArIe'


# Generated at 2022-06-21 00:04:42.535468
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    return not AnsibleVaultEncryptedUnicode.isupper(None)


# Generated at 2022-06-21 00:04:54.682059
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:05:05.089845
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    # test all the functions of AnsibleVaultEncryptedUnicode
    # encrypt a string
    vault = yaml.VaultLib()
    secret = vault.new_password()
    data = "Test123"
    # create an AnsibleVaultEncryptedUnicode (avu)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(data, vault, secret)
    # set avu's vault to vault
    avu.vault = vault
    # test data in avu
    assert(data == avu.data)
    assert(data != avu)
    assert(data == to_text(avu))
    assert(data == to_text(avu.format('%r')))
    assert(data == avu.capitalize())
    assert(data == avu.casefold())


# Generated at 2022-06-21 00:05:16.556806
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    import unittest
    class test_AnsibleVaultEncryptedUnicode___lt__(unittest.TestCase):
        def setUp(self):
            from ansible.parsing.vault import VaultLib
            self.vault = VaultLib('geheim')
        def test_1(self):
            plain = 'plain'
            self.assertEqual(AnsibleVaultEncryptedUnicode.from_plaintext(plain, self.vault, 'geheim') < plain, True)
        def test_2(self):
            plain = 'plain'
            self.assertEqual('plain' < AnsibleVaultEncryptedUnicode.from_plaintext(plain, self.vault, 'geheim'), False)
        def test_3(self):
            plain = 'plain'

# Generated at 2022-06-21 00:05:25.537558
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    # This test is to check how the method _rfind is behaving in the class AnsibleVaultEncryptedUnicode
    # The method is not behaving correctly, as we want it to return the last occurrence of a character
    # and not find.
    # When 'test_string' is created and the character 'a' is searched, 'test_string' is returned
    # instead of 'a'

    # To check the method rfind of class AnsibleVaultEncryptedUnicode, we create a instance of this
    # class.
    test_string = AnsibleVaultEncryptedUnicode('test_string')

    # Last occurrence of character 'a' should be 'a'
    assert test_string.rfind('a') != 'a'
    assert test_string.rfind('a') == 'test_string'


# Generated at 2022-06-21 00:05:35.230953
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    '''Test AnsibleVaultEncryptedUnicode.is_encrypted for correct return values.'''

    # data to encrypt and use for testing
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret
    cipher_data = '\x00\x00\x00\x01Z\x01\x00\x00\xc5\x01\x00\x00\x86\x01\x03\x00\x01\x02\x03\x14\x00\x00\x00\x00\x01\x00\x00\x00\x01'
    plain_data = "abc\n"

    # create secret
    secret = get_file_vault_secret(None)

# Generated at 2022-06-21 00:05:39.641657
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    s = u'{foo}'
    m = AnsibleVaultEncryptedUnicode(s)
    t = {'foo': 'bar'}
    assert s % t == 'bar'
    assert m % t == 'UNSAFE'


# Generated at 2022-06-21 00:05:54.143501
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    avu = AnsibleVaultEncryptedUnicode("hello world, how are you doing?")
    assert(avu.rpartition("or") == ("hello world, how are you doing?", "or", "ld, how are you doing?"))
    assert(avu.rpartition("or")[2] == AnsibleVaultEncryptedUnicode("ld, how are you doing?"))


# Generated at 2022-06-21 00:05:58.115713
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    """
    - AnsibleVaultEncryptedUnicode:
      - title:
    """
    assert 'Abc De' == AnsibleVaultEncryptedUnicode('abc de').title()



# Generated at 2022-06-21 00:05:59.556334
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    assert isinstance(AnsibleSequence([]), list)


# Generated at 2022-06-21 00:06:03.087241
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    seq = AnsibleVaultEncryptedUnicode('123456')
    assert '34' == seq[2:4]
    assert '56' == seq[5:7]



# Generated at 2022-06-21 00:06:06.152721
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    test_dict = AnsibleMapping()
    test_dict['key1'] = 'value1'
    assert test_dict['key1'] == 'value1'


# Generated at 2022-06-21 00:06:16.754564
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:06:29.048565
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    '''Unit test for method __add__ of class AnsibleVaultEncryptedUnicode'''
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import BytesIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_password = 'ansible'
    infile = BytesIO('abc')
    outfile = BytesIO()
    cipher_name = 'AES256'

    vault = VaultLib(cipher_name)
    encrypted_data = vault.encrypt(infile, outfile, vault_password)

    avu = AnsibleVaultEncryptedUnicode(encrypted_data)
    avu.vault = vault

    assert avu + '123' == 'abc123'

# Generated at 2022-06-21 00:06:38.990090
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    assert("1".isdigit())
    assert("0".isdigit())
    assert("123".isdigit())
    assert("-123".isdigit() is False)
    assert("A".isdigit() is False)

    if sys.version_info.major == 3:
        assert("123.4".isdigit() is False)
    else:
        assert("123.4".isdigit())


# Generated at 2022-06-21 00:06:47.622015
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    assert AnsibleVaultEncryptedUnicode("a").casefold() == AnsibleVaultEncryptedUnicode("a").casefold()
    assert AnsibleVaultEncryptedUnicode("A").casefold() == AnsibleVaultEncryptedUnicode("a").casefold()
    assert AnsibleVaultEncryptedUnicode("A").casefold() != AnsibleVaultEncryptedUnicode("B").casefold()



# Generated at 2022-06-21 00:06:55.249741
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    ''' 
    This unit test ensures rsplit method of class AnsibleVaultEncryptedUnicode works as expected.
    '''

# Generated at 2022-06-21 00:07:15.405290
# Unit test for method upper of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:07:23.182758
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    s = AnsibleSequence( yaml.load('''[
        "Ansible",
        "rocks",
        1.0,
        {},
        [],
        {
            "ansible_pos": [ "./test_yaml.py", 1, 0 ]
        }
    ]''') )
    assert len(s) == 6

    # the tests below are not portable between python2 and python3
    # since they do not use the abstract base class sequence
    assert s[0] == "Ansible"
    assert s[1] == "rocks"
    assert s[2] == 1.0
    assert s[3] == {}
    assert s[4] == []
    assert s[5] == { "ansible_pos": [ "./test_yaml.py", 1, 0 ] }

# Generated at 2022-06-21 00:07:34.621491
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    from ansible.parsing.vault import VaultLib

    # Create a VaultLib object
    vault = VaultLib([])

    # Create a vault string, the original type is str
    vault_str = 'vault: Vault password is incorrect'

    # Create a AnsibleVaultEncryptedUnicode object using AnsibleVaultEncryptedUnicode.from_plaintext
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(vault_str, vault, b'password')

    # Create a dictionary with the AnsibleVaultEncryptedUnicode object as the key
    my_dict = {avu: 'avu'}

    # Create a AnsibleVaultEncryptedUnicode object using AnsibleVaultEncryptedUnicode.from_plaintext
    avu2 = AnsibleVaultEncryptedUnic

# Generated at 2022-06-21 00:07:44.312576
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    # Set up the test class
    class AnsibleVaultEncryptedUnicode_Test(AnsibleVaultEncryptedUnicode):
        def __init__(self, *args):
            AnsibleVaultEncryptedUnicode.__init__(self, *args)

    # Create the test
    ansible_vault_test_raw = u'abcdéééé'
    ansible_vault_test = AnsibleVaultEncryptedUnicode_Test(ansible_vault_test_raw)

    assert ansible_vault_test_raw.isprintable() == ansible_vault_test.isprintable()

AnsibleUnsafeText = AnsibleVaultEncryptedUnicode


# Generated at 2022-06-21 00:07:51.199662
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    if 'AnsibleVaultEncryptedUnicode' in globals():
        str1 = AnsibleVaultEncryptedUnicode('Hello World')
        str2 = AnsibleVaultEncryptedUnicode('Hello')
        str3 = AnsibleVaultEncryptedUnicode('World')
        str4 = AnsibleVaultEncryptedUnicode(' ')
        assert(str1.rindex('Hello') == 0)
        assert(str1.rindex('World') == 6)
        assert(str1.rindex(' ') == 5)
        assert(str1.rindex(str2) == 0)
        assert(str1.rindex(str3) == 6)
        assert(str1.rindex(str4) == 5)

# Generated at 2022-06-21 00:07:56.631107
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    plain = to_bytes('{secret}', encoding='utf-8')

# Generated at 2022-06-21 00:08:00.346042
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    # Test that the method rjust of the class AnsibleVaultEncryptedUnicode works as expected
    assert AnsibleVaultEncryptedUnicode('abc').rjust(5) == '  abc'



# Generated at 2022-06-21 00:08:09.323123
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    assert AnsibleVaultEncryptedUnicode('foo').count('a') == 0
    assert AnsibleVaultEncryptedUnicode('foo').count('o') == 2
    assert AnsibleVaultEncryptedUnicode('foo').count('o', 2) == 1
    assert AnsibleVaultEncryptedUnicode('foo').count('o', 0, 2) == 1
    assert AnsibleVaultEncryptedUnicode('a').count('') == 2
    assert AnsibleVaultEncryptedUnicode('aaaa').count('') == 5
    assert AnsibleVaultEncryptedUnicode('aaaa').count('', 2) == 3
    assert AnsibleVaultEncryptedUnicode('aaaa').count('', 0, 2) == 2


# Generated at 2022-06-21 00:08:16.391259
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    value = AnsibleVaultEncryptedUnicode.from_plaintext("abcdef", None, None)
    assert value[0] == "a"
    assert value[-1] == "f"
    assert value[2:4] == "cd"
    assert value[1:4:2] == "bd"
    assert value[:-1] == "abcde"
    assert value[::-1] == "fedcba"


# Generated at 2022-06-21 00:08:21.625873
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    my_obj = AnsibleVaultEncryptedUnicode(u"MY DATA")
    expected_res = u"My data"
    assert my_obj.capitalize() == expected_res

# Unit tests for methods casefold, endswith, isalnum, isspace, istitle
# of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:08:34.440141
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    s = AnsibleVaultEncryptedUnicode("  12345")
    assert "  12345" == str(s)
    assert "12345" == s.lstrip()


# Generated at 2022-06-21 00:08:42.374563
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    # Generate a random string
    rand_int = random.randint(0, sys.maxsize)
    rand_str = str(rand_int)
    rand_unicode = unicode(rand_str)

    # Test __getitem__ with a simple integer and string
    base = AnsibleVaultEncryptedUnicode(rand_str)
    base.zfill(10)
    assert len(base) == 10
    assert base[0] == "0"
    assert base == "000000000" + rand_str


# Generated at 2022-06-21 00:08:54.877012
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    # Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
    #
    # From comment of Python's UserString.py
    #
    # I've decided to restrict Unicode representation to hexadecimal for tidyness.
    # This code could be changed to print without u'' but the result is not really readable
    # anyway.
    #
    import unittest

    class TestAnsibleVaultEncryptedUnicode(unittest.TestCase):
        def setUp(self):
            self.avu = AnsibleVaultEncryptedUnicode('\xc3\xa9')

        def test_isinstance(self):
            self.assertIsInstance(self.avu, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-21 00:09:04.174726
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    # Ensure ``AnsibleVaultEncryptedUnicode`` format method works
    # the same as ``str``
    plain_str = u'a,b,c'
    plain_u = AnsibleVaultEncryptedUnicode(plain_str)
    plain_str_fmt   = plain_str.format('d', e='f')
    plain_u_fmt = plain_u.format('d', e='f')
    assert plain_u_fmt == plain_str_fmt

    # Ensure ``AnsibleVaultEncryptedUnicode`` cannot be formatted
    # with keywords if it contains no replacement fields
    plain_str_fmt_err   = plain_str.format(d='e')
    plain_u_fmt_err = plain_u.format(d='e')
    assert plain_str

# Generated at 2022-06-21 00:09:13.044458
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib

    vault_secret = 'this is a really really really really really really really really really really really really super secret password just for testing'
    vault = VaultLib(vault_secret)
    password = vault.encrypt('this is a test')
    encrypted_data = AnsibleVaultEncryptedUnicode(password)
    encrypted_data.vault = vault

    assert encrypted_data <= 'this is a test'
    assert not encrypted_data <= 'this is a test too'
    assert not encrypted_data <= 'this is a test!'


# Generated at 2022-06-21 00:09:23.605320
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('test')
    # This is the main check for __le__: the data property is the same, this is what's compared
    v1 = AnsibleVaultEncryptedUnicode.from_plaintext('foobaz', vault, 'test')
    v2 = AnsibleVaultEncryptedUnicode.from_plaintext('foobaz', vault, 'test')
    assert v1 <= v2
    assert v2 <= v1

    # This is just a check to make sure that the underlying method is operating correctly
    v1 = AnsibleVaultEncryptedUnicode.from_plaintext('foobaz', vault, 'test')
    v2 = AnsibleVaultEncryptedUnicode.from_plaintext('foobazabc', vault, 'test')

# Generated at 2022-06-21 00:09:32.151804
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    # test the constructor
    class Vault:
        '''
        fake vaultlib class to test AnsibleVaultEncryptedUnicode constructor
        '''
        def encrypt(self, plaintext, secret):
            encrypted = plaintext
            return encrypted

        def decrypt(self, ciphertext):
            decrypted = ciphertext
            return decrypted

        def is_encrypted(self, ciphertext):
            return True

    avue = AnsibleVaultEncryptedUnicode.from_plaintext('foo', Vault(), 'secret')
    assert isinstance(avue, AnsibleVaultEncryptedUnicode)
    assert avue == 'foo'
    assert avue == b'foo'
    assert avue == u'foo'
    assert avue != u'foo2'
    assert avue.is_encrypted() is True

# Generated at 2022-06-21 00:09:37.946785
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    '''Unit test for method isalnum of class AnsibleVaultEncryptedUnicode'''
    avu = AnsibleVaultEncryptedUnicode('teststring42')
    assert avu.isalnum()
    avu = AnsibleVaultEncryptedUnicode('teststring42%%')
    assert not avu.isalnum()


# Generated at 2022-06-21 00:09:40.196606
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    u = AnsibleVaultEncryptedUnicode('abcd')
    u2 = AnsibleVaultEncryptedUnicode('1')
    assert repr(u.replace('a','1')) == repr(u2)

# Generated at 2022-06-21 00:09:51.302862
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    """
    Test method ``AnsibleVaultEncryptedUnicode.__complex__`` against values in
    Python, to ensure it follows the same behavior.
    """
    vault = AnsibleVaultEncryptedUnicode.from_plaintext(u'1+2j', 'secret')
    assert vault.__complex__() == u'1+2j'

    vault = AnsibleVaultEncryptedUnicode.from_plaintext(u'(1+2j)', 'secret')
    assert vault.__complex__() == u'(1+2j)'

    vault = AnsibleVaultEncryptedUnicode.from_plaintext(u'1.0+2.0j', 'secret')
    assert vault.__complex__() == u'1.0+2.0j'

    vault = AnsibleVaultEncrypted

# Generated at 2022-06-21 00:10:23.326836
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    # pylint: disable=protected-access
    # fudge the class so we can set some attribute values
    class _AnsibleVaultEncryptedUnicode(AnsibleVaultEncryptedUnicode):
        def __init__(self, ciphertext, vault, data):
            AnsibleVaultEncryptedUnicode.__init__(self, ciphertext)
            self.vault = vault
            self.data = data
    class _Vault:
        def decrypt(self, ciphertext):
            return 'decrypted:%s' % ciphertext

    # simple tests
    assert _AnsibleVaultEncryptedUnicode('something', None, '123').endswith('23')
    assert not _AnsibleVaultEncryptedUnicode('something', None, '123').endswith('234')

    # with

# Generated at 2022-06-21 00:10:33.530281
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('ansible')

    password = 'password'
    plaintext = 'abcdefg'
    encrypted = vault.encrypt(plaintext, password)
    avu = AnsibleVaultEncryptedUnicode(encrypted)
    assert avu.rindex('d') == 3
    assert avu.rindex('b') == 1
    assert avu.rindex('c') == 2
    assert avu.rindex('e') == 4
    assert avu.rindex('a') == 0
    assert avu.rindex('g') == 6
    assert avu.rindex('abc') == 0
    assert avu.rindex('def') == 3
    assert avu.rindex('gfe') == 3

# Generated at 2022-06-21 00:10:39.003191
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    from ansible.parsing.vault import VaultLib

    # Arrange
    vault = VaultLib(password='secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, 'secret')

    # Act
    actual = avu.startswith('abc')

    # Assert
    assert actual is True



# Generated at 2022-06-21 00:10:50.632388
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    avu_partition_object = AnsibleVaultEncryptedUnicode('a5:$ANSIBLE_VAULT;0.7;AES256;', True)
    assert avu_partition_object.partition(':') == (u'a5', u':', u'$ANSIBLE_VAULT;0.7;AES256;')
    assert avu_partition_object.partition('ANSIBLE_VAULT;') == (u'a5:$', u'ANSIBLE_VAULT;', u'0.7;AES256;')
    assert avu_partition_object.partition('not found') == (u'a5:$ANSIBLE_VAULT;0.7;AES256;', u'', u'')


# Generated at 2022-06-21 00:10:52.736938
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    x = AnsibleVaultEncryptedUnicode('YELLOW SUBMARINE')
    assert x.lower() == 'yellow submarine'

# Generated at 2022-06-21 00:10:59.434418
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    import ansible.parsing.vault as vaultlib
    vault = vaultlib.VaultLib('secret')
    assert 'secret' == AnsibleVaultEncryptedUnicode.from_plaintext('thank you for the secret', vault, 'secret').data
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('thank you for the secret', vault, 'secret')
    assert 'secret' == avu.data[avu.find('secret'):]
    assert 'thank you for the ' == avu.data[:avu.find('secret')]
    assert 'secret' == avu.data[::-1][avu[::-1].find('secret'):]
    assert 'thank you for the ' == avu.data[::-1][:avu[::-1].find('secret')]
