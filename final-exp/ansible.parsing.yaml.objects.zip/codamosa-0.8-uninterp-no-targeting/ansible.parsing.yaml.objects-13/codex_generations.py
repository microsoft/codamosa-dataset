

# Generated at 2022-06-21 00:01:24.602707
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    assert AnsibleVaultEncryptedUnicode("Hello").swapcase() == AnsibleVaultEncryptedUnicode("hELLO")
    assert AnsibleVaultEncryptedUnicode("Hello").swapcase().swapcase() == AnsibleVaultEncryptedUnicode("Hello")
    assert AnsibleVaultEncryptedUnicode("Hello").swapcase() == AnsibleVaultEncryptedUnicode("hELLO")
    assert AnsibleVaultEncryptedUnicode("Hello").swapcase() == AnsibleVaultEncryptedUnicode("hELLO")


# Generated at 2022-06-21 00:01:28.319319
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    input = AnsibleVaultEncryptedUnicode(u'12345')
    expected_output = True
    actual_output = input.isdigit()
    assert expected_output == actual_output


# Generated at 2022-06-21 00:01:34.902572
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    s = str("abc")
    t = str(" ")
    assert s.ljust(5) == "abc  "
    assert s.ljust(5, t) == "abc  "

    s = AnsibleVaultEncryptedUnicode("abc")
    t = AnsibleVaultEncryptedUnicode(" ")

    assert s.ljust(5) == "abc  "
    assert s.ljust(5, t) == "abc  "


# Generated at 2022-06-21 00:01:38.111176
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    method_under_test = AnsibleVaultEncryptedUnicode('a').center
    assert method_under_test(2) == '  a'



# Generated at 2022-06-21 00:01:46.110321
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    actual = AnsibleVaultEncryptedUnicode(b'123456').zfill(7)
    assert isinstance(actual, AnsibleVaultEncryptedUnicode)
    assert actual == AnsibleVaultEncryptedUnicode(b'0123456')
    actual = AnsibleVaultEncryptedUnicode(b'123456').zfill(4)
    assert isinstance(actual, AnsibleVaultEncryptedUnicode)
    assert actual == AnsibleVaultEncryptedUnicode(b'123456')



# Generated at 2022-06-21 00:01:48.934677
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    str = "test string"
    avueu = AnsibleVaultEncryptedUnicode(str)
    assert avueu.capitalize() == "Test string"


# Generated at 2022-06-21 00:01:59.627951
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    assert AnsibleVaultEncryptedUnicode(b'hello world').title() == b'Hello World'
    assert AnsibleVaultEncryptedUnicode(u'hello world').title() == u'Hello World'

# Generated at 2022-06-21 00:02:07.180816
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    s = AnsibleVaultEncryptedUnicode(b'abcdefghijklmnopqrstuvwxyz')
    if _sys.version_info < (3,):
        assert s.translate(None, 'aeiou') == 'bcdfghjklmnpqrstvwxyz'
    else:
        assert s.translate(str.maketrans(dict.fromkeys('aeiou'))) == 'bcdfghjklmnpqrstvwxyz'


# Generated at 2022-06-21 00:02:16.848421
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    # test isupper of AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('')
    assert not avu.isupper(), 'avu.isupper() 1 failed'

    avu = AnsibleVaultEncryptedUnicode('\n')
    assert not avu.isupper(), 'avu.isupper() 2 failed'

    avu = AnsibleVaultEncryptedUnicode(' \t')
    assert not avu.isupper(), 'avu.isupper() 3 failed'

    # test isupper of AnsibleVaultEncryptedUnicode under various locale
    import locale

    # Build the locale list
    locale_list = []

# Generated at 2022-06-21 00:02:19.247277
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    avue = AnsibleVaultEncryptedUnicode(b'Hello World')
    assert avue.title() == 'Hello World'


# Generated at 2022-06-21 00:02:26.075852
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    plaintext = 'correct horse battery staple'
    assert plaintext == AnsibleVaultEncryptedUnicode(plaintext).encode()


# Generated at 2022-06-21 00:02:30.473160
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    assert AnsibleVaultEncryptedUnicode(u'abc').islower()
    assert not AnsibleVaultEncryptedUnicode(u'AbC').islower()
    assert not AnsibleVaultEncryptedUnicode(u'ABC').islower()


# Generated at 2022-06-21 00:02:39.699055
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError
    # prepare VaultLib
    plaintext=b'3.5'
    secret=b'$ANSIBLE_VAULT;1.1;AES256\n33373039386462626238663039323061346264333933316361343437306636333236633664303361\n39353930383062386466353864373636643233323764356637393466653835323064376233653735\n6437656363343965336334336364366534336331663733\n'
    vault = VaultLib(plaintext)
    # create AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:02:51.171769
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    from ansible.parsing import vault
    from ansible_collections.notstdlib.moveitallout.plugins.filter.vault_decrypt import vault_decrypt
    from ansible_collections.notstdlib.moveitallout.plugins.filter.vault_decrypt import vault_decrypt_filter

    # create an AnsibleVaultEncryptedUnicode object
    a = AnsibleVaultEncryptedUnicode.from_plaintext(u'Some text', vault, secret=b'password')

    # compare the result of the method lower() with the decrypted value
    # This test checks that the method lower returns the exact same result
    # as the decrypted value.

# Generated at 2022-06-21 00:02:58.077275
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    assert AnsibleVaultEncryptedUnicode('test').islower()
    assert not AnsibleVaultEncryptedUnicode('TEST').islower()
    assert AnsibleVaultEncryptedUnicode('test1').islower()
    assert not AnsibleVaultEncryptedUnicode('TEST1').islower()
    assert not AnsibleVaultEncryptedUnicode('TEST 1').islower()



# Generated at 2022-06-21 00:03:06.508942
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    msg='Unicode is not printable'
    instance = AnsibleVaultEncryptedUnicode('')
    assert not instance.isprintable(), msg
    instance.data = '\u0007'
    assert not instance.isprintable(), msg
    instance.data = '\u0020'
    assert instance.isprintable(), msg
    instance.data = '\u0021'
    assert instance.isprintable(), msg
    instance.data = '\u0048'
    assert instance.isprintable(), msg
    instance.data = '\u007E'
    assert instance.isprintable(), msg
    instance.data = '\u007F'
    assert not instance.isprintable(), msg
    # and some slightly more exotic ones:
    instance.data = '\u00A0'
    assert instance

# Generated at 2022-06-21 00:03:18.070364
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    #
    # expected_result_literal is the string that would be returned by
    #     AnsibleVaultEncryptedUnicode('literal').casefold()
    #     AnsibleVaultEncryptedUnicode('æ').casefold()
    #
    expected_result_literal  = 'literal'
    expected_result_æ        = 'ae'

    #
    # test_literal is a literal string that is defined to have the same
    # semantics as the string that would be returned by
    #     AnsibleVaultEncryptedUnicode('literal').casefold()
    # test_æ is a literal string that is defined to have the same
    # semantics as the string that would be returned by
    #     AnsibleVaultEncryptedUnicode('æ').casefold()
    #

# Generated at 2022-06-21 00:03:21.468013
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    avu = AnsibleVaultEncryptedUnicode("blah")
    avu.data = "42"
    assert int(avu) == 42


# Generated at 2022-06-21 00:03:24.583610
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    avu = AnsibleVaultEncryptedUnicode("ABCD")
    result = avu.rfind("CD")
    assert result == 2


# Generated at 2022-06-21 00:03:28.985721
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    x = AnsibleBaseYAMLObject()
    x.ansible_pos = (u"foobar", 7, 12)
    assert x._data_source == u"foobar"
    assert x._line_number == 7
    assert x._column_number == 12


# Generated at 2022-06-21 00:03:40.870572
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    s = AnsibleVaultEncryptedUnicode('a')
    s.data = '   abc   '
    assert s.strip() == 'abc'
    s.data = '   abc'
    assert s.strip() == 'abc'
    s.data = 'abc   '
    assert s.strip() == 'abc'
    s.data = '     '
    assert s.strip() == ''

if __name__ == '__main__':
    from unittest import main
    main()

# Generated at 2022-06-21 00:03:52.895716
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    avueu_inst = AnsibleVaultEncryptedUnicode
    assert avueu_inst('a').isidentifier()
    assert not avueu_inst('a ').isidentifier()


if hasattr(yaml, 'CSafeLoader'):
    class AnsibleLoader(yaml.CSafeLoader):
        ''' Main class for ansible YAML loading '''

        def construct_yaml_map(self, node):
            data = AnsibleMapping()
            yield data
            value = self.construct_mapping(node)
            data.update(value)
            data.ansible_pos = (self.name, node.start_mark.line + 1, node.start_mark.column + 1)


# Generated at 2022-06-21 00:04:03.890300
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:04:13.279482
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    from collections import Iterable
    import sys

    if sys.version_info[0] < 3:
        class CompatIterable(Iterable):
            def __iter__(self):
                for i in range(5):
                    yield i
    else:
        CompatIterable = Iterable

    for data in [
        b'abc',
        list(range(5)),
        CompatIterable(),
    ]:
        # ensure we can iterate over it
        assert isinstance(reversed(AnsibleVaultEncryptedUnicode(data)), Iterable)

# Generated at 2022-06-21 00:04:24.500772
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib()
    # Testing with a valid vault id
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('test1', vault, 'test_secret')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test2', vault, 'test_secret')
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext('test3', vault, 'test_secret')
    avu1.vault = vault
    avu2.vault = vault
    avu3.vault = vault
    avulist = [avu1, avu2, avu3]
    #

# Generated at 2022-06-21 00:04:27.106715
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    '''
    Check to make sure AnsibleBaseYAMLObject constructor works without error
    '''
    obj = AnsibleBaseYAMLObject()
    assert obj.ansible_pos is None


# Generated at 2022-06-21 00:04:38.733034
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    version = _sys.version_info


# Generated at 2022-06-21 00:04:42.687410
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    assert AnsibleVaultEncryptedUnicode("{password}", True).format_map({'password': 'secret'}) == 'secret'
    assert format_map({'password': 'secret'}) == 'secret'


# Generated at 2022-06-21 00:04:53.444597
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    assert AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None) >= 'foo'
    assert AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None) >= AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None)
    assert not AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None) >= 'bar'
    assert not AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None) >= AnsibleVaultEncryptedUnicode.from_plaintext('bar', None, None)



# Generated at 2022-06-21 00:05:01.542947
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    avu_1 = AnsibleVaultEncryptedUnicode('encrypted_text')
    avu_1.vault = None
    avu_2 = AnsibleVaultEncryptedUnicode('encrypted_text')
    avu_2.vault = None
    assert avu_1 >= avu_2
    assert avu_2 >= avu_1
    assert not avu_1 == avu_2
    assert not avu_2 == avu_1
    assert avu_1 != avu_2
    assert avu_2 != avu_1

# Generated at 2022-06-21 00:05:21.635010
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:05:29.502979
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    import unittest
    import vaultlib
    import os

    # Create a vault with non-english unicode characters
    secret = "password"
    vault = vaultlib.VaultLib(secret)
    unicode_plaintext = u"Á"
    unicode_ciphertext = vault.encrypt(unicode_plaintext)
    avu = AnsibleVaultEncryptedUnicode(unicode_ciphertext)
    avu.vault = vault

    # Test different casing
    class TestStringMethods(unittest.TestCase):
        def test_casefold(self):
            self.assertEqual(avu.casefold(), u"á")

    if __name__ == '__main__':
        unittest.main()


# Generated at 2022-06-21 00:05:38.138396
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:05:39.820336
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    assert AnsibleVaultEncryptedUnicode('abc').upper() == 'ABC'



# Generated at 2022-06-21 00:05:50.828600
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    from ansible.parsing import vault

    vault_password_file = os.path.join(tempfile.gettempdir(), 'ansible-vault-password-file')
    file_content = "test_vault_password"
    with open(vault_password_file, 'wb') as f:
        f.write(file_content.encode('utf-8'))
    vault_secret = vault.get_vault_secret(vault_password_files=[vault_password_file])
    plaintext="test_plaintext"
    ciphertext = vault.VaultLib(vault_secret).encrypt(plaintext, secret=vault_password_file)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-21 00:05:57.998352
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    sample = AnsibleVaultEncryptedUnicode(b'foo')
    assert sample.endswith(b'o') == True

if yaml.__with_libyaml__:
    # We meaningfully confuse PyYAML when we use our own classes, so we need to give
    # it a hint to not try to use the C version with our custom class
    yaml.CLoader.yaml_implicit_resolvers = {}



# Generated at 2022-06-21 00:06:03.562776
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    a = AnsibleVaultEncryptedUnicode('abc')
    b = AnsibleVaultEncryptedUnicode('123')
    mapping = {'a': a, 'b': b}
    assert "a|>{a}<|b|>{b}<|" == "{a}|{b}".format_map(mapping)


# Generated at 2022-06-21 00:06:12.298863
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    assert AnsibleVaultEncryptedUnicode('  title  ').title() == '  Title  '
    assert AnsibleVaultEncryptedUnicode('\ttitle\t').title() == '\tTitle\t'
    assert AnsibleVaultEncryptedUnicode(text_type('  title  ')).title() == '  Title  '

# This class is used to handle binary data in vars/files etc.
# It is checked for an id by the check_object method
# and if found the value is base64 encoded and the class
# is set to AnsibleBase64

# Generated at 2022-06-21 00:06:16.560935
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    assert AnsibleVaultEncryptedUnicode("bar") < "foo"
    assert AnsibleVaultEncryptedUnicode("bar") < AnsibleVaultEncryptedUnicode("foo")
    assert not AnsibleVaultEncryptedUnicode("foo") < "bar"
    assert not AnsibleVaultEncryptedUnicode("foo") < AnsibleVaultEncryptedUnicode("bar")
    assert not ("foo" < AnsibleVaultEncryptedUnicode("bar"))


# Generated at 2022-06-21 00:06:19.804791
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    assert AnsibleVaultEncryptedUnicode(
        to_bytes('this is a test')
    ).split(' ') == ['this', 'is', 'a', 'test']


# Generated at 2022-06-21 00:06:41.574516
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu2 = AnsibleVaultEncryptedUnicode('bar')
    seq = [1, avu2, 3, avu, 5]
    res = avu.join(seq)
    assert res == "1bar3foofoo5"

    seq = [1, "bar", 3, "foo", 5]
    res = avu.join(seq)
    assert res == "1bar3foofoo5"

    seq = [1, avu2, 3, "foo", 5]
    res = avu.join(seq)
    assert res == "1bar3foofoo5"

    with pytest.raises(TypeError):
        seq = [1, "bar", 3, 5]
        res = avu.join(seq)

# Generated at 2022-06-21 00:06:52.872663
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    import re
    result = "abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcde"
    s = AnsibleVaultEncryptedUnicode(result)
    assert s.rindex("e") == len(result) - 1
    assert s.rindex("f") == -1
    assert s.rindex("a") == 0
    assert s.rindex("cde") == 19
    assert s.rindex("cde", 0, -1) == 19
    assert s.rindex("cde", 0, -2) == 13
    assert s.rindex("cde", 0, -3) == 7
    assert s.rindex("cde", 0, -4) == 1
    assert s.rindex("cde", 0, -5) == -1
    assert s

# Generated at 2022-06-21 00:07:01.225032
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    class DummyVault(object):
        """A dummy Vault object that doesn't do anything to the data"""
        def encrypt(self, data, secret):
            return data
        def decrypt(self, data, obj):
            return data
        def is_encrypted(self, data):
            return False

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('secret', DummyVault(), None)
    assert type(reversed(avu)) is text_type
    assert reversed(avu) == 'terces'


# Generated at 2022-06-21 00:07:04.813854
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    result = reversed(AnsibleVaultEncryptedUnicode(b'dog'))
    assert(isinstance(result, text_type))
    assert(result == 'god')


# Generated at 2022-06-21 00:07:09.925524
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    u_string = AnsibleVaultEncryptedUnicode('abcdefgabc', vault=None)
    assert u_string.index('c') == 2
    assert u_string.index('c', 3) == 7
    assert u_string.index('c', 3, -1) == 7
    assert u_string.index('x') == -1

# Generated at 2022-06-21 00:07:19.940426
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    s = AnsibleVaultEncryptedUnicode('abcdef')
    assert s.startswith('a')
    assert s.startswith('ab')
    assert s.startswith('abc')
    assert not s.startswith('abcdeg')
    assert s.startswith(('a', 'b', 'c'))
    assert s.startswith(('ab', 'bc'))
    assert not s.startswith(('a', 'b', 'cd'))

    # test AnsibleVaultEncryptedUnicode itself
    assert AnsibleVaultEncryptedUnicode.startswith.__doc__
    assert AnsibleVaultEncryptedUnicode.startswith.__name__ == 'startswith'
    assert AnsibleVaultEncryptedUnicode.startswith.__qualname__

# Generated at 2022-06-21 00:07:28.805519
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    class SimpleVault:
        def decrypt(self, data, obj=None):
            return data

    vault = SimpleVault()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('_key_', vault, secret='_secret_')
    mapping = {'key': 'value'}

    assert avu.format_map(mapping) == '_key_'

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('key={key}', vault, secret='_secret_')
    assert avu.format_map(mapping) == 'key=value'



# Generated at 2022-06-21 00:07:31.307144
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    avu = AnsibleVaultEncryptedUnicode('something')
    assert avu.__unicode__() == 'something'



# Generated at 2022-06-21 00:07:42.355726
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    import unittest.mock as mock
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import decrypt

    result = mock.MagicMock()
    result.decrypt = mock.MagicMock(return_value="hello")
    vault = mock.MagicMock()
    vault.decrypt = mock.Mock(return_value="hello")
    vault.is_encrypted = mock.Mock(return_value=True)
    secret = VaultSecret()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("hello", vault, secret)
    assert avu.vault == vault

# Generated at 2022-06-21 00:07:50.285001
# Unit test for method lower of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:08:05.993161
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    s = AnsibleVaultEncryptedUnicode("The quick brown fox jumps over the lazy dog")

    # with the needle in the middle
    assert s.rfind("brown") == 10

    # with the needle at the start
    assert s.rfind("The") == 0

    # with the needle at the end
    assert s.rfind("dog") == 40

    # with the needle not present
    assert s.rfind("xxx") == -1

    # with start and end specified
    assert s.rfind("The", 0, 15) == 0
    assert s.rfind("The", 16, 40) == -1



# Generated at 2022-06-21 00:08:07.648173
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    string_to_strip = 'ABC '
    avue = AnsibleVaultEncryptedUnicode(string_to_strip)
    assert avue.rstrip() == 'ABC'

# Generated at 2022-06-21 00:08:09.949208
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    new = AnsibleVaultEncryptedUnicode('*[')
    assert new.lstrip('*') == '[', 'method lstrip of class AnsibleVaultEncryptedUnicode returns wrong data'


# Generated at 2022-06-21 00:08:13.106837
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    av = AnsibleVaultEncryptedUnicode('encrypted')
    assert av.join(['hello ', 'world']) == 'hello encryptedworld'


# Generated at 2022-06-21 00:08:15.639026
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    assert AnsibleVaultEncryptedUnicode('').upper() is None


# Generated at 2022-06-21 00:08:26.766542
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    import re
    for string in [(u'தமிழ்'), (u'मराठी'), (u'Українська'), (u'العربية')]:
        r = re.compile(string.casefold())
        assert r.search(string) is not None
        assert r.search(string.casefold()) is not None
        assert r.search(string.upper()) is not None
        assert r.search(string.lower()) is not None
        assert r.search(string.swapcase()) is not None
        assert r.search(string.capitalize()) is not None
        assert r.search(string.title()) is not None

# Generated at 2022-06-21 00:08:33.445390
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    # Python 2 doesn't recognize unicode characters as whitespace, and
    # as such won't recognize them as printable.
    if _sys.version_info[0] < 3:
        assert AnsibleVaultEncryptedUnicode(' ').isprintable()
        assert AnsibleVaultEncryptedUnicode(u' ').isprintable()
        assert AnsibleVaultEncryptedUnicode(u'\u2000').isprintable()
    else:
        assert not AnsibleVaultEncryptedUnicode(' ').isprintable()
        assert not AnsibleVaultEncryptedUnicode(u' ').isprintable()
        assert not AnsibleVaultEncryptedUnicode(u'\u2000').isprintable()


# Generated at 2022-06-21 00:08:44.694255
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    original = u"""\
#!/bin/bash

echo "TEST_VAR=$TEST_VAR"
echo "TEST_VAR2=$TEST_VAR2"
"""
    vault.load_vault_file(".vault_pass")
    avue = AnsibleVaultEncryptedUnicode.from_plaintext(original, vault, "secret")

    if _sys.version_info[0] < 3:
        # python2.7
        assert avue.__radd__('#!/bin/bash\n\n') == '#!/bin/bash\n\nTEST_VAR=$TEST_VAR\necho "TEST_VAR2=$TEST_VAR2"'

# Generated at 2022-06-21 00:08:55.519932
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    # The following line needs to be changed to have the vault secret:
    vault = vaultlib.VaultLib('vault_secret')
    # The following line needs to be changed to have the secret:
    secret = '123'
    # The following line needs to be changed to have the secret:
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode.from_plaintext(secret, vault, secret)
    # Check if unicode is correct:
    unicode_decrypted = ansible_vault_encrypted_unicode.__unicode__()
    # Check if unicode is correct:
    assert unicode_decrypted == secret


# Generated at 2022-06-21 00:09:02.962269
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    ciphertext = b"$ANSIBLE_VAULT;1.1;AES256\n"
    ciphertext += b"253665363235653637363062363839383734336665616564303939636630326431646635303665\n"
    ciphertext += b"31653665303836356538326438633731643566653537353339303333313333383635626131333062\n"
    ciphertext += b"65323836383466396162363462316563373132303433396531323964653636666264393965636332\n"

# Generated at 2022-06-21 00:09:21.268934
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    '''
    AnsibleVaultEncryptedUnicode.__mod__(args) -> str
    Return the string obtained by formatting the AnsibleVaultEncryptedUnicode using the specified dictionary.
    '''
    # string module
    my_string = u'Hello, %(planet)s'
    my_dict = {'planet': 'world'}
    assert my_string % my_dict == 'Hello, world'

    # py3 - basic string formatting
    my_string = AnsibleVaultEncryptedUnicode(u'Hello, {planet}')
    my_dict = {'planet': 'world'}
    assert my_string % my_dict == 'Hello, world'

    # py3 - basic string formatting - with vault
    my_string = AnsibleVaultEncryptedUnicode('My age is {age}')

# Generated at 2022-06-21 00:09:28.071387
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    assert AnsibleUnicode('spam') == 'spam'
    assert isinstance(AnsibleUnicode('spam'), text_type)
    assert int(AnsibleUnicode('1')) == 1
    assert float(AnsibleUnicode('1.4')) == 1.4


# Generated at 2022-06-21 00:09:31.169141
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    string = AnsibleVaultEncryptedUnicode("test")
    string = string.center(6)
    assert string == " test "
    string = string.center(4)
    assert string == "test"


# Generated at 2022-06-21 00:09:41.395754
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    secret = 'secret'

# Generated at 2022-06-21 00:09:51.533059
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    import ansible.module_utils.six as six

    # Test for Unicode input with and without unicode literal
    if six.PY3:
        good_data = [u'übercafé']
        bad_data = [u'ÜBERCAFÉ']
    else:
        good_data = [u'übercafé', 'übercafé']
        bad_data = ['ÜBERCAFÉ', u'ÜBERCAFÉ']

    for data in good_data:
        assert isinstance(data, text_type)

    for data in bad_data:
        assert not isinstance(data, text_type)

    for data in good_data:
        obj = AnsibleUnicode(data)
        assert isinstance(obj, text_type)


# Generated at 2022-06-21 00:10:01.823590
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:10:08.957939
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    from ansible.parsing.vault import VaultLib
    vault_secret = b'ansible'
    plaintext = b'123'
    vault = VaultLib(vault_secret)
    vaulted_plaintext = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, vault_secret)
    assert isinstance(123, int)
    assert isinstance(int(vaulted_plaintext), int)
    assert 123 == int(vaulted_plaintext)



# Generated at 2022-06-21 00:10:20.267204
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    # Test for alphabetic string
    print("Testing for alphabetic string:")
    obj = AnsibleUnicode("abcd")
    obj_result = obj.islower()
    print("Actual : {} , Expected : {}".format(obj_result,True))

    # Test for numeric string
    print("Testing for numeric string:")
    obj = AnsibleUnicode("123")
    obj_result = obj.islower()
    print("Actual : {} , Expected : {}".format(obj_result,False))

    # Test for alphanumeric string
    print("Testing for alphanumeric string:")
    obj = AnsibleUnicode("abc123")
    obj_result = obj.islower()
    print("Actual : {} , Expected : {}".format(obj_result,True))

    # Test

# Generated at 2022-06-21 00:10:26.597909
# Unit test for method title of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:10:30.482957
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    assert not AnsibleVaultEncryptedUnicode.__ge__(None, None)
    assert not AnsibleVaultEncryptedUnicode.__ge__(AnsibleVaultEncryptedUnicode("{"), AnsibleVaultEncryptedUnicode("{"))

# Generated at 2022-06-21 00:10:41.576954
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    a = AnsibleVaultEncryptedUnicode("test")
    assert a.rjust(10) == "      test"


# Generated at 2022-06-21 00:10:47.646806
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # data is not decrypted yet.
    assert AnsibleVaultEncryptedUnicode('abc') < 'abc'
    assert not AnsibleVaultEncryptedUnicode('abc') < 'abd'
    assert AnsibleVaultEncryptedUnicode('abc') < 'abcd'
    assert not AnsibleVaultEncryptedUnicode('abcd') < 'abc'



# Generated at 2022-06-21 00:10:56.977298
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''
    This is a unit test to ensure that correct behavior is maintained for method __ne__ of class AnsibleVaultEncryptedUnicode.
    This method should return True if the comparison is not equal, False otherwise.
    :return: boolean
    '''
    # Arrange
    class Vault(object):
        def __init__(self, ignore_decryption_errors, password_path, new_path):
            self.ignore_decryption_errors = ignore_decryption_errors
            self.password_path = password_path
            self.new_path = new_path

        def encrypt(self, value, secret):
            return value + str(42)

        def is_encrypted(self, value):
            if value.endswith(str(42)):
                return True
            return False


# Generated at 2022-06-21 00:11:01.095737
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    # Create the testing object
    my_vault = AnsibleVaultEncryptedUnicode(b"my_vault_string")

    # Verify islower method
    assert not my_vault.islower()
