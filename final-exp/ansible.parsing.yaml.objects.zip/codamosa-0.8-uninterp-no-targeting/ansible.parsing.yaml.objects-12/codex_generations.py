

# Generated at 2022-06-21 00:01:25.708759
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    '''
    Unit test for method isspace of class AnsibleVaultEncryptedUnicode
    '''
    # pylint: disable=missing-docstring
    def _test(instr, expect):
        assert (AnsibleVaultEncryptedUnicode(instr).isspace() == expect)
        assert (AnsibleVaultEncryptedUnicode(to_bytes(instr)).isspace() == expect)

    # test of function isspace
    for char in string.whitespace:
        _test(char, True)

    for char in string.printable:
        if char in string.whitespace:
            continue
        _test(char, False)

    for char in string.whitespace:
        _test(char + to_bytes('A'), False)

# Generated at 2022-06-21 00:01:31.691809
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    from ansible import constants as C
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret
    # Initialize vault with test secret
    vault = VaultLib(get_file_vault_secret([C.DEFAULT_VAULT_PASSWORD_FILE]))
    # Initialize AnsibleVaultEncryptedUnicode
    # with ansible vault tag, and ciphertext

# Generated at 2022-06-21 00:01:43.364585
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    import itertools
    from sys import maxunicode
    from string import ascii_letters, ascii_lowercase, ascii_uppercase
    from string import punctuation, whitespace, digits, printable

    # Create a list of all unicode characters
    lst = list(range(0, maxunicode + 1))
    unicode_lst = [to_text(chr(num)) for num in lst]
    printable_lst = list(printable)

    # Test assertion: AnsibleVaultEncryptedUnicode should mimic the behaviour of str
    avu = AnsibleVaultEncryptedUnicode('')

# Generated at 2022-06-21 00:01:46.885452
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    import ansible.parsing.vault as vault

    vault_pass = 'secret'
    cleartext = 'hello world'
    vault = vault.VaultLib(vault_pass)
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(cleartext, vault, vault_pass)

    encrypted.index('world')
    try:
        encrypted.index('Z')
        assert False
    except ValueError:
        pass
    except:
        assert False



# Generated at 2022-06-21 00:01:53.965008
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    '''
    test ansiblevaultencryptedunicode __lt__ method
    '''
    assert AnsibleVaultEncryptedUnicode('abc').__lt__('abc') == False
    assert AnsibleVaultEncryptedUnicode('abc').__lt__('abd') == True
    assert AnsibleVaultEncryptedUnicode('abc').__lt__('abb') == False
    assert AnsibleVaultEncryptedUnicode('abd').__lt__(AVEU_ABC) == False
    assert AnsibleVaultEncryptedUnicode('abb').__lt__(AVEU_ABC) == True



# Generated at 2022-06-21 00:02:06.925699
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    # Create an AnsibleMapping object for testing
    test_object = AnsibleMapping()
    test_object["key1"] = "value1"
    test_object["key2"] = "value2"
    test_object["key3"] = "value3"

    # Make sure that the test object has three keys
    assert test_object.keys() == set(["key1", "key2", "key3"])

    # Make sure that the values for each of the three keys are correct
    assert test_object["key1"] == "value1"
    assert test_object["key2"] == "value2"
    assert test_object["key3"] == "value3"

    # Delete all of the keys in the test object
    del test_object["key1"]
    del test_object["key2"]
    del test_

# Generated at 2022-06-21 00:02:10.802352
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    avu = AnsibleVaultEncryptedUnicode("abc")
    assert not avu.isupper()
    avu = AnsibleVaultEncryptedUnicode("ABC")
    assert avu.isupper()


# Generated at 2022-06-21 00:02:15.448527
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    # test for non vault attribute
    avu = AnsibleVaultEncryptedUnicode('foo', 'bar')
    assert avu.lower() == 'foo'

    # test with vault but not encrypted
    avu.vault = self
    assert avu.lower() == 'foo'
    assert isinstance(avu.lower(), AnsibleUnicode)


# Generated at 2022-06-21 00:02:27.592688
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    from ansible.parsing.vault import VaultLib
    vault_text = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          62323965316266316338623864316331346361623230366231323963636237306633353939313263\n          61633462313438613065343533396663613361353166613161643939306266336536333165303933\n          62346265626361363133313239363530386237656539666162313330323562373835393462346365\n          613238633833\n          "

# Generated at 2022-06-21 00:02:38.025351
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    # Create a AnsibleVaultEncryptedUnicode object
    class DummyVault:
        def __init__(self, password):
            self.password = password
        def is_encrypted(self, string):
            return True
        def decrypt(self, string, obj):
            return string + self.password
        def encrypt(self, string, password):
            return string + password
    password = 'password'
    dummyVault = DummyVault(password)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(
        password, dummyVault, password)
    # Create a mapping object
    mapping = {'key': 'value'}
    # Test that format_map works as expected. Note that in Python 3
    # 'value' and 'valuepassword' are the same string:
    # 'value'

# Generated at 2022-06-21 00:02:57.308720
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    assert AnsibleVaultEncryptedUnicode('abc').count('a') == 1
    assert AnsibleVaultEncryptedUnicode('abc').count('a', 0, 1) == 1
    assert AnsibleVaultEncryptedUnicode('abc').count('a', 0, 2) == 1
    assert AnsibleVaultEncryptedUnicode('abc').count('a', 0, 3) == 1
    assert AnsibleVaultEncryptedUnicode('abc').count('b') == 1
    assert AnsibleVaultEncryptedUnicode('abc').count('b', 0, 2) == 1
    assert AnsibleVaultEncryptedUnicode('abc').count('b', 0, 3) == 1
    assert AnsibleVaultEncryptedUnicode('abc').count('c') == 1
    assert AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:03:00.713826
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    s = AnsibleVaultEncryptedUnicode(u'HELLO')
    assert isinstance(s, AnsibleVaultEncryptedUnicode)
    assert s.capitalize() == 'Hello'
    assert s.capitalize().__class__ == text_type


# Generated at 2022-06-21 00:03:07.953015
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    test_string = 'This is a test string'
    avu = AnsibleVaultEncryptedUnicode(test_string)

    assert avu.endswith('g')
    assert avu.endswith('ing')
    assert avu.endswith('test string')
    assert not avu.endswith('test')
    assert not avu.endswith('test stri')
    assert not avu.endswith('test string ')
    assert not avu.endswith('test string g')


# Generated at 2022-06-21 00:03:13.133118
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    print('test_AnsibleVaultEncryptedUnicode_endswith: start')
    str = AnsibleVaultEncryptedUnicode('test')
    assert str.endswith('st')
    print('test_AnsibleVaultEncryptedUnicode_endswith: pass')

# Generated at 2022-06-21 00:03:16.255495
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    x = AnsibleVaultEncryptedUnicode('aa')
    assert ('aa'.lstrip() == x.lstrip()), "Method lstrip does not work"


# Generated at 2022-06-21 00:03:23.037167
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    from units.mock.vault import VaultLib
    vault = VaultLib('mypassword')
    # First test with the same type for old and new strings
    old = AnsibleVaultEncryptedUnicode.from_plaintext(seq='old', vault=vault, secret=b'mypassword')
    new = AnsibleVaultEncryptedUnicode.from_plaintext(seq='new', vault=vault, secret=b'mypassword')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq='old is not new', vault=vault, secret=b'mypassword')
    avu_replace = avu.replace(old, new)

# Generated at 2022-06-21 00:03:28.817047
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    ''' Test method __hash__ of class AnsibleVaultEncryptedUnicode '''
    print("AnsibleVaultEncryptedUnicode.__hash__()")

    s = AnsibleVaultEncryptedUnicode("hello world")
    assert isinstance(s.__hash__(), int)
    assert s.__hash__() == hash("hello world")


# Generated at 2022-06-21 00:03:39.524699
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    # Data
    t1 = "123"
    value = AnsibleVaultEncryptedUnicode(t1)

    # Expected result
    expected = [t1]

    # Actual result
    actual = value.split()

    # Test
    assert actual == expected, "Split method failed with empty parameter"

    # Expected result
    expected = [t1]

    # Actual result
    actual = value.split(None)

    # Test
    assert actual == expected, "Split method failed with None parameter"

    # Data
    t2 = "test"
    value = AnsibleVaultEncryptedUnicode(t1 + " " + t2)

    # Expected result
    expected = [t1, t2]

    # Actual result
    actual = value.split()

    # Test

# Generated at 2022-06-21 00:03:45.752940
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    avu = AnsibleVaultEncryptedUnicode("")
    assert len(avu) == 0

    avu = AnsibleVaultEncryptedUnicode("a")
    assert len(avu) == 1

    avu = AnsibleVaultEncryptedUnicode("ab")
    assert len(avu) == 2



# Generated at 2022-06-21 00:03:50.174073
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    value = 'foo'
    key = 'bar'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(value, VaultLib(), key)
    assert avu.is_encrypted()


# Generated at 2022-06-21 00:03:59.164361
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    from ansible.parsing.vault import VaultLib
    ciphertext = "hello world"
    vaultPasswordFile = "../../tests/test/test_vault.txt"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(ciphertext, VaultLib(vaultPasswordFile), "test")
    assert avu.index("o") == 4


# Generated at 2022-06-21 00:04:10.121036
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnicode

    # Create an encrypted string
    vault = VaultLib([])
    secret = "test_secret"
    ciphertext = vault.encrypt("test_data", secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    # Test cases
    assert (type(avu) == type(u"") == type(""))
    assert (type(avu) != type(b""))

    # Test not encrypted string
    try:
        assert (avu + "test_data")
        assert (False)
    except vault.AnsibleVaultError:
        assert (True)



# Generated at 2022-06-21 00:04:15.708367
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    a = b'This is ascii str.'
    au = AnsibleVaultEncryptedUnicode(a)
    assert au.isascii() == True
    b = b'This is not ascii \xe8\x96\x87 str.'
    bu = AnsibleVaultEncryptedUnicode(b)
    assert bu.isascii() == False



# Generated at 2022-06-21 00:04:20.411961
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    a = AnsibleVaultEncryptedUnicode("test@test.test")
    assert a.rjust(12) == "   test@test.test"
    assert a.rjust(12, '-') == "---test@test.test"


# Generated at 2022-06-21 00:04:29.420777
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    from unittest import TestCase
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    # This is an invalid ciphertext, but it does not matter for what we want
    # to test

# Generated at 2022-06-21 00:04:40.500866
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib("password")

# Generated at 2022-06-21 00:04:51.865899
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    assert AnsibleVaultEncryptedUnicode('foo') * 3 == 'foofoofoo'
    assert 3 * AnsibleVaultEncryptedUnicode('foo') == 'foofoofoo'
    try:
        AnsibleVaultEncryptedUnicode('foo') * AnsibleVaultEncryptedUnicode('foo')
    except TypeError as e:
        assert to_native(e) == "can't multiply sequence by non-int of type 'AnsibleVaultEncryptedUnicode'"
    else:
        assert False, "Expected TypeError for multiply AnsibleVaultEncryptedUnicode by AnsibleVaultEncryptedUnicode"
    assert AnsibleVaultEncryptedUnicode('foo') * None is None


# Generated at 2022-06-21 00:05:02.398413
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    plaintext = '0123456789'
    ciphertext = b'\xfa\xef\xc3\xd3l\xcc\xb9\x9a:\x0f\x97\x1b\x8f\x1c'
    # ciphertext was generated with Ansible 2.2, vault_id 'test', secret 'test'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vaultlib.VaultLib(['test'], '')
    assert avu.data == plaintext
    assert int(avu) == int(plaintext)

_BasicSafeConstructor = yaml.SafeConstructor.add_constructor
_BasicConstructor = yaml.Constructor.add_constructor


# Generated at 2022-06-21 00:05:09.417818
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    """
    Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

    `AnsibleVaultEncryptedUnicode` class cannot satisfiable the interface of datetime.datetime class
    which also has `__eq__` method.

    The `__eq__` method of `AnsibleVaultEncryptedUnicode` class should return False when the
    instance attribute `vault` equals to None.
    """

    # Create an instance of class AnsibleVaultEncryptedUnicode
    # the instance attribute `vault` is set to None by default
    avu_1 = AnsibleVaultEncryptedUnicode("test")

    # The instance of datetime.datetime class
    dt_1 = datetime.datetime(2013, 10, 30, 13, 30)

    # When the instance attribute `

# Generated at 2022-06-21 00:05:19.731425
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    plaintext = b"""
    456        # integral
    456.789     # floating point
    -456.789     # floating point
    456e+3        # floating point exponential
    -456E3        # floating point exponential
    -456E-3        # floating point exponential
    456e+12        # floating point exponential
    +456     # sign
    -456     # sign
    +456.789     # sign with decimal
    -456.789     # sign with decimal
    -456E3        # sign with exponential
    -45600.0        # garbage
    45 600     # garbage
    """

# Generated at 2022-06-21 00:05:33.976463
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    avu = AnsibleVaultEncryptedUnicode("abc")
    if not sys.version_info[0] == 3:
        assert avu.translate(_idmap3) == "abc"
    else:
        assert avu.translate(_idmap3, _idmap1) == "abc"

if sys.version_info[0] == 3:
    _idmap1 = bytes.maketrans(b'abc', b'xyz')
    _idmap2 = bytes.maketrans(b'abc', b'xyz')
    _idmap3 = bytes.maketrans(b'abc', b'xyz')
else:
    _idmap1 = string.maketrans('abc', 'xyz')

# Generated at 2022-06-21 00:05:40.940844
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    import string
    import unittest

    # tests for AnsibleVaultEncryptedUnicode.rfind(s, sub, start=0, end=sys.maxint)
    class Test_rfind(unittest.TestCase):
        def test_invalid_arg_types(self):
            s = AnsibleVaultEncryptedUnicode("abc")
            self.assertRaises(TypeError, s.rfind)

        def test_not_found(self):
            # not found at start
            s = AnsibleVaultEncryptedUnicode("abc")
            self.assertEqual(s.rfind("d"), -1)
            # not found at end
            self.assertEqual(s.rfind("d"), -1)
            # not found in middle

# Generated at 2022-06-21 00:05:49.982739
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    title_inputs = {
        None: None,
        'a': 'A',
        'a1': 'A1',
        'a1b2c3': 'A1b2c3',
        'a1.b2.c3': 'A1.B2.C3',
    }

    for ansible_unicode_input, expected_ansible_unicode_output in title_inputs.items():
        ansible_unicode_output = AnsibleVaultEncryptedUnicode(ansible_unicode_input).title()
        assert ansible_unicode_output == expected_ansible_unicode_output



# Generated at 2022-06-21 00:05:53.222111
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    ciphertext = 'This is a secret message'
    vault = AnsibleVaultEncryptedUnicode(ciphertext)
    assert vault[:] == ciphertext


# Generated at 2022-06-21 00:05:57.154620
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    u = AnsibleVaultEncryptedUnicode('bar')
    assert u.__add__(AnsibleVaultEncryptedUnicode('foo')) == 'barfoo'


# Generated at 2022-06-21 00:06:02.405122
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    assert AnsibleVaultEncryptedUnicode('password', 'aVault').rfind('ord') == 5
    assert AnsibleVaultEncryptedUnicode('password', 'aVault').rfind('word') == -1
    assert AnsibleVaultEncryptedUnicode('password', 'aVault').rfind('') == 8
    assert AnsibleVaultEncryptedUnicode('password', 'aVault').rfind('pa') == 0
    assert AnsibleVaultEncryptedUnicode('password', 'aVault').rfind('ass') == 3
    assert AnsibleVaultEncryptedUnicode('$$$password$$$', 'aVault').rfind('$$$') == 8
    assert AnsibleVaultEncryptedUnicode('$$$password$$$', 'aVault').rfind('$$') == -1

# Generated at 2022-06-21 00:06:14.068084
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    avu = AnsibleVaultEncryptedUnicode('abcdef')
    assert avu.rpartition('d') == ('abc', 'd', 'ef')
    assert avu.rpartition('x') == ('', '', 'abcdef')

    avu = AnsibleVaultEncryptedUnicode('abcdef')
    avu2 = AnsibleVaultEncryptedUnicode('d')
    assert avu.rpartition(avu2) == ('abc', 'd', 'ef')
    assert avu.rpartition(avu2) == ('abc', 'd', 'ef')
    #returns this on Python 2.6
    #avu.rpartition(avu2) == ('abc', 'd', 'ef')



# Generated at 2022-06-21 00:06:24.423669
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    # Check method split with argument split
    # input
    avu = AnsibleVaultEncryptedUnicode(b'foo bar')
    avu.vault = type('Vault', (object,), {'decrypt': lambda s, ciphertext: ciphertext})
    # output
    assert avu.split(' ') == ['foo', 'bar']

    # Check method split without argument split
    # input
    avu = AnsibleVaultEncryptedUnicode(b'foo bar')
    avu.vault = type('Vault', (object,), {'decrypt': lambda s, ciphertext: ciphertext})
    # output
    assert avu.split() == ['foo', 'bar']



# Generated at 2022-06-21 00:06:33.219618
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # we actually want to test if the data is encrypted, but we don't have a vault to do that
    # so we will just check the type
    plaintext = u'hello'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, None, None)
    # starting at 0 with a length of 1 should be the first char
    assert type(avu[0]) == AnsibleVaultEncryptedUnicode
    # starting at 1 with a length of 2 should be the 2nd, 3rd chars
    assert type(avu[1:3]) == AnsibleVaultEncryptedUnicode


# Generated at 2022-06-21 00:06:41.013357
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    str_list = [u'1234', u'abcde', u'1234abcde', u'-1234', u'+1234']
    ansible_vault_str_list = [AnsibleVaultEncryptedUnicode('1234'), AnsibleVaultEncryptedUnicode('abcde'), AnsibleVaultEncryptedUnicode('1234abcde'), AnsibleVaultEncryptedUnicode('-1234'), AnsibleVaultEncryptedUnicode('+1234')]
    
    for i in range(len(str_list)):
        assert(str_list[i].isdecimal() == ansible_vault_str_list[i].isdecimal())


# Generated at 2022-06-21 00:06:56.101340
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    avu = AnsibleVaultEncryptedUnicode("aaaa")
    assert len(avu) == 4


# Generated at 2022-06-21 00:07:07.961264
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    if sys.version_info < (3, 3):
        return True
    # Test unicode strings
    assert AnsibleVaultEncryptedUnicode('a').isidentifier()
    assert AnsibleVaultEncryptedUnicode('A').isidentifier()
    assert AnsibleVaultEncryptedUnicode('aA').isidentifier()
    assert AnsibleVaultEncryptedUnicode('_').isidentifier()
    assert AnsibleVaultEncryptedUnicode('_foo').isidentifier()
    assert not AnsibleVaultEncryptedUnicode('6').isidentifier()
    assert not AnsibleVaultEncryptedUnicode('%').isidentifier()
    assert AnsibleVaultEncryptedUnicode('a_').isidentifier()

# Generated at 2022-06-21 00:07:11.949511
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    ciphertext = 'something'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    chars = "o"
    result = avu.lstrip(chars)
    assert result == "mething"



# Generated at 2022-06-21 00:07:18.847362
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    vault_password = b'password'
    vault_text = b'Test\x20\nMy\x20\nEncrypted\x20\nFile\x20\n'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(
       vault_text,
       vaultlib.VaultLib(vault_password),
       vault_password
    )
    assert avu.title() == b'Test\x20\nMy\x20\nEncrypted\x20\nFile\x20\n'

# Generated at 2022-06-21 00:07:30.215922
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    test_obj = AnsibleVaultEncryptedUnicode('set_fact:')
    assert test_obj.startswith('set_fact') == True
    assert test_obj.startswith('set_fact:') == True
    assert test_obj.startswith(u'set_fact') == True
    assert test_obj.startswith(u'set_fact:') == True
    assert test_obj.startswith('SET_FACT') == False
    assert test_obj.startswith('SET_FACT:') == False
    assert test_obj.startswith(u'SET_FACT') == False
    assert test_obj.startswith(u'SET_FACT:') == False
    assert test_obj.startswith(test_obj) == True
    assert test_obj.startswith

# Generated at 2022-06-21 00:07:40.045059
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    key = b'123456789012345678901234'
    data = AnsibleVaultEncryptedUnicode.from_plaintext(['foo', 'bar'], AnsibleVaultLib.new(key), key)
    assert data <= ['foo', 'bar']
    assert not data <= ['foo', 'baz']
    assert data <= AnsibleVaultEncryptedUnicode.from_plaintext(['foo', 'bar'], AnsibleVaultLib.new(key), key)
    assert not data <= AnsibleVaultEncryptedUnicode.from_plaintext(['foo', 'baz'], AnsibleVaultLib.new(key), key)
    assert not data <= ['foo', 'baz']

# Generated at 2022-06-21 00:07:48.258815
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    assert(AnsibleVaultEncryptedUnicode("1") >= AnsibleVaultEncryptedUnicode("1") == True)
    assert(AnsibleVaultEncryptedUnicode("1") >= AnsibleVaultEncryptedUnicode("2") == False)
    assert(AnsibleVaultEncryptedUnicode("2") >= AnsibleVaultEncryptedUnicode("1") == True)
    assert(AnsibleVaultEncryptedUnicode("1") >= "1" == True)
    assert(AnsibleVaultEncryptedUnicode("1") >= "2" == False)
    assert("2" >= AnsibleVaultEncryptedUnicode("1") == True)


# Generated at 2022-06-21 00:07:57.622383
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    class FakeVault(object):
        def is_encrypted(self, text):
            return text.startswith('$ANSIBLE_VAULT')
        def decrypt(self, text, obj=None):
            return text
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', FakeVault(), 'secret')
    assert avu + 'bar' == 'foobar'
    assert 'bar' + avu == 'barfoo'
    assert avu + AnsibleVaultEncryptedUnicode.from_plaintext('bar', FakeVault(), 'secret') == 'foobar'


# Generated at 2022-06-21 00:08:04.769844
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('"test0','test', 'test')
    avu.vault = vault
    assert avu.rindex('test') == 0
    assert avu.rindex('t') == 3
    assert avu.rindex('test', 2) == 0
    assert avu.rindex('t', 0, 3) == 2


# Generated at 2022-06-21 00:08:10.094864
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('test')
    text = 'this is a string'
    secret = 'mysecret'
    data = AnsibleVaultEncryptedUnicode.from_plaintext(text, vault, secret)

    if _sys.version_info[0] < 3:
        assert to_native(data) == text
    else:
        assert to_native(data) == text.encode('utf-8')


# Generated at 2022-06-21 00:08:38.949203
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    assert AnsibleVaultEncryptedUnicode(b'test').endswith(
        AnsibleVaultEncryptedUnicode(b"t")) == True
    assert AnsibleVaultEncryptedUnicode(b'test').endswith(
        AnsibleVaultEncryptedUnicode(b"a")) == False
    assert AnsibleVaultEncryptedUnicode(b'test').endswith(b"t") == True
    assert AnsibleVaultEncryptedUnicode(b'test').endswith(b"a") == False
    assert AnsibleVaultEncryptedUnicode(b'test').endswith("t") == True
    assert AnsibleVaultEncryptedUnicode(b'test').endswith("a") == False


# Generated at 2022-06-21 00:08:41.979083
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    aveu = AnsibleVaultEncryptedUnicode(" ").data
    assert ("".join(aveu.translate(None, string.whitespace)) == "")


# Generated at 2022-06-21 00:08:47.841854
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    a = AnsibleSequence()
    a.append(1)
    a.append(2)
    assert a == [1, 2]


if __name__ == '__main__':
    # If run as a program, invoke the demo() function.
    print('running func test')
    test_AnsibleSequence()

# Generated at 2022-06-21 00:08:53.186837
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    import unittest
    class TestMethods(unittest.TestCase):
        def test_method_casefold(self):
            s = AnsibleVaultEncryptedUnicode(b'abcde')
            self.assertEqual(s.casefold(), b'abcde')
    unittest.main()


# Generated at 2022-06-21 00:09:01.869611
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    # string
    f = u"This is a test string for String"
    assert f.count(u"i") == 3
    assert f.count(u" ") == 4
    assert f.count(u"t") == 4
    assert f.count(u"T") == 3
    # unicode
    f = AnsibleVaultEncryptedUnicode(u"This is a test string for String")
    assert f.count(u"i") == 3
    assert f.count(u" ") == 4
    assert f.count(u"t") == 4
    assert f.count(u"T") == 3
    # ansible vault unicode

# Generated at 2022-06-21 00:09:13.486269
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    string1 = AnsibleVaultEncryptedUnicode("abc", "")
    string2 = AnsibleVaultEncryptedUnicode("abc", "")

    assert string1.rsplit("a") == ['', 'bc']
    assert string1.rsplit("b") == ['a', 'c']
    assert string1.rsplit("c") == ['ab', '']
    assert string1.rsplit("d") == ['abc']

    assert string1.rsplit("a", 1) == ['', 'bc']
    assert string1.rsplit("b", 1) == ['a', 'c']
    assert string1.rsplit("c", 1) == ['ab', '']
    assert string1.rsplit("d", 1) == ['abc']


# Generated at 2022-06-21 00:09:25.258075
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:09:35.980752
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    nowarn = []
    avu = AnsibleVaultEncryptedUnicode(ciphertext=u'')
    assert isinstance(avu.__ge__('a'), bool)
    nowarn.append(avu.__ge__('a'))
    avu = AnsibleVaultEncryptedUnicode(ciphertext=u'a')
    assert isinstance(avu.__ge__('a'), bool)
    nowarn.append(avu.__ge__('a'))
    avu = AnsibleVaultEncryptedUnicode(ciphertext=u'a')
    assert isinstance(avu.__ge__(u'a'), bool)
    nowarn.append(avu.__ge__(u'a'))

# Generated at 2022-06-21 00:09:43.751278
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    AVEU = AnsibleVaultEncryptedUnicode
    # Example 1. The following is equivalent to
    # print("Hello " + AVEU("World"))
    # "Hello " (str) + encrypted(str)
    assert AVEU("World").__radd__("Hello ") == "Hello World"

    # Example 2. The following is equivalent to
    # print("Hello " + AVEU("World"))
    # "Hello " (unicode) + encrypted(str)
    assert AVEU("World").__radd__(u"Hello ") == "Hello World"

    # Example 3. The following is equivalent to
    # print("Hello " + AVEU("World"))
    # "Hello " (str) + encrypted(unicode)

# Generated at 2022-06-21 00:09:53.384929
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    sh = '''
    # Test encryption and decryption of string with expandtabs, tabs can be 0..8
    #
    # "$(sep)" is intentionally in the middle of a tab to exercise the encode/decode
    # code to ensure expandtabs works correctly.
    #
    # Passed: $(argv)
    # Tab = $(tab_size)
    # File = $(file)
    # Encrypted = "$(encrypted)"
    # Decrypted = "$(decrypted)"
    #
    # ...
    #
    ############################################################
    '''

    # Remove all tabs to satisfy the python formatter
    sh = sh.expandtabs(8).replace('\t', '')

    # Use a fixed key to make sure we test the exact same string

# Generated at 2022-06-21 00:10:44.040018
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    ansible_vault = AnsibleVaultEncryptedUnicode

    # Test an empty string
    assert(ansible_vault('', vault=test_vault, secret=test_secret).count('') == 1)

    str2 = ansible_vault('', vault=test_vault, secret=test_secret)
    assert(ansible_vault('', vault=test_vault, secret=test_secret).count(str2) == 1)

    # Test normal case
    str2 = ansible_vault('a', vault=test_vault, secret=test_secret)
    assert(ansible_vault('aaaaa', vault=test_vault, secret=test_secret).count(str2) == 5)


# Generated at 2022-06-21 00:10:49.716500
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    assert AnsibleVaultEncryptedUnicode('foo').isalpha(), "'foo'.isalpha()"
    assert AnsibleVaultEncryptedUnicode('123').isalpha(), "'123'.isalpha()"
    assert AnsibleVaultEncryptedUnicode('123 foo').isalpha(), "'123 foo'.isalpha()"


# Generated at 2022-06-21 00:10:55.239157
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    from ansible.parsing.vault import VaultLib
    my_str = u'foo\xb7bar'
    vault = VaultLib('secret')
    encrypted_str = AnsibleVaultEncryptedUnicode.from_plaintext(my_str, vault, 'secret')
    assert(encrypted_str.__unicode__() == u'foo\xb7bar')

# Generated at 2022-06-21 00:11:06.542492
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    import unittest
    from ansible.parsing.vault import VaultLib

    class TestAnsibleVaultEncryptedUnicode___ge__(unittest.TestCase):
        def setUp(self):
            self.va = VaultLib('password')
            self.v1 = AnsibleVaultEncryptedUnicode.from_plaintext('abcdefg', self.va, b'password')
            self.v1.ansible_pos = ('file', 1, 2)
            self.v2 = AnsibleVaultEncryptedUnicode.from_plaintext('abcde', self.va, b'password')
            self.v2.ansible_pos = ('file', 1, 2)
