

# Generated at 2022-06-21 00:01:25.708100
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    vault = VaultLib.VaultLib(None, None, 'password')
    # Test format_map with parameters provided in the map.
    value = AnsibleVaultEncryptedUnicode.from_plaintext('My {} name is {}', vault, None)
    params = {'first': 'first', 'last': 'last'}
    assert value.format_map(params) == 'My first name is last'
    # Test format_map with parameters provided in the map, but missing from the string.
    value = AnsibleVaultEncryptedUnicode.from_plaintext('My {} name is {}', vault, None)
    params = {'first': 'first', 'last': 'last', 'middle': 'middle'}
    try:
        value.format_map(params)
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-21 00:01:27.904840
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    x = AnsibleVaultEncryptedUnicode("test")
    assert(text_type(x * 3) == "testtesttest")


# Test AnsibleVaultEncryptedUnicode.__rmul__(int)

# Generated at 2022-06-21 00:01:39.327378
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:01:44.703972
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    test_string = "string"
    test_TODO_value = "TODO: replace this value with a valid value"
    test_result = "string"
    assert test_string.ljust(10) == test_result
    assert test_string.ljust(10, '0') == test_result



# Generated at 2022-06-21 00:01:51.443852
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    d1 = AnsibleVaultEncryptedUnicode.from_plaintext(u'123', None, None)
    assert d1.isdecimal() == True
    d2 = AnsibleVaultEncryptedUnicode.from_plaintext(u'1a3', None, None)
    assert d2.isdecimal() == False
    d3 = AnsibleVaultEncryptedUnicode.from_plaintext(u'1 3', None, None)
    assert d3.isdecimal() == False

# Generated at 2022-06-21 00:01:53.246217
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    a = AnsibleVaultEncryptedUnicode('')
    b = a.title()
    assert a is b


# Generated at 2022-06-21 00:02:04.391307
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    # Test with a lowercase string
    lowercase_str = "lowercase"
    lowercase_AnsibleVaultEncryptedUnicode = AnsibleVaultEncryptedUnicode(lowercase_str)
    assert lowercase_AnsibleVaultEncryptedUnicode.islower()

    # Test with a uppercase string
    uppercase_str = "UPPERCASE"
    uppercase_AnsibleVaultEncryptedUnicode = AnsibleVaultEncryptedUnicode(uppercase_str)
    assert not uppercase_AnsibleVaultEncryptedUnicode.islower()


# Generated at 2022-06-21 00:02:11.737224
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    f = AnsibleBaseYAMLObject()
    f.ansible_pos = ('test_file_name', 2, 3)
    assert f.ansible_pos == ('test_file_name', 2, 3)

    # verify that setting incorrect value will raise error
    try:
        f.ansible_pos = ('test_file_name', 2)
        raise AssertionError('Should have failed when setting ansible pos with incorrect number of values')
    except AssertionError:
        pass



# Generated at 2022-06-21 00:02:22.360085
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    from ansible.parsing.vault import VaultLib
    test_unicode_str = "arbitraRy text which is unicode"

    vault_password = 'test'
    vault = VaultLib('!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3035626536333662626330373231376438663230356164303238393637346539616362396361610a\n          66353339393032376231616636336165666661316231666430653764313963323965623931610a\n          6235643761646664306539\n          ')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(test_unicode_str, vault, vault_password)
   

# Generated at 2022-06-21 00:02:34.718223
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    # Test 1
    avu = AnsibleVaultEncryptedUnicode('abcd')
    avu.ansible_pos = (None, None, None)
    assert '   abcd' == avu.rjust(6)

    # Test 2
    avu = AnsibleVaultEncryptedUnicode('abcd')
    avu.ansible_pos = (None, None, None)
    assert ' abcd' == avu.rjust(5)

    # Test 3
    avu = AnsibleVaultEncryptedUnicode('abcd')
    avu.ansible_pos = (None, None, None)
    assert 'abcd' == avu.rjust(4)

    # Test 4
    avu = AnsibleVaultEncryptedUnicode('abcd')
    avu.ansible_

# Generated at 2022-06-21 00:02:53.422909
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    a = AnsibleVaultEncryptedUnicode.from_plaintext('world', vault=None, secret=None)
    assert 'hello' == 'hello world'.endswith(a)
    assert 'hello' != 'hello world'.endswith(a, 0, 6)



# Generated at 2022-06-21 00:03:02.055215
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    class FakeVault:
        def is_encrypted(self, data):
            return True

        def encrypt(self, data, secret):
            return data.upper().encode('utf-8')

        def decrypt(self, data, obj=None):
            return data.decode('utf-8')

    vault = FakeVault()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault=vault, secret=None)
    assert not avu.isupper()

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('HELLO', vault=vault, secret=None)
    assert avu.isupper()


# Generated at 2022-06-21 00:03:09.360103
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    container = AnsibleSequence()

    # Check that the container is a list
    assert type(container) == list, 'Type of container is not list'
    assert type(container) != dict, 'Type of container is dict'
    assert type(container) != text_type, 'Type of container is str'

    # Check that the container is an AnsibleSequence
    assert isinstance(container, AnsibleSequence), 'Container is not an AnsibleSequence'
    assert isinstance(container, list), 'Container is not a list'
    assert not isinstance(container, dict), 'Container is a dict'
    assert not isinstance(container, text_type), 'Container is a str'

    # Check that the container can contain a tuple
    container.append((1, 2))

# Generated at 2022-06-21 00:03:12.782510
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    s = AnsibleVaultEncryptedUnicode(b'abCD eFghi JKlmno')
    assert s.swapcase() == u'ABcd EfGHI jkLMNO'



# Generated at 2022-06-21 00:03:17.813670
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    from ansible.plugins.vault import VaultLib

    secret = 'secret'
    vault = VaultLib(secret)
    obj = 'data'

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(obj, vault, secret)

    assert repr(avu) == repr(obj)


# Generated at 2022-06-21 00:03:22.768980
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    """
        Test for method __complex__ of class AnsibleVaultEncryptedUnicode
    """
    assert AnsibleVaultEncryptedUnicode.__complex__() is None, "AnsibleVaultEncryptedUnicode.__complex__(): Test case failed"


# Generated at 2022-06-21 00:03:34.556032
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    import tempfile
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import _MISSING_PASSWORD_ERROR

    # create temp files
    tmp_fd, tmp_fn = tempfile.mkstemp()
    with open(tmp_fn, 'w') as f:
        f.write('ansible')

    # create vault instance and lock it
    vault = VaultLib()
    vault.lock()

    # encrypt tmp_fd with password 'ansible'
    vault.read_vault_file(tmp_fn, 'ansible')
    plaintext = 'PASSWORD_ANSIBLE'
    encrypted_text = vault.encrypt(plaintext, secret='ansible')

    # create AnsibleVaultEncryptedUnicode with vault, encrypted_text and 'ansible'

# Generated at 2022-06-21 00:03:39.886558
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    from ansible.parsing.vault import VaultLib
    plaintext = "password"
    vault = VaultLib('test', load=False)
    password = '123'
    encrypted_password = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, password)
    assert encrypted_password.data == "password"
    assert encrypted_password >= plaintext
    assert not encrypted_password >= "passwort"


# Generated at 2022-06-21 00:03:52.246021
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    from ansible import constants as C
    from ansible.parsing.vault import VaultLib
    p = VaultLib(C.DEFAULT_VAULT_PASSWORD_FILE)

    plaintext = '1234'
    ciphertext = 'BAMAbXZhOjEyMzQ='
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = p

    assert not avu.isalpha()

    plaintext = 'abc'
    ciphertext = 'BAMAbXZhOmFiYw=='
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = p
    assert avu.isalpha()

    plaintext = 'abc1'

# Generated at 2022-06-21 00:03:59.962727
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    class Vault(object):
        def __init__(self, password=None):
            self.password = password

        def decrypt(self, dat, obj=None):
            if dat == "encrypted":
                return 'encrypted'
            return dat

    vault = Vault()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('encrypted', vault, 'password')
    avu.vault = vault
    assert avu.endswith('ted')



# Generated at 2022-06-21 00:04:17.159948
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    avu1 = AnsibleVaultEncryptedUnicode('hello world')
    assert avu1.isprintable()
    avu2 = AnsibleVaultEncryptedUnicode('\t\n\r\x0b\x0c')
    assert not avu2.isprintable()
    avu3 = AnsibleVaultEncryptedUnicode('\x00')
    assert not avu3.isprintable()
    avu4 = AnsibleVaultEncryptedUnicode('\x07')
    assert not avu4.isprintable()
    avu5 = AnsibleVaultEncryptedUnicode('\x1f')
    assert not avu5.isprintable()
    avu6 = AnsibleVaultEncryptedUnicode('\x7f')

# Generated at 2022-06-21 00:04:22.337999
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    assert isinstance(1 + AnsibleVaultEncryptedUnicode(1), int)
    assert isinstance(1.0 + AnsibleVaultEncryptedUnicode(1), float)
    assert isinstance(1j + AnsibleVaultEncryptedUnicode(1), complex)



# Generated at 2022-06-21 00:04:30.752798
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    '''
    Test method casefold of class AnsibleVaultEncryptedUnicode
    '''

    def c_casefold(o):
        '''
        Convenience function which provides the casefolding of a string
        '''
        return o.casefold()

    # Testing rare characters
    assert c_casefold(AnsibleVaultEncryptedUnicode(u'\u00C0')) == u'\u00e0'
    assert c_casefold(AnsibleVaultEncryptedUnicode(u'\u00C1')) == u'\u00e1'
    assert c_casefold(AnsibleVaultEncryptedUnicode(u'\u00C2')) == u'\u00e2'

# Generated at 2022-06-21 00:04:36.781243
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    import ansible.plugins.vault.VaultLib as VaultLib
    vault = VaultLib.VaultLib('hunter2')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('testing', vault, 'hunter2')
    assert avu.rstrip() == 'testing'



# Generated at 2022-06-21 00:04:45.698792
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    avu = AnsibleVaultEncryptedUnicode('foo', vault=None)
    assert 'f' in avu
    assert 'z' not in avu
    assert 'FOO' not in avu
    assert AnsibleVaultEncryptedUnicode('FOO', vault=None) not in avu

    # Try contain on an encrypted object, this should fail
    avu = AnsibleVaultEncryptedUnicode('U2FsdGVkX18', vault=None)
    assert 'z' not in avu
    assert 'f' not in avu
    assert 'U' not in avu


# Generated at 2022-06-21 00:04:48.596566
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    assert "%s" % AnsibleVaultEncryptedUnicode.from_plaintext(u'FOO', None, None) == u'FOO'



# Generated at 2022-06-21 00:04:59.354244
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    '''Test if AnsibleVaultEncryptedUnicode objects are correctly handled by method isprintable of class AnsibleVaultEncryptedUnicode'''
    nonprintable = '\x00'
    printable = '\x01'
    # Following AssertionError is acceptable ...
    # AssertionError: ... is not a valid string
    avl = AnsibleVaultEncryptedUnicode(nonprintable)
    assert not avl.isprintable
    avl = AnsibleVaultEncryptedUnicode(printable)
    assert avl.isprintable

if __name__ == '__main__':
    test_AnsibleVaultEncryptedUnicode_isprintable()
    sys.exit(0)

# Generated at 2022-06-21 00:05:02.762651
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    avu = AnsibleVaultEncryptedUnicode('\t')

    assert avu.isspace()==True

    avu = AnsibleVaultEncryptedUnicode('a')
    assert avu.isspace()==False



# Generated at 2022-06-21 00:05:08.034501
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    # Given
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello world', vault, 'password')
    avu.ansible_pos = ('', 1, 1)

    # When
    result = avu.strip()

    # Then
    assert result == 'hello world'



# Generated at 2022-06-21 00:05:18.873805
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    # Create an undecrypted AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;name\n8b83828b9f89b08bcb9f9b8e8b8d998b8bb68b8b8b8c8e83828d8b8b958b8a8b\n;blah blah blah')
    # Copy its internal ciphertext and test it
    #
    # This is the same string you'd get in the output of 'ansible-vault view'

# Generated at 2022-06-21 00:05:37.395262
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    from ansible_vault import VaultLib
    from random import random

    # NOTE: Initialise the vault with a random set of bytes
    vault = VaultLib(
        [random() for i in range(0, VaultLib.BLOCK_SIZE)]
    )

    # NOTE: Create an encrypted string with the vault above
    encrypted_string = to_text(vault.encrypt(b'123.456'))

    # NOTE: Create an AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode(encrypted_string)
    # NOTE: Set the attribute vault
    avu.vault = vault

    # NOTE: Test if AnsibleVaultEncryptedUnicode object can be converted to a float
    assert(float(avu) == 123.456)

# Generated at 2022-06-21 00:05:38.735270
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    assert AnsibleVaultEncryptedUnicode('abc').__add__('def') == 'abcdef'



# Generated at 2022-06-21 00:05:49.906135
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    # Test for spaces
    testString1 = AnsibleVaultEncryptedUnicode(' ')
    assert testString1.isspace()
    testString2 = AnsibleVaultEncryptedUnicode('hello world')
    assert not testString2.isspace()
    # Test for new line
    testString3 = AnsibleVaultEncryptedUnicode('\n')
    assert testString3.isspace()
    testString4 = AnsibleVaultEncryptedUnicode('hello\nworld')
    assert not testString4.isspace()
    # Test for tab
    testString5 = AnsibleVaultEncryptedUnicode('\t')
    assert testString5.isspace()
    testString6 = AnsibleVaultEncryptedUnicode('hello\tworld')
    assert not testString6.isspace()


# Generated at 2022-06-21 00:06:01.134384
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    vault_data = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256\n3637663036323537353733663038346635616365323532356537363735393334303639656166633139\n3261306534376539336638633964393630326635303839626338616665623364663961636138323631\n393731383835363466376435')
    non_vault_data = AnsibleUnicode(u'data')

    assert(vault_data.isidentifier() == False)
    assert(non_vault_data.isidentifier() == False)



# Generated at 2022-06-21 00:06:11.644120
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    from ansible.parsing.vault import VaultLib
    import unittest

    class TestAnsibleVaultEncryptedUnicodeUpper(unittest.TestCase):
        def setUp(self):
            self.vault = VaultLib('ansible')
            self.secret = 'ansible'
            self.plaintext = 'ansible'
            self.avu = AnsibleVaultEncryptedUnicode.from_plaintext(self.plaintext, self.vault, self.secret)
            self.avu.vault = self.vault

        def test_upper(self):
            self.assertEqual(self.avu.upper(), 'ANSIBLE')

    unittest.main()

# Generated at 2022-06-21 00:06:19.632317
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    # Test with non-encrypted input
    data = AnsibleVaultEncryptedUnicode('aB3')
    assert data.isalnum()
    data = AnsibleVaultEncryptedUnicode('abc')
    assert data.isalnum()
    data = AnsibleVaultEncryptedUnicode('123')
    assert data.isalnum()
    data = AnsibleVaultEncryptedUnicode('a B 3')
    assert not data.isalnum()
    data = AnsibleVaultEncryptedUnicode('\n')
    assert not data.isalnum()
    data = AnsibleVaultEncryptedUnicode(' ')
    assert not data.isalnum()

    # Test with encrypted input

# Generated at 2022-06-21 00:06:25.030292
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    avueu = AnsibleVaultEncryptedUnicode('tHis')
    assert avueu.title() == u'This'
    avueu = AnsibleVaultEncryptedUnicode('tHis-tHat')
    assert avueu.title() == u'This-That'


# Generated at 2022-06-21 00:06:35.632188
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_password = 'test'
    text = to_text("abcde: !vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          613238616662343965303531633639623166393064646566356438626439393661613961383138\n          643963646162636537306130396638646361383639626439373932613866653364653934643862\n          38613338316639643036\n        key: value\n")
    vault = VaultLib([vault_password])

# Generated at 2022-06-21 00:06:45.855099
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    class FakeVault(object):
        def decrypt(self, ciphertext, obj=None):
            return b'Dogs rule!'

        def encrypt(self, plaintext, secret):
            return b'Dogs rule!'

        def is_encrypted(self, data):
            return True
    fake_vault = FakeVault()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('Dogs rule!', fake_vault, 'ansible')
    # Should have been encrypted
    assert avu.is_encrypted()
    # Should be uppercase
    assert avu.isupper()


#
# The AnsibleDumper class is adapted from ruamel.yaml
# This class is used to create the custom YAML objects that Ansible uses
#
# Copyright (c) 2013-2015 by the author(s

# Generated at 2022-06-21 00:06:47.365266
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    try:
        AnsibleBaseYAMLObject()
    except NotImplementedError:
        return True
    raise Exception('test_AnsibleBaseYAMLObject failed')



# Generated at 2022-06-21 00:07:03.688967
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    '''Test the method rstrip of the class AnsibleVaultEncryptedUnicode'''
    
    assert AnsibleVaultEncryptedUnicode.rstrip('abcdef', 'def') == 'abc'
    assert AnsibleVaultEncryptedUnicode.rstrip('abcdef', 'cde') == 'abf'
    assert AnsibleVaultEncryptedUnicode.rstrip('abcdef', 'abc') == 'def'
    

# Generated at 2022-06-21 00:07:06.280299
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert str(avu) == 'foo'


# Generated at 2022-06-21 00:07:17.204903
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    import vault

    key = vault.VaultLib.generate_key()
    vault_obj = vault.VaultLib(key)
    find_str = 'see'

    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext('do you see my duck?', vault_obj, 'password')
    encrypted_string.vault = vault_obj
    assert encrypted_string.__repr__() == "u'gAAAAABAEQ1T7MbFoXuT7Z_DsCLsHfO7YSYgIdDcnVubyb2H8uV7l-X9TgT7Tj6Mq3V0E_2SjKeVMAidrr6i8U6R-0X0f4PA=='"
    assert find_str in encrypted_string.__

# Generated at 2022-06-21 00:07:22.254063
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    from .vaultlib import VaultLib
    string = "AnsibleVaultEncryptedUnicode"
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(string)
    ansible_vault_encrypted_unicode.vault = VaultLib([])
    assert ansible_vault_encrypted_unicode.title() == "Ansiblevaultencryptedunicode"
    assert ansible_vault_encrypted_unicode.title().data == string.title()


# Generated at 2022-06-21 00:07:33.862597
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('ansible')
    secret = 'ansible'
    plaintext = 'test_AnsibleVaultEncryptedUnicode_center'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    # Test for center
    s = avu.center(1)
    assert s == 't'

    s = avu.center(1, 'x')
    assert s == 't'

    s = avu.center(2)
    assert s == ' t'

    s = avu.center(2, 'x')
    assert s == 'xt'

    s = avu.center(3)
    assert s

# Generated at 2022-06-21 00:07:44.468394
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    # Setup
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n63313161343131626265376430343130663736386336663435626362323462653337366632613366\n34356630343164303964386136303534373335626632333733386563613834663937326663353133\n63633732663339303636313163373430636236643439396435663839\n'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    # Exercise
    # Verify
    try:
        repr(avu)
    except Exception:
        raise AssertionError("Repr should not raise exception")



# Generated at 2022-06-21 00:07:51.111019
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    avu = AnsibleVaultEncryptedUnicode('!vault |$ANSIBLE_VAULT;1.1;AES256\n33313665663036343865656632333333383765343065363338613461323938653434613561333139613336\n37373536393933373830616464666666373232653439323431646338613932626135656438383264326533\n36363435613364346466653564663532366330626138313137346433616237643662393936343632626163\n39306562366562346132393265\n')
    assert hash(avu) == hash(avu.data)


# Generated at 2022-06-21 00:08:03.401172
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():

    # Test method count with three parameters
    assert ("abcabcabc".count("a") == 3)
    assert ("abcabcabc".count("b") == 3)
    assert ("abcabcabc".count("c") == 3)
    assert ("abcabcabc".count("") == 10)
    assert ("abcabcabc".count("e") == 0)
    assert ("abcabcabc".count("a", 0, 5) == 2)
    assert ("abcabcabc".count("a", -1, 0) == 0)
    assert ("abcabcabc".count("abc", 0, 10) == 3)
    assert ("abcabcabc".count("abc", 0, 20) == 3)
    assert ("abcabcabc".count("abc", 0, 30) == 3)
    assert ("abcabcabc".count("abc", 0, -1) == 2)


# Generated at 2022-06-21 00:08:05.371755
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    avu = AnsibleVaultEncryptedUnicode('first line\nsecond line\n')
    assert(['first line', 'second line', ''] == avu.splitlines())


# Generated at 2022-06-21 00:08:12.485764
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    av = AnsibleVaultEncryptedUnicode(ciphertext=b'abc')
    assert('abc' == av.strip())
    assert(isinstance(av.strip(), to_text('').__class__))
    av = AnsibleVaultEncryptedUnicode(ciphertext=b'   abc   ')
    assert('abc' == av.strip())
    av = AnsibleVaultEncryptedUnicode(ciphertext=b'a abc a')
    assert('a abc a' == av.strip())
    assert('abca' == av.strip('a'))
    assert('abc ' == av.rstrip('a'))
    assert(' abc' == av.lstrip('a'))
    assert('c ' == av.strip('aAbBc'))

# Generated at 2022-06-21 00:08:31.575317
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    avu_list = list()
    for index in range(4):
        avu_list.append(AnsibleVaultEncryptedUnicode('%d' % index))
    for index in range(4):
        avu_list.append(AnsibleVaultEncryptedUnicode('%d' % (index%3)))
    for index in range(4):
        avu_list.append(AnsibleVaultEncryptedUnicode('%d' % (index%2)))
# AttributeError: 'AnsibleVaultEncryptedUnicode' object has no attribute 'vault'.
#    joined = AnsibleVaultEncryptedUnicode.join(avu_list)
# TypeError: descriptor 'join' for 'AnsibleVaultEncryptedUnicode' objects doesn't apply to a 'Ansible

# Generated at 2022-06-21 00:08:39.159946
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    '''
    Test that calling str() on a AnsibleVaultEncryptedUnicode object
    raises an exception
    '''
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('TEST', None, None)
    with pytest.raises(AnsibleVaultError):
        # raise AnsibleVaultError('BUG: vault object not set on AnsibleVaultEncryptedUnicode, cannot decrypt')
        str(avu)


# Generated at 2022-06-21 00:08:51.084805
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    vault_password = 'test_AnsibleVaultEncryptedUnicode'
    vault = vaultlib('password', vault_password)

    # Test constructor with string, unicode, and non-string input
    u_string = AnsibleVaultEncryptedUnicode.from_plaintext(b'encrypted unicode', vault, vault_password)
    u_unicode = AnsibleVaultEncryptedUnicode.from_plaintext('encrypted unicode', vault, vault_password)
    u_non_string = AnsibleVaultEncryptedUnicode.from_plaintext(5, vault, vault_password)

    assert(u_string.data == 'encrypted unicode')
    assert(u_unicode.data == 'encrypted unicode')
    assert(u_non_string.data == '5')

    # Test that constructor with invalid vault

# Generated at 2022-06-21 00:08:59.614082
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    class VaultDummyClass(object):
        def decrypt(self, data, obj, **kwargs):
            ''' dummy decryption method '''
            return to_text(data)

        def is_encrypted(self, ciphertext):
            ''' dummy is_encrypted method '''
            return True

    vault = VaultDummyClass()
    secret = None
    plaintext = 'abc'
    ciphertext = b'abc'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    avu._ciphertext = ciphertext
    avu.vault = vault
    assert len(avu) == 3


# Generated at 2022-06-21 00:09:11.304195
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    from ansible.module_utils.basic import AnsibleModule, AnsibleVault, Bytes
    from ansible.parsing.vault import VaultLib, VaultSecret
    import re

    vault = VaultLib(VaultSecret('test'))
    data = vault.encrypt(to_text(b'abc'), 'test')
    avue = AnsibleVaultEncryptedUnicode(data)
    avue.vault = vault
    assert re.match(r'^!vault \|[0-9A-Za-z+/=]{44}$', to_text(avue))
    assert to_text(avue.swapcase()) == to_text(vault.encrypt(to_text(b'ABC'), 'test'))



# Generated at 2022-06-21 00:09:18.346482
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    vaultpass = 'test'
    ciphertext = 'test'
    vault = vaultlib.VaultLib(vaultpass)
    avu_evaluated = AnsibleVaultEncryptedUnicode(ciphertext).upper()
    avu_unevaluated = AnsibleVaultEncryptedUnicode(ciphertext)
    avu_unevaluated.vault = vault
    avu_unevaluated = avu_unevaluated.upper()
    assert avu_evaluated == avu_unevaluated



# Generated at 2022-06-21 00:09:21.468210
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    # Test case for invalid type of variable
    test = None
    try:
        AnsibleVaultEncryptedUnicode("bar") + test
    except TypeError:
        pass
    else:
        assert False, "AnsibleVaultEncryptedUnicode should raise TypeError"

    assert "foo" + AnsibleVaultEncryptedUnicode("bar") == "foobar"



# Generated at 2022-06-21 00:09:26.613330
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    # We never hash decrypted data, only ciphertext.
    # This is not an actual test, we do not expect __hash__ to work correctly.
    # This is to ensure doctest will not break after change in the code.
    k, v = 'test', 'test2'

    # Using a hashmap to demonstrate that AnsibleVaultEncryptedUnicode.__hash__ is not working.
    d = {}
    d[k] = v

    # Changing value for key 'test'
    v = v.upper()

    # Printing the value for key 'test'
    print(d[k])



# Generated at 2022-06-21 00:09:32.151053
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    def _test(test):
        assert test.islower() == test.data.islower()

    _test(AnsibleVaultEncryptedUnicode(""))
    _test(AnsibleVaultEncryptedUnicode("123"))
    _test(AnsibleVaultEncryptedUnicode("abc"))
    _test(AnsibleVaultEncryptedUnicode("ABC"))



# Generated at 2022-06-21 00:09:42.078769
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:10:32.109735
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    msg = AnsibleVaultEncryptedUnicode('secret')
    if b'foo' in msg:
        raise AssertionError("b'foo' should not be in AnsibleVaultEncryptedUnicode object 'secret'")
    if 'foo' in msg:
        raise AssertionError("'foo' should not be in AnsibleVaultEncryptedUnicode object 'secret'")
    if b'sec' in msg:
        raise AssertionError("b'sec' should not be in AnsibleVaultEncryptedUnicode object 'secret'")
    if 'sec' in msg:
        raise AssertionError("'sec' should not be in AnsibleVaultEncryptedUnicode object 'secret'")

# Generated at 2022-06-21 00:10:35.419368
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    input = u'\u043f\u0440\u0438\u0432\u0435\u0442'  # Russian
    assert AnsibleUnicode(input).data == u'\u043f\u0440\u0438\u0432\u0435\u0442'


# Generated at 2022-06-21 00:10:45.423055
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    # The case foldings in the following list are taken from Unicode Standard Annex #15
    # http://www.unicode.org/reports/tr15/tr15-32.html
    u = '\u0041\u0130\u00df\u0300\u0306\u1e68\u3099\u309a\ufb00'
    r = 'a\u0069\u00df\u03b2\u03b2\u1e69\u1e9b\u1e9b\u0066\u0066\u0069'
    assert AnsibleVaultEncryptedUnicode(u).casefold() == r



# Generated at 2022-06-21 00:10:55.628006
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:11:04.448887
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test password')

    plaintext = 'foo bar'
    new_plaintext = 'bar foo'
    encrypted_text = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, 'test password')
    assert(encrypted_text.replace('foo', 'bar').data == new_plaintext)
    assert(encrypted_text.replace('bar', 'foo').data == plaintext)
    assert(encrypted_text.replace(plaintext, new_plaintext).data == new_plaintext)