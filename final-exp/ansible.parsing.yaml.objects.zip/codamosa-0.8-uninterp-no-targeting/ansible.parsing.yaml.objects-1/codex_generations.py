

# Generated at 2022-06-21 00:01:19.135876
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    avu = AnsibleVaultEncryptedUnicode(u'')
    avu.data = u'123'
    result = avu.zfill(5)
    assert result == u'00123'


# Generated at 2022-06-21 00:01:26.029418
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    assert AnsibleVaultEncryptedUnicode(' ').isspace()
    assert AnsibleVaultEncryptedUnicode('\t').isspace()
    assert AnsibleVaultEncryptedUnicode('\n').isspace()
    assert AnsibleVaultEncryptedUnicode('\r').isspace()
    assert AnsibleVaultEncryptedUnicode('\v').isspace()
    assert AnsibleVaultEncryptedUnicode('\f').isspace()
    assert not AnsibleVaultEncryptedUnicode('a').isspace()


# Generated at 2022-06-21 00:01:31.966576
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:01:36.319633
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    """
    Test method __contains__ of class AnsibleVaultEncryptedUnicode
    """
    avu = AnsibleVaultEncryptedUnicode("testing123")
    assert 't' in avu
    assert 'testing' in avu
    assert '123' in avu
    assert '4' not in avu
    assert 'testing1234' not in avu



# Generated at 2022-06-21 00:01:43.478427
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    a = 'abc'
    b = AnsibleVaultEncryptedUnicode.from_plaintext(a, None, None)
    assert b.isalnum()
    assert b.isalnum() == a.isalnum()
    assert to_text(b) == 'abc'
    assert text_type(b) == 'abc'
    assert to_bytes(b) == b'abc'
    assert bytes(b) == b'abc'


# Generated at 2022-06-21 00:01:53.394956
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    # Create an AnsibleVaultEncryptedUnicode from a str
    a = AnsibleVaultEncryptedUnicode("abc")
    assert a.isalpha() == True
    # Create an AnsibleVaultEncryptedUnicode from a unicode
    b = AnsibleVaultEncryptedUnicode(u"abc")
    assert b.isalpha() == True
    # Create an AnsibleVaultEncryptedUnicode from a long str
    a = AnsibleVaultEncryptedUnicode("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
    assert a.isalpha() == True
    # Create an AnsibleVaultEncryptedUnicode from a long unicode

# Generated at 2022-06-21 00:02:02.417663
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    '''Test isspace function of AnsibleVaultEncryptedUnicode class'''

    # unencrypted string
    u = u'\n\n'
    r = AnsibleVaultEncryptedUnicode.from_plaintext(u, None, None)
    assert r.isspace()

    # encrypted string
    u = u'\n\n'
    r = AnsibleVaultEncryptedUnicode.from_plaintext(u, None, None)
    assert r.isspace()


# Generated at 2022-06-21 00:02:06.106893
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    avu = AnsibleVaultEncryptedUnicode('abcVal')
    assert(text_type('Val') in avu)

# end of class AnsibleVaultEncryptedUnicode



# Generated at 2022-06-21 00:02:13.986969
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    from ansible.vault.vault import VaultLib

    vault = VaultLib(password='password')

    plaintext = 'the quick brown fox jumps over the lazy dog'
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, 'secret')

    assert len(encrypted.rjust(50)) == 50
    assert len(encrypted.rjust(50, '-')) == 50
    assert encrypted.rjust(50).endswith(plaintext)
    assert encrypted.rjust(50, '-').endswith(plaintext)

# Generated at 2022-06-21 00:02:19.293404
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib('test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, '123')
    assert(len(avu) == len('test'))



# Generated at 2022-06-21 00:02:37.508990
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    assert AnsibleVaultEncryptedUnicode('  abc  ').rstrip() == '  abc'
    assert AnsibleVaultEncryptedUnicode('abc').rstrip() == 'abc'
    assert AnsibleVaultEncryptedUnicode('  ').rstrip() == ''
    avu = AnsibleVaultEncryptedUnicode('  abc  ')
    avu.data = '  abc  '
    assert avu.rstrip() == '  abc'
    avu.data = 'abc'
    assert avu.rstrip() == 'abc'
    avu.data = '  '
    assert avu.rstrip() == ''


# Generated at 2022-06-21 00:02:47.188734
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    from ansible.parsing.vault import VaultLib

    vault_secret = 'password'
    vault = VaultLib([])
    vault.load_vault_id('/etc/ansible/vault_password.txt')
    vault.encrypt_bytes(b'This is a test string.', vault_secret)

    assert AnsibleVaultEncryptedUnicode.from_plaintext(b'This is a test string.', vault, vault_secret).lower()
    assert AnsibleVaultEncryptedUnicode.from_plaintext(b'This is a test string.', vault, vault_secret).lower().lower()


# Generated at 2022-06-21 00:02:54.510113
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # There's a known issue in Python < 2.7.9, 2.6.9, 3.2.6, 3.3.6 and 3.4.0 that
    # creates an infinite recursion when converting a bytestring to unicode
    # when using the __getslice__ method.
    # For more info: https://bugs.python.org/issue16533
    av = AnsibleVaultEncryptedUnicode(u'abc')
    av[0:1]



# Generated at 2022-06-21 00:02:59.219058
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    # test with a unicode object
    cleartext_u = u'\xc3\xb1'
    av_u = AnsibleVaultEncryptedUnicode(cleartext_u.encode('utf-8'), 'cleartext_u')
    # unicode objects are encoded with 'utf-8' by default
    assert cleartext_u.encode() == av_u.encode()
    assert cleartext_u.encode('utf-8') == av_u.encode('utf-8')
    assert cleartext_u.encode('latin-1') == av_u.encode('latin-1')
    # 'strict' is the default UnicodeEncodeError handler for unicode objects

# Generated at 2022-06-21 00:03:01.511731
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    u = AnsibleVaultEncryptedUnicode(b'AAAAAA')
    print('u = {}'.format(u))
    assert u.casefold() == 'aaaaaa'


# Generated at 2022-06-21 00:03:02.504128
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    a = AnsibleMapping()
    assert isinstance(a, dict)
    assert isinstance(a, AnsibleMapping)


# Generated at 2022-06-21 00:03:07.334059
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    avu = AnsibleVaultEncryptedUnicode('foo')
    import unittest
    class MyTestCase(unittest.TestCase):
        def test_isascii(self):
            self.assertEqual(avu.isascii(), True)
    suite = unittest.TestLoader().loadTestsFromTestCase(MyTestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-21 00:03:18.689265
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    if _sys.version_info[0] > 2:
        return
    yaml_text = "vault_test: !vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  39663137666537646636333166633138643837346339353365643738656361626565323934363366\n  393461363665666661353637386233643737323963323139373534303136326662326361306461630a\n  3265353163306531643062396239303864316335306538666536346638333339633162353636306465\n  393561"
    yaml_obj = yaml.load(yaml_text)
    v_obj = yaml_

# Generated at 2022-06-21 00:03:24.529990
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    v = AnsibleVaultEncryptedUnicode('foo,bar,baz')
    assert v.split(',') == ['foo', 'bar', 'baz']
    assert v.split(',', 1) == ['foo', 'bar,baz']
    assert v.split(',', 1, 2) == ['foo', 'bar']


# Generated at 2022-06-21 00:03:36.212444
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:03:55.821061
# Unit test for method partition of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:04:05.429094
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    a = AnsibleVaultEncryptedUnicode("foo")
    assert a[:] == "foo"
    assert a[:-1] == "fo"
    assert a[:1] == "f"
    assert a[1:] == "oo"
    assert a[-1:] == "o"
    assert a[-1:5] == "o"
    assert a[-5:-1] == "fo"
    assert a[-5:-2] == "f"

    b = AnsibleVaultEncryptedUnicode("Ansible Vault Encrypted")
    assert b[4:12] == "Vault "
    assert b[4:-5] == "Vault Encrypt"
    assert b[:10] == "Ansible V"
    assert b[-5:] == "ecrypt"

# Generated at 2022-06-21 00:04:09.485772
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    avu = AnsibleVaultEncryptedUnicode(ciphertext=b'CIPHERTEXT')
    avu.vault = VaultLib('PASSWORD')
    assert repr(avu) == "u'PLAINTEXT'"


# Generated at 2022-06-21 00:04:21.224920
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    import unittest as ut

    # Create a vault object, secret 42
    va_factory = vault.VaultLib
    class StubVault(vault.VaultLib):
        '''
        A stub object that mocks vault.VaultLib.is_encrypted()
        '''
        def __init__(self, secret):
            vault.VaultLib.__init__(self, secret)
        def is_encrypted(self, ciphertext):
            '''
            Override VaultLib.is_encrypted() to always return True
            '''
            return True
    va_factory = StubVault

    # Create a AnsibleVaultEncryptedUnicode object with a stub vault
    secret = b'42'
    vault = va_factory(secret)
    ciphertext = u'foo bar baz'
    avu

# Generated at 2022-06-21 00:04:29.279253
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    ANSIBLE_VAULT_TEST_ENV = r'ANSIBLE_VAULT_TEST'
    vault_password = r'vault_password'

# Generated at 2022-06-21 00:04:40.415509
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    t = AnsibleVaultEncryptedUnicode(u'pokémon')
    assert t.rstrip(u'n') == u'pokémo'
    assert t.rstrip(u'o') == u'pokém'
    assert t.rstrip(u'n') != u'pokém'
    assert t.rstrip(u'm') == u'poké'
    assert t.rstrip(u'p') == u'oké'
    assert t.rstrip(u'poké') == u''
    assert t.rstrip(u'pokémon') == u''
    assert t.rstrip(u'') == u'pokémon'
    assert t.rstrip(u'n') != u'pokém'
    assert t.rstrip(u'o') != u'pokém'

# Generated at 2022-06-21 00:04:53.444927
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    clear_text = u"""
# This is an example of valid YAML that can be stored in the Ansible Vault
---
# First example password
password1:
  description: "This is a sample password"
  value: "This is very secret"

# Second example password
password2:
  description: "This is another sample password"
  value: "This is another secret"
"""
    print("Testing AnsibleVaultEncryptedUnicode.isupper() method")
    print("Original YAML: %s" % clear_text)
    vault = VaultLib([])
    encrypted_text = vault

# Generated at 2022-06-21 00:04:58.764127
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    # py2 and py3 are different in their handling of the 'format' method
    # e.g. py2.7 calls '__format__' while py3.6 calls '__mod__'
    # so the unit test on this is different
    avu = AnsibleVaultEncryptedUnicode('abc')
    if sys.version_info < (3,):
        if '__format__' in dir(avu):
            formatted = avu.__format__('s')
        else:
            formatted = avu.format('s')
    else:
        formatted = avu.__mod__('%s')

    assert formatted == 'abc', \
        'AnsibleVaultEncryptedUnicode.format(): unexpected result=[%s]' % formatted


# The following to_yaml and from_yaml methods were modified from the

# Generated at 2022-06-21 00:05:06.490224
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():

    """This function should be called only from unit tests.

    Note that the test is implemented as a function, instead of a method
    of a class, to avoid the case where the test is called through
    a real instance of AnsibleVaultEncryptedUnicode.

    This note may seem silly, but the code that is to be tested would
    be changed by the presence of the test method in the class.
    """

    assert not AnsibleVaultEncryptedUnicode('\v').isprintable()
    assert not AnsibleVaultEncryptedUnicode('\f').isprintable()
    assert not AnsibleVaultEncryptedUnicode('\r').isprintable()


# Generated at 2022-06-21 00:05:11.946350
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    assert len(AnsibleVaultEncryptedUnicode('_')) == 1
    assert len(AnsibleVaultEncryptedUnicode('a')) == 1
    assert len(AnsibleVaultEncryptedUnicode('ab')) == 2
    assert len(AnsibleVaultEncryptedUnicode('abc')) == 3


# Generated at 2022-06-21 00:05:34.139157
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    r"""Test for AnsibleVaultEncryptedUnicode.splitlines()

    splitlines() method of AnsibleVaultEncryptedUnicode returns a list of lines in the string,
    breaking at line boundaries. Line breaks are not included in the resulting list
    unless keepends is given and true.

    This method uses the same values as str.splitlines().
    For more information on this method, see help(str.splitlines).

    Note: The splitlines() method is included only for compatibility with
    Python 2. It splits on all combinations of internal newlines and the
    external newlines represented by the string, plus it splits on all
    Unicode line breaks. For splitting on various newline combinations, see
    the split() method.
    """
    # Verify that '\n' is recognized as newline.
    #
    # This also verifies that the data

# Generated at 2022-06-21 00:05:41.013257
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    import unittest
    from ansible.module_utils.common.vault import VaultLib
    from ansible.module_utils.yaml import YAML, AnsibleVaultEncryptedUnicode, AnsibleUnicode

    class TestVaultLib(VaultLib):
        def encrypt(self, plaintext, secret):
            if plaintext == 'text that is not a vault secret':
                return plaintext

# Generated at 2022-06-21 00:05:45.864869
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode("VaultEncryptedUnicode")
    assert ansible_vault_encrypted_unicode.expandtabs(10) == "VaultEncryptedUnicode"



# Generated at 2022-06-21 00:05:53.686876
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    assert AnsibleVaultEncryptedUnicode(u'foo').endswith(u'o')
    assert AnsibleVaultEncryptedUnicode(u'foo').endswith(u'oo')
    assert AnsibleVaultEncryptedUnicode(u'foo').endswith(u'oo', 0, 1) is False
    assert AnsibleVaultEncryptedUnicode(u'foo').endswith(u'oo', -2, -1)
    assert AnsibleVaultEncryptedUnicode(u'foo').endswith(u'o', 0, 1)
    assert AnsibleVaultEncryptedUnicode(u'foo').endswith(u'foo', 0, 0) is False
    assert AnsibleVaultEncryptedUnicode(u'foo').endswith(u'foo', -1)

# Generated at 2022-06-21 00:05:58.057210
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    class A(AnsibleBaseYAMLObject):
        pass

    a = A()
    a.ansible_pos = ('filename', 1, 1)
    assert a.ansible_pos == ('filename', 1, 1)


# Generated at 2022-06-21 00:06:03.700168
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    def test(ciphertext, expected):
        avu = AnsibleVaultEncryptedUnicode(ciphertext)
        assert avu.rstrip() == expected

    test(b'', b'')
    test(b' ', b'')
    test(b'abc', b'abc')
    test(b'abc ', b'abc')



# Generated at 2022-06-21 00:06:08.354977
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    value = u'AAA'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(value, None, None)
    assert avu.data == value
    assert avu.strip() == value
    assert isinstance(avu.strip(), AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-21 00:06:14.119357
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    vault = VaultLib({})
    ciphertext = vault.encrypt('foobar')
    obj1 = AnsibleVaultEncryptedUnicode(ciphertext)
    obj1.vault = vault
    obj2 = AnsibleVaultEncryptedUnicode(ciphertext)
    obj2.vault = vault
    assert obj1 == obj2



# Generated at 2022-06-21 00:06:25.028045
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():

    class FakeVaultObject(object):
        def is_encrypted(self, bytes):
            return True

        def decrypt(self, bytes):
            return "string"

    padded_string = AnsibleVaultEncryptedUnicode(" string ")
    padded_string.vault = FakeVaultObject()
    stripped_string = padded_string.strip()
    assert isinstance(stripped_string, AnsibleVaultEncryptedUnicode)

    not_padded_string = AnsibleVaultEncryptedUnicode("string ")
    not_padded_string.vault = FakeVaultObject()
    stripped_string = not_padded_string.strip()
    assert isinstance(stripped_string, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-21 00:06:27.219502
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    avu = AnsibleVaultEncryptedUnicode("FoO")
    fold = avu.casefold()
    if fold.data != "foo":
        raise AssertionError("casefold method of AnsibleVaultEncryptedUnicode class not working")

test_AnsibleVaultEncryptedUnicode_casefold()


# Generated at 2022-06-21 00:06:47.202579
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    avu_a = AnsibleVaultEncryptedUnicode('avu_a')
    avu_b = AnsibleVaultEncryptedUnicode('avu_b')
    avu_c = AnsibleVaultEncryptedUnicode('avu_c')
    test_str = 'first second and last'

    replacement_a = avu_a.replace(avu_b, avu_c)
    replacement_b = avu_a.replace(avu_b, 'avu_c')
    replacement_c = avu_a.replace('avu_b', avu_c)

    assert replacement_a == replacement_b == replacement_c == 'avu_a'
    assert test_str.replace('second', 'third') == test_str.replace(avu_b, 'third') == test

# Generated at 2022-06-21 00:06:51.360689
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    assert AnsibleVaultEncryptedUnicode('a').isalpha() == True
    assert AnsibleVaultEncryptedUnicode('a ').isalpha() == False
    assert AnsibleVaultEncryptedUnicode('1').isalpha() == False
    assert AnsibleVaultEncryptedUnicode('1a').isalpha() == False


# Generated at 2022-06-21 00:06:54.963372
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    ansible_unicode = AnsibleUnicode('test')
    assert isinstance(ansible_unicode, text_type)
    assert repr(ansible_unicode) == u"u'test'"
    assert ansible_unicode == u'test'


# Generated at 2022-06-21 00:07:01.440584
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    # Test with normal string
    string1 = u"   "
    assert_equal(string1.isspace(), AnsibleVaultEncryptedUnicode(string1).isspace())

    # Test with non-normal string
    string2 = '\u200b'
    assert_equal(string2.isspace(), AnsibleVaultEncryptedUnicode(string2).isspace())



# Generated at 2022-06-21 00:07:12.852661
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:07:16.808490
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    avu = AnsibleVaultEncryptedUnicode('abcd')
    assert avu.zfill(5) == '0abcd'
    assert avu.zfill(4) == 'abcd'
    assert avu.zfill(1) == 'abcd'


# Generated at 2022-06-21 00:07:20.091746
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    assert AnsibleVaultEncryptedUnicode('foo').isprintable()
    assert not AnsibleVaultEncryptedUnicode('\n').isprintable()
    assert AnsibleVaultEncryptedUnicode('\x7f').isprintable()



# Generated at 2022-06-21 00:07:27.652249
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    assert "0001" == AnsibleVaultEncryptedUnicode("1").zfill(4)
    assert " +2000" == AnsibleVaultEncryptedUnicode(" +2000").zfill(6)
    assert "***" == AnsibleVaultEncryptedUnicode("***").zfill(2)
    assert "***" == AnsibleVaultEncryptedUnicode("***").zfill(3)
    assert "***" == AnsibleVaultEncryptedUnicode("***").zfill(0)



# Generated at 2022-06-21 00:07:33.131806
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    mytext = u'2'
    avu = AnsibleVaultEncryptedUnicode(mytext)
    assert avu.isnumeric()

    mytext = u'2000'
    avu = AnsibleVaultEncryptedUnicode(mytext)
    assert avu.isnumeric()

    mytext = u'10.5'
    avu = AnsibleVaultEncryptedUnicode(mytext)
    assert avu.isnumeric()

    mytext = u'10.5e-12'
    avu = AnsibleVaultEncryptedUnicode(mytext)
    assert avu.isnumeric()

    mytext = u'2e+10'
    avu = AnsibleVaultEncryptedUnicode(mytext)
    assert avu.isnumeric()


# Generated at 2022-06-21 00:07:37.137176
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    avue = AnsibleVaultEncryptedUnicode.from_plaintext('1.2+2.4j', None, None)
    result = avue.__complex__()
    assert result == (1.2 + 2.4j)



# Generated at 2022-06-21 00:08:16.572057
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    # Test 1
    password = 'foobarbaz'

# Generated at 2022-06-21 00:08:27.629017
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    for i in range(0, 2):
        secret = b'secret'
        plaintext = 'foo'

        if i == 1:
            plaintext = 'foo'.encode(encoding='utf8')

        import ansible.parsing.vault
        vault = ansible.parsing.vault.VaultLib(secret)
        avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)

        assert avu.data == plaintext
        assert avu.index('f') == 0
        assert avu.index('o') == 1
        assert avu.index('foo') == 0
        assert avu.index('f', 1) == 1
        assert avu.index('f', 1, 2) == 1
        assert avu.index('x') == -1

# Generated at 2022-06-21 00:08:38.939595
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    """Unit test for the method expandtabs
    """
    # TODO: what is the expected behavior of expandtabs ?
    # Example 1
    aveu = AnsibleVaultEncryptedUnicode("Some\tsample\ttext")
    assert aveu.expandtabs(3) == "Some  sample  text"

    # Example 2
    aveu = AnsibleVaultEncryptedUnicode("Some\tsample\ttext")
    assert aveu.expandtabs(4) == "Some  sample   text"

    # Example 3
    aveu = AnsibleVaultEncryptedUnicode("Some\tsample\ttab\tafter\ttab")
    assert aveu.expandtabs(3) == "Some  sample  tab  after  tab"

    # Example 4
   

# Generated at 2022-06-21 00:08:50.796454
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    '''
    Mandatory arguments
    - width : the length of the resulting string with the original string centered between padding expected to be an int
    Optional arguments
    - fillchar : padding character expected to be a string
    '''
    sample_text = 'test text'
    encrypted_text = AnsibleVaultEncryptedUnicode(sample_text)
    assert len(encrypted_text.center(31)) == 31, 'Test fail: padding absent'
    assert len(encrypted_text.center(31, 'x')) == 31, 'Test fail: padding absent'
    assert len(encrypted_text.center(32)) == 32, 'Test fail: padding absent'
    assert len(encrypted_text.center(32, 'x')) == 32, 'Test fail: padding absent'

# Generated at 2022-06-21 00:09:00.524354
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    # A test string with a sequence which matches the pattern
    # This test will pass if there is no match found
    str1 = 'What is your name?'
    pattern = 'y '
    assert AnsibleVaultEncryptedUnicode(str1).rfind(pattern) == -1
    # A test string with a sequence which matches the pattern
    # This test will pass if the match is found
    str2 = 'What is your name?'
    pattern = 'ur '
    assert AnsibleVaultEncryptedUnicode(str2).rfind(pattern) == 10
    # A test string with a sequence which matches the pattern
    # This test will pass if the match is found
    str2 = 'What is your name?'
    pattern = 'ur '
    assert AnsibleVaultEncryptedUnicode(str2).rfind(pattern) == 10

# Generated at 2022-06-21 00:09:04.316254
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.zfill(5) == '00abc', 'Failed to execute method zfill of class AnsibleVaultEncryptedUnicode'


# Generated at 2022-06-21 00:09:15.885770
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault = VaultLib('password', '/tmp/test')
    secret = 'password'

    # Test 1: Test splitting the string when it is a string
    ciphertext = vault.encrypt('str1str2str3', secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.split('str') == ['1', '2', '3']

    # Test 1.1: Test splitting the string when it is a unicode
    ciphertext = vault.encrypt(u'\ud83d\ude02\ud83d\ude02\ud83d\ude02', secret)
    avu

# Generated at 2022-06-21 00:09:20.394689
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Check if returns correct value
    # Check if returns correct value when given value
    # Check if returns correct value when given value, vault
    assert True

    # Check if returns incorrect value
    # Check if returns incorrect value when given value
    # Check if returns incorrect value when given value, vault
    assert True


# Generated at 2022-06-21 00:09:27.783878
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    from ansible.parsing.vault import VaultLib
    secret = b'127.0.0.1'
    t = AnsibleVaultEncryptedUnicode(b'hello world')
    t.vault = VaultLib(b'127.0.0.1')
    assert t.__getslice__(0,6) == u'hello'
    assert t.__getslice__(6,11) == u' worl'
    assert t.__getslice__(11,1) == u''
    assert t.__getslice__(11,0) == u''
    assert t.__getslice__(0,1) == u'h'
    assert t.__getslice__(0,0) == u''
    assert t.__getslice__(0,-1) == u

# Generated at 2022-06-21 00:09:30.325122
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    x = AnsibleVaultEncryptedUnicode('a')
    assert x.rpartition('a') == 'a', "didn't return correct value"


# Generated at 2022-06-21 00:10:10.529851
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    # Initialize data "ascii_printable_letter" with ascii letters
    ascii_printable_letter = 'abcdefghijklmnopqrstuvwxyz'

    # Create a new object with encrypted ansible letter.
    # 'ascii_printable_letter' is a normal string, not a ansible vault object.
    vault_ansible_letter = AnsibleUnicode(ascii_printable_letter)

    if sys.version_info[0] < 3:
        # Python 2.x
        assert isinstance(vault_ansible_letter, basestring)
    else:
        # Python 3.x
        assert isinstance(vault_ansible_letter, str)

    # Test AnsibleVaultEncryptedUnicode.isprintable()
    assert vault_ans

# Generated at 2022-06-21 00:10:15.327910
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    string1 = AnsibleVaultEncryptedUnicode('1')
    string2 = AnsibleVaultEncryptedUnicode('2')
    assert '[1, \'\', \'\']' == repr(string1.partition(string2))


# Generated at 2022-06-21 00:10:26.737140
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    class DummyVault(object):
        def is_encrypted(self, b):
            return True
        def decrypt(self, b):
            return b
        def encrypt(self, b, s):
            return b

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('', vault=DummyVault(), secret='')
    avu.vault = None
    # We need to create a mapping with string keys, otherwise format_map will fail
    mapping = {'a': 1, 'b': 2}
    assert '{a},{b}'.format_map(mapping) == '1,2', 'format_map failed without encryption'
    avu.vault = DummyVault()
    avu.data = '{a},{b}'

# Generated at 2022-06-21 00:10:35.602057
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib()

# Generated at 2022-06-21 00:10:41.229806
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    s = AnsibleVaultEncryptedUnicode("hello big {} world".format("blue"))
    b = AnsibleVaultEncryptedUnicode(b"hello big {} world".format("blue"))
    assert text_type(s) == 'hello big {} world'.format("blue")
    assert text_type(b) == 'hello big {} world'.format("blue")



# Generated at 2022-06-21 00:10:44.628008
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    a = AnsibleVaultEncryptedUnicode('password: !vault |')
    assert not a.endswith('\n')
    assert a.endswith('|')



# Generated at 2022-06-21 00:10:47.547853
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.capitalize() == 'Test'



# Generated at 2022-06-21 00:10:54.159945
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    x = 'Any string'
    y = AnsibleVaultEncryptedUnicode.from_plaintext(x, None, None)
    assert y.lower() == x.lower()


# allow for libyaml C loading
try:
    from yaml import CSafeLoader as AnsibleLoader
    from yaml import CSafeDumper as AnsibleDumper
except ImportError:
    from yaml import SafeLoader as AnsibleLoader
    from yaml import SafeDumper as AnsibleDumper


# Generated at 2022-06-21 00:10:56.341421
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    assert hasattr(AnsibleSequence, 'ansible_pos')

# vim: set et sw=4 ts=8 sts=4:

# Generated at 2022-06-21 00:11:07.222295
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode