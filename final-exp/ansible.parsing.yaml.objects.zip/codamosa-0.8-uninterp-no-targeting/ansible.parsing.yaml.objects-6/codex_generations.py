

# Generated at 2022-06-21 00:01:33.586604
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    # Create an instance of AnsibleVaultEncryptedUnicode with the value 'mY pAsswOrd is mypassword'
    avu = AnsibleVaultEncryptedUnicode('mY pAsswOrd is mypassword')
    # Call the title method of the instance
    x = avu.title()
    # Check if the value returned by title method is equal to 'My Password Is Mypassword'
    assert x == 'My Password Is Mypassword'


# Generated at 2022-06-21 00:01:37.977132
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    assert AnsibleVaultEncryptedUnicode('hi').capitalize() == AnsibleVaultEncryptedUnicode('Hi')
    # assert AnsibleVaultEncryptedUnicode('hI').capitalize() == AnsibleVaultEncryptedUnicode('Hi')
    # assert AnsibleVaultEncryptedUnicode('HI').capitalize() == AnsibleVaultEncryptedUnicode('Hi')


# Generated at 2022-06-21 00:01:41.009203
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    avu = AnsibleVaultEncryptedUnicode("this_is_ciphertext")
    assert len(avu) == 19, "should be 19"


# Generated at 2022-06-21 00:01:51.820574
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    # TODO: I don't like this test, it uses the 'real' vaultlib, it doesn't work when tests are run without ansible-test (i.e. without the entire ansible pip package installed), it doesn't test anything
    try:
        # pylint: disable=unused-variable
        from ansible.parsing.vault import VaultLib
    except ImportError:
        return

    data = 'plaintext'
    secret = 'secret'
    vault = VaultLib('password')

    # Test when AnsibleVaultEncryptedUnicode is created with plaintext
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(data, vault, secret)
    assert isinstance(avu.__unicode__(), text_type)
    assert to_text(avu.__unicode__()) == data



# Generated at 2022-06-21 00:01:55.220776
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    avu = AnsibleVaultEncryptedUnicode('abc')
    avu.vault = None
    assert avu.capitalize() == 'Abc'


# Generated at 2022-06-21 00:02:07.630457
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    a = AnsibleVaultEncryptedUnicode(u'secret')
    a.vault = FakeVault()
    assert(a.data == u'secret')
    assert(a[::] == u'secret')
    assert(a[::-1] == u'terces')
    assert(a[0:5] == u'secre')
    assert(a[5:10] == u't')
    assert(a[0:-1] == u'secre')
    assert(a[0:-2] == u'secr')
    assert(a[-1:-10] == u'')
    assert(a[-2:-10] == u'')
    assert(a[-2:10] == u't')
    assert(a[-3:10] == u'et')



# Generated at 2022-06-21 00:02:11.064043
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    av = AnsibleVaultEncryptedUnicode("{test: \"\t1\"}")
    assert av.expandtabs(tabsize=8) == "{test: \"        1\"}"


# Generated at 2022-06-21 00:02:21.053572
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    import unittest
    class AnsibleVaultEncryptedUnicode___complex__TestCase(unittest.TestCase):
        def __init__(self, vault, ciphertext):
            super(AnsibleVaultEncryptedUnicode___complex__TestCase, self).__init__()
            self.vault = vault
            self.ciphertext = ciphertext

        def runTest(self):
            self.vault.password = '234sysjdkf'
            avu = AnsibleVaultEncryptedUnicode(
                ciphertext=self.ciphertext,
                vault=self.vault,
            )
            avu.ansible_pos = ['source', 1, 1]
            expected_complex = complex(avu.data)
            actual_complex = complex(avu)

# Generated at 2022-06-21 00:02:33.834930
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    a = AnsibleVaultEncryptedUnicode('1')
    original_method = a.rstrip
    a.rstrip = lambda *args, **kwargs: original_method(*args, **kwargs)

    assert("A" == AnsibleVaultEncryptedUnicode("A\n").rstrip(to_text("\n")))
    assert("A" == AnsibleVaultEncryptedUnicode("A\n").rstrip(to_text("\r\n")))
    assert("A" == AnsibleVaultEncryptedUnicode("A\n").rstrip(to_text(" ")))
    assert("A" == AnsibleVaultEncryptedUnicode("A\n").rstrip())
    assert("A" == AnsibleVaultEncryptedUnicode("A").rstrip())

# Generated at 2022-06-21 00:02:39.619342
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    try:
        from ansible.parsing.vault import VaultLib
    except ImportError:  # future import problem in py3.3
        VaultLib = None
    if VaultLib:
        vault = VaultLib(b'1234')
        v = AnsibleVaultEncryptedUnicode('tESt', vault, b'1234')
        assert v.lower() == 'test'
        assert v.data == 'tESt'



# Generated at 2022-06-21 00:03:01.511311
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:03:09.010780
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-21 00:03:12.877805
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    class obj(AnsibleBaseYAMLObject):
        pass
    a = obj()
    a.ansible_pos = ("foo",1,2)
    assert(a.ansible_pos == ("foo",1,2))


# Generated at 2022-06-21 00:03:21.482327
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    from ansible.utils.encrypt import VaultLib
    vault = VaultLib({'password': 'testpassword'})

    # Test isascii with an encryptable string
    s = AnsibleVaultEncryptedUnicode.from_plaintext('!ascii', vault, 'testpassword')
    assert s.isascii()
    s.data = '!contains\N{LATIN SMALL LETTER A WITH GRAVE}'
    assert not(s.isascii())
    s.data = '!\N{LATIN SMALL LETTER A WITH GRAVE}'
    assert not(s.isascii())

    # Test isascii with an encrypted string

# Generated at 2022-06-21 00:03:28.341739
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    assert str(AnsibleVaultEncryptedUnicode('foo')) == 'foo'
    assert str(AnsibleVaultEncryptedUnicode(u'foo')) == 'foo'
    assert str(AnsibleVaultEncryptedUnicode('foo', vault = '')) == 'foo'
    assert to_text(AnsibleVaultEncryptedUnicode(b'foo')) == 'foo'


# Generated at 2022-06-21 00:03:37.948111
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    # '\xFC' is a character that can be represented in Latin-1 and UTF-8,
    # but not in ISO-8859-1.
    avu = AnsibleVaultEncryptedUnicode("\xFC")
    # In Python 2, the default encoding is ASCII, so this raises a UnicodeEncodeError.
    if _sys.version_info[0] > 2:
        assert avu.encode("ISO-8859-1") == b'\xFC'
    else:
        try:
            avu.encode("ISO-8859-1")
        except UnicodeEncodeError:
            pass



# Generated at 2022-06-21 00:03:46.987174
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    a = b'FOO'
    b = to_bytes('FOO')
    c = to_bytes('Foo')

    avua = AnsibleVaultEncryptedUnicode(a)
    result = avua > b
    assert(result == False)

    avua = AnsibleVaultEncryptedUnicode(b)
    result = avua > a
    assert(result == False)

    avua = AnsibleVaultEncryptedUnicode(b)
    result = avua > c
    assert(result == True)


# Generated at 2022-06-21 00:03:59.071785
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    # rpartition is a method that use str.rpartition
    # str.rpartition is a method that return a sequence
    # rpartition returns a sequence
    # so we define some variables to test this method of class AnsibleVaultEncryptedUnicode
    string = 'B'
    sep = 'A'
    sep1 = 'C'
    sep2 = 'D'
    string_encrypted = AnsibleVaultEncryptedUnicode(b'B')
    sep_encrypted = AnsibleVaultEncryptedUnicode(b'A')
    sep1_encrypted = AnsibleVaultEncryptedUnicode(b'C')
    sep2_encrypted = AnsibleVaultEncryptedUnicode(b'D')
    # test if rpartition returns a sequence
    # test with a normal string

# Generated at 2022-06-21 00:04:01.757602
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    test_string = AnsibleVaultEncryptedUnicode('hello')
    if test_string.strip('') != 'hello':
        raise AssertionError('Strip method not working')


# Generated at 2022-06-21 00:04:08.494449
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    from ansible.parsing.vault import VaultLib
    assert AnsibleVaultEncryptedUnicode('password', VaultLib('secret')).isalpha() is False
    assert AnsibleVaultEncryptedUnicode('password', VaultLib('secret')).isalpha() is False
    assert AnsibleVaultEncryptedUnicode('abc', VaultLib('secret')).isalpha() is True
    assert AnsibleVaultEncryptedUnicode('ABC', VaultLib('secret')).isalpha() is True
    assert AnsibleVaultEncryptedUnicode('ABCD', VaultLib('secret')).isalpha() is True
    assert AnsibleVaultEncryptedUnicode('1234', VaultLib('secret')).isalpha() is False

# Generated at 2022-06-21 00:04:18.206987
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    # Test function AnsibleSequence.__init__
    sut = AnsibleSequence()
    assert isinstance(sut, AnsibleSequence)


# Generated at 2022-06-21 00:04:28.093998
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    # test1
    seq = "foo"
    old = "o"
    new = "0"
    avu = AnsibleVaultEncryptedUnicode(seq)
    replaced_seq = avu.replace(old, new)
    assert replaced_seq == "f00"

    # test2
    seq = "foo"
    old = "o"
    new = AnsibleVaultEncryptedUnicode("0")
    avu = AnsibleVaultEncryptedUnicode(seq)
    replaced_seq = avu.replace(old, new)
    assert replaced_seq == "f00"

    # test3
    seq = "foo"
    old = AnsibleVaultEncryptedUnicode("o")
    new = "0"
    avu = AnsibleVaultEncryptedUnicode(seq)


# Generated at 2022-06-21 00:04:33.429480
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    s = to_text(b'foo')
    v = AnsibleVaultEncryptedUnicode(b'foo')
    assert s.islower() == v.islower()
    assert s.islower() == True

    s = to_text(b'FOO')
    v = AnsibleVaultEncryptedUnicode(b'FOO')
    assert s.islower() == v.islower()
    assert s.islower() == False

    s = to_text(b'foo')
    v = AnsibleVaultEncryptedUnicode(b'foo')
    assert s.islower() == v.islower()
    assert s.islower() == True



# Generated at 2022-06-21 00:04:38.361718
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    string1 = AnsibleUnicode("hello")
    string2 = AnsibleUnicode("hello")
    assert str(string1) == "hello"
    assert (string1 == string2)
    assert hash(string1) == hash(string2)
    string3 = string1 + string2
    assert str(string3) == "hellohello"


# Generated at 2022-06-21 00:04:42.687930
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    s = AnsibleVaultEncryptedUnicode("hello world")
    ds = AnsibleVaultEncryptedUnicode("hello world")
    assert s.zfill(3) == ds.zfill(3)
    assert not s.is_encrypted()



# Generated at 2022-06-21 00:04:46.591359
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    s = AnsibleVaultEncryptedUnicode('abc.def.ghi.jpg')
    assert s.rpartition('.') == ('abc.def.ghi', '.', '.jpg')


# Generated at 2022-06-21 00:04:58.266531
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():

    assert AnsibleVaultEncryptedUnicode('10').zfill(6) == '000010'
    assert AnsibleVaultEncryptedUnicode('10').zfill(2) == '10'
    assert AnsibleVaultEncryptedUnicode('10').zfill(1) == '10'
    assert AnsibleVaultEncryptedUnicode('10').zfill(0) == '10'
    assert AnsibleVaultEncryptedUnicode('1').zfill(2) == '01'
    assert AnsibleVaultEncryptedUnicode('1').zfill(1) == '1'
    assert AnsibleVaultEncryptedUnicode('1').zfill(0) == '1'
    assert AnsibleVaultEncryptedUnicode('0').zfill(2) == '00'
    assert AnsibleVault

# Generated at 2022-06-21 00:05:07.217021
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    string_to_encrypt = '{username}:{password}'
    expected_result = 'admin:admin1234'
    mapping = {'username': 'admin', 'password': 'admin1234'}

    # with no vault, it is not encrypted, to_text() is called,
    # the string returned is PY3 str, not unicode
    avu = AnsibleVaultEncryptedUnicode(string_to_encrypt)
    assert isinstance(avu.format_map(mapping), text_type)
    assert avu.format_map(mapping) == expected_result

    # with vault, it is encrypted
    from ansible.parsing.vault import VaultLib
    avu.vault = VaultLib('vault_secret')
    avu.data = string_to_encrypt

# Generated at 2022-06-21 00:05:18.247197
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    from math import sqrt
    # first part of test
    test_object1 = AnsibleVaultEncryptedUnicode('-1.5+0.8j')
    result = complex(test_object1)
    expected_result = complex(-1.5,0.8)
    assert(result == expected_result)
    # second part of test
    test_object2 = AnsibleVaultEncryptedUnicode('1+2j')
    result = complex(test_object2)
    expected_result = complex(1,2)
    assert(result == expected_result)
    # third part of test
    test_object3 = AnsibleVaultEncryptedUnicode('2+2j')
    result = complex(test_object3)
    expected_result = complex(2,2)

# Generated at 2022-06-21 00:05:23.071612
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    avu = AnsibleVaultEncryptedUnicode("foo")
    assert avu.translate("o", "x") == "fxx"
    assert avu.translate("o") == "f"
    assert avu.translate("o", "") == "f"
    with pytest.raises(TypeError):
        avu.translate("o", "x", "y")


# Generated at 2022-06-21 00:05:48.200426
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    printable_chars = set(text_type(chr(x)) for x in range(128)) - {u'\x07', u'\x0b', u'\x0c', u'\x1b'}
    printable_strings = set(text_type(string.printable))
    non_printable_strings = {u'abc\x07def', u'abc\x0b\u1001def', u'abc\u1001def', u'abc\x1bdef'}
    assert all([AnsibleVaultEncryptedUnicode(x).isprintable() for x in printable_chars | printable_strings])
    assert all([not AnsibleVaultEncryptedUnicode(x).isprintable() for x in non_printable_strings])



# Generated at 2022-06-21 00:05:59.744501
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    # Test case 1
    avueu_test = AnsibleVaultEncryptedUnicode(ciphertext=b"This is a test string.\n")
    avueu_test.data = u"This is a test string.\n"
    assert (avueu_test.rindex(sub=u"i") == 8)

    # Test case 2
    avueu_test = AnsibleVaultEncryptedUnicode(ciphertext=b"This is a test string.\n")
    avueu_test.data = u"This is a test string.\n"
    assert (avueu_test.rindex(sub=u"i", start=12) == 14)

    # Test case 3

# Generated at 2022-06-21 00:06:08.650099
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    password = 'lkjdfg'
    secret = 'secret'
    plaintext = 'This is some plaintext'
    vault = vaultlib.VaultLib(password)
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    output = 'This is some plaintext'
    assert output == '%s' % encrypted
    encrypted = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;blah')
    assert plaintext != encrypted
    assert '$ANSIBLE_VAULT' != encrypted



# Generated at 2022-06-21 00:06:12.540964
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    print("Swapping case ...")
    avu = AnsibleVaultEncryptedUnicode("Hello World")
    print(avu.swapcase())
    print(type(avu.swapcase()))
    print("Success !")

if __name__ == '__main__':
    test_AnsibleVaultEncryptedUnicode_swapcase()



# Generated at 2022-06-21 00:06:20.289884
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    data = 'abc'
    ciphertext = '$ANSIBLE_VAULT;1.2;AES256;ansible\n303564303337343331633563623964366531333235613464653466356561666232616663633833\n396536663463353130306662613332656631663038653139343963666263303565636162336539\n363438656566626436306635363761323633306635333266633338323333633035366530323134\n39346162613366\n'
    vault = vaultlib.VaultLib('abc')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    assert avu.data == data

# Generated at 2022-06-21 00:06:32.171910
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:06:35.491505
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    assert AnsibleVaultEncryptedUnicode("---").startswith("---")
    assert AnsibleVaultEncryptedUnicode("---").startswith("--")
    assert not AnsibleVaultEncryptedUnicode("--").startswith("---")
    assert not AnsibleVaultEncryptedUnicode("--").startswith("-")



# Generated at 2022-06-21 00:06:42.354872
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    try:
        sys.gettrace()
        def f():
            try:
                class A(AnsibleVaultEncryptedUnicode):
                    vault = None
                    def __complex__(self):
                        return complex(self.data)

                a = A(b'0j')
                print(complex(a))
                print(a.__complex__())
                print(a.data.__complex__())
                a.vault = object()
                print(a.__complex__())
            finally:
                pass
        f()
    except SystemExit:
        raise
    except:
        import traceback
        traceback.print_exc()
        raise


# Generated at 2022-06-21 00:06:49.184056
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    from ansible.parsing import vault

    secret = 'foobar'
    seq = 'foo'
    vault = vault.VaultLib(password=secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert(avu.vault is vault)
    assert(avu.data == seq)


# Backwards compatibility for yaml objects

# Generated at 2022-06-21 00:06:52.375098
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    a = AnsibleVaultEncryptedUnicode('ANSIBLE')
    assert a.count('A') == 1
    assert a.count('A', 2) == 0
    assert a.count('E') == 1
    assert a.count('E', 2) == 1



# Generated at 2022-06-21 00:07:21.904108
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    encrypted = AnsibleVaultEncryptedUnicode(u'ln1\nln2\nln3\n')
    assert len(encrypted.splitlines()) == 4
    assert encrypted.splitlines(True) == [u'ln1\n', u'ln2\n', u'ln3\n', u'']


# Generated at 2022-06-21 00:07:28.376794
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    from ansible.module_utils.vault import VaultLib

    secret = 'secret'
    vault = VaultLib([])

    t = 'this is my {0} vault'.format(AnsibleVaultEncryptedUnicode('encrypted', vault, secret))
    assert t == 'this is my encrypted vault'


# alias for backwards compatibility
AnsibleVaultEncryptedUnicodeString = AnsibleVaultEncryptedUnicode


# Generated at 2022-06-21 00:07:39.714634
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY3

    vault_id = 1
    vault_secret = '$ANSIBLE_VAULT;a;b'
    vault = VaultLib(bytes(vault_id), bytes(vault_secret))

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('avustring', vault, vault_secret)

    assert avu.center(10) == b' avustring '
    if PY3:
        # On PY3, the non-text parameters returned from the call are bytes,
        # and can't be comparison with the unicode string of avu.center
        assert avu.center(10, b'x')

# Generated at 2022-06-21 00:07:48.353096
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    u8 = u"foo".encode('utf-8')
    # test creation of unicode from bytestring
    assert AnsibleUnicode(u8) == u8.decode('utf-8')
    # test creation of unicode from string
    assert AnsibleUnicode(u8.decode('utf-8')) == u8.decode('utf-8')
    # test creation of unicode from unicode
    assert AnsibleUnicode(u8.decode('utf-8')) == u8.decode('utf-8')
    # test creation of unicode from bytestring in ASCII
    assert AnsibleUnicode(b'foo') == u8.decode('utf-8')
    # test creation of unicode from object whose str is a bytestring in ASCII

# Generated at 2022-06-21 00:07:50.636316
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    avu = AnsibleVaultEncryptedUnicode('ABC')
    assert avu.lower() == 'abc'


# Generated at 2022-06-21 00:08:03.140949
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    from ansible.parsing.vault import VaultLib
    result='passw0rd'
    avu = AnsibleVaultEncryptedUnicode()
    avu.vault = VaultLib('password')
    avu.data = result
    avu.ansible_pos = ('test.yml', 1, 0)
    assert '{0.data}'.format(avu) == result
    assert '{0.data[0]}'.format(avu) == result[0]
    assert '{0.data[0:3]}'.format(avu) == result[0:3]
    assert '{0.data:3}'.format(avu) == result
    assert '{0.data!r}'.format(avu) == result
    assert '{:s}'.format(avu) == result


# Generated at 2022-06-21 00:08:11.179231
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    # Failure cases
    # 1. istitle returns True for string with atleast 1 alpha character and that character is not capitalized
    assert not AnsibleVaultEncryptedUnicode("abc").istitle()
    assert not AnsibleVaultEncryptedUnicode("abcdef").istitle()
    assert not AnsibleVaultEncryptedUnicode("abcdefg").istitle()

    # 2. istitle returns True for string with atleast 1 alphanumeric character and that character is not capitalized
    assert not AnsibleVaultEncryptedUnicode("123").istitle()
    assert not AnsibleVaultEncryptedUnicode("123456").istitle()
    assert not AnsibleVaultEncryptedUnicode("1234567").istitle()

    # 3. istitle returns True for string with atleast 1 alpha character and that character is not

# Generated at 2022-06-21 00:08:23.028326
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    password = 'password'
    # Simple string
    plaintext = 'test string'

# Generated at 2022-06-21 00:08:26.163788
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    mapping = AnsibleMapping()
    assert isinstance(mapping, dict)
    assert isinstance(mapping, AnsibleBaseYAMLObject)



# Generated at 2022-06-21 00:08:33.524544
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    from ansible.utils.vault import VaultLib
    from ansible.parsing import vault

    vault = VaultLib('testpassword')
    ut = vault.encode('test').decode('unicode_escape')
    s = AnsibleVaultEncryptedUnicode(ut)
    s.vault = vault

    # 1. 'test' is contained in the decrypted version of our string
    assert 'test' in s
    # 2. 'test' is contained in the encrypted version of our string
    assert ut[27:31] in s
    # 3. 'test' is contained in another encrypted version of our string
    c = AnsibleVaultEncryptedUnicode(ut)
    c.vault = vault
    assert 'test' in c
    # 4. 'test' is contained in the encrypted and decrypted versions of another string

# Generated at 2022-06-21 00:09:12.247301
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    import ansible.vault as vault
    # bytes ciphertext
    avu = AnsibleVaultEncryptedUnicode('\xbc\xd2\x04\xcbz\x18\xb3\x0c\x8d\x16\xc9\x0f\xe8\x06\x08')
    avu.vault = vault.AESVaultLib('toto')
    assert(to_text(avu) == 'toto')
    assert(to_text(avu) == str(avu))
    assert(str(avu) == 'toto')
    assert(to_text(avu * 3) == str('tototototo'))
    assert(str(avu) == 'toto')
    assert(avu + avu == 'totototo')

# Generated at 2022-06-21 00:09:18.495882
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password=to_bytes('ansible'))
    secret = 'ansible'
    plaintext = '12345'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.isdigit()


# Generated at 2022-06-21 00:09:26.128908
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    class FakeVault(object):
        def __init__(self, secret):
            self.secret = secret

        def encrypt(self, seq, secret=None):
            if secret == self.secret:
                return seq
            raise ValueError('Secret is invalid')

        def decrypt(self, ciphertext, secret=None):
            raise ValueError('Please use "data" property')

        def is_encrypted(self, ciphertext):
            return ciphertext != 'some plaintext'

    secret = 'top secret'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('some plaintext', FakeVault(secret), secret)
    assert len(avu) == 17


# Generated at 2022-06-21 00:09:35.669473
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    import sys
    if sys.version_info >= (3, 0):
        assert AnsibleBaseYAMLObject._get_ansible_position() == (None, 0, 0)
        AnsibleBaseYAMLObject._set_ansible_position((None, 1, 2))
        assert AnsibleBaseYAMLObject._get_ansible_position() == (None, 1, 2)
        try:
            AnsibleBaseYAMLObject._set_ansible_position("hi")
        except AssertionError:
          pass
        except:
          raise AssertionError("Unexpected exception raised when trying to set ansible_pos to an invalid value")



# Generated at 2022-06-21 00:09:43.545130
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    txt = AnsibleVaultEncryptedUnicode("y")
    assert(txt.rfind("abcdefg") == -1)
    assert(txt.rfind("abcdefg", -1) == -1)
    assert(txt.rfind("abcdefg", -2) == -1)
    assert(txt.rfind("abcdefg", -3) == -1)
    assert(txt.rfind("abcdefg", -4) == -1)
    assert(txt.rfind("abcdefg", -5) == -1)
    assert(txt.rfind("abcdefg", -6) == -1)
    assert(txt.rfind("abcdefg", -7) == -1)
    assert(txt.rfind("abcdefg", -8) == -1)

# Generated at 2022-06-21 00:09:49.049389
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    class FakeVault(object):
        def decrypt(self, data, **kwargs):
            return 'abcdefghij'
    fake_vault = FakeVault()
    test_str = AnsibleVaultEncryptedUnicode('fake')
    test_str.vault = fake_vault
    assert test_str.translate(None, 'a') == 'bcdefghij'


# Generated at 2022-06-21 00:09:57.542188
# Unit test for method format of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:10:09.449899
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    s = ' '
    assert (AnsibleVaultEncryptedUnicode(s)).istitle() is True

    s = '   \t\n\r'
    assert (AnsibleVaultEncryptedUnicode(s)).istitle() is True

    s = '\t\n\rXYZ'
    assert (AnsibleVaultEncryptedUnicode(s)).istitle() is True

    s = '\n\rXYZ'
    assert (AnsibleVaultEncryptedUnicode(s)).istitle() is True

    s = '\tXYZ'
    assert (AnsibleVaultEncryptedUnicode(s)).istitle() is True

    s = 'XYZ'
    assert (AnsibleVaultEncryptedUnicode(s)).istitle() is True

# Unit test

# Generated at 2022-06-21 00:10:21.074083
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    from ansible.parsing.vault import VaultLib
    secret = "password"
    from ansible.module_utils.six.moves import StringIO
    unpadded = StringIO()
    vault = VaultLib([])
    encrypted_data = vault.encrypt(secret, unpadded)
    # store the encrypted password in the file for testing purposes
    encrypted_password_file = open('encrypted_password.txt', 'w+')
    encrypted_password_file.write(encrypted_data)
    encrypted_password_file.close()

    # validating the translation method
    encrypted_unicode_string = AnsibleVaultEncryptedUnicode.from_plaintext(secret, vault, secret)
    table = encrypted_unicode_string.maketrans({"p": "i"})
    translated_string = encrypted_unicode_

# Generated at 2022-06-21 00:10:28.576677
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    '''
    Attempts to print the ansible.parsing.vault.AnsibleVaultEncryptedUnicode
    class.
    '''
    try:
        from ansible.parsing.vault import VaultLib
    except ImportError:
        return

    avu = AnsibleVaultEncryptedUnicode('dGhpc2lzYW4=');
    vault = VaultLib('secret')
    avu.vault = vault
    print(avu)

