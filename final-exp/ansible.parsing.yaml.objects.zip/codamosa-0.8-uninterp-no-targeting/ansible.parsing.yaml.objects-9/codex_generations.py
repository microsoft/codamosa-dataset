

# Generated at 2022-06-21 00:01:20.996860
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    avue = AnsibleVaultEncryptedUnicode(b'A' + b'x' * 1000)
    assert avue.lstrip(b'A' + b'x' * 1000) == ''


##
# additional methods used in templating to test certain attributes
# of a variable
##


# Generated at 2022-06-21 00:01:25.320223
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    u = AnsibleVaultEncryptedUnicode('äbc')
    assert u.capitalize() == 'Äbc'
    u = AnsibleVaultEncryptedUnicode('ABC')
    assert u.capitalize() == 'Abc'
    u = AnsibleVaultEncryptedUnicode('123')
    assert u.capitalize() == '123'


# Generated at 2022-06-21 00:01:33.040383
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # non-AnsibleVaultEncryptedUnicode string
    assert(AnsibleVaultEncryptedUnicode('a') != 'a')
    assert(AnsibleVaultEncryptedUnicode('a') != AnsibleVaultEncryptedUnicode('b'))
    assert(not AnsibleVaultEncryptedUnicode('a') != 'a')
    assert(not AnsibleVaultEncryptedUnicode('a') != AnsibleVaultEncryptedUnicode('a'))

# Generated at 2022-06-21 00:01:40.103371
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    a1 = AnsibleVaultEncryptedUnicode("a")
    a2 = AnsibleVaultEncryptedUnicode("a")
    assert a1 <= a2
    assert not a2 <= a1
    assert a1 <= "a"
    assert not a1 <= "b"
    assert not a2 <= "a"
    assert not a2 <= "b"
    assert "a" <= a1
    assert not "a" <= a2
    assert not "b" <= a1
    assert not "b" <= a2
    assert a1 <= u"a"
    assert not a1 <= u"b"
    assert not a2 <= u"a"
    assert not a2 <= u"b"
    assert u"a" <= a1
    assert not u"a" <= a2

# Generated at 2022-06-21 00:01:47.917982
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import ansible.parsing.vault as vault
    secret = 'secret'
    secret_seq = 'the secret is 123'
    vault = vault.VaultLib(secret)
    ciphertext = vault.encrypt(secret_seq, secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(secret_seq, vault, secret)
    assert(avu == ciphertext)
    avu1 = AnsibleVaultEncryptedUnicode(ciphertext)
    assert(avu == avu1)

# Generated at 2022-06-21 00:01:56.066227
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:02:02.313837
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    if 'AnsibleVaultEncryptedUnicode.isascii' in globals():
        del globals()['AnsibleVaultEncryptedUnicode.isascii']
    try:
        AnsibleVaultEncryptedUnicode("\0", vault=None).isascii()
        return True
    except AttributeError:
        return False


# Generated at 2022-06-21 00:02:13.678507
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    if _sys.version_info[0] == 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    import pytest

    class mystr(str):
        def __radd__(self, other):
            return other + self

    # Python 3 removes __getslice__ and __coerce__ so our code should too
    if _sys.version_info[0] == 2:
        mystr.__getslice__ = str.__getslice__
        mystr.__coerce__ = str.__coerce__

    # __radd__ with a regular string
    s = mystr('abc')
    assert '123' + s == '123abc'

    # __radd__ with a unicode
    if _sys.version_info[0] == 3:
        u

# Generated at 2022-06-21 00:02:25.852176
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    a = AnsibleVaultEncryptedUnicode("")
    assert a.splitlines() == ['']
    a = AnsibleVaultEncryptedUnicode("\r")
    assert a.splitlines() == ['\r']
    a = AnsibleVaultEncryptedUnicode("\r\n")
    assert a.splitlines() == ['\r\n']
    a = AnsibleVaultEncryptedUnicode("\n")
    assert a.splitlines() == ['\n']
    a = AnsibleVaultEncryptedUnicode("\n\r")
    assert a.splitlines() == ['\n', '\r']
    a = AnsibleVaultEncryptedUnicode("\r\n\r\n\n")

# Generated at 2022-06-21 00:02:36.996812
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    import unittest

    class Test_AnsibleVaultEncryptedUnicode_upper(unittest.TestCase):

        def test_with_string_argument(self):
            u = AnsibleVaultEncryptedUnicode('abc')
            self.assertEqual(u.upper(), 'ABC')

        def test_with_unicode_argument(self):
            u = AnsibleVaultEncryptedUnicode('abc')
            self.assertEqual(u.upper(), 'ABC')

        def test_their_replacement_method(self):
            u = AnsibleVaultEncryptedUnicode('AbC')
            self.assertEqual(u.data, 'AbC')
            self.assertEqual(text_type(u).upper(), 'ABC')

# Generated at 2022-06-21 00:03:01.928769
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    from ansible.parsing.vault import VaultLib
    seq = '1234'
    secret = 'secret'
    vault = VaultLib(password=secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert (avu.__radd__('56') == '56' + seq)
    assert (avu.__radd__(u'56') == u'56' + seq)
    assert (bytes('56') + avu == bytes('56') + seq)
    try:
        assert (None + avu == None + seq)
        assert False
    except TypeError as e:
        assert 'invalid type for __add__' in str(e)



# Generated at 2022-06-21 00:03:08.870594
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    class MockVault(object):
        def __init__(self, password, method):
            pass
        def decrypt(self, data):
            return data

    result = AnsibleVaultEncryptedUnicode("aaa", vault=MockVault("", "")).rindex("a")
    assert result == 2, ("AnsibleVaultEncryptedUnicode.rindex('a') returned %s, expected %s" % (result, 2))
    result = AnsibleVaultEncryptedUnicode("aaa", vault=MockVault("", "")).rindex("b")
    assert result == -1, ("AnsibleVaultEncryptedUnicode.rindex('b') returned %s, expected %s" % (result, -1))


# Generated at 2022-06-21 00:03:19.356788
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    # When using Python 3, ensure that the method AnsibleVaultEncryptedUnicode.__str__()
    # returns a str object in all cases.
    #
    # In particular, the following object:
    #   AnsibleVaultEncryptedUnicode.from_plaintext(seq='')
    # must return an empty str object.
    #
    # Previously, this object returned a unicode object.
    from ansible.parsing.vault import VaultLib

    vault = VaultLib()
    secret = 'secret'

    def assert_is_str(s):
        if not isinstance(s, str):
            raise AssertionError('Expected {!r} to be an instance of str'.format(s))

    # From plaintext.

# Generated at 2022-06-21 00:03:31.498178
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('a+b', vault=None, secret=None)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('a+b', vault=None, secret=None)
    assert(avu1.__le__(avu2))
    assert(avu2.__le__(avu1))
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('a+bc', vault=None, secret=None)
    assert(avu1.__le__(avu2))
    assert(not avu2.__le__(avu1))
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('a+/b', vault=None, secret=None)
   

# Generated at 2022-06-21 00:03:39.095369
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    assert 'aaaabcabcabcdef' == AnsibleVaultEncryptedUnicode('abcabcabc').__mod__(('abc', 'def'))
    assert 'abcdefabcabcabc' == AnsibleVaultEncryptedUnicode('abcabcabc').__mod__(('abc', 'def'))
    assert 'efabcabcabcabc' == AnsibleVaultEncryptedUnicode('abcabcabc').__mod__(('abc', 'def'))
    assert '1.7' == AnsibleVaultEncryptedUnicode('%f').__mod__(1.7)


# Generated at 2022-06-21 00:03:51.261140
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    test_cases = (
        # dict with strings and booleans
        {
            'text': 'Ansible.Vault',
            'result': True
        },
        {
            'text': 'Ansible.Vault-Encrypted',
            'result': True
        },
        {
            'text': 'Ansible:vault',
            'result': False
        },
        {
            'text': 'Ansible vault',
            'result': False
        },
        {
            'text': 'ansible vault',
            'result': False
        }
    )

    for case in test_cases:
        avu = AnsibleVaultEncryptedUnicode(case['text'])
        assert avu.istitle() == case['result']


# Generated at 2022-06-21 00:03:51.922047
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    pass


# Generated at 2022-06-21 00:03:58.198515
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    assert AnsibleVaultEncryptedUnicode(b'abc').islower() == True
    assert AnsibleVaultEncryptedUnicode(b'Abc').islower() == False
    assert AnsibleVaultEncryptedUnicode(b'ABC').islower() == False
    assert AnsibleVaultEncryptedUnicode(b'123').islower() == False
    assert AnsibleVaultEncryptedUnicode(b'AbC').islower() == False
    assert AnsibleVaultEncryptedUnicode(b'AbC123').islower() == False
    assert AnsibleVaultEncryptedUnicode(b'abc123').islower() == True
    assert AnsibleVaultEncryptedUnicode(b'abc!@#$%^&*()').islower() == True
    assert AnsibleVaultEncryptedUnic

# Generated at 2022-06-21 00:04:08.828220
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_passphrase = "password"

# Generated at 2022-06-21 00:04:20.588326
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    unicode_string = AnsibleVaultEncryptedUnicode(None)

    unicode_string.data = u''
    assert unicode_string.isidentifier() == False
    unicode_string.data = u'a'
    assert unicode_string.isidentifier() == True
    unicode_string.data = u'a1'
    assert unicode_string.isidentifier() == True
    unicode_string.data = u'a1b2'
    assert unicode_string.isidentifier() == True
    unicode_string.data = u'a1b2c'
    assert unicode_string.isidentifier() == True
    unicode_string.data = u'a_1b_2'
    assert unicode_string.isidentifier() == True
    unicode_string.data

# Generated at 2022-06-21 00:04:39.096993
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    from ansible.parsing.vault import VaultLib
    vault_password = 'ansible'
    vault = VaultLib(vault_password)
    plaintext = 'password'

# Generated at 2022-06-21 00:04:46.806644
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    fail=0
    if len(AnsibleVaultEncryptedUnicode('{msg}',2).format_map(dict(msg='secret'))):
        fail=1
    if not len(AnsibleVaultEncryptedUnicode('{msg}',2).format_map(dict(msg=AnsibleVaultEncryptedUnicode('secret',2)))):
        fail=1
    print('fail=%d' % fail)


# Generated at 2022-06-21 00:04:58.480074
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 00:05:00.658640
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    """ Unit test for method center of class AnsibleVaultEncryptedUnicode """
    string = AnsibleVaultEncryptedUnicode('cat')
    width = 5
    fillchar = ' '
    string.center(width, fillchar=fillchar)
    assert string == '  cat'


# Generated at 2022-06-21 00:05:03.528180
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    class MyClass:
        def __str__(self):
            return 'str'

    my_class = MyClass()
    assert "before %s after" % my_class == "before str after"



# Generated at 2022-06-21 00:05:14.912980
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    # Setup
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    class mock_vaultlib(object):
        """Mock for AnsibleVaultEncryptedUnicode.__init__.vault"""
        def __init__(self, ciphertext):
            pass

        def encrypt(self, seq, secret):
            pass

        def decrypt(self, ciphertext, obj=None):
            return ' '

        def is_encrypted(self, ciphertext):
            return True


# Generated at 2022-06-21 00:05:18.946614
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.rjust(10) == '      test'
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.rjust(10,'*') == '******test'


# Generated at 2022-06-21 00:05:28.125997
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    assert AnsibleVaultEncryptedUnicode('a').lstrip() == 'a'
    assert AnsibleVaultEncryptedUnicode('a').lstrip('a') == ''
    assert AnsibleVaultEncryptedUnicode('a').lstrip('b') == 'a'
    assert AnsibleVaultEncryptedUnicode('a').lstrip('ab') == ''
    assert AnsibleVaultEncryptedUnicode('aba').lstrip('ab') == 'a'
    assert AnsibleVaultEncryptedUnicode('aba').lstrip('ab') == 'a'
    assert AnsibleVaultEncryptedUnicode('aba').lstrip('ab') == 'a'
    assert AnsibleVaultEncryptedUnicode('ababa').lstrip('ab') == 'aba'

# Generated at 2022-06-21 00:05:33.964082
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    seq = AnsibleVaultEncryptedUnicode("test")
    res = seq.split("s")
    assert isinstance(res, list), "res should be a list"
    assert len(res) == 2, "res should have 2 elements"
    assert isinstance(res[0], AnsibleVaultEncryptedUnicode), "res[0] should be an AnsibleVaultEncryptedUnicode"
    assert isinstance(res[1], AnsibleVaultEncryptedUnicode), "res[1] should be an AnsibleVaultEncryptedUnicode"
    assert res[0].is_encrypted(), "res[0] should be encrypted"
    assert res[1].is_encrypted(), "res[1] should be encrypted"


# Generated at 2022-06-21 00:05:38.292834
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib

    data = 'password'
    password = 'asdasdasdsdasd'
    vault = VaultLib(password)
    ciphertext = vault.encrypt(data, password)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    assert avu.count('s') == 3



# Generated at 2022-06-21 00:05:47.261315
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass


# Generated at 2022-06-21 00:05:52.783400
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    class MockVault(object):
        def decrypt(self, _ciphertext, obj=None):
            return u'Foo'

    ciphertext = AnsibleVaultEncryptedUnicode('abcd')
    ciphertext.vault = MockVault()

    # Test endswith(self, suffix, start=0, end=_sys.maxsize):
    assert u'Foo'.endswith(u'o', 0, 3)
    assert ciphertext.endswith(u'o', 0, 3)



# Generated at 2022-06-21 00:06:00.245607
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    class MockVault(object):
        def __init__(self):
            self.password = None

        def encrypt(self, plaintext, secret):
            return plaintext

        def decrypt(self, ciphertext, secret):
            return ciphertext

    mock_vault = MockVault()
    avue = AnsibleVaultEncryptedUnicode.from_plaintext('abc', mock_vault, '123')
    assert avue.casefold() == 'abc'



# Generated at 2022-06-21 00:06:02.397006
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    import doctest
    doctest.testmod(AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-21 00:06:14.026687
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    import unittest

    class AnsibleVaultEncryptedUnicodeTestCase(unittest.TestCase):
        def test_isnumeric_positive(self):
            self.assertTrue(AnsibleVaultEncryptedUnicode(u'123').isnumeric())
            self.assertTrue(AnsibleVaultEncryptedUnicode(u'\u00B2').isnumeric())
            self.assertTrue(AnsibleVaultEncryptedUnicode(u'\u00B2', vault=None).isnumeric())

        def test_isnumeric_negative(self):
            self.assertFalse(AnsibleVaultEncryptedUnicode(u'abc').isnumeric())
            self.assertFalse(AnsibleVaultEncryptedUnicode(u'123a').isnumeric())
            self

# Generated at 2022-06-21 00:06:21.056509
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    """ Verify that isalpha() of AnsibleVaultEncryptedUnicode return true if the data is alphanumeric"""
    from ansible.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    password_file = None
    password = b'12345'
    temp = None
    expected = True
    seq = 'abcde12345'

    if temp:
        password_file = temp.name
        temp.write(password)
        temp.close()

    vault = VaultLib(password_file=password_file, password=password)
    secret = VaultSecret(password_file=password_file, password=password)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu.isalnum() == expected

test_Ansible

# Generated at 2022-06-21 00:06:23.995300
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    assert AnsibleVaultEncryptedUnicode('test').title() == 'Test'


# Generated at 2022-06-21 00:06:30.260726
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    # Without a vault the upper method should return the ciphertext
    avu = AnsibleVaultEncryptedUnicode('12345')
    assert avu.upper() == '12345'

    # With a vault it should return the decrypted text
    avu.vault = vaultlib.VaultLib('mypassword')
    avu.data = 'mypassword'
    assert avu.upper() == 'MYPASSWORD'




# Generated at 2022-06-21 00:06:35.328760
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    """Test if the method rfind of AnsibleVaultEncryptedUnicode class works correctly
    """
    s = "aabb"
    avu = AnsibleVaultEncryptedUnicode(s)
    if avu.rfind("a") != 0:
        raise AssertionError("Method rfind of AnsibleVaultEncryptedUnicode class does not work correctly")



# Generated at 2022-06-21 00:06:43.215909
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    v = 'RV7bx4y4jV7kqY3A'
    ct = b'$ANSIBLE_VAULT;1.1;AES256\n393036653330323264323862663937303333376663336136613333663436653666373739306165\n613938323233313637653033666231613661336361613163306633386663633533353463313934\n65303338343832383166613361376366533663339636430333365393333323461663537326334\n6561653039336434353764\n'
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(None)
    avu = AnsibleV

# Generated at 2022-06-21 00:07:02.569196
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test when the parent class is str (python 2)
    if _sys.version_info[0] == 2:
        import unittest
        from vault import VaultLib
        from ansible.parsing.vault import VaultSecret

        vault_secret = "".join([random.choice(string.ascii_letters + string.digits) for n in range(32)])
        vault_secret_bytes = to_bytes(vault_secret)
        vault = VaultLib(vault_secret)

        # maxsize = sys.maxsize
        maxsize = sys.maxsize - 1
        avu_str = AnsibleVaultEncryptedUnicode.from_plaintext("ABC", vault, vault_secret)

        # These are all valid use cases, since the ansible vault string can be treated as a string
        # This test is

# Generated at 2022-06-21 00:07:07.269801
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    try:
        a = AnsibleUnicode('a')
    except Exception as e:
        assert False, "AnsibleUnicode() threw an exception: %s" % e
    else:
        assert isinstance(a, AnsibleUnicode)
        assert a == u'a'


# Generated at 2022-06-21 00:07:12.904633
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    '''AnsibleVaultEncryptedUnicode.__reversed__()'''
    plaintext = "I'm a string"
    av = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault=None, secret="secret")
    test = reversed(av)
    assert test == plaintext[::-1]


# Generated at 2022-06-21 00:07:16.131532
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    a = AnsibleSequence([1,2,3])
    assert a.ansible_pos == (None, 0, 0)
    assert a == [1,2,3]


# Generated at 2022-06-21 00:07:23.610768
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    from ansible.parsing.vault import VaultLib

    # test with different versions
    for version in [1, 2, None]:
        # set the test password
        password = 'testPassword'

        # initialize VaultLib object with test password
        # NOTE: this is only possible because we initialize the vault object
        #       with the default parameters
        vault = VaultLib(password)

        # Test isnumeric on AnsibleVaultEncryptedUnicode object
        # with different encodings

# Generated at 2022-06-21 00:07:25.408145
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    import ansible.parsing.vault
    import collections

# Generated at 2022-06-21 00:07:34.892516
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    TEST_STRING = "5"
    ansible_vault_encrypted_object = AnsibleVaultEncryptedUnicode(ciphertext=TEST_STRING)

    assert int(ansible_vault_encrypted_object) == 5

    TEST_STRING = "foobar"
    ansible_vault_encrypted_object = AnsibleVaultEncryptedUnicode(ciphertext=TEST_STRING)

    try:
        int(ansible_vault_encrypted_object)
    except ValueError:
        exception_raised = True
    else:
        exception_raised = False

    assert exception_raised is True


# Generated at 2022-06-21 00:07:45.270935
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    vault = VaultLib()
    secret = b'bar'
    # Note that vaulted_string is a AnsibleUnicode object, not a AnsibleVaultEncryptedUnicode object
    enc_string = vault.encrypt(u'foo', secret)
    vaulted_string = AnsibleVaultEncryptedUnicode(enc_string)
    vaulted_string.vault = vault
    plain_string = vaulted_string.data
    print('vaulted_string is %s' % vaulted_string)
    print('plain_string is %s' % plain_string)

    # Define a

# Generated at 2022-06-21 00:07:47.438639
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    avu = AnsibleVaultEncryptedUnicode('   foo')
    assert avu.lstrip() == 'foo'


# Generated at 2022-06-21 00:07:59.381056
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    assert AnsibleVaultEncryptedUnicode('000').isdecimal()
    assert not AnsibleVaultEncryptedUnicode('000 ').isdecimal()
    assert AnsibleVaultEncryptedUnicode('0').isdecimal()
    assert AnsibleVaultEncryptedUnicode('345').isdecimal()
    assert AnsibleVaultEncryptedUnicode('99999').isdecimal()
    assert not AnsibleVaultEncryptedUnicode('99999 ').isdecimal()
    assert AnsibleVaultEncryptedUnicode('0123').isdecimal()
    assert not AnsibleVaultEncryptedUnicode('0123 ').isdecimal()
    assert not AnsibleVaultEncryptedUnicode(' 9876').isdecimal()

# Generated at 2022-06-21 00:08:15.942918
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    # test for correct work with string
    test_string = to_text('test_string')
    test_vault = AnsibleVaultEncryptedUnicode('test_vault')
    assert test_vault.__ge__(test_string) == False

    # test for correct work with AnsibleVaultEncryptedUnicode
    test_string = AnsibleVaultEncryptedUnicode('test_string')
    test_vault = AnsibleVaultEncryptedUnicode('test_vault')
    assert test_vault.__ge__(test_string) == False


# Generated at 2022-06-21 00:08:27.047511
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    """ Unit test for method __float__ of class AnsibleVaultEncryptedUnicode """
    from ansible import constants as C
    from ansible.vault import VaultLib


# Generated at 2022-06-21 00:08:35.845672
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    # Define a string
    s = "Hello world !"
    # Create a cipher text
    avu = AnsibleVaultEncryptedUnicode(s)
    # Call the upper method
    res = avu.upper()
    # Check the result
    if res == "HELLO WORLD !":
        print("OK")
        return 0
    print("KO")
    return 1

if __name__ == '__main__':
    # Test AnsibleVaultEncryptedUnicode class
    import sys
    sys.exit(test_AnsibleVaultEncryptedUnicode_upper())

# Generated at 2022-06-21 00:08:39.740191
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    ansible_vault_encrypted_unicode_obj = AnsibleVaultEncryptedUnicode("/root/ansible_vault_encrypted_unicode_obj.py")
    print(ansible_vault_encrypted_unicode_obj.split("."))


# Generated at 2022-06-21 00:08:44.400952
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    a1 = AnsibleVaultEncryptedUnicode('encrypted string')
    assert len(a1) == len(a1.data)
    for s in range(20):
        a1 = AnsibleVaultEncryptedUnicode(str(s))
        assert len(a1) == len(a1.data)


# Generated at 2022-06-21 00:08:56.792582
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    from ansible.utils import vault as vaultlib
    secret = "password"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("ansible", vaultlib.VaultLib(), secret)
    values = {"token": avu}
    url = "https://example.com?q={token}".format(**values)
    assert url == "https://example.com?q=ansible"
    assert isinstance(url, text_type)
    assert isinstance(avu.data, text_type)



# Generated at 2022-06-21 00:08:59.036690
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    assert to_text(AnsibleVaultEncryptedUnicode(to_bytes('foo')), errors='surrogate_or_strict') == u'foo'


# Generated at 2022-06-21 00:09:11.204444
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    import unittest
    from ansible.parsing.vault import VaultLib

    class AnsibleVaultEncryptedUnicodeTests(unittest.TestCase):

        def setUp(self):
            self.vault_password = 'ansible'
            password_file = '/tmp/ansible-vault-password-file'
            tmp_file = open(password_file, 'w')
            tmp_file.write(self.vault_password)
            tmp_file.close()
            self.vault = VaultLib(password_file)


# Generated at 2022-06-21 00:09:14.199673
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    from ansible.parsing.vault import VaultLib

    test_string = "This is a test."
    vault = VaultLib(b"1234")
    ciphertext = vault.encrypt(test_string, None)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    assert str(avu) == test_string



# Generated at 2022-06-21 00:09:23.667533
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    if not hasattr(text_type, 'casefold'):
        assert(True)
        return
    import ansible.parsing.vault as vault
    secret1 = 'abc123'
    ciphertext = vault.VaultLib.encrypt(
        b'ABCDEFGHIJKL',
        secret1,
        b'_ansible_vault_pass'
    )
    ciphertext = to_text(ciphertext)
    vu = AnsibleVaultEncryptedUnicode(ciphertext)
    vu.vault = vault.VaultLib(secret1)
    assert(vu.casefold() == 'abcdefghijkl')


# Generated at 2022-06-21 00:09:35.557519
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    # create a new object and make sure it has been created properly
    x = AnsibleBaseYAMLObject()
    assert x


# Generated at 2022-06-21 00:09:38.350719
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    assert AnsibleVaultEncryptedUnicode('Foo').lower() == 'foo'
    assert AnsibleVaultEncryptedUnicode('Foo').lower() == 'foo'



# Generated at 2022-06-21 00:09:48.654715
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper
    secret = 'my_key'

    ciphertext = VaultLib(secret).encrypt(u'foobar', secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = VaultLib(secret)

    assert avu.rstrip() == 'foobar'

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu.rstrip('bar') == 'foo'

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu.rstrip('ba') == 'foo'

# Generated at 2022-06-21 00:09:50.902454
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    if sys.version_info < (3, 5):
        return
    assert AnsibleVaultEncryptedUnicode.isalnum == text_type.isalnum


# Generated at 2022-06-21 00:09:57.036222
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    a = AnsibleSequence(['a', 'b', 'c'])
    assert isinstance(a, AnsibleSequence)
    assert len(a) == 3
    assert list(a) == ['a', 'b', 'c']
    a = AnsibleSequence({'a': 'b'})
    assert isinstance(a, AnsibleSequence)
    assert len(a) == 1
    assert list(a) == ['a']
    a = AnsibleSequence(a='b')
    assert isinstance(a, AnsibleSequence)
    assert len(a) == 1
    assert list(a) == ['a']

test_AnsibleSequence()


# Generated at 2022-06-21 00:10:00.648297
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    av = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, 'secret')
    assert av.rindex('t') == 2



# Generated at 2022-06-21 00:10:05.559121
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    l = []
    for i in range(0, 10):
        l.append(str(i))
    l = AnsibleVaultEncryptedUnicode("").join(l)
    print("Unit test for AnsibleVaultEncryptedUnicode.join: %s" % l)



# Generated at 2022-06-21 00:10:12.850110
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    actual = AnsibleVaultEncryptedUnicode("foo/bar").rpartition("/")
    assert(actual == ("foo", "/", "bar")), "Actual <" + actual + "> is different from expected <" + ("foo", "/", "bar") + ">"

    actual = AnsibleVaultEncryptedUnicode("foo/bar/").rpartition("/")
    assert(actual == ("foo/bar", "/", "")), "Actual <" + actual + "> is different from expected <" + ("foo/bar", "/", "") + ">"

    actual = AnsibleVaultEncryptedUnicode("foobar").rpartition("/")
    assert(actual == ("", "", "foobar")), "Actual <" + actual + "> is different from expected <" + ("", "", "foobar")

# Generated at 2022-06-21 00:10:18.987189
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    avu = AnsibleVaultEncryptedUnicode('foo')
    avu.vault = mock_vault()

    assert avu.rjust(5) == '  foo'
    assert avu.rjust(5, '-') == '--foo'
    assert avu.rjust(5, 'a') == 'aaafoo'



# Generated at 2022-06-21 00:10:30.173423
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    import ansible.vault

    vault_key = '6301fe2f-a9a6-4889-b694-6a1a31e1d0a8'
    vault_password = 'secret'
    director_password = 'supersecret'

    vault = ansible.vault.VaultLib(vault_password)
    encrypted_director_password = AnsibleVaultEncryptedUnicode.from_plaintext(director_password, vault, vault_key)

    # Test normal interpolation
    interpolation_result = '{director_password}'.format(director_password=encrypted_director_password)
    assert director_password == interpolation_result

    # Test format_map interpolation
    interpolation_result = '{director_password}'.format_map({'director_password': encrypted_director_password})

# Generated at 2022-06-21 00:10:52.515179
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    s = AnsibleVaultEncryptedUnicode(to_bytes('A'))
    seq = [s, s, s]
    assert 'AAA' == s.join(seq)
    assert 'AAA' == ''.join(seq)


# Generated at 2022-06-21 00:10:56.930198
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    s = AnsibleVaultEncryptedUnicode('a')
    e = AnsibleVaultEncryptedUnicode('b')
    assert 'a' + e == s + e
    assert e + 'a' == e + s
    assert s + 'a' == s + 'a'


# Generated at 2022-06-21 00:11:07.641395
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    avu_fake = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    avu_fake._ciphertext = to_bytes(avu_fake._ciphertext)
    assert avu_fake.is_encrypted() == True
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    # This sets .vault
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=VaultLib(), secret='password')
    assert avu.is_encrypted() == True
    # Test a string that is not encrypted
    avu_plaintext = AnsibleVaultEncryptedUnicode('foo')