

# Generated at 2022-06-23 05:42:23.600983
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    assert list( AnsibleVaultEncryptedUnicode(b'abcdef')[::-1] ) == [b'f', b'e', b'd', b'c', b'b', b'a']


# Generated at 2022-06-23 05:42:26.590439
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    plaintext = u'az'
    assert AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault=None, secret=None).isalpha() == plaintext.isalpha()


# Generated at 2022-06-23 05:42:34.541254
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    class DummyVault(object):
        def decrypt(self, data, obj=None):
            return b'plaintext_data'
    dummy_vault = DummyVault()

    # Test without vault object
    avu = AnsibleVaultEncryptedUnicode(b'plaintext_data')
    assert avu.split() == ['plaintext_data']
    # Test with vault object
    avu.vault = dummy_vault
    assert avu.split() == ['plaintext_data']
    assert avu.split(b'') == ['p', 'l', 'a', 'i', 'n', 't', 'e', 'x', 't', '_', 'd', 'a', 't', 'a']
    assert avu.split(b'_') == ['plaintext', 'data']

# Generated at 2022-06-23 05:42:47.720543
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    plaintext = 'this unencrypted string referes to the encrypted secret'
    plaintext_list = ['encrypted', 'string', 'is', 'here']
    secret = 'secret'
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(secret)
    ciphertext = vault.encrypt(plaintext, secret)
    ciphertext_list = [vault.encrypt(item, secret) for item in plaintext_list]
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(ciphertext, vault, secret)
    avu_list = [AnsibleVaultEncryptedUnicode.from_plaintext(item, vault, secret) for item in ciphertext_list]

# Generated at 2022-06-23 05:42:56.838391
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    # Test with simple title string
    assert AnsibleUnicode(u'CamelCase').istitle()

    # Test with leading and trailing illegal chars
    assert AnsibleUnicode(u'$CamelCase').istitle()
    assert AnsibleUnicode(u'CamelCase$').istitle()
    assert not AnsibleUnicode(u'$CamelCase$').istitle()

    # Test with illegal successive words
    assert not AnsibleUnicode(u'CamelCase CamelCase').istitle()

    # Test with single word
    assert not AnsibleUnicode(u'CamelCase').istitle()

    # Test with all upcase and all downcase word
    assert not AnsibleUnicode(u'UPPERCASE').istitle()
    assert not AnsibleUnicode(u'lowercase').istitle

# Generated at 2022-06-23 05:43:08.355041
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    input = range(10)
    ansible_pos = ('the_source', 42, 24)

    # test __init__() method
    ansible_mapping = AnsibleMapping(input, ansible_pos)

    assert dict(input) == dict(ansible_mapping)
    assert 'the_source' == ansible_mapping.ansible_pos[0]
    assert 42 == ansible_mapping.ansible_pos[1]
    assert 24 == ansible_mapping.ansible_pos[2]

    # test _set_ansible_position()
    ansible_mapping.ansible_pos = ansible_pos
    assert 'the_source' == ansible_mapping.ansible_pos[0]
    assert 42 == ansible_mapping.ansible_pos[1]
    assert 24

# Generated at 2022-06-23 05:43:18.093403
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    from ansible.parsing.vault import VaultLib
    pl = 'test1'
    pw = 'test2'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(pl, VaultLib(password=pw), secret=pw)
    assert avu.__lt__(pl)
    assert not avu.__lt__('test3')
    assert not avu.__lt__(u'test3')
    assert not avu.__lt__(123456)


# Generated at 2022-06-23 05:43:22.080450
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    secret = b'secret'
    vault = VaultLib([secret], 1)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(u'foo', vault, secret)
    avu += u'bar'
    assert avu == u'foobar'


# Generated at 2022-06-23 05:43:29.494678
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    plain_string = "This is a plain string."
    cipher_string = "U2FsdGVkX1+2Q9rwv0xUyW4/V0YHM4NbNv1Ls2hgSV7/uT1E9H7hqC0B7hk6DMyU"

    # Try to decode a string using format_map method
    s = AnsibleVaultEncryptedUnicode(cipher_string)
    assert s.data == plain_string

    # Try to decode a string without and AnsibleVaultEncryptedUnicode object
    s = cipher_string
    assert s != plain_string

# Generated at 2022-06-23 05:43:37.116289
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    assert AnsibleVaultEncryptedUnicode.isidentifier(AnsibleVaultEncryptedUnicode('abcABC123_xyz')) == True
    assert AnsibleVaultEncryptedUnicode.isidentifier(AnsibleVaultEncryptedUnicode('2b')) == False
    assert AnsibleVaultEncryptedUnicode.isidentifier(AnsibleVaultEncryptedUnicode('abc ABC 123 _xyz')) == False


# Generated at 2022-06-23 05:43:43.210860
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    assert AnsibleVaultEncryptedUnicode(to_bytes(b'foo', errors='surrogate_or_strict')).islower()
    assert not AnsibleVaultEncryptedUnicode(to_bytes(b'Foo', errors='surrogate_or_strict')).islower()
    assert not AnsibleVaultEncryptedUnicode(to_bytes(b'FOO', errors='surrogate_or_strict')).islower()



# Generated at 2022-06-23 05:43:48.440760
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    s = AnsibleVaultEncryptedUnicode("foo")
    assert s.rjust(5) == "  foo" and type(s.rjust(5)) is AnsibleVaultEncryptedUnicode
    assert s.rjust(5, "=") == "==foo"



# Generated at 2022-06-23 05:43:57.186886
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    import unittest
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Set secret password
    secret = 'secret_password'
    tests = {
        'Unicode object': u'hello world',
        'String object': 'hello world',
        'Int object': 1,
        'List object': [],
        'Dictionary object': {},
        'AnsibleVaultEncryptedUnicode object': AnsibleVaultEncryptedUnicode(''),
    }

    # Create VaultLib obj
    vault = VaultLib([])

    # Convert objects

# Generated at 2022-06-23 05:44:02.553110
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    # Tests for empty strings
    for string in ['', '\n', '\r', '\r\n']:
        assert AnsibleVaultEncryptedUnicode(string).splitlines() == ['']
        assert AnsibleVaultEncryptedUnicode(string).splitlines(keepends=True) == [string]

    # Tests for one char strings
    for string in ['a', '\na', '\ra', '\r\na']:
        assert AnsibleVaultEncryptedUnicode(string).splitlines() == ['a']
        assert AnsibleVaultEncryptedUnicode(string).splitlines(keepends=True) == [string]

    # Tests for multi char strings

# Generated at 2022-06-23 05:44:07.744214
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    assert AnsibleVaultEncryptedUnicode("test").partition("n") == ('te', 'n', '')
    assert AnsibleVaultEncryptedUnicode("test").partition("test") == ('', 'test', '')
    assert AnsibleVaultEncryptedUnicode("test").partition("test,test") == ('', 'test', ',test')



# Generated at 2022-06-23 05:44:18.291932
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    import ansible.parsing.vault
    plaintext = 'some vaunted plaintext'
    vault = ansible.parsing.vault.VaultLib('somepass')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, 'somepass')
    assert avu + 'some other text' == avu.data + 'some other text'
    assert 'some text' + avu == 'some text' + avu.data
    assert avu + avu == avu.data + avu.data
    assert avu + AnsibleVaultEncryptedUnicode('some other text') == avu.data + 'some other text'
    assert AnsibleVaultEncryptedUnicode('some text') + avu == 'some text' + avu.data

# Generated at 2022-06-23 05:44:21.203205
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    str1 = "password"
    str2 = "ball"
    pass1 = AnsibleVaultEncryptedUnicode(str1)
    pass2 = AnsibleVaultEncryptedUnicode(str2)
    assert not pass1.__contains__(pass2)



# Generated at 2022-06-23 05:44:30.319899
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    '''(1) Test if method __radd__ of class AnsibleVaultEncryptedUnicode returns
    a type AnsibleVaultEncryptedUnicode
    (2) Test if class AnsibleVaultEncryptedUnicode also can add a Integer
    '''
    avu1 = AnsibleVaultEncryptedUnicode(u'23')
    avu2 = AnsibleVaultEncryptedUnicode(u'4')
    avu3 = avu1.__radd__(avu2)
    assert(isinstance(avu3, AnsibleVaultEncryptedUnicode))
    avu3 = avu1.__radd__(3)
    assert(isinstance(avu3, AnsibleVaultEncryptedUnicode))


# Generated at 2022-06-23 05:44:39.827058
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    # Byte strings that comply with the definition of ASCII in the Python
    # Standard Library.
    valid_ascii_bytes = (
        b'\x09\x0a\x0d\x20-\x7e', # printable ASCII characters
        b'\x00\x01\x02\x03\x04\x05\x06\x07', # ASCII control characters
        b'\x0b\x0c',                 # ASCII whitespace control characters
        b'\x7f',                     # DEL control character
        b'',                         # empty string
    )

# Generated at 2022-06-23 05:44:44.787182
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault=None, secret=None)
    assert avu.__add__('') == 'test'
    assert avu.__add__(avu) == 'testtest'
    assert avu.__add__('test') == 'testtest'


# Generated at 2022-06-23 05:44:54.052463
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    # data is unicode
    avu = AnsibleVaultEncryptedUnicode('pwd')
    assert avu.__contains__('w')
    assert not avu.__contains__('z')
    # data is bytes
    avu = AnsibleVaultEncryptedUnicode(b'pwd')
    assert avu.__contains__('w')
    assert not avu.__contains__('z')
    # data is unicode and contains is unicode
    avu = AnsibleVaultEncryptedUnicode('pwd')
    assert avu.__contains__('w')
    assert not avu.__contains__('z')
    # data is bytes and contains is unicode
    avu = AnsibleVaultEncryptedUnicode(b'pwd')
    assert avu.__

# Generated at 2022-06-23 05:44:57.692464
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    testval = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault=None, secret='foo')
    assert testval * 2 == 'hellohello'

# end class AnsibleVaultEncryptedUnicode



# Generated at 2022-06-23 05:45:04.527520
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    try:
        x = AnsibleVaultEncryptedUnicode('test')
        assert x.zfill(5) == '0test'
    except AssertionError:
        print("test_AnsibleVaultEncryptedUnicode_zfill failed")
        raise
    else:
        print("test_AnsibleVaultEncryptedUnicode_zfill passed")


# Generated at 2022-06-23 05:45:09.345638
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    vault = None
    secret = None
    if vault and secret:
        avu = AnsibleVaultEncryptedUnicode.from_plaintext("2.2.0.0/16", vault, secret)
    else:
        avu = AnsibleVaultEncryptedUnicode("2.2.0.0/16")
    assert avu.rjust(12) == "  2.2.0.0/16"


# Generated at 2022-06-23 05:45:19.110520
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    import ansible.parsing.vault as vault
    from ansible.parsing.vault import VaultLib
    import os.path
    from ansible.module_utils._text import to_bytes

    vault_id = "testvault"
    vault_password_file = "~/.vault_pass.txt"
    vault_test_file = "vault_test.yml"
    vault_encode_test_file = "vault_test.txt"
    content = to_bytes("test replace\n")

    with open(vault_encode_test_file, 'wb') as f:
        f.write(content)

    vault_secret = vault.get_file_vault_secret(filename=vault_password_file, vault_id=vault_id, loader=None)

# Generated at 2022-06-23 05:45:24.043540
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    assert AnsibleVaultEncryptedUnicode('') not in 'a'
    assert AnsibleVaultEncryptedUnicode('') not in b'a'
    assert AnsibleVaultEncryptedUnicode('') not in u'a'
    assert AnsibleVaultEncryptedUnicode('') not in b'a'



# Generated at 2022-06-23 05:45:35.296914
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    import crypt
    from ansible.parsing.vault.vault import VaultLib

    plaintext = 'secret'
    vault_id = 'vault-test'

    vault_pass = VaultLib([], 1).new_password()
    ciphertext = crypt.crypt(vault_pass, vault_id)
    plaintext = plaintext.encode('utf-8')
    secret = (ciphertext.decode('utf-8'), plaintext)

    vault = VaultLib(vault_id, 1)

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert avu.join(['a', 'b', 'c']) == 'asecretbsecretc'

# Generated at 2022-06-23 05:45:44.671315
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    test_obj = AnsibleBaseYAMLObject()
    # ansible_position's default should be None
    assert test_obj.ansible_pos == None

    test_obj.ansible_pos = ('/path/to/data', '1', '2')
    assert test_obj.ansible_pos == ('/path/to/data', '1', '2')

    # AnsibleBaseYAMLObject should not be able to assign other type to ansible_position
    try:
        test_obj.ansible_pos = ('/path/to/data', '1')
    except AssertionError as e:
        assert "ansible_pos can only be set with a tuple/list of three values: source, line number, column number" in str(e)



# Generated at 2022-06-23 05:45:48.457519
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    s = AnsibleVaultEncryptedUnicode("   strip me  ")
    s2 = s.strip()
    assert s2 == "strip me"



# Generated at 2022-06-23 05:45:55.860173
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    import vaultlib
    vault = vaultlib.VaultLib("password")
    plaintext = "text to encrypt"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, "password")
    # Make sure the string can be decrypted and format_map can be
    # called on it.
    assert(avu.data == plaintext)
    assert(avu.format_map({}) == plaintext)
    avu.vault = None
    # Without a vault, format_map should still work.
    assert(avu.format_map({}) == plaintext)


# Generated at 2022-06-23 05:45:57.431676
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    # This method will be replaced by the real testing method below
    pass


# Generated at 2022-06-23 05:46:03.310806
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    """
    Tests the method `AnsibleVaultEncryptedUnicode.count`
    """
    def assert_count(expected, haystack, needle, start=None, end=None):
        """
        Asserts that `haystack.count(needle)` returns the expected value.
        """
        kwargs = {}
        if start is not None:
            kwargs['start'] = start
        if end is not None:
            kwargs['end'] = end
        assert haystack.count(needle, **kwargs) == expected

    plaintext = "The quick brown fox jumps over the lazy dog"
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(plaintext)

    # Start and end are not specified.

# Generated at 2022-06-23 05:46:15.665906
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:46:25.727463
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')

    unencrypted = 'hello world'
    encrypted = vault.encrypt(unencrypted)
    avu = AnsibleVaultEncryptedUnicode(encrypted)

    if unencrypted != avu:
        raise ValueError('AvU != unencrypted string')
    if 'o' != to_text('o'):
        raise ValueError('Encrypted character != decrypted character')
    if avu.count('o') != unencrypted.count('o'):
        raise ValueError('count() of AvU != count() of unencrypted string')

_yaml_base_dumper = yaml.SafeDumper
if yaml.__with_libyaml__:  # pylint: disable=using-constant-test
    _yaml_

# Generated at 2022-06-23 05:46:28.769093
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    test_str = AnsibleVaultEncryptedUnicode(b'secret')
    assert(test_str.zfill(15) == '000000secret')



# Generated at 2022-06-23 05:46:34.595458
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    # Create a vault object
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    # Create an AnsibleVaultEncryptedUnicode object
    r1 = AnsibleVaultEncryptedUnicode.from_plaintext('!', vault, 'test')
    assert not r1.isprintable()


# Generated at 2022-06-23 05:46:39.711525
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    assert AnsibleVaultEncryptedUnicode(u'\N{LATIN CAPITAL LETTER SHARP S}\u03b2\N{MODIFIER LETTER SMALL TURNED ALPHA}').casefold() == u'\xdf\u03b2\N{MODIFIER LETTER SMALL TURNED ALPHA}'


# Generated at 2022-06-23 05:46:46.368080
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    vault = None
    contents = 'A\tB\tC'
    try:
        ciphertext = vault.encrypt(contents)
    except:
        pass
    encrypted1 = AnsibleVaultEncryptedUnicode(ciphertext)
    assert encrypted1.expandtabs() == 'A       B       C'

if __name__ == '__main__':
  test_AnsibleVaultEncryptedUnicode_expandtabs()

# Generated at 2022-06-23 05:46:49.470098
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    def split(string):
        return [x.strip() for x in string.rpartition(':')]

    string = AnsibleVaultEncryptedUnicode('asdf: ')
    assert split(string) == split(string.data)



# Generated at 2022-06-23 05:47:00.514973
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    test = AnsibleVaultEncryptedUnicode('abc')
    assert test.join(['1', '2', '3']) == '1abc2abc3'
    assert test.join(['1', 2, 3]) == '1abc2abc3'
    assert test.join(['1', '2', 3]) == '1abc2abc3'

# Preserve order when construct
yaml.add_constructor(u'tag:yaml.org,2002:map', dict)
yaml.add_constructor(u'tag:yaml.org,2002:str',
                     lambda loader, node: AnsibleUnicode(loader.construct_scalar(node)))

# Generated at 2022-06-23 05:47:06.486682
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    e_str = AnsibleVaultEncryptedUnicode.from_plaintext('this_is_not_alpha', None, None)
    assert not e_str.isalpha()

    e_str = AnsibleVaultEncryptedUnicode.from_plaintext('thisisalpha', None, None)
    assert e_str.isalpha()


# Generated at 2022-06-23 05:47:14.389882
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    # Ensure that islower returns correct value for lowercase strings
    assert AnsibleVaultEncryptedUnicode('abc').islower() == True
    assert AnsibleVaultEncryptedUnicode('abc').islower() == True

    # Ensure that islower returns correct value for uppercase strings
    assert AnsibleVaultEncryptedUnicode('ABC').islower() == False
    assert AnsibleVaultEncryptedUnicode('ABC').islower() == False

    # Ensure that islower returns correct value for mixed-case strings
    assert AnsibleVaultEncryptedUnicode('AbC').islower() == False
    assert AnsibleVaultEncryptedUnicode('AbC').islower() == False

    # Ensure that islower returns correct value for strings with spaces

# Generated at 2022-06-23 05:47:26.594260
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    class FakeVault(object):
        def __init__(self):
            self.tries = 0
        def encrypt(self, plaintext, secret):
            self.tries += 1
            return 'ciphertext'
        def decrypt(self, ciphertext, obj):
            # obj = the AnsibleVaultEncryptedUnicode object
            return 'plaintext'
        def is_encrypted(self, ciphertext):
            return True

    avu = AnsibleVaultEncryptedUnicode('ciphertext')
    avu.vault = FakeVault()
    assert avu == 'plaintext'
    assert avu.vault.tries == 1

    new_avu = avu.replace('plaintext', 'text')
    assert isinstance(new_avu, AnsibleVaultEncryptedUnicode)
   

# Generated at 2022-06-23 05:47:36.653631
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    password = 'asd123asd'
    ansible_vault = vaultlib.VaultLib(password)

    password2 = 'qwe123qwe'
    ansible_vault2 = vaultlib.VaultLib(password2)

    text = 'Hello'

    # Test with 2 encrypted string
    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext(text, ansible_vault, password)
    encrypted_string2 = AnsibleVaultEncryptedUnicode.from_plaintext(text, ansible_vault2, password2)
    final_string = encrypted_string + encrypted_string2
    assert final_string == encrypted_string.data + encrypted_string2.data

    # Test with encrypted and non-encrypted string
    final_string = encrypted_string + text
    assert final_string

# Generated at 2022-06-23 05:47:44.141622
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    iv = AnsibleVaultEncryptedUnicode(b'YmIxMjM0NTY3ODkK')
    iv.vault = vault_unittest
    assert chr(iv[0]) == 'Y'
    assert str(iv[0:4]) == 'YmIx'


if sys.version_info < (3,):
    long = long
else:
    long = int



# Generated at 2022-06-23 05:47:54.697824
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    """
    AnsibleVaultEncryptedUnicode.__add__ should return a new AnsibleVaultEncryptedUnicode object
    """
    assert type(AnsibleVaultEncryptedUnicode("blah")) == AnsibleVaultEncryptedUnicode
    a = AnsibleVaultEncryptedUnicode("blah")
    assert type(a + a) == AnsibleVaultEncryptedUnicode
    assert not a.is_encrypted()
    assert not AnsibleVaultEncryptedUnicode("blah").is_encrypted()
    assert AnsibleVaultEncryptedUnicode("!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          ").is_encrypted()


AnsibleUnsafeText = AnsibleVaultEncryptedUnicode

# The following represent the types

# Generated at 2022-06-23 05:48:04.057069
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    from ansible.plugins.vault import VaultLib
    vault = VaultLib('test')
    plaintext = 'test_plaintext'
    secret = 'test'
    ciphertext = vault.encrypt(plaintext, secret)
    test_vault_unicode = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    test_vault_unicode.vault = vault  # adding vault for decryption
    test_vault_unicode.center(10, '-')  # calling center method of class AnsibleVaultEncryptedUnicode
    assert test_vault_unicode._ciphertext == ciphertext
    assert test_vault_unicode.data == plaintext


# Generated at 2022-06-23 05:48:06.042387
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    assert AnsibleVaultEncryptedUnicode('a').ljust(3) == 'a  '



# Generated at 2022-06-23 05:48:16.149611
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    # https://github.com/ansible/ansible/issues/12663
    # Reported by @thbkrkr
    #
    # This bug only happens when C locale is used.
    s = AnsibleVaultEncryptedUnicode("\xE9")
    assert s.title() == '\xC9'
    assert s.title() == '\xC9'  # See if it is cached well
    # Same bug occurs in casefold(), upper(), and lower()
    # I'm not checking them because we don't use the methods.

test_AnsibleVaultEncryptedUnicode_title()

#
# For testing the above, you need to have libyaml-dev installed;
# you can use the --with-libyaml configure flag to build with libyaml support
#


# Generated at 2022-06-23 05:48:21.685564
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    """
    Test the str method for a simple string
    """
    vault = mock.Mock()
    vault.configure_mock(**{'is_encrypted.return_value': False, 'decrypt.return_value': 'simple'})
    avec = AnsibleVaultEncryptedUnicode("!vault |\n          12345")
    avec.vault = vault
    assert str(avec) == 'simple'


# Generated at 2022-06-23 05:48:28.291471
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import crypt
    from vaultlib import VaultLib
    vault = VaultLib(crypt.get_crypt_method())

    av = AnsibleVaultEncryptedUnicode.from_plaintext('Slice of Apple Pie', vault, 'password')
    av2 = AnsibleVaultEncryptedUnicode.from_plaintext('Slices of Apple Pie', vault, 'password')

    assert av != av2


# Generated at 2022-06-23 05:48:37.350311
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    x = AnsibleVaultEncryptedUnicode('abcdefghijklmnopqrstuvwxyz0123456789')
    y = AnsibleVaultEncryptedUnicode('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')
    assert x.translate(dict.fromkeys(map(ord, 'abcdefghijklmn'), 'ABCDEFGHIJKLMN')) == AnsibleVaultEncryptedUnicode('ABCDEFGHIJKLMNopqrstuvwxyz0123456789')

# Generated at 2022-06-23 05:48:44.641492
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    try:
        index(["a", "b", "c"], "b")
    except NameError:
        def index(obj, item):
            return obj.index(item)
    assert index(AnsibleVaultEncryptedUnicode("abc"), "a") == 0
    assert index(AnsibleVaultEncryptedUnicode("abc"), "b") == 1
    assert index(AnsibleVaultEncryptedUnicode("abc"), "c") == 2
    try:
        index(AnsibleVaultEncryptedUnicode("abc"), "d")
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-23 05:48:51.189372
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    class MockVault(object):
        def encrypt(self, string, secret):
            return string

        def decrypt(self, string, secret):
            return string

    vault = MockVault()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello world', vault, None)
    avu.vault = vault
    assert hash('hello world') == hash(avu)

# Generated at 2022-06-23 05:48:57.986927
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    '''
    This method tests whether the is_alpha functionality of the AnsibleVaultEncryptedUnicode
    class is working or not.

    Arguments: None
    Returns: None
    '''
    raw_unencrypted_string = 'Hello World'
    ansible_vault_encrypted_string = AnsibleVaultEncryptedUnicode(raw_unencrypted_string)
    assert ansible_vault_encrypted_string.isalpha() == True

test_AnsibleVaultEncryptedUnicode_isalpha()


# Generated at 2022-06-23 05:49:09.019332
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    assert AnsibleVaultEncryptedUnicode(u'abc').startswith('a')
    assert AnsibleVaultEncryptedUnicode(u'abc').startswith('ab')
    assert not AnsibleVaultEncryptedUnicode(u'abc').startswith('b')

    assert AnsibleVaultEncryptedUnicode(u'abc').startswith(u'a')
    assert AnsibleVaultEncryptedUnicode(u'abc').startswith(u'ab')
    assert not AnsibleVaultEncryptedUnicode(u'abc').startswith(u'b')

    assert AnsibleVaultEncryptedUnicode(u'abc').startswith(u'a', 0)

# Generated at 2022-06-23 05:49:11.403634
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    assert AnsibleVaultEncryptedUnicode('abc').center(10) == '   abc    '

# Generated at 2022-06-23 05:49:19.255409
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    class Vault:
        '''Dummy Vault class'''
        class AnsibleVaultError(Exception):
            pass

        def decrypt(self, ciphertext, obj=None):
            return to_bytes(ciphertext)

    avu = AnsibleVaultEncryptedUnicode(b'encrypted text')
    avu.vault = Vault()

    output = repr(avu)
    assert output == 'encrypted text'

yaml.add_constructor(u'!vault', AnsibleVaultEncryptedUnicode.from_plaintext)
yaml.add_multi_constructor(u'!vault', AnsibleVaultEncryptedUnicode.from_plaintext)



# Generated at 2022-06-23 05:49:27.082972
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:49:37.678057
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    test_input = "abcdefabcdefabcdefabcdefabcdefabcdefabcdef"
    test_passwd = "foobar"
    test_class = AnsibleVaultEncryptedUnicode

    from ansible.parsing.vault import VaultLib
    vault = VaultLib(test_passwd)
    e = vault.encrypt(test_input)

    o = test_class(e)
    o.vault = vault
    assert o.partition("de") == ("abc", "de", "fabcdefabcdefabcdefabcdefabcdefabcdefabc")

    e = vault.encrypt("abcde")
    o = test_class(e)
    o.vault = vault
    assert o.partition("de") == ("abc", "de", "")

# Generated at 2022-06-23 05:49:40.379687
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    assert AnsibleVaultEncryptedUnicode('foo') > AnsibleVaultEncryptedUnicode('bar')
    assert AnsibleVaultEncryptedUnicode('foo') > 'bar'

# Generated at 2022-06-23 05:49:46.597701
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    x = AnsibleVaultEncryptedUnicode("P@ssw0rd")
    y = AnsibleVaultEncryptedUnicode("P@ssw0rd")

    assert hash(x) == hash(y)

    z = "P@ssw0rd"

    assert hash(x) == hash(z)



# Generated at 2022-06-23 05:49:53.454759
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    #Given
    ciphertext = "example string with tabs"
    tabsize = 7

    #When
    encrypted_text = AnsibleVaultEncryptedUnicode(ciphertext)

    #Then
    assert(encrypted_text.expandtabs(tabsize) == "example string with tabs")



# Generated at 2022-06-23 05:50:03.189372
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    from ansible.parsing.vault import VaultLib

    # Generate password
    password = "".join(VaultLib.generate_password())
    # Instantiate vault
    vault = VaultLib(password=password)

    # Instantiate a secret
    secret = AnsibleVaultEncryptedUnicode.from_plaintext("secret", vault, password)

    # Test that secret is encrypted
    assert(secret.is_encrypted() == True)

    # Test that secret starts with "secre"
    assert(secret.startswith("secre") == True)

    # Test that secret ends with "cret"
    assert(secret.endswith("cret") == True)

    # Test that secret find index of "r"
    assert(secret.find("r") == 3)

    # Test that secret rfind index of "

# Generated at 2022-06-23 05:50:13.140893
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    try:
        from ansible_vault import Vault
    except ImportError:
        # Cannot run unit test of AnsibleVaultEncryptedUnicode
        # without having ansible-vault installed
        return

    vault = Vault(None, 'test')
    ciphertext = vault.encrypt('test data')
    string = AnsibleVaultEncryptedUnicode(ciphertext)
    string.vault = vault

    __, sep, __ = string.partition('data')
    assert sep == 'data'

    __, sep, __ = string.partition('DATA')
    assert sep == ''

    __, sep, __ = string.partition('notfound')
    assert sep == ''



# Generated at 2022-06-23 05:50:21.048846
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    avu = AnsibleVaultEncryptedUnicode('secret:secret')
    assert (avu.split(':')[0] == 'secret')
    assert (avu.split(':')[1] == 'secret')
    assert (avu.split(':', 1)[0] == 'secret')
    assert (avu.split(':', 1)[1] == 'secret')
    assert (avu.split(':', 2)[0] == 'secret')
    assert (avu.split(':', 2)[1] == 'secret')
    avu = AnsibleVaultEncryptedUnicode('a:b:c:d')
    assert (avu.split(':') == ['a', 'b', 'c', 'd'])

# Generated at 2022-06-23 05:50:31.908500
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    # This is an example test method.
    # It should be replaced with the unit tests needed to test
    # class AnsibleVaultEncryptedUnicode and its methods.
    from ansiblevault import VaultLib

    secret = 'hjklahgljhglgjhlghjhgjhgljghljghljjhgljhg'
    vault = VaultLib(password=secret)
    encrypted_string = '!vault |' + vault.encrypt('Hello World!!!\n')
    s = AnsibleVaultEncryptedUnicode(encrypted_string)
    s.vault = vault
    assert s.__str__() == 'Hello World!!!\n'


# Generated at 2022-06-23 05:50:42.382946
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():

    # Python 3.7.2
    assert AnsibleVaultEncryptedUnicode('abc').isascii()
    assert AnsibleVaultEncryptedUnicode('\u00C5').isascii()
    assert not AnsibleVaultEncryptedUnicode('\u00E4').isascii()
    assert not AnsibleVaultEncryptedUnicode('\u00F6').isascii()
    assert not AnsibleVaultEncryptedUnicode('\u00FC').isascii()
    assert AnsibleVaultEncryptedUnicode('\u00C5').isascii()
    assert AnsibleVaultEncryptedUnicode('a\u00C5').isascii()
    assert not AnsibleVaultEncryptedUnicode('\u00E4').isascii

# Generated at 2022-06-23 05:50:45.230478
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    u = AnsibleVaultEncryptedUnicode(u'')
    m = dict(name='George')
    actual = u.format_map(m)
    expected = u''
    assert actual == expected


# Generated at 2022-06-23 05:50:54.820033
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    '''
    Runs a series of tests for the join() method
    '''

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_vault_secret
    import types
    import sys

    # Create a generator/iterator for a list of strings
    def string_generator():
        for s in ['a', 'b', 'c']:
            yield s

    # Create a generator/iterator for a list of integers
    def int_generator():
        for i in [1, 2, 3]:
            yield i

    # Create a generator/iterator for a list of AnsibleVaultEncryptedUnicode
    def avu_generator():
        vault_password_file = get_vault_secret('vault_test.key')

# Generated at 2022-06-23 05:51:07.567635
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    # Test a basic usage of the method
    plaintext = 'foo'
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256;ansible\n35356234613961333462613238346531666535343964633265383738313065643834386330623435\n6362626163346265303737643839393630663130363431653237363465333162343132653739396236\n6237643361653239656665626531663638663139363239353761323139316261336535333831343864\n383066386332666262\n'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, None, 'ansible')
   

# Generated at 2022-06-23 05:51:14.144589
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    class TestVault(object):
        def encrypt(self, plaintext, secret):
            return plaintext

        def decrypt(self, ciphertext, obj):
            return ciphertext

        def is_encrypted(self, ciphertext):
            return True

    vault = TestVault()
    secret = 'secret'
    plaintext = 'abcabcabcafababcabcabcabcabcabcabcabcabcabc'
    avueu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert plaintext.count('abc', 1, 30) == avueu.count('abc', 1, 30)



# Generated at 2022-06-23 05:51:19.079062
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    assert AnsibleUnicode(u'test') == u'test'
    assert isinstance(AnsibleUnicode(u'test'), AnsibleUnicode)
    assert AnsibleUnicode(u'test').ansible_pos == (None, 0, 0)


# Generated at 2022-06-23 05:51:28.070842
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    # Test modulos with string constant arguments
    assert 'one: 1' == 'one: %s' % AnsibleVaultEncryptedUnicode('1')
    assert 'one: a' == 'one: %s' % AnsibleVaultEncryptedUnicode('a')
    assert 'one: True' == 'one: %s' % AnsibleVaultEncryptedUnicode('True')
    assert 'one: none' == 'one: %s' % AnsibleVaultEncryptedUnicode('none')
    assert 'one: 1' == 'one: %s' % AnsibleVaultEncryptedUnicode(1)
    assert 'one: 1.1' == 'one: %s' % AnsibleVaultEncryptedUnicode(1.1)


# Generated at 2022-06-23 05:51:39.602720
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    import tempfile
    from ansible.parsing.vault import VaultLib

    # Encrypt with ansible-vault
    password_file = tempfile.NamedTemporaryFile().name
    with open(password_file, 'w') as f:
        f.write("top_secret\n")

    ansible_vault_cmd = 'ansible-vault'
    if sys.platform.startswith('win') and ('ANSIBLE_VAULT' in _sys.argv[0] or 'ANSIBLE_VAULT.PY' in _sys.argv[0]):
        ansible_vault_cmd = 'ansible-vault.exe'

    stdout = _sys.stdout
    _sys.stdout = open('/dev/null', 'w')

# Generated at 2022-06-23 05:51:44.671676
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():

    # Setup
    # Test is an AnsibleVaultEncryptedUnicode('test')
    Test = AnsibleVaultEncryptedUnicode('test')

    # Expected result
    expected_result = ['test']

    # Actual result
    actual_result = Test.rsplit()

    # Check
    assert actual_result == expected_result



# Generated at 2022-06-23 05:51:53.323946
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:51:58.820459
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    # test that all characters in string.whitespace are recognized as whitespace
    for c in ' \t\n\r\v\f':
        unicode_obj = AnsibleVaultEncryptedUnicode('a%sa' % c)
        assert not unicode_obj.isspace()
        assert unicode_obj[1].isspace()
        assert not unicode_obj[3].isspace()
    # test that non-whitespace characters are correctly recognized
    unicode_obj = AnsibleVaultEncryptedUnicode('a b')
    assert not unicode_obj[0].isspace()
    assert not unicode_obj[2].isspace()


# Generated at 2022-06-23 05:52:05.350218
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    assert AnsibleVaultEncryptedUnicode(b'\nHello, world.\n').rstrip() == u'\nHello, world.'
    assert AnsibleVaultEncryptedUnicode(b'\nHello, world.\n').rstrip(b'.') == u'\nHello, world'
    assert AnsibleVaultEncryptedUnicode(b'\nHello, world.\n').rstrip(b'\n') == u'\nHello, world.'



# Generated at 2022-06-23 05:52:13.956708
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    # Tests for method isalpha (self)
    # Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
    assert AnsibleVaultEncryptedUnicode(u'thisisaplaintextpassphrase').isalpha()
    assert AnsibleVaultEncryptedUnicode(u'123').isalpha() == False
    assert AnsibleVaultEncryptedUnicode(u'123abc').isalpha() == False
    assert AnsibleVaultEncryptedUnicode(u'abc123').isalpha() == False
    assert AnsibleVaultEncryptedUnicode(u'').isalpha()


# Generated at 2022-06-23 05:52:15.908906
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    seq = AnsibleSequence()
    assert isinstance(seq, AnsibleSequence)
    assert isinstance(seq, list)



# Generated at 2022-06-23 05:52:20.446919
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    # load the vault
    password = 'dummy_password'
    vault = vaultlib.VaultLib(password)

    # create some encrypted strings
    seq = '1234567890'
    secret = vault.encrypt(seq, password)
    avu = AnsibleVaultEncryptedUnicode(secret)
    avu.vault = vault

    # test
    assert avu[0] == seq[0]
    assert avu[-1] == seq[-1]
