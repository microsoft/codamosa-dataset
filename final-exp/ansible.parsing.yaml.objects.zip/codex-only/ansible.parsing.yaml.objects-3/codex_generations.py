

# Generated at 2022-06-23 05:42:25.464141
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    avue = AnsibleVaultEncryptedUnicode('    hello')
    assert avue.lstrip(' ') == 'hello'
    avue = AnsibleVaultEncryptedUnicode('hello')
    assert avue.lstrip(' ') == 'hello'
    avue = AnsibleVaultEncryptedUnicode('')
    assert avue.lstrip(' ') == ''


# Generated at 2022-06-23 05:42:27.977734
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    source = "AaBbCcDd"
    assert AnsibleVaultEncryptedUnicode(source).casefold() == "aabbccdd"


# Generated at 2022-06-23 05:42:36.984563
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    """ unit test for AnsibleVaultEncryptedUnicode.isidentifier """

    # check it is not restricted to alphanumeric characters
    avu = AnsibleVaultEncryptedUnicode('_foo')
    assert avu.isidentifier() == '_foo'.isidentifier()
    avu = AnsibleVaultEncryptedUnicode('_f00')
    assert avu.isidentifier() == '_f00'.isidentifier()

    # check it is not restricted to an ascii string
    avu = AnsibleVaultEncryptedUnicode('föö')
    assert avu.isidentifier() == 'föö'.isidentifier()
    # ansible-vault decrypt: no longer using UTF-8 as default
    # assert avu.isidentifier() == True



# Generated at 2022-06-23 05:42:46.357826
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    assert (AnsibleVaultEncryptedUnicode('Abc')).center(1) == 'Abc'
    assert (AnsibleVaultEncryptedUnicode('Abc')).center(2) == 'Abc'
    assert (AnsibleVaultEncryptedUnicode('Abc')).center(3) == 'Abc'
    assert (AnsibleVaultEncryptedUnicode('Abc')).center(4) == ' Abc'
    assert (AnsibleVaultEncryptedUnicode('Abc')).center(5) == ' Abc '


# Generated at 2022-06-23 05:42:51.125560
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    u = AnsibleVaultEncryptedUnicode(u'\u00e9')
    assert u.encode().decode('latin-1') == u'\u00e9'
    assert u.encode() == b'\xc3\xa9'
    assert u.encode('latin-1') == b'\xe9'



# Generated at 2022-06-23 05:43:00.318183
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    def test_function(veu):
        assert veu.data == u'a, b, c, d'
        assert veu.rsplit() == [u'a,', u'b,', u'c,', u'd']
        assert veu.rsplit(',') == [u'a,', u'b,', u'c,', u'd']
        assert veu.rsplit(',', 1) == [u'a, b, c, d']
        assert veu.rsplit(',', 2) == [u'a, b, c', u'd']

    veu = AnsibleVaultEncryptedUnicode(u'a, b, c, d')
    test_function(veu)


# Generated at 2022-06-23 05:43:08.870555
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    l1 = [1, 2, 3]
    l2 = [4, 5, 6]
    l3 = [7, 8, 9]
    my_dict = {'x': l1, 'y': l2, 'z': l3}
    my_template = '{x[2]} {y[1]} {z[0]}'
    my_expected_answer = '3 5 7'

    assert my_expected_answer == my_template.format_map(my_dict)

    my_vault = AnsibleVaultEncryptedUnicode(b'blahblahblah')
    my_vault.data = my_template
    assert my_expected_answer == my_vault.format_map(my_dict)


# Generated at 2022-06-23 05:43:21.603008
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('test')

    # test binary
    iv = '\x01\x02'
    key = '\x01\x02\x03\x04\x05\x06\x07\x08\x01\x02\x03\x04\x05\x06\x07\x08'
    salt = '\x0a\x0b\x0c\x0d\x0e\x0f\x10\x11\x0a\x0b\x0c\x0d\x0e\x0f\x10\x11'
    plaintext = '24'

# Generated at 2022-06-23 05:43:26.831227
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    plaintext = 'my_plaintext'
    secret = 'secret'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()


# Generated at 2022-06-23 05:43:37.248046
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    # Check what happens if encrypted and unencrypted parts separate the search string
    x =  AnsibleVaultEncryptedUnicode.from_plaintext(u'a,b,c', None, None)
    assert x.partition(',') == (u'a', u',', u'b,c')
    assert x.partition('c') == (u'a,b,', u'c', u'')
    # Check what happens if search string is in encrypted and unencrypted parts
    x =  AnsibleVaultEncryptedUnicode.from_plaintext(u'asdf,b,c', None, None)
    assert x.partition(',') == (u'asdf', u',', u'b,c')

# Generated at 2022-06-23 05:43:47.901578
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    # Test if behavior is same as that of regular string.
    s = AnsibleVaultEncryptedUnicode('   spacious   ')
    assert s.rstrip() == '   spacious'
    assert s.rstrip(' \t') == '   spacious'
    assert s.rstrip(' \t') == '   spacious'
    assert s.rstrip('spa') == '   spacious'
    assert s.rstrip('zp') == '   spacious'

    # Test if behavior is same as that of regular string.
    s = AnsibleVaultEncryptedUnicode('mississippi')
    assert s.rstrip('ipz') == 'mississ'

    # Test if behavior is same as that of regular string.
    s = AnsibleVaultEncryptedUnicode('')
    assert s.rstrip() == ''

   

# Generated at 2022-06-23 05:43:51.894439
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    b = AnsibleBaseYAMLObject()
    assert(b.ansible_pos == (None, 0, 0))
    b = AnsibleBaseYAMLObject(src='source', line=1, col=2)
    assert(b.ansible_pos == ('source', 1, 2))

# Generated at 2022-06-23 05:43:59.814219
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    """
    Test method isdecimal of class AnsibleVaultEncryptedUnicode for various input strings
    """
    # Test for empty string
    assert AnsibleVaultEncryptedUnicode(b'').isdecimal() == False
    # Test for strings with non decimal characters
    assert AnsibleVaultEncryptedUnicode(b'a0').isdecimal() == False
    assert AnsibleVaultEncryptedUnicode(b'A0').isdecimal() == False
    assert AnsibleVaultEncryptedUnicode(b'aB').isdecimal() == False
    assert AnsibleVaultEncryptedUnicode(b'aBc').isdecimal() == False
    assert AnsibleVaultEncryptedUnicode(b'0aB').isdecimal() == False
    assert AnsibleVaultEncryptedUnic

# Generated at 2022-06-23 05:44:09.186532
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # This test is based on 2.7.12
    # Encrypted string should not be equal to plain string
    plain = 'this should not match'
    encrypted = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;9.9.9;AES256\n383334656666656433353665373735643435336437356365313461333232653564653138633961\n373733643965323135616331346262636130666566663339\n')
    assert(encrypted != plain)
    assert(not (encrypted == plain))


# Generated at 2022-06-23 05:44:19.401736
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():

    # This string is surrogate escaped in to bytes
    string_bytes = to_bytes(u'\udc80')

    # Make sure that surrogate escaping occurs
    if not isinstance(string_bytes, bytes):
        raise AssertionError('Test string failed to surrogate escape')

    avu = AnsibleVaultEncryptedUnicode(string_bytes)
    test_out = avu.encode(encoding='ascii')

    if test_out == string_bytes:
        raise AssertionError('AnsibleVaultEncryptedUnicode.encode did not encode string')

    if test_out == avu.encode():
        raise AssertionError('AnsibleVaultEncryptedUnicode.encode failed to encode string with default parameters')


# Generated at 2022-06-23 05:44:29.328159
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib

    sec = VaultLib([])
    s = AnsibleVaultEncryptedUnicode.from_plaintext(b'foobar', sec, b'1763')
    assert s.count(b'foo') == 1
    assert s.count(b'bar') == 1
    assert s.count(b'baz') == 0
    assert s.count(b'qux') == 0
    assert s.count(b'foo', 1) == 0
    assert s.count(b'bar', 0, 6) == 1
    assert s.count(b'baz', 0, 7) == 0
    assert s.count(b'qux', 0, 7) == 0



# Generated at 2022-06-23 05:44:30.319304
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    pass



# Generated at 2022-06-23 05:44:41.043586
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:44:48.739395
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    avu = AnsibleVaultEncryptedUnicode('abcde12345abcde')
    assert len(avu.rsplit('1')) == 3
    assert avu.rsplit('1')[0] == 'abcde12345abcde'
    assert avu.rsplit('1')[1] == ''
    assert avu.rsplit('1')[2] == ''
    assert len(avu.rsplit('a')) == 2
    assert avu.rsplit('a')[0] == 'abcde12345'
    assert avu.rsplit('a')[1] == 'bcde'
    assert len(avu.rsplit('A')) == 2
    assert avu.rsplit('A')[0] == 'abcde12345abcde'

# Generated at 2022-06-23 05:44:55.533797
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    assert AnsibleVaultEncryptedUnicode('abc').zfill(5) == '00abc'
    assert AnsibleVaultEncryptedUnicode('-2').zfill(5) == '-0002'
    assert AnsibleVaultEncryptedUnicode('+2').zfill(5) == '+0002'
    assert AnsibleVaultEncryptedUnicode('abc').zfill(2) == 'abc'
    assert AnsibleVaultEncryptedUnicode('abc').zfill(1) == 'abc'
    assert AnsibleVaultEncryptedUnicode('+2').zfill(1) == '+2'



# Generated at 2022-06-23 05:45:05.128472
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256\n36613766393462313330636438326436663933346637313261386564323365386433653361323338\n35623831396134323633363464663336353562663166633033353734383662386332326462633330\n3533643666396439316162373432616538336632616231376133\n'
    vault = vaultlib.VaultLib(b'pansible')

    # Test 1
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    assert(avu.rjust(6) == '  pansible')

    # Test 2
    av

# Generated at 2022-06-23 05:45:11.098164
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    assert not AnsibleVaultEncryptedUnicode('abc').isnumeric()
    assert AnsibleVaultEncryptedUnicode(u'123').isnumeric()


# Generated at 2022-06-23 05:45:16.456054
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    value = '1234'
    result = AnsibleVaultEncryptedUnicode(value)
    expected = value
    assert result.zfill(8) == expected
    value = '1.234'
    result = AnsibleVaultEncryptedUnicode(value)
    expected = '0001.234'
    assert result.zfill(8) == expected


# Generated at 2022-06-23 05:45:27.962391
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib("mypassword")
    secret = "mypassword"
    s = "this is a secret"
    v1 = AnsibleVaultEncryptedUnicode.from_plaintext(s, vault, secret)
    v2 = AnsibleVaultEncryptedUnicode.from_plaintext("this is not a secret", vault, secret)
    assert v1 == s
    assert not v2 == s


yaml.constructor.BaseConstructor.add_constructor(
    u'tag:yaml.org,2002:map',
    type(AnsibleMapping).__new__
)


# Generated at 2022-06-23 05:45:32.375393
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    assert AnsibleVaultEncryptedUnicode.__mod__('', '') == ''

    assert AnsibleVaultEncryptedUnicode.__mod__('%s', '') == ''
    assert AnsibleVaultEncryptedUnicode.__mod__('%s', 'hello') == 'hello'

    assert AnsibleVaultEncryptedUnicode.__mod__('%d %d %d', [1, 2, 3]) == '1 2 3'
    assert AnsibleVaultEncryptedUnicode.__mod__('%d %d %d', (1, 2, 3)) == '1 2 3'
    assert AnsibleVaultEncryptedUnicode.__mod__('%d %s %s', [1, 'hello', 'world']) == '1 hello world'

# Generated at 2022-06-23 05:45:43.490081
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    class MockVault(object):
        def is_encrypted(self, data):
            return True
        def decrypt(self, data, obj=None):
            return 'ansible_secret'
    vault = MockVault()

    # the method .rfind() exists in class AnsibleVaultEncryptedUnicode
    assert hasattr(AnsibleVaultEncryptedUnicode, 'rfind')

    # the method .rfind() of class AnsibleVaultEncryptedUnicode returns a numeric result
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('my_ansible_secret', vault, 'my_ansible_secret')
    assert avu.rfind('ansible_secret') == 6

    # the method .rfind() of class AnsibleVaultEncryptedUnicode returns a numeric result
    av

# Generated at 2022-06-23 05:45:47.925287
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    avu = AnsibleVaultEncryptedUnicode(u'(42+0j)')
    expected_value = 42+0j
    assert avu.__complex__() == expected_value


# Generated at 2022-06-23 05:45:51.353226
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    avu = AnsibleVaultEncryptedUnicode(to_bytes('foo'))
    expected = avu.center(5)
    assert '  foo  ' == expected


# Generated at 2022-06-23 05:45:53.706364
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    x = AnsibleVaultEncryptedUnicode('   123')
    assert x.lstrip() == '123'


# Generated at 2022-06-23 05:46:04.246980
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    secret = b'this is a secret'
    cipher_text = b'$ANSIBLE_VAULT;1.1;AES256\n33363835643935343634343635633232656162353864373436376231613130633038613433616662310a3737626235626430373966633561663232616132313331336661663064663933643438306431620a643162373064373335643361626233313165666534366639366463336535376162363264336130\n'
    avu = AnsibleVaultEncryptedUnicode(cipher_text)
    avu.vault = vault
    avu.data = secret

# Generated at 2022-06-23 05:46:14.443002
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    # Tests passing str values
    assert AnsibleVaultEncryptedUnicode(b'foo').isprintable() == True
    assert AnsibleVaultEncryptedUnicode(b'f\no\no').isprintable() == False
    assert AnsibleVaultEncryptedUnicode(b'foo\n').isprintable() == False
    assert AnsibleVaultEncryptedUnicode(b'foo\r').isprintable() == False
    assert AnsibleVaultEncryptedUnicode(b'foo\t').isprintable() == False
    # Tests passing text values
    assert AnsibleVaultEncryptedUnicode(u'foo').isprintable() == True
    assert AnsibleVaultEncryptedUnicode(u'f\no\no').isprintable() == False
    assert AnsibleVaultEncryptedUnic

# Generated at 2022-06-23 05:46:24.638444
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    import unittest
    from ansible.parsing.vault import VaultLib

    class TestAnsibleVaultEncryptedUnicode(unittest.TestCase):

        def setUp(self):
            self.key = 'thisisakey'
            self.vault = VaultLib(self.key)
            self.vault_encrypted_unicode = AnsibleVaultEncryptedUnicode.from_plaintext('thisisatest', self.vault, self.key)
            self.vault_encrypted_unicode.vault = self.vault

        def test_start_lower(self):
            val = self.vault_encrypted_unicode.__getslice__(start=0, end=1)
            self.assertEquals(val, 't')


# Generated at 2022-06-23 05:46:35.885794
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:46:41.500645
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    try:
        original_len = len
        len = AnsibleVaultEncryptedUnicode.__len__
        assert len(AnsibleVaultEncryptedUnicode('foo')) == 3
    finally:
        AnsibleVaultEncryptedUnicode.__len__ = len
        len = original_len



# Generated at 2022-06-23 05:46:51.400617
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    # Make sure digits are preserved
    assert AnsibleVaultEncryptedUnicode('1234').zfill(5) == '1234'
    # Make sure leading alpha characters are preserved
    assert AnsibleVaultEncryptedUnicode('abc123').zfill(8) == 'abc123'
    # Make sure leading '-' is preserved
    assert AnsibleVaultEncryptedUnicode('-1234').zfill(6) == '-1234'
    # Make sure leading '+' is preserved
    assert AnsibleVaultEncryptedUnicode('+1234').zfill(6) == '+1234'
    # Make sure leading ' ' is preserved
    assert AnsibleVaultEncryptedUnicode(' 1234').zfill(6) == ' 1234'
    # Make sure leading '0x' is preserved
    assert Ansible

# Generated at 2022-06-23 05:47:01.986040
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    s = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert s.isalpha() == True
    assert AnsibleVaultEncryptedUnicode.from_plaintext(s, None, 'secret').isalpha() == True

    s = '0123456789'
    assert s.isalpha() == False
    assert AnsibleVaultEncryptedUnicode.from_plaintext(s, None, 'secret').isalpha() == False

    s = '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
    assert s.isalpha() == False
    assert AnsibleVaultEncryptedUnicode.from_plaintext(s, None, 'secret').isalpha() == False



# Generated at 2022-06-23 05:47:04.234217
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    aveu = AnsibleVaultEncryptedUnicode.from_plaintext('my_password', vault=None, secret='password')
    aveu.upper()
    return None

# Generated at 2022-06-23 05:47:13.100710
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault_password = 'password123'

    # String with no character
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('', VaultLib(vault_password))
    assert avu1.rindex('') == 0
    assert avu1.rindex('', 0, 0) == 0
    # String with one character
    assert avu1.rindex('0') == -1
    assert avu1.rindex('0', 0, 0) == -1
    # String with multiple characters
    assert avu1.rindex('012345') == -1
    assert av

# Generated at 2022-06-23 05:47:21.122673
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    # test for negative number
    assert AnsibleVaultEncryptedUnicode('-182').isdecimal() == False
    # test for positive number
    assert AnsibleVaultEncryptedUnicode('182').isdecimal() == True
    # test for string with type char
    assert AnsibleVaultEncryptedUnicode('abcd').isdecimal() == False
    # test for string with type char number
    assert AnsibleVaultEncryptedUnicode('a17b').isdecimal() == False
    # test for string with type char special character
    assert AnsibleVaultEncryptedUnicode('a!@#').isdecimal() == False



# Generated at 2022-06-23 05:47:27.110230
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    plaintext = 'I use Ansible Vault! It is a pleasure to develop.'
    secret = 'password'
    vault = vaultlib.VaultLib(secret.encode('utf-8'))
    encrypted_text = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    decrypted_text = to_text(encrypted_text[0:6])

    assert decrypted_text == 'I use '
    print('Check "I use" in "%s"' % decrypted_text)



# Generated at 2022-06-23 05:47:29.764450
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    s = "THIS IS STRING EXAMPLE....WOW!!!"
    assert AnsibleVaultEncryptedUnicode(s).isupper() == s.isupper()


# Generated at 2022-06-23 05:47:35.556062
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    avu = AnsibleVaultEncryptedUnicode(b'[test]\na=1\n    b=2\nc=3\n')
    avu = avu.rstrip()
    assert avu == AnsibleVaultEncryptedUnicode(b'[test]\na=1\n    b=2\nc=3')



# Generated at 2022-06-23 05:47:41.496345
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    assert len(AnsibleVaultEncryptedUnicode('abc').rjust(20)) == 20

    assert len(AnsibleVaultEncryptedUnicode('abc').rjust(20, 'a')) == 20

    assert len(AnsibleVaultEncryptedUnicode('abc').rjust(20, AnsibleVaultEncryptedUnicode('a'))) == 20

    assert len(AnsibleVaultEncryptedUnicode('abc').rjust(20, 'ab')) == 20


# Generated at 2022-06-23 05:47:52.059395
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:48:02.988795
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:48:09.959848
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    for i in range(0, len(source_str)):
        # Test indexing from the left
        if source_str[i] != decrypted_str[i]:
            print ('test failed: AnsibleVaultEncryptedUnicode__getitem__[%d], got "%s", expected "%s"' %
                   (i, source_str[i], decrypted_str[i]))
            return 1

        # Test indexing from the right

# Generated at 2022-06-23 05:48:21.440960
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    assert AnsibleVaultEncryptedUnicode("123").isnumeric() is True
    assert AnsibleVaultEncryptedUnicode("123").isnumeric() is not False
    assert AnsibleVaultEncryptedUnicode("123").isnumeric() is not None
    assert AnsibleVaultEncryptedUnicode("123").isnumeric() is not True
    assert AnsibleVaultEncryptedUnicode("abc").isnumeric() is False
    assert AnsibleVaultEncryptedUnicode("abc").isnumeric() is not True
    assert AnsibleVaultEncryptedUnicode("abc").isnumeric() is not None
    assert AnsibleVaultEncryptedUnicode("abc").isnumeric() is not False
    assert AnsibleVaultEncryptedUnicode("123").isnumeric() is not None
    assert Ans

# Generated at 2022-06-23 05:48:32.714493
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
  encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext('a', None, None)
  encrypted_string.ansible_pos = ('test source', 0, 0)
  assert encrypted_string == 'a'
  assert encrypted_string != 'b'


# ansible_word_re <- this is an import, but due to its complexity it cannot be eval'ed

# STUPID YAML LOADS HACK
#
# This is a hack to work around a corner case of the yaml module.  The problem is as follows:
#
# 1) bool and int are a subclass of scalar, due to the way the yaml module is written.
# 2) The default yaml constructor is yaml.BaseConstructor, which is a subclass of yaml.SafeConstructor
# 3) In the yaml.SafeConstructor class

# Generated at 2022-06-23 05:48:35.836013
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    import sys
    avu = AnsibleVaultEncryptedUnicode('Sorry, no tests.')
    if sys.version_info >= (3,):
        assert avu.__float__() == 0.0
    else:
        assert avu.__float__() == 0



# Generated at 2022-06-23 05:48:43.763668
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    """ Unit testing AnsibleVaultEncryptedUnicode.lower() """

    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault.secret = 'test_vault_secret'
    if vault.is_encrypted('$ANSIBLE_VAULT|1.1|AES256|dGhpdCBpcyBhIHNlY3JldA=='):
        ciphertext = '$ANSIBLE_VAULT|1.1|AES256|dGhpdCBpcyBhIHNlY3JldA=='
    else:
        ciphertext = vault.encrypt('this is a secret', vault.secret)

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.lower()

# Generated at 2022-06-23 05:48:49.074941
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    test_string1 = AnsibleVaultEncryptedUnicode("This Is A Title")
    assert test_string1.istitle() == True
    test_string2 = AnsibleVaultEncryptedUnicode("This Is NOT A Title")
    assert test_string2.istitle() == False


# Generated at 2022-06-23 05:48:58.917611
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    avu = AnsibleVaultEncryptedUnicode("!vault |\n      $ANSIBLE_VAULT;1.1;AES256\n      39336262656131643833396239363863633535393362326563356238643131303464303338666130\n      62313461316663373264666535363764333336653339386531653661626636336662313166626635\n      66656134\n")
    assert False == avu.isalnum()

# Generated at 2022-06-23 05:49:09.521955
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    failed = False
    avu = AnsibleVaultEncryptedUnicode("ansible")
    if avu.isprintable():
        failed = True
    avu = AnsibleVaultEncryptedUnicode("ansible\f")
    if avu.isprintable():
        failed = True
    avu = AnsibleVaultEncryptedUnicode("ansible\n")
    if avu.isprintable():
        failed = True
    avu = AnsibleVaultEncryptedUnicode("ansible\r")
    if avu.isprintable():
        failed = True
    avu = AnsibleVaultEncryptedUnicode("ansible\t")
    if avu.isprintable():
        failed = True
    avu = AnsibleVaultEncryptedUnicode("ansible\v")
   

# Generated at 2022-06-23 05:49:16.586198
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Setup
    ciphertext1 = "Blah Blah Blah"
    ciphertext2 = "Foo Foo Foo"
    # Exercise
    encrypted_unicode1 = AnsibleVaultEncryptedUnicode(ciphertext1)
    encrypted_unicode2 = AnsibleVaultEncryptedUnicode(ciphertext2)
    # Verify
    assert not encrypted_unicode1.__gt__(encrypted_unicode2)
    assert encrypted_unicode2.__gt__(encrypted_unicode1)

# Generated at 2022-06-23 05:49:19.560408
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    a_vault = AnsibleVaultEncryptedUnicode("strip\n")
    assert a_vault.rstrip() == "strip"


# Generated at 2022-06-23 05:49:23.879802
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    encrypted = AnsibleVaultEncryptedUnicode('abc\tdef\tghi')
    assert encrypted.expandtabs(1) == 'abc def ghi'
    assert encrypted.expandtabs(2) == 'abc  def  ghi'

# Generated at 2022-06-23 05:49:32.722196
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
  from ansible.parsing.vault import VaultEditor
  from ansible.parsing.vault import VaultLib
  from ansible.parsing.vault import AnsibleVaultError
  from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
  import os

  TEST_DATA = b'abc'

# Generated at 2022-06-23 05:49:42.892847
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    avue = AnsibleVaultEncryptedUnicode("&a")
    avue.vault = None
    print("*** rindex with invalid vault ***")
    try:
        avue.rindex("a")
    except AttributeError as err:
        print("AttributeError raised as expected: {0}".format(err))
    else:
        raise Exception("AttributeError was expected to have been raised")
    print("*** rindex with valid vault ***")
    import vault
    avue.vault = vault.VaultLib("password")
    print("rindex returned: {0}".format(avue.rindex("a")))



# Generated at 2022-06-23 05:49:50.227969
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    class MockVault(object):
        def decrypt(self, secret, obj=None):
            return secret

        def encrypt(self, text, secret):
            return text

    # Test to check that the comparison works when both are strings
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext("abc", MockVault(), "secret")
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext("abc", MockVault(), "secret")
    assert not (avu1 < avu2)

    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext("abd", MockVault(), "secret")
    assert avu1 < avu2

    # Test to check that the comparison works when both are of type AnsibleVaultEncryptedUnicode
    avu1 = Ans

# Generated at 2022-06-23 05:49:52.702331
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    data = AnsibleVaultEncryptedUnicode('secret value')
    assert data.upper() == 'SECRET VALUE'


# Generated at 2022-06-23 05:49:56.722394
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    # Tests assume the following variables are defined:
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode("test")
    assert ansible_vault_encrypted_unicode.casefold() == "test"

# Generated at 2022-06-23 05:50:08.338353
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib("ansible")
    secret = 'dummy_secret'
    msg = "Dummy message to be encrypted"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(msg, vault, secret)
    substr = 'Dummy'
    assert(avu.rindex(substr) == avu.index(substr))
    substr = '*Dummy*'
    assert(avu.rindex(substr) == avu.index(substr))
    substr = '*Dummy*'
    assert(avu.rindex(substr + '*') == avu.index(substr))
    substr = 'Dummy*'

# Generated at 2022-06-23 05:50:21.482705
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    print("\nTEST: Test AnsibleVaultEncryptedUnicode.isprintable()")

    a = AnsibleVaultEncryptedUnicode("hello")
    b = AnsibleVaultEncryptedUnicode("hello\x00")

    print("not encrypted: ", end="")
    assert a.data.isprintable()
    assert not b.data.isprintable()

    print("encrypted: ", end="")
    assert a.isprintable()
    assert not b.isprintable()

    print("\nSUCCESS: AnsibleVaultEncryptedUnicode.isprintable()")

AnsibleSequence.add_multi = AnsibleMapping.update



# Generated at 2022-06-23 05:50:23.912780
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    s = AnsibleVaultEncryptedUnicode(u'ababababab')
    assert s.count(u'ab') == 5



# Generated at 2022-06-23 05:50:31.083872
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    # __le__ of AnsibleVaultEncryptedUnicode should work well with a
    #   AnsibleVaultEncryptedUnicode parameter
    # Arrange
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    plaintext = "test"
    secret = "secret"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)

    # Act
    result = avu <= avu2

    # Assert
    assert result == (plaintext <= plaintext)



# Generated at 2022-06-23 05:50:37.242274
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    secret = 'mysecret'
    vault = VaultLib(password=secret)
    vtext = "this is a secret"
    avu_with_secret = AnsibleVaultEncryptedUnicode.from_plaintext(vtext, vault, secret)
    rjusted_avu = avu_with_secret.rjust(50)
    assert rjusted_avu == "                            this is a secret"


# Generated at 2022-06-23 05:50:40.840380
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.zfill(5) == '00abc'

    avu = AnsibleVaultEncryptedUnicode('+2')
    assert avu.zfill(3) == '+02'



# Generated at 2022-06-23 05:50:48.220285
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    '''
    Unit test for method ljust of class AnsibleVaultEncryptedUnicode
    '''
    avu = AnsibleVaultEncryptedUnicode("Test")
    assert avu.ljust(5) == "Test "
    assert avu.ljust(5, 'x') == "Testx"



# Generated at 2022-06-23 05:50:59.520640
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:51:07.521277
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    # Test that __le__ properly compares instances of AnsibleVaultEncryptedUnicode
    assert (AnsibleVaultEncryptedUnicode(b'The quick brown fox\njumped over the lazy dog') <= AnsibleVaultEncryptedUnicode(b'The quick brown fox\njumped over the lazy dog'))
    assert not (AnsibleVaultEncryptedUnicode(b'The quick brown fox\njumped over the lazy dog') <= AnsibleVaultEncryptedUnicode(b'The quick brown fox\njumped over the lazy DOG'))



# Generated at 2022-06-23 05:51:11.648176
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    data = u'abc/d/e/f'

    ave_data = AnsibleVaultEncryptedUnicode(data)

    reversed_data = u'f/e/d/cba'

    assert reversed_data == to_text(reversed(ave_data))
    assert reversed_data == to_text(ave_data[::-1])



# Generated at 2022-06-23 05:51:17.366704
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    # Enforce that lowercas and uppercase versions of a character are considered equal
    # for purposes of AnsibleVaultEncryptedUnicode.upper()
    s = AnsibleVaultEncryptedUnicode("n\u00f9cleus")
    assert s.upper() == "NUCLEUS"


# Generated at 2022-06-23 05:51:28.638350
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Testing if the str or unicode has higher priority
    ansible_vault_unicode1 = AnsibleVaultEncryptedUnicode('ansible_vault_ciphertext1')
    ansible_vault_unicode2 = AnsibleVaultEncryptedUnicode('ansible_vault_ciphertext2')
    ansible_vault_unicode3 = AnsibleVaultEncryptedUnicode('ansible_vault_ciphertext3')
    ansible_vault_unicode4 = AnsibleVaultEncryptedUnicode('ansible_vault_ciphertext4')
    ansible_vault_unicode5 = AnsibleVaultEncryptedUnicode('ansible_vault_ciphertext5')

# Generated at 2022-06-23 05:51:39.810015
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    # Create an object for method __mul__ of class AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('foo')

    # The __mul__ method of AnsibleVaultEncryptedUnicode objects:
    #     Repeatedly returns a copy of the string with the string passed
    #     as a parameter concatenated
    assert avu * 3 == 'foofoofoo'
    assert 3 * avu == 'foofoofoo'
    assert avu * 'a' == 'afoo'
    assert 'a' * avu == 'afoo'
    assert avu * avu == 'foofoo'


if __name__ == '__main__':
    # Test method __mul__ of class AnsibleVaultEncryptedUnicode
    test_AnsibleVaultEnc

# Generated at 2022-06-23 05:51:49.834503
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    # A AnsibleVaultEncryptedUnicode with a Vault attribute that can decrypt it.
    import ansible.constants
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor

    secret = 'secret\n'

# Generated at 2022-06-23 05:51:57.998946
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    error_message = "rstrip method of class AnsibleVaultEncryptedUnicode must accept strings " \
                    "or AnsibleVaultEncryptedUnicodes as its argument"
    assert_message = "rstrip('xyz') method of class AnsibleVaultEncryptedUnicode must return an instance type of AnsibleVaultEncryptedUnicode"
    s = "abcd efgh ijkl\n"
    s = AnsibleVaultEncryptedUnicode(s)

    st = "xyz"
    st = AnsibleVaultEncryptedUnicode(st)

    assert isinstance(s.rstrip(), AnsibleVaultEncryptedUnicode), assert_message

# Generated at 2022-06-23 05:52:07.883172
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:52:11.465862
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    string = u'\u1234\u20ac\u8000'
    avu = AnsibleVaultEncryptedUnicode(to_bytes(string))
    assert avu.isprintable() == string.isprintable()


# Generated at 2022-06-23 05:52:18.513206
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    s = 'Déjà vu'
    plaintext = to_bytes(s)
    password = '$ANSIBLE_VAULT;1.1;AES256'

    # first, encrypt the data
    vault = VaultLib([password])
    ciphertext = vault.encrypt(plaintext, password)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    # now test to see if the original plaintext is returned
    assert avu.casefold() == s.casefold()

