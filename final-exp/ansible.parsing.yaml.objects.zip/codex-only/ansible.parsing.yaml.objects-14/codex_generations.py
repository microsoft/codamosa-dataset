

# Generated at 2022-06-23 05:42:32.755877
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    from ansible.parsing.vault import VaultLib

    s = b'\x12\x34\x56\x78\x9A\xBC\xDE\xF0\x00\x01\x02\x03\x04'
    secret = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C'
    plaintext = b'abcdefghijklmno'
    passwords = {'default': secret}
    vault = VaultLib(passwords)

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)

    avu.vault.secrets['default'] = secret
    assert avu.strip() == plaintext

# Generated at 2022-06-23 05:42:40.583804
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    plaintext = 'abc'
    encrypted_text = '$ANSIBLE_VAULT;1.2;AES256;test\n9b9f92b2bb06b7f28bfa2714ab716b8fa1c8066105a45d1a9f09dd346905d3c3\n'

    enc_obj = AnsibleVaultEncryptedUnicode(encrypted_text)
    assert(enc_obj.__gt__(plaintext) == True)



# Generated at 2022-06-23 05:42:47.675855
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    # arrange
    avue1 = AnsibleVaultEncryptedUnicode("test")
    avue2 = AnsibleVaultEncryptedUnicode("1.0")
    # act
    result1 = avue1.__complex__()
    result2 = avue2.__complex__()
    # assert
    assert isinstance(result1, complex)
    assert isinstance(result2, complex)
    assert result1 == complex(0,0)
    assert result2 == complex(1.0,0)



# Generated at 2022-06-23 05:42:50.045249
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    assert AnsibleVaultEncryptedUnicode('value').title() == 'Value'
    assert AnsibleVaultEncryptedUnicode('VALUE').title() == 'Value'


# Generated at 2022-06-23 05:42:53.702583
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    plaintext = AnsibleVaultEncryptedUnicode(u'abcd')
    print(plaintext.translate('a', 'b', 'c'))
    pass

test_AnsibleVaultEncryptedUnicode_translate()


# Generated at 2022-06-23 05:43:01.429116
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import getpass
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault = VaultLib([], 'AES256', getpass.getpass)
    avue = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, VaultSecret('123'))
    avue2 = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, VaultSecret('123'))
    assert(avue == avue2)

    avue = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, VaultSecret('123'))

# Generated at 2022-06-23 05:43:04.927044
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    avue = AnsibleVaultEncryptedUnicode("abc")
    assert avue.casefold() == "abc"


# Generated at 2022-06-23 05:43:15.744657
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;test\n551109ec69396e05e34f5b88f8a8a2f2ccbddf96a9d1255b9d1b7fa317bafc77\n')
    assert avu.rjust(5) == ' $ANSIBLE_VAULT;1.2;AES256;test\n551109ec69396e05e34f5b88f8a8a2f2ccbddf96a9d1255b9d1b7fa317bafc77\n'

# Generated at 2022-06-23 05:43:20.367331
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    import textwrap
    original = textwrap.dedent('''
        This is a test.
        It should be decrypted.
        It has two lines.
    ''')

    ciphertext = to_bytes(original)
    data = AnsibleVaultEncryptedUnicode(ciphertext)
    data = [x for x in data]
    assert len(data[0]), len(ciphertext) == 45
    assert original == data


# Generated at 2022-06-23 05:43:29.143929
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    from ansible.vault import VaultLib
    vault = VaultLib('1234')

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('\x00', vault, '1234')
    assert not avu.isprintable()

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('\x01', vault, '1234')
    assert avu.isprintable()

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, '1234')
    assert avu.isprintable()

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('', vault, '1234')
    assert avu.isprintable()


# Generated at 2022-06-23 05:43:34.873142
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    class FakeVault:
        def decrypt(self, data, secret, obj=None):
            return "decrypted"

    fake_vault = FakeVault()
    avu = AnsibleVaultEncryptedUnicode("wkjw0iu2kj42")
    avu.vault = fake_vault
    assert avu.format("{}") == "decrypted"
    assert avu.format("{:+010.5f}") == "decrypted"
    assert avu.format("{:>15s}") == "decrypted"



# Generated at 2022-06-23 05:43:46.629896
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    my_password = 'mypassword'
    my_secret = VaultSecret(my_password)
    my_vault = VaultLib(my_secret)
    my_string = AnsibleVaultEncryptedUnicode.from_plaintext(
        'A space   ',
        my_vault, my_secret
    )
    assert my_string.strip() == 'A space'

# Add the dynamic class to the look up table for the yaml loader
yaml.add_multi_constructor(u'!vault', AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 05:43:53.613786
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    text = to_text(b'abc123')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(text, None, None)
    assert avu.isalnum()

if _sys.version_info < (2, 7):
    # Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
    def test_AnsibleVaultEncryptedUnicode_isdecimal():
        text = to_text(b'123')
        avu = AnsibleVaultEncryptedUnicode.from_plaintext(text, None, None)
        assert avu.isdecimal()


# Generated at 2022-06-23 05:43:59.533345
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    print("")
    print("test_AnsibleVaultEncryptedUnicode_istitle():")
    avue = AnsibleVaultEncryptedUnicode("test", vault="vault")
    print("\tAnsibleVaultEncryptedUnicode: %s" % (avue.data))
    print("\t%s" % (avue.istitle()))



# Generated at 2022-06-23 05:44:05.104150
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    from ansible.parsing import vault

    vault_password = 'vault-password'

    text = '''
    groups:
    - []
    - []
    '''

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(text, vault.VaultLib(vault_password), vault_password)
    assert(avu.split() == text_type(text).split())



# Generated at 2022-06-23 05:44:09.759533
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    """
    Check AnsibleVaultEncryptedUnicode.index method
    """
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.index('b') == 1
    assert avu.index('c') == 2
    assert avu.index('b',2) == -1
    assert avu.index('z') == -1
    assert avu.index('b',-1,4) == 1

# Generated at 2022-06-23 05:44:19.899724
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    # Test 1
    str_test = AnsibleVaultEncryptedUnicode("test")
    str_test.ansible_pos = ('/mock_dir/mock_file', 3, 12)
    if str(str_test) != 'test':
        sys.exit(1) # Test 1 fail
    # Test 2

# Generated at 2022-06-23 05:44:20.617152
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    pass



# Generated at 2022-06-23 05:44:26.609719
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    avueu1 = AnsibleVaultEncryptedUnicode(b'\x80\x9f<\x9e\x8c\x17\xab\xc4P\xfd\xcc\x8c\x83\xe0\x9f\x1b\xacx\xcc\xdb\x03\xb2\x17\x9b\xa6')

# Generated at 2022-06-23 05:44:37.278980
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    avu_a = AnsibleVaultEncryptedUnicode("a")
    avu_c = AnsibleVaultEncryptedUnicode("c")
    assert (avu_a < avu_c) == ("a" < "c")
    assert (avu_a < "c") == ("a" < "c")

yaml.add_path_resolver(
    u'tag:yaml.org,2002:python/unicode',
    [u''],
    lambda loader, node: AnsibleUnicode(node.value),
)
yaml.add_path_resolver(
    u'tag:yaml.org,2002:str',
    [u''],
    lambda loader, node: AnsibleUnicode(node.value),
)



# Generated at 2022-06-23 05:44:48.514118
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    if _sys.version_info < (3, 0):
        # In Python 2 rsplit is implemented as:
        # def rsplit(self, sep=None, maxsplit=-1):
        #       return self.split(sep, maxsplit)[::-1]
        # so in this case we only need to test that split works as expected
        pass
    else:
        # In Python 3 rsplit is implemented as in C-code, so we need to
        # define specific test for it.
        a = AnsibleVaultEncryptedUnicode('a b c')
        assert a.rsplit(maxsplit=1) == ['a b', 'c']
        assert a.rsplit(' ', maxsplit=1) == ['a b', 'c']

# Generated at 2022-06-23 05:44:50.199398
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():

    assert float(AnsibleVaultEncryptedUnicode("1.5")) == 1.5


# Generated at 2022-06-23 05:44:52.110026
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    unit = AnsibleVaultEncryptedUnicode("123")
    assert unit.capitalize() == "123".capitalize()


# Generated at 2022-06-23 05:45:02.769081
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    # test join with AnsibleVaultEncryptedUnicode and string
    string_vault = AnsibleVaultEncryptedUnicode.from_plaintext('string', vault=None, secret='secret')
    join_test = string_vault.join(['join','test'])
    assert join_test == 'jointest'

    # test join with only AnsibleVaultEncryptedUnicode
    string_vault_1 = AnsibleVaultEncryptedUnicode.from_plaintext('string', vault=None, secret='secret')
    string_vault_2 = AnsibleVaultEncryptedUnicode.from_plaintext('string', vault=None, secret='secret')
    join_test_1 = string_vault_1.join([string_vault_2])

# Generated at 2022-06-23 05:45:11.618495
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    assert isinstance('hello', text_type)
    assert isinstance('hello', AnsibleUnicode)
    assert isinstance(u'hello', AnsibleUnicode)
    assert u'hello' != 'hello'
    assert str(u'hello') == 'hello'
    assert str(AnsibleUnicode('hello')) == 'hello'
    assert AnsibleUnicode(
        'hello'
    ) == "hello", 'constructing with string should preserve the original string'
    assert AnsibleUnicode(
        'hello'
    ) == AnsibleUnicode(
        'hello'
    ), 'two AnsibleUnicode constructed from the same string should be equal'

# Generated at 2022-06-23 05:45:14.695448
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    assert AnsibleVaultEncryptedUnicode('foobar').index('bar') == 3


# Generated at 2022-06-23 05:45:21.875739
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    sample_string = u"\thello\t"
    aveu = AnsibleVaultEncryptedUnicode(sample_string)
    assert aveu.expandtabs() == sample_string.expandtabs()
    assert aveu.expandtabs(tabsize=2) == sample_string.expandtabs(tabsize=2)
    assert aveu.expandtabs(tabsize=4) == sample_string.expandtabs(tabsize=4)


# Generated at 2022-06-23 05:45:32.102319
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    '''
    Unit test for type AnsibleVaultEncryptedUnicode

    Function isidentifier returns True for certain strings which
    shouldn't return True when the string is encrypted.
    This test checks for the negative case.

    Usage: python -m ansible.utils.unsafe_proxy [TEST_to_bytes]
    '''

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader

    try:
        old_sys_stdout = _sys.stdout
        _sys.stdout = open(to_bytes('/dev/null'), 'w')
    except (OSError, IOError):
        pass


# Generated at 2022-06-23 05:45:42.066734
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    from ansible.vault import VaultLib
    from six import PY2, PY3

    vault = VaultLib('password')

    if PY3:
        ciphertext = "".encode("utf-8")
    else:
        ciphertext = ""

    avue = AnsibleVaultEncryptedUnicode(ciphertext)

    try:
        hash(avue)
    except TypeError:
        assert True
    else:
        assert False

    avue.vault = vault

    if PY3:
        hash(avue) == hash("".encode("utf-8"))
    else:
        hash(avue) == hash("")



# Generated at 2022-06-23 05:45:53.809591
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    def method_test(case):
        avuobj = AnsibleVaultEncryptedUnicode.from_plaintext(case, None, None)
        return avuobj.isalpha()

    # test normal case
    test_case = "thisisastring"
    expect_result = True
    assert method_test(test_case) == expect_result

    # test empty string
    test_case = ""
    expect_result = False
    assert method_test(test_case) == expect_result

    # test digit string
    test_case = "1234567890"
    expect_result = False
    assert method_test(test_case) == expect_result

    # test alphanummeric string
    test_case = "1234567890thisisastring12345"
    expect_result = False
    assert method_

# Generated at 2022-06-23 05:45:56.164363
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    assert AnsibleVaultEncryptedUnicode(b'FOO').lower() == u'foo'


# Generated at 2022-06-23 05:46:05.755636
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret
    vault_pass = get_file_vault_secret('/Users/mpetazzoni/dev/ansible/test/test_vault_pass')
    vault = VaultLib(vault_pass)

    # test isupper (no vault)
    avu = AnsibleVaultEncryptedUnicode(b'UNIT')
    assert(not avu.isupper())
    assert(avu.data == 'UNIT')

    # test isupper (with vault)

# Generated at 2022-06-23 05:46:11.532272
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    """
    Tests function __complex__ of class AnsibleVaultEncryptedUnicode to verify
    that the function returns a correct object.

    :return None:
    """
    test_string = AnsibleVaultEncryptedUnicode("1.1+1j")
    assert complex(test_string) == 1.1+1j



# Generated at 2022-06-23 05:46:17.200321
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    secret = 'secret'
    vault = AnsibleVaultEncryptedUnicode.from_plaintext(text_type('password'), vault=VaultLib(password_bytes=secret), secret=secret)
    key_value = text_type('{{ key_name }}').join([text_type('some_key'), vault])
    assert key_value == 'some_keysome_key'



# Generated at 2022-06-23 05:46:24.805083
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    # create object
    obj = AnsibleBaseYAMLObject()
    # test constructor
    assert obj._data_source == None
    assert obj._line_number == 0
    assert obj._column_number == 0
    # test attribute setter and getter using a tuple
    data = "a"
    line = 5
    col = 10
    obj.ansible_pos = (data, line, col)
    assert obj._data_source == data
    assert obj._line_number == line
    assert obj._column_number == col
    # test attribute setter and getter using a list
    data = "b"
    line = 15
    col = 110
    obj.ansible_pos = [data, line, col]
    assert obj._data_source == data
    assert obj._line_number == line
    assert obj._column

# Generated at 2022-06-23 05:46:28.769223
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    # Arrange
    obj = AnsibleVaultEncryptedUnicode('abc')

    # Act
    result = obj.zfill(3)

    # Assert
    assert result == 'abc'


# Generated at 2022-06-23 05:46:40.659960
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # byte string
    ciphertext = b'abc'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert(avu[0:0] == b'')
    assert(avu[0:2] == b'ab')
    assert(avu[0:3] == b'abc')
    assert(avu[0:4] == b'abc')
    assert(avu[-3:-3] == b'')
    assert(avu[-3:-1] == b'ab')
    assert(avu[-3:-0] == b'abc')
    assert(avu[-3:0] == b'abc')

    # unicode
    ciphertext = u'abc'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)

# Generated at 2022-06-23 05:46:50.776662
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    class MockVault(object):
        """Mock class that pretends to be an AnsibleVault object."""

        def __init__(self, secret):
            self.secret = secret

        def is_encrypted(self, data):
            """Always return True."""
            return True

        def decrypt(self, data, obj=None):
            """Return the secret as plaintext."""
            return self.secret

        def encrypt(self, data, secret):
            """Return the plaintext as ciphertext."""
            return data

    unencrypted_data = u'the quick brown fox'
    secret = u'a secret'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(unencrypted_data, MockVault(secret), secret)

# Generated at 2022-06-23 05:47:01.570164
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    # Test cases are taken from
    # https://docs.python.org/3/library/stdtypes.html#str.expandtabs
    cases = [
        ("tab\ttab\t", 8, "tab       tab       "),
        ("tab\ttab\t", 4, "tab   tab   "),
        ("tab\ttab\t", 2, "tab tab "),
    ]

    for (case, size, expected) in cases:
        result = AnsibleVaultEncryptedUnicode(case).expandtabs(size)
        print("case: %s" % case)
        print("result: %s" % result)
        print("expected: %s" % expected)
        assert(result == expected)

# To test the method replace of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:47:10.855482
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    """Test for method rsplit"""
    assert AnsibleVaultEncryptedUnicode('ab c\n\nde fg\rkl\r\n').rsplit() == ['ab', 'c', '', 'de', 'fg', 'kl']
    assert AnsibleVaultEncryptedUnicode('ab c\n\nde fg\rkl\r\n').rsplit(maxsplit=1) == ['ab c\n\nde fg\rkl', '']
    assert AnsibleVaultEncryptedUnicode('ab c\n\nde fg\rkl\r\n').rsplit(maxsplit=2) == ['ab c\n\nde', 'fg\rkl', '']

# Generated at 2022-06-23 05:47:14.836139
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    u = AnsibleVaultEncryptedUnicode(b'foo')
    assert not isinstance(u.__reversed__(), generator)
    assert u.__reversed__() == 'oof'


# Generated at 2022-06-23 05:47:26.797644
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    src_string = 'abcdefgh'

# Generated at 2022-06-23 05:47:32.832368
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    test_string = "Hello World"
    test_string_encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(test_string, None, None)
    expected_result = test_string.split()
    result = test_string_encrypted.split()
    assert result == expected_result, "Result of encrypted string split is not the same as expected %s" % result


# Generated at 2022-06-23 05:47:36.112856
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    ansible_mapping = AnsibleMapping()
    assert isinstance(ansible_mapping, AnsibleMapping)
    assert isinstance(ansible_mapping, dict)

# Generated at 2022-06-23 05:47:44.091474
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    """
    AnsibleVaultEncryptedUnicode.__rmod__ should be able to act
    as a python native type
    """
    try:
        from unittest import mock
    except ImportError:
        import mock

    mock_vault = mock.Mock()

    plaintext = "Test for method rmod"
    ciphertext = "FooTest for methoc ciphertextrmod"
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = mock_vault

    mock_vault.decrypt.return_value = plaintext

    assert '%s' % avu == plaintext

if __name__ == '__main__':
    import sys
    import unittest

    sys.exit(unittest.main())

# Generated at 2022-06-23 05:47:54.797899
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    # Test use of optional parameter start
    # Test with valid values start
    assert AnsibleVaultEncryptedUnicode("abcdabcd").rfind("cd", 0, 8) == 4
    assert AnsibleVaultEncryptedUnicode("abcdabcd").rfind("cd", 2, 8) == 4
    assert AnsibleVaultEncryptedUnicode("abcdabcd").rfind("cd", -1, 8) == 4
    # Test with default values for start
    assert AnsibleVaultEncryptedUnicode("abcdabcd").rfind("cd", 0, 8) == 4
    # Test with invalid values for start
    try:
        AnsibleVaultEncryptedUnicode("abcdabcd").rfind("cd", -1, -4)
    except ValueError:
        pass

# Generated at 2022-06-23 05:48:02.990762
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test with normal use case.
    vault = FakeVault()
    secret = "abcd1234"
    plain_text = "the quick brown fox"
    cipher_text = vault.encrypt(plain_text, secret)
    avue = AnsibleVaultEncryptedUnicode.from_plaintext(plain_text, vault, secret)
    assert cipher_text == avue._ciphertext
    assert cipher_text == avue[:]
    assert plain_text == avue.data

    # Test with negative start and end.
    assert plain_text[-1:] == avue[-1:]
    assert plain_text[-3:-1] == avue[-3:-1]
    assert plain_text[-1:-1] == avue[-1:-1]

    # Test with given start and end.
   

# Generated at 2022-06-23 05:48:12.995516
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_vault_secret

    data = 'data'
    secret = get_vault_secret(None, ask_vault_pass=False)
    ciphertext = VaultLib.encrypt(secret, data)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = VaultLib(secret)

    assert str(avu.format_map({'1': 'test'})) == 'test'
    assert avu.format_map({'1': 'test'}) == data


# Generated at 2022-06-23 05:48:19.777551
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    class MyVault(object):
        pass

    o = AnsibleVaultEncryptedUnicode(None)
    o.vault = MyVault()

    o.data = 'a'
    assert(o.__gt__('x') == False)
    assert(o.__gt__('a') == False)
    assert(o.__gt__('A') == True)
    assert(o.__gt__('b') == False)

    o.data = 'b'
    assert(o.__gt__('x') == False)
    assert(o.__gt__('a') == True)
    assert(o.__gt__('A') == True)
    assert(o.__gt__('b') == False)



# Generated at 2022-06-23 05:48:31.644951
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    avue1 = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    avue2 = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    print('Test AnsibleVaultEncryptedUnicode: avue1: %s\navue2: %s\nObject types: avue1:%s avue2:%s' % (avue1, avue2, type(avue1), type(avue2)))
    assert avue1 > avue2 == False, "Failed test AnsibleVaultEncryptedUnicode__gt__"
    assert avue2 > avue1 == False, "Failed test AnsibleVaultEncryptedUnicode__gt__"



# Generated at 2022-06-23 05:48:36.402900
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    import random
    strings = [ to_text(i) for i in range(0, 10)]
    random.shuffle(strings)
    for string in strings:
        encrypted = AnsibleVaultEncryptedUnicode(string)
        assert encrypted.isdigit(), 'isdigit() failed for string: %s' % string



# Generated at 2022-06-23 05:48:45.474421
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    adict = {'a': 1, 'b': 2}
    amap = AnsibleMapping(adict)
    assert amap == adict
    amap.ansible_pos = ('main.yml', 10, 20)
    assert amap.ansible_pos == ('main.yml', 10, 20)
    assert amap.a == 1
    assert amap['a'] == 1
    assert amap.b == 2
    assert amap['b'] == 2
    amap.c = 3
    assert amap.c == 3
    assert amap['c'] == 3
    amap['d'] = 4
    assert amap.d == 4
    assert amap['d'] == 4
    try:
        amap.e
    except AttributeError:
        pass
    except Exception:
        assert False

# Generated at 2022-06-23 05:48:56.648437
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    uni = AnsibleVaultEncryptedUnicode(u'foo')
    assert uni.isidentifier()

    uni = AnsibleVaultEncryptedUnicode(u'foo0')
    assert uni.isidentifier()

    uni = AnsibleVaultEncryptedUnicode(u'foo_bar')
    assert uni.isidentifier()

    uni = AnsibleVaultEncryptedUnicode(u'foo_bar123')
    assert uni.isidentifier()

    uni = AnsibleVaultEncryptedUnicode(u'foo bar')
    assert not uni.isidentifier()

    uni = AnsibleVaultEncryptedUnicode(u'foo+')
    assert not uni.isidentifier()



# Generated at 2022-06-23 05:49:03.571447
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    encrypted_text = AnsibleVaultEncryptedUnicode('playbook: abcd')
    encrypted_text.vault = vault_lib.AnsibleVaultLib()
    left, sep, right = encrypted_text.partition(':')
    assert(left == 'playbook')
    assert(sep == ':')
    assert(right == ' abcd')



# Generated at 2022-06-23 05:49:08.114442
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    e = AnsibleVaultEncryptedUnicode('test_AnsibleVaultEncryptedUnicode_partition')
    assert e.partition('n') == ('test_AnsibleVaultEncryptedUnicode_partitio', 'n', 'e')

# the following test methods allow the class to function with the python unittest module

# Generated at 2022-06-23 05:49:13.985213
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    from ansible.parsing.vault import VaultLib
    pass_phrase = 'p4ssw0rd'
    secret = b'abcde'
    vault = VaultLib(pass_phrase)
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(secret, vault, pass_phrase)
    assert len(secret) == len(encrypted)


# Generated at 2022-06-23 05:49:17.988270
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    av = AnsibleVaultEncryptedUnicode([])
    av.data = '123456789'
    assert av.zfill(15) == '00000123456789'
    return True



# Generated at 2022-06-23 05:49:29.294165
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    # Test with a non encrypted string
    plaintext = AnsibleVaultEncryptedUnicode('123')
    plaintext.vault = None
    assert plaintext.data == to_text('123')
    assert int(plaintext) == 123
    assert isinstance(int(plaintext), int)

    # Test with an encrypted string which can be decrypted
    plaintext = AnsibleVaultEncryptedUnicode('123')
    plaintext.vault = True
    assert plaintext.data == to_text('123')
    assert int(plaintext) == 123
    assert isinstance(int(plaintext), int)

    # Test with an encrypted string which CANNOT be decrypted
    plaintext = AnsibleVaultEncryptedUnicode('123')
    plaintext.vault = False

# Generated at 2022-06-23 05:49:34.075012
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    inputstr = " a b\nc  "
    avu = AnsibleVaultEncryptedUnicode(inputstr)
    avu.vault = None

    ret = avu.strip()
    if (ret == "a b\nc"):
        print("Test passed")
    else:
        print("Test failed")


# Generated at 2022-06-23 05:49:44.905127
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    # Normal test cases which are converted to ASCII by Turkish locale
    plaintext = u"Anadolu Zirvesi"
    ciphertext = "U2FsdGVkX18X66OT0Y+yVjJwDdWpV1RkZuV7ljn+eN9/Wl2tYHVc3qEgsoPMV8W/hrcnJm7jkzQsbg9XbjEJmw=="
    vault = VaultLib(plaintext, ciphertext)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, plaintext)
    assert casefold(avu) == casefold(plaintext)
    assert casefold(avu) == "anadolu zirvesi"

# Generated at 2022-06-23 05:49:56.331358
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    from ansible.parsing.vault import VaultLib
    from io import BytesIO

    vault = VaultLib([], 1)
    vault.decrypt(b'$ANSIBLE_VAULT;1.1;AES256\n32403439643337646261323065653336363239666535646633363235313531653135313731363235313\n633366346531336233356335653333343066323538666535643265633130663335646632656262633265\n356235646633333964336634353737\n', b'foo')

# Generated at 2022-06-23 05:50:02.227338
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('my secret plaintext\n', vault, 'secret')
    assert avu.is_encrypted()
    decrypted = avu.data
    assert not avu.is_encrypted()
    print(decrypted)



# Generated at 2022-06-23 05:50:13.868200
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    from ansible import constants
    from ansible.parsing.vault import VaultLib
    from binascii import unhexlify
    import os
    import tempfile
    tmpdir = tempfile.mkdtemp()
    # Use fixed salt, iv and password
    salt = b'\x9f\x10\x05\xc1\xfb\x4e\x7a\xf4\xfa\x24\x9b\x95\x3a\x6a\x6f\x06'
    iv = b'\x8a\x9d\xcc\x59\x52\x58\x43\x20\x0d\xb0\x32\xda\xcd\xa1\x50\x8a'
    password = b'ansiblekubernetes'


# Generated at 2022-06-23 05:50:16.158279
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    assert (AnsibleVaultEncryptedUnicode(u'hello').islower())

# Generated at 2022-06-23 05:50:20.325917
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    s1 = AnsibleVaultEncryptedUnicode(u'foo')
    s2 = AnsibleVaultEncryptedUnicode(u'bar')
    s3 = s1 + s2
    assert s3.data == u'foobar'


# Generated at 2022-06-23 05:50:32.844305
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    x = AnsibleVaultEncryptedUnicode("hello", "world")
    assert x.center(5) == AnsibleVaultEncryptedUnicode('hello', 'world')
    assert x.center(6) == AnsibleVaultEncryptedUnicode('hello ', 'world')
    assert x.center(7) == AnsibleVaultEncryptedUnicode(' hello ','world')
    assert x.center(8) == AnsibleVaultEncryptedUnicode(' hello  ','world')
    assert x.center(9) == AnsibleVaultEncryptedUnicode('  hello  ','world')
    assert x.center(10) == AnsibleVaultEncryptedUnicode('  hello   ','world')

# Generated at 2022-06-23 05:50:39.357679
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    assert AnsibleVaultEncryptedUnicode('abc').casefold() == 'abc'.casefold()
    assert AnsibleVaultEncryptedUnicode('abc ').casefold() == 'abc '.casefold()
    assert AnsibleVaultEncryptedUnicode(' abc').casefold() == ' abc'.casefold()
    assert AnsibleVaultEncryptedUnicode('$ E 1').casefold() == '$ E 1'.casefold()



# Generated at 2022-06-23 05:50:42.585947
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    obj = AnsibleVaultEncryptedUnicode('hello')
    assert obj.ljust(10) == 'hello     '
    assert obj.ljust(10,'-') == 'hello-----'
    assert obj.ljust(10,'') == 'hello'


# Generated at 2022-06-23 05:50:49.659632
# Unit test for method encode of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:50:56.326175
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    testdata_list = [
        ('abc', 3, 'abcabcabc'),
        ('abc', 0, ''),
        ('abc', -1, ''),
        ('abc', '3', 'abcabcabc'),
        ('', 3, ''),
        ('', 0, '')
    ]
    for data in testdata_list:
        assert AnsibleVaultEncryptedUnicode(data[0]) * data[1] == data[2] # noqa: WPS441



# Generated at 2022-06-23 05:51:01.772597
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    expected_result = 'ThIs Is A Test Title'
    unittest_string = 'tHiS is a test title'
    avu = AnsibleVaultEncryptedUnicode(unittest_string)
    result = avu.title()

# Generated at 2022-06-23 05:51:06.609573
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    from ansible.parsing.vault import VaultLib
    s = AnsibleVaultEncryptedUnicode('ciphertext')
    s.vault = VaultLib('secret')
    # The following list can be obtained using
    # test_AnsibleVaultEncryptedUnicode_join.test_list
    test_list = ['ab', 'cd', 'ef']
    assert s.join(test_list) == 'abcdef'



# Generated at 2022-06-23 05:51:08.822699
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    avueu = AnsibleVaultEncryptedUnicode('TeSt')
    if avueu.lower() != 'test':
        raise AssertionError()


# Generated at 2022-06-23 05:51:11.708945
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    # Arrange
    string = '''
---
# Test string
test:
  - "test"
  - "test"
'''
    # Act and assert
    assert AnsibleVaultEncryptedUnicode(string).rfind(' ') == 9



# Generated at 2022-06-23 05:51:15.338783
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    test_str = AnsibleVaultEncryptedUnicode(b'*' * 1000)
    assert repr(test_str) == repr(test_str.data)


# Generated at 2022-06-23 05:51:26.313807
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Test with a valid value.
    avu = AnsibleVaultEncryptedUnicode('testa')
    assert avu[1:3] == 'es', 'Must be "es"'

    # Test with a beginning greater than the length of the field.
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu[10:11] == '', 'Must be empty'

    # Test with an end greater than the length of the field.
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu[1:11] == 'est', 'Must be "est"'

    # Test with a beginning negative value (from the end of the field).
    avu = AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-23 05:51:36.659026
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    ########################################################################
    # INVALID INPUT:
    ########################################################################
    # empty string
    try:
        actual = AnsibleUnicode()
    except TypeError as e:
        expected = "__init__() takes exactly 2 arguments (1 given)"
        assert str(e) == expected

    # string is the wrong type
    try:
        actual = AnsibleUnicode(42)
    except TypeError as e:
        expected = "'int' object is not iterable"
        assert str(e) == expected

    ########################################################################
    # VALID INPUT:
    ########################################################################
    # ansible string
    actual = AnsibleUnicode("ansible string")
    expected = "ansible string"
    assert actual == expected
    assert actual.__class__ == AnsibleUnic

# Generated at 2022-06-23 05:51:46.862457
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    from ansible.parsing.vault import VaultLib
    a = AnsibleVaultEncryptedUnicode("aa")
    b = AnsibleVaultEncryptedUnicode("bb")
    c = AnsibleVaultEncryptedUnicode("cc")
    d = AnsibleVaultEncryptedUnicode("dd")
    ab = AnsibleVaultEncryptedUnicode("aabb")
    c_d = AnsibleVaultEncryptedUnicode("ccdd")
    abcd = AnsibleVaultEncryptedUnicode("aabbccdd")
    secret = "secret"
    obj = VaultLib([])

    # Test with plaintext inputs
    assert a.join([b, c, d]) == abcd
    assert b.join([a, c, d]) == abcd

# Generated at 2022-06-23 05:51:53.405715
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    s = AnsibleVaultEncryptedUnicode(u'this is a test string')
    assert s.count(s) == 1
    assert s.count(u'i') == 3
    assert s.count(u'i', 7) == 1
    assert s.count(u'i', 7, 2) == 0
    try:
        s.count(u'', 12)
    except ValueError:
        pass
    else:
        raise AssertionError('Failed to raise ValueError for empty substring')



# Generated at 2022-06-23 05:52:04.877990
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''
    Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
    '''
    # The following two lines of code can be inserted at the beginning of the
    # function to be tested - it may be useful for debugging.
    #
    # from pytest import set_trace ; set_trace ()
    # import pdb ; pdb . set_trace ()

    # Arrange
    from ansible_collections.ansible.community.plugins.vars.password.vault import VaultLib
    vault = VaultLib('password')
    txt1 = AnsibleVaultEncryptedUnicode.from_plaintext('example', vault, 'password')
    txt1.vault = vault
    txt2 = AnsibleVaultEncryptedUnicode.from_plaintext('example2', vault, 'password')


# Generated at 2022-06-23 05:52:07.712412
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    test_seq = AnsibleSequence()
    assert isinstance(test_seq, list)
    assert isinstance(test_seq, AnsibleSequence)


# Generated at 2022-06-23 05:52:11.311060
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    assert not AnsibleVaultEncryptedUnicode("hi").isupper()
    assert not AnsibleVaultEncryptedUnicode("Hi").isupper()
    assert AnsibleVaultEncryptedUnicode("HI").isupper()



# Generated at 2022-06-23 05:52:14.869979
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    # Create an instance
    avu = AnsibleVaultEncryptedUnicode(u'\uc5f0\ud569')

    # Check that upper of the instance returns the expected value
    assert avu.upper() == u'\uc5f0\ud569'


# Generated at 2022-06-23 05:52:22.034957
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    vault = VaultLib('test')
    secret = b'test'
    plaintext = 'the quick brown fox'
    ciphertext = vault.encrypt(plaintext, secret)
    ciphertext = AnsibleVaultEncryptedUnicode(ciphertext)
    ciphertext.vault = vault

    # Test that ciphertext is alphanumeric
    assert ciphertext.isalnum() is True

    # Test that ciphertext is not alphanumeric in a non-vault context
    ciphertext.vault = None
    assert ciphertext.isalnum() is False

    # Test that ciphertext is alphanumeric in different vault context

# Generated at 2022-06-23 05:52:28.854416
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    from ansible.parsing.vault import VaultLib, VaultSecret
    vault = VaultLib()
    secret = VaultSecret()
    secret.set_password('VaultSecret')
    foo = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, secret)
    bar = AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, secret)
    assert not foo >= bar
    assert foo >= 'bar'
    assert foo >= AnsibleVaultEncryptedUnicode('bar')
