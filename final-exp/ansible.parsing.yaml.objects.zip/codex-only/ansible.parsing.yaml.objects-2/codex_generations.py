

# Generated at 2022-06-23 05:42:32.669092
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:42:34.303199
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    pass
#    string = AnsibleVaultEncryptedUnicode('This Is Title Case')
#    assert string.istitle()



# Generated at 2022-06-23 05:42:36.070892
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    # testing __repr__ should return a string
    avu = AnsibleVaultEncryptedUnicode(b'YmlsZSBjb250ZW50')
    assert isinstance(repr(avu), str) is True


# Generated at 2022-06-23 05:42:44.496213
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader

    vault = VaultLib([])
    vault.set_vault_id('test-vault')
    secret = b'vaultpassword'
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(b'abcd', vault, secret)
    loader = AnsibleLoader(None, None)
    print(loader.get_single_data(encrypted))

# Generated at 2022-06-23 05:42:56.352221
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    a = AnsibleBaseYAMLObject()
    a.ansible_pos = (None, 0, 0)
    if a.ansible_pos != (None, 0, 0):
        raise Exception()

    try:
        a.ansible_pos = None
        raise Exception()
    except AssertionError:
        pass

    try:
        a.ansible_pos = ()
        raise Exception()
    except AssertionError:
        pass

    try:
        a.ansible_pos = (None,)
        raise Exception()
    except AssertionError:
        pass

    try:
        a.ansible_pos = (None, None)
        raise Exception()
    except AssertionError:
        pass


# Generated at 2022-06-23 05:43:08.289740
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('encrypted_password')

    avu_1 = AnsibleVaultEncryptedUnicode.from_plaintext('', vault, 'mysecret')
    avu_2 = AnsibleVaultEncryptedUnicode.from_plaintext('', vault, 'mysecret')

    assert avu_1 <= avu_2

    avu_3 = AnsibleVaultEncryptedUnicode.from_plaintext('1', vault, 'mysecret')
    avu_4 = AnsibleVaultEncryptedUnicode.from_plaintext('1', vault, 'mysecret')

    assert avu_3 <= avu_4

    avu_5 = AnsibleVaultEncryptedUnicode.from_plaintext('1', vault, 'mysecret')
   

# Generated at 2022-06-23 05:43:16.807531
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    import base64
    from ansible.utils.vault import VaultLib

    password = 'password'
    secret = 'secret'
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n' + \
                 base64.b64encode(VaultLib(password).encrypt(secret)).decode() + '\n'

    assert AnsibleVaultEncryptedUnicode(ciphertext) == secret


# Generated at 2022-06-23 05:43:22.122525
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    avu = AnsibleVaultEncryptedUnicode("ciphertext")
    avu.vault = mock.Mock()
    avu.vault.decrypt.return_value = u'abc'
    assert avu.isalpha()

    avu.vault.decrypt.return_value = u'abc1'
    assert not avu.isalpha()


# Generated at 2022-06-23 05:43:31.076670
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    # Tested method
    method_tested = AnsibleVaultEncryptedUnicode.__ge__

    # Test case
    # assert with "this" being AVU with vault and "other" being AVU without vault
    # Should return False
    test_case_1 = {
        "this": AnsibleVaultEncryptedUnicode("this is the text"),
        "other": AnsibleVaultEncryptedUnicode("this is the text")
    } # type: Dict[str, Union[AnsibleVaultEncryptedUnicode, text_type]]
    test_case_1["this"].vault = object()
    test_case_1["this"].data = "this is the text"
    test_case_1["other"].vault = None

# Generated at 2022-06-23 05:43:34.879505
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    letters = ('a', 'b', 'c', 'd', 'e', 'f')
    avue = AnsibleVaultEncryptedUnicode('def')
    for letter in letters:
        if avue > letter:
            return True
    return False


# Generated at 2022-06-23 05:43:46.629139
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:43:52.949478
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    secret = 'secret'

    seq = 'seq'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)

    assert avu.data == seq
    assert avu.is_encrypted()

    avu.data = 'other'
    assert avu._ciphertext != seq
    assert avu.data == 'other'
    assert avu.is_encrypted()



# Generated at 2022-06-23 05:44:00.201406
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    # print ("testing isalpha")
    # test data
    data = [
        (u'1234', False),
        (u'abcd', True),
        (u'ABCD', True),
        (u'aaaaa1aaaaa', False),
        (u'aaaaa[aaaaa', False),
        (u'aaaaa!aaaaa', False),
        (u'1aaaaa2aaaaa3', False),
        (u'a', True),
        (u'A', True),
        (u' ', False),
        (u'\n', False),
        (u'\t', False),
        (u'', False),
        (u'aaaaa1aaaaa', False),
        (u'aaaaa&aaaaa', False),
        ]

# Generated at 2022-06-23 05:44:07.456085
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    from ansible.parsing.vault import VaultLib
    avu = AnsibleVaultEncryptedUnicode('mystring')
    assert avu.data == 'mystring'

    avu = AnsibleVaultEncryptedUnicode(b'mystring')
    assert avu.data == 'mystring'

    vault = VaultLib('secret')
    ciphertext = vault.encrypt('mystring', 'secret')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.data == 'mystring'



# Generated at 2022-06-23 05:44:17.771153
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    unencrypted_text = 'tHiS Is NoT EnCrYpTeD'

# Generated at 2022-06-23 05:44:28.921171
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    #for Python2
    #ascii_space = '\x20'
    #unicode_space = u'\u0020'
    #for Python3
    ascii_space = '\x20'
    unicode_space = ' '

    # Test on ASCII string
    test_string = ascii_space
    ansible_vault_uni = AnsibleVaultEncryptedUnicode(test_string)
    ansible_vault_uni.vault = vaultlib.VaultLib('password')
    expected_result = ascii_space.isspace()
    computed_result = ansible_vault_uni.isspace()

# Generated at 2022-06-23 05:44:38.723615
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    test_string = u'Östgöta'
    assert(AnsibleVaultEncryptedUnicode(test_string).rfind(u'ö') == 5)
    assert(AnsibleVaultEncryptedUnicode(test_string).rfind(u'ö', 4, 2) == -1)
    assert(AnsibleVaultEncryptedUnicode(test_string).rfind(u'\u00f6') == 5)
    assert(AnsibleVaultEncryptedUnicode(test_string).rfind(u'\u00f6', 4, 2) == -1)
    assert(AnsibleVaultEncryptedUnicode(test_string).rfind(u'\uff26') == 5)

# Generated at 2022-06-23 05:44:49.732429
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    """
    Test various inputs to ensure that the isprintable method
    is operating properly.
    """
    avue = AnsibleVaultEncryptedUnicode(to_bytes("ABCDEFGHIJKLMNOPQRSTUVWXYZ"))
    assert avue.isprintable()

    # Whitespace returns true
    avue = AnsibleVaultEncryptedUnicode(to_bytes(" "))
    assert avue.isprintable()

    # Tab returns true
    avue = AnsibleVaultEncryptedUnicode(to_bytes("\t"))
    assert avue.isprintable()

    # Carriage return returns true
    avue = AnsibleVaultEncryptedUnicode(to_bytes("\n"))
    assert avue.isprintable()

    # Space/Tab/Carriage return all return true


# Generated at 2022-06-23 05:44:58.512455
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    obj = AnsibleVaultEncryptedUnicode(u'This Is Title Formatted')
    obj2 = AnsibleVaultEncryptedUnicode(u'This Is Not Title Formatted')

    if obj.istitle() is False:
        raise ValueError('[FAILED] Test istitle of class AnsibleVaultEncryptedUnicode - istitle() returned incorrect value')

    if obj2.istitle() is True:
        raise ValueError('[FAILED] Test istitle of class AnsibleVaultEncryptedUnicode - istitle() returned incorrect value')


# Generated at 2022-06-23 05:45:06.478908
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # test as a normal value
    password = 'mypass'
    secret = 'mysecret'
    text = 'mytext'
    ciphertext = 'myciphertext'
    uni = AnsibleVaultEncryptedUnicode(ciphertext)
    uni.vault = vault
    uni.vault.password = password
    uni.vault.secret = secret

    uni_str = 'mytext'
    uni_str.vault = vault
    uni_str.vault.password = password
    uni_str.vault.secret = secret

    assert uni == uni_str
    assert (uni != uni_str) == False



# Generated at 2022-06-23 05:45:14.299011
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    assert AnsibleVaultEncryptedUnicode('1+1j').__complex__() == 1+1j
    assert AnsibleVaultEncryptedUnicode('-1+1j').__complex__() == -1+1j
    assert AnsibleVaultEncryptedUnicode('-1-1j').__complex__() == -1-1j
    assert AnsibleVaultEncryptedUnicode('1-1j').__complex__() == 1-1j
    assert AnsibleVaultEncryptedUnicode('1').__complex__() == 1
    assert AnsibleVaultEncryptedUnicode('-1').__complex__() == -1
    assert AnsibleVaultEncryptedUnicode('1.1').__complex__() == 1.1
    assert AnsibleVaultEncryptedUnicode('-1.1').__

# Generated at 2022-06-23 05:45:20.176524
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    avueu = AnsibleVaultEncryptedUnicode('test_AnsibleVaultEncryptedUnicode_strip')
    avueu.vault = AnsibleVaultLib()
    assert(not avueu.strip().is_encrypted())
    assert(avueu.strip() == 'test_AnsibleVaultEncryptedUnicode_strip')


# Generated at 2022-06-23 05:45:27.369234
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    ciphertext = b'abc'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    class Vault(object):
        def decrypt(self, ciphertext, obj=None):
            # obj is None, this should not happen in normal use
            return u'abcd'
    vault = Vault()
    avu.vault = vault
    assert avu.ljust(5) == u'abcd '
    assert avu.ljust(6) == u'abcd  '



# Generated at 2022-06-23 05:45:32.700998
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('yotcayotinay')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('yam', vault, 'testpassword')
    assert avu.data == 'yam'
    assert avu == 'yam'
    assert avu != 'yamb'


# Generated at 2022-06-23 05:45:43.689201
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    # Tests that the given string is properly sliced
    # Args:
    #     str: The string that must be used as a basis for the test
    #     start: The index of the start of the slice
    #     end: The index of the end of the slice
    #     expected_str_output: The expected result of the slice operation
    def test_slice_getitem(str, start, end, expected_str_output):
        assert_msg = "test_slice_getitem('{0}', {1}, {2}, '{3}') failed".format(
            str, start, end, expected_str_output)
        aveu = AnsibleVaultEncryptedUnicode(str)
        assert aveu[start:end] == expected_str_output, assert_msg

    str = "this is a very long string"

# Generated at 2022-06-23 05:45:54.931610
# Unit test for method lower of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:46:00.780909
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    line = "this is a test line"

    # partition does a find, we test find later
    assert AnsibleVaultEncryptedUnicode('this is a test line').partition('is') == ('th', 'is', ' is a test line')
    assert AnsibleVaultEncryptedUnicode('this is a test line').partition('not there') == ('this is a test line', '', '')



# Generated at 2022-06-23 05:46:04.454210
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    """Assert that the len() works with an AnsibleVaultEncryptedUnicode"""
    str = "this is a test"
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(str, None, None)
    assert len(encrypted) == len(str)


# Generated at 2022-06-23 05:46:11.944433
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    from ansible.parsing.vault import VaultLib
    secret = 'test-secret'
    value = 'test-value'
    vault = VaultLib([])
    ciphertext = vault.encrypt(value, secret)
    vault.update([secret])
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    assert str(avu) == 'test-value'



# Generated at 2022-06-23 05:46:22.803478
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    vault_str = AnsibleVaultEncryptedUnicode(b'foobar')
    assert int(vault_str) == 0

    vault_str = AnsibleVaultEncryptedUnicode(b'34')
    assert int(vault_str) == 0

    vault_str = AnsibleVaultEncryptedUnicode(b'1')
    assert int(vault_str) == 0

    from ansible.parsing.vault import VaultLib
    vault = VaultLib(b'password')
    vault_str = vault.encrypt(b'foobar')
    assert int(vault_str) == 0

    vault_str = vault.encrypt(b'34')
    assert int(vault_str) == 34

    vault_str = vault.encrypt(b'1')

# Generated at 2022-06-23 05:46:34.773243
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    vault_password_file = "~/.vault_pass.txt"

    # Importing locally in order to not interfere with the tests
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(vault_password_file)
    plaintext = "abc123"

    ciphertext = vault.encrypt(plaintext, "secret")
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert(avu >= plaintext), "Failed: avu >= plaintext, %r >= %r" % (avu, plaintext)

    assert(avu >= avu), "Failed: avu >= avu, %r >= %r" % (avu, avu)


# Generated at 2022-06-23 05:46:39.483577
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    from ansible.parsing.vault import VaultLib

    # Creating sample vault
    vault = VaultLib('mysecret', 'myfile.yml')
    u = AnsibleVaultEncryptedUnicode("A B C", vault=vault)

    # Testing
    assert(u.isspace() is False)

# Generated at 2022-06-23 05:46:45.751117
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    av = yaml.AnsibleVaultEncryptedUnicode.from_plaintext('foo', None, None)
    assert isinstance(av, yaml.AnsibleVaultEncryptedUnicode)
    assert av.data == 'foo'
    assert av[0] == 'f'
    assert av[-1] == 'o'
    assert av[-2] == 'o'
    assert av[-3] == 'f'

# Generated at 2022-06-23 05:46:50.943483
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    '''Test method __radd__ of class AnsibleVaultEncryptedUnicode'''
    str_a = AnsibleVaultEncryptedUnicode('a')
    str_b = AnsibleVaultEncryptedUnicode('b')
    assert str_a + str_b == 'ab'
    assert str_a + 'b' == 'ab'
    assert 'a' + str_b == 'ab'
    assert 'a' + 'b' == 'ab'


# Generated at 2022-06-23 05:47:01.969650
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    encrypted = AnsibleVaultEncryptedUnicode('eJwzMtAIGzEAVAAMoBXAA==')
    assert encrypted.rpartition(u'foo') == (u'', u'', u'eJwzMtAIGzEAVAAMoBXAA==')
    assert encrypted.rpartition(u'bar') == (u'eJwzMtAIGzEAVAAMoBXAA==', u'', u'')
    assert encrypted.rpartition(u'AIGzE') == (u'eJwzMtAI', u'GzE', u'AVAAMoBXAA==')

# Generated at 2022-06-23 05:47:09.859953
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    assert AnsibleVaultEncryptedUnicode.from_plaintext(u'aab', None, None).rfind(u'a') == 2
    assert AnsibleVaultEncryptedUnicode.from_plaintext(u'aab', None, None).rfind(u'b') == 3
    assert AnsibleVaultEncryptedUnicode.from_plaintext(u'aab', None, None).rfind(u'c') == -1
    assert AnsibleVaultEncryptedUnicode.from_plaintext(u'aab', None, None).rfind(u'a', 0, 1) == -1
    assert AnsibleVaultEncryptedUnicode.from_plaintext(u'aab', None, None).rfind(u'a', 0, 2) == 0
    assert AnsibleVaultEncryptedUn

# Generated at 2022-06-23 05:47:12.208470
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    assert isinstance(AnsibleVaultEncryptedUnicode('hello').__unicode__(), text_type)



# Generated at 2022-06-23 05:47:22.210901
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    import os
    import stat

    tmp_file_name = 'test_data_file'
    tmp_data_file = open(tmp_file_name, "w+")
    tmp_data_file.write("test-test-test")
    tmp_data_file.close()
    os.chmod(tmp_file_name, stat.S_IRWXU)


# Generated at 2022-06-23 05:47:24.495133
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    assert b'ab'.capitalize() == b'Ab'
    assert b'aB'.capitalize() == b'Ab'
    assert b'ab'.capitalize() == b'Ab'
    assert b'aB'.capitalize() == b'Ab'


# Generated at 2022-06-23 05:47:30.108580
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    assert isinstance(AnsibleVaultEncryptedUnicode.__getitem__(AnsibleVaultEncryptedUnicode('pippo'),0), str)
    assert isinstance(AnsibleVaultEncryptedUnicode.__getitem__(AnsibleVaultEncryptedUnicode('pippo'),slice(1,4)), AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 05:47:35.220572
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    assert AnsibleBaseYAMLObject._data_source == None
    assert AnsibleBaseYAMLObject._line_number == 0
    assert AnsibleBaseYAMLObject._column_number == 0
    try:
        AnsibleBaseYAMLObject.ansible_pos = 'foo'
    except AssertionError:
        pass
    else:
        assert False, "Expected an AssertionError to be raised"


# Generated at 2022-06-23 05:47:37.672608
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    avue_obj = AnsibleVaultEncryptedUnicode('aBcDeF')
    assert avue_obj.swapcase() == 'AbCdEf'

# Generated at 2022-06-23 05:47:46.372036
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    assert AnsibleVaultEncryptedUnicode("abc123xyz").isalnum()
    assert not AnsibleVaultEncryptedUnicode("abc123 xyz").isalnum()
    assert not AnsibleVaultEncryptedUnicode("abc 123 xyz").isalnum()
    assert AnsibleVaultEncryptedUnicode("123").isalnum()
    assert not AnsibleVaultEncryptedUnicode("").isalnum()
    assert not AnsibleVaultEncryptedUnicode(" ").isalnum()


# Generated at 2022-06-23 05:47:56.749913
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    assert AnsibleVaultEncryptedUnicode('\tabc\tdef\tg\th').expandtabs() == '        abc    def    g       h'
    assert AnsibleVaultEncryptedUnicode('\tabc\tdef\tg\th').expandtabs(1) == '        abc    def    g       h'
    assert AnsibleVaultEncryptedUnicode('\tabc\tdef\tg\th').expandtabs(2) == '   abc  def  g  h'
    assert AnsibleVaultEncryptedUnicode('\tabc\tdef\tg\th').expandtabs(3) == '  abc def g h'

# Generated at 2022-06-23 05:48:02.116228
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    plaintext = u'FOR TESTING ONLY α β'
    plaintext_casefold_expected = u'for testing only α β'
    avu = AnsibleVaultEncryptedUnicode(plaintext)
    assert avu.casefold() == plaintext_casefold_expected


# Generated at 2022-06-23 05:48:06.850294
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    assert AnsibleVaultEncryptedUnicode('1000').isnumeric()

test_AnsibleVaultEncryptedUnicode_isnumeric()


# Generated at 2022-06-23 05:48:12.293857
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    avu = AnsibleVaultEncryptedUnicode("SecrEt")
    assert avu.isupper()
    avu = AnsibleVaultEncryptedUnicode("secret")
    assert not avu.isupper()
    avu = AnsibleVaultEncryptedUnicode("sec1et")
    assert not avu.isupper()



# Generated at 2022-06-23 05:48:19.348524
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    assert AnsibleVaultEncryptedUnicode("XYZ").isdigit() == False
    assert AnsibleVaultEncryptedUnicode("123").isdigit() == True
    assert AnsibleVaultEncryptedUnicode("123.4").isdigit() == False
    assert AnsibleVaultEncryptedUnicode("123XYZ").isdigit() == False
    assert AnsibleVaultEncryptedUnicode("XYZ123").isdigit() == False



# Generated at 2022-06-23 05:48:31.400617
# Unit test for method replace of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:48:39.665931
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    # Make sure that AnsibleVaultEncryptedUnicode method __rmod__
    # behaves the same way on both Python 2.7 and Python 3.6
    # in different situations

    # Test data
    s = AnsibleVaultEncryptedUnicode('test')
    # Just a stub, cause __rmod__ method calls __mod__ method of
    # a template parameter, which is not available in unit tests
    class StubClass:
        def __mod__(self, s):
            return 's'

    t1 = StubClass()
    t2 = StubClass()
    r = 'test'

    # Python 2.7 behavior
    assert s.__rmod__(t1) == r

    # Python 3.6 behavior
    assert s.__rmod__(t2) == r


# Generated at 2022-06-23 05:48:48.733148
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    class TestVault(object):
        def encrypt(self, seq, secret):
            return 'encrypted: ' + seq
        def decrypt(self, seq, obj=None):
            return 'decrypted: ' + seq
        def is_encrypted(self, seq):
            return True
    s = AnsibleVaultEncryptedUnicode.from_plaintext('decrypted: text', TestVault(), None)
    assert s == 'decrypted: text'
    assert s.expandtabs(4) == 'decrypted:     text'



# Generated at 2022-06-23 05:48:54.695295
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    av = AnsibleVaultEncryptedUnicode("Hello!")
    assert(av.find("llo") == 2)
    assert(av.find("LLO") == -1)
    assert(av.find("!") == 5)
    av2 = AnsibleVaultEncryptedUnicode("Hello!")
    assert(av.find(av2) == 0)
    assert(av.find(av2, 1) == -1)



# Generated at 2022-06-23 05:48:56.501963
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    assert AnsibleVaultEncryptedUnicode('test', None).capitalize() == 'Test'


# Generated at 2022-06-23 05:49:08.495698
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    assert AnsibleVaultEncryptedUnicode(b'\xff').isascii() is False
    assert AnsibleVaultEncryptedUnicode(b'\x7f').isascii() is True
    assert AnsibleVaultEncryptedUnicode(b'\x00').isascii() is True
    assert AnsibleVaultEncryptedUnicode(b'\x01').isascii() is True
    assert AnsibleVaultEncryptedUnicode(b'\x08').isascii() is True
    assert AnsibleVaultEncryptedUnicode(b'\t').isascii() is True
    assert AnsibleVaultEncryptedUnicode(b'\n').isascii() is True

# Generated at 2022-06-23 05:49:13.119426
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert not AnsibleVaultEncryptedUnicode('Hello World')
    assert AnsibleVaultEncryptedUnicode(b'Hello World') == 'Hello World'


# Generated at 2022-06-23 05:49:25.600726
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    # Assume that the following lines are used in a playbook
    # - vars:
    #     v1: ansible-vault encrypted text
    # - name: print title of v1
    #     debug: msg={{ v1.title() }}
    #
    # to run unit test, execute the following command:
    # PYTHONPATH=lib python -m ansible.utils.unsafe_proxy ansible_vault_encrypt_unicode
    v1 = AnsibleVaultEncryptedUnicode('I am a title string')
    v1.ansible_pos = ['', 1, 1]
    print(v1.title())

if __name__ == '__main__':
    test_AnsibleVaultEncryptedUnicode_title()



# Generated at 2022-06-23 05:49:33.430573
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    v = '\n\tvault |\n  ENC[AES256_GCM,data:pvzJUw==,iv:I6WOQ2JHG6dtlR6X9FgY1Q==,\
        tag:Rn50gSbFc+sHsEo4CqxXqg==,type:str]\n'
    avu = AnsibleVaultEncryptedUnicode(v)
    assert avu[0] == '\n'
    print(avu.data)
    assert avu.data == 'test'
    assert avu.lower() == AnsibleVaultEncryptedUnicode.from_plaintext('test', vault=None, secret='test')



# Generated at 2022-06-23 05:49:41.879780
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    o = AnsibleVaultEncryptedUnicode("1")
    o2 = AnsibleVaultEncryptedUnicode("2")
    if not (o >= "1" and o2 >= "1"):
        raise AssertionError("A AnsibleVaultEncryptedUnicode is not greater than or equal to"
                             "'1'")
    else:
        print("Test AnsibleVaultEncryptedUnicode passed test")

if __name__ == "__main__":
    test_AnsibleVaultEncryptedUnicode___ge__()

# Generated at 2022-06-23 05:49:54.049289
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:50:05.934551
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    maketrans = AnsibleVaultEncryptedUnicode.maketrans
    from_encrypt = AnsibleMapping({"a": "ali", "b": "baba"})
    to_encrypt = AnsibleMapping({"a": "baba", "b": "ali"})
    ave = AnsibleVaultEncryptedUnicode.from_plaintext
    a = to_encrypt
    b = from_encrypt
    table = maketrans(a, b)

    # initial value
    assert ave("ababababababab", ave.vault, secret=None).translate(table) == "alialialialiali"

    # change 'baba' in the translate table
    to_encrypt["a"] = "ali"

# Generated at 2022-06-23 05:50:14.211803
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    # Test with an AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode("Hello World")
    assert avu.index("World") == 6
    try:
        avu.index("world")
    except ValueError:
        pass
    else:
        raise Exception("Failed to throw expected exception")

    # Test with a string
    avu = AnsibleVaultEncryptedUnicode("Hello World")
    assert avu.index("World") == 6
    try:
        avu.index("world")
    except ValueError:
        pass
    else:
        raise Exception("Failed to throw expected exception")


# Generated at 2022-06-23 05:50:21.968024
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    from ansible.vars import AnsibleVars

    ds = '/path/to/my/file.yml'
    line = 42
    col = 21

    data = 'test_data'

    # test basic constructor
    base = AnsibleBaseYAMLObject()
    assert base.ansible_pos == (None, 0, 0)
    assert data not in base

    # test constructor with data from AnsibleVars
    base = AnsibleBaseYAMLObject(AnsibleVars(ds, line, col))
    assert base.ansible_pos == (ds, line, col)

    # test constructor with data from dict
    base = AnsibleBaseYAMLObject({'_ds': ds, '_line': line, '_col': col})

# Generated at 2022-06-23 05:50:22.393637
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    pass



# Generated at 2022-06-23 05:50:31.019186
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    from ansible.parsing.vault import VaultLib
    seq = 'This is a test'
    avueu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, VaultLib(), 'test')

    assert avueu.rindex('test') == 11
    assert avueu.rindex('test', 0) == 11
    assert avueu.rindex('test', 0, 8) == -1
    assert avueu.rindex('test', 9, -1) == 11
    assert avueu.rindex('test', -10, -1) == 11



# Generated at 2022-06-23 05:50:41.609447
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:50:52.574504
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    import ansible.parsing.vault as vault
    secret = "secret"
    plaintext = "plaintext"
    ciphertext = vault.VaultLib.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault.VaultLib(secret)

    assert (plaintext > ciphertext) is False
    assert (plaintext > avu) is True
    assert (ciphertext > plaintext) is False
    assert (ciphertext > avu) is False
    assert (avu > plaintext) is False
    assert (avu > ciphertext) is True
    assert (avu > avu) is False


# Generated at 2022-06-23 05:51:01.288017
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    assert AnsibleVaultEncryptedUnicode(to_bytes(' ')).isspace()
    assert AnsibleVaultEncryptedUnicode(to_bytes('\t')).isspace()
    assert AnsibleVaultEncryptedUnicode(to_bytes('\n')).isspace()
    assert AnsibleVaultEncryptedUnicode(to_bytes('')).isspace() is False
    assert AnsibleVaultEncryptedUnicode(to_bytes('helloworld')).isspace() is False



# Generated at 2022-06-23 05:51:07.199907
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    from ansible.parsing.vault import VaultLib
    import random

    charset = VaultLib.CHARSET_ALPHA_NUM
    length = random.randrange(1, 50)
    x = ''.join(random.sample(charset, length))
    avu = AnsibleVaultEncryptedUnicode(x)
    assert avu.data.isdecimal() == avu.isdecimal()



# Generated at 2022-06-23 05:51:15.200857
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    from unittest import TestCase
    from ansible.utils.vault import VaultLib
    class TestCaseSplit(TestCase):
        def test_case_sensitive(self):
            vault = VaultLib([])
            ciphertext = b'$ANSIBLE_VAULT;1.1;AES256\n36303331393334306535333763643963313166656363396636633764353163366636393063393234\n66663539303533386466353430376337393636666564656632636533323336306131303064653539\n'
            data = 'string'
            secret = 'test'
            avu = AnsibleVaultEncryptedUnicode.from_plaintext(data, vault, secret)

# Generated at 2022-06-23 05:51:23.100812
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    assert 'Foo'.upper() == AnsibleVaultEncryptedUnicode('Foo').upper()
    assert AnsibleVaultEncryptedUnicode('Foo').upper() == AnsibleVaultEncryptedUnicode('Foo').upper()
    assert AnsibleVaultEncryptedUnicode('Foo').upper() != AnsibleVaultEncryptedUnicode('foo').upper()
    assert AnsibleVaultEncryptedUnicode('foo').upper() != AnsibleVaultEncryptedUnicode('bar').upper()


# Generated at 2022-06-23 05:51:29.363588
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:51:36.332271
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    if sys.version_info < (3, 3):
        assert not AnsibleVaultEncryptedUnicode('foo').isprintable()
        assert AnsibleVaultEncryptedUnicode(u'foo').isprintable()
    else:
        assert AnsibleVaultEncryptedUnicode('foo').isprintable()
        assert AnsibleVaultEncryptedUnicode(u'foo').isprintable()

# unit test for AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:51:41.481958
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    assert AnsibleVaultEncryptedUnicode('\x10').isprintable() == False
    assert AnsibleVaultEncryptedUnicode('\r\n').isprintable() == False
    assert AnsibleVaultEncryptedUnicode(' ').isprintable() == True
    assert AnsibleVaultEncryptedUnicode('a').isprintable() == True

# Generated at 2022-06-23 05:51:43.906957
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    assert AnsibleVaultEncryptedUnicode('abcabcabcabc').rsplit('b', 1) == ['abcabcabc', 'c']



# Generated at 2022-06-23 05:51:52.798445
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    class DummyVault:
        def encrypt(self, plaintext, bytes):
            assert plaintext == 'test1'
            assert secret == 'secret'
            return 'ciphertext'
        def decrypt(self, ciphertext, bytes):
            assert ciphertext == 'ciphertext'
            assert secret == 'secret'
            return plaintext
        def is_encrypted(self, ciphertext):
            return True

    avu = AnsibleVaultEncryptedUnicode
    plaintext = 'test1'
    secret = 'secret'
    vault = DummyVault()

    avu = AnsibleVaultEncryptedUnicode(plaintext)
    assert avu.replace('test', 'other') == 'other1'

    avu = avu.from_plaintext(plaintext, vault, secret)
    assert avu.replace

# Generated at 2022-06-23 05:51:56.644004
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    """Ensure that isdecimal returns True only if the entire string is decimal."""
    assert AnsibleVaultEncryptedUnicode('1234').isdecimal()
    assert not AnsibleVaultEncryptedUnicode('1234abc').isdecimal()
    assert AnsibleVaultEncryptedUnicode('12.34').isdecimal()


# Generated at 2022-06-23 05:52:01.417263
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # The current method to check the encrypted state is just to check the first
    # five bytes of the ciphertext.
    # bytes([6, 0, 0, 0]) is the header of pycrypto
    # b'$ANSIBLE_VAULT' is the header of ansible vault
    # ansible vault uses AES256 as default cipher
    assert(AnsibleVaultEncryptedUnicode(b'\x06\x00\x00\x00' + b'\x0A\x00\x00\x00' + b'\x00\x00\x00\x00').is_encrypted())
    assert(AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT').is_encrypted())

# Generated at 2022-06-23 05:52:09.481183
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    """
    This test checks if the title method works in the same way
    as the normal string title method
    """
    # Normal string title method
    normal_string_title_method = "hello world"
    normal_string_title_method_return = normal_string_title_method.title()
    assert(normal_string_title_method_return == "Hello World")
    # AnsibleVaultEncryptedUnicode title method
    ansible_vault_encrypted_unicode_title_method = AnsibleVaultEncryptedUnicode.from_plaintext(
        "hello world",
        vault=None,
        secret=None
    )
    ansible_vault_encrypted_unicode_title_method_return = ansible_vault_encrypted_unicode_title_method.title()

# Generated at 2022-06-23 05:52:17.636548
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    s = AnsibleVaultEncryptedUnicode.from_plaintext('abcd',None,None)
    assert ' ' * 8 + 'b' == s.expandtabs(8)[1]
    assert ' ' * 4 + 'b' == s.expandtabs(4)[1]
    assert ' ' * 2 + 'b' == s.expandtabs(2)[1]
    assert ' ' + 'b' == s.expandtabs(1)[1]
    assert '        b' == s.expandtabs(0)[1]
    assert '    b' == s.expandtabs(-8)[1]



# Generated at 2022-06-23 05:52:29.269284
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    # Build up some test data
    stripped_data = "hello, world!"
    leading_data = "abc"
    trailing_data = "xyz"
    test_data = leading_data + stripped_data + trailing_data

    # Load test data into an AnsibleVaultEncryptedString
    avus = AnsibleVaultEncryptedUnicode(test_data)

    # Test the lstrip method
    assert avus.lstrip() == stripped_data
    assert avus.lstrip(leading_data) == stripped_data
    assert avus.lstrip(leading_data[0]) == stripped_data
    assert avus.lstrip(leading_data[-1]) == stripped_data
    assert avus.lstrip(leading_data[-2]) == leading_data[-2:] + stripped_data