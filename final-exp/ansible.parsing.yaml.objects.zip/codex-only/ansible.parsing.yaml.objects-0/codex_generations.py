

# Generated at 2022-06-23 05:42:28.382242
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    from ansible.parsing.vault import VaultLib
    try:
        from unittest import mock
    except ImportError:
        import mock

    vault = VaultLib('password')

    # use mock to simulate decrypt function
    vault.decrypt = mock.MagicMock(return_value=b'hello')
    test_ciphertext = vault.encrypt(b"hello")

    # test with string format, not include '{}'
    avu = AnsibleVaultEncryptedUnicode(test_ciphertext)
    avu.vault = vault
    avu_format = avu.format()
    assert avu_format == 'hello'

    # test with string format, include '{}'
    avu = AnsibleVaultEncryptedUnicode(test_ciphertext)
    avu.v

# Generated at 2022-06-23 05:42:37.264181
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    # test for replace method with the same AnsibleVaultEncryptedUnicode class
    avu = AnsibleVaultEncryptedUnicode('hello world')
    avu_replaced = avu.replace(avu, 'bye world')
    assert avu_replaced == 'bye world'

    # test for replace method with the same AnsibleVaultEncryptedUnicode class
    # with a different class
    avu = AnsibleVaultEncryptedUnicode('hello world')
    avu_replaced = avu.replace('hello', 'bye')
    assert avu_replaced == 'bye world'

    # test for replace method with the same AnsibleVaultEncryptedUnicode class
    # with a different class
    avu = AnsibleVaultEncryptedUnicode('hello world')

# Generated at 2022-06-23 05:42:41.288686
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    assert int(AnsibleVaultEncryptedUnicode('5')) == 5
    assert int(AnsibleVaultEncryptedUnicode('5'))+2 == 7


# Generated at 2022-06-23 05:42:46.383573
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    secret = 'secret'
    plain = AnsibleVaultEncryptedUnicode.from_plaintext('password', vault=vault, secret=secret)
    index = plain.index('s')
    assert index == 1



# Generated at 2022-06-23 05:42:48.434949
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    avu = AnsibleVaultEncryptedUnicode("This is a test")
    assert avu.isidentifier() == False


# Generated at 2022-06-23 05:42:57.515075
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    class AnsibleVaultUnicode(AnsibleVaultEncryptedUnicode):
        def __init__(self, data):
            super(AnsibleVaultUnicode, self).__init__(data)
            self.vault = None

    secret = 'password'
    #This is the encrypted string of 'secret_key'

# Generated at 2022-06-23 05:43:03.477483
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    import unittest
    import ansible.plugins.vault as vault
    import ansible.plugins.vault.VaultLib
    import ansible.plugins.vault.VaultEditor

    class TestAnsibleVaultEncryptedUnicode___lt__(unittest.TestCase):
        def setUp(self):
            super(TestAnsibleVaultEncryptedUnicode___lt__, self).setUp()
            self.secret = 'password'
            self.vault = ansible.plugins.vault.VaultLib(self.secret)

        def test_avu_lt_str_true(self):
            '''
            Test AnsibleVaultEncryptedUnicode.__lt__(str) is True
            '''
            seq = '1'
            avu = AnsibleVaultEncryptedUnic

# Generated at 2022-06-23 05:43:12.212350
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password='test')

    try:
        text = AnsibleVaultEncryptedUnicode.from_plaintext('a' * 16, vault, 'test')
        text.index(AnsibleVaultEncryptedUnicode.from_plaintext('b' * 16, vault, 'test'))

        text = AnsibleVaultEncryptedUnicode.from_plaintext('a' * 16, vault, 'test')
        text.index('b' * 16)
    except ValueError as e:
        assert False


# Generated at 2022-06-23 05:43:20.888686
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    from random import randrange
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-23 05:43:26.230140
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib([])
    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, 'secret')
    assert encrypted_string.translate({ord('a'): None}) == 'bc'



# Generated at 2022-06-23 05:43:37.163823
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.hostvars import HostVarsVars
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret = VaultSecret('test')
    vault = VaultLib(secret)
    secret.password = 'test'

    avu = AnsibleVaultEncryptedUnicode(vault.encrypt('test'))
    avu.vault = vault

    assert avu.rsplit(sep=' ', maxsplit=0) == ['test']
    assert avu.rsplit(sep=' ', maxsplit=1) == ['test']

# Generated at 2022-06-23 05:43:46.097480
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    # Check that if the template is not an AnsibleVaultEncryptedUnicode the
    # result is the same as format()
    template = '%s'
    assert AnsibleVaultEncryptedUnicode(b'World') % template == AnsibleVaultEncryptedUnicode(b'World').format(template)
    # Check that if AnsibleVaultEncryptedUnicode object is used as template it
    # returns the same result as format()
    template = AnsibleVaultEncryptedUnicode(b'%s')
    assert AnsibleVaultEncryptedUnicode(b'World') % template == AnsibleVaultEncryptedUnicode(b'World').format(template)

AnsibleVaultEncryptedUnicode.__rmod__.__test__ = False



# Generated at 2022-06-23 05:43:55.734311
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    # Create an AnsibleVaultEncryptedUnicode for testing
    aveu = AnsibleVaultEncryptedUnicode("My String")

    # Test AnsibleVaultEncryptedUnicode with another string
    assert aveu.__ge__("My String")
    assert aveu.__ge__("My String2")
    assert not aveu.__ge__("My String1")

    # Test AnsibleVaultEncryptedUnicode with another AnsibleVaultEncryptedUnicode
    bveu = AnsibleVaultEncryptedUnicode("My String")
    assert aveu.__ge__(bveu)
    bveu = AnsibleVaultEncryptedUnicode("My String2")
    assert aveu.__ge__(bveu)
    bveu = AnsibleVaultEnc

# Generated at 2022-06-23 05:44:01.809643
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    """Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode"""
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('mysecret')
    # when not encrypted, act like a string
    avu = AnsibleVaultEncryptedUnicode('not encrypted')
    avu.vault = vault
    # Show that it is a different class
    assert type(avu) != type('not encrypted')
    assert hash('not encrypted') == hash(avu)

    # still a different class
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('encrypted', vault, 'mypassword')
    # Show that it is a different class
    assert type(avu) != type('encrypted')
    # Show that it matches the __hash__ of the decrypted value

# Generated at 2022-06-23 05:44:10.054670
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    avu = AnsibleVaultEncryptedUnicode('a\tb\tc')
    men = avu.expandtabs()
    assert men == 'a       b       c'


# Generated at 2022-06-23 05:44:20.089423
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    encrypted_text = AnsibleVaultEncryptedUnicode.from_plaintext("Hello World", vault, "ansible")
    assert encrypted_text.format("{}") == encrypted_text
    assert encrypted_text.format("{}".format("test")) == "test"


yaml.add_representer(AnsibleVaultEncryptedUnicode,
                     lambda dumper, data: dumper.represent_scalar(
                         u'!vault', u'$ANSIBLE_VAULT;1.1;AES256;ansible\n%s\n' % data.data))


# These are only here to retain the old API of having a global
# function called ``load`` which is now handled by the class
# Ansible

# Generated at 2022-06-23 05:44:23.447704
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    s = AnsibleVaultEncryptedUnicode.from_plaintext(u'foo', None, None)
    assert s.isprintable()

    s = AnsibleVaultEncryptedUnicode.from_plaintext(u'foo\n', None, None)
    assert not s.isprintable()


# Generated at 2022-06-23 05:44:29.833966
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    class AnsibleVault:
        def encrypt(self, value, secret):
            return str.encode(value)

        def decrypt(self, value, secret, obj=None):
            return to_text(value, errors='surrogate_or_strict')

        def is_encrypted(self, value):
            return False

    av = AnsibleVaultEncryptedUnicode('foo')
    av.vault = AnsibleVault()

    assert av * 1 == 'foo'
    assert 1 * av == 'foo'
    assert av == 'foo'

# Generated at 2022-06-23 05:44:32.963012
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    data = AnsibleVaultEncryptedUnicode('something')

    # Test that hash() works even if .data returns an empty string
    data.data = ''
    hash(data)


# Generated at 2022-06-23 05:44:43.006260
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:44:52.149520
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    av = AnsibleVaultEncryptedUnicode('Vault')
    av_num = AnsibleVaultEncryptedUnicode('12345')
    assert(av.rfind('u') == 3)
    assert(av.rfind('u', 0, 2) == -1)
    assert(av.rfind('V') == 0)
    assert(av.rfind('V', 1, 4) == -1)
    assert(av_num.rfind('2') == 3)
    assert(av_num.rfind('3', 2, 4) == -1)
    assert(av_num.rfind('1') == 0)
    assert(av_num.rfind('1', 1, 4) == -1)



# Generated at 2022-06-23 05:45:02.809617
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    from ansible.parsing.vault import VaultLib

    def do_test(value, expectation):
        vault = VaultLib(password='password')
        encrypted = vault.encrypt(value)
        avu = AnsibleVaultEncryptedUnicode(encrypted)
        avu.vault = vault
        assert str(avu) == expectation

    do_test(u'\u5341\u56db', '\xe5\x90\x88\xe5\x9b\x9b')
    do_test(u'\u65e5', '\xe6\x97\xa5')
    do_test(u'\u672c\u5f0f', '\xe6\x9c\xac\xe5\xbc\x8f')

# Generated at 2022-06-23 05:45:15.825807
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing import vault
    import sys
    if sys.version_info[0] == 3:
        unichr = chr
    plaintext_value = unichr(0x00E9)
    plaintext = AnsibleVaultEncryptedUnicode(plaintext_value)
    ciphertext = VaultLib.encrypt(plaintext, 'password')
    encrypted = AnsibleVaultEncryptedUnicode(ciphertext)
    print(encrypted.data)
    print(encrypted.islower())
    assert encrypted.islower() == True

# Generated at 2022-06-23 05:45:19.836105
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    str = AnsibleVaultEncryptedUnicode('hello world')
    assert str.rfind('ello') == 1
    assert str.rfind(str) == 0
    assert str.rfind('ello', 2) == -1


# Generated at 2022-06-23 05:45:22.933764
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    a = AnsibleVaultEncryptedUnicode.__new__(text_type)
    a.data = "abc"

    b = a.center(6,"-")

    assert b == "--abc--"


# Generated at 2022-06-23 05:45:27.015251
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    assert AnsibleVaultEncryptedUnicode(u'ab').upper() == u'AB'
    assert AnsibleVaultEncryptedUnicode(u'AB').upper() == u'AB'



# Generated at 2022-06-23 05:45:33.311919
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    # Test empty strings
    assert AnsibleVaultEncryptedUnicode('').find(AnsibleVaultEncryptedUnicode('')) == 0
    assert AnsibleVaultEncryptedUnicode('').find('') == 0
    assert AnsibleVaultEncryptedUnicode('').find(AnsibleVaultEncryptedUnicode(''), start=0) == 0
    assert AnsibleVaultEncryptedUnicode('').find('') == 0
    assert AnsibleVaultEncryptedUnicode('').find(AnsibleVaultEncryptedUnicode(''), start=0, end=_sys.maxsize) == 0
    assert AnsibleVaultEncryptedUnicode('').find('') == 0

    # Test substrings

# Generated at 2022-06-23 05:45:41.902743
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():

    ### tests using unicode as argument
    s = AnsibleVaultEncryptedUnicode.from_plaintext(u' ', None, None)
    assert s.split() == [s]

    s = AnsibleVaultEncryptedUnicode.from_plaintext(u" \t", None, None)
    assert s.split() == [s]

    s = AnsibleVaultEncryptedUnicode.from_plaintext(u'"""', None, None)
    assert s.split() == [s]

    s = AnsibleVaultEncryptedUnicode.from_plaintext(u'hi', None, None)
    assert s.split() == [s]

    s = AnsibleVaultEncryptedUnicode.from_plaintext(u'hihihi', None, None)

# Generated at 2022-06-23 05:45:44.444794
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
  avueu = AnsibleVaultEncryptedUnicode("hello")
  assert avueu.__complex__() == (0+0j)

# Generated at 2022-06-23 05:45:55.348104
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    msg = "AnsibleVaultEncryptedUnicode.__float__ is broken"
    v = AnsibleVaultEncryptedUnicode.from_plaintext('123.456', None, None)
    assert float(v) == 123.456, msg
    v = AnsibleVaultEncryptedUnicode.from_plaintext('123,456', None, None)
    try:
        float(v)
        raise AssertionError(msg)
    except ValueError:
        pass
    v = AnsibleVaultEncryptedUnicode.from_plaintext('abc', None, None)
    try:
        float(v)
        raise AssertionError(msg)
    except ValueError:
        pass
    v = AnsibleVaultEncryptedUnicode.from_plaintext('', None, None)

# Generated at 2022-06-23 05:46:03.219959
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    av = AnsibleVaultEncryptedUnicode.from_plaintext('abc', None, None)
    test_string = 'test {a} {c}'
    mapping = {'a': '123', 'c': '456'}
    assert av.format_map(mapping) == 'test 123 456'
    assert test_string.format_map(mapping) == 'test 123 456'
    assert av.format_map(av.__class__.__dict__) == 'abc'
    assert test_string.format_map(av.__class__.__dict__) == test_string



# Generated at 2022-06-23 05:46:05.911981
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    a = AnsibleVaultEncryptedUnicode("a")
    a.center(1)


# Generated at 2022-06-23 05:46:16.998063
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    # Test 0
    ciphertext = 'Ali\xe2\x80\x99s\xe2\x80\x99s\xe2\x80\x99s\xe2\x80\x99s\xe2\x80\x99s\xe2\x80\x99s'
    # ciphertext_list = list(ciphertext)
    ciphertext_list = [x for x in ciphertext]
    print('ciphertext_list = %s' % repr(ciphertext_list))  # [A, l, i, â, €, s, €, s, â, €, s, â, €, s, â, €, s, €, s, â, €, s]

# Generated at 2022-06-23 05:46:20.212324
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    ansible_vault_encrypted_unicode_class_instance = AnsibleVaultEncryptedUnicode(pwd('changeme'))
    length = ansible_vault_encrypted_unicode_class_instance.__len__()
    assert (length == 8)



# Generated at 2022-06-23 05:46:26.892525
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:46:34.720825
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    input_string = to_text('a,b,c,d,e,f', encoding='utf-8')
    expected_output = ['a', 'b', 'c', 'd', 'e', 'f']
    ansible_vault_unicode_object = AnsibleVaultEncryptedUnicode(input_string)
    assert ansible_vault_unicode_object.split(',') == expected_output
    assert ansible_vault_unicode_object.split(',', 2) == ['a', 'b', 'c,d,e,f']


# Generated at 2022-06-23 05:46:44.227994
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    data = AnsibleVaultEncryptedUnicode('abc\ndef\n')
    assert data.splitlines() == ['abc', 'def', '']
    assert data.splitlines(keepends=True) == ['abc\n', 'def\n', '\n']
    assert data.splitlines(True) == ['abc\n', 'def\n', '\n']

    data = AnsibleVaultEncryptedUnicode('abc\rdef\r')
    assert data.splitlines() == ['abc', 'def', '']
    assert data.splitlines(keepends=True) == ['abc\r', 'def\r', '\r']
    assert data.splitlines(True) == ['abc\r', 'def\r', '\r']


# Generated at 2022-06-23 05:46:53.432999
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    '''
    Unit test for constructor of class AnsibleVaultEncryptedUnicode

    This method cannot be called by AnsibleUnicode() because the
    constructor AnsibleVaultEncryptedUnicode() requires a vault object
    as input, which does not get created until after the yaml parser
    is run.
    '''
    # TODO: refactor this, it's pretty bad
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.parsing.vault import AnsibleVaultError
    from ansible.parsing.vault import get_file_vault_secrets
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, _read_vault_y

# Generated at 2022-06-23 05:46:58.858729
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    import unittest
    import unittest.mock

    # Setup
    ciphertext = b'bar'
    vault = unittest.mock.Mock()
    vault.decrypt.return_value = b'123.456'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    # Test
    result = avu.__float__()

    # Verify
    assert result == 123.456



# Generated at 2022-06-23 05:47:07.262945
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    av = AnsibleVaultEncryptedUnicode.from_plaintext('the.secret.string\n')

    assert av.data == 'the.secret.string\n'
    assert av.splitlines() == ['the.secret.string\n']
    assert av.splitlines(True) == ['the.secret.string\n']

    av = AnsibleVaultEncryptedUnicode.from_plaintext('the.secret.string')

    assert av.data == 'the.secret.string'
    assert av.splitlines() == ['the.secret.string']
    assert av.splitlines(True) == ['the.secret.string']

    av = AnsibleVaultEncryptedUnicode.from_plaintext('the.secret.string\n second line')


# Generated at 2022-06-23 05:47:14.735436
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    class MockVault(object):
        def decrypt(self, ciphertext):
            return b'10.0'

        def encrypt(self, plaintext):
            return b'encrypted'

    ciphertext = b'vaulted'
    vault = MockVault()
    avu = AnsibleVaultEncryptedUnicode(ciphertext=ciphertext)
    avu.vault = vault
    assert(avu.__float__() == 10.0)



# Generated at 2022-06-23 05:47:26.798127
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    '''
    Unit test for the index method of AnsibleVaultEncryptedUnicode
    '''
    import ansible.parsing.vault
    vault = ansible.parsing.vault.VaultLib('testvalue')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('1234567890', vault, 'testvalue')
    try:
        print(avu.index('4'))
    except Exception as e:
        print('index exception "' + str(e) + '"')
        print(type(avu))
        raise
    except:
        print("index unknown exception")
        print(type(avu))
        raise

# Generated at 2022-06-23 05:47:32.010705
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    ciphertext = to_bytes('$ANSIBLE_VAULT;1.1;AES256\n36626135356531616434323139346463663135643663313164366635643730386465373564333739\n653564363337643536353833356633666639306433313662343739630a3735396438373837343532\n61336661396139323461366138343638613833653762623365653633')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vaultlib.VaultLib('hunter2')
    assert avu.isalpha() == True

# Generated at 2022-06-23 05:47:36.410045
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    avu = AnsibleVaultEncryptedUnicode('ABCdefghij')
    assert avu[:3] == 'ABC'
    assert avu[3:6] == 'def'
    assert avu[3:] == 'defghij'
    assert avu[-3:] == 'hij'


# Generated at 2022-06-23 05:47:42.713482
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    if sys.version_info >= (3,0,0):
        assert(not AnsibleVaultEncryptedUnicode.from_plaintext('', None, None).isnumeric())
        assert(AnsibleVaultEncryptedUnicode.from_plaintext('123', None, None).isnumeric())
        assert(AnsibleVaultEncryptedUnicode.from_plaintext('x123', None, None).isnumeric())
        assert(AnsibleVaultEncryptedUnicode.from_plaintext('x123x', None, None).isnumeric())



# Generated at 2022-06-23 05:47:52.709411
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    # Test for method __complex__(...)
    # Failure to calculate the complex number
    assert_func = AnsibleVaultEncryptedUnicode.from_plaintext("10.0", None, None)
    assert_func.data = to_text("10.0")
    assert_func.__complex__()

    # An empty string is not a valid complex number
    assert_func = AnsibleVaultEncryptedUnicode.from_plaintext("", None, None)
    try:
        assert_func.__complex__()
    except ValueError:
        pass
    else:
        raise AssertionError("A ValueError should have been raised")


# Generated at 2022-06-23 05:47:56.871598
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    s = AnsibleVaultEncryptedUnicode(b'aabbcc')
    assert(s.split() == [u'aabbcc'])


# Generated at 2022-06-23 05:48:06.869401
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    ciphertext = b'1234567890'
    avu = AnsibleUnicode(ciphertext)
    assert not avu.islower(), "For plaintext, this should return False"
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert not avu.islower(), "For ciphertext, this should return False"
    assert not avu.islower(), "For plaintext, this should return False"
    avu = AnsibleVaultEncryptedUnicode(b'aBcDeFg')
    assert not avu.islower(), "For ciphertext, this should return False"
    assert avu.islower(), "For plaintext, this should return True"


# Generated at 2022-06-23 05:48:15.280896
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    from ansible.plugins.vault import VaultLib
    v = VaultLib(password='foo')
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('123\n', v, 'foo')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('456\n', v, 'foo')
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext('abc\n', v, 'foo')
    assert to_text(avu1 + avu2) == '123\n456\n'
    assert to_text(avu2 + avu3) == '456\nabc\n'



# Generated at 2022-06-23 05:48:20.649944
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    from .ansible_vault import VaultLib
    vault = VaultLib('ansible')
    plaintext = 'foo\n'
    secret = 'ansible'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.rstrip() == 'foo'

# Generated at 2022-06-23 05:48:26.030420
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    ascii_str = 'unicode'
    ascii_str_expected = 'Unicode'
    ascii_str_actual = AnsibleVaultEncryptedUnicode(ascii_str).capitalize()
    assert ascii_str_actual == ascii_str_expected


# Generated at 2022-06-23 05:48:30.550304
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    vault = None
    secret = 'secret'
    seq = 'abcdef'
    sep = 'c'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu.rpartition(sep) == ('ab', 'c', 'def')

# Generated at 2022-06-23 05:48:32.667393
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    # Testing for isupper method
    assert AnsibleVaultEncryptedUnicode('ABC').isupper() == True


# Generated at 2022-06-23 05:48:41.195832
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    from vaultlib.vault import VaultLib
    import tempfile
    tf = tempfile.NamedTemporaryFile(mode='w+')
    vault = VaultLib(filename=tf.name, password='ansible')
    #create a decrypted string
    data = 'asdf1234'
    # create an encrypted string with AnsibleVaultEncryptedUnicode.from_plaintext
    enc_data = AnsibleVaultEncryptedUnicode.from_plaintext(data, vault, 'ansible')
    assert enc_data.endswith('4')
    assert not enc_data.endswith('5')

# The following is taken from a StackOverflow answer:
# http://stackoverflow.com/questions/5121931/in-python-how-can-you-load-yaml-mappings-as-ordered

# Generated at 2022-06-23 05:48:53.213390
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # test __lt__ method of class AnsibleVaultEncryptedUnicode
    # check __lt__ compares AnsibleVaultEncryptedUnicode objects to byte-strings only if all other comparisons fail
    avu = AnsibleVaultEncryptedUnicode("foo")
    assert avu < 'bar'
    assert avu < 'foobar'
    assert not (avu < 'foo')
    assert not (avu < 'fo')
    assert not (avu < 'f')
    # check __lt__ compares AnsibleVaultEncryptedUnicode objects to unicode-strings if all other comparisons fail
    assert avu < 'bar'
    assert avu < 'foobar'
    assert not (avu < 'foo')
    assert not (avu < 'fo')
    assert not (avu < 'f')
    # check

# Generated at 2022-06-23 05:49:02.037797
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    d = AnsibleVaultEncryptedUnicode.from_plaintext('abc', 'asd', 'qwe')
    assert d.islower(), '"abc" should be lower case'
    d = AnsibleVaultEncryptedUnicode.from_plaintext('ABC', 'asd', 'qwe')
    assert not d.islower(), '"ABC" should not be lower case'
    d = AnsibleVaultEncryptedUnicode.from_plaintext('Abc', 'asd', 'qwe')
    assert not d.islower(), '"Abc" should not be lower case'
    d = AnsibleVaultEncryptedUnicode.from_plaintext('abC', 'asd', 'qwe')
    assert not d.islower(), '"abC" should not be lower case'
    d = Ansible

# Generated at 2022-06-23 05:49:11.685153
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    import pytest

    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('\n\r')
    assert ['\n', '\r'] == ansible_vault_encrypted_unicode.splitlines()

    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('\n\r\n')
    assert ['\n', '\r\n'] == ansible_vault_encrypted_unicode.splitlines()

    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('\n\r\n')
    assert ['\n\r\n'] == ansible_vault_encrypted_unicode.splitlines(keepends=False)

    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:49:17.269614
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    val1 = AnsibleVaultEncryptedUnicode("myuser")
    val2 = "ansible_ssh_user=%(val1)s"
    assert val1.__rmod__(val2) == "ansible_ssh_user=myuser"


# this class is copied from the vault module:

# Generated at 2022-06-23 05:49:21.664421
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    data = "123"
    avu = AnsibleVaultEncryptedUnicode(data)
    assert avu.isdecimal() == True, "expected True"

    data = "123a"
    avu = AnsibleVaultEncryptedUnicode(data)
    assert avu.isdecimal() == False, "expected False"


# Generated at 2022-06-23 05:49:27.255531
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    assert AnsibleVaultEncryptedUnicode("AnsiBle").istitle()
    assert AnsibleVaultEncryptedUnicode("AnsiBleVault").istitle()
    assert not AnsibleVaultEncryptedUnicode("ansiBleVault").istitle()
    assert not AnsibleVaultEncryptedUnicode("ansiBle").istitle()


# Generated at 2022-06-23 05:49:37.760999
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret = b'password'

# Generated at 2022-06-23 05:49:50.673656
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-23 05:49:55.867510
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    test_str = u"abc123"
    avu = AnsibleVaultEncryptedUnicode(test_str)
    assert avu.isdigit() == False
    test_str = u"123"
    avu = AnsibleVaultEncryptedUnicode(test_str)
    assert avu.isdigit() == True


# Generated at 2022-06-23 05:50:01.233326
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    # Prepare input data
    s = 'The \'quick\' brown fox jumps over the \'lazy\' dog'

    # Execute the method with input data
    avu = AnsibleVaultEncryptedUnicode(s)
    result = avu.isascii()

    # Verify the result
    assert result is True


# Generated at 2022-06-23 05:50:11.923467
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # test_ne_string
    aveu1 = AnsibleVaultEncryptedUnicode("hello world")
    aveu2 = AnsibleVaultEncryptedUnicode("hello")
    aveu1.vault = True
    aveu2.vault = True
    assert aveu1 != aveu2

    # test_ne_None
    aveu1 = AnsibleVaultEncryptedUnicode("hello world")
    aveu2 = AnsibleVaultEncryptedUnicode("hello")
    aveu1.vault = True
    aveu2.vault = True
    assert aveu1 != None
    assert aveu2 != None

    # test_ne_int
    aveu1 = AnsibleVaultEncryptedUnicode("hello world")
    ave

# Generated at 2022-06-23 05:50:21.622988
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avue = AnsibleVaultEncryptedUnicode('')
    assert not avue.__eq__('')

    avue = AnsibleVaultEncryptedUnicode(':').data
    assert not avue.__eq__('foo')


# Generated at 2022-06-23 05:50:23.336253
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    assert AnsibleVaultEncryptedUnicode("foo").center(5) == "  foo "


# Generated at 2022-06-23 05:50:30.337055
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    def test(string, sep, expected_result):
        result = AnsibleVaultEncryptedUnicode(string).partition(sep)
        assert result == expected_result

    test('banana', 'a', ('b', 'a', 'nana'))
    test('banana', 'na', ('ba', 'na', 'na'))
    test('banana', 'banana', ('', 'banana', ''))
    test('banana', 'bananas', ('banana', '', ''))
    test('banana', 'b', ('', 'b', 'anana'))
    test('banana', '', ('', '', 'banana'))


# Generated at 2022-06-23 05:50:39.647116
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    # Test cases for method isdigit of class AnsibleVaultEncryptedUnicode
    # 1. Test case: Test isdecimal with non-decimal, non-digit and other
    #    test strings
    # 2. Test case: Test with valid and invalid unicode characters
    # 3. Test case: Test with valid and invalid Unicode strings
    # 4. Test case: Test with valid and invalid BMP character

    # Test case: Test with valid and invalid UTF-8 character
    valid_utf8 = u'\u1234'
    avue = AnsibleVaultEncryptedUnicode(to_bytes(valid_utf8))
    # Since the data is encrypted, it will always return False

# Generated at 2022-06-23 05:50:47.304286
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    import base64
    from ansible.parsing.vault import VaultLib

    test_string = base64.b64decode(b'aGVsbG8gd29ybGQ=')
    vault = VaultLib(password='ansible')
    avue = AnsibleVaultEncryptedUnicode(vault.encrypt(test_string))

    assert avue.encode('utf-8') == b'hello world'
    assert avue.encode('utf-8', errors='ignore') == b'hello world'
    assert avue.encode('utf-8', errors='strict') == b'hello world'
    assert avue.encode('utf-8', errors='replace') == b'hello world'

# Generated at 2022-06-23 05:50:58.058824
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    # test with a single value
    v = AnsibleVaultEncryptedUnicode("the quick brown fox jumps over the lazy dog")
    assert v.find('quick') == 4
    assert v.find('quick', 0) == 4
    assert v.find('quick', 5) == -1
    assert v.find('quick', 1, 5) == -1

    # test with a tuple
    assert v.find(('quick', 'fox')) == 4
    assert v.find(('quick', 'fox'), 0) == 4
    assert v.find(('quick', 'fox'), 5) == 16
    assert v.find(('quick', 'fox'), 1, 5) == -1

    # test with nested tuples
    assert v.find((('quick', 'fox'), 'dog')) == 4

# Generated at 2022-06-23 05:51:05.223779
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    # AVAILABLE_ANSIBLE_VAULT_FORMATS = dict((v.extension, v) for v in _available_vaults.values())
    # available_vaults = AnsibleVaultEncryptedUnicode.AVAILABLE_ANSIBLE_VAULT_FORMATS
    # a = available_vaults['key']
    # b = available_vaults['value']
    # a.capitalize()
    # b.capitalize()
    return True


# Generated at 2022-06-23 05:51:13.831553
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    """
    Test AnsibleVaultEncryptedUnicode.lower()
    """
    # Test with the latest version of vaultlib
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    vault = VaultLib([loader])

    secret = b'$ecret'
    plaintext = u'FoO'
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.lower() == plaintext.lower()



# Generated at 2022-06-23 05:51:17.670119
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    data = "abcd"
    avu = AnsibleVaultEncryptedUnicode(data)
    assert sys.version_info < (3, 0, 0), "Test only for Python 2"
    assert avu % "test", "testabcd"
    assert avu % 1, "1abcd"
    assert avu % 1.0, "1.0abcd"


# Generated at 2022-06-23 05:51:22.889249
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    avu = AnsibleVaultEncryptedUnicode(b"HeLlO")
    assert avu.rjust(9) == "  HeLlO"
    assert avu.rjust(9, "*") == "**HeLlO"
    assert avu.rjust(4) == "HeLlO"


# Generated at 2022-06-23 05:51:33.828751
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    import re

# Generated at 2022-06-23 05:51:38.592131
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    class MyClass(AnsibleBaseYAMLObject):
        pass

    p = MyClass()
    expected = {'_data_source': None, '_line_number': 0, '_column_number': 0}
    assert p._get_ansible_position() == expected
    assert p.ansible_pos == expected



# Generated at 2022-06-23 05:51:46.480855
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    u = to_text(b"Encrypted")
    secret = to_text(b"secret")
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(u, vault, secret)
    assert avu.islower() == False
    u = to_text(b"encrypted")
    secret = to_text(b"secret")
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(u, vault, secret)
    assert avu.islower() == True


# Generated at 2022-06-23 05:51:55.605938
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    class Vault:
        def decrypt(self, pw, *args, **kwargs):
            return pw

    vault = Vault()

    pw = AnsibleVaultEncryptedUnicode.from_plaintext('0123456789', vault=vault, secret='password')
    assert pw.rpartition('234') == ('01', '234', '56789')
    assert pw.rpartition('234') != ('02', '234', '56789')
    assert pw.rpartition('234') != ('01', '235', '56789')
    assert pw.rpartition('234') != ('01', '234', '56799')
    assert pw.rpartition('234') != ('01', '2345', '6789')



# Generated at 2022-06-23 05:52:06.306847
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    # Test when translate is called with a string in which there are
    # characters from the string table.
    s = AnsibleVaultEncryptedUnicode('abc', '')
    assert s.translate(string.maketrans('ab', 'AB')) == 'ABc'

    # Test when translate is called with a string in which there are no
    # characters from the string table.
    s = AnsibleVaultEncryptedUnicode('abc', '')
    assert s.translate(string.maketrans('yz', 'YZ')) == 'abc'

    # Test when translate is called with a string in which there are
    # characters not in the string table. None of these characters are
    # supposed to be removed, translated, or modified.
    s = AnsibleVaultEncryptedUnicode('abc', '')
   

# Generated at 2022-06-23 05:52:17.000065
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    assert AnsibleVaultEncryptedUnicode('FOO').isupper()
    assert not AnsibleVaultEncryptedUnicode('FOO').islower()
    assert AnsibleVaultEncryptedUnicode('FOO').upper() == AnsibleVaultEncryptedUnicode('FOO')
    assert AnsibleVaultEncryptedUnicode('FOO').lower() == AnsibleVaultEncryptedUnicode('foo')

    assert not AnsibleVaultEncryptedUnicode('').isupper()
    assert not AnsibleVaultEncryptedUnicode('').islower()
    assert AnsibleVaultEncryptedUnicode('').upper() == AnsibleVaultEncryptedUnicode('')
    assert AnsibleVaultEncryptedUnicode('').lower() == AnsibleVaultEncryptedUnicode('')