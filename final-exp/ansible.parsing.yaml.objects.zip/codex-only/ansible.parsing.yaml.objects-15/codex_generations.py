

# Generated at 2022-06-23 05:42:31.283050
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    inst = AnsibleVaultEncryptedUnicode("abcabcabcabcabc")
    assert inst.rindex("a") == 0
    assert inst.rindex("b") == 12
    assert inst.rindex("c") == 11
    assert inst.rindex("0") == -1

    assert inst.rindex("a", 4) == 0
    assert inst.rindex("b", 4) == 12
    assert inst.rindex("c", 4) == 11
    assert inst.rindex("0", 4) == -1

    assert inst.rindex("a", 3, 6) == 3
    assert inst.rindex("b", 3, 6) == -1
    assert inst.rindex("c", 3, 6) == 4
    assert inst.rindex("0", 3, 6) == -1


# Generated at 2022-06-23 05:42:38.318595
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    import ansible.parsing.vault
    secret = 'p@ssw0rd'
    test_string = 'test'
    vault = ansible.parsing.vault.Encryptor(secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(test_string, vault, secret)
    assert(avu.upper() == test_string.upper())
    assert(avu == test_string)
    assert(avu.upper == test_string.upper)
    assert(isinstance(avu.upper(), text_type))
    assert(isinstance(avu, AnsibleVaultEncryptedUnicode))


# Generated at 2022-06-23 05:42:44.232091
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    assert AnsibleVaultEncryptedUnicode('A').isupper()
    assert AnsibleVaultEncryptedUnicode('A').isupper() is True
    assert AnsibleVaultEncryptedUnicode('a').isupper() is False
    assert AnsibleVaultEncryptedUnicode('').isupper() is False


# Generated at 2022-06-23 05:42:56.224127
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    '''
    Unit tests to ensure that AnsibleVaultEncryptedUnicode calls the isdigit method of its internal string only.
    '''
    import ansible
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import ansible.module_utils.six as six
    import io

    secret = VaultSecret('SECRET')
    vault = VaultLib(secret)

    string = AnsibleVaultEncryptedUnicode.from_plaintext(six.ensure_text('123'), vault, secret)
    assert string.isdigit() is True

    # By adding a new method to the internal string, we can check its not called.
    def isdigit(self):
        raise AssertionError(
            'Should not call isdigit of internal string.'
        )

# Generated at 2022-06-23 05:42:59.777435
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    pass



# Generated at 2022-06-23 05:43:09.064731
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert int(avu) == 0

    avu.data = '3'
    assert int(avu) == 3
    assert type(int(avu)) == int

    avu.data = '3.14'
    assert int(avu) == 3
    assert type(int(avu)) == int

    avu.data = 'bar'
    assert int(avu) == 0
    assert type(int(avu)) == int

    avu.data = '-3'
    assert int(avu) == -3
    assert type(int(avu)) == int

    avu.data = '-3.14'
    assert int(avu) == -3
    assert type(int(avu)) == int


# Generated at 2022-06-23 05:43:17.056262
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():

    class TestClass(object):
        def __init__(self, obj):
            self.obj = obj
            self.data = obj

        data = property(lambda self: self.obj)

    test_string = TestClass('ansible')

    avue = AnsibleVaultEncryptedUnicode.from_plaintext('ansible', AnsibleVaultAES256(), b'password')

    assert test_string.startswith('ansible')
    assert avue.startswith('ansible')

    assert not test_string.startswith('ans')
    assert not avue.startswith('ans')


# Generated at 2022-06-23 05:43:27.253940
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    assert AnsibleVaultEncryptedUnicode('01234 56789').rstrip('9') == '01234 5678'
    assert AnsibleVaultEncryptedUnicode('01234 56789').rstrip('89') == '01234 567'
    assert AnsibleVaultEncryptedUnicode('01234 56789').rstrip('789') == '01234 567'
    assert AnsibleVaultEncryptedUnicode('01234 56789').rstrip('6789') == '01234 5'
    assert AnsibleVaultEncryptedUnicode('01234 56789').rstrip('56789') == '01234 '
    assert AnsibleVaultEncryptedUnicode('01234 56789').rstrip('456789') == '01234 '

# Generated at 2022-06-23 05:43:30.870667
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    assert AnsibleVaultEncryptedUnicode("a").isalnum()
    assert not AnsibleVaultEncryptedUnicode(" ").isalnum()
    assert not AnsibleVaultEncryptedUnicode("").isalnum()


# Generated at 2022-06-23 05:43:40.484022
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    from ansible.parsing.vault import VaultLib

    secret = 'mysecret'
    vault = VaultLib(secrets=[secret])
    plaintext = open('/etc/hosts','r').read()
    ciphertext = vault.encrypt(plaintext, secret)

    avu_1 = AnsibleVaultEncryptedUnicode.from_plaintext(ciphertext, vault, secret)
    avu_2 = AnsibleVaultEncryptedUnicode.from_plaintext(ciphertext, vault, secret)

    # Make sure the vault encrypted unicode objects are really equal
    assert avu_1 == avu_2

    # Now add these two objects to each other and make sure the result is equal
    avu_3 = avu_1 + avu_2
    avu_4 = avu_2 + av

# Generated at 2022-06-23 05:43:47.760536
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    import ansible.utils.vault as vault
    _vault = vault.VaultLib()
    test_string = u"987654322"
    avue1 = AnsibleVaultEncryptedUnicode.from_plaintext(test_string, _vault, "123456")
    assert avue1.isdecimal() == True, "isdecimal() method is not working correctly"


# Generated at 2022-06-23 05:43:52.525672
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    s = AnsibleSequence(['a', 'b'])
    assert len(s) == 2
    assert s[0] == 'a'
    assert s[1] == 'b'
    assert repr(s) == "AnsibleSequence(['a', 'b'])"
    # we can't test equality as AnsibleSequence subclasses list
    # and list doesn't use __eq__



# Generated at 2022-06-23 05:44:02.265759
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    avu = AnsibleVaultEncryptedUnicode("**VALUE**")
    assert avu.rindex("E") == 4
    assert avu.rindex("E", 4) == 4
    assert avu.rindex("E", 2, 5) == 4
    assert avu.rindex("E", 2, 3) == -1
    assert avu.rindex("E", 0) == 4

    try:
        avu.rindex("Y", 2, 3)
        assert False
    except ValueError:
        assert True

    try:
        avu.rindex("E", 2, 1)
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-23 05:44:14.198166
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    # int width test
    avu = AnsibleVaultEncryptedUnicode(b'abc')
    assert avu.rjust(3) == 'abc'
    avu.vault = vaultlib.VaultLib('password')
    assert avu.rjust(7) == '  abc'
    assert avu.rjust(7, '!') == '!!abc'
    assert avu.rjust(7, '0') == '00abc'
    assert avu.rjust(7, '!0') == '!00abc'


# Generated at 2022-06-23 05:44:27.511778
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('blah')
    secret = 'fakesecret'

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('99.9', vault, secret)
    assert float(avu) == 99.9

    # This should not throw an exception
    try:
        # this is not a float
        avu = AnsibleVaultEncryptedUnicode.from_plaintext('99.9dummytext', vault, secret)
        float(avu)
        assert False, 'Calling __float__() on an AnsibleVaultEncryptedUnicode with a non float string should throw an error'
    except ValueError:
        pass

    # This should not throw an exception

# Generated at 2022-06-23 05:44:31.543330
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    test_dict = {'a':'b'}
    test_AnsibleMapping = AnsibleMapping(test_dict)
    assert test_AnsibleMapping == test_dict


# Generated at 2022-06-23 05:44:35.599605
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    avu = AnsibleVaultEncryptedUnicode("qwertyuiop")
    assert(list(reversed(avu)) == ['p', 'o', 'i', 'u', 'y', 't', 'r', 'e', 'w', 'q'])


# Generated at 2022-06-23 05:44:38.284594
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    u = AnsibleVaultEncryptedUnicode("abc\tdef")
    assert u.expandtabs() == "abc    def"

# Generated at 2022-06-23 05:44:49.384092
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-23 05:44:52.760267
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    h = AnsibleVaultEncryptedUnicode('42')
    assert h.__complex__() == complex(42)


# Generated at 2022-06-23 05:45:03.623014
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    from ansible import vault

    v = vault.VaultLib('password')
    av = AnsibleVaultEncryptedUnicode.from_plaintext('test', v, 'password')

    assert av.index('test') == 0
    assert av.index('1') == -1
    assert av.index('t') == 0
    assert av.index('X') == -1
    assert av.index('st') == 1
    assert av.index('est') == 2
    assert av.index('test', start=0) == 0
    assert av.index('test', start=1) == -1
    assert av.index('tset', start=0) == -1
    assert av.index('t', start=0) == 0
    assert av.index('X', start=0) == -1

# Generated at 2022-06-23 05:45:12.613630
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    from ansible.parsing.yaml.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    secret = VaultSecret('5er5')
    vault = VaultLib([secret])
    avue = AnsibleVaultEncryptedUnicode.from_plaintext('5er5', vault, secret)
    assert avue.upper() == '5ER5'


# Generated at 2022-06-23 05:45:15.102025
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    avu = AnsibleVaultEncryptedUnicode('text')
    assert avu.capitalize() == 'Text'
    assert avu.capitalize().__class__ == text_type


# Generated at 2022-06-23 05:45:20.662436
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    obj = AnsibleMapping()
    assert type(obj) == AnsibleMapping
    assert type(obj) == dict
    assert type(obj) != list
    obj['a'] = '5'
    assert obj['a'] == '5'
    assert obj.a == '5'



# Generated at 2022-06-23 05:45:23.070921
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    x = AnsibleVaultEncryptedUnicode(u"fOO")
    assert x.capitalize() == u"Foo"


# Generated at 2022-06-23 05:45:27.214163
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    avu = AnsibleVaultEncryptedUnicode(u'foobar')
    assert avu.capitalize() == u'Foobar'

    # Make sure it's not re-creating a new object
    assert avu.capitalize() is avu


# Generated at 2022-06-23 05:45:32.513056
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    '''
    unit test for method __int__ of class AnsibleVaultEncryptedUnicode

    >>> x = AnsibleVaultEncryptedUnicode("x")
    >>> int(x)
    Traceback (most recent call last):
      ...
    TypeError: int() argument must be a string, a bytes-like object or a number, not 'AnsibleVaultEncryptedUnicode'
    '''
    pass


# Generated at 2022-06-23 05:45:43.569594
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    assert not AnsibleVaultEncryptedUnicode('').isspace()
    assert not AnsibleVaultEncryptedUnicode(' ').isspace()
    assert not AnsibleVaultEncryptedUnicode('a').isspace()
    assert not AnsibleVaultEncryptedUnicode('\t').isspace()
    assert not AnsibleVaultEncryptedUnicode(' \t ').isspace()
    assert AnsibleVaultEncryptedUnicode('\t ').isspace()
    assert AnsibleVaultEncryptedUnicode(' \t\n').isspace()
    assert AnsibleVaultEncryptedUnicode('\n').isspace()
    assert AnsibleVaultEncryptedUnicode('\r').isspace()
    assert AnsibleVaultEncryptedUnicode('\r\n').isspace()
   

# Generated at 2022-06-23 05:45:48.560526
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    avu = AnsibleVaultEncryptedUnicode("")
    assert 'x' not in avu
    avu = AnsibleVaultEncryptedUnicode("x")
    assert 'x' in avu


# Generated at 2022-06-23 05:45:57.346120
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:46:00.480904
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    text = "ciphertext"
    # isdigit returns false because the object is encrypted
    avu = AnsibleVaultEncryptedUnicode(text)
    assert avu.isdigit() == False


# Generated at 2022-06-23 05:46:07.272200
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    '''Test that method rstrip works.'''
    avueu = AnsibleVaultEncryptedUnicode('')
    assert avueu.rstrip() == ''
    avueu = AnsibleVaultEncryptedUnicode('abc')
    assert avueu.rstrip() == 'abc'
    avueu = AnsibleVaultEncryptedUnicode(' abc')
    assert avueu.rstrip() == ' abc'
    avueu = AnsibleVaultEncryptedUnicode('abc ')
    assert avueu.rstrip() == 'abc'


# Generated at 2022-06-23 05:46:17.509606
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    secret='password'
    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext('test', VaultLib(password=secret), secret)
    assert encrypted_string.count('test') == 1
    assert encrypted_string.count('est') == 1
    assert encrypted_string.count('tes') == 1
    assert encrypted_string.count('st') == 1
    assert encrypted_string.count('t') == 1
    assert encrypted_string.count('t', 0, 1) == 1
    assert encrypted_string.count('t', 0, 2) == 1
    assert encrypted_string.count('t', 0, 3) == 2
    assert encrypted_string.count('t', 0, 4) == 2

# Generated at 2022-06-23 05:46:22.371744
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    secret = "foo"
    vault = VaultLib([], 'AES256')
    plaintext = to_bytes('I am not encrypted')
    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()


# Generated at 2022-06-23 05:46:27.562860
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():

    from ansible.parsing.vault import VaultLib

    seq = 'test password'
    secret = 'test secret'
    vault = VaultLib(['--ask-vault-pass'])
    encrypted_seq = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert seq == encrypted_seq.data



# Generated at 2022-06-23 05:46:31.653902
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    string_one_char = AnsibleVaultEncryptedUnicode(' ')
    assert string_one_char.isspace()
    string_with_space = AnsibleVaultEncryptedUnicode('foo bar')
    assert not string_with_space.isspace()



# Generated at 2022-06-23 05:46:37.315101
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('abc', None, None)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('123', None, None)
    assert avu1.isalpha()
    assert not avu2.isalpha()


# Generated at 2022-06-23 05:46:44.406618
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    # Get a string
    str_ = "Hello World"
    # Create an AnsibleVaultEncryptedUnicode object
    avu = AnsibleVaultEncryptedUnicode(str_)
    # Get the item of the object
    item = avu.data
    # Get the type of the item
    type_ = type(item)
    # Test the result
    assert item == str_
    assert isinstance(item, str) == True



# Generated at 2022-06-23 05:46:48.249210
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    assert AnsibleVaultEncryptedUnicode('THIS IS A TEST').casefold() == 'this is a test', "Failed method .casefold of class AnsibleVaultEncryptedUnicode"


# Generated at 2022-06-23 05:46:56.019148
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    # Create instance of test class
    test = AnsibleVaultEncryptedUnicode('test')

    # Test equality with AnsibleVaultEncryptedUnicode
    assert test.endswith('st') == True

    # Test equality with String
    assert test.endswith('es') == False

    # Test equality with String
    assert test.endswith(AnsibleVaultEncryptedUnicode('es')) == False


# Generated at 2022-06-23 05:46:58.035760
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    assert AnsibleVaultEncryptedUnicode("password").capitalize() == "Password"


# Generated at 2022-06-23 05:47:01.723225
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    avu = AnsibleVaultEncryptedUnicode('abc')

    result = avu[:1]
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result == 'a'

    result = avu[:-1]
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result == 'ab'



# Generated at 2022-06-23 05:47:09.675098
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:47:14.920190
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    # Test the multiplication of an AnsibleVaultEncryptedUnicode with an Integer
    assert "aaa" == "a" * 3

    # Test the multiplication of an AnsibleVaultEncryptedUnicode with an Integer by a variable
    variable = 2
    assert "aaaa" == "a" * variable


# Generated at 2022-06-23 05:47:24.353650
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    from ansible.parsing.vault import VaultLib
    avueu = AnsibleVaultEncryptedUnicode(u'')
    try:
        temp = avueu.decrypt(u'')
    except AttributeError:
        pass
    else:
        raise RuntimeError("testing AnsibleVaultEncryptedUnicode constructor failed.")
    vault = VaultLib('secret')
    avueu.vault = vault
    avueu.data = 'blah'
    temp = avueu.data
    if temp != u"blah":
        raise RuntimeError("testing AnsibleVaultEncryptedUnicode constructor failed.")
    if not avueu.is_encrypted():
        raise RuntimeError("testing AnsibleVaultEncryptedUnicode constructor failed.")
    if avueu.is_encrypted():
        raise Runtime

# Generated at 2022-06-23 05:47:28.567955
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    pass


try:
    from yaml import CSafeLoader as SafeLoader, CSafeDumper as SafeDumper
except ImportError:
    from yaml import SafeLoader, SafeDumper



# Generated at 2022-06-23 05:47:40.643963
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    import textwrap
    from ansible.parsing.vault import VaultLib
    secret = 'my_secret'

# Generated at 2022-06-23 05:47:52.907058
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:47:56.993679
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    a = AnsibleVaultEncryptedUnicode.from_plaintext('0+1j',1,1)
    a = complex(a)
    assert a == complex(0,1)

# Generated at 2022-06-23 05:48:07.704762
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    from ansible.parsing.vault import VaultLib
    vault_password = 'secret'
    vault = VaultLib(vault_password)
    # 1. simple test
    u1 = AnsibleVaultEncryptedUnicode('abcdef')
    u1.vault = vault
    u1.data
    u1.capitalize()
    assert u1.data == 'Abcdef'
    #2. all chars test
    u2 = AnsibleVaultEncryptedUnicode(''.join([chr(i) for i in range(0, 256)]))
    u2.vault = vault
    u2.data
    u2.capitalize()
    assert u2.data == u2.data.capitalize()
    #3. empty string test

# Generated at 2022-06-23 05:48:16.837194
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    if sys.version_info[0] == 3:
        assert AnsibleVaultEncryptedUnicode("1+1j").__complex__() == (1+1j)
        assert AnsibleVaultEncryptedUnicode("1+1Ej").__complex__() == (1+1j)
        assert AnsibleVaultEncryptedUnicode("-1+1Ej").__complex__() == (-1+1j)
        assert AnsibleVaultEncryptedUnicode("-1-1Ej").__complex__() == (-1-1j)
        assert AnsibleVaultEncryptedUnicode("1-1Ej").__complex__() == (1-1j)
        assert AnsibleVaultEncryptedUnicode("-1j").__complex__() == (-1j)
        assert AnsibleVaultEncrypted

# Generated at 2022-06-23 05:48:30.806660
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    '''
    Test instantiation of AnsibleBaseYAMLObject, AnsibleMapping, AnsibleUnicode and AnsibleSequence
    '''
    # make sure we can create instances of these
    d = AnsibleBaseYAMLObject()
    d = AnsibleMapping()
    d = AnsibleUnicode()
    d = AnsibleSequence()

    # make sure we can set ansible_pos
    d = AnsibleMapping()
    d.ansible_pos = ('/etc/ansible/hosts', 3, 4)
    (src, line, col) = d.ansible_pos
    assert src == '/etc/ansible/hosts'
    assert line == 3
    assert col == 4

if __name__ == "__main__":
    test_AnsibleBaseYAMLObject()



# Generated at 2022-06-23 05:48:33.471903
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    assert "abc".ljust(10) == "abc       "
    assert "abc".ljust(10, 'x') == "abcxxxxxxx"
    assert "abc".ljust(10, 'xy') == "abcxyxyxyx"


# Generated at 2022-06-23 05:48:44.158302
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('pass')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, 'pass')
    assert avu.is_encrypted(), 'Expected AnsibleVaultEncryptedUnicode to be encrypted, though it is not.'

# Generated at 2022-06-23 05:48:54.805801
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    # data is a unicode string
    assert AnsibleVaultEncryptedUnicode(b'test').encode() == b'test'
    assert AnsibleVaultEncryptedUnicode(b'test').encode(encoding='UTF-8') == b'test'
    assert AnsibleVaultEncryptedUnicode(b'test').encode(errors='replace') == b'test'

    # data is a byte string
    assert AnsibleVaultEncryptedUnicode(u'test').encode() == b'test'
    assert AnsibleVaultEncryptedUnicode(u'test').encode(encoding='UTF-8') == b'test'
    assert AnsibleVaultEncryptedUnicode(u'test').encode(errors='replace') == b'test'



# Generated at 2022-06-23 05:49:01.837890
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    s = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, 'mypassword')
    assert s.isspace() is False


try:
    from yaml import CLoader as AnsibleLoader
except ImportError:
    from yaml import Loader as AnsibleLoader


# Generated at 2022-06-23 05:49:11.547556
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('s3kret')

    av1 = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n633033396161646365616433666136626435396232373337396538633863626263346531386361623\na\n')
    av1.vault = vault
    av1.data = 'test'

    av2 = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n633033396161646365616433666136626435396232373337396538633863626263346531386361623\na\n')
    av2.vault = vault


# Generated at 2022-06-23 05:49:20.976097
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    import codecs
    # isprintable of AnsibleVaultEncryptedUnicode should be True when the data is printable
    aveu = AnsibleVaultEncryptedUnicode("hello")
    assert(aveu.isprintable() is True)
    # isprintable of AnsibleVaultEncryptedUnicode should be False when the data includes a non printable char
    # which is 0xFF in this test
    aveu = AnsibleVaultEncryptedUnicode(codecs.decode("\xFF", "latin1"))
    assert(aveu.isprintable() is False)


# Generated at 2022-06-23 05:49:24.179071
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    test_ansible_vault_unicode = AnsibleVaultEncryptedUnicode('Hello')
    assert test_ansible_vault_unicode == 'Hello'


# Generated at 2022-06-23 05:49:28.681930
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    """Test for AnsibleVaultEncryptedUnicode.islower()
    """
    assert AnsibleVaultEncryptedUnicode(b'abc').islower()
    assert not AnsibleVaultEncryptedUnicode(b'ABC').islower()
    assert not AnsibleVaultEncryptedUnicode(b'123').islower()


# Generated at 2022-06-23 05:49:34.408845
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    from ansible.parsing.vault import VaultLib

    seq = '1234'
    vault = VaultLib('123')
    secret = '123'
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert ansible_vault_encrypted_unicode.zfill(9) == '0000001234'



# Generated at 2022-06-23 05:49:37.741636
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    s = AnsibleVaultEncryptedUnicode("HELLO")
    assert not s.isupper()


# Generated at 2022-06-23 05:49:47.757624
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    import ansible.parsing.vault
    from ansible.parsing.vault import VaultLib
    plaintext = text_type('hello, ansible!')
    secret = text_type('my secret')
    vault = VaultLib([])
    ciphertext = to_bytes(vault.encrypt(plaintext, secret).decode('unicode_escape'))
    aveu = AnsibleVaultEncryptedUnicode(ciphertext)
    aveu.vault = vault
    assert text_type(aveu) == text_type('hello, ansible!')


# Generated at 2022-06-23 05:49:58.032364
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    assert AnsibleVaultEncryptedUnicode('a\tb').expandtabs() == 'a       b'
    assert AnsibleVaultEncryptedUnicode('a          b').expandtabs(4) == 'a    b'
    assert AnsibleVaultEncryptedUnicode('a        b').expandtabs(4) == 'a    b'
    assert AnsibleVaultEncryptedUnicode('a        b').expandtabs() == 'a        b'
    assert AnsibleVaultEncryptedUnicode('a\tb').expandtabs(4) == 'a    b'
    assert AnsibleVaultEncryptedUnicode('a\tb').expandtabs(5) == 'a     b'
    assert AnsibleVaultEncryptedUnicode('a\tb').expandtab

# Generated at 2022-06-23 05:50:07.124220
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    seq = b'A\u0300\u0316B\u0327C\u0328'
    vault = AnsibleVaultEncryptedUnicode.from_plaintext(seq, None, 'test')
    assert vault.data == u'A\u0300\u0316B\u0327C\u0328'
    assert vault.casefold() == u'a\u0316\u0327bc\u0327\u0328'
    assert vault.data == u'A\u0300\u0316B\u0327C\u0328'


# Generated at 2022-06-23 05:50:09.457450
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    ''' test the constructor of class AnsibleMapping '''
    assert AnsibleMapping() == {}



# Generated at 2022-06-23 05:50:23.381158
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    import crypt

    class TestVault(object):

        def __init__(self, key):
            self.key = key

        def is_encrypted(self, ciphertext):
            return True

        def decrypt(self, ciphertext, obj):
            if obj.data == 'oops':
                raise ValueError('oops')
            else:
                return '+'.join((self.key, ciphertext))

        def encrypt(self, plaintext, secret):
            if secret == 'oops':
                raise ValueError('oops')
            return '-'.join((self.key, plaintext))

    tv = TestVault('fake')
    s = AnsibleVaultEncryptedUnicode('encrypted_string')
    s.vault = tv

    assert s.is_encrypted()
    assert s.data == 'fake+encrypted_string'
   

# Generated at 2022-06-23 05:50:27.475985
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    print("Start test_AnsibleVaultEncryptedUnicode_startswith")
    avu = AnsibleVaultEncryptedUnicode(ciphertext=to_text("foo"))
    assert avu.startswith(AnsibleVaultEncryptedUnicode(ciphertext="f"))
    assert avu.startswith("f")
    assert not avu.startswith(AnsibleVaultEncryptedUnicode(ciphertext="b"))
    assert not avu.startswith("b")


# This function is used to convert the AnsibleVaultEncryptedUnicode object
# to an OrderedDict, in order to dump it as !vault YAML

# Generated at 2022-06-23 05:50:38.949665
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    class DummyVault(object):
        def __init__(self):
            self.data = b'123456789'

        def encrypt(self, data, secret):
            '''data is always unicode'''
            return to_bytes(data)

        def decrypt(self, data, obj=None):
            '''data is always bytes'''
            return to_bytes(self.data)

        def is_encrypted(self, data):
            '''data is always bytes'''
            return False

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abc', DummyVault(), b'secret')
    avu.vault = DummyVault()

    plaintext = avu + 'def'

# Generated at 2022-06-23 05:50:46.906167
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    ab = AnsibleVaultEncryptedUnicode('ab')
    assert ab.isalpha() is True
    a = AnsibleVaultEncryptedUnicode('a')
    assert a.isalpha() is True
    b = AnsibleVaultEncryptedUnicode('b')
    assert b.isalpha() is True
    abc = AnsibleVaultEncryptedUnicode('abc')
    assert abc.isalpha() is True
    abcde = AnsibleVaultEncryptedUnicode('abcde')
    assert abcde.isalpha() is True
    abcdefghijklmnopqrstuvwxyz = AnsibleVaultEncryptedUnicode('abcdefghijklmnopqrstuvwxyz')

# Generated at 2022-06-23 05:50:52.632744
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    if sys.version_info[0] < 3:
        test_string = AnsibleVaultEncryptedUnicode(u"test")
        assert test_string.islower()
    else:
        test_string = AnsibleVaultEncryptedUnicode("test")
        assert test_string.islower()



# Generated at 2022-06-23 05:51:02.344698
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    from ansible_collections.community.crypto.tests.unit.compat import unittest
    from ansible_collections.community.crypto.tests.unit.compat.mock import patch
    from ansible_collections.community.crypto.plugins.vault.VaultLib import VaultLib
    from ansible_collections.community.crypto.plugins.vault.VaultSecret import VaultSecret

    class TestAnsibleVaultEncryptedUnicode(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test___reversed__(self):
            vault_secret = VaultSecret('VaultSecret')
            vault = VaultLib(vault_secret, 'yaml')
            vault_secret.set_password(1234)

            plain

# Generated at 2022-06-23 05:51:11.586595
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:51:21.939605
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib()
    plaintext = 'foo'
    secret = 'secret'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    encrypted = avu.data
    assert(avu.data > 'bar')
    assert(avu.data > AnsibleVaultEncryptedUnicode.from_plaintext('bar', vault, secret))
    assert(not avu.data > 'foo')
    assert(not avu.data > AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault, secret))


# Generated at 2022-06-23 05:51:25.016145
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    ustr = AnsibleVaultEncryptedUnicode(b'encrypted')
    # It's not a string so what to test for this
    assert True



# Generated at 2022-06-23 05:51:29.963679
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    # Assert True for non-control characters
    for char in string.printable:
        assert AnsibleVaultEncryptedUnicode(char).isprintable() == True

    # Assert False for control characters
    for char in string.ascii_lowercase:
        assert AnsibleVaultEncryptedUnicode("\0{}".format(char)).isprintable() == False
        assert AnsibleVaultEncryptedUnicode("{}\0".format(char)).isprintable() == False

    # Assert False for unicode escape sequence
    assert AnsibleVaultEncryptedUnicode("\x1b[1;32m").isprintable() == False


# Generated at 2022-06-23 05:51:39.849471
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    import ansible.parsing.vault as vault
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import vars_loader

    av_str = AnsibleVaultEncryptedUnicode.from_plaintext('foo bar', vault.VaultLib('ansible'), PlayContext().password)
    av_str.ansible_pos = ("/some/file", 1, 2)
    assert av_str[0] == 'f'
    assert av_str[-1] == 'r'
    assert av_str[3:6] == ' ba'
    assert av_str[3:6] != 'fo'
    assert av_str[:6] == 'foo ba'


# Generated at 2022-06-23 05:51:47.148575
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    #This check is necessary to not have u"\n" interpreted as two characters
    #This case is not treated in the test
    assert u"\n".splitlines() == [u""]


# Generated at 2022-06-23 05:51:55.206863
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    import crypt

# Generated at 2022-06-23 05:52:01.417624
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    ''' Tests that AnsibleVaultEncryptedUnicode.__reversed__() behaves like a string'''
    # Non-zero tests
    input_str = "abcd"
    assert to_text(reversed(input_str)) == to_text(reversed(AnsibleVaultEncryptedUnicode(input_str)))

    # Zero tests
    input_str = ""
    assert to_text(reversed(input_str)) == to_text(reversed(AnsibleVaultEncryptedUnicode(input_str)))


# Generated at 2022-06-23 05:52:03.453245
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    assert AnsibleVaultEncryptedUnicode('abc') * 3 == 'abcabcabc'


# Generated at 2022-06-23 05:52:14.277907
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    from ansible.parsing.vault import VaultLib, VaultEditor
    if sys.version_info[0] == 2:
        unicode = unicode
    else:
        unicode = str

    # create a vault and encrypt some test data
    vault = VaultLib()
    vault_password = 'test_password'
    editor = VaultEditor(vault, vault_password)
    str_test_data = u'hello world'
    vault_data = editor.create_encrypted_data(str_test_data)

    # create a AnsibleVaultEncryptedUnicode object
    obj = AnsibleVaultEncryptedUnicode.from_plaintext(vault_data, vault, vault_password)

    # check that the method swapcase works
    assert to_native(obj) == to_native(str_test_data)

# Generated at 2022-06-23 05:52:17.994690
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    x = AnsibleVaultEncryptedUnicode(to_bytes("foo"))
    if to_text(x, errors='surrogate_or_strict') != u"foo":
        raise AssertionError("__unicode__ failed")


# Generated at 2022-06-23 05:52:20.944409
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    avu = AnsibleVaultEncryptedUnicode('value')
    assert complex(avu) == complex('value')

