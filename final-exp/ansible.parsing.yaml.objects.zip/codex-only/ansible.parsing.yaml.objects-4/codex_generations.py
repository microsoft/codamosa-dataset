

# Generated at 2022-06-23 05:42:29.771598
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing import vault
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor

    my_password = 'secret'
    plaintext = 'some plaintext'

    vault = VaultLib([my_password])

    # encrypt plaintext
    ciphertext = vault.encrypt(plaintext, my_password)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    # test is_encrypted method
    assert(avu.is_encrypted())

    # decrypt plaintext
    plaintext = avu.data

    # re_encrypt plaintext
    ciphertext = vault.encrypt(plaintext, my_password)

# Generated at 2022-06-23 05:42:38.278953
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    c = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          30653162623661613065663663236338623233373834393330356132396539376531396365326666\n          3339363464353866363164303262623065666438343864353130646563626666370a386139353366\n          393131626261376130323033376430373061663965356562333763643262356332356431343966\n          31353330633135643463393364386264663033376365316332330a\n"

# Generated at 2022-06-23 05:42:43.750261
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password='mypass')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault=vault, secret='mypass')
    assert avu == 'hello'


# Generated at 2022-06-23 05:42:48.959390
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    # for Python 2.7.9+ and Python 3.4+
    assert AnsibleVaultEncryptedUnicode('abc').islower()
    assert not AnsibleVaultEncryptedUnicode('abc ').islower()
    assert not AnsibleVaultEncryptedUnicode('abc 123').islower()
    assert not AnsibleVaultEncryptedUnicode('abcABC').islower()



# Generated at 2022-06-23 05:42:52.763909
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    test_string = AnsibleVaultEncryptedUnicode("hello world")
    test_string.vault = MockVaultLib()
    assert "e" in test_string
    assert AnsibleVaultEncryptedUnicode("w") in test_string



# Generated at 2022-06-23 05:43:01.636043
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    """
    The method __getitem__ needs to decrypt the plaintext and return the same
    item as the plaintext.  This is not just r[:] (which correctly returns a string).
    It has to return r[i] or r[i:j], depending on what is passed as index.
    """
    s = b"blah"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(s, None, None)
    assert avu[:] == s
    assert avu[0] == s[0]
    assert avu[:1] == s[:1]
    assert avu[1:] == s[1:]
    assert avu[-1] == s[-1]
    assert avu[:-1] == s[:-1]

# Generated at 2022-06-23 05:43:08.468257
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    # Arrange
    seq = 'test_AnsibleVaultEncryptedUnicode___hash__'
    secret = 'password'

    # Act
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq=seq, vault=VaultLib(), secret=secret)

    # Assert
    assert hash(seq) == hash(avu)



# Generated at 2022-06-23 05:43:15.441777
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    from ansible.plugins.vault import VaultLib
    vault = VaultLib([])
    test_string = "test_string"
    encrypted_test_string = vault.encrypt(test_string, 'secret')
    enc_string = AnsibleVaultEncryptedUnicode(encrypted_test_string)
    enc_string.vault = vault
    assert enc_string.encode() == test_string.encode()
    assert enc_string.encode('ascii') == test_string.encode('ascii')



# Generated at 2022-06-23 05:43:22.947394
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
  import tempfile
  import random
  import string
  random_string = ''.join(random.choice(string.ascii_letters) for _ in range(5))
  random_list = [random.choice(string.ascii_letters) for _ in range(5)]
  with tempfile.NamedTemporaryFile(prefix='ansible-vault-', suffix='.yml', delete=False) as tf:
    tf.close()
    tf_name = tf.name
    vault = vaultlib.VaultLib(filename='ansible-vault')
    vault.create(random_string, tf_name)
    result = vault.load(tf_name)
    assert type(result) is dict
    assert result == {}



# Generated at 2022-06-23 05:43:34.490895
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Set up the test
    secret = VaultSecret(b'secret key')
    vault = VaultLib(password=secret)
    avueu = AnsibleVaultEncryptedUnicode.from_plaintext(u'value', vault, secret)
    expected_output = u'other value'

    # Test for unicode value
    input_value = u'other '
    actual_output = input_value + avueu
    assert expected_output == actual_output, 'expected %s, got %s' % (expected_output, actual_output)

    # Test for str value on PY3
    if _sys.version_info[0] == 3:
        input_value = b'other '
       

# Generated at 2022-06-23 05:43:44.495406
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    from ansible.parsing.vault import VaultLib
    from .test_my_vars import test_vault_password
    test_message = 'test message'
    test_vault = VaultLib(password=test_vault_password)
    test_encrypted_message = AnsibleVaultEncryptedUnicode.from_plaintext(test_message, test_vault, secret=test_vault_password)
    test_mapping = {'message': test_message}
    assert test_encrypted_message.format_map(mapping=test_mapping) == test_message


# Generated at 2022-06-23 05:43:54.872454
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    assert not AnsibleVaultEncryptedUnicode(b'!?#').isalnum()
    assert AnsibleVaultEncryptedUnicode(b'abc').isalnum()
    assert AnsibleVaultEncryptedUnicode(b'ab12').isalnum()
    assert AnsibleVaultEncryptedUnicode(b'\u00e0\u00e9\u00ed').isalnum()
    assert not AnsibleVaultEncryptedUnicode(b'').isalnum()
    assert not AnsibleVaultEncryptedUnicode(b' ').isalnum()
    assert not AnsibleVaultEncryptedUnicode(b'\0').isalnum()
    assert not AnsibleVaultEncryptedUnicode(b'\n').isalnum()

# Generated at 2022-06-23 05:44:00.678042
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu.is_encrypted()
    plaintext = b'Hello World'
    avu = AnsibleVaultEncryptedUnicode(plaintext)
    assert not avu.is_encrypted()



# Generated at 2022-06-23 05:44:11.250535
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    from ansible.parsing.vault import VaultLib
    text = 'My secret text'
    key = 'secret'
    ciphertext = VaultLib.encrypt(text, key)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = VaultLib()
    assert str(avu) == text
    assert avu.data == text


# Generated at 2022-06-23 05:44:19.408335
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    from ansible.parsing.vault import VaultLib
    passphrase = 'testpassphrase'
    vault = VaultLib(passphrase)
    secret = 'testsecret'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(secret, vault, passphrase)
    assert avu.index('e') == secret.index('e')
    # The following assertion is from the test of:
    # def index(self, sub, start=0, end=_sys.maxsize)
    # in class AnsibleVaultEncryptedUnicode
    with pytest.raises(ValueError) as e:
        avu.index('e', 0, 1)
    assert to_text(e.value, errors='surrogate_or_strict') == "substring not found"



# Generated at 2022-06-23 05:44:29.821384
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    a = AnsibleVaultEncryptedUnicode('string')
    assert a.endswith('g')
    assert not a.endswith('i')
    assert a.endswith('ng')
    assert not a.endswith('ng\ufffd')
    assert a.endswith(AnsibleVaultEncryptedUnicode('g'))
    assert not a.endswith(AnsibleVaultEncryptedUnicode('i'))
    assert a.endswith(AnsibleVaultEncryptedUnicode('ng'))
    assert not a.endswith(AnsibleVaultEncryptedUnicode('ng\ufffd'))
    assert not a.endswith(b'g')
    assert a.endswith(b'ng')

# Generated at 2022-06-23 05:44:37.089145
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    import string
    import unittest

    vault = DummyVaultLib()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(u'a' * 64, vault, u'a' * 64)
    del vault

    for c in string.printable:
        if c.isidentifier():
            assert avu.isidentifier()
            break
        else:
            assert not avu.isidentifier()

    del avu



# Generated at 2022-06-23 05:44:42.523286
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    assert AnsibleVaultEncryptedUnicode('hello').translate(None) == 'hello'
    assert AnsibleVaultEncryptedUnicode('hello').translate('abc') == 'hello'
    assert AnsibleVaultEncryptedUnicode('hello').translate({97: None, 98: None}) == 'hello'


# Generated at 2022-06-23 05:44:49.963979
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    u = u"\u8fd9\u662f\u4e00\u4e2a\u6d4b\u8bd5"
    vu = AnsibleVaultEncryptedUnicode(u.encode('utf-8'))
    assert u.encode() == vu.encode(), vu.encode()
    assert u.encode('ascii') == vu.encode('ascii'), vu.encode('ascii')
    assert u.encode('ascii', 'backslashreplace') == vu.encode('ascii', 'backslashreplace'), vu.encode('ascii', 'backslashreplace')

# Generated at 2022-06-23 05:44:56.965287
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    if sys.version_info[0] == 3:
        avu = AnsibleVaultEncryptedUnicode("what_exactly_is_python_best_practice_to_check_if_a_string_is_a_valid_identifier?")
        assert(avu.isidentifier())
        avu = AnsibleVaultEncryptedUnicode("what exactly is python best practice to check if a string is a valid identifier?")
        assert(not avu.isidentifier())
        avu = AnsibleVaultEncryptedUnicode("!")
        assert(not avu.isidentifier())
        avu = AnsibleVaultEncryptedUnicode("")
        assert(not avu.isidentifier())
        avu = AnsibleVaultEncryptedUnicode("0")

# Generated at 2022-06-23 05:45:12.027559
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    s = AnsibleVaultEncryptedUnicode("foo\nbar")
    assert s.splitlines() == ['foo', 'bar']
    s = AnsibleVaultEncryptedUnicode("foo\nbar\n")
    assert s.splitlines() == ['foo', 'bar']
    assert s.splitlines(True) == ['foo\n', 'bar\n']
    s = AnsibleVaultEncryptedUnicode("foo\nbar\n\n")
    assert s.splitlines() == ['foo', 'bar']
    assert s.splitlines(True) == ['foo\n', 'bar\n', '\n']
    s = AnsibleVaultEncryptedUnicode("foo\r\nbar\r\n\r\n")
    assert s.splitlines() == ['foo', 'bar']
   

# Generated at 2022-06-23 05:45:16.812323
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    avu1 = AnsibleVaultEncryptedUnicode('!foo')
    avu2 = AnsibleVaultEncryptedUnicode('!foo')
    avu3 = AnsibleVaultEncryptedUnicode('!bar')
    assert repr(avu1) == repr(avu2)
    assert repr(avu1) != repr(avu3)


# Generated at 2022-06-23 05:45:26.755681
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    cipertext = b'$ANSIBLE_VAULT;1.1;AES256\n63353960623035656664353135656437383438333164353165613435333235646361646232386364\n353266626262386162366131633661323136616262366165396363323234316531633338376265323\n623632643866653238396331656262633463303065353863633165323539633739366233653233633\n3565616132326662646166613162333761636663326332626362343834393864373730643932366365\n376439\n'

# Generated at 2022-06-23 05:45:37.223037
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    password = 'VaultPassword'
    plaintext = 'Encryption is great!'
    encrypted_text = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3562323634373335343739333262633134316533336533313932646638356566343130393738323238\n          6461386138373436653633616432336330623533323663653539646631373464316165323163326536\n          3438626633643439\n          "

    vault = vault_load(password, encrypted_text)
    encrypted_unicode = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, password)
    decrypted_unicode = encrypted_unicode + ' Sure is!'

# Generated at 2022-06-23 05:45:40.592963
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    with open('test_ljust', 'r') as fh:
        text = fh.read()

    result = "test_ljust            "
    avu = AnsibleVaultEncryptedUnicode(text)
    assert avu.ljust(20) == result


# Generated at 2022-06-23 05:45:42.409613
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass  # For now, not testing this method because it's dependent on external class `vault`



# Generated at 2022-06-23 05:45:54.044869
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    from ansible.constants import DEFAULT_VAULT_SECRET_FILE
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(DEFAULT_VAULT_SECRET_FILE)

    assert 'Hello world!' == str(AnsibleVaultEncryptedUnicode.from_plaintext('Hello world!', vault, b'password'))
    assert 'Hello world!' == str(AnsibleVaultEncryptedUnicode.from_plaintext('Hello world!', vault, 'password'))
    assert isinstance(str(AnsibleVaultEncryptedUnicode.from_plaintext('Hello world!', vault, b'password')), str)
    assert isinstance(str(AnsibleVaultEncryptedUnicode.from_plaintext('Hello world!', vault, 'password')), str)




# Generated at 2022-06-23 05:46:04.451601
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    # True cases
    assert AnsibleVaultEncryptedUnicode(b' ').isspace()
    assert AnsibleVaultEncryptedUnicode(b'\t').isspace()
    assert AnsibleVaultEncryptedUnicode(b'\n').isspace()
    assert AnsibleVaultEncryptedUnicode(b'\x0b').isspace()
    assert AnsibleVaultEncryptedUnicode(b'\x0c').isspace()

    # False cases
    assert not AnsibleVaultEncryptedUnicode(b'\r').isspace()
    assert not AnsibleVaultEncryptedUnicode(b'a').isspace()
    assert not AnsibleVaultEncryptedUnicode(b' ' * 2).isspace()

# Generated at 2022-06-23 05:46:16.329475
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    import vault
    import sys
    import os

    secret = os.urandom(32).encode('base64')[:32]

    vault_mgr = vault.VaultLib(secret)

    # AnsibleVaultEncryptedUnicode.__hash__() crashes by design if the object is
    # not a regular AnsibleUnicode.
    x = AnsibleVaultEncryptedUnicode.from_plaintext(
        'test',
        vault=vault_mgr,
        secret=secret)
    print(repr(x))
    print(hex(hash(x)))

    # Vault secret always assumes a unicode object
    if sys.version_info[0] == 2:
        secret = secret.decode('utf-8')
    secret1 = secret + '1'

    # AnsibleVaultEncrypted

# Generated at 2022-06-23 05:46:24.802532
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    # '''
    # Test method AnsibleVaultEncryptedUnicode.__mul__()
    # '''
    # # Setup
    # str_01 = AnsibleVaultEncryptedUnicode('0123456789')
    # int_01 = 10
    # str_02 = AnsibleVaultEncryptedUnicode('0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789')
    # # Verification
    # assert str_01 * int_01 == str_02
    pass


# Generated at 2022-06-23 05:46:31.446154
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
  from ansible.plugins.vault import VaultLib
  vault = VaultLib('test')
  vault.password = 'test'
  from ansible.parsing.vault import VaultSecret
  vault_secret = VaultSecret('test')

  avu_obj = AnsibleVaultEncryptedUnicode.from_plaintext('teststring', vault, vault_secret)

  # eval the function
  assert 8 == len(avu_obj)


# Generated at 2022-06-23 05:46:41.193534
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    ob = AnsibleBaseYAMLObject()
    assert ob.ansible_pos == (None, 0, 0)
    ob = AnsibleBaseYAMLObject()
    ob.ansible_pos = (None, 1, 2)
    assert ob.ansible_pos == (None, 1, 2)

# Setup the Ansible Base YAML Objects
AnsibleMapping.add_to_class('yaml_tag', u'!python/object:ansible.parsing.yaml.objects.AnsibleMapping')
AnsibleSequence.add_to_class('yaml_tag', u'!python/object:ansible.parsing.yaml.objects.AnsibleSequence')

# Generated at 2022-06-23 05:46:51.167142
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    password = '$ecre7p@ssw0rd'
    vault = VaultLib(password)
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('this is a test', vault, password)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext(' message', vault, password)
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext(' message', vault, password)
    assert avu1.data + avu2.data == 'this is a test message'
    assert avu3.data == ' message'
    assert avu1 + avu2 == 'this is a test message'
    assert avu1 + avu3 == 'this is a test message'
    assert avu2

# Generated at 2022-06-23 05:47:00.919005
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    # Test basic isspace functionality
    assert AnsibleVaultEncryptedUnicode(u' ').isspace()
    assert not AnsibleVaultEncryptedUnicode(u'a').isspace()
    assert not AnsibleVaultEncryptedUnicode(u'B').isspace()

    # Test a string consisting of only spaces
    assert AnsibleVaultEncryptedUnicode(u'    ').isspace()

    # Test a string consisting of a number of spaces and tabs
    assert AnsibleVaultEncryptedUnicode(u' \t   \t ').isspace()
    assert not AnsibleVaultEncryptedUnicode(u' \u1234   \t ').isspace()



# Generated at 2022-06-23 05:47:02.657975
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    assert int(AnsibleVaultEncryptedUnicode('123')) == 123


# Generated at 2022-06-23 05:47:13.733122
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    if _sys.version_info[0] == 2:
        return

    words = [
        'Caf\u00e9',
        'Cafe\u0301',
        'cafe\u0301',
        'Caf\u00e9',
        'caf\u00e9',
        '\u212B',
        '\u00C5ngstr\u00f6m',
    ]
    s = '-'.join(words)
    t = AnsibleVaultEncryptedUnicode(words[0])
    for word in words[1:]:
        t += '-'
        t += AnsibleVaultEncryptedUnicode(word)
    assert t.casefold() == s.casefold()


# Generated at 2022-06-23 05:47:23.270488
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    base = AnsibleVaultEncryptedUnicode('')

    # When called with no args, replace returns the same object unchanged
    assert base.replace() is base

    # When called with a single text arg, replace returns the same object unchanged
    assert base.replace('a') is base

    # When called with a single unicode arg, replace returns the same object unchanged
    assert base.replace(u'a') is base

    # When called with a single AnsibleVaultEncryptedUnicode arg, replace returns the same object unchanged
    assert base.replace(AnsibleVaultEncryptedUnicode('a')) is base

    # When called with text args, replace replaces the text in the AnsibleVaultEncryptedUnicode object
    base = AnsibleVaultEncryptedUnicode('ab')
    assert base.replace('b', 'c')

# Generated at 2022-06-23 05:47:33.415753
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    # Test cases are from Python 2.7, 3.5
    # Test cases from Python 2.7, 3.5
    assert AnsibleVaultEncryptedUnicode('foo bar').swapcase() == AnsibleVaultEncryptedUnicode('FOO BAR')
    assert AnsibleVaultEncryptedUnicode('Foo Bar').swapcase() == AnsibleVaultEncryptedUnicode('fOO bAR')
    assert AnsibleVaultEncryptedUnicode('FOOBAR').swapcase() == AnsibleVaultEncryptedUnicode('foobar')
    assert AnsibleVaultEncryptedUnicode('!@#$%^&').swapcase() == AnsibleVaultEncryptedUnicode('!@#$%^&')
    assert AnsibleVaultEncryptedUnicode('foo\\u2160bar').swap

# Generated at 2022-06-23 05:47:42.538564
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    # This test relies on the function casefold of AnsibleVaultEncryptedUnicode being equal to casefold of unicode
    # This test is not possible to run using AnsibleVaultEncryptedUnicode because casefold of AnsibleVaultEncryptedUnicode
    # will never be equal to casefold of unicode without triggering the decryption
    # We therefore need to create a subclass that "fakes" the type of AnsibleVaultEncryptedUnicode
    # but uses the casefold of unicode
    class FakeAVU(AnsibleVaultEncryptedUnicode):
        def __init__(self, data):
            self.data = data
            self.vault = None


# Generated at 2022-06-23 05:47:52.423092
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    avu = AnsibleVaultEncryptedUnicode('hello world')
    avu.vault = mock.Mock()
    avu.vault.decrypt = mock.Mock()
    avu.vault.decrypt.return_value = 'hello world'
    assert (avu[1:5] == 'ello')
    assert (avu[-5:] == 'world')
    avu.vault.decrypt.assert_called_once_with(b'ello world', None)

_yaml_base_loader = yaml.BaseLoader
_yaml_base_dumper = yaml.BaseDumper



# Generated at 2022-06-23 05:47:58.482238
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    av = AnsibleVaultEncryptedUnicode(['replaced'] * 2)
    assert av[1:3] == ['replaced', 'replaced']
    assert av[-3:-1] == ['replaced', 'replaced']
    assert av[-3:100] == ['replaced', 'replaced']
    assert av[-100:100] == ['replaced', 'replaced']
    assert av[100:200] == []
    assert av[:] == ['replaced', 'replaced']



# Generated at 2022-06-23 05:48:00.916357
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    class Obj(AnsibleBaseYAMLObject):
        pass
    obj = Obj()
    assert obj._data_source is None
    assert obj._line_number == 0
    assert obj._column_number == 0


# Generated at 2022-06-23 05:48:05.016198
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    s = AnsibleVaultEncryptedUnicode('xyz')
    assert (s != 'xyz')
    assert (s != AnsibleVaultEncryptedUnicode('xyz'))
    assert (not (s != 'xy'))


# Generated at 2022-06-23 05:48:15.318197
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    from ansible.plugins.vault import vaultlib
    from ansible import constants as C
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    avu_test = AnsibleVaultEncryptedUnicode.from_plaintext("abc12", vaultlib.VaultLib(password=C.DEFAULT_VAULT_PASSWORD), C.DEFAULT_VAULT_PASSWORD)
    assert avu_test.rpartition("a") == ("", "a", "bc12")
    assert avu_test.rpartition("b") == ("a", "b", "c12")
    assert avu_test.rpartition("c") == ("ab", "c", "12")

# Generated at 2022-06-23 05:48:19.649051
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    t = AnsibleVaultEncryptedUnicode("\thello world\n\tsecond line")
    print(t)
    t_expanded = t.expandtabs()
    print(t_expanded)
    assert t_expanded == "    hello world\n\tsecond line"


# Generated at 2022-06-23 05:48:31.548820
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    from ansible.parsing.vault import VaultLib
    plaintext = "this is a long and somewhat silly rabbit string\n"
    plaintext += "this is a long and somewhat silly rabbit string\n"
    plaintext += "this is a long and somewhat silly rabbit string\n"
    plaintext += "this is a long and somewhat silly rabbit string\n"
    plaintext += "this is a long and somewhat silly rabbit string\n"
    plaintext += "this is a long and somewhat silly rabbit string\n"
    plaintext += "this is a long and somewhat silly rabbit string\n"
    plaintext += "this is a long and somewhat silly rabbit string\n"
    plaintext += "this is a long and somewhat silly rabbit string\n"
    plaintext += "this is a long and somewhat silly rabbit string\n"

# Generated at 2022-06-23 05:48:34.616611
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    avu = AnsibleVaultEncryptedUnicode(ciphertext=b'abc')
    assert avu.capitalize() == u'Abc'


# Generated at 2022-06-23 05:48:35.797498
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    obj = AnsibleMapping()
    assert(obj == {})



# Generated at 2022-06-23 05:48:37.812902
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    assert AnsibleVaultEncryptedUnicode('a').__add__('b') == 'ab'



# Generated at 2022-06-23 05:48:45.419522
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    password = 'ciao'
    plaintext_1 = AnsibleVaultEncryptedUnicode.from_plaintext(
        "abcde %s", vault=AnsibleVault(), secret=password)
    plaintext_2 = 'abcde %s'
    first = "ciao"
    second = "miao"
    third = "bau"
    result_1 = plaintext_1 % (first, second, third)
    result_2 = plaintext_2 % (first, second, third)
    assert result_1 == result_2


# Generated at 2022-06-23 05:48:57.013445
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    avue_str = 'Abc def Ghi'
    avue_str_upper = 'ABC DEF GHI'
    avue_str_title = 'Abc Def Ghi'
    avue = AnsibleVaultEncryptedUnicode(avue_str)
    assert avue.title() == avue_str_title
    avue = AnsibleVaultEncryptedUnicode(avue_str.upper())
    assert avue.title() == avue_str_title
    avue = AnsibleVaultEncryptedUnicode(avue_str_upper)
    assert avue.title() == avue_str_title
    avue = AnsibleVaultEncryptedUnicode(avue_str_title)
    assert avue.title() == avue_str_title
    avue = AnsibleVault

# Generated at 2022-06-23 05:49:06.363158
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    if sys.version_info >= (3, 0):
        assert u'\N{LATIN SMALL LETTER SHARP S}'.casefold() == 'ss'
        assert u'\N{GREEK SMALL LETTER FINAL SIGMA}'.casefold() == 'σ'
        assert u'\N{GREEK CAPITAL LETTER SIGMA}'.casefold() == 'σ'
        assert u'\N{GREEK SMALL LETTER SIGMA}'.casefold() == 'σ'

test_AnsibleVaultEncryptedUnicode_casefold()



# Generated at 2022-06-23 05:49:09.009747
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    avu = AnsibleVaultEncryptedUnicode("example")
    assert avu.__mod__("%s.com") == "example.com"


# Generated at 2022-06-23 05:49:14.132971
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    ciphertext = u'Hello World!'
    plaintext = u'Hello World!'
    avu1 = AnsibleVaultEncryptedUnicode(ciphertext)
    assert(avu1 <= plaintext) == True
    assert(avu1 <= ciphertext) == False

# help yaml with our classes

# Generated at 2022-06-23 05:49:26.265047
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    assert AnsibleVaultEncryptedUnicode('').isidentifier() == False
    assert AnsibleVaultEncryptedUnicode('  ').isidentifier() == False
    assert AnsibleVaultEncryptedUnicode('1').isidentifier() == False
    assert AnsibleVaultEncryptedUnicode('_').isidentifier() == False
    assert AnsibleVaultEncryptedUnicode('_a').isidentifier() == False
    assert AnsibleVaultEncryptedUnicode('a').isidentifier() == False
    assert AnsibleVaultEncryptedUnicode('a_').isidentifier() == False
    assert AnsibleVaultEncryptedUnicode('a1').isidentifier() == False
    assert AnsibleVaultEncryptedUnicode('a1b').isidentifier() == False


# Generated at 2022-06-23 05:49:31.960778
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():

    def test_impl(avu, template):
        return avu.__rmod__(template)

    data = to_text('The quick brown fox jumps over the lazy dog')
    template = to_text('%s, %(animal)s')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(data, None, None)
    assert test_impl(avu, template) == to_text('The quick brown fox jumps over the lazy dog, %(animal)s')



# Generated at 2022-06-23 05:49:44.065425
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # units under test
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # mock
    mock_args_a = dict(
        ciphertext='ciphertext-a',
        vault=VaultLib(password='password-a'),
    )
    mock_args_b = dict(
        ciphertext='ciphertext-b',
        vault=VaultLib(password='password-b'),
    )
    mock_args_c = dict(
        ciphertext='ciphertext-c',
        vault=VaultLib(password='password-c'),
    )

    # TODO: could be refactored, with the same test_data_set
    # test_data_set_a
    data_set_a

# Generated at 2022-06-23 05:49:52.023987
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib([])
    secret = 'mysecret'
    a = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault, secret)
    assert a.is_encrypted()
    a = AnsibleVaultEncryptedUnicode('hello')
    assert not a.is_encrypted()


# Generated at 2022-06-23 05:49:58.340765
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    v = AnsibleVaultEncryptedUnicode(b"this is a test string")
    print(v)
    assert v.capitalize() == b"This is a test string"
    v = AnsibleVaultEncryptedUnicode(b"this is a test string")
    assert v.capitalize() == b"This is a test string"


# Generated at 2022-06-23 05:50:02.951730
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.isascii() is True
    avu = AnsibleVaultEncryptedUnicode(u'\u00E9')
    assert avu.isascii() is False

# Generated at 2022-06-23 05:50:09.594978
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    # PY2
    assert u'foo' == AnsibleUnicode(u'foo')
    assert u'foo\u1234' == AnsibleUnicode(u'foo\u1234')
    # PY3
    assert 'foo' == AnsibleUnicode('foo')
    assert 'foo\u1234' == AnsibleUnicode('foo\u1234')


# Generated at 2022-06-23 05:50:23.468061
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:50:33.675530
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    class MyAnsibleVaultEncryptedUnicode(AnsibleVaultEncryptedUnicode):
        pass

    v = MyAnsibleVaultEncryptedUnicode(to_bytes('1'))
    assert(v.isdecimal())

    v = MyAnsibleVaultEncryptedUnicode(to_bytes(''))
    assert(not v.isdecimal())

    v = MyAnsibleVaultEncryptedUnicode(to_bytes('1a'))
    assert(not v.isdecimal())

    v = MyAnsibleVaultEncryptedUnicode(to_bytes('1.0'))
    assert(not v.isdecimal())

    v = MyAnsibleVaultEncryptedUnicode(to_bytes('1,0'))

# Generated at 2022-06-23 05:50:38.287360
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    X = AnsibleVaultEncryptedUnicode(b'abcdefghijklmnopqrstuvwxyz')
    X.vault = vault = DummyVault()
    assert X.translate(None, b'z') == 'abcdefghijklmnopqrstuvwxy'


# Generated at 2022-06-23 05:50:39.267684
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    pass



# Generated at 2022-06-23 05:50:46.808509
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    seq = AnsibleVaultEncryptedUnicode('0123456789')
    assert seq.isdigit()
    seq = AnsibleVaultEncryptedUnicode('0123456789 test')
    assert not seq.isdigit()
    seq = AnsibleVaultEncryptedUnicode('0123456789test')
    assert not seq.isdigit()
    seq = AnsibleVaultEncryptedUnicode('test 0123456789')
    assert not seq.isdigit()
    seq = AnsibleVaultEncryptedUnicode('test')
    assert not seq.isdigit()
    seq = AnsibleVaultEncryptedUnicode('0123456789\ntest')
    assert not seq.isdigit()


# Generated at 2022-06-23 05:50:58.716219
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    """ strip the vault secret from an AnsibleVaultEncryptedUnicode """

    assert AnsibleVaultEncryptedUnicode('\n').splitlines() == ['','']
    assert AnsibleVaultEncryptedUnicode('\n ').splitlines() == ['','']
    assert AnsibleVaultEncryptedUnicode('\n\n').splitlines() == ['','','']
    assert AnsibleVaultEncryptedUnicode('\n \n').splitlines() == ['','']

    assert AnsibleVaultEncryptedUnicode('\r').splitlines() == ['','']
    assert AnsibleVaultEncryptedUnicode('\r ').splitlines() == ['','']
    assert AnsibleVaultEncryptedUnicode('\r\r').splitlines() == ['','','']

# Generated at 2022-06-23 05:51:09.320012
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    # Test case for exception raised by 'isdecimal' method of class AnsibleVaultEncryptedUnicode
    # Test case for negative number
    test_data = -123
    test_data = text_type(test_data)
    result = AnsibleVaultEncryptedUnicode.from_plaintext(test_data, vault=None, secret=None)
    assert result.isdecimal() == False
    # Test case for float
    test_data = 12.3
    test_data = text_type(test_data)
    result = AnsibleVaultEncryptedUnicode.from_plaintext(test_data, vault=None, secret=None)
    assert result.isdecimal() == False
    # Test case for empty string
    test_data = ''
    test_data = text_type(test_data)


# Generated at 2022-06-23 05:51:14.780545
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    from vault import VaultLib
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', VaultLib(), '1')
    assert 0 == avu.index('f')
    assert 1 == avu.index('o', 1)
    assert 1 == avu.index('o', 1, 2)

# Initialize the custom YAML tag handler so the AnsibleVaultEncryptedUnicode class is used when
# it is encountered while parsing YAML data
yaml.add_multi_constructor(u"!vault", AnsibleVaultEncryptedUnicode)

# vim: set expandtab:

# Generated at 2022-06-23 05:51:18.768236
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    test_text = '123456'
    v = AnsibleVaultEncryptedUnicode(test_text)
    assert v.zfill(2) == test_text
    assert v.zfill(8) == '000123456'
    assert v.zfill(10) == '00000123456'
    # Test negative width
    assert v.zfill(-2) == test_text



# Generated at 2022-06-23 05:51:22.943254
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    if not AnsibleVaultEncryptedUnicode_islower_test():
        raise Exception("AnsibleVaultEncryptedUnicode_islower_test failed!")
    else:
        print("AnsibleVaultEncryptedUnicode_islower_test passed!")


# Generated at 2022-06-23 05:51:33.877980
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    import re
    value = AnsibleVaultEncryptedUnicode('abcd')
    assert value.isidentifier()
    value = AnsibleVaultEncryptedUnicode('\u00c1')
    assert value.isidentifier()
    value = AnsibleVaultEncryptedUnicode('\u00e0')
    print(value)
    assert value.isidentifier()
    value = AnsibleVaultEncryptedUnicode('\u00f0')
    print(value)
    assert value.isidentifier()
    value = AnsibleVaultEncryptedUnicode('\u00f1')
    print(value)
    assert value.isidentifier()
    value = AnsibleVaultEncryptedUnicode('\u0303')
    print(value)
    assert value.isidentifier()
   

# Generated at 2022-06-23 05:51:44.342382
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    import ansible.vault as vault
    from ansible.parsing.vault import VaultLib
    testcases = [(' abc def ', ' abc def '),
                 ('a b c d  e  f', 'a b c d  e  f'),
                 (' a   b   c', ' a   b   c'),
                 ('abc ', 'abc '),
                 (' abc', ' abc'),
                 ('  ', '  '),
                 ('  abc  ', '  abc  ')]
    tests = []

    # Define the methods
    def encrypt(self, plaintext, secret):
        return plaintext.encode('utf-8')

    def decrypt(self, ciphertext, obj):
        return ciphertext.decode('utf-8')

    def is_encrypted(self, ciphertext):
        return

# Generated at 2022-06-23 05:51:46.523874
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    data = AnsibleVaultEncryptedUnicode("test_data")
    assert data.index("_") == 4


# Generated at 2022-06-23 05:51:48.104901
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    ljust = AnsibleVaultEncryptedUnicode("data").ljust(4)
    assert isinstance(ljust, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 05:51:50.630250
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    avu = AnsibleVaultEncryptedUnicode('  foo bar  ')
    assert avu.strip() == avu.data.strip()



# Generated at 2022-06-23 05:51:53.320663
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    assert ("foo" % AnsibleVaultEncryptedUnicode("bar")) == "foobar"


# Generated at 2022-06-23 05:52:04.834161
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    s = AnsibleVaultEncryptedUnicode(b'abcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabc')
    sub1 = 'a'
    sub2 = 'b'
    sub3 = 'c'

    assert s.rindex(sub1) == 93
    assert s.rindex(sub1, 1, 50) == 1
    assert s.rindex(sub1, 1) == 93
    assert s.rindex(sub2) == 94
    assert s.rindex(sub2, 1, 50) == 2
    assert s.rindex(sub2, 1) == 94
    assert s.rindex(sub3) == 95

# Generated at 2022-06-23 05:52:15.669774
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    _text = AnsibleVaultEncryptedUnicode('bar.baz')
    _text2 = AnsibleVaultEncryptedUnicode('bar.baz')
    _text3 = AnsibleVaultEncryptedUnicode('bar.baz')

    # Test the following assertions:
    # 1. 'plain string' is a substring of _text
    # 2. 'plain string' is not a substring of _text2
    # 3. '.' is a substring of _text3
    assert 'plain string' in _text
    assert 'plain string' not in _text2
    assert '.' in _text3

    # rpartition() return a seq value of 3 elements
    assert isinstance(_text.rpartition('.'), tuple)
    assert isinstance(_text2.rpartition('.'), tuple)

# Generated at 2022-06-23 05:52:23.137549
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256Cipher, VaultAES256HMAC
    vs = VaultSecret('foo')
    v = VaultLib([('AES256', VaultAES256(VaultAES256Cipher(), VaultAES256HMAC()))], 1)

    cleartext = 'x'
    ciphertext = v.encrypt(cleartext, vs)
    encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)
    encrypted_unicode.vault = v

    assert encrypted_unicode.count(cleartext) == 1
