

# Generated at 2022-06-23 05:42:30.956980
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    """
    description:
        Test for __gt__ of class AnsibleVaultEncryptedUnicode
    steps:
        1. Create a AnsibleVaultEncryptedUnicode object
        2. Create another AnsibleVaultEncryptedUnicode object
        3. Create a normal string object
        4. Check __gt__ compares different types of objects correctly
    expectedResult:
        1. AnsibleVaultEncryptedUnicode object is successfully created.
        2. AnsibleVaultEncryptedUnicode object is successfully created.
        3. String object is successfully created.
        4. __gt__ compares different types of objects correctly.
    """
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('hello', None, None)

# Generated at 2022-06-23 05:42:36.601184
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    avu = AnsibleVaultEncryptedUnicode(b"")
    avu.data = "test"
    assert (u"test" == avu)
    assert (u"test" == avu.data)
    assert (u"test1" == (avu + 1))
    assert (u"test1" == (1 + avu))
    assert (b"test1" == (avu + 1).encode())
    assert (b"test1" == (1 + avu).encode())


# Generated at 2022-06-23 05:42:48.215681
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    vault = yaml.load('!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          33363161633562353762313663633133633536616237643065323132306135323263663963353164\n          6334616663656436363861613865343961390a303834646232666634646665373565653937666530\n          35346539303537376561313639316466393735316635633066383930523935346364316235346635\n          660a\n          ')
    assert(vault == b'bar')
    print("{0}".format(vault))
    assert(not vault.isprintable())

# Generated at 2022-06-23 05:42:54.837857
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    '''
    Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
    '''
    # given
    from ansible.parsing.vault import VaultLib
    vault = VaultLib()
    secret = '$ecret'
    encrypted_value = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, secret)
    encrypted_value.vault = vault
    # when
    res = encrypted_value.__hash__()
    # then
    assert res == hash('abc')


# Generated at 2022-06-23 05:42:55.792095
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:43:08.260549
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    ''' AnsibleVaultEncryptedUnicode.__le__(other)

    Returns True if all characters in the string value is alphabetically less
    or equal to all characters in the string other. The order is case-sensitive.
    '''
    msg = 'The method AnsibleVaultEncryptedUnicode.__le__() was called with an unknown argument.'
    vault = None # Mock Vault object
    secret = 'secret' # Mock vault secret
    # Test non-matching string
    s1 = 'abc' # Mock string s1
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(s1, vault, secret)
    s2 = 'aaa' # Mock string s2
    avu2 = AnsibleVaultEncryptedUnicode(s2)

# Generated at 2022-06-23 05:43:21.397345
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    import unittest

    class AnsibleVaultEncryptedUnicodeTest(unittest.TestCase):
        def test(self):
            self.assertEqual(
                text_type(AnsibleVaultEncryptedUnicode('s3cr3t')), u's3cr3t'
            )
            self.assertEqual(
                '%s' % AnsibleVaultEncryptedUnicode('s3cr3t'), u's3cr3t'
            )
            self.assertEqual(
                u'%s' % AnsibleVaultEncryptedUnicode('s3cr3t'), u's3cr3t'
            )

# Generated at 2022-06-23 05:43:31.362954
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    # tests with normal (decrypted) inputs
    result = AnsibleVaultEncryptedUnicode('123')
    assert result.isdigit()
    result = AnsibleVaultEncryptedUnicode('123a')
    assert not result.isdigit()
    result = AnsibleVaultEncryptedUnicode('abc ')
    assert not result.isdigit()
    result = AnsibleVaultEncryptedUnicode('1')
    assert result.isdigit()
    result = AnsibleVaultEncryptedUnicode('a')
    assert not result.isdigit()

    # tests with vault encrypted inputs (it does not matter if the vault
    # encryption is invalid)
    result = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;toto\ntoto!')

# Generated at 2022-06-23 05:43:33.395356
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    # No error expected
    AnsibleMapping()
    # No error expected
    AnsibleMapping({})
    # No error expected
    AnsibleMapping(dict())


# Generated at 2022-06-23 05:43:39.935671
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    from ansible.parsing.vault import VaultLib
    vault_password = '$ANSIBLE_VAULT;1.1;AES256'
    plaintext = 'foo'
    ciphertext = '3q2+7w=='
    vault = VaultLib(vault_password)
    enc = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, vault_password)
    assert enc.encode() == ciphertext



# Generated at 2022-06-23 05:43:45.692201
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    secret = 'topsecret'
    vault = AnsibleVault(secret)

    pre = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=vault, secret=secret)
    post = 'bar'
    template = '{0:s} {1:s}'
    expected = 'bar foo'
    actual = template.format(post, pre)

    assert expected == actual


# Generated at 2022-06-23 05:43:55.413001
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    original = AnsibleVaultEncryptedUnicode('ab|ab|ab')

    def check_rsplit(avu, sep, maxsplit, expected):
        result = avu.rsplit(sep, maxsplit)
        assert result == expected
    check_rsplit(original, '|', 2, ['ab|ab', 'ab'])
    check_rsplit(original, '|', 1, ['ab|ab', 'ab'])
    check_rsplit(original, '|', 0, ['ab|ab|ab'])
    check_rsplit(original, '|', -1, ['ab', 'ab', 'ab'])
    check_rsplit(original, 'b', 1, ['ab|ab|', 'a'])

# Generated at 2022-06-23 05:43:59.915528
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    from ansible.parsing.vault import VaultLib
    from io import StringIO
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import string_types
    from ansible.utils.unicode import to_unicode

    string_val = to_unicode(u'foo > bar')
    sub_string_val = to_unicode(u'>')
    new_string_val = to_unicode(u'>=')

    max_split = -1

    # setup
    vault_password = 'test'
    try:
        vault = VaultLib(vault_password)
    except AnsibleError as e:
        raise AssertionError('Error creating vault: %s' % to_native(e))

    # create an AnsibleVaultEncryptedUnicode object
    avu

# Generated at 2022-06-23 05:44:09.157593
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    # test for method isalpha of class AnsibleVaultEncryptedUnicode
    # test A-Z and a-z
    assert AnsibleVaultEncryptedUnicode('ABC').isalpha()
    assert AnsibleVaultEncryptedUnicode('abc').isalpha()

    # test non-alpha chars
    assert not AnsibleVaultEncryptedUnicode('aBc123').isalpha()
    assert not AnsibleVaultEncryptedUnicode('aBc\nA').isalpha()
    assert not AnsibleVaultEncryptedUnicode('aB%cA').isalpha()
    assert not AnsibleVaultEncryptedUnicode('AAAaAAA').isalpha()

    # test empty string
    assert not AnsibleVaultEncryptedUnicode('').isalpha()


# Generated at 2022-06-23 05:44:18.064334
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    assert AnsibleVaultEncryptedUnicode(b'abc').isprintable()
    assert not AnsibleVaultEncryptedUnicode(b'abc\x01').isprintable()
    assert not AnsibleVaultEncryptedUnicode(b'abc\x7f').isprintable()
    assert not AnsibleVaultEncryptedUnicode(b'abc\x80').isprintable()
    assert not AnsibleVaultEncryptedUnicode(b'abc\xff').isprintable()
    assert AnsibleVaultEncryptedUnicode(b'abc\x1e\x1f').isprintable()
    assert not AnsibleVaultEncryptedUnicode(b'abc\x1d').isprintable()
    assert AnsibleVaultEncryptedUnicode(b'abc\x1e').isprintable

# Generated at 2022-06-23 05:44:20.065471
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    instance = AnsibleVaultEncryptedUnicode(to_bytes("ciphertext"))
    assert repr(instance) == repr(instance.data)


# Generated at 2022-06-23 05:44:26.284929
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    string = "\x1b[36m[WARNING]:\x1b[39m\x1b[0m changed: [localhost]"
    avu = AnsibleVaultEncryptedUnicode(string.encode('utf-8'))
    assert avu.isprintable()
    assert avu.encode('ascii', errors='ignore').decode('utf-8').isprintable()

# Generated at 2022-06-23 05:44:37.322397
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    unit = AnsibleVaultEncryptedUnicode("this is a test")
    assert unit.rsplit(maxsplit=-1) == ['this', 'is', 'a', 'test']
    assert unit.rsplit(maxsplit=1) == ['this is a', 'test']
    assert unit.rsplit(maxsplit=0) == ['this is a test']
    assert unit.rsplit(maxsplit=2) == ['this is', 'a', 'test']

    unit2 = AnsibleVaultEncryptedUnicode("a.b b.a")
    assert unit2.rsplit(sep='.', maxsplit=0) == ['a.b b.a']
    assert unit2.rsplit(sep='.', maxsplit=1) == ['a.b b', 'a']
    assert unit

# Generated at 2022-06-23 05:44:48.560484
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():

    # Set up a dummy vault
    class TestVault:
        def decrypt(self, ciphertext, obj=None):
            return ciphertext
        def is_encrypted(self, ciphertext):
            return False

    vault = TestVault()

    # Set up some data
    data = ["A", "B", "C", "D"]
    data_ansible_vault = [AnsibleVaultEncryptedUnicode.from_plaintext(item, vault, None) for item in data]
    data_plaintext = [item.data for item in data_ansible_vault]

    # Joining a string sequence with AnsibleVaultEncryptedUnicode should return a normal Python string
    # and leave the AnsibleVaultEncryptedUnicode objects unmodified
    joined_plaintext = "".join(data_plaintext)


# Generated at 2022-06-23 05:44:54.127658
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    s = AnsibleSequence('foo', 'bar')
    assert s.ansible_pos == (None, 0, 0)
    assert s == [ 'foo', 'bar' ]
    s = AnsibleSequence('foo', 'bar', src='/path/to/file.yml', line=42, col=17)
    assert s.ansible_pos == ('/path/to/file.yml', 42, 17)
    assert s == [ 'foo', 'bar' ]


# Generated at 2022-06-23 05:45:02.851188
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    from ansible.parsing.vault import VaultLib
    vault_password = b"secret" 
    vault = VaultLib(vault_password)
    data = AnsibleVaultEncryptedUnicode.from_plaintext("""
#!/bin/bash
echo "Hello world"
echo "user: '{{ my_user }}'"
""", vault, b"ansible_password")
    assert data.index("!") == 0
    assert data.index("echo") == 4
    assert data.index("my_user") == -1
    assert data.index(b"my_user") == -1
    assert data.index(u"my_user") == -1


# Generated at 2022-06-23 05:45:15.856779
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    # Test when right side is empty string
    avue = AnsibleVaultEncryptedUnicode('This is a test')
    assert avue.rpartition(' ') == ('This is a', ' ', '')
    # Test when right side is decimal number
    avue = AnsibleVaultEncryptedUnicode('This is a test 1234')
    assert avue.rpartition(' ') == ('This is a test', ' ', '1234')
    # Test when right side is non-decimal number
    avue = AnsibleVaultEncryptedUnicode('This is a test c')
    assert avue.rpartition(' ') == ('This is a test', ' ', 'c')
    # Test when right side is a string
    avue = AnsibleVaultEncryptedUnicode('This is a test test')
   

# Generated at 2022-06-23 05:45:17.805759
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    # See https://bugs.python.org/issue21996
    assert float(AnsibleVaultEncryptedUnicode('-inf')) == float('-inf')


# Generated at 2022-06-23 05:45:21.219746
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    str = AnsibleVaultEncryptedUnicode()
    str.data = '1,2,3'
    assert str.rsplit(',') == ['1', '2', '3']



# Generated at 2022-06-23 05:45:25.631257
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    c = AnsibleVaultEncryptedUnicode(b'abca')
    (a, b, c) = c.rpartition('a')
    assert a=='abc' and b=='a' and c=='', "Failed method AnsibleVaultEncryptedUnicode.rpartition()"


# Generated at 2022-06-23 05:45:31.247996
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    for test1, test2, expected in [('a', 'a', True), ('a', 'b', True), ('b', 'a', False), ('a', '', True), ('a', 'aa', True), ('aa', 'a', False)]:
        assert (AnsibleVaultEncryptedUnicode(test1) <= AnsibleVaultEncryptedUnicode(test2)) == expected


# Generated at 2022-06-23 05:45:37.713063
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    """
    Test of AnsibleVaultEncryptedUnicode.__mul__
    """
    my_vault = AnsibleVaultEncryptedUnicode(u'!vault |2.0')
    assert my_vault*2 == u'!vault |2.0!vault |2.0'


# Generated at 2022-06-23 05:45:49.557018
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    """Unit test for AnsibleVaultEncryptedUnicode.__add__()
    """
    # test with two vault strings
    a = AnsibleVaultEncryptedUnicode.from_plaintext('a', 'vault', 'secret')
    b = AnsibleVaultEncryptedUnicode.from_plaintext('b', 'vault', 'secret')
    c = a + b
    assert c == 'ab'
    assert isinstance(c, AnsibleVaultEncryptedUnicode)

    # test with two un-encrypted strings
    a = 'a'
    b = 'b'
    c = a + b
    assert c == 'ab'
    assert isinstance(c, str)

    # test with a vault string and an un-encrypted string
    a = AnsibleVaultEncryptedUnicode.from_plain

# Generated at 2022-06-23 05:46:00.828343
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    # Test 1 - A number based string
    text = AnsibleBaseYAMLObject()
    text.ansible_pos = ('test.yaml', 10, 25)
    text.data = '123'
    assert(text.isdigit() == True)

    # Test 2 - A non number based string
    text = AnsibleBaseYAMLObject()
    text.ansible_pos = ('test.yaml', 10, 25)
    text.data = 'HelloWorld'
    assert(text.isdigit() == False)

    # Test 3 - An empty string
    text = AnsibleBaseYAMLObject()
    text.ansible_pos = ('test.yaml', 10, 25)
    text.data = ''
    assert(text.isdigit() == False)

    # Test 4 - A unicode number based string

# Generated at 2022-06-23 05:46:03.504856
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    test_string = u'1234567890'
    string = AnsibleVaultEncryptedUnicode(test_string)
    result = string.title()
    assert result == '1234567890'



# Generated at 2022-06-23 05:46:11.341091
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():

    class DummyVault(object):
        def __init__(self):
            self._password = 'dummy'

        def encrypt(self, s, password=None):
            return 'dummy_encrypted'

        def decrypt(self, s, password=None):
            return 'dummy_decrypted'

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello world', DummyVault(), None)

    assert avu.index('o') == 4
    assert avu.index('o', 5) == 7
    assert avu.index('o', 5, 0) == 7
    assert avu.index('o', 5, 8) == 7
    assert avu.index('o', 5, 9) == -1

    assert avu.index('d') == -1



# Generated at 2022-06-23 05:46:22.536654
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    from ansible.parsing import vault
    av = vault.VaultLib('test_password1234')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test_password1234', av, 'test_salt1234')
    assert avu.data == 'test_password1234'

# Generated at 2022-06-23 05:46:25.884177
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    avu = AnsibleVaultEncryptedUnicode('hello')
    assert(avu.expandtabs() == 'hello')



# Generated at 2022-06-23 05:46:38.012528
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    class MockVault():
        def __init__(self, decrypt_result):
            self.decrypt_result = decrypt_result

        def decrypt(self, ciphertext, secret=None, obj=None):
            return self.decrypt_result

    v = MockVault("the plaintext")
    # test with a !vault object
    s = AnsibleVaultEncryptedUnicode.from_plaintext("the plaintext", v, secret=None)
    s.vault = v
    assert s.endswith("plaintext")
    assert not s.endswith("plain")
    assert s.endswith("plaintext", 0, len("the plaintext"))
    assert s.endswith("plaintext", 0, len("the plaintext")+1)

# Generated at 2022-06-23 05:46:49.034252
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    from ansible.parsing.vault import VaultLib

    """ test for bug #9081, https://github.com/ansible/ansible/issues/9081 """
    v = VaultLib(b'test')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(u'1234', v, b'pass')
    assert 1 == avu.index(u'2')
    assert 3 == avu.index(u'4')

    avu = AnsibleVaultEncryptedUnicode(to_bytes(u'abc'))
    assert 2 == avu.index(u'c')
    try:
        avu.index(u'd')
        assert False
    except ValueError:
        pass

if __name__ == '__main__':
    test_AnsibleVault

# Generated at 2022-06-23 05:47:00.378243
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    """
    Test method __float__ of class AnsibleVaultEncryptedUnicode
    """

    def _assert_float(expected, value, msg=None):
        actual = float(value)
        assert actual == expected, msg or "float %s did not equal %s" % (actual, expected)

    _assert_float(0.0, AnsibleVaultEncryptedUnicode("0"))
    _assert_float(0.0, AnsibleVaultEncryptedUnicode("0.0"))
    _assert_float(0.0, AnsibleVaultEncryptedUnicode("-0.0"))
    _assert_float(0.0, AnsibleVaultEncryptedUnicode("+0.0"))
    _assert_float(1.0, AnsibleVaultEncryptedUnicode("1"))
    _assert

# Generated at 2022-06-23 05:47:11.798644
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    # Object of class AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode(b"12345")

    # Object of class string
    string = "12345"

    # Counts the number of occurrences of a substring in the given string
    assert avu.count(string, start=0, end=_sys.maxsize) == 1
    assert avu.count(string, start=None, end=_sys.maxsize) == 1
    assert avu.count(string, start=0, end=None) == 1
    assert avu.count(string, start=None, end=None) == 1


# Unit tests for method endswith of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:47:22.219058
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    # The test requires vault secrets file, so it is not run by the CI
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import EncryptedUnicode

    # create vault with dummy secret
    vault = VaultLib('dummy')

    # create encrypted string (this is what we have in a YAML file)
    encrypted_text = EncryptedUnicode.from_plaintext('Hello World', vault, 'dummy')

    # create vaule_text from encrypted string (this is what we get from the YAML file)

# Generated at 2022-06-23 05:47:29.156399
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    vault_password = 'testpassword'
    vault_text = 'test data'
    ciphertext = None

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    # Different object type
    ret = avu.__lt__('some string')
    assert ret == False

    # Equal
    ret = avu.__lt__(vault_text)
    assert ret == False

    # Greater
    ret = avu.__lt__('some string')
    assert ret == False

    # Less
    ret = avu.__lt__('')
    assert ret == False

if __name__ == '__main__':
    test_AnsibleVaultEncryptedUnicode___lt__()

# Generated at 2022-06-23 05:47:35.101754
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    s1 = AnsibleVaultEncryptedUnicode('foo')
    s2 = s1.__class__('foo')
    s3 = s1.__class__('bar')
    assert hash(s1) != hash(s2)
    assert hash(s1) != hash(s3)


# Generated at 2022-06-23 05:47:42.708984
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    class FakeVault:
        def __init__(self):
            self.key = "12345678"
            self.filename = "/tmp/ansible_test_vault"

        def encrypt(self, plaintext):
            return "encrypted " + plaintext

        def decrypt(self, ciphertext):
            return ciphertext.replace("encrypted ", "")

        def is_encrypted(self, ciphertext_or_plaintext):
            return ciphertext_or_plaintext != self.decrypt(ciphertext_or_plaintext)

    vault = FakeVault()
    expected = "my secret message"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(expected, vault, vault.key)
    assert avu.data == expected
    assert avu.is_encrypted()


# Generated at 2022-06-23 05:47:50.104434
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    # Test with a int
    secret = AnsibleVaultEncryptedUnicode('1234')
    assert secret * 1 == '1234'
    assert secret * 2 == '12341234'
    assert secret * 3 == '123412341234'

    # Test with a str
    secret = AnsibleVaultEncryptedUnicode('1234')
    assert secret * '1' == '1234'
    assert secret * '12' == '12341234'
    assert secret * '123' == '123412341234'



# Generated at 2022-06-23 05:47:59.502856
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    import pytest

    v = AnsibleVaultEncryptedUnicode(b"I am a test")
    assert v[2:9] == "am a te"
    assert v[0:9] == "I am a te"
    assert v[0:] == "I am a test"
    assert v[:9] == "I am a te"
    assert v[:] == "I am a test"

    with pytest.raises(TypeError):
        str(v[0:9:2])

    assert v[:2] == "I "
    assert v[2:] == "am a test"
    assert v[2:2] == ""
    assert v[-10:] == "am a test"
    assert v[:-10] == "I "

# Generated at 2022-06-23 05:48:04.648561
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    class FakeVault():
        def decrypt(self, text, obj):
            return "20"

    avu = AnsibleVaultEncryptedUnicode("Test")
    avu.vault = FakeVault()
    result = int(avu)
    assert 20 == result


# Generated at 2022-06-23 05:48:12.106677
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    class AnsibleVault():
        def __init__(self, secret):
            self.secret = secret

        def decrypt(self, ciphertext, secret=None):
            if self.secret:
                return ciphertext.decode('base64').lower().encode('base64')
            return ciphertext.decode('base64')

    secret_lowercase = '12345678'
    secret_uppercase = 'ABCDEFGH'
    ciphertext_lowercase = b'SVhZTEU='
    ciphertext_uppercase = b'SVhZTEU='
    ansible_vault_lowercase = AnsibleVault(secret=secret_lowercase)
    ansible_vault_uppercase = AnsibleVault(secret=secret_uppercase)
    avu_lowercase = AnsibleVaultEnc

# Generated at 2022-06-23 05:48:17.593555
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    avu = AnsibleVaultEncryptedUnicode(
        'U29tZSBjb2RlCg==\n\n')
    avu.vault = "testvault"
    assert "test" + avu == "testSome code\n"
    assert avu + "test" == "Some code\ntest"



# Generated at 2022-06-23 05:48:23.017285
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    # Testing that the index method operates correctly with different inputs
    test_ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('hello')
    # if the substring is the data variable of another ansible vault encrypted unicode object
    # the index method should return the index of the original data variable
    test_ansible_vault_encrypted_unicode_two = AnsibleVaultEncryptedUnicode('he')
    assert test_ansible_vault_encrypted_unicode.index(test_ansible_vault_encrypted_unicode_two) == 0

    # if the substring is of a different type, the method should convert to the default type of the data variable,
    # and treat it as a normal string
    assert test_ansible_vault_encrypted_unicode.index(1.0) == 0



# Generated at 2022-06-23 05:48:33.593851
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    vault_pass = 'password'
    value = AnsibleVaultEncryptedUnicode.from_plaintext('a-a', vault_pass, vault_pass)
    assert isinstance(value, AnsibleVaultEncryptedUnicode)
    assert value.lstrip('-') == value

    value = AnsibleVaultEncryptedUnicode.from_plaintext('a-a', vault_pass, vault_pass)
    assert isinstance(value, AnsibleVaultEncryptedUnicode)
    assert value.lstrip('a') == '-a'

    value = AnsibleVaultEncryptedUnicode.from_plaintext('-a-a', vault_pass, vault_pass)
    assert isinstance(value, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 05:48:42.607904
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    s = AnsibleVaultEncryptedUnicode('hello')
    assert s.title() == 'Hello'
    s = AnsibleVaultEncryptedUnicode('hello world')
    assert s.title() == 'Hello World'
    s = AnsibleVaultEncryptedUnicode('hello42world')
    assert s.title() == 'Hello42world'
    s = AnsibleVaultEncryptedUnicode('42hello')
    assert s.title() == '42hello'
    s = AnsibleVaultEncryptedUnicode('helloworld42')
    assert s.title() == 'Helloworld42'


# Generated at 2022-06-23 05:48:54.028863
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:49:02.685382
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    """Unit tests for AnsibleVaultEncryptedUnicode.title()

    We test the case where the AnsibleVaultEncryptedUnicode
    wraps a Unicode object.

    We test the case where the AnsibleVaultEncryptedUnicode
    wraps an ascii-only bytestring.
    """
    import ansible.parsing.vault

    # Create the plaintext AnsibleVaultEncryptedUnicode
    # object with a plaintext unicode.
    plaintext_univ = u'here is a test of the title method'
    plaintext_avu = AnsibleVaultEncryptedUnicode(plaintext_univ)
    assert plaintext_avu.title() == plaintext_univ.title()

    # Create the plaintext AnsibleVaultEncryptedUnicode
    # object with a plain

# Generated at 2022-06-23 05:49:08.412077
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    from ansible.parsing.vault import VaultLib
    test_data = 'testing string'
    secret = '$ANSIBLE_VAULT;1.1;AES256'

    ciphertext = VaultLib().encrypt(test_data, secret)
    u = AnsibleVaultEncryptedUnicode(ciphertext)
    u.vault = VaultLib()
    assert u.__repr__() == 'testing string'


# Generated at 2022-06-23 05:49:18.301861
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    assert AnsibleVaultEncryptedUnicode('foo').rjust(5) == '  foo'
    assert AnsibleVaultEncryptedUnicode('foo').rjust(5, '0') == '00foo'
    assert AnsibleVaultEncryptedUnicode('foo').rjust(5, '1') == '11foo'
    assert AnsibleVaultEncryptedUnicode('foo').rjust(6, 'A') == 'AAfoo'
    assert AnsibleVaultEncryptedUnicode('foo').rjust(6, 'AA') == 'AAAfoo'
    assert AnsibleVaultEncryptedUnicode('foo').rjust(5, 'AAA') == 'AAAfoo'
    assert AnsibleVaultEncryptedUnicode('foo').rjust(5, 'AAAA') == 'AAAAfoo'


# Generated at 2022-06-23 05:49:29.473184
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    encrypted = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;9.9;AES256;ansible_key\n'
                                     '36443137663436323335363533663365373865386632353438373066353230316431633661663965\n'
                                     '3765656333663633233363966333661383630366566346237353930336562616561396131623861\n'
                                     '34643334363535316566\n')

# Generated at 2022-06-23 05:49:37.681151
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible import errors
    import sys

    if sys.version_info[0] < 3:
        # Python 2
        # Note: the `unicode` type was converted to `text_type` in `__init__`
        #       so, this test is only valid when running on Python 2
        avu = AnsibleVaultEncryptedUnicode(u'abc')
        avu.vault = None
        assert avu.__eq__(u'abc')
        assert not avu.__eq__(u'def')
        avu.vault = errors.AnsibleVaultError('failure')
        assert not avu.__eq__(u'abc')



# Generated at 2022-06-23 05:49:47.139446
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    from ansible.module_utils.vault import VaultLib, VaultSecret
    from ansible.parsing.vault import VaultEditor

    secret = VaultSecret('test', None, None)
    vault = VaultLib(secret)

    ciphertext = vault.encrypt('a' * 50, b'a' * 32)
    plaintext = vault.decrypt(ciphertext, b'a' * 32)

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    assert avu.index(plaintext) == 0



# Generated at 2022-06-23 05:49:50.781258
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    avu = AnsibleVaultEncryptedUnicode(u'string value')
    assert avu.format_map({'value': u'12'}) == u'string 12'



# Generated at 2022-06-23 05:49:53.683213
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    avue = AnsibleVaultEncryptedUnicode('abcde')
    assert isinstance(reversed(avue), text_type)


# Generated at 2022-06-23 05:50:01.324905
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    from ansible.parsing.vault import VaultLib

    message = 'my password is 12345'
    secret1 = 'my secret password'
    secret2 = 'another password'
    ciphertext = VaultLib(secret1).encrypt(message, secret2)

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = VaultLib(secret2)

    # We should be able to transate an AnsibleVaultEncryptedUnicode object
    # (that has been decrypted) using the same method we do for str objects
    translated = avu.translate(None, string.digits)
    assert translated == 'my password is '

# Class for regular YAML files that can use vault

# Generated at 2022-06-23 05:50:13.525277
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    from ansible.plugins.vault import VaultLib

    vault = VaultLib(password='test')

# Generated at 2022-06-23 05:50:21.406340
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    # testing the isdecimal() function with the u''
    # type we defined above
    for i in range(1,2000):
       b = AnsibleVaultEncryptedUnicode(to_bytes(str(i), errors='surrogate_or_strict'))
       c = (b.data).isdecimal()
       assert c == True, 'the returned value is not True'
    for i in range(1,2000):
       b = AnsibleVaultEncryptedUnicode(to_bytes(str(i), errors='surrogate_or_strict'))
       a = to_text(str(i), errors='surrogate_or_strict')
       c = b.isdecimal()
       assert c == a.isdecimal(), 'the returned values are not the same'



# Generated at 2022-06-23 05:50:33.182726
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    import re
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    result = """
    ---
    foo: this is a string
    """

    vault = VaultLib('test')
    vault.update({'password': 'test'})

    data = AnsibleLoader(result, vault_secrets=vault).get_single_data()
    index = data['foo'].index('is')
    assert index == 5

    data = AnsibleLoader(result, vault_secrets=vault).get_single_data()
    index = data['foo'].index(re.compile('is'))
    assert index == 5


# Generated at 2022-06-23 05:50:43.029512
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    class TestVault:
    # vaultlib.VaultLib is not importable here, this class is meant to mimic it
        def __init__(self):
            self.password = None

        def get_password (self):
            return self.password

        def set_password (self, password):
            self.password = password

        def unset_password (self):
            self.password = None

        def encrypt (self, plaintext, secret=None):
            return 'encryptedplaintext'.encode('utf-8')

        def decrypt (self, ciphertext, secret=None):
            if self.password is None:
                raise RuntimeError(
                    'Cannot decrypt vault encrypted text, no secret provided')
            return 'plaintext'.encode('utf-8')


# Generated at 2022-06-23 05:50:49.995923
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    # Input values for testing
    INVALID_INPUTS = [
        '',
        [],
        'a',
        'ab',
        'abc',
        ['a', 'b', 'c'],
        'a5',
        'Hello World!',
        'a5Z',
        'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
    ]

# Generated at 2022-06-23 05:51:04.130674
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    # Create Data
    class Class(object):
        def __init__(self, name):
            self.name = name
    class_shape_5 = Class('square')
    sequence_shape_5 = [1, 2, 3, 4, class_shape_5]
    mapping_shape_5 = {'name': 'square', 'sides': 4}
    # Create Instance
    ansible_vault_encrypted_unicode_instance_shape_5 = AnsibleVaultEncryptedUnicode([1, 2, 3, 4, class_shape_5, 'square', 4, {'name': 'square', 'sides': 4}])
    ansible_vault_encrypted_unicode_instance_shape_5.ansible_pos = (None, 0)
    ansible_vault_encrypted_unicode_instance_shape_

# Generated at 2022-06-23 05:51:11.982148
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    from ansible.parsing.vault import VaultLib
    my_secret = 'my secret'
    my_vault = VaultLib([('default', my_secret)])
    my_encrypted_string = my_vault.encrypt('my string')
    my_avu = AnsibleVaultEncryptedUnicode.from_plaintext('my string', my_vault, my_secret)

    # Check equality
    assert my_avu == my_encrypted_string

    # Check calls
    assert my_avu.startswith('my string', 0, _sys.maxsize)
    assert not my_avu.startswith('my string', 10, _sys.maxsize)
    assert not my_avu.startswith('my string', 0, 3)

# Generated at 2022-06-23 05:51:24.306129
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    try:
        # Python 2
        from StringIO import StringIO
    except ImportError:
        # Python 3
        from io import StringIO

    import sys
    import unittest
    import vault

    # For some reason, the following import statement is needed, even though
    # 'from AnsibleVaultEncryptedUnicode import AnsibleVaultEncryptedUnicode' has
    # already been imported above.
    import ansible.parsing.vault

    class TestAnsibleVaultEncryptedUnicode(unittest.TestCase):
        def setUp(self):
            self.capturedOutput = StringIO()
            sys.stdout = self.capturedOutput
            self.vault = vault.VaultLib('test_password')

        def tearDown(self):
            self.capturedOutput.close()


# Generated at 2022-06-23 05:51:31.331418
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    # method __mod__ of class AnsibleVaultEncryptedUnicode
    # should return a plain text string
    # (not a AnsibleVaultEncryptedUnicode)
    vault_pass = 'vault_pass'
    plaintext = 'plaintext'

# Generated at 2022-06-23 05:51:33.582472
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    avu = AnsibleVaultEncryptedUnicode("hello")
    assert avu.rjust(10) == "     hello"


# Generated at 2022-06-23 05:51:44.105777
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    print('> test_AnsibleVaultEncryptedUnicode___gt__')

    password = 'ansible'
    secret = 'secret value'
    plaintext = '%s' % secret
    ciphertext = None

    # setup vault
    import ansible.parsing.vault as vault
    vault.VaultLib.load_vault_lib(password)
    vault_obj = vault.VaultLib(password)

    # encrypt
    ciphertext = vault_obj.encrypt(plaintext, password)

    # create AnsibleVaultEncryptedUnicode object
    avueu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault_obj, password)

    # test __gt__
    assert avueu.__gt__(ciphertext) == False

# Generated at 2022-06-23 05:51:49.516997
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    from ansible.parsing.vault import VaultLib
    plaintext = "Ansible"
    secret = b"supersecret"
    vault = VaultLib([])
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    encrypted.vault = vault # The vault needs to be set after creating it
    assert encrypted.lower() == plaintext.lower()


# Generated at 2022-06-23 05:51:54.884863
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    # We try to decrypt a string, which contains the character "0". The method should return 1.
    a = AnsibleVaultEncryptedUnicode("hello")
    a.data = "0"
    assert a.isdigit() == 1
    # Now we check with a string that contains "a" instead of "0"
    a.data = "a"
    assert a.isdigit() == 0
    # Finally, we try with a string that contains nothing
    a.data = ""
    assert a.isdigit() == 0


# Generated at 2022-06-23 05:52:05.992207
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
  a = AnsibleVaultEncryptedUnicode('foo bar foo')
  assert a.startswith('foo')
  b = a.replace('foo', 'bar', 1)
  assert b == 'bar bar foo'
  b = a.replace('foo', 'bar', 2)
  assert b == 'bar bar bar'
  b = a.replace('foo', 'bar', 3)
  assert b == 'bar bar bar'
  b = a.replace('foo', 'bar', 4)
  assert b == 'bar bar bar'
  b = a.replace('foo', 'bar', 0)
  assert b == 'foo bar foo'
  b = a.replace('foo', 'bar', -1)
  assert b == 'foo bar bar'
  b = a.replace('foo', 'bar', -2)
  assert b

# Generated at 2022-06-23 05:52:11.181590
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    test_string = AnsibleVaultEncryptedUnicode("test string")
    assert test_string.startswith("test str")
    assert not test_string.startswith("invalid string")

#--------------------------------------------------
# methods to alter the class structure of the objects
# as they are loaded so that they have the correct
# ansible structure for lookups, lists, etc.


# Generated at 2022-06-23 05:52:20.266280
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # test with instance of AnsibleVaultEncryptedUnicode
    assert AnsibleVaultEncryptedUnicode.__add__(
        AnsibleVaultEncryptedUnicode(b'foo'),
        AnsibleVaultEncryptedUnicode(b'bar')
    ) == b'foobar'

    # test with text
    assert AnsibleVaultEncryptedUnicode.__add__(
        AnsibleVaultEncryptedUnicode(b'foo'),
        'bar'
    ) == 'foobar'

    # test with plain bytes
    assert AnsibleVaultEncryptedUnicode.__add__(
        AnsibleVaultEncryptedUnicode(b'foo'),
        b'bar'
    ) == b'foobar'

