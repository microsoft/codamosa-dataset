

# Generated at 2022-06-23 05:42:27.687661
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:42:36.861615
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    import ansible.parsing.vault
    import ansible.parsing.vaultlib

    password = "password"
    text_in = "secret"
    text_out = "secret"

    vault = ansible.parsing.vault.VaultLib(password)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(text_in, vault, password)

    assert avu.data == text_out
    assert avu.is_encrypted() == True
    assert avu.vault != None

    if hasattr(avu, '__hash__'):
        hash(avu)
    assert str(avu) == text_out
    assert repr(avu) == to_text(repr(text_out))
    assert int(avu)

# Generated at 2022-06-23 05:42:39.670271
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    avu = AnsibleVaultEncryptedUnicode('A')
    assert avu.lower() == 'a'


# Generated at 2022-06-23 05:42:44.016491
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    aveu = AnsibleVaultEncryptedUnicode('Mein Passwort: 12345')

    table = aveu.maketrans(dict.fromkeys(string.ascii_letters))
    aveu.translate(table)

# Generated at 2022-06-23 05:42:51.210337
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    avu = AnsibleVaultEncryptedUnicode("test string")
    assert avu.__mod__("{0}") == "test string"
    assert avu.__mod__("{0}{1}") == "test string{1}"
    assert avu.__mod__("{0}{0}") == "test stringtest string"
    assert avu.__mod__("{0} {1}") == "test string {1}"
    assert avu.__mod__("{0} {1}") == "test string {1}"


# Generated at 2022-06-23 05:43:00.411313
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    import unittest
    import sys

    class Tester(unittest.TestCase):
        def setUp(self):
            import vault
            self.guarded_vault = vault.VaultLib(bytes([1, 2, 3, 4]))
            self.guarded_vault.changed = True
            self.guarded_plain = AnsibleVaultEncryptedUnicode.from_plaintext("test1test2test3test4test5", self.guarded_vault, "test")

        def test_rstrip(self):
            self.assertEqual(self.guarded_plain.rstrip("test5"), "test1test2test3test4")

    try:
        unittest.main()
    except SystemExit as inst:
        if inst.args[0]:
            raise



# Generated at 2022-06-23 05:43:13.271195
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    def _gen_test_data():
        for i in range(0x0000, 0x0020):
            if i not in [0x0009, 0x000A, 0x000B, 0x000C, 0x000D, 0x0020]:
                yield i
        for i in range(0x0085, 0x00A0):
            yield i
        for i in range(0x2000, 0x200B):
            yield i
        for i in range(0x2028, 0x202F):
            yield i
        for i in range(0x205F, 0x2070):
            yield i
        for i in range(0x3000, 0x3008):
            yield i
        yield 0x00A0
        yield 0x2000
        yield 0x2002
        yield 0x2003
        yield

# Generated at 2022-06-23 05:43:16.175630
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    a = AnsibleVaultEncryptedUnicode('foo')

    assert(a.split() == ['foo'])



# Generated at 2022-06-23 05:43:18.175084
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    assert int(AnsibleVaultEncryptedUnicode('1')) == 1


# Generated at 2022-06-23 05:43:28.104398
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    # Create an ansible vault encrypted string containing a newline
    # This should be treated as a single line
    av1 = AnsibleVaultEncryptedUnicode("here\n")
    assert av1.splitlines(True) == ['here\n']
    assert av1.splitlines(False) == ['here']

    # Create an ansible vault encrypted string containing a carriage return
    # This should split into two lines
    av2 = AnsibleVaultEncryptedUnicode("here\r")
    assert av2.splitlines(True) == ['here\r']
    assert av2.splitlines(False) == ['here']

    # Create an ansible vault encrypted string containing a carriage return and newline
    # This should be treated as a single line
    av3 = AnsibleVaultEncryptedUnicode("here\r\n")


# Generated at 2022-06-23 05:43:37.856613
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    seq = [b'a', b'b', b'c']
    seq_wrapped = [AnsibleVaultEncryptedUnicode(v) for v in seq]
    # method join is called by the AnsibleVaultEncryptedUnicode
    assert AnsibleVaultEncryptedUnicode(b' ').join(seq) == AnsibleVaultEncryptedUnicode(b' ').join(seq_wrapped)
    assert AnsibleVaultEncryptedUnicode(b' ').join(seq) == AnsibleVaultEncryptedUnicode(b'abc')
    assert AnsibleVaultEncryptedUnicode(b' ').join(seq_wrapped) == AnsibleVaultEncryptedUnicode(b'abc')


# Generated at 2022-06-23 05:43:41.438298
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    # Initialize
    result = None
    expected = None

    # Start test
    avueu = AnsibleVaultEncryptedUnicode('')
    avueu.data = 'foo'

    result = reversed(avueu)
    expected = 'oof'

    # End test
    assert result == expected



# Generated at 2022-06-23 05:43:50.940171
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    if _sys.version_info[0] == 2:
        assert(to_native(AnsibleVaultEncryptedUnicode('X')) == 'X')
        assert(to_native(b'XY' + AnsibleVaultEncryptedUnicode('X')) == 'XYX')
        assert(to_native(AnsibleVaultEncryptedUnicode('X') + b'XY') == 'XXY')
        assert(to_native(b'XY' + AnsibleVaultEncryptedUnicode('X') + b'Z') == 'XYXZ')
    else:
        assert(to_native(AnsibleVaultEncryptedUnicode('X')) == 'X')

# Generated at 2022-06-23 05:44:00.688038
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    encrypted_unicode = AnsibleVaultEncryptedUnicode('Hello:World')
    assert encrypted_unicode.split(':') == ['Hello', 'World']
    assert encrypted_unicode.split() == ['Hello:World']
    assert encrypted_unicode.split(None) == ['Hello:World']
    assert encrypted_unicode.split(':', 1) == ['Hello', 'World']
    assert encrypted_unicode.split(':', 2) == ['Hello', 'World']
    assert encrypted_unicode.split(':', 1) == ['Hello', 'World']
    assert encrypted_unicode.split(':', 0) == ['Hello:World']



# Generated at 2022-06-23 05:44:15.274824
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    import tempfile
    import os
    import stat

    # Prepare a random secret
    random_secret_file_name = tempfile.mkstemp()[1]
    random_secret_file = open(random_secret_file_name, 'wb')
    random_secret_file.write(os.urandom(16))
    random_secret_file.close()
    os.chmod(random_secret_file_name, stat.S_IRUSR)

    # Prepare the vault
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted as vault_is_encrypted
    from ansible.parsing.vault import is_unlocked as vault_is_unlocked
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    vault

# Generated at 2022-06-23 05:44:23.883370
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    text = 'this is a string'
    vault = AnsibleVaultEncryptedUnicode.from_plaintext(text, vault='vault', secret='secret')
    # one of the two is class AnsibleVaultEncryptedUnicode
    assert to_text(vault + 'this is another string') == text + 'this is another string'
    # both are class AnsibleVaultEncryptedUnicode
    assert to_text(vault + vault) == text + text


# Generated at 2022-06-23 05:44:31.682565
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    import vault

    # TODO: this test is not a good use of unittest
    myvault = vault.VaultLib('testpassword')
    orig = "good morning"
    avue = AnsibleVaultEncryptedUnicode.from_plaintext(orig, myvault, 'testpassword')
    avue2 = AnsibleVaultEncryptedUnicode.from_plaintext("good morning", myvault, "testpassword")
    avue3 = AnsibleVaultEncryptedUnicode.from_plaintext("not good morning", myvault, "testpassword")
    fail = "fail"
    fail2 = "good afternoon"

    assert(avue > avue2)
    assert(avue2 < avue3)
    assert(avue < fail)
    assert(avue > fail2)



# Generated at 2022-06-23 05:44:35.685757
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    plaintext_value = 'foo'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext_value, vault=None, secret='bar')
    assert complex(avu) == complex(plaintext_value)


# Generated at 2022-06-23 05:44:43.112198
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    test_cases = [
        ('is_identifier', True),
        ('1identifier', False),
    ]

    for case in test_cases:
        if AnsibleVaultEncryptedUnicode(case[0]).isidentifier() != case[1]:
            raise AssertionError("Unexpected result for AnsibleVaultEncryptedUnicode.isidentifier")

test_AnsibleVaultEncryptedUnicode_isidentifier()


# Generated at 2022-06-23 05:44:47.647756
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    str = AnsibleVaultEncryptedUnicode("2+2j")
    ansible_vault_encrypted_unicode_complex = str.__complex__()
    builtin_bytes_complex = complex(str)
    assert ansible_vault_encrypted_unicode_complex == builtin_bytes_complex



# Generated at 2022-06-23 05:44:56.137686
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    v = AnsibleVaultEncryptedUnicode('012345678')

    if sys.version_info >= (3, 0):
        assert v[:] == '012345678'
        assert v[0:] == '012345678'
        assert v[2:] == '2345678'
        assert v[:2] == '01'
        assert v[:5] == '01234'
        assert v[:-3] == '0123456'
        assert v[:-6] == '0123'
        assert v[-7:-5] == '23'
        assert v[-5:7] == '4567'
        assert v[-9:9] == '012345678'
        assert v[-20:20] == '012345678'
        assert v[-20:-15] == ''

# Generated at 2022-06-23 05:45:00.560215
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    aveu = AnsibleVaultEncryptedUnicode("fOObAr")
    aveu.vault = AnsibleVaultLib(None)
    assert aveu.lower() == "foobar"


# Generated at 2022-06-23 05:45:05.071844
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:45:17.134711
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    assert AnsibleVaultEncryptedUnicode('abc').isprintable() == True
    assert AnsibleVaultEncryptedUnicode('abc\n').isprintable() == False
    assert AnsibleVaultEncryptedUnicode('abc\t').isprintable() == False
    assert AnsibleVaultEncryptedUnicode('\x00').isprintable() == False
    assert AnsibleVaultEncryptedUnicode('\x01').isprintable() == False
    assert AnsibleVaultEncryptedUnicode('\x10').isprintable() == False
    assert AnsibleVaultEncryptedUnicode('\x7F').isprintable() == False
    assert AnsibleVaultEncryptedUnicode('\x80').isprintable() == False

# Generated at 2022-06-23 05:45:25.261630
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():

    def run_test(str_in, expected):
        av_unicode = AnsibleVaultEncryptedUnicode(str_in)
        assert 3 == len(av_unicode.rpartition('='))
        for i in [0,1,2]:
            assert expected[i] == av_unicode.rpartition('=')[i]

    run_test('ABC=DEF', ('ABC', '=', 'DEF')) # equal sign is found
    run_test('ABCDEF', ('', '', 'ABCDEF'))  # equal sign is missing



# Generated at 2022-06-23 05:45:31.234803
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    encrypted = AnsibleVaultEncryptedUnicode(b'\x00dKS4\x00\x1d\x02\xafR\xdb\xa9X\xbcT\x00\xe1f\xa1s\t\xd4\xeb-\x02\x00\x00')
    assert encrypted.isalpha() == True


# Generated at 2022-06-23 05:45:37.222618
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    # Test for specific part of the method
    test_data = to_bytes('TEST')

    class TestVault(object):
        def decrypt(self, ciphertext, obj=None):
            return test_data

    ansible_vault_obj = AnsibleVaultEncryptedUnicode('ciphertext')
    ansible_vault_obj.vault = TestVault()

    assert ansible_vault_obj.lower() == test_data.lower()


# Generated at 2022-06-23 05:45:45.822580
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    avu = AnsibleVaultEncryptedUnicode('secretstring')

    # the default data element of AnsibleVaultEncryptedUnicode is a byte string
    # we can multiply with an integer (and get back a byte string)
    assert(avu * 2 == b'secretstringsecretstring')

    # we can multiply with a byte string (and get back a byte string)
    assert(avu * b'X' == b'secretstringX')

    # but we cannot multiply with a unicode string (this generates an exception)
    try:
        avu * u'X'
        # if we get here we have not raised an exception
        # therefore the test is failed
        assert(False)
    except TypeError as e:
        # we get here because we raised an exception (as expected)
        assert(True)

    #

# Generated at 2022-06-23 05:45:52.510277
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
  assert AnsibleVaultEncryptedUnicode('123').isdecimal() == True

# this is how PyYAML represents a yaml null
AnsibleNull = AnsibleUnicode('null')

# used to test isinstance(x,text_type) as a workaround to
# what looks like a bug in PyYAML: http://pyyaml.org/ticket/29
AnsibleUnicodeType = type(u'')


# Generated at 2022-06-23 05:45:54.518603
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    assert not AnsibleVaultEncryptedUnicode.__gt__(None,None)


# Generated at 2022-06-23 05:46:03.431923
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    assert AnsibleVaultEncryptedUnicode('thethethe').count('the') == 3
    assert AnsibleVaultEncryptedUnicode('xxaaxxaa').count('x') == 4
    assert AnsibleVaultEncryptedUnicode('xxaaxxaa').count('x', 0, 10) == 4
    assert AnsibleVaultEncryptedUnicode('xxaaxxaa').count('x', 0, 4) == 2
    assert AnsibleVaultEncryptedUnicode('xxaaxxaa').count('x', 2) == 2
    assert AnsibleVaultEncryptedUnicode('xxaaxxaa').count('x', 2, 10) == 2


# Generated at 2022-06-23 05:46:10.714372
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    import ansible.vault
    vault = ansible.vault.VaultLib('12345')
    plain = 'This is'
    cipher = vault.encrypt(plain, '12345')
    cipher_obj = AnsibleVaultEncryptedUnicode(cipher)
    cipher_obj.vault = vault
    assert cipher_obj.swapcase() == plain.swapcase()



# Generated at 2022-06-23 05:46:16.212517
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    msg = u'ĀīūĀīū'
    my_obj = AnsibleVaultEncryptedUnicode(msg)
    assert (my_obj.isascii() == False)
    msg = u'ABCDEFG'
    my_obj = AnsibleVaultEncryptedUnicode(msg)
    assert (my_obj.isascii() == True)



# Generated at 2022-06-23 05:46:26.339429
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    '''
    Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
    '''
    secret = 'secret'
    password = 'password'
    plaintext = 'this is plaintext'

    from ansible_test.vault import VaultLib
    vault1 = VaultLib(password)
    plaintext_vault_object = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault1, secret)

    assert plaintext_vault_object.data == plaintext

    # Strip whitespace
    assert plaintext_vault_object.rstrip() == plaintext.rstrip()
    # Strip a single character
    assert plaintext_vault_object.rstrip('x') == plaintext.rstrip('x')
    # Strip multiple characters
    assert plaintext_vault_object.r

# Generated at 2022-06-23 05:46:38.443617
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    from ansible.parsing.vault import VaultLib
    vault_password = 'mypassword'

# Generated at 2022-06-23 05:46:45.749702
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    from ansible import vault

    plaintext = 'hello world'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault.VaultLib(), 'ansible')
    assert avu.data == plaintext

    try:
        avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, None)
        assert False, 'Expected AnsibleVaultError'
    except vault.AnsibleVaultError:
        pass



# Generated at 2022-06-23 05:46:49.167333
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    avu1 = AnsibleVaultEncryptedUnicode(b'abc')
    avu2 = AnsibleVaultEncryptedUnicode(b'def')
    assert avu1 + avu2 == 'abcdef'


# Generated at 2022-06-23 05:46:55.778034
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    a_list = AnsibleSequence()
    a_list.append("foobar")
    assert isinstance(a_list, list)
    assert isinstance(a_list, AnsibleSequence)
    assert a_list[0] == "foobar"

    # check stringification
    assert str(a_list).replace("u'", "'") == "['foobar']"


# Generated at 2022-06-23 05:47:06.219546
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    avu = AnsibleVaultEncryptedUnicode(
        b'[0a1b2c3d4e5f]')
    start = 0
    end = -1
    ret = avu.__getslice__(start, end)
    assert(ret == b'[0a1b2c3d4e5f]')
    start = 1
    end = -1
    ret = avu.__getslice__(start, end)
    assert(ret == b'0a1b2c3d4e5f]')
    start = -1
    end = -1
    ret = avu.__getslice__(start, end)
    assert(ret == b'f')

    # format
    start = -1
    end = -1
    ret = avu.__getsl

# Generated at 2022-06-23 05:47:14.061811
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    # Check that __int__ works when it should
    # Does not raise
    try:
        int(AnsibleVaultEncryptedUnicode("42"))
    except Exception:
        # Raised, unit test has failed
        raise AssertionError("__int__ method of AnsibleVaultEncryptedUnicode raised exception when it should not have")

    # Check that __int__ raises when it should
    # Raises
    try:
        int(AnsibleVaultEncryptedUnicode("Hello world"))
    except ValueError:
        # Raised, test passed
        return
    # Did not raise, unit test has failed
    raise AssertionError("__int__ method of AnsibleVaultEncryptedUnicode did not raise exception when it should have")



# Generated at 2022-06-23 05:47:26.188749
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():

    # In case you have to test many classes:
    class A(object): pass
    class B(object): pass

    # Test case with plain text string on the left side
    text = AnsibleVaultEncryptedUnicode('')

    # validation for plain text string
    print("test_AnsibleVaultEncryptedUnicode___radd__ case 1")
    for item in ['Hello World', '',
                 object(), object, dir, 2, 3.0,
                 A(), B,
                 [], [2, 3],
                 {}, {'a': 'b', 'c': 'd'},
                 b'', b'xyz']:
        result = item + text
        print("type({}) = {}".format(item, type(item)))
        print("type({}) = {}".format(text, type(text)))

# Generated at 2022-06-23 05:47:31.064638
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    from ansible.parsing.vault import VaultLib
    vault_text = VaultLib().encrypt(u'this is a unicode string')
    assert u'this is a unicode string' == AnsibleVaultEncryptedUnicode(vault_text).__unicode__()



# Generated at 2022-06-23 05:47:37.134390
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    avu = AnsibleVaultEncryptedUnicode("   ")
    assert avu.expandtabs() == "   "
    assert avu.expandtabs(tabsize=1) == "   "
    assert avu.expandtabs(tabsize=2) == "  "
    assert avu.expandtabs(tabsize=3) == " "
    assert avu.expandtabs(tabsize=4) == ""

test_AnsibleVaultEncryptedUnicode_expandtabs()


# Generated at 2022-06-23 05:47:44.052597
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode('') == AnsibleVaultEncryptedUnicode('')
    assert AnsibleVaultEncryptedUnicode('') != 'a'
    assert AnsibleVaultEncryptedUnicode('') != b'a'
    assert AnsibleVaultEncryptedUnicode('') != AnsibleVaultEncryptedUnicode(b'a')



# Generated at 2022-06-23 05:47:54.710122
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    # This is a regression test for an error triggered by swapping case in
    # an encrypted unicode object.
    #
    # The bug was that we erroneously checked is_encrypted() before calling
    # AnsibleVaultEncryptedUnicode.swapcase(). However, the is_encrypted()
    # method does a plaintext operation, and thus triggered a decryption
    # which should not have happened.
    class MyVault(object):
        def is_encrypted(self, data):
            return True

        def decrypt(self, data, obj):
            raise ValueError('This should not be called')
    vault = MyVault()
    u = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault, 'secret')
    u.swapcase()

# Generated at 2022-06-23 05:47:58.281657
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    # Arrange
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('25.0', None, None)
    expected = '25.0'

    # Act
    actual = avu.zfill(5)

    # Assert
    assert expected == actual



# Generated at 2022-06-23 05:48:08.395911
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:48:16.149610
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    '''
    Test method __gt__ of class AnsibleVaultEncryptedUnicode.

    :return:
    '''
    import ansible.parsing.vault
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(u'qwerty', ansible.parsing.vault.VaultLib('123456'), u'123456')
    assert avu == u'qwerty'
    assert avu < u'qwertyqwerty'
    assert avu <= u'qwerty'
    assert avu > u'QWERTY'
    assert avu >= u'qwerty'



# Generated at 2022-06-23 05:48:30.806858
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():

    from ansible.parsing.vault import VaultLib

    passphrase = 'abc'
    secret = 'my secret'
    vault = VaultLib(passphrase)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(secret, vault, passphrase)

    # Check __str__ when _ciphertext is not encrypted
    avu._ciphertext = secret
    assert str(avu) == secret

    # Check __str__ when _ciphertext is encrypted
    avu._ciphertext = vault.encrypt(secret, passphrase)
    assert str(avu) == secret

    # Check __str__ when .vault is not defined and _ciphertext is not encrypted
    avu.vault = None
    avu._ciphertext = secret
    assert str(avu) == secret

    #

# Generated at 2022-06-23 05:48:37.748962
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    '''
    This test exercises method join of class AnsibleVaultEncryptedUnicode
    '''

    import unittest
    from unittest.mock import patch, Mock

    class AnsibleVaultEncryptedUnicodeTestCase(unittest.TestCase):

       def setUp(self):
           self.avu = AnsibleVaultEncryptedUnicode('encrypted_text')

       def tearDown(self):
           pass

       @patch('ansible.parsing.vault.VaultLib')
       def test_join_str(self, mock_vault):
            '''
            This test validates the success path for method join of class AnsibleVaultEncryptedUnicode
            given a string 'a'
            '''


# Generated at 2022-06-23 05:48:46.320447
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    # This method is used by AnsibleVaultEncryptedUnicode to encrypt data
    # and it checks for __len__ on encrypted string.
    # It failed when str is unicode on Python3.
    from ansible.constants import VAULT_VERSION_1

    class FakeVaultLib(object):
        def __init__(self, secret):
            self.secret = secret

        def encrypt(self, plaintext, secret=None):
            """Break out plaintext type checking to enable unit tests"""
            # While the contents of plaintext can be binary, it must not be
            # a subclass of string. In any case, unicode is deprecated, just
            # let the error propagate.
            if isinstance(plaintext, text_type):
                return to_bytes(plaintext, errors='strict')

            # The previous check ensures we can use

# Generated at 2022-06-23 05:48:50.472389
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    avu = AnsibleVaultEncryptedUnicode('THIS IS SOME DATA')
    assert(avu * 5 == 'THIS IS SOME DATA' * 5)
    assert(5 * avu == 5 * 'THIS IS SOME DATA')



# Generated at 2022-06-23 05:48:54.369256
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    avue = AnsibleVaultEncryptedUnicode(ciphertext='Hello World! ')
    avue.vault = vaultlib.VaultLib(password='ansible')
    assert(avue.rstrip() == 'Hello World!')


# Generated at 2022-06-23 05:48:56.946053
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    s = AnsibleVaultEncryptedUnicode("abcdefg")
    r = s.isalpha()
    assert r == True


# Generated at 2022-06-23 05:49:01.423907
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    assert AnsibleVaultEncryptedUnicode('abc').rindex('b') == 1
    assert AnsibleVaultEncryptedUnicode('abc').rindex('b', 0, 2) == 1


# Generated at 2022-06-23 05:49:10.205518
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    """Unit test for AnsibleVaultEncryptedUnicode.translate()."""
    # Test that translate() correctly handles the removal of characters.
    # This used to be broken when the string to be translated was encrypted.
    # The fix was to ensure that str.maketrans() returns a bytes object.
    txt = 'bazar'
    t_txt = txt.translate(str.maketrans('a', 'o'))
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(txt, None, None)
    t_avu = avu.translate(str.maketrans('a', 'o'))
    assert t_avu == t_txt

# Generated at 2022-06-23 05:49:20.355041
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    import binascii
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError

    def isdecimal(x): return isinstance(x, (int, float))

    # Create a vault obj
    vault = VaultLib([])
    secret = b'$ANSIBLE_VAULT;1.1;AES256\n' + to_bytes(binascii.hexlify(vault.create_binary_key()).decode('ascii')) + b'\n\n'
    secret += b'!vault |\n'
    secret += vault.encrypt(b'hello world', 'secret')
    secret += b'\n'

    # TODO: This raises an exception
    # secret += b'\n!vault |

# Generated at 2022-06-23 05:49:22.698133
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode(None)
    assert avu.__ne__('any_value')


# Generated at 2022-06-23 05:49:32.520662
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import AnsibleVaultError

    # vault w/o password returns without error
    plaintext = "hello"
    vault = VaultLib([])
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, None)
    assert avu.title() == plaintext.title()

    # vault w/ password returns without error
    plaintext = "hello"
    vault = VaultLib(['-v', '-l'])
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, 'test')
    assert avu.title() == plaintext.title()

    # vault w/o password returns

# Generated at 2022-06-23 05:49:38.583043
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    avu = AnsibleVaultEncryptedUnicode('test')
    if not avu.istitle():
        raise AssertionError('AnsibleVaultEncryptedUnicode.istitle() does not return False for avu = "test"')



# Generated at 2022-06-23 05:49:51.748878
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('xaxbb', vault=None, password='password')
    assert avu.find('') == 0
    assert avu.find('a') == 1
    assert avu.find('a', 1) == 1
    assert avu.find('a', 2) == -1
    assert avu.find('b') == 3
    assert avu.find('b', 3) == 3
    assert avu.find('b', 4) == -1
    assert avu.find('c') == -1
    assert avu.find('ab') == -1
    assert avu.find('ax') == -1
    assert avu.find('xx') == -1
    assert avu.find('bb') == -1

    avu = AnsibleVault

# Generated at 2022-06-23 05:50:02.291036
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import UnsafeVaultLib as UnsafeVaultLib
    import string
    import random

    def random_string():
        string_length = random.randint(1, 5)
        return ''.join(random.choice(string.ascii_lowercase) for x in range(string_length))

    vault = VaultLib(None)
    # Test repeated string multiplication
    for length in range(1,6):
        repeat_count = random.randint(1, 5)
        plain_password = random_string()
        ciphertext = vault.encrypt(plain_password, plain_password)
        avu = AnsibleVaultEncryptedUnicode(ciphertext, vault)
        repeated_avu = avu * repeat

# Generated at 2022-06-23 05:50:09.714863
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    class MockVault():
        def encrypt(self, data, secret):
            return data

        def decrypt(self, cypher):
            return cypher

        def is_encrypted(self, string):
            return False

    vault = MockVault()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('{}', vault, 'secret')
    assert avu.format('foo') == 'foo'


# Generated at 2022-06-23 05:50:18.423463
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    avu_obj = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, 'secret')
    if avu_obj.strip() != 'test':
        raise AssertionError('AnsibleVaultEncryptedUnicode method strip not working')

# Generated at 2022-06-23 05:50:31.018646
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    str_in = 'foo'
    str_out = 'oof'

# Generated at 2022-06-23 05:50:40.998988
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:50:48.624181
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    avu = AnsibleVaultEncryptedUnicode("文本")
    assert avu.rjust(4, " ") == " " + "文本"
    avu1 = AnsibleVaultEncryptedUnicode("文本")
    assert avu1.rjust(6, " ") == "   文本"


# Generated at 2022-06-23 05:50:53.746935
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    from vault import VaultLib
    vault = VaultLib('password')
    data = AnsibleVaultEncryptedUnicode.from_plaintext('asdf1234', vault, 'password')
    assert data.endswith('4')
    assert not data.endswith('3')


# Generated at 2022-06-23 05:51:06.453850
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    vault = object()
    secret = object()
    ciphertext = object()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('2',
        vault, secret)

    avu._ciphertext = ciphertext
    avu.vault = vault

    vault.isdigit = lambda plaintext : plaintext == '2'

    assert avu.isdigit() is True

    avu._ciphertext = ciphertext
    avu.vault = vault

    vault.isdigit = lambda plaintext : plaintext == 'a'

    assert avu.isdigit() is False


# class AnsibleUnsafeVaultEncryptedUnicode(AnsibleUnicode):
#     '''
#     Used in the temporary in-memory objects while the YAML is being loaded.
#     After that

# Generated at 2022-06-23 05:51:08.475089
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    obj = AnsibleVaultEncryptedUnicode("value")
    assert obj.__str__() == "value"


# Generated at 2022-06-23 05:51:11.034264
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('aabbcc\n', '', 'password')
    ans = avu.rstrip()
    assert ans == 'aabbcc'


# Generated at 2022-06-23 05:51:15.794451
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    s = 'asdf\n'
    avu = AnsibleVaultEncryptedUnicode(s)
    vault = VaultLib(None)
    avu.vault = vault
    n = avu.rstrip()
    assert(n == avu.data.rstrip())



# Generated at 2022-06-23 05:51:21.937788
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password='ansible')
    ciphertext = vault.encrypt(u"Hello World!")
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.data == u"Hello World!"
    assert avu.data == avu


# Generated at 2022-06-23 05:51:26.871745
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    a = AnsibleVaultEncryptedUnicode('cat')
    result = '%s' % a
    assert result == 'cat'

_yaml_base_loader = yaml.BaseLoader
_yaml_safe_loader = getattr(yaml, 'CSafeLoader', yaml.SafeLoader)
_yaml_loader = _yaml_safe_loader



# Generated at 2022-06-23 05:51:37.087264
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ''' ansible.module_utils.vault.AnsibleVaultEncryptedUnicode.is_encrypted()

        tests if is_encrypted returns the expected value
    '''
    from ansible.parsing.vault import VaultLib
    secret = 'testpassword'
    vault = VaultLib(secret)

    unencrypted = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(unencrypted, vault, secret)
    assert avu.is_encrypted() is False

    encrypted = vault.encrypt(unencrypted, secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(encrypted, vault, secret)
    assert avu.is_encrypted() is True

PY3 = _sys.version_info[0] == 3


# Generated at 2022-06-23 05:51:47.230755
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:51:51.351893
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    # Arrange
    avu1 = AnsibleVaultEncryptedUnicode('a')
    avu2 = AnsibleVaultEncryptedUnicode('b')
    # Act
    result = avu1.format('{0}', avu2)
    # Assert
    assert result == 'ab'


# Generated at 2022-06-23 05:52:03.600719
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    # Ciphertext is base64 encoded
    ciphertext = b"gAAAAABh/lXYiOmxNkO-fNxbDhKGzO8NhUoKhuSxHwPI6ZsiOK6I3GuqD1U4Mv-2yIY-9lH2cnPJtaOwIwg1W8B1n6bTpJjPkTlYWz9VIZDQJjm38pbw-liW-BAAAAAA=="
    from ansible.parsing.vault import VaultLib

    av = AnsibleVaultEncryptedUnicode.from_plaintext(to_text(ciphertext, errors='surrogate_or_strict'), VaultLib(b""), b"")

# Generated at 2022-06-23 05:52:09.515595
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    """Test of the split method for class AnsibleVaultEncryptedUnicode"""
    test_string = "test-string"
    test_AnsibleVaultEncryptedUnicode = AnsibleVaultEncryptedUnicode(test_string)
    result = test_AnsibleVaultEncryptedUnicode.split('-')
    assert result == [u'test', u'string']


# Generated at 2022-06-23 05:52:18.791781
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    from ansible.parsing import vault
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    vault_pass = 'some-vault-password-that-is-long'