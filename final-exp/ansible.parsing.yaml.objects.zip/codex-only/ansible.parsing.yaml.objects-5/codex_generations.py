

# Generated at 2022-06-23 05:42:20.763353
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    foo = AnsibleVaultEncryptedUnicode('foo')
    assert foo.startswith(foo)
    assert foo.startswith('fo')
    assert not foo.startswith('oo')
    assert foo.startswith('fo', 0, 1)


# Generated at 2022-06-23 05:42:31.529840
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    # test text using ASCII characters
    string_vault = AnsibleVaultEncryptedUnicode('abc')
    string_vault.vault = vaultlib.VaultLib([])
    string_vault.data = 'abc' # allow decode
    assert string_vault.encode(encoding='utf-8') == b'abc'
    assert string_vault.encode(encoding='utf-8', errors='strict') == b'abc'
    assert string_vault.encode(encoding='utf-8', errors='surrogate_or_strict') == b'abc'
    assert string_vault.encode(encoding='utf-16') == b'\xff\xfea\x00b\x00c\x00'

# Generated at 2022-06-23 05:42:34.862071
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    avu = AnsibleVaultEncryptedUnicode('hello')
    result = 'HELLO'
    if avu.swapcase() != result:
        raise RuntimeError("AnsibleVaultEncryptedUnicode.swapcase() failed")


# Generated at 2022-06-23 05:42:47.763215
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    pwd = b'$6$aw8/ikj/iKBtRb7t$mPFm8W/fNhvLgX9Fn3Ll8YHtNNpzB.KgwBu3qINH0I1ZpvuvKV9cIJ0YP0QF7G.5pdUQo6KjS6U8ri6Zu0e4C0'
    salt = b'aw8/ikj/iKBtRb7t'
    passwd = b'ansible'
    vault_obj = AnsibleVaultAES256(pwd, salt=salt)
    plaintext = u"secret"

# Generated at 2022-06-23 05:42:56.891592
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    # test object with vault
    secret = 'secret'
    vault = vaultlib.VaultLib(secret)
    string = u'strinG'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(string, vault, secret)

    # test strip string
    stripped = avu.rstrip(b'str')
    if not isinstance(stripped, AnsibleVaultEncryptedUnicode):
        raise Exception('test stripped should be of type AnsibleVaultEncryptedUnicode')
    if u'G' != stripped:
        raise Exception('test stripped does not match: %s' % stripped)

    # test no vault
    avu.vault = None
    stripped = avu.rstrip(b'str')

# Generated at 2022-06-23 05:43:05.183790
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing import vault
    import os
    cwd = os.path.dirname(__file__)
    vault_path = os.path.join(cwd, '../../lib/ansible/parsing/vault/vault.py')
    vault = vault.VaultLib(password_path=vault_path)

    test1 = "hello world"
    ciphertext1 = vault.encrypt(test1)
    encryptedUnicode1 = AnsibleVaultEncryptedUnicode(ciphertext1)
    encryptedUnicode1.vault = vault
    assert encryptedUnicode1.count('o') == 2

    test2 = "some unicode: ö å"
    ciphertext2 = vault.encrypt(test2)
    encryptedUnicode2 = AnsibleVaultEnc

# Generated at 2022-06-23 05:43:15.273292
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    class MyVault(object):
        def decrypt(self, ciphertext, obj=None):
            return ciphertext
        def is_encrypted(self, ciphertext):
            return True

    for value in [u'abc', u'ABC', u'abc123', u'abc_123', u'abc-123']:
        assert AnsibleVaultEncryptedUnicode.from_plaintext(value, vault=MyVault(), secret="bad_password").isalpha()

    for value in [u'', u'1', u'1.2', u'abc-123']:
        assert not AnsibleVaultEncryptedUnicode.from_plaintext(value, vault=MyVault(), secret="bad_password").isalpha()


# Generated at 2022-06-23 05:43:23.367289
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    avu = AnsibleVaultEncryptedUnicode(to_bytes('hello'))
    assert avu[1:] == to_text('ello')
    assert avu[3:] == to_text('lo')
    assert avu[3:3] == to_text('')
    assert avu[3:2] == to_text('')
    assert avu[3:-1] == to_text('l')
    assert avu[-1:] == to_text('o')
    assert avu[-2:-1] == to_text('l')
    assert avu[-1:-2] == to_text('')
    assert avu[-3:-2] == to_text('l')


# Note: the following aliases are defined for backwards compatibility
ansible_native_unicode_representation = text_

# Generated at 2022-06-23 05:43:28.851580
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    assert to_text(AnsibleVaultEncryptedUnicode(b'this_is_a_test_passed_by_amit')) == AnsibleVaultEncryptedUnicode(b'this_is_a_test_passed_by_amit').capitalize()



# Generated at 2022-06-23 05:43:33.945025
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    """Unit test for constructor of class AnsibleSequence"""
    test_seq = AnsibleSequence(["abc", "def", "ghi"])
    assert len(test_seq) == 3
    assert test_seq[0] == "abc"
    assert test_seq[1] == "def"
    assert test_seq[2] == "ghi"


# Generated at 2022-06-23 05:43:46.465043
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    class MockVault:
        @staticmethod
        def is_encrypted(data):
            return False
        def encrypt(self, data, secret):
            raise NotImplementedError()
        def decrypt(self, data, secret, obj):
            return data

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', MockVault(), None)
    avu = avu.strip()
    assert avu == 'foo'

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', MockVault(), None)
    avu = avu.strip('')
    assert avu == 'foo'

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foo', MockVault(), None)
    avu = avu.strip('o')
   

# Generated at 2022-06-23 05:43:55.024652
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    # set up object
    s_obj = AnsibleVaultEncryptedUnicode(" ")
    assert s_obj.isspace() == True

    s_obj = AnsibleVaultEncryptedUnicode("\n")
    assert s_obj.isspace() == True

    s_obj = AnsibleVaultEncryptedUnicode("\r")
    assert s_obj.isspace() == True

    s_obj = AnsibleVaultEncryptedUnicode("\t")
    assert s_obj.isspace() == True

    s_obj = AnsibleVaultEncryptedUnicode("a")
    assert s_obj.isspace() == False

    s_obj = AnsibleVaultEncryptedUnicode("\v")
    assert s_obj.isspace() == True


# Generated at 2022-06-23 05:44:02.198002
# Unit test for method encode of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:44:11.484304
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    test = vault.encrypt("test")
    avu = AnsibleVaultEncryptedUnicode(test)
    avu.vault = vault
    assert avu.strip() == "test"



# Generated at 2022-06-23 05:44:14.069610
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    result = AnsibleVaultEncryptedUnicode.from_plaintext(u'test', None, None).partition('e')
    assert result == (u't', u'e', u'st')



# Generated at 2022-06-23 05:44:27.467825
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    # Test when value is a real number (should output a complex number with a 0 imaginary part).
    # Test with a positive number.
    avue_u1 = AnsibleVaultEncryptedUnicode(b'2.2')
    assert (avue_u1.__complex__() == 2.2+0j)
    # Test with a negative number.
    avue_u1 = AnsibleVaultEncryptedUnicode(b'-2.2')
    assert (avue_u1.__complex__() == -2.2+0j)

    # Test when value is a real-imaginary number (should output a complex number).
    # Test with a real positive number and an imaginary positive number.
    avue_u1 = AnsibleVaultEncryptedUnicode(b'2.2j')

# Generated at 2022-06-23 05:44:38.109978
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    avue = AnsibleVaultEncryptedUnicode.from_plaintext('to be or not to be', None, None)
    assert avue.index('to be', 0) == 0, "AnsibleVaultEncryptedUnicode index, did not return the correct index"
    assert avue.index('to be', 1) == 5, "AnsibleVaultEncryptedUnicode index, did not return the correct index"
    assert avue.index('to be', 5) == 5, "AnsibleVaultEncryptedUnicode index, did not return the correct index"
    assert avue.index('to be', 8) == -1, "AnsibleVaultEncryptedUnicode index, did not return the correct index"

test_AnsibleVaultEncryptedUnicode_index()


# Generated at 2022-06-23 05:44:47.415479
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    ''' This method should return python complex objecet '''
    # '%s == complex(%r)' is just used to print parameters
    # the method ``complex()`` takes the real part from the front
    # of the string and the imaginary part from the end.
    tests = [
        (u'1+2j', '%s == complex(%r)' % (complex(1, 2), u'1+2j'))
    ]
    for input, expected in tests:
        obj = AnsibleVaultEncryptedUnicode(input)
        result = complex(obj)
        assert result == complex(1, 2)


# Generated at 2022-06-23 05:44:55.951902
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib('my secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('Hello\nthere', vault, 'my secret')
    avu.ansible_pos = ('test', 1, 0)
    lines = avu.splitlines()
    assert len(lines) == 2
    assert lines[0] == 'Hello'
    assert lines[1] == 'there'
    assert lines[0].ansible_pos == ('test', 1, 0)
    assert lines[1].ansible_pos == ('test', 2, 0)


# Generated at 2022-06-23 05:45:01.106041
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    """As AnsibleVaultEncryptedUnicode is a subclass of UserString,
    test existence of method partition.
    """
    u = AnsibleVaultEncryptedUnicode('abc')
    assert u.partition('b') == ('a', 'b', 'c')
    assert u.partition('x') == ('abc', '', '')



# Generated at 2022-06-23 05:45:09.754211
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    # test the split method for AnsibleVaultEncryptedUnicode
    # this test will compare the split method of AnsibleVaultEncryptedUnicode
    # with the split method of str
    from ansible_vault import VaultLib
    vault = VaultLib([])

    plaintext = "The quick brown fox jumps over the lazy dog"
    ciphertext = vault.encrypt(plaintext, None)
    str_ciphertext = "!vault |$ANSIBLE_VAULT;1.1;AES256\n" + ciphertext.decode("utf8")
    avu = AnsibleVaultEncryptedUnicode(str_ciphertext)
    avu.vault = vault

    assert plaintext.split(" ") == avu.split(" ")

# Generated at 2022-06-23 05:45:19.437804
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    '''
    Test AnsibleVaultEncryptedUnicode method __rmod__
    '''
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_password = 'vault'
    plaintext = 'secret'

    vault = VaultLib(vault_password)

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, vault_password)

    assert avu != 'secret'
    assert 'secret' != avu
    assert 'not secret' != avu

    assert avu.__rmod__('not secret') == 'not secret'
    assert avu.__rmod__('not secret') != 'secret'


# Generated at 2022-06-23 05:45:23.930181
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    assert AnsibleVaultEncryptedUnicode(u'10').isnumeric() == True
    assert AnsibleVaultEncryptedUnicode(u'10.5').isnumeric() == False
    assert AnsibleVaultEncryptedUnicode(u'a').isnumeric() == False


# Generated at 2022-06-23 05:45:28.208327
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    s = AnsibleVaultEncryptedUnicode(b'x')
    assert s.endswith(b'x')
    assert s.endswith(AnsibleVaultEncryptedUnicode(b'x'))


# Generated at 2022-06-23 05:45:36.126306
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    from ansible.parsing.vault import VaultLib
    passphrase = 'ansible'
    vault = VaultLib(passphrase)
    plaintext = b'Hello world'
    ciphertext = vault.encrypt(plaintext, passphrase)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.data.lower() == 'hello world'


# Creates an Ansible mapping (Python dictionary) with the same content that would be created by loading
# the YAML representation in input_string, but without parsing the YAML.

# Generated at 2022-06-23 05:45:47.938132
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    string_formatted_with_format = "string_template_%(key)s" % {'key': 'format'}
    string_formatted_with_format_map = "string_template_%(key)s" % {'key': 'format_map'}

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('string_template_format', vault=None, secret=None)
    avu_with_format = avu.format(key='format')
    avu_with_format_map = avu.format_map(dict(key='format_map'))

    assert string_formatted_with_format == avu_with_format
    assert string_formatted_with_format_map == avu_with_format_map


# Generated at 2022-06-23 05:45:50.937350
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    mapping = AnsibleMapping()
    assert isinstance(mapping, dict)
    assert isinstance(mapping, AnsibleMapping)


# Generated at 2022-06-23 05:46:01.992664
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    if not _sys.version_info[0] == 3:
        assert(AnsibleVaultEncryptedUnicode('\t').isspace() is True)  # 0x09, tab
        assert(AnsibleVaultEncryptedUnicode('\n').isspace() is True)  # 0x0a, line feed
        assert(AnsibleVaultEncryptedUnicode('\r').isspace() is True)  # 0x0d, carriage return
        assert(AnsibleVaultEncryptedUnicode(' ').isspace() is True)  # 0x20, space
        assert(AnsibleVaultEncryptedUnicode('\x0b').isspace() is True)  # 0x0b, vertical tab

# Generated at 2022-06-23 05:46:06.637598
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    x = AnsibleVaultEncryptedUnicode("xyz")
    x.data = "abc"
    if x.join("") != "abc":
        sys.exit("test_AnsibleVaultEncryptedUnicode_join() failed")


# Generated at 2022-06-23 05:46:16.128910
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    v = AnsibleVaultEncryptedUnicode('hello', 'foo')
    assert v.rindex('e') == 1
    assert v.rindex('l') == 3
    assert v.rindex('a') == -1

PY2 = _sys.version_info[0] == 2

# -------------------------------------------------------
#
# Python 2.x and 3.x are supported, and there are some
# operations that don't work the same way between
# the two.  This class is a wrapper around a string object
# that returns the correct text on both Python versions.
#

if PY2:
    _native_str = str
else:
    _native_str = str


# Generated at 2022-06-23 05:46:20.519554
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    # Construct using bracket notation, check that result is ansible_pos == None
    test_AnsibleMapping_d = { 'foo': 'bar' }
    assert AnsibleMapping(test_AnsibleMapping_d).ansible_pos == None


# Unit tests for constructor of class AnsibleUnicode

# Generated at 2022-06-23 05:46:27.087123
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    avueu = AnsibleVaultEncryptedUnicode('test')
    assert avueu.isalnum()
    assert AnsibleVaultEncryptedUnicode('TeSt').isalnum()
    assert AnsibleVaultEncryptedUnicode('_!@#$%^&*()_1234567890').isalnum()
    assert AnsibleVaultEncryptedUnicode('      ').isalnum() is False
    assert AnsibleVaultEncryptedUnicode('abcabcabcabcabcabcabcabcabcabcabcabcabcabc1').isalnum()
    assert AnsibleVaultEncryptedUnicode('abcabcabcabcabcabcabcabcabcabcabcabcabcabc1a').isalnum() is False
    assert AnsibleVaultEncryptedUnicode('abcabcabcabcabcabcabcabcabcabcabcabcabcabc1\n').isalnum()

# Generated at 2022-06-23 05:46:32.869513
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    from ansible.parsing.vault import VaultLib
    vault_password = 'vault_password'
    vault = VaultLib(vault_password)
    txt = vault.encrypt('abc')
    avu = AnsibleVaultEncryptedUnicode(txt)
    avu.vault = vault
    assert avu.rstrip() == u'abc'


# Generated at 2022-06-23 05:46:35.570448
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    avue = AnsibleVaultEncryptedUnicode('string', 0, 0)
    assert avue.rjust(20, '0') == '000000000000string'


# Generated at 2022-06-23 05:46:40.743787
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    import ansible.parsing.vault as vault
    secret = 'test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('secret', vault, secret)
    assert avu.data == 'secret'
    assert avu.strip() == 'secret'


# Generated at 2022-06-23 05:46:48.047100
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    # create AnsibleVaultEncryptedUnicode instance with some dummy data
    avue = AnsibleVaultEncryptedUnicode(b'1234567890')
    result = avue.find('a')
    # the secret data is not a string with 'a' in it, the result should be -1
    assert result == -1


# Generated at 2022-06-23 05:47:00.244567
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    class FakeVault(object):
        data_to_return = b'foo'

        def decrypt(self, *args, **kwargs):
            return self.data_to_return

    vault_object = FakeVault()

    u1 = AnsibleVaultEncryptedUnicode(b'12')
    u2 = AnsibleVaultEncryptedUnicode(b'34')
    u3 = AnsibleVaultEncryptedUnicode(b'12')
    u4 = AnsibleVaultEncryptedUnicode(b'foo')
    u5 = AnsibleVaultEncryptedUnicode(b'bar')
    u6 = AnsibleVaultEncryptedUnicode(b'foobar')

    # Test same instance
    assert u1 is not u1

    assert u1 < u2
    assert u2 > u

# Generated at 2022-06-23 05:47:04.475256
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    seq = []
    ansi_seq = AnsibleSequence(seq)
    assert ansi_seq.ansible_pos == (None, 0, 0)
    ansi_seq.ansible_pos = ('/tmp/myfile', 5, 10)
    assert ansi_seq.ansible_pos == ('/tmp/myfile', 5, 10)



# Generated at 2022-06-23 05:47:09.792966
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    res = AnsibleVaultEncryptedUnicode('password')
    res.rindex('d')
    assert res.rindex('d') == 6
    assert res.rindex('d', 3, 6) == 3
    assert res.rindex('d', 4, 5) == -1
    assert res.rindex('d', 6, 6) == 6
    assert res.rindex('d', 6, 5) == -1


# Generated at 2022-06-23 05:47:18.132612
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    from ansible.vault import VaultLib
    vault_password_file = '.vault_passwd'
    vault = VaultLib(password_files=[vault_password_file])
    ciphertext = vault.encrypt(u'foo')
    avu1 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu1.vault = vault
    avu2 = avu1.lower()
    assert avu2.data == 'foo'
    assert avu2.vault is None


# Generated at 2022-06-23 05:47:24.014340
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    import ansible.parsing.vault as vault
    test_vault = vault.VaultLib('test_password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("FOO", test_vault, 'test_password')
    assert avu.isupper()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("FOO", test_vault, 'test_password')
    avu.data = "foo"
    assert not avu.isupper()


# Generated at 2022-06-23 05:47:31.011211
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    seq = "0123456789"
    avueu = AnsibleVaultEncryptedUnicode('Test')
    res = avueu.join(seq)
    if res != '0Test1Test2Test3Test4Test5Test6Test7Test8Test9':
        raise Exception('AnsibleVaultEncryptedUnicode_join failed')



# Generated at 2022-06-23 05:47:34.219517
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    if sys.version_info[:2] == (2, 6):
        return
    import doctest
    import ansible.vault
    doctest.testmod(ansible.vault)

# Generated at 2022-06-23 05:47:36.652881
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    x = AnsibleVaultEncryptedUnicode("abc")
    assert reversed(x) == "cba", "reversed of string 'abc' should be 'cba'"

# Generated at 2022-06-23 05:47:43.434536
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    input = AnsibleVaultEncryptedUnicode.from_plaintext('HELLO', None, '')
    expected = True
    actual = input.isupper()
    assert actual == expected
    input = AnsibleVaultEncryptedUnicode.from_plaintext('hello', None, '')
    expected = False
    actual = input.isupper()
    assert actual == expected



# Generated at 2022-06-23 05:47:54.435465
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    s = AnsibleVaultEncryptedUnicode("A,B,C",)
    assert s.partition(',') == ('A','+',',B,C')
    assert s.partition('-') == ('A,B,C','-','')
    assert s.partition('') == ('','','')
    assert s.partition(',B') == ('A','B,C','')
    assert s.partition(',C') == ('A,B','C','')
    assert s.partition(',c') == ('A,B,C','-','')

    assert s.replace('A', 'X') == 'X,B,C'
    assert s.replace('+', ',') == 'A,B,C'

# Generated at 2022-06-23 05:47:58.471628
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    assert len(AnsibleVaultEncryptedUnicode('x')) == 1
    assert len(AnsibleVaultEncryptedUnicode('xy')) == 2
    assert len(AnsibleVaultEncryptedUnicode('xyz')) == 3


# Generated at 2022-06-23 05:48:01.128276
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    o = AnsibleMapping()
    o['foo'] = 'bar'
    assert o['foo'] == 'bar'
    assert len(o.keys()) == 1


# Generated at 2022-06-23 05:48:09.084188
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    from ansible.parsing.vault import VaultLib
    import types

    v = VaultLib('test')
    plaintext = u'Lorem ipsum dolor sit amet.'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, v, 'test')

    # The ansible_vault_password_file logic is potentially dangerous
    # and has been shown to cause problems.
    #
    # We don't test it when running tests, but it's enabled in
    # ansible-playbook.
    #
    # TODO: Convert this to either an integration test or a functional
    #       test that uses the CLI
    avu.vault.password = None

    assert type(avu.data) == type(plaintext)

# Generated at 2022-06-23 05:48:17.561861
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    # test case where data is not vault encrypted
    fake_vault = object()
    avu_string = 'Vault encrypted text'
    avue = AnsibleVaultEncryptedUnicode.from_plaintext(
        avu_string, fake_vault, 'my secret')
    assert not avue.is_encrypted()
    assert avue.endswith('text')
    assert not avue.endswith('TexT')
    assert avue.endswith('Vault')
    assert not avue.endswith('vault')

    # test case where data is vault encrypted
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('my secret', 'sha256')

# Generated at 2022-06-23 05:48:19.771390
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    avu = AnsibleVaultEncryptedUnicode(b'ciphertext')
    avu.data = 'datatext'
    assert avu.__complex__() == complex(u'datatext')


# Generated at 2022-06-23 05:48:25.294633
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    '''
    Ensure that the __unicode__ method does not encode to 'ascii'
    '''
    test_string = 'Weiß'
    sequence = AnsibleVaultEncryptedUnicode(test_string)
    assert to_text(sequence) == test_string


# Generated at 2022-06-23 05:48:33.252755
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    from ansible_collections.ansible.community.plugins.modules.vault import VaultLib
    vault = VaultLib({'vault_password_file': 'vault_password_file.txt'})

    seq = 'this is a test'
    secret = 'my sekrit passwd'

    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert repr(avu) == "u'this is a test'"

    assert isinstance(avu.data, text_type)


# Generated at 2022-06-23 05:48:41.394875
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.vault import get_vault_secret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import tempfile

    # Create a temporary file
    tmp_file = tempfile.mkstemp()

    # Write a vault secret to the file
    tmp_secret = b'foo bar'
    with open(tmp_file[1], 'w') as f:
        f.write(tmp_secret)

    # Read back the vault scrt
    vault_secret = get_file_vault_secret(tmp_file[1])

    # Create a vault object

# Generated at 2022-06-23 05:48:46.245348
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    avu = AnsibleVaultEncryptedUnicode(u'a')
    assert isinstance(avu.__complex__(), complex)
    assert avu.__complex__() == complex(avu.data)


# Generated at 2022-06-23 05:48:56.354788
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    if sys.version_info[0] == 3:
        assert "\u0FA1" in AnsibleVaultEncryptedUnicode('aa\u0FA1aa') # is a not-assigned Unicode character for Python 3
    else:
        assert "\u0FA1" not in AnsibleVaultEncryptedUnicode('aa\u0FA1aa') # is a not-assigned Unicode character for Python 2
    assert "\u0FA1" not in AnsibleVaultEncryptedUnicode('aa\u0FA1aa').data # is a not-assigned Unicode character
    assert not AnsibleVaultEncryptedUnicode('aa\u0FA1aa').isprintable() # is a not-assigned Unicode character



# Generated at 2022-06-23 05:49:05.948947
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    assert AnsibleVaultEncryptedUnicode(b' test\n \n').rstrip() == ' test'

# Generated at 2022-06-23 05:49:11.822833
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    # Test case 5 and 6
    s = 'Hello, world'
    # Test case 7
    s1 = 'Hello, 世界'
    # Test case 8
    s2 = 'Hello, супермаркет'

    def _test(s):
        avu = AnsibleVaultEncryptedUnicode(s)
        return avu.islower()

    assert _test(s) is False
    assert _test(s1) is False
    assert _test(s2)



# Generated at 2022-06-23 05:49:20.235553
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    import sys
    import random

    avueu = AnsibleVaultEncryptedUnicode(b'foobar')
    try:
        # this is Python 2
        assert(isinstance(avueu.__unicode__(), unicode))
    except:
        # this is Python 3
        assert(isinstance(avueu.__unicode__(), str))

    for ASCII in range(128):
        avueu = AnsibleVaultEncryptedUnicode(bytes([ASCII]))
        try:
            # this is Python 2
            assert(isinstance(avueu.__unicode__(), unicode))
        except:
            # this is Python 3
            assert(isinstance(avueu.__unicode__(), str))


# Generated at 2022-06-23 05:49:29.666060
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:49:38.975344
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    if _sys.version_info[0] >= 3:
        # Python 3
        # Unicode space characters that are considered whitespace by isspace
        # but not by the str.isspace method
        uws = u'\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000'
    else:
        # Python 2
        # Unicode space characters that are considered whitespace by isspace
        # but not by the str.isspace method
        uws = u'\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000'


# Generated at 2022-06-23 05:49:46.539630
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    assert AnsibleUnicode('abc') == u'abc'
    assert AnsibleUnicode(b'abc') == u'abc'
    assert AnsibleUnicode(u'abc') == u'abc'
    assert to_native(AnsibleUnicode(b'abc')) == u'abc'
    assert str(AnsibleUnicode(b'abc')) == 'abc'


# Generated at 2022-06-23 05:49:53.268158
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    v = AnsibleVaultEncryptedUnicode(" ")

    # This is a test for https://github.com/ansible/ansible/issues/27336
    # When that issue is closed, this could be replaced with a pytest assert
    if not v.isspace():
       raise Exception("This is a test for https://github.com/ansible/ansible/issues/27336")

# Unit tests above this line


# Generated at 2022-06-23 05:50:01.685472
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    import ansible.parsing.vault
    vault = ansible.parsing.vault.AnsibleVault('s3cr3t', 'vault-id')
    data = ['1', '2', '3']

# Generated at 2022-06-23 05:50:05.425659
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    result = AnsibleMapping()

    assert(isinstance(result, dict))
    assert(isinstance(result, AnsibleMapping))


# Generated at 2022-06-23 05:50:09.222491
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    x = AnsibleVaultEncryptedUnicode(b'abc')
    assert x.isascii()

    x = AnsibleVaultEncryptedUnicode('\x80')
    assert not x.isascii()

# Generated at 2022-06-23 05:50:11.382968
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    avueu = AnsibleVaultEncryptedUnicode('\tfoo ')
    assert avueu.strip() == u'foo'


# Generated at 2022-06-23 05:50:20.334888
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleVaultEncryptedUnicodeVaultSecret
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicodeObject
    vault_secret_key = 'AES256-CFB:vault_secret_key'
    vault_secret = AnsibleVaultEncryptedUnicodeVaultSecret()
    vault_secret.load(vault_secret_key)
    vault_password = 'vault_password'
    vault = VaultLib(vault_password, salt='salt')

# Generated at 2022-06-23 05:50:32.887884
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    v1 = AnsibleVaultEncryptedUnicode.from_plaintext(u'abcd', None, None)
    v2 = AnsibleVaultEncryptedUnicode.from_plaintext(u'ABCD', None, None)
    v3 = AnsibleVaultEncryptedUnicode.from_plaintext(u'ABCD abcd', None, None)
    v4 = AnsibleVaultEncryptedUnicode.from_plaintext(u'Abcd Efgh', None, None)
    v5 = AnsibleVaultEncryptedUnicode.from_plaintext(u'Abcd efgh', None, None)
    v6 = AnsibleVaultEncryptedUnicode.from_plaintext(u'ABcD efgh', None, None)
    v7 = AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:50:41.204004
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    s = AnsibleVaultEncryptedUnicode('hello')
    assert s.ljust(7) == 'hello  '
    assert s.ljust(7, '1234') == 'hello14'

_yaml_base_url = 'https://yaml.org/type/'

# Generated at 2022-06-23 05:50:47.097270
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault=None, secret=None)
    assert avu.upper() == 'ABC'
    assert avu.data.upper() == 'ABC'



# Generated at 2022-06-23 05:50:54.726676
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    for value in [42, u'42']:
        for vault in [None, 'fake_vault']:
            for secret in ['', 'secret', u'secret']:
                avu = AnsibleVaultEncryptedUnicode.from_plaintext(value, vault, secret)
                assert avu.rsplit() == value.rsplit()
# END Unit test for method rsplit of class AnsibleVaultEncryptedUnicode



# Generated at 2022-06-23 05:50:58.389326
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    assert AnsibleVaultEncryptedUnicode('test').capitalize() == 'Test'


# Generated at 2022-06-23 05:51:05.934717
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    cipher_data = "bar"
    vault = mock.Mock()
    vault.is_encrypted.return_value = True
    vault.decrypt.return_value = "foo"

    avu = AnsibleVaultEncryptedUnicode("bar")
    avu.vault = vault

    # when
    avu_isalpha = avu.isalpha()
    data_isalpha = avu.data.isalpha()

    # then
    assert avu_isalpha == data_isalpha



# Generated at 2022-06-23 05:51:07.655709
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    assert repr(AnsibleMapping()) == dict().__repr__()


# Generated at 2022-06-23 05:51:12.000546
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    assert AnsibleVaultEncryptedUnicode('abcd').join(('a', 'b', 'c')) == 'abcabcabc'
    assert AnsibleVaultEncryptedUnicode(' ').join(('a', 'b', 'c')) == 'a b c'
    assert AnsibleVaultEncryptedUnicode('abcd').join(('', 'b', 'c')) == 'babcdc'
    assert AnsibleVaultEncryptedUnicode('abcd').join(('a', 'b', 'c', '')) == 'abcdabc'
    assert AnsibleVaultEncryptedUnicode('abcd').join(('', 'b', 'c', '')) == 'babcdc'
    assert AnsibleVaultEncryptedUnicode('abcd').join(('a', '')) == 'aaba'


# Generated at 2022-06-23 05:51:24.307236
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import vault
    text = 'unicode test'
    password = 'vault_pass'
    vault = vault.VaultLib(password)
    with open('test.yml', 'w') as f:
        f.write('unicode: !vault |\n')
        f.write('          $ANSIBLE_VAULT;1.1;AES256\n')
        f.write('          63626334623536623162383635623635343964333266326435383130393035633938313965663362626\n')
        f.write('          366562316438396137613831336233376466663366643337666436386130313137343637666331306530\n')

# Generated at 2022-06-23 05:51:29.741797
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    from ansible.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    secret = VaultSecret(password=b'ANOTHERTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST')
    vault = VaultLib(password=secret)


# Generated at 2022-06-23 05:51:40.453276
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    import hashlib

    secret = 'test_hash_secret'

    # create a vault object for testing
    vault_lib_path = 'import ansible.plugins.vault'
    vault_args = 'password="%s", keep_content=True' % secret
    vault_class = 'VaultLib'
    vault = yaml.load(
        '!!python/object/new:%s %s' % (vault_lib_path, vault_args)
    )
    vault = getattr(vault, vault_class)()

    # create a plaintext and encrypted string to test
    plaintext = 'test_hash_secret'

    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)

    # assert expected hash values
    assert hashlib.md5(encrypted).hexdigest

# Generated at 2022-06-23 05:51:50.152913
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    """
    AnsibleVaultEncryptedUnicode.isascii() is supposed to return True if the data attribute is an ASCII string
    """
    # The plain text is an ASCII string
    plain_text = u"1234567890"
    avu = AnsibleVaultEncryptedUnicode("")
    avu.data = plain_text
    assert avu.data == plain_text
    assert avu.isascii()

    # The plain text is a non ASCII string
    plain_text = u"1234567890\u00c9"
    avu = AnsibleVaultEncryptedUnicode("")
    avu.data = plain_text
    assert avu.data == plain_text
    assert not avu.isascii()


# Generated at 2022-06-23 05:52:02.721773
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    # just to get rid of unused import warning
    assert xrange
    text = """
    a: 1
    b: 2
    c: 3
    """
    vault = AnsibleVault('vault', 'secret')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(text, vault, 'secret')
    assert avu.is_encrypted()
    # in the encrypted state avu.data == '!vault |$ANSIBLE_VAULT;1.1;AES256\n3330653564376535613866646231386635643432333439373334356138366461636133346465353864\n32386364336162316530383334356634396236620a35363637303564393533643630346630373466

# Generated at 2022-06-23 05:52:03.739585
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:52:14.606767
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    from ansible.parsing.vault import VaultEditor

    s = u"Hi there! How are you. This2 is anoth3r senten5e"
    e = u"!HIT vE"
    secret = u"test"
    ve = VaultEditor(None)
    ave = AnsibleVaultEncryptedUnicode.from_plaintext(s, ve, secret)

    # AnsibleVaultEncryptedUnicode.istitle() should not return true
    # until it is decrypted
    assert not ave.istitle(), "istitle returns wrong value"

    # AnsibleVaultEncryptedUnicode.istitle() should return true
    # after it is decrypted
    assert to_text(ave) == to_text(s), "decryption was failed"

# Generated at 2022-06-23 05:52:20.665294
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    from ansible.parsing.vault import VaultLib

    plain_txt = to_bytes("abcdefghijklmnopqrstuvwxyz")
    encrypted = VaultLib(b'hi').encrypt(plain_txt)

    cipher = AnsibleVaultEncryptedUnicode(encrypted)
    cipher.vault = VaultLib(b'hi')
    assert len(cipher) == 26
    assert cipher.is_encrypted()

    cipher = AnsibleVaultEncryptedUnicode(plain_txt)
    assert len(cipher) == 26
    assert not cipher.is_encrypted()
