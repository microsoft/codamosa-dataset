

# Generated at 2022-06-23 05:42:30.869123
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:42:39.096505
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    """
    Test case for AnsibleVaultEncryptedUnicode.find
    """
    avueu = AnsibleVaultEncryptedUnicode(
        b'This is a encrypted string with a unicode monkey: \xe4\xf6\xfc')

    # Test for simple find
    assert avueu.find('encrypted') == 10
    assert avueu.find('encrypted', 10) == 10
    assert avueu.find('encrypted', 11) == -1
    assert avueu.find('unicode', 11, 20) == 20
    assert avueu.find('unicode', 21, 30) == -1

    # Test for find with an encrypted unicode object
    finding = AnsibleVaultEncryptedUnicode('encrypted')
    assert avueu.find(finding) == 10
    assert avueu.find

# Generated at 2022-06-23 05:42:50.004440
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    # Assert if the template is of type encrypted unicode
    template = AnsibleVaultEncryptedUnicode(
        b'The number is %(num)d.')
    assert isinstance(template, AnsibleVaultEncryptedUnicode)

    # Assert if the template is of type unicode
    template = to_text('The number is %(num)d.')
    assert isinstance(template, text_type)

    # Assert if the template is of type string
    template = to_native('The number is %(num)d.')
    assert isinstance(template, str)

    # Assert if the args is a dictionary
    args = {'num': 1234}
    assert isinstance(args, dict)

    # Assert if the args is a sequence
    args = [1]

# Generated at 2022-06-23 05:42:56.586719
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    "Testing isalpha method of class AnsibleVaultEncryptedUnicode"
    assert AnsibleVaultEncryptedUnicode('a').isalpha() == True
    assert AnsibleVaultEncryptedUnicode('abcd').isalpha() == True
    assert AnsibleVaultEncryptedUnicode('abcd1').isalpha() == False
    assert AnsibleVaultEncryptedUnicode('abc-d').isalpha() == False
    assert AnsibleVaultEncryptedUnicode('abc d').isalpha() == False


# Generated at 2022-06-23 05:43:04.914910
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    avu = AnsibleVaultEncryptedUnicode('')
    assert avu.isdigit() == False
    avu = AnsibleVaultEncryptedUnicode('1')
    assert avu.isdigit() == True
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert avu.isdigit() == False
    avu = AnsibleVaultEncryptedUnicode('10')
    assert avu.isdigit() == True
    avu = AnsibleVaultEncryptedUnicode('-10')
    assert avu.isdigit() == False
    avu = AnsibleVaultEncryptedUnicode('10.0')
    assert avu.isdigit() == False
    avu = AnsibleVaultEncryptedUnicode('10,0')
    assert av

# Generated at 2022-06-23 05:43:12.753508
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    assert AnsibleVaultEncryptedUnicode(u'I am title').istitle() == True
    assert AnsibleVaultEncryptedUnicode(u'I am not title').istitle() == False
    assert AnsibleVaultEncryptedUnicode(u'I am not title').istitle() == False
    assert AnsibleVaultEncryptedUnicode(u'I\'am not title').istitle() == False
    assert AnsibleVaultEncryptedUnicode(u'i am not title').istitle() == False
    assert AnsibleVaultEncryptedUnicode(u'I am not title.').istitle() == False
    assert AnsibleVaultEncryptedUnicode(u'i Am not title.').istitle() == False
    assert AnsibleVaultEncryptedUnicode(u'I am Not title').istitle()

# Generated at 2022-06-23 05:43:24.057904
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    for s in ("I", "I love J3LO!","I LOVE J3LO!"):
        assert AnsibleVaultEncryptedUnicode(s).isupper() == s.isupper()
        assert AnsibleVaultEncryptedUnicode(s.lower()).isupper() == s.lower().isupper()



PY3 = _sys.version_info[0] == 3

if PY3:
    def utf8(s):
        if isinstance(s, bytes):
            return s
        return s.encode('utf-8')
else:
    def utf8(s):
        if isinstance(s, text_type):
            return s.encode('utf-8')
        return s

# Workaround for Python 3.4 and later not having a __dict__ attribute
# added to exceptions

# Generated at 2022-06-23 05:43:28.729607
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    avu = AnsibleVaultEncryptedUnicode('123')
    assert avu.isnumeric()

    avu = AnsibleVaultEncryptedUnicode('123.')
    assert not avu.isnumeric()

    avu = AnsibleVaultEncryptedUnicode('123xyz')
    assert not avu.isnumeric()



# Generated at 2022-06-23 05:43:30.267904
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    assert AnsibleVaultEncryptedUnicode('test').upper() == 'TEST'


# Generated at 2022-06-23 05:43:40.419333
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    avu = AnsibleVaultEncryptedUnicode("\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99")
    assert avu.translate(None, \
                         "\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99") == ""

# Generated at 2022-06-23 05:43:47.277506
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    """
    AnsibleVaultEncryptedUnicode cut and paste from the Python 2.7.13 source code.
    """
    S = AnsibleVaultEncryptedUnicode('xxx\txxx')
    print(S.expandtabs(8))
    print(S.expandtabs(4))
    print(S.expandtabs(2))


# Generated at 2022-06-23 05:43:50.346594
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    value = AnsibleVaultEncryptedUnicode('123')
    assert value.isdigit() == True, "Failed unit test for AnsibleVaultEncryptedUnicode.isdigit()"



# Generated at 2022-06-23 05:43:54.555354
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    tst = AnsibleVaultEncryptedUnicode('test')
    result = tst.endswith('t')
    if not result:
        raise AssertionError('AnsibleVaultEncryptedUnicode does not have the endswith method implemented')


# Generated at 2022-06-23 05:43:58.862686
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    avue = AnsibleVaultEncryptedUnicode('test_AnsibleVaultEncryptedUnicode')
    assert avue.ljust(1024, '=') == ansible_vault_enc_text.ljust(1024, '=')


# Generated at 2022-06-23 05:44:00.987052
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    plain_text = 'ansible vault encrypted unicode'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plain_text, vault=None, secret='password')
    assert avu.capitalize() == plain_text.capitalize()
    assert avu.data != plain_text


# Generated at 2022-06-23 05:44:09.040643
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    # create sub object first
    sub = AnsibleVaultEncryptedUnicode(u'_key')
    # create object to be tested
    string = AnsibleVaultEncryptedUnicode(u'_password: !vault |_key')
    # set up vault
    import ansible.parsing.vault as vault
    vault_pass = 'vault_pass'
    vault_obj = vault.VaultLib(vault_pass)
    string.vault = vault_obj
    # run test
    result = string.rfind(sub)
    assert result == 10


# Generated at 2022-06-23 05:44:17.990125
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # Test for success
    avu1 = AnsibleVaultEncryptedUnicode('0')
    avu1.vault = 'A'
    avu2 = AnsibleVaultEncryptedUnicode('1')
    avu2.vault = 'A'
    assert not avu1.__lt__(avu2)
    # Test for failure
    avu1 = AnsibleVaultEncryptedUnicode('0')
    avu1.vault = 'A'
    avu2 = AnsibleVaultEncryptedUnicode('0')
    avu2.vault = 'B'
    assert not avu1.__lt__(avu2)
    # Test for failure
    avu1 = AnsibleVaultEncryptedUnicode('0')
    avu1.vault = None
   

# Generated at 2022-06-23 05:44:22.043693
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    from ansible.module_utils.vault import VaultLib
    secret='test'
    vault = VaultLib(password_file='/etc/ansible/vault_pass.txt')
    ciphertext = vault.encrypt('test', secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu.ljust(10) == 'test       '



# Generated at 2022-06-23 05:44:30.956880
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    print ("Running AnsibleVaultEncryptedUnicode_isdigit()", file=_sys.stdout)
    # Unit test to check if class AnsibleVaultEncryptedUnicode has method isdigit():

    # New class instance, using AnsibleVaultEncryptedUnicode as the superclass
    class IntVal(AnsibleVaultEncryptedUnicode):
        """
        Example of subclass of AnsibleVaultEncryptedUnicode, but defining __int__ method to return the decrypted text as an Integer
        """
        def __init__(self, value):
            super(IntVal, self).__init__(value)

        def __int__(self):
            if self.vault:
                return int(self.data)
            #If the decrypted value is not an integer, return None, to signal error
            return

# Generated at 2022-06-23 05:44:41.494493
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    class MockVault:
        def __init__(self, result=None):
            self.result = result

        def is_encrypted(self, data):
            return True

        def decrypt(self, data, **kwargs):
            return self.result

    for encrypted, result, chars, expected in [
        ('', '', None, ''),
        ('', '', '', ''),
        (' ', ' ', None, ''),
        (' ', ' ', '', ''),
        (' ', '\x00', ' ', '\x00'),
        (' ', '\x00', '', '\x00'),
        (' ', None, ' ', ' '),
        (' ', None, '', ' '),
    ]:
        # strip
        s = AnsibleVaultEncryptedUnicode(' ')
        s.vault = MockV

# Generated at 2022-06-23 05:44:51.671347
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    u = AnsibleUnicode('foo')
    assert u._data_source is None
    assert u._line_number == 0
    assert u._column_number == 0

    try:
        u.ansible_pos = (u, 0)
    except:
        pass
    else:
        raise AssertionError('ansible_pos bad tuple was unexpectedly accepted as input')

    try:
        u.ansible_pos = (u, 0, 0, 0)
    except:
        pass
    else:
        raise AssertionError('ansible_pos bad tuple was unexpectedly accepted as input')

    # Test that ansible_pos property can be set
    # using a tuple/list of three values
    u.ansible_pos = (u, 0, 0)
    assert u._data_source == u
    assert u._line

# Generated at 2022-06-23 05:45:02.488308
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    key = "CorrectHorseBatteryStaple"

    test_string = "MySecret"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(test_string, vault, key)

    enc = avu.encode('UTF-8')


# Generated at 2022-06-23 05:45:15.721616
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

    # TODO: Use AnsibleVaultEncryptedUnicode.from_plaintext()
    avu = AnsibleVaultEncryptedUnicode(
        vault.encrypt('a,b,c,d', 'topsecret'),
    )
    avu.vault = VaultLib([])

    # Test ansible_vault in parameter "sep"
    assert avu.split(sep='a,b') == [
        '', 'c,d'
    ]

    # Test ansible_vault in parameter "maxsplit"

# Generated at 2022-06-23 05:45:19.821592
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    avu = AnsibleVaultEncryptedUnicode('1')
    assert avu._ciphertext == to_bytes('1')
    assert avu.data == to_text('1')



# Generated at 2022-06-23 05:45:23.468114
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    assert AnsibleVaultEncryptedUnicode("aaaa123-bbbb456-cccc789").isalnum()
    assert not AnsibleVaultEncryptedUnicode("aaaa123!=bbbb456-cccc789").isalnum()


# Generated at 2022-06-23 05:45:25.309061
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    result = AnsibleVaultEncryptedUnicode("hello")
    assert len(result) == 5



# Generated at 2022-06-23 05:45:36.395600
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    import os
    import tempfile

    class AnsibleVaultMock(object):
        vault_password_file = None
        vault_password = None
        vault_files = []
        def encrypt(self, plaintext, password=None, salt_size=None, salt=None, iv=None,
            cipher='aes256', keysize=None, iterations=None):
            from ansible.parsing.vault import get_hexdigest, get_bytes, get_cipher, get_fernet
            from ansible.parsing.vault import get_text

            binary_plaintext = get_bytes(plaintext)
            key = self.get_key(password, salt_size, salt, iv, cipher, keysize, iterations)
            cipher = get_cipher(vault_password)
            cipher_obj = cipher

# Generated at 2022-06-23 05:45:41.273465
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    print(AnsibleVaultEncryptedUnicode.__doc__)
    test_data = AnsibleVaultEncryptedUnicode('hello')
    assert test_data.rjust(10) == '     hello'

if __name__ == '__main__':
    test_AnsibleVaultEncryptedUnicode_rjust()

# Generated at 2022-06-23 05:45:45.925625
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    assert not AnsibleVaultEncryptedUnicode('\x80').isascii()
    assert AnsibleVaultEncryptedUnicode('\n').isascii()
    assert AnsibleVaultEncryptedUnicode('a').isascii()
    assert AnsibleVaultEncryptedUnicode('').isascii()
    assert AnsibleVaultEncryptedUnicode('abc\n').translate({0x41: None}).isascii()


# Generated at 2022-06-23 05:45:51.093154
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():

    # Create a AnsibleVaultEncryptedUnicode object and test __radd__ method
    try:
        # This should fail because .vault is undefined
        test_object = AnsibleVaultEncryptedUnicode('test_text')
        test_object.__radd__('test_string')
        assert False, 'AnsibleVaultEncryptedUnicode constructor should fail ' \
                      'if vault is not defined'
    except AssertionError as e:
        assert str(e) == 'Error creating AnsibleVaultEncryptedUnicode, invalid vault (None) provided', \
            'incorrect error returned from AnsibleVaultEncryptedUnicode constructor'
    except Exception as e:
        assert False, 'wrong error returned from AnsibleVaultEncryptedUnicode constructor: ' + str(e)


# Generated at 2022-06-23 05:46:02.515865
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    from ansible.vault import VaultLib
    vault = VaultLib('PASSWORD')
    encrypted_text1 = vault.encrypt('Letters123', 'TesTpAss')
    encrypted_unicode_object1 = AnsibleVaultEncryptedUnicode(encrypted_text1)
    encrypted_text2 = vault.encrypt('Letters123', 'TesTpAss')
    encrypted_unicode_object2 = AnsibleVaultEncryptedUnicode(encrypted_text2)
    assert encrypted_unicode_object1.endswith('123') == True
    assert encrypted_unicode_object1.endswith('ABC') == False
    assert encrypted_unicode_object1.endswith('123', 0 , 3) == False
    assert encrypted_unicode_object1.endswith('123', 0 , 7) == True

# Generated at 2022-06-23 05:46:08.326947
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    l = ['foo', 'bar', 'baz']
    sep = '-'
    res = sep.join(l)
    assert res == 'foo-bar-baz'
    res = AnsibleVaultEncryptedUnicode('-').join(l)
    assert res == 'foo-bar-baz'


# Generated at 2022-06-23 05:46:14.705553
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    from ansible.parsing.vault import VaultLib

    secret = VaultLib.generate_key()
    vault = VaultLib([secret])
    ciphertext = vault.encrypt('hello')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.rjust(10) == '     hello'


# Backwards compatibility aliases
AnsibleVaultEncryptedUnicodeV1 = AnsibleVaultEncryptedUnicode



# Generated at 2022-06-23 05:46:19.238731
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    # Just test the basic: that it runs without errors
    text = AnsibleVaultEncryptedUnicode(b'\xff')
    assert not text.isprintable()

# see the original UserString implementation for a comment about this method
# def __getitem__(self, index):
#    return self.data[index]

# the following methods are defined in alphabetical order:



# Generated at 2022-06-23 05:46:23.556500
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    from ansible.parsing.vault import VaultLib
    secret = 'secret'
    vault = VaultLib(password_file=None, secret=secret)
    string1 = AnsibleVaultEncryptedUnicode.from_plaintext('aaa', vault, secret)
    string2 = 'bbb'
    assert string1.__add__(string2) == 'aaabbb'


# Generated at 2022-06-23 05:46:35.384866
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    def create_instance(value):
        avu = AnsibleVaultEncryptedUnicode()
        avu._ciphertext = value
        return avu
    def test(value, search_for, expected, start=0, end=4294967295,
             msg="AnsibleVaultEncryptedUnicode.startswith method incorrect result"):
        avu = create_instance(value)
        result = avu.startswith(search_for, start, end)
        if result != expected:
            raise AssertionError(msg)
    # test1
    value = b'abcdefghijklmno'
    search_for = b'ab'
    expected = True
    test(value, search_for, expected)
    # test 2
    value = b'abcdefghijklmno'
   

# Generated at 2022-06-23 05:46:41.820827
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    assert not (AnsibleVaultEncryptedUnicode('abc') <= 'abc')
    assert AnsibleVaultEncryptedUnicode('abc') <= AnsibleVaultEncryptedUnicode('abc')
    assert not (AnsibleVaultEncryptedUnicode('abc') <= 'cba')
    assert not (AnsibleVaultEncryptedUnicode('cba') <= 'abc')



# Generated at 2022-06-23 05:46:51.631561
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    import ansible.utils.unsafe_proxy
    x = AnsibleSequence("hello", 1, ["a", "b"], {"c": "d"})
    assert x == ["hello", 1, ["a", "b"], {"c": "d"}]
    assert x._data_source is None
    assert x._line_number == 0
    assert x._column_number == 0
    assert repr(x) == repr(["hello", 1, ["a", "b"], {"c": "d"}])
    assert isinstance(x, list)
    assert isinstance(x, AnsibleBaseYAMLObject)

    x = AnsibleSequence("hello")
    assert x == ["hello"]
    assert x._data_source is None
    assert x._line_number == 0
    assert x._column_number == 0

# Generated at 2022-06-23 05:46:58.391279
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    import unittest

    class MyTestCase(unittest.TestCase):
        def test_upper(self):
            x = AnsibleVaultEncryptedUnicode("hello")
            self.assertEqual(x.upper(), "HELLO")

    suite = unittest.TestLoader().loadTestsFromTestCase(MyTestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-23 05:47:08.296901
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    # print('UNIT TEST: AnsibleVaultEncryptedUnicode.__reversed__()')
    # ######################################################################
    avu = AnsibleVaultEncryptedUnicode('')
    try:
        reversed(avu)
    except TypeError:
        pass
    # ######################################################################
    avu = AnsibleVaultEncryptedUnicode('abc')
    try:
        rev = reversed(avu)
        assert str(rev) == 'cba'
    except TypeError:
        assert False
    # ######################################################################
    avu = AnsibleVaultEncryptedUnicode('0123456789')
    try:
        rev = reversed(avu)
        assert str(rev) == '9876543210'
    except TypeError:
        assert False
    #

# Generated at 2022-06-23 05:47:14.424838
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    str = AnsibleVaultEncryptedUnicode(None)
    str.data = 'abc'
    assert(str.endswith('c'))
    assert(str.endswith('b'))
    assert(str.endswith('a'))
    assert(str.endswith('d') == False)



# Generated at 2022-06-23 05:47:18.581230
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    avu = AnsibleVaultEncryptedUnicode("abc")
    avu2 = avu.swapcase()
    assert (avu2 == "ABC")



# Generated at 2022-06-23 05:47:27.215907
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    # Tests with a plain string
    avu = AnsibleVaultEncryptedUnicode('mySecretValue')
    avu2 = AnsibleVaultEncryptedUnicode('newValue')
    assert avu.replace('Secret', '') == 'myValue'
    assert avu.replace('Secret', 'newValue') == 'mynewValueValue'
    assert avu.replace('Secret', avu2) == 'mynewValueValue'

    # Tests with an AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode('mySecretValue')
    # AnsibleVaultEncryptedUnicode and a plain string
    avu2 = AnsibleVaultEncryptedUnicode('newValue')
    assert avu.replace(avu2, '') == 'mynewValueValue'
    assert avu

# Generated at 2022-06-23 05:47:29.858493
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    avu = AnsibleVaultEncryptedUnicode('\xcb\xa8\xcb\xa6')
    assert(avu.isupper() == False)


# Generated at 2022-06-23 05:47:35.069338
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    # Given: a AnsibleVaultEncryptedUnicode object containing a base64 string
    avu = AnsibleVaultEncryptedUnicode(b'bmV3IGxpbmUgCg==')

    # When: I call the method __unicode__()
    data = avu.__unicode__()

    # Then: I see the b64 string decoded
    assert data == u'\n'


# Generated at 2022-06-23 05:47:43.648469
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    avu = AnsibleVaultEncryptedUnicode('a')
    assert avu.data == u'a'
    assert avu.isalnum()
    avu = AnsibleVaultEncryptedUnicode('ab')
    assert avu.data == u'ab'
    assert avu.isalnum()
    avu = AnsibleVaultEncryptedUnicode('a1')
    assert avu.data == u'a1'
    assert avu.isalnum()
    avu = AnsibleVaultEncryptedUnicode('1')
    assert avu.data == u'1'
    assert avu.isalnum()
    avu = AnsibleVaultEncryptedUnicode('/a')
    assert avu.data == u'/a'
    assert not avu.isalnum()
    avu = Ans

# Generated at 2022-06-23 05:47:47.690698
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    '''Test rjust.
    :return:
    '''
    assert '-123'.rjust(10, '0') == '0000-123'
    assert len('0000-123') == 10



# Generated at 2022-06-23 05:47:50.452520
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
   inputString = "abcabc"
   expected = 3
   actual = AnsibleVaultEncryptedUnicode.rindex(inputString, "abc")
   assert expected == actual

# Generated at 2022-06-23 05:47:57.541684
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():

    # Try to construct an instance
    try:
        obj = AnsibleMapping()
    except:
        assert False, "AnsibleMapping failed to construct"

    # set some arbitrary keys and values
    obj["foo"] = "bar"
    obj["baz"] = 1

    # Make sure keys are correct
    assert obj["foo"] == "bar", "foo was not set"
    assert obj["baz"] == 1, "baz was not set"



# Generated at 2022-06-23 05:48:03.567793
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    from ansible.vault import VaultLib

    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', VaultLib(), None)
    assert "1test" == 1 + avu
    assert "test1" == avu + 1
    assert "1test1" == 1 + avu + 1



# Generated at 2022-06-23 05:48:14.682232
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    import textwrap
    vault = VaultLib('123')

# Generated at 2022-06-23 05:48:19.051429
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    string = 'this is a string'
    avu = AnsibleVaultEncryptedUnicode(string)
    assert(avu.__le__(string))

    string = AnsibleVaultEncryptedUnicode(string)
    assert(avu.__le__(string))


# Generated at 2022-06-23 05:48:26.576339
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    from ansible.parsing.vault import VaultLib
    vault_secret = VaultLib.generate_key()
    vault = VaultLib(vault_secret)

    eu = AnsibleVaultEncryptedUnicode('test', vault=vault, secret=vault_secret)
    eu2 = eu.swapcase()

    assert eu == 'test'
    assert eu2 == 'TEST'



# Generated at 2022-06-23 05:48:30.224609
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    avu = AnsibleVaultEncryptedUnicode('Test')
    assert avu.ljust(2) == 'Test', 'Failed to pass test: ljust of class AnsibleVaultEncryptedUnicode'


# Generated at 2022-06-23 05:48:39.846134
# Unit test for method lstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lstrip():
    assert type(AnsibleVaultEncryptedUnicode('test').lstrip()) == AnsibleVaultEncryptedUnicode
    assert AnsibleVaultEncryptedUnicode('test').lstrip() == AnsibleVaultEncryptedUnicode('test')
    assert AnsibleVaultEncryptedUnicode(' test').lstrip() == AnsibleVaultEncryptedUnicode('test')
    assert AnsibleVaultEncryptedUnicode('test ').lstrip() == AnsibleVaultEncryptedUnicode('test ')
    assert AnsibleVaultEncryptedUnicode(' test ').lstrip() == AnsibleVaultEncryptedUnicode('test ')
    assert AnsibleVaultEncryptedUnicode('test  ').lstrip() == AnsibleVaultEncryptedUnicode('test  ')
    assert AnsibleV

# Generated at 2022-06-23 05:48:52.330275
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    x = AnsibleVaultEncryptedUnicode("[OK]")
    assert "[OK]" == x.data
    assert "[" == x.rsplit("OK]")[0]

    assert "[" == (x.rsplit("OK]")[0])
    assert "" == (x.rsplit("OK]")[1])
    assert "" == (x.rsplit("OK]")[2])
    assert "[OK" == (x.rsplit("OK")[0])
    assert "" == (x.rsplit("OK")[1])
    assert "" == (x.rsplit("OK")[2])

    x = AnsibleVaultEncryptedUnicode("[OK]")
    assert "[OK]" == x.data

# Generated at 2022-06-23 05:48:55.419475
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    alist = [1, 2, 3]
    AnsibleSequence(alist)
    assert alist == AnsibleSequence(alist)


# Generated at 2022-06-23 05:49:05.291772
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    import vaultlib

    vault1 = vaultlib.VaultSecret('password')

    # Check that a vault is required
    try:
        avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('my_secret', None, 'password')
        raise Exception('Construction should have failed due to bad vault')
    except vaultlib.AnsibleVaultError:
        pass

    # Check the construction of a AnsibleVaultEncryptedUnicode
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('my_secret', vault1, 'password')
    assert avu1._ciphertext is not None
    assert avu1.vault == vault1

    # Check that the construction of a second AnsibleVaultEncryptedUnicode works
    avu2 = AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:49:11.363997
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    assert AnsibleVaultEncryptedUnicode(to_bytes('abcdefghijklmnopqrstuvwxyz')).islower()
    assert not AnsibleVaultEncryptedUnicode(to_bytes('ABCDEFGHIJKLMNOPQRSTUVWXYZ')).islower()
    assert not AnsibleVaultEncryptedUnicode(to_bytes('0123456789')).islower()
    assert not AnsibleVaultEncryptedUnicode(to_bytes('\n \t')).islower()



# Generated at 2022-06-23 05:49:13.985240
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    import re
    s = AnsibleVaultEncryptedUnicode('a1', vault={})
    assert s.rindex('1') == 1


# Generated at 2022-06-23 05:49:22.004640
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    c = '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          36626561346139623336316434653234306636336662333735306637653563393861613766333965\n          313535643231643664393066666133356264\n          37346335316532353231353961326464366231666535636234623630356436633066656531303435\n          396564\n          '
    obj = AnsibleVaultEncryptedUnicode(c)
    assert obj.is_encrypted() == True

# Unit test 2 for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:49:31.198817
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    from ansible.parsing.vault import VaultLib

    secrets = ['test test', 'test test', 'test']
    secrets_b64 = [VaultLib.encrypt(secret, 'test') for secret in secrets]

    # Test format with the correct number of arguments
    s = AnsibleVaultEncryptedUnicode.from_plaintext(secrets[0], VaultLib(), 'test')
    try:
        ret = s.format('test')
    except TypeError:
        assert False, 'format() needs exactly 1 argument'
    else:
        if ret != 'test test':
            assert False, 'format() returned ' + ret + ' but needs to return test test'

    # Test format with a missing argument

# Generated at 2022-06-23 05:49:39.819793
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    class DummyVault(object):
        def decrypt(self, ciphertext, obj=None):
            return to_text('Some text'*10)

    secret = 'x'*16
    text = 'Some text'*10
    vault = DummyVault()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(text, vault, secret)
    assert text == avu.data
    assert avu.find(avu) == 0
    assert avu.find('Some text', 0, 12) == 0
    assert avu.find('Some text', 1, 12) == 10
    assert avu.find('Some text', 1, 11) == 10
    assert avu.find('some text') == -1
    assert avu.find('Some', 0, 1) == -1
    #assert av

# Generated at 2022-06-23 05:49:53.058068
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    from ansible.parsing.vault import VaultLib
    s = AnsibleVaultEncryptedUnicode.from_plaintext(
        u'   a   b   c   d   ',
        VaultLib([], 1),
        'pw'
    )
    print('s = ', s)
    print('s.data = ', s.data)
    print('s.strip() = ', s.strip())
    assert s.strip() == u'a   b   c   d'
    assert s.strip() != u'a b c d'
    print('s.strip(u" ") = ', s.strip(u" "))
    assert s.strip(u" ") == u'a   b   c   d'
    assert s.strip(u" ") != u'a b c d'
    print

# Generated at 2022-06-23 05:50:00.308164
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    AVEU_a = AnsibleVaultEncryptedUnicode('a')
    AVEU_b = AnsibleVaultEncryptedUnicode('b')
    assert AVEU_a + AVEU_b == 'ab'
    assert AVEU_a + 'b' == 'ab'
    assert 'a' + AVEU_b == 'ab'
    assert AVEU_a + 2 == 'a2'
    assert 2 + AVEU_b == '2b'


# Generated at 2022-06-23 05:50:07.277589
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('a', vault=None, secret='secret')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('b', vault=None, secret='secret')
    assert avu1.__ge__(avu2) == False
    assert avu2.__ge__(avu1) == True
    assert avu1.__ge__(avu1) == True


# Generated at 2022-06-23 05:50:16.981927
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    assert AnsibleVaultEncryptedUnicode("1234")[1:3] == "23"
    assert AnsibleVaultEncryptedUnicode("1234")[2:] == "34"
    assert AnsibleVaultEncryptedUnicode("1234")[:2] == "12"
    assert AnsibleVaultEncryptedUnicode("1234")[:] == "1234"
    assert AnsibleVaultEncryptedUnicode("1234")[0:10:2] == "13"
    assert AnsibleVaultEncryptedUnicode("1234")[10:-1:-2] == "3"
    assert AnsibleVaultEncryptedUnicode("1234")[10:100:-2] == "3"
    assert AnsibleVaultEncryptedUnicode("1234")[-2:0:-1]

# Generated at 2022-06-23 05:50:26.767124
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    assert AnsibleVaultEncryptedUnicode('A').swapcase() == 'a'
    assert AnsibleVaultEncryptedUnicode('a').swapcase() == 'A'
    assert AnsibleVaultEncryptedUnicode('A').swapcase() !=  AnsibleVaultEncryptedUnicode('a')
    assert AnsibleVaultEncryptedUnicode('A').swapcase() !=  AnsibleVaultEncryptedUnicode('A')
    assert AnsibleVaultEncryptedUnicode('a').swapcase() != AnsibleVaultEncryptedUnicode('a')
    assert AnsibleVaultEncryptedUnicode('a').swapcase() != AnsibleVaultEncryptedUnicode('A')
    assert AnsibleVaultEncryptedUnicode('A').swapcase() == AnsibleVault

# Generated at 2022-06-23 05:50:32.451924
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    assert AnsibleVaultEncryptedUnicode('test').__str__() == 'test'
    assert AnsibleVaultEncryptedUnicode('test').__str__(1) == 'test'
    assert AnsibleVaultEncryptedUnicode('test').__str__(1, 2) == 'test'


# Generated at 2022-06-23 05:50:44.497953
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    # Test for plaintext that could be encrypted.
    assert (AnsibleUnicode("hello world").rfind("world", 0, 11) == 6)
    # Test for plaintext that couldn't be encrypted.
    assert (AnsibleVaultEncryptedUnicode("hello world").rfind("world", 0, 11) == -1)
    # Test for plaintext that could be encrypted.
    assert (AnsibleUnicode("My password is 'password123'.").rfind("password", 0, 30) == 14)
    # Test for plaintext that could be encrypted.
    assert (AnsibleUnicode("My password is 'password123'.").rfind("password", 15, 30) == 14)
    # Test for plaintext that could be encrypted.

# Generated at 2022-06-23 05:50:56.162852
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    if sys.version_info > (3, 0):
        import unicodedata
        # test some edge cases for isidentifier() function
        assert unicodedata.lookup("GREEK SMALL LETTER IOTA") == "\u03b9"
        assert unicodedata.lookup("FULLWIDTH LATIN SMALL LETTER O") == "\uff4f"
        assert unicodedata.lookup("LATIN SMALL LETTER SALTILLO") == "\ua78b"
        assert unicodedata.lookup("PRESENTATION FORM FOR VERTICAL LEFT CURLY BRACKET") == "\ufe38"
        assert unicodedata.lookup("PRESENTATION FORM FOR VERTICAL RIGHT CURLY BRACKET") == "\ufe3b"

# Generated at 2022-06-23 05:51:07.655566
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    import unittest
    import tempfile
    import shutil
    from ansible.parsing.vault import VaultSecret, VaultLib

    class TestAnsibleVaultEncryptedUnicode_endswith_UnitTest(unittest.TestCase):

        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_ansible_vault_encrypted_endswith_with_correct_secret_returns_true(self):
            secret = VaultSecret('correct_secret')
            vault_file_path = self.temp_dir + '/vault'

# Generated at 2022-06-23 05:51:15.389007
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    try:
        import ansible.parsing.vault
    except ImportError:
        print("Unable to import vault lib")
        return

    avu = AnsibleVaultEncryptedUnicode("test")
    assert avu.data == "test"
    assert avu.vault == None

    vault = ansible.parsing.vault.VaultLib("test")
    avu = AnsibleVaultEncryptedUnicode("test", vault, "test")
    assert avu.data == "test"
    assert avu.vault == None


# Generated at 2022-06-23 05:51:24.790372
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    a = AnsibleVaultEncryptedUnicode(b"hello world")
    assert str(a) == "hello world"
    assert repr(a) == "u'hello world'"
    assert (a == u'hello world')
    assert (u'hello world' == a)
    assert (a == "hello world")
    assert ("hello world" == a)
    assert not (a != "hello world")
    assert not ("hello world" != a)
    assert not (a != u'hello world')
    assert not (u'hello world' != a)

test_AnsibleVaultEncryptedUnicode()


# Generated at 2022-06-23 05:51:26.911697
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    assert AnsibleVaultEncryptedUnicode('hello').capitalize() == 'Hello', \
        "test_AnsibleVaultEncryptedUnicode.capitalize() failed"


# Generated at 2022-06-23 05:51:39.374577
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:51:49.239990
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    if not isinstance(AnsibleVaultEncryptedUnicode.__doc__, text_type):
        raise AssertionError("AnsibleVaultEncryptedUnicode.__doc__ should be a text_type")
    if not isinstance(AnsibleVaultEncryptedUnicode.__name__, text_type):
        raise AssertionError("AnsibleVaultEncryptedUnicode.__name__ should be a text_type")
    s = AnsibleVaultEncryptedUnicode(u"a b c d e f")
    l = s.rsplit(None, 2)
    if not isinstance(l, list):
        raise AssertionError("AnsibleVaultEncryptedUnicode.rsplit should return a list")

# Generated at 2022-06-23 05:51:57.262930
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    # check that non-unicode objects are converted to unicode
    # unicode is valid
    assert isinstance(AnsibleUnicode(u'foo'), text_type)
    assert isinstance(AnsibleUnicode(b'foo'), text_type)
    assert isinstance(AnsibleUnicode(AnsibleUnicode(u'foo')), text_type)
    assert isinstance(AnsibleUnicode(u'foo'), text_type)

    # str (bytes) is valid input
    assert isinstance(AnsibleUnicode(b'foo'), text_type)

    # int/float are not valid (``text_type`` only takes str and unicode)

# Generated at 2022-06-23 05:52:02.276128
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    if __name__ == "__main__":
        vault = None
        try:
            from ansible.parsing import vault as _vault
        except ImportError:
            pass
        else:
            vault = _vault.VaultLib('test')
        secret = "password"
        text = AnsibleVaultEncryptedUnicode.from_plaintext('test', vault, secret)
        assert text.rfind('test') == 0



# Generated at 2022-06-23 05:52:05.567404
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    test_str = AnsibleVaultEncryptedUnicode("line 1\nline 2\nline 3")
    assert test_str.splitlines() == ['line 1', 'line 2', 'line 3']


# Generated at 2022-06-23 05:52:16.148745
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    string = AnsibleVaultEncryptedUnicode('')
    #string.data = '1'
    string.__setattr__('data', '1')
    assert int(string) == int('1')

    string = AnsibleVaultEncryptedUnicode('')
    #string.data = '1'
    string.__setattr__('data', '1')
    assert int(string, base=8) == int('1', base=8)

    string = AnsibleVaultEncryptedUnicode('')
    #string.data = '1.2'
    string.__setattr__('data', '1.2')
    try:
        assert int(string, base=8)
    except ValueError:
        pass
    except Exception as e:
        raise(e)



# Generated at 2022-06-23 05:52:20.689292
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    s = AnsibleVaultEncryptedUnicode('123')
    assert s.isdigit()
    s = AnsibleVaultEncryptedUnicode('123a')
    assert not s.isdigit()
