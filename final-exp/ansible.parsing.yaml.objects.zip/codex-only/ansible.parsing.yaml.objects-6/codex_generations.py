

# Generated at 2022-06-23 05:42:25.417927
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    class C(AnsibleVaultEncryptedUnicode):
        pass
    class D:
        def __getitem__(self, item):
            assert item == 'a'
            return 'b'
    s = C('{a}')
    assert s.format_map(D()) == 'b'

# Generated at 2022-06-23 05:42:33.683957
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    # load a vault
    vault_key = 'lackadaisical mellifluous mortmain catechism '.split()
    vault_key.reverse()
    vault_key = ''.join(vault_key)
    vault_key = to_text('%s\n' % vault_key)
    test_vault = AnsibleVaultLib(vault_key)

    # load the secret dictionary file
    secret_dict_file = AnsibleVaultEncryptedUnicode.from_plaintext("""
---
secret:
  first: John
  last: Doe
  age: 42
  mother: Jane Doe
""", test_vault, vault_key)

    # load the message file

# Generated at 2022-06-23 05:42:46.202655
# Unit test for method replace of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:42:54.259412
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    class MockVault(object):
        def __init__(self, secret):
            self.secret = secret

        def decrypt(self, ciphertext, obj=None):
            return to_text(self.secret + ciphertext[1:], errors='surrogate_or_strict')

    secret = 'Some-vault-secret'
    ciphertext = '!vault |' + yaml.dump(AnsibleVaultEncryptedUnicode.from_plaintext('my string', MockVault(secret), secret), Dumper=yaml.SafeDumper)

    assert AnsibleVaultEncryptedUnicode(ciphertext).capitalize() == 'My string'


# Generated at 2022-06-23 05:42:57.361023
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    avu = AnsibleVaultEncryptedUnicode(b'foo')
    assert avu.index(b'b') == 0
    assert avu.index(b'f') == 1
    assert avu.index(b'o') == 2



# Generated at 2022-06-23 05:42:58.912948
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    assert repr(AnsibleVaultEncryptedUnicode('hello')) == repr('hello')


# Generated at 2022-06-23 05:43:08.523343
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    assert not AnsibleVaultEncryptedUnicode(b'abc').islower()
    assert not AnsibleVaultEncryptedUnicode(b'ABC').islower()
    assert not AnsibleVaultEncryptedUnicode(b'123').islower()
    assert not AnsibleVaultEncryptedUnicode(b'    ').islower()
    assert AnsibleVaultEncryptedUnicode(b'abc ').islower()
    assert AnsibleVaultEncryptedUnicode(b' abc').islower()
    assert AnsibleVaultEncryptedUnicode(b'abc\n').islower()
    assert AnsibleVaultEncryptedUnicode(b' abc\n').islower()
    assert AnsibleVaultEncryptedUnicode(b'abc\n ').islower()
    assert Ansible

# Generated at 2022-06-23 05:43:10.036033
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    obj = AnsibleVaultEncryptedUnicode("hello")
    assert obj.zfill(8) == '000hello'


# Generated at 2022-06-23 05:43:22.023571
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    # data to use for tests
    data = [
        ('a', 'a'),
        ('a', 'b'),
        ('b', 'a'),
        ('a', None),
        (None, 'a'),
        (None, None),
        (None, 'b'),
        ('b', None),
    ]
    for a, b in data:
        # construct objects for testing
        if b is None:
            avu_a = AnsibleVaultEncryptedUnicode(a)
            avu_b = b
        else:
            avu_a = AnsibleVaultEncryptedUnicode(a)
            avu_b = AnsibleVaultEncryptedUnicode(b)

        # run test
        result = avu_a.__le__(avu_b)

        # verify result

# Generated at 2022-06-23 05:43:23.953269
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    assert AnsibleVaultEncryptedUnicode('hello').capitalize() == 'Hello'


# Generated at 2022-06-23 05:43:26.843031
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode("foo") != "bar"
    assert AnsibleVaultEncryptedUnicode("foo") != AnsibleVaultEncryptedUnicode("bar")



# Generated at 2022-06-23 05:43:32.339089
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    # Check initialization with unicode strings (both PY2 and PY3)
    auo1 = AnsibleUnicode(u"I can haz unicodez?")
    auo2 = AnsibleUnicode("I can haz unicodez?")
    assert auo1 == auo2

    # Check initialization with bytestrings (both PY2 and PY3)
    auo3 = AnsibleUnicode(b"I can haz unicodez?")
    assert auo1 == auo3



# Generated at 2022-06-23 05:43:35.756185
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    avu = AnsibleVaultEncryptedUnicode("test")
    assert "test" in avu
    assert "e" not in avu
    avu2 = AnsibleVaultEncryptedUnicode("e")
    assert avu2 in avu



# Generated at 2022-06-23 05:43:45.132128
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    # Arrange
    class AnsibleVaultEncryptedUnicodeMock(AnsibleVaultEncryptedUnicode):

        def __init__(self, data):
            super(AnsibleVaultEncryptedUnicodeMock, self).__init__(data)
            self.data = data

    # Act
    a1 = AnsibleVaultEncryptedUnicodeMock('a')
    a2 = AnsibleVaultEncryptedUnicodeMock('b')
    ans = a1.__le__(a2)

    # Assert
    assert (ans == True)



# Generated at 2022-06-23 05:43:48.913164
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    # Test for a title method on python 2.7 or 3.x
    string = AnsibleVaultEncryptedUnicode('the title method')
    assert string.title() == 'The Title Method'


# Generated at 2022-06-23 05:43:57.512545
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    plaintext = 'foo'
    from ansible.parsing.vault import VaultLib

    vaulttext = b'$ANSIBLE_VAULT;1.2;AES256;myvaultlabel\n5a60b5c5cf5f5e5a52256434120564133b0b7e0f1f205d734d2e2b7e502460385b304733732537c\n28206535352a2a275d79624434667b493723616671770a6635332a2c2e2f7d2e2a2f7e717521'

    # vaulttext encrypted with secret 'foo'
    assert VaultLib(None).is_encrypted(vaulttext)
    u = AnsibleVaultEncryptedUnicode(vaulttext)


# Generated at 2022-06-23 05:43:59.677934
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    obj = AnsibleVaultEncryptedUnicode("test")
    assert hash(obj) == hash("test")


# Generated at 2022-06-23 05:44:11.577121
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    """
    Test for method __repr__ of class AnsibleVaultEncryptedUnicode
    """
    def method_test(seq):
        avu = AnsibleVaultEncryptedUnicode(seq)
        assert avu.__repr__() == '{}'.format(to_bytes(seq))

    method_test('"Hello World".')
    method_test('"Hello World!".')
    method_test('"Hello World!..')
    # The following line would cause an Failure: AssertionError: 'ansible_pos can only be set with a tuple/list of three values: source, line number, column number' if the AnsibleVaultEncryptedUnicode class would not have a data_source attribute
    AnsibleVaultEncryptedUnicode.ansible_pos = "1"



# Generated at 2022-06-23 05:44:20.835622
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    """Right now we are simply reusing the __hash__ of the underlying string.

    When we implement the class as a read-only data type we need to
    come up with a real hash function
    """
    from hashlib import md5
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultLib
    from ansible.parsing import vault
    plaintext = 'foo'
    key = 'bar'

# Generated at 2022-06-23 05:44:22.239720
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    v = AnsibleVaultEncryptedUnicode('test')
    assert v.rindex('t', 0, -1) == 1


# Generated at 2022-06-23 05:44:31.030888
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    # See https://github.com/ansible/ansible/issues/67594
    s = AnsibleVaultEncryptedUnicode(b'this.module.name')
    assert s.rpartition('.') == ('this.module', '.', 'name')
    assert s.rpartition('.module') == ('this', '.', 'module.name')
    assert s.rpartition('.module.') == ('this', '.', 'module.name')
    assert s.rpartition('module') == ('this.module', '', 'name')
    assert s.rpartition('') == ('this.module.name', '', '')



# Generated at 2022-06-23 05:44:40.374910
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    assert AnsibleUnicode('abc') == u'abc'
    assert to_text(AnsibleUnicode('abc')) == 'abc'
    assert to_text(AnsibleUnicode(b'abc')) == 'abc'

    assert str(AnsibleUnicode('abc')) == 'abc'
    assert repr(AnsibleUnicode('abc')) == 'abc'

    assert hash(AnsibleUnicode('abc')) == hash(u'abc')

    assert len(AnsibleUnicode('abc')) == 3
    assert AnsibleUnicode('abc')[0] == 'a'

    assert AnsibleUnicode('abc') in [u'a', u'bc', u'def']
    assert AnsibleUnicode('abc') == 'abc'
    assert Ansible

# Generated at 2022-06-23 05:44:42.234058
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    assert AnsibleVaultEncryptedUnicode('abc').join(['abc', 'abc']) == 'abcabcabc'


# Generated at 2022-06-23 05:44:46.736049
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    avu = AnsibleVaultEncryptedUnicode(b'42')
    assert int(avu) == 42
    avu = AnsibleVaultEncryptedUnicode(b'0x42')
    assert int(avu, 16) == 0x42

if __name__ == '__main__':
    test_AnsibleVaultEncryptedUnicode___int__()

# vim: set et sw=4:

# Generated at 2022-06-23 05:44:51.035316
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test123')
    assert hash(AnsibleVaultEncryptedUnicode.from_plaintext('string', vault, 'test123')) == hash('string')


# Generated at 2022-06-23 05:44:59.588697
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    data = b'I aM $uper $3cure'

    import ansible.parsing.vault as vault
    vault_obj = vault.VaultLib('$ecret')
    cyphertext = vault_obj.encrypt(data)
    avu = AnsibleVaultEncryptedUnicode(cyphertext)
    avu.vault = vault_obj

    if avu.lower() != to_text(b'i am $uper $3cure'):
        raise AssertionError('lower test failed')

test_AnsibleVaultEncryptedUnicode_lower()



# Generated at 2022-06-23 05:45:12.375393
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    class MockVault:
        def encrypt(self, plaintext, secret=None):
            return '!vault |' + plaintext

        def decrypt(self, ciphertext, obj=None):
            return ciphertext[8:]

        def is_encrypted(self, text):
            return text.startswith('!vault |')

    plaintext_ucode = u'hello'
    secret = 'secret'
    vault = MockVault()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext_ucode, vault, secret)
    assert avu == plaintext_ucode
    assert avu.is_encrypted() is True


# Generated at 2022-06-23 05:45:19.902212
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():

    # Test strings
    # - string_a
    #   - special characters - \n, \t
    #   - numbers - 0-9
    #   - alphabets - a-z, A-Z
    #   - special characters - $, %
    #   - unicode string - '\u00ce'
    # - string_b
    #   - special characters - \n, \t
    #   - numbers - 0-9
    #   - alphabets - a-z, A-Z
    #   - special characters - $, %
    string_a = """\n\t1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ$%\u00ce"""


# Generated at 2022-06-23 05:45:22.758163
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    s = AnsibleVaultEncryptedUnicode(u'1+2j')
    assert s.__complex__() == 1+2j



# Generated at 2022-06-23 05:45:34.765222
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    '''
    Tests the AnsibleVaultEncryptedUnicode.replace method
    '''
    # 1. Simple test - replace string
    txt = "abcdabcdabcdabcd"
    txt_obj = AnsibleVaultEncryptedUnicode(txt)
    txt_obj = txt_obj.replace("a", "X")
    assert txt_obj == "XbcdXbcdXbcdXbcd", "replace string 1 failed"

    # 2. Simple test - replace string with no case
    txt = "abcdabcdabcdabcd"
    txt_obj = AnsibleVaultEncryptedUnicode(txt)
    txt_obj = txt_obj.replace("A", "X")

# Generated at 2022-06-23 05:45:40.266002
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib

    vault_lib = VaultLib([])
    vault_lib.secrets['id'] = b'password'

    vault_encrypted_unicode = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault_lib, 'password')
    assert vault_encrypted_unicode == 'foo'


# Generated at 2022-06-23 05:45:47.773100
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    # GIVEN
    # sequence of testcases
    testcases = [
        {
            'password': 'Mypass0',
            'seq': 'hello world',
            'expected': False
        },
        {
            'password': 'Mypass0',
            'seq': 'HELLO WORLD',
            'expected': True
        },
        {
            'password': 'Mypass0',
            'seq': 'HELLO WORLD',
            'expected': True
        },
        {
            'password': 'Mypass0',
            'seq': 'HELLO WORLD',
            'expected': True
        },
    ]


# Generated at 2022-06-23 05:45:57.092738
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    TESTS = [
        (u'\xf1', 'utf-8', '\xc3\xb1'),
        (u'\u0100', 'utf-8', '\xc4\x80')
    ]
    for plaintext, encoding, ciphertext in TESTS:
        vault = MockVault(ciphertext)
        avue = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, '')
        assert avue.encode(encoding) == ciphertext, "method encode failed for plaintext '%s' and encoding '%s'" % (plaintext, encoding)


# Generated at 2022-06-23 05:46:04.534725
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    # Arrange
    avu = AnsibleVaultEncryptedUnicode("test")
    avu._ciphertext = "test"
    avu.vault = None
    expected = "tset"

    # Act
    reversed = to_text(avu.__reversed__(), errors='surrogate_or_strict')
    actual = to_text(reversed, errors='surrogate_or_strict')

    # Assert
    assert expected == actual



# Generated at 2022-06-23 05:46:16.375537
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    from ansible.parsing.vault import VaultLib

    my_pass = 'secret'
    my_enc_text = b'$ANSIBLE_VAULT;1.1;AES256\n633131646232306565383336666366613239626535333930666663346262356162386136613136\n3636263323532323631343365376236663234626161393966646538666462343835393430363462\n6335626564376237346331646266653866353661366132346338623961666463623861\n'
    my_plain_text = '''---
my_var: my_value
other_var: other_value
'''


# Generated at 2022-06-23 05:46:26.490053
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    class _DummyVault:
        def __init__(self):
            pass

        class Secret(object):
            def __init__(self, secret):
                self._secret = secret

            def __eq__(self, other):
                return self._secret == other._secret

            def __ne__(self, other):
                return self._secret != other._secret

        def encrypt(self, data, secret=None):
            if secret is None:
                secret = self.Secret("")
            return data.encode("UTF-8")

        def decrypt(self, data, secret=None, obj=None):
            return data.decode("UTF-8")

    import string
    alphabet = string.ascii_lowercase + string.ascii_uppercase
    dummy_vault = _DummyVault()

# Generated at 2022-06-23 05:46:34.837210
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    class TestAVU(AnsibleVaultEncryptedUnicode):
        def __init__(self, ciphertext, vault):
            super(TestAVU, self).__init__(ciphertext)
            self.vault = vault

    class TestVault:
        def decrypt(self, ciphertext, obj=None):
            return '{0}'.format(ciphertext)
    test_avu = TestAVU('foo', TestVault())
    # when evaluating format
    # 'foo' will be text, but self will still be AnsibleVaultEncryptedUnicode
    assert test_avu.format() == 'foo'
    assert test_avu.format('bar') == 'foo'
    assert test_avu.format('bar', 'foo') == 'foo'

# Generated at 2022-06-23 05:46:41.233101
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    '''Test for method __reversed__ of class AnsibleVaultEncryptedUnicode'''
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml import AnsibleVaultError, BaseCLI

    vault = BaseCLI.setup_vault()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abcdefg', vault, 'secret')
    assert text_type(reversed(avu)) == 'gfedcba'


# Generated at 2022-06-23 05:46:51.600974
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    assert type(str(AnsibleVaultEncryptedUnicode(b'\xc0'))) == str
    assert type(str(AnsibleVaultEncryptedUnicode(b'\xc0'), 'utf-8')) == str
    assert type(str(AnsibleVaultEncryptedUnicode(b'\xc0'), 'utf-16')) == str
    assert type(str(AnsibleVaultEncryptedUnicode(b'\xc0'), 'utf-16-le')) == str
    assert type(str(AnsibleVaultEncryptedUnicode(b'\xc0'), 'utf-16-be')) == str
    assert type(str(AnsibleVaultEncryptedUnicode(b'\xc0'), errors='replace')) == str


# Generated at 2022-06-23 05:46:55.019961
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    avu = AnsibleVaultEncryptedUnicode("  a")
    assert avu < "b"
    assert not (avu < " ")


# Generated at 2022-06-23 05:47:02.122674
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    """
    Create a AnsibleVaultEncryptedUnicode object with non printable character for testing.
    isprintable function returns False for non printable characters
    """
    secret = 'hello_world'
    plaintext = u'hello\x00world'
    vault_obj = ansible.vault.VaultLib('password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault_obj, secret)
    assert avu.isprintable() == False


# Generated at 2022-06-23 05:47:09.982214
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    assert 1+2j == complex(AnsibleVaultEncryptedUnicode(u'1+2j'))
    assert 3+4j == complex(AnsibleVaultEncryptedUnicode(u'3+4j'))
    assert 5+6j == complex(AnsibleVaultEncryptedUnicode(u'5+6j'))
    assert 7+8j == complex(AnsibleVaultEncryptedUnicode(u'7+8j'))
    assert 9+10j == complex(AnsibleVaultEncryptedUnicode(u'9+10j'))
    assert 11+12j == complex(AnsibleVaultEncryptedUnicode(u'11+12j'))

# Generated at 2022-06-23 05:47:17.256682
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    test_str = AnsibleVaultEncryptedUnicode("")
    assert test_str.isdigit() == test_str.data.isdigit()
    test_str = AnsibleVaultEncryptedUnicode("01234567")
    assert test_str.isdigit() == test_str.data.isdigit()
    test_str = AnsibleVaultEncryptedUnicode("01234567ABC")
    assert test_str.isdigit() == test_str.data.isdigit()


# Generated at 2022-06-23 05:47:25.626672
# Unit test for method ljust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_ljust():
    myString = AnsibleVaultEncryptedUnicode("ABC")
    ljustString = myString.ljust(10,".")
    assert ljustString == "ABC....... "
    assert not ljustString.is_encrypted()
    assert ljustString[0].is_encrypted()
    assert ljustString[1].is_encrypted()
    assert ljustString[2].is_encrypted()
    assert not ljustString[3].is_encrypted()
    assert not ljustString[4].is_encrypted()
    assert not ljustString[5].is_encrypted()
    assert not ljustString[6].is_encrypted()
    assert not ljustString[7].is_encrypted()
    assert not ljustString[8].is_encrypted()
    assert not ljustString[9].is_encrypted()

# Generated at 2022-06-23 05:47:35.376027
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import os
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    from ansible.constants import DEFAULT_VAULT_PASSWORD_FILE

    tp = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'vault_pass')

# Generated at 2022-06-23 05:47:38.474853
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    ansible_vault_euc_test_instance = AnsibleVaultEncryptedUnicode('test')
    result = ansible_vault_euc_test_instance.rjust(5)
    assert result == ' test'



# Generated at 2022-06-23 05:47:50.972620
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    '''
    Test whether method __radd__ of class AnsibleVaultEncryptedUnicode works properly
    with __add__ method of AnsibleVaultEncryptedUnicode instance and string.
    This test does not test __radd__ with __add__ of string, since it is not supported
    by AnsibleVaultEncryptedUnicode, so it is undefined.
    The test uses __radd__ for concatenation.
    '''
    input = ['ansible', 'is']

# Generated at 2022-06-23 05:47:54.606379
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    key = 'key/dir/file.yml'
    value = 'value/dir/file.yml'
    AnsibleVaultEncryptedUnicode(key) + AnsibleVaultEncryptedUnicode(value)


# Generated at 2022-06-23 05:48:02.941619
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    p = 'h'
    v = 'v' * 4096
    r = 'h: 4096'

    avu = AnsibleVaultEncryptedUnicode(v)
    assert (avu.format_map(dict(p=p, v=v)) == r)
    avu = AnsibleVaultEncryptedUnicode(v)
    assert (avu.format_map(dict(p=[p], v=v)) == r)
    avu = AnsibleVaultEncryptedUnicode(v)
    assert (avu.format_map(dict(p=p, v=v, p1=p)) == r)



# Generated at 2022-06-23 05:48:06.130709
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    encryptedUnicode = "%s" % AnsibleVaultEncryptedUnicode("password")
    if encryptedUnicode != "password":
        raise AssertionError("AnsibleVaultEncryptedUnicode __mod__ method doesn't work")


# Generated at 2022-06-23 05:48:11.620377
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    a = AnsibleUnicode(u'123AABBCCDDEEFFGGHH11')
    b = AnsibleUnicode(u'aaa')
    c = AnsibleUnicode(u'bbb')

    d = AnsibleVaultEncryptedUnicode(u'123AABBCCDDEEFFGGHH11')
    e = AnsibleVaultEncryptedUnicode(u'aaa')
    f = AnsibleVaultEncryptedUnicode(u'bbb')
    print (a.replace(b, c))
    print (d.replace(e, f))

# Generated at 2022-06-23 05:48:22.208080
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    import ansible.parsing.vault
    from ansible.errors import AnsibleError
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # ISSUE:
    # This test fails when run after other tests, because it does not
    # cleanup the vault cache.
    vault_cache_dir = '/tmp/ansible_vault_test_cache'
    vault_id = '00000'
    secret = "abc"

# Generated at 2022-06-23 05:48:27.597154
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    aveu = AnsibleVaultEncryptedUnicode('HELLO', vault=None)
    assert aveu.lower() == 'hello'

yaml.add_multi_representer(AnsibleVaultEncryptedUnicode,
                           AnsibleVaultEncryptedUnicode.to_yaml)



# Generated at 2022-06-23 05:48:36.851374
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    import tempfile
    from ansible.parsing.vault import VaultLib

    # test unicode
    plaintext = u'\u043f\u0440\u0438\u0432\u0435\u0442'

    # Note: using temp vault password file
    with tempfile.NamedTemporaryFile() as vault_password_file:
        vault_password_file.write('vaultpassword')
        vault_password_file.flush()

        vault = VaultLib(filename=vault_password_file.name)

        # encrypt plaintext via Vault
        encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, vault_password_file.name)

        # decrypt encrypted value via Vault
        decrypted = encrypted.data

        # check that decrypted matches original plaintext value

# Generated at 2022-06-23 05:48:45.009420
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    from collections import UserString
    def ustr(x): return AnsibleVaultEncryptedUnicode(x)
    # intermix with UserString for complete coverage
    S = ustr('AAAABBBCCCDDD')
    S2 = UserString.MutableString('Python')
    T = ustr('xxyxx')
    T2 = UserString.MutableString('Pythox')
    U = ustr('yyyxy')
    U2 = UserString.MutableString('Pyoxox')
    # translation table can be UserString
    S.translate(T)
    S2.translate(T2)
    S.translate(T2)
    # translation table can be AnsibleVaultEncryptedUnicode
    S.translate(U)
    S2.translate(U2)

# Generated at 2022-06-23 05:48:53.496205
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(b'password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(b"hello", vault, b'password')
    assert avu.is_encrypted()

    vault = VaultLib(b'password')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(b"hello", vault, b'password')
    assert not avu.is_encrypted()


# Generated at 2022-06-23 05:48:57.523280
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    my_AnsibleVaultEncryptedUnicode = AnsibleVaultEncryptedUnicode("blah blah blah blah")
    # If rindex('') raises an error, we don't need to call assertTrue.
    # If it does not, then we have proven that it does not raise an error.
    try:
        my_AnsibleVaultEncryptedUnicode.rindex("")
    except ValueError:
        assert True


# Generated at 2022-06-23 05:49:08.940230
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    key = '123'
    ciphertext = b'gAAAAABc0V7Ae6z5Fg7lQF_ZO9QAc_GyEzllWmfy8ckOyCq-qqqmvz-89xVdblU6ZAZU6IiBR6N0MVAt0uL-5CC5z5F6iUmQrzZnh1gXfugG76jP4a4nrw=='
    av = AnsibleVaultEncryptedUnicode(ciphertext)
    av.vault = vaultlib.VaultLib('AES256')
    av.vault.decrypt(ciphertext, key)

# Generated at 2022-06-23 05:49:16.700382
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    assert AnsibleVaultEncryptedUnicode(u'hello').isspace() is False
    assert AnsibleVaultEncryptedUnicode(u'\t').isspace() is True
    assert AnsibleVaultEncryptedUnicode(u'\n').isspace() is True
    assert AnsibleVaultEncryptedUnicode(u'\f').isspace() is True
    assert AnsibleVaultEncryptedUnicode(u'\r').isspace() is True
    assert AnsibleVaultEncryptedUnicode(u'\v').isspace() is True

# Generated at 2022-06-23 05:49:21.510560
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    sequence = b'Hello World!'

    from ansible.parsing.vault import VaultLib
    vault_pass = 'secret'
    vault = VaultLib(vault_pass)

    uu = AnsibleVaultEncryptedUnicode(vault.encrypt(to_text(sequence)))
    uu.vault = vault

    assert repr(uu) == repr(to_text(sequence))



# Generated at 2022-06-23 05:49:27.462787
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    from ansible.parsing.yaml.vault import VaultLib
    vault_password = '12345678'
    vault = VaultLib(vault_password)
    ciphertext = vault.encrypt('\t')
    avue = AnsibleVaultEncryptedUnicode(ciphertext)
    avue.vault = vault
    assert avue.expandtabs(4) == '    '


# Generated at 2022-06-23 05:49:33.948468
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    from ansible.utils.vault import VaultLib
    vault_pass = 'mypass'
    vault_content = b'plaintext'
    vault = VaultLib(vault_pass)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(vault_content, vault, vault_pass)
    rev_avu = reversed(avu)
    assert avu[::-1] == rev_avu


# Generated at 2022-06-23 05:49:44.832855
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    msg = 'AnsibleVaultEncryptedUnicode object "AVEU object with value b\'AV Encrypted:2:9aIConRtTzdZfQ==\\n\'" not greater equal to string "AV Encrypted:2:9aIConRtTzdZfQ==\\n"'

# Generated at 2022-06-23 05:49:47.644479
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    am = AnsibleMapping()
    assert isinstance(am, dict)
    assert isinstance(am, AnsibleMapping)


# Generated at 2022-06-23 05:49:54.306702
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    import locale
    locale.setlocale(locale.LC_ALL, 'en_US.UTF-8') # For string.decimal test in Linux, otherwise it will raise UnicodeEncodeError: 'ascii' codec can't encode character u'\xab' in position 0: ordinal not in range(128)
    avu = AnsibleVaultEncryptedUnicode(u'123456789')
    assert avu.isdecimal()



# Generated at 2022-06-23 05:50:06.208555
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    assert AnsibleVaultEncryptedUnicode("abc").endswith("c")
    assert AnsibleVaultEncryptedUnicode("abc").endswith("b") == False
    assert AnsibleVaultEncryptedUnicode("abc").endswith("")
    assert AnsibleVaultEncryptedUnicode("abc").endswith("a") == False
    assert AnsibleVaultEncryptedUnicode("abc").endswith("abc")
    assert AnsibleVaultEncryptedUnicode("abc").endswith("bc")
    assert AnsibleVaultEncryptedUnicode("abc").endswith("abc", 0)
    assert AnsibleVaultEncryptedUnicode("abc").endswith("bc", 0, 2)

# Generated at 2022-06-23 05:50:16.146762
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    # These test cases cover the platform specific behavior of rstrip
    # This is why we have multiple test cases
    if _sys.platform in ['sunos5', 'linux2']:
        s = '\rtest\r'
        seq = AnsibleVaultEncryptedUnicode(s)
        assert s.rstrip() == seq.rstrip()
    elif _sys.platform == 'darwin':
        s = '\ntest\n'
        seq = AnsibleVaultEncryptedUnicode(s)
        assert s.rstrip() == seq.rstrip()
    elif _sys.platform == 'win32':
        s = '\r\ntest\r\n'
        seq = AnsibleVaultEncryptedUnicode(s)
        assert s.rstrip() == seq.rstrip()

# Generated at 2022-06-23 05:50:20.215724
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # test AnsibleVaultEncryptedUnicode
    va = AnsibleVaultEncryptedUnicode('secret', 'vault_secret')
    assert va.rindex('r') == 3

    # test AnsibleUnsafeText
    va = AnsibleUnsafeText('secret', 'vault_secret')
    assert va.rindex('r') == 3


# Unit tests for AnsibleVaultEncryptedUnicode
if __name__ == '__main__':
    test_AnsibleVaultEncryptedUnicode_rindex()

# Generated at 2022-06-23 05:50:27.391465
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    from ansible.parsing.vault import VaultLib

    # Test decryption, ensure no error
    s = AnsibleVaultEncryptedUnicode.from_plaintext("foo", VaultLib(), "test")
    i = int(s)

    # Test that the value is kept in int(s)
    assert i == 0


# Generated at 2022-06-23 05:50:37.050038
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    password = 'secret'
    plaintext = 'this is my secret'
    vault_id = 'test vault'
    vault_secret = 'test secret'
    vault_obj = VaultLib(password)
    encrypted_obj = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault_obj, vault_secret)
    encrypted_obj.vault = vault_obj

    before, sep, after = encrypted_obj.partition(vault_secret)
    assert 'this is my' == ansible_items.AnsibleVaultEncryptedUnicode.get_plaintext(before)
    assert 'secret' == ansible_items.AnsibleVaultEncryptedUnicode.get_plaintext(sep)
    assert '' == ansible_items.AnsibleVaultEncryptedUnicode.get_plain

# Generated at 2022-06-23 05:50:45.585037
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    assert AnsibleVaultEncryptedUnicode('  test\t').split() == ['test']
    assert AnsibleVaultEncryptedUnicode('  test\t').split(None) == ['test']
    assert AnsibleVaultEncryptedUnicode('  test\t').split(' ') == ['', '', 'test\t']
    assert AnsibleVaultEncryptedUnicode('  test\t').split(' ', 1) == ['', 'test\t']
    assert AnsibleVaultEncryptedUnicode('  test\t').split(' ', 2) == ['', '', 'test\t']
    assert AnsibleVaultEncryptedUnicode('  test\t').split('\t') == ['  test']

# Generated at 2022-06-23 05:50:55.664436
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    # Check if isprintable return True for all ASCII printable characters
    for i in range(32, 127):
        str_char = chr(i)
        avu_char = AnsibleVaultEncryptedUnicode(str_char)
        assert avu_char.isprintable()

    # Check if isprintable return False for all ASCII non-printable characters
    for i in range(0, 32):
        str_char = chr(i)
        avu_char = AnsibleVaultEncryptedUnicode(str_char)
        assert not avu_char.isprintable()



# Generated at 2022-06-23 05:51:07.613421
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():

    # Setup
    password = "mysecret"
    plaintext = "hello world"

# Generated at 2022-06-23 05:51:15.279507
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    assert AnsibleVaultEncryptedUnicode('abcabc').translate(str.maketrans('bca', 'bca')) == 'abcabc'
    assert AnsibleVaultEncryptedUnicode('abcabc').translate(str.maketrans('', '', 'a')) == 'bcbc'
    assert AnsibleVaultEncryptedUnicode('abcabc').translate(str.maketrans('abc', 'xyz')) == 'xyzxyz'
    assert AnsibleVaultEncryptedUnicode('abcabc').translate(str.maketrans('abc', 'xyz', 'a')) == 'xyzxyz'

# Generated at 2022-06-23 05:51:26.277123
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    e = AnsibleVaultEncryptedUnicode('')
    assert 0 == e.count('a')
    assert 0 == e.count('')

    e = AnsibleVaultEncryptedUnicode('a')
    assert 1 == e.count('')
    assert 1 == e.count('a')
    assert 0 == e.count('b')

    e = AnsibleVaultEncryptedUnicode('ab')
    assert 2 == e.count('')
    assert 1 == e.count('a')
    assert 1 == e.count('b')
    assert 0 == e.count('c')

    e = AnsibleVaultEncryptedUnicode('aba')
    assert 3 == e.count('')
    assert 2 == e.count('a')
    assert 1 == e.count('b')
    assert 0

# Generated at 2022-06-23 05:51:35.597762
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError

    try:
        vault = VaultLib([])
    except AnsibleVaultError as e:
        print("Failed to initialize ansible vault: %s" % e)
        sys.exit(1)

    # Note: The password is 'ansible'
    AVU = AnsibleVaultEncryptedUnicode.from_plaintext("this is a test", vault, secret='ansible')

    assert isinstance(AVU, AnsibleVaultEncryptedUnicode)
    assert AVU.count('is') == 2
    assert AVU.count('ansible') == 0

# Generated at 2022-06-23 05:51:41.121581
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    assert AnsibleVaultEncryptedUnicode('test').zfill(2) == 'test'
    assert AnsibleVaultEncryptedUnicode('test').zfill(4) == 'test'
    assert AnsibleVaultEncryptedUnicode('test').zfill(6) == '0test'
    assert AnsibleVaultEncryptedUnicode('test').zfill(8) == '00000test'


# Generated at 2022-06-23 05:51:45.609130
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    '''
    Tests the __mul__ method of the AnsibleVaultEncryptedUnicode class.
    '''
    avu = AnsibleVaultEncryptedUnicode('foo')
    assert avu * 3 == 'foofoofoo'


# Generated at 2022-06-23 05:51:55.176535
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib

    vaultfile = VaultLib(password='password')

    # test __eq__
    assert AnsibleVaultEncryptedUnicode.from_plaintext('test', vaultfile, 'password') == 'test'
    assert AnsibleVaultEncryptedUnicode.from_plaintext('test', vaultfile, 'password') == b'test'
    assert AnsibleVaultEncryptedUnicode.from_plaintext('test', vaultfile, 'password') == AnsibleVaultEncryptedUnicode.from_plaintext('test', vaultfile, 'password')

    # test __ne__
    assert AnsibleVaultEncryptedUnicode.from_plaintext('test', vaultfile, 'password') != 'test1'
    assert AnsibleVaultEncryptedUnicode.from_plaintext

# Generated at 2022-06-23 05:52:04.299841
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:52:09.471351
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    assert AnsibleVaultEncryptedUnicode('aB').istitle() == False
    assert AnsibleVaultEncryptedUnicode('AB').istitle()
    assert AnsibleVaultEncryptedUnicode('a1B').istitle() == False
    assert AnsibleVaultEncryptedUnicode('1B').istitle() == False
    assert AnsibleVaultEncryptedUnicode('B').istitle()
    assert AnsibleVaultEncryptedUnicode('A').istitle() == False



# Generated at 2022-06-23 05:52:12.100870
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    a = AnsibleVaultEncryptedUnicode('test')
    assert a * 3 == 'testtesttest'


# Generated at 2022-06-23 05:52:17.879755
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Initialize a AnsibleVaultEncryptedUnicode object
    data = "This is a string"
    avu = AnsibleVaultEncryptedUnicode(data)

    # Test when data has been decrypted
    avu_data = "This is another string"
    avu.data = avu_data
    assert avu.__gt__(data) == True

    # Test when data has not been decrypted
    assert avu.__gt__(data) == False


# Generated at 2022-06-23 05:52:18.782353
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    pass



# Generated at 2022-06-23 05:52:22.088861
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    e = AnsibleVaultEncryptedUnicode('ciphertext')
    assert len(e) == 11
