

# Generated at 2022-06-23 05:42:27.140149
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    required_hash = AnsibleVaultEncryptedUnicode(b'hello').__hash__()
    assert AnsibleVaultEncryptedUnicode(b'hello').__hash__() == required_hash, "hash values are not equal"

# Docstring for this class.
AnsibleVaultEncryptedUnicode.__doc__ = '''\
AnsibleVaultEncryptedUnicode(data) --> encrypted unicode object

AnsibleVaultEncryptedUnicode is a subclass of unicode that
can be marked for decryption before being used.  This class
is used so that the vault decryption can be done on a larger
block than just a single string.

'''


# Generated at 2022-06-23 05:42:33.261714
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    import unittest
    import vault
    from ansible.parsing.vault import VaultLib

    class TestAnsibleVaultEncryptedUnicode(unittest.TestCase):

        def test_lower(self):
            '''
            Lower case of an AnsibleVaultEncryptedUnicode behaves like that of a string.
            '''
            secret = 'test_test_test'
            plaintext = 'Hello World!'
            ciphertext = '$ANSIBLE_VAULT;1.1;AES256;\naXNhbGJhcmgyMDAwCg==\n4a4a35475f274355416d73724450486e62796b726e4a6c774b6d733d0a\n'

            vault = VaultLib(password=secret)
            avu

# Generated at 2022-06-23 05:42:40.294024
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():

    def avue(s):
        return AnsibleVaultEncryptedUnicode(s)

    assert(avue('a') >= avue('b'))
    assert(avue('a') >= 'b')
    assert(avue('b') >= 'a')
    assert('a' >= avue('b'))
    assert('b' >= avue('a'))


# Generated at 2022-06-23 05:42:42.820806
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    av = AnsibleVaultEncryptedUnicode("password\n")
    assert av.rstrip("\n") == "password"

# Generated at 2022-06-23 05:42:53.069730
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:42:59.628886
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    # No exception thrown
    ciphertext_bytes = b'foo'
    num_of_repetitions = 2
    avu = AnsibleVaultEncryptedUnicode(ciphertext_bytes)
    avu * num_of_repetitions
    del avu

    # Exception thrown
    ciphertext_bytes = b'foo'
    num_of_repetitions = b'bar'
    avu = AnsibleVaultEncryptedUnicode(ciphertext_bytes)
    try:
        avu * num_of_repetitions
    except TypeError:
        pass
    del avu
    return True


# Generated at 2022-06-23 05:43:04.890653
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    from ansible.parsing.vault import VaultLib
    a = AnsibleVaultEncryptedUnicode.from_plaintext(u'123', VaultLib('hello'), secret='hello')
    assert(a.isnumeric())
    b = AnsibleVaultEncryptedUnicode.from_plaintext(u'abc', VaultLib('hello'), secret='hello')
    assert(not b.isnumeric())

# Generated at 2022-06-23 05:43:13.111356
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    assert True
    # FIXME: This test isn't actually testing anything.
    assert True


yaml.add_representer(AnsibleVaultEncryptedUnicode,
                     lambda dumper, data: dumper.represent_scalar(u'!vault', to_text(data), style='|'))
yaml.add_constructor(u'!vault',
                     lambda loader, node: AnsibleVaultEncryptedUnicode(node.value))

# AnsibleVaultEncryptedUnicode.__doc__ = text_type.__doc__



# Generated at 2022-06-23 05:43:19.401140
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    test_list = ['A', 'B', 'C']
    l = AnsibleSequence(test_list)
    for i in l:
        assert i == test_list[i]
    assert l.ansible_pos == None
    l.ansible_pos = ("test.yml", 12, 13)
    assert l.ansible_pos == ("test.yml", 12, 13)


# Generated at 2022-06-23 05:43:29.065920
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    # These cases rely on the __eq__ method of the class AnsibleVaultEncryptedUnicode
    test_value_1 = AnsibleVaultEncryptedUnicode('test')
    test_value_2 = 'test'
    test_value_3 = AnsibleVaultEncryptedUnicode('test')

    test_data_1 = ["something", test_value_1, "else"]
    test_data_2 = ["something", test_value_2, "else"]
    test_data_3 = ["something", test_value_3, "else"]
    separator = ", "
    expected_result = 'something, test, else'

    assert test_value_1.join(test_data_1) == expected_result, 'test_value_1.join(test_data_1) == expected_result'

# Generated at 2022-06-23 05:43:36.853694
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    utf8_a_tilde = b'\xc3\xa1'
    ciphertext = utf8_a_tilde + b'\x00\x00'

    avu = AnsibleVaultEncryptedUnicode(ciphertext)

    s = avu.expandtabs(tabsize=1)
    assert s[0:2] == b'a\t'

    avu.vault = None
    s = avu.expandtabs(tabsize=1)
    assert s[0:2] == b'\xc3\xa1\t'


# Generated at 2022-06-23 05:43:46.187478
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    from ansible.parsing.vault import VaultLib
    from os import environ
    try:
        ansible_vault_password_file = environ['ANSIBLE_VAULT_PASSWORD_FILE']
    except KeyError:
        sys.exit("environment variable ANSIBLE_VAULT_PASSWORD_FILE not set")
    vault = VaultLib(password_files=[ansible_vault_password_file])
    # This is the value of the first line of the file 'test-hosts'

# Generated at 2022-06-23 05:43:55.799205
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    ciphertext = "AQAAAAEAACmW58Ld73iKjnLm6DZFpfZiRH9Xn1jEtz6L0B8KjBdUuw0UcZvlQvjKW/////5UElVgI5KjOvV8WYcdBLQI3qrODOZjvV7WzIa9XV7OcjJAVe8VE="
    secret = "a_secret"
    vault = vaultlib.VaultLib(secret=secret)
    string = AnsibleVaultEncryptedUnicode.from_plaintext(u'password', vault, secret)
    result = string.rfind(u'word')
    assert result == 6
    result = string.rfind(u'Word')

# Generated at 2022-06-23 05:44:05.270035
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    if sys.version_info[0] == 2:
        t1 = AnsibleVaultEncryptedUnicode('{0} is {1:d}'.format('one', 1))
        assert t1 == u'one is 1'
        t2 = AnsibleVaultEncryptedUnicode('{} is {}'.format('one', 1))
        assert t2 == u'one is 1'
    else:
        t1 = AnsibleVaultEncryptedUnicode('{0} is {1:d}'.format('one', 1))
        assert t1 == 'one is 1'
        t2 = AnsibleVaultEncryptedUnicode('{} is {}'.format('one', 1))
        assert t2 == 'one is 1'



# Generated at 2022-06-23 05:44:15.589481
# Unit test for method swapcase of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_swapcase():
    from unittest import TestCase

    class TestAnsibleVaultEncryptedUnicode_swapcase(TestCase):
        def test_swapcase(self):
            obj = AnsibleVaultEncryptedUnicode('This String')
            expected = 'tHIS sTRING'
            result = obj.swapcase()
            self.assertEqual(result, expected)

    # Run the unittest
    unittest.main(
        module='__main__', defaultTest='test_AnsibleVaultEncryptedUnicode_swapcase', verbosity=2)


# Generated at 2022-06-23 05:44:24.429959
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    from ansible.parsing.vault import VaultLib
    secret = 'dummy password'
    vault = VaultLib(password=secret)

    yaml_str = 'foo: secret value'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(yaml_str, vault, secret)

    unencrypted = vault.decrypt(avu._ciphertext)
    assert(avu[1] == unencrypted[1])
    assert(avu[-1] == unencrypted[-1])

# Generated at 2022-06-23 05:44:31.921396
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():

    # Test successful positive test case for function isidentifier
    # Test isidentifier for valid identifier string
    ansible_vault_encrypted_unicode_successful_positive_case = AnsibleVaultEncryptedUnicode.from_plaintext(
        'ansible'
        , object
        , object
    )
    if not ansible_vault_encrypted_unicode_successful_positive_case.isidentifier():
        raise AssertionError()

    # Test unsuccessful positive test case for function isidentifier
    # Test isidentifier for invalid identifier string
    ansible_vault_encrypted_unicode_unsuccessful_positive_case = AnsibleVaultEncryptedUnicode.from_plaintext(
        'Ansible'
        , object
        , object
    )

# Generated at 2022-06-23 05:44:42.200413
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    # Classic use of AnsibleVaultEncryptedUnicode.translate
    func = AnsibleVaultEncryptedUnicode("This is a test string").translate
    assert func(None, ' ') == 'Thisisateststring'
    assert func(None, ' '*10) == 'Thisisateststring'

    # Classic use of str.translate
    func = str("This is a test string").translate
    assert func(None, ' ') == 'Thisisateststring'
    assert func(None, ' '*10) == 'Thisisateststring'

    # Classic use with unicode string
    func = str("This is a test string").translate
    assert func(None, ' ') == 'Thisisateststring'

# Generated at 2022-06-23 05:44:49.714821
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    # ASCII string
    assert not AnsibleVaultEncryptedUnicode(b'abc').isprintable()
    # Unicode string
    assert not AnsibleVaultEncryptedUnicode(b'\xc3\x89ric').isprintable()
    # String contains Unicode character
    assert not AnsibleVaultEncryptedUnicode(b'Eric\x80').isprintable()
    # Empty string
    assert not AnsibleVaultEncryptedUnicode(b'').isprintable()
    # None
    assert not AnsibleVaultEncryptedUnicode(None).isprintable()
    # Empty list
    assert not AnsibleVaultEncryptedUnicode([]).isprintable()
    # Empty dictionary
    assert not AnsibleVaultEncryptedUnicode({}).isprintable()
    # Integer

# Generated at 2022-06-23 05:45:01.343036
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    # Test with a sub of type AnsibleVaultEncryptedUnicode
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('This is a test', 'vault', 'secret')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('test', 'vault', 'secret')
    rfind = avu.rfind(avu2)
    assert rfind == 8, "Failed to find sub AnsibleVaultEncryptedUnicode"
    # Test with a sub of type str
    rfind = avu.rfind('test')
    assert rfind == 8, "Failed to find sub str"
    # Test with a sub of type ansible_unicode
    rfind = avu.rfind(u'test')

# Generated at 2022-06-23 05:45:09.204757
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    plaintext = 'foo'
    vault = vaultlib.VaultLib('ansible')
    a = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, 'secret')
    assert a.data == plaintext
    assert a.__mod__('bar') == 'foo'



# Generated at 2022-06-23 05:45:16.786636
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    # Test construction of a AnsibleUnicode from a unicode string.
    u = u'a unicode \u018e string \xf1'
    au = AnsibleUnicode(u)
    assert isinstance(au, text_type)
    assert isinstance(au, AnsibleBaseYAMLObject)
    assert au == u
    if _sys.version_info[0] == 2:
        assert isinstance(au, unicode)  # noqa: F821 pylint: disable=undefined-variable
        assert isinstance(au.decode('utf-8'), text_type)
    else:
        assert isinstance(au, str)


# Generated at 2022-06-23 05:45:28.155181
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    from ansible.utils.vault import VaultLib
    from ansible.errors import AnsibleError

    # Tests for constructors

    # invalid vault
    try:
        AnsibleVaultEncryptedUnicode('ciphertext', None)
        assert False
    except AnsibleVaultError as e:
        assert to_native(e) == 'Invalid vault object None provided'

    # invalid ciphertext
    try:
        AnsibleVaultEncryptedUnicode([], VaultLib())
        assert False
    except AnsibleVaultError as e:
        assert to_native(e) == 'Ciphertext must be a string, got list'

    # valid ciphertext

    vault = VaultLib()
    ciphertext = b"ciphertext"
    avu = AnsibleVaultEncryptedUnicode(ciphertext, vault)
   

# Generated at 2022-06-23 05:45:38.072636
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    u = AnsibleVaultEncryptedUnicode('\u00A0')
    assert not u.isspace()
    u = AnsibleVaultEncryptedUnicode('\u0009')
    assert u.isspace()
    u = AnsibleVaultEncryptedUnicode('\u000A')
    assert u.isspace()
    u = AnsibleVaultEncryptedUnicode('\u000B')
    assert u.isspace()
    u = AnsibleVaultEncryptedUnicode('\u000C')
    assert u.isspace()
    u = AnsibleVaultEncryptedUnicode('\u000D')
    assert u.isspace()
    u = AnsibleVaultEncryptedUnicode('\u0020')
    assert u.isspace()
    u = AnsibleVaultEnc

# Generated at 2022-06-23 05:45:46.597550
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test correct behavior if vault is not set
    avu = AnsibleVaultEncryptedUnicode('test')
    assert(avu == 'test') is False
    assert(avu != 'test') is True
    assert(avu != 'test2') is True

    # Test correct behavior if vault is set
    from ansible.parsing.vault import VaultLib
    avu.vault = VaultLib()
    assert(avu == 'test') is True
    assert(avu != 'test') is False
    assert(avu != 'test2') is True



# Generated at 2022-06-23 05:45:59.000967
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    uni_str = AnsibleVaultEncryptedUnicode(u'abcd')
    uni_str.data = 'abcd'
    assert uni_str.data == u'abcd'
    assert uni_str.replace('a', 'A', 1) == u'Abcd'
    assert uni_str.replace('a', 'A', -1) == u'Abcd'
    assert uni_str.replace('a', 'A', 100) == u'Abcd'
    assert uni_str.replace('a', 'A', 0) == u'abcd'
    assert uni_str.replace('xyz', 'A', 0) == u'abcd'
    assert uni_str.replace(u'x', u'A', 0) == u'abcd'
    assert uni_str

# Generated at 2022-06-23 05:46:04.258054
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('foobar', AnsibleVaultLib.load(), 'secret')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('bar', AnsibleVaultLib.load(), 'secret')
    avu_replaced = avu.replace('foo', 'bar')
    assert avu2 == avu_replaced


# Generated at 2022-06-23 05:46:16.212725
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():

    # Create an instance of AnsibleMapping
    x = AnsibleMapping()

    # Test that we are able to set a value
    x['a'] = 1

    # Test that setting a value is persistent
    assert x['a'] == 1

    # Test that we are able to get a different value
    assert x['b'] is None

    # Test that we are able to set a value via an assignment
    x.b = 2

    # Test that setting a value is persistent
    assert x['b'] == 2

    # Test that we are able to get a different value that is None
    assert x['c'] is None

    # Test that the instance is a dictionary
    assert isinstance(x, dict)

    # Test that the instance is an AnsibleMapping
    assert isinstance(x, AnsibleMapping)


# Generated at 2022-06-23 05:46:23.813674
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    '''Test isidentifier from class AnsibleVaultEncryptedUnicode.
    '''

    # List of possible inputs for unicode characters

# Generated at 2022-06-23 05:46:35.620433
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    # test for each possible combination of char_set or None in argument
    # and char_set or None as last characters of string

    test_string = '123456789'

    uv = AnsibleVaultEncryptedUnicode(test_string)

    # test with no argument, expect no change
    assert uv.rstrip() == test_string

    # test with empty char_set, expect no change
    assert uv.rstrip('') == test_string

    # test with all characters in char_set, expect empty string
    assert uv.rstrip(test_string) == ''

    # test with characters not in string, expect no change
    assert uv.rstrip('abcde') == test_string

    # test characters in string but not last, expect no change
    assert uv.rstrip('345') == test_

# Generated at 2022-06-23 05:46:41.607382
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    import unittest
    class AnsibleVaultEncryptedUnicodeTestCase(unittest.TestCase):
        def test_rjust(self):
            avue = AnsibleVaultEncryptedUnicode(u'abc')
            self.assertEqual(avue.rjust(10), to_text('       abc'))
    unittest.main()



# Generated at 2022-06-23 05:46:51.694497
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:46:57.702745
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    avu = AnsibleVaultEncryptedUnicode(to_bytes('data'))
    result = avu.join([avu, avu, avu])
    assert result == 'datadatadata'
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Test for method __str__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:47:02.778006
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    avu1 = AnsibleVaultEncryptedUnicode('a')
    avu2 = AnsibleVaultEncryptedUnicode('b')
    joined = AnsibleVaultEncryptedUnicode.join([avu1, avu2])
    assert joined.data == 'ab'



# Generated at 2022-06-23 05:47:05.145133
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    am = AnsibleMapping()
    assert isinstance(am, dict)
    assert isinstance(am, AnsibleBaseYAMLObject)


# Generated at 2022-06-23 05:47:16.389146
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    """_data_source must be a string."""
    try:
        yaml_obj = AnsibleBaseYAMLObject()
    except TypeError:
        pass
    else:
        raise AssertionError('_data_source must be a string.')

    """_line_number must be an integer."""
    try:
        yaml_obj = AnsibleBaseYAMLObject(1)
    except TypeError:
        pass
    else:
        raise AssertionError('_line_number must be an integer.')

    """_column_number must be an integer."""
    try:
        yaml_obj = AnsibleBaseYAMLObject('/etc/passwd', 42)
    except TypeError:
        pass
    else:
        raise AssertionError('_column_number must be an integer.')



# Generated at 2022-06-23 05:47:27.408346
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    if not AnsibleVaultEncryptedUnicode:
        raise SkipTest

    from unittest import skipIf
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # can we read the secret from the environment?
    # if not we skip this test
    if not VaultSecret('password'):
        raise SkipTest

    # if we can not decrypt the sample encrypted string we skip this test
    v = VaultLib('password')

# Generated at 2022-06-23 05:47:33.561128
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    assert AnsibleVaultEncryptedUnicode(u' ').isspace()
    assert AnsibleVaultEncryptedUnicode(u'\t').isspace()
    assert AnsibleVaultEncryptedUnicode(u'\n').isspace()
    assert AnsibleVaultEncryptedUnicode(u'\x0c').isspace()
    assert AnsibleVaultEncryptedUnicode(u'\x0b').isspace()



# Generated at 2022-06-23 05:47:40.602575
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    '''
    Function used by ansible/test/units/lib/ansible_test/_data/test_module_utils_basic.py
    '''
    for test_string in ["ascii", "ASCII", "ascii_only"]:
        assert AnsibleVaultEncryptedUnicode(test_string).isascii()
    for test_string in ["\u037e", "ξ", "Ϊ", "λ", "с"]:
        assert not AnsibleVaultEncryptedUnicode(test_string).isascii()



# Generated at 2022-06-23 05:47:52.861468
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    from ansible.parsing.vault import VaultLib

    vault_pass = "foobaz"
    vault = VaultLib(vault_pass)

    ansible_vault = AnsibleVaultEncryptedUnicode.from_plaintext("abc", vault, vault_pass)
    assert ansible_vault >= "abc"
    assert not ansible_vault >= "def"
    ansible_vault2 = AnsibleVaultEncryptedUnicode.from_plaintext("abc", vault, vault_pass)
    assert ansible_vault >= ansible_vault2
    assert ansible_vault2 >= ansible_vault
    ansible_vault2.data = "def"
    assert not ansible_vault >= ansible_vault2
    assert ansible_vault2 >= ansible_v

# Generated at 2022-06-23 05:48:01.557803
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    print("")
    print("Test AnsibleVaultEncryptedUnicode class method isalpha")
    from ansible.parsing.vault import VaultLib
    import os
    import getpass

    # use a vault password that is the same for local or test environements to
    # avoid creating a new vault file for every test
    # the vault file itself will be deleted by the test
    vault_pass = 'ansible'
    filename = os.path.join('/tmp', 'ansible_test_vault.yml')
    print("  Vault password: %s" % vault_pass)
    print("  Vault file: %s" % filename)
    print("  Password should be 'foo'")
    plaintext = 'foo'

    vault = VaultLib(vault_password_file=filename)
    sequence = 'foo'

# Generated at 2022-06-23 05:48:07.854453
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    '''
    Tests:
        method __rmod__ of class AnsibleVaultEncryptedUnicode

    Expected results:
        method __rmod__ of class AnsibleVaultEncryptedUnicode should
        return the string representation of the object.

    '''
    print('Testing method __rmod__ of class AnsibleVaultEncryptedUnicode...')

    _object = AnsibleVaultEncryptedUnicode.from_plaintext('plaintext', None, 'secret')
    assert str(_object) == 'plaintext'
    print('Test passed')



# Generated at 2022-06-23 05:48:10.337098
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    if _sys.version_info < (2, 7):
        return False
    else:
        return True


# Generated at 2022-06-23 05:48:17.386713
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    # Success case
    from ansible.parsing.vault import VaultLib
    test_text = 'Hello World'
    vault_pass = 'MySecretPassword'
    vault = VaultLib(vault_pass)
    avueu = AnsibleVaultEncryptedUnicode.from_plaintext(test_text, vault, vault_pass)
    assert complex(avueu) == complex(test_text)



# Generated at 2022-06-23 05:48:19.652729
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    assert isinstance(AnsibleVaultEncryptedUnicode(b'ABC'), AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-23 05:48:31.549007
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    """
    Testing the following:
    find(self, sub, start=0, end=_sys.maxsize)
    """
    # Ensure that find always returns -1 if self.data is empty

# Generated at 2022-06-23 05:48:36.661097
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    true_tests = [u"U", u"U."]
    false_tests = [u"U.", u"U,"]
    for test in true_tests:
        assert AnsibleVaultEncryptedUnicode(test).isupper() == True
    for test in false_tests:
        assert AnsibleVaultEncryptedUnicode(test).isupper() == False


# Generated at 2022-06-23 05:48:41.965625
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    data = u"hello world"
    try:
        # Python 2
        assert(repr(AnsibleVaultEncryptedUnicode(data).__unicode__()) == "u'hello world'")
    except:
        # Python 3
        assert(repr(AnsibleVaultEncryptedUnicode(data).__unicode__()) == "'hello world'")


# Generated at 2022-06-23 05:48:47.495543
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    expected_result = complex(1j)
    encrypted_value = AnsibleVaultEncryptedUnicode.from_plaintext(str(expected_result), None, None)
    result = complex(encrypted_value)
    assert result == expected_result



# Generated at 2022-06-23 05:48:57.655602
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    printable_chars = string.ascii_letters + string.digits + string.punctuation + ' '
    not_printable_chars = '\n\r'
    # let's test with a random string of ascii characters
    random_string = ''.join(random.choice(string.ascii_letters) for _ in range(30))
    # test with a string containing printable and not printable characters
    test_data = random_string + not_printable_chars + random_string
    avu_test = AnsibleVaultEncryptedUnicode(test_data)
    assert not avu_test.isprintable()
    # test with a string containing only printable characters
    test_data = random_string + printable_chars + random_string
    avu_test = AnsibleV

# Generated at 2022-06-23 05:49:01.188017
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    asc = AnsibleSequence([1, 2])
    assert asc[0] == 1
    assert asc[1] == 2
    assert len(asc) == 2


# Generated at 2022-06-23 05:49:11.068633
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    #     def __gt__(self, string):
    #         if isinstance(string, AnsibleVaultEncryptedUnicode):
    #             return self.data > string.data
    #         return self.data > string

    #     if isinstance(string, AnsibleVaultEncryptedUnicode) -> return self.data > string.data
    #     if isinstance(string, AnsibleVaultEncryptedUnicode) -> return self.data > string
    #     if isinstance(string, AnsibleVaultEncryptedUnicode) -> return self.data > string

    i1 = AnsibleVaultEncryptedUnicode('abc')
    i2 = AnsibleVaultEncryptedUnicode('ABC')

    assert i1 > 'ABC'
    assert i2 > 'abc'

    assert i1 > i2
   

# Generated at 2022-06-23 05:49:15.453157
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password='test')
    msg = 'hello world!'
    ob = AnsibleVaultEncryptedUnicode.from_plaintext(msg, vault, 'test')
    assert ob.lower() == msg.lower()


# Generated at 2022-06-23 05:49:18.088954
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    s = AnsibleVaultEncryptedUnicode(u'aBc')
    assert s.upper() == u'ABC'



# Generated at 2022-06-23 05:49:25.533481
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    '''
    usage:

    >>> from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    >>>
    >>> encrypted_text = AnsibleVaultEncryptedUnicode('abc')
    >>> encrypted_text.__getslice__(1, 2)
    'b'
    >>> encrypted_text.__getslice__(1, 1)
    ''
    '''
    pass



# Generated at 2022-06-23 05:49:30.578410
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    test = 'test'
    pwd = 'test'
    vault = VaultLib(pwd)
    v = AnsibleVaultEncryptedUnicode.from_plaintext(test, vault, pwd)
    assert v.center(10) == '   test   '


# Generated at 2022-06-23 05:49:37.730397
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():

    mystr  = AnsibleVaultEncryptedUnicode.from_plaintext('plaintext')
    mystr2 = AnsibleVaultEncryptedUnicode(mystr.data)
    assert mystr == mystr2
    mystr3 = AnsibleVaultEncryptedUnicode('%s' % mystr.data)
    assert mystr == mystr3
    mystr4 = AnsibleVaultEncryptedUnicode(mystr)
    assert mystr == mystr4
    mystr5 = AnsibleVaultEncryptedUnicode('%s' % mystr)
    assert mystr == mystr5

    with pytest.raises(AssertionError):
        AnsibleVaultEncryptedUnicode.from_plaintext('plaintext', vault=None)


# Generated at 2022-06-23 05:49:46.627492
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    test_strings = ["I am isprintable",
                    "Iamnotis\x1fprintable",
                    "Iamnotis\nprintable",
                    "Iamnotis\rprintable",
                    "Iamnotis\x0cprintable",
                    "Iamnotis\tprintable",
                    "Iamnotis\x0bprintable",
                    "I am isprintable",
                    ]

    # This is a string generator with all cases of
    # printable and unprintable characters.
    # See https://docs.python.org/3.5/library/string.html
    # and http://hg.python.org/cpython/file/3.5/Lib/string.py#l121-l181

# Generated at 2022-06-23 05:49:57.324651
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    """
    testing method isdecimal of class AnsibleVaultEncryptedUnicode
    """
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor

    # Create Test Data
    # B.py3_0 : object is neither digit nor decimal
    # B.py3_1 : object is digit but not decimal
    # B.py3_2 : object is decimal but not digit
    # B.py3_3 : object is both decimal and digit
    B_py3_0 = 'a'
    B_py3_1 = '5'
    B_py3_2 = '\u00B2'
    B_py3_3 = '5'
    # B.py2_0 : object is neither digit nor decimal
    # B.py2_

# Generated at 2022-06-23 05:50:06.912146
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    from ansible.parsing import vaultlib
    testvault = vaultlib.VaultLib('password')

    obj = AnsibleVaultEncryptedUnicode('someencrypteddata')
    obj.vault = testvault
    assert(obj.vault == testvault)
    assert(obj.data == u"someencrypteddata")

    obj = AnsibleVaultEncryptedUnicode(u"anotherencrypteddata")
    obj.vault = testvault
    assert(obj.vault == testvault)
    assert(obj.data == u"anotherencrypteddata")


# Generated at 2022-06-23 05:50:16.719569
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    # On Python 2.x, rstrip has a `chars` parameter, while on Python 3.x it is called `chars`
    chars = getattr(string, 'whitespace', string.whitespace)

    def check_rstrip(data, chars, expected_result):
        # type: (AnsibleVaultEncryptedUnicode, str, str) -> None

        # On Python 3.x, str.rstrip expects a unicode string,
        # while on Python 2.x, str.rstrip expects a byte string
        expected_result = expected_result.encode('utf-8') if _sys.version_info[0] == 2 else expected_result

        vault = make_test_vault()

# Generated at 2022-06-23 05:50:19.559006
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    x_0 = AnsibleVaultEncryptedUnicode('abc')
    x_1 = x_0.strip()
    x_2 = x_1.strip('a')
    x_3 = x_2.strip('b')
    x_4 = x_3.strip('c')

    assert x_0 == x_1 == x_2 == 'abc'
    assert x_3 == x_4 == ''


# Generated at 2022-06-23 05:50:24.616294
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    avu = AnsibleVaultEncryptedUnicode('{5, 3}')
    assert complex(avu) == complex(5, 3)


# Generated at 2022-06-23 05:50:26.668235
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    test_vault = AnsibleVaultEncryptedUnicode.from_plaintext(
        'abcdefghijklmnopqrstuvwxyz',
        vault=None,
        secret=None
    )
    assert test_vault[5:10] == 'fghij'


# Generated at 2022-06-23 05:50:37.512257
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    """Test if method isidentifier of class AnsibleVaultEncryptedUnicode is working
    """
    simple_str = "simple"
    u_str = "u_str"
    u_str_upper = "U_STR"
    u_str_lower = "u_str"
    U_STR_lower = "U_STR"
    U_STR = "U_STR"
    u_1234 = "u_1234"
    U_1234 = "U_1234"
    _1234 = "_1234"
    u_1234_ = "u_1234_"
    u_ = "u_"
    u_U = "u_U"
    _simple_str_ = "_simple_str_"
    _simple_str = "_simple_str"

# Generated at 2022-06-23 05:50:44.535881
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    from ansible.vault import VaultLib
    vault = VaultLib('password')
    vault_text = AnsibleVaultEncryptedUnicode.from_plaintext('test_string', vault, 'password')
    assert vault_text >= 'test_string'
    assert vault_text >= vault_text
    assert vault_text >= AnsibleVaultEncryptedUnicode.from_plaintext('test_string', vault, 'password')
    assert vault_text >= AnsibleVaultEncryptedUnicode.from_plaintext('test_stronger', vault, 'password')
    assert vault_text >= 'test_stronger' is False


# Generated at 2022-06-23 05:50:56.200759
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    b = yaml.load(b'foo: !vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          64336534633637376162303662346366633239656133343730363762396263373365326365653530\n          646264460a633234393661333863353639376231626331653834383632623464356536643039656134\n          660a', Loader=yaml.BaseLoader)

# Generated at 2022-06-23 05:51:01.288477
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    '''test method AnsibleVaultEncryptedUnicode.__gt__(self=AnsibleVaultEncryptedUnicode('123'), string=AnsibleVaultEncryptedUnicode('12'))'''
    obj = AnsibleVaultEncryptedUnicode('123')
    string = AnsibleVaultEncryptedUnicode('12')
    return obj.__gt__(string)


# Generated at 2022-06-23 05:51:06.177065
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    unicode_object = AnsibleVaultEncryptedUnicode('hello\nworld\r\nHow are you\rI am fine')
    assert unicode_object.splitlines() == ['hello', 'world', 'How are you', 'I am fine']
    assert unicode_object.splitlines(keepends=True) == ['hello\n', 'world\r\n', 'How are you\r', 'I am fine']


# Generated at 2022-06-23 05:51:09.237302
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    data = AnsibleVaultEncryptedUnicode("8")
    assert data.isdecimal() is True
    data = AnsibleVaultEncryptedUnicode("8.0")
    assert data.isdecimal() is False

# Generated at 2022-06-23 05:51:11.493222
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    assert AnsibleVaultEncryptedUnicode('helloworld').isalnum() == True
    assert AnsibleVaultEncryptedUnicode('hello world').isalnum() == False


# Generated at 2022-06-23 05:51:19.485116
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    check if __ne__ of AnsibleVaultEncryptedUnicode is working properly
    """
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnicode

    vault_secret = "123456"
    vault_password = VaultLib()
    vault_password.secrets = [vault_secret]

    # encrypt string "string" with vault_secret, we will use it below
    encrypted_string = AnsibleUnicode("string")
    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext(encrypted_string, vault_password, vault_secret)

    # test if a != b
    a = AnsibleVaultEncryptedUnicode("test")
    b = Ansible

# Generated at 2022-06-23 05:51:21.910681
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    avu = AnsibleVaultEncryptedUnicode('mytext')
    assert avu.lower() == 'mytext'


# Generated at 2022-06-23 05:51:32.923638
# Unit test for constructor of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:51:43.596394
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    import ansible.vars.unsafe_proxy
    from ansible.parsing.vault import VaultLib
    from ansible import constants as C
    vault_password = 'password'
    vault_secret = VaultLib([vault_password])().decrypt(vault_password)
    vault_lib = VaultLib([vault_password])
    my_string = 'to encrypt'.encode('utf-8')

# Generated at 2022-06-23 05:51:53.452320
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
  import collections
  import copy
  import vault

  vault = vault.VaultLib('test')
  s = '!vault |' + vault.encrypt('test')
  avue = AnsibleVaultEncryptedUnicode.from_yaml(collections.OrderedDict(
          yaml.safe_load(s)))
  avue.vault = vault
  assert(avue != 'test')

  s = '!vault |' + vault.encrypt('test')
  avue2 = AnsibleVaultEncryptedUnicode.from_yaml(collections.OrderedDict(
          yaml.safe_load(s)))
  avue2.vault = vault

  avue3 = copy.deepcopy(avue)
  assert(avue != avue3)


# Generated at 2022-06-23 05:51:55.566101
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode('hello')
    assert avu == 'hello'
    assert avu != 'bye'


# Generated at 2022-06-23 05:52:06.316711
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test for correct concatenation of strings
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode("A")
    assert ansible_vault_encrypted_unicode + "B" == "AB"
    assert ansible_vault_encrypted_unicode.data + "B" == "AB"

    # Test for correct concatenation of AnsibleVaultEncryptedUnicodes
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode("A")
    ansible_vault_encrypted_unicode2 = AnsibleVaultEncryptedUnicode("B")
    assert ansible_vault_encrypted_unicode + ansible_vault_encrypted_unicode2 == "AB"

# Generated at 2022-06-23 05:52:17.001092
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    # Creating a mock vault object
    class mockVault:
        def __init__(self):
            self.test = None

        def encrypt(self, data, secret=None):
            encrypted = data.encode('base64')
            if not self.test:
                return encrypted
            else:
                return encrypted + 's'

        def is_encrypted(self, data, secret=None):
            if data.endswith('s'):
                return True
            return False

    vault = mockVault()

    # Creating a vault_enc object.
    vault_enc = AnsibleVaultEncryptedUnicode.from_plaintext('ansible', vault, 'secret')

    # Testing with a mock vault
    assert not vault_enc.is_encrypted()
    vault

# Generated at 2022-06-23 05:52:26.434985
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    # Test the method of AnsibleVaultEncryptedUnicode
    # with the specified values
    avu1 = AnsibleVaultEncryptedUnicode('VaultEncryptedUnicode string')
    avu2 = AnsibleVaultEncryptedUnicode('VaultEncryptedUnicode')
    assert avu1.partition('VaultEncryptedUnicode') == ('', 'VaultEncryptedUnicode', ' string')
    assert avu2.partition('VaultEncryptedUnicode') == ('', 'VaultEncryptedUnicode', '')

