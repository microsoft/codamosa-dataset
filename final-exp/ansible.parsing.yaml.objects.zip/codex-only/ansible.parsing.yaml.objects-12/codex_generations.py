

# Generated at 2022-06-23 05:42:29.256100
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultSecret

    # create dummy vault
    vault = VaultLib(VaultSecret('123'))

    # create dummy data
    data = 'Hello world'

    envelope = AnsibleVaultEncryptedUnicode.from_plaintext(data, vault, vault.secrets[0])

    # test __gt__
    assert envelope > data


# Generated at 2022-06-23 05:42:34.504220
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    print("() Test AnsibleVaultEncryptedUnicode is_encrypted()")

    from ansible.parsing.vault import VaultLib
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("This is a private message", VaultLib(), u"ansible")

    assert avu.is_encrypted()

    print("() Test AnsibleVaultEncryptedUnicode is_encrypted() OK")


# Generated at 2022-06-23 05:42:36.066642
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    obj = AnsibleVaultEncryptedUnicode('value')
    other = AnsibleVaultEncryptedUnicode('other')
    assert(False == (obj > other))


# Generated at 2022-06-23 05:42:38.900543
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    obj = AnsibleVaultEncryptedUnicode('test')
    assert obj.__mod__(5) == 'test'



# Generated at 2022-06-23 05:42:49.880144
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    a = AnsibleVaultEncryptedUnicode(u"Hello")
    assert a.rstrip() == u"Hello"
    a = AnsibleVaultEncryptedUnicode(text_type())
    assert a.rstrip() == text_type()
    a = AnsibleVaultEncryptedUnicode(u" Hello")
    assert a.rstrip() == u" Hello"
    a = AnsibleVaultEncryptedUnicode(u"Hello ")
    assert a.rstrip() == u"Hello"
    a = AnsibleVaultEncryptedUnicode(u"Hello ")
    assert a.rstrip(u" ") == u"Hello"
    a = AnsibleVaultEncryptedUnicode(u"Hello")
    assert a.rstrip(u" ") == u"Hello"

# Generated at 2022-06-23 05:42:52.424921
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    secret = 'test'
    plaintext = 'test'

    assert AnsibleVaultEncryptedUnicode(plaintext).upper() == plaintext.upper()


# Generated at 2022-06-23 05:42:56.425183
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    avu = AnsibleVaultEncryptedUnicode('abcd')
    avu.vault = vault = DummyVaultLib()
    assert avu.rsplit() == ['abcd']
    avu.vault = None
    assert avu.rsplit() == ['abcd']



# Generated at 2022-06-23 05:42:58.995535
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    
    # given
    s = AnsibleVaultEncryptedUnicode('123')
    
    # when
    b = s.isalpha()
    
    # then
    assert b == False


# Generated at 2022-06-23 05:43:03.148320
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    '''Test case of method isspace of class AnsibleVaultEncryptedUnicode'''
    text = "  "
    avu = AnsibleVaultEncryptedUnicode(text)
    assert avu.isspace() == text.isspace()


# Generated at 2022-06-23 05:43:07.235259
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    AVUEU = AnsibleVaultEncryptedUnicode("\n\r\n\r  1  \r\n\r\n\r")
    assert AVUEU.strip() == "1"


# Generated at 2022-06-23 05:43:17.376067
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    secret = b'fbuvso!9!tbmfsu!boe'
    vault = vaultlib.VaultLib(secret)
    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256;spam\n343665393965366166363766656564663432643938343835303161656236366332373935626438\n393630383566613036663035626439613037353831663362353365653839356264366232393935\n666538303436656563356138356437353836652\n'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.data == 'test string'
    assert avu.r

# Generated at 2022-06-23 05:43:27.476270
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    avueu = AnsibleVaultEncryptedUnicode("My Encrypted String")
    assert to_text(avueu) == "My Encrypted String"

    avueu.data = "Some new data"
    assert to_text(avueu) == "Some new data"
    assert to_bytes(avueu) == to_bytes("Some new data")

    try:
        avueu.decrypt()
        raise AssertionError('AnsibleVaultEncryptedUnicode decrypt() method should have thrown an exception')
    except:
        pass


# Generated at 2022-06-23 05:43:33.780815
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    """
    Test for method expandtabs of class AnsibleVaultEncryptedUnicode
    """
    assert AnsibleVaultEncryptedUnicode('hello\tworld').expandtabs() == 'hello   world'
    assert AnsibleVaultEncryptedUnicode('hello\tworld').expandtabs(tabsize=5) == 'hello     world'
    assert AnsibleVaultEncryptedUnicode('hello world').expandtabs() == 'hello world'
    assert AnsibleVaultEncryptedUnicode('hello world').expandtabs(tabsize=5) == 'hello world'



# Generated at 2022-06-23 05:43:46.423462
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:43:53.995896
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    passwd = "test"
    encrypted_string = vault.encrypt(b"a,b,c,d,e,f,g,h,i,j", passwd)
    avu = AnsibleVaultEncryptedUnicode(encrypted_string)
    avu.vault = vault
    result = avu.rsplit(sep=b',', maxsplit=3)
    assert result == ["a,b,c,d,e", "f", "g,h,i,j"]


# Generated at 2022-06-23 05:43:57.152479
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    obj = 'foo'
    avu = AnsibleVaultEncryptedUnicode(obj)
    assert avu.rjust(5) == '  foo'


# Generated at 2022-06-23 05:43:59.370433
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    sequence = AnsibleSequence([1, 2, 3])
    assert isinstance(sequence, list)
    assert len(sequence) == 3
    assert sequence == [1, 2, 3]


# Generated at 2022-06-23 05:44:06.268036
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    v = AnsibleVaultEncryptedUnicode.from_plaintext("bar", 'yaml', ['secret'])
    assert v.rfind('f') == -1
    v2 = AnsibleVaultEncryptedUnicode.from_plaintext("barfoo", 'yaml', ['secret'])
    assert v2.rfind('f') == 3
    v3 = AnsibleVaultEncryptedUnicode.from_plaintext("barfoof", 'yaml', ['secret'])
    assert v3.rfind('f') == 3



# Generated at 2022-06-23 05:44:16.861992
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    # test non ascii characters
    not_ascii_characters = [
        u'\u00c1', # Á
        u'\u00e4', # ä
        u'\u30c6', # テ
        u'\u4e2d', # 中
        u'\u1f1fa\u1f1f8' # flag: United States
    ]
    for char in not_ascii_characters:
        assert(not AnsibleVaultEncryptedUnicode(char).isascii())

    # test non ascii string
    not_ascii_string = u'This is a multilingual string.\n'
    for char in not_ascii_characters:
        not_ascii_string += char

# Generated at 2022-06-23 05:44:28.698955
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    class MockVault(object):
        def __init__(self, secret, plaintext, ciphertext):
            self._secret = secret
            self._plaintext = plaintext
            self._ciphertext = ciphertext
            self._obj = None
            self.is_encrypted = False

        def encrypt(self, plaintext, secret=None):
            if secret and secret != self._secret:
                raise Exception('Secret does not match')
            return self._ciphertext

        def decrypt(self, ciphertext, secret=None):
            if secret and secret != self._secret:
                raise Exception('Secret does not match')
            self._obj = ciphertext
            return self._plaintext

        def is_encrypted(self, text):
            return self.is_encrypted


# Generated at 2022-06-23 05:44:34.171246
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    value = 'hunting'
    assert AnsibleVaultEncryptedUnicode(value).rindex('t', 4, 10) == 7
    assert AnsibleVaultEncryptedUnicode(value).rindex('ting', 4, 10) == 7
    assert AnsibleVaultEncryptedUnicode(value).rindex('ting', 4, 2) == -1


# Generated at 2022-06-23 05:44:36.769456
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    assert complex(AnsibleVaultEncryptedUnicode(ciphertext=b'0.10')) == complex('0.10')


# Generated at 2022-06-23 05:44:39.294479
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    obj = AnsibleVaultEncryptedUnicode('b')
    obj.data = 'abc'

    # Using class method for testing
    assert 'cba' == obj.__reversed__()


# Generated at 2022-06-23 05:44:41.572954
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    ciphertext = "!vault |"
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu.lower() == ciphertext.lower()


# Generated at 2022-06-23 05:44:43.043386
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    print(AnsibleVaultEncryptedUnicode('foo').upper())


# Generated at 2022-06-23 05:44:44.779949
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    s = AnsibleVaultEncryptedUnicode('ab\0xab')
    assert s.rindex('\0x') == 2


# Generated at 2022-06-23 05:44:52.430754
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    """
    AnsibleVaultEncryptedUnicode.__lt__(other) -> test success
    """
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    vault_text = AnsibleVaultEncryptedUnicode.from_plaintext(u'vvvvvvvvvvvvvvvv', vault, b'password')
    data = u'foobar'
    avu = AnsibleVaultEncryptedUnicode(data)
    assert not avu.__lt__(u'foobar')
    assert not avu.__lt__(vault_text)



# Generated at 2022-06-23 05:45:03.015507
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    vault.secrets = 'test'
    ciphertext = to_bytes(vault.encrypt('asdf'))
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('blah', vault, 'test')
    avu2 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu2.vault = vault
    avu3 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu3.vault = vault

    assert avu1 < 'asdf'
    assert not avu1 < 'blah'
    assert (avu1 < avu2) == ('blah' < 'asdf')

# Generated at 2022-06-23 05:45:12.012970
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Test case for AnsibleVaultEncryptedUnicode + AnsibleVaultEncryptedUnicode
    data_1 = "hello"
    data_2 = "world"
    data_3 = "hello"
    data_4 = "world"
    default_vault = vault.VaultLib('mysecret')
    ansible_vault_1 = AnsibleVaultEncryptedUnicode.from_plaintext(data_1, default_vault, 'mysecret')
    ansible_vault_2 = AnsibleVaultEncryptedUnicode.from_plaintext(data_2, default_vault, 'mysecret')
    ansible_vault_3 = AnsibleVaultEncryptedUnicode.from_plaintext(data_3, default_vault, 'mysecret')
    ansible_vault_4

# Generated at 2022-06-23 05:45:13.349506
# Unit test for constructor of class AnsibleMapping
def test_AnsibleMapping():
    assert isinstance(AnsibleMapping(), AnsibleMapping)



# Generated at 2022-06-23 05:45:24.332366
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    """
    Test of the AnsibleVaultEncryptedUnicode.index method
    """
    vault_text = AnsibleVaultEncryptedUnicode("foobar")

    # Test with a substring that is not in the string
    try:
        vault_text.index("barfoo")
        assert(False)
    except ValueError as e:
        assert(str(e) == "substring not found")

    # Test with a substring that is at the beginning of the string
    assert(vault_text.index("foo") == 0)

    # Test with a substring that is not at the beginning of the string
    assert(vault_text.index("bar") == 3)

    # Test with a substring that is at the end of the string

# Generated at 2022-06-23 05:45:28.586641
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    avu = AnsibleVaultEncryptedUnicode('abc')
    expected = AnsibleVaultEncryptedUnicode('abc')
    expected.data = '  abc'
    assert avu.zfill(5) == expected


# Generated at 2022-06-23 05:45:30.932435
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    test_obj = AnsibleVaultEncryptedUnicode("test")
    assert test_obj.capitalize() == "Test"



# Generated at 2022-06-23 05:45:36.973452
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    import vaultlib
    vault = vaultlib.VaultLib('test', 3)
    secret_str = "mysecret"
    vault_str = AnsibleVaultEncryptedUnicode.from_plaintext(secret_str, vault, "mypassword")
    assert vault_str.endswith(secret_str)
    assert not vault_str.endswith(secret_str+"0")
    assert not vault_str.endswith(secret_str[:7])


# Generated at 2022-06-23 05:45:42.826990
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    # Test if the isascii method work correctly,
    # and it's not a simple wrapper of isascii method in str class
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('U+1F601', None, None)
    if avu.isascii():
        raise AssertionError('Failed to test isascii of AnsibleVaultEncryptedUnicode')



# Generated at 2022-06-23 05:45:49.807188
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    # Test AnsibleVaultEncryptedUnicode isupper method for strings in different cases
    test_strings = {
        'ABC': True,
        'Abc': False,
        'ABC123': False,
        'abc': False
    }
    for k, v in test_strings.items():
        assert AnsibleVaultEncryptedUnicode(k, None).isupper() == v



# Generated at 2022-06-23 05:46:01.075118
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    assert complex("2+2j") == AnsibleVaultEncryptedUnicode("2+2j").__complex__()
    assert complex(" 2") == AnsibleVaultEncryptedUnicode(" 2").__complex__()
    assert complex("2 ") == AnsibleVaultEncryptedUnicode("2 ").__complex__()
    assert complex("077") == AnsibleVaultEncryptedUnicode("077").__complex__()
    assert complex(" 0o77") == AnsibleVaultEncryptedUnicode(" 0o77").__complex__()
    assert complex(" 0o77   ") == AnsibleVaultEncryptedUnicode(" 0o77   ").__complex__()
    assert complex("0x77") == AnsibleVaultEncryptedUnicode("0x77").__complex__()

# Generated at 2022-06-23 05:46:07.622300
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    tests = {"a:b:c:d": ["a", "b", "c", "d"], r"\w+:\w+": ["root:x", "wheel:x"], r"\w+:\w+\Z": ["root:x"]}
    for data, expected in tests.items():
        assert AnsibleVaultEncryptedUnicode(data).split(":") == expected


# Generated at 2022-06-23 05:46:17.740938
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    # Ensure that we correctly format AnsibleVaultEncryptedUnicode objects when
    # they are the second argument to ``%``.
    #
    # Note that this test is a bit circuitous: We want to ensure that
    # AnsibleVaultEncryptedUnicode.__mod__() works, so we create an
    # AnsibleVaultEncryptedUnicode and then attempt to use it to format a string
    # with ``%``.  This requires that AnsibleVaultEncryptedUnicode.__str__()
    # works, so we can't just call ``AnsibleVaultEncryptedUnicode.__mod__()``
    # directly.
    secret = "super secret"

    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-23 05:46:24.156302
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    sequence = "abc12def123"
    avue = AnsibleVaultEncryptedUnicode(sequence)
    #assert(avue.endswith("abc12def123"))
    assert(avue.endswith("def123"))
    #assert(avue.endswith(""))
    assert(not avue.endswith("def1234"))
    assert(avue.endswith("123", 8, 12))
    assert(not avue.endswith("123", 7, 12))
    #assert(avue.endswith("", 0, 0))
    #assert(avue.endswith("", 1))


# Generated at 2022-06-23 05:46:35.324778
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    assert isinstance(AnsibleVaultEncryptedUnicode('a'), AnsibleVaultEncryptedUnicode)
    assert AnsibleVaultEncryptedUnicode('a').isidentifier()
    assert AnsibleVaultEncryptedUnicode('a_b').isidentifier()
    assert not AnsibleVaultEncryptedUnicode('_').isidentifier()
    assert not AnsibleVaultEncryptedUnicode('a ').isidentifier()
    # a non-alphabetic character at the beginning is invalid
    assert not AnsibleVaultEncryptedUnicode('1a').isidentifier()
    # a non-alphabetic character after the first is valid
    assert AnsibleVaultEncryptedUnicode('a1').isidentifier()


# Generated at 2022-06-23 05:46:46.678402
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:46:59.853540
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    '''test method endswith of class AnsibleVaultEncryptedUnicode'''

    # Exception test: if sub is of type AnsibleVaultEncryptedUnicode, return self.data.endswith(sub.data, start, end)
    class vault_fake:
        def encrypt(self, arg1, arg2):
            pass
        def decrypt(self, arg1, arg2):
            pass
        def is_encrypted(self, arg1):
            pass
    seq = 'string'
    secret = 'secret'
    vault = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault_fake, secret)
    avu_sub = AnsibleVaultEncryptedUnicode.from_plaintext('substring', vault_fake, secret)
    start = 0
    end = _sys.maxsize

# Generated at 2022-06-23 05:47:08.141053
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    # Initialize ansible_vault_password_file
    vault_password_file = None
    # Set default ansible_vault_password_file
    if vault_password_file is None:
        if 'ANSIBLE_VAULT_PASSWORD_FILE' in _sys.environ:
            vault_password_file = os.path.expanduser(_sys.environ['ANSIBLE_VAULT_PASSWORD_FILE'])
        else:
            vault_password_file = os.path.join(os.path.expanduser('~'), '.vault_password')
    # If vault_password_file doesn't exist, skip test
    if not os.path.isfile(vault_password_file):
        raise unittest.SkipTest('ANSIBLE_VAULT_PASSWORD_FILE not set')
    # Set

# Generated at 2022-06-23 05:47:19.089236
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    key = b'12345678901234567890123456789012'
    avue = AnsibleVaultEncryptedUnicode.from_plaintext('myvalue', VaultLib(key), key)
    assert avue.is_encrypted() == True
    avue = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;fdb56636ffc93eceb2dff7cf79b069c64')
    avue.vault = VaultLib(key)
    assert avue.is_encrypted() == False
    avue = AnsibleVaultEncryptedUnicode('myvalue')
    avue.vault = VaultLib(key)
    assert avue.is_encrypted() == False

# Generated at 2022-06-23 05:47:24.451272
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    '''
    test strip() of class AnsibleVaultEncryptedUnicode
    '''
    #  create class object with data
    avu = AnsibleVaultEncryptedUnicode('123')
    # call strip on class object
    stripped_data = avu.strip()
    #  check if data are stripped
    assert stripped_data == '123'


# Generated at 2022-06-23 05:47:34.428728
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    from ansible.parsing.vault import VaultEditor
    import unittest

    # create vault
    master_password = 'boguspass'
    vault = VaultEditor(master_password)

    # setup
    ansible_pos = ['n/a', 123, 9]
    test_text = 'test text'
    expected_len = len(test_text)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(test_text, vault, master_password)
    avu.ansible_pos = ansible_pos

    # test
    actual_len = len(avu)

    # verify
    assert expected_len == actual_len

if __name__ == '__main__':
    import unittest
    import doctest


# Generated at 2022-06-23 05:47:40.520941
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    avu = AnsibleVaultEncryptedUnicode('\x00\x01\x02\x03\x04')
    assert avu.index(b'\x01') == 1
    assert avu.index(b'\x02\x03') == 2

    avu2 = AnsibleVaultEncryptedUnicode('\x00\x01\x02\x03\x04')
    assert avu.index(avu2) == 0
    assert avu.index(avu2, 1) == -1
    assert avu.index(avu2, 1, 3) == -1

# Generated at 2022-06-23 05:47:51.612899
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    class Vault:
        # This method is used to get the password of vault.
        # The code in format_map uses a property 'name' of object to get the password.
        def get_encrypted_password(self, obj):
            return obj.name

        # This method is used to decrypt the encrypted data.
        def decrypt(self, data, obj):
            return obj.name + ';' + data
    vault = Vault()

    plaintext = 'password'
    ciphertext = 'ciphertext'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    # Create a class with a property 'name' for the vault password
    class VaultPassword:
        def __init__(self, password):
            self.name = password

    # Create an instance of VaultPassword
    password

# Generated at 2022-06-23 05:47:57.361637
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    import ansible.plugins.vault.VaultLib

    m = AnsibleVaultEncryptedUnicode('string')
    m.vault = ansible.plugins.vault.VaultLib.VaultLib({})

    n = AnsibleVaultEncryptedUnicode('longer')
    n.vault = ansible.plugins.vault.VaultLib.VaultLib({})

    assert m < n


# Generated at 2022-06-23 05:48:02.906243
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    obj = AnsibleVaultEncryptedUnicode('\x02\x04\t')
    assert len(obj.zfill(10)) == 10
    assert obj.zfill(10).startswith('0000000')
    assert obj.zfill(10)[7:] == obj


# Generated at 2022-06-23 05:48:05.509492
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    text = "abc"
    ntext = AnsibleVaultEncryptedUnicode.from_plaintext(text, None, None)
    assert ntext.upper() == text.upper()



# Generated at 2022-06-23 05:48:15.716465
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    # init object
    avu = AnsibleVaultEncryptedUnicode('enc_seq')

    # test string has a 'c' in it
    if 'c' not in avu.data:
        raise AssertionError('expected to find char in attribute data')

    # test translate method
    avu.translate(str.maketrans('', '', 'c'))

    # test string doesn't have a 'c' in it
    if 'c' in avu.data:
        raise AssertionError('expected to not find char in attribute data')

    # expected out
    output = 'en_seq'
    # actual out
    actual = avu.data

    if output != actual:
        raise AssertionError('expected: {0} actual: {1}'.format(output, actual))



# Generated at 2022-06-23 05:48:24.730132
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    import collections
    import unittest

    class AnsibleVaultEncryptedUnicode_TestCase(unittest.TestCase):

        def test_isdecimal(self):
            # Test that isdecimal returns True for decimal characters.
            avu = AnsibleVaultEncryptedUnicode('0123456789')
            self.assertTrue(avu.isdecimal(), "isdecimal: '0123456789' is not a decimal")

            avu = AnsibleVaultEncryptedUnicode('1234567890')
            self.assertTrue(avu.isdecimal(), "isdecimal: '1234567890' is not a decimal")

            avu = AnsibleVaultEncryptedUnicode('1234567890')

# Generated at 2022-06-23 05:48:33.181376
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    from ansible.parsing.vault import VaultLib

    plaintext = u'a b c'
    secret = VaultLib.gen_secret()
    vault = VaultLib(self.vault_password_file)
    encrypted_plaintext = AnsibleVaultEncryptedUnicode.from_plaintext('a b c', vault, secret)
    encrypted_plaintext.vault = VaultLib(self.vault_password_file)
    decrypted_plaintext = encrypted_plaintext.data

    assert plaintext.split() == decrypted_plaintext.split(), \
       "split() method of AnsibleVaultEncryptedUnicode class works wrong"

# Generated at 2022-06-23 05:48:37.182867
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    assert AnsibleVaultEncryptedUnicode("baa baa black sheep").count("b") == 2
    assert AnsibleVaultEncryptedUnicode("baa baa black sheep").count("baa") == 2
    assert AnsibleVaultEncryptedUnicode("baa baa black sheep").count("ab") == 0



# Generated at 2022-06-23 05:48:45.995362
# Unit test for method encode of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:48:51.133146
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    test_string = u"Hello World"
    vault = fake_ansible_vault()
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(test_string, vault, 'vault_password')
    assert avu.__unicode__() == u"Hello World"

# Generated at 2022-06-23 05:49:00.487466
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    assert AnsibleVaultEncryptedUnicode("/home/simon\t/bin /sbin /usr/bin").expandtabs(4) == "/home/simon   /bin /sbin /usr/bin"
    assert AnsibleVaultEncryptedUnicode("/home/simon\t/bin\t/sbin\t/usr/bin").expandtabs(4) == "/home/simon   /bin /sbin /usr/bin"
    assert AnsibleVaultEncryptedUnicode("/home/simon\t/bin\t/sbin\t/usr/bin").expandtabs(8) == "/home/simon        /bin    /sbin    /usr/bin"

# Generated at 2022-06-23 05:49:09.559254
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    t1 = AnsibleVaultEncryptedUnicode("")
    assert t1.isalpha() == False

    t2 = AnsibleVaultEncryptedUnicode("a")
    assert t2.isalpha()

    t3 = AnsibleVaultEncryptedUnicode("abc")
    assert t3.isalpha()

    t4 = AnsibleVaultEncryptedUnicode("abc12")
    assert t4.isalpha() == False

    t5 = AnsibleVaultEncryptedUnicode("ABC12")
    assert t5.isalpha() == False

    t6 = AnsibleVaultEncryptedUnicode("a b c")
    assert t6.isalpha() == False


# Generated at 2022-06-23 05:49:19.221669
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    '''
    Since isdecimal() is used in the validation of a 'port' variable,
    this function tests the case where isdigit() returns True but
    isdecimal() returns False.
    '''
    avu = AnsibleVaultEncryptedUnicode('\u200c')
    assert avu.isdecimal() == False
    assert avu.isdigit() == True

if sys.version_info[0] == 2:
    # Methods below are a copy from ``collections.UserString``
    # Some are copied as is, where others are modified to not
    # auto wrap with ``self.__class__``
    def __getslice__(self, i, j):
        i = max(i, 0); j = max(j, 0)
        return self.data[i:j]


# Generated at 2022-06-23 05:49:21.965202
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    a = AnsibleSequence()
    assert len(a) == 0
    a = AnsibleSequence(range(10))
    assert len(a) == 10



# Generated at 2022-06-23 05:49:25.119168
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
  avue = AnsibleVaultEncryptedUnicode('test')
  avue.data = 'testy'
  assert avue.format() == 'testy'

# Generated at 2022-06-23 05:49:32.233805
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    secret = b'123'
    vault = VaultLib(secret)
    vault.vault = YAMLVaultLib(secret)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('my_password')
    assert avu.data == 'my_password'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('my_password', vault=vault, secret=secret)
    assert avu.data == 'my_password'
    assert avu.format(foo='bar') == 'my_password'
    assert avu.format_map(dict(foo='bar')) == 'my_password'


# Generated at 2022-06-23 05:49:44.258832
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    s = AnsibleVaultEncryptedUnicode("abc")
    assert s.center(2) == s
    assert s.center(3) == "abc"
    assert s.center(4) == " abc"
    assert s.center(5) == "  abc"
    assert s.center(6) == " abc "
    assert s.center(7) == "  abc  "
    assert s.center(8) == "   abc  "
    assert s.center(9) == "   abc   "
    assert s.center(12) == "    abc    "
    assert s.center(13) == "   abc     "
    assert s.center(14) == "   abc     "
    assert s.center(3, ".") == s

# Generated at 2022-06-23 05:49:53.995949
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    class TestVault(object):
        def encrypt(self, plaintext, secret):
            return plaintext
        def decrypt(self, ciphertext, obj=None):
            return ciphertext
        def is_encrypted(self, ciphertext):
            return True

    secret = 'password'
    plaintext = 'plaintext'
    ciphertext = plaintext
    vault = TestVault()
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    avu2 = AnsibleVaultEncryptedUnicode(ciphertext)
    assert hash(avu1) == hash(avu2)



# Generated at 2022-06-23 05:50:00.049716
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    import collections

    if hasattr(collections, 'UserString'):
        if hasattr(collections.UserString, 'isidentifier'):
            del collections.UserString.isidentifier

    avu = AnsibleVaultEncryptedUnicode('test_AnsibleVaultEncryptedUnicode_isidentifier')
    assert avu.isidentifier()


# Generated at 2022-06-23 05:50:12.593956
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    def func(sample, input_int):
        # FIXME: We don't really know what we should get back.
        #        If a unicode string is decrypted we might get a
        #        str or bytes or even a int or float.
        #        We don't change the output in this case
        #        But if it is not decrypted we should get the original string
        #        back.
        expected = sample.data if hasattr(sample, 'data') else sample
        assert int(sample, input_int) == int(expected, input_int)

    yield func, AnsibleVaultEncryptedUnicode('10'), 0
    yield func, AnsibleVaultEncryptedUnicode('10'), 2
    yield func, AnsibleVaultEncryptedUnicode('10'), 10
    yield func, AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:50:17.339979
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    from ansible.parsing.vault import VaultLib
    v = VaultLib()
    secret = 'secret'
    ciphertext = v.encrypt('Hello world!', secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = v
    assert 'Hello world!' == avu.data
    assert repr('Hello world!') == avu.__repr__()


# Generated at 2022-06-23 05:50:22.159138
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    iv = vault.encrypt('test')
    avu = AnsibleVaultEncryptedUnicode(iv)
    avu.vault = vault
    assert avu.rsplit('t') == ['tes', '']


# Generated at 2022-06-23 05:50:29.972982
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    # unicode string which contains unicode type characters
    s_u = u'\u00c1\u00c9\u00cd\u00d3\u00da\u00dc'
    # ansibleVaultEncryptedUnicode object which contains unicode type characters
    avu_u = AnsibleVaultEncryptedUnicode(s_u)
    assert avu_u.istitle() is True
    # unicode string which contains plain ascii characters
    s_a = u'aBCD'
    # ansibleVaultEncryptedUnicode object which contains plain ascii characters
    avu_a = AnsibleVaultEncryptedUnicode(s_a)
    assert avu_a.istitle() is False
    # unicode string which contains both types of characters

# Generated at 2022-06-23 05:50:38.318909
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    assert AnsibleVaultEncryptedUnicode('foo').is_encrypted() is False
    assert AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256').is_encrypted() is True
    # vaultlib object must be present for is_encrypted() to return a useful value
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256')
    avu.vault = VaultLib('password')
    assert avu.is_encrypted() is True
    avu.vault = None
    assert avu.is_encrypted() is False


# Generated at 2022-06-23 05:50:40.606770
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None)
    #print(avu.data)


# Generated at 2022-06-23 05:50:42.803478
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    aveu = AnsibleVaultEncryptedUnicode('hello world')
    # Just check for exceptions
    aveu.rjust(10)


# Generated at 2022-06-23 05:50:53.667412
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    ciphertext = b'$ANSIBLE_VAULT;1.2;AES256;yarik\r\n333937383863656231396131666263636663313637396538316565353737633365656537313438\r\n366361323131633261346133393936303538303264343635303565373661356534643135343937\r\n663365356665333132313430376534653864353065396634313239336164336466383964663331\r\n63653264643335\r\n'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = AnsibleVaultLib()
    assert avu.isdig

# Generated at 2022-06-23 05:51:06.418844
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    str1 = AnsibleVaultEncryptedUnicode('abc')
    str2 = AnsibleVaultEncryptedUnicode('abcc')
    str3 = AnsibleVaultEncryptedUnicode('acc')
    str4 = AnsibleVaultEncryptedUnicode('abcc')
    str5 = AnsibleVaultEncryptedUnicode('aCc')
    str6 = AnsibleVaultEncryptedUnicode('aBcc')
    assert str1.strip('c') == ''
    assert str2.strip('c') == 'ab'
    assert str3.strip('c') == 'a'
    assert str4.strip('c') in ('ab', 'bc')
    assert str5.strip('c') in ('a', 'aC')
    assert str6.strip('c') == 'aB'




# Generated at 2022-06-23 05:51:09.255934
# Unit test for method split of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_split():
    assert isinstance(AnsibleVaultEncryptedUnicode('').split(), list)


# Generated at 2022-06-23 05:51:11.997036
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    plaintext = '''abc\n123\nxyz\n'''
    avec = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, None, 'secret')
    assert avec.splitlines() == [plaintext]



# Generated at 2022-06-23 05:51:24.305100
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    # Use the !vault tag for yaml in order to create the AnsibleVaultEncryptedUnicode object
    # We need to do this in order to test the behaviour of __float__
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from base64 import b64encode

    sequence = '1234.56'
    vault = VaultLib([])
    secret = 'password'
    constructor = AnsibleConstructor(vault_secrets=[secret])

    # Encrypt the sequence using the password provided
    ciphertext = vault.encrypt(sequence, secret)

    # Base64 encode the ciphertext and write it as a yaml file
    cl = b64encode(ciphertext)

# Generated at 2022-06-23 05:51:28.770423
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    assert 'abc\n  \t \v\f' == 'abc\n  \t \v\f'.expandtabs()
    assert 'abc\n  a\ta\ta' == 'abc\n  \ta\ta'.expandtabs()
    assert 'abc\n  a a a' == 'abc\n  \ta\ta'.expandtabs(1)
    assert 'abc\n  a  a  a' == 'abc\n  \ta\ta'.expandtabs(2)



# Generated at 2022-06-23 05:51:39.849580
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    # Given
    vault_pwd1 = b'vault_pwd1'
    vault_pwd2 = b'vault_pwd2'

# Generated at 2022-06-23 05:51:42.340862
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    t = AnsibleVaultEncryptedUnicode("AAA")
    assert t.translate(string.maketrans("A","B")) == "BBB"


# Generated at 2022-06-23 05:51:50.026282
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    # Test with normal string
    s = AnsibleVaultEncryptedUnicode('abc')
    assert not s.isnumeric()

    # Test with numeric string
    s = AnsibleVaultEncryptedUnicode('123')
    assert s.isnumeric()

    # Test with numeric string that contains non-numeric characters
    s = AnsibleVaultEncryptedUnicode('1abc')
    assert not s.isnumeric()

    # Test with non-numeric string that contains numeric characters
    s = AnsibleVaultEncryptedUnicode('a1bc')
    assert not s.isnumeric()


# Generated at 2022-06-23 05:51:53.248368
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    secret = "secret"
    plaintext = "abcdefghijklm"
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault=AnsibleVaultAES256(), secret=secret)

    assert avu[2] == "c"


# Generated at 2022-06-23 05:52:04.745937
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    # When constructor argument is not a string, raise Exception
    with pytest.raises(TypeError):
        AnsibleVaultEncryptedUnicode(1)
    # For string 'abc'
    actual = AnsibleVaultEncryptedUnicode('abc')
    # - method casefold() returns the same string
    assert actual.casefold() == 'abc'
    # - method capitalize() returns the capitalized string
    assert actual.capitalize() == 'Abc'
    # - method center() returns the centered string
    assert actual.center(5) == ' abc '
    # - method count() returns the count of sub string
    assert actual.count('a') == 1
    # - method endswith() returns the truth value of the statement
    assert actual.endswith('c')
    # - method expandtabs() returns the expanded

# Generated at 2022-06-23 05:52:15.535208
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    avu = AnsibleVaultEncryptedUnicode("!vault")
    ansible_pos = (1, 2, 3)
    avu.ansible_pos = ansible_pos
    assert avu.ansible_pos == ansible_pos
    for data in ["", "abc", "私", u"\U0001f4a9"]:
        avu = AnsibleVaultEncryptedUnicode(data)
        assert len(avu) == len(data)
    avu = AnsibleVaultEncryptedUnicode("")
    assert len(avu) == 0
    avu = AnsibleVaultEncryptedUnicode("abc")
    assert len(avu) == 3
    avu = AnsibleVaultEncryptedUnicode("私")
    assert len(avu) == 1

# Generated at 2022-06-23 05:52:22.098740
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    from ansible_collections.community.general.plugins.vars.vault import VaultLib
    from ansible_collections.ansible.community.plugins.vars.vault import VaultSecret
    vault = VaultLib(password_files=VaultSecret('foobar'))
    avu = AnsibleVaultEncryptedUnicode.from_plaintext("foo", vault, 'foobar')
    try:
        avu.index("bar")
        assert False
    except ValueError as e:
        assert str(e) == "substring not found"
    try:
        avu.index("f")
    except ValueError as e:
        assert False, str(e)


# Generated at 2022-06-23 05:52:27.882200
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():

    a = AnsibleVaultEncryptedUnicode("a")
    b = AnsibleVaultEncryptedUnicode("b")
    c = AnsibleVaultEncryptedUnicode("c")
    assert a <= a
    assert a <= b
    assert not a <= c
    assert a == "a"

    try:
        a <= "a"
    except AssertionError:
        pass
    else:
        assert False
