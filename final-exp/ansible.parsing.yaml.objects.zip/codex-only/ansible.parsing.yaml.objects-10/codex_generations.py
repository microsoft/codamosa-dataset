

# Generated at 2022-06-23 05:42:27.731267
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    try:
        import ansible.parsing.vault as vault
    except ImportError:
        print("Error importing ansible.parsing.vault, skipping test")
        return
    try:
        vault_pass = open('/etc/vault_pass', 'rb')
    except:
        print("Error reading vault pass, skipping test")
        return
    v = vault.VaultLib(vault_pass.read())
    plaintext = "this is the plaintext string"
    ciphertext = v.encrypt(plaintext, key_vars={'vault_id': 'unit_test'})
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = v
    assert avu.data == plaintext
    assert avu[3] == plaintext[3]

# Generated at 2022-06-23 05:42:29.724830
# Unit test for method upper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_upper():
    assert AnsibleVaultEncryptedUnicode('abcde').upper() == 'ABCDE'


# Generated at 2022-06-23 05:42:33.910563
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    obj = AnsibleVaultEncryptedUnicode('abc')
    assert obj < 'abc'
    assert obj < 'abcd'
    assert not obj < 'ab'
    assert not obj < 'a'

    obj = AnsibleVaultEncryptedUnicode('')
    assert not obj < ''
    assert obj < 'a'



# Generated at 2022-06-23 05:42:41.322081
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    from ansible.vault import Vault
    data = 'testing'.encode()

# Generated at 2022-06-23 05:42:50.568755
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib()
    vault_password = 'password'
    test_string_plain = "A Test"
    test_string_cipher = vault.encrypt(test_string_plain, vault_password)

    # __init__() converts ciphertext to a string
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(test_string_cipher)
    ansible_vault_encrypted_unicode.vault = vault

    # istitle() decrypts data and calls istitle() on the resulting string
    assert ansible_vault_encrypted_unicode.istitle() == test_string_plain.istitle()



# Generated at 2022-06-23 05:42:58.144792
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    a = AnsibleVaultEncryptedUnicode('ansible')
    assert a.startswith('ans')
    assert not a.startswith('le')
    assert a.startswith('')
    assert a.startswith('')
    assert a.startswith(AnsibleVaultEncryptedUnicode('ans'))
    assert not a.startswith(AnsibleVaultEncryptedUnicode('le'))
    assert a.startswith(AnsibleVaultEncryptedUnicode(''))
    assert a.startswith(AnsibleVaultEncryptedUnicode(''))


# Generated at 2022-06-23 05:43:02.878732
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    expected = True
    actual = AnsibleVaultEncryptedUnicode('test').startswith('test')
    assert actual == expected


# ------------------------------------------------------------------------------
# DO NOT EDIT BELOW THIS LINE
# ------------------------------------------------------------------------------

# Backwards compatibility for Ansible < 2.0



# Generated at 2022-06-23 05:43:14.093332
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    plaintext = 'This is a test'
    plaintext_unicode = u'This is a test'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, AnsibleVaultLib(), 'VaultPassword')
    avu_unicode = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext_unicode, AnsibleVaultLib(), 'VaultPassword')
    assert avu.__getslice__(0, len(avu)) == plaintext
    assert avu_unicode.__getslice__(0, len(avu)) == plaintext
    assert avu.__getslice__(0, len(avu) - 1) == plaintext[0:len(plaintext) - 1]

# Generated at 2022-06-23 05:43:16.531418
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    txt = "2.5"
    avu = AnsibleVaultEncryptedUnicode(txt)
    assert float(avu) == float(txt)


# Generated at 2022-06-23 05:43:20.617060
# Unit test for method __hash__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___hash__():
    """
    AnsibleVaultEncryptedUnicode: test for __hash__
    """
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode("fixture")
    ansible_vault_encrypted_unicode.__hash__()


# Generated at 2022-06-23 05:43:28.063516
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    # test data and expected results.
    test_parameters = [
        (123, 123j),
        (123.0, 123.0j),
        (0, 0j),
    ]
    # loop over test data
    for data, result in test_parameters:
        # create a class instance
        avu = AnsibleVaultEncryptedUnicode.from_plaintext(data, None, None)
        # check that expected result equals result of method __complex__
        assert result == avu.__complex__()
        # for coverage of __complex__
        assert result == complex(avu)


# Generated at 2022-06-23 05:43:39.389631
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    from ansible.parsing.vault import VaultLib
    v = VaultLib('test')
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('abc', v, 'test')
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('def', v, 'test')
    avu3 = AnsibleVaultEncryptedUnicode.from_plaintext('ghi', v, 'test')
    assert avu1.join(avu2) == 'abcdef'
    assert avu1.join([avu2]) == 'abcdef'
    assert avu1.join((avu2, avu3)) == 'abcdefghi'
    assert avu1.join([avu2, avu3]) == 'abcdefghi'



# Generated at 2022-06-23 05:43:42.209311
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    avu = AnsibleVaultEncryptedUnicode('')
    with pytest.raises(TypeError):
        complex(avu)



# Generated at 2022-06-23 05:43:49.333164
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    avu = AnsibleVaultEncryptedUnicode('this is a test')
    result = avu.rpartition(' is ')
    assert type(result) is tuple
    assert len(result) == 3
    assert type(result[0]) is AnsibleVaultEncryptedUnicode
    assert type(result[1]) is AnsibleVaultEncryptedUnicode
    assert type(result[2]) is AnsibleVaultEncryptedUnicode



# Generated at 2022-06-23 05:43:56.998355
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    """ method isdigit of class AnsibleVaultEncryptedUnicode """
    avue = AnsibleVaultEncryptedUnicode(b'') # empty byte string
    assert avue.isdigit() == False
    avue = AnsibleVaultEncryptedUnicode(b'123')
    assert avue.isdigit() == False
    avue = AnsibleVaultEncryptedUnicode(b'123abc')
    assert avue.isdigit() == False


# Generated at 2022-06-23 05:44:06.953661
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    class AnsibleVaultEncryptedUnicodeStub(AnsibleVaultEncryptedUnicode):
        def __init__(self, data, vault=None):
            super(AnsibleVaultEncryptedUnicodeStub, self).__init__(data)
            self.vault = vault

        @property
        def data(self):
            if not self.vault:
                raise vault.AnsibleVaultError('stub called without vault')
            return self.vault.decrypt(self._ciphertext)

        @data.setter
        def data(self, value):
            self._ciphertext = value


# Generated at 2022-06-23 05:44:15.030559
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    vault_password = 'secret'
    message = 'Hello, %(name)s'
    name = 'world'
    values = {'name': name}
    obj = AnsibleVaultEncryptedUnicode(vault_password, message)
    # Test with a dictionary
    assert obj.__mod__(values) == 'Hello, world'
    # Test with a string
    assert obj.__mod__(name) == 'Hello, world'
    # Test with an integer
    assert obj.__mod__(1) == 'Hello, 1'


# Generated at 2022-06-23 05:44:27.846819
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    plaintext_1 = 'abc'
    plaintext_2 = 'def'

    ciphertext_1 = b'vault|0|H4sIAAAAAAAAAMWQQQoDMRBFGyiWFmZmZYWBlZiZmZghIz6+TuU6WMiU6GpIEFTKu' \
                   b'b0CgQAAAAA'
    ciphertext_2 = b'vault|1|H4sIAAAAAAAAAMWQQUrDMBBFGyiWFmZmZYWBlZiZmZghIz6+TuU6WMiU6GpIEFTKu' \
                   b'b0CgBdqF6UAAAAA'

    vault = VaultLib('password')

# Generated at 2022-06-23 05:44:40.209928
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    assert AnsibleVaultEncryptedUnicode('secret').rfind('t') == 5
    assert AnsibleVaultEncryptedUnicode('secret').rfind('x') == -1
    assert AnsibleVaultEncryptedUnicode('secret').rfind('t', 0, 5) == -1
    assert AnsibleVaultEncryptedUnicode('secret').rfind('t', 4, 6) == 5
    assert AnsibleVaultEncryptedUnicode('secret').rfind('t', 4) == 5
    assert AnsibleVaultEncryptedUnicode('secret').rfind('t', 0, 6) == 5
    assert AnsibleVaultEncryptedUnicode('secret').rfind('t', start=0, end=6) == 5

# Generated at 2022-06-23 05:44:41.742916
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    assert AnsibleUnicode('') is not None



# Generated at 2022-06-23 05:44:44.186374
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    avu = AnsibleVaultEncryptedUnicode("ABC")
    assert avu.lower() == "abc"


# Generated at 2022-06-23 05:44:46.645672
# Unit test for method __len__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___len__():
    s = AnsibleVaultEncryptedUnicode('abcdefg')
    assert len(s) == 7



# Generated at 2022-06-23 05:44:55.772101
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Check for the case where obj.vault is not set
    avu1 = AnsibleVaultEncryptedUnicode('abc')
    avu2 = AnsibleVaultEncryptedUnicode('abc')
    assert avu1.vault == avu2.vault == None
    assert avu1 == avu2
    assert avu1.__gt__(avu2) == False

    # Check for the case where obj.vault is set
    import vaultlib
    vault = vaultlib.VaultLib()
    password = 'password'
    avu1 = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, password)
    avu2 = AnsibleVaultEncryptedUnicode.from_plaintext('abc', vault, password)
    assert avu1 == avu2

# Generated at 2022-06-23 05:44:58.174343
# Unit test for method __int__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___int__():
    assert int(AnsibleVaultEncryptedUnicode('1'))==1


# Generated at 2022-06-23 05:45:13.052229
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    # Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
    # Input parameters
    #     str_value = a string which length is more than 1 but no alpha
    #     expected_result = False
    str_value = '1234'
    expected_result = False
    ansiblevault_obj = AnsibleVaultEncryptedUnicode(str_value)
    actual_result = ansiblevault_obj.isalpha()
    assert actual_result == expected_result, "Failed to validate a string that has no alpha"

    # Input parameters
    #     str_value = a string that has only alpha in it
    #     expected_result = True
    str_value = 'abc'
    expected_result = True

# Generated at 2022-06-23 05:45:18.101455
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib('mysecret')

    s = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault, 'mysecret')
    # This should not raise exception
    s.index('l')


# Generated at 2022-06-23 05:45:27.962570
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    tests = (
        # valid identifiers
        "a_proxy_url",
        "aProxyUrl",
        "_aProxyUrl",
        "a_proxy_url_1",
        "a_proxy_url_longer_than_30_characters",
        # invalid identifiers
        "",
        "1_proxy_url",
        "a-proxy-url",
        "a proxy url",
        "a_proxy_url$",
        "a_proxy_url_longer_than_31_characters",
    )

    for test in tests:
        avu = AnsibleVaultEncryptedUnicode(test)
        assert avu.isidentifier() == test.isidentifier()

# Generated at 2022-06-23 05:45:34.458496
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    avu = AnsibleVaultEncryptedUnicode('\x0c\xef\xdd\x00\x03')
    assert (avu.isprintable() is False)
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert (avu.isprintable() is True)
    avu = AnsibleVaultEncryptedUnicode('ÀÁÂÃ')
    assert (avu.isprintable() is True)



# Generated at 2022-06-23 05:45:37.330567
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    avue = AnsibleVaultEncryptedUnicode('foo')
    assert repr(avue) == to_text('foo')



# Generated at 2022-06-23 05:45:42.988239
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    assert not AnsibleVaultEncryptedUnicode('hello') <= 'bad'
    assert not AnsibleVaultEncryptedUnicode('hello') <= AnsibleVaultEncryptedUnicode('bad')
    assert AnsibleVaultEncryptedUnicode('hello') <= 'hello'
    assert AnsibleVaultEncryptedUnicode('hello') <= AnsibleVaultEncryptedUnicode('hello')


# Generated at 2022-06-23 05:45:48.359070
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    assert isinstance(AnsibleVaultEncryptedUnicode.from_plaintext('foo', 1, 'bar'), AnsibleVaultEncryptedUnicode)

if __name__ == '__main__':
    test_AnsibleVaultEncryptedUnicode()



# Generated at 2022-06-23 05:45:52.768542
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    s = 'abc\ndef'
    avu = AnsibleVaultEncryptedUnicode(s)
    assert avu.splitlines() == s.splitlines()
    assert avu.splitlines(True) == s.splitlines(True)


# Generated at 2022-06-23 05:46:03.479394
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    avue = AnsibleVaultEncryptedUnicode(b'e1e2e3')

    # rsplit without maxsplit
    assert(avue.rsplit() == avue.data.rsplit())
    assert(avue.rsplit('e') == avue.data.rsplit('e'))
    assert(avue.rsplit('e', 1) == avue.data.rsplit('e', 1))
    assert(avue.rsplit('e', 2) == avue.data.rsplit('e', 2))

    # rsplit with maxsplit
    assert(avue.rsplit('e', 2) == avue.rsplit('e', maxsplit=2))

# Generated at 2022-06-23 05:46:11.945006
# Unit test for method __getitem__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getitem__():
    avu = AnsibleVaultEncryptedUnicode(b'abc')
    # Test a normal use case
    result = avu[1]
    assert result == b'b'
    # Test a use case with an index out of range
    try:
        result = avu[3]
        assert False, "Did not raise IndexError as expected"
    except IndexError:
        assert True
    # Test a use case with a negative index
    result = avu[-2]
    assert result == b'b'

# Generated at 2022-06-23 05:46:17.928188
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    # test with string
    value = 'a'
    obj = AnsibleVaultEncryptedUnicode(value)
    assert (obj.isalpha() == value.isalpha())

    # test with AnsibleVaultEncryptedUnicode
    value = 'abc'
    obj = AnsibleVaultEncryptedUnicode(value)
    assert (obj.isalpha() == value.isalpha())



# Generated at 2022-06-23 05:46:21.903375
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    string = AnsibleVaultEncryptedUnicode("Hello")
    assert string.find("Hell") == 0
    assert string.find("ell") == 1
    assert string.find("ell",1) == 1
    assert string.find("big_world") == -1


# Generated at 2022-06-23 05:46:26.639458
# Unit test for method __repr__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___repr__():
    # Test method __repr__ of class AnsibleVaultEncryptedUnicode
    # given values
    input_value = "This is a test string"
    expected_value = repr(input_value)
    actual_value = AnsibleVaultEncryptedUnicode(input_value).__repr__()

    # assert
    assert expected_value == actual_value



# Generated at 2022-06-23 05:46:34.942835
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    class MockVault(object):
        def __init__(self, is_encrypted, decrypted):
            self.is_encrypted = is_encrypted
            self.decrypted = decrypted

        def encrypt(self, seq, secret):
            return seq

        def decrypt(self, ciphertext, obj=None):
            return self.decrypted

    vault = MockVault(False, '1')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault, 'secret')
    assert avu.isnumeric() is False

    vault = MockVault(False, '12345')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello', vault, 'secret')
    assert avu.isnumeric() is True

    vault = MockVault(False, 'abcd')

# Generated at 2022-06-23 05:46:41.747885
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Given
    ciphertext = "hello"
    vault = vaultlib.VaultLib("vault password")
    secret = "secret"

    avu_1 = AnsibleVaultEncryptedUnicode.from_plaintext("abc", vault, secret)
    avu_2 = AnsibleVaultEncryptedUnicode.from_plaintext("abd", vault, secret)

    # When
    result = avu_2 > avu_1

    # Then
    assert result == True


# Generated at 2022-06-23 05:46:50.926678
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test for equality between plaintext and encrypted string
    plain_str = "test_str"
    plain_str2 = "test_str2"
    avue = AnsibleVaultEncryptedUnicode.from_plaintext(plain_str, vault=None, secret=None)
    avue_copy = AnsibleVaultEncryptedUnicode.from_plaintext(plain_str, vault=None, secret=None)
    avue_plain = AnsibleVaultEncryptedUnicode(plain_str)
    avue_plain2 = AnsibleVaultEncryptedUnicode(plain_str2)

    assert avue == avue_copy
    assert avue != avue_plain
    assert avue != avue_plain2



# Generated at 2022-06-23 05:46:56.964220
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    x = AnsibleBaseYAMLObject()
    y = AnsibleBaseYAMLObject()
    y.ansible_pos = ("/tmp/test.yml", 42, 4)
    assert x.ansible_pos == (None, 0, 0)
    assert y.ansible_pos == ("/tmp/test.yml", 42, 4)


# Generated at 2022-06-23 05:47:00.877343
# Unit test for method expandtabs of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_expandtabs():
    string_expandtabs = AnsibleVaultEncryptedUnicode('\thello, world.')
    assert string_expandtabs.expandtabs() == '        hello, world.'
    assert string_expandtabs.expandtabs(tabsize=16) == '                hello, world.'



# Generated at 2022-06-23 05:47:04.576525
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    test_str = AnsibleVaultEncryptedUnicode('1234')
    assert test_str.isnumeric() == True
    test_str = AnsibleVaultEncryptedUnicode('abc')
    assert test_str.isnumeric() == False


# Generated at 2022-06-23 05:47:13.413663
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    """
    Checks for method __str__ of class AnsibleVaultEncryptedUnicode
    """
    if sys.version_info[0] == 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    import ansible.parsing.vault

    output = StringIO()
    sys.stdout = output

    a = AnsibleVaultEncryptedUnicode.from_plaintext(to_bytes('testdata'), ansible.parsing.vault.VaultLib('password'), 'password')
    print(a)


# Generated at 2022-06-23 05:47:23.031920
# Unit test for method strip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_strip():
    from ansible.parsing.vault import VaultLib

    # Create a new vault file
    filename = 'test_vault_file'
    password = 'test_vault_password'
    vault = VaultLib(password)
    with open(filename, 'w') as f:
        f.write('vault_password_file = ' + filename)

    # Test with a simple string
    test_string = 'foo'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(test_string, vault, password)

    # Test with a string beginning with an space
    test_string = ' foo'
    expected_encrypted_string = vault.encrypt(test_string, password)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(test_string, vault, password)
   

# Generated at 2022-06-23 05:47:30.408253
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    avu = AnsibleVaultEncryptedUnicode(b'abc')
    assert avu.count(b'a') == 1
    assert avu.count(b'b') == 1
    assert avu.count(b'c') == 1
    assert avu.count(b'abc') == 1
    assert avu.count(b'bc') == 1
    assert avu.count(b'd') == 0
    assert avu.count(b'abcd') == 0

if yaml.__with_libyaml__:
    # load libyaml bindings if available
    try:
        from yaml import CLoader as Loader, CDumper as Dumper
        # Let the user know why we are not using libyaml
    except ImportError:
        from yaml import Loader, Dumper

# Generated at 2022-06-23 05:47:39.076831
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    class StubVault(object):
        def decrypt(self, cipher_text, obj=None):
            return 'hello foo'


# Generated at 2022-06-23 05:47:47.841354
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    """
    The method encode in class AnsibleVaultEncryptedUnicode
    should always return a byte string and never a unicode
    """
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    secret = 'foo'
    plaintext = 'bar'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert isinstance(avu.encode(), bytes)
    assert avu.encode() == b'bar'



# Generated at 2022-06-23 05:47:57.791540
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    # Test that the method returns True when the decrypted string contains digit
    assert AnsibleVaultEncryptedUnicode('!vault |$ANSIBLE_VAULT;1.1;AES256\n3662316136613531666337333363164353833666636353632396330386133353966386264636265\n6663303966333231316265306130633961656438303636353339\n').isdigit() == True

# Generated at 2022-06-23 05:48:08.086582
# Unit test for method endswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_endswith():
    assert not AnsibleVaultEncryptedUnicode(b'').endswith(b'')
    assert not AnsibleVaultEncryptedUnicode(b'').endswith(b'a')
    assert AnsibleVaultEncryptedUnicode(b'a').endswith(b'')
    assert AnsibleVaultEncryptedUnicode(b'a').endswith(b'a')
    assert not AnsibleVaultEncryptedUnicode(b'a').endswith(b'b')
    assert AnsibleVaultEncryptedUnicode(b'abc').endswith(b'')
    assert AnsibleVaultEncryptedUnicode(b'abc').endswith(b'a')
    assert AnsibleVaultEncryptedUnicode(b'abc').endswith(b'b')
   

# Generated at 2022-06-23 05:48:12.478332
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():

    result = AnsibleVaultEncryptedUnicode.lower()
    assert type(result) is AnsibleVaultEncryptedUnicode

    result = AnsibleVaultEncryptedUnicode.lower(self, value)
    assert type(result) is AnsibleVaultEncryptedUnicode



# Generated at 2022-06-23 05:48:17.081642
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(u'abcdefghijklmnopqrstuvwxyz', None, None)
    assert avu.rstrip('z') == 'abcdefghijklmnopqrstuvwxy'

# Generated at 2022-06-23 05:48:24.769678
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    assert float(AnsibleVaultEncryptedUnicode('1.1')) == 1.1
    assert float(AnsibleVaultEncryptedUnicode('0.1')) == 0.1
    assert float(AnsibleVaultEncryptedUnicode('1.0')) == 1.0


# Generated at 2022-06-23 05:48:32.686977
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import vaultlib as vault
    plaintext = b'Hello world'
    vault1 = vault.VaultLib('mysecret', None)
    ciphertext = vault1.encrypt(plaintext)
    avu1 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu1.vault = vault1
    assert avu1.is_encrypted()
    assert plaintext not in avu1
    avu1.data = plaintext
    assert not avu1.is_encrypted()
    assert plaintext in avu1


# Generated at 2022-06-23 05:48:41.224683
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():

    # Create an AnsibleVaultEncryptedUnicode object, passing it an int argument
    obj = AnsibleVaultEncryptedUnicode(5)
    pos = obj.rfind(obj)
    assert pos == 0, "test AnsibleVaultEncryptedUnicode.rfind() did not return '0' as expected"
    pos = obj.rfind(obj, 0, 4)
    assert pos == 0, "test AnsibleVaultEncryptedUnicode.rfind() did not return '0' as expected"
    pos = obj.rfind(obj, 0, 5)
    assert pos == 0, "test AnsibleVaultEncryptedUnicode.rfind() did not return '0' as expected"
    pos = obj.rfind(obj, 0, 6)
    # The position is returned as a signed integer, which is

# Generated at 2022-06-23 05:48:53.213573
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:49:03.889755
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    import ansible.parsing.vault as vaultlib

    password = 'test'
    test_str = 'Hello'
    vault = vaultlib.VaultLib(password)

    encrypted_str = AnsibleVaultEncryptedUnicode.from_plaintext(test_str, vault, password)
    assert isinstance(encrypted_str, AnsibleVaultEncryptedUnicode)
    assert encrypted_str.is_encrypted()
    assert not hasattr(encrypted_str, 'data')

    # Pass a string to the encode method
    # The returned object should be a Python bytestring which is the encrypted string
    encoded_string = encrypted_str.encode()
    assert isinstance(encoded_string, bytes)
    assert encoded_string == encrypted_str._ciphertext

    # Test by passing the encoding option to the encode method.

# Generated at 2022-06-23 05:49:13.205343
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    plaintext_value = "vaulted_value"
    vault = vault_load_old("vault_password")
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext_value, vault, "vault_password")
    try:
        complex_value = complex(avu)
        assert complex_value.real == 0 and complex_value.imag == 0
    except TypeError:
        # we expect a TypeError if the content of the data is not
        # a valid complex number
        pass



# Generated at 2022-06-23 05:49:20.516317
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    _assert = to_text('0123456789') < to_text('123456789')
    assert(to_text('0123456789') < AnsibleVaultEncryptedUnicode(to_bytes('123456789')))
    assert(_assert == (to_text('0123456789') < AnsibleVaultEncryptedUnicode(to_bytes('123456789'))))



# Generated at 2022-06-23 05:49:30.745069
# Unit test for method __rmod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___rmod__():
    import sys
    is_py2 = sys.version[0] == '2'
    is_py3k = sys.version_info >= (3, 0, 0)
    is_py34 = (3, 4, 0) <= sys.version_info < (3, 5, 0)
    is_py36 = (3, 6, 0) <= sys.version_info < (3, 7, 0)

    if is_py2:
        from StringIO import StringIO
    elif is_py3k:
        from io import StringIO

    from vaultlib import VaultLib
    from ansible.parsing.vault import VaultSecret, get_file_vault_secret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # get vault secret
    this_file = _

# Generated at 2022-06-23 05:49:34.905665
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    msg = 'abc'
    avu = AnsibleVaultEncryptedUnicode(ciphertext=msg)
    assert avu.islower()

    msg = 'ABC'
    avu = AnsibleVaultEncryptedUnicode(ciphertext=msg)
    assert not avu.islower()



# Generated at 2022-06-23 05:49:39.332538
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    avu = AnsibleVaultEncryptedUnicode("abc\nabc\nabc")
    assert (avu.splitlines(keepends=True) == ["abc\n", "abc\n", "abc"])



# Generated at 2022-06-23 05:49:51.332841
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    assert not AnsibleVaultEncryptedUnicode("abc").istitle()
    assert AnsibleVaultEncryptedUnicode("A").istitle()
    assert not AnsibleVaultEncryptedUnicode("Aa").istitle()
    assert AnsibleVaultEncryptedUnicode("AaB").istitle()
    assert AnsibleVaultEncryptedUnicode("AaBb").istitle()
    assert AnsibleVaultEncryptedUnicode("AaBbCc").istitle()
    assert not AnsibleVaultEncryptedUnicode("AaBcC").istitle()
    assert not AnsibleVaultEncryptedUnicode("AaBcC ").istitle()



# Generated at 2022-06-23 05:50:01.958298
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    plaintext = 'In cryptography, the Data Encryption Standard (DES)'
    assert plaintext.count('e') == 4
    assert plaintext.count('e', 1, 4) == 1
    assert plaintext.count('z') == 0
    assert plaintext.count('z', 1, 4) == 0

    from ansible.parsing.vault import VaultLib
    vault_id = VaultLib.generate_vault_password()
    vault = VaultLib(vault_id)
    ciphertext = to_bytes(vault.encrypt(plaintext))

    encrypted = AnsibleVaultEncryptedUnicode(ciphertext)
    encrypted.vault = vault
    assert encrypted.count('e') == 4
    assert encrypted.count('e', 1, 4) == 1
    assert encrypted.count('z') == 0
   

# Generated at 2022-06-23 05:50:10.375465
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    teststr = AnsibleVaultEncryptedUnicode('こんにちは、世界!')
    assert teststr.translate(str.maketrans({'こ': 'こ', 'ん': 'ん', 'に': 'に', 'ち': 'ち', 'は': 'は', '、': '、', '世': '世', '界': '界', '!': '!'})) == 'こんにちは、世界!'



# Generated at 2022-06-23 05:50:24.171266
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    assert 'A'.isupper()
    assert not 'a'.isupper()
    assert not '1'.isupper()


# Generated at 2022-06-23 05:50:27.339814
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    assert AnsibleVaultEncryptedUnicode("foo").rjust(3) == "foo"
    assert AnsibleVaultEncryptedUnicode("foo").rjust(6) == "   foo"



# Generated at 2022-06-23 05:50:30.461300
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    s = AnsibleVaultEncryptedUnicode("Hello, World")
    assert s.startswith("Hello")
    assert not s.startswith("Hola")

# Generated at 2022-06-23 05:50:41.231294
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    avu = AnsibleVaultEncryptedUnicode("a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z")

# Generated at 2022-06-23 05:50:49.992487
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    # Plaintext that is not lowercased
    assert AnsibleVaultEncryptedUnicode.from_plaintext('test', None, None).islower()
    assert not AnsibleVaultEncryptedUnicode.from_plaintext('Test', None, None).islower()
    assert not AnsibleVaultEncryptedUnicode.from_plaintext('TEST', None, None).islower()
    assert not AnsibleVaultEncryptedUnicode.from_plaintext('123', None, None).islower()



# Generated at 2022-06-23 05:51:00.784308
# Unit test for constructor of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode():
    from ansible.parsing.vault import VaultLib

    test1_password = "test123"
    test1_secret = "toomanysecrets"
    # Verify initialization with a Vault object
    test1_obj = AnsibleVaultEncryptedUnicode.from_plaintext(test1_secret, VaultLib(test1_password), test1_password)
    test1_plaintext = test1_obj.data
    assert test1_plaintext == test1_secret
    test1_plaintext_as_bytes = to_bytes(test1_secret)

# Generated at 2022-06-23 05:51:06.991613
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    d = AnsibleBaseYAMLObject()
    d._line_number = 5
    d._column_number = 10
    d._data_source = "/path/to/file.yml"
    assert d.ansible_pos == ("/path/to/file.yml", 5, 10)
    d.ansible_pos = ("/path/to/file2.yml", 1, 2)
    assert d._line_number == 1
    assert d._column_number == 2
    assert d._data_source == "/path/to/file2.yml"



# Generated at 2022-06-23 05:51:11.840948
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    from ansible.parsing.vault import VaultLib
    password = "asd"
    vault = VaultLib(password)
    enc = vault.encrypt(b'\xe4\xe4\xef\xe4')
    text = AnsibleVaultEncryptedUnicode(enc)
    text.vault = vault
    print(text.translate(dict.fromkeys(range(256), None)))
    print(text.encode())


# Generated at 2022-06-23 05:51:16.153854
# Unit test for method __mul__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mul__():
    avueu = AnsibleVaultEncryptedUnicode(to_bytes('this is encrypted'))

    assert avueu * 2 == 'this is encryptedthis is encrypted'
    assert 2 * avueu == 'this is encryptedthis is encrypted'


# Generated at 2022-06-23 05:51:19.534577
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    # It should not fail
    assert float(AnsibleVaultEncryptedUnicode.from_plaintext(u'123', None, None)) == 123



# Generated at 2022-06-23 05:51:30.686053
# Unit test for method isalnum of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalnum():
    import ansible.parsing.vault
    from ansible.parsing.vault import VaultLib

    plaintext = 'abc'
    secret = 'secret'
    password = 'password'

    vault = VaultLib(password)
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    assert len(avu) == 3
    assert avu[0] == plaintext[0]
    assert avu[-1] == plaintext[-1]
    assert avu == plaintext
    assert avu.islower()
    assert avu.isalpha()
    assert avu.isalnum()
    assert not avu.isspace()
    assert not avu.isdigit()
    assert not avu.isupper()
    assert not avu.istitle

# Generated at 2022-06-23 05:51:33.652616
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    vault = AnsibleVaultEncryptedUnicode("1")
    vault.vault = None
    assert vault == "1"
    assert vault != "2"



# Generated at 2022-06-23 05:51:38.051404
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    avue = AnsibleVaultEncryptedUnicode('abcde')
    avue.vault = None
    assert avue.find('de') == 3
    assert avue.find('de', 4) == -1
    assert avue.find('de', 1, 2) == -1


# Generated at 2022-06-23 05:51:44.056749
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    # Check that rfind does not fail for one character (issue #23608)
    assert AnsibleVaultEncryptedUnicode.from_plaintext(
        'some password',
        VaultLib('password'),
        'password'
    ).rfind('w') == -1



# Generated at 2022-06-23 05:51:46.151833
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode("test")
    assert avu != "not test"



# Generated at 2022-06-23 05:51:51.240460
# Unit test for method index of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_index():
    # Given an encrypted string with bracket in it
    # When method index is called with a substring which has bracket in it
    # Then it should return correct result
    substring = "["
    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext("abcdefg[", False, "secret")
    actual = encrypted_string.index(substring)
    expected = 6
    # Then actual should be same as expected
    assert actual == expected

# Generated at 2022-06-23 05:51:53.476218
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    #TODO: write a test
    pass


# Generated at 2022-06-23 05:51:57.192287
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    obj = AnsibleVaultEncryptedUnicode("ThIS is tEST!")
    assert not obj.isupper()
    assert obj.isupper() == obj.data.isupper()

    obj = AnsibleVaultEncryptedUnicode("THIS IS TEST!")
    assert obj.isupper()
    assert obj.isupper() == obj.data.isupper()



# Generated at 2022-06-23 05:52:00.531307
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    avu = AnsibleUnicode("test")
    try:
        avu.center(3)
    except AttributeError:
        pass
    else:
        raise Exception("test fail")


# Generated at 2022-06-23 05:52:09.510601
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    avu = AnsibleVaultEncryptedUnicode(b'\x9a\xed\x8b\xdf\x1a\x92\x08')
    assert avu.encode('utf-8') == b'\xe2\x98\x83'
    assert avu.encode('utf-8', 'surrogateescape') == b'\xed\xa0\x83'
    assert avu.encode('utf-8', 'surrogatepass') == b'\xe2\x98\x83'
    assert avu.encode('utf-8', 'ignore') == b''
    assert avu.encode('utf-8', 'strict') == b''
    assert avu.encode('utf-8', 'replace') == b'?'

# Generated at 2022-06-23 05:52:12.692728
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    avue = AnsibleVaultEncryptedUnicode("foobar")
    avue.vault = vaultlib.VaultLib("password")
    assert avue.startswith("foo")


# Generated at 2022-06-23 05:52:20.462844
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    """Test that AnsibleVaultEncryptedUnicode.__add__() performs as expected.
    """

    def assert_AnsibleVaultEncryptedUnicode_add(primary, secondary, expected):
        """Assert that AnsibleVaultEncryptedUnicode primary.__add__(secondary) is expected.
        """
        assert (primary.__add__(secondary) == expected)

    # Test that we can perform string concatenation on an AnsibleVaultEncryptedUnicode instance.
    assert_AnsibleVaultEncryptedUnicode_add(
        AnsibleVaultEncryptedUnicode('abc'),
        'def',
        'abcdef')
