

# Generated at 2022-06-23 05:42:27.940066
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    test_string = b'Hello World!'
    test_vault = AnsibleVaultEncryptedUnicode(test_string)
    assert test_vault.rindex(b'o') == 8



# Generated at 2022-06-23 05:42:31.987033
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    from ansible.parsing import vault
    data = vault.VaultLib.new().encrypt('abc123', 'test')
    avueu = AnsibleVaultEncryptedUnicode(data)
    assert isinstance(avueu.__unicode__(), text_type)



# Generated at 2022-06-23 05:42:33.952594
# Unit test for method __mod__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___mod__():
    assert to_text("%s", (AnsibleVaultEncryptedUnicode("%s"),)) == to_text("%s")


# Generated at 2022-06-23 05:42:36.709535
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    plaintext_content = u'123456789'
    db = AnsibleVaultEncryptedUnicode(plaintext_content)
    assert db.rjust(20, '0') == u'000000000000123456789'


# Generated at 2022-06-23 05:42:47.591075
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    from ansible import errors
    from ansible.parsing.vault import VaultLib, VaultEditor
    from ansible.parsing.vault import VaultSecret, VaultPassword
    from ansible.parsing.vault import UnsafeText

    secret = 'mysecret'
    password = VaultPassword(None, None, secret)
    vault = VaultLib([password])
    ciphertext = vault.encrypt('testdata')
    avuu1 = AnsibleVaultEncryptedUnicode(ciphertext)
    avuu1.vault = vault
    avuu2 = AnsibleVaultEncryptedUnicode(b'testdata')
    avuu2.vault = vault
    assert avuu1 != avuu2
    assert avuu1 == avuu2

# Generated at 2022-06-23 05:42:54.218993
# Unit test for method format_map of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format_map():
    secret = b'abc'
    plaintext = b'This is a secret'
    vault = AnsibleVaultLib(secret)

    ciphertext = vault.encrypt(plaintext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    s = 'This is a {secret}'
    mapping = {'secret': avu}
    res = s.format_map(mapping)
    assert (plaintext.decode('utf-8') in res)


# Generated at 2022-06-23 05:42:56.627428
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    '''
    the variable 'seq' should be an instance of AnsibleSequence
    '''
    assert isinstance(seq, AnsibleSequence)



# Generated at 2022-06-23 05:42:59.929764
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('abc', None, 'secret')
    assert avu.rjust(10).startswith('       abc')
    assert avu.rjust(10, '_').startswith('______abc')



# Generated at 2022-06-23 05:43:03.198062
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    sequence = AnsibleVaultEncryptedUnicode("zzzaaaaaaz")

    assert sequence.rfind('z') == 5
    # The line below produces an error!
    #sequence.vault = vaultlib.VaultLib()

    #assert sequence.vault.decrypt(sequence) == 'zzzaaaaaaz'
    assert sequence.rfind('z') == 5
    #assert sequence.rfind('a') == 5

# Generated at 2022-06-23 05:43:11.020450
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    import pytest

    avu = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256;vault-user\n333432613037366432353439623036303664316465383338343966306162663533626262643737\n393961386131386431613262656365343661303839383538666533656434383364396531613930\n643162393663326436356438656339393037666330333262633732357d")

# Generated at 2022-06-23 05:43:22.903357
# Unit test for constructor of class AnsibleBaseYAMLObject
def test_AnsibleBaseYAMLObject():
    from ansible.module_utils.basic import AnsibleModule

    EXPECTED_ANSIBLE_POS = ('/tmp/foo', 1, 2)

    class FakeModule(object):
        ''' Fake class to provide a basic module arg spec'''
        def __init__(self):
            self.argument_spec = dict(data=dict(type='str'))
            self.warnings = []

    class FakeAnsibleModule(AnsibleModule):
        ''' Fake class to provide a basic module object'''
        def __init__(self):
            self.params = {'data': 'foo'}
            self.check_mode = False
            self.debug = True
            self.fail_json = False
            self.exit_json = False
            self.run_command = False


# Generated at 2022-06-23 05:43:29.143008
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    import ansible.parsing.vault as vault
    my_vault = vault.VaultLib([])

    me = AnsibleVaultEncryptedUnicode.from_plaintext('adam', my_vault, 'adam')
    me.vault = my_vault
    assert me.title() == 'Adam'
    assert me == 'adam'


# Generated at 2022-06-23 05:43:39.751284
# Unit test for method zfill of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_zfill():
    # Test the zfill method of the AnsibleVaultEncryptedUnicode class
    # If a string is shorter than the given width, it will be padded with leading zeros

    # Test case 1: testing normally
    # Test if the method returns the same result as the method of the same name in python string class
    test_str_1 = '12300'
    width_1 = 10
    test_str_result_1 = '000012300'
    assert((AnsibleVaultEncryptedUnicode(test_str_1)).zfill(width_1) == test_str_result_1)

    # Test case 2: testing normally
    # Test if the method returns the same result as the method of the same name in python string class
    test_str_2 = '000'
    width_2 = 2
    test_str_result_

# Generated at 2022-06-23 05:43:49.611094
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # Test encrypted string
    text = '$ANSIBLE_VAULT;1.1;AES256'
    avu = AnsibleVaultEncryptedUnicode(text)
    assert avu.is_encrypted()

    # Test plaintext string
    text = 'plaintext'
    avu = AnsibleVaultEncryptedUnicode(text)
    assert not avu.is_encrypted()

    # Test with an empty string
    avu = AnsibleVaultEncryptedUnicode('')
    assert not avu.is_encrypted()

    # Test with a real vault
    vault = VaultLib('password')
    text = 'plaintext'

# Generated at 2022-06-23 05:43:53.774602
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    assert 'foo'.__radd__('bar') == 'bar' + 'foo'
    assert AnsibleVaultEncryptedUnicode('foo').__radd__('bar') == 'bar' + 'foo'


# Generated at 2022-06-23 05:44:00.978378
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    for source in [b'ansible', b'ansible:vault']:
        avu = AnsibleVaultEncryptedUnicode(source)
        assert isinstance(avu.partition(b':'), tuple)
        assert len(avu.partition(b':')) == 3
        assert isinstance(avu.partition(b':')[0], text_type)
        assert isinstance(avu.partition(b':')[1], text_type)
        assert isinstance(avu.partition(b':')[2], text_type)
        assert avu.partition(b':') == (avu.partition(b':')[0], avu.partition(b':')[1], avu.partition(b':')[2])



# Generated at 2022-06-23 05:44:08.787242
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    assert AnsibleVaultEncryptedUnicode('1') + AnsibleVaultEncryptedUnicode('2') == '12'
    assert AnsibleVaultEncryptedUnicode('1') + '2' == '12'



# Generated at 2022-06-23 05:44:17.917358
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    assert AnsibleVaultEncryptedUnicode('a').rindex('a') == 0
    assert AnsibleVaultEncryptedUnicode('a').rindex('a', 0, 1) == 0
    assert AnsibleVaultEncryptedUnicode('a').rindex('a', 0, 0) == 0
    assert AnsibleVaultEncryptedUnicode('a').rindex('a', 0, -1) == 0
    assert AnsibleVaultEncryptedUnicode('a').rindex('a', 0, -2) == 0
    assert AnsibleVaultEncryptedUnicode('a').rindex('a', 0, -3) == -1
    assert AnsibleVaultEncryptedUnicode('ab').rindex('a', 0, -1) == 0
    assert AnsibleVaultEncryptedUnicode('b').rindex

# Generated at 2022-06-23 05:44:22.525747
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    # Setup
    obj = AnsibleVaultEncryptedUnicode(u'1.5')

    # Exercise
    float_value = float(obj)

    # Verify
    assert float_value == 1.5

    # Cleanup - none necessary



# Generated at 2022-06-23 05:44:28.460180
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    aveu = AnsibleVaultEncryptedUnicode('abcdef')
    aveu.vault = None
    assert(aveu.title() == 'Abcdef')

yaml_loader.add_constructor(u'tag:yaml.org,2002:python/unicode', yaml_loader.construct_yaml_unicode)

YAML_LITERAL_PATTERN = u'\n|\r\n|\r|\x85|\u2028|\u2029'
YAML_LITERAL_REGEXP = re.compile(YAML_LITERAL_PATTERN)

YAML_FOLD_PATTERN = u'[^\S\n]{2,}'

# Generated at 2022-06-23 05:44:40.251130
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    # Try some unicode
    x = AnsibleUnicode(u'\u00e9')
    assert isinstance(x, AnsibleUnicode)
    assert x == u'\u00e9'
    assert not isinstance(x, to_text(u'\u00e9'))

    # Try some regular text
    x = AnsibleUnicode('abc')
    assert isinstance(x, AnsibleUnicode)
    assert x == u'abc'
    assert not isinstance(x, 'abc')

    # Try some bytes
    x = AnsibleUnicode(b'\xc3\xa9')
    assert isinstance(x, AnsibleUnicode)
    assert x == u'\u00e9'

# Generated at 2022-06-23 05:44:48.071374
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    # This test is a copy from Lib/test/test_str.py
    # with a modification that also uses a AnsibleVaultEncryptedUnicode as needle
    S = AnsibleVaultEncryptedUnicode
    basic_needles = [S(''),S('a'),S('b'),S('c'),S('ab'),S('bc'),S('abc')]
    unicode_needles = [S('\u3042'),S('\u3044'),S('\u3046'),S('\u3048')]
    all_needles = basic_needles + unicode_needles

# Generated at 2022-06-23 05:44:56.494367
# Unit test for method isdecimal of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdecimal():
    from crypt import Crypt
    from ansible.plugins.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    secret = VaultSecret('some_password')
    password = secret.get_secret()
    cipher_suite = Crypt.get_cipher(VaultEditor.get_configuration().cipher)
    vault = VaultLib([password], cipher_suite)
    vi = VaultEditor(vault, '', force_editor=None, filenames=[])
    avue = AnsibleVaultEncryptedUnicode.from_plaintext('', vault, password)
    assert(avue.isdecimal() == False)

# Generated at 2022-06-23 05:45:01.343488
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    assert AnsibleVaultEncryptedUnicode("FOO").isupper() == True
    assert AnsibleVaultEncryptedUnicode("Foo").isupper() == False
    assert AnsibleVaultEncryptedUnicode("").isupper() == False


# Generated at 2022-06-23 05:45:05.337101
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    avu = AnsibleVaultEncryptedUnicode("abc")
    assert avu.islower()
    avu = AnsibleVaultEncryptedUnicode("abcABC")
    assert not avu.islower()


# Generated at 2022-06-23 05:45:15.103424
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    s = AnsibleVaultEncryptedUnicode('0')
    assert s.isdigit()
    s = AnsibleVaultEncryptedUnicode('09')
    assert s.isdigit()
    s = AnsibleVaultEncryptedUnicode('1')
    assert s.isdigit()
    s = AnsibleVaultEncryptedUnicode('9')
    assert s.isdigit()
    s = AnsibleVaultEncryptedUnicode('')
    assert not s.isdigit()
    s = AnsibleVaultEncryptedUnicode('a')
    assert not s.isdigit()
    s = AnsibleVaultEncryptedUnicode('-1')
    assert not s.isdigit()
    s = AnsibleVaultEncryptedUnicode('3.14')

# Generated at 2022-06-23 05:45:26.808093
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    error_msg = "Method isdigit() of class AnsibleVaultEncryptedUnicode not working as expected"

    avue = AnsibleVaultEncryptedUnicode(b'0123456789')
    assert avue.isdigit() == True, error_msg

    avue = AnsibleVaultEncryptedUnicode(b'foo')
    assert avue.isdigit() == False, error_msg

    avue = AnsibleVaultEncryptedUnicode(b'foo')
    avue.data = '0123456789'
    assert avue.isdigit() == True, error_msg


# Generated at 2022-06-23 05:45:37.263941
# Unit test for method capitalize of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_capitalize():
    assert AnsibleVaultEncryptedUnicode('').capitalize() == ''
    assert AnsibleVaultEncryptedUnicode('h').capitalize() == 'H'
    assert AnsibleVaultEncryptedUnicode('hello').capitalize() == 'Hello'
    assert AnsibleVaultEncryptedUnicode('Hello').capitalize() == 'Hello'
    assert AnsibleVaultEncryptedUnicode('HELLO').capitalize() == 'Hello'
    assert AnsibleVaultEncryptedUnicode('\xbc').capitalize() == '\xbc'
    assert AnsibleVaultEncryptedUnicode('\xbc\xff').capitalize() == '\xbc\xff'
    assert AnsibleVaultEncryptedUnicode('\xa1').capitalize() == '\xa1'
    assert AnsibleVaultEnc

# Generated at 2022-06-23 05:45:44.175301
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    assert "abcd" == AnsibleVaultEncryptedUnicode("abcd").istitle()
    assert "aBcd" == AnsibleVaultEncryptedUnicode("aBcd").istitle()
    assert "Abcd" == AnsibleVaultEncryptedUnicode("Abcd").istitle()
    assert "ABCd" == AnsibleVaultEncryptedUnicode("ABCd").istitle()
    assert "ABCD" == AnsibleVaultEncryptedUnicode("ABCD").istitle()


# Generated at 2022-06-23 05:45:49.906787
# Unit test for method center of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_center():
    avueu = AnsibleVaultEncryptedUnicode(b'data')
    assert avueu.center(width=20, fillchar=None) == '        data        '
    assert avueu.center(width=20, fillchar='*') == '*******data********'


# Generated at 2022-06-23 05:45:52.309344
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    assert AnsibleVaultEncryptedUnicode("abc").join(["def", 3]) == "abcdef3"


# Generated at 2022-06-23 05:45:55.428781
# Unit test for method splitlines of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_splitlines():
    avu = AnsibleVaultEncryptedUnicode('one\ntwo\nthree')
    assert avu.splitlines() == ['one', 'two', 'three']

# Generated at 2022-06-23 05:45:57.244065
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    if 'lower' in dir(AnsibleVaultEncryptedUnicode):
        assert True
    else:
        assert False




# Generated at 2022-06-23 05:46:01.238566
# Unit test for constructor of class AnsibleSequence
def test_AnsibleSequence():
    seq = AnsibleSequence(['a', 'b', 'c'])
    assert len(seq) == 3
    assert seq[0] == 'a'
    assert seq[1] == 'b'
    assert seq[2] == 'c'


# Generated at 2022-06-23 05:46:09.580155
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # Add serveral tests
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(None)

    # AnsibleVaultEncryptedUnicode object
    assert ansible_vault_encrypted_unicode.__lt__(ansible_vault_encrypted_unicode) == False
    assert ansible_vault_encrypted_unicode.__lt__(None) == False

    # Text object
    assert ansible_vault_encrypted_unicode.__lt__('test') == False


# Generated at 2022-06-23 05:46:14.618092
# Unit test for method isascii of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isascii():
    assert AnsibleVaultEncryptedUnicode('foo').isascii()
    assert not AnsibleVaultEncryptedUnicode('föö').isascii()
    assert not AnsibleVaultEncryptedUnicode('ÄÖ').isascii()
    assert not AnsibleVaultEncryptedUnicode('€').isascii()



# Generated at 2022-06-23 05:46:23.090136
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    import ansible.parsing.vault
    test_strings = [
        'AAAA',
        u'AAAA',
        'AAAA',
        'BBBB',
        'CCCC',
        'DDDD',
    ]
    vault = ansible.parsing.vault.VaultLib('hunter2')
    vault_strings = [
        'AAAA',
        u'AAAA',
        'AAAA',
        'BBBB',
        'CCCC',
        'DDDD',
    ]
    plaintext = [
        'AAAA',
        'AAAA',
        'AAAA',
        'BBBB',
        'CCCC',
        'DDDD',
    ]
    for i in range(len(vault_strings)):
        vault_strings[i] = AnsibleVaultEncryptedUnicode.from_plain

# Generated at 2022-06-23 05:46:28.089607
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('hello world', None, None)
    assert avu.partition(' ') == ('hello', ' ', 'world')
    assert avu.partition('x') == ('hello world', '', '')


# Generated at 2022-06-23 05:46:36.567757
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    assert ''.__reversed__() == AnsibleVaultEncryptedUnicode('').__reversed__()
    assert 'a'.__reversed__() == AnsibleVaultEncryptedUnicode('a').__reversed__()
    assert 'abc'.__reversed__() == AnsibleVaultEncryptedUnicode('abc').__reversed__()
    assert 'abcdefghijklmnopqrstuvwxyz'.__reversed__() == AnsibleVaultEncryptedUnicode('abcdefghijklmnopqrstuvwxyz').__reversed__()


# Generated at 2022-06-23 05:46:47.827795
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    yaml_data = """
    - host: localhost
      block: |
        foo: "{{ vault_reversed_string }}"
      tasks: []
    """

    data = {}
    data['vault_reversed_string'] = AnsibleVaultEncryptedUnicode(b'olleH!')

    class MockVault(object):
        def is_encrypted(self, blob):
            return False

        def decrypt(self, blob, obj=None):
            return blob

        def encrypt(self, blob, secret):
            return blob

    mock_vault = MockVault()
    data['vault_reversed_string'].vault = mock_vault

    data = yaml.load(yaml_data, Loader=yaml.SafeLoader)

# Generated at 2022-06-23 05:46:57.753395
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    avu1 = AnsibleVaultEncryptedUnicode('foo')
    avu2 = AnsibleVaultEncryptedUnicode('bar')
    avu3 = avu1 + avu2
    assert avu3 == AnsibleVaultEncryptedUnicode('foobar')
    assert avu1 + 'bar' == 'foobar'
    assert 'bar' + avu1 == 'barfoo'
    assert avu1 + b'bar' == 'foobar'
    assert avu1 + b'bar'.decode('utf-8') == 'foobar'


# Generated at 2022-06-23 05:47:04.078132
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    '''
    Test the class method rsplit.
    '''
    avu = AnsibleVaultEncryptedUnicode('abc')
    assert type(avu.rsplit()) is list
    assert type(avu.rsplit(maxsplit=1)) is list
    assert type(avu.rsplit(sep='a')) is list
    assert type(avu.rsplit(sep='a', maxsplit=1)) is list


# Generated at 2022-06-23 05:47:15.132572
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    avue = AnsibleVaultEncryptedUnicode(ciphertext='')
    try:
        avue.rstrip()
    except AttributeError as e:
        assert False, "Failed to rstrip (1): %s" % str(e)
    except Exception as e:
        assert False, "Failed to rstrip (2): %s" % str(e)

    avue = AnsibleVaultEncryptedUnicode(ciphertext='abc')
    try:
        avue.rstrip()
    except AttributeError as e:
        assert False, "Failed to rstrip (3): %s" % str(e)
    except Exception as e:
        assert False, "Failed to rstrip (4): %s" % str(e)


# Generated at 2022-06-23 05:47:23.310068
# Unit test for method translate of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_translate():
    AVEU = AnsibleVaultEncryptedUnicode(u"Hello")
    assert AVEU.translate(None, u"e") == "Hllo"
    AVEU = AnsibleVaultEncryptedUnicode("Hello")
    assert AVEU.translate(None, "e") == "Hllo"
    AVEU = AnsibleVaultEncryptedUnicode(u"Hello")
    assert AVEU.translate(None, u"e") == "Hllo"

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# end class AnsibleVaultEncryptedUnicode



# Generated at 2022-06-23 05:47:27.257550
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    assert str(AnsibleVaultEncryptedUnicode(b'\xc2\xa2')) == '¢'



# Generated at 2022-06-23 05:47:37.244458
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # This is the string
    # "Bring me some beer or leave this place."
    # as bytes encoded in UTF-8
    # according to https://www.bytes.com/topic/python/answers/128069-how-display-utf-8-string-utf-8-encoding
    # taking the UTF-8 encoding of this string
    # and replacing each '0' with '\0',
    # and returning the resulting bytes object
    # results in the original bytes object
    # (so the '0' in UTF-8 encoding is a \0 in python)
    s = """Bring me some beer or leave this place."""
    b = b"Bring me some \xc3\xa0 beer or leave this place."
    v = AnsibleVaultEncryptedUnicode(b)
    assert v == s

# Generated at 2022-06-23 05:47:44.140457
# Unit test for method islower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_islower():
    a = AnsibleVaultEncryptedUnicode.from_plaintext(u'aBcDefG', None, None)
    assert a.islower()

    b = AnsibleVaultEncryptedUnicode.from_plaintext(u'ABCDEFG', None, None)
    assert not b.islower()

test_AnsibleVaultEncryptedUnicode_islower()


# Generated at 2022-06-23 05:47:47.059147
# Unit test for method rstrip of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rstrip():
    test_value = AnsibleVaultEncryptedUnicode(b'foobar\x00\x01\x02')
    expected_value = AnsibleVaultEncryptedUnicode(b'foobar')
    assert test_value.rstrip(b'\x00\x01\x02') == expected_value



# Generated at 2022-06-23 05:47:51.758499
# Unit test for method encode of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_encode():
    avu = AnsibleVaultEncryptedUnicode(to_bytes('foo'))
    assert avu.encode('us-ascii') == to_bytes('foo')
    assert avu.encode('ascii') == to_bytes('foo')
    assert avu.encode('utf-8') == to_bytes('foo')



# Generated at 2022-06-23 05:48:02.752738
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    # 'isidentifier' is a new method in Python 3.0.
    # See Issue #7627.
    from ansible.parsing.vault import VaultLib

    v = VaultLib([], 'secret')
    s = AnsibleVaultEncryptedUnicode.from_plaintext('one', v, 'secret')
    assert s.isidentifier() is False
    s = AnsibleVaultEncryptedUnicode.from_plaintext('o', v, 'secret')
    assert s.isidentifier() is False
    s = AnsibleVaultEncryptedUnicode.from_plaintext('one2', v, 'secret')
    assert s.isidentifier() is True
    s = AnsibleVaultEncryptedUnicode.from_plaintext('_one', v, 'secret')
    assert s.isidentifier

# Generated at 2022-06-23 05:48:07.553960
# Unit test for method partition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_partition():
    avu = AnsibleVaultEncryptedUnicode("adfsadfssss")
    t = avu.partition("s")
    assert t == ("adf", "s", "adfssss")

# Generated at 2022-06-23 05:48:12.487906
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    from ansible.parsing.vault import VaultLib
    vault_password = 'secret'
    vault = VaultLib(vault_password)
    encrypted_str = AnsibleVaultEncryptedUnicode.from_plaintext('123', vault, vault_password)
    assert complex(encrypted_str) == complex(123)


# Generated at 2022-06-23 05:48:19.354651
# Unit test for method casefold of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_casefold():
    # It is only possible to test this with python 3.3 and newer
    #
    # This function is required to be present and work with unicode objects
    # which is not possible with python 2.7 and it is not possible to
    # define it as unicode only.
    #
    # See https://github.com/ansible/ansible/issues/24878
    # and https://github.com/ansible/ansible/issues/25643
    if sys.version_info >= (3, 3):
        avu = AnsibleVaultEncryptedUnicode("ÀÐÑ")
        assert avu == avu.casefold() == "àðñ"
        assert "ÀÐÑ" == avu.casefold()



# Generated at 2022-06-23 05:48:31.400243
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    # List of possible valid identifiers
    list_str = [
        "this",
        "is",
        "a",
        "list",
        "of",
        "str",
        ]
    # Create a list of AnsibleVaultEncryptedUnicode object
    list_avu = [
        AnsibleVaultEncryptedUnicode(s) for s in list_str
        ]
    # Using itertools.permutations we can generate all possible permutations
    # of the list of AnsibleVaultEncryptedUnicode objects, then we check
    # if the result is a valid identifier
    from itertools import permutations
    import string
    n = len(list_avu)

# Generated at 2022-06-23 05:48:40.625094
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    import pytest
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('123')
    a = AnsibleVaultEncryptedUnicode.from_plaintext('mystr1', vault, 'foo')
    b = AnsibleVaultEncryptedUnicode.from_plaintext('mystr1', vault, 'foo')
    assert a.__ge__(b) == True, 'AnsibleVaultEncryptedUnicode.__ge__() should return True if the strings are equal'
    b = AnsibleVaultEncryptedUnicode.from_plaintext('mystr2', vault, 'foo')
    assert a.__ge__(b) == False, 'AnsibleVaultEncryptedUnicode.__ge__() should return False if the right-side string is alphabetically greater than the left'


# Generated at 2022-06-23 05:48:49.074806
# Unit test for method __str__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___str__():
    assert isinstance(str(AnsibleVaultEncryptedUnicode("foo")), str)
    assert isinstance(to_text(AnsibleVaultEncryptedUnicode("foo")), text_type)

    if _sys.version_info.major < 3:
        assert isinstance(unicode(AnsibleVaultEncryptedUnicode("foo")), unicode)
        assert isinstance(AnsibleVaultEncryptedUnicode("foo").encode("utf-8"), str)



# Generated at 2022-06-23 05:48:56.158223
# Unit test for method isnumeric of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isnumeric():
    input_isnumeric = [
        ('¹²³①②③', True),
        ('ⅠⅡⅢ', True),
        ('ⅰⅱⅲ', True),
        ('⒈⒉⒊', True),
        ('⑴⑵⑶', True),
        ('①②③', True),
    ]
    for test_data, expected in input_isnumeric:
        actual = AnsibleVaultEncryptedUnicode(test_data)
        assert actual.isnumeric() == expected



# Generated at 2022-06-23 05:49:05.828555
# Unit test for constructor of class AnsibleUnicode
def test_AnsibleUnicode():
    obj = AnsibleUnicode(u'foobarbaz')
    assert obj.startswith(u'foo')
    assert not obj.startswith('foo')
    assert not obj.startswith(u'baz')
    assert obj.endswith(u'baz')
    assert not obj.endswith(u'bar')
    assert obj.find(u'bar') == 3
    assert obj.rfind(u'bar') == 3
    assert obj.index(u'baz') == 6
    assert obj.rindex(u'baz') == 6
    assert u'test' in obj
    assert u'foobar' in obj
    assert len(obj) == 9
    assert obj[:3] == u'foo'
    assert obj[3:6] == u'bar'
    assert obj

# Generated at 2022-06-23 05:49:09.716261
# Unit test for method title of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_title():
    text = AnsibleVaultEncryptedUnicode('hello world')
    assert text.title() == 'Hello World'



# Generated at 2022-06-23 05:49:19.289739
# Unit test for method istitle of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_istitle():
    # note the different character here:
    #  U+00AD SOFT HYPHEN
    #  U+2010 HYPHEN
    #  U+002D HYPHEN-MINUS
    #  U+058A ARMENIAN HYPHEN
    #  U+1806 MONGOLIAN TODO SOFT HYPHEN
    #  U+2012 FIGURE DASH
    #  U+2013 EN DASH
    #  U+2014 EM DASH
    #  U+FE58 SMALL EM DASH
    #  U+FE63 SMALL HYPHEN-MINUS
    #  U+FF0D FULLWIDTH HYPHEN-MINUS
    assert u'\u00ad'.istitle() # False
    assert u'\u2010'.istitle() # False
    assert u'\u002d'.istitle

# Generated at 2022-06-23 05:49:24.818305
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu   = AnsibleVaultEncryptedUnicode('abcdefghij')
    avu1  = AnsibleVaultEncryptedUnicode('abcdefghij')
    avu2  = AnsibleVaultEncryptedUnicode('ABCDEFGHIJ')
    if avu != avu1:
        raise AssertionError()
    if avu == avu2:
        raise AssertionError()

_mutable_types = (list, set, dict, AnsibleSequence, AnsibleMapping)


# Generated at 2022-06-23 05:49:27.792285
# Unit test for method format of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_format():
    text = AnsibleVaultEncryptedUnicode('xx{0}xx{1}xx', None, '')
    assert text.format('0', '1') == 'xx0xx1xx'


# Generated at 2022-06-23 05:49:37.967191
# Unit test for method isspace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isspace():
    x = AnsibleVaultEncryptedUnicode(' ')
    assert x.isspace()
    x = AnsibleVaultEncryptedUnicode('\t')
    assert x.isspace()
    x = AnsibleVaultEncryptedUnicode('\n')
    assert x.isspace()
    x = AnsibleVaultEncryptedUnicode('\r')
    assert x.isspace()
    x = AnsibleVaultEncryptedUnicode('\r\n')
    assert x.isspace()
    x = AnsibleVaultEncryptedUnicode('')
    assert not x.isspace()
    x = AnsibleVaultEncryptedUnicode('a')
    assert not x.isspace()
    x = AnsibleVaultEncryptedUnicode(' ' * 10)
    assert x.iss

# Generated at 2022-06-23 05:49:42.856331
# Unit test for method startswith of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_startswith():
    # test example from: https://docs.python.org/3/library/stdtypes.html#str.startswith
    v = AnsibleVaultEncryptedUnicode("xxabcxx")
    assert v.startswith("abc")



# Generated at 2022-06-23 05:49:49.874434
# Unit test for method isdigit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isdigit():
    avu = AnsibleVaultEncryptedUnicode(to_text(u"1234"))
    assert avu.isdigit()

    avu = AnsibleVaultEncryptedUnicode(to_text(u"1234ABC"))
    assert not avu.isdigit()

    avu = AnsibleVaultEncryptedUnicode(to_text(u"ABC1234"))
    assert not avu.isdigit()



# Generated at 2022-06-23 05:49:55.952297
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    class Vault:
        @staticmethod
        def decryt(cipher, obj):
            return 'a'
        def __init__(self, v):
            self.v = v

    v = Vault('b')
    aver = AnsibleVaultEncryptedUnicode.from_plaintext('a', v, '')
    aver.vault = v
    assert aver == 'a'
    assert aver != 'b'



# Generated at 2022-06-23 05:50:01.347081
# Unit test for method isupper of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isupper():
    a = AnsibleVaultEncryptedUnicode(b'Test A')
    assert a.isupper() is True
    assert a.islower() is False

    a = AnsibleVaultEncryptedUnicode(b'test A')
    assert a.isupper() is False
    assert a.islower() is True


# Generated at 2022-06-23 05:50:13.566404
# Unit test for method rsplit of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rsplit():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret = to_bytes('test')
    vault = VaultLib([])
    encrypted_string = AnsibleVaultEncryptedUnicode.from_plaintext(
        'foo:bar',
        vault=vault,
        secret=secret
    )

    # no arguments, rsplit should split on whitespace
    splitted_string = encrypted_string.rsplit()
    assert len(splitted_string) == 2
    assert splitted_string[0] == 'foo:'
    assert splitted_string[1] == 'bar'

    # no arguments, rsplit should split on whitespace

# Generated at 2022-06-23 05:50:19.684535
# Unit test for method __complex__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___complex__():
    avue = AnsibleVaultEncryptedUnicode('x')
    avue.data = '1+1j'
    assert complex('1+1j') == avue.__complex__()
    # check that text representation of complex number is converted to
    # a complex number first
    avue.data = '1 + 1j'
    assert complex('1+1j') == avue.__complex__()
    # check it works with floats as well
    avue.data = '1.0 + 1j'
    assert complex('1+1j') == avue.__complex__()


# Generated at 2022-06-23 05:50:32.366771
# Unit test for method isprintable of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isprintable():
    # Only tests non-ASCII characters
    # See https://docs.python.org/3/library/stdtypes.html#str.isprintable
    # and https://docs.python.org/3/library/stdtypes.html#str.encode
    avu = AnsibleVaultEncryptedUnicode('à')
    assert avu.isprintable()

    avu = AnsibleVaultEncryptedUnicode('\x11')
    assert not avu.isprintable()

    avu = AnsibleVaultEncryptedUnicode('\x7f')
    assert not avu.isprintable()

    avu = AnsibleVaultEncryptedUnicode('\x9f')
    assert not avu.isprintable()

    avu = AnsibleVaultEncryptedUnicode('\xa9')


# Generated at 2022-06-23 05:50:40.267956
# Unit test for method __radd__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___radd__():
    # unicode has a value
    s = u'abc'
    avu_s = AnsibleVaultEncryptedUnicode(s)
    # other is an AnsibleVaultEncryptedUnicode with a value
    o = u'xyz'
    avu_o = AnsibleVaultEncryptedUnicode(o)
    # expected adds the strings
    expected = s + o
    # result
    result = avu_s.__radd__(avu_o)
    # result should be equal to the expected value
    assert result == expected


# Generated at 2022-06-23 05:50:49.890443
# Unit test for method rindex of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rindex():
    plaintext = 'abcdefghtijklmnopqrstuvwxyz'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, MockVaultLib(), 'password')
    sub = 'fgh'
    assert avu.rindex(sub) == 5
    sub = 'klm'
    assert avu.rindex(sub) == 10
    sub = 'wxyz'
    assert avu.rindex(sub) == 22

MockVaultLib = namedtuple('MockVaultLib', ['encrypt', 'decrypt', 'is_encrypted'])
MockVaultLib.encrypt.__doc__ = 'Mock encrypt method of vaultlib'
MockVaultLib.decrypt.__doc__ = 'Mock decrypt method of vaultlib'
MockVault

# Generated at 2022-06-23 05:51:00.310877
# Unit test for method __float__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___float__():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.vault import VaultLib
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.vault import VaultSecret
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.vault import VaultAES256
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.vault import VaultAES256Ciphertext


# Generated at 2022-06-23 05:51:05.884707
# Unit test for method __unicode__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___unicode__():
    # This method is not fully tested
    # Only test on python2, python3 has a very different Unicode handling
    if _sys.version_info[0] < 3:
        expected = u'Hello World'
        b = AnsibleVaultEncryptedUnicode(u'Hello World')
        assert unicode(b) == expected
        assert b.__unicode__() == expected



# Generated at 2022-06-23 05:51:09.937645
# Unit test for method rjust of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rjust():
    obj = AnsibleVaultEncryptedUnicode(b'a')
    value = obj.rjust(2)
    assert value == b' a'


# Generated at 2022-06-23 05:51:14.520238
# Unit test for method isidentifier of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isidentifier():
    # this string is a valid identifier
    text_str = 'Ansible2'
    avu = AnsibleVaultEncryptedUnicode(text_str)
    assert avu.isidentifier() == True

    # this string is not a valid identifier
    text_str = '2Ansible'
    avu = AnsibleVaultEncryptedUnicode(text_str)
    assert avu.isidentifier() == False


# Generated at 2022-06-23 05:51:25.557941
# Unit test for method rpartition of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rpartition():
    from ansible.parsing.vault import VaultLib
    with open('test-vault', 'rb') as f:
        password = f.read().strip()
    vault = VaultLib(password)
    vault_encrypted_unicode_object = AnsibleVaultEncryptedUnicode.from_plaintext('dummy_data', vault, password)
    vault_encrypted_unicode_object._ciphertext = to_bytes('utBx1RC0LzfsIVQrHuBXqg==\n')
    assert(vault_encrypted_unicode_object.rpartition(":")[2] == to_text('dummy_data'))

# Generated at 2022-06-23 05:51:36.069025
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():

    def _assert_find(expected, find, *args, **kwargs):
        if isinstance(expected, Exception):
            with pytest.raises(Exception):
                find(*args, **kwargs)
        else:
            assert find(*args, **kwargs) == expected

    # Encrypted data
    s = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=object(), secret='secret')

    assert s.find('foo') == 0
    assert s.find('f') == 0
    assert s.find('o') == 1
    assert s.find('oo') == 1
    assert s.find('fo') == 0

    assert s.find('oo', end=1) == -1
    assert s.find('fo', end=1) == 0


# Generated at 2022-06-23 05:51:38.299776
# Unit test for method __reversed__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___reversed__():
    avu = AnsibleVaultEncryptedUnicode('abcdefg')
    assert 'gfedcba' == reversed(avu)


# Generated at 2022-06-23 05:51:46.903635
# Unit test for method join of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_join():
    class BrokenAnsibleVault():
        def decrypt(self, encrypted_data, obj=None):
            raise Exception('This is expected')

    avu = AnsibleVaultEncryptedUnicode('c2VjcmV0IGlk')
    avu.vault = BrokenAnsibleVault()

    try:
        avu.join(['c2VjcmV0IGFjY2VzcyBpZA==', '\n'])
    except:
        _, err, _ = _sys.exc_info()
        assert err.args[0] == 'This is expected'
        return

    assert False, 'Expected exception was not raised'


# Generated at 2022-06-23 05:51:55.040121
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    # When the sub string is not contained in AnsibleVaultEncryptedUnicode.
    assert AnsibleVaultEncryptedUnicode('test').count('z') == 0
    # When the sub string is contained in AnsibleVaultEncryptedUnicode.
    assert AnsibleVaultEncryptedUnicode('test').count('t') == 2
    # When the sub string is contained in AnsibleVaultEncryptedUnicode
    # and start is not zero.
    assert AnsibleVaultEncryptedUnicode('test').count('t', 1) == 1
    # When the sub string is contained in AnsibleVaultEncryptedUnicode
    # and end is not _sys.maxsize.
    assert AnsibleVaultEncryptedUnicode('test').count('t', 0, 3) == 2


# Generated at 2022-06-23 05:52:06.105738
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    PASSWORDS = ['abcd', 'wxyz']

    # Test is_encrypted() for unencrypted data
    t_data = 'This is my secret data'
    t_vault = VaultLib([PASSWORDS[0]])
    t_encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(t_data, t_vault, PASSWORDS[0])
    assert not t_encrypted.is_encrypted()

    # Test is_encrypted() for data encrypted with the wrong password
    t_data = 'This is my secret data'
    t_vault = VaultLib([PASSWORDS[1]])
    t_encrypted = AnsibleVaultEnc

# Generated at 2022-06-23 05:52:08.132099
# Unit test for method lower of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_lower():
    a = AnsibleVaultEncryptedUnicode("FOO")
    assert a.lower() == "foo"

# Generated at 2022-06-23 05:52:17.212197
# Unit test for method isalpha of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_isalpha():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultSecret

    secret = 'password'
    vault = VaultLib(
        [
            '--vault-id', 'test@prompt',
            '--vault-password-file', os.path.join(os.path.dirname(__file__), 'vault-password.txt'),
        ]
    )

    plaintext = 'abcXYZ123'
    ciphertext = vault.encrypt(plaintext, secret)

    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault

    assert avu.isalpha() == plaintext.isalpha()



# Generated at 2022-06-23 05:52:29.147149
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    iv = AnsibleVaultEncryptedUnicode('ABCDEF')
    assert 'A' in iv
    assert 'B' in iv
    assert 'C' in iv
    assert 'D' in iv
    assert 'E' in iv
    assert 'F' in iv
    assert 'H' not in iv
    assert 'X' not in iv
    assert 'Y' not in iv
    assert 'Z' not in iv

    iv2 = AnsibleVaultEncryptedUnicode('DXYZ')
    assert iv2 in iv
    assert 'D' in iv
    assert 'X' in iv
    assert 'Y' in iv
    assert 'Z' in iv
    assert 'A' not in iv
    assert 'C' not in iv
    assert 'E' not in iv
    assert 'F' not in iv

