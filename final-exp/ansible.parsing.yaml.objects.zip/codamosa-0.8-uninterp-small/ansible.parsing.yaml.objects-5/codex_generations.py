

# Generated at 2022-06-25 04:42:36.675460
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Setup
    obj = AnsibleVaultEncryptedUnicode('text')

    # Assertion
    assert obj > 'text' is False


# Generated at 2022-06-25 04:42:39.512692
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    # Not implemented
    pass


# Generated at 2022-06-25 04:42:44.515216
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    bool_0 = True
    bool_1 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_1)
    var_0 = ansible_vault_encrypted_unicode_0.__lt__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:42:47.219871
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # This method assume the value is encrypted, it should throw an error
    # when value is not encrypted
    with pytest.raises(AssertionError):
        test_case_0()


import unittest

# Generated at 2022-06-25 04:42:53.687708
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str())
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str())
    bool_0 = ansible_vault_encrypted_unicode_0.__contains__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:42:58.568703
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ge__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:43:02.282094
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_0.__contains__(None)


# Generated at 2022-06-25 04:43:07.510228
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Setup input parameters
    self_0 = AnsibleVaultEncryptedUnicode('{1}')
    other_0 = AnsibleVaultEncryptedUnicode('[c]')
    # Execute method
    result_0 = self_0.__gt__(other_0)
    assert result_0 == ('{1}' > '[c]')


# Generated at 2022-06-25 04:43:11.120647
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Create a AnsibleVaultEncryptedUnicode
    # array_2 = []
    # ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(array_2)

    # Call the method
    try:
        raise Exception("Test not implemented")
    except Exception as e:
        print("Exception:", e)


# Generated at 2022-06-25 04:43:19.963970
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a unicode value
    ansible_vault_encrypted_unicode_0_string = 'Vault string'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_0_string)
    ansible_vault_encrypted_unicode_1_string = 'Vault string'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_1_string)
    ansible_vault_encrypted_unicode_2_string = 'Vault string'
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_1_string)
    assert ansible

# Generated at 2022-06-25 04:43:35.231737
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Unicode like object that is not evaluated (decrypted) until it needs to be
    if _sys.version_info < (3, 0):
        class AnsibleVaultEncryptedUnicode:
            def __init__(self, ciphertext):
                pass

            def __add__(self, other):
                return other

    # inputs and expected outputs

# Generated at 2022-06-25 04:43:41.685062
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with valid values
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('vault_string')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('vault_string')
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1) is False

    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode('vault_string_1')
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_2) is True

    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode('vault_string')


# Generated at 2022-06-25 04:43:47.578859
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(bool_0)


# Generated at 2022-06-25 04:43:51.721502
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_1 = ansible_vault_encrypted_unicode_0 == bool_0


# Generated at 2022-06-25 04:43:52.573158
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass


# Generated at 2022-06-25 04:43:59.508845
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:44:02.708467
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    pass


# Generated at 2022-06-25 04:44:07.693535
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = True
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_1)
    var_0 = ansible_vault_encrypted_unicode_0 + ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:44:16.806012
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Test when exception is not thrown
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert var_0 == False
    # Test when exception is thrown
    try:
        bool_0 = True
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
        ansible_vault_encrypted_unicode_0.is_encrypted()
    except:
        var_1 = False
        assert var_1 == False


# Generated at 2022-06-25 04:44:20.896693
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(to_text(u'', errors='surrogate_or_strict'))
    ansible_vault_encrypted_unicode_0.data = to_text(u'', errors='surrogate_or_strict')
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:44:29.331543
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0 != 3.14


# Generated at 2022-06-25 04:44:33.175987
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:44:41.086549
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode("P")

# Generated at 2022-06-25 04:44:46.156374
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Create a new instance of the class under test
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()

    # Assert that the __eq__ method of the instance behaves as expected
    assert ansible_vault_encrypted_unicode_0.__eq__('str') == NotImplemented


# Generated at 2022-06-25 04:44:51.173487
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Check if the object is encrypted or not.
    # The object is not encrypted if the attribute vault is set to None.

    # The test is successful if the is_encrypted() method returns False in the above case.

    # Create an encrypted object
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("ciphertext")
    ansible_vault_encrypted_unicode_0.vault = None
    test_is_encrypted = ansible_vault_encrypted_unicode_0.is_encrypted()
    if(test_is_encrypted):
        raise Exception("Test case for method is_encrypted of class AnsibleVaultEncryptedUnicode Failed.")


# Generated at 2022-06-25 04:44:56.753074
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = True
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_1)
    bool_2 = ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:45:01.818589
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # No-op test with a return value
    # This is a stub that should be replaced with a real test
    # This is a regression test, which tests that
    # the method does not raise an exception
    try:
        AnsibleVaultEncryptedUnicode.__eq__()
    except:
        raise AssertionError("Method __eq__() raised ExceptionType unexpectedly!")
    return


# Generated at 2022-06-25 04:45:06.249486
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(bool_0)
    assert var_0 == False


# Generated at 2022-06-25 04:45:09.287993
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(False)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(bool_0)
    assert bool_0 == bool_0



# Generated at 2022-06-25 04:45:13.757336
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(b'cyber')
    # ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(b'cryptography')
    # var_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    pass


# Generated at 2022-06-25 04:45:19.374969
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.__getslice__(0, 0)


# Generated at 2022-06-25 04:45:22.748771
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = False
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:45:26.280728
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = False
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__("")


# Generated at 2022-06-25 04:45:32.831830
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:45:36.046917
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(str(1))

# Generated at 2022-06-25 04:45:40.678285
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Case 1:
    # Create a AnsibleVaultEncryptedUnicode object,
    # then set its value to False,
    # then find the value of an instance of class AnsibleVaultEncryptedUnicode
    # which is equal to the false value
    bool_0 = False
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(False)


# Generated at 2022-06-25 04:45:46.954497
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_0.data = True
    ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:45:51.664098
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_x = False
    ansible_vault_encrypted_unicode_x = AnsibleVaultEncryptedUnicode(bool_x)
    bool_y = True
    ansible_vault_encrypted_unicode_y = AnsibleVaultEncryptedUnicode(bool_y)
    ansible_vault_encrypted_unicode_x.__ne__(ansible_vault_encrypted_unicode_y)


# Generated at 2022-06-25 04:45:58.812647
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    int_0 = 1
    int_1 = 0
    float_0 = float(int_0)
    float_1 = float(int_1)
    int_2 = ansible_vault_encrypted_unicode_0.__getslice__(float_0, float_1)


# Generated at 2022-06-25 04:46:00.204607
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    v1 = AnsibleVaultEncryptedUnicode("password")
    v2 = AnsibleVaultEncryptedUnicode("password")

    assert v1 != v2


# Generated at 2022-06-25 04:46:08.768402
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = True
    assert ansible_vault_encrypted_unicode_0.__eq__(bool_1)
    ansible_vault_encrypted_unicode_0.data = False
    bool_2 = False
    assert ansible_vault_encrypted_unicode_0.__eq__(bool_2)
    ansible_vault_encrypted_unicode_0.data = True
    bool_3 = False
    assert not ansible_vault_encrypted_unicode_0.__eq__(bool_3)



# Generated at 2022-06-25 04:46:14.350421
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    if sys.version_info >= (3, 0):
        int_0 = 1234567890
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(int_0)
        var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:46:22.239256
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_0 = True
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_0)

    var_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)

    assert var_0, "Expected test case to pass but instead got %s" % str(var_0)


# Generated at 2022-06-25 04:46:25.991757
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    string = "test"
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(string)
    bool_0 = ansible_vault_encrypted_unicode_0 == string
    assert bool_0


# Generated at 2022-06-25 04:46:30.918082
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("")
    var_0 = ansible_vault_encrypted_unicode_0.__ne__("")
    print("var_0 = {}".format(var_0))


# Generated at 2022-06-25 04:46:34.455400
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(bool_0)
    assert var_0 == False


# Generated at 2022-06-25 04:46:37.261758
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    int_0 = ansible_vault_encrypted_unicode_0.__ne__(0)


# Generated at 2022-06-25 04:46:41.537019
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    bool_1 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(bool_1)


# Generated at 2022-06-25 04:46:45.090599
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    a = AnsibleVaultEncryptedUnicode('a')
    b = AnsibleVaultEncryptedUnicode('a')
    assert(a != b)



# Generated at 2022-06-25 04:46:48.907339
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:46:56.577380
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:47:00.323709
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = to_text(0.0)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    int_0 = ansible_vault_encrypted_unicode_0.__eq__(0)
    assert int_0 == 0


# Generated at 2022-06-25 04:47:03.133216
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:47:09.401472
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    try:
        bool_0 = True
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
        var_0 = ansible_vault_encrypted_unicode_0.__eq__(True)
    except Exception as var_1:
        pass


# Generated at 2022-06-25 04:47:12.056452
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:47:20.169209
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Tests that all elements of the class AnsibleVaultEncryptedUnicode are
    # equal

    try:
        # Setting up the test
        bool_0 = True
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
        ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_0)

        # Test
        var_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)

        # Assertion Error if test failed
    except AssertionError:
        print('Test Failed')
        sys.exit(1)

    # Return results if test passed
    print('Test Succeeded')
    sys.exit(0)



# Generated at 2022-06-25 04:47:24.333234
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = True
    var_0 = ansible_vault_encrypted_unicode_0 == bool_1


# Generated at 2022-06-25 04:47:30.947794
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    str_0 = "f4|"
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(str_0)
    print(bool_0)


# Generated at 2022-06-25 04:47:35.125786
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:47:39.064564
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dictionary_0 = {
        ('vault_pass', 'ansible vault pass'): ('foo')
    }
    string_0 = dictionary_0['vault_pass']
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode((dictionary_0['vault_pass']))
    ansible_vault_encrypted_unicode_0.vault = vault.VaultLib(string_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:47:48.668809
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("tRlCX9")
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode("tRlCX9")
    result = ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
    print("result:", result)


# Generated at 2022-06-25 04:47:50.595563
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:47:52.942072
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    print("Testing AnsibleVaultEncryptedUnicode.is_encrypted() ...")
    # Test 1
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:47:59.134536
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_0)
    var_0 = ansible_vault_encrypted_unicode_1.__eq__(ansible_vault_encrypted_unicode_0)
    print(var_0)


# Generated at 2022-06-25 04:48:03.105597
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_0 = False
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:48:03.736372
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass


# Generated at 2022-06-25 04:48:08.536811
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    # _ Python 2.7.5 (default, Aug  1 2019, 00:00:00) 
    # _ [GCC 4.8.5 20150623 (Red Hat 4.8.5-39)] on linux2
    # _ Type "help", "copyright", "credits" or "license" for more information.
    # >>> 
    # _ >>> from ansible.parsing.vault import ansible_vault_encrypted_unicode, test_case_0, test_AnsibleVaultEncryptedUnicode___ne__
    # _ >>> test_case_0()
    # _ >>> test_AnsibleVaultEncryptedUnicode___ne__()


# Generated at 2022-06-25 04:48:12.007862
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    func_0 = AnsibleVaultEncryptedUnicode()
    func_0.data = u'one two three'
    func_1 = AnsibleVaultEncryptedUnicode()
    func_1.data = u'one two three'
    assert func_0.__ne__(func_1) == False


# Generated at 2022-06-25 04:48:18.076363
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    bool_1 = bool_0
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_1)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:48:27.950234
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(3.4)
    dec_0 = -3.4
    var_1 = ansible_vault_encrypted_unicode_0.__ne__(dec_0)
    str_0 = 'april'
    var_2 = ansible_vault_encrypted_unicode_0.__ne__(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('april')

# Generated at 2022-06-25 04:48:39.278987
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'r9r5h5o5Q,#6U^y&,8I4P;o4D'
    bool_0 = False
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert var_0 == bool_0



# Generated at 2022-06-25 04:48:42.172564
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(True)


# Generated at 2022-06-25 04:48:45.301760
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:48:48.864956
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:48:50.421717
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    test_case_0()


# Generated at 2022-06-25 04:48:54.090379
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    str_0 = str()
    str_1 = str()
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(str_0)


# Generated at 2022-06-25 04:48:56.310301
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert True == True
    assert False == False


# Generated at 2022-06-25 04:49:00.152964
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = False
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:49:10.027493
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)
    var_1 = not ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    var_2 = var_0 == var_1
    if var_2:
        return True
    else:
        return False


# Generated at 2022-06-25 04:49:11.181510
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert ansible_vault_encrypted_unicode.__eq__(ansible_vault_encrypted_unicode, ansible_vault_encrypted_unicode)


# Generated at 2022-06-25 04:49:26.170906
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Test 1
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    # Test 2
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    str_0 = "c"
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted(str_0)
    # Test 3
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    str_0 = "b"
    var_0 = ansible_

# Generated at 2022-06-25 04:49:36.277430
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Tests that AnsibleVaultEncryptedUnicode.__eq__(other) detects equality
    # between itself and other AnsibleVaultEncryptedUnicode objects.
    ciphertext = b'encrypted!'
    vault = None
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ciphertext)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)
    assert var_0 == True



# Generated at 2022-06-25 04:49:39.038687
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:49:45.220399
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    seq = b'example'
    vault = None
    secret = b'passphrase'

    # Call method
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu == b'example'
    assert avu != b'example2'


# Generated at 2022-06-25 04:49:52.071785
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    string_0 = " !vault | "
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(string_0)
    ansible_vault_encrypted_unicode_0.vault = bool_0
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(string_0)
    ansible_vault_encrypted_unicode_1.vault = bool_0
    ansible_vault_encrypted_unicode_0.data = string_0
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert var_0 is False


# Generated at 2022-06-25 04:49:53.284350
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode.__eq__(False == True)


# Generated at 2022-06-25 04:49:56.389650
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:50:01.515311
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = ansible_vault_encrypted_unicode_0.__ne__(bool_0)


# Generated at 2022-06-25 04:50:05.268358
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    text_0 = "Yaml"
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(text_0)
    assert ansible_vault_encrypted_unicode_0.__ne__(text_0), "Failed to find text_0 in AnsibleVaultEncryptedUnicode instance"


# Generated at 2022-06-25 04:50:11.431246
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:50:24.803091
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = None
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(bool_0)


# Generated at 2022-06-25 04:50:27.454176
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(b'True')
    ansible_vault_encrypted_unicode_0.data = 'True'
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:50:36.888458
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # try to rerun function 3 times if test fails
    retry = 3
    while retry != 0:
        # create vault object
        vault_obj = vault.VaultLib('test/test_vars.yml')

        # create encrypted unicode string
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext(vault_obj.encrypt('test'), vault_obj, 'test')
        var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()

        # check if vault object was encrypted
        if var_0:
            break

        retry -= 1
    assert var_0 == True



# Generated at 2022-06-25 04:50:47.232132
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    assert(
        # Test with a string
        AnsibleVaultEncryptedUnicode("some-string").is_encrypted()
        ==
        False
    )

    assert(
        # Test with an integer
        AnsibleVaultEncryptedUnicode(123).is_encrypted()
        ==
        False
    )

    assert(
        # Test with a float
        AnsibleVaultEncryptedUnicode(3.456).is_encrypted()
        ==
        False
    )

    assert(
        # Test with a list
        AnsibleVaultEncryptedUnicode([1,2,3]).is_encrypted()
        ==
        False
    )


# Generated at 2022-06-25 04:50:53.601051
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = ansible_vault_encrypted_unicode_0 == bool_0
    assert bool_1 == False



# Generated at 2022-06-25 04:51:01.410792
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a variable
    string_0 = ""
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(string_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(string_0)

    # Test with a variable
    string_0 = ""
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(string_0)
    string_0 = "abc"
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(string_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:51:02.647425
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    test_case_0()


# Generated at 2022-06-25 04:51:08.847799
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = ansible_vault_encrypted_unicode_0.__eq__(bool_0)
    assert bool_1 is bool_0


# Generated at 2022-06-25 04:51:12.975418
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    bool_1 = True
    assert bool_0 is bool_1
    bool_2 = False
    assert var_0 is bool_2


# Generated at 2022-06-25 04:51:16.087949
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Create an instance of the class to be tested
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    # Create a new object to compare to
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    # Call the method under test
    ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:51:29.504903
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = False
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_1)
    try:
        bool_0 = ansible_vault_encrypted_unicode_1.__ne__(ansible_vault_encrypted_unicode_0)
    except AnsibleVaultError:
        bool_0 = True
    else:
        bool_0 = False


# Generated at 2022-06-25 04:51:37.699263
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    str_0 = 'fwefwefewf'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.data.is_encrypted()



# Generated at 2022-06-25 04:51:41.893257
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # This method validates AnsibleVaultEncryptedUnicode.__ne__(int)
    # and AnsibleVaultEncryptedUnicode.__ne__(str)
    int_0 = 2
    str_0 = 'Hello World!'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(int_0)
    var_1 = ansible_vault_encrypted_unicode_0.__ne__(str_0)

    assert var_0 == True and var_1 == False

test_AnsibleVaultEncryptedUnicode___ne__()


# Generated at 2022-06-25 04:51:44.565199
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(bool_0)


# Generated at 2022-06-25 04:51:50.676523
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:51:58.884924
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Given
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(100)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(99)

    # When
    boolean_0 = ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1

    # Then
    assert boolean_0


# Generated at 2022-06-25 04:52:03.187533
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:52:09.255081
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(None)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:52:11.860536
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:52:14.214618
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_0)
    var_0 = ansible_vault_encrypted_unicode_1.__eq__('True')
