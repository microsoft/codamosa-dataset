

# Generated at 2022-06-25 04:42:43.239024
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode.from_plaintext(u'foo', 'vault', 'secret')
    assert (ansible_vault_encrypted_unicode_1 == u'foo')

# Generated at 2022-06-25 04:42:44.127805
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    pass


# Generated at 2022-06-25 04:42:46.908190
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert AnsibleVaultEncryptedUnicode("string").is_encrypted() == False
    # add your test here


# Generated at 2022-06-25 04:42:48.371174
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    string_0 = AnsibleVaultEncryptedUnicode('')



# Generated at 2022-06-25 04:42:57.706960
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('ciphertext')
    setattr(ansible_vault_encrypted_unicode_0, 'vault', 'vault')
    ansible_vault_encrypted_unicode_0.data = 'data'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('ciphertext')
    setattr(ansible_vault_encrypted_unicode_1, 'vault', 'vault')
    ansible_vault_encrypted_unicode_1.data = 'data'
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:43:01.121225
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    assert ansible_vault_encrypted_unicode_0.__le__(str()) == False


# Generated at 2022-06-25 04:43:08.925315
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    # No value is set for attribute "data", so we should raise a ValueError exception
    with pytest.raises(ValueError):
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
        sub = 'foo'
        start = 0
        end = sys.maxsize
        ansible_vault_encrypted_unicode_0.rfind(sub, start, end)

ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('foo')


# Generated at 2022-06-25 04:43:10.870730
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    avu = AnsibleVaultEncryptedUnicode('A')
    assert avu.rfind('') == 1


# Generated at 2022-06-25 04:43:17.357831
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    obj = AnsibleVaultEncryptedUnicode.from_plaintext('test', vaultlib.VaultLib(), 'test')
    assert obj[1:3] == 'es'
    assert obj[:2] == 'te'
    assert obj[2:] == 'st'
    assert obj[-2:] == 'st'
    assert obj[:-2] == 'te'


# Generated at 2022-06-25 04:43:23.572019
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('abc')
    ansible_vault_encrypted_unicode_0.data = 'abc'
    ansible_vault_encrypted_unicode_0.vault = False
    assert not ansible_vault_encrypted_unicode_0.__ne__('abc')
    assert ansible_vault_encrypted_unicode_0.__ne__('abcd')
    assert ansible_vault_encrypted_unicode_0.__ne__('')


# Generated at 2022-06-25 04:43:43.031246
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode('')
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_unicode_1 = AnsibleUnicode('')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_1)
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:43:48.122177
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str())
    ansible_vault_encrypted_unicode_0.__class__.find(ansible_vault_encrypted_unicode_0, str())


# Generated at 2022-06-25 04:43:52.689786
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    result = ansible_vault_encrypted_unicode_0.find(' ')
    assert result == "0"


# Generated at 2022-06-25 04:44:03.814923
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.data = '2gyc@s'
    ansible_unicode_1 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_1)
    ansible_vault_encrypted_unicode_1.data = '5vw7/'
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)

# Generated at 2022-06-25 04:44:06.189262
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    ming = AnsibleVaultEncryptedUnicode("ming hei xu")
    mat = ming.find("t")
    assert (mat == -1)


# Generated at 2022-06-25 04:44:12.473386
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    ansible_unicode_0 = AnsibleUnicode(None)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.find('')


# Generated at 2022-06-25 04:44:21.333941
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.find()
    ansible_unicode_1 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0.find(ansible_unicode_1)
    ansible_vault_encrypted_unicode_0.find(ansible_unicode_0)


# Generated at 2022-06-25 04:44:28.644078
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.find(ansible_vault_encrypted_unicode_0)
    ansible_vault_encrypted_unicode_0.find(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:44:40.648616
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    # Variables
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('0')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('1')
    ansible_unicode_0 = AnsibleUnicode(ansible_vault_encrypted_unicode_0)
    ansible_unicode_1 = AnsibleUnicode(ansible_vault_encrypted_unicode_1)

    # Statement
    # Check our parsing
    # assert ansible_vault_encrypted_unicode_0 == '0'
    # assert ansible_vault_encrypted_unicode_1 == '1'
    # assert ansible_unicode_0 == '0'
    # assert ansible_unicode_1 == '1'
    #

# Generated at 2022-06-25 04:44:48.028287
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_1 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_1)
    ansible_vault_encrypted_unicode_1.vault = True
    ansible_vault_encrypted_unicode_1.data = True
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(ansible_unicode_1)
    ansible_vault_encrypted_unicode_2.vault = True
    ansible_vault_encrypted_unicode_2.data = None
    ansible_unicode_2 = AnsibleUnicode()
    ansible_unicode_2.ansible_pos = True
    ansible_unicode_3 = Ansible

# Generated at 2022-06-25 04:44:58.627809
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.data = "ansible.vault_encrypted_unicode_0 data"
    ansible_vault_encrypted_unicode_0_expected = False
    ansible_vault_encrypted_unicode_0_actual = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert ansible_vault_encrypted_unicode_0_actual == ansible_vault_encrypted_unicode_0_expected, "Test Case 0 Failed!"



# Generated at 2022-06-25 04:45:06.943858
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_4 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_5 = AnsibleVault

# Generated at 2022-06-25 04:45:11.732030
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:45:14.955856
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    assert ansible_vault_encrypted_unicode_0.__ne__('NE')


# Generated at 2022-06-25 04:45:21.313121
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_unicode_1 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_1)
    ansible_vault_encrypted_unicode_1.is_encrypted()


# Generated at 2022-06-25 04:45:26.010823
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    def __ne___default(self, string):
        pass

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(__ne___default)
    string_0 = to_text('^\xeb\xdd')

    ansible_vault_encrypted_unicode_0 != string_0


# Generated at 2022-06-25 04:45:33.776290
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:45:43.908642
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    # dummy vault
    class DummyVault(object):
        def __init__(self, password_string, secret):
            pass

        def encrypt(self, text, secret):
            return text

        def decrypt(self, encrypted_text, secret):
            return encrypted_text

        def is_encrypted(self, text):
            return True
    ansible_vault_encrypted_unicode_0.vault = DummyVault
    assert(ansible_vault_encrypted_unicode_0.is_encrypted())


# Generated at 2022-06-25 04:45:49.487469
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Setup
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_unicode_1 = AnsibleUnicode()

    # Test
    assert(ansible_vault_encrypted_unicode_0 == ansible_unicode_1)


# Generated at 2022-06-25 04:45:54.518916
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('this is a test')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('this is a test')
    assert not ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:46:04.649049
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.__ne__(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0)
    ansible_vault_encrypted_unicode_0.__ne__(0)


# Generated at 2022-06-25 04:46:08.994560
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    assert not ansible_vault_encrypted_unicode_0.__eq__("string")


# Generated at 2022-06-25 04:46:11.217411
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert AnsibleVaultEncryptedUnicode(AnsibleUnicode()).is_encrypted() == True

# Generated at 2022-06-25 04:46:18.235189
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    # FIXME: do we need to check the return type?
    ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:46:20.319617
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_unicode_0) == False


# Generated at 2022-06-25 04:46:22.337646
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()


# Generated at 2022-06-25 04:46:26.357631
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(u'The light of the moon is the light of the night.')
    result = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert result == False


# Generated at 2022-06-25 04:46:32.432850
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    test_str = '$ANSIBLE_VAULT;1.1;AES256'
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == ansible_vault_encrypted_unicode_0.vault.is_encrypted(test_str)


# Generated at 2022-06-25 04:46:39.753346
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('foo')
    ansible_vault_encrypted_unicode_0.data = 'bar'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('foo')
    ansible_vault_encrypted_unicode_1.data = 'baz'
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode('foo')
    ansible_vault_encrypted_unicode_2.data = 'bam'
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
    assert ans

# Generated at 2022-06-25 04:46:44.491154
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.__ne__(None)


# Generated at 2022-06-25 04:46:59.124222
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode()

    ansible_vault_encrypted_unicode_0.data = "abc"
    ansible_vault_encrypted_unicode_1.data = "abc"
    x = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert x != ansible_vault_encrypted_unicode_1.is_encrypted()
    assert x == ansible_vault_encrypted_unicode_2.is_encrypted()


# Generated at 2022-06-25 04:47:02.002077
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:47:10.874614
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.vault = ansible_unicode_0
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_1.vault = ansible_unicode_0
    ansible_vault_encrypted_unicode_0.data = ansible_unicode_0
    ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:47:20.015920
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_0 = vault.VaultLib()
    ansible_vault_encrypted_unicode_0.vault = ansible_vault_0
    ansible_vault_0.is_encrypted = mock.MagicMock()
    ansible_vault_0.is_encrypted.return_value = False
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == ansible_vault_0.is_encrypted.return_value
    ansible_vault_0.is_encrypted.assert_called_with(ansible_unicode_0)


# Generated at 2022-06-25 04:47:28.723156
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_unicode_1 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_1)
    ansible_vault_encrypted_unicode_1.vault = None
    assert ansible_vault_encrypted_unicode_1 != ansible_unicode_1


# Generated at 2022-06-25 04:47:33.115590
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.__ne__(ansible_unicode_0)


# Generated at 2022-06-25 04:47:38.245136
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.__ne__(ansible_unicode_0)


# Generated at 2022-06-25 04:47:44.729085
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)
    ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:47:50.019515
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    # Assigning variables
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    # Initializing instance attributes
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_0._ciphertext = b''
    # Getting the type of 'ansible_vault_encrypted_unicode_0' (line 9)
    ansible_vault_encrypted_unicode_0_247755 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 9, 0), 'ansible_vault_encrypted_unicode_0')
    # Setting the type of the member

# Generated at 2022-06-25 04:47:54.703906
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()

    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode()

    # Test either side of __eq__ is a AnsibleVaultEncryptedUnicode
    assert(ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1)

    # Test both sides of __eq__ is not a AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:48:09.464290
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('ciphertext')
    ansible_vault_encrypted_unicode_0.data = 'plaintext'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('ciphertext')
    ansible_vault_encrypted_unicode_1.data = 'plaintext'
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode('ciphertext')
    ansible_vault_encrypted_unicode_2.data = 'not_equal'
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode('ciphertext')

# Generated at 2022-06-25 04:48:12.463401
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:48:17.333487
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('test_value')
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:48:27.533002
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode.from_plaintext(ansible_vault_encrypted_unicode_0, ansible_vault_encrypted_unicode_0, ansible_vault_encrypted_unicode_0)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode.from_plaintext(ansible_vault_encrypted_unicode_0, ansible_vault_encrypted_unicode_1, ansible_vault_encrypted_unicode_0)

# Generated at 2022-06-25 04:48:30.867052
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0, ansible_unicode_0)
    ansible_vault_encrypted_unicode_1 = is_encrypted(ansible_vault_encrypted_unicode_0)
    ansible_vault_encrypted_unicode_2 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:48:38.095579
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    unicode_0 = u'\x7a'
    assert not ansible_vault_encrypted_unicode_0.__eq__(unicode_0)  # AssertionError


# Generated at 2022-06-25 04:48:41.151220
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:48:44.619834
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    other = AnsibleUnicode()
    ansible_vault_encrypted_unicode_1 = ansible_vault_encrypted_unicode_0.__ne__(other)


# Generated at 2022-06-25 04:48:52.911634
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    if not ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1:
        print('FAIL. AnsibleVaultEncryptedUnicode.__eq__() returned False for True test case')
    else:
        print('PASS. AnsibleVaultEncryptedUnicode.__eq__() returned True for True test case')


# Generated at 2022-06-25 04:48:55.974190
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)

    ansible_vault_encrypted_unicode_0.__ne__(ansible_unicode_0)


# Generated at 2022-06-25 04:49:12.433004
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0._ciphertext = '5p5Vu*m'
    ansible_vault_encrypted_unicode_0.vault = AnsibleVaultLib('9Nl;H-Q')

    # Call AnsibleVaultEncryptedUnicode.__eq__
    ansible_vault_encrypted_unicode_0._ciphertext = 't._wjt'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.vault = AnsibleVaultLib('&)v4J')
    print(ansible_vault_encrypted_unicode_1)

# Generated at 2022-06-25 04:49:17.889875
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.vault = AnsibleVaultLib()
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:49:23.522398
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.__UNSAFE__ = False
    ansible_vault_encrypted_unicode_0.__ENCRYPTED__ = False
    if not ansible_vault_encrypted_unicode_0.__UNSAFE__ and not ansible_vault_encrypted_unicode_0.__ENCRYPTED__:
        return


# Generated at 2022-06-25 04:49:29.425353
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import UnsafeText
    ansible_vault_lib_0 = VaultLib(UnsafeText(''))
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(UnsafeText(''))
    ansible_vault_encrypted_unicode_0.vault = ansible_vault_lib_0
    ansible_vault_lib_0.is_encrypted = lambda arg_1, arg_2: True
    ansible_vault_encrypted_unicode_0.data = UnsafeText('')
    assert ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:49:36.868729
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1.vault = AnsibleVaultLib()
    ansible_vault_encrypted_unicode_1._ciphertext = to_bytes('')
    assert ansible_vault_encrypted_unicode_1.is_encrypted()


# Generated at 2022-06-25 04:49:39.972343
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_unicode_0)


# Generated at 2022-06-25 04:49:51.048129
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('3o')
    assert not ansible_vault_encrypted_unicode_0.__eq__('3o')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('3o')
    ansible_vault_encrypted_unicode_1.vault = not_a_vault
    assert not ansible_vault_encrypted_unicode_1.__eq__('3o')
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode('3o')
    ansible_vault_encrypted_unicode_2.vault = VaultLib(None, None, None)
    ansible_vault_encrypted_unicode_2.vault

# Generated at 2022-06-25 04:49:58.995110
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("Data Vault Test")
    ansible_vault_encrypted_unicode_is_encrypted_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    print("AnsibleVault Encrypted Data is %r" % ansible_vault_encrypted_unicode_is_encrypted_0)



# Generated at 2022-06-25 04:50:02.807080
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    assert ansible_unicode_0 == ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 04:50:08.981914
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    assert not ansible_vault_encrypted_unicode_0.__ne__(ansible_unicode_0)


# Generated at 2022-06-25 04:50:21.285519
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_1 = ansible_vault_encrypted_unicode_0
    assert ansible_vault_encrypted_unicode_1.__eq__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:50:28.926492
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_1 = ansible_vault_encrypted_unicode_0 == ansible_unicode_0
    assert ansible_vault_encrypted_unicode_1 == True
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_3 = ansible_vault_encrypted_unicode_2 == ansible_vault_encrypted_unicode_0
    assert ansible_vault_encrypted_unicode_3 == True
    ansible_vault_encrypted

# Generated at 2022-06-25 04:50:33.901946
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    assert ansible_vault_encrypted_unicode_0 == ansible_unicode_0


# Generated at 2022-06-25 04:50:44.336466
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_unicode_1 = AnsibleUnicode()
    ansible_unicode_2 = AnsibleUnicode()
    ansible_unicode_3 = AnsibleUnicode()
    ansible_unicode_4 = AnsibleUnicode()
    ansible_unicode_5 = AnsibleUnicode()
    ansible_unicode_6 = AnsibleUnicode()
    ansible_unicode_7 = AnsibleUnicode()
    ansible_unicode_8 = AnsibleUnicode()
    ansible_unicode_9 = AnsibleUnicode()
    ansible_unicode_10 = AnsibleUnicode()
    ansible_unicode_11 = AnsibleUnicode()
    ansible_unicode_

# Generated at 2022-06-25 04:50:50.754597
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(None)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:50:58.572698
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('salt')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ciphertext=None)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(ciphertext=False)
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode(ciphertext=0)
    ansible_vault_encrypted_unicode_4 = AnsibleVaultEncryptedUnicode(ciphertext=1234)
    ansible_vault_encrypted_unicode_5 = AnsibleVaultEncryptedUnicode(ciphertext='salt')

# Generated at 2022-06-25 04:51:05.792841
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.data = ansible_unicode_0

    # Test when other is not type AnsibleVaultEncryptedUnicode
    # Expect: True
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_unicode_0)


# Generated at 2022-06-25 04:51:09.492339
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(text_type())
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(None)

    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1) == False


# Generated at 2022-06-25 04:51:13.371695
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.data = 'foo'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1.data = 'foo'

    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:51:22.077668
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_1.vault = ansible_unicode_0
    assert (ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1)



# Generated at 2022-06-25 04:51:35.556436
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('abc')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('abc')

    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1) == False


# Generated at 2022-06-25 04:51:39.254191
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Initialize objects
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)

    # Check function return value
    assert ansible_vault_encrypted_unicode_0.is_encrypted() is False


# Generated at 2022-06-25 04:51:46.982033
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_4 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_5 = AnsibleVaultEncryptedUnicode()


# Generated at 2022-06-25 04:51:48.400136
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:51.544436
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_unicode_0) == ansible_unicode_0 == ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 04:52:01.347829
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_unicode_1 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_1)
    ansible_unicode_2 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(ansible_unicode_2)


# Generated at 2022-06-25 04:52:10.440275
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_4 = AnsibleVaultEncryptedUnicode()
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
    ansible_vault_encrypted_unicode_0.data = "ansible_vault_encrypted_unicode_1"
    ansible_vault_encrypted_unicode_0.v

# Generated at 2022-06-25 04:52:14.070388
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.data = ansible_unicode_0.data
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:52:19.473445
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    assert not AnsibleVaultEncryptedUnicode(ansible_unicode_0)
