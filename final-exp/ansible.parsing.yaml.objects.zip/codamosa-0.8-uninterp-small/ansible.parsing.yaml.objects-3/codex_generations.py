

# Generated at 2022-06-25 04:42:48.341088
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = bool_0
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_1)
    assert (ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1)



# Generated at 2022-06-25 04:42:52.995953
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = "r"
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.__ne__(str_0)


# Generated at 2022-06-25 04:42:53.734177
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    pass


# Generated at 2022-06-25 04:42:57.886443
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    assert (((ansible_vault_encrypted_unicode_0 == 'a') == False) and ((ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_0) == False))


# Generated at 2022-06-25 04:43:00.495499
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('<encrypted data>')
    str_0 = '<encrypted data>'
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(str_0)
    assert bool_0


# Generated at 2022-06-25 04:43:05.387829
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)



# Generated at 2022-06-25 04:43:08.753334
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    #
    # Test __getslice__ from class AnsibleVaultEncryptedUnicode
    #
    text_0 = 'R"W&o;Pd$Kg'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(text_0)
    assert ansible_vault_encrypted_unicode_0[:] == text_0



# Generated at 2022-06-25 04:43:09.535292
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    test_case_0()


# Generated at 2022-06-25 04:43:20.992811
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:43:23.386157
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    bool_0 = False
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_0.__ge__(bool_0)


# Generated at 2022-06-25 04:43:32.578431
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_0.__eq__(bool_0)


# Generated at 2022-06-25 04:43:33.723038
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    # Test the AnsibleVaultEncryptedUnicode class
    test_case_0()



# Generated at 2022-06-25 04:43:44.728719
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # See: https://docs.python.org/3/library/unittest.html#setupclass-and-teardownclass
    # Setup class
    if hasattr(test_AnsibleVaultEncryptedUnicode_is_encrypted, 'has_run'):
        return

    test_AnsibleVaultEncryptedUnicode_is_encrypted.has_run = True

    # Setup validation
    bool_0 = None
    test_case_0()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)

    # Get value of parameter ansible_vault_encrypted_unicode_0.is_encrypted()
    result = ansible_vault_encrypted_unicode_0.is_encrypted()

    # Validate parameter ansible_vault_encrypted

# Generated at 2022-06-25 04:43:47.131513
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str(0))
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str(0))
    assert ansible_vault_encrypted_unicode_1 == ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 04:43:55.936615
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # The following code raises an exception, because the AnsibleVaultEncryptedUnicode object has no vault attribute
    # The vault attribute can be set only by calling the AnsibleVaultEncryptedUnicode.from_plaintext method
    try:
        # Execute the code that is expected to raise an exception
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("1234567890")
        ansible_vault_encrypted_unicode_0.is_encrypted()
    except Exception as e:
        exception_raised = e

    if not isinstance(exception_raised, AttributeError):
        raise AssertionError('Expected exception not raised')


# Generated at 2022-06-25 04:43:57.669180
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    unicode_0 = str()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(unicode_0)



# Generated at 2022-06-25 04:43:59.931254
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    try:
        assert AnsibleVaultEncryptedUnicode.__le__(AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedUnicode) == NotImplemented
    except AssertionError:
        return
    assert True


# Generated at 2022-06-25 04:44:06.510706
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:44:13.758866
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    int_0 =  0
    int_1 =  1
    ansible_vault_encrypted_unicode_0___getslice__(ansible_vault_encrypted_unicode_0, int_0, int_1)


# Generated at 2022-06-25 04:44:24.452889
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_0.data = '!@#$%^&*()_+'
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(True)
    ansible_vault_encrypted_unicode_1.data = '!@#$%^&*()_+'
    ansible_vault_encrypted_unicode_1.vault = None
    assert not ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:44:34.899806
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    list_3 = ['1', '2', '3']
    ansible_vault_encrypted_unicode_4 = AnsibleVaultEncryptedUnicode(list_3)
    str_2 = '1'
    ansible_vault_encrypted_unicode_5 = AnsibleVaultEncryptedUnicode(str_2)
    assert ansible_vault_encrypted_unicode_5 <= ansible_vault_encrypted_unicode_4


# Generated at 2022-06-25 04:44:39.071951
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    bool_test = True
    bool_0 = bool_test
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    str_0 = "str_0"
    bool_1 = (str_0 <= ansible_vault_encrypted_unicode_0)
    assert bool_1


# Generated at 2022-06-25 04:44:44.222094
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    bool_0 = False
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = True
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_1)
    bool_0 = ansible_vault_encrypted_unicode_1.__le__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:44:50.400503
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = 0
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    boolean_0 = not ansible_vault_encrypted_unicode_0
    sys.stdout.write(str(boolean_0))


# Generated at 2022-06-25 04:44:56.951299
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    test_str = 'abcdef'
    test_string = AnsibleVaultEncryptedUnicode(test_str)
    expected_len = len(test_str)
    actual_len = test_string.rfind('b')
    if not (actual_len == expected_len):
        raise Exception('AnsibleVaultEncryptedUnicode.rfind failed, expected {0}, got {1}'.format(expected_len, actual_len))


# Generated at 2022-06-25 04:45:05.659511
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    """Unit test for method __le__ of class AnsibleVaultEncryptedUnicode"""
    # Test for call with no arguments
    try:
        AnsibleVaultEncryptedUnicode.__le__()
    except Exception as e:
        print(e)
        assert str(e) == 'Function __le__() takes exactly 2 arguments (0 given)'
    # Test for call with one argument
    try:
        AnsibleVaultEncryptedUnicode.__le__(True)
    except Exception as e:
        print(e)
        assert str(e) == 'Function __le__() takes exactly 2 arguments (1 given)'
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    # Test for call with two arguments

# Generated at 2022-06-25 04:45:12.597193
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__contains__(bool_0)


# Generated at 2022-06-25 04:45:17.651975
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    test_object = None
    # TODO add test logic here
    try:
        test_object.__eq__()
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 04:45:27.898220
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:45:32.831435
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_0.__eq__(None)


# Generated at 2022-06-25 04:45:42.742642
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)

    # Test the method is_encrypted
    assert_equal(ansible_vault_encrypted_unicode_0.is_encrypted(), False)



# Generated at 2022-06-25 04:45:47.328645
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:45:48.263603
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    test_case_0()


# Generated at 2022-06-25 04:45:52.555886
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    assert AnsibleVaultEncryptedUnicode.rfind(ansible_vault_encrypted_unicode_0) == 123


# Generated at 2022-06-25 04:45:58.153836
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext(
        bool_0, v, s)
    if not ansible_vault_encrypted_unicode_0.__ne__(
            bool_0):
        raise RuntimeError


# Generated at 2022-06-25 04:46:02.727377
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = False
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    # Test method __ne__ of class AnsibleVaultEncryptedUnicode
    bool_0 = True
    ansible_vault_encrypted_unicode_0.__ne__(bool_0)


# Generated at 2022-06-25 04:46:05.932278
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    # Test to see if our method works
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    


# Generated at 2022-06-25 04:46:17.682162
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = False
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_1)
    ansible_vault_encrypted_unicode_1 = ansible_vault_encrypted_unicode_0
    if not ansible_vault_encrypted_unicode_1.__eq__(ansible_vault_encrypted_unicode_0):
        raise AssertionError("Error in AnsibleVaultEncryptedUnicode.__eq__() method")
    else:
        print("Test test_AnsibleVaultEncryptedUnicode___eq__() passed")


# Generated at 2022-06-25 04:46:19.828305
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    bool_0 = True
    string_0 = 'rfind'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    assert ansible_vault_encrypted_unicode_0.rfind(string_0) == 0


# Generated at 2022-06-25 04:46:21.004215
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass


# Generated at 2022-06-25 04:46:31.499249
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    assert not ansible_vault_encrypted_unicode_0.is_encrypted(), 'ansible_vault_encrypted_unicode_0.is_encrypted() failed'


# Generated at 2022-06-25 04:46:32.389018
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    pass


# Generated at 2022-06-25 04:46:35.653334
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert bool_0 is False


# Generated at 2022-06-25 04:46:41.918802
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    # AnsibleVaultEncryptedUnicode instance
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()

    # Check if the method is_encrypted of AnsibleVaultEncryptedUnicode class returns a value
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()

    # Assert the method returns a value
    assert bool_0



# Generated at 2022-06-25 04:46:45.521460
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    pass


# Generated at 2022-06-25 04:46:47.399453
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    obj = AnsibleVaultEncryptedUnicode()
    other = 'test'
    result = obj.__ne__(other)
    assert result is True


# Generated at 2022-06-25 04:46:50.755553
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    assert (ansible_vault_encrypted_unicode_0.is_encrypted() == False)


# Generated at 2022-06-25 04:46:57.312316
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    str_0_str_1 = "sub"
    str_0 = AnsibleVaultEncryptedUnicode(str_0_str_1)
    str_1_str_1 = "sub"
    str_1 = AnsibleVaultEncryptedUnicode(str_1_str_1)
    int_0 = str_0.rfind(str_1)


# Generated at 2022-06-25 04:47:03.562373
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with boolean value for other.
    other = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(other)
    assert not ansible_vault_encrypted_unicode_0.__ne__(other)

    # Test with a valid string value for other.
    other = 'string'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(other)
    assert not ansible_vault_encrypted_unicode_0.__ne__(other)


# Generated at 2022-06-25 04:47:09.014208
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_0 = True
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = (ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1)
    assert bool_1


# Generated at 2022-06-25 04:47:19.331193
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import jinja2

    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = True
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_1)
    bool_2 = True
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(bool_2)


# Generated at 2022-06-25 04:47:25.602918
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = False
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_1)
    ansible_vault_encrypted_unicode_0.data = bool_1
    bool_2 = not bool_1
    assert ansible_vault_encrypted_unicode_0 == bool_1
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
    ansible_vault_encrypted_unicode_0.data = bool_2

# Generated at 2022-06-25 04:47:33.072891
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ut_data = {'false_positive':'$ANSIBLE_VAULT', 'false_negative':'foo bar baz', 'true_positive':'$ANSIBLE_VAULT;1.1;AES256', 'true_negative':''}
    for ct, val in ut_data.items():
        avu = AnsibleVaultEncryptedUnicode(val)
        if val.startswith('$ANSIBLE_VAULT'):
            assert avu.is_encrypted()
        else:
            assert not avu.is_encrypted()


# Generated at 2022-06-25 04:47:39.512002
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode("ABC").__ne__("ABC") == False
    assert AnsibleVaultEncryptedUnicode("ABC").__ne__("CBA") == False
    assert AnsibleVaultEncryptedUnicode("ABC").__ne__("A") == True
    assert AnsibleVaultEncryptedUnicode("").__ne__("ABC") == True
    assert AnsibleVaultEncryptedUnicode("ABC").__ne__("") == False


# Generated at 2022-06-25 04:47:51.796960
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    str_0 = 'Mon May 14 21:30:58 2018'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('Mon May 14 21:30:59 2018')
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('Mon May 14 21:30:59 2018')

# Generated at 2022-06-25 04:47:53.528476
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    return



# Generated at 2022-06-25 04:48:01.776747
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # test_case_0
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_0.data = 'Z'
    exception_0 = AssertionError()
    try:
        assert not(ansible_vault_encrypted_unicode_0 == bool_0)
    except AssertionError as e:
        exception_0 = e
    assert type(exception_0) == AssertionError
    test_case_0()

    # test_case_1
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)

# Generated at 2022-06-25 04:48:09.731842
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_0)
    assert(ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:48:13.245792
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_1 = False

    assert not ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:48:17.928693
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = False
    assert ansible_vault_encrypted_unicode_0 != bool_1


# Generated at 2022-06-25 04:48:26.186802
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    result = ansible_vault_encrypted_unicode_0.__eq__(bool_0)


# Generated at 2022-06-25 04:48:34.053438
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    data_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(data_0)

    # Test with string
    assert ansible_vault_encrypted_unicode_0.is_encrypted()

    # Test with unicode
    data_1 = u'2.7.0'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(data_1)
    assert not ansible_vault_encrypted_unicode_1.is_encrypted()



# Generated at 2022-06-25 04:48:38.006540
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    arg_0 = ""
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)

    # Call the __ne__ method of class AnsibleVaultEncryptedUnicode
    ne_result = ansible_vault_encrypted_unicode_0.__ne__(arg_0)
    # Assert that ne_result is equal to true
    assert ne_result == True


# Generated at 2022-06-25 04:48:47.273446
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Tests for case where self.vault is not None and (other != self.data)
    # Construct args
    bool_arg_0 = True
    ansible_vault_encrypted_unicode_arg_0 = AnsibleVaultEncryptedUnicode(bool_arg_0)
    ansible_vault_encrypted_unicode_arg_1 = AnsibleVaultEncryptedUnicode.from_plaintext(bool_arg_0, ansible_vault_encrypted_unicode_arg_0.vault, None)

    # Call method
    assertion_flag_0 = not (ansible_vault_encrypted_unicode_arg_0 != ansible_vault_encrypted_unicode_arg_1)

    # Check __ne__ calls return valid
    success = True

# Generated at 2022-06-25 04:48:51.113265
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:48:55.044649
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Create an object of class AnsibleVaultEncryptedUnicode
    string_0 = str()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(string_0)

    # Invoke method __ne__
    ansible_vault_encrypted_unicode___ne__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:48:58.987353
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:49:03.199617
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # No such method
    assert not hasattr(AnsibleVaultEncryptedUnicode, '__eq__')


# Generated at 2022-06-25 04:49:12.096624
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    None_0 = None
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(None_0)
    result_0 = ansible_vault_encrypted_unicode_1.__eq__(bool_0)
    result_1 = ansible_vault_encrypted_unicode_1.__eq__(ansible_vault_encrypted_unicode_0)
    result_2 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    result_3 = ansible_vault_encrypted_unicode_0.__eq__(bool_0)
   

# Generated at 2022-06-25 04:49:17.263181
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Create an AnsibleVaultEncryptedUnicode from a bool
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("")
    # Verify that the AnsibleVaultEncryptedUnicode is not encrypted
    assert ansible_vault_encrypted_unicode_0.is_encrypted() is False


# Generated at 2022-06-25 04:49:25.977809
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(to_bytes(float(0)))
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(to_text(0.0 + 0.5j))
    bool_1 = ansible_vault_encrypted_unicode_0.__eq__(to_text(-2.0))
    assert bool_0 == bool_1


# Generated at 2022-06-25 04:49:28.927770
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    print('Testing method AnsibleVaultEncryptedUnicode.is_encrypted')
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert bool_0 == True


# Generated at 2022-06-25 04:49:38.040605
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_0.vault = None
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:49:45.183888
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_0)
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False
    assert ansible_vault_encrypted_unicode_1.is_encrypted() == False


# Generated at 2022-06-25 04:49:45.826049
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass


# Generated at 2022-06-25 04:49:55.807571
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'foo'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = False
    assert ansible_vault_encrypted_unicode_1.__ne__(bool_0)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode(str_0)
    assert not ansible_vault_encrypted_unicode_2.__ne__(ansible_vault_encrypted_unicode_3)


# Generated at 2022-06-25 04:49:59.850033
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # TODO: AssertionError
    try:
        AnsibleVaultEncryptedUnicode().__eq__()
    except NameError:
        assert True == True



# Generated at 2022-06-25 04:50:07.087955
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_1 = bool_0

    assert(ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1))


# Generated at 2022-06-25 04:50:11.585944
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    assert not(ansible_vault_encrypted_unicode_0 != bool_0)


# Generated at 2022-06-25 04:50:16.743847
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # create a fake AnsibleVaultEncryptedUnicode
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    #create a fake bool
    bool_1 = True
    #ansible_vault_encrypted_unicode_0 != bool_1
    assert ansible_vault_encrypted_unicode_0.__ne__(bool_1) == True



# Generated at 2022-06-25 04:50:25.026269
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_0.__eq__(bool_0)


# Generated at 2022-06-25 04:50:33.654329
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # gen_arg = [?]
    # expected_return = [?]
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(None)
    with pytest.raises(AnsibleVaultError) as ansible_vault_error:
        ansible_vault_encrypted_unicode._eq_(None)
    assert "Error creating AnsibleVaultEncryptedUnicode, invalid vault (None) provided" in str(ansible_vault_error.value)



# Generated at 2022-06-25 04:50:36.728321
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_0)
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:50:47.202088
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    bool_1 = False
    dict_0 = {
        "key1": "value1",
        "key2": "value2",
    }
    int_0 = 0
    int_1 = 0
    str_0 = "value"
    # a simple demo for argument type and value checking
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.__ne__(None)
    ansible_vault_encrypted_unicode_0.__ne__(bool_0)
    ansible_vault_encrypted_unicode_0.__ne__(bool_1)
    ansible_vault_encrypted_unicode_0.__ne__(dict_0)
   

# Generated at 2022-06-25 04:50:54.856373
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_0.ansible_pos = (None, None, None)
    bool_1 = False
    assert (ansible_vault_encrypted_unicode_0 != bool_1)


# Generated at 2022-06-25 04:50:58.594298
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_0 = ansible_vault_encrypted_unicode_0.__eq__(bool_0)


# Generated at 2022-06-25 04:51:04.585611
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Script generated using a template
    # Don't forget to edit the script the match your use case.
    # Do not add any logic in this script
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    # Call method with args to test
    ansible_vault_encrypted_unicode_0.__ne__('')


# Generated at 2022-06-25 04:51:13.501516
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(None)
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1) == True
    str_0 = 'a'
    str_1 = 'a'
    assert ansible_vault_encrypted_unicode_0.__ne__(str_1) == False
    str_2 = 'n'
    assert ansible_vault_encrypted_unicode_0.__ne__(str_2) == True
    # test comparing to a non-vault object (not a string)
    assert ansible_

# Generated at 2022-06-25 04:51:20.982547
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('test')
    bool_1 = ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
    assert bool_1


# Generated at 2022-06-25 04:51:25.003077
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = True
    assert ansible_vault_encrypted_unicode_0 == bool_1


# Generated at 2022-06-25 04:51:34.412724
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)
    assert bool_0


# Generated at 2022-06-25 04:51:41.434654
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = False
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bool_1)
    ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:51:48.642127
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_0 = True
    result_ansible_vault_encrypted_unicode_0 = ansible_vault_encrypted_unicode_0.__eq__(bool_0)
    print(result_ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:51:52.951941
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    try:
        str_0 = str()
        ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_0)
        str_1 = str()
        ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode(str_1)
        assert ansible_vault_encrypted_unicode_2 != ansible_vault_encrypted_unicode_3

    except Exception as e:
        print(e.message)


# Generated at 2022-06-25 04:52:03.839869
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Initialize test objects
    bool_0 = True
    unicode_0 = u'Hello World!'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(unicode_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(unicode_0)
    # Test equality for same object
    test_eq = (ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_0)
    test_eq = (ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1)
    # Test equality for different object of same value
    test_eq = (ansible_vault_encrypted_unicode_0 == unicode_0)
    test_

# Generated at 2022-06-25 04:52:13.684324
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Create an instance of class AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(b'a')
    
    # Create an instance of class AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(b'a')

    # In this test, we call the __ne__ method of class AnsibleVaultEncryptedUnicode
    # with two AnsibleVaultEncryptedUnicode objects as inputs.
    # The call to the __ne__ method of class AnsibleVaultEncryptedUnicode should return
    # a bool object that is False.

# Generated at 2022-06-25 04:52:20.391307
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test case test_case_0
    # Tests equality against a boolean, False
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(False)
    assert ansible_vault_encrypted_unicode_0 != True
