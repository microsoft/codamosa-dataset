

# Generated at 2022-06-25 04:42:39.626268
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    tuple_0 = ()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(tuple_0)
    str_0 = ansible_vault_encrypted_unicode_0.__add__(tuple_0)


# Generated at 2022-06-25 04:42:41.929210
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    tuple_0 = ()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(tuple_0)
    var_0 = ansible_vault_encrypted_unicode_0.find()




# Generated at 2022-06-25 04:42:47.127228
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    tuple_0 = ()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(tuple_0)
    var_0 = ansible_vault_encrypted_unicode_0.__getslice__()


# Generated at 2022-06-25 04:42:51.549704
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    tuple_0 = ()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(tuple_0)
    str_0 = to_str(str())
    var_0 = ansible_vault_encrypted_unicode_0.__add__(str_0)


# Generated at 2022-06-25 04:42:55.754397
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    tuple_0 = ()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(tuple_0)
    var_0 = ansible_vault_encrypted_unicode_0.count()


# Generated at 2022-06-25 04:43:00.334631
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    def run_test():
        tuple_0 = ()
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(tuple_0)
        var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
        assert var_0 == True

    run_test()


# Generated at 2022-06-25 04:43:08.246816
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    tuple_0 = ()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(tuple_0)
    tuple_1 = ()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(tuple_1)
    var_0 = ansible_vault_encrypted_unicode_0.__add__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:43:10.710489
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    tuple_0 = ()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(tuple_0)
    ansible_vault_encrypted_unicode_0.__lt__()



# Generated at 2022-06-25 04:43:14.160485
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    # Checks the type of the object returned by the method __add__
    assert (type(AnsibleVaultEncryptedUnicode.__add__(AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedUnicode)) == str)


# Generated at 2022-06-25 04:43:18.354444
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    tuple_0 = ()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(tuple_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__()

# Generated at 2022-06-25 04:43:35.277312
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    from vault import VaultLib
    from ansible.parsing.vault import VaultLib as AnsibleVaultLib, VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode as AnsibleVaultEncryptedUnicode
    vault = VaultLib(VaultSecret('secret'))
    ciphertext = vault.encrypt('password', 'secret')
    o = AnsibleVaultEncryptedUnicode(ciphertext)
    o.vault = AnsibleVaultLib(VaultSecret('secret'))
    slice_0 = o[0:1]


# Generated at 2022-06-25 04:43:41.710048
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:43:48.566562
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('foo')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('bar')
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1) == True


# Generated at 2022-06-25 04:43:52.534366
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("abcdefg")
    ansible_vault_encrypted_unicode_1 = ansible_vault_encrypted_unicode_0.__getslice__(0, 7)


# Generated at 2022-06-25 04:43:59.479697
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_2.vault = ansible_vault_encrypted_unicode_1
    ansible_vault_encrypted_unicode_1.vault = ansible_vault_encrypted_unicode_0
    ansible_vault_encrypted_unicode_0.data = "test"
    ansible_vault_encrypted_unicode_1.data = "test"
    ansible_vault_encrypted_unicode_2.data = "test"
    assert ansible

# Generated at 2022-06-25 04:44:04.127860
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode().__eq__(None)


# Generated at 2022-06-25 04:44:14.401147
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('GAAAAABABQCOrvx2-LxaFArbJ-h4OlZ1tpMJ4nAmsK9XoHpf-yJFmBrm5w5Etya5bU6BciU6FKurpeoE_3CqNUJz-LxNbNlR1DQQ==\n')
    ansible_vault_encrypted_unicode_0.ansible_pos = ('/home/dave/ansible/test/units/module_utils/ansible_playbook/yaml/constructor_test.yaml', 6, 50)

# Generated at 2022-06-25 04:44:15.779864
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass


# Generated at 2022-06-25 04:44:22.108162
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    avu = AnsibleVaultEncryptedUnicode('Password: $6$OI4BU4GJ$KPdwOt/x26')
    assert avu[5:10] == 'word:', '__getslice__() failed'
    assert avu[5:5] == '', '__getslice__() failed'

if __name__ == '__main__':
    test_case_0()
    test_AnsibleVaultEncryptedUnicode___getslice__()

# Generated at 2022-06-25 04:44:30.171001
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    s1 = text_type('spam')
    s2 = text_type('spam')
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext(s1, None, None)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode.from_plaintext(s2, None, None)
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:44:39.523688
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 10.0
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:44:43.775250
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ret_val = ansible_vault_encrypted_unicode_0.__ne__(float_0)
    assert "AssertionError" not in str(ret_val)


# Generated at 2022-06-25 04:44:53.052894
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 638.55
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.vault = None
    float_1 = 404.59
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_1)
    ansible_vault_encrypted_unicode_1.vault = None
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:44:57.765081
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Create instance of AnsibleVaultEncryptedUnicode
    test_AnsibleVaultEncryptedUnicode___eq__instance = AnsibleVaultEncryptedUnicode('')
    # Determine whether __eq__ method is functionally equivalent to == operator over the same operands
    assert((test_AnsibleVaultEncryptedUnicode___eq__instance == False) ==
           test_AnsibleVaultEncryptedUnicode___eq__instance.__eq__(False))


# Generated at 2022-06-25 04:45:01.015982
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(638.574)
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:45:09.849507
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext(None, None, None)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(None)
    ansible_vault_encrypted_unicode_1.vault = None
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode.from_plaintext(None, None, None)
    ansible_vault_encrypted_unicode_2.vault = None
    if(ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1):
        ansible_vault_encrypted_unicode_3 = ansible_vault_encrypted_unicode_1 != ansible_vault

# Generated at 2022-06-25 04:45:21.072314
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('uq3keqp{n&n,#hkbszv&}+wn^o_jt=5d,*a1@+5olboax5u{')
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    int_0 = int('9433584')
    str_0 = str(int_0)
    bool_1 = ansible_vault_encrypted_unicode_0.is_encrypted()
    if (ansible_vault_encrypted_unicode_0):
        str_1 = str(ansible_vault_encrypted_unicode_0.is_encrypted())


# Generated at 2022-06-25 04:45:26.469398
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = to_text('')
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    assert (ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:45:38.630351
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # float_0 = 877.75
    float_0 = float(877.75)
    # ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    # ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)
    # ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
    assert (ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:45:39.574247
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
  assert False


# Generated at 2022-06-25 04:45:49.089220
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Case 0
    # input
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float(877.75))

    # expected result
    ansible_vault_encrypted_unicode_0_expected = False

    # actual result
    ansible_vault_encrypted_unicode_0_actual = ansible_vault_encrypted_unicode_0.is_encrypted()

    # verify the result
    assert ansible_vault_encrypted_unicode_0_actual == ansible_vault_encrypted_unicode_0_expected


# Generated at 2022-06-25 04:45:57.739972
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    unicode_0 = u'189yc5q6d'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(unicode_0)

    ansible_vault_encrypted_unicode_0.vault = None

    ansible_vault_encrypted_unicode_0.data
    ansible_vault_encrypted_unicode_0.data = u'a'

    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext(u'test', vault = None, secret = u'vault_password')

    assert ansible_vault_encrypted_unicode_0.is_encrypted() == True

    ansible_v

# Generated at 2022-06-25 04:46:03.751915
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Input parameters:
    self = 'string'
    other = 'string'

    # Expected return value:
    retval = True

    # Testing:

    # Method to test: __ne__(self, other)
    # This method is not directly callable. It gets called by the python code.
    # Here the code to test the method.

    retval = self.__ne__(other)

    # Validate the return value
    assert retval == True, "Return value validation failed."



# Generated at 2022-06-25 04:46:08.324971
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bool_0 = bool
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.vault = None
    bool_1 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert bool_1 == bool_0
    ansible_vault_encrypted_unicode_0.vault = None
    bool_1 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert bool_1 == bool_0


# Generated at 2022-06-25 04:46:12.854374
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_s = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_s)
    assert 0 != ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 04:46:15.758541
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 986.64
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    AnyType_1 = type(None)
    # AssertionError raised.
    with pytest.raises(AssertionError): ansible_vault_encrypted_unicode_0.__ne__(AnyType_1)


# Generated at 2022-06-25 04:46:20.409824
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = ansible_vault_encrypted_unicode_0.__eq__(None)


# Generated at 2022-06-25 04:46:26.538956
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)
    try:
        ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)
    except:
        pass

# Generated at 2022-06-25 04:46:30.873554
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(9.99)
    result = ansible_vault_encrypted_unicode_0.__ne__(28.35)



# Generated at 2022-06-25 04:46:35.461742
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Create a new instance of a class
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(801.65)

    # Call method is_encrypted on the instance
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:46:47.198056
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert(ansible_vault_encrypted_unicode_0 == float_0)
    float_1 = 795.07
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_1)
    assert(not (ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1))


# Generated at 2022-06-25 04:46:50.257782
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert ansible_vault_encrypted_unicode_0 != float_0


# Generated at 2022-06-25 04:46:51.591756
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert false == AnsibleVaultEncryptedUnicode.is_encrypted()


# Generated at 2022-06-25 04:46:55.344346
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 695.24
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    float_1 = 1375.3
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_1)
    ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:46:58.605963
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    boolean_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:47:02.473990
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.data = '])-{NTnx!'
    float_0 = float_0
    assert float_0 != ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 04:47:12.599241
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = AnsibleVaultEncryptedUnicode(843.22)
    float_1 = AnsibleVaultEncryptedUnicode(780.207)
    float_2 = AnsibleVaultEncryptedUnicode(486.66)
    float_3 = AnsibleVaultEncryptedUnicode(968.8)
    # self.__eq__(self, other)
    assert not float_0.__eq__(float_0, float_1)
    assert not float_0.__eq__(float_0, float_2)
    assert not float_0.__eq__(float_0, float_3)
    assert not float_0.__eq__(float_0, float_0)
    assert not float_1.__eq__(float_1, float_2)
    assert not float_

# Generated at 2022-06-25 04:47:20.911405
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 937.08
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    str_0 = "Encrypts Ansible vars using AES"
    int_0 = 9
    float_0 = 1.29
    int_1 = 7
    str_1 = "Encrypts Ansible vars using AES"
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_1.__ne__(ansible_vault_encrypted_unicode_1)
    ansible_vault_encrypted_unicode_0.__ne__(str_0)

# Generated at 2022-06-25 04:47:32.765811
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Tests for object type
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(1)
    assert not (ansible_vault_encrypted_unicode_0 == None)

    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(1)
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1

    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(2)
    assert not (ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1)

    # Tests for primitive type

# Generated at 2022-06-25 04:47:38.935865
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    __dummy0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(__dummy0)
    __dummy = 976.17
    assert (ansible_vault_encrypted_unicode_0.__ne__(__dummy) != False or __dummy == ansible_vault_encrypted_unicode_0.__ne__(__dummy))


# Generated at 2022-06-25 04:47:47.005563
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.__eq__(float_0)


# Generated at 2022-06-25 04:47:53.718140
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 703.02
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    int_0 = int('[0-9]', 16)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(int_0)
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1



# Generated at 2022-06-25 04:47:58.711061
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 956.32
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    str_0 = ansible_vault_encrypted_unicode_0.__ne__('4Hd.?1')
    if str_0:
        str_0 = str_0
    else:
        str_0 = str_0
    return str_0


# Generated at 2022-06-25 04:48:01.842025
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_1 = 647.52
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_1)
    ansible_vault_encrypted_unicode_1.vault = "AnsibleVaultAES256"


# Generated at 2022-06-25 04:48:11.831243
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # get instance
    text_0 = 'g_fv_gkDG'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(text_0)
    int_0 = -9
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(int_0)
    # call function
    ret_val = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    # assert the return value is None
    assert ret_val is None, 'Error: Wrong return value'


# Generated at 2022-06-25 04:48:18.507527
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    # TODO: Test with string
    float_0 = 90.77
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    if not ansible_vault_encrypted_unicode_0 == string_0:
        raise Exception("Should be equal")    
    

# Generated at 2022-06-25 04:48:23.320974
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    try:
        float_0 = 763.27
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
        boolean_0 = ansible_vault_encrypted_unicode_0.__ne__(float_0)
        assert boolean_0
    except AssertionError as e:
        raise e


# Generated at 2022-06-25 04:48:26.388508
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)


# Generated at 2022-06-25 04:48:32.390895
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = 897.43
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    boolean_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:48:40.199115
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from test_utils import unit_test_eq, UnitTestCase

    unit_test_eq(True, AnsibleVaultEncryptedUnicode('foo') != AnsibleVaultEncryptedUnicode('bar'), "AnsibleVaultEncryptedUnicode('foo') != AnsibleVaultEncryptedUnicode('bar')")
    unit_test_eq(True, AnsibleVaultEncryptedUnicode('foo') != 'foo', "AnsibleVaultEncryptedUnicode('foo') != 'foo'")


# Generated at 2022-06-25 04:48:47.517386
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 0.0
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert not ansible_vault_encrypted_unicode_0.__eq__(float_0), "AnsibleVaultEncryptedUnicode - Equals"


# Generated at 2022-06-25 04:48:50.331818
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    pass


# Generated at 2022-06-25 04:48:53.980814
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("test")
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0), 'Failed to assert __ne__ of AnsibleVaultEncryptedUnicode'


# Generated at 2022-06-25 04:49:00.827925
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    # Test1
    try:
        ansible_vault_encrypted_unicode_0.is_encrypted()
    except Exception as e:
        print('Exception raised: ' + str(e))
    else:
        print('test1: passed')
    # Test2
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)
    try:
        ansible_vault_encrypted_unicode_1.is_encrypted()
    except Exception as e:
        print('Exception raised: ' + str(e))
    else:
        print('test2: passed')


# Generated at 2022-06-25 04:49:07.196431
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    # AssertionError
    try:
        ansible_vault_encrypted_unicode_0.__eq__(float_0)
    except AssertionError:
        pass


# Generated at 2022-06-25 04:49:11.370488
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 939.131549
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)



# Generated at 2022-06-25 04:49:17.373102
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    float_1 = 877.75
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_1)
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:49:22.407970
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Set up test data
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)

    # Run the SUT
    result = ansible_vault_encrypted_unicode_0.__eq__(float_0)

    # Verify the results
    #assert result == expected_result
    #print(result)


# Generated at 2022-06-25 04:49:26.695510
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ciphertext = "abc"
    unicode_0 = AnsibleVaultEncryptedUnicode(ciphertext)

    # Case 0:
    # if self.vault:
    #     return other == self.data
    # return False
    #
    # Case 1:
    # if self.vault:
    #     return other != self.data
    # return True
    assert not unicode_0 == ciphertext
    assert unicode_0 != ciphertext


# Generated at 2022-06-25 04:49:33.020171
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert bool_0 == False



# Generated at 2022-06-25 04:49:43.062366
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)

    ansible_vault_encrypted_unicode_0.data = float_0
    assert ansible_vault_encrypted_unicode_0.__eq__(float_0) == True


# Generated at 2022-06-25 04:49:48.797883
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 612.7
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)
    assert(ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:49:55.524285
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    # AssertionError: Error creating AnsibleVaultEncryptedUnicode, invalid vault (None) provided
    # assert ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:50:04.028912
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    # Test with string
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert(ansible_vault_encrypted_unicode_0 == float_0)

    # Test with AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)
    assert(ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:50:11.897388
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    boolean_0 = ansible_vault_encrypted_unicode_0.__eq__(float_0)
    boolean_1 = ansible_vault_encrypted_unicode_0.__eq__(float_0)
    boolean_2 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)



# Generated at 2022-06-25 04:50:19.870567
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 763.21
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0)
    str_0 = str(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:50:23.408292
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # str_0 = AnsibleVaultEncryptedUnicode(str_0)

    str_0 = 'abc'
    str_1 = 'def'
    str_0 = AnsibleVaultEncryptedUnicode(str_0)

    print(str_0 != str_1)
    print(type(str_0))
    print(dir(str_0))


# Generated at 2022-06-25 04:50:24.785181
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(93)


# Generated at 2022-06-25 04:50:30.060299
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 814.37
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    string_0 = 'R)$+%c"pOn!;t!_+0.h'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(string_0)
    ansible_vault_encrypted_unicode_1._ciphertext = string_0
    ansible_vault_encrypted_unicode_1.vault = None
    ansible_vault_encrypted_unicode_1.vault = None
    ansible_vault_encrypted_unicode_1._ciphertext = string_0
    ansible_vault_encrypted_unicode_1._line_number = float_0
   

# Generated at 2022-06-25 04:50:37.546349
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    try:
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext(1544668887, 'x', "da39a3ee5e6b4b0d3255bfef95601890afd80709")
        ansible_vault_encrypted_unicode_0.__eq__(to_bytes(1544668887))
    except AssertionError:
        return True
    except:
        return False
    else:
        raise AssertionError


# Generated at 2022-06-25 04:50:45.869931
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 16.0
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:50:57.962193
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)

    test_bool = ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1

    assert not test_bool

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('test')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('test')

    test_bool = ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1

    assert not test_bool

   

# Generated at 2022-06-25 04:51:01.612321
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)


# Generated at 2022-06-25 04:51:05.436375
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 178.47
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    bool_0 = ansible_vault_encrypted_unicode_0 == float_0
    print(bool_0)


# Generated at 2022-06-25 04:51:10.422647
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(float_0)
    assert bool_0 == True


# Generated at 2022-06-25 04:51:17.965083
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -116.53
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = ansible_vault_encrypted_unicode_0

    if ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1:
        raise TypeError()

    if not ansible_vault_encrypted_unicode_0 != float_0:
        raise TypeError()

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    if not ansible_vault_encrypted_unicode_0 != float_0:
        raise TypeError()

    ansible_vault_encrypted_unicode_0 = Ans

# Generated at 2022-06-25 04:51:21.678064
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    pass


# Generated at 2022-06-25 04:51:24.046474
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:27.430931
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Setting up variables for test_case_4
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    test_case_4 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert not test_case_4, "Test case 4 failed"


# Generated at 2022-06-25 04:51:28.798044
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)


# Generated at 2022-06-25 04:51:38.257683
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_0)
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:51:41.594369
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = 71.36
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:50.598204
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_1 = 877.75
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_1)
    ansible_vault_encrypted_unicode_1.vault = AnsibleVault()
    try:
        print(ansible_vault_encrypted_unicode_1.vault.decrypt(ansible_vault_encrypted_unicode_1._ciphertext, obj=ansible_vault_encrypted_unicode_1))
    except TypeError:
        pass
    ansible_vault_encrypted_unicode_1.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:51:59.441590
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(text_type)

    # Unit test: __ne__
    # Parameter: AnsibleVaultEncryptedUnicode
    #
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(text_type)
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0) == True



# Generated at 2022-06-25 04:52:05.380272
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Initializing arguments with default values
    unicode_0 = 'default value: unicode_0'
    # Calling method __eq__ of class AnsibleVaultEncryptedUnicode with errors=surrogate_or_strict
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode.__eq__(AnsibleVaultEncryptedUnicode,unicode_0,errors='surrogate_or_strict')


# Generated at 2022-06-25 04:52:10.579925
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    boolean_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0)

    assert boolean_0 == True



# Generated at 2022-06-25 04:52:17.166760
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    assert to_text(test_case_0.ansible_vault_encrypted_unicode_0) == to_text(test_case_0.float_0)
    assert test_case_0.ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:52:23.648634
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    '''
    Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
    '''
    float_0 = 877.75
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0_copy = AnsibleVaultEncryptedUnicode(float_0)

    try:
        ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_0_copy
        assert 1 == 1
    except AssertionError as exception_instance:
        print('AssertionError:', exception_instance)

