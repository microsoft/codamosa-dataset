

# Generated at 2022-06-25 04:42:48.452710
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    itr = AnsibleVaultEncryptedUnicode()
    print('Defining a '+str(itr.__class__)+' object')
    print('')

    # Defining a AnsibleVaultEncryptedUnicode object
    itr.data = 'My message'
    print('Defining a '+str(itr.__class__)+' object')
    print('itr.data = \'My message\'')

    # Defining a AnsibleVaultEncryptedUnicode object
    itr_1 = AnsibleVaultEncryptedUnicode()
    itr_1.data = 'message'
    print('Defining a '+str(itr_1.__class__)+' object')
    print('itr_1.data = \'message\'')


# Generated at 2022-06-25 04:42:58.929327
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_unicode_1 = AnsibleUnicode()
    ansible_unicode_0.data = ansible_unicode_1
    ansible_unicode_2 = AnsibleUnicode()
    ansible_unicode_2.data = b''
    ansible_unicode_3 = AnsibleUnicode()
    ansible_unicode_3.data = ansible_unicode_2
    ansible_unicode_4 = AnsibleVaultEncryptedUnicode()
    ansible_unicode_4.data = b''
    ansible_unicode_5 = AnsibleUnicode()
    ansible_unicode_5.data = ansible_unicode_4

# Generated at 2022-06-25 04:43:03.392830
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleVaultEncryptedUnicode('This is a unicode string')
    ansible_unicode_1 = AnsibleUnicode('This is a unicode string')
    assert (ansible_unicode_0 == ansible_unicode_1)


# Generated at 2022-06-25 04:43:07.329280
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_unicode_0.__contains__(ansible_unicode_0)


# Generated at 2022-06-25 04:43:10.184203
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    plaintext = 'abc'
    vault = AnsibleVaultLib.VaultLib('secret')
    avue = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, 'secret')
    assert avue.is_encrypted() == True


# Generated at 2022-06-25 04:43:18.633794
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test case with normal string
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('test')
    ansible_vault_encrypted_unicode_1 = 'test-1'
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
    # Test case with another vault object
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode('test-2')
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_2



# Generated at 2022-06-25 04:43:26.322300
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext('16be3b8d3176a1bfa1e7c35b97f846e5',
                                                                                    vault, '00000000')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode.from_plaintext('16be3b8d3176a1bfa1e7c35b97f846e5',
                                                                                    vault, '00000000')
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode.from_plaintext('bad8e60f8cc69990c6f0ef6b30c3a1',
                                                                                    vault, '00000000')
    ansible_

# Generated at 2022-06-25 04:43:33.141578
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    # Initialize a AnsibleVaultEncryptedUnicode object
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(to_bytes("", encoding='utf-8'))
    # call ansible_vault_encrypted_unicode.replace
    ansible_vault_encrypted_unicode.replace(None, None)


# Generated at 2022-06-25 04:43:44.360563
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test without secret key
    avu_1 = AnsibleVaultEncryptedUnicode.from_plaintext('foo',
                                vault=vault.VaultLib('ansible') , secret=None)
    assert avu_1.is_encrypted() == False
    assert avu_1 != 'foo'
    assert avu_1 != avu_1
    assert 'foo' != avu_1
    assert avu_1 != 'bar'
    avu_2 = AnsibleVaultEncryptedUnicode.from_plaintext('bar',
                                vault=vault.VaultLib('ansible'), secret=None)
    assert avu_2.is_encrypted() == False
    assert avu_1 != avu_2
    assert avu_2 != avu_1
    # Test with secret key
   

# Generated at 2022-06-25 04:43:54.410122
# Unit test for method replace of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_replace():
    from ansible.parsing.vault import VaultLib
    secret = "This is a secret"
    vault = VaultLib([])
    avu_0 = AnsibleVaultEncryptedUnicode.from_plaintext(b'The quick brown fox jumped over the lazy dog', vault, secret)
    assert avu_0.replace(b'The', b'A') == b'A quick brown fox jumped over the lazy dog'
    avu_1 = AnsibleVaultEncryptedUnicode.from_plaintext(b'The quick brown fox jumped over the lazy dog', vault, secret)
    assert avu_1.replace(b'The', b'A', 1) == b'A quick brown fox jumped over the lazy dog'

# Generated at 2022-06-25 04:44:07.910165
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(b'')
    ansible_vault_encrypted_unicode_0.ansible_pos = (None, 0, 0)
    assert ansible_vault_encrypted_unicode_0.__getslice__(0, 0) == b''


# Generated at 2022-06-25 04:44:13.513381
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    vault = AnsibleVaultLib()
    my_secret = 'secret'
    my_plain = 'plain'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(my_plain, vault, my_secret)
    assert avu == my_plain


# Generated at 2022-06-25 04:44:19.145825
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Tests with a 'ansible_unicode_0' object of class 'AnsibleUnicode'
    ansible_unicode_0 = AnsibleUnicode()
    other_0 = ansible_unicode_0
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext(ansible_unicode_0, None, None)
    # Test Check to see if the AnsibleVaultEncryptedUnicode object is equal to the AnsibleUnicode object
    assert (ansible_vault_encrypted_unicode_0 == other_0)


# Generated at 2022-06-25 04:44:28.807087
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    try:
        # Copy and paste of code from class method from_plaintext()
        ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(u'TEXT')
        ansible_vault_encrypted_unicode_1.vault = True
        # Call method __eq__
        ansible_vault_encrypted_unicode_1.__eq__(u'value')
    except AssertionError as exception_instance:
        if exception_instance.args[0] != 'ansible_pos can only be set with a tuple/list of three values: source, line number, column number':
            raise
    except Exception as exception_instance:
        raise


# Generated at 2022-06-25 04:44:30.960276
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    from ansible.vault.vaultlib import VaultLib
    avu = AnsibleVaultEncryptedUnicode('test', vault=VaultLib('test'))
    text_to_compare = avu[:]
    assert text_to_compare == 'test', 'Failed to run __getslice__ of class AnsibleVaultEncryptedUnicode'


# Generated at 2022-06-25 04:44:37.508619
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    vault = AnsibleVaultEncryptedUnicode
    secret = '12345'

    try:
        ciphertext = vault.from_plaintext('secret string', vault, secret)
    except Exception as e:
        assert(False)
        return

    assert(ciphertext.is_encrypted())



# Generated at 2022-06-25 04:44:45.665163
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    args_0 = 'test'
    # Calling AnsibleVaultEncryptedUnicode.__ne__(self, *args, **kwargs) with arguments (args_0)
    r0 = AnsibleVaultEncryptedUnicode.__ne__(AnsibleVaultEncryptedUnicode, *args_0)
    assert r0 == 'False', 'Return value 0 of AnsibleVaultEncryptedUnicode.__ne__ was incorrect'
    args_1 = 0
    args_2 = 0
    # Calling AnsibleVaultEncryptedUnicode.__ne__(self, *args, **kwargs) with arguments (args_1, args_2)
    r1 = AnsibleVaultEncryptedUnicode.__ne__(AnsibleVaultEncryptedUnicode, *args_1, *args_2)

# Generated at 2022-06-25 04:44:47.158455
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    test_object = AnsibleVaultEncryptedUnicode('test_val')
    assert test_object.is_encrypted() == False


# Generated at 2022-06-25 04:44:53.551196
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    expected = True
    actual = False
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.data = "test string"
    actual = (ansible_vault_encrypted_unicode_0 == "test string")
    if actual is not expected:
        msg = "expected: %s, actual: %s" % (expected, actual)
        print(msg)

if __name__ == "__main__":
    test_case_0()
    test_AnsibleVaultEncryptedUnicode___eq__()

# Generated at 2022-06-25 04:44:57.431382
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    obj = AnsibleVaultEncryptedUnicode('string')
    str = 'string'
    assert obj != str

# Generated at 2022-06-25 04:45:05.006431
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # create object
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()

    # test method
    ansible_vault_encrypted_unicode_a = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert ansible_vault_encrypted_unicode_a == False


# Generated at 2022-06-25 04:45:08.653592
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(u'ciphertext')
    ansible_vault_encrypted_unicode_0.vault = None
    assert ansible_vault_encrypted_unicode_0.__eq__(u'plaintext')


# Generated at 2022-06-25 04:45:11.930016
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext("am a string", None, None)
    assert ansible_vault_encrypted_unicode_0 == "am a string"


# Generated at 2022-06-25 04:45:21.396798
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_unicode_1 = AnsibleUnicode()
    ansible_unicode_2 = AnsibleUnicode()
    ansible_unicode_3 = AnsibleUnicode()
    ansible_unicode_4 = AnsibleUnicode()
    ansible_unicode_5 = AnsibleUnicode()
    ansible_unicode_6 = AnsibleUnicode()
    ansible_unicode_7 = AnsibleUnicode()
    ansible_unicode_8 = AnsibleUnicode()
    ansible_unicode_9 = AnsibleUnicode()
    ansible_unicode_10 = AnsibleUnicode()
    ansible_unicode_11 = AnsibleUnicode()
    ansible_unicode_

# Generated at 2022-06-25 04:45:29.399807
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode._ciphertext = '1'
    try:
        ansible_vault_encrypted_unicode.ansible_pos = (1, 2, 3)
    except AssertionError as e:
        assert str(e) == 'ansible_pos can only be set with a tuple/list of three values: source, line number, column number'
    ansible_vault_encrypted_unicode.__UNSAFE__ = '1'
    try:
        ansible_vault_encrypted_unicode.__ENCRYPTED__ = False
    except AssertionError as e:
        assert str(e) == '__ENCRYPTED__ cannot be set to false'
    ansible

# Generated at 2022-06-25 04:45:32.012887
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    z1 = AnsibleVaultEncryptedUnicode(u'abc')
    z2 = AnsibleVaultEncryptedUnicode(u'abc')
    z3 = AnsibleVaultEncryptedUnicode(u'ab')
    assert not z1.__eq__(z3)
    assert z1.__eq__(z2)


# Generated at 2022-06-25 04:45:34.228652
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()

    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:45:34.788782
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert(False)



# Generated at 2022-06-25 04:45:45.728111
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # setup test data
    import ansiblevault.cli
    # create an AnsibleVaultEncryptedUnicode object

# Generated at 2022-06-25 04:45:51.989571
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleVaultEncryptedUnicode('insecure')

    try:
        ansible_unicode_0 == ansible_unicode_0
    except Exception:
        raise AssertionError

    try:
        ansible_unicode_0 != ansible_unicode_0
    except Exception:
        raise AssertionError

    try:
        ansible_unicode_0 < ansible_unicode_0
    except Exception:
        raise AssertionError

    try:
        ansible_unicode_0 <= ansible_unicode_0
    except Exception:
        raise AssertionError

    try:
        ansible_unicode_0 > ansible_unicode_0
    except Exception:
        raise AssertionError


# Generated at 2022-06-25 04:45:56.853798
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # The unit test will fail if this method is not implemented
    assert False

# Generated at 2022-06-25 04:46:05.933184
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

    # Assert type of __eq__`s return type
    assert isinstance(ansible_vault_encrypted_unicode_0.__eq__(str_0), bool)

    # Test when is equal
    str_1 = 'path_join'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_0.vault = 'xxx'
    assert ansible_vault_encrypted_unicode_1.__eq__(ansible_vault_encrypted_unicode_0) == True

    # Test when is not equal

# Generated at 2022-06-25 04:46:14.800216
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'arg'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'arg'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    result = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)
    assert result is False


# Generated at 2022-06-25 04:46:18.552234
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    value = False
    value = ansible_vault_encrypted_unicode_0.__eq__(str_0)
    return value


# Generated at 2022-06-25 04:46:24.529462
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'hello'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = VaultLib('12345')
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:46:26.574978
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = AnsibleVaultEncryptedUnicode(' ')
    bool_0 = str_0.is_encrypted()
    assert bool_0



# Generated at 2022-06-25 04:46:35.368832
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'path_exists'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    # Since we are not setting the vault lib we get False
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_1.vault = None
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1) is False


# Generated at 2022-06-25 04:46:41.349808
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Test with valid input
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = False
    result = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert not result


# Generated at 2022-06-25 04:46:46.581038
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert bool_0


# Generated at 2022-06-25 04:46:54.639438
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'path_join'
    str_1 = 'AnsibleVaultEncryptedUnicode'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_0.vault = ansible_vault_encrypted_unicode_1
    ansible_vault_encrypted_unicode_0.data = str_1
    # __ne__ in AnsibleVaultEncryptedUnicode returns false when it is not
    # possible to decrypt the content.
    # This is a problem when checking equality between two
    # AnsibleVaultEncryptedUnicode objects that are not encrypted without
   

# Generated at 2022-06-25 04:47:03.568768
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'mock_variables_files'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'playbook_dir'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode.__ne__(ansible_vault_encrypted_unicode_0, ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:47:07.960373
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.loader import AnsibleVaultEncryptedUnicode
    # Test AnsibleVaultEncryptedUnicode is_encrypted
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = VaultLib()
    print(ansible_vault_encrypted_unicode_0.is_encrypted() == False)


# Generated at 2022-06-25 04:47:11.552982
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('path_join')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('path_join')
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:47:18.632998
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    returns_int_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)



# Generated at 2022-06-25 04:47:20.807427
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'str_0'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert not ansible_vault_encrypted_unicode_0.__ne__(str_0)


# Generated at 2022-06-25 04:47:25.246130
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('config_file_join')
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:47:34.440565
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

    str_1 = 'path_join'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)

    result = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    assert result != True, "AnsibleVaultEncryptedUnicode: test_AnsibleVaultEncryptedUnicode___eq__() failed, " \
                           "expected False got True"


# Generated at 2022-06-25 04:47:39.310047
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Create object under test without vault
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(str_0)
    assert bool_0


# Generated at 2022-06-25 04:47:43.506681
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'This is my test string'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_1 != ansible_vault_encrypted_unicode_2


# Generated at 2022-06-25 04:47:47.698817
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'l'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__('l')


# Generated at 2022-06-25 04:47:57.887573
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
    assert ansible_vault_encrypted_unicode_0 != str_0


# Generated at 2022-06-25 04:48:05.092724
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'asd'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    print(ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:48:13.697806
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'path_join'
    unicode_1 = text_type(str_1)
    unicode_1 = unicode_1.lowercase
    if unicode_0 == unicode_1:
        print('unicode_1 is: ', str(unicode_1))
        print(True)
    else:
        print(False)
    str_2 = 'path_join'
    unicode_2 = to_text(str_2)
    unicode_2 = unicode_2.lowercase
    if unicode_0 == unicode_2:
        print('unicode_2 is: ', str(unicode_2))
        print(True)

# Generated at 2022-06-25 04:48:15.957827
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    return ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:48:21.144326
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'source_vars'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:48:29.801685
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = '~/\x1a\x1c\xae@\x05\x8f\xe9\x0b\xb1\x18\x81\x1c\x1a\x1c\xae@\x05\x8f\xe9\x0b\xb1\x18\x81\x1c'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()

if __name__ == '__main__':
    test_case_0()
    test_AnsibleVaultEncryptedUnicode_is_encrypted()

# Generated at 2022-06-25 04:48:33.421883
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('file')
    assert not ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:48:35.868311
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    pass


# Generated at 2022-06-25 04:48:38.583411
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

    # Verify if the method is_encrypted of class AnsibleVaultEncryptedUnicode returns False
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:48:41.279140
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.__ne__(None)


# Generated at 2022-06-25 04:48:52.809331
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'path_join'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert not ansible_vault_encrypted_unicode_0.__ne__(str_0)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

# Generated at 2022-06-25 04:48:56.372478
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = '-@'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(str_0)
    assert bool_0 is False


# Generated at 2022-06-25 04:49:02.816176
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'path_join'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    result = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:49:07.745625
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # ansible_vault_encrypted_unicode_0 is AnsibleVaultEncryptedUnicode
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    boolean_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    str_1 = 'false'
    assert str_1 == boolean_0
    str_2 = 'path_join'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_2)
    boolean_1 = ansible_vault_encrypted_unicode_1.is_encrypted()
    str_3 = 'false'
    assert str_3 == boolean_1


# Generated at 2022-06-25 04:49:19.818135
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_4 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_5 = AnsibleVaultEncryptedUnicode(str_0)

# Generated at 2022-06-25 04:49:23.845253
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    test = (1 != ansible_vault_encrypted_unicode_0)
    if test:
        assert True
    else:
        print('AssertionError: %s' % assert_message)


# Generated at 2022-06-25 04:49:29.015388
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    test_passed = not ansible_vault_encrypted_unicode_0.is_encrypted()

    assert test_passed == True


# Generated at 2022-06-25 04:49:36.735219
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    if not (eq(ansible_vault_encrypted_unicode_0, ansible_vault_encrypted_unicode_1)):
        raise AssertionError('Test Failed')


# Generated at 2022-06-25 04:49:43.942930
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.data = 'path_join'
    if ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_0:
        print('passed')
    else:
        print('failed')


# Generated at 2022-06-25 04:49:49.660078
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'access_control'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:49:56.306567
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Create fake class object
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('test')

    # Test method with valid parameter
    # UNIT TEST FAILS: No value is returned, but ansible_vault_encrypted_unicode_0.is_encrypted() is True.
    ret_val = ansible_vault_encrypted_unicode_0.is_encrypted()
    print("ret_val", ret_val)



# Generated at 2022-06-25 04:50:02.690738
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)
    assert not ansible_vault_encrypted_unicode_0.__eq__(1)


# Generated at 2022-06-25 04:50:11.305196
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('path_join')
    assert ansible_vault_encrypted_unicode_0.__ne__(str_0) == False
    str_0 = 'wf_debug'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('path_join')
    assert ansible_vault_encrypted_unicode_0.__ne__(str_0) == True


# Generated at 2022-06-25 04:50:13.626383
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 04:50:24.546310
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_4 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_4.data = 'foo'
    ansible_vault_encrypted_unicode_3.data = 'foo'
    ansible_vault_encrypted_unicode_2.data

# Generated at 2022-06-25 04:50:28.776127
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # get a handle on the function
    function = AnsibleVaultEncryptedUnicode.is_encrypted
    # test the expected types
    assert type(function) == instancemethod



# Generated at 2022-06-25 04:50:38.349129
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.data = 'test'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_1.data = 'test'
    ansible_vault_encrypted_unicode_1.data = 'test2'

    ansible_vault_encrypted_unicode_1.__ne__(ansible_vault_encrypted_unicode_0)
    ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)



# Generated at 2022-06-25 04:50:44.181217
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'get_binary_content'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'run_command'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)


# Generated at 2022-06-25 04:50:50.485204
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'vault'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    from ansible.parsing.vault import VaultLib
    vault_lib_0 = VaultLib()
    ansible_vault_encrypted_unicode_0.vault = vault_lib_0
    ansible_vault_encrypted_unicode_1.vault = vault_lib_0
    # Call is_encrypted method on ansible_vault_encrypted_unicode_0 object
    ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:50:53.697641
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode('') == 'string is implicit'
    assert not AnsibleVaultEncryptedUnicode('') == AnsibleVaultEncryptedUnicode('string is explicit')


# Generated at 2022-06-25 04:51:01.389933
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = test_case_0()
    ansible_vault_encrypted_unicode_0.__ne__()
    pass

# Generated at 2022-06-25 04:51:09.338406
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    res = ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
    print(res)
    if res:
        print('AnsibleVaultEncryptedUnicode ' + str_0 + ' is equal to ' + str_0)
    else:
        print('AnsibleVaultEncryptedUnicode ' + str_0 + ' is not equal to ' + str_0)

if __name__ == '__main__':
    sys.modules['ansible.vault'] = __

# Generated at 2022-06-25 04:51:15.084607
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'path_join'
    assert True == ansible_vault_encrypted_unicode_0.__eq__(str_1)


# Generated at 2022-06-25 04:51:17.548818
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.data == ansible_vault_encrypted_unicode_1.data


# Generated at 2022-06-25 04:51:25.447788
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    str_1 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_0.data = str_0
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_1 == ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 04:51:32.955319
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = ansible_vault_encrypted_unicode_0
    assert ansible_vault_encrypted_unicode_1 == str_0


# Generated at 2022-06-25 04:51:36.292390
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:51:40.757787
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert ansible_vault_encrypted_unicode_0.__ne__(str_0) == False


# Generated at 2022-06-25 04:51:51.537197
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()
    ansible_vault_encrypted_unicode_1.is_encrypted()
    ansible_vault_encrypted_unicode_0.is_encrypted()
    ansible_vault_encrypted_unicode_1.is_encrypted()
    ansible_vault_encrypted_unicode_0.is_encrypted()
    ansible_vault_encrypted_unicode_1.is_encrypted()
    ansible_vault_encrypted_unicode_0.is_

# Generated at 2022-06-25 04:52:00.393746
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'decode'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'decode'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)
    assert bool_0


# Generated at 2022-06-25 04:52:11.832879
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = 'path_join'
    ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:52:12.354577
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    pass




# Generated at 2022-06-25 04:52:17.040246
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    # assert ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:52:22.368971
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'path_join'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

    try:
        ansible_vault_encrypted_unicode_0.__ne__(str_0)
    except NotImplementedError:
        pass
