

# Generated at 2022-06-25 04:42:51.327378
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(b'\x00')
    assert ansible_vault_encrypted_unicode_0.__gt__('\x00') == 0
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(b'\x00')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(b'\x00')
    assert ansible_vault_encrypted_unicode_0.__gt__(ansible_vault_encrypted_unicode_1) == 0


# Generated at 2022-06-25 04:42:57.126044
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # Call AnsibleVaultEncryptedUnicode::__gt__ with parameter:
    # string={String object}
    # exp_rtn_value=false
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    assert False == (ansible_vault_encrypted_unicode_0.__gt__())


# Generated at 2022-06-25 04:43:02.799885
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(b'ansible_vault_encrypted_unicode')
    ansible_vault_encrypted_unicode.vault = None
    ansible_vault_encrypted_unicode._ciphertext = b'ansible_vault_encrypted_unicode_ciphertext'

    # Test for true
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(b'version_2')
    ansible_vault_encrypted_unicode_1.vault = None
    ansible_vault_encrypted_unicode_1._ciphertext = b'version_1'
    assert ansible_vault_encrypted_unicode > ansible_vault_encrypted_unicode_1

    # Test

# Generated at 2022-06-25 04:43:08.358659
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    # Setup
    vault = MockVault(True)
    secret = 'secret'
    plaintext = 'plaintext'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)

    # Execute
    actual_return = avu.is_encrypted()

    # Verify
    actual_return_should_be = True
    assert actual_return == actual_return_should_be


# Generated at 2022-06-25 04:43:17.699513
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode()
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
    assert ansible_vault_encrypted_unicode_1 == ansible_vault_encrypted_unicode_2
    assert ansible_vault_encrypted_unicode_2 == ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 04:43:25.708442
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(b'abcdef')
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(b'abcdef')
    ansible_vault_encrypted_unicode_1.vault = None
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(b'abcdef')
    ansible_vault_encrypted_unicode_2.vault = None
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode(b'abcdef')
    ansible_vault_encrypted_unicode_3.vault = None

# Generated at 2022-06-25 04:43:35.499274
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Initialize test objects
    AnsibleVaultEncryptedUnicode_0 = AnsibleVaultEncryptedUnicode()
    class AnsibleVaultEncryptedUnicode_1(dict):
        ''' sub class for dictionaries '''
        pass
    AnsibleVaultEncryptedUnicode_1_instance = AnsibleVaultEncryptedUnicode_1()
    # Initialize test values
    other = AnsibleVaultEncryptedUnicode_0
    # Call method
    # This return should be False
    return AnsibleVaultEncryptedUnicode_0.__eq__(other)


# Generated at 2022-06-25 04:43:37.892376
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(
        str()
    )
    assert ansible_vault_encrypted_unicode_0.__eq__(str()) == False



# Generated at 2022-06-25 04:43:43.683676
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing import vault

    vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('f')
    vault_encrypted_unicode_0.vault = VaultLib(None)
    ansible_vault_encrypted_unicode_0 = 'f'
    boolean_0 = isinstance(ansible_vault_encrypted_unicode_0, AnsibleVaultEncryptedUnicode)
    ansible_vault_encrypted_unicode_1 = ansible_vault_encrypted_unicode_0
    vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode.from_plaintext('f', vault_encrypted_unicode_0.vault, None)
    ansible_vault_encrypted_unicode_

# Generated at 2022-06-25 04:43:54.436013
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault
    vault = ansible.parsing.vault.VaultLib('test')

# Generated at 2022-06-25 04:44:00.748766
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Create an object of class AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_obj = AnsibleVaultEncryptedUnicode()

    # Get the result of this method call
    result = ansible_vault_encrypted_unicode_obj.is_encrypted()

    assert True == result


# Generated at 2022-06-25 04:44:08.961114
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("\"None\"")
    ansible_vault_encrypted_unicode_0.vault = "AnsibleVault"
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode("\"None\"")
    ansible_vault_encrypted_unicode_1.vault = "AnsibleVault"
    ansible_vault_encrypted_unicode_1.data = "unicode"
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:44:14.768221
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_unicode_1 = AnsibleVaultEncryptedUnicode()
    assert ansible_unicode_0 != ansible_unicode_1, "ansible_unicode_0 == ansible_unicode_1"



# Generated at 2022-06-25 04:44:17.837473
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    test = 'test'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(test)
    assert ansible_vault_encrypted_unicode_0 == 'test'
    assert ansible_vault_encrypted_unicode_0 != 'testing'


# Generated at 2022-06-25 04:44:21.268374
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    avu = AnsibleVaultEncryptedUnicode('blah')
    # assert avu.is_encrypted() is False (python 2.7:  unorderable types)
    assert avu.is_encrypted() == False


# Generated at 2022-06-25 04:44:25.609491
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(None)
    assert ansible_vault_encrypted_unicode_0.__eq__(None) == False


# Generated at 2022-06-25 04:44:34.064907
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import vault

    # Make an AnsibleUnicode instance
    plaintext = 'This is the plaintext!'
    secret = 'This is the secret.'

    vaultlib = vault.VaultLib(secret)
    plaintext_avu = vaultlib.encrypt(plaintext)

    # Test undefined and set vault
    try:
        plaintext_avu.is_encrypted()
        success = False
    except AttributeError:
        success = True
    assert success, 'The encryption status is undefined if the vault is not set'

    plaintext_avu.vault = vaultlib
    result = plaintext_avu.is_encrypted()
    assert result, 'The encryption status is not updated when the vault is set'

    # Test decryption and set ansible_pos(tuple)

# Generated at 2022-06-25 04:44:42.716986
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    ciphertext = "$ANSIBLE_VAULT;1.1;AES256\r\n6331353738623665393466373461666332346373373532303631303665343665353333396432333\r\nc63736136633735366331633364663532636361303933363831333861616231336232663163623833\r\n613330653530333534333163336365\r\n"
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert avu.is_encrypted()
    ansible_vault = AnsibleVault()
    avu.vault = ansible_vault
    assert avu.is_encrypted()



# Generated at 2022-06-25 04:44:49.339636
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleVaultEncryptedUnicode(None)
    ansible_unicode_1 = AnsibleUnicode(None)
    # TODO: assertion fails
    assert not (ansible_unicode_0 == ansible_unicode_1)


# Generated at 2022-06-25 04:44:55.768479
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(34)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(35)
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:45:03.272202
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    a = AnsibleVaultEncryptedUnicode('')
    a._ciphertext = ''
    b = ''
    c = AnsibleVaultEncryptedUnicode('')
    c._ciphertext = ''
    return (a == b) and (c == b) and (b == a)


# Generated at 2022-06-25 04:45:07.391956
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("")
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode("")
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:45:11.282712
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # This is not a real unit test, it's made only to get the coverage report
    # AnsibleVaultEncryptedUnicode has not yet been tested in practice
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.__eq__('test')


# Generated at 2022-06-25 04:45:23.641361
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    # Some of ansible's tests needs this behaviour and will fail if we
    # define the __len__ on that class
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode as Avu
    assert not hasattr(Avu, '__len__')

    # some plain text strings
    plaintext_0 = text_type('plain text 0')
    plaintext_1 = text_type('{ "plain": "text 1" }')
    plaintext_2 = text_type('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/')

# Generated at 2022-06-25 04:45:30.242142
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('ciphertext')
    ansible_vault_encrypted_unicode_0.data = b'plaintext'
    assert ansible_vault_encrypted_unicode_0 == u'plaintext'


# Generated at 2022-06-25 04:45:39.920189
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    unicode_0 = 'lg{Q#>b~gdKjz|p(|k=9'
    bool_0 = ansible_vault_encrypted_unicode_0 != unicode_0
    assert bool_0
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1.data = u'Ox.F(j`f0'
    bool_1 = ansible_vault_encrypted_unicode_1 != ansible_vault_encrypted_unicode_0
    assert bool_1
    bool_2 = ansible_vault_encrypted_unicode_1 != unicode_0
    assert bool_

# Generated at 2022-06-25 04:45:43.961676
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(__file__, vault)
    # Not using assertRaises due to issue found during ansible release 1.9.x (see #28245)
    try:
        ansible_vault_encrypted_unicode_0.__ne__(__file__)
    except AssertionError:
        pass
    else:
        assert False, "Expected AssertionError"


# Generated at 2022-06-25 04:45:50.864860
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test if the return equals the expected result
    from ansible.parsing.vault import VaultLib

    vault_password = 'secret'
    vault = VaultLib(vault_password)

# Generated at 2022-06-25 04:45:55.280414
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("zV+c")
    ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)

# Generated at 2022-06-25 04:46:01.353569
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    '''
    Test the AnsibleVaultEncryptedUnicode class is_encrypted method
    '''
    class VaultStub():
        def is_encrypted(self, obj):
            return False

    seq = 'plaintext'
    secret = 'this is a secret'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, VaultStub(), secret)
    assert avu.is_encrypted() == False



# Generated at 2022-06-25 04:46:08.601410
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(to_bytes(u'ascii', errors='surrogate_or_strict'))
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(to_bytes(u'ascii', errors='surrogate_or_strict'))

    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1



# Generated at 2022-06-25 04:46:17.779290
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # test with valid inputs - 1
    avu1 = AnsibleVaultEncryptedUnicode('')
    avu2 = AnsibleVaultEncryptedUnicode('')
    v1 = avu1 == avu2
    assert v1 == False
    # test with valid inputs - 2
    avu1 = AnsibleVaultEncryptedUnicode('')
    v1 = avu1 == ' '
    assert v1 == False
    # test with valid inputs - 3
    avu1 = AnsibleVaultEncryptedUnicode('universe')
    v1 = avu1 == 'universe'
    assert v1 == True


# Generated at 2022-06-25 04:46:20.784543
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypte_unicode_0 = AnsibleVaultEncryptedUnicode('')
    ansible_vault_encrypte_unicode_0.data = 'ansible_vault_encrypte_unicode_0.data'
    assert ansible_vault_encrypte_unicode_0.__ne__('ansible_vault_encrypte_unicode_0.data') == False



# Generated at 2022-06-25 04:46:26.102515
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('\x04\x14\x11\x04\x12\x1a\t\x1a\x11t\r\t\r\x04\x13\x0e\x1d')
    assert not ansible_vault_encrypted_unicode_0.__ne__('')


# Generated at 2022-06-25 04:46:35.939824
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # ansible_vault_encrypted_unicode_0 is a AnsibleVaultEncryptedUnicode with a null vault
    plaintext = 'Some plaintext'
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n35313731356666383938353664343132366464636631323539623466363533643438393234623163363\n3938616563343161354334656132343032613361383233393365326265393262326366616561653363\n3463343536663632386237383530323430313838343235306162623863303436633832336138333238\n393066\n'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncrypted

# Generated at 2022-06-25 04:46:39.897777
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    tmp = AnsibleVaultEncryptedUnicode("foo")
    # Test normal execution
    assert tmp == "foo"
    assert tmp == u"foo"
    assert tmp == b"foo"


# Generated at 2022-06-25 04:46:42.480658
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode('my text')
    astr = 'another text'
    assert not avu == astr


# Generated at 2022-06-25 04:46:47.264168
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu = AnsibleVaultEncryptedUnicode(b'bar')
    assert avu == 'bar'
    assert not avu != 'bar'
    assert not avu == 'foo'
    assert avu != 'foo'


# Generated at 2022-06-25 04:46:54.749080
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('gAAAAABW8IpU6JMbU6gBOotFjIW8QvM9eBl40iVuKNC5FwQ2KjB1sA7CxahPCHoT8AhpD_ZL-NMezNTPkBs_1j_tA==')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('gAAAAABW8IpU6JMbU6gBOotFjIW8QvM9eBl40iVuKNC5FwQ2KjB1sA7CxahPCHoT8AhpD_ZL-NMezNTPkBs_1j_tA==')

# Generated at 2022-06-25 04:47:01.666939
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # This test requires vault, and fails if the vault library or
    # the vault password is not present. The try: except: around
    # the test below should cause this test to be skipped if vault
    # is not available.
    from ansible.parsing.vault import VaultLib
    vault_secret = b'foobar'
    vault = VaultLib(vault_secret)
    test_string = b'foo'
    ciphertext = vault.encrypt(test_string, vault_secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted() is True


# Generated at 2022-06-25 04:47:08.888329
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    ansible_vault_encrypted_unicode_0.vault = vaultlib.VaultLib('some_secrets')
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == True


# Generated at 2022-06-25 04:47:13.444438
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.data = "data"
    ansible_unicode_0 = AnsibleUnicode()
    ansible_unicode_0.data = "data"

    assert ansible_vault_encrypted_unicode_0 != ansible_unicode_0


# Generated at 2022-06-25 04:47:15.402141
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    avueu = AnsibleVaultEncryptedUnicode('test',)
    assert avueu.is_encrypted()
    assert not avueu.is_encrypted()


# Generated at 2022-06-25 04:47:23.549673
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import binascii
    from ansible.utils.vault import VaultLib

    # a string is not encrypted by default
    ciphertext = 'hello my friend'
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    assert not avu.is_encrypted()

    # a string that is not encrypted and not being managed by a vault
    # is not encrypted either
    avu.vault = None
    assert not avu.is_encrypted()

    # now let's encrypt the same string
    secret = 'my-secret'
    vault = VaultLib(password=secret)
    ciphertext = vault.encrypt(ciphertext, secret)
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()

    #

# Generated at 2022-06-25 04:47:32.848108
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    avu = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;xyz')
    assert avu.is_encrypted()
    assert not avu._ciphertext.startswith('$ANSIBLE_VAULT')
    assert not avu.data.startswith('$ANSIBLE_VAULT')

    avu2 = AnsibleVaultEncryptedUnicode('plaintext')
    assert not avu2.is_encrypted()
    assert not avu2._ciphertext.startswith('$ANSIBLE_VAULT')
    assert avu2.data.startswith('plain')


# Generated at 2022-06-25 04:47:42.293278
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_1 = AnsibleUnicode()
    ansible_unicode_1.ansible_pos = [None, 0, 0]
    ansible_unicode_1.data = '''test'''

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.ansible_pos = [None, 0, 0]
    ansible_vault_encrypted_unicode_0.ciphertext = '''$ANSIBLE_VAULT;1.1;AES256'''
    ansible_vault_encrypted_unicode_0.vault = to_text('''ansible_vault''')

    assert ansible_vault_encrypted_unicode_0 != ansible_unicode_1



# Generated at 2022-06-25 04:47:48.118096
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(((b'\x00\x00\x00\x00\x00\x00\x00\x00') * 10))
    assert (ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0) == False)


# Generated at 2022-06-25 04:47:49.875217
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('P\x01')
    assert ansible_vault_encrypted_unicode_0.__eq__('M') == False


# Generated at 2022-06-25 04:47:54.107286
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    assert AnsibleVaultEncryptedUnicode.__eq__(None) == false
    assert AnsibleVaultEncryptedUnicode.__eq__(AnsibleVaultEncryptedUnicode()) == false



# Generated at 2022-06-25 04:48:02.153915
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    avue_unencrypted = AnsibleVaultEncryptedUnicode(u'This is a string')

# Generated at 2022-06-25 04:48:13.878835
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_2.data = "foo"
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_2
    assert ansible_vault_encrypted_unicode_2 != ansible_vault_encrypted_unicode_0
    assert ansible_vault_encrypted_unicode_1 != ansible_vault

# Generated at 2022-06-25 04:48:18.513542
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib

    password = 'password'

    vault = VaultLib(password)
    # Test encrypted string
    test_data = vault.encrypt("fooo")
    avu = AnsibleVaultEncryptedUnicode('fooo')
    avu.vault = vault
    assert avu.is_encrypted() == vault.is_encrypted(test_data)
    # Test unencrypted string
    test_data = "fooo"
    avu.data = test_data
    assert avu.is_encrypted() == vault.is_encrypted(test_data)


# Generated at 2022-06-25 04:48:25.299260
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    plaintext = u'my plaintext'

# Generated at 2022-06-25 04:48:28.373735
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    pstr = "hello world"
    assert pstr != AnsibleVaultEncryptedUnicode.from_plaintext(
        pstr, vault=None, secret=None)
    assert AnsibleVaultEncryptedUnicode.from_plaintext(
        pstr, vault=None, secret=None) != pstr


# Generated at 2022-06-25 04:48:33.975555
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Setup
    ansible_unicode_1 = AnsibleUnicode()
    ansible_unicode_2 = AnsibleUnicode()

    # Inspection
    # AssertionError: The first argument of __ne__ should be AnsibleVaultEncryptedUnicode.
    # assert_raises(AssertionError, ansible_unicode_1.__ne__, ansible_unicode_2)

    ansible_unicode_1.data = "Hello"
    ansible_unicode_2.data = "World"
    assert ansible_unicode_1.__ne__(ansible_unicode_2)



# Generated at 2022-06-25 04:48:36.314216
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    assert ansible_vault_encrypted_unicode_0.__eq__()


# Generated at 2022-06-25 04:48:36.762099
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    pass

# Generated at 2022-06-25 04:48:45.709296
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:48:47.298465
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    assert ansible_vault_encrypted_unicode_0.__ne__(None) == False


# Generated at 2022-06-25 04:48:48.709382
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ob = AnsibleVaultEncryptedUnicode()
    ob.__eq__()
    ob.__eq__(None)


# Generated at 2022-06-25 04:48:53.832967
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()


# Generated at 2022-06-25 04:48:59.292458
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.__ne__()


# Generated at 2022-06-25 04:49:06.489149
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    assert not ansible_vault_encrypted_unicode_0.__eq__((AnsibleUnicode(),))


# Generated at 2022-06-25 04:49:14.048939
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_type_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_type_unicode_0)
    ansible_unicode_0 = AnsibleUnicode()
    ansible_unicode_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_unicode_0)


# Generated at 2022-06-25 04:49:25.638267
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.vault = AnsibleVaultLib()

    # Boolean for parameter ANSIBLE_VAULT_PASSWORD not set, defaulting to False
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_1.vault = AnsibleVaultLib()


# Generated at 2022-06-25 04:49:32.716892
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("fB")
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode("")
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1



# Generated at 2022-06-25 04:49:39.069808
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Setup mock object for AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_obj = AnsibleVaultEncryptedUnicode('string')

    # Setup mock object for AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_obj_1 = AnsibleVaultEncryptedUnicode('string_1')

    # assert that the return value of method under test is as expected
    assert ansible_vault_encrypted_unicode_obj.__ne__(ansible_vault_encrypted_unicode_obj_1) == True



# Generated at 2022-06-25 04:49:47.387374
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.vault = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.vault.is_encrypted(ansible_vault_encrypted_unicode_0._ciphertext)


# Generated at 2022-06-25 04:49:48.643015
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Constructor test
    test_case_0()



# Generated at 2022-06-25 04:49:55.019807
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    int_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    unicode_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:50:01.984972
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:50:08.995102
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_0._ciphertext = 'abc'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1.vault = None
    ansible_vault_encrypted_unicode_1._ciphertext = 'abc'
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:50:16.625809
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.vault = 'VaultLib.AnsibleVaultEncryptedUnicode.test'
    ansible_vault_encrypted_unicode_0.data = 'ansible_vault_encrypted_unicode_0.data'
    assert ansible_vault_encrypted_unicode_0 == 'ansible_vault_encrypted_unicode_0.data'


# Generated at 2022-06-25 04:50:23.656698
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_4 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_5 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
   

# Generated at 2022-06-25 04:50:30.231587
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_unicode_0)


# Generated at 2022-06-25 04:50:37.372822
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.data = "foo"
    ansible_vault_encrypted_unicode_0.data = "bar"
    assert not ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 04:50:43.318709
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    var_0 = AnsibleUnicode()
    assert not ansible_vault_encrypted_unicode_0 == var_0


# Generated at 2022-06-25 04:50:51.300917
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert ansible_vault_encrypted_unicode_0.is_encrypted()
    assert not ansible_vault_encrypted_unicode_2.is_encrypted()
    assert not ansible_vault_encrypted_unicode_1.is_encrypted()



# Generated at 2022-06-25 04:50:56.225345
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    boolean_0 = ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:51:04.667985
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_unicode_1 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_1)
    ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:51:11.374683
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    boolean_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:23.342598
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:51:28.695637
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    assert ansible_vault_encrypted_unicode_0.__ne__(None)


# Generated at 2022-06-25 04:51:34.898316
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_unicode_1 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_1)

    try:
        ansible_vault_encrypted_unicode_1.is_encrypted()
    except Exception as e:
        print(e.args)


# Generated at 2022-06-25 04:51:38.636395
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)

    #Test normal execution
    assert ansible_vault_encrypted_unicode_0.__eq__('test_value') == False


# Generated at 2022-06-25 04:51:42.418822
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_unicode_0 = AnsibleUnicode()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:47.829507
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.data = "test string"
    assert ansible_vault_encrypted_unicode_0.__ne__(AnsibleVaultEncryptedUnicode()) is True


# Generated at 2022-06-25 04:51:50.089414
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:52.055248
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1.is_encrypted()


# Generated at 2022-06-25 04:52:02.013661
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_1)
    ansible_vault_encrypted_unicode_0.vault = ansible_vault_0
    ansible_vault_encrypted_unicode_1.vault = ansible_vault_1
    return_value_test_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    return_value_test_1 = ansible_vault_encrypted_unicode_1.is_encrypted()



# Generated at 2022-06-25 04:52:14.056780
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_unicode_0 = AnsibleUnicode()
    ansible_unicode_1 = AnsibleUnicode()
    ansible_unicode_0.ansible_pos = ("test_AnsibleVaultEncryptedUnicode___ne__.py", 25, 0)
    ansible_unicode_1.ansible_pos = ("test_AnsibleVaultEncryptedUnicode___ne__.py", 26, 0)
    ansible_vault_encrypted_unicode_0.data = ansible_unicode_0
    ansible_vault_encrypted_unicode_1.data = ans

# Generated at 2022-06-25 04:52:23.444487
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_unicode_1)
    ansible_vault_encrypted_unicode_0.vault = ansible_vault_0

    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
    assert not (ansible_vault_encrypted_unicode_0 == ansible_unicode_0)
