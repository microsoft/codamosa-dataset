

# Generated at 2022-06-25 04:42:49.732420
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    str_0 = 'a'
    int_0 = 0
    int_1 = 1
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__getslice__(int_0, int_1)


# Generated at 2022-06-25 04:42:57.208678
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = ''
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    assert var_0 is True


# Generated at 2022-06-25 04:43:01.172899
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    str_0 = 'string'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    int_arg_0 = 3
    int_arg_1 = 7
    var_0 = ansible_vault_encrypted_unicode_0.__getslice__(int_arg_0, int_arg_1)


# Generated at 2022-06-25 04:43:04.077566
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    pass


# Generated at 2022-06-25 04:43:08.833377
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    str_0 = "qzrZ1kAj1g9p"
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = "F2"
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    var_0 = ansible_vault_encrypted_unicode_0.__contains__(ansible_vault_encrypted_unicode_1)
    assert var_0 == False


# Generated at 2022-06-25 04:43:13.058584
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:43:17.783119
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(str_0)


# Generated at 2022-06-25 04:43:21.156042
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    
    # ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str)
    # assert __eq__(ansible_vault_encrypted_unicode_0) == True
    assert True == True


# Generated at 2022-06-25 04:43:23.496297
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:43:26.097193
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__getslice__(0, 10)


# Generated at 2022-06-25 04:43:33.434651
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    var_0 = AnsibleVaultEncryptedUnicode(str_0).__ne__(str_0)
    assert var_0 == True


# Generated at 2022-06-25 04:43:37.481700
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = ''
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(str_1)


# Generated at 2022-06-25 04:43:43.176502
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:43:47.305405
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__('foo')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:43:50.632592
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__('string')
    assert var_0 == False


# Generated at 2022-06-25 04:44:01.645008
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)

    ansible_vault_encrypted_unicode_1.vault = ansible_vault_encrypted_unicode_0.vault
    ansible_vault_encrypted_unicode_1.data = ansible_vault_encrypted_unicode_0.data

    var_0 = ansible_vault_encrypted_unicode_1.__eq__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:44:09.832307
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:44:16.007144
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = ''
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:44:25.790327
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Setup the mock vault
    class MockVault:
        pass
    mock_vault = MockVault()
    mock_vault.is_encrypted = lambda x: True

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('test')
    ansible_vault_encrypted_unicode_0.vault = mock_vault
    str_0 = 'test'
    var_1 = ansible_vault_encrypted_unicode_0.__ne__(str_0)
    assert var_1 == False


# Generated at 2022-06-25 04:44:30.855412
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = 'example string'
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)
    assert True == var_0


# Generated at 2022-06-25 04:44:41.989291
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.data = 'asdf'
    ansible_vault_encrypted_unicode_4 = AnsibleVaultEncryptedUnicode('asdf')
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_4)
    assert bool_0 != True


# Generated at 2022-06-25 04:44:47.695047
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.__eq__(str_0) == False


# Generated at 2022-06-25 04:44:52.235286
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_b = b'0'
    ansible_vault_encrypted_unicode_b = AnsibleVaultEncryptedUnicode(str_b)
    str_0 = '0'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_b.__eq__(ansible_vault_encrypted_unicode_0)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = '1'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    var_1 = ansible_vault_encrypted_unicode_0.__

# Generated at 2022-06-25 04:44:56.823521
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = ''
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:45:00.560326
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(0)


# Generated at 2022-06-25 04:45:03.707185
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    ansible_vault_encrypted_unicode_0 = ansible_vault_encrypted_unicode_0.__ne__('')


# Generated at 2022-06-25 04:45:06.929998
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__('a')


# Generated at 2022-06-25 04:45:11.137239
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = '%'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    var_1 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert var_0 == var_1


# Generated at 2022-06-25 04:45:14.667050
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # ansible_vault_encrypted_unicode_0 is a AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('str_0')
    ansible_vault_encrypted_unicode_0.vault = None
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:45:22.566928
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = ''
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:45:32.096240
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("")
    ansible_vault_encrypted_unicode_0.__is_encrypted()



# Generated at 2022-06-25 04:45:38.727285
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__("")



# Generated at 2022-06-25 04:45:49.607915
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Setup test data
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = ''
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    str_2 = ''
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_2)
    str_3 = ''
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode(str_3)
    str_4 = ''
    ansible_vault_encrypted_unicode_4 = AnsibleVaultEncryptedUnicode(str_4)
    str_5 = ''
    ansible_vault

# Generated at 2022-06-25 04:45:54.977328
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:45:59.616543
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_0 = ''
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(str_0)




# Generated at 2022-06-25 04:46:07.401080
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'test'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode('test-0')
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1.data)
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    assert ansible_vault_encrypted_unicode_0.__eq__(str_0)
    assert not ansible_vault_encrypted_

# Generated at 2022-06-25 04:46:13.167885
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Test fixture
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    # Test call
    result = ansible_vault_encrypted_unicode_0.is_encrypted()
    # Test assertions
    assert(not result)


# Generated at 2022-06-25 04:46:18.353406
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # case 1
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    assert (ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1)
    # case 2
    str_0 = to_bytes('')
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)

# Generated at 2022-06-25 04:46:25.305027
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:46:35.881481
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret
    vault_secret = get_file_vault_secret(None, None)
    vault = VaultLib(vault_secret)

    for str_1 in ['', '1', '11']:
        ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode.from_plaintext(str_1, vault, vault_secret)
        ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode.from_plaintext(str_1, vault, vault_secret)

# Generated at 2022-06-25 04:46:49.163145
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0._ciphertext = '1'
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('')
    ansible_vault_encrypted_unicode_1.vault = None
    ansible_vault_encrypted_unicode_1.vault = None
    assert not ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)



# Generated at 2022-06-25 04:46:53.569795
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:46:57.128267
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    boolean_0 = ansible_vault_encrypted_unicode_0.__ne__('')


# Generated at 2022-06-25 04:47:00.587962
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = str_0.__eq__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:47:04.161890
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.ansible_pos = ('src', 1, 1)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__('')
    assert var_0 == False


# Generated at 2022-06-25 04:47:07.844485
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(str_0)


# Generated at 2022-06-25 04:47:10.884055
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(str_0)


# Generated at 2022-06-25 04:47:18.091335
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    try:
        # Case 1
        str_0 = 'qrst'
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
        bool_0 = ansible_vault_encrypted_unicode_0.__eq__(str_0)
    except Exception as e:
        print('Error in Unit Test #0:')
        print(e)
    else:
        print('Unit Test #0 Passed')


# Generated at 2022-06-25 04:47:21.478823
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('string')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('other string')
    flag_0 = ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
    flag_1 = ansible_vault_encrypted_unicode_1 != ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 04:47:28.967819
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.path import unfrackpath

    src  = unfrackpath(__file__)
    test = AnsibleVaultEncryptedUnicode.from_plaintext(u"is_encrypted", VaultLib(password_file=unfrackpath(src + '/password-file')), "debug")
    assert test.is_encrypted()

# Generated at 2022-06-25 04:47:38.716859
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:47:45.736655
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    atexit_object_0 = False
    try:
        # Setup
        import ansible.parsing.vault as ansible_vault_1
        ansible_vault_0 = ansible_vault_1.VaultLib([])
        str_0 = '$ANSIBLE_VAULT;1.1;AES256;'
        ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode.from_plaintext(str_0, ansible_vault_0, 'SomeSecret')
        # Assertion
        assert ansible_vault_encrypted_unicode_1.is_encrypted()
    except:
        atexit_object_0 = True
    finally:
        if not (not atexit_object_0):
            pass


# Generated at 2022-06-25 04:47:49.403799
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.__ne__(str_0)


# Generated at 2022-06-25 04:47:55.711216
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_0.data = str_0
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(str_0)


# Generated at 2022-06-25 04:48:02.526405
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:48:13.657782
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    str_0 = ''
    int_1 = 1
    str_2 = 'a'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_2)

    # Should not equal None
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(None)
    assert not var_0

    # Should not equal a int
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(int_1)
    assert not var_0

    # Should equal an AnsibleVaultEncryptedUnicode of the same value

# Generated at 2022-06-25 04:48:17.957771
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ';!'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__('')


# Generated at 2022-06-25 04:48:21.534223
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__()


# Generated at 2022-06-25 04:48:26.676543
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    result_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert result_0 == False


# Generated at 2022-06-25 04:48:29.128971
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:48:33.921618
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert AnsibleVaultEncryptedUnicode.is_encrypted() == None


# Generated at 2022-06-25 04:48:38.058756
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    value = ansible_vault_encrypted_unicode_0.__ne__(str_0)


# Generated at 2022-06-25 04:48:47.274602
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:48:49.461167
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ans_vault_enc_un_0 = AnsibleVaultEncryptedUnicode('hello')
    unicode_0 = 'hello'
    var_0 = ans_vault_enc_un_0.__ne__(unicode_0)
    assert var_0


# Generated at 2022-06-25 04:48:57.743620
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # A collection of test cases for AnsibleVaultEncryptedUnicode class.
    # Test case __ne__ of class AnsibleVaultEncryptedUnicode
    # Testing input: 'Hello World'
    str_0 = 'Hello World'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    # Testing input: 'Hello World'
    str_1 = 'Hello World'
    # Expected output: False
    assert (ansible_vault_encrypted_unicode_0 != str_1) == False

    # Test case __ne__ of class AnsibleVaultEncryptedUnicode
    # Testing input: ansible_vault_encrypted_unicode_0
    str_0 = 'ansible_vault_encrypted_unicode_0'
    ansible

# Generated at 2022-06-25 04:49:02.753594
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:49:07.948525
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Default constructor
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("qwerty")

    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    var_1 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:49:15.962728
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = ''
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_1.__ne__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:49:26.257430
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:49:32.629581
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(str_0)


# Generated at 2022-06-25 04:49:42.461631
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = "text"
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert var_0 is False


# Generated at 2022-06-25 04:49:48.517124
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'a'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = FakeVault(False)
    x_0 = ansible_vault_encrypted_unicode_0.is_encrypted()

# Generated at 2022-06-25 04:49:51.508132
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert var_0 == False


# Generated at 2022-06-25 04:49:59.835264
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'This is not a string'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'ThIs'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)
    assert var_0 == True



# Generated at 2022-06-25 04:50:06.620866
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = ''
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(str_1)


# Generated at 2022-06-25 04:50:14.244129
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = '2'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(str_0)
    assert isinstance(var_0, text_type)
    var_1 = ansible_vault_encrypted_unicode_0.__eq__(str_0)
    assert var_0 == var_1



# Generated at 2022-06-25 04:50:17.447012
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    int_0 = ansible_vault_encrypted_unicode_0.__eq__('')


# Generated at 2022-06-25 04:50:25.649469
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'gPQTqT3oqhQM'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = None
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(str_0)


# Generated at 2022-06-25 04:50:30.030703
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(str_0)


# Generated at 2022-06-25 04:50:41.760197
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

    # str_1 = ''
    # ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    # var_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    # var_1 = ansible_vault_encrypted_unicode_1.__eq__(AnsibleVaultEncryptedUnicode(str_0))
    # assumptions = [var_0, var_1]
    # assert var_0 == var_1


# Generated at 2022-06-25 04:50:52.917713
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    try:
        var_0 = ansible_vault_encrypted_unicode_0.__eq__(False)
    except Exception as e:
        var_1 = e
        var_0 = False

    assert var_0 == False


# Generated at 2022-06-25 04:50:57.780352
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.data
    ansible_vault_encrypted_unicode_0.data = str_0

# Generated at 2022-06-25 04:51:00.241720
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:04.976021
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("KjbMkPLGnxNxRJhA")
    boolean_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert boolean_0 == True


# Generated at 2022-06-25 04:51:11.575946
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # This test should be revised when supporting multiple cipher modules
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-25 04:51:19.103100
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.data = str_0
    var_0 = ansible_vault_encrypted_unicode_0.__ne__({'ciphertext':str_0})
    assert var_0 == True


# Generated at 2022-06-25 04:51:26.296538
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    ansible_vault_encrypted_unicode_1.vault = None
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:51:31.786392
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__('')


# Generated at 2022-06-25 04:51:35.228981
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'Hello World!'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert(ansible_vault_encrypted_unicode_0.is_encrypted() is True)


# Generated at 2022-06-25 04:51:39.280706
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = None
    # Line 1
    test_str = 'foo'
    result = ansible_vault_encrypted_unicode_0 != test_str
    
    assert result == True


# Generated at 2022-06-25 04:51:46.994657
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:51:52.856569
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(str_0)


# Generated at 2022-06-25 04:51:57.548537
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert ansible_vault_encrypted_unicode_1.__eq__(ansible_vault_encrypted_unicode_2) == True


# Generated at 2022-06-25 04:52:01.874717
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    try:
        # Unit test setup
        str_0 = ''
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

        # Unit test
        bool_0 = ansible_vault_encrypted_unicode_0.__ne__(str_0)

        # Unit test assertions
        assert bool_0

    except Exception as e:
        raise e


# Generated at 2022-06-25 04:52:06.887233
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    str_1 = 'string'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    var_1 = ansible_vault_encrypted_unicode_1.is_encrypted()


# Generated at 2022-06-25 04:52:10.932079
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:52:17.203479
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_3 = ansible_vault_encrypted_unicode_0.__ne__(str_0)


# Generated at 2022-06-25 04:52:17.875574
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    assert True


# Generated at 2022-06-25 04:52:21.889303
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
