

# Generated at 2022-06-25 04:42:36.914050
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():

    # Setup
    o = AnsibleVaultEncryptedUnicode.from_plaintext(['banana'], None, None)

    # Assertions
    assert ('banana' in o)


# Generated at 2022-06-25 04:42:42.092114
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_rfind():
    ansible_vault_encrypted_unicode_obj = AnsibleVaultEncryptedUnicode('sdfsdfsdfsdfs')
    ansible_vault_encrypted_unicode_obj.rfind('')


# Generated at 2022-06-25 04:42:48.084779
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    # Create an AnsibleVaultEncryptedUnicode with the following arguments
    #
    # To create the AnsibleVaultEncryptedUnicode data, we use:
    #
    # # 
    # # Initialize a Vault object and encrypt the plaintext
    # # 
    # vault = vaultlib.VaultLib('secret')
    # ansible_vault_encrypted_unicode_data = vault.encrypt('mydata')
    # 
    # Then, we create a AnsibleVaultEncryptedUnicode object with the data stored in: ansible_vault_encrypted_unicode_data
    #
    ansible_vault_encrypted_unicode_object_0 = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_data)
    assert ansible_vault_encrypted_

# Generated at 2022-06-25 04:42:51.228497
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT:')
    assert isinstance(ansible_vault_encrypted_unicode_0.is_encrypted(), bool)


# Generated at 2022-06-25 04:42:55.207751
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Exception - test
    try:
        ciphertext = AnsibleVaultEncryptedUnicode('')
        ciphertext.vault = None
        assert ciphertext != ''
    except:
        pass


# Generated at 2022-06-25 04:42:58.630511
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    # Test case with a valid value
    assert ansible_vault_encrypted_unicode_0.__contains__(AnsibleVaultEncryptedUnicode.from_plaintext(str_0, vault_lib_0, str_1))


# Generated at 2022-06-25 04:43:06.950019
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:43:13.600347
# Unit test for method rfind of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:43:19.002206
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.find(ansible_vault_encrypted_unicode_1)



# Generated at 2022-06-25 04:43:26.510705
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    print('Testing AnsibleVaultEncryptedUnicode.__contains__')
    ansible_vault_encrypted_unicode_0 = ansible_vault.AnsibleVaultEncryptedUnicode.from_plaintext(ansible_vault, [1, 2, 3])
    ansible_vault_encrypted_unicode_1 = ansible_vault.AnsibleVaultEncryptedUnicode.from_plaintext(ansible_vault, [2, 3, 4])
    ansible_vault_encrypted_unicode_2 = ansible_vault.AnsibleVaultEncryptedUnicode.from_plaintext(ansible_vault, [3, 4, 5])
    ansible_vault_encrypted_unicode_3 = ansible_vault.AnsibleVaultEncryptedUnic

# Generated at 2022-06-25 04:43:42.754280
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(35)
    ansible_vault_encrypted_unicode_0.data = "bu'hO"
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(35)
    ansible_vault_encrypted_unicode_1.data = "bu'hO"
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(35)
    ansible_vault_encrypted_unicode_0.data = "bu'hO"
    ansible_vault_encrypted_unicode_1 = Ansible

# Generated at 2022-06-25 04:43:44.471695
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_v_e_u = AnsibleVaultEncryptedUnicode(string.printable)
    ret = ansible_v_e_u.__ne__('A')

    assert ret is False


# Generated at 2022-06-25 04:43:54.488934
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('mzkdfr')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('xvdsvp')
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode('Stxqnq')
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode('Euyrxl')
    assert(ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1))
    assert(ansible_vault_encrypted_unicode_2.__ne__(ansible_vault_encrypted_unicode_3))


# Generated at 2022-06-25 04:44:05.259948
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    ansible_vault_encrypted_unicode_str_0 = '_t'
    ansible_vault_encrypted_unicode_str_1 = '_t'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext(ansible_vault_encrypted_unicode_str_0, None, None)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode.from_plaintext(ansible_vault_encrypted_unicode_str_1, None, None)
    ansible_vault_encrypted_unicode_2 = ansible_vault_encrypted_unicode_0 < ansible_vault_encrypted_unicode_1
    print(ansible_vault_encrypted_unicode_2)

#

# Generated at 2022-06-25 04:44:15.889014
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("'netbiosName': '`}&lz{R:Ky@L%cKZojt<!=bxE3k0f@KXy{5>'")
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode("'netbiosName': '`}&lz{R:Ky@L%cKZojt<!=bxE3k0f@KXy{5>'")
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:44:22.730055
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('qP5n5j5A5eEGRITg5C5408')
    assert ansible_vault_encrypted_unicode_0.__lt__('F')
    assert ansible_vault_encrypted_unicode_0.__lt__('D')
    ansible_vault_encrypted_unicode_0.__lt__('P')
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('j3qn7Tbs')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('UfVcFb8jv')

# Generated at 2022-06-25 04:44:29.612674
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('test')
    ansible_vault_encrypted_unicode_0.data = 'test'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('test')
    ansible_vault_encrypted_unicode_1.data = 'test'

    assert ansible_vault_encrypted_unicode_0 < ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:44:34.755950
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # First test with string arg
    foo = AnsibleVaultEncryptedUnicode('foo')
    bar = AnsibleVaultEncryptedUnicode('bar')
    assert foo < 'bar'
    assert 'bar' > foo
    assert foo < bar
    assert bar > foo
    assert not foo < 'foo'
    assert not 'foo' < foo
    assert not foo < None
    assert not None < foo


# Generated at 2022-06-25 04:44:37.896680
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_1 = ansible_vault_encrypted_unicode_0
    ansible_vault_encrypted_unicode_2 = ansible_vault_encrypted_unicode_0
    ansible_vault_encrypted_unicode_1.__eq__(ansible_vault_encrypted_unicode_2)
    ansible_vault_encrypted_unicode_1.__eq__(unicode_0)


# Generated at 2022-06-25 04:44:42.278232
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('sOmQz7TTf6FcOJ7f/XZ3q/b/CdJcQ0/LefRx+IaLJ04=', vault)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('5JtL5E2QU5ooZbPBA2HYJg==', vault)
    ansible_vault_encrypted_unicode_0.vault = vault
    ansible_vault_encrypted_unicode_1.vault = vault
    assert ansible_vault_encrypted_unicode_0 <= ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:45:01.264578
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    global str_0

    encrypted_0 = ''
    encrypted_1 = ''
    str_1 = ''
    str_2 = 'a'
    str_3 = 'A'
    str_4 = 'aA'
    str_5 = 'aaA'
    str_6 = 'aAa'
    str_7 = 'aaa'
    str_8 = 'aZ'
    encrypted_0 = str_7
    encrypted_1 = str_6
    str_1 = encrypted_0 < encrypted_1
    test_case_0()
    encrypted_0 = str_6
    encrypted_1 = str_5
    str_2 = encrypted_0 < encrypted_1
    test_case_0()
    encrypted_0 = str_5
    encrypted_1 = str_4
    str_3 = encrypted_0

# Generated at 2022-06-25 04:45:06.480764
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'A'
    str_1 = 'B'
    obj_0 = AnsibleVaultEncryptedUnicode(str_0)
    obj_0._ciphertext = str_0
    ans = obj_0.__ne__(str_1)
    if ans != str_0 != str_1:
        raise AssertionError()



# Generated at 2022-06-25 04:45:07.643741
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    str_0 = "test"
    str_1 = "test"


# Generated at 2022-06-25 04:45:13.130537
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'A'
    str_1 = 'A'
    str_3 = 'aa'
    obj = AnsibleVaultEncryptedUnicode(str_0)
    obj._ciphertext = str_0
    ansible_class = AnsibleVaultEncryptedUnicode
    ansible_class._ciphertext = str_1
    tst = obj != ansible_class
    assert tst == False
    ansible_class._ciphertext = str_3
    tst = obj != ansible_class
    assert tst == True


# Generated at 2022-06-25 04:45:14.954804
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'A'
    str_1 = 'A'
    result = str_0 == str_1



# Generated at 2022-06-25 04:45:19.883443
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    str_0 = 'A'
    ansible_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_0 < 'B'


# Generated at 2022-06-25 04:45:23.070923
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'A'
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(str_0, vault, secret)
    expected = True
    actual = encrypted == str_0
    assert expected == actual


# Generated at 2022-06-25 04:45:25.930755
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    str_0 = 'A'
    str_1 = 'B'
    # AssertionError: False not less than True
    assert (str_0 < str_1) == True


# Generated at 2022-06-25 04:45:29.832360
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    test_case_0()


# Generated at 2022-06-25 04:45:37.780078
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    str_0 = 'A'
    str_1 = 'B'
    str_0_obj = AnsibleVaultEncryptedUnicode(str_0)
    str_1_obj = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.__lt__(str_1_obj)
    ansible_vault_encrypted_unicode_0.__lt__(str_1)


# Generated at 2022-06-25 04:45:45.213014
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'A'
    str_1 = 'B'
    str_2 = 'C'
    str_3 = 'D'
    str_4 = 'E'
    str_5 = 'F'


# Generated at 2022-06-25 04:45:48.738304
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    str_0 = 'A'
    new_inst = AnsibleVaultEncryptedUnicode(str_0)
    start_0 = 1
    end_0 = 1
    ansible_getslice__0 = new_inst.__getslice__(start_0, end_0)
    assert ansible_getslice__0 is not None


# Generated at 2022-06-25 04:45:52.374534
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Runs the __getslice__ method of AnsibleVaultEncryptedUnicode on a AnsibleVaultEncryptedUnicode
    # object with a an empty plaintext
    str_0 = AnsibleVaultEncryptedUnicode('')
    str_1 = str_0.__getslice__(1, 1)
    assert str_1 == ''


# Generated at 2022-06-25 04:46:03.114089
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'foo'
    str_1 = '!vault |'

# Generated at 2022-06-25 04:46:05.737782
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    global str_0
    assert isinstance(str_0, AnsibleVaultEncryptedUnicode)

    str_1 = 'A'

    result = str_0.__eq__(str_1)
    print(result)


# Generated at 2022-06-25 04:46:17.984593
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    str_0 = 'A'
    avueu_0 = AnsibleVaultEncryptedUnicode.from_plaintext(str_0, vault, 'secret')
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext("''", vault, 'secret')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode.from_plaintext("'F$Yz)u'", vault, 'secret')
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode.from_plaintext("'9-\'T'", vault, 'secret')

# Generated at 2022-06-25 04:46:19.927393
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'A'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__('A')
    assert bool_0


# Generated at 2022-06-25 04:46:24.368432
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # func(AnsibleVaultEncryptedUnicode, )
    # Testing result: raises
    with pytest.raises(NotImplementedError):
        str_0 = 'A'
        str_0.is_encrypted()
        print(str_0)


# Generated at 2022-06-25 04:46:35.549545
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_vault_secret

    vault = VaultLib()
    secret_file_path = '/tmp/ansible_secret_file.txt'
    cmd = 'echo secret > ' + secret_file_path
    _sys.stdout.write("\nExecuting: " + cmd)
    from os import system
    system(cmd)
    secret = get_vault_secret(filename=secret_file_path)
    priv_int = 1
    priv_int = AnsibleVaultEncryptedUnicode.from_plaintext("string", vault, secret)
    result = priv_int.is_encrypted()
    assert (result == True)


# Generated at 2022-06-25 04:46:39.233542
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'A'
    avu = AnsibleVaultEncryptedUnicode(str_0)
    assert avu.is_encrypted() == False


# Generated at 2022-06-25 04:46:47.095892
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    avu = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256\n\n")
    assert avu.is_encrypted() == True


# Generated at 2022-06-25 04:46:49.932009
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_1 = 'A'
    str_2 = 'b'
    # str_2 = 'c'
    assert(str_1 == str_2)

    key_0 = 'b'
    key_1 = 'a'
    # assert(key_0 == key_1)


# Generated at 2022-06-25 04:46:56.505202
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = AnsibleVaultEncryptedUnicode(ciphertext='A')
    # Test case: str_0: AnsibleVaultEncryptedUnicode object with value "A"
    try:
        ansible_vault_encrypted_unicode__eq_(str_0, 'A')
    except Exception as e:
        print(e)
    # Test case: str_0: AnsibleVaultEncryptedUnicode object with value "A"
    try:
        ansible_vault_encrypted_unicode__eq_(str_0, 'B')
    except Exception as e:
        print(e)


# Generated at 2022-06-25 04:46:57.599544
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    uni_0 = AnsibleVaultEncryptedUnicode()


# Generated at 2022-06-25 04:46:59.532211
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_1 = 'abcd'
    str_2 = 'abcd'
    str_1 == str_2


# Generated at 2022-06-25 04:47:08.968878
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # x1 is created here, x2 is created in AnsibleVaultEncryptedUnicode.__eq__()
    x1 = AnsibleVaultEncryptedUnicode.from_plaintext(value, )
    x2 = AnsibleVaultEncryptedUnicode.from_plaintext(value, )
    if (x1 != x2):
        # State 0
        if (x1 != x2):
            # State 2
            if (x1 != x2):
                # State 4
                str_1 = str(x1)
                str_2 = str(x2)

# Generated at 2022-06-25 04:47:10.348486
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'A'
    str_2 = 'C'
    assert str_0 != str_2


# Generated at 2022-06-25 04:47:12.971987
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'A'
    str_1 = 'B'
    exc_1 = AnsibleVaultEncryptedUnicode(str_0)
    assert((exc_1 == str_1) == False)


# Generated at 2022-06-25 04:47:14.647284
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode.from_plaintext('A', object(), object()) == 'A'


# Generated at 2022-06-25 04:47:19.569409
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'A'
    py_expected = test_case_0()
    py_actual = py_expected
    print("Expected : ", py_expected)
    print("Actual   : ", py_actual)
    assert py_expected == py_actual, "Test Case Failed: test_AnsibleVaultEncryptedUnicode___eq__"


# Generated at 2022-06-25 04:47:33.819821
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    obj_0 = AnsibleVaultEncryptedUnicode.from_plaintext('',)
    obj_0.data = test_case_0()
    res_0 = obj_0.__ne__(1)
    res_1 = obj_0.__ne__('')
    res_2 = obj_0.__ne__(True)
    res_3 = obj_0.__ne__({})
    res_4 = obj_0.__ne__([])
    res_5 = obj_0.__ne__(obj_0)
    res_6 = obj_0.__ne__('A')
    res_7 = obj_0.__ne__('A')


# Generated at 2022-06-25 04:47:40.632250
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Create an instance of AnsibleVaultEncryptedUnicode
    str_0 = AnsibleVaultEncryptedUnicode('pass')
    ansibleVaultEncryptedUnicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext(str_0, None, 'MyVaultSecret')
    # Assert that the value of ansibleVaultEncryptedUnicode_0.__eq__ is equal to False
    assert ansibleVaultEncryptedUnicode_0.__eq__ is False


# Generated at 2022-06-25 04:47:51.881979
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'A'
    str_1 = 'B'
    str_2 = 'A'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext(str_0, None, None)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode.from_plaintext(str_1, None, None)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode.from_plaintext(str_2, None, None)
    ansible_vault_encrypted_unicode_2._vault = None
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode.from_plaintext(str_0, None, None)
   

# Generated at 2022-06-25 04:47:54.706158
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'A'
    str_1 = 'A'
    assert (str_0 == str_1)


# Generated at 2022-06-25 04:48:02.062611
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'A'
    avu_0 = AnsibleVaultEncryptedUnicode.from_plaintext(str_0, AnsibleVault(), 'pass')
    str_1 = 'B'
    avu_1 = AnsibleVaultEncryptedUnicode.from_plaintext(str_1, AnsibleVault(), 'pass')
    str_2 = 'A'
    avu_2 = AnsibleVaultEncryptedUnicode.from_plaintext(str_2, AnsibleVault(), 'pass')
    assert avu_0 != avu_1
    assert avu_0 == avu_2
    assert avu_0 != str_1
    assert avu_0 == str_2


# Generated at 2022-06-25 04:48:08.713154
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
   str_0 = 'A'
   avu_0 = AnsibleVaultEncryptedUnicode(str_0)
   avu_1 = AnsibleVaultEncryptedUnicode('B')
   if (avu_1 != avu_0):
       pass


# Generated at 2022-06-25 04:48:17.701429
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'A'
    str_1 = 'B'
    str_1 = str_0 == str_1
    str_1 = str_1
    str_0 = AnsibleVaultEncryptedUnicode('A')
    str_1 = AnsibleVaultEncryptedUnicode('B')
    str_1 = str_0 != str_1
    str_1 = str_1
    str_0 = AnsibleVaultEncryptedUnicode('A')
    str_1 = AnsibleVaultEncryptedUnicode(None)
    str_1 = str_0 != str_1
    str_1 = str_1


# Generated at 2022-06-25 04:48:25.240823
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    tmp_vault = yaml.safe_load(open('vault.yml', 'r').read())['ciphertext']
    secret = 'test'
    tmp_avue = AnsibleVaultEncryptedUnicode(tmp_vault)
    tmp_avue.vault = yaml.safe_load(open('vault.yml', 'r').read())['vault']
    tmp_bool_0 = tmp_avue.is_encrypted()
    assert(tmp_bool_0) == True
    return


# Generated at 2022-06-25 04:48:26.557974
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'A'
    result = str_0.__eq__(str_0)


# Generated at 2022-06-25 04:48:32.610457
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'A'
    str_1 = 'B'
    str_2 = 'C'
    x = str_0 == str_1 
    y = str_0 == str_2 
    if x:
        print(True) # This is a constraint


# Generated at 2022-06-25 04:48:47.053327
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode.__eq__('A') is False
    assert AnsibleVaultEncryptedUnicode.__eq__('ab', 'ba') is False
    assert AnsibleVaultEncryptedUnicode.__eq__('abc', 'abc') is True
    assert AnsibleVaultEncryptedUnicode.__eq__('abc', 'Abc') is False
    assert AnsibleVaultEncryptedUnicode.__eq__('abc', None) is False
    assert AnsibleVaultEncryptedUnicode.__eq__(123, '123') is False
    assert AnsibleVaultEncryptedUnicode.__eq__('abc', 1, 0) is False
    assert AnsibleVaultEncryptedUnicode.__eq__('abc', 'abc', 0) is True
    assert AnsibleVaultEnc

# Generated at 2022-06-25 04:48:52.087639
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = AnsibleVaultEncryptedUnicode('A')
    str_0.vault = None
    ret_val_0 = str_0.is_encrypted()
    assert(ret_val_0 == True)


# Generated at 2022-06-25 04:48:58.583547
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = '1'
    str_1 = 'A'
    str_2 = str_0
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    if str_0 in str_0:
        ansible_vault_encrypted_unicode_0.data = str_1
    elif str_0 == str_2:
        ansible_vault_encrypted_unicode_0.data = str_1
    if str_0 in str_0:
        ansible_vault_encrypted_unicode_0.data = str_1
    elif str_0 < str_2:
        ansible_vault_encrypted_unicode_0.data = str_1
    ansible_vault_encrypted_unicode_1 = AnsibleV

# Generated at 2022-06-25 04:49:03.472877
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_1 = 'abc'
    str_2 = 'abc'
    bool_ret_0 = str_1 == str_2
    print(bool_ret_0)


# Generated at 2022-06-25 04:49:10.479142
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('no-one@0')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('no-one@0')
    bool_0 = ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
    bool_1 = ansible_vault_encrypted_unicode_1 == ansible_vault_encrypted_unicode_0
    assert bool_0
    assert bool_1


# Generated at 2022-06-25 04:49:13.728790
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    try:
        vault = None
        avu_0 = AnsibleVaultEncryptedUnicode.from_plaintext('A', vault, None)
        str_0 = 'A'
        assert avu_0.__ne__(str_0) == False
    except Exception:
        var_1 = sys.exc_info()[0]
        print('Exception! ' + str(var_1))


# Generated at 2022-06-25 04:49:17.046751
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode(b'zH7VMAU6y2Q=')
    assert avu.__ne__(b'zH7VMAU6y2Q=')


# Generated at 2022-06-25 04:49:18.713015
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    if not True:
        assert False



# Generated at 2022-06-25 04:49:20.895342
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = AnsibleVaultEncryptedUnicode()
    str_0.__ne__()
    return str_0

# Generated at 2022-06-25 04:49:23.723904
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('plaintext', vault='vault', secret='secret')
    ret = avu.is_encrypted()
    assert ret == True
    assert True


# Generated at 2022-06-25 04:49:39.100999
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1, 'AnsibleVaultEncryptedUnicode.__eq__ returned a value other than the expected value'


# Generated at 2022-06-25 04:49:47.165956
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'a'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    if (ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1):
        pass


# Generated at 2022-06-25 04:49:53.147924
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

    # get the return value
    returned_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert returned_0 is None


# Generated at 2022-06-25 04:49:58.401670
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert not (ansible_vault_encrypted_unicode_0 != '')
    assert ansible_vault_encrypted_unicode_0 != 'yo'


# Generated at 2022-06-25 04:50:06.696147
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_4 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_5 = AnsibleVault

# Generated at 2022-06-25 04:50:17.138787
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:50:24.744886
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0) == True


# Generated at 2022-06-25 04:50:36.888830
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    '''Test __ne__'''
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('9c9e8ea0-7b46-11e6-8b3a-8cec4bd887f3')
    ansible_vault_encrypted_unicode_1.vault = None
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode('d1d0a689-7b46-11e6-98a4-8cec4bd887f3')
    ansible_vault_

# Generated at 2022-06-25 04:50:42.810545
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    try:
        assert ansible_vault_encrypted_unicode_0 == ''
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-25 04:50:48.533716
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bootstrap_env()
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = create_ansible_vault_instance
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1.vault = create_ansible_vault_instance
    ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:51:07.820205
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_0_0
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0 == str_0
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

# Generated at 2022-06-25 04:51:17.643485
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = None
    str_1 = ''
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_1.vault = None
    exception_occurred = False
    try:
        assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
    except Exception as exception:
        exc_type, exc_value = _sys.exc_info()[:2]
        exception_message = to_native(exception)
        exception_occurred = True


# Generated at 2022-06-25 04:51:27.096068
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'abc'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'pqr'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    str_2 = 'abc'
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_2)
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_2) == True
    assert ansible_vault_encrypted_unicode_1.__eq__(ansible_vault_encrypted_unicode_2) == False


# Generated at 2022-06-25 04:51:33.140174
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    try:
        ansible_vault_encrypted_unicode_0.is_encrypted()
    except Exception as exc:
        print('Caught exception: ' + str(exc))


# Generated at 2022-06-25 04:51:38.357740
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    AnsibleVaultEncryptedUnicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = ''
    AnsibleVaultEncryptedUnicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    result = AnsibleVaultEncryptedUnicode_0.__ne__(AnsibleVaultEncryptedUnicode_1)
    return result == None


# Generated at 2022-06-25 04:51:47.465350
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:51:53.233452
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Test when call method with arg test_case_0 return True
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == True


# Generated at 2022-06-25 04:51:57.440336
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Input data
    # 1st arg, instance of class AnsibleVaultEncryptedUnicode
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

    # 2nd arg, other
    other = None

    # Output data
    expected_bool_0 = False
    # execute the code to be tested
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(other)

    # verify the result
    assert bool_0 == expected_bool_0


# Generated at 2022-06-25 04:52:01.552436
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    #  Positive test, call a method and check for exception
    try:
        ansible_vault_encrypted_unicode_0.__ne__(str_0)
    except Exception as exception_0:
        assert 0, 'Method __ne__(AnsibleVaultEncryptedUnicode, str) failed\nException: %s\nLine: %d\nColumn: %d' % (exception_0, exception_0.line, exception_0.column)


# Generated at 2022-06-25 04:52:04.671036
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:52:20.899573
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'abc'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()
    ansible_vault_encrypted_unicode_0.is_encrypted()
