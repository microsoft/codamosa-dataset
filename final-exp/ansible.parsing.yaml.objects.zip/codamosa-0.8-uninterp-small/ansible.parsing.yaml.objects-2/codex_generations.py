

# Generated at 2022-06-25 04:42:38.538317
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    seq = 'string'
    vault = None
    secret = 'secret'
    encrypted_unicode = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert not encrypted_unicode.__ne__('string')



# Generated at 2022-06-25 04:42:48.621122
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    data_to_encrypt = 'This is some data'
    encrypt_this = AnsibleVaultEncryptedUnicode.from_plaintext(data_to_encrypt, None, 'password')

    # This is what we are testing, this returns True for equality
    assert data_to_encrypt != encrypt_this
    # This is what we are testing, this returns True for equality
    assert 'This is some data' != encrypt_this
    # This is what we are testing, this returns True for equality
    assert '' != encrypt_this

    data_to_encrypt = ''
    encrypt_this = AnsibleVaultEncryptedUnicode.from_plaintext(data_to_encrypt, None, 'password')

    # This is what we are testing, this returns True for equality
    assert '' != encrypt_this


# Generated at 2022-06-25 04:42:58.298798
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    with open('test_value_0.yml') as fh:
        yaml_obj = yaml.load(fh)

# Generated at 2022-06-25 04:42:59.402727
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu_0 = AnsibleVaultEncryptedUnicode('')
    avu_0.__ne__('')


# Generated at 2022-06-25 04:43:09.647628
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('test_value')
    from ansible.parsing.vault import VaultLib
    ansible_vault_encrypted_unicode_0.vault = VaultLib('test_value')
    ansible_vault_encrypted_unicode_0.data = 'test_value'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('test_value')
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:43:17.117048
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Create a instance of AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('')
    # Check for the __getslice__ is instance of
    # AnsibleVaultEncryptedUnicode
    assert isinstance(ansible_vault_encrypted_unicode.__getslice__(),
                      AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-25 04:43:21.830749
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import vaultlib

    secret = 'secretsauce'
    text = 'this is the plaintext'
    vault = vaultlib.VaultLib(password_file=':memory:')
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(text, vault, secret)
    assert isinstance(avu.__ne__('this is not the plaintext'), bool)


# Generated at 2022-06-25 04:43:24.140526
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.data = 'foo'
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:43:28.916821
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():

    # static method test
    str_2 = to_text(AnsibleVaultEncryptedUnicode.__getslice__('', '', ''))


# Generated at 2022-06-25 04:43:41.269012
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:43:52.726912
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('HFPUSVCLRFA')
    ansible_vault_encrypted_unicode_1 = ansible_vault_encrypted_unicode_0.__getslice__(7, 9)
    assert ansible_vault_encrypted_unicode_1 == 'CL'


# Generated at 2022-06-25 04:43:54.837592
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes([104, 101, 108, 108, 111]))
    assert to_text(ansible_vault_encrypted_unicode_0[1:4]) == u'ell'


# Generated at 2022-06-25 04:44:00.351272
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(b"TestString")
    # No implementation, test passes by not raising an exception


# Generated at 2022-06-25 04:44:05.353399
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.__getslice__(start=0, end=0)


# Generated at 2022-06-25 04:44:16.807065
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1.data = ( '>an#' + string.ascii_lowercase )
    ansible_vault_encrypted_unicode_0.data = '>an#'
    ansible_vault_encrypted_unicode_0.data = ( ( ( ( ( ( '    ' + '>an#' ) + string.ascii_lowercase ) + ' ' ) + string.ascii_letters ) + ' ' ) + '!' )
    ansible_vault_encrypted_unicode_1.data = "    >an#' ' '!' "

# Generated at 2022-06-25 04:44:25.456850
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault_lib_0 = VaultLib('secret')
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('ciphertext')
    ansible_vault_encrypted_unicode_0.vault = vault_lib_0
    ansible_vault_encrypted_unicode_0.data = 'plaintext'
    assert ansible_vault_encrypted_unicode_0.__eq__('plaintext') == True
    ansible_vault_encrypted_unicode_0.vault = None
    assert ansible_vault_encrypted_unicode_0.__eq__('plaintext') == False
    ansible_vault_encrypted_unicode_0.vault = vault_lib_0
    ansible_vault

# Generated at 2022-06-25 04:44:28.490632
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test cases for AnsibleVaultEncryptedUnicode.__ne__()

    # Invalid test case: no assert statement
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("")


# Generated at 2022-06-25 04:44:35.916141
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # WARNING: not an encrypted object
    ciphertext = b"This is a test"

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ciphertext)

    # Call the method
    try:
        ansible_vault_encrypted_unicode_0.is_encrypted()
    except Exception as e:
        print("AnsibleVaultError: " + str(e))
        return
    else:
        print("The is_encrypted method does not raise an AnsibleVaultError")
        return



# Generated at 2022-06-25 04:44:40.172264
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    string_0 = AnsibleVaultEncryptedUnicode('example string')

    assert string_0.is_encrypted() == False


# Generated at 2022-06-25 04:44:43.697515
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()

    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:44:49.494656
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    obj0 = AnsibleVaultEncryptedUnicode(u'1')
    obj1 = AnsibleVaultEncryptedUnicode(u'1')
    assert obj0 != obj1


# Generated at 2022-06-25 04:44:59.046001
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_0)
    if ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1):
        print('assertion is true')
    else:
        print('assertion is false')
    if ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_2):
        print('assertion is true')
    else:
        print('assertion is false')
    if ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_3):
        print('assertion is true')

# Generated at 2022-06-25 04:45:06.709969
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ciphertext=to_bytes('The quick brown fox jumps over the lazy dog'))
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ciphertext=to_bytes('The quick brown fox jumps over the lazy dog'))
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:45:11.528312
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    if PYTHON_VERSION == 2:
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('string')
    if PYTHON_VERSION == 3:
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('string'.encode('utf-8'))
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('string')


# Generated at 2022-06-25 04:45:13.959878
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('')


# Generated at 2022-06-25 04:45:25.893004
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
    # Test of __ne__(self, other)

    class BaseModel:
        def __init__(self, name):
            self.name = name

    # Creation of an instance of BaseModel
    base_model = BaseModel('test')

    # Creation of an instance of AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:45:38.360711
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.vault import VaultLib
    str = 'AnsibleVaultEncryptedUnicode'
    passwd = '$ANSIBLE_VAULT;1.2;AES256;user\n666634663934656435373432656538323264353538303334323162626636326239616265373366\n396632323239663039308000\n'
    vault_password = 'user'

    # create vault instance
    vault = VaultLib(vault_password)
    # create encrypted string
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(str, vault, vault_password)
    # test is_encrypted
    assert(avu.is_encrypted())


# Generated at 2022-06-25 04:45:49.321367
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ciphertext=b'y\xcb\x82\xc1\x8b\x90\xa2\x9e\x9e\xf1\xea\xe2')
    assert not ansible_vault_encrypted_unicode_0.__ne__('')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ciphertext=b'\xa3\x0f\xbe\xf5\x8f\x0c\x08\xe1\x82\xe8\xb7\xfd\xc2\xfd')
    assert ansible_vault_encrypted_unicode_1.__ne__('')
    ansible_vault_encrypted

# Generated at 2022-06-25 04:45:52.515241
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_base_y_a_m_l_object_0)
    ansible_vault_encrypted_unicode_0.__ne__(ansible_base_y_a_m_l_object_0)


# Generated at 2022-06-25 04:45:56.611139
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("test")
    assert ansible_vault_encrypted_unicode_0.__eq__("test") != False


# Generated at 2022-06-25 04:46:03.664142
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('snoopy')
    assert not ansible_vault_encrypted_unicode_0.__eq__('snoopy')


# Generated at 2022-06-25 04:46:05.070447
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu = AnsibleVaultEncryptedUnicode('hello')
    return avu == 'hello'


# Generated at 2022-06-25 04:46:09.162928
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # arrange:  make up objects
    avu0 = AnsibleVaultEncryptedUnicode('a')
    avu1 = AnsibleVaultEncryptedUnicode('a')
    avu2 = AnsibleVaultEncryptedUnicode('b')

    # act:  compare avus with __ne__
    result1 = avu0 != avu1
    result2 = avu0 != avu2

    # assert:  assert the results of these two comparisons
    assert not result1
    assert result2



# Generated at 2022-06-25 04:46:14.758065
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # In this simple test case, we assume that our subclass of
    # AnsibleVaultEncryptedUnicode has a Vault attribute that can decrypt
    # it.
    #
    # We assume we have a method that returns true when a given string
    # is encrypted.
    #
    # We assume we have a vault object that can decrypt an encrypted
    # string.
    #
    # We construct a string and encrypt it with the vault object.
    #
    # We assert that is_encrypted returns true.
    #
    # We then set the _ciphertext attribute of the object to the
    # plaintext string.
    #
    # We assert that is_encrypted returns false.

    class TestVaultCrypto(object):
        def __init__(self):
            return

        def encrypt(self, plaintext, secret):
            return

# Generated at 2022-06-25 04:46:17.505818
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    result = ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:46:25.150922
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.data = '1'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1.data = '1'
    assert not (ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:46:33.545634
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = string.ascii_letters
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode.from_plaintext(ansible_vault_encrypted_unicode_0, None, None)
    ansible_vault_encrypted_unicode_2 = ansible_vault_encrypted_unicode_0
    assert(ansible_vault_encrypted_unicode_1 == ansible_vault_encrypted_unicode_2)



# Generated at 2022-06-25 04:46:40.285243
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    test__ne__0 = AnsibleVaultEncryptedUnicode("test__ne__0")
    test__ne__0.vault = None
    assert test__ne__0 != "test__ne__0", "Expected result False, actual result %s" % str(test__ne__0 != "test__ne__0")
    test__ne__1 = AnsibleVaultEncryptedUnicode("test__ne__1")
    test__ne__1.vault = None
    assert test__ne__1 != "test__ne__1", "Expected result False, actual result %s" % str(test__ne__1 != "test__ne__1")
    test__ne__2 = AnsibleVaultEncryptedUnicode("test__ne__2")
    test__ne__2.vault = None
    assert test__ne

# Generated at 2022-06-25 04:46:50.570452
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Create test ciphertext
    test_ciphertext = '$ANSIBLE_VAULT;1.1;AES256;test_host;\n' \
                      '336233356630306134393735386631326563383863616232333462373365636436646163663962\n' \
                      '3034386262623033366139376561663133363837376161326666\n'

    # Create test vault
    vault_password = 'test'
    test_vault = ansible.vault.VaultLib(vault_password)

    # Create test object
    test_avue_object = AnsibleVaultEncryptedUnicode(test_ciphertext)
    test_avue_object.vault = test_vault

    # Test
    assert test

# Generated at 2022-06-25 04:46:55.106261
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Tests for method is_encrypted of class AnsibleVaultEncryptedUnicode
    # Make sure is_encrypted returns False if no Vault object is set
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('test-string')
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:46:59.867830
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass


# Generated at 2022-06-25 04:47:03.861473
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = 93494.9087
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0._Vault__is_encrypted = True
    assert_equal(ansible_vault_encrypted_unicode_0.is_encrypted(), True)



# Generated at 2022-06-25 04:47:06.039021
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 881.02
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.__ne__(float_0)


# Generated at 2022-06-25 04:47:17.465143
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault
    # Create a new instance of class AnsibleVaultEncryptedUnicode using a valid argument
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('arg_0')

    # Attempt to call the method
    try:
        result = ansible_vault_encrypted_unicode_1.is_encrypted()
    except AttributeError as e:
        # The method call should fail due to incorrect number of arguments
        assert(e.args[0] == 'is_encrypted() takes exactly 1 positional argument (0 given)')

    # Create a new instance of class AnsibleVaultEncryptedUnicode using a valid argument
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode('arg_0')

    # Attempt

# Generated at 2022-06-25 04:47:19.901293
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1344.12165
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:47:26.023571
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    list_0 = [None, None, 5, to_text(''), 5, 3.3, to_text(''), to_text(''), 4, None, None, 5, to_text(''), 5, to_text(''), to_text(''), to_text(''), to_text(''), 3.3, to_text(''), to_text(''), to_text(''), 5, to_text(''), None, to_text(''), 4, to_text(''), to_text(''), to_text(''), None, to_text(''), 4, to_text(''), to_text(''), to_text(''), None, to_text('')]
    str_0 = to_text('')
    ansible_vault_encrypted_unicode_0 = Ansible

# Generated at 2022-06-25 04:47:34.006865
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1344.12165
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    print('unencrypted == float?:', ansible_vault_encrypted_unicode_0 == float_0)
    print('unencrypted == unicode float?:', ansible_vault_encrypted_unicode_0 == text_type(float_0))
    print('unencrypted == string float?:', ansible_vault_encrypted_unicode_0 == str(float_0))


# Generated at 2022-06-25 04:47:38.247095
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1344.12165
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    rest_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:47:41.275450
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1344.12165
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert ansible_vault_encrypted_unicode_0.__eq__(0) == False


# Generated at 2022-06-25 04:47:48.938402
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1344.12165
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)
    # Try to match some of the output of the disassembly of this function.
    assert_2 = ansible_vault_encrypted_unicode_1.is_encrypted()
    if assert_2 == False:
        pass


# Generated at 2022-06-25 04:47:57.033909
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(1.4)
    int_0 = 1
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(int_0)
    assert bool_0 == False



# Generated at 2022-06-25 04:48:07.716784
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -725.9865
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    str_1 = 'SI1'
    ansible_vault_encrypted_unicode_0.vault = str_1
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_2.vault = str_1
    ansible_vault_encrypted_unicode_0.vault = str_1


# Generated at 2022-06-25 04:48:13.859333
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    int_0 = 0
    unicode_0 = '{'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(unicode_0)
    assert not ansible_vault_encrypted_unicode_0.__eq__(int_0)
    int_0 = 0
    int_1 = 1
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext(int_0, vault=None, secret=int_1)
    assert ansible_vault_encrypted_unicode_0.__eq__(int_0)


# Generated at 2022-06-25 04:48:17.988102
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 1636.12054
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert ansible_vault_encrypted_unicode_0 == float_0


# Generated at 2022-06-25 04:48:21.262123
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1344.12165
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)

    ansible_vault_encrypted_unicode_0.is_encrypted()

# Generated at 2022-06-25 04:48:22.920652
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    test_case_0()
    # TODO: need to implement the test


# Generated at 2022-06-25 04:48:28.588681
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("7e3nlitqcq7o2grt")
    # Test method __ne__ of class AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_0.__ne__("")
    # Test method __ne__ of class AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_0.__ne__("")


# Generated at 2022-06-25 04:48:32.529617
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1786.05763
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    print (ansible_vault_encrypted_unicode_0.is_encrypted())


# Generated at 2022-06-25 04:48:37.033779
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1344.12165
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)


# Generated at 2022-06-25 04:48:43.195114
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext('test/vault/test_vault.yml', to_text('test'), to_text('ansible'))
    unicode_0 = u'ansible'
    ansible_vault_encrypted_unicode_0.ansible_pos = (to_text('test/vault/test_vault.yml'), 1, 0)
    ansible_vault_encrypted_unicode_0.vault = vault.AnsibleVaultLib('ansible')
    assert ansible_vault_encrypted_unicode_0 != unicode_0


# Generated at 2022-06-25 04:48:58.954843
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    unicode_0 = u"yT\n'[p\x10|!!\x0b"
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(unicode_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(unicode_0)
    ansible_vault_encrypted_unicode_1.data = u"\x03\x00\x7f\x80p\x7f\x10\x00\x0bp\x00\x03\x10\x00\x0b\x00\x03\x00p\x7f\x10\x00\x0b\x03"
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted

# Generated at 2022-06-25 04:49:04.613992
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert ansible_vault_encrypted_unicode_0.__ne__(191.0) is True


# Generated at 2022-06-25 04:49:10.027362
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1344.12165
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)

    # Call AnsibleVaultEncryptedUnicode___ne__
    try:
        ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0)
    except Exception:
        assert(False)


# Generated at 2022-06-25 04:49:14.976672
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1044.12165
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    float_1 = 136.6
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_1)
    boolean_0 = ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
    assert_false(boolean_0)
    boolean_1 = ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_0
    assert_true(boolean_1)


# Generated at 2022-06-25 04:49:22.049927
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Setup
    float_0 = -1344.12165
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)

    # Assertions
    assert False == ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:49:25.128680
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    class_instance = AnsibleVaultEncryptedUnicode(-1344.12165)
    bool_0 = class_instance.__eq__(False)
    bool_1 = class_instance.__eq__(class_instance)
    assert bool_0
    assert bool_1


# Generated at 2022-06-25 04:49:32.143134
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(0.66)
    # Check exception is not raised
    try:
        ansible_vault_encrypted_unicode_0.is_encrypted()
    except Exception as e:
        print('Unexpected exception raised: {}'.format(e))


# Generated at 2022-06-25 04:49:40.404662
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -943.973652
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_2 = ansible_vault_encrypted_unicode_1
    ansible_vault_encrypted_unicode_0_new = AnsibleVaultEncryptedUnicode(float_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)

# Generated at 2022-06-25 04:49:46.344606
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    a = AnsibleVaultEncryptedUnicode.from_plaintext('password', 'mypassword')
    b = AnsibleVaultEncryptedUnicode.from_plaintext('password', 'mypassword')
    assert a != b



# Generated at 2022-06-25 04:49:54.530180
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    int_0 = -1344
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(int_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(-1344)
    if __name__ == '__main__':
        ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:50:08.981983
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('ansible')
    assert(ansible_vault_encrypted_unicode_0.is_encrypted())
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    assert(ansible_vault_encrypted_unicode_0.is_encrypted())
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(int(-1887565835))
    assert(ansible_vault_encrypted_unicode_0.is_encrypted())
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('Iubuntu')
    assert(ansible_vault_encrypted_unicode_0.is_encrypted())


# Generated at 2022-06-25 04:50:15.551904
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Check that the AnsibleVaultEncryptedUnicode.is_encrypted method works
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(b'Hello World!')
    # Suppress printed output during test
    try:
        original = sys.stdout
        f = open(os.devnull, 'w')
        sys.stdout = f

        assert ansible_vault_encrypted_unicode_0.is_encrypted() == False

    finally:
        sys.stdout = original



# Generated at 2022-06-25 04:50:20.528813
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1.data = 'Hello, World!'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.data = 'Hello, World!'
    return ansible_vault_encrypted_unicode_1 != ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 04:50:30.666174
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('<value>')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('<value>')
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode('<value>')
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    bool_1 = ansible_vault_encrypted_unicode_2.__eq__(ansible_vault_encrypted_unicode_1)
    bool_2 = ansible_vault_encrypted_unicode_1.__eq__(ansible_vault_encrypted_unicode_1)
    bool_3

# Generated at 2022-06-25 04:50:35.957213
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1.01506956669
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert (not (ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_0))


# Generated at 2022-06-25 04:50:45.206403
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Set up test objects
    float_0 = -558.955;
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)

    if float_0 != float_0:
        ansible_vault_encrypted_unicode_0.data = float_0
    else:
        ansible_vault_encrypted_unicode_0.data = -1344.12165

    expected_result = False
    actual_result = ansible_vault_encrypted_unicode_0 != float_0
    assert expected_result == actual_result


# Generated at 2022-06-25 04:50:57.817677
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(int_0)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode(int_0)
    ansible_vault_encrypted_unicode_4 = AnsibleVaultEncryptedUnicode(int_0)
    ansible_vault_encrypted_unicode_5 = AnsibleVaultEncryptedUnicode(int_0)

# Generated at 2022-06-25 04:51:03.140473
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    '''
    Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
    '''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(21)
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()

    ansible_vault_encrypted_unicode_0.data = ansible_vault_encrypted_unicode_0.data + 'test'
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(21)
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:06.192471
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1344.12165
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:10.735084
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    print('Test AnsibleVaultEncryptedUnicode is_encrypted')

    # Helper functions
    global ansible_vault_encrypted_unicode_0
    global boolean_0
    global function_0

    def function_0(ansible_vault_encrypted_unicode_0):
        return ansible_vault_encrypted_unicode_0.is_encrypted()

    # Set up test input
    boolean_0 = True

    # Perform test
    function_0(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:51:23.220950
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    result = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert result == False


# Generated at 2022-06-25 04:51:27.188827
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1344.12165
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert ansible_vault_encrypted_unicode_0 != float_0


# Generated at 2022-06-25 04:51:29.679552
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()


# Generated at 2022-06-25 04:51:37.700474
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1344.12165
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0) == False


# Generated at 2022-06-25 04:51:39.363207
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1344.12165
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)



# Generated at 2022-06-25 04:51:46.825130
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    sequence_0 = '''The quick brown fox jumped over the lazy dog'''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(sequence_0)
    ansible_unicode_0 = AnsibleUnicode(sequence_0)
    # Test that the __ne__ method returns a boolean
    assert (ansible_vault_encrypted_unicode_0 != ansible_unicode_0) is not False
    assert (ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_0) is not False


# Generated at 2022-06-25 04:51:52.568964
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
  float_0 = -1344.12165
  float_1 = -1344.12165
  float_2 = -1344.12165
  float_3 = -1344.12165
  int_0 = 16

# Generated at 2022-06-25 04:52:01.056823
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    test_val = AnsibleVaultEncryptedUnicode(b'foo')
    actual_val = test_val.is_encrypted()
    expected_val = False
    print('Expected:')
    print('  {0}'.format(expected_val))
    print('Actual:')
    print('  {0}'.format(actual_val))
    assert actual_val == expected_val
test_AnsibleVaultEncryptedUnicode_is_encrypted()


# Generated at 2022-06-25 04:52:04.772158
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1344.12165
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    boolean_0 = ansible_vault_encrypted_unicode_0.__eq__(float_0)
    assert boolean_0


# Generated at 2022-06-25 04:52:12.592682
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1280.098586
    float_1 = float_0
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_1)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(-1041.563919)
    ansible_vault_encrypted_unicode_0.data = ansible_vault_encrypted_unicode_1
    str_0 = ''
    ansible_vault_encrypted_unicode_1.data = str_0
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
