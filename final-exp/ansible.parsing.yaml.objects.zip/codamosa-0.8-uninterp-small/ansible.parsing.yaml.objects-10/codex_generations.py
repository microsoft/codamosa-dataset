

# Generated at 2022-06-25 04:42:41.866541
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    params = AnsibleVaultEncryptedUnicode("")
    result = params.__lt__("")
    assert result == False


# Generated at 2022-06-25 04:42:44.608797
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = AnsibleVaultEncryptedUnicode.__ne__("HelloWorld!")


# Generated at 2022-06-25 04:42:47.904300
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("Password")
    assert ansible_vault_encrypted_unicode_0.__ne__("Password") == False


# Generated at 2022-06-25 04:42:48.814319
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    pass # No-op


# Generated at 2022-06-25 04:42:54.072615
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    ansible_unicode_0 = AnsibleUnicode(u'')
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(u'')


# Generated at 2022-06-25 04:42:54.942599
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    pass


# Generated at 2022-06-25 04:42:55.850571
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    pass



# Generated at 2022-06-25 04:43:03.297000
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    from ansible.parsing.vault import VaultLib
    test_vault = VaultLib('secret')
    ans_vault_uni_0 = AnsibleVaultEncryptedUnicode.from_plaintext("this is a test", test_vault, "secret")
    start_0 = 1
    end_0 = 5
    ansible_vault_encrypted_unicode_find_ret_0 = ans_vault_uni_0.find("this", start_0, end_0)
    assert ansible_vault_encrypted_unicode_find_ret_0 == -1


# Generated at 2022-06-25 04:43:08.807686
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    try:
        vault_pass = None
        if not vault_pass:
            vault_pass = os.environ.get('ANSIBLE_VAULT_PASSWORD_FILE', None)
        ansible_vault_actual_0, ansible_vault_expected_0 = None, None
        ansible_vault_0 = vault.VaultLib(vault_pass)
        ansible_vault_actual_0 = ansible_vault_0.decrypt(ansible_vault_encrypted_0)
    except IOError as exception_0:
        assert False
    assert ansible_vault_actual_0 == ansible_vault_expected_0


# Generated at 2022-06-25 04:43:14.038157
# Unit test for method __add__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___add__():
    str_0 = "test_value"
    str_1 = "test_value_0"
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_2 = ansible_vault_encrypted_unicode_1 + ansible_vault_encrypted_unicode_0
    str_2 = "test_value_0test_value"
    assert(ansible_vault_encrypted_unicode_2 == str_2)


# Generated at 2022-06-25 04:43:22.361419
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    int_0 = ansible_vault_encrypted_unicode_0.__getslice__(1, 6)


# Generated at 2022-06-25 04:43:26.845770
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1.is_encrypted()

if __name__ == "__main__":
    test_AnsibleVaultEncryptedUnicode_is_encrypted()

# Generated at 2022-06-25 04:43:39.871093
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'o(O=$'
    str_1_return = ansible_vault_encrypted_unicode_0.__ne__(str_1)
    #return
    str_2 = 'bV7h9'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_2)
    str_3 = 'gJfdx'
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_3)

# Generated at 2022-06-25 04:43:48.246187
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    assert __ne__(ansible_vault_encrypted_unicode_0, ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:43:52.726886
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    str_0 = 'z-rl:o#u"'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    # Test using an if statement
    if ansible_vault_encrypted_unicode_0.find('#') != -1:
        pass


# Generated at 2022-06-25 04:44:01.024489
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:44:06.332294
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    str_0 = 'Jtt6=L'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    sub_0 = 'vb'
    result_0 = ansible_vault_encrypted_unicode_0.count(sub_0)



# Generated at 2022-06-25 04:44:12.636947
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.__getslice__(1, 4)


# Generated at 2022-06-25 04:44:16.934626
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    str_0 = '-?G.h#'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    int_0 = -8
    int_1 = -1
    str_1 = ansible_vault_encrypted_unicode_0.__getslice__(int_0, int_1)


# Generated at 2022-06-25 04:44:21.463149
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    str_0 = '0'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    int_0 = ansible_vault_encrypted_unicode_0.find('X')
    assert(int_0 == -1)


# Generated at 2022-06-25 04:44:30.780120
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'a1G!v2'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert not (ansible_vault_encrypted_unicode_0 != str_0)


# Generated at 2022-06-25 04:44:38.994318
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Init AnsibleVaultEncryptedUnicode object
    str_0 = 'G'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

    # Call is_encrypted method
    ansible_vault_encrypted_unicode_0.is_encrypted()

    # Call is_encrypted method with argument
    ansible_vault_encrypted_unicode_0.is_encrypted(str_0)



# Generated at 2022-06-25 04:44:42.265866
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:44:45.726242
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'VqY!&p@u'
    ansible_vault_encrypted_unicode_0.__eq__(str_1)


# Generated at 2022-06-25 04:44:48.172698
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = '+f73'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:44:51.047605
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert bool_0 == True, 'Expected True, got %s' % bool_0


# Generated at 2022-06-25 04:45:01.047782
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    #
    # Test the method __ne__ of the class AnsibleVaultEncryptedUnicode.
    #
    # AssertionError: ansible_pos can only be set with a tuple/list of three values: source, line number, column number
    #
    # ###############
    # # Example 0
    # ###############
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = None
    try:
        ansible_vault_encrypted_unicode_0.ansible_pos = 1
        assert 0 == 1
    except AssertionError:
        pass
    #
    # ###############
    # #

# Generated at 2022-06-25 04:45:06.512436
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'XWkgy&'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)

AnsibleVaultEncryptedUnicode.__ne__(ansible_vault_encrypted_unicode_0, ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:45:08.958361
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    test_case_0()
    # assert ansible_vault_encrypted_unicode_0.data == str_0
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:45:15.682811
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1.vault.encrypt('$', 'n")8WnBqe_c%T*Z')

    if ansible_vault_encrypted_unicode_0.is_encrypted():
        ansible_vault_encrypted_unicode_0.set_vault(ansible_vault_encrypted_unicode_1.vault)

# Generated at 2022-06-25 04:45:28.214203
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    substring_0 = 'gy&'
    substring_1 = 'g'
    substring_2 = '&'
    substring_3 = 'X'
    substring_4 = 'W'
    substring_5 = 'k'
    substring_6 = 'y'
    substring_7 = 'kgy&'
    substring_8 = 'XWkgy&'
    substring_9 = 'XWky'
    substring_10 = 'Wky'
    substring_11 = 'Wkgy'
    substring_12 = 'XWkg'
    substring_13 = 'k'
    substring

# Generated at 2022-06-25 04:45:33.914009
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    if __name__ == '__main__':
        str_1 = 'lJZ@'
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_1)
        ansible_vault_encrypted_unicode_0.find(str_1)



# Generated at 2022-06-25 04:45:38.616711
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'XWkgy&'
    str_1 = str_0

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_0)

    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_0
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_2


# Generated at 2022-06-25 04:45:43.343796
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Test with a mock object of class AnsibleVaultEncryptedUnicode
    # is_encrypted is not implemented, we expect an error
    tested_obj = AnsibleVaultEncryptedUnicode()
    with pytest.raises(NotImplementedError):
        tested_obj.is_encrypted()


# Generated at 2022-06-25 04:45:49.771482
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'FHi6~'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:45:57.031236
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = '!jK7Vu'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert not ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:46:01.782529
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(str_0)
    assert bool_0 is False


# Generated at 2022-06-25 04:46:05.462714
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'H<>|@'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = '{$_0h'
    assert not ansible_vault_encrypted_unicode_0 == str_1


# Generated at 2022-06-25 04:46:12.650554
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(str_0)
    assert bool_0 is False


# Generated at 2022-06-25 04:46:18.109916
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    str_0 = '0#'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = '@'
    str_2 = ''
    int_0 = ansible_vault_encrypted_unicode_0.find(str_1, 0, 2, str_2, str_2)
    assert int_0 >= 0



# Generated at 2022-06-25 04:46:32.636870
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'XWkgy&'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert(ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:46:33.848892
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # FIXME: implement this test
    pass


# Generated at 2022-06-25 04:46:35.126621
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert test_case_0()

# Generated at 2022-06-25 04:46:41.613152
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import vault as _vault
    str_0 = 'BH&|b+"8>'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    _vault_0 = _vault.VaultLib('$ANSIBLE_VAULT;1.1;AES256')
    ansible_vault_encrypted_unicode_1.vault = _vault_0
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_0)
    _vault_1 = _vault.VaultLib('$ANSIBLE_VAULT;1.1;AES256')
    ans

# Generated at 2022-06-25 04:46:47.156980
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:46:53.820533
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1.vault = None
    return_value_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    assert return_value_0 is False


# Generated at 2022-06-25 04:46:59.076821
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    args = []
    # Call the __eq__ function (line 16) with the proper arguments
    AnsibleVaultEncryptedUnicode.__eq__(args)


# Generated at 2022-06-25 04:47:03.619286
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    string_0 = 'Compulsory'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(string_0)
    try:
        assert ansible_vault_encrypted_unicode_0.is_encrypted() is None
    except:
        _sys.stderr.write("Error occurred in test_AnsibleVaultEncryptedUnicode_is_encrypted\n")
        raise


# Generated at 2022-06-25 04:47:07.046852
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'XWkgy&'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert (ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:47:09.574926
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'XmzmpyRfr.d-'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.is_encrypted()

# Generated at 2022-06-25 04:47:20.005482
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'xK$'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = '2V7%'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    # print(ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:47:22.973402
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('h @pV].9u,r?U6]KUz')
    ansible_vault_encrypted_unicode_0.vault = object
    str_0 = 'Kz02;%)'
    assert (ansible_vault_encrypted_unicode_0 == str_0)


# Generated at 2022-06-25 04:47:30.952624
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    result = ansible_vault_encrypted_unicode_1.is_encrypted()
    assert ansible_vault_encrypted_unicode_1 == str_0


# Generated at 2022-06-25 04:47:31.924571
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert None



# Generated at 2022-06-25 04:47:36.047454
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.__ne__('XWkgy&')


# Generated at 2022-06-25 04:47:39.869618
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'MV8H$'
    ansible_vault_encrypted_unicode_0.__ne__(str_1)


# Generated at 2022-06-25 04:47:51.796922
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'YJY@!#'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1.vault = None
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_2.vault = None
    assert not ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:47:57.420205
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = None
    str_1 = 'XWkgy&'
    assert ansible_vault_encrypted_unicode_0.__ne__(str_1)


# Generated at 2022-06-25 04:48:02.266216
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    str_1 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert (ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0))

# Generated at 2022-06-25 04:48:10.411139
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'Vault'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = ''
    return_value_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert not return_value_0


# Generated at 2022-06-25 04:48:27.052366
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    setup_module()
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    # AssertionError
    try:
        ansible_vault_encrypted_unicode_0.is_encrypted()
    except AssertionError:
        pass


# Generated at 2022-06-25 04:48:33.270976
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    # Test call to __ne__
    str_1 = '+R@do;kM'
    result = ansible_vault_encrypted_unicode_0.__ne__(str_1)


# Generated at 2022-06-25 04:48:41.546367
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = '&/'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.data = 'T'
    try:
        assert (ansible_vault_encrypted_unicode_0 != 'T')
    except AssertionError as e:
        print("Test 0 of 2 failed:")
        print(e)
    ansible_vault_encrypted_unicode_0.data = '2'
    try:
        assert (ansible_vault_encrypted_unicode_0 != '2')
    except AssertionError as e:
        print("Test 1 of 2 failed:")
        print(e)

# Generated at 2022-06-25 04:48:48.654423
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # import class
    import ansible.parsing.vault as vault

    # create a vault object
    pwd = input('Enter Vault Password: ')
    vault = vault.get_vault_object(
        password=pwd,
        identifier=None,
        salt_size=None,
        cipher='aes256',
        new_cipher=False,
    )

    # create the encrypted ansible vault unicode object
    str_0 = input('Enter string to encrypt: ')

    # invoke the method
    is_encrypted = vault.is_encrypted(str_0)

    # print the result
    print(is_encrypted)

#Unit test for method from_plaintext of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:48:51.028084
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.__eq__('XWkgy&') == False


# Generated at 2022-06-25 04:48:56.216852
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)

    #Expected: True
    print(ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:49:02.969631
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'XWkgy&'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)

    ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:49:09.320779
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('XWkgy&')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('XWkgy&')
    ansible_vault_encrypted_unicode_0.data = 'Q6wFbB'

    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:49:15.515768
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    is_encrypted_output = ansible_vault_encrypted_unicode_0.is_encrypted()
    # print(is_encrypted_output)


# Generated at 2022-06-25 04:49:21.816358
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    boolean_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:49:39.151716
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'XWkgy&'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)

    # First call should return False
    # Second call should return True
    assert not ansible_vault_encrypted_unicode_0.__eq__(str_1)
    assert ansible_vault_encrypted_unicode_0.__eq__(str_1)


# Generated at 2022-06-25 04:49:46.229461
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = '$#o@Pf-I'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = '$#o@Pf-I'
    boolean_0 = ansible_vault_encrypted_unicode_0.__ne__(str_1)


# Generated at 2022-06-25 04:49:48.954602
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = '1i&5y8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = '#EI&)|'
    result = ansible_vault_encrypted_unicode_0.__ne__(str_1)
    assert(result)


# Generated at 2022-06-25 04:49:59.408561
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = '<'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = '<'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_1 = None
    ansible_vault_encrypted_unicode_0 = None
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = '<'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)

# Generated at 2022-06-25 04:50:01.458828
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'c(6'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'U:y.G>H'
    assert ansible_vault_encrypted_unicode_0 != str_1


# Generated at 2022-06-25 04:50:06.760775
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('XWkgy&')
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__('XWkgy&')
    assert bool_0 == False


# Generated at 2022-06-25 04:50:17.177815
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    str_0 = 'CX%cS-^2IY5'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0._ciphertext = str_0
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_0._line_number = -1305011095

    str_1 = 'zHRB$iKQ!^'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_1._line_number = -1305011095
    ansible_vault_encrypted_unicode_1._cipher

# Generated at 2022-06-25 04:50:26.243408
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = '|hG?:@F&'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert (ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:50:33.612002
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # <script>
    #     str_0 = 'XWkgy&'
    #     ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    #     # Call the method under test.
    #     str_1 = ansible_vault_encrypted_unicode_0.is_encrypted()
    # </script>
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    # Call the method under test.
    str_1 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:50:44.194895
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'XWkgy&'
    str_1 = '^wY@iM'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_0.data = str_1
    assert isinstance(ansible_vault_encrypted_unicode_0, AnsibleVaultEncryptedUnicode)
    assert isinstance(ansible_vault_encrypted_unicode_1, AnsibleVaultEncryptedUnicode)
    bool_0 = ansible_vault_encrypted_unicode_1 == ansible_vault_encrypted_unicode_0
    assert bool_0

# Generated at 2022-06-25 04:50:57.740434
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('\u0004')
    assert ansible_vault_encrypted_unicode_0 != '\u0004'


# Generated at 2022-06-25 04:51:00.024047
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:51:04.784890
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert bool_0



# Generated at 2022-06-25 04:51:11.572284
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'eO3'
    assertion_failed = None
    try:
        ansible_vault_encrypted_unicode_0.__ne__(str_1)
    except AssertionError as e:
        assertion_failed = e

    assert assertion_failed is not None


# Generated at 2022-06-25 04:51:21.700205
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()

    from ansible.parsing.vault import VaultLib
    vault = VaultLib(_sys.stdout.write)
    vault.KEYS = ['SECRET']
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext('my_password', vault, 'SECRET')
    ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:51:24.397166
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:51:27.584223
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = "h"
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:51:32.947541
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = "A"
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:34.935618
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    '''
    Unit test for method str_0__eq__ of class AnsibleVaultEncryptedUnicode
    '''


# Generated at 2022-06-25 04:51:41.796339
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'f&'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_1.vault = None
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
    assert ansible_vault_encrypted_unicode_1 != ansible_vault_encrypted_unicode_0

# Generated at 2022-06-25 04:51:54.124253
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:58.224329
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'XWkgy&'
    str_1 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    str_2 = 'XWkgy&'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_2)
    bool_1 = ansible_vault_encrypted_unicode_1.is_encrypted()


# Generated at 2022-06-25 04:52:05.554783
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'XQ%c!'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:52:10.184888
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'XWkgy&'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert not ansible_vault_encrypted_unicode_0.__eq__(str_0)


# Generated at 2022-06-25 04:52:22.014478
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    print('Testing is_encrypted...')
    from ansible.parsing.vault import VaultLib

    vault_password_file = 'test/files/test0.txt'
    vault_password = 'test/files/test1.txt'
    vault_password_bytes = 'test/files/test2.txt'

    in_text = 'hello world!\n'
    in_text_bytes = 'hello world!\n'.encode('ascii')

    # Test with AnsibleVaultEncryptedUnicode
    vault = VaultLib(vault_password, [vault_password_file, vault_password_bytes])
    cyphertext = vault.encrypt(in_text)
    cipher_ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(cyphertext)