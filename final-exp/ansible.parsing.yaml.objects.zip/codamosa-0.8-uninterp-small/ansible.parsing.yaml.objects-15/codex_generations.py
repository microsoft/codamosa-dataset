

# Generated at 2022-06-25 04:42:35.851044
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with ansible_vault_encrypted_unicode_0 and ansible_vault_encrypted_unicode_1
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_2.vault = None
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_1.vault = ansible_vault_encrypted_unicode_2.vault
    ansible_vault_encrypted_unicode_0.data = 'test'
    ansible

# Generated at 2022-06-25 04:42:42.263856
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    # test case 0
    str_0 = 'o-#zhBFwTDLkQ\rj(c4P'
    ansible_mapping_0 = AnsibleMapping()
    assert not ansible_mapping_0 in ansible_mapping_0


# Generated at 2022-06-25 04:42:53.280226
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:42:59.752721
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    str_0 = 'o-#zhBFwTDLkQ\rj(c4P'
    str_1 = 'mYmXt'
    str_2 = 'o-#zhBFwTDLkQ\rj(c4P'
    ansible_mapping_0 = AnsibleMapping()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_1)
    int_0 = ansible_vault_encrypted_unicode_0.count(str_1)
    int_1 = ansible_vault_encrypted_unicode_0.count(str_2)


# Generated at 2022-06-25 04:43:09.647439
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    str_0 = '6/I\fb&F'
    str_1 = '9i3qIvsNb)*Q'
    ansible_mapping_0 = AnsibleMapping()
    ansible_mapping_0['0'] = AnsibleVaultEncryptedUnicode(str_1)
    ansible_mapping_0['1'] = AnsibleVaultEncryptedUnicode(str_1)
    ansible_mapping_0['2'] = AnsibleVaultEncryptedUnicode(str_1)
    assert ansible_mapping_0['0'] >= ansible_mapping_0['1']


# Generated at 2022-06-25 04:43:17.825372
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # The following code throws an exception, because
    # you are comparing an instance of class AnsibleVaultEncryptedUnicode
    # to an integer.
    str_0 = 'o-#zhBFwTDLkQ\rj(c4P'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(
        'XiOe-')
    ansible_vault_encrypted_unicode_0.__ne__(5)


# Generated at 2022-06-25 04:43:23.359463
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    str_0 = 'o-#zhBFwTDLkQ\rj(c4P'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    # Other variables for test
    str_1 = '-4P'
    str_2 = 'Q\rj(c'
    str_3 = 'o-#zhBFwTDLkQ\rj(c4P'
    str_4 = '\rj(c'
    # Output-only variables
    ansible_vault_encrypted_unicode_1 = None
    ansible_vault_encrypted_unicode_2 = None
    ansible_vault_encrypted_unicode_3 = None
    ansible_vault_encrypted_unicode_4 = None
    ansible_

# Generated at 2022-06-25 04:43:24.671804
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'o-#zhBFwTDLkQ\rj(c4P'
    ansible_mapping_0 = AnsibleMapping()


# Generated at 2022-06-25 04:43:37.395484
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    str_0 = 'o-#zhBFwTDLkQ\rj(c4P'
    ansible_mapping_0 = AnsibleMapping()
    str_1 = ',dQ-v<GuOP!W&'
    str_2 = 'wv>x^'
    str_3 = 'MCI/`vnhB]Hs'
    str_4 = 'wv>x^'
    str_5 = 'i"gVu$`o(:2['
    str_6 = 'i"gVu$`o(:2['
    str_7 = '"O^y<5Ci4E'
    str_8 = 'i"gVu$`o(:2['
    str_9 = 'MCI/`vnhB]Hs'
    str

# Generated at 2022-06-25 04:43:43.105634
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    str_0 = '0.1|H,v}8c^WK'
    encrypt = AnsibleVaultEncryptedUnicode(data=str_0)
    # count of AnsibleVaultEncryptedUnicode is called
    result = encrypt.count()


# Generated at 2022-06-25 04:44:06.189265
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('gI2vxTx1wdT0OCmTmsTn6ZlXSvSQzKj3qcY8ScnW4FEGfB6U4nnsU_8ihYCZdOAyyiD1-Lzj37JRQ')

# Generated at 2022-06-25 04:44:09.278533
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = None
    assert ansible_vault_encrypted_unicode_0 == None


# Generated at 2022-06-25 04:44:11.688371
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # FIXME: implement this function
    pass


# Generated at 2022-06-25 04:44:13.310913
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    value = 'value'
    encrypted = AnsibleVaultEncryptedUnicode.from_plaintext(value, vault=None, secret='password')
    assert encrypted > value


# Generated at 2022-06-25 04:44:23.071577
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    """
    Unit tests for the AnsibleVaultEncryptedUnicode class's __eq__ method

    Tests:
        AnsibleVaultEncryptedUnicode vs. itself
        AnsibleVaultEncryptedUnicode vs. non-AnsibleVaultEncryptedUnicode
    """

    # Test against itself
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('test')
    assert ansible_vault_encrypted_unicode_0 == 'test'

    # Test against non-AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('test')
    assert ansible_vault_encrypted_unicode_1 == 'test'
    assert ansible_vault_encrypted_unicode_1

# Generated at 2022-06-25 04:44:30.871385
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # NOTE: This test will fail due to the fact that !vault is not a yaml tag that yaml will load.
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(None)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(None)
    # [ansible_vault_encrypted_unicode_0 '__gt__' ansible_vault_encrypted_unicode_1] -> (gbool)
    ansible_vault_encrypted_unicode_0.__gt__(ansible_vault_encrypted_unicode_1)



# Generated at 2022-06-25 04:44:41.099506
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    # BEGIN: Test for method __gt__ of class AnsibleVaultEncryptedUnicode

    avu = AnsibleVaultEncryptedUnicode(b'foo')
    assert avu > 'bar'
    avu = AnsibleVaultEncryptedUnicode(b'foo')
    assert not avu > 'bar'
    avu = AnsibleVaultEncryptedUnicode(b'foo')
    assert not avu > 'foo'
    avu = AnsibleVaultEncryptedUnicode(b'foo')
    assert not avu > 'foo'

    # END: Test for method __gt__ of class AnsibleVaultEncryptedUnicode


# Generated at 2022-06-25 04:44:44.788800
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """Test __ne__ of AnsibleVaultEncryptedUnicode"""

    # Setup
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(b'0')

    # Testing
    assert ansible_vault_encrypted_unicode_0.__ne__(0) is True



# Generated at 2022-06-25 04:44:50.591085
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.data = 'test_value_1'
    assert (ansible_vault_encrypted_unicode_0 == 'test_value_1')


# Generated at 2022-06-25 04:44:54.418233
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    try:
        assert ansible_vault_encrypted_unicode_0.__eq__()
    except NotImplementedError:
        pass
    else:
        assert False


# Generated at 2022-06-25 04:45:05.013920
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Unit test for replacing __ne__
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str())
    ansible_vault_encrypted_unicode_0.data = "3"
    # Replace the following line with actual test
    assert False == ansible_vault_encrypted_unicode_0.__ne__(None)



# Generated at 2022-06-25 04:45:13.067118
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = '0123456789'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.data = str_0
    ansible_vault_encrypted_unicode_0.vault = None
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(str_0)


# Generated at 2022-06-25 04:45:20.688501
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 178.93
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    int_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:45:25.527309
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(int_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(int_1)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(int_1)


# Generated at 2022-06-25 04:45:29.898001
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
  ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('0')
  var_0 = ansible_vault_encrypted_unicode_0 == '0'
  assert var_0


# Generated at 2022-06-25 04:45:35.775500
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('pyramid')
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__('pyramid')
    assert not bool_0


# Generated at 2022-06-25 04:45:41.173675
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    float_1 = -912.09
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(float_1)


# Generated at 2022-06-25 04:45:50.742117
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = "\tQ%\t\t\t"
    str_1 = "\r"
    str_2 = "RePg4Y4RY\r7f_RZ!cV1S&\tX\r7\t"
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_2)
    var_0 = ansible_vault_encrypted_unicode_1.__ne__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:45:58.410900
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('some encrypted text')

    assert ansible_vault_encrypted_unicode == 'some encrypted text'
    assert 'some encrypted text' == ansible_vault_encrypted_encrypted_unicode

    assert ansible_vault_encrypted_unicode != 'some encrypted text'
    assert 'some encrypted text' != ansible_vault_encrypted_encrypted_unicode



# Generated at 2022-06-25 04:46:02.508753
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 90.1728
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    # Test with float_0 as the argument
    # var_1 = ansible_vault_encrypted_unicode_0.__eq__(float_0)
    # Test with ansible_vault_encrypted_unicode_0 as the argument
    var_2 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)

# Unit Test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:46:09.239490
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.decrypt('ciphertext')
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    # assert var_0 == 'true'


# Generated at 2022-06-25 04:46:11.934012
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    float_1 = 5574.17
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(float_1)


# Generated at 2022-06-25 04:46:15.848569
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(None)


# Generated at 2022-06-25 04:46:20.094226
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:46:22.478954
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    int_0 = 1
    str_0 = ansible_vault_encrypted_unicode_0.split(int_0)


# Generated at 2022-06-25 04:46:23.995424
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass


# Generated at 2022-06-25 04:46:31.750855
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1588.92
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    boolean_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0)
    assert(boolean_0 == False)


# Generated at 2022-06-25 04:46:39.062973
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 559.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:46:43.309645
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert var_0 == False


# Generated at 2022-06-25 04:46:46.795518
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -290.0
    #assert variable == value (FAIL)
    # If a test has a failure, the try..except clause prevents the system from exiting


# Generated at 2022-06-25 04:46:56.427150
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    class_0 = AnsibleVaultEncryptedUnicode(str)
    int_0 = 6
    # AssertionError is expected
    with pytest.raises(AssertionError) as exception:
        class_0.__ne__(int_0)


# Generated at 2022-06-25 04:46:59.664399
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    int_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(int_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(int_0)
    assert var_0 == False


# Generated at 2022-06-25 04:47:03.127291
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    var_0 = AnsibleVaultEncryptedUnicode(23)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(var_0)
    var_1 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert var_1 == False


# Generated at 2022-06-25 04:47:11.267239
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(dict_0)
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1) == False

    # Test for equality of none
    assert ansible_vault_encrypted_unicode_0.__ne__(None) == True


# Generated at 2022-06-25 04:47:15.374701
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_2 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)



# Generated at 2022-06-25 04:47:18.496214
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    test_param = AnsibleVaultEncryptedUnicode.from_plaintext('123', None, None)
    assert not test_param.__eq__('123')


# Generated at 2022-06-25 04:47:21.704505
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:47:26.903497
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(u'7')
    assert ansible_vault_encrypted_unicode_0.__eq__(u'7')


# Generated at 2022-06-25 04:47:31.516153
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1444.35

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    result = ansible_vault_encrypted_unicode_0.is_encrypted()

    assert result == False


# Generated at 2022-06-25 04:47:37.793389
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # this is the "real" UNSAFE_STRING
    # and the AnsibleVaultEncryptedUnicode is UNSAFE, the following is not
    # because it is not using the UNSAFE global
    float_0 = float()
    float_0 = -3419.166
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    tmp_1 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert(tmp_1 == False)


# Generated at 2022-06-25 04:47:46.449664
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('secure_vector')
    assert not ansible_vault_encrypted_unicode_0.__ne__('$sFnX`B7I')


# Generated at 2022-06-25 04:47:50.327723
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    int_0 = ansible_vault_encrypted_unicode_0.__eq__(int_0)


# Generated at 2022-06-25 04:47:55.327471
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    float_1 = 1444
    assert not ansible_vault_encrypted_unicode_0.__eq__(float_1)


# Generated at 2022-06-25 04:48:03.012491
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(float_0)


# Generated at 2022-06-25 04:48:08.924375
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 1748.03
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(list_0)


# Generated at 2022-06-25 04:48:09.486569
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert True



# Generated at 2022-06-25 04:48:10.356338
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert True


# Generated at 2022-06-25 04:48:14.228560
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:48:17.834822
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__('')


# Generated at 2022-06-25 04:48:26.223513
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    string_0 = 'z_E'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(string_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__('z_E')
    assert var_0 == False

    string_0 = '=Jx'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(string_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__('=Jx')
    assert var_0 == True


# Generated at 2022-06-25 04:48:33.090841
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    boolean_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    print(boolean_0)



# Generated at 2022-06-25 04:48:37.682434
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Test is the method is_encrypted working
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:48:41.074378
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('abcd')
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:48:43.681061
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = "Blah blah blah"
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:48:45.490443
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode.from_plaintext('This is a string')
    assert ansible_vault_encrypted_unicode_1.is_encrypted() == True



# Generated at 2022-06-25 04:48:47.621903
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode("abc").__eq__("abc") == True
    assert AnsibleVaultEncryptedUnicode("abc").__eq__("ABC") == False
    assert AnsibleVaultEncryptedUnicode("ABC").__eq__("abc") == False


# Generated at 2022-06-25 04:48:57.690051
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 1434.02
    dict_0 = {"foo":1434.02}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_0.data = ansible_vault_encrypted_unicode_1
    ansible_vault_encrypted_unicode_0.__eq__(dict_0)
    ansible_vault_encrypted_unicode_0.__eq__(float_0)
    ansible_vault_encrypted_unicode_0.__eq__(1434.02)

    #Negative Test Cases:
    #Test Case 1
    ansible_

# Generated at 2022-06-25 04:49:02.786891
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 0.375
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    boolean_0 = ansible_vault_encrypted_unicode_0.__eq__(float_0)
    boolean_1 = ansible_vault_encrypted_unicode_0.__eq__(None)


# Generated at 2022-06-25 04:49:10.774589
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 1745.66
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    float_1 = float('inf')
    float_2 = float('inf')
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(float_1)
    assert var_0 == False
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_1)
    var_1 = ansible_vault_encrypted_unicode_1.__ne__(float_2)
    assert var_1 == False


# Generated at 2022-06-25 04:49:15.718252
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__('&QyOCq:')


# Generated at 2022-06-25 04:49:24.022916
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert ansible_vault_encrypted_unicode_0.__ne__('2030.3')
    assert not ansible_vault_encrypted_unicode_0.__ne__(1038.0)


# Generated at 2022-06-25 04:49:36.799551
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_arg_0 = -1444.35
    dict_arg_1 = {"abc": 1.0}
    ansible_vault_encrypted_unicode_arg_2 = AnsibleVaultEncryptedUnicode(float_arg_0)
    ansible_vault_encrypted_unicode_arg_3 = AnsibleVaultEncryptedUnicode(dict_arg_1)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_arg_0)
    ansible_vault_encrypted_unicode_0.data = ansible_vault_encrypted_unicode_arg_3
    dict_1 = {"abc": 1.0}
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(dict_1)
   

# Generated at 2022-06-25 04:49:42.491971
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(u'7')
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(volatile.AnsibleVaultEncryptedUnicode('a'))


# Generated at 2022-06-25 04:49:49.249730
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    # Test the AnsibleVaultEncryptedUnicode constructor
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)

    # Test the AnsibleVaultEncryptedUnicode __eq__ method
    var_0 = 'Hello'
    var_1 = var_0 == ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 04:49:55.717220
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:50:01.631934
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert True == ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:50:04.846698
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(float_0)


# Generated at 2022-06-25 04:50:11.706012
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(False)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(True)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)
    assert var_0


# Generated at 2022-06-25 04:50:18.892198
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 12.97
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:50:25.361449
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)
    bool_1 = False
    assert ansible_vault_encrypted_unicode_0.__ne__(bool_1) == True
    int_0 = -59512
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(int_0)
    int_1 = 0
    assert ansible_vault_encrypted_unicode_1.__ne__(int_1) == True
    str_0 = 'do not compare unicode'
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'test_case_1'
    assert ansible

# Generated at 2022-06-25 04:50:35.780610
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'z0lS'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.__ne__(str_0)
    ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0.__ne__)


# Generated at 2022-06-25 04:50:42.828234
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 7515.98
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__()
    # __eq__ has incorrect return type
    assert isinstance(bool_0, bool)


# Generated at 2022-06-25 04:50:43.875791
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    uni = AnsibleVaultEncryptedUnicode(0)
    res = uni.__ne__('a')



# Generated at 2022-06-25 04:50:53.033539
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'j[\x1f\x1aj#\x1e\x17\x0bq\x12\x1b\n\x07*\n'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    int_0 = ansible_vault_encrypted_unicode_0.__eq__(str_0)


# Generated at 2022-06-25 04:51:00.546639
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(True)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(False)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    var_1 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)
    ansible_vault_encrypted_unicode_0.__eq__(False)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:05.090758
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    inp = AnsibleVaultEncryptedUnicode('1')
    inp.vault = FakeVault()
    assert inp == 1
    assert inp != 0
    assert not inp != 1
    assert inp != '2'
    assert not inp == '1'



# Generated at 2022-06-25 04:51:11.231880
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()

    AnsibleVaultEncryptedUnicode_0 = AnsibleVaultEncryptedUnicode(bool_0, bool_1, bool_2, bool_3)
    assert AnsibleVaultEncryptedUnicode_0.__eq__(bool_4) == False
    assert AnsibleVaultEncryptedUnicode_0.__eq__(bool_5) == False
    assert AnsibleVaultEncryptedUnicode_0.__eq__(bool_6) == False


# Generated at 2022-06-25 04:51:16.889624
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('before')
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:51:20.756422
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    int_0 = 38
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(int_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(int_0)
    print(var_0)


# Generated at 2022-06-25 04:51:26.469439
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(None)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(None)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(None)
    var_0 = (ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1)
    var_1 = (ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_2)


# Generated at 2022-06-25 04:51:37.949279
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    boolean_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0)
    assert boolean_0


# Generated at 2022-06-25 04:51:41.634697
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(u'mbkj')
    any_0 = str()
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(any_0)



# Generated at 2022-06-25 04:51:45.588549
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    global float_0, ansible_vault_encrypted_unicode_0, var_0
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:51:48.235624
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -2.0106454
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(float_0)


# Generated at 2022-06-25 04:51:53.232356
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:57.037233
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:59.604707
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    list_0 = [1]
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(list_0)


# Generated at 2022-06-25 04:52:02.237163
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -29.07
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:52:09.971548
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__(float_0)


# Generated at 2022-06-25 04:52:13.543614
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1444.35
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)
    var_0 = ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
