

# Generated at 2022-06-25 04:42:41.577314
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test setup, etc
    AnsibleVaultEncryptedUnicode

    # Test execution
    # Test assertion(s)
    assert false



# Generated at 2022-06-25 04:42:53.217038
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    import ansible.parsing.vault

    vault = ansible.parsing.vault.VaultLib('ansible')
    # pylint: disable=protected-access
    protected_0 = vault._VaultLib__generate_new_password()
    protected_1 = vault._VaultLib__generate_new_password()

    # pass in a plaintext string and a Vault object
    plaintext = 'string'
    encrypted_0 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, protected_0)
    assert encrypted_0.is_encrypted()
    assert isinstance(encrypted_0.data, text_type)
    assert encrypted_0.data == 'string'

    # pass in a plaintext unicode object and a Vault object
    plaintext = u'unicode'
   

# Generated at 2022-06-25 04:42:54.457801
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    try:
        if self.__eq__(other):
            return
    except:
        return


# Generated at 2022-06-25 04:42:55.827875
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bool_0 = None
    ansible_mapping_0 = AnsibleMapping()


# Generated at 2022-06-25 04:42:58.543587
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    # assert that the comparison (AnsibleVaultEncryptedUnicode < "test") returns true
    assert AnsibleVaultEncryptedUnicode("test") <= "test"


# Generated at 2022-06-25 04:43:02.562769
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_unicode_0 = AnsibleVaultEncryptedUnicode('')
    ansible_unicode_1 = AnsibleVaultEncryptedUnicode('...')
    assert ansible_unicode_0 != ansible_unicode_1


# Generated at 2022-06-25 04:43:06.650109
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Input parameters
    obj = None
    start = 0
    end = None

    # Output: return value
    # Actual output:
    result = None

    # Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
    assert result == None


# Generated at 2022-06-25 04:43:08.747630
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = None
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bool_0)


# Generated at 2022-06-25 04:43:11.890179
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = None
    temp_obj = AnsibleVaultEncryptedUnicode("")
    bool_0 = temp_obj.__eq__("")
    assert bool_0 == False


# Generated at 2022-06-25 04:43:16.761304
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    assert (ansible_vault_encrypted_unicode_0 <= ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:43:30.824550
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -145.0
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    str_0 = 'ra'
    ansible_vault_encrypted_unicode_0 == str_0


# Generated at 2022-06-25 04:43:37.515958
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1) == False
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)

# Generated at 2022-06-25 04:43:43.213474
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:43:45.653402
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:43:49.067321
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert True


# Generated at 2022-06-25 04:43:52.693431
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:43:55.056016
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert type(AnsibleVaultEncryptedUnicode.__ne__(AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedUnicode)) == bool


# Generated at 2022-06-25 04:44:05.541409
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    int_0 = -15
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(int_0)
    float_0 = float(int_0)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(int_0)
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_2


# Generated at 2022-06-25 04:44:06.368234
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    test_case_0()


# Generated at 2022-06-25 04:44:07.941873
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    test_case_0()


# Generated at 2022-06-25 04:44:20.474684
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    test_AnsibleVaultEncryptedUnicode___getslice___tuple_0 = ()
    ansible_vault_encrypted_unicode_0.__init__(test_AnsibleVaultEncryptedUnicode___getslice___tuple_0)


# Generated at 2022-06-25 04:44:30.823416
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # create new object
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    list_0 = ["a", "b", "c", "d", "e"]
    # substring in list
    ansible_vault_encrypted_unicode_0.__getslice__(0, len(list_0))
    # substring at the edge of list
    ansible_vault_encrypted_unicode_0.__getslice__(0, 2)
    ansible_vault_encrypted_unicode_0.__getslice__(1, len(list_0))
    # substring of single character
    ansible_vault_encrypted_unicode_0.__getslice__(2, 3)
    # substring of single character at the edge of list
   

# Generated at 2022-06-25 04:44:34.766251
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    test_case_0()


# Generated at 2022-06-25 04:44:43.277330
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.plugins.vault import VaultLib

    vault = VaultLib(_vault_password_file='test/ansible-vault-password-test.txt')

    # Case 1: Encrypted __eq__ is False for same plaintext strings (case-sensitive)
    # When
    plaintext_a = 'hello world'
    plaintext_b = 'hello world'
    a = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext_a, vault, secret='hello')
    b = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext_b, vault, secret='hello')

    # Then
    assert a == b

    # Case 2: Encrypted __eq__ is False for same plaintext strings (case-insensitive)
    # When
    plaintext_a = 'hello world'


# Generated at 2022-06-25 04:44:54.256533
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    # Testing against: '\x80\x9f\x8d\xabo\x8a\xa0\xd2\x06\xa2\x0c\\\xe3\xad\xab\xf0\xa8'
    test = AnsibleVaultEncryptedUnicode('\x80\x9f\x8d\xabo\x8a\xa0\xd2\x06\xa2\x0c\\\xe3\xad\xab\xf0\xa8')
    test.__getslice__(4, 0)

    # Testing against: '\x1b\x1b6\xb3\x19\xb7'
    test = AnsibleVaultEncryptedUnicode('\x1b\x1b6\xb3\x19\xb7')
   

# Generated at 2022-06-25 04:45:02.345659
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    print("Testing AnsibleVaultEncryptedUnicode.is_encrypted()")
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ret_val_0 = ansible_vault_encrypted_unicode_0.is_encrypted();
    if ret_val_0 != False:
        print("TEST FAILED: expected 'TEST_FAILED'")
        sys.exit(1)
    print("TEST PASSED")
    return


# Generated at 2022-06-25 04:45:03.231988
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    test_case_0()


# Generated at 2022-06-25 04:45:07.679769
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    exception_raised1 = None
    try:
        ansible_vault_encrypted_unicode_0.__getslice__(float_0, float_0)
    except Exception as e1:
        exception_raised1 = e1
    assert not exception_raised1



# Generated at 2022-06-25 04:45:14.811226
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with 0 arguments
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(0.00)
    try:
        if (ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1):
            raise AssertionError("Expected 'False', got '%s'" % "True")
    except AssertionError:
        _stderr.write('AssertionError: Expected \'False\', got \'%s\'' % "True")
        raise
    # Test with 1 arguments
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(1)

# Generated at 2022-06-25 04:45:26.642519
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.data = 'uy5w'
    ansible_vault_encrypted_unicode_0.vault = yaml.YAMLObject()
    ansible_vault_encrypted_unicode_0.vault.read = yaml.YAMLObject()
    ansible_vault_encrypted_unicode_0.vault.read.data = 'x'
    ansible_vault_encrypted_unicode_0.vault.decrypt = yaml.YAMLObject()
    ansible_vault_encrypted_unicode_0.vault.decrypt.data = '1'
    ansible

# Generated at 2022-06-25 04:45:39.883121
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -15.51
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    float_1 = -7.98
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_1)
    ansible_vault_encrypted_unicode_0.vault = ansible_vault_encrypted_unicode_0
    ansible_vault_encrypted_unicode_0.data = float_0
    ansible_vault_encrypted_unicode_1.vault = ansible_vault_encrypted_unicode_0
    ansible_vault_encrypted_unicode_1.data = float_1
    assert not ansible_vault_encrypted_unicode_0 == ansible_vault

# Generated at 2022-06-25 04:45:43.302458
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -15.9
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:45:46.785524
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert bool_0 == True



# Generated at 2022-06-25 04:45:48.308896
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)


# Generated at 2022-06-25 04:45:50.701221
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 1.25
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    with pytest.raises(Exception):
        assert ansible_vault_encrypted_unicode_0 == float_0


# Generated at 2022-06-25 04:45:56.512288
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # input
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(0)

    with pytest.raises(NotImplementedError) as e:
        AnsibleVaultEncryptedUnicode.is_encrypted(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:46:00.608959
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float(-1789.89))
    assert not ansible_vault_encrypted_unicode_0.__eq__(float(-1789.89))



# Generated at 2022-06-25 04:46:01.524161
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    pass


# Generated at 2022-06-25 04:46:07.877163
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -85.97
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    a = [ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0), ansible_vault_encrypted_unicode_0.__eq__(float_0), ansible_vault_encrypted_unicode_0.__eq__(list()), ansible_vault_encrypted_unicode_0.__eq__(list()), ansible_vault_encrypted_unicode_0.__eq__(-1617.34)]
    print(a)


# Generated at 2022-06-25 04:46:16.977823
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    res = None
    float_0 = -235.46478
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.vault = StringIO("this is a test")
    float_1 = -235.46478
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_1)
    res = ansible_vault_encrypted_unicode_1.__eq__(ansible_vault_encrypted_unicode_0)
    assert(res)



# Generated at 2022-06-25 04:46:23.122189
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Input Params
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(0.0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(0.0)
    # Output Params
    ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:46:31.004609
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert not ansible_vault_encrypted_unicode_0.__ne__(str(float_0))


# Generated at 2022-06-25 04:46:41.315556
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 823.85
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0 = ansible_vault_encrypted_unicode_0.title()
    ansible_vault_encrypted_unicode_1 = __AnsibleVaultEncryptedUnicode__(ansible_vault_encrypted_unicode_0)
    ansible_vault_encrypted_unicode_2 = __AnsibleVaultEncryptedUnicode__(ansible_vault_encrypted_unicode_0)
    ansible_vault_encrypted_unicode_2 = ansible_vault_encrypted_unicode_2.swapcase()
    float_1 = -62.22
    ansible_vault

# Generated at 2022-06-25 04:46:46.580756
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    try:
        ansible_vault_encrypted_unicode_0.__eq__()
    except:
        pass


# Generated at 2022-06-25 04:46:54.323693
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = False

# Generated at 2022-06-25 04:46:57.408434
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('')
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:47:01.422175
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert  not AnsibleVaultEncryptedUnicode(0).__ne__(None)
    assert  not AnsibleVaultEncryptedUnicode(0).__ne__("")
    assert  not AnsibleVaultEncryptedUnicode("").__ne__("")
    assert  not AnsibleVaultEncryptedUnicode("").__ne__(0)


# Generated at 2022-06-25 04:47:03.865034
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    test_case_0()


# Generated at 2022-06-25 04:47:08.918835
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.ansible_pos = None
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_0.endswith('')


# Generated at 2022-06-25 04:47:13.774761
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    #test_0
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(-1789.89)
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1

    return


# Generated at 2022-06-25 04:47:26.533915
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Instantiating the object
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    # Calling the method under test
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:47:31.973697
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = 1789.89
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:47:33.777680
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    case_0()
    case_1()
    test_case_0()


# Generated at 2022-06-25 04:47:42.844800
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -2421.4
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    int_0 = 0
    str_0 = str(ansible_vault_encrypted_unicode_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(int_0)
    int_1 = 0
    str_1 = str_0

    # Simple test to see if __eq__ throws or not
    try:
        ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    except Exception as e:
        print(e)
    assert(str_0 == str_1)
test_AnsibleVaultEncryptedUnic

# Generated at 2022-06-25 04:47:48.249445
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 1789.0
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    float_1 = 2134.99
    ansible_vault_encrypted_unicode_0 = ansible_vault_encrypted_unicode_0.__ne__(float_1)


# Generated at 2022-06-25 04:47:51.616244
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    # from ansible.parsing.vault import VaultLib
    # vault = VaultLib([])
    # avue = AnsibleVaultEncryptedUnicode('abc', vault)
    # assert avue != 'abc'
    pass



# Generated at 2022-06-25 04:47:54.060318
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    a = to_text("a")
    b = to_text("b")
    assert a != b


# Generated at 2022-06-25 04:47:56.840850
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 554.91
    bcir_0 = AnsibleVaultEncryptedUnicode(float_0)
    bool_0 = bcir_0.__ne__()


# Generated at 2022-06-25 04:48:03.152497
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    with pytest.raises(AnsibleVaultError):
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('^')
        str_0 = ''
        ansible_vault_encrypted_unicode_0.__ne__(str_0)


# Generated at 2022-06-25 04:48:07.791155
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    u'''Check that method is_encrypted of class AnsibleVaultEncryptedUnicode is called.'''

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()
    try:
        assert True
    except AssertionError as e:
        print('AssertionError raised: ', e)


# Generated at 2022-06-25 04:48:20.762687
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_7 = -904.57
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_7)
    ansible_vault_encrypted_unicode_1.is_encrypted()
    float_3 = -966.1
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(float_3)
    ansible_vault_encrypted_unicode_2.is_encrypted()


# Generated at 2022-06-25 04:48:25.823907
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(1)
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:48:34.985755
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    float_1 = float("nan")
    float_0 = float("nan")
    float_0 = float("nan")
    float_2 = float("nan")
    float_2 = float("nan")
    float_0 = float("nan")
    float_2 = float("nan")
    float_0 = float("nan")
    float_2 = float("nan")
    float_1 = float("nan")
    float_0 = float("nan")
    float_1 = float("nan")
    float_0 = float("nan")
    float_2 = float("nan")
    float_2 = float("nan")
    float_0 = float("nan")

# Generated at 2022-06-25 04:48:36.020204
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    test_case_0()


# Generated at 2022-06-25 04:48:43.359768
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert AnsibleVaultEncryptedUnicode(17.48).is_encrypted() == False
    assert AnsibleVaultEncryptedUnicode("axbxlx").is_encrypted() == False
    assert AnsibleVaultEncryptedUnicode(b'H^\xfb\xfd\xfe\x00\x05\xeb\xd3').is_encrypted() == False
    assert AnsibleVaultEncryptedUnicode(112.78).is_encrypted() == False
    assert AnsibleVaultEncryptedUnicode(-52.27).is_encrypted() == False
    assert AnsibleVaultEncryptedUnicode(-4).is_encrypted() == False
    assert AnsibleVaultEncryptedUnicode("vrokx").is_encrypted() == False

# Generated at 2022-06-25 04:48:45.487270
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert ansible_vault_encrypted_unicode_0._AnsibleVaultEncryptedUnicode__eq__() == "Hi :)"


# Generated at 2022-06-25 04:48:50.493519
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    flag = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert flag == False
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('abcdefg')
    flag = ansible_vault_encrypted_unicode_1.is_encrypted()
    assert flag == False


# Generated at 2022-06-25 04:48:53.577267
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    int_0 = 666534
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(int_0)
    assert (ansible_vault_encrypted_unicode_0.is_encrypted() == False)


# Generated at 2022-06-25 04:49:00.564693
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    int_0 = -2
    str_0 = 'd\r=pev\x7fWl|\x7f\x7f'
    str_1 = 'Y6UH\x7fMO\x7f'
    str_2 = '4\x7f\x7f'
    str_3 = 'Dqik\x7f\x7f'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_3)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_2)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_3 = AnsibleVault

# Generated at 2022-06-25 04:49:10.804876
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    print("START TEST test_AnsibleVaultEncryptedUnicode_is_encrypted")
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("test")
    # Test when this method is called before the .vault attribute is set
    ansible_vault_encrypted_unicode_0.vault = None
    if ansible_vault_encrypted_unicode_0.is_encrypted():
        print("Test 1: PASS")
    else:
        print("Test 1: FAIL")
    ansible_vault_encrypted_unicode_0.vault = "test"
    if ansible_vault_encrypted_unicode_0.is_encrypted():
        print("Test 2: PASS")
    else:
        print("Test 2: FAIL")

# Generated at 2022-06-25 04:49:21.934847
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Code coverage for AnsibleVaultEncryptedUnicode.is_encrypted()
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:49:24.832711
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)

    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False



# Generated at 2022-06-25 04:49:35.494547
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()
    unicode_0 = u"\n    - name: This is a test\n      foo: bar\n"
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(unicode_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:49:38.785695
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(1)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(0)
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:49:45.536582
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    try:
        ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)
    except:
        assert False


# Generated at 2022-06-25 04:49:56.298353
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')

    with pytest.raises(vault.AnsibleVaultError):
        ansible_vault_encrypted_unicode_0.is_encrypted()

    # NOTE: The Vault must be initialized with the password.
    # NOTE: Get the password by calling 'get_vault_pass_'
    ansible_vault_encrypted_unicode_0.vault = vault.VaultLib('')
    assert ansible_vault_encrypted_unicode_0.is_encrypted()

    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('')
    with pytest.raises(vault.AnsibleVaultError):
        ansible_vault_encrypted_

# Generated at 2022-06-25 04:50:01.434846
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:50:04.392824
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:50:10.846999
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    int_0 = 0
    bool_0 = int_0 < ansible_vault_encrypted_unicode_0.__ne__(float_0)
    assert bool_0


# Generated at 2022-06-25 04:50:14.642365
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    test_val = ansible_vault_encrypted_unicode_0.__ne__(float_0)
    assert test_val == True


# Generated at 2022-06-25 04:50:27.663277
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = '#'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()
    str_1 = '\n'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert not ansible_vault_encrypted_unicode_1.is_encrypted()
    str_2 = '#'
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_2)
    assert not ansible_vault_encrypted_unicode_2.is_encrypted()
    str_3 = '\n'
    ansible_vault_encrypted_unicode

# Generated at 2022-06-25 04:50:32.529767
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    float_0 = -1789.89
    assert ansible_vault_encrypted_unicode_0 == float_0



# Generated at 2022-06-25 04:50:36.609158
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    bool_0 = not ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 04:50:44.038519
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = 864.27
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    float_1 = 203.3
    assert not ansible_vault_encrypted_unicode_0.__eq__(float_1)
    float_1 = float_0
    assert ansible_vault_encrypted_unicode_0.__eq__(float_1)


# Generated at 2022-06-25 04:50:50.421886
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = str("\"J")
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = str("\x0b\x1a")
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(str_1)
    # Assert the value of bool_0 is True
    assert bool_0 == True
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)
    # Assert the value of bool_0 is True
    assert bool_0 == True


# Generated at 2022-06-25 04:50:56.174589
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('U')
    assert not ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0), "__eq__(AnsibleVaultEncryptedUnicode) failed"


# Generated at 2022-06-25 04:51:01.662157
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    boolean_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:08.531945
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    str_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    print(str_0)


# Generated at 2022-06-25 04:51:17.876875
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(-98.06)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1.ansible_pos = (-47.54, 96, -77)
    ansible_vault_encrypted_unicode_1.vault = unittest.mock.MagicMock()
    ansible_vault_encrypted_unicode_1.vault.decrypt.return_value = '80.22'
    ansible_vault_encrypted_unicode_1.vault.is_encrypted.return_value = True
    ansible_vault_encrypted_unicode_1.data = '2.0'


# Generated at 2022-06-25 04:51:26.667398
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    Test the AnsibleVaultEncryptedUnicode class
    """
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)

    str_0 = "5"
    float_1 = float(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_1)

    # If is encrypted, __ne__ will return true since it does not know the actual value
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:51:39.425764
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = 8.88
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    assert not ansible_vault_encrypted_unicode_0.__ne__(float_0)


# Generated at 2022-06-25 04:51:44.939110
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_0 = -1692.87
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    float_1 = 2556.91
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_1)
    assert (ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:51:49.439401
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -5.0
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    int_0 = stdin(1)
    if not ansible_vault_encrypted_unicode_0.__ne__(int_0):
        print('unit test failed')
    else:
        print('unit test passed')


# Generated at 2022-06-25 04:51:50.322291
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bool_0 = bool()
    # assert func_0
    assert bool_0


# Generated at 2022-06-25 04:51:52.945945
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("")
    assert False == ansible_vault_encrypted_unicode_0.__ne__("")


# Generated at 2022-06-25 04:51:55.587280
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    float_1 = AnsibleVaultEncryptedUnicode(0.0)
    float_1.data = 1.0
    assert float_1 == 1.0


# Generated at 2022-06-25 04:52:02.696094
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    float_0 = -1789.89
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(float_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(float_0)
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:52:06.423941
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert True


# Generated at 2022-06-25 04:52:14.537907
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Input data for the Parametrized testcase
    AnsibleVaultEncryptedUnicode_is_encrypted_input_data = [
        # Testcase #1
        [
            AnsibleVaultEncryptedUnicode(b'\x02\x02\x02'),
            True
        ],
        # Testcase #2
        [
            AnsibleVaultEncryptedUnicode(b'\x01\x01\x01'),
            False
        ],
    ]
    # Output data for the Parametrized testcase
    AnsibleVaultEncryptedUnicode_is_encrypted_output_data = [
        # Testcase #1
        [
            True
        ],
        # Testcase #2
        [
            False
        ],
    ]

# Generated at 2022-06-25 04:52:23.171587
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(-1789.89)
    if ansible_vault_encrypted_unicode_0.is_encrypted():
        raise RuntimeError("Test Failed")
    ansible_vault_encrypted_unicode_0._ciphertext = bytes((0, 1, 2))
    if ansible_vault_encrypted_unicode_0.is_encrypted():
        raise RuntimeError("Test Failed")
    return
