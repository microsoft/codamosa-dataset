

# Generated at 2022-06-25 04:42:37.719816
# Unit test for method __lt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___lt__():
    # method name: __lt__
    # no type checking, no return
    pass


# Generated at 2022-06-25 04:42:41.003977
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    ansible_unicode_0 = AnsibleUnicode('')
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_unicode_0)
    ansible_vault_encrypted_unicode_0.__ge__()


# Generated at 2022-06-25 04:42:43.950628
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass


# Generated at 2022-06-25 04:42:46.330179
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)



# Generated at 2022-06-25 04:42:57.095201
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_a = {}
    ansible_vault_encrypted_unicode_a = AnsibleVaultEncryptedUnicode(dict_a)

    dict_b = {}
    ansible_vault_encrypted_unicode_b = AnsibleVaultEncryptedUnicode(dict_b)

    # False case
    if (ansible_vault_encrypted_unicode_a == ansible_vault_encrypted_unicode_b):
        raise AssertionError('Failed to test equality of AnsibleVaultEncryptedUnicode')

    # True case
    ansible_vault_encrypted_unicode_a._ciphertext = ansible_vault_encrypted_unicode_b._ciphertext

# Generated at 2022-06-25 04:42:59.055993
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    print("Running test_AnsibleVaultEncryptedUnicode_is_encrypted...")
    test_case_0()


# Generated at 2022-06-25 04:43:02.674784
# Unit test for method __ge__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ge__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    str_0 = '2' * 5
    bool_0 = ansible_vault_encrypted_unicode_0 >= str_0


# Generated at 2022-06-25 04:43:09.755665
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.data = ansible_vault_encrypted_unicode_1.data
    # assert not ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1.data



# Generated at 2022-06-25 04:43:13.289999
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:43:17.426155
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert ansible_vault_encrypted_unicode_0 == "str"


# Generated at 2022-06-25 04:43:33.825422
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    """
    Tests if the encryption is correct using a known value
    """
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('test')
    with open('../../../examples/ansible-vault/vaultpassword', 'r') as vault_password_file:
        password = vault_password_file.read()
    ansible_vault_encrypted_unicode_0.vault = vaultlib.VaultLib(password)
    assert ansible_vault_encrypted_unicode_0 == 'test'

# Generated at 2022-06-25 04:43:39.571419
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_0 = ""
    assert ansible_vault_encrypted_unicode_0.__ne__(dict_0) == True


# Generated at 2022-06-25 04:43:44.652886
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    start = 0
    end = _sys.maxsize


# Generated at 2022-06-25 04:43:46.772217
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    pass


# Generated at 2022-06-25 04:43:50.423758
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    dict_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    maxsize_0 = _sys.maxsize
    int_0 = ansible_vault_encrypted_unicode_0.__getslice__(0, maxsize_0)


# Generated at 2022-06-25 04:43:53.495220
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert ansible_vault_encrypted_unicode_0 <= False


# Generated at 2022-06-25 04:43:59.064450
# Unit test for method __le__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___le__():
    # Test for method __le__(self, string)
    assert AnsibleVaultEncryptedUnicode('ab').__le__(AnsibleVaultEncryptedUnicode('ab'))


# Generated at 2022-06-25 04:44:03.325351
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_1 = {}
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(dict_1)
    dict_2 = {}
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(dict_2)
    ansible_vault_encrypted_unicode_1.__eq__(ansible_vault_encrypted_unicode_2)


# Generated at 2022-06-25 04:44:05.515586
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    try:
        dict_0 = {}
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
        ansible_vault_encrypted_unicode_0.__eq__(dict_0)
    except:
        print (_sys.exc_info()[1])


# Generated at 2022-06-25 04:44:08.462978
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_0.vault = None
    result = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert result is False
    ansible_vault_encrypted_unicode_0.vault = dict_0
    result = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert result is False


# Generated at 2022-06-25 04:44:20.319715
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():

    # cond_0__true_0 is a boolean value used in a boolean condition
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(None)
    cond_0__true_0 = ansible_vault_encrypted_unicode_0
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(None)

    if cond_0__true_0 is not None :
        if isinstance(cond_0__true_0, text_type):
            if True:
                assert False
        if not isinstance(cond_0__true_0, text_type):
            if True:
                assert False

# Generated at 2022-06-25 04:44:25.883291
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(None)
    ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:44:32.777371
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert not ansible_vault_encrypted_unicode_0.__eq__(dict_0)
    ansible_vault_encrypted_unicode_0.data = 'test'
    try:
        assert ansible_vault_encrypted_unicode_0.__eq__('test')
    except TypeError:
        assert False
    assert not ansible_vault_encrypted_unicode_0.__eq__('fail')




# Generated at 2022-06-25 04:44:34.900494
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:44:40.783527
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert not ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0)



# Generated at 2022-06-25 04:44:46.880561
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test case 1
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(dict_0)
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1, "Failed to handle positive case."
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0) == False, "Failed to handle negative case."


# Generated at 2022-06-25 04:44:53.093033
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    dict_0 = {'foo': 'asdf'}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    dict_1 = dict_0
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(dict_1)
    # assert (ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1))
    ansible_vault_encrypted_unicode_1._data_source = 'foo'
    # assert (ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1))


# Generated at 2022-06-25 04:44:55.190826
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    secret = 'secret'
    seq = 'some string'
    res = AnsibleVaultEncryptedUnicode.from_plaintext(seq, None, secret)
    assert(res.is_encrypted() == False)



# Generated at 2022-06-25 04:44:58.887303
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    int_0 = ansible_vault_encrypted_unicode_0.__eq__()


# Generated at 2022-06-25 04:45:02.589624
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)

    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:45:15.529624
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(dict_0)
    try:
        ansible_vault_encrypted_unicode_0.__eq__(dict_0)
    except NotImplementedError:
        pass
    except:
        raise AssertionError("unexpected exception")
    try:
        ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    except NotImplementedError:
        pass
    except:
        raise AssertionError("unexpected exception")


# Generated at 2022-06-25 04:45:21.355317
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert isinstance(ansible_vault_encrypted_unicode_0.is_encrypted(), bool)


# Generated at 2022-06-25 04:45:21.999225
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    pass


# Generated at 2022-06-25 04:45:24.880956
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode("")
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:45:30.548350
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_0.__ne__(dict_0)


# Generated at 2022-06-25 04:45:33.969031
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)

    assert ansible_vault_encrypted_unicode_0 != dict_0


# Generated at 2022-06-25 04:45:41.542238
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    dict_1 = {}
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(dict_1)
    ansible_vault_encrypted_unicode_1.__ne__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:45:51.249127
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    print("Test 0 for method __ne__ of class AnsibleVaultEncryptedUnicode")
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(0)
    ansible_vault_encrypted_unicode_0.__ne__(0)
    print("Test 1 for method __ne__ of class AnsibleVaultEncryptedUnicode")
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(1)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(0)
    ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)

# Generated at 2022-06-25 04:45:59.716579
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    dict_1 = {}
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(dict_1)
    ansible_vault_encrypted_unicode_0.data = dict_1
    res = ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
    print("\nResult:" + str(res))
    return res

# Generated at 2022-06-25 04:46:04.019128
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode({})
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode({})
    boolean_0 = ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:46:14.017398
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("")
    assert isinstance(ansible_vault_encrypted_unicode_0, AnsibleVaultEncryptedUnicode)
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0) is False


# Generated at 2022-06-25 04:46:17.667850
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('<CK>')

    # test case where both are the same
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_0

    # test case where one is the same
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('<CK>')
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1



# Generated at 2022-06-25 04:46:26.737156
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_0.vault = dict_0
    ansible_vault_encrypted_unicode_0.data = "abcd"
    # if self.vault:
    if 1:
        assert ansible_vault_encrypted_unicode_0.__eq__(dict_0)
    # {
    #     return False
    # }
    assert not ansible_vault_encrypted_unicode_0.__eq__(dict_0)


# Generated at 2022-06-25 04:46:31.003368
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert(not ansible_vault_encrypted_unicode_0.is_encrypted())


# Generated at 2022-06-25 04:46:32.636541
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
  assert AnsibleVaultEncryptedUnicode.__ne__() == False


# Generated at 2022-06-25 04:46:36.796292
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:46:43.076976
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    result = ansible_vault_encrypted_unicode_0.__ne__(dict_0)

    if result is not None:
        raise Exception("Expected None, got {}".format(result))



# Generated at 2022-06-25 04:46:52.821535
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing import vault
    from ansible.parsing.vault import VaultLib

    class FakeVaultLib(VaultLib):
        def __init__(self):
            self._file_vault_id = None

        def get_encryption_key(self):
            return b'key'

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('{$ANSIBLE_VAULT;1.1;AES256}')
    ansible_vault_encrypted_unicode_0.vault = FakeVaultLib()

    print('data %s' % ansible_vault_encrypted_unicode_0.data)

# Generated at 2022-06-25 04:46:56.652370
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'str'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:46:57.448208
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass


# Generated at 2022-06-25 04:47:04.792455
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert ansible_vault_encrypted_unicode_0.__eq__(dict_0)
    assert not ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:47:14.757296
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_1.vault = dict_0
    ansible_vault_encrypted_unicode_1.vault.is_encrypted = dict_0
    ansible_vault_encrypted_unicode_1.vault.decrypt = dict_0
    ansible_vault_encrypted_unicode_1.vault.is_encrypted(dict_0, dict_0)
    ansible_vault_encrypted_unicode_1.vault.decrypt(dict_0, dict_0)
    ansible_v

# Generated at 2022-06-25 04:47:19.095948
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    items = [{'a': 'b', 'c': 'd'}, "password"]
    for item in items:
        assert AnsibleVaultEncryptedUnicode(item) == item

    assert AnsibleVaultEncryptedUnicode(items[0]) != items[1]


# Generated at 2022-06-25 04:47:25.421676
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)

    try:
        ansible_vault_encrypted_unicode_0.__ne__(dict_0)
    except vault.AnsibleVaultError:
        pass


# Generated at 2022-06-25 04:47:31.880156
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test for method __eq__ (AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedUnicode)
    assert True == (AnsibleVaultEncryptedUnicode('fq') == AnsibleVaultEncryptedUnicode('fq'))
    assert True != (AnsibleVaultEncryptedUnicode('fq') == AnsibleVaultEncryptedUnicode('ab'))


# Generated at 2022-06-25 04:47:34.396318
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    test_case_0()



# Generated at 2022-06-25 04:47:40.523908
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_0.vault = {}
    try:
        ansible_vault_encrypted_unicode_0.__eq__(dict_0)
    except Exception as e:
        print("UNEXPECTED EXCEPTION:", e)
        raise


# Generated at 2022-06-25 04:47:45.272848
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)

    ansible_vault_encrypted_unicode_0.__eq__()


# Generated at 2022-06-25 04:47:52.452492
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    dict_0 = {}
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(dict_0)
    try:
        ansible_vault_encrypted_unicode_0 != dict_0
        assert False
    except AssertionError:
        pass
    ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:47:55.543739
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)


# Generated at 2022-06-25 04:48:05.027037
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert False == ansible_vault_encrypted_unicode_0.__eq__(dict_0)


# Generated at 2022-06-25 04:48:08.051638
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('str')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('str')

    status = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    assert status


# Generated at 2022-06-25 04:48:18.535721
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    print("> test_AnsibleVaultEncryptedUnicode___eq__")
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('Passw0rd00')
    ansible_vault_encrypted_unicode_0.vault = VaultLib('$ANSIBLE_VAULT;1.1;AES256')

# Generated at 2022-06-25 04:48:21.540236
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert not ansible_vault_encrypted_unicode_0.__ne__(dict_0)


# Generated at 2022-06-25 04:48:23.538427
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Call AnsibleVaultEncryptedUnicode.__ne__(self, other)
    test_case_0()


# Generated at 2022-06-25 04:48:30.866903
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    message = "This is a test message"

# Generated at 2022-06-25 04:48:36.542294
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:48:40.002502
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test case for built-in function __ne__
    # Encrypted unicode is not equal to other object
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(b'a')
    assert ansible_vault_encrypted_unicode_0.__ne__('b') == True


# Generated at 2022-06-25 04:48:43.661402
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert ansible_vault_encrypted_unicode_0.__ne__("") == True


# Generated at 2022-06-25 04:48:47.740054
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_0.data = 'foo'
    assert ansible_vault_encrypted_unicode_0.is_encrypted() is False


# Generated at 2022-06-25 04:48:59.290535
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Assert that AnsibleVaultEncryptedUnicode.__ne__() returns <type 'bool'>
    assert(isinstance(AnsibleVaultEncryptedUnicode('').__ne__('a'), bool))
    # Assert that AnsibleVaultEncryptedUnicode.__ne__() returns <type 'bool'>
    assert(isinstance(AnsibleVaultEncryptedUnicode('foo').__ne__('foo'), bool))
    # Assert that AnsibleVaultEncryptedUnicode.__ne__() returns <type 'bool'>
    assert(isinstance(AnsibleVaultEncryptedUnicode('').__ne__(''), bool))
    # Assert that AnsibleVaultEncryptedUnicode.__ne__() returns <type 'bool'>

# Generated at 2022-06-25 04:49:05.025319
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = None
    if not(ansible_vault_encrypted_unicode_0 == None):
        raise AssertionError("test_AnsibleVaultEncryptedUnicode___eq__: failed")


# Generated at 2022-06-25 04:49:10.358674
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_0 = {}
    obj = AnsibleVaultEncryptedUnicode(dict_0)
    obj.data = dict_0
    obj.vault = 'AnsibleVaultEncryptedUnicode'
    var_0 = obj.__eq__('AnsibleVaultEncryptedUnicode')
    var = var_0
    assert var == False, "Return value is {}".format(var)


# Generated at 2022-06-25 04:49:20.896553
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # test_is_encrypted_0
    # Arrange
    secret = 'test'
    plaintext = 'test'
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(secret)
    ciphertext = vault.encrypt(plaintext)
    encrypted_test = AnsibleVaultEncryptedUnicode(ciphertext)
    encrypted_test.vault = vault
    # Act
    expected = True
    actual = encrypted_test.is_encrypted()
    # Assert
    assert expected == actual, 'actual: {0}, expected: {1}'.format(actual, expected)

    # test_is_encrypted_1
    # Arrange
    secret = 'test'
    plaintext = 'test'
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-25 04:49:27.946436
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    import random
    import time
    try:
        import ansible.parsing.vault
        vault_lib_available = True
    except ImportError:
        vault_lib_available = False
    # init
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    # assert
    if vault_lib_available:
        import ansible.parsing.vault
        ansible_vault_encrypted_unicode_0.vault = ansible.parsing.vault.VaultLib()
        secret = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(32)])
        ansible_vault_encrypted_unicode_0.vault.password = secret


# Generated at 2022-06-25 04:49:32.758459
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert not (ansible_vault_encrypted_unicode_0 == dict_0)


# Generated at 2022-06-25 04:49:36.634184
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_1 = {}
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(dict_1)
    assert ansible_vault_encrypted_unicode_1.is_encrypted() == False


# Generated at 2022-06-25 04:49:46.159895
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(dict_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)
    bool_1 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)
    bool_2 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)

# Generated at 2022-06-25 04:49:54.529413
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()

    try:
        ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    except IOError as exception_0:
        return True
    else:
        raise exception_0

# Generated at 2022-06-25 04:49:57.901426
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert ansible_vault_encrypted_unicode_0.__eq__(ciphertext) == False


# Generated at 2022-06-25 04:50:10.796912
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_0.__ne__(dict_0)


# Generated at 2022-06-25 04:50:13.381349
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    other = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_0)
    other = None
    test_case_0()


# Generated at 2022-06-25 04:50:19.654165
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    exception_0 = Exception()
    assert ansible_vault_encrypted_unicode_0.__ne__(exception_0)


# Generated at 2022-06-25 04:50:24.661794
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_0.__ne__(None)


# Generated at 2022-06-25 04:50:30.187494
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    test_dict = {}
    test_ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(test_dict)
    actual = test_ansible_vault_encrypted_unicode.is_encrypted()
    desired = False
    assert actual == desired


# Generated at 2022-06-25 04:50:37.615685
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = "0.nvT*8}h~F"
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = ".Xd{`MF-L"
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1) == True


# Generated at 2022-06-25 04:50:45.981380
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_0.data = "foobar"

    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_1.data = "foobar"

    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1) == False


# Generated at 2022-06-25 04:50:51.858100
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # should return False when self.vault set and other != self.data
    yaml_object_0 = AnsibleVaultEncryptedUnicode(u'my_encrypted_stuff')
    assert yaml_object_0.__eq__('passed value') == False


# Generated at 2022-06-25 04:50:56.800745
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode('') != ''

#def test_AnsibleVaultEncryptedUnicode___ne__():
#    assert AnsibleVaultEncryptedUnicode('') != u''

#def test_AnsibleVaultEncryptedUnicode___ne__():
#    assert AnsibleVaultEncryptedUnicode('').__ne__('') == False


# Generated at 2022-06-25 04:51:04.543755
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    dict_0 = {}
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(dict_0)
    if ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1:
        return
    else:
        raise AssertionError()



# Generated at 2022-06-25 04:51:22.138956
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert ansible_vault_encrypted_unicode_0.__ne__(1)


# Generated at 2022-06-25 04:51:27.394232
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:34.713831
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert (type(ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)) is bool)
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:51:37.671425
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    assert ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:46.394184
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:51:50.495932
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    # Exception raised when calling is_encrypted
    with pytest.raises(RuntimeError) as exec_info:
        ansible_vault_encrypted_unicode_0.is_encrypted()
    assert 'RuntimeError' in str(exec_info)


# Generated at 2022-06-25 04:51:54.521531
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_0.vault = None  # This is needed for non-crashing in the call to is_encrypted
    ansible_vault_encrypted_unicode_0.data =  b"asdf"
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:52:02.401681
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    # test case 0
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    try:
        ansible_vault_encrypted_unicode_0.__eq__()
    except Exception as exception:
        if type(exception) == TypeError:
            print('TypeError')
        else:
            print('Exception')


# Generated at 2022-06-25 04:52:10.001489
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    str_0 = 'text'
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(str_0)
    assert bool_0


# Generated at 2022-06-25 04:52:14.276372
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    dict_0 = {}
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(dict_0)
    ansible_vault_encrypted_unicode_0.data
    try:
        ansible_vault_encrypted_unicode_0.is_encrypted()
    except Exception as exception:
        assert str(exception) == 'AssertionError(\'ansible_vault_encrypted_unicode_0.vault is None\')'
