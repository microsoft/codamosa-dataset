

# Generated at 2022-06-25 04:42:50.803964
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    str_0 = '>\x9b\xd7\xce#\xf7\x16\xe2\x86\x827\x9dk\x16\x9d\x10\x84\x08\xcf'
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(str_0)
    assert bool_0

# Generated at 2022-06-25 04:42:55.850776
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    # Initialization

    # Test
    # AssertionError
    try:
        test_case_0()
    except AssertionError as e:
        print(e)

if __name__ == '__main__':
    test_AnsibleVaultEncryptedUnicode_find()

# Generated at 2022-06-25 04:43:02.507051
# Unit test for method find of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:43:06.933079
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    assert ansible_vault_encrypted_unicode_0 != '\x04\x01\x00\x00'


# Generated at 2022-06-25 04:43:10.050238
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert AnsibleVaultEncryptedUnicode.__ne__('string_1', AnsibleVaultEncryptedUnicode.__init__())


# Generated at 2022-06-25 04:43:14.068691
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    assert not ansible_vault_encrypted_unicode_0.__eq__('\xc6\x92')


# Generated at 2022-06-25 04:43:21.673493
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bytes_0 = b'\x00\x00\x00\x00'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bytes_0)
    ansible_vault_encrypted_unicode_1.vault = None
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:43:25.334211
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    b = b'\n\n\n\n\n\n\n\n\n\n\n\n\n\n'
    aveu0 = AnsibleVaultEncryptedUnicode(b)
    aveu1 = aveu0.__getslice__(1, 3)
    assert(aveu1._ciphertext == b'\n\n')


# Generated at 2022-06-25 04:43:32.526139
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bytes_0 = b'\xd0\xf4\x03'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    str_0 = '0.Rf{'
    assert (ansible_vault_encrypted_unicode_0 == str_0) == False


# Generated at 2022-06-25 04:43:34.993581
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    assert ansible_vault_encrypted_unicode_0.find(bytes_0) == 0


# Generated at 2022-06-25 04:43:49.333287
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ciphertext_0 = 'i\x0f\x1d\x0b\x05\x1b\x0b\x0b\x05\x1b\x07\x0b\x0f\x16'
    avu_0 = AnsibleVaultEncryptedUnicode(ciphertext_0)
    assert avu_0.is_encrypted()


# Generated at 2022-06-25 04:43:52.651056
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert not ansible_vault_encrypted_unicode_0.__eq__(str_0)


# Generated at 2022-06-25 04:43:59.535413
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    """
    Test method __ne__ of class AnsibleVaultEncryptedUnicode
    """

    str_0 = 'string_0'
    str_1 = 'string_1'
    str_2 = 'string_2'
    str_3 = 'string_3'

    avu_0 = AnsibleVaultEncryptedUnicode(str_0)
    avu_1 = AnsibleVaultEncryptedUnicode(str_1)
    avu_2 = AnsibleVaultEncryptedUnicode(str_2)
    avu_3 = AnsibleVaultEncryptedUnicode(str_3)
    #
    # Test __ne__ when str_0 != str_1
    #
    assert(avu_0 != avu_1)
    #
    # Test __ne__ when str_

# Generated at 2022-06-25 04:44:04.128270
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'string_1'
    str_1 = 'string_2'
    assert not str_0 != str_1



# Generated at 2022-06-25 04:44:10.915266
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Initialization and setup of variables
    str_1 = 'string_1'
    obj_1 = AnsibleVaultEncryptedUnicode(str_1)

    # Testing
    assert not obj_1.__ne__(str_1)


# Generated at 2022-06-25 04:44:20.688530
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'string_1'
    str_1 = 'string_2'
    avu_0 = AnsibleVaultEncryptedUnicode(str_0)
    avu_1 = AnsibleVaultEncryptedUnicode(str_0)
    avu_2 = AnsibleVaultEncryptedUnicode(str_1)
    assert avu_0 != avu_1
    assert avu_0 != avu_2
    assert avu_1 != avu_2


# Generated at 2022-06-25 04:44:24.595985
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = AnsibleVaultEncryptedUnicode.from_plaintext('string_1')
    # (assertion 15
    check_obj_15 = str_0 != 'string_1'
    assert check_obj_15
    # (assertion 16
    check_obj_16 = str_0 != AnsibleVaultEncryptedUnicode.from_plaintext('string_1')
    assert check_obj_16


# Generated at 2022-06-25 04:44:32.181184
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'string_1'
    str_1 = 'string_2'
    str_2 = 'string_2'
    avu_0 = AnsibleVaultEncryptedUnicode.from_plaintext(str_0, vault=None, secret=None)
    avu_1 = AnsibleVaultEncryptedUnicode.from_plaintext(str_1, vault=None, secret=None)
    bool_0 = avu_0.__eq__(str_1)
    bool_1 = avu_1.__eq__(str_2)


# Generated at 2022-06-25 04:44:37.176343
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'string_1'
    str_1 = 'string_1'
    x = AnsibleVaultEncryptedUnicode(str_0)
    x.vault = None
    assert x == str_1



# Generated at 2022-06-25 04:44:39.071613
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    obj_0 = AnsibleVaultEncryptedUnicode('string_1')
    assert (obj_0 != 'string_1')


# Generated at 2022-06-25 04:44:46.817038
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.vault import VaultLib
    vault = VaultLib(password='password')
    # Test for method __ne__
    avu_1 = AnsibleVaultEncryptedUnicode.from_plaintext('string', vault, 'secret')
    avu_2 = AnsibleVaultEncryptedUnicode.from_plaintext('string_1', vault, 'secret')
    assert (avu_1 != avu_2)


# Generated at 2022-06-25 04:44:48.904367
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'drpepper'
    avu_0 = AnsibleVaultEncryptedUnicode.from_plaintext(str_0, None, 'drpepper')
    assert avu_0.__ne__('drpepper')


# Generated at 2022-06-25 04:44:56.260921
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'string_1'
    ansible_vault_encrypted_unicode_0 = ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0 == str_0
    print('%s' % bool_0)
    assert bool_0 == True


# Generated at 2022-06-25 04:44:59.513773
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'string_1'
    avu_0 = AnsibleVaultEncryptedUnicode.from_plaintext(str_0)
    try:
        assert avu_0.__eq__(str_0)
    except AssertionError as ae:
        if not ae.__str__() == 'False':
            raise ae
    assert (avu_0 == str_0)


# Generated at 2022-06-25 04:45:07.604535
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'string_0'
    str_1 = 'string_1'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('string_0')
    ansible_vault_encrypted_unicode_0.data = 'string_1'
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('string_1')
    ansible_vault_encrypted_unicode_1.data = 'string_1'
    ansible_vault_encrypted_unicode_1.vault = None
    assert ansible_vault_encrypted_unicode_0.__ne__(str_0)
    assert ansible_vault_encrypted_unicode_

# Generated at 2022-06-25 04:45:09.982030
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'string_0'
    avu_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert avu_0.__eq__(str_0) == False


# Generated at 2022-06-25 04:45:17.396157
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('string_1')
    assert ansible_vault_encrypted_unicode.__ne__() == NotImplemented
    test_case_0()


# Generated at 2022-06-25 04:45:27.187536
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_1 = 'string_1'
    str_2 = 'string_2'
    str_3 = 'string_1'
    # Initialise
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_1)
    # Normal case
    assert ansible_vault_encrypted_unicode_0.__ne__(str_2)
    # Normal case
    assert not ansible_vault_encrypted_unicode_0.__ne__(str_3)
    # Normal case
    assert not ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_0)
    # Normal case
    assert not ansible_vault_encrypted_unicode_0.__ne__(str_1)

# Unit test

# Generated at 2022-06-25 04:45:32.320779
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:45:38.378109
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a valid input
    str_0 = AnsibleVaultEncryptedUnicode('abc')
    str_1 = AnsibleVaultEncryptedUnicode('abc')
    assert str_0 == str_1



# Generated at 2022-06-25 04:45:46.657504
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'string_1'
    # Test for __ne__ method of class AnsibleVaultEncryptedUnicode

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.data = str_0

    # AssertionError:
    assert ansible_vault_encrypted_unicode_0 != str_0


# Generated at 2022-06-25 04:45:49.488744
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'test string'
    str_1 = 'test string'
    object_0 = AnsibleVaultEncryptedUnicode(str_0)
    object_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert (object_0 != object_1) == False


# Generated at 2022-06-25 04:45:55.007525
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    import ansible.parsing.vault
    import ansible.parsing.vault
    str_0 = 'string_1'
    vault_0 = ansible.parsing.vault.VaultLib()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = ansible.parsing.vault.VaultLib()
    ansible_vault_encrypted_unicode_0.vault.decrypt(str_0)
    assert ansible_vault_encrypted_unicode_0.__ne__(str_0) == False



# Generated at 2022-06-25 04:46:00.071131
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'string_1'
    avu = AnsibleVaultEncryptedUnicode(str_0)
    lpd = avu.data
    if lpd != str_0:
        raise AssertionError('AnsibleVaultEncryptedUnicode.__eq__(self, object)')


# Generated at 2022-06-25 04:46:02.357479
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_1 = 'string_2'
    x = str_1
    y = AnsibleVaultEncryptedUnicode(str_0)
    assert x == y


# Generated at 2022-06-25 04:46:07.341416
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    # Call function __eq__ with parameters:
    # 'string_1'
    try:
        if AnsibleVaultEncryptedUnicode.__eq__(str_0) ==  True:
            ok_count += 1
    except Exception as e:
        error_count += 1
        print(e)
    return ansible.module_utils.basic.AnsibleModule(argument_spec= dict(), supports_check_mode=False)

if __name__ == '__main__':
  main()
  main()

# Generated at 2022-06-25 04:46:13.118394
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'string_1'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    try:
        ansible_vault_encrypted_unicode_0.__ne__(str_0)
    except UnboundLocalError as e:
        print(e)


# Generated at 2022-06-25 04:46:14.212700
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    test_case_0()



# Generated at 2022-06-25 04:46:17.683169
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu2 = AnsibleVaultEncryptedUnicode('something')
    str_0 = AnsibleVaultEncryptedUnicode('different')
    avu2.vault = None
    assert_success(False, avu2.__ne__, str_0)


# Generated at 2022-06-25 04:46:19.108475
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    test_case_0()
    str_0 = 'string_1'
    str_0 = 'string_1'

    return str_0


# Generated at 2022-06-25 04:46:27.166248
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = AnsibleVaultEncryptedUnicode()
    str_1 = AnsibleVaultEncryptedUnicode()
    str_0.data = 'string_1'
    str_1.data = 'string_2'
    str_1.__ne__(str_0)
    str_1.__ne__('string_1')


# Generated at 2022-06-25 04:46:34.588156
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.vars.unsafe_proxy import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vault.vault import VaultLib
    from tests.unit.vars.unsafe_proxy.test_AnsibleVaultEncryptedUnicode import test_AnsibleVaultEncryptedUnicode___ne__

    # str_0 = 'string_1'
    # str_1 = 'string_2'
    # str_2 = 'string_3'
    # str_3 = 'string_4'
    # str_4 = 'string_5'
    # str_5 = 'string_6'
    # str_6 = 'string_7'
    # str_7 = 'string_8'

# Generated at 2022-06-25 04:46:36.289094
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    example = AnsibleVaultEncryptedUnicode(str_0)
    res = example.is_encrypted()
    assert res == None


# Generated at 2022-06-25 04:46:40.567176
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    av = AnsibleVaultEncryptedUnicode.from_plaintext('string_1', vault, secret)
    assert av.is_encrypted() == True, "AnsibleVaultEncryptedUnicode.is_encrypted failed."


# Generated at 2022-06-25 04:46:50.546368
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'string_1'
    str_1 = 'string_1'
    ansiblevault_encryptedunicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext(str_0, vault_0, str_1)
    ansiblevault_encryptedunicode_0.vault = vault_0
    ansiblevault_encryptedunicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert ansiblevault_encryptedunicode_0.__ne__(str_1) == False
    assert ansiblevault_encryptedunicode_1.__ne__(str_1) == False
    assert ansiblevault_encryptedunicode_1.__ne__(str_0) == True


# Generated at 2022-06-25 04:46:57.016324
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = AnsibleVaultEncryptedUnicode('string')
    str_1 = 'string'
    ret = str_0 == str_1
    str_2 = 'string'
    ret = str_0 == str_2
    str_3 = 'string_0'
    ret = str_0 == str_3


# Generated at 2022-06-25 04:46:59.869299
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'abc_1'
    arr_0 = AnsibleVaultEncryptedUnicode.from_plaintext(str_0)
    assert(arr_0.is_encrypted())


# Generated at 2022-06-25 04:47:06.231841
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = 'string_01'
    str_1 = 'string_02'
    str_2 = 'string_03'
    str_3 = 'string_04'
    str_4 = 'string_05'
    int_0 = 1
    int_1 = 2
    int_2 = 3
    int_3 = 4
    int_4 = 5
    float_0 = 1.1
    float_1 = 2.2
    float_2 = 3.3
    float_3 = 4.4
    float_4 = 5.5
    bool_0 = True
    bool_1 = False
    bool_2 = False
    bool_3 = True
    bool_4 = True
    bool_5 = True
    AnsibleVaultEncryptedUnicode_0 = AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:47:09.046876
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'string_0'


# Generated at 2022-06-25 04:47:17.890195
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    #fixture
    str_0 = 'string_1'
    avu_0 = AnsibleVaultEncryptedUnicode.from_plaintext(str_0, None, None)
    str_1 = 'string_1'
    avu_1 = AnsibleVaultEncryptedUnicode.from_plaintext(str_1, None, None)
    str_2 = 'string_2'
    avu_2 = AnsibleVaultEncryptedUnicode.from_plaintext(str_2, None, None)
    #test
    assert (avu_0 == avu_0)
    assert (avu_0 == avu_1)
    assert (avu_1 == avu_0)
    assert (avu_0 != avu_2)

# Generated at 2022-06-25 04:47:27.875694
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    assert (ansible_vault_encrypted_unicode_0 != b'\x01' )


# Generated at 2022-06-25 04:47:32.417882
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bytes_0 = b'\x01\x07\xba'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    string_0 = 'a'
    assert ansible_vault_encrypted_unicode_0.__ne__(string_0)


# Generated at 2022-06-25 04:47:35.126002
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode.__eq__(AnsibleVaultEncryptedUnicode(''), '') == (None is not None)


# Generated at 2022-06-25 04:47:43.653044
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.vault import VaultLib
    if not _sys.version_info[0] == 2:
        raise AssertionError('This test is only useful on PY2')
    vault = VaultLib([])

# Generated at 2022-06-25 04:47:45.843539
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    # No test needed, this is the same as __eq__ but with the opposite
    # comparison
    pass


# Generated at 2022-06-25 04:47:51.932551
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bytes_0 = b'\xf0\x80\x81\xb6'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    str_0 = u'\u00a9\ufb00\u2000\u05d0\u0500\ue01f\u01f1'
    assert ansible_vault_encrypted_unicode_0.__eq__(str_0)


# Generated at 2022-06-25 04:47:56.331134
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    assert ansible_vault_encrypted_unicode_0.is_encrypted() is False


# Generated at 2022-06-25 04:48:04.700097
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    str_0 = ansible_vault_encrypted_unicode_0.__ne__('W\x1f\xc4')
    assert str_0 is True


# Generated at 2022-06-25 04:48:10.991955
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bytes_0 = b'\xab'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bytes_0)
    test_bytes = b'\xab'
    try:
        __result = ansible_vault_encrypted_unicode_1.__eq__(test_bytes)

    #unicode.__eq__ is not implemented
    except:
        __result = False

    return __result


# Generated at 2022-06-25 04:48:18.668987
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)

    try:
        ansible_vault_encrypted_unicode_0.is_encrypted()
    except Exception as e:
        assert False, "Unexpected Exception raised: {}".format(e)


# Generated at 2022-06-25 04:48:30.639072
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bytes_0 = b'\x96\xce'
    bytes_1 = b'\x9c\xcf'
    bytes_2 = b'\x97\x8e'
    bytes_3 = b'\x9c\xce'
    bytes_4 = b'\x1c\xe2'
    bytes_5 = b'\xdc\xac'
    bytes_6 = b'\x8c\x98'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    ansible_vault_encrypted_unicode_0.vault = MockVaultLib(bytes_1, bytes_2, bytes_3, bytes_4, bytes_5, bytes_6)
    ansible_vault_encrypted_unicode_1

# Generated at 2022-06-25 04:48:39.822206
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    bytes_1 = b'\x99\xd0'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bytes_1)
    try:
        assert(ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1)
        raise AssertionError('AssertionError expected')
    except AssertionError:
        pass


# Generated at 2022-06-25 04:48:46.313670
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Data from test_case_0
    data = {
        'bytes_0': b'\xb4\xa8',
        'ansible_vault_encrypted_unicode_0': AnsibleVaultEncryptedUnicode(b'\xb4\xa8')
    }
    bytes_0 = data['bytes_0']
    ansible_vault_encrypted_unicode_0 = data['ansible_vault_encrypted_unicode_0']

    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:48:48.341332
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with a nonexistent class
    nonexistent_class = AnsibleVaultEncryptedUnicode(b'\xab\xff\xec')
    nonexistent_class.__ne__('a')



# Generated at 2022-06-25 04:48:56.811248
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    str_0 = 'K\x0c\x85\xcc\xae\x1b\x96=\xb4f\xe4)\x0e\x8b\x1a\xdd\x9f\x8c\xcd\xe5'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    assert result_0 is None, "Expected result to be None, but got %s" % result_0


# Generated at 2022-06-25 04:49:00.538130
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    assert not isinstance(ansible_vault_encrypted_unicode_0, object)
    assert not isinstance(ansible_vault_encrypted_unicode_0, str)
    assert ansible_vault_encrypted_unicode_0.__ne__('')


# Generated at 2022-06-25 04:49:02.168649
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    pass


# Generated at 2022-06-25 04:49:09.957700
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('\x01\x00\x00\x00\x01\x00\x00\x00\x01')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('\x01\x00\x00\x00\x01\x00\x00\x00\x01')
    bool_0 = ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
    assert bool_0


# Generated at 2022-06-25 04:49:16.341678
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    str_0 = str(ansible_vault_encrypted_unicode_0)
    assert ansible_vault_encrypted_unicode_0 != str_0



# Generated at 2022-06-25 04:49:22.515043
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(bytes_0)
    assert bool_0 is True


# Generated at 2022-06-25 04:49:38.921909
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bytes_0 = b'\x99\xf4\xcb\x97\x9b\xa3'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    assert not ansible_vault_encrypted_unicode_0.__eq__(b"\xdb\xd9\xeb$\x8b\x93"), "Failed to find expected result for call AnsibleVaultEncryptedUnicode.__eq__(b\"\\xdb\\xd9\\xeb$\\x8b\\x93\")"
    bytes_1 = b'\x92\x8c\xa2\xd2\x90\xee'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bytes_1)

# Generated at 2022-06-25 04:49:45.442520
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    obj_0 = ansible_vault_encrypted_unicode_0
    ansible_vault_encrypted_unicode_0 = obj_0

# Generated at 2022-06-25 04:49:53.799032
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bytes_0 = b'\x9d\x14'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    bytes_1 = b'\x06\x90\x88\x8b\x7f\xec\x15'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bytes_1)
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)
    assert ansible_vault_encrypted_unicode_0.__ne__('\xc8\xb5\x9a\x94\x98\x84\x04')
    assert ansible_vault_encrypted_unicode_0.__ne

# Generated at 2022-06-25 04:49:56.074490
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    result = AnsibleVaultEncryptedUnicode.is_encrypted(ansible_vault_encrypted_unicode_0)



# Generated at 2022-06-25 04:49:58.869791
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 04:50:06.962882
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:50:17.177242
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    # N.B., '==' is for reference equality
    assert not (ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(b"\xce\x98\xce\xbb")
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
    # N.B., str(x) != x (str(x) == x.data), etc.
    assert ansible_vault_encrypted_unicode_0 != bytes_

# Generated at 2022-06-25 04:50:21.066533
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Nothing to test
    pass


# Generated at 2022-06-25 04:50:24.627723
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():

    # Assert that method AnsibleVaultEncryptedUnicode.is_encrypted
    # is called.
    assert ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:50:35.223401
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bytes_0 = b'\xbf'
    # Value to use with AnsibleVaultEncryptedUnicode.__eq__
    arg_0 = b'\x01'
    # Call the method
    arg_0 = to_bytes(arg_0, errors='surrogate_or_strict')
    # Create an instance of AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    # Call the method with arguments
    ansible_vault_encrypted_unicode_0.__eq__(arg_0)


# Generated at 2022-06-25 04:50:44.510003
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    try:
        bytes_0 = b'\xb4\xa8'
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    except (NameError, AssertionError):
        return
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:50:46.249242
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    pass


# Generated at 2022-06-25 04:50:52.096215
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bytes_0 = b'\xd1'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:50:57.679557
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    str_0 = '\xb4\xa8'
    assert ansible_vault_encrypted_unicode_0 == str_0
    str_1 = '\xb4\xa8'
    assert ansible_vault_encrypted_unicode_0 == str_1
    str_2 = '\xb4\xa8'
    assert ansible_vault_encrypted_unicode_0 == str_2


# Generated at 2022-06-25 04:51:07.244707
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Tests for the AnsibleVaultEncryptedUnicode class
    cipher_text = b'\xb4\xa8'  # In utf-8 here is 1 char, not 2 bytes
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(cipher_text)
    # Call the instance method __eq__ with a good instance of parameter
    assert ansible_vault_encrypted_unicode_0.__eq__('test') is False

    # Call the instance method __eq__ with an instance of the wrong type
    try:
        ansible_vault_encrypted_unicode_0.__eq__(3)
    except Exception as e:
        assert isinstance(e, AttributeError)


# Generated at 2022-06-25 04:51:13.300358
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bytes_0 = b'\x0e\x0c'
    bytes_1 = b'\xfe\xec\xdd\xb7'
    bytes_2 = b'\xfc\xa4\xbb\x95'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bytes_1)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(bytes_2)
    assert ansible_vault_encrypted_unicode_2.__ne__(ansible_vault_encrypted_unicode_1) == False
    assert ansible_vault_encrypted_unicode_1.__ne__

# Generated at 2022-06-25 04:51:25.290611
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bytes_0 = b'\xff'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    ansible_vault_encrypted_unicode_0.ansible_pos = (
        'vH'
    )
    bytes_1 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bytes_1)
    ansible_vault_encrypted_unicode_1.ansible_pos = (
        'vH'
    )
    ansible_vault_encrypted_unicode_1.vault = ansible_vault_encrypted_unicode_0.vault
    ansible_vault_encrypted_unicode_0.vault = ansible_vault

# Generated at 2022-06-25 04:51:35.640211
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bytes_0 = b'\xef\xf0\x79\x83\xbd\xea'
    bytes_1 = b'\x04\x8d\xec\x02\x56\x4c'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bytes_1)
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1) == False


# Generated at 2022-06-25 04:51:39.511502
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bytes_0 = b'\xc0\xf6\xbe\xfe\xed\xc6\xca'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    boolean_0 = ansible_vault_encrypted_unicode_0.__eq__(b'\xce\xcf')
    assert boolean_0


# Generated at 2022-06-25 04:51:44.792642
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    bytes_0 = [202, 128, 128]
    bytes_1 = [2, 3, 36, 0, 0]
    # args = [(bytes_0, b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'), (bytes_1, b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')]

# Generated at 2022-06-25 04:51:53.208993
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bytes_0 = b'\xb4\xa8'
    bytes_1 = b'\xc4\x9a\x8a\xce'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(bytes_1)
    assert not ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:51:59.637882
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    bytes_0 = b'\xb4\xa8'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:52:04.539343
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(b'\xb4\xa8')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(b'\xb4\xa8')
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1) == True


# Generated at 2022-06-25 04:52:13.161014
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from yaml.constructor import Constructor
    from ansible import errors
    from ansible.parsing.vault import VaultLib
    constructor = Constructor()
    bytes_0 = b'\xda\xcc\xee\xf6\xd8\xde\xe3\xc6'
    to_native(bytes_0, errors='surrogate_or_strict')
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    vault_lib_0 = VaultLib('\n')
    ansible_vault_encrypted_unicode_0.vault = vault_lib_0
    try:
        assert ansible_vault_encrypted_unicode_0.__ne__(0)
    except:
        ansible_vault_encrypted_

# Generated at 2022-06-25 04:52:19.386188
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    args = []
    # No exception raised
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(b'\xb4\xa8')
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:52:23.646493
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    bytes_0 = yaml.load(
        '\n'
        '---\n'
        '0\n',
        Loader=yaml.SafeLoader)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    int_0 = ansible_vault_encrypted_unicode_0.__ne__(0.0)
