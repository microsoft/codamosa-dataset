

# Generated at 2022-06-25 04:42:40.054710
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    test_ansible_unicode = 'test_ansible_unicode string'
    ansible_vault_encrypted_unicode_find_0 = ansible_vault_encrypted_unicode_0.find(test_ansible_unicode)

# Generated at 2022-06-25 04:42:46.200427
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    ciphertext = to_bytes("AES256:Xs/sZ/1g7Vq3WtLH7VfHIolgw1YKc1I0u8dFCzP2azg=")
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    string = "plaintext"
    avu.vault = vault_impl
    result = avu.__gt__(string)
    assert result == True


if __name__ == '__main__':
    test_case_0()
    test_AnsibleVaultEncryptedUnicode___gt__()

# Generated at 2022-06-25 04:42:56.910338
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:42:58.827615
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    avue = AnsibleVaultEncryptedUnicode(None)
    avue.find(None, None, None)
    return


# Generated at 2022-06-25 04:43:01.832348
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    avueu_0 = AnsibleVaultEncryptedUnicode()
    result = avueu_0.is_encrypted()
    assert(result == False)


# Generated at 2022-06-25 04:43:08.394999
# Unit test for method __contains__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___contains__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()

    # Test normal operation
    try:
        ansible_vault_encrypted_unicode_0.__contains__('test_value')
    except Exception:
        assert False
    # Test expected exceptions
    try:
        ansible_vault_encrypted_unicode_0.__contains__('test_value')
    except Exception:
        assert False


# Generated at 2022-06-25 04:43:12.032847
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('test')
    ansible_vault_encrypted_unicode_0.data = 'test1'
    ansible_vault_encrypted_unicode_0.vault = 'test2'
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False


# Generated at 2022-06-25 04:43:19.454156
# Unit test for method __gt__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___gt__():
    ansible_unicode_0 = AnsibleUnicode('VZ3hqp')
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext('0', 'VZ3hqp', 'VZ3hqp')
    var_0 = ansible_vault_encrypted_unicode_0.__gt__(ansible_unicode_0)
    assert var_0 == False



# Generated at 2022-06-25 04:43:24.645576
# Unit test for method find of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_find():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.data = 'b'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1.data = 'a'
    ansible_vault_encrypted_unicode_0.find(ansible_vault_encrypted_unicode_1.data)


# Generated at 2022-06-25 04:43:37.395974
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("05/I/7mbu8/Nsu2E6S1JEY5j+e/PwD78Y7JUz0=")
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_0._ciphertext = b'05/I/7mbu8/Nsu2E6S1JEY5j+e/PwD78Y7JUz0='
    ansible_vault_encrypted_unicode_0.vault = object

# Generated at 2022-06-25 04:43:54.590339
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(None)
    # Assert if the start is <0, the slice will go to index 0
    assert ansible_vault_encrypted_unicode_0.__getslice__(-1, 0) == to_text(ansible_vault_encrypted_unicode_0[0])
    # Assert if the end is >len(ansible_vault_encrypted_unicode_0), the slice will go to the last index
    assert ansible_vault_encrypted_unicode_0.__getslice__(0, len(ansible_vault_encrypted_unicode_0) + 1) == to_text(ansible_vault_encrypted_unicode_0[-1])


# Generated at 2022-06-25 04:44:03.264628
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # use try except to catch exception and verify that exception is raised
    try:
        # Create the AnsibleVaultEncryptedUnicode object and assert that the value is correct
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext('test', {}, 'password')
        assert ansible_vault_encrypted_unicode_0  == 'test'
    except TypeError as e:
        if 'is not json serializable' in e.message:
            assert False
        else:
            assert False


# Generated at 2022-06-25 04:44:08.366762
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('test_value')
    ansible_vault_encrypted_unicode_0.vault = 'test_value'
    ansible_vault_encrypted_unicode_0.data = 'test_value'
    ansible_vault_encrypted_unicode_0.data = 'test_value'
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == 'test_return'



# Generated at 2022-06-25 04:44:09.940682
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu.__ne__('test')

# Generated at 2022-06-25 04:44:14.842551
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    output = AnsibleVaultEncryptedUnicode('test_ansible_vault_encrypted_unicode')
    output.__getslice__(4, 6)
    output.__getslice__(0, 15)
    output.__getslice__(5, 10)


# Generated at 2022-06-25 04:44:24.588243
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    plaintext = 'abc'
    password = 'ansible'
    secret = 'hello'
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(password)
    ciphertext = vault.encrypt(plaintext)
    avu_0 = AnsibleVaultEncryptedUnicode(ciphertext)
    avu_0.vault = vault
    avu_1 = AnsibleVaultEncryptedUnicode('def')
    try:
        assert plaintext != avu_0
    except AssertionError:
        raise AssertionError('ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode.__ne__ raised AssertionError unexpectedly!')
    try:
        assert avu_0 != plaintext
    except AssertionError:
        raise

# Generated at 2022-06-25 04:44:27.761544
# Unit test for method __getslice__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___getslice__():
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1._ciphertext = to_bytes("all")
    ansible_vault_encrypted_unicode_1.vault = None
    ansible_vault_encrypted_unicode_1.__init__("all")
    assert ansible_vault_encrypted_unicode_1.__getslice__(0, 3) == b"all"


# Generated at 2022-06-25 04:44:35.532473
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_unicode_0 = AnsibleUnicode('20')
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('20')
    ansible_vault_encrypted_unicode_0.vault = ansible_unicode_0
    try:
        assert ansible_vault_encrypted_unicode_0 == '20'
    except AssertionError:
        raise AssertionError('test_AnsibleVaultEncryptedUnicode___eq__ did not pass')


# Generated at 2022-06-25 04:44:38.445311
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    aveu_0 = AnsibleVaultEncryptedUnicode(None)
    aveu_1 = AnsibleVaultEncryptedUnicode(None)

    assert aveu_0 != aveu_1


# Generated at 2022-06-25 04:44:42.002284
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu = AnsibleVaultEncryptedUnicode('test')
    assert avu == 'test'


# Generated at 2022-06-25 04:44:51.456617
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_0 = AnsibleVaultEncryptedUnicode.from_plaintext('test', False, b'test')
    assert isinstance(ansible_vault_0.__ne__, object)
    ansible_vault_1 = AnsibleVaultEncryptedUnicode.from_plaintext('test', False, b'test')
    ansible_vault_0.data = ansible_vault_1.data
    ansible_vault_1.ansible_pos = (None, 0, 0)
    ansible_vault_0.ansible_pos = (None, 0, 0)
    ansible_vault_0.data = 'test'
    assert not ansible_vault_0 == ansible_vault_1
    assert ansible_vault_0 != ansible_v

# Generated at 2022-06-25 04:44:55.980206
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Create an instance of class AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_obj_0 = AnsibleVaultEncryptedUnicode('test_value')
    # Assert test_value of ansible_vault_encrypted_unicode_obj_0 is not equal to test_value_0
    assert ansible_vault_encrypted_unicode_obj_0.data != 'test_value_0'


# Generated at 2022-06-25 04:45:00.047383
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    vault = AnsibleVaultEncryptedUnicode('This is an encrypted vault text')
    if vault.is_encrypted() != False:
        raise AssertionError("expected False, got {0}".format(vault.is_encrypted()))


# Generated at 2022-06-25 04:45:05.136483
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;0.1;AES256;my_password", None).is_encrypted() is True

if __name__ == '__main__':
    test_case_0()
    test_AnsibleVaultEncryptedUnicode_is_encrypted()

# Generated at 2022-06-25 04:45:10.862699
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(u'Hello')
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:45:23.600499
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('this is a plaintext')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('this is a vaulted')
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode('this is a second vaulted')
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_1.vault = ansible_vault_encrypted_unicode_2.vault = None
    sys.stdout.write("Testing method '__eq__' of class 'AnsibleVaultEncryptedUnicode'\n")
    ansible_vault_encrypted_unicode_2 == ansible_v

# Generated at 2022-06-25 04:45:31.295267
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(to_bytes('{"key": "value"}'))
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(to_bytes('{"key": "value"}'))
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1) == True


# Generated at 2022-06-25 04:45:37.100543
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    # TODO
    pass


# Generated at 2022-06-25 04:45:47.040722
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_sequence_0 = AnsibleSequence()
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_sequence_0)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_sequence_0)
    # Verify that the two AnsibleVaultEncryptedUnicode are equal
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_0
    # Verify that the AnsibleVaultEncryptedUnicode and list are equal
    assert ansible_vault_encrypted_unicode_0 == ansible_sequence_0


# Generated at 2022-06-25 04:45:51.216991
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('abc')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('aBc')
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:46:04.577669
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    unresolved = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n353636623561623863313832623138623863366130663165396338396265666632393536313933\n633536663361346634363037393361666233316662373436393765303731353635373538373833\n613961383830643566346431666338626362376431626530643534613034333037626134363032\n373337316366633462653639373066376663636436333236623865636463396134613231633362\n613466343865323630343035')

# Generated at 2022-06-25 04:46:07.033103
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    other = "a"
    ansible_vault_encrypted_unicode_0.vault = other
    ansible_vault_encrypted_unicode_0.__eq__(other)


# Generated at 2022-06-25 04:46:15.088569
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    plaintext_0 = u'The quick brown fox'
    notEncrypted_0 = AnsibleVaultEncryptedUnicode(plaintext_0)
    assert notEncrypted_0.is_encrypted()

    # This is not a valid vault!
    vault_0 = object()
    encrypted_0 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext_0, vault_0, 'password')
    assert encrypted_0.is_encrypted()

    return


# Generated at 2022-06-25 04:46:21.425955
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    seq = 'Hello World!'
    vault = vaultlib.VaultLib('vaultpassword')
    secret = 'secretpassword'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq, vault, secret)
    assert avu == "Hello World!"
    assert avu == AnsibleUnicode("Hello World!")
    assert avu == AnsibleUnicode("Hello World!")
    assert avu == 12



# Generated at 2022-06-25 04:46:26.284659
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('hello')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('hello')
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:46:31.709844
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext('foo', vault=MockVault(False), secret='secret')
    unicode_0 = u'bar'
    assert not (ansible_vault_encrypted_unicode_0 == unicode_0)


# Generated at 2022-06-25 04:46:41.069984
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test for case where vault is None
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(
        "",
    )
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(
        "crypto"
    )
    # Test for case where vault is not None
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(
        "",
    )
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(
        "crypto"
    )


# Generated at 2022-06-25 04:46:51.289657
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('abcdefg')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('abcdefg')
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode('abc')
    ansible_vault_encrypted_unicode_3 = 'abcdefg'


# Generated at 2022-06-25 04:46:59.178611
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 04:47:03.728471
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("")
    var_for_assert = ansible_vault_encrypted_unicode_0.__eq__("")
    try:
        assert var_for_assert
    except AssertionError:
        raise AssertionError("Caught AssertionError while testing __eq__ of AnsibleVaultEncryptedUnicode")


# Generated at 2022-06-25 04:47:13.737415
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    avu = AnsibleVaultEncryptedUnicode(b'hello world!')

    from ansible.parsing.vault import VaultLib
    avu.vault = VaultLib('test')
    avu.vault.password = 'test'
    assert not avu.is_encrypted()


# Generated at 2022-06-25 04:47:18.643600
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    bool_0 = ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
    assert bool_0


# Generated at 2022-06-25 04:47:22.090897
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('')
    assert(ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:47:33.777247
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Create an instance of AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("B\x03\x14\x19\x01\x1e\x1d\r\r\x02\x1e\x19\r")

    # Call method __ne__ with arguments
    #ansible_vault_encrypted_unicode_0.__ne__("H#d\x1e\x19\x13\x02\x0b\x15\x1d\r\x1b\x1d\x1b\x13\x0b\r\r'\x15\r\r\r\r\r\r")


# Generated at 2022-06-25 04:47:38.717043
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(None)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(None)
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 04:47:50.419884
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext('example plaintext', vault, secret)

    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_0)

    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)

    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_0)

    ansible_vault_encrypted_unicode_1.vault = vault

    assert not ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)

# Generated at 2022-06-25 04:47:52.229529
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Create an AnsibleVaultEncryptedUnicode object
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(b'abcdefghijklmopqrstuvwxyz')



# Generated at 2022-06-25 04:48:01.349804
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.vault = ansible_vault_encrypted_unicode_1
    ansible_vault_encrypted_unicode_1.vault = ansible_vault_encrypted_unicode_0
    ansible_vault_encrypted_unicode_2 = ansible_vault_encrypted_unicode_0
    ansible_vault_encrypted_unicode_1 = ansible_vault_encrypted_unicode_0
    ansible_vault_encrypted_unicode_1.vault = ansible_vault_encrypted_unicode_2
    ansible_v

# Generated at 2022-06-25 04:48:07.164899
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Test with a None vault
    avu = AnsibleVaultEncryptedUnicode.from_plaintext('Hello World', None, None)
    assert avu == 'Hello World'


# Generated at 2022-06-25 04:48:17.519769
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.data = b'c29tZV9ieXRlX2NvZGUN'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1.data = b'c29tZV9ieXRlX2NvZGUN'

    return_value = ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1

    return return_value


# Generated at 2022-06-25 04:48:27.463740
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1.vault = ansible_vault_encrypted_unicode_0.vault
    assert not ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:48:33.099061
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()

    result = ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1

    assert not result


# Generated at 2022-06-25 04:48:37.551346
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_0.data = 'abc'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1.data = 'def'

    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:48:40.960331
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avu1 = AnsibleVaultEncryptedUnicode('s3cr3t')
    avu2 = AnsibleVaultEncryptedUnicode('s3cr3t')
    assert avu1 == avu2



# Generated at 2022-06-25 04:48:48.969086
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ciphertext = u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          66633238613835336535343261333131613235363436393163303936633033333264666235326539\n          31323163313962333366613163366137633766396233313935626434383362386531616334636463\n          35386332366464663063353866396230666266666435653339393588a6ccd40c6a3c6d9fe6dcf3e3\n          0d8d1b0c7ff4432e\n          '
    # Instantiate a AnsibleVaultEncryptedUnicode object
    ansible_vault_encrypted_unicode

# Generated at 2022-06-25 04:48:50.730819
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert AnsibleVaultEncryptedUnicode.__eq__([], "ansible_vault")


# Generated at 2022-06-25 04:48:52.559537
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str = AnsibleVaultEncryptedUnicode("test")
    assert str.__ne__("test") == False


# Generated at 2022-06-25 04:48:55.179501
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Raises ValueError exception
    with pytest.raises(ValueError):
        ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext(None, None, None)


# Generated at 2022-06-25 04:49:05.469656
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    plaintext = 'test string'

# Generated at 2022-06-25 04:49:15.956465
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    if len(AnsibleVaultEncryptedUnicode('foo')) == 0:
        print("AnsibleVaultEncryptedUnicode(foo)");

# Generated at 2022-06-25 04:49:27.191313
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('sample string')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('sample string')
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode('sample string')
    assert ansible_vault_encrypted_unicode_0 is not None # placeholder
    assert ansible_vault_encrypted_unicode_1 is not None # placeholder
    assert ansible_vault_encrypted_unicode_2 is not None # placeholder
    # __eq__ of AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_0.data = 'sample string'
    assert ansible_vault_encrypted_unicode_0 == ansible_

# Generated at 2022-06-25 04:49:36.766235
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_1, vault, secret)
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode.from_plaintext(ansible_sequence_0, ansible_vault_encrypted_unicode_0, ansible_vault_encrypted_unicode_1)
    assert not (ansible_vault_encrypted_unicode_1 == ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:49:40.101760
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert False



# Generated at 2022-06-25 04:49:49.427683
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # This is known encrypted vault file
    with open('tests/vault.yml') as f:
        encrypted_data = f.read()
        avu = AnsibleVaultEncryptedUnicode(encrypted_data)
        assert True == avu.is_encrypted()
    # This is known non-encrypted vault file
    with open('tests/vault_plaintext.yml') as f:
        encrypted_data = f.read()
        avu = AnsibleVaultEncryptedUnicode(encrypted_data)
        assert False == avu.is_encrypted()


# Generated at 2022-06-25 04:49:59.859190
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    avueu = AnsibleVaultEncryptedUnicode.from_plaintext('plaintext', None, None)
    avueu._ciphertext = 'this is encrypted'
    avueu.vault = None
    result = avueu.__eq__(None)
    assert result == False

    avueu.vault = None
    result = avueu.__eq__(avueu)
    assert result == False

    avueu.vault = None
    result = avueu.__eq__('plaintext')
    assert result == False

    avueu.vault = None
    result = avueu.__eq__('this is encrypted')
    assert result == False

    avueu.vault = None
    result = avueu.__eq__(u'plaintext')

# Generated at 2022-06-25 04:50:07.502482
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    from ansible.parsing.vault import VaultLib
    testobj1 = AnsibleVaultEncryptedUnicode.from_plaintext(to_bytes('Testing'), VaultLib(), to_bytes('testpass'))
    testobj2 = AnsibleVaultEncryptedUnicode.from_plaintext(to_bytes('Testing'), VaultLib(), to_bytes('testpass'))
    assert testobj1.__ne__(testobj2)


# Generated at 2022-06-25 04:50:12.964945
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Create an instance of AnsibleVaultEncryptedUnicode
    seq = 'my_secret'
    avu = AnsibleVaultEncryptedUnicode.from_plaintext(seq)

    # Verify is_encrypted returns True
    assert(True == avu.is_encrypted())

    # Verify data decrypts properly
    assert(seq == avu.data)


# Generated at 2022-06-25 04:50:17.058167
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    bool_0 = ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
    assert bool_0


# Generated at 2022-06-25 04:50:28.303312
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('', 'YzY5ZjRlZWJhZjI5ZmNjZWM1YWVlMzk0YjVkYjI5ZGE=')
    print(ansible_vault_encrypted_unicode_0 == '')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('', 'YzY5ZjRlZWJhZjI5ZmNjZWM1YWVlMzk0YjVkYjI5ZGE=')
    print(ansible_vault_encrypted_unicode_1 == '')
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUn

# Generated at 2022-06-25 04:50:36.927433
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    sequence_1 = AnsibleSequence()
    sequence_1.append('foo')
    sequence_1.append('bar')
    sequence_1.append('baz')
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(
        ciphertext=''
    )
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(
        ciphertext=''
    )
    assert ansible_vault_encrypted_unicode_0 != sequence_1
    assert ansible_vault_encrypted_unicode_1 != sequence_1



# Generated at 2022-06-25 04:50:45.466628
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # test_case_0
    str_0 = 'q:w-"k2)E6gz52i)'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0 == 'q:w-"k2)E6gz52i)'


# Generated at 2022-06-25 04:50:49.911510
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'G@{w"k2)A(gz52i)'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'q:w-"k2)E6gz52i)'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    result = ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
    assert result is False



# Generated at 2022-06-25 04:50:55.259674
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'q:w-"k2)E6gz52i)'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = None
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert var_0 == True


# Generated at 2022-06-25 04:50:59.057753
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'q:w-"k2)E6gz52i)'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert var_0 == False


# Generated at 2022-06-25 04:51:03.628481
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'q:w-"k2)E6gz52i)'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert(ansible_vault_encrypted_unicode_0.is_encrypted())

# Generated at 2022-06-25 04:51:06.628532
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'Y'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__eq__()


# Generated at 2022-06-25 04:51:14.839494
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'Q=v+?W!!jc8!\\z:*('
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:51:25.490216
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'q:w-"k2)E6gz52i)'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0 == str_0
    str_1 = '1234567890123456789012345678901234567890'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    bool_1 = ansible_vault_encrypted_unicode_1 == str_0
    bool_2 = ansible_vault_encrypted_unicode_1 == str_1
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_0)

# Generated at 2022-06-25 04:51:29.053734
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = '~Q:W-"K2)E6GZ52I)'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    sys.stdout.write("%s\n" % var_0)


# Generated at 2022-06-25 04:51:38.977116
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = '(-5a'
    str_1 = '^\x1b'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_1.vault = None
    var_0 = ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
    var_1 = ansible_vault_encrypted_unicode_1 != ansible_vault_encrypted_unicode_0
    var_2 = ansible_vault_encrypted_unicode_1

# Generated at 2022-06-25 04:51:49.318203
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    # AnsibleVaultEncryptedUnicode.__ne__(None)
    str_0 = 'P;IFpky;g-5D?V7'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne__(None)

    # AnsibleVaultEncryptedUnicode.__ne__('YmBkJ*Fp*Z1xq3`d+')
    str_0 = 'P;IFpky;g-5D?V7'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    var_0 = ansible_vault_encrypted_unicode_0.__ne

# Generated at 2022-06-25 04:51:55.489607
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_obj_0 = AnsibleVaultEncryptedUnicode('q:w-"k2)E6gz52i)')
    ansible_vault_encrypted_unicode_obj_1 = AnsibleVaultEncryptedUnicode('')
    ansible_vault_encrypted_unicode_obj_2 = AnsibleVaultEncryptedUnicode('}Z%dS')
    ansible_vault_encrypted_unicode_obj_3 = AnsibleVaultEncryptedUnicode('NhCx`2&O')
    ansible_vault_encrypted_unicode_obj_4 = AnsibleVaultEncryptedUnicode('x>Qk|')

# Generated at 2022-06-25 04:52:01.445238
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'q:w-"k2)E6gz52i)'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()
    assert True



# Generated at 2022-06-25 04:52:02.919520
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass


# Generated at 2022-06-25 04:52:13.616158
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    source_0 = 'o_6D_4(|4[^-#}'
    source_1 = 'l@S'
    source_2 = 'n@M'
    target_0 = 'a(1:i'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(source_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1.data = source_1
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_2.data = source_2
    bool_0 = ansible_vault_encrypted_unicode_0 == target_0
   

# Generated at 2022-06-25 04:52:21.195715
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
	str_0 = '"g:KX8(7#l,FZ*,lkK'
	ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
	var_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
	assert var_0 == True
