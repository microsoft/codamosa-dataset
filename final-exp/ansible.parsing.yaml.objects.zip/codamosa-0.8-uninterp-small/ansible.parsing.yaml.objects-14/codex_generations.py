

# Generated at 2022-06-25 04:42:48.848503
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(5)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(0)
    ansible_vault_encrypted_unicode_0.data = ansible_vault_encrypted_unicode_1
    print(ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1))



# Generated at 2022-06-25 04:42:53.090519
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    sample_str_0 = 'This is a sample string'
    vault_0 = AnsibleVaultEncryptedUnicode.from_plaintext(sample_str_0)
    assert vault_0.is_encrypted()


# Generated at 2022-06-25 04:42:54.804728
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    plaintext = "Test"
    avu = AnsibleVaultEncryptedUnicode(plaintext)
    avu.__ne__(plaintext)



# Generated at 2022-06-25 04:42:59.100715
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    str_b = to_bytes(u"hello")
    str_u = u"hello"

    avue = AnsibleVaultEncryptedUnicode(str_b)

    if avue == str_u:
        sys.stdout.write(u"0")
    else:
        sys.stdout.write(u"1")


# Generated at 2022-06-25 04:43:07.233521
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('mypassword')
    plaintext = 'foo'
    secret = 'bar'
    ciphertext = vault.encrypt(plaintext, secret, obj=None)
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext, vault, secret)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ciphertext)

    # This line checks the data is decrypted on the fly
    # If the data is pre-decrypted, this will raise an exception
    ansible_vault_encrypted_unicode_0 == plaintext
    ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_0

# Generated at 2022-06-25 04:43:12.783767
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Set up test data
    ciphertext = "SOME_STRING"

    # Run the method under test
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(ciphertext)
    is_encrypted = ansible_vault_encrypted_unicode.is_encrypted()

    # Check the results
    assert is_encrypted == True


# Generated at 2022-06-25 04:43:18.130419
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext('this is a secret string', vault, password)
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 04:43:22.064527
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    # Get a vault
    vault = vaultlib.VaultLib('password')

    # Ensure that an AnsibleVaultEncryptedUnicode is encrypted when it should be
    assert vaulted.is_encrypted()

    # Ensure that an AnsibleVaultEncryptedUnicode is not encrypted when it shoould not be
    assert not vaulted_plain.is_encrypted()

# Generated at 2022-06-25 04:43:24.410242
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # This method does not work, but should be a stub for the real unit test.
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('', '', '', '')
    assert not ansible_vault_encrypted_unicode_0


# Generated at 2022-06-25 04:43:36.325145
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = yaml_object.construct_yaml_object(node=node_0, deep=True)
    string_0 = ansible_vault_encrypted_unicode_0.__ne__(to_text(value=string_0))
    string_1 = ansible_vault_encrypted_unicode_0.__ne__(to_text(value=string_1))
    string_2 = ansible_vault_encrypted_unicode_0.__ne__(to_text(value=string_2))
    string_3 = ansible_vault_encrypted_unicode_0.__ne__(to_text(value=string_3))


# Generated at 2022-06-25 04:43:52.229659
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_mapping_0 = AnsibleMapping()
    try:
        result = ansible_vault_encrypted_unicode_0 != ansible_mapping_0
    except NameError:
        pass
    else:
        assert False

    ansible_unicode_0 = AnsibleUnicode()
    ansible_unicode_1 = AnsibleUnicode()
    ansible_unicode_2 = AnsibleUnicode()
    ansible_unicode_3 = AnsibleUnicode()
    ansible_unicode_1 = ansible_unicode_0
    ansible_unicode_2 = ansible_unicode_0
    ansible_unicode_2 = ansible_unicode_3

# Generated at 2022-06-25 04:43:55.049622
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    x = AnsibleVaultEncryptedUnicode('x')
    # TBD - Bug in ansible, python needs string not AnsibleVaultEncryptedUnicode
    assert x.count() >= 1


# Generated at 2022-06-25 04:43:59.667334
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    avu = AnsibleVaultEncryptedUnicode('aaaaa')
    assert avu.count('a') == 5


# Generated at 2022-06-25 04:44:05.315461
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext('test', None, '')
    assert ansible_vault_encrypted_unicode_0.count('test') == 1


# Generated at 2022-06-25 04:44:16.806152
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    ansible_vault_encrypted_unicode_obj_0 = AnsibleVaultEncryptedUnicode(u'arbitrary')
    ansible_vault_encrypted_unicode_obj_0.data = u'arbitrary'
    bool_retval_0 = ansible_vault_encrypted_unicode_obj_0.__eq__(u'arbitrary')
    assert(bool_retval_0 == True)

    ansible_vault_encrypted_unicode_obj_1 = AnsibleVaultEncryptedUnicode(u'arbitrary')
    ansible_vault_encrypted_unicode_obj_1.data = u'arbitrary'
    bool_retval_1 = ansible_vault_encrypted_unicode_obj_1.__eq__(u'Not arbitrary')

# Generated at 2022-06-25 04:44:19.237460
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert 'is_encrypted' in dir(AnsibleVaultEncryptedUnicode.is_encrypted)


# Generated at 2022-06-25 04:44:28.192748
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("aaaaa")
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode("aaaaa")
    ansible_vault_encrypted_unicode_0.data = ansible_vault_encrypted_unicode_1.data
    ansible_vault_encrypted_unicode_0.data = ansible_vault_encrypted_unicode_1.data
    ansible_vault_encrypted_unicode_0.count(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:44:29.091267
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Testing if true is not equal to false
    test_case_0(False, True)


# Generated at 2022-06-25 04:44:31.767291
# Unit test for method count of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_count():
    seq = 'a'
    sub = 'a'
    start = 0
    end = _sys.maxsize
    assert AnsibleVaultEncryptedUnicode.count(seq, sub, start, end) == 1


# Generated at 2022-06-25 04:44:40.774170
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Create an instance of class AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_instance_0 = AnsibleVaultEncryptedUnicode('c',)
   # Create an instance of class AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_instance_1 = AnsibleVaultEncryptedUnicode('b',)
    # Store result in variable
    result = ansible_vault_encrypted_unicode_instance_0 != ansible_vault_encrypted_unicode_instance_1
    assert result == False


# Generated at 2022-06-25 04:44:48.086846
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    class0 = type(ansible_vault_encrypted_unicode_0)
    # __eq__ should return bool
    eq_retval_1 = class0.__eq__()
    assert(isinstance(eq_retval_1, bool))



# Generated at 2022-06-25 04:44:50.184509
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('A')
    ansible_vault_encrypted_unicode_0.data = 'B'
    assert ansible_vault_encrypted_unicode_0 != 'B'


# Generated at 2022-06-25 04:44:56.088079
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_str_0)
    ansible_vault_encrypted_unicode_0.vault = ansible_vault_0
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:44:57.352276
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert isinstance(test_AnsibleVaultEncryptedUnicode_is_encrypted, object)


# Generated at 2022-06-25 04:45:03.593118
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("")
    ansible_vault_encrypted_unicode_0.data = "foo"
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode("")
    ansible_vault_encrypted_unicode_1.data = "fob"
    assert not ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:45:08.693606
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode("ciphertext1")
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode("ciphertext2")
    ansible_vault_encrypted_unicode_0.vault = AnsibleVaultLib("ciphertext1")
    assert not (ansible_vault_encrypted_unicode_1 == ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:45:11.677847
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():

    # instantiate the object
    avu = AnsibleVaultEncryptedUnicode('test')

    # execute the method
    result = avu.__eq__(None)

    # check the result
    assert result == False



# Generated at 2022-06-25 04:45:17.428061
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    plaintext_0 = 'test string'
    ciphertext_0 = b'$ANSIBLE_VAULT;1.1;AES256\n37303934353166623431633538386162623136303435323965663863386232343266626435336166\n38646630346488717517e'
    vault_0 = 'VaultLib'
    secret_0 = 'test secret'
    avu_0 = AnsibleVaultEncryptedUnicode.from_plaintext(plaintext_0, vault_0, secret_0)
    result_0 = avu_0.__eq__(plaintext_0)
    assert result_0
    assert avu_0.__eq__(b'[') == False


# Generated at 2022-06-25 04:45:25.748702
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    # Test with valid input
    test_AnsibleVaultEncryptedUnicode___ne__.example_data_0 = [
        AnsibleVaultEncryptedUnicode(b'abc')
    ]
    if test_AnsibleVaultEncryptedUnicode___ne__.example_data_0[0].__ne__(test_AnsibleVaultEncryptedUnicode___ne__.example_data_0[0]):
        raise AssertionError()



# Generated at 2022-06-25 04:45:34.228804
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Simple example for testing equality
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode()
    if ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1:
        print('Equal')
    else:
        print('Not equal')


# Generated at 2022-06-25 04:45:46.867195
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('my_password')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('super_secret')
    ansible_vault_encrypted_unicode_1.vault = 'my_vault'
    ansible_vault_encrypted_unicode_0.vault = 'my_vault'
    assert ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:45:52.816137
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Create the object
    
    # This should be an encrypted value and raise an error
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode()

    # Tests should fail at this point
    # Run method __eq__ against no vault
    try:
        ansible_vault_encrypted_unicode_0.__eq__()
        # We should not get here
        raise Exception('AssertionError: Should not get here')
    except AssertionError as e:
        assert to_native(e) == 'ansible_pos can only be set with a tuple/list of three values: source, line number, column number'

    # Create the object
    
    # Create the object
    
    # Create the object
    
    # Create the object
    
    # Create the object
    
   

# Generated at 2022-06-25 04:46:03.432722
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(
        ciphertext=bytes(bytearray(
            [103, 73, 91, 96, 96, 96, 96, 96, 96, 96, 96, 96, 96])))
    assert ansible_vault_encrypted_unicode_0.__ne__(to_text(
        '0', errors='surrogate_or_strict')) is True
    assert ansible_vault_encrypted_unicode_0.__ne__(to_text(
        '2', errors='surrogate_or_strict')) is True
    assert ansible_vault_encrypted_unicode_0.__ne__(to_text(
        '4', errors='surrogate_or_strict')) is True
    assert ans

# Generated at 2022-06-25 04:46:06.025033
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    """
    :avu: Instance of class AnsibleVaultEncryptedUnicode
    :returns: None
    """
    avu = AnsibleVaultEncryptedUnicode('')
    avu.is_encrypted()


# Generated at 2022-06-25 04:46:18.026406
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('')
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('test_value')
    ansible_vault_encrypted_unicode_2 = ansible_vault_encrypted_unicode_1
    ansible_vault_encrypted_unicode_0.data = 'foo'
    ansible_vault_encrypted_unicode_0.vault = None
    ansible_vault_encrypted_unicode_1.data = 'foo'
    ansible_vault_encrypted_unicode_1.vault = None
    ansible_vault_encrypted_unicode_2.data = 'foo'
    ansible_vault_encrypted_unicode_2.vault = None

# Generated at 2022-06-25 04:46:18.561638
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert True

# Generated at 2022-06-25 04:46:21.793787
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    avu = AnsibleVaultEncryptedUnicode(b'ciphertext')
    if avu == None:
        assert True


# Generated at 2022-06-25 04:46:25.345177
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    eq_res = AnsibleVaultEncryptedUnicode(1).__eq__('AnsibleVaultEncryptedUnicode(1)')
    sys.stdout.write("%s\n" % eq_res)


# Generated at 2022-06-25 04:46:29.112416
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib(password='1234')
    ciphertext = vault.encrypt('test_data_here')
    avu = AnsibleVaultEncryptedUnicode(ciphertext)
    avu.vault = vault
    assert avu.is_encrypted()



# Generated at 2022-06-25 04:46:36.900838
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    print("Testing  AnsibleVaultEncryptedUnicode.__ne__")
    # Testing primitive data types
    ansible_mapping = AnsibleMapping()
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('bar')
    ansible_vault_encrypted_unicode.vault = None
    assert(ansible_vault_encrypted_unicode.__ne__('bar') == False)

    ansible_mapping = AnsibleMapping()
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode('bar')
    ansible_vault_encrypted_unicode.vault = None
    assert(ansible_vault_encrypted_unicode.__ne__('foo') == True)



# Generated at 2022-06-25 04:46:46.620792
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    """
    Tests that the is_encrypted method of the AnsibleVaultEncryptedUnicode class returns the proper value.
    """
    str_0 = 'abc123'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()

# Generated at 2022-06-25 04:46:48.972463
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:46:49.716287
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    test_case_0()


# Generated at 2022-06-25 04:46:53.359333
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:46:57.529741
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'a'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'b'
    assert (str_1 != ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:47:04.456473
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'rLN8KxWg'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = None
    bool_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert bool_0 == False
    str_1 = ''
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_1.vault = None
    bool_1 = ansible_vault_encrypted_unicode_1.is_encrypted()
    assert bool_1 == False


# Generated at 2022-06-25 04:47:14.284474
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'n'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = ''
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_1 = ansible_vault_encrypted_unicode_0
    str_2 = ''
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_2)
    ansible_vault_encrypted_unicode_2 = ansible_vault_encrypted_unicode_1
    str_3 = 'h'

# Generated at 2022-06-25 04:47:18.910422
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    assert test_case_0() is None
    assert AnsibleVaultEncryptedUnicode(to_bytes('', errors='surrogate_or_strict')).__eq__(AnsibleVaultEncryptedUnicode(to_bytes('', errors='surrogate_or_strict'))) is True


# Generated at 2022-06-25 04:47:25.979089
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    other_0 = ''
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(other_0)
    ansible_vault_encrypted_unicode_1.eq(ansible_vault_encrypted_unicode_0)


# Generated at 2022-06-25 04:47:33.949764
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.data = str_0
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)

    assert not ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1, 'Failed to assert equal truth for test_AnsibleVaultEncryptedUnicode___ne__'


# Generated at 2022-06-25 04:47:48.581026
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    # Create a new vault object
    vault = VaultLib('SECRET1')
    str_0 = 'test_data'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    # Set the vault attribute to the vault object
    ansible_vault_encrypted_unicode_0.vault = vault
    # Ensure we get false as result as the value is not encrypted
    assert ansible_vault_encrypted_unicode_0.is_encrypted() == False
    # Encrypt the string
    encrypted_string = vault.encrypt(str_0)
    # Create a new AnsibleVaultEncryptedUnicode object with the encrypted string
    ansible_vault_encrypted_unicode_1 = Ansible

# Generated at 2022-06-25 04:47:54.882614
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    str_1 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert not (ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:48:02.665556
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    str_0 = 'test'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.vault = None
    vault_method_call_result_0 = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert not vault_method_call_result_0
    str_1 = 'test'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_1.vault = vault
    vault_method_call_result_1 = ansible_vault_encrypted_

# Generated at 2022-06-25 04:48:05.904962
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    test_case_0()


# Generated at 2022-06-25 04:48:09.731346
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert (ansible_vault_encrypted_unicode_0.is_encrypted() == False)


# Generated at 2022-06-25 04:48:16.835947
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.data != str_0


# Generated at 2022-06-25 04:48:23.305209
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    boolean_0 = ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)
    assert(boolean_0)


# Generated at 2022-06-25 04:48:29.391903
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0 = ansible_vault_encrypted_unicode_0
    try:
        eq = ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_0
    except Exception as e:
        print(e)
        traceback.print_exc()
        print('')
        raise(e)

    assert eq == True


# Generated at 2022-06-25 04:48:32.363631
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    # Checking for False condition
    assert ansible_vault_encrypted_unicode_0.__ne__(str_0) == False


# Generated at 2022-06-25 04:48:39.060873
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    ansible_vault_encrypted_unicode_0 = ''
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_0)
    ansible_vault_encrypted_unicode_2 = ''
    assert ansible_vault_encrypted_unicode_1 != ansible_vault_encrypted_unicode_2


# Generated at 2022-06-25 04:48:47.037895
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # Instance initialization
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    
    # Invoke method
    ret_val_1 = ansible_vault_encrypted_unicode_0.__eq__(str_0)
    return ret_val_1


# Generated at 2022-06-25 04:48:52.045057
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.__ne__()


# Generated at 2022-06-25 04:48:56.820437
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    str_2 = ''
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_2)
    ansible_vault_encrypted_unicode_3 = AnsibleVaultEncryptedUnicode(str_2)
    bool_0 = ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
    bool_1 = ansible_vault_encrypted_unicode_2 != ansible_vault_encrypted_unicode_3
    pass

# Unit test

# Generated at 2022-06-25 04:48:58.129045
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    pass


# Generated at 2022-06-25 04:48:59.572858
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    result = AnsibleVaultEncryptedUnicode.is_encrypted()


# Generated at 2022-06-25 04:49:05.070708
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    result = ansible_vault_encrypted_unicode_0.is_encrypted()
    assert not result


# Generated at 2022-06-25 04:49:15.768194
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.data = str_0
    # Test for the following condition:
    # self.vault and self.vault.is_encrypted(self._ciphertext)
    # The test is known to fail if the condition is True
    ansible_vault_encrypted_unicode_0.vault = str_0
    # After calling class methods and setting variables:
    # self.data = str_0
    # self.vault = str_0
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:49:22.126639
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

    with pytest.raises(UnboundLocalError):
        ansible_vault_encrypted_unicode_0.__ne__(str_0)


# Generated at 2022-06-25 04:49:24.178519
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)


# Generated at 2022-06-25 04:49:32.346965
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = ''
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:49:40.779329
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    if str_0 == 'abc':
        assert True
    else:
        assert False


# Generated at 2022-06-25 04:49:45.241775
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

    # Test for method is_encrypted of class AnsibleVaultEncryptedUnicode
    result = ansible_vault_encrypted_unicode_0.is_encrypted()
    ansible_vault_encrypted_unicode_0.vault = ''
    result = ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:49:48.372044
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_1 = 'e'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_1)
    ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:49:58.325545
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1.vault = AnsibleVaultLib('', '', '', '', '')
    ansible_vault_encrypted_unicode_1.data = ''
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_2.vault = AnsibleVaultLib('', '', '', '', '')
    ansible_vault_encrypted_unicode_2.data = ''
    ansible

# Generated at 2022-06-25 04:50:02.570783
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = 'data'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    # Do something with ansible_vault_encrypted_unicode_0
    ansible_vault_encrypted_unicode_0.is_encrypted()



# Generated at 2022-06-25 04:50:10.132146
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    str_1 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    result_1 = ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1


# Generated at 2022-06-25 04:50:17.064928
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    # 1
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = ''
    assert ansible_vault_encrypted_unicode_0.__eq__(str_1) == False
    str_2 = ''
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_2)
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1) == False


# Generated at 2022-06-25 04:50:20.450918
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    result = ansible_vault_encrypted_unicode_0.__ne__('')


# Generated at 2022-06-25 04:50:22.569737
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0
    #assert ansible_vault_encrypted_unicode_0.__eq__(str_0)


# Generated at 2022-06-25 04:50:29.152307
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.__ne__('')


# Generated at 2022-06-25 04:50:43.572728
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_0 = ''
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1) == True
    str_0 = 'abc'
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_2) == False


# Generated at 2022-06-25 04:50:52.096291
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    assert False # TODO I would like the vault to provide an interface to test this
    str_0 = b''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:00.572905
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
  str_0 = ''
  ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
  ansible_vault_encrypted_unicode_0.is_encrypted()

if __name__ == "__main__":
    import sys

    # When user executes the file directly
    # Arguments from command line not available
    sys.argv = ["__main__", "--verbose"]
    if len(sys.argv) > 1:
        if sys.argv[1] == "--verbose":
            global_verbose_output = True
            sys.argv.pop(1)
        else:
            global_verbose_output = False
    else:
        global_verbose_output = False

    import traceback
    import unittest


# Generated at 2022-06-25 04:51:08.204352
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode('test')
    ansible_vault_encrypted_unicode_2 = AnsibleVaultEncryptedUnicode('test')
    assert not ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)
    assert ansible_vault_encrypted_unicode_1.__eq__(ansible_vault_encrypted_unicode_2)


# Generated at 2022-06-25 04:51:15.853639
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'foo'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'foo'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    bool_0 = ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1)


# Generated at 2022-06-25 04:51:18.915785
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()

# Generated at 2022-06-25 04:51:23.149773
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert (ansible_vault_encrypted_unicode_0 != '')



# Generated at 2022-06-25 04:51:25.771019
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    bool_0 = ansible_vault_encrypted_unicode_0.__ne__(str_0)


# Generated at 2022-06-25 04:51:31.689692
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.__eq__(str_0)


# Generated at 2022-06-25 04:51:35.128946
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert ansible_vault_encrypted_unicode_0.__eq__(str_0)


# Generated at 2022-06-25 04:51:40.971269
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)


# Generated at 2022-06-25 04:51:46.685142
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:51:49.436285
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.__ne__()


# Generated at 2022-06-25 04:51:54.748086
# Unit test for method __ne__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___ne__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode.from_plaintext(str_0, vault, vault_secret)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(ansible_vault_encrypted_unicode_0._ciphertext)
    ansible_vault_encrypted_unicode_0.vault = ansible_vault_encrypted_unicode_1.vault = vault
    ansible_vault_encrypted_unicode_0.__ne__(ansible_vault_encrypted_unicode_1)




# Generated at 2022-06-25 04:51:57.635149
# Unit test for method is_encrypted of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode_is_encrypted():
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert not ansible_vault_encrypted_unicode_0.is_encrypted()


# Generated at 2022-06-25 04:52:01.035034
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)

    # Call method __eq__ of class AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode_0.__eq__()



# Generated at 2022-06-25 04:52:06.264278
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'abc'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    str_1 = 'abc'
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    bool_0 = ansible_vault_encrypted_unicode_0 == ansible_vault_encrypted_unicode_1
    assert bool_0 == True


# Generated at 2022-06-25 04:52:14.028088
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = 'abc'
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_0.data = str_0
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1.data = str_0
    assert ansible_vault_encrypted_unicode_0.__eq__(ansible_vault_encrypted_unicode_1) is True
    assert ansible_vault_encrypted_unicode_1.__eq__(ansible_vault_encrypted_unicode_0) is True


# Generated at 2022-06-25 04:52:22.233658
# Unit test for method __eq__ of class AnsibleVaultEncryptedUnicode
def test_AnsibleVaultEncryptedUnicode___eq__():
    str_0 = ''
    str_1 = ''
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(str_1)
    assert ansible_vault_encrypted_unicode_0 != ansible_vault_encrypted_unicode_1
