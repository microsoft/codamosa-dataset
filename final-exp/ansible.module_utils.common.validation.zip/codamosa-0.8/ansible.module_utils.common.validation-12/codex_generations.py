

# Generated at 2022-06-11 01:40:54.388017
# Unit test for function check_required_together
def test_check_required_together():
    from ansible.module_utils.common.validation import check_required_together

    # Empty case
    parameters = {}
    terms = []
    assert check_required_together(terms, parameters) == []

    # Required together ok
    terms = [('a', 'b')]
    parameters = {'a': True, 'b': True}
    assert check_required_together(terms, parameters) == []

    # Required together not ok
    terms = [('a', 'b')]
    parameters = {'a': True, 'c': False}
    assert check_required_together(terms, parameters) != []

    # Non required together ok
    terms = [('a', 'b')]
    parameters = {'a': True, 'b': False}
    assert check_required_together(terms, parameters) == []

    # Required

# Generated at 2022-06-11 01:41:06.432861
# Unit test for function check_required_if
def test_check_required_if():
    # a function to test check_required_if
    def test_check_required_if_run(requirements, parameters, options_context=None, exception_expected=False):
        # run check_required_if to test
        try:
            check_required_if(requirements, parameters, options_context=options_context)
            if exception_expected:
                assert False
        except Exception as e:
            if not exception_expected:
                assert False

    # check no exception thrown when no requirements and no parameters
    test_check_required_if_run(requirements=None, parameters={}, options_context=None, exception_expected=False)

    # check exception thrown when parameter key not found in parameters

# Generated at 2022-06-11 01:41:13.835072
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = dict(
        arg1={'required': True},
        arg2={'required': True},
        arg3={'required': True},
        arg4={'required': False},
    )
    with pytest.raises(TypeError) as excinfo:
        check_required_arguments(argument_spec, dict(arg1=True, arg2=True))
    assert 'arg3' in to_native(excinfo.value)



# Generated at 2022-06-11 01:41:19.972716
# Unit test for function check_type_dict
def test_check_type_dict():
    mydict = {'a': 'b'}
    mydict_string = "a=b"
    mydict_string_dict = "{'a': 'b'}"
    my_dict_result = check_type_dict(mydict)
    my_dict_string_result = check_type_dict(mydict_string)
    my_dict_string_dict_result = check_type_dict(mydict_string_dict)
    mydict_string_one_equals_sign = "a=b, c=d"
    mydict_string_one_equals_sign_result = check_type_dict(mydict_string_one_equals_sign)
    assert my_dict_result == mydict
    assert my_dict_string_result == mydict
    assert my_dict_string_dict_result == my

# Generated at 2022-06-11 01:41:31.779854
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(42) == 42
    assert safe_eval('42') == 42
    assert safe_eval('42') != '42'
    assert safe_eval('["a", "b", "c"]') == ["a", "b", "c"]
    assert safe_eval('{"a": "b", "c": "d"}') == {"a": "b", "c": "d"}
    assert safe_eval('42') == safe_eval(42)
    assert safe_eval('42') == safe_eval('42') == safe_eval('042')
    assert safe_eval('42.0') == safe_eval('042.000')
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('true') == 'true'
    assert safe_eval('false')

# Generated at 2022-06-11 01:41:42.532011
# Unit test for function check_required_arguments
def test_check_required_arguments():
    class ModuleFailException(Exception):
        pass
    class ModuleExitException(Exception):
        pass
    class AnsibleFailJson:
        def __init__(self, module, msg):
            self.msg = msg
            self.module = module
        def fail_json(self, *args, **kwargs):
            raise ModuleFailException(self.msg)

    class AnsibleExitJson:
        def __init__(self, module, msg):
            self.msg = msg
            self.module = module
        def exit_json(self, *args, **kwargs):
            raise ModuleExitException(self.msg)

    class AnsibleExitJsonException(Exception):
        def __init__(self, module, msg):
            self.msg = msg
            self.module = module

# Generated at 2022-06-11 01:41:52.029641
# Unit test for function check_required_together
def test_check_required_together():
    parameters = dict(field1=1, field2=2, field3=3)

    result = check_required_together([('field1','field2','field3')], parameters)
    assert result == []

    result = check_required_together([('field1','field2','field5')], parameters)
    assert result == [('field1','field2','field5')]
    assert result

    parameters = dict(field5=5, field6=6)

    result = check_required_together([('field1','field2','field3'),('field4','field5','field6')], parameters)
    assert result == []
    assert not result


# Generated at 2022-06-11 01:42:03.774444
# Unit test for function check_required_if

# Generated at 2022-06-11 01:42:07.333391
# Unit test for function check_type_int
def test_check_type_int():
    assert isinstance(check_type_int(123), integer_types)
    assert isinstance(check_type_int("123"), integer_types)
    assert isinstance(check_type_int("-123"), integer_types)



# Generated at 2022-06-11 01:42:12.616661
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    params = {
        'update': True,
        'state': 'present',
        'name': 'test',
        'id': 8,
    }
    check = [
        'name',
        ['id', 'name'],
    ]

    try:
        check_mutually_exclusive(check, params)
    except TypeError as e:
        print(e)



# Generated at 2022-06-11 01:42:18.264669
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1024*1024*8



# Generated at 2022-06-11 01:42:23.988428
# Unit test for function check_type_float
def test_check_type_float():
    assert type(check_type_float(1)) == float
    assert type(check_type_float(1.1)) == float
    assert type(check_type_float('1.1')) == float
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1) == 1.0


# Generated at 2022-06-11 01:42:26.346591
# Unit test for function check_type_int
def test_check_type_int():
    """ Check if the function check_type_int() works properly"""
    assert check_type_int(5) == 5
    assert check_type_int("5") == 5
    try:
        check_type_int("numbers") == "numbers"
    except:
        pass


# Generated at 2022-06-11 01:42:33.220316
# Unit test for function check_required_if
def test_check_required_if():
    parameters = {}
    requirements = [
        ['state', 'present', ['path'], True],
        ['someint', 99, ['bool_param', 'string_param']],
    ]

    try:
        check_required_if(requirements, parameters)
    except TypeError as err:
        results = err.results
        assert '[{\'parameter\': \'someint\', \'value\': 99, \'requirements\': (\'bool_param\', \'string_param\'), \'missing\': [\'bool_param\', \'string_param\'], \'requires\': \'all\'}]' == str(results)



# Generated at 2022-06-11 01:42:35.219280
# Unit test for function check_type_bits
def test_check_type_bits():
    result = check_type_bits('1Mb')
    assert result == 1048576
# EOC

# Generated at 2022-06-11 01:42:47.486568
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test success
    check_mutually_exclusive(terms=[['a', 'b'], ['c', 'd']], parameters={'a': None, 'c': None})
    check_mutually_exclusive(terms=['a', 'b'], parameters={'a': None})
    # Test failure
    try:
        check_mutually_exclusive(terms=['a', 'b'], parameters={'a': None, 'b': None})
    except TypeError as e:
        assert "parameters are mutually exclusive" in to_native(e)
    # Test failure with options context

# Generated at 2022-06-11 01:42:56.881009
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Check positive values
    positive_values = ['1024', '1024B', '1kB', '1.23MB', '1.2k', '1.2mb', '1.2m', '1.2K', '1.2M', '1.2G', '1.2g']
    for value in positive_values:
        assert check_type_bytes(value) > 0

    # Check negative values
    negative_values = ['-1024', '-1024B', '-1kB', '-1.23MB', '-1.2k', '-1.2mb', '-1.2m', '-1.2K', '-1.2M', '-1.2G', '-1.2g']
    for value in negative_values:
        assert check_type_bytes(value) < 0


#

# Generated at 2022-06-11 01:42:59.003354
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576


# Generated at 2022-06-11 01:43:07.456540
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        "a": {"required": True},
        "b": {}
    }
    parameters = {"b": "value"}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == ["a"]

    argument_spec = {
        "a": {"required": False},
        "b": {"required": True}
    }
    parameters = {"a": "value"}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == ["b"]

    argument_spec = {
        "a": {"required": False},
        "b": {}
    }
    parameters = {}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []


# Generated at 2022-06-11 01:43:18.816527
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1+1') == 2
    assert safe_eval('a+1', {'a': 1}) == 2
    assert safe_eval('"a"') == "a"
    assert safe_eval('a.keys()', {'a': {'b': 1, 'c': 2}}) == 'a.keys()'
    assert safe_eval('import os') == 'import os'
    assert safe_eval('0o10') == 8
    assert safe_eval('0x10') == 16
    assert safe_eval('0b10') == 2
    assert safe_eval('0b10', include_exceptions=True) == (2, None)
    assert safe_eval('a+1', include_exceptions=True) == ('a+1', None)

# Generated at 2022-06-11 01:43:35.221419
# Unit test for function check_required_together
def test_check_required_together():
    # Test the case where no item in the list is in the given parameters
    parameters = {"id": "1234"}
    terms = (["name", "state"], ["age", "gender"])
    try:
        check_required_together(terms=terms, parameters=parameters)
    except TypeError:
        pass
    else:
        raise AssertionError("No TypeError raised")

    # Test the case where one of the items in the list is not in the given parameters
    parameters = {"id": "1234", "state": "present"}
    terms = (["name", "state"], ["age", "gender"])
    try:
        check_required_together(terms=terms, parameters=parameters)
    except TypeError:
        pass
    else:
        raise AssertionError("No TypeError raised")

    # Test the

# Generated at 2022-06-11 01:43:42.453311
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    missing_params = check_missing_parameters(parameters={'foo': 'bar'}, required_parameters=['foo'])
    assert missing_params == []
    with pytest.raises(TypeError):
        check_missing_parameters(parameters={'foo': 'bar'}, required_parameters=['foo', 'bar'])


# Generated at 2022-06-11 01:43:52.204454
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    exchange_parameters = {'a': '1', 'b': '2', 'c': '3'}
    parameters = {'a': '1', 'b': '2', 'c': '3', 'd': '4'}
    check = [('a', 'b', 'c'), ('a', 'b')]

    try:
        result = check_mutually_exclusive(check, parameters)
        assert result == []
    except TypeError:
        assert False

    try:
        result = check_mutually_exclusive(check, exchange_parameters)
        assert result != []
    except TypeError:
        assert True


# Generated at 2022-06-11 01:43:59.316910
# Unit test for function check_required_if
def test_check_required_if():
    # case: all requirements should be present
    assert check_required_if([['state', 'present', ('path',), True]], {'state': 'present', 'path': 'tmp.txt'}) == []
    assert check_required_if([['state', 'present', ('path',), False]], {'state': 'present', 'path': 'tmp.txt'}) == []
    assert check_required_if([['state', 'present', ('path',), False]], {'state': 'present', 'path': None}) == []
    # requirement path is missing
    assert check_required_if([['state', 'present', ('path',), False]], {'state': 'present'}) != []
    # case: at least one of the requirements should be present

# Generated at 2022-06-11 01:44:09.096010
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), False],
        ['someint', 99, ('bool_param', 'string_param')]
    ]
    assert check_required_if(requirements, {'state': 'present'}) == []
    assert check_required_if(requirements, {'someint': 99}) == []
    assert check_required_if(requirements, {'someint': 99, 'bool_param': 'foo'}) == []
    assert check_required_if(requirements, {'someint': 99, 'bool_param': 'foo', 'state': 'present', 'path': 'foo'}) == []
    assert check_required_if(requirements, {'someint': 99, 'string_param': 'foo', 'state': 'absent'}) == []
    assert check_required_

# Generated at 2022-06-11 01:44:19.412695
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes(1) == 1
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1kb') == 1024
    assert check_type_bytes('1tb') == 1099511627776

"""
The following functions are used internally to determine the default value
for the arg_spec paramater of the AnsibleModule class based on the module's
docstring.
"""



# Generated at 2022-06-11 01:44:28.549280
# Unit test for function check_type_bytes

# Generated at 2022-06-11 01:44:38.046219
# Unit test for function check_required_if
def test_check_required_if():
    import pytest
    requirements = [['state', 'present', ('path',), True]]
    parameters = dict(state='present',path='/test',test='test1')
    requirements_2 = [['state', 'present', ('path',), False]]
    parameters_2 = dict(state='present',test='test1')
    requirements_3 = [['state', 'present', ('path',)]]
    parameters_3 = dict(state='present',path='/test',test='test1')
    requirements_4 = [['state', 'present', ('path','test'), False]]
    parameters_4 = dict(state='present',path='/test',test='test1')
    requirements_5 = [['state', 'present', ('path','test'), False]]

# Generated at 2022-06-11 01:44:50.275819
# Unit test for function check_required_together
def test_check_required_together():
    from ansible.module_utils.common.text.utils import assert_equal

    try:
        check_required_together(terms=None, parameters=None)
        assert False, "Expected a failure due to lack of parameters"
    except:
        pass

    try:
        parameters = {'ansible_connection': 'network_cli'}
        terms = [['provider', 'transport']]
        check_required_together(terms=terms, parameters=parameters)
        assert False, "Expected a failure due to lack of required parameters"
    except:
        pass


# Generated at 2022-06-11 01:44:57.588419
# Unit test for function check_required_if
def test_check_required_if():
    # Testing negative cases
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'absent', 'someint': 25}
    actual_results = check_required_if(requirements, parameters, None)
    assert actual_results == []

    parameters = {'state': 'present', 'someint': 25}
    actual_results = check_required_if(requirements, parameters, None)
    assert actual_results == []

    parameters = {'path': '/tmp', 'someint': 99}
    actual_results = check_required_if(requirements, parameters, None)
    assert actual_results == []


# Generated at 2022-06-11 01:45:14.387015
# Unit test for function check_required_one_of
def test_check_required_one_of():
    result = check_required_one_of([['a', 'b']], {'a': 1})
    assert result == []

    result = check_required_one_of([['a', 'b']], {'a': 1, 'b': 1})
    assert result == []

    result = check_required_one_of([['a', 'b']], {'b': 1})
    assert result == []

    try:
        result = check_required_one_of([['a', 'b']], {})
    except TypeError:
        assert True
    else:
        assert False

    result = check_required_one_of([['a'], ['b', 'c']], {'a': 1, 'c': 1})
    assert result == []


# Generated at 2022-06-11 01:45:20.569614
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("'foo bar'") == 'foo bar'
    assert safe_eval("foo") == 'foo'
    assert safe_eval("[1,2,3]", locals={"b": 2}) == [1,2,3]
    assert safe_eval("{'a':'b', 'c':'d'}") == {'a':'b', 'c':'d'}
    assert safe_eval("2 + 2") == 4
    assert safe_eval("5 + 5") == 10
    assert safe_eval("(1,2,3)") == (1,2,3)
    assert safe_eval("(1,2,3)")[1] == 2
    assert safe_eval("{'a':'b', 'c':'d'}")['c'] == 'd'
    assert safe_

# Generated at 2022-06-11 01:45:23.172485
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1mb') == 1048576


# Generated at 2022-06-11 01:45:28.988918
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    # unit test for negative value
    assert check_type_bytes('-1') == -1
    assert check_type_bytes('1B') == 1
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776



# Generated at 2022-06-11 01:45:40.362087
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together([['foo','bar','baz'], ['baz','yaz']], \
            {'bar':None, 'baz':None}) == []

    assert check_required_together([['foo','bar','baz'], ['baz','yaz']], \
            {'foo':None, 'baz':None}) == []

    assert check_required_together([['foo','bar','baz'], ['baz','yaz']], \
            {'bar':None, 'baz':None, 'zoo':None}) == []

    assert check_required_together([['foo','bar','baz'], ['baz','yaz']], \
            {'bar':None, 'foo':None, 'zoo':None}) == []


# Generated at 2022-06-11 01:45:51.145828
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('-6') == -6
    assert safe_eval('1.2') == 1.2
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('"a,b"') == 'a,b'
    assert safe_eval('["a", "b"]') == ['a', 'b']
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval('["a", {"b": "c"}]') == ['a', {'b': 'c'}]
    assert safe_eval('["a", {"b": ["c", ["d", "e"]]}]') == ['a', {'b': ['c', ['d', 'e']]}]

# Generated at 2022-06-11 01:46:00.351796
# Unit test for function check_required_one_of
def test_check_required_one_of():
    params = {
        'name': 'blah',
        'state': 'present',
        'description': 'test'
    }
    check_required_one_of([('name','description')], params)
    assert True, 'check_required_one_of function should pass if one of the parameters are found'
    try:
        check_required_one_of([('name1','description')], params)
        assert False, 'check_required_one_of function should raise error if none of the parameters are found'
    except TypeError as e:
        assert True, 'check_required_one_of function should raise error if none of the parameters are found'



# Generated at 2022-06-11 01:46:08.664794
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together([("a", "b"), ("c", "d", "e")], {"a": 1, "b": 2, "e": 5}) == []
    assert check_required_together([("a", "b"), ("c", "d", "e")], {"a": 1}) == []
    assert check_required_together([("a", "b"), ("c", "d", "e")], {"a": 1, "c": "3"}) == []
    assert check_required_together([("a", "b"), ("c", "d", "e")], {"a": 1, "c": "3", "e": "5"}) == []

# Generated at 2022-06-11 01:46:15.559602
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1') == 1
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576


# Generated at 2022-06-11 01:46:26.020060
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    with pytest.raises(TypeError):
        check_type_bits('1.33Mb')


PRIMITIVE_TYPES = {
    'bool': check_type_bool,
    'bytes': check_type_bytes,
    'float': check_type_float,
    'int': check_type_int,
    'list': check_type_list,
    'dict': check_type_dict,
    'path': check_type_path,
    'raw': check_type_raw,
    'string': check_type_str,
}

# FIXME: These are here for backwards compat but needs to be updated
#        to use type checking and removed from here.

# Generated at 2022-06-11 01:46:39.617990
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('100MB') == 104857600
    assert check_type_bytes('100mb') == 104857600
    assert check_type_bytes('100kb') == 102400
    assert check_type_bytes('100Kb') == 102400
    assert check_type_bytes('100kb') == 102400
    assert check_type_bytes('100Kb') == 102400
    assert check_type_bytes('100K') == 102400
    assert check_type_bytes('100M') == 104857600
    assert check_type_bytes('100G') == 107374182400
    assert check_type_bytes('100TB') == 109951162777600
    assert check_type_bytes('100PB') == 112589990684262400
    assert check_type_bytes('100EB') == 115

# Generated at 2022-06-11 01:46:46.720141
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(3) == 3.0
    assert check_type_float(3.5) == 3.5
    assert check_type_float('3') == 3.0
    assert check_type_float('3.5') == 3.5
    assert check_type_float(b'3.5') == 3.5
    assert check_type_float(b'3') == 3.0
    raises(TypeError, check_type_float, [])



# Generated at 2022-06-11 01:46:56.072263
# Unit test for function check_required_together
def test_check_required_together():
    try:
        check_required_together([tuple(['name','other'])],{'name':'test1','other':'test2'})
        check_required_together([tuple(['name','other'])],{'name':'test1','other':''})
        check_required_together([tuple(['name','other'])],{'name':'','other':''})
        check_required_together([tuple(['name','other'])],{})
        check_required_together([['name','other']],{'name':'test1','other':'test2'})
        assert True
    except:
        assert False



# Generated at 2022-06-11 01:47:03.785876
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1024b') == 1024
    assert check_type_bits('1024') == 1024
    assert check_type_bits('1024M') == 1073741824
    assert check_type_bits('1024Mb') == 1073741824
    assert check_type_bits('1Gb') == 1073741824

    assert not check_type_bits('1024Mb').startswith(b'1')



# Generated at 2022-06-11 01:47:11.552606
# Unit test for function check_required_together
def test_check_required_together():
    terms = [
        ['a', 'b'],
        ['c', 'd']
    ]
    params = {
        'a': 'hello',
        'b': 'world'
    }
    check_required_together(terms=terms, parameters=params)
    params = {
        'c': 'hello',
        'd': 'world'
    }
    check_required_together(terms=terms, parameters=params)
    params = {
        'c': 'hello'
    }
    check_required_together(terms=terms, parameters=params)



# Generated at 2022-06-11 01:47:15.998233
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Kb') == 8192
    assert check_type_bits('1Mb') == 8388608
    assert check_type_bits('1Gb') == 8589934592
    # test for error
    try:
        check_type_bits('1M')
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-11 01:47:18.381858
# Unit test for function check_type_int
def test_check_type_int():
    for value in [123, '123', 'a']:
        check_type_int(value)

# Generated at 2022-06-11 01:47:27.607435
# Unit test for function check_required_if
def test_check_required_if():
    param_list1 = {
        'state': 'present',
        'path': 'k',
        'someint': 5
        }
    fail_list1 = [
        ['state', 'present', ('path',), True]
        ]
    param_list2 = {
        'state': 'present',
        'path': 'k',
        'someint': 99
        }
    fail_list2 = [
        ['someint', 99, ('bool_param', 'string_param')]
        ]
    param_list3 = {
        'state': 'present',
        'path': 'k',
        'someint': 99,
        'string_param': 's'
        }
    fail_list3 = [
        ['someint', 99, ('bool_param', 'string_param')]
        ]
   

# Generated at 2022-06-11 01:47:37.285527
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(True) is True
    assert safe_eval(1) == 1
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('0') == 0
    assert safe_eval('') == ''
    assert safe_eval('"asdf"') == 'asdf'

    # unicode

# Generated at 2022-06-11 01:47:49.633305
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(18) == 18
    assert check_type_float(18.5) == 18.5

    assert check_type_float('18') == 18
    assert check_type_float('18.5') == 18.5
    with pytest.raises(TypeError):
        check_type_float('18.5.5')

    assert check_type_float(b'18') == 18
    assert check_type_float(b'18.5') == 18.5
    with pytest.raises(TypeError):
        check_type_float(b'18.5.5')

    assert check_type_float(u'18') == 18
    assert check_type_float(u'18.5') == 18.5
    with pytest.raises(TypeError):
        check_type_

# Generated at 2022-06-11 01:47:59.645583
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1KiB') == 1024
    assert check_type_bits('1GiB') == 1073741824
    assert check_type_bits('12345678901234567890Mb') == 12345678901234567890 * 1048576


# Generated at 2022-06-11 01:48:11.102624
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    specs = dict(
        mutually_exclusive=[
            ['one', 'two'],
            ['four', 'five'],
            ['seven', 'eight'], ],
        subspecs=dict(
            mutually_exclusive=[
                ['one', 'four'],
                ['two', 'five'],
            ],
            mutually_exclusive_with_vars=[
                ['{{one}}', '{{four}}'],
                ['{{two}}', '{{five}}'],
            ],
        )
    )
    # test mutually_exclusive
    parameters = dict(
        one=1,
        two=2,
        three=3,
        four=4,
        five=5,
        six=6,
        seven=7,
        eight=8,
    )

# Generated at 2022-06-11 01:48:17.228260
# Unit test for function check_required_one_of
def test_check_required_one_of():
    '''
    Example taken from the ansible_service_mgr module
    '''
    data = [
        {'check_required_one_of': [['state', 'enabled']]},
        {'check_required_one_of': [['state', 'disabled']]},
        {'check_required_one_of': [['state', 'restarted']]},
        {'check_required_one_of': [['state', 'reloaded']]},
        {'check_required_one_of': [['state', 'reloaded']]},
        {'check_required_one_of': [['state']]}
    ]

# Generated at 2022-06-11 01:48:21.130557
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    tests = (
        ({'a': 1, 'b': 2}, None),
        ({'a': 1, 'b': 2}, [['a']]),
        ({'a': 1, 'b': 2}, [['a', 'b']]),
    )
    for test in tests:
        result = check_mutually_exclusive(*test)
        assert result == []


# Generated at 2022-06-11 01:48:24.488202
# Unit test for function check_type_bytes
def test_check_type_bytes():
  assert check_type_bytes('1K') == 1024
  assert check_type_bytes('5M') == 5242880
  try:
    assert check_type_bytes('5B')
  except TypeError:
    pass


# Generated at 2022-06-11 01:48:29.493985
# Unit test for function safe_eval
def test_safe_eval():
    assert callable(safe_eval)
    # Check for valid return values
    test_variable = '"Test123"'
    assert safe_eval(test_variable) == "Test123"
    # Check for invalid return values
    test_variable = '''"Test123"/5'''
    assert safe_eval(test_variable) == test_variable


# Generated at 2022-06-11 01:48:34.970076
# Unit test for function check_required_together
def test_check_required_together():
    terms = [
        ['name', 'command'],
        ['name', 'src'],
        ['name', 'raw'],
        ['command', 'src'],
        ['command', 'raw'],
        ['src', 'raw']
    ]
    parameters = dict(name="foo", src="/tmp/bar")
    check_required_together(terms, parameters)



# Generated at 2022-06-11 01:48:45.789453
# Unit test for function check_required_together
def test_check_required_together():
    spec = [
        ('a', 'b'),
        ('b', 'c', 'd'),
    ]
    params = dict(a="A", b="B")
    assert check_required_together(spec, params) == []
    params = dict(a="A", c="C")
    try:
        check_required_together(spec, params)
        assert False
    except TypeError:
        assert True
    params = dict(a="A", b="B", c="C")
    assert check_required_together(spec, params) == []
    params = dict(a="A", b="B", d="D")
    assert check_required_together(spec, params) == []
    params = dict(b="B", c="C", d="D")
    assert check_required_together(spec, params) == []


# Generated at 2022-06-11 01:48:57.811302
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{'k1':'v1'}") == {'k1':'v1'}
    assert check_type_dict("k1=v1,k2=v2,k3=v3") == {'k1':'v1', 'k2':'v2', 'k3':'v3'}
    assert check_type_dict({'k1':'v1', 'k2':'v2'}) == {'k1':'v1', 'k2':'v2'}
    assert check_type_dict(dict(k1='v1', k2='v2')) == {'k1':'v1', 'k2':'v2'}

# Generated at 2022-06-11 01:49:06.867638
# Unit test for function check_type_int
def test_check_type_int():
    with pytest.raises(TypeError):
        check_type_int([])
    with pytest.raises(TypeError):
        check_type_int({"a":"a"})
    with pytest.raises(TypeError):
        check_type_int({"a":"a"})
    with pytest.raises(TypeError):
        check_type_int(False)
    with pytest.raises(TypeError):
        check_type_int(True)
    with pytest.raises(TypeError):
        check_type_int((1,2))
    with pytest.raises(TypeError):
        check_type_int("1a")
    assert check_type_int("1") == 1
    assert check_type_int("0") == 0

# Generated at 2022-06-11 01:49:21.001640
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert to_bytes(human_to_bytes('0'), nonstring='passthru') == human_to_bytes('0')
    assert to_bytes(human_to_bytes('1'), nonstring='passthru') == human_to_bytes('1')
    assert to_bytes(human_to_bytes('1B'), nonstring='passthru') == human_to_bytes('1B')
    assert to_bytes(human_to_bytes('1KB'), nonstring='passthru') == human_to_bytes('1KB')
    assert to_bytes(human_to_bytes('1MB'), nonstring='passthru') == human_to_bytes('1MB')
    assert to_bytes(human_to_bytes('1G'), nonstring='passthru') == human_to_bytes('1G')
    assert to_bytes

# Generated at 2022-06-11 01:49:33.226268
# Unit test for function check_type_dict
def test_check_type_dict():
    test_dict = {'a': 'b', 'c': 'd'}
    test_str = "a='b', c='d'"
    assert check_type_dict(test_str) == test_dict

    test_str = "{'a': 'b', 'c': 'd'}"
    assert check_type_dict(test_str) == test_dict

    test_str = '{"a": "b", "c": "d"}'
    assert check_type_dict(test_str) == test_dict

    test_str = 'a=b, c=d'
    assert check_type_dict(test_str) == test_dict

    test_str = 'a=b, c=d'
    assert check_type_dict(test_str) == test_dict


# Generated at 2022-06-11 01:49:35.620945
# Unit test for function check_type_bits
def test_check_type_bits():
    try:
        assert check_type_bits('100Mb') == 104857600
    except:
        assert check_type_bits('100Mb') != 104857600


# Generated at 2022-06-11 01:49:44.081222
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1b') == 1
    assert check_type_bits('1bit') == 1
    assert check_type_bits('2bits') == 2
    assert check_type_bits('1kb') == 1024*8
    assert check_type_bits('1mb') == 1024*1024*8
    assert check_type_bits('1gb') == 1024*1024*1024*8
    assert check_type_bits('1tb') == 1024*1024*1024*1024*8
    assert check_type_bits('1pb') == 1024*1024*1024*1024*1024*8



# Generated at 2022-06-11 01:49:46.352876
# Unit test for function check_type_bits
def test_check_type_bits():
    assert(check_type_bits('1Mb') == 1048576)

# Function check_type_bool

# Generated at 2022-06-11 01:49:51.389550
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(0) == 0

# Generated at 2022-06-11 01:49:58.981993
# Unit test for function check_type_dict
def test_check_type_dict():
    test = check_type_dict('{\"test\":\"test\"}')
    assert(isinstance(test,dict))
    test = check_type_dict('test=test,test2=test2')
    assert(isinstance(test,dict))
    test = check_type_dict('test')
    assert(isinstance(test,dict))
    test = check_type_dict({'test':'test'})
    assert(isinstance(test,dict))


# Generated at 2022-06-11 01:50:05.024599
# Unit test for function check_type_int
def test_check_type_int():
    check_type_int(2)
    check_type_int('2')
    try:
        check_type_int(None)
    except TypeError:
        print("Unit test:check_type_int")
    try:
        check_type_int(2.1)
    except TypeError:
        print("Unit test:check_type_int")


# Generated at 2022-06-11 01:50:14.895226
# Unit test for function check_required_together
def test_check_required_together():
    parameters = dict(a=1, b=2)
    terms = [['a', 'b']]
    options_context = []
    assert [] == check_required_together(terms, parameters, options_context)
    terms = [['a', 'c']]
    assert [['a', 'c']] == check_required_together(terms, parameters, options_context)
    parameters = dict(a=1)
    assert [['a', 'c']] == check_required_together(terms, parameters, options_context)
    parameters = dict(c=1)
    assert [['a', 'c']] == check_required_together(terms, parameters, options_context)
    terms = [['a', 'b', 'c']]