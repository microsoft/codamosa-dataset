

# Generated at 2022-06-11 01:40:53.790285
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    assert check_missing_parameters([], None) == []
    assert check_missing_parameters(dict(a=1, b=1, c=1), None) == []
    assert check_missing_parameters([], ['a']) == []
    assert check_missing_parameters(dict(a=1, b=1, c=1), ['d']) == []
    assert check_missing_parameters(dict(a=1, b=1, c=1), ['d', 'e']) == []
    assert check_missing_parameters(dict(a=1, b=1, c=1), ['d', 'e', 'a']) == []
    assert check_missing_parameters(dict(b=1, c=1), ['a']) == ['a']

# Generated at 2022-06-11 01:40:56.463879
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together(terms=[('a', 'b'), ('c', 'd')], parameters={'a': 1, 'b': 1, 'd': 1}) == []



# Generated at 2022-06-11 01:41:03.156251
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Unrecognised input
    with pytest.raises(TypeError):
        assert check_type_bytes('1Xb') == 1
    # recognized inputs
    assert check_type_bytes('0') == 0
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576



# Generated at 2022-06-11 01:41:14.893665
# Unit test for function check_required_if
def test_check_required_if():
    from ansible.module_utils.common.collections import ImmutableDict
    import textwrap

    spec = dict(
        foo=dict(type='str', required=True),
        bar=dict(type='str', required=True),
        x=dict(type='str', required=True),
        y=dict(type='str', required=True),
        w=dict(type='str', required=True),
        z=dict(type='str', required=True),
    )


# Generated at 2022-06-11 01:41:25.491786
# Unit test for function check_required_if
def test_check_required_if():
    def t(requirements, parameters):
        return check_required_if(requirements, parameters, [])
    requirements = [['state', 'present', ('path',), False]]
    assert t(requirements, {'state': 'present'})
    assert t(requirements, {'state': 'absent'})
    assert t(requirements, {'state': 'present', 'path': '/a/b'})
    assert t(requirements, {'state': 'absent', 'path': '/a/b'})
    try:
        t(requirements, {'state': 'present', 'path': ''})
    except TypeError:
        assert True, "Should throw TypeError since 'path' is not given"

# Generated at 2022-06-11 01:41:35.021434
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = [['1','2','3','4','5'],['6','7','8','9','10']]
    parameters = {'1': '1','2': '2','3':'3','4':'4','5':'5','x':'x','y':'y','z':'z'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        print(e)
        assert False ,"test_check_mutually_exclusive"
    parameters = {'1': '1'}
    assert [] == check_mutually_exclusive(terms, parameters)


# Generated at 2022-06-11 01:41:44.277567
# Unit test for function check_required_if
def test_check_required_if():
    assert check_required_if([['state', 'present', ['service'], True]],
                             {'state': 'present', 'service': 'httpd'}) == []
    assert check_required_if([['state', 'present', ['service'], True]],
                             {'state': 'present', 'service': 'httpd', 'open_port': True}) == []
    assert check_required_if([['state', 'present', ['service'], True]],
                             {'state': 'present', 'open_port': True}) == [{'missing': ['service'], 'requires': 'any', 'parameter': 'state', 'value': 'present', 'requirements': ['service']}]

# Generated at 2022-06-11 01:41:51.085801
# Unit test for function check_required_together
def test_check_required_together():
    terms = [
        ['a', 'b'],
        ['c', 'd'],
        ['e', 'f']
    ]
    #Test case where param b exists, but a is missing
    parameters = {'b': None}
    check_required_together(terms, parameters)
    #Test case where param e exists, but f is missing
    parameters = {'e': None}
    check_required_together(terms, parameters)



# Generated at 2022-06-11 01:42:03.038379
# Unit test for function check_type_dict

# Generated at 2022-06-11 01:42:07.265581
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'test1':1, 'test2':2}
    required_parameters = ['test1', 'test2', 'test3']
    try:
        check_missing_parameters(parameters, required_parameters)
    except:
        return True
    return False
print(test_check_missing_parameters())


# Generated at 2022-06-11 01:42:25.306591
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1+2') == 3
    assert safe_eval('0o11') == 9
    assert safe_eval('0x11') == 17
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('1==1') is True
    assert safe_eval('1==2') is False
    assert safe_eval('{}') == {}
    assert safe_eval('[]') == []
    assert safe_eval('()') == ()
    assert safe_eval('["foo", "bar"]') == ["foo", "bar"]
    assert safe_eval('("foo", "bar")') == ("foo", "bar")
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}

# Generated at 2022-06-11 01:42:26.877946
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(15)==15
    assert check_type_int('15')==15
    try:
        check_type_int('we')
    except TypeError:
        pass


# Generated at 2022-06-11 01:42:30.627747
# Unit test for function check_required_arguments
def test_check_required_arguments():
    spec = {'name': {'required': True, 'type': 'str'}, 'age': {'required': True, 'type': 'int'}}
    check = {'name': 'Bob', 'age': 45}
    check_required_arguments(spec, check)



# Generated at 2022-06-11 01:42:41.383771
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(u"1 + 2") == 3
    assert safe_eval(u"list(range(5))") == [0, 1, 2, 3, 4]
    assert safe_eval(u"list(range(5))[-1]") == 4
    assert safe_eval(u"list(range(5))", include_exceptions=True)[0] == [0, 1, 2, 3, 4]
    assert safe_eval(u"2 + 2", include_exceptions=True)[0] == 4
    assert safe_eval(u"my_func()", include_exceptions=True)[0] == u"my_func()"
    assert safe_eval(u"my_func()", include_exceptions=True)[1] is None

# Generated at 2022-06-11 01:42:45.226274
# Unit test for function check_type_bits
def test_check_type_bits():

    # check with valid input
    assert check_type_bits('1Mb') == 1048576

    with pytest.raises(TypeError):
        # check with incorrect input
        assert check_type_bits('1MB')



# Generated at 2022-06-11 01:42:56.159349
# Unit test for function safe_eval
def test_safe_eval():
    # Test with include_exceptions set to True
    assert safe_eval('foo', include_exceptions=True) == ('foo', None)
    assert safe_eval('foo.bar()', include_exceptions=True) == ('foo.bar()', None)
    assert safe_eval('1+1', include_exceptions=True) == (2, None)
    assert safe_eval('import foo', include_exceptions=True) == ('import foo', None)
    assert safe_eval('foo.bar()', include_exceptions=True) == ('foo.bar()', None)
    assert safe_eval(u'foo', include_exceptions=True) == ('foo', None)

    # Test with include_exceptions set to False
    assert safe_eval('foo') == 'foo'

# Generated at 2022-06-11 01:43:02.164762
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments({'param1': {'required': True}}, {}) == ['param1']
    assert check_required_arguments({'param1': {'required': False}}, {}) == []
    assert check_required_arguments({'param1': {'required': False}}, {'param1': 'value'}) == []


# Generated at 2022-06-11 01:43:10.127526
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1m') == 1048576
    assert check_type_bits('1') == 8
    assert check_type_bits('8') == 8
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1K') == 1024
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1kB') == 1024
    assert check_type_bits('1k') == 1024
    assert check_type_bits('1B') == 1
    assert check_type_bits('1b') == 1

# Generated at 2022-06-11 01:43:19.976804
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert(check_required_one_of([['a', 'b']], dict(a=1, b=2)))
    assert(check_required_one_of([['a', 'b']], dict(a=1)))
    assert(check_required_one_of([['a', 'b']], dict(b=1)))

    try:
        check_required_one_of([['a', 'b']], dict())
        assert False
    except TypeError:
        assert True
    try:
        check_required_one_of([['a', 'b']], dict(), options_context=['parent'])
        assert False
    except TypeError as e:
        assert str(e) == "one of the following is required: a, b found in parent"
        assert True



# Generated at 2022-06-11 01:43:30.722933
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = dict(required_arg_1=dict(required=True), required_arg_2=dict(required=True), not_required=dict())
    missing = check_required_arguments(argument_spec, dict())
    assert sorted(missing) == ["required_arg_1", "required_arg_2"]
    missing = check_required_arguments(argument_spec, dict(required_arg_1=True))
    assert sorted(missing) == ["required_arg_2"]
    missing = check_required_arguments(argument_spec, dict(required_arg_1=True, required_arg_2=True))
    assert sorted(missing) == []



# Generated at 2022-06-11 01:43:43.382068
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [['a', 'b', 'c']]
    parameters = {'a': '1', 'b': '2'}
    assert check_required_one_of(terms, parameters) == []

    parameters = {'d': '1', 'e': '2'}
    try:
        check_required_one_of(terms, parameters)
        assert false
    except TypeError as type_error:
        assert 'one of the following is required: a, b, c' in str(type_error)



# Generated at 2022-06-11 01:43:50.049388
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    module_args = {'banana': 'monkeys', 'orange': 'oranges', 'apple': 'apples'}
    results = check_mutually_exclusive(['banana', 'orange'], module_args)
    assert results is None
    results = check_mutually_exclusive(['banana', 'orange', 'apple'], module_args)
    assert results is not None
    results = check_mutually_exclusive(['banana', 'orange'], module_args, ['state', 'present'])
    assert results is None
    results = check_mutually_exclusive(['banana', 'orange', 'apple'], module_args, ['state', 'present'])
    assert results is not None



# Generated at 2022-06-11 01:43:59.325636
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = dict()
    argument_spec['one'] = dict(required=False)
    argument_spec['two'] = dict(required=True)
    argument_spec['three'] = dict(required=False)
    parameters = dict()
    assert check_required_arguments(argument_spec, parameters) == ['two']
    parameters['one'] = 'one'
    parameters['three'] = 'three'
    assert check_required_arguments(argument_spec, parameters) == []
    argument_spec['two']['required'] = False
    parameters['two'] = 'two'
    assert check_required_arguments(argument_spec, parameters) == []
    del parameters['two']
    assert check_required_arguments(argument_spec, parameters) == []



# Generated at 2022-06-11 01:44:03.786174
# Unit test for function check_required_if
def test_check_required_if():
    results = check_required_if([('state', 'present', ('path',), True)], {'state': 'present'})
    assert len(results) > 0, 'This should be a failed test. \'path\' is required.'



# Generated at 2022-06-11 01:44:16.234139
# Unit test for function check_required_together
def test_check_required_together():
    # Let's create a test function that check the function check_required_together
    # We will test the function with two dictionaries:
    parameters1 = {'a': '1', 'b': '2', 'c': '3'}
    parameters2 = {'a': '1', 'b': '2', 'd': '4'}
    # In both cases, the parameters should raise an error
    try:
        check_required_together([['a', 'b', 'c']], parameters1)
    except TypeError as err:
        assert "parameters are required together: a, b, c" in to_native(err)

# Generated at 2022-06-11 01:44:20.371610
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1MB') == 1048576
    assert check_type_bits('1mb') == 1048576



# Generated at 2022-06-11 01:44:22.113526
# Unit test for function check_type_float
def test_check_type_float():
    import unittest
    class Test(unittest.TestCase):
        def test_check_type_float(self):
            result=check_type_float('1.0')
            self.assertEqual(result,1.0)
    unittest.main(defaultTest="Test",verbosity=2)

# Generated at 2022-06-11 01:44:27.973442
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("3 * 4 * 5") == 60
    assert safe_eval("3 * 4 * 5", include_exceptions=True) == (60, None)
    assert safe_eval("3 * 4 * foo") == "3 * 4 * foo"
    assert safe_eval("foo.bar()") == "foo.bar()"
    assert safe_eval("import foo") == "import foo"
    assert safe_eval("foo") == "foo"
    assert safe_eval("foo", locals=dict(foo=42)) == 42



# Generated at 2022-06-11 01:44:30.581814
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int("1") == 1
# End of function test_check_type_int



# Generated at 2022-06-11 01:44:32.746513
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert (check_type_bytes('1kB') == 1000)
    try:
        check_type_bytes('test')
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-11 01:44:41.326840
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0
    assert check_type_float("1.0") == 1.0
    assert check_type_float("1.0".encode()) == 1.0
    assert check_type_float(1.0) == 1.0
    assert_raises(TypeError, check_type_float, "a")


# Generated at 2022-06-11 01:44:52.262548
# Unit test for function check_required_together
def test_check_required_together():
    module_args = dict(
        foo=1,
        bar=1
    )
    spec = dict(
        required_together=[[['foo', 'bar']]]
    )
    options_context = []
    try:
        check_required_together(spec['required_together'], module_args, options_context)
    except TypeError as e:
        assert True, e.message
    module_args = dict(
        foo=1
    )
    try:
        check_required_together(spec['required_together'], module_args, options_context)
        assert True, 'should not get here'
    except TypeError as e:
        assert 'foo, bar' in e.message
#test_check_required_together()



# Generated at 2022-06-11 01:45:02.691862
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by(None, {}) == {}
    assert check_required_by({'arg1': 'arg2'}, {}) == {'arg1': ['arg2']}
    assert check_required_by({'arg1': 'arg2'}, {'arg2': 'some value'}) == {'arg1': ['arg2']}
    assert check_required_by({'arg1': 'arg2'}, {'arg2': 'some value', 'arg1': 'some value'}) == {}
    assert check_required_by({'arg1': ['arg2', 'arg3']}, {'arg2': 'some value', 'arg3': 'value'}) == {}

# Generated at 2022-06-11 01:45:04.196120
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 8388608



# Generated at 2022-06-11 01:45:08.291968
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(u'1') == 1.0
    assert check_type_float(u'1.0') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0') == 1.0
    try:
        check_type_float('a')
        raise RuntimeError("Expected exception was not raised")
    except TypeError:
        pass



# Generated at 2022-06-11 01:45:19.028027
# Unit test for function check_required_by
def test_check_required_by():
    examples = [
        ({}, {'a': 1}, None),
        ({'a': ['b']}, {'a': 1}, None),
        ({'a': ['b']}, {'a': 1, 'b': 2}, None),
        ({'a': ['b', 'c']}, {'a': 1, 'b': 2}, None),
        ({'a': ['b']}, {'a': 1, 'c': 2}, "missing parameter(s) required by 'a': b found in None"),
        ({'a': ['b', 'c']}, {'a': 1}, "missing parameter(s) required by 'a': b, c found in None")]
    for requirements, parameters, expected in examples:
        actual = check_required_by(requirements, parameters)
        if expected:
            assert actual == expected

# Generated at 2022-06-11 01:45:30.795766
# Unit test for function check_required_together
def test_check_required_together():
    parameters_true = {'a': 'test',
                       'b': 'test', }
    parameters_false = {'a': 'test', }

    terms_true = [['a', 'b'], ]
    terms_false = [['a', 'b', 'c'], ]

    results = check_required_together(terms_true, parameters_true)
    assert results == []

    try:
        check_required_together(terms_false, parameters_true)
    except TypeError as e:
        assert "required together" in e.args[0]
    else:
        assert False

    try:
        check_required_together(terms_true, parameters_false)
    except TypeError as e:
        assert "required together" in e.args[0]
    else:
        assert False


# Generated at 2022-06-11 01:45:42.751337
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict({'v':'1'}) == {'v':'1'}
    assert check_type_dict('v=1') == {'v':'1'}
    assert check_type_dict('"v"=1') == {'"v"':'1'}
    assert check_type_dict('v=1, v2=2') == {'v':'1', 'v2':'2'}
    assert check_type_dict('v=1, "v2"="2"') == {'v':'1', '"v2"':'"2"'}
    assert check_type_dict({'v=1':'1'}) == {'v=1':'1'}
    assert check_type_dict('{"v":1}') == {'v':'1'}
   

# Generated at 2022-06-11 01:45:52.585649
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(4) == 4
    def assert_the_int():
        assert check_type_int("4") == 4
    assert_the_int()
    def assert_the_float():
        assert check_type_int(4.5) == 4
    assert_the_float()
    def assert_the_float_with_string():
        assert check_type_int("4.5") == 4
    assert_the_float_with_string()
    def assert_the_string_with_decimal():
        assert check_type_int("4.5") == 4
    assert_the_string_with_decimal()
    def assert_the_string():
        assert check_type_int("4") == 4
    assert_the_string()


# Generated at 2022-06-11 01:46:04.093626
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a":1}') == {"a" : 1}
    assert check_type_dict('{"a": "b"}') == {"a" : "b"}
    assert check_type_dict('{"a": "b"}') == {"a" : "b"}
    assert check_type_dict('k="v"') == {"k": "v"}
    assert check_type_dict('"k" = "v"') == {"k": "v"}
    assert check_type_dict('"k" = "v"') == {"k": "v"}
    assert check_type_dict('"k" = "v"') == {"k": "v"}
    assert check_type_dict('k="v"') == {"k": "v"}

# Generated at 2022-06-11 01:46:21.057413
# Unit test for function check_required_together
def test_check_required_together():
    check_required_together([['a', 'b'],['c', 'd']], {'a': 1, 'b': 1, 'c': 1})
    check_required_together([['a', 'b'],['c', 'd']], {'a': 1, 'b': 1, 'c': 1, 'd': 1})
    with pytest.raises(TypeError):
        check_required_together([['a', 'b'],['c', 'd']], {'a': 1, 'b': 1, 'c': 1, 'd': 1, 'e': 1})
        check_required_together([['a', 'b'],['c', 'd']], {'a': 1, 'b': 1, 'c': 0})

# Generated at 2022-06-11 01:46:29.753257
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("1") == 1
    assert safe_eval("'1'") == "1"
    assert safe_eval("('abc', 'def')") == ("abc", "def")
    assert safe_eval("{'a':'1', 'b':False}") == {"a": "1", "b": False}
    assert safe_eval(text_type({"k1": {"k2": {"k3": {'k4': u'漢字'}}}})) == {"k1": {"k2": {"k3": {'k4': u'漢字'}}}}

# Generated at 2022-06-11 01:46:36.163172
# Unit test for function check_required_if
def test_check_required_if():
    data = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')]
    ]
    parameters = {
        'someint': 99,
        'bool_param': True,
        'string_param': 'hello'
    }
    options_context = []
    assert check_required_if(data, parameters, options_context) == []



# Generated at 2022-06-11 01:46:41.825284
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    options = ["ansible_network_os", "ios"]
    try:
        check_mutually_exclusive(terms, parameters, options)
    except TypeError as e:
        assert "parameters are mutually exclusive: a|b, c|d" in to_native(e)



# Generated at 2022-06-11 01:46:46.052980
# Unit test for function check_required_by
def test_check_required_by():
    parameters = dict(
        foo="baz",
        hello=True,
    )
    check_required_by(requirements=dict(
        foo=['hello'],
    ), parameters=parameters)
    assert True



# Generated at 2022-06-11 01:46:57.504085
# Unit test for function check_required_one_of
def test_check_required_one_of():
    MODULE_SPEC_ARGS = {'parameters': {'arg1': {'type': 'str'},
                                       'arg2': {'type': 'int'}
                                       }
                        }
    MODULE_ARGS = {'arg1': 'foo',
                   'arg2': 2
                   }
    try:
        check_required_one_of([['arg1'], ['arg2']], MODULE_ARGS)
    except TypeError as e:
        assert False, 'One of the terms is required'

    try:
        check_required_one_of([['arg1'], ['arg2']], MODULE_ARGS, options_context=['parameters'])
    except TypeError as e:
        assert False, 'One of the terms is required'


# Generated at 2022-06-11 01:47:03.522174
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) is 1.0
    assert check_type_float('1.0') is 1.0
    assert check_type_float(1) is 1.0
    assert_raises(TypeError, check_type_float, object())
    assert_raises(TypeError, check_type_float, 'toast')


# Generated at 2022-06-11 01:47:14.410379
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {
        'name': 'state',
        'partition': ['state', 'partition']
    }
    parameter = {
        'name': 'foo',
        'state': 'present',
        'partition': 'Common'
    }
    assert check_required_by(requirements, parameters) == {}

    parameter = {
        'name': 'foo',
        'state': 'present',
    }
    assert check_required_by(requirements, parameters) == {
        'partition': ['state', 'partition']
    }

    parameter = {
        'name': 'foo',
        'state': 'present',
        'partition': 'Common'
    }
    assert check_required_by(requirements, parameters) == {}


# Generated at 2022-06-11 01:47:25.178397
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("'key1':'value1'")["key1"] == "value1"
    assert check_type_dict("{'key1':'value1'}")["key1"] == "value1"
    assert check_type_dict("{\\'key1\\':\\'value1\\'}")["key1"] == "value1"
    assert check_type_dict('key1=value1')["key1"] == "value1"
    assert check_type_dict(' key1= value1  ')["key1"] == "value1"
    assert check_type_dict(' key1= value1  ')["key1"] == "value1"
    assert check_type_dict(' key1 = value1  ')["key1"] == "value1"

# Generated at 2022-06-11 01:47:28.806538
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {'name': 'Ansible', 'state': 'present',
                  'value' : '"test value"'}
    terms = [['name', 'value']]
    assert check_required_together(terms, parameters) == []



# Generated at 2022-06-11 01:47:35.496540
# Unit test for function check_type_int
def test_check_type_int():
    # valid values for integer
    assert check_type_int(123) == 123
    assert check_type_int('123') == 123
    try:
        check_type_int('abc')
    except TypeError:
        pass
    else:
        raise AssertionError('missing TypeError')

# Generated at 2022-06-11 01:47:43.074540
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') != 10485760
    assert check_type_bits('10Gb') == 10737418240
    assert check_type_bits('1tb') == 10995116277760
    assert check_type_bits('1G') == 1073741824
    assert check_type_bits('1T') == 1099511627776

# FIXME: Should we remove or deprecate this?

# Generated at 2022-06-11 01:47:53.838389
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'firstname': {
            'required': True,
            'type': 'str'
        },
        'lastname': {
            'required': False,
            'type': 'str'
        },
    }

    try:
        res = check_required_arguments(argument_spec, {'anything': 'value'})
        assert False, "check_required_arguments did not fail when it should have"
    except TypeError as e:
        assert "missing required arguments" in str(e), "Invalid exception raised"

    parameters = {
        'firstname': 'Foo',
        'lastname': 'Bar',
    }

    res = check_required_arguments(argument_spec, parameters)
    assert len(res) == 0, "Wrong result from check_required_arguments"



# Generated at 2022-06-11 01:47:58.813235
# Unit test for function check_required_by
def test_check_required_by():
    requirements = dict(key1=['param2', 'param3'])
    parameters = dict(key1='value1', param2=None, param3=None)
    assert check_required_by(requirements, parameters) == dict(key1=['param2', 'param3'])



# Generated at 2022-06-11 01:48:08.341406
# Unit test for function safe_eval
def test_safe_eval():
    result, exception = safe_eval('{"foo": "bar"}', None, include_exceptions=True)
    if exception is None:
        assert result == {"foo": "bar"}
    else:
        raise exception

    result = safe_eval('{"foo": "bar"}')
    assert result == {"foo": "bar"}

    # replace this with a more generic function?
    result, exception = safe_eval('{"foo": "{{bar}}"}', dict(bar='bar'), include_exceptions=True)
    if exception is None:
        assert result == {"foo": "bar"}
    else:
        raise exception



# Generated at 2022-06-11 01:48:11.042488
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(123) == 123
    assert check_type_int("123") == 123
    assert check_type_int("Blah") == TypeError


# Generated at 2022-06-11 01:48:20.351174
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict({'hello':['world', 'moon', 'sun']}) == {'hello':['world', 'moon', 'sun']}
    assert check_type_dict('{"hello": ["world", "moon", "sun"]}') == {"hello": ["world", "moon", "sun"]}
    assert check_type_dict('hello=world,moon,sun') == {'hello': 'world,moon,sun'}
    assert check_type_dict('hello=world\,moon\,sun') == {'hello': 'world,moon,sun'}
    assert check_type_dict('hello="world,moon,sun"') == {'hello': '"world,moon,sun"'}

# Generated at 2022-06-11 01:48:28.653263
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(0.0) == 0.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0

    with pytest.raises(TypeError) as excinfo:
        check_type_float([1])
    assert 'list' in to_native(excinfo.value)
    with pytest.raises(TypeError) as excinfo:
        check_type_float(dict(d=1))
    assert 'dict' in to_native(excinfo.value)



# Generated at 2022-06-11 01:48:40.240534
# Unit test for function check_required_together
def test_check_required_together():
    from ansible.module_utils.common.text.validators import check_required_together
    try:
        result = check_required_together([['a']], {})
        assert(result == [])

    except TypeError:
        assert(False)

    try:
        result = check_required_together([['a', 'b']], {})
        assert(False)

    except TypeError:
        assert(True)

    try:
        result = check_required_together([['a', 'b']], {'a': 1})
        assert(False)

    except TypeError:
        assert(True)

    try:
        result = check_required_together([['a', 'b']], {'b': 1})
        assert(False)

    except TypeError:
        assert(True)


# Generated at 2022-06-11 01:48:41.958914
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-11 01:48:56.077475
# Unit test for function safe_eval
def test_safe_eval():
    # when nothing matches
    assert safe_eval('whatever') == 'whatever'

    # when no functions are found
    assert safe_eval("['a', 'b', 'c']") == ['a', 'b', 'c']

    # when no import is found
    assert safe_eval("{'a': 'b', 'c': 'd'}") == {'a': 'b', 'c': 'd'}

    # when function is found
    assert safe_eval("os.path.exists('/etc/hosts')") == "os.path.exists('/etc/hosts')"

    # when the import is found
    assert safe_eval("import os") == "import os"



# Generated at 2022-06-11 01:48:57.710812
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert((check_type_bytes('42')) == 42)



# Generated at 2022-06-11 01:49:06.345161
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes("1024") == 1024
    assert check_type_bytes("1024B") == 1024
    assert check_type_bytes("1KB") == 1024
    assert check_type_bytes("1MB") == 1048576
    assert check_type_bytes("1GB") == 1073741824
    assert check_type_bytes("1TB") == 1099511627776
    assert check_type_bytes("1PB") == 1125899906842624
    assert check_type_bytes("1EB") == 1152921504606846976
    assert check_type_bytes("1ZB") == 1180591620717411303424
    assert check_type_bytes("1YB") == 1208925819614629174706176



# Generated at 2022-06-11 01:49:08.588563
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1


# Generated at 2022-06-11 01:49:19.508122
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes(1024) == 1024
    assert check_type_bytes(2**40) == 2**40
    assert check_type_bytes('1Ki') == 1024
    assert check_type_bytes('1Mi') == 1048576
    assert check_type_bytes('1Gi') == 1073741824
    assert check_type_bytes('1Ti') == 1099511627776
    assert check_type_bytes('1024') == 1024
    assert check_type_bytes('2**40') == 2**40

# Generated at 2022-06-11 01:49:24.884202
# Unit test for function check_type_int
def test_check_type_int():
    assert(check_type_int(2) == 2)
    assert(check_type_int('2') == 2)

    try:
        check_type_int(2.5)
    except TypeError:
        pass
    else:
        assert(False, "float(2.5) should not be converted to an int")

    try:
        check_type_int('2.5')
    except TypeError:
        pass
    else:
        assert(False, "string '2.5' should not be converted to an int")

    try:
        check_type_int('this is not an int')
    except TypeError:
        pass
    else:
        assert(False, "string 'this is not an int' should not be converted to an int")


# Generated at 2022-06-11 01:49:35.884287
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('0') == 0
    assert safe_eval('12345') == 12345
    assert safe_eval('-12345') == -12345
    assert safe_eval('0xFF') == 255
    assert safe_eval('-0xFF') == -255
    assert safe_eval('0123') == 83
    assert safe_eval('1.0') == 1.0
    assert safe_eval('-1.0') == -1.0
    assert safe_eval('1.9e400') == 1.9e400
    assert safe_eval('"foo"') == "foo"
    assert safe_eval("'foo'") == "foo"
    assert safe_eval('b"foo"') == "foo"
    assert safe_eval("b'foo'") == "foo"

# Generated at 2022-06-11 01:49:47.438469
# Unit test for function check_type_int
def test_check_type_int():
    for i in [0,1,2,3,-1,-2,-3]:
        assert type(check_type_int(i))==int
    for i in range(30000,30100):
        assert type(check_type_int(i))==int
    for i in range(-30000,-29900):
        assert type(check_type_int(i))==int
    for i in ["0","1","2","3","-1","-2","-3"]:
        assert type(check_type_int(i))==int
    for i in ["30000","30001","30002","30003","-30000","-30001","-30002","-30003"]:
        assert type(check_type_int(i))==int

# Generated at 2022-06-11 01:49:48.048607
# Unit test for function check_type_int
def test_check_type_int():
    pass


# Generated at 2022-06-11 01:50:00.453119
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1+1') == 2
    assert safe_eval('{"a": 1}') == {"a": 1}
    assert safe_eval('"abc"') == "abc"
    assert safe_eval('[123]') == [123]
    assert safe_eval('import datetime') == 'import datetime'
    assert safe_eval('array.array(123,456)') == 'array.array(123,456)'
    assert safe_eval(1) == 1
    assert safe_eval(['a']) == ['a']
    assert safe_eval(('a')) == ('a')
    assert safe_eval({'a': 1}) == {'a': 1}
    assert safe_eval(None) is None
    assert safe_eval(('a', 'b')) == ('a', 'b')

# Generated at 2022-06-11 01:50:04.569445
# Unit test for function check_type_int
def test_check_type_int():
    # TODO: implement
    pass


# Generated at 2022-06-11 01:50:14.447737
# Unit test for function check_type_bytes
def test_check_type_bytes():
    '''
    Unit test for function check_type_bytes.
    '''
    # Test 1: value = "8k"
    # Expected result: 8192
    value1 = "8k"
    assert check_type_bytes(value1) == 8192

    # Test 2: value = "8K"
    # Expected result: 8192
    value2 = "8K"
    assert check_type_bytes(value2) == 8192

    # Test 3: value = "8 K"
    # Expected result: 8192
    value3 = "8 K"
    assert check_type_bytes(value3) == 8192

    # Test 4: value = " 8K"
    # Expected result: 8192
    value4 = " 8K"
    assert check_type_bytes(value4) == 8192