

# Generated at 2022-06-11 01:40:38.407040
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
  terms = [['foo', 'bar'], ['baz', 'blippy']]
  parameters = {'foo': 'bah', 'baz': 'ugh'}
  check_mutually_exclusive(terms, parameters)
  try:
      check_mutually_exclusive(terms, {'foo': 'bar', 'baz': 'ugh'})
  except TypeError:
      pass


# Generated at 2022-06-11 01:40:50.065633
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2]') == [1, 2]
    assert safe_eval('{"a": 1}') == {"a": 1}
    assert safe_eval('{"a": [1, 2]}') == {"a": [1, 2]}
    assert safe_eval('{"a": {"b": [1, 2]}}') == {"a": {"b": [1, 2]}}
    assert safe_eval('1') == 1
    assert safe_eval('a') == 'a'
    assert safe_eval('1.0') == 1.0
    assert safe_eval('a') == 'a'
    assert safe_eval('[1, 2] + [1, 2]') == [1, 2]

# Generated at 2022-06-11 01:41:02.558367
# Unit test for function check_type_dict
def test_check_type_dict():
    dict1 = "k1=v1, k2=v2"
    dict2 = "{'k1': 'v1', 'k2': 'v2'}"
    dict3 = "{u'k1': u'v1', u'k2': u'v2'}"
    dict4 = "{\"k1\": \"v1\", \"k2\": \"v2\"}"
    dict5 = "{\"k1\": \"v1\", \"k2\": \"v2\""
    dict6 = "{u'k1': u'v1', u'k2': u'v2}"
    dict7 = "k1:v1, k2:v2"
    dict8 = "{k1: v1, k2: v2}"
    dict9 = "{k1: v1 k2: v2}"

# Generated at 2022-06-11 01:41:06.727803
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    try:
        check_mutually_exclusive(terms=['a', 'b', 'c'], parameters={'a': 1, 'b': 1, 'c': 1})
        assert False
    except TypeError:
        assert True
    except:
        assert False



# Generated at 2022-06-11 01:41:14.126750
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Create a spec
    spec = {
        'a': {'required': True},
        'b': {'required': True},
    }
    # Test
    assert check_required_arguments(spec, {}) == ['a', 'b']
    # Test
    assert check_required_arguments(spec, {'a': 1}) == ['b']
    # Test
    assert check_required_arguments(spec, {'a': 1, 'b': 1}) == []



# Generated at 2022-06-11 01:41:17.695253
# Unit test for function check_type_dict
def test_check_type_dict():
    assert isinstance(check_type_dict("{'a':'b'}"), dict)
    assert isinstance(check_type_dict("['a','b']"), dict)
    assert check_type_dict("{'a':'b'}") == {'a':'b'}

# Generated at 2022-06-11 01:41:28.669914
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_field': {'required': True, 'type': 'str'},
        'optional_field': {'required': False, 'type': 'str'}
    }
    parameters = {'required_field': 'required_field'}
    assert check_required_arguments(argument_spec, parameters) == []

    parameters = {'optional_field': 'optional_field'}
    assert check_required_arguments(argument_spec, parameters) == ['required_field']

    parameters = {}
    assert check_required_arguments(argument_spec, parameters) == ['required_field']



# Generated at 2022-06-11 01:41:39.741153
# Unit test for function check_type_dict
def test_check_type_dict():
    d1 = {}
    d2 = {"key1": "value1", "key2": "value2"}
    d3 = '{"key1": "value1", "key2": "value2"}'
    d4 = 'key1=value1, key2=value2'
    d5 = 'key1 = value1, key2 = value2'
    d6 = 'key1 = value1, key2 = value2, key3 = value3'
    d7 = "key1 = value1, key2 = {'key3': 'value3'}"
    d8 = 'key1 = "value1", key2 ='
    d9 = 'key1 = "\\"value1\\"", key2 ='

    assert check_type_dict(d1) == d1
    assert check_type_dict(d2)

# Generated at 2022-06-11 01:41:46.402253
# Unit test for function safe_eval
def test_safe_eval():
    data_values = dict(
        # boolean
        a=True,
        b=False,
        # integer
        c=10,
        d=15,
        # list
        e=[1, 2, 3, 4],
        f=[1, 2, 3, 4],
        # dict
        g=dict(a=10, b=20, c=30),
        h=dict(a=10, b=20, c=30),
        # string
        i='hello world',
        j='hello world',
        # json string
        k='{"a": 5, "b": 10}',
        l='{"a": 5, "b": 10}',
    )
    for data in data_values.keys():
        value, exception = safe_eval(data, include_exceptions=True)

# Generated at 2022-06-11 01:41:58.946768
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {
        'key_1': 'required_1',
        'key_2': ['required_1', 'required_2']
    }
    parameters = {
        'key_1': 'param_1',
        'key_2': 'param_2',
        'key_3': 'param_3',
        'required_1': 'req_1',
        'required_2': 'req_2'
    }
    result = check_required_by(requirements, parameters)
    assert not result

    del parameters['required_1']
    result = check_required_by(requirements, parameters)
    assert len(result.keys()) == 2
    assert len(result['key_1']) == 1
    assert result['key_1'][0] == 'required_1'

# Generated at 2022-06-11 01:42:20.050706
# Unit test for function check_required_if
def test_check_required_if():
    # Test check_required_if function with one check and all requirements should be present
    requirements = [['foo', 'bar', ('requirement1', 'requirement2')]]

    # Test missing all requirements
    parameters = {'foo': 'bar'}
    try:
        check_required_if(requirements, parameters)
    except TypeError as e:
        assert 'all of the following are missing' in str(e)
        assert 'requirement1' in str(e)
        assert 'requirement2' in str(e)

    # Test all requirements are present
    parameters = {'foo': 'bar', 'requirement1': 'foo', 'requirement2': 'bar'}
    check_required_if(requirements, parameters)

    # Test check_required_if function with one check and at least one requirement should be present
    requirements

# Generated at 2022-06-11 01:42:22.612691
# Unit test for function check_type_bytes
def test_check_type_bytes():
    result = check_type_bytes('1kb')
    assert result == 1024, "1kb is 1024"
    result = check_type_bytes('1giB')
    assert result == 1024*1024*1024, "1giB is 1073741824"



# Generated at 2022-06-11 01:42:27.824698
# Unit test for function check_required_together
def test_check_required_together():
    parameters = dict(user='root',
                      password='password',
                      status='status')
    terms = []
    terms.append(['user', 'password'])
    terms.append(['password', 'status'])
    terms.append(['status', 'user', 'password'])
    assert len(terms) == check_required_together(terms, parameters)



# Generated at 2022-06-11 01:42:35.392801
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ['path',], True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state':'present', 'someint':'99', 'bool_param':'true'}
    test_options_context = ['test_options_context']

# Generated at 2022-06-11 01:42:37.569279
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576

# end



# Generated at 2022-06-11 01:42:49.633063
# Unit test for function check_required_by
def test_check_required_by():
    # Case 1: no requirements, no error
    assert check_required_by(requirements=None, parameters={'a': 1, 'b': 2}) == {}

    # Case 2: requirements, none of them in parameters, no error
    assert check_required_by(requirements={'a': ['c', 'd']}, parameters={'b': 2}) == {}

    # Case 3: requirements, only one of them in parameters, no error
    assert check_required_by(requirements={'a': ['c', 'd']}, parameters={'a': 1, 'b': 2}) == {}

    # Case 4: requirements, error

# Generated at 2022-06-11 01:42:57.858610
# Unit test for function check_required_if
def test_check_required_if():
    # Test for all requirements should be present
    all_req_parameters = dict(
        someint=99,
        bool_param=True,
        string_param='hello'
    )
    all_req_requirements = [
        ['someint', 99, ('bool_param', 'string_param')]
    ]

    try:
        check_required_if(all_req_requirements, dict(someint=99), options_context=['test'])
        assert False
    except TypeError as e:
        assert "is 99 but all of the following are missing: bool_param, string_param found in test" == str(
            e)

# Generated at 2022-06-11 01:43:06.141827
# Unit test for function check_required_if
def test_check_required_if():
    from ansible_collections.netapp.home.plugins.module_utils.netapp import NaElement
    required_if = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
        ['someint', 99, ('bool_param', 'string_param'), True],
    ]
    parameters = {'path': 'value', 'someint': 99, 'bool_param': 'value'}
    check_required_if(required_if, parameters)
    parameters = {'path': 'value', 'someint': 99, 'bool_param': 'value', 'string_param': 'value'}
    check_required_if(required_if, parameters)

# Generated at 2022-06-11 01:43:18.355557
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    test_dict = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}
    test_case1 = [['key1', 'key2']]
    test_case2 = [['key1', 'key2'], ['key2', 'key3'], ['key3', 'key1'], ['key1', 'key3']]
    test_case3 = [['key1', 'key2'], ['key2', 'key3'], ['key3', 'key1']]


# Generated at 2022-06-11 01:43:31.017261
# Unit test for function safe_eval
def test_safe_eval():
    a = safe_eval('1 + 1')
    assert a == 2

    a = safe_eval("['a', 'b', 'c']")
    assert a == ['a', 'b', 'c']

    a = safe_eval('{"key": "value"}')
    assert a == {'key': 'value'}

    a = safe_eval("('a', 'b', 'c')")
    assert a == ('a', 'b', 'c')

    a = safe_eval("{'a', 'b', 'c'}")
    assert a == {'a', 'b', 'c'}

    a = safe_eval("1")
    assert a == 1

    a = safe_eval("1.3")
    assert a == 1.3

    a = safe_eval("True")
    assert a


# Generated at 2022-06-11 01:43:49.565284
# Unit test for function safe_eval
def test_safe_eval():
    # Test 1: Safe eval with non-string data
    test_result_1 = (safe_eval(["test_data"]), None)
    assert test_result_1 == (["test_data"], None)

    # Test 2: Safe eval with import
    bad_eval_2 = "import os"
    test_result_2 = (safe_eval(bad_eval_2), None)
    assert test_result_2 == (bad_eval_2, None)

    # Test 3: Safe eval with method call
    bad_eval_3 = "os.system('ls')"
    test_result_3 = (safe_eval(bad_eval_3), None)
    assert test_result_3 == (bad_eval_3, None)

    # Test 4: Safe eval with normal string

# Generated at 2022-06-11 01:43:59.258334
# Unit test for function safe_eval
def test_safe_eval():
    # safe_eval should return original string when called with a string containing method calls or imports.
    assert safe_eval('foo.bar') == 'foo.bar'
    assert safe_eval('foo.bar(a=1)') == 'foo.bar(a=1)'
    assert safe_eval('import foo') == 'import foo'

    # Function safe_eval should return a list when called with a string containing a list.
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]

    # Function safe_eval should return a dict when called with a string containing a dict.
    assert safe_eval('{1: 1}') == {1: 1}

    # Function safe_eval should return the original string when called with a string containing unacceptable syntax.
    assert safe_eval('foo') == 'foo'
    assert safe_

# Generated at 2022-06-11 01:44:06.095086
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {
        'a': 'foo',
        'b': 'bar',
    }
    missing_params = []
    required_parameters = ['a', 'b']
    for param in required_parameters:
        if not parameters.get(param):
            missing_params.append(param)
    if missing_params:
        msg = "missing required arguments: %s" % ', '.join(missing_params)
        raise TypeError(to_native(msg))


# Generated at 2022-06-11 01:44:09.380817
# Unit test for function safe_eval
def test_safe_eval():
    safe_eval("0")
    safe_eval("1")
    safe_eval("'a'")
    safe_eval("'a'.strip()")



# Generated at 2022-06-11 01:44:21.653855
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = dict()
    required_parameters = ['hello', 'world', 'ansible']
    result = check_missing_parameters(parameters, required_parameters)
    assert result == required_parameters
    parameters = dict()
    parameters['hello'] = 'world'
    required_parameters = ['hello', 'world', 'ansible']
    result = check_missing_parameters(parameters, required_parameters)
    assert result == ['world', 'ansible']
    parameters = dict()
    parameters['hello'] = 'world'
    parameters['ansible'] = 'rocks'
    required_parameters = ['hello', 'world', 'ansible']
    result = check_missing_parameters(parameters, required_parameters)
    assert result == ['world']
    parameters = dict()

# Generated at 2022-06-11 01:44:30.540941
# Unit test for function safe_eval
def test_safe_eval():
    # Test for each type of allowed input, then test for each type of disallowed input
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('"foo"', include_exceptions=True) == ('foo', None)
    assert safe_eval('b"foo"') == b'foo'
    assert safe_eval('b"foo"', include_exceptions=True) == (b'foo', None)
    assert safe_eval('["foo", "bar"]') == ['foo', 'bar']
    assert safe_eval('["foo", "bar"]', include_exceptions=True) == (['foo', 'bar'], None)
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('{"foo": "bar"}', include_exceptions=True)

# Generated at 2022-06-11 01:44:35.975354
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1b') == 1
    assert check_type_bits('1') == 1


# Generated at 2022-06-11 01:44:40.914008
# Unit test for function check_required_together
def test_check_required_together():
    # success
    parameters = {"a": "1", "b": "2"}
    terms = [["a", "b"]]
    check_required_together(terms, parameters)

    # failure
    parameters = {"a": "1", "b": "2"}
    terms = [["a", "b"], ["c", "d"]]
    check_required_together(terms, parameters)


# Generated at 2022-06-11 01:44:52.661725
# Unit test for function safe_eval
def test_safe_eval():
    from random import random
    from os import makedirs, path
    import tempfile
    from tempfile import NamedTemporaryFile
    import json

    test_results = []

    rand_function_names = []
    rand_function_passes = []

    rand_module_names = []
    rand_module_passes = []

    rand_full_eval_list = []
    rand_full_eval_passes = []

    # Create random function to check

# Generated at 2022-06-11 01:44:53.996523
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-11 01:45:07.652782
# Unit test for function check_required_together
def test_check_required_together():
    import pytest
    valid_terms = [
                    ['a', 'b'],
                    ('a', 'b'),
                    (['a', 'b'],['c']),
                    ['a', 'b', 'c']
                  ]
    parameters = dict(a=1, b=2, c=3)
    for term in valid_terms:
        assert check_required_together(term, parameters) == []

    invalid_terms =   [
                        ['d', 'b'],
                        ('d', 'b'),
                        ['a', 'b', 'd']
                     ]
    for term in invalid_terms:
        with pytest.raises(TypeError):
            check_required_together(term, parameters)


# Generated at 2022-06-11 01:45:18.509258
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1kb') == 1024
    assert check_type_bytes('1mb') == 1048576
    assert check_type_bytes('1gb') == 1073741824
    assert check_type_bytes('1tb') == 1099511627776
    assert check_type_bytes('1KiB') == 1024
    assert check_type_bytes('1MiB') == 1048576
    assert check_type_bytes('1GiB') == 1073741824
    assert check_type_bytes('1TiB') == 1099511627776
    assert check_type_bytes('1 byte') == 1
    assert check_type_bytes('1 kilobyte') == 1024
    assert check_type_bytes('1 megabyte') == 1048576
    assert check_type_bytes('1 gigabyte') == 10737418

# Generated at 2022-06-11 01:45:26.700275
# Unit test for function check_type_bits
def test_check_type_bits():
    try:
        print ("Testing check_type_bits...")
        assert check_type_bits('1Mb') == 1048576
        print ("Test success. Result: %d" % check_type_bits('1Mb'))
    except AssertionError as e:
        print ("check_type_bits function test FAILED")

# Generated at 2022-06-11 01:45:37.751347
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float("1.1") == 1.1
    assert check_type_float("-12.3") == -12.3
    assert check_type_float("0") == 0.0
    assert check_type_float("0.0") == 0.0
    assert check_type_float(1) == 1.0
    assert check_type_float(-1) == -1.0
    assert check_type_float(1.1) == 1.1
    assert check_type_float(-12.3) == -12.3
    assert check_type_float(0) == 0.0
    assert check_type_float(0.0) == 0.0
    assert check_type_float(1) == 1.0
    assert check_type_float(-1) == -1.0

# Generated at 2022-06-11 01:45:48.958307
# Unit test for function check_required_arguments
def test_check_required_arguments():
    check_required_arguments({}, {})
    check_required_arguments({'foo': {'required': False}}, {})
    check_required_arguments({'foo': {'required': False}}, {'foo': None})
    check_required_arguments({'foo': {'required': False}}, {'bar': None})

    with pytest.raises(TypeError) as excinfo:
        message = "missing required arguments: foo"
        check_required_arguments({'foo': {'required': True}}, {})
    assert str(excinfo.value) == message

    with pytest.raises(TypeError) as excinfo:
        message = "missing required arguments: bar, foo"
        check_required_arguments({'foo': {'required': True}}, {'bar': None})

# Generated at 2022-06-11 01:45:56.795929
# Unit test for function check_required_together
def test_check_required_together():
    p = dict()
    p['a'] = "a"
    p['b'] = "b"
    p['c'] = "c"
    # t1 is a list consisting of lists.
    # Each list contains terms that are required together
    t1 = [["a", "b", "c"]]
    t2 = [["d", "e", "f"]]
    # p contains all the terms of the first list
    assert check_required_together(t1, p) == []
    # p does not contain a term from the second list so failure expected
    assert check_required_together(t2, p) == t2



# Generated at 2022-06-11 01:46:00.799185
# Unit test for function check_type_float
def test_check_type_float():
    # Test if function returns correct type of float
    assert type(check_type_float(1.5)) == float
    assert check_type_float(1.5) == 1.5
    # Test if function returns correct type of float
    assert type(check_type_float(1)) == float
    assert check_type_float(1) == 1.0
    # Test if function returns correct type of float
    assert type(check_type_float('1.5')) == float
    assert check_type_float('1.5') == 1.5
    # Test if function raises error on unknown input
    with pytest.raises(TypeError):
        check_type_float(None)
#end of unit test for function check_type_float



# Generated at 2022-06-11 01:46:07.499494
# Unit test for function check_type_float
def test_check_type_float():
    # Test float
    # int_value = 10
    assert float(10) == check_type_float(10)
    # str_value = '10'
    assert float(10) == check_type_float('10')
    # float_value = 10.00
    assert float(10.00) == check_type_float(10.00)
    # Special case where a float is a str where the format is int.0
    assert float(10.0) == check_type_float(10.0)

    # Test exception
    assert '10.01' == check_type_float('test')


# Generated at 2022-06-11 01:46:16.342074
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = dict(
        foo=dict(type='str', required=True),
        bar=dict(type='str', required=False)
    )
    params = dict(
        foo='boo'
    )
    assert not check_required_arguments(argument_spec, params)

    params = dict(
        bar='bar'
    )
    try:
        check_required_arguments(argument_spec, params)
        assert False
    except Exception as e:
        assert str(e).startswith('missing required arguments:')



# Generated at 2022-06-11 01:46:17.976181
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-11 01:46:31.471924
# Unit test for function check_required_together
def test_check_required_together():
    terms = [["field1", "field2"], ["field3", "field4", "field5"]]
    parameters = {"field1": "abc", "field3": "cde", "field4": "efg"}
    options_context = ["subspec_1", "subspec_2"]
    assert check_required_together(terms, parameters, options_context) == []

    parameters = {"field1": "abc", "field3": "cde"}
    assert check_required_together(terms, parameters, options_context) == [["field3", "field4", "field5"]]



# Generated at 2022-06-11 01:46:41.610759
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(7) == 7
    assert check_type_int('7') == 7
    try:
        check_type_int('not-int')
    except TypeError as e:
        assert "not-int cannot be converted to an int" == str(e)
    else:
        assert False, "Should raise a TypeError"
    try:
        check_type_int([1,2,3])
    except TypeError as e:
        assert "[1, 2, 3] cannot be converted to an int" == str(e)
    else:
        assert False, "Should raise a TypeError"
    try:
        check_type_int({'a':1})
    except TypeError as e:
        assert "{'a': 1} cannot be converted to an int" == str(e)

# Generated at 2022-06-11 01:46:53.587680
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('b""') == b''
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('[1]') == [1]
    assert safe_eval('(1,)') == (1,)
    assert safe_eval('{"a": 1}') == {"a": 1}
    assert safe_eval('{"a": "{{test}}"}', dict(test='test')) == {"a": "test"}
    assert isinstance(safe_eval('"a"'), string_types)
    assert isinstance(safe_eval('u"a"'), string_types)
    assert safe_eval('b"a"') == b'a'

# Generated at 2022-06-11 01:46:59.049222
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits("1mb") == 8388608
    assert check_type_bits("1pb") == 1125899906842624
    try:
        assert check_type_bits("1tb")
    except TypeError:
        pass
    else:
        assert False, "check_type_bits TypeError exception not raised"


# Generated at 2022-06-11 01:47:07.939777
# Unit test for function check_required_together
def test_check_required_together():
    from nose2.tools import params

# Generated at 2022-06-11 01:47:15.073480
# Unit test for function check_type_float
def test_check_type_float():
    """Test whether the given value can be converted to a float,
    no matter the data type.
    """
    for value in [12345, 12345.0, "12345", "12345.0", b"12345", b"12345.0"]:
        assert isinstance(check_type_float(value), float)

    # ValueError: Invalid literal for int() with base 10: 'a'
    with pytest.raises(TypeError):
        check_type_float('a')



# Generated at 2022-06-11 01:47:15.615877
# Unit test for function check_required_together
def test_check_required_together():
    True



# Generated at 2022-06-11 01:47:21.446313
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('4k') == 4096
    assert check_type_bytes('4K') == 4096
    assert check_type_bytes('4kb') == 4096
    assert check_type_bytes('4KB') == 4096
    assert check_type_bytes('4m') == 4194304
    assert check_type_bytes('1M') == 1048576



# Generated at 2022-06-11 01:47:29.037164
# Unit test for function check_required_arguments
def test_check_required_arguments():
    module_arg_spec = {
        'required_param1': {
            'type': 'str',
            'required': True,
        },
        'optional_param1': {
            'type': 'str',
        },
    }
    missing = check_required_arguments(module_arg_spec, {"required_param1": "present"})
    assert missing == []
    missing = check_required_arguments(module_arg_spec, {"required_param1": "present", "optional_param1": "present"})
    assert missing == []
    try:
        missing = check_required_arguments(module_arg_spec, {"optional_param1": "present"})
    except TypeError as e:
        assert to_native(e) == "missing required arguments: required_param1"

# Generated at 2022-06-11 01:47:38.195507
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("1") == 1
    assert safe_eval("1.2") == 1.2
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("'string'") == 'string'
    # make sure safe_eval doesn't allow method calls to modules
    assert safe_eval('.split(') == '.split('
    assert safe_eval('os.path') == 'os.path'
    assert safe_eval('os.path.split(') == 'os.path.split('
    # make sure safe_eval doesn't allow imports
    assert safe_eval('import json') == 'import json'

# Generated at 2022-06-11 01:47:53.035803
# Unit test for function check_required_by
def test_check_required_by():
    for req in {'foo':['bar','baz'],'moo':'cow','moo2':'cow'}:
        for param in {'foo':'foo','moo':'moo'}:
            assert check_required_by(requirements, parameters) == {}
    for req in {'foo':['bar','baz'],'moo':'cow','moo2':'cow'}:
        for param in {'foo':'foo'}:
            assert check_required_by(requirements, parameters) == {'foo':['bar','baz']}

# Generated at 2022-06-11 01:48:02.026541
# Unit test for function check_type_bytes
def test_check_type_bytes():
    values = [
        ['1g', 1024*1024*1024],
        ['1m', 1024*1024],
        ['1k', 1024],
        ['1', 1],
        ['1b', 1],
        ['2.2k', 2.2*1024],
        ['.2m', 200000],
        ['1.1m', 1.1*1024*1024],
        ['2.2g', 2.2*1024*1024*1024],
    ]
    for (val, expected) in values:
        assert check_type_bytes(val) == expected



# Generated at 2022-06-11 01:48:05.238435
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(4) == 4
    assert check_type_int(4.5) != 4.5
    assert check_type_int("4") == 4


# Generated at 2022-06-11 01:48:15.758909
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by({'a': 'b', 'c': 'd'}, {}) == {}
    assert check_required_by({'a': ['c', 'd']}, {'a': 'x'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'x', 'b': 'y'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'x', 'c': 'y'}) == {'a': ['b']}
    assert check_required_by({'a': ['b', 'c']}, {'a': 'x', 'c': 'y'}) == {'a': ['b']}

# Generated at 2022-06-11 01:48:23.163580
# Unit test for function check_type_bytes
def test_check_type_bytes():
    ''' test class check_type_bytes '''
    assert '100b' == check_type_bytes('100b')
    assert '1000b' == check_type_bytes('1000b')
    assert '1kb' == check_type_bytes('1kb')
    assert '1K' == check_type_bytes('1K')
    assert '1Kb' == check_type_bytes('1Kb')
    assert '1mb' == check_type_bytes('1mb')
    assert '1m' == check_type_bytes('1m')
    assert '1M' == check_type_bytes('1M')
    assert '1Mb' == check_type_bytes('1Mb')
    assert '1gb' == check_type_bytes('1gb')
    assert '1g' == check_type_bytes

# Generated at 2022-06-11 01:48:33.490560
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('[1,2,3]', include_exceptions=True) == ([1, 2, 3], None)
    assert safe_eval('[1,2,3', include_exceptions=True) == ('[1,2,3', None)
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo', include_exceptions=True) == ('foo', None)
    assert safe_eval('import foo', include_exceptions=True) == ('import foo', None)
    assert safe_eval('foo.bar()', include_exceptions=True) == ('foo.bar()', None)



# Generated at 2022-06-11 01:48:36.948718
# Unit test for function check_required_one_of
def test_check_required_one_of():
    params = {}
    result = check_required_one_of([["one", "two"], ["three", "four"]], params, ["eiq", "qeq", "qeq"])
    assert result == [["three", "four"]]


# Generated at 2022-06-11 01:48:47.099078
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # test with invalid terms
    terms = ['ip', 'ipv4', 'ipv6']
    parameters = {'ip': '10.10.10.10', 'ipv4': '10.10.10.10', 'ipv6': '::1'}
    options_context = ['provider']
    the_check = check_mutually_exclusive(terms, parameters, options_context)
    assert len(the_check) == 3
    assert 'ip' in the_check
    assert 'ipv4' in the_check
    assert 'ipv6' in the_check

    # test with valid terms
    terms = ['ip', 'ipv4', 'ipv6']

# Generated at 2022-06-11 01:48:59.673558
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(1) == b'1'
    assert check_type_bytes('1') == b'1'
    assert check_type_bytes('1b') == b'1b'
    assert check_type_bytes('1kb') == b'1024'
    assert check_type_bytes('1mb') == b'1048576'
    assert check_type_bytes('1gb') == b'1073741824'
    assert check_type_bytes('1tb') == b'1099511627776'
    assert check_type_bytes('1K') == b'1024'
    assert check_type_bytes('1M') == b'1048576'
    assert check_type_bytes('1G') == b'1073741824'

# Generated at 2022-06-11 01:49:07.204431
# Unit test for function check_required_by
def test_check_required_by():
    try:
        assert check_required_by({'a': 'b'}, {'a': True}) == {}
        assert check_required_by({'a': ['b', 'c']}, {'a': True, 'b': True}) == {}
        assert check_required_by({'a': ['b', 'c']}, {'a': True, 'c': True}) == {}
        assert check_required_by({'a': ['b', 'c']}, {'a': True}) == {'a': ['b', 'c']}
        assert check_required_by({'a': ['b', 'c']}, {'a': True, 'b': True, 'c': False}) == {}
    except Exception:
        raise AssertionError


# Generated at 2022-06-11 01:49:23.278070
# Unit test for function check_required_arguments
def test_check_required_arguments():  # pylint: disable=unused-variable
    from ansible.module_utils.common.validation import check_required_arguments

    # All required arguments present
    argument_spec = {
        'required1': {'required': True},
        'required2': {'required': True},
        'not_required': {'required': False},
    }
    parameters = {
        'required1': 'anything',
        'required2': 'anything',
    }
    assert check_required_arguments(argument_spec, parameters) == []

    # Missing required arguments
    parameters_missing_required = {
        'required1': 'anything',
    }
    assert check_required_arguments(argument_spec, parameters_missing_required) == ['required2']

    # The keys in argument_spec and parameters do not match
    parameters

# Generated at 2022-06-11 01:49:23.907035
# Unit test for function check_required_by
def test_check_required_by():
    pass



# Generated at 2022-06-11 01:49:35.619041
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('100') == 100
    assert check_type_bytes('100b') == 100
    assert check_type_bytes('100k') == 102400
    assert check_type_bytes('100kb') == 102400
    assert check_type_bytes('100m') == 104857600
    assert check_type_bytes('100mb') == 104857600
    assert check_type_bytes('100g') == 107374182400
    assert check_type_bytes('100gb') == 107374182400
    assert check_type_bytes('100t') == 109951162777600
    assert check_type_bytes('100tb') == 109951162777600
    assert check_type_bytes('100p') == 112589990684262400

# Generated at 2022-06-11 01:49:46.947926
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # Check that check_required_one_of works as expected when given invalid
    # values.
    assert check_required_one_of(None, None) == []

    assert check_required_one_of([None], None) == []

    assert check_required_one_of([[None]], None) == []

    # Check that check_required_one_of returns the right value when given valid
    # values.
    try:
        check_required_one_of([["foo", "bar"]], None)
    except TypeError:
        assert False, "Should not raise TypeError when given valid values."
    except:
        assert False, "Should not raise any other exception when given valid values."


# Generated at 2022-06-11 01:49:53.686612
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes("2k") == 2048
    assert check_type_bytes("3m") == 3145728
    assert check_type_bytes("4g") == 4294967296
    assert check_type_bytes("5t") == 549755813888
    assert check_type_bytes("9p") == 1125899906842624
    assert check_type_bytes("10e") == 1152921504606846976


# Generated at 2022-06-11 01:50:05.610381
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['x','y'],['y','z']]
    parameters = {'x': True, 'y': True, 'z': True}
    try:
        check_required_together(terms,parameters)
        assert True
    except:
        assert False
    try:
        parameters = {'x': False, 'y': False, 'z': False}
        check_required_together(terms,parameters)
        assert True
    except:
        assert False
    try:
        parameters = {'x': False, 'y': False}
        check_required_together(terms,parameters)
        assert True
    except:
        assert False

# Generated at 2022-06-11 01:50:15.615690
# Unit test for function check_type_dict