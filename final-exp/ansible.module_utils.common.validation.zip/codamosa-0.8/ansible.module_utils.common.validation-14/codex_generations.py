

# Generated at 2022-06-11 01:40:36.920405
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
            'state': 'present',
            'path': 'path', 
            'someint': 99,
            'bool_param': True
    }
    options_context = None
    res = check_required_if(requirements, parameters, options_context)


# Generated at 2022-06-11 01:40:48.314627
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together(
        [('a', 'b')],
        {'a': 1, 'b': 1}
    ) == []

    assert check_required_together(
        [('a', 'b')],
        {'a': 1}
    ) == [('a', 'b')]

    assert check_required_together(
        [('a', 'b')],
        {'b': 1}
    ) == [('a', 'b')]

    assert check_required_together(
        [('a', 'b')],
        {}
    ) == [('a', 'b')]

    assert check_required_together(
        [('a', 'b'), ('c', 'd')],
        {'a': 1, 'b': 1}
    ) == [('c', 'd')]



# Generated at 2022-06-11 01:40:55.565076
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    """Unit test for function check_missing_parameters.
    """
    assert check_missing_parameters(
        {'param1': 10}, None) == []
    assert check_missing_parameters(
        {'param1': 10, 'param2': 20}, ['param1', 'param2', 'param3']) == ['param3']
    try:
        check_missing_parameters({'param1': 10}, ['param2', 'param3'])
        assert False, "An exception should have been raised"
    except TypeError as e:
        assert "missing required arguments: param2, param3" == str(e)
    except:
        assert False, "Unexpected exception raised"



# Generated at 2022-06-11 01:41:07.422415
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {
        'host': 'hostname',
        'port': ['hostname', 'portname'],
        'type': ['hostname', 'portname', 'type'],
    }
    parameters1 = {
        'hostname': 'host',
        'portname': 'port',
        'host': 'host',
        'port': 'port'
    }
    assert check_required_by(requirements, parameters1) == {}
    parameters2 = {
        'hostname': 'host',
        'portname': 'port',
        'host': 'host',
        'port': 'port',
    }
    assert check_required_by(requirements, parameters2) == {}

# Generated at 2022-06-11 01:41:18.055086
# Unit test for function check_required_if
def test_check_required_if():
    """Test for function check_required_if"""
    def _check_required_if(requirements, parameters, expected_result, fail_msg):
        """Internal function to execute check_required_if and test the result"""
        try:
            result = check_required_if(requirements, parameters, None)
        except TypeError:
            if expected_result is None:
                return True
            raise Exception("{0} expected: {1}, actual: None".format(fail_msg, str(expected_result)))
        except Exception as exception:
            raise Exception("{0} unexpected exception: {1}".format(fail_msg, str(exception)))


# Generated at 2022-06-11 01:41:30.753608
# Unit test for function check_required_if
def test_check_required_if():
    parameters = {'state': 'present', 'a': 'b'}
    result = check_required_if([['state', 'present', ('path',), True]], parameters)
    assert result == []

    parameters = {'state': 'present', 'path': '/tmp'}
    result = check_required_if([['state', 'present', ('path',), True]], parameters)
    assert result == []

    parameters = {'state': 'present', 'a': 'b'}
    with pytest.raises(TypeError):
        check_required_if([['state', 'present', ('path',), False]], parameters)

    parameters = {'state': 'present', 'a': 'b', 'path': '/tmp', 'other': 'val'}

# Generated at 2022-06-11 01:41:41.710437
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Setup of parameters and argument_spec dictionaries
    parameters = {}
    argument_spec = {}

    # Setup of ArgumentSpec object
    class ArgumentSpec(object):
        def __init__(self):
            self.argument_spec = argument_spec

    # test that an empty parameter and argument_spec dictionary results in
    # an empty list
    assert not check_required_arguments(argument_spec, parameters)

    # test that a single required argument results in a TypeError being raised
    argument_spec = {
        'required': {
            'required': True,
            'type': 'str',
        },
    }
    try:
        check_required_arguments(argument_spec, parameters, options_context=None)
    except TypeError:
        pass

    # test that a single required argument in the parameters results in an
    #

# Generated at 2022-06-11 01:41:43.937905
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {}
    parameters['DEBUG'] = True
    parameters['ANSIBLE_LOG'] = '/path/to/log_file'
    check_required_together([['DEBUG', 'ANSIBLE_LOG']], parameters)



# Generated at 2022-06-11 01:41:56.026307
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("5") == 5
    assert safe_eval("'5'") == '5'
    assert safe_eval("'5'", include_exceptions=True) == ('5', None)
    assert safe_eval("b'5'", include_exceptions=True) == (b'5', None)
    assert safe_eval("b'5'") == b'5'
    assert safe_eval("['5']") == ['5']
    assert isinstance(safe_eval("['5']"), list)
    assert safe_eval("{'a': '5'}") == {'a': '5'}
    assert isinstance(safe_eval("['5']"), list)
    assert safe_eval("{'a': '5'}") == {'a': '5'}

# Generated at 2022-06-11 01:42:00.466299
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1gb') == 1073741824
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1b') == 1



# Generated at 2022-06-11 01:42:17.483298
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("10") == 10
    assert safe_eval("['abc', 'def']") == ['abc', 'def']
    assert safe_eval("['abc', 'def']", include_exceptions=True) == (['abc', 'def'], None)
    assert safe_eval("['abc', 'def']", include_exceptions=True)[0] == ['abc', 'def']
    assert safe_eval("['abc', 'def']", include_exceptions=True)[1] is None
    assert safe_eval("foo.bar()") == "foo.bar()"
    assert safe_eval("import foo") == "import foo"
    assert safe_eval("import foo", include_exceptions=True) == ("import foo", None)

# Generated at 2022-06-11 01:42:29.721075
# Unit test for function check_required_one_of
def test_check_required_one_of():

    parameters = {'a': 'A', 'b': 'B', 'c': 'C'}

    # Check that a single list works
    terms = [['a', 'b']]
    try:
        check_required_one_of(terms, parameters)
    except:
        assert False

    # Check that two lists works
    terms = [['a', 'b'], ['c', 'd']]
    try:
        check_required_one_of(terms, parameters)
    except:
        assert False

    # Check that a single tuple works
    terms = [('a', 'b')]
    try:
        check_required_one_of(terms, parameters)
    except:
        assert False

    # Check that two tuples works
    terms = [('a', 'b'), ('c', 'd')]
   

# Generated at 2022-06-11 01:42:38.843780
# Unit test for function safe_eval
def test_safe_eval():
    # test simple case
    result = safe_eval('[1,2,3]')
    assert isinstance(result, list)

    # test case with exception
    result = safe_eval(None)
    assert result is None

    # test result and exception
    result, exception = safe_eval('[1,2,3]', include_exceptions=True)
    assert isinstance(result, list)
    assert exception is None

    # test result and exception
    result, exception = safe_eval(None, include_exceptions=True)
    assert result is None
    assert exception is None

    # test importing
    result = safe_eval('import qwe')
    assert result == 'import qwe'


# Generated at 2022-06-11 01:42:42.159034
# Unit test for function check_type_dict
def test_check_type_dict():
    d = check_type_dict('k1=v1, k2=v2')
    assert d == {'k1': 'v1', 'k2': 'v2'}



# Generated at 2022-06-11 01:42:47.160235
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(5.34) == 5.34
    assert check_type_float(5) == 5.0
    assert check_type_float('5.34') == 5.34
    assert check_type_float('5') == 5.0


# Generated at 2022-06-11 01:42:52.525488
# Unit test for function check_required_by
def test_check_required_by():
    # Good case
    options = {'name': 'foo', 'type': 'file', 'state': 'absent'}
    check_required_by({'name': ['type', 'state']}, options)

    # Bad case
    try:
        check_required_by({'name': ['type']}, options)
        assert(False)
    except TypeError:
        pass



# Generated at 2022-06-11 01:43:04.855459
# Unit test for function check_required_if
def test_check_required_if():
    ret = check_required_if([
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')]
    ], {'state': 'present', 'someint': 99})

    assert ret == [
        {
            'parameter': 'someint',
            'value': 99,
            'requirements': ('bool_param', 'string_param'),
            'missing': ['bool_param', 'string_param'],
            'requires': 'all'
        }
    ]

    ret = check_required_if([
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')]
    ], {'state': 'present', 'someint': 99, 'string_param': 'test'})



# Generated at 2022-06-11 01:43:17.633616
# Unit test for function check_type_dict
def test_check_type_dict():
    from ansible.utils import module_docs
    from ansible.utils.display import Display
    display = Display()
    # use the documentation from the ansible module,
    # because it's a multi-line string that does not have double quotes
    # and tests for that
    temp_dict, temp_type = module_docs.get_docstring(None, display)
    temp_dict = check_type_dict(temp_dict)
    assert isinstance(temp_dict, dict)
    assert 'options' in temp_dict
    assert isinstance(temp_dict['options'], list)
    options = temp_dict['options']
    assert len(options) > 0
    # select the first option that has 'choices' in it
    option = next((x for x in options if 'choices' in x), None)

# Generated at 2022-06-11 01:43:18.669736
# Unit test for function check_required_arguments
def test_check_required_arguments():
    check_required_arguments(argument_spec, options)



# Generated at 2022-06-11 01:43:31.412355
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('foo') == 'foo'
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('{}') == {}
    assert safe_eval('[]') == []
    assert safe_eval('(1,)') == (1,)
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('"foo" + "bar"') == 'foobar'
    assert safe_eval('"foo" * 3') == 'foofoofoo'
    assert safe_eval('u"foo"') == u'foo'
    assert safe_eval('a, b = 1, 2') == (1, 2)

# Generated at 2022-06-11 01:43:47.441765
# Unit test for function check_required_together
def test_check_required_together():
    # For testing purpose, using the following nested dict structure
    #  {
    #    "top_level_key": {
    #        "key_1": <value>,
    #        "key_2": <value>,
    #        ...
    #        "key_n": <value>,
    #    }
    #  }

    # Case 1: Check top_level_key with each list of terms.
    #         Each list should include parameters that are all required
    #         when at least one is specified in the parameters.
    top_level_key = dict()
    top_level_key["key_1"] = "foo"
    top_level_key["key_2"] = "foo"

    # Case 1.1: None value is not allowed
    terms = [[None]]
    parameters = top_level_key
    options

# Generated at 2022-06-11 01:43:58.036272
# Unit test for function check_required_one_of
def test_check_required_one_of():
    try:
        check_required_one_of([["a", "b"]], {"c": None})
    except TypeError as e:
        assert "required" in str(e)
    else:
        assert False, "check_required_one_of failed to fail"

    try:
        check_required_one_of([(1, 2)], {"c": None})
    except TypeError as e:
        assert "required" in str(e)
    else:
        assert False, "check_required_one_of failed to fail"

    try:
        check_required_one_of(["a", "b"], {"a": None})
    except TypeError as e:
        assert "required" in str(e)
    else:
        assert False, "check_required_one_of failed to fail"

    return True

# Generated at 2022-06-11 01:44:07.952877
# Unit test for function check_required_by
def test_check_required_by():
    """ Test check_required_by function
    """

    parameters = {
        'access_mode': "vpc-only",
        'access_key': "abc",
        'secret_key': "def"
    }

    requirements = {
        'access_mode': 'access_key',
        'access_key': 'secret_key'
    }
    msg = check_required_by(requirements, parameters)
    assert msg == {}
    requirements = {
        'access_mode': 'access_key',
        'access_key': 'secret_key',
        'secret_key': 'session_token'
    }
    msg = check_required_by(requirements, parameters)
    assert msg == {'secret_key': ['session_token']}



# Generated at 2022-06-11 01:44:11.540013
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1b') == 1
    assert check_type_bits('1kb') == 8192
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-11 01:44:23.135959
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    test_parameters = {}
    test_terms = [["key1", "key2"], ["key3", "key4"]]
    assert len(check_mutually_exclusive(test_terms, test_parameters)) == 0
    test_parameters = {"key1": True, "key2": True}
    test_terms = [["key1", "key2"], ["key3", "key4"]]
    try:
        check_mutually_exclusive(test_terms, test_parameters)
        assert "Unhandled Exception"
    except TypeError:
        assert True
    test_parameters = {"key1": True, "key2": True, "key3": False, "key4": False}
    assert len(check_mutually_exclusive(test_terms, test_parameters)) == 0

# Generated at 2022-06-11 01:44:32.386491
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert isinstance(safe_eval('[1, 2, 3]'), list)
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert isinstance(safe_eval('[1, 2, 3]', include_exceptions=True), tuple)
    assert safe_eval('{"a": "b"}', include_exceptions=True) == ({'a': 'b'}, None)
    assert isinstance(safe_eval('{"a": "b"}', include_exceptions=True), tuple)
    assert safe_eval('import os', include_exceptions=True) == ('import os', None)
    assert isinstance(safe_eval('import os', include_exceptions=True), tuple)

# Generated at 2022-06-11 01:44:39.181246
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": 1, "b": 2.0}') == {"a": 1, "b": 2.0}
    assert check_type_dict('a=1, b=2.0') == {"a": "1", "b": "2.0"}
    # a=1, b=2.0, c=a=b=x should be invalid
    try:
        check_type_dict('a=1, b=2.0, c=a=b=x')
        assert False, 'dictionary requested, could not parse JSON or key=value'
    except TypeError:
        pass


# Generated at 2022-06-11 01:44:43.019318
# Unit test for function check_type_int
def test_check_type_int():
    # Test normal usage and valid input
    assert check_type_int(5) == 5
    # Test invalid input
    with pytest.raises(TypeError):
        check_type_int('asdf')


# Generated at 2022-06-11 01:44:52.138779
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'a': 1, 'b': 2, 'c': 3}") == {'a': 1, 'b': 2, 'c': 3}
    assert safe_eval("{1: 'a', 2: 'b', 3: 'c'}") == {1: 'a', 2: 'b', 3: 'c'}
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("'a'") == 'a'



# Generated at 2022-06-11 01:45:02.541801
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("b'123'") == b'123'
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'a': 'b'}") == {'a': 'b'}
    assert safe_eval("-123") == -123
    assert safe_eval("123.456") == 123.456
    assert safe_eval("-123.456") == -123.456
    assert safe_eval("123j") == 123j
    assert safe_eval("-123j") == -123j
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("['none']") == ['none']

# Generated at 2022-06-11 01:45:17.045638
# Unit test for function safe_eval
def test_safe_eval():
    import pytest

    assert safe_eval('{"a":1, "b":[1,2,3]}') == {"a": 1, "b": [1, 2, 3]}
    assert safe_eval('{1:1, 2:2}') == {1: 1, 2: 2}
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('"a string"') == "a string"
    assert safe_eval('123') == 123
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('1.5') == 1.5
    assert safe_eval('None') is None


# Generated at 2022-06-11 01:45:22.385843
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required1': {'required': True},
        'required2': {'required': True},
        'optional3': {'required': False},
        'optional4': {'required': False},
    }

    parameters = {
        'required1': 'required1',
        'optional3': 'optional3',
    }

    if check_required_arguments(argument_spec, parameters):
        raise AssertionError('check_required_arguments should have returned empty list')

    parameters = {
        'optional3': 'optional3',
    }

    try:
        check_required_arguments(argument_spec, parameters)
        raise AssertionError('check_required_arguments should have raised exception')
    except TypeError:
        pass



# Generated at 2022-06-11 01:45:24.399619
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits("1Mb") == 1048576
# End of unit test


# Generated at 2022-06-11 01:45:31.200932
# Unit test for function check_required_arguments
def test_check_required_arguments():
    params = {"name": "John"}
    argument_spec = {
        "name": {"required": True, "type": "str"},
        "age": {"required": False, "type": "int"}
    }
    missing = check_required_arguments(argument_spec, params)
    assert not missing
    params = {}
    argument_spec = {
        "name": {"required": True, "type": "str"},
        "age": {"required": False, "type": "int"}
    }
    with pytest.raises(TypeError):
        missing = check_required_arguments(argument_spec, params)



# Generated at 2022-06-11 01:45:42.812996
# Unit test for function check_type_bytes
def test_check_type_bytes():
    #Test case 1:
    #check_type_bytes(1 K,1 M,1 G,1 byte)
    assert check_type_bytes('1 K') == 1024
    assert check_type_bytes('1 M') == 1048576
    assert check_type_bytes('1 G') == 1073741824
    assert check_type_bytes('1 byte') == 1
    #Test case 2:
    #check_type_bytes(4 B,4 b,4 B/b,4 b/B)
    assert check_type_bytes('4 B') == 4
    assert check_type_bytes('4 b') == 4
    assert check_type_bytes('4 B/b') == 4
    assert check_type_bytes('4 b/B') == 4
    #Test case 3:
    #check_type_bytes(15, '

# Generated at 2022-06-11 01:45:45.588809
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    try:
        check_type_bits('1.5Mb')
    except TypeError:
        pass



# Generated at 2022-06-11 01:45:50.893165
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # This test is not considered functional, the function is free to raise a TypeError
    # so no assert is done. The purpose is just to find a way to unit test this method.
    try:
        check_required_arguments({'missing': {'required': True}}, {'present': None})
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-11 01:46:03.080538
# Unit test for function check_required_arguments
def test_check_required_arguments():
    spec = dict(
        a=dict(required=True,
               type='dict',
               options=dict(
                   a1=dict(required=True),
                   a2=dict(),
               )),
        b=dict(required=True),
        c=dict(required=True),
    )
    params = dict(c='c')
    missing = check_required_arguments(spec, params)
    assert (missing == [u'b'])

    params = dict(b='b')
    missing = check_required_arguments(spec, params)
    assert (missing == [u'a', u'c'])

    params = dict(a=dict(a2=u'a2'))
    missing = check_required_arguments(spec, params)

# Generated at 2022-06-11 01:46:14.189825
# Unit test for function check_required_arguments
def test_check_required_arguments():
    def check_required_arguments(argument_spec, parameters, options_context=None):
        if not isinstance(parameters, dict):
            parameters = {}
        missing = []
        if argument_spec is None:
            return missing
        for (k, v) in argument_spec.items():
            required = v.get('required', False)
            if required and k not in parameters:
                missing.append(k)
        if missing:
            msg = "missing required arguments: %s" % ", ".join(sorted(missing))
            if options_context:
                msg = "{0} found in {1}".format(msg, " -> ".join(options_context))
            raise TypeError(to_native(msg))
        return missing



# Generated at 2022-06-11 01:46:25.023836
# Unit test for function check_type_dict
def test_check_type_dict():
    # Test if correct dict() is returned
    assert({'key1': 'value1', 'key2': 'value2'}
           == check_type_dict("key1='value1',key2='value2'"))
    assert({'key1': "'value1'"} == check_type_dict("key1='value1'"))
    assert({'key1': '"value1"'} == check_type_dict("key1=\"value1\""))
    assert({'key1': '"value1,value2"'}
           == check_type_dict("key1=\"value1,value2\""))
    assert({'key1': '"value1",value2"'}
           == check_type_dict("key1=\"value1\",value2"))

    # Test if correct dict() is returned even when whitespace is used in the
    #

# Generated at 2022-06-11 01:46:39.103945
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # creating a dictionary with test input and expected output
    data = {
        '1.0M': 1048576,
        '12.0M': 12582912,
        '1 K': 1024,
        '10 MB': 10485760,
        '1.5G': 1610612736,
        '1,000': 1000,
        '1048576': 1048576
    }
    # if the key and value are equal after passing the input key value to
    # the check_type_bytes function, then the test passes
    for k, v in data.items():
        assert check_type_bytes(k) == v

RESTRICTED_RESOURCE_FILENAME = '/etc/ansible/resource_filters.yml'

# Generated at 2022-06-11 01:46:47.325828
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1MB') == 1048576
    assert check_type_bits('1 mb') == 1048576
    assert check_type_bits('1mB') == 1048576
    assert check_type_bits(1) == 1
    try:
        check_type_bits('one')
        assert False
    except TypeError:
        pass
    try:
        check_type_bits(1.0)
        assert False
    except TypeError:
        pass



# Generated at 2022-06-11 01:46:59.387050
# Unit test for function check_required_by
def test_check_required_by():
    results = check_required_by({}, {'key1': 'value'})
    assert isinstance(results, dict)
    assert not results

    results = check_required_by({'key1': None}, {'key1': 'value'})
    assert isinstance(results, dict)
    assert not results

    results = check_required_by({'key1': None}, {'key1': 'value', 'key2': 'value'})
    assert isinstance(results, dict)
    assert not results

    results = check_required_by({'key1': None}, {'key2': 'value'})
    assert isinstance(results, dict)
    assert not results

    results = check_required_by({'key1': 'key2'}, {'key1': 'value', 'key2': 'value'})

# Generated at 2022-06-11 01:47:00.139389
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-11 01:47:08.497163
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([["param1", "param2"]], {"param1": 1}) == []
    assert check_required_one_of([["param1", "param2"]], {}) == [["param1", "param2"]]
    assert check_required_one_of([["param1", "param2"]], {"param3": 1}) == [["param1", "param2"]]
    assert check_required_one_of([["param2", "param3"]], {"param1": 1}) == [["param2", "param3"]]
    assert check_required_one_of([["param2", "param3"]], {"param1": 1}) == [["param2", "param3"]]

# Generated at 2022-06-11 01:47:15.721419
# Unit test for function check_required_by
def test_check_required_by():
    test_parameters = {'key': 'value', 'key1': 'value1', 'key2': 'value2'}
    result = check_required_by({'key': ['key1', 'key2']}, test_parameters)
    assert not result
    result = check_required_by({'key': 'key1'}, test_parameters)
    assert not result
    result = check_required_by({'key': ['key1', 'key2'], 'key3': ['key1', 'key2']}, test_parameters)
    assert not result
    result = check_required_by({'key': ['key1', 'key2'], 'key4': ['key1', 'key2']}, test_parameters)
    assert result
    assert result['key4'] == ['key1', 'key2']
    result

# Generated at 2022-06-11 01:47:26.207346
# Unit test for function check_type_bytes
def test_check_type_bytes():
    for value in [4, 4.4, '4', '4.4']:
        result = check_type_bytes(value)
        assert(result == 4)

    for value in ['4k', '4kb', '4KB', 4 * 1024, '4mb', '4MB', 4 * 1024 * 1024, '4gb', '4GB', 4 * 1024 * 1024 * 1024]:
        result = check_type_bytes(value)
        assert(result == value)

    for value in ['4PB', '4pb', '4tb', '4TB', '4EB', '4eb']:
        result = check_type_bytes(value)
        assert(result == value)

    for value in [None, 4.0, '4.0']:
        with pytest.raises(TypeError):
            check_type_bytes

# Generated at 2022-06-11 01:47:28.689038
# Unit test for function check_type_bits
def test_check_type_bits():
    value = check_type_bits('1Mb')
    assert value == 1048576, 'Expected 8, but got: {0}'.format(str(value))



# Generated at 2022-06-11 01:47:38.036678
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Test underscore
    value = '100_B'
    assert check_type_bytes(value) == 100
    # Test capital initial for 'bits'
    value = '1_kbits'
    assert check_type_bytes(value) == 128
    # Test capital initial for 'Bytes'
    value = '100_KB'
    assert check_type_bytes(value) == 102400
    # Test capital initial for 'bits'
    value = '1_Kbits'
    assert check_type_bytes(value) == 128
    # Test capital initial for 'Bits'
    value = '100_Kbits'
    assert check_type_bytes(value) == 12800
    # Test capital initial for 'Bytes' and underscore
    value = '1_KB'
    assert check_type_bytes(value) == 1024
    # Test capital

# Generated at 2022-06-11 01:47:46.460550
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert check_type_dict('a=1,b=2') == {"a": "1", "b": "2"}
    assert check_type_dict({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert check_type_dict('a=1,b=2,c=3') == {"a": "1", "b": "2", "c": "3"}



# Generated at 2022-06-11 01:48:01.054857
# Unit test for function check_required_one_of
def test_check_required_one_of():
    test_args = {
        'parameters': {
            'param1': 'test11'
        },
        'terms': [
            ['param1'],
            ['param2']
        ]
    }
    output = check_required_one_of(**test_args)
    assert len(output) == 0
    test_args = {
        'parameters': {
            'param1': 'test11'
        },
        'terms': [
            ['param2'],
            ['param3']
        ]
    }
    output = check_required_one_of(**test_args)
    assert len(output) > 0



# Generated at 2022-06-11 01:48:12.418417
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {'required_param': {'required': True, 'type': 'str'},
                     'param_with_default': {'required': False, 'type': 'str', 'default': 'A'},
                     'param_with_no_required_or_default': {'type': 'str'}}
    # Check missing param
    try:
        check_required_arguments(argument_spec, {})
        assert False, "Expected TypeError"
    except TypeError:
        pass
    # Check no missing param with one required param
    try:
        check_required_arguments(argument_spec, {'required_param': 'test'})
        assert True
    except TypeError:
        assert False, "Did not expect TypeError"
    # Check no missing param with one required param and one default param

# Generated at 2022-06-11 01:48:18.304989
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = { 'foo': {'required': True, 'type': 'str', 'aliases': ['name'], 'default': 'bar'},
                      'bar': {'required': False, 'type': 'str', 'aliases': ['name'], 'default': 'foo'}}
    parameters = {'foo': 'bar'}
    options_context = ['foo']
    missing = check_required_arguments(argument_spec, parameters, options_context=options_context)
    assert not missing

    parameters.pop('foo')
    try:
        check_required_arguments(argument_spec, parameters, options_context=options_context)
    except TypeError as e:
        assert 'missing required arguments: foo' in to_native(e)


# Generated at 2022-06-11 01:48:28.017434
# Unit test for function check_type_bits
def test_check_type_bits():
    value_list = [['1Kb', 1024], ['4kb', 4096], ['1Mb', 1048576], ['4Mb', 4194304], ['1Gb', 1073741824], ['4Gb', 4294967296], ['1Tb', 1.09951163e+12], ['4Tb', 4.398046504e+12], ['1Tb', 1.099511627776e+12], ['4Tb', 4.398046511104e+12], ['1Pb', 1.125899907e+15], ['4Pb', 4.503599627e+15]]
    for value, expected in value_list:
        result = check_type_bits(value)
        assert result == expected, "Expected %s, got %s" % (expected, result)



# Generated at 2022-06-11 01:48:34.195057
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1 KiB') == 1024
    assert check_type_bytes('500 MB') == 524288000
    assert check_type_bytes('1 G') == 1073741824
    assert check_type_bytes(500) == 500

    try:
        check_type_bytes('1 KXB')
        assert False, 'Should have thrown an exception'
    except TypeError:
        pass


# Generated at 2022-06-11 01:48:39.274859
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(2) == 2.0
    assert check_type_float('2') == 2.0
    assert check_type_float(2.0) == 2.0
    assert check_type_float('') == 0.0
    assert check_type_float('test_test') == 0.0


# Generated at 2022-06-11 01:48:48.201977
# Unit test for function check_required_if
def test_check_required_if():
    spec = dict(
        param1=dict(type='str', required=True),
        param2=dict(type='str'),
        param3=dict(type='str', required_if=[['param1', 'present', ['param2', 'param3']]]),
        param4=dict(type='str', required_if=[['param1', 'present', ['param2', 'param3'], True]]),
        param5=dict(type='str', required_if=[['param1', 'present', ['param2', 'param3'], False]])
    )

    options_context = ['foo']


# Generated at 2022-06-11 01:49:00.457519
# Unit test for function check_required_together
def test_check_required_together():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os
    sys.path.append(os.path.dirname(__file__) + '/../../vars')
    from parm_validation import check_required_together
    module = AnsibleModule(
        argument_spec=dict(
            a=dict(type='int', required=False),
            b=dict(type='int', required=False),
            c=dict(type='int', required=False),
            d=dict(type='int', required=False),
            required_together=[['a', 'b'], ['c', 'd']]
        )
    )
    parameters = module.params
    check_required_together(module.argument_spec['required_together'], parameters)

# Generated at 2022-06-11 01:49:01.842287
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1mb') == 1048576



# Generated at 2022-06-11 01:49:12.382047
# Unit test for function check_type_bytes
def test_check_type_bytes():
    try:
        check_type_bytes('1234')
    except TypeError:
        raise AssertionError("Converting 1234 to bytes failed")

    try:
        check_type_bytes('1KB')
    except TypeError:
        raise AssertionError("Converting 1KB to bytes failed")

    try:
        check_type_bytes('1MB')
    except TypeError:
        raise AssertionError("Converting 1MB to bytes failed")

    try:
        check_type_bytes('1GB')
    except TypeError:
        raise AssertionError("Converting 1GB to bytes failed")

    try:
        check_type_bytes('1TB')
    except TypeError:
        raise AssertionError("Converting 1TB to bytes failed")


# Generated at 2022-06-11 01:49:17.022810
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-11 01:49:25.033733
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1') != 2
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('[1, 2, 3]') != [1, 2]
    assert safe_eval('{"a": 1, "b": 2, "c": 3}') == {"a": 1, "b": 2, "c": 3}
    assert safe_eval('{"a": 1, "b": 2, "c": 3}') != {"a": 1, "b": 2}
    assert safe_eval('{"a": [1, 2, 3]}') == {"a": [1, 2, 3]}
    assert safe_eval('{"a": [1, 2, 3]}') != {"a": [1, 3]}
    assert safe_

# Generated at 2022-06-11 01:49:31.141093
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('8Mb') == 8388608
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('8Gb') == 8589934592
    assert check_type_bits('1Tb') == 1099511627776


# Generated at 2022-06-11 01:49:40.087720
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by({'foo': 'bar'}, dict(foo=None)) == {}
    assert check_required_by({'foo': 'bar'}, dict(foo=True)) == {}
    assert check_required_by({'foo': 'bar'}, dict(foo=True, bar=False)) == {}
    assert check_required_by({'foo': ('bar',)}, dict(foo=False, bar=False)) == {'foo': ['bar']}
    assert check_required_by({'foo': ('bar', 'baz')}, dict(foo=False, bar=False)) == {'foo': ['bar', 'baz']}
    assert check_required_by({'foo': ('bar', 'baz')}, dict(foo=True, bar=False)) == {'foo': ['baz']}
    assert check_

# Generated at 2022-06-11 01:49:49.110584
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{ "permit": [ "vlan_id/1060" ] }') == {"permit": ["vlan_id/1060"]}
    assert check_type_dict('permit=[ "vlan_id/1060" ]') == {"permit": ["vlan_id/1060"]}
    assert check_type_dict('permit=[ "vlan_id/1060" ]') == {"permit": ["vlan_id/1060"]}
    assert check_type_dict('permit=[ "vlan_";id/1060" ]') == {"permit": ['"vlan_";id/1060" ]']}



# Generated at 2022-06-11 01:50:01.340048
# Unit test for function safe_eval
def test_safe_eval():
    (result, exception) = safe_eval("test", include_exceptions=True)
    assert result == "test"
    assert exception is None

    (result, exception) = safe_eval("1234", include_exceptions=True)
    assert result == "1234"
    assert exception is not None

    result = safe_eval("1234")
    assert result == "1234"

    (result, exception) = safe_eval("[1, 2]", include_exceptions=True)
    assert isinstance(result, list)
    assert result == [1, 2]
    assert exception is None

    (result, exception) = safe_eval("{'a': 1, 'b': 'foo'}", include_exceptions=True)
    assert isinstance(result, dict)

# Generated at 2022-06-11 01:50:10.109855
# Unit test for function check_type_dict