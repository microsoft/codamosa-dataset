

# Generated at 2022-06-11 01:40:48.619162
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # correct
    arg_spec = dict(a=dict(required=True), b=dict(required=True))
    params = dict(a=1, b=2, c=3)
    result = check_required_arguments(arg_spec, params)
    assert result == []

    # missing
    params = dict(b=2, c=3)
    try:
        check_required_arguments(arg_spec, params)
    except TypeError as e:
        assert "a" in to_native(e)

    # missing options_context
    try:
        check_required_arguments(arg_spec, params)
    except TypeError as e:
        assert "found in" not in to_native(e)

    # missing options_context with options_context

# Generated at 2022-06-11 01:41:01.592120
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1gb') == 1073741824
    assert check_type_bits('1tb') == 1099511627776
    assert check_type_bits('1pb') == 1125899906842624
    assert check_type_bits('1eb') == 1152921504606846976
    assert check_type_bits('1zb') == 1180591620717411303424
    assert check_type_bits('1yb') == 1208925819614629174706176
    assert check_type_bits('1kb/s') == 1024
    assert check_type_bits('1mb/s') == 1048576

# Generated at 2022-06-11 01:41:13.337539
# Unit test for function check_required_by
def test_check_required_by():
    # Test case 1
    requirements = {"required_by": "foo", "foo": "bar"}
    parameters = {"foo": "foo"}
    options_context = None
    assert check_required_by(requirements, parameters, options_context) == {"required_by": ["bar"]}

    # Test case 2
    requirements = {"required_by": "foo", "foo": "bar"}
    parameters = {"foo": None}
    options_context = None
    with pytest.raises(TypeError) as exception:
        check_required_by(requirements, parameters, options_context)
    assert "missing parameter(s) required by 'required_by': bar" in str(exception)

    # Test case 3
    requirements = {"required_by": "foo", "foo": "bar"}
    parameters = {"foo": "bar"}


# Generated at 2022-06-11 01:41:19.513023
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = dict(
        name=dict(required=True),
        force=dict(required=False, type='bool', default=False),
        state=dict(choices=['present', 'absent'], default='present'),
    )
    assert check_required_arguments(argument_spec, dict(name='test')) == []
    try:
        check_required_arguments(argument_spec, dict(state='present', force=False))
        assert False, "failed to throw an exception"
    except TypeError as e:
        assert "missing required arguments: name" == str(e)



# Generated at 2022-06-11 01:41:31.436433
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(terms=None, parameters={"foo": "bar"}) == []
    assert check_mutually_exclusive(terms=[], parameters={"foo": "bar"}) == []
    assert check_mutually_exclusive(terms=["foo", "bar"], parameters={"foo": "bar"}) == []
    assert check_mutually_exclusive(terms=["foo", ["bar", "baz"]], parameters={"foo": "bar", "baz": "boo"}) == []
    assert check_mutually_exclusive(terms=[["foo", "bar"], "baz"], parameters={"foo": "bar", "baz": "boo"}) == []

# Generated at 2022-06-11 01:41:42.252729
# Unit test for function check_required_by
def test_check_required_by():
    param_1 = {
        'key_1': 'Some value',
        'key_2': 'Some value',
        'key_3': 'Some value'
    }
    param_2 = {
        'key_1': 'Some value',
        'key_2': 'Some value'
    }
    param_3 = {
        'key_1': 'Some value',
        'key_3': 'Some value'
    }
    param_4 = {
        'key_1': 'Some value',
        'key_2': 'Some value',
        'key_4': 'Some value'
    }
    param_5 = {
        'key_1': 'Some value',
        'key_4': 'Some value'
    }

# Generated at 2022-06-11 01:41:54.575192
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [['state', 'present', ('path',), True],
                    ['someint', 99, ('bool_param', 'string_param')],
                    ['someint', 99, ('bool_param', 'string_param'), True],
                    ['someint', 1, ('bool_param', 'string_param')]]
    parameters = {'state': 'present', 'path': '/home/user/ansible'}
    assert check_required_if(requirements, parameters) == []
    parameters = {'state': 'present', 'path': '/home/user/ansible', 'someint': 99}

# Generated at 2022-06-11 01:42:05.658016
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'a': 1}
    required_parameters = ['a', 'b']
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == ['b'], "Missing parameters are not found correctly"

    parameters = {'a': 1, 'b': 2}
    required_parameters = ['a', 'b']
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == [], "Missing parameters are not found correctly"

    parameters = {'a': 1, 'b': 2}
    required_parameters = []
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == [], "Missing parameters are not found correctly"



# Generated at 2022-06-11 01:42:12.357547
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {'a': {'required': True}, 'b': {'required': False}}
    parameters = {'a': 'good', 'b': 'good'}
    assert check_required_arguments(argument_spec, parameters) == []

    parameters = {'a': 'good'}
    assert check_required_arguments(argument_spec, parameters) == []

    parameters = {'b': 'good'}
    assert check_required_arguments(argument_spec, parameters) == ['a']


# Generated at 2022-06-11 01:42:21.385070
# Unit test for function check_required_if
def test_check_required_if():
    import pytest
    """
    Test cases for function check_required_if
    """
    requirements = [
        ['state', 'present', ('path',), True]
    ]
    parameters = {"path":"/tmp/abc"}
    # Test case when one of the required parameter is missing
    with pytest.raises(TypeError) as excinfo:
        check_required_if(requirements, parameters, options_context=None)
    assert "but any of the following are missing: path" in str(excinfo.value)
    # Test case when all required parameters are missing
    parameters1 = {}
    with pytest.raises(TypeError) as excinfo:
        check_required_if(requirements, parameters1, options_context=None)

# Generated at 2022-06-11 01:42:34.519011
# Unit test for function check_required_if
def test_check_required_if():
    assert check_required_if(
        [['state', 'present', ['path'], True]],
        {'path': '/tmp', 'state': 'present'}
    ) == []
    assert check_required_if(
        [['state', 'present', ['path'], True]],
        {'state': 'present'}
    ) == [{'parameter': 'state', 'value': 'present', 'requirements': ['path'], 'missing': ['path'], 'requires': 'any'}]
    assert check_required_if(
        [['state', 'present', ['path']]],
        {'state': 'present'}
    ) == [{'parameter': 'state', 'value': 'present', 'requirements': ['path'], 'missing': ['path'], 'requires': 'all'}]




# Generated at 2022-06-11 01:42:46.375747
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval('2 + 3')
    assert result == 5
    result = safe_eval('[1, 2, 3]')
    assert result == [1, 2, 3]
    result = safe_eval("'two' + 'three'")
    assert result == 'twothree'
    # Evaluating string that contains method calls
    result = safe_eval("'two'.join(['one', 'three'])")
    assert result == "'two'.join(['one', 'three'])"
    # Evaluating string that contains imports
    result = safe_eval("import six")
    assert result == "import six"
    # Evaluating a tuple (this is needed in some cases)
    result = safe_eval("(1, 2)")
    assert result == (1, 2)
    # Evaluating None
    result = safe

# Generated at 2022-06-11 01:42:56.506458
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of(terms=[['a', 'b', 'c'], ['d', 'e']],
                                 parameters={'a': 1}) == []
    assert check_required_one_of(terms=[['a', 'b', 'c'], ['d', 'e']],
                                 parameters={'a': 1, 'b':2}) == []
    assert check_required_one_of(terms=[['a', 'b', 'c'], ['d', 'e']],
                                 parameters={'a': 1, 'b':2, 'c':3}) == []
    assert check_required_one_of(terms=[['a', 'b', 'c'], ['d', 'e']],
                                 parameters={'a': 1, 'b':2, 'd':3}) == []
    assert check_required_

# Generated at 2022-06-11 01:43:07.284429
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Test multiple number formats
    assert '100B' == check_type_bytes('100B')
    assert '100KB' == check_type_bytes('100K')
    assert '100MB' == check_type_bytes('100M')
    assert '100GB' == check_type_bytes('100G')
    # Test number + uppercase
    assert '100B' == check_type_bytes('100b')
    assert '100KB' == check_type_bytes('100k')
    assert '100MB' == check_type_bytes('100m')
    assert '100GB' == check_type_bytes('100g')
    # Test float
    assert '100GB' == check_type_bytes('99.9G')
    # Test with space
    assert '100GB' == check_type_bytes('100 GB')


# Generated at 2022-06-11 01:43:18.724842
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [['state', 'present', ('path',), True], ['someint', 99, ('bool_param', 'string_param')]]
    parameters = {'state': 'present', 'path': 'somepath', 'someint': 99}
    result = check_required_if(requirements, parameters)
    assert result == []
    requirements = [['someint', 99, ('bool_param', 'string_param')]]
    parameters = {'state': 'present', 'path': 'somepath', 'someint': 99}
    result = check_required_if(requirements, parameters)
    assert result == [{'missing': ['bool_param', 'string_param'], 'parameter': 'someint', 'value': 99, 'requirements': ('bool_param', 'string_param'), 'requires': 'all'}]



# Generated at 2022-06-11 01:43:31.411289
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    '''Test function check_mutually_exclusive'''
    fail_string = "Parameters are mutually exclusive: test|test1"

    original_terms = [["test", "test1"]]
    good_parameters = dict(test="good")
    bad_parameters = dict(test="bad", test1="bad")
    good_parameter_keys = ["test"]
    assert check_mutually_exclusive(original_terms, good_parameters) == ''
    assert check_mutually_exclusive(original_terms, bad_parameters) == fail_string

    terms = dict(terms=original_terms)
    assert check_mutually_exclusive(terms, good_parameters, options_context=good_parameter_keys) == ''

# Generated at 2022-06-11 01:43:38.106503
# Unit test for function safe_eval
def test_safe_eval():
    # error handling
    assert safe_eval('import foo') == 'import foo'
    assert safe_eval('{"a": lambda x: x+1}') == '{"a": lambda x: x+1}'

    # dicts
    assert safe_eval('{"a": "foo"}') == {'a': 'foo'}
    assert safe_eval('{"a": 1}') == {'a': 1}
    assert safe_eval('{"a": "foo", "b": "1"}') == {'a': 'foo', 'b': '1'}
    assert safe_eval('{"a": "foo", "bar": "1"}') == {'a': 'foo', 'bar': '1'}

# Generated at 2022-06-11 01:43:45.870659
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{'k':'v'}") == {'k':'v'}
    assert check_type_dict("k=v") == {'k':'v'}
    assert check_type_dict("k = v") == {'k':'v'}
    assert check_type_dict("k = 'v'") == {'k':'v'}
    assert check_type_dict("k = \"v\"") == {'k':'v'}



# Generated at 2022-06-11 01:43:51.035287
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    params = {'a': 1, 'b': 2, 'c': 3}
    try:
        check_mutually_exclusive(['a', 'b'], params)
    except TypeError:
        pass
    else:
        raise AssertionError("check_mutually_exclusive failed to raise TypeError")



# Generated at 2022-06-11 01:43:57.629851
# Unit test for function safe_eval
def test_safe_eval():
    # safe_eval
    test_list = [
        ['false', False],
        ['true', True],
        ['1', 1],
        ['1', 1],
        ['"string"', 'string'],
        ['4.4', 4.4],
        ['None', None],
    ]
    for val, expected_result in test_list:
        result = safe_eval(val)
        assert result == expected_result, '%s != %s' % (result, expected_result)



# Generated at 2022-06-11 01:44:09.974018
# Unit test for function check_type_bytes
def test_check_type_bytes():

    testcases = [
        (1, b'1'),
        (1.0, b'1.0'),
        ('10B', b'10'),
        ('10KB', b'10240'),
        ('10MB', b'10485760'),
        ('10GB', b'1073741824'),
        ('10TB', b'1099511627776'),
        ('10PB', b'11258999068426240'),
        ('10EB', b'1152921504606846976'),
        ('10ZB', b'1180591620717411303423'),
        ('10YB', b'1208925819614629174706178'),
    ]

    for value, result in testcases:
        if not isinstance(result, bytes):
            result = to_bytes(result)
        assert check_

# Generated at 2022-06-11 01:44:14.595927
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1m') == 8388608



# Generated at 2022-06-11 01:44:25.505622
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # successful test
    test_params = {'mode': 'test', 'state': 'present'}
    r = check_required_one_of([['mode', 'state']], parameters=test_params)
    assert not r

    # required test
    test_params = {'mode': 'test'}
    r = check_required_one_of([['mode', 'state']], parameters=test_params)
    assert r

    # pass test
    test_params = {'mode': 'test', 'state': 'present'}
    r = check_required_one_of([['mode', 'state', 'absent']], parameters=test_params)
    assert not r

    # failed test
    test_params = {'mode': 'test'}

# Generated at 2022-06-11 01:44:30.540921
# Unit test for function check_required_arguments
def test_check_required_arguments():
    args_spec = dict(
        required_arg=dict(type='str', required=True),
        optional_arg=dict(type='str', required=False),
    )
    params = dict(required_arg='example')
    assert check_required_arguments(args_spec, params) == []

    params = dict(optional_arg='example')
    assert check_required_arguments(args_spec, params) == ['required_arg']

# Generated at 2022-06-11 01:44:39.086010
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive([['a', 'b']], dict(a='a', b='b'))
    try:
        check_mutually_exclusive([['a', 'b']], dict(a='a', b='b', c='c'))
    except TypeError as e:
        assert 'a|b' in e.args[0]
        assert 'found parameters: c' in e.args[0]
    assert check_mutually_exclusive([['a', 'b'], ['b', 'c']], dict(a='a'))
    assert check_mutually_exclusive([[['a', 'b'], ['b', 'c']]], dict(a='a'))

# Generated at 2022-06-11 01:44:41.935616
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    check_mutually_exclusive([['a', 'b']], dict(a=1, b=2), options_context=['test'])



# Generated at 2022-06-11 01:44:50.989833
# Unit test for function check_type_bytes
def test_check_type_bytes():
    pair_test_bytes= {'1TB': 1099511627776, '1MB': 1048576, '1GB': 1073741824, '1KB': 1024, '1PB': 1125899906842624, '1B': 1, '1EB': 1152921504606846976}
    for (value_test, expected) in pair_test_bytes.items():
        result = check_type_bytes(value_test)
        assert result == expected, "Returned '%s' but we expected '%s'" % (result, expected)


# Generated at 2022-06-11 01:45:00.972096
# Unit test for function safe_eval
def test_safe_eval():
    import pytest
    from ansible.module_utils.common.text.formatters import to_text

    def test_pass(value, locals=None, include_exceptions=False):
        result, err = safe_eval(value, locals, include_exceptions=include_exceptions)
        if include_exceptions:
            assert err is None
        else:
            assert err is None
            assert result is not None
            assert result == value
        return result

    def test_fail(value, locals=None, include_exceptions=False):
        result, err = safe_eval(value, locals, include_exceptions=include_exceptions)
        if include_exceptions:
            assert err is not None
        else:
            assert err is None
            assert result is None
        return result

    # test json

# Generated at 2022-06-11 01:45:08.461233
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(["param1", "param2"], {"param1": 1, "param2": 2}) == [["param1", "param2"]]
    assert check_mutually_exclusive([["param1", "param2"], ["param3", "param4"]], {"param1": 1, "param3": 3}) == []
    assert check_mutually_exclusive(["param1", "param2"], {"param1": 1}) == []
    assert check_mutually_exclusive(None, {"param1": 1}) == []



# Generated at 2022-06-11 01:45:19.106379
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("test_literal", None) == 'test_literal'
    assert safe_eval("1", None) == 1
    assert safe_eval("-1", None) == -1
    assert safe_eval("1.1", None) == 1.1
    assert safe_eval("-1.1", None) == -1.1
    assert safe_eval("[1]", None) == [1]
    assert safe_eval("[1,2]", None) == [1, 2]
    assert safe_eval("{'a': 1}", None) == {'a': 1}
    assert safe_eval("{'a': 1, 'b': 2}", None) == {'a': 1, 'b': 2}
    assert safe_eval("()", None) == ()

# Generated at 2022-06-11 01:45:29.640624
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = ['name', 'name_default']
    parameters = {'name': ['test'], 'name_default': ['test']}
    with pytest.raises(TypeError) as excinfo:
        check_mutually_exclusive(terms, parameters)
    assert "parameters are mutually exclusive: name|name_default found in " in str(excinfo.value)
    terms = ['name', 'name_default']
    parameters = {'name': ['test'], 'name_default': ['test'], 'state': ['present']}
    assert check_mutually_exclusive(terms, parameters) == []



# Generated at 2022-06-11 01:45:39.946130
# Unit test for function safe_eval
def test_safe_eval():
    examples = {
        "string": "'I am a string'",
        "true": "True",
        "false": "False",
        "int": "17",
        "none": "None",
        "list": "['one', 1, True, None]",
        "dict": "{'one': 1, 'two': 2, 'three': 3}",
    }
    for example, result in examples.items():
        value = safe_eval(result)
        assert(isinstance(value, type(jsonify(result))))
        assert(isinstance(safe_eval(result, include_exceptions=True), tuple))
        assert(safe_eval(result, include_exceptions=True)[0] == value)



# Generated at 2022-06-11 01:45:48.608535
# Unit test for function check_type_bits

# Generated at 2022-06-11 01:45:55.927470
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1') == 1
    assert check_type_bits('1.0') == 8
    assert check_type_bits('1b') == 1
    assert check_type_bits('1.0b') == 8
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('1Tb') == 1099511627776
    assert check_type_bits('1Pb') == 1125899906842624
    assert check_type_bits('1Eb') == 1152921504606846976
    assert check_type_bits('1Zb') == 1180591620717411303424
    assert check_type_

# Generated at 2022-06-11 01:46:06.651018
# Unit test for function check_required_if
def test_check_required_if():
    """This is the unit test for function check_required_if"""
    # test_check_required_if_1
    requirements = [['state', 'present', ('path',), True]]
    parameters = {'path': 12}
    try:
        check_required_if(requirements, parameters)
    except TypeError as e:
        assert e.message == "missing required arguments: path"
    else:
        assert False, "Expected an exception"

    # test_check_required_if_2
    requirements = [['state', 'present', ('path',), True]]
    parameters = {'state': 'present'}
    try:
        check_required_if(requirements, parameters)
    except TypeError as e:
        assert e.message == "missing required arguments: path"

# Generated at 2022-06-11 01:46:14.722064
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('3') == 3
    assert safe_eval('3.2') == 3.2
    assert safe_eval('[3, 2]') == [3, 2]
    assert safe_eval('{}') == {}
    assert safe_eval('{"a": [3, 2]}') == {"a": [3, 2]}
    assert safe_eval('a') == 'a'
    assert safe_eval('42', include_exceptions=True) == (42, None)



# Generated at 2022-06-11 01:46:25.344694
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(123.45) == 123.45
    assert check_type_float("123.45") == 123.45
    assert check_type_float(123) == 123.0
    assert check_type_float("123") == 123.0
    assert check_type_float(b"123") == 123.0
    assert check_type_float(b"123.45") == 123.45
    assert check_type_float(b"123.45", False) == 123.45
    assert check_type_float(u"123.45") == 123.45
    assert check_type_float(u"123.45", False) == 123.45
    assert check_type_float(u"123") == 123.0


# Generated at 2022-06-11 01:46:35.093130
# Unit test for function check_required_if
def test_check_required_if():
    """Function check_required_if unit test"""

    # Exiting units for no error
    try:
        check_required_if(None, {})
        check_required_if([], {})
        check_required_if([['ip', '10.10.10.10', ('path',)], ], {"ip": "10.10.10.10", "path": "/tmp"})
        check_required_if([['ip', '10.10.10.10', ('path',)]], {"ip": "10.10.10.10", "path": "/tmp"})
    except:
        assert False

    # Exiting units for error

# Generated at 2022-06-11 01:46:42.465940
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576, 'check_type_bits 1Mb failed'
    assert check_type_bits('2Kb') == 2048, 'check_type_bits 2Kb failed'
    assert check_type_bits('4b') == 4, 'check_type_bits 4b failed'
    try:
       check_type_bits('4')
       assert(0 == 1) # bad value
    except TypeError:
        pass # good value
    try:
       check_type_bits('1M')
       assert(0 == 1) # bad value
    except TypeError:
        pass # good value


# Generated at 2022-06-11 01:46:54.126890
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(u'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(u'1') == 1.0
    try:
        assert check_type_float(object) is None
        assert False
    except TypeError:
        pass
    try:
        assert check_type_float('1.0.1')
        assert False
    except TypeError:
        pass



# Generated at 2022-06-11 01:47:07.159615
# Unit test for function check_type_dict
def test_check_type_dict():
    from ansible.module_utils.common._collections_compat import Mapping

    class mapping(Mapping):
        " This class is used for the test of check_type_dict "
        def __init__(self, *args, **kwargs):
            self.data = dict(*args, **kwargs)

        def __iter__(self):
            return iter(self.data)

        def __len__(self):
            return len(self.data)

        def __getitem__(self, key):
            return self.data[key]

    try:
        check_type_dict("k1=v1,k2=v2")
    except Exception as e:
        assert False, "should not raise exception: %s" % to_text(e)


# Generated at 2022-06-11 01:47:11.972242
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
        ['someint', 99, ('bool_param', 'slh')],
        ['someint', 99, ('bool_param', 'slh')]
    ]
    for index, req in enumerate(requirements):
        results = []
        if index < 2:
            results = check_required_if(req, {'state': 'present'})
        else:
            results = check_required_if(req, {'someint': 99})
        assert len(results) == 1



# Generated at 2022-06-11 01:47:19.654436
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True') is True
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('-1') == -1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('-1.1') == -1.1
    assert safe_eval('"foobar"') == 'foobar'
    assert safe_eval("'foobar'") == 'foobar'
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}
    assert safe_eval("['foo', 'bar']") == ['foo', 'bar']
    assert safe_eval('1 + 1') == 1 + 1
    assert safe_eval('foo') == 'foo'

# Generated at 2022-06-11 01:47:24.329697
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int('3') == 3
    assert check_type_int(3) == 3

    try:
        check_type_int('foo')
    except TypeError:
        pass
    else:
        raise AssertionError("failed to raise error non-int string")


# Generated at 2022-06-11 01:47:34.892531
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    options = []
    mutually_exclusive = [["1", "2"]]
    check_mutually_exclusive(mutually_exclusive, options)
    check_mutually_exclusive([], options)
    options = [1, 2, 3]
    try:
        check_mutually_exclusive(mutually_exclusive, options)
    except TypeError:
        pass
    # test inclusive
    options = [1, 3]
    check_mutually_exclusive(mutually_exclusive, options)
    # test multiple disjoint coverage
    mutually_exclusive = [["1", "2"], ["3", "4"]]
    options = [1, 2, 3]
    try:
        check_mutually_exclusive(mutually_exclusive, options)
    except TypeError:
        pass
    # test multiple overlap

# Generated at 2022-06-11 01:47:46.793881
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.text.formatters import to_bytes

    def to_json(val, pretty=False):
        if not isinstance(val, str):
            val = val.decode('utf-8')
        if pretty:
            return json.dumps(jsonify(val, format=False), indent=4, sort_keys=True)
        else:
            return to_text(json.dumps(jsonify(val, format=False), sort_keys=True), errors='surrogate_then_replace')

    def check_result(result, expected):
        if isinstance(expected, binary_type):
            expected = expected.decode(locale.getpreferredencoding())

# Generated at 2022-06-11 01:47:55.557773
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int("1") == 1
    assert check_type_int(1.5) == 1
    assert check_type_int(1.6) == 1
    assert check_type_int(1.8) == 1
    try:
        check_type_int("hello")
        assert False
    except TypeError as e:
        assert e.args[0] == "unicode object cannot be converted to an int"
    try:
        check_type_int("")
        assert False
    except TypeError as e:
        assert e.args[0] == "invalid literal for int() with base 10: ''"

# Generated at 2022-06-11 01:48:07.987065
# Unit test for function check_required_together
def test_check_required_together():
    # Test that all required parameters are present
    # arg1 is required if arg2 is specified
    # arg3 is required if arg4 is specified
    # arg5 is required if arg6 is specified
    terms = [
        ['arg1', 'arg2'],
        ['arg3', 'arg4'],
        ['arg5', 'arg6']
    ]
    parameters = {'arg1': 'test1', 'arg2': 'test2', 'arg3': 'test3', 'arg4': 'test4', 'arg5': 'test5', 'arg6': 'test6'}
    assert not check_required_together(terms, parameters)
    # Test that all required parameters are present
    # arg1 is required if arg2 is specified
    # arg2 is required if arg1 is specified
    # arg3 is required if arg4 is specified

# Generated at 2022-06-11 01:48:11.502754
# Unit test for function check_type_float
def test_check_type_float():
    try:
        check_type_float("abc")
    except TypeError as e:
        assert str(e) == "'abc' cannot be converted to a float"
    else:
        assert False, "TypeError has not been raised"



# Generated at 2022-06-11 01:48:17.253024
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1.1) == 1.1
    assert check_type_float("1") == 1.0
    assert check_type_float("1.1") == 1.1
    assert check_type_float(b"1.1") == 1.1
    assert check_type_float(b"1") == 1.0
    assert check_type_float(b"1.0") == 1.0

    try:
        # There is no float, or int, in the below string
        check_type_float("some string")
        assert False, "Should throw an exception"
    except TypeError:
        pass



# Generated at 2022-06-11 01:48:22.324229
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(12345) == 12345
    assert check_type_int('12345') == 12345


# Generated at 2022-06-11 01:48:33.490687
# Unit test for function check_type_dict
def test_check_type_dict():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    test1 = check_type_dict("{\"k1\": \"v1\", \"k2\": \"v2\"}")
    assert isinstance(test1, dict) and test1 == {"k1": "v1", "k2": "v2"}
    test2 = check_type_dict("{'k1': 'v1', 'k2': 'v2'}")
    assert isinstance(test2, dict) and test2 == {"k1": "v1", "k2": "v2"}
    test3 = check_type_dict("{\"k1\": \"v1\", \"k2\": \"v2\"}".format(x="test"))

# Generated at 2022-06-11 01:48:34.097770
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    pass



# Generated at 2022-06-11 01:48:45.174809
# Unit test for function check_required_if
def test_check_required_if():
    '''Function check_required_if'''
    requirements = [ ['state', 'present', ('path',), True],
                     ['someint', 99, ('bool_param', 'string_param')],
                     ['param', 'a_value', ('required_param', 'optional_param')]]
    parameters = {'state': 'present', 'path': '/a', 'param': 'a_value', 'optional_param': 'xyz'}
    assert [] == check_required_if(requirements, parameters)

    requirements = [['param', 'another_value', ('required_param',)]]
    parameters = {'state': 'present', 'path': '/a', 'param': 'another_value', 'required_param': 'abc'}
    assert [] == check_required_if(requirements, parameters)


# Generated at 2022-06-11 01:48:57.157250
# Unit test for function check_required_together
def test_check_required_together():
    options = {"a": 1, "b": 2}
    assert check_required_together([["a", "b"]], options) == []
    assert check_required_together([["a", "b"], ["c"]], options) == []
    assert check_required_together([["a", "b"], ["b", "c"]], options) == []
    assert check_required_together([["a", "b"], ["b", "c"], ["b", "d"]], options) == []
    assert check_required_together([["a", "b"], ["c", "d"]], options) == []

# Generated at 2022-06-11 01:49:06.477848
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by(None, None, None) == {}
    assert check_required_by(dict(), dict(), None) == {}
    assert check_required_by(dict(a=[]), dict(a=[]), None) == {}
    assert check_required_by(dict(a=[]), dict(b=[]), None) == {}
    assert check_required_by(dict(a=[]), dict(a=None), None) == {}
    assert check_required_by(dict(a=['b']), dict(a=[]), None) == dict(a=['b'])
    assert check_required_by(dict(a=[2]), dict(a=[]), None) == dict(a=[2])
    assert check_required_by(dict(a=['b']), dict(a=None), None) == dict

# Generated at 2022-06-11 01:49:11.606976
# Unit test for function check_required_together
def test_check_required_together():
    try:
        check_required_together([[['a', 'b']], [['c', 'd']], [['e', 'f']]], dict(b=1, c=1, d=1, f=1))
    except Exception as e:
        print(e)
    else:
        raise AssertionError("check_required_together should raise an exception if all fields are not present")



# Generated at 2022-06-11 01:49:22.075027
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together([],{}) == []
    assert check_required_together(['a'], {'b':'foo'}) == []
    assert check_required_together(['a', 'b'], {'a':'1', 'b':'2'}) == []
    assert check_required_together([('a', 'b')], {'a':'1', 'b':'2'}) == []
    assert check_required_together([('a', 'b')], {'a': '1'}) == [('a', 'b')]
    assert check_required_together([('a', 'b')], {'b': '1'}) == [('a', 'b')]
    assert check_required_together([('a', 'b')], {}) == [('a', 'b')]
    assert check_required

# Generated at 2022-06-11 01:49:23.538512
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float("-1.1") == -1.1


# Generated at 2022-06-11 01:49:24.242368
# Unit test for function check_type_float
def test_check_type_float():
    pass


# Generated at 2022-06-11 01:49:37.314055
# Unit test for function check_required_together
def test_check_required_together():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean  # pylint: disable=unused-import
    import ansible.module_utils.network.common.utils  # pylint: disable=unused-import

    module = AnsibleModule(
        argument_spec={
            "test1": {"type": "str"},
            "test2": {"type": "str"},
            "test3": {"type": "str"},
        }
    )


# Generated at 2022-06-11 01:49:48.513332
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval('1') == 1
    assert safe_eval('()') == ()
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('dict(a=1,b=2)') == {'a': 1, 'b': 2}
    assert safe_eval('dict()') == {}
    assert safe_eval('1,2') == (1, 2)
    assert safe_eval('"a"') == "a"
    assert safe_eval('True') == True
    assert safe_eval('1.2') == 1.2
    assert safe_eval('None') is None
    assert safe_eval('a') == 'a'

# Generated at 2022-06-11 01:50:01.054603
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('foo') == 'foo'
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1]') == [1]
    assert safe_eval('dict(A=1)') == dict(A=1)
    assert safe_eval('os') == 'os'
    assert safe_eval('os.environ') == 'os.environ'
    assert safe_eval('import sys') == 'import sys'
    assert safe_eval('1 + "foo"') == '1 + "foo"'
    assert safe_eval(1) == 1
    assert safe_eval(dict(A=1)) == dict(A=1)
    assert safe_eval(['foo', 'bar']) == ['foo', 'bar']

# Generated at 2022-06-11 01:50:09.926062
# Unit test for function safe_eval
def test_safe_eval():
    if os.path.isfile('/usr/bin/python2'):
        py2 = '/usr/bin/python2'
    elif os.path.isfile('/usr/bin/python'):
        py2 = '/usr/bin/python'
    else:
        py2 = 'python'

    if os.path.isfile('/usr/bin/python3'):
        py3 = '/usr/bin/python3'
    elif os.path.isfile('/usr/bin/python'):
        py3 = '/usr/bin/python'
    else:
        py3 = 'python'

    import subprocess
    mylist = [{'a': True}, {'a': False}, {'a': "string"}]