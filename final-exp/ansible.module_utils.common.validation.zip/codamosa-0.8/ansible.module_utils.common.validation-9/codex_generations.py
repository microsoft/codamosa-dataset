

# Generated at 2022-06-11 01:40:45.349962
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments({'param1': {'required': True}, 'param2': {}}, {'param1': 'test1'}) == []
    assert check_required_arguments({'param1': {'required': True}, 'param2': {}}, {'param1': 'test1', 'param2': 'test2'}) == []
    assert check_required_arguments({'param1': {'required': True}, 'param2': {}}, {'param2': 'test2'}) == ['param1']
    assert check_required_arguments({'param1': {'required': True}, 'param2': {}}, {}) == ['param1']

# Generated at 2022-06-11 01:40:52.190460
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('[1]') == [1]
    assert safe_eval('{"a": 1}') == {"a": 1}
    assert safe_eval('{"a": 1}', include_exceptions=True) == ({"a": 1}, None)
    assert safe_eval('os.listdir()') == 'os.listdir()'
    assert safe_eval('os.listdir()', include_exceptions=True) == ('os.listdir()', None)



# Generated at 2022-06-11 01:41:01.049535
# Unit test for function check_required_by
def test_check_required_by():
    parsed = {'name': 'test', 'required_by': 'none'}
    requirements = {'name': 'required_by'}
    try:
        check_required_by(requirements, parsed)
    except TypeError:
        pass
    else:
        assert False, "TypeError not raised!"

    requirements = {'name': 'required_by', 'required_by': 'value'}
    try:
        check_required_by(requirements, parsed)
    except TypeError:
        pass
    else:
        assert False, "TypeError not raised!"



# Generated at 2022-06-11 01:41:04.030609
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    try:
        check_mutually_exclusive([['a', 'b'], ['c', 'd']], dict(a='1', b='2', d='3'))
    except TypeError as e:
        assert e.args[0] == 'parameters are mutually exclusive: a|b, c|d'
    check_mutually_exclusive([['a', 'b'], ['c', 'd']], dict(a='1', d='3'))
    check_mutually_exclusive([['a', 'b'], ['c', 'd']], dict(e='2'))


# Generated at 2022-06-11 01:41:09.207293
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """
    Test that check_mutually_exclusive raises an error on mutually exclusive
    arguments
    """
    try:
        check_mutually_exclusive([['a', 'b'], ['c', 'd']], dict(a=1, b=2, c=3, d=4))
    except TypeError:
        pass



# Generated at 2022-06-11 01:41:16.775936
# Unit test for function check_required_arguments
def test_check_required_arguments():
    params = {'a': 1, 'b': 2, 'c': 3}
    spec = {'a': {'required': True}, 'b': {'required': True}, 'c': {'required': True}}
    result = check_required_arguments(spec, params)
    assert [] == result
    spec = {'b': {'required': True}}
    try:
        result = check_required_arguments(spec, params)
        assert False
    except TypeError as err:
        assert str(err) == "missing required arguments: b"


# Generated at 2022-06-11 01:41:28.771377
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    result = check_mutually_exclusive([['term1', 'term2'], ['term3', 'term4']], {'term1': 'foo', 'term2': 'bar'})
    assert result == []
    try:
        result = check_mutually_exclusive([['term1', 'term2'], ['term3', 'term4']], {'term1': 'foo', 'term4': 'bar'})
    except TypeError as e:
        assert str(e) == 'parameters are mutually exclusive: term1|term2, term3|term4'
    else:
        raise AssertionError('check_mutually_exclusive did not fail')



# Generated at 2022-06-11 01:41:39.787254
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {
        "type": "str",
        "required_by": ["myvalue"]
        }
    parameters = {
        "type": "str",
         "myvalue": "test",
    }
    options_context = []
    results = check_required_by(requirements,parameters,options_context)
    assert(results) == {}

    requirements = {
        "type": "str",
        "required_by": ["myvalue"]
        }
    parameters = {
        "type": "str",
    }
    options_context = []
    results = check_required_by(requirements,parameters,options_context)
    assert(results) == {'type': ['myvalue']}


# Generated at 2022-06-11 01:41:48.979817
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    options = dict(
        int_arg=1,
        str_arg="random string",
        list_arg=[1, 2, 3],
        dict_arg=dict(
            key=3
        )
    )
    mutually_exclusive = [('int_arg', 'str_arg'), 'list_arg']
    # Test for passing list of lists
    check_mutually_exclusive(mutually_exclusive, options)

    # Test for passing a single list
    check_mutually_exclusive(['int_arg', 'str_arg'], options)
    with pytest.raises(TypeError):
        check_mutually_exclusive(mutually_exclusive, dict(options, list_arg=[]))

# Generated at 2022-06-11 01:42:00.838164
# Unit test for function check_required_arguments
def test_check_required_arguments():
    """Unit test for function check_required_arguments

    :returns: True, if the test passes, otherwise False.
    """
    argument_dict = {'req1': {'required': True},
                     'req2': {'required': True},
                     'default': {'default': 'default'},
                     'args': {'required': False}}

    try:
        check_required_arguments(argument_dict, {'req1': 1,
                                                 'default': 'default'})
    except TypeError:
        return False
    except Exception:
        raise

    try:
        check_required_arguments(argument_dict, {'req1': 1,
                                                 'req3': 'not there'})
    except TypeError:
        return False
    except Exception:
        raise


# Generated at 2022-06-11 01:42:12.670061
# Unit test for function safe_eval
def test_safe_eval():
    # literal strings and numbers
    assert safe_eval('True') is True
    assert safe_eval('true') is True
    assert safe_eval('1') == 1
    assert safe_eval(u'1') == 1
    assert safe_eval(u'\u0031') == 1
    assert safe_eval('[1, 2]') == [1, 2]
    assert safe_eval('"foo"') == 'foo'
    # check that it's not just calling str()
    assert safe_eval('[1, 2]') != '[1, 2]'
    assert safe_eval('"foo"') != '"foo"'
    # not json (no double quotes around key)
    assert safe_eval('{foo: "bar"}') == '{foo: "bar"}'
    # not a literal value

# Generated at 2022-06-11 01:42:21.577416
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive([['a', 'b'], 'c'],
                                    dict(a='a', b='b', c='c')) == []
    assert check_mutually_exclusive([['a', 'b', 'c']],
                                    dict(a='a', b='b', c='c')) == [['a', 'b', 'c']]
    assert check_mutually_exclusive([['a', 'b', 'c']], dict(a='a')) == []
    assert check_mutually_exclusive([['a', 'b', 'c']], dict(a='a', b='b')) == [['a', 'b', 'c']]

# Generated at 2022-06-11 01:42:32.044371
# Unit test for function check_required_if
def test_check_required_if():
    parameters = {
        "present_param": True,
        "missing_param": True,
        "cond_param_l1_r1": "r1",
        "cond_param_l1_r2": "r1",
        "cond_param_l1_r3": "r1",
        "cond_param_l2_r1": "r2",
        "cond_param_l3_r1": "r3"
    }

# Generated at 2022-06-11 01:42:43.490862
# Unit test for function check_required_if
def test_check_required_if():
    # Test requirements as tuple
    requirements = [
        ['state', 'present', ('path',), False],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = dict(state='present', path='/tmp/somefile', someint=99)
    results = check_required_if(requirements, parameters)
    assert len(results) == 0
    # Test requirements as list
    requirements = [
        ['state', 'present', ['path'], False],
        ['someint', 99, ['bool_param', 'string_param']],
    ]
    parameters = dict(state='present', path='/tmp/somefile', someint=99)
    results = check_required_if(requirements, parameters)
    assert len(results) == 0
    # Test requirements as tuple
    requirements

# Generated at 2022-06-11 01:42:54.972591
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = dict(
        foo=dict(required=True, type='str'),
        bar=dict(required=True, type='str'),
        baz=dict(required=False, type='str'),
    )
    parameters = dict(foo="foo", bar="bar")
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = dict(foo="foo", baz="baz")
    assert check_required_arguments(argument_spec, parameters) == ['bar']
    parameters = dict(baz="baz")
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert e.args[0] == "missing required arguments: bar, foo"
    else:
        assert False, "Expected TypeError"
    parameters = dict

# Generated at 2022-06-11 01:43:04.640392
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together([("foo", "bar")], {}) == []
    assert check_required_together([("foo", "bar")], {"foo": "", "bar": ""}) == []
    assert check_required_together([("foo", "bar")], {"foo": ""}) == []
    assert check_required_together([("foo", "bar")], {"bar": ""}) == []
    assert check_required_together([("foo", "bar")], {"foobar": ""}) == [['foo', 'bar']]
    assert check_required_together([("foo", "bar")], {"foo": "", "foobar": ""}) == [['foo', 'bar']]



# Generated at 2022-06-11 01:43:17.322549
# Unit test for function check_required_together
def test_check_required_together():
    """Test the check_required_together function"""
    terms = None
    parameters = {}

    results = check_required_together(terms, parameters)
    assert results == []

    terms = [
        ('one', 'two', 'three')]
    parameters = {'one': 'ok', 'two': 'ok', 'three': 'ok'}
    results = check_required_together(terms, parameters)
    assert results == []

    # Test for the case the parameters in the tuple has not the same count
    terms = [
        ('one', 'two', 'three')]
    parameters = {'one': 'ok', 'two': 'ok', 'three': 'missing'}
    results = check_required_together(terms, parameters)
    assert results == [('one', 'two', 'three')]

# Generated at 2022-06-11 01:43:27.718417
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together([("a", "b"), ("c", "d")], dict(a="a", b="b", c="c")) == []
    assert check_required_together([("a", "b"), ("c", "d")], dict(a="a")) == [("a", "b"), ("c", "d")]
    assert check_required_together([("a", "b"), ("c", "d")], dict(a="a", c="c")) == [("a", "b")]
    assert check_required_together([("a", "b"), ("c", "d")], dict(a="a", c="c")) == [("a", "b")]



# Generated at 2022-06-11 01:43:36.363120
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert isinstance(check_type_bytes(dict({'val': '1', 'unit': 'b'})), int)
    assert check_type_bytes(dict({'val': '1', 'unit': 'b'})) == 1
    assert isinstance(check_type_bytes(dict({'val': '1', 'unit': 'KiB'})), int)
    assert check_type_bytes(dict({'val': '1', 'unit': 'KiB'})) == 1024
    assert isinstance(check_type_bytes(dict({'val': '1', 'unit': 'MiB'})), int)
    assert check_type_bytes(dict({'val': '1', 'unit': 'MiB'})) == 1048576

# Generated at 2022-06-11 01:43:47.589123
# Unit test for function check_type_dict
def test_check_type_dict():
    # Test dictionary
    dictionary = {'one': 'two', 'three': 'four'}

    # Test json string
    json_string = '{"one": "two", "three": "four"}'

    # Test equal sign string
    equal_string = 'one=two, three=four'

    # Test equal sign string with spaces
    equal_spaces_string = 'one = two, three = four'

    # Test item with no equal
    no_equal_string = 'one, two=three, four'

    # Testing single string with no equal
    single_no_equal_string = 'one'

    assert check_type_dict(dictionary) == {'one': 'two', 'three': 'four'}
    assert check_type_dict(json_string) == {'one': 'two', 'three': 'four'}

# Generated at 2022-06-11 01:44:07.110819
# Unit test for function check_type_dict

# Generated at 2022-06-11 01:44:09.929389
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    # Invalid value
    assert_raises(TypeError, check_type_bytes, 'xx')



# Generated at 2022-06-11 01:44:22.176479
# Unit test for function check_required_if
def test_check_required_if():
    parameters = dict(parameter=True)
    requirements = [
        ('parameter', True, ('required1', 'required2'), True),
        ('parameter', 'present', ('required3',)),
    ]

    results = check_required_if(requirements, parameters)
    assert not results

    requirements = [
        ('parameter', True, ('required1', 'required2'), True),
        ('test_parameter', 'present', ('required3',)),
    ]

    results = check_required_if(requirements, parameters)
    assert len(results) == 1
    assert results[0]['missing'] == ['required3']
    assert results[0]['requires'] == 'all'
    assert results[0]['parameter'] == 'test_parameter'

# Generated at 2022-06-11 01:44:30.761018
# Unit test for function check_type_dict
def test_check_type_dict():
    assert(check_type_dict('{}') == {})
    assert(check_type_dict('{"a":"b"}') == {"a":"b"})
    assert(check_type_dict('a=b') == {"a": "b"})
    assert(check_type_dict('a=b,c') == {"a": "b", "c": None})
    assert(check_type_dict('a=b,c=d') == {"a": "b", "c": "d"})
    assert(check_type_dict('a=b, c=d') == {"a": "b", "c": "d"})
    assert(check_type_dict('a=b, c=d, e="foo"') == {"a": "b", "c": "d", "e": "foo"})

# Generated at 2022-06-11 01:44:39.238394
# Unit test for function check_required_if
def test_check_required_if():
    # test case when option is not present in the parameters
    requirements = [
        ['state', 'absent', ('path',)],
    ]
    parameters = dict(
        state='present'
    )
    options_context = None
    results = check_required_if(requirements, parameters, options_context)
    assert isinstance(results, list)
    assert not results
    # test case when option is present in the parameters and
    # value is less than requirement value
    requirements = [
        ['state', 'present', ('path',)],
    ]
    parameters = dict(
        state='present'
    )
    options_context = None
    results = check_required_if(requirements, parameters, options_context)
    assert isinstance(results, list)
    assert not results

    # test case when option is present in

# Generated at 2022-06-11 01:44:47.100184
# Unit test for function check_type_bytes
def test_check_type_bytes():
    value = "20M"
    if check_type_bytes(value) != 20971520:
        raise AssertionError("check_type_bytes failed. Expected 20971520 returned '{0}'".format(check_type_bytes(value)))
    print("check_type_bytes passed")

if __name__ == '__main__':
    test_check_type_bytes()
# END - Unit test for function check_tye_bytes


# Generated at 2022-06-11 01:44:52.541795
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    try:
        check_mutually_exclusive([['a'], ['b']], {'a': 'yes', 'b': 'yes'})
    except TypeError as e:
        assert e.args[0] == "parameters are mutually exclusive: a|b, b|a found in "
    else:
        assert False, "Expected TypeError"



# Generated at 2022-06-11 01:44:54.183694
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(2)   == 2
    assert check_type_int('2') == 2


# Generated at 2022-06-11 01:45:04.944467
# Unit test for function check_type_int
def test_check_type_int():
    from ansible.module_utils.six import PY3, integer_types
    from six import string_types
    # Test for int type
    assert check_type_int(10) is 10
    if PY3:
        # Test for int type
        assert check_type_int(10) is 10
    # Test for string type. Convert it to int and return.
    assert check_type_int("60") is 60
    # Test for string type. Convert it to int and return.
    assert check_type_int("10") is 10
    # Test for string type. Convert it to int and return.
    assert check_type_int("20") is 20
    # Test for string type. Convert it to int and return.
    assert check_type_int("30") is 30
    # Test for invalid string type. Raise TypeError.


# Generated at 2022-06-11 01:45:08.379991
# Unit test for function check_type_float
def test_check_type_float():
    assert type(check_type_float('3.2')) == float
    assert type(check_type_float(3.2)) == float
    assert type(check_type_float('-3.2')) == float
    assert type(check_type_float(-3.2)) == float
    assert type(check_type_float(3)) == float
    assert type(check_type_float(-3)) == float
    assert type(check_type_float(3.0)) == float
    assert type(check_type_float(-3.0)) == float


# Generated at 2022-06-11 01:45:20.825684
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('42b') == 42
    assert check_type_bits('42Kb') == 43008
    assert check_type_bits('42Mb') == 44040192
    assert check_type_bits('42Gb') == 452984832
    assert check_type_bits('42Tb') == 46554351616
    assert check_type_bits('42Pb') == 4781217334784
    assert check_type_bits('42Eb') == 49070094696448
    assert check_type_bits('42Zb') == 503380160544768
    assert check_type_bits('42Yb') == 5160593752347648


# Generated at 2022-06-11 01:45:26.201136
# Unit test for function check_type_dict
def test_check_type_dict():
    # Make a dictionary
    d = {"k1": "v1", "k2": "v2"}
    # Convert the dictionary to a string
    s = json.dumps(d)
    # Ensure that the check_type_dict function converts the string back to the original dictionary
    d1 = check_type_dict(s)
    assert d1 == d
    # Ensure that the check_type_dict function returns the dictionary if it is passed a dictionary
    assert d1 == check_type_dict(d)
    # Create a new string in the format that would be passed in by a user as an argument.
    s = "k1=v1, k2=v2"
    # Ensure that the string can be converted to a dictionary by the check_type_dict function
    d2 = check_type_dict(s)
    assert d == d

# Generated at 2022-06-11 01:45:32.574705
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{ 's' * 3 }}") == "sss"
    assert safe_eval("{{ (1, 2) }}") == (1, 2)
    assert safe_eval("{{ {'a': 'b'} }}") == {"a": "b"}
    assert safe_eval("a{{ 'b' }}") == "ab"
    assert safe_eval("ImportError: cannot import name OpenSSL") == "ImportError: cannot import name OpenSSL"



# Generated at 2022-06-11 01:45:37.924510
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1+2') == 3
    assert safe_eval('[1,2]') == [1, 2]
    assert safe_eval('{"a": 1, "b": "2"}') == {'a': 1, 'b': '2'}
    assert safe_eval('1+2', include_exceptions=True) == (3, None)
    assert safe_eval('[1,2]', include_exceptions=True) == ([1, 2], None)
    assert safe_eval('{"a": 1, "b": "2"}', include_exceptions=True) == ({'a': 1, 'b': '2'}, None)
    assert safe_eval('1+') == '1+'
    assert safe_eval('[1,2') == '[1,2'

# Generated at 2022-06-11 01:45:44.543999
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(3) == 3
    assert check_type_int("3") == 3
    assert check_type_int("three") == 3
    try:
        check_type_int("three") == 3
    except ValueError:
        pass
    assert check_type_int("5") == 5
    assert check_type_int("7") == 7
    try:
        assert check_type_int("seven") == 7
    except TypeError:
        pass


# Generated at 2022-06-11 01:45:50.378022
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {"arg1": {"required": True}, "arg2": {"required": False}}
    parameters = {"arg1": "value1"}

    if check_required_arguments(argument_spec, parameters) != []:
        raise  AssertionError()

    try:
        check_required_arguments(argument_spec, {})
        raise AssertionError()
    except TypeError:
        pass



# Generated at 2022-06-11 01:46:02.614605
# Unit test for function check_required_if
def test_check_required_if():
    assert check_required_if(requirements = None, parameters = None) == []
    assert check_required_if([], parameters = None) == []
    assert check_required_if(requirements = [['state', 'present', ('path',)]],
                             parameters = {'path':'/tmp/file.txt',
                                           'state':'present'}) == []
    assert check_required_if(requirements = [['someint', 99, ('bool_param', 'string_param')]],
                             parameters = {'someint':5,
                                           'string_param':'string'}) == []

# Generated at 2022-06-11 01:46:04.025113
# Unit test for function check_type_bytes
def test_check_type_bytes():
  value = '1KiB'
  result = check_type_bytes(value)
  assert result == 1024


# Generated at 2022-06-11 01:46:06.855081
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    with pytest.raises(TypeError) as ee:
        check_type_bits('32Mb')

# Generated at 2022-06-11 01:46:18.963325
# Unit test for function check_required_if
def test_check_required_if():
    assert check_required_if(
        requirements=None,
        parameters={
            'state': 'present',
            'path': '/the/path'
        }
    ) == []
    assert check_required_if(
        requirements=[
            ['state', 'present', ('path',), True],
        ],
        parameters={
            'state': 'present',
            'path': '/the/path'
        }
    ) == []
    assert check_required_if(
        requirements=[
            ['state', 'present', ('path',)],
        ],
        parameters={
            'state': 'present',
            'path': '/the/path'
        }
    ) == []

# Generated at 2022-06-11 01:46:30.832644
# Unit test for function check_mutually_exclusive

# Generated at 2022-06-11 01:46:41.163233
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['a'], ['b']], {'a': 1}) == []
    assert check_required_one_of([['a', 'b']], {'a': 1}) == []
    assert check_required_one_of([['a'], ['b']], {'b': 1}) == []
    assert check_required_one_of([['a'], ['b']], {'a': 1, 'b': 1}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'b': 1, 'c': 1}) == []
    assert check_required_one_of([['a'], ['b']], {}) == [['a', 'b']]

# Generated at 2022-06-11 01:46:50.042351
# Unit test for function check_required_by
def test_check_required_by():
    options_context = None

    # Testing function with valid input
    requirements = {
        "path": ["mode"]
    }
    parameters = {
        "path": "/home",
        "mode": "777"
    }

    actual_result = check_required_by(requirements, parameters, options_context)
    assert actual_result == {}

    # Testing function with invalid input
    parameters = {
        "path": "/home"
    }

    actual_result = check_required_by(requirements, parameters, options_context)
    assert actual_result == {'path': ['mode']}



# Generated at 2022-06-11 01:46:55.512270
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1K') == 1*1024
    assert check_type_bits('1Mb') == 1*1024*1024
    assert check_type_bits('1Gb') == 1*1024*1024*1024
    assert check_type_bits('1Tb') == 1*1024*1024*1024*1024


# Generated at 2022-06-11 01:47:05.804547
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('9mb') == 9437184
    assert check_type_bits('9MB') == 9437184
    assert check_type_bits('9mib') == 100663296
    assert check_type_bits('9Mib') == 100663296

    # larger than maxint, should be converted to int according to python docs
    assert check_type_bits('9Gib') == 976562500

    with pytest.raises(TypeError):
        check_type_bits('1M')

    with pytest.raises(TypeError):
        check_type_bits('1Mbib')



# Generated at 2022-06-11 01:47:16.617968
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{'x': 1, 'y': 2, 'z': 3}") == {"x": 1, "y": 2, "z": 3}
    assert check_type_dict("{x: 1, 'y': 2, \"z\": 3}") == {"x": 1, "y": 2, "z": 3}
    assert check_type_dict("x: 1, y: 2, z: 3") == {"x": "1", "y": "2", "z": "3"}
    assert check_type_dict("'x'='1', 'y':'2', \"z\": '3'") == {"x": "1", "y": "2", "z": "3"}

# Generated at 2022-06-11 01:47:26.512584
# Unit test for function check_type_dict
def test_check_type_dict():
    value_dict = {'key1':'value1', 'key2':'value2'}
    value_string = 'key1=value1,key2=value2'
    value_json = '{"key1":"value1", "key2":"value2"}'
    value_invalid = 'key1=value1=key2=value2'

    assert check_type_dict(value_dict) == {'key1':'value1', 'key2':'value2'}
    assert check_type_dict(value_string) == {'key1':'value1', 'key2':'value2'}
    assert check_type_dict(value_json) == {'key1':'value1', 'key2':'value2'}

# Generated at 2022-06-11 01:47:27.928590
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-11 01:47:29.309760
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert b'10K' == check_type_bytes('10K')



# Generated at 2022-06-11 01:47:38.379431
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes("1K") == 1024
    assert check_type_bytes("1KB") == 1024
    assert check_type_bytes("1M") == 1048576
    assert check_type_bytes("1MB") == 1048576
    assert check_type_bytes("1G") == 1073741824
    assert check_type_bytes("1GB") == 1073741824
    assert check_type_bytes("1T") == 1099511627776
    assert check_type_bytes("1TB") == 1099511627776
    assert check_type_bytes("1KiB") == 1024
    assert check_type_bytes("1MiB") == 1048576
    assert check_type_bytes("1GiB") == 1073741824
    assert check_type_bytes("1TiB") == 1099511627776

# Generated at 2022-06-11 01:47:53.023669
# Unit test for function check_required_if
def test_check_required_if():
    """Unit test for function check_required_if"""
    requirements = [['state', 'present', ('path',), True], ['someint', 99, ('bool_param', 'string_param')]]
    parameters = {'state': 'present', 'path': None}
    options_context = None
    result = [{'parameter': 'state', 'value': 'present', 'requirements': ('path',), 'missing': ['path'], 'requires': 'all'}]
    assert check_required_if(requirements, parameters, options_context) == result

    requirements = [['state', 'present', ('path',), True], ['someint', 99, ('bool_param', 'string_param')]]
    parameters = {'state': 'present', 'path': None}
    options_context = None

# Generated at 2022-06-11 01:48:05.414544
# Unit test for function check_required_together
def test_check_required_together():
    from collections import namedtuple
    from ansible.module_utils.parsing.convert_bool import boolean

    Spec = namedtuple('Spec', [
        'required_together',
    ])

    parameters = {
        'a': True,
        'b': True,
        'c': True,
        'd': True,
        'e': True,
        'f': True,
        'g': True,
        'h': True,
    }

    # test with no optional parameters available
    test_params = [
        (['a', 'b', 'c'], {}),
        (['e', 'f', 'g', 'h'], {}),
        (['a', 'b', 'c'], {'a': True, 'b': True}),
    ]


# Generated at 2022-06-11 01:48:09.204121
# Unit test for function check_required_together
def test_check_required_together():
    try:
        assert(check_required_together([['a', 'b']], {'a': '1'}) == [])
        assert(check_required_together([['a', 'b']], {'a': '1', 'b': '1'}) == [])
        assert(check_required_together([['a', 'b']], {'a': '1', 'b': '1', 'c': '1'}) == [])
        assert(check_required_together([['a', 'b']], {}) == [])
    except TypeError:
        assert(False)

    try:
        assert(check_required_together([['a', 'b']], {'a': '1', 'c': '1'}) != [])
    except TypeError:
        assert(True)
        return
    assert(False)


# Generated at 2022-06-11 01:48:19.060776
# Unit test for function check_required_arguments
def test_check_required_arguments():
    spec = {
        'required': {
            'required': True,
            'type': 'str',
        },
        'not_required': {
            'required': False,
            'type': 'int',
        },
    }
    spec_with_options_context = {'arg1': spec}
    spec_with_options_context['arg1']['options_context'] = ['foo','bar']
    assert check_required_arguments(argument_spec=None, parameters=None) == []
    assert check_required_arguments(argument_spec={}, parameters={}) == []
    assert check_required_arguments(argument_spec={'foo': {'required': True}}, parameters={}) == ['foo']
    assert check_required_arguments(argument_spec={'foo': {'required': False}}, parameters={})

# Generated at 2022-06-11 01:48:29.337456
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # check_mutually_exclusive(terms, parameters, options_context=None)
    # no error
    check_mutually_exclusive(None, {})
    # no error
    params = {'a': 1, 'b': 2}
    check_mutually_exclusive(['a', 'b'], params)
    # no error
    params = {'a': 1, 'b': 2, 'c': 3}
    check_mutually_exclusive([['a', 'b'], ['b', 'c']], params)
    # OK too
    params = {'b': 2, 'c': 3}
    check_mutually_exclusive([['a', 'b'], ['b', 'c']], params)
    # OK too
    params = {'a': 1, 'c': 3}

# Generated at 2022-06-11 01:48:31.002987
# Unit test for function check_required_arguments
def test_check_required_arguments():
    v = '2.4'
    assert 1 == 1



# Generated at 2022-06-11 01:48:42.478403
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('10') == 10
    assert check_type_bytes('10k') == 10 * 1024
    assert check_type_bytes('10K') == 10 * 1024
    assert check_type_bytes('10m') == 10 * 1024 * 1024
    assert check_type_bytes('10M') == 10 * 1024 * 1024
    assert check_type_bytes('10g') == 10 * 1024 * 1024 * 1024
    assert check_type_bytes('10G') == 10 * 1024 * 1024 * 1024
    assert check_type_bytes('10t') == 10 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('10T') == 10 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('10p') == 10 * 1024 * 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-11 01:48:47.660465
# Unit test for function check_required_by
def test_check_required_by():

    requirements = {
        'param1': ['param2', 'param3'],
    }

    parameters = {
        'param1': 'param1 value',
        'param2': None
    }

    with pytest.raises(TypeError):
        check_required_by(requirements, parameters)

    parameters = {
        'param1': 'param1 value',
        'param2': 'param2 value'
    }

    assert check_required_by(requirements, parameters) == {}



# Generated at 2022-06-11 01:48:59.970009
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = [
        ['a', 'b', 'c'],
        ['d', 'e'],
        ['f', 'g']
    ]
    check_mutually_exclusive(terms, {})
    check_mutually_exclusive(terms, {'d': 1})
    try:
        check_mutually_exclusive(terms, {'a': 1, 'b': 2})
    except TypeError:
        pass
    else:
        assert(False)
    try:
        check_mutually_exclusive(terms, {'d': 1, 'e': 2})
    except TypeError:
        pass
    else:
        assert(False)
    try:
        check_mutually_exclusive(terms, {'f': 1, 'g': 2, 'e': 3})
    except TypeError:
        pass

# Generated at 2022-06-11 01:49:07.802440
# Unit test for function check_type_dict
def test_check_type_dict():
    #As dict
    assert check_type_dict({'k': 'v'}) == {'k': 'v'}
    #As JSON
    assert check_type_dict('{"k1":"v1", "k2":"v2"}') == {'k1': 'v1', 'k2': 'v2'}
    #As key=value
    assert check_type_dict('k1=v1, k2=v2') == {'k1': 'v1', 'k2': 'v2'}

    #Invalid JSON
    try:
        check_type_dict('k1:v1, k2:v2')
    except TypeError as err:
        assert to_native(err).endswith('could not parse JSON or key=value')

    #Invalid key=value

# Generated at 2022-06-11 01:49:20.027280
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive([('one','two')], {'one':1,'two':2})
    assert check_mutually_exclusive([['one','two']], {'one':1,'three':2})
    assert check_mutually_exclusive([('one','two')], {'one':1})

    try:
        assert check_mutually_exclusive([('one','two')], {'one':1,'two':2, 'three':3})
    except TypeError:
        pass
    else:
        raise AssertionError("check_mutually_exclusive failed to raise TypeError")



# Generated at 2022-06-11 01:49:32.134979
# Unit test for function check_type_int
def test_check_type_int():
    assert(check_type_int("1") == 1)
    assert(check_type_int("-1") == -1)
    assert(check_type_int("1.0") == 1)
    assert(check_type_int("-1.0") == -1)
    assert(check_type_int("1.1") == 1)
    assert(check_type_int("-1.1") == -1)
    assert(check_type_int("1%") == 1)
    assert(check_type_int("-1%") == -1)
    assert(check_type_int("1,000") == 1000)
    assert(check_type_int("-1,000") == -1000)
    assert(check_type_int(1) == 1)

# Generated at 2022-06-11 01:49:39.803827
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("key1=value1,key2=value2") == {'key1': 'value1', 'key2': 'value2'}
    assert check_type_dict('key1="value1",key2="value2"') == {'key1': 'value1', 'key2': 'value2'}
    assert check_type_dict('key1="value1, value2",key2=value3') == {'key1': 'value1, value2', 'key2': 'value3'}
    assert check_type_dict('key1=\'value1\',key2=value3') == {'key1': 'value1', 'key2': 'value3'}

# Generated at 2022-06-11 01:49:49.914015
# Unit test for function check_required_together
def test_check_required_together():
    # Following code is tested by self
    def get_test_data(test_id):
        test_data = {}
        test_data[1]= {'terms': [['a', 'b', 'c']], 'parameters': {} }
        test_data[2]= {'terms': [['a', 'b', 'c']], 'parameters': {'a':1, 'b':2} }
        test_data[3]= {'terms': [['a', 'b', 'c']], 'parameters': {'a':1, 'b':2, 'c':5 } }
        test_data[4]= {'terms': [['a', 'b', 'c']], 'parameters': {'a':1, 'b':2, 'd':6 } }
        return test_data[test_id]


# Generated at 2022-06-11 01:50:02.137420
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('123Mb') == 12843008
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('1Tb') == 1099511627776
    assert check_type_bits('1Pb') == 1125899906842624
    assert check_type_bits('1Eb') == 1152921504606846976
    assert check_type_bits('1Zb') == 1180591620717411303424
    assert check_type_bits('1Yb') == 1208925819614629174706176
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1b') == 1

# Generated at 2022-06-11 01:50:04.103898
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int("123") == 123


# Generated at 2022-06-11 01:50:07.468563
# Unit test for function safe_eval
def test_safe_eval():
    one = 'test'
    assert safe_eval('1') == 1
    assert safe_eval('test') == 'test'
    assert safe_eval(str(one)) == 'test'
    assert safe_eval('"test"') == 'test'
    assert safe_eval('1+2') == 3

