

# Generated at 2022-06-11 01:40:51.755520
# Unit test for function check_required_if
def test_check_required_if():
    def assert_check_required_if(requirements, parameters, expected_results):
        got_results = check_required_if(requirements, parameters)
        assert len(got_results) == len(expected_results)
        for got_result, expected_result in zip(got_results, expected_results):
            assert got_result['parameter'] == expected_result['parameter']
            assert got_result['value'] == expected_result['value']
            assert got_result['requirements'] == expected_result['requirements']
            assert got_result['missing'] == expected_result['missing']
            assert got_result['requires'] == expected_result['requires']

    # No requirements
    requirements = None

# Generated at 2022-06-11 01:41:01.001115
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(terms=[['a', 'b'], ['c']], parameters={'a': 'a', 'c': 'c'}) == []
    assert check_mutually_exclusive(terms=[['a', 'b'], ['c']], parameters={'a': 'a', 'b': 'b'}) == [['a', 'b']]
    assert check_mutually_exclusive(terms=[['a', 'b'], ['c']], parameters={'a': 'a', 'b': 'b', 'c': 'c'}) == [['a', 'b'], ['c']]



# Generated at 2022-06-11 01:41:04.758163
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments({'a': {'required': True}}, {'a': 'foo'}) == []
    assert check_required_arguments({'a': {'required': True}}, {}) == ['a']



# Generated at 2022-06-11 01:41:06.161005
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-11 01:41:17.086146
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """Test function that checks if terms are mutually exclusive.

    Notes:
        This function is a unit test of the check_mutually_exclusive() function in the
        module_utils/network/common/utils.py file.
    """
    # Test a single exclusion set
    exclusion_set = [['blah', 'baz', 'foo']]
    # Test a combination of invalid exclusions
    parameters = dict(blah=True, foo=True, bar=True, baz=True)
    with pytest.raises(TypeError) as excinfo:
        check_mutually_exclusive(exclusion_set, parameters)

    # Test a combination of valid exclusions
    parameters = dict(blah=True, foo=False, bar=False)
    assert check_mutually_exclusive(exclusion_set, parameters) == []

    # Test

# Generated at 2022-06-11 01:41:24.668298
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {
        "foo": ["bar"],
        "bar": "bas",
        "bat": ["bat"],
    }
    parameters = {
        "foo": "foo",
    }
    assert check_required_by(requirements, parameters) == {
        'foo': ['bar'],
        'bar': ['bat'],
        'bat': [],
    }



# Generated at 2022-06-11 01:41:36.300767
# Unit test for function check_required_together
def test_check_required_together():
        try:
            check_required_together([], {'a': 1})
        except TypeError as e:
            assert False, 'No exception should be raised if terms is None'

        try:
            check_required_together([('a', 'b')], {'a': 1})
        except TypeError as e:
            msg = 'parameters are required together: a, b'
            assert to_native(e) == msg, 'Should throw an exception'

        try:
            check_required_together([('a', 'b')], {'a': 1, 'b': 1})
        except TypeError as e:
            assert False, 'No exception should be raised if terms are valid'


# Generated at 2022-06-11 01:41:44.907934
# Unit test for function check_required_by

# Generated at 2022-06-11 01:41:57.469754
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.common.text.converters import to_text

    terms = [['a', 'b'], ['c', 'd']]
    parameters = dict(a=True, c=True)

    try:
        check_mutually_exclusive(terms, parameters)
        assert False, "should be mutually exclusive"
    except TypeError:
        assert True, "correctly caught error"

    terms = [['a', 'b'], ['c', 'd']]
    parameters = dict(a=True, d=True)

    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        assert False, "should not be mutually exclusive"

    # testing when a term is of type AnsibleUnsafeText

# Generated at 2022-06-11 01:42:07.625388
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1+2') == 3
    assert safe_eval('"a"') == 'a'
    assert safe_eval(b'1') == 1
    assert safe_eval(b'1+2') == 3
    assert safe_eval(b'"a"') == 'a'
    assert safe_eval('"a"+"b"') == 'ab'
    assert safe_eval('set([1, 2, 3])') == {1, 2, 3}
    assert safe_eval('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert safe_eval('1', include_exceptions=True)[0] == 1
    assert safe_eval('1+2', include_exceptions=True)[0] == 3
   

# Generated at 2022-06-11 01:42:21.669956
# Unit test for function check_required_if
def test_check_required_if():
    # check for at least one required parameter
    requirements = [['state', 'present', ('path',), True]]
    parameters = {'state': 'present', 'bool_param': True}
    assert not check_required_if(requirements, parameters)

    requirements = [['state', 'present', ('path',), True]]
    parameters = {'state': 'present'}
    try:
        check_required_if(requirements, parameters)
        assert False
    except TypeError as e:
        assert e.args == ("state is present but any of the following are missing: path",)

    # check that all required parameters are passed
    requirements = [['state', 'present', ('path', 'bool_param'), False]]
    parameters = {'state': 'present', 'bool_param': True}

# Generated at 2022-06-11 01:42:25.856659
# Unit test for function check_type_bytes
def test_check_type_bytes():
    if PY2:
        assert check_type_bytes(1048576) == b"10M"
    else:
        assert check_type_bytes(1048576) == u"10M"
    assert check_type_bytes(1048576) == b"10M"
    #assert check_type_bytes(1048576) == '10M'
    assert check_type_bytes(1024) == '1K'
    assert check_type_bytes(1025) == '1025'
    assert check_type_bytes(0) == '0'



# Generated at 2022-06-11 01:42:34.327985
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = dict(state='present', bool_param=True)
    result = check_required_if(requirements, parameters)
    assert len(result) == 0
    parameters = dict(bool_param=True)
    try:
        result = check_required_if(requirements, parameters)
        assert False
    except TypeError as e:
        assert 'is present but any of the following are missing: path' == to_native(e)


# Generated at 2022-06-11 01:42:45.705250
# Unit test for function check_required_by
def test_check_required_by():
    params = {'key1': True, 'key2': None, 'key3': False, 'key4': 'four'}
    test_result = {'key1': ['key4']}
    requirements = {'key1': ['key4']}
    res = check_required_by(requirements, params, options_context=['test-context'])
    assert (res == test_result)

    params = {'key1': True, 'key2': False, 'key3': False, 'key4': 'four'}
    test_result = {'key2': ['Test_Key'], 'key3': []}
    requirements = {'key2': ['Test_Key'], 'key3': []}
    res = check_required_by(requirements, params, options_context=['test-context'])

# Generated at 2022-06-11 01:42:56.381728
# Unit test for function check_required_if
def test_check_required_if():
    fail = False
    error_msg = None
    parameters = dict(
        state='present',
        path=u'/path/to/nowhere'
    )

    try:
        check_required_if([['state','present',[]],['path','/path/to/nowhere',['temp_name']]],parameters)
    except Exception as e:
        fail = True
        error_msg = str(e)

    if not fail:
        assert False, "check_required_if should have failed for an empty requirement list"

    if error_msg.find('requires at least one of the following') == -1:
        assert False, "check_required_if did not fail with 'requires at least one of the following', the actual error message was %s" % error_msg

    fail = False
    error_msg = None


# Generated at 2022-06-11 01:42:59.940452
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    with pytest.raises(TypeError):
        check_type_bits('1M')

# Generated at 2022-06-11 01:43:04.423418
# Unit test for function check_required_arguments
def test_check_required_arguments():
    parameters = dict(arg=True)
    spec = dict(arg=dict(required=True))
    assert(check_required_arguments(spec, parameters) == [])
    parameters.pop('arg')
    assert(check_required_arguments(spec, parameters) == ['arg'])
# End unit test for function check_required_arguments



# Generated at 2022-06-11 01:43:17.062853
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {'one': 'value', 'three': 'value', 'five': 'value'}
    requirements = {'one': ['three', 'four'], 'three': ['four'], 'five': ['six', 'seven']}
    try:
        assert check_required_by(requirements, parameters, options_context=None) == {'one': ['four'], 'three': ['four'], 'five': ['six', 'seven']}
    except TypeError as e: # noqa
        raise AssertionError
    parameters = {'one': 'value', 'three': 'value'}
    requirements = {'one': [], 'three': []}
    try:
        check_required_by(requirements, parameters, options_context=None)
    except TypeError as e:
        raise AssertionError



# Generated at 2022-06-11 01:43:19.195996
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int("1") == 1
    assert check_type_int("one") == 1
    try:
        check_type_int("false")
    except TypeError:
        pass
    else:
        assert False, ("Expected a TypeError exception to get thrown "
            "but it didn't")


# Generated at 2022-06-11 01:43:31.889799
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = dict(
        arg1=dict(required=True),
        arg2=dict(required=False, choices=['present', 'absent'])
    )

    parameters = dict(arg2='present')
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []

    del parameters['arg2']
    try:
        missing = check_required_arguments(argument_spec, parameters)
        assert False, 'should have failed with TypeError'
    except TypeError as e:
        assert 'missing required arguments' in e.args[0]

    # multiple missing arguments
    parameters = dict(arg3='present')

# Generated at 2022-06-11 01:43:43.432745
# Unit test for function check_type_bytes
def test_check_type_bytes():
    check_type_bytes("2")
    check_type_bytes("2 MB")
    check_type_bytes("2MB")
    check_type_bytes("2m")
    check_type_bytes("2 MiB")
    check_type_bytes("2MiB")
    check_type_bytes("2M")


# Generated at 2022-06-11 01:43:47.946628
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    """
    test required_parameters
    """
    from ansible.module_utils.common.validation import check_missing_parameters
    res = check_missing_parameters({'a': 'a'}, ['a'])
    assert res == []
    res = check_missing_parameters({'a': 'a'}, ['a', 'b'])
    assert res == ['b']



# Generated at 2022-06-11 01:43:58.343570
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert isinstance(check_type_int(1), int)
    assert check_type_int('1') == 1
    assert isinstance(check_type_int('1'), int)
    assert check_type_int(1.5) == 1
    assert isinstance(check_type_int(1.5), int)
    assert check_type_int('1.5') == 1
    assert isinstance(check_type_int('1.5'), int)
    assert check_type_int(0.5) == 0
    assert isinstance(check_type_int(0.5), int)
    assert check_type_int('0.5') == 0
    assert isinstance(check_type_int('0.5'), int)

# Generated at 2022-06-11 01:44:03.305509
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('2Mb') == 2097152
    assert check_type_bits('200Kb') == 204800
    assert check_type_bits('200KB') == 204800
    assert check_type_bits('200kb') == 204800



# Generated at 2022-06-11 01:44:15.640689
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    from ansible.module_utils.common._collections_compat import Mapping
    import numpy as np

    # Assert that the function returns an empty list for a
    # missing parameters when the required_parameters is None
    assert check_missing_parameters(parameters={'test': 1},
                                    required_parameters=None) == []

    # Assert that the function returns a non-empty list for a
    # missing parameters when the required_parameters is not None
    assert check_missing_parameters(parameters={'test': 1},
                                    required_parameters=['fail']) == ['fail']

    # Assert that the function returns an empty list for a
    # missing parameters when the required_parameters is not None

# Generated at 2022-06-11 01:44:20.365590
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True')
    assert safe_eval('False')
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 2*3') == 7
    assert safe_eval('(1 + 2)*3') == 9
    assert safe_eval('1 == 1')
    assert safe_eval('text_type("Hi")') == u'Hi'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('{"key1": "value1", "key2": "value2"}') == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-11 01:44:28.112584
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1+1') == 2
    assert safe_eval('1+1', include_exceptions=True)[0] == 2
    assert safe_eval('import os') == 'import os'
    assert safe_eval('import os', include_exceptions=True)[0] == 'import os'
    assert safe_eval('os.getcwd()') == 'os.getcwd()'
    assert safe_eval('os.getcwd()', include_exceptions=True)[0] == 'os.getcwd()'
    assert safe_eval('{"a": [1,2,3]}', include_exceptions=True)[0] == {"a": [1, 2, 3]}



# Generated at 2022-06-11 01:44:34.486017
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # Check for missing required parameters
    module = AnsibleModule(argument_spec={'required_param': {'required': True}})
    try:
        check_missing_parameters(module.params)
    except TypeError:
        pass
    else:
        assert False, "Should have thrown TypeError with missing required param"

    # Check for missing required parameters
    module = AnsibleModule(argument_spec={'required_param1': {'required': True}, 'required_param2': {'required': True}})
    try:
        check_missing_parameters(module.params)
    except TypeError:
        pass
    else:
        assert False, "Should have thrown TypeError with missing required param"


# Generated at 2022-06-11 01:44:41.186016
# Unit test for function check_required_if
def test_check_required_if():
    """Unit tests for function check_required_if"""
    requirements = []
    params = {}
    assert check_required_if(requirements, params) == []


# Generated at 2022-06-11 01:44:47.294384
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    assert check_missing_parameters({'foo': 'bar'}, required_parameters=['foo']) == []
    assert check_missing_parameters({'foo': 'bar'}, required_parameters=['foo', 'bar']) == ['bar']
    assert check_missing_parameters({}, required_parameters=['foo', 'bar']) == ['foo', 'bar']


# Generated at 2022-06-11 01:45:01.484426
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1MB') == 1048576
    assert check_type_bits('1MBit') == 1048576
    assert check_type_bits('1MBit') == 1048576
    assert check_type_bits('1 Mb') == 1048576
    assert check_type_bits('1 Mbit') == 1048576
    assert check_type_bits('1 MB') == 1048576
    assert check_type_bits('1 MBit') == 1048576
    assert check_type_bits('1 MBit') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1mbit') == 1048576

# Generated at 2022-06-11 01:45:10.763410
# Unit test for function check_type_dict
def test_check_type_dict():

    assert check_type_dict({'a' : 1}) == {'a' : 1}
    assert check_type_dict('{"a" : 1}') == {"a" : 1}
    assert check_type_dict('a="1", b="2"') == {"a" : "1", "b" : "2"}
    try:
        check_type_dict('a="1", b="2')
        assert 1 == 2
    except TypeError:
        assert 1 == 1
    try:
        check_type_dict('a="1", b="2')
        assert 1 == 2
    except TypeError:
        assert 1 == 1


# Generated at 2022-06-11 01:45:17.966074
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576, 'Error check_type_bytes function'
    assert check_type_bytes('1G') == 1073741824, 'Error check_type_bytes function'
    assert check_type_bytes('1T') == 1099511627776, 'Error check_type_bytes function'
    assert check_type_bytes('1K') == 1024, 'Error check_type_bytes function'
    assert check_type_bytes('1') == 1, 'Error check_type_bytes function'



# Generated at 2022-06-11 01:45:30.651883
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(1000) == 1000
    assert check_type_bytes('1Gb') == 1073741824
    assert check_type_bytes('1KB') == 1 * 1024
    assert check_type_bytes('1MB') == 1 * 1024 * 1024
    assert check_type_bytes('1GB') == 1 * 1024 * 1024 * 1024
    assert check_type_bytes('1TB') == 1 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1PB') == 1 * 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1EB') == 1 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1ZB') == 1 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1YB') == 1

# Generated at 2022-06-11 01:45:32.623804
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-11 01:45:37.964736
# Unit test for function safe_eval
def test_safe_eval():
    # Basic test of safe_eval
    assert safe_eval('1+3') == 4
    assert safe_eval('[1]') == [1]
    assert safe_eval('{1:1}') == {1: 1}
    # Create a mock exception
    class MockException(Exception):
        pass
    # Test safe_eval with some code that should fail
    assert safe_eval('a') == 'a'
    assert safe_eval('1+') == '1+'
    assert safe_eval('1+', include_exceptions=True) == ('1+', None)
    assert safe_eval(os, include_exceptions=True) == (os, None)
    assert safe_eval('import math', include_exceptions=True) == ('import math', None)

# Generated at 2022-06-11 01:45:41.741318
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('dict(a=1, b=2)') == {"a": 1, "b": 2}
    assert safe_eval("'a'") == 'a'
    assert safe_eval("u'a'") == 'a'
    assert safe_eval('1.1') == 1.1
    assert safe_eval('[1, {"a": "b"}]') == [1, {"a": "b"}]

# Generated at 2022-06-11 01:45:52.169054
# Unit test for function check_required_arguments
def test_check_required_arguments():
    import json
    import os
    import tempfile
    import traceback
    import sys
    import pytest

    # Since this module is always imported by the _AnsibleModule class, we have
    # to use the full path to import
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_iterable


# Generated at 2022-06-11 01:46:03.760340
# Unit test for function check_required_together
def test_check_required_together():
    # Test all required together
    terms = [['a', 'b']]
    parameters = dict(a='1', b='2')
    result = check_required_together(terms, parameters)
    assert result == []
    # Test one of multiple required together
    terms = [['a', 'b', 'c'], ['d', 'e']]
    parameters = dict(a='1', b='2', d='3')
    result = check_required_together(terms, parameters)
    assert result == []
    # Test one of multiple required together
    terms = [['a', 'b', 'c'], ['d', 'e']]
    parameters = dict(a='1', b='2', e='3')
    result = check_required_together(terms, parameters)
    assert result == []
    # Test missing one of required together

# Generated at 2022-06-11 01:46:05.002033
# Unit test for function check_type_bits
def test_check_type_bits():
    assert 1048576 == check_type_bits('1Mb')


# Generated at 2022-06-11 01:46:15.595132
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('10B') == 10
    assert check_type_bytes('10K') == 10240
    assert check_type_bytes('10M') == 10485760
    assert check_type_bytes('10G') == 10737418240
    assert check_type_bytes('10T') == 10995116277760
    assert check_type_bytes('10P') == 11258999068426240



# Generated at 2022-06-11 01:46:19.662854
# Unit test for function check_required_one_of

# Generated at 2022-06-11 01:46:27.071282
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = dict(
        dict1=dict(required=True)
    )
    parameters = dict(dict1='value')
    assert [] == check_required_arguments(argument_spec, parameters)

    argument_spec = dict(
        dict1=dict(required=True),
        dict2=dict(required=True)
    )
    parameters = dict(dict2='value')
    try:
        check_required_arguments(argument_spec, parameters)
        assert False
    except TypeError as e:
        assert "missing required arguments: dict1" == to_native(e)



# Generated at 2022-06-11 01:46:37.757217
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('import bar') == 'import bar'
    assert safe_eval('[foo, bar]') == ['foo', 'bar']
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('foo.bar()', include_exceptions=True) == ('foo.bar()', None)
    assert safe_eval('[foo, bar]', include_exceptions=True) == (['foo', 'bar'], None)
    assert safe_eval('module.function()') == 'module.function()'
    assert safe_eval('module.function()', include_exceptions=True) == ('module.function()', None)



# Generated at 2022-06-11 01:46:41.754138
# Unit test for function check_required_together
def test_check_required_together():
    res = check_required_together([('a', 'b')], {'a': 'A', 'c': 'C'})
    if res == [('a', 'b')]:
        print("check_required_together function works as expected")
    else:
        print("check_required_together function does not work as expected")


# Generated at 2022-06-11 01:46:43.292787
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-11 01:46:55.331526
# Unit test for function check_required_together
def test_check_required_together():
    params = dict(
        one=1,
        two=2,
        three=3,
        four=4,
        five=5,
        six=6,
        seven=7,
        eight=8,
        nine=9,
        ten=10,
    )

    try:
        check_required_together(terms=[('one', 'two'), ('three', 'four')], parameters=params)
    except TypeError:
        assert False, "check_required_together failed"

    # fail

# Generated at 2022-06-11 01:47:00.619843
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(10) == 10
    assert check_type_int("10") == 10
    assert check_type_int(1.0) == 1
    assert check_type_int("1.0") == 1
    assert check_type_int("abc") == "abc"


# Generated at 2022-06-11 01:47:08.246803
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert(check_type_bytes('1m') == 1048576)
    assert(check_type_bytes('2.5g') == 2684354560)
    assert(check_type_bytes('3T') == 32212254720)  # WARNING: This is in Byte
                                                   # Any value above 2**32 will overflow an Int32
    assert(check_type_bytes('4') == 4)
    assert(check_type_bytes(4) == 4)
    assert(check_type_bytes(4.2) == 4)
    assert(check_type_bytes(4.9) == 4)
    try:
        check_type_bytes('invalid string')
        assert False
    except TypeError as e:
        assert True


# Generated at 2022-06-11 01:47:18.020620
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1 Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1 Mb') == 1048576
    assert check_type_bits('2 Kb') == 2048
    assert check_type_bits('3 kb') == 3072
    assert check_type_bits('4 GB') == 34359738368
    assert check_type_bits('5 gb') == 42949672960
    assert check_type_bits('6 tb') == 6871947673600
    assert check_type_bits('7 TB') == 8589934592000
    assert check_type_bits('8 pb') == 1125899906842624
    assert check_type_

# Generated at 2022-06-11 01:47:29.106690
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{ "a": 1, "b": 2 }') == {"a": 1, "b": 2}
    assert check_type_dict('{ "a": "1,2", "b": [1,2,3] }') == {"a": "1,2", "b": [1,2,3]}
    assert check_type_dict('a=1,b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a=1, b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a="1,2",b=[1,2,3]') == {"a": "1,2", "b": "[1,2,3]"}

# Generated at 2022-06-11 01:47:38.248489
# Unit test for function check_type_bits

# Generated at 2022-06-11 01:47:50.531360
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('5M') == 5242880
    assert check_type_bytes('20g') == 21474836480
    assert check_type_bytes('100') == 100
    assert check_type_bytes('0xabc') == 2748
    assert check_type_bytes('-2T') == -2199023255552
    assert check_type_bytes('-2t') == -2199023255552
    assert check_type_bytes(-21474836480) == -21474836480
    assert check_type_bytes(5242880) == 5242880
    assert check_type_bytes(0) == 0
    assert check_type_bytes(None) == None
    assert check_type_bytes('') == None
    assert check_type_bytes('abc') == None



# Generated at 2022-06-11 01:48:02.371427
# Unit test for function check_type_dict

# Generated at 2022-06-11 01:48:11.100977
# Unit test for function check_type_bits
def test_check_type_bits():
    # test if bits can be converted to integer correctly
    assert check_type_bits('1Gb') == 1073741824

    # test if bits can be returned as original value
    assert check_type_bits(1073741824) == 1073741824

    # test if unexpected values passed in will raise error
    try:
        check_type_bits('1Tb')
        pytest.fail('It was unexpected that we were able to convert \'1Tb\' to a Bit value.')
    except TypeError as e:
        assert str(e) == '<class \'str\'> cannot be converted to a Bit value'



# Generated at 2022-06-11 01:48:14.114853
# Unit test for function check_type_float
def test_check_type_float():
    with pytest.raises(TypeError):
        check_type_float(['test'])
    assert check_type_float('1.1') == 1.1
    assert check_type_float(1) == 1.0
    assert check_type_float(1.0) == 1.0


# Generated at 2022-06-11 01:48:22.211968
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.return_values import ReturnData
    import sys

    # passing an integer should return the same
    assert safe_eval(1) == 1

    # passing a float should return the same
    assert safe_eval(1.1) == 1.1

    # passing a string should return the same
    assert safe_eval('foo') == 'foo'

    # strings with spaces are not safe
    assert safe_eval(' foo bar ') == ' foo bar '

    # passing a boolean True or False should return the actual boolean
    assert safe_eval(True) is True
    assert safe_eval(False) is False

    # empty constructs should evaluate to the basic empty structure
    assert safe_eval('') == ''
    assert safe_eval('[]') == []
    assert safe_eval('()') == ()


# Generated at 2022-06-11 01:48:26.203207
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("2 + 2") == 4
    assert safe_eval("['a', 'b', 'c']") == ['a', 'b', 'c']
    assert safe_eval("foo.bar()", include_exceptions=True) == ("foo.bar()", None)



# Generated at 2022-06-11 01:48:37.240407
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    def setup_function(self):
        self.parameters = {'my_ip': '10.1.1.1', 'my_int': 10, 'my_str': 'foo'}
        self.expected_results_no_failure = []
        self.expected_results_failure = [['my_ip', 'my_int']]
        self.terms_success = ['my_ip', 'my_str']
        self.terms_failure = [['my_ip', 'my_int'], ['my_str']]
        self.options_context = ['options_context']

    def test_no_failure(self):
        self.assertEqual(check_mutually_exclusive(self.terms_success, self.parameters), self.expected_results_no_failure)

# Generated at 2022-06-11 01:48:45.371321
# Unit test for function check_type_bytes
def test_check_type_bytes():
    test_values = [
        ('10k', 10240),
        ('16g', 17179869184),
        ('1GB', 1073741824),
        ('4KiB', 4096),
        ('4.2KB', 4250),
        ('4.2GB', 4498046511104)
    ]
    for value, result in test_values:
        assert check_type_bytes(value) == result, \
            '%s did not produce expected result %s, produced %s instead' % \
            (value, result, check_type_bytes(value))


# Generated at 2022-06-11 01:48:55.964820
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(3.14) == 3.14
    assert check_type_float(3) == 3
    assert check_type_float('3.14') == 3.14
    assert check_type_float(b'3.14') == 3.14
    success = False
    try:
        check_type_float(b'ascii')
    except TypeError:
        success = True
    assert success



# Generated at 2022-06-11 01:49:05.749008
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['test', 'test1'], ['test2', 'test3']]
    parameters = dict(test=10, test1=20)
    assert check_required_together(terms, parameters) == []
    parameters = dict(test=10)
    try:
        assert check_required_together(terms, parameters) == []
    except:
        pass
    parameters = dict(test=10, test3=20)
    try:
        assert check_required_together(terms, parameters) == []
    except:
        pass
    terms = [['test', 'test1'], ['test2', 'test3']]
    parameters = dict(test=10, test1=20, test2=30, test3=50)

# Generated at 2022-06-11 01:49:14.388109
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(
        terms=[['one', 'two', 'three'], ['four', 'five']],
        parameters=dict(one='', four='', six='')
    ) == []

    try:
        assert check_mutually_exclusive(
            terms=[['one', 'two', 'three'], ['four', 'five']],
            parameters=dict(one='', two='', four='', six='')
        ) == []
    except TypeError:
        pass
    else:
        raise AssertionError('Mutually exclusive parameters not detected')


# Generated at 2022-06-11 01:49:22.815097
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float("1") == 1.0
    assert check_type_float("1.0") == 1.0
    assert check_type_float("64") == 64.0
    assert check_type_float("64.0") == 64.0
    assert check_type_float(b"64") == 64.0
    assert check_type_float(b"64.0") == 64.0
    assert check_type_float(to_text(64, errors='surrogate_or_strict')) == 64.0
    assert check_type_float(to_text(64.0, errors='surrogate_or_strict')) == 64.0
    assert check

# Generated at 2022-06-11 01:49:34.574107
# Unit test for function safe_eval
def test_safe_eval():
    # Test normal value
    assert 'string' == safe_eval("string")
    # Test value with BAD characters templates
    assert "{{{}}}}" == safe_eval("{{{}}}}")
    # Test value with method call
    assert "1.something()" == safe_eval("1.something()")
    # Test value with import call
    assert "import something" == safe_eval("import something")
    # Test normal value with include_exceptions
    assert ('string', None) == safe_eval("string", include_exceptions=True)
    # Test value with BAD characters templates with include_exceptions
    assert ("{{{}}}}", None) == safe_eval("{{{}}}}", include_exceptions=True)
    # Test value with method call with include_exceptions
    assert ("1.something()", None) == safe_eval

# Generated at 2022-06-11 01:49:41.972186
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('"test"') == "test"
    assert safe_eval('1') == 1
    assert safe_eval('[1, 2]') == [1, 2]
    assert safe_eval('{"k": "v"}') == {"k": "v"}
    assert safe_eval('None') is None
    assert safe_eval('False') is False
    assert safe_eval('True') is True
    # next one should throw an exception
    assert safe_eval('1 + 1') == '1 + 1'



# Generated at 2022-06-11 01:49:51.056618
# Unit test for function check_type_bytes
def test_check_type_bytes():
    test_cases = [
        ('bytes', b'bytes'),
        ('1KB', 1024),
        ('1K', 1024),
        ('1MB', 1024*1024),
        ('1M', 1024*1024),
        ('1GB', 1024*1024*1024),
        ('1G', 1024*1024*1024),
    ]
    for val, expected in test_cases:
        new_val = check_type_bytes(val)
        assert new_val == expected, "%s: %s != %s" % (val, new_val, expected)

# Mapping of type names to validator functions

# Generated at 2022-06-11 01:49:54.310834
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("k1=v1, k2=v2") == {"k1": "v1", "k2": "v2"}



# Generated at 2022-06-11 01:50:06.007136
# Unit test for function check_type_dict

# Generated at 2022-06-11 01:50:15.970444
# Unit test for function check_required_arguments
def test_check_required_arguments():
    arguments = {
        'a': dict(required=False),
        'b': dict(required=False),
    }

    assert check_required_arguments(arguments, dict()) == list()
    assert check_required_arguments(arguments, dict(a='foo')) == list()
    assert check_required_arguments(arguments, dict(a='foo', b='bar')) == list()
    assert check_required_arguments(arguments, dict(b='bar')) == list()

    arguments = {
        'a': dict(required=True),
        'b': dict(required=False),
    }

    assert check_required_arguments(arguments, dict(a='foo')) == list()
    assert check_required_arguments(arguments, dict(a='foo', b='bar')) == list