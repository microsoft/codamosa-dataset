

# Generated at 2022-06-11 01:40:53.117589
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    test_params = dict(name='hostname',
            user='admin',
            password='password123',
            host='1.1.1.1')
    required_params = ['name', 'user', 'password', 'host']
    options_context = ['mock']

    assert check_missing_parameters(test_params, required_params) == []

    required_params.append('extra')

    try:
        check_missing_parameters(test_params, required_params)
        assert False
    except TypeError as e:
        assert to_native(e) == "missing required arguments: extra"



# Generated at 2022-06-11 01:41:05.240807
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Required argument not present
    argument_spec = dict(
        arg1=dict(required=True),
    )
    params = dict(
        arg2=2,
    )
    msg = "missing required arguments: arg1"
    assert check_required_arguments(argument_spec, params) == msg

    # Required argument is empty
    argument_spec = dict(
        arg1=dict(required=True, type='str'),
        arg2=dict(type='str')
    )
    params = dict(
        arg1='',
    )
    msg = "missing required arguments: arg1"
    assert check_required_arguments(argument_spec, params) == msg

    # Required argument present

# Generated at 2022-06-11 01:41:14.626835
# Unit test for function check_required_together
def test_check_required_together():
    # Test with valid parameters
    terms = ([["param1", "param2"]])
    parameters = {"param1": "value1", "param2": "value2"}
    required_together_result = check_required_together(terms, parameters)
    assert len(required_together_result) == 0

    # Test with invalid parameters
    terms = ([["param1", "param2"]])
    parameters = {"param1": "value1"}
    try:
        required_together_result = check_required_together(terms, parameters)
        if required_together_result:
            return True
    except TypeError:
        return True



# Generated at 2022-06-11 01:41:20.711862
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {'name': {'required': True, 'type': 'str'},
                     'state': {'default': 'present', 'required': False, 'choices': ['present', 'absent']}}
    parameters = {}
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert e.args[0] == "missing required arguments: name"
    else:
        assert False, "check_required_arguments did not raise TypeError as expected"



# Generated at 2022-06-11 01:41:32.897410
# Unit test for function check_required_arguments
def test_check_required_arguments():
    missing = check_required_arguments({}, {})
    assert len(missing) == 0

    missing = check_required_arguments({'a': {}}, {})
    assert len(missing) == 0

    missing = check_required_arguments({'a': {}}, {'a': None})
    assert len(missing) == 0

    missing = check_required_arguments({'a': {'required': True}}, {'a': None})
    assert len(missing) == 0

    missing = check_required_arguments({'a': {'required': True}}, {})
    assert len(missing) == 1
    assert missing[0] == 'a'

    missing = check_required_arguments({'a': {'default': 'x'}}, {})
    assert len(missing) == 0

    missing = check_

# Generated at 2022-06-11 01:41:43.009089
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # check_mutually_exclusive returns empty list when checks are valid
    assert check_mutually_exclusive([['a', 'b']], {'a': 1, 'b': 2}) == []
    assert check_mutually_exclusive([['a', 'b']], {'a': 1}) == []
    assert check_mutually_exclusive([['a', 'b']], {'b': 2}) == []
    assert check_mutually_exclusive([['a', 'b']], {}) == []
    # check_mutually_exclusive raises TypeError when checks are invalid

# Generated at 2022-06-11 01:41:49.484425
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    arguments = dict()
    required_params = None
    assert check_missing_parameters(arguments, required_params) == []

    required_params = ['a', 'b']
    assert check_missing_parameters(arguments, required_params) == required_params

    arguments = dict(a='b')
    required_params = ['a', 'b']
    assert check_missing_parameters(arguments, required_params) == ['b']



# Generated at 2022-06-11 01:41:52.710759
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive([['foo', 'bar']], {'foo': 1, 'bar': 2}) == [["foo", "bar"]]



# Generated at 2022-06-11 01:42:01.610405
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by(requirements={"key1": "value1", "key2": "value2"},
                             parameters={"key1": "value1", "key2": "value2", "value1": "value3", "value2": "value4"}) == {}
    assert check_required_by(requirements={"key1": "value1", "key2": "value2"},
                             parameters={"key1": "value1", "value1": "value3", "value2": "value4"}) == {'key1': ['value2'], 'value1': ['key2']}



# Generated at 2022-06-11 01:42:11.225193
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/',
        'someint': 99,
    }
    assert check_required_if(requirements, parameters) == []
    assert check_required_if(requirements, parameters) == []
    parameters = {
        'state': 'present',
        'someint': 99,
    }
    assert check_required_if(requirements, parameters) == [{'missing': ['path'], 'requires': 'any', 'parameter': 'state', 'value': 'present', 'requirements': ('path',)}]
    parameters = {
        'someint': 99,
    }
    assert check

# Generated at 2022-06-11 01:42:22.573011
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1.5Mb') == 1572864
    assert check_type_bits(1.5) == 1.5



# Generated at 2022-06-11 01:42:32.444034
# Unit test for function check_required_if
def test_check_required_if():
    # prepare a list of requirements
    requirements = [
        # check if 'key' equals to 'val'
        # if 'key' equals to 'val', at least one of 'requirements' is required.
        ['key', 'val', ['requirement1', 'requirement2'], True],
        # if 'key' equals to 'val', 'requirements' are required.
        ['key', 'val', ('requirement3', 'requirement4')],
    ]
    # prepare parameters for the function check_required_if
    parameters = {
        'key': 'val',
    }
    # check the function
    missing = check_required_if(requirements, parameters)
    # get the list of missing requirements
    missing_requirements = []
    for item in missing:
        missing_requirements.extend(item['missing'])

# Generated at 2022-06-11 01:42:43.743286
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval('True and False') == False
    assert safe_eval('True and True') == True
    assert safe_eval(True and False) == False
    assert safe_eval(True) == True
    assert safe_eval(False) == False
    assert safe_eval(True and False) == False
    assert safe_eval(True and True) == True
    assert safe_eval('x', {'x': False}) == False
    assert safe_eval('{1: 2, 2: 1}') == {1: 2, 2: 1}
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)


# Generated at 2022-06-11 01:42:52.776518
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    result = check_missing_parameters(parameters={'state': 'present'}, required_parameters=['state', 'path'])
    assert result == ['path']
    result = check_missing_parameters(parameters={'state': 'present', 'path': '/path/to/file'}, required_parameters=['state', 'path'])
    assert result == []
    result = check_missing_parameters(parameters={'state': 'present', 'path': '/path/to/file'}, required_parameters=[])
    assert result == []


# Generated at 2022-06-11 01:43:04.898661
# Unit test for function check_required_together
def test_check_required_together():

    def check_required_together_success(params):
        params = {'parameters': params}
        check_required_together([['one', 'two', 'three'], ['four', 'five']], params)

    def check_required_together_failure(params):
        params = {'parameters': params}
        try:
            check_required_together([['one', 'two', 'three'], ['four', 'five']], params)
        except TypeError as e:
            if 'required together' not in e.args[0]:
                raise Exception('check_required_together_failure raised incorrect error: {0}\nExpected error message to include "required together"'.format(e.args[0]))

    # Case: Everything required is present

# Generated at 2022-06-11 01:43:10.305175
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1MB') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1m') == 8388608



# Generated at 2022-06-11 01:43:20.344089
# Unit test for function safe_eval
def test_safe_eval():
    # None parameter
    assert safe_eval(None) == None
    # String parameters
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("{'a':'b'}") == {'a': 'b'}
    assert safe_eval("('a','b')") == ('a','b')
    assert safe_eval("'True'") == 'True'
    # Boolean parameters
    assert safe_eval("True") == True
    assert safe_eval("False") == False
    assert safe_eval("None") == None
    assert safe_eval("1 == 1") == True
    assert safe_eval("2 == 3") == False

# Generated at 2022-06-11 01:43:23.131342
# Unit test for function check_required_by
def test_check_required_by():
    try:
        requirements = {'a': 'b'}
        test_parameters = {'a': None, 'b': 2}
        check_required_by(requirements, test_parameters)
    except Exception as e:
        print ("An unpexpected exception is thrown: {0}".format(e))



# Generated at 2022-06-11 01:43:30.017678
# Unit test for function safe_eval
def test_safe_eval():
    assert(safe_eval('foo') == 'foo')
    assert(safe_eval('1+2') == 3)
    assert(safe_eval('foo.bar()') == 'foo.bar()')
    assert(safe_eval('import os') == 'import os')
    assert(safe_eval('{1:2}') == {1: 2})



# Generated at 2022-06-11 01:43:34.687852
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('5') == 5
    assert safe_eval('{"a":5}') == {'a': 5}
    assert safe_eval('yyy') == 'yyy'
    # do not allow method calls to modules
    assert safe_eval('y.z(y)') == 'y.z(y)'
    # do not allow imports
    assert safe_eval('import sys') == 'import sys'



# Generated at 2022-06-11 01:43:44.809915
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1')   == 1
    assert check_type_bits('1MB') == 1048576


# Generated at 2022-06-11 01:43:56.752103
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int('-2') == -2
    assert check_type_int('0') == 0
    assert check_type_int('2') == 2
    assert check_type_int(2) == 2
    try:
      check_type_int(-2.1)
      assert(0)
    except TypeError as e:
      assert(str(e) == "<type 'float'> cannot be converted to an int")
    try:
      check_type_int(2.1)
      assert(0)
    except TypeError as e:
      assert(str(e) == "<type 'float'> cannot be converted to an int")

# Generated at 2022-06-11 01:44:03.201230
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{"a": "b"}') == {"a": "b"}
    assert safe_eval('["a", "b"]') == ["a", "b"]
    assert safe_eval('7') == 7
    assert safe_eval('"test"') == 'test'
    assert safe_eval('"{"') == '{'
    assert safe_eval('"{"', include_exceptions=True) == ('{', None)
    assert safe_eval('"test\n"') == 'test\n'
    assert safe_eval('["a", {"b": "c"}]') == ['a', {'b': 'c'}]
    assert safe_eval('["a", {"b": "c"}]', include_exceptions=True) == (['a', {'b': 'c'}], None)
    assert safe

# Generated at 2022-06-11 01:44:15.640748
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1Kib') == 1024
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('1Gib') == 1073741824
    assert check_type_bits('1Tb') == 1099511627776
    assert check_type_bits('1Tib') == 1099511627776
    assert check_type_bits('1Pb') == 1125899906842624
    assert check_type_bits('1Pib') == 1125899906842624
    assert check_type_bits('1Eb') == 11529215046068469

# Generated at 2022-06-11 01:44:20.365940
# Unit test for function check_required_together
def test_check_required_together():
    e = TypeError
    terms = [["arg1","arg2","arg3"],["arg4","arg5","arg6"]]
    parameters = {'arg1':'1'}
    with pytest.raises(e):
        check_required_together(terms,parameters)
    parameters = {'arg1':'1','arg2':'2','arg3':'3'}
    check_required_together(terms,parameters)
    parameters = {'arg1':'1','arg2':'2'}
    with pytest.raises(e):
        check_required_together(terms,parameters)
    parameters = {'arg1':'1','arg2':'2','arg4':'4'}
    check_required_together(terms,parameters)

# Generated at 2022-06-11 01:44:28.921951
# Unit test for function check_type_dict
def test_check_type_dict():
    # Test against valid string
    test_dict = check_type_dict('{"exact_count":1}')
    assert test_dict == {"exact_count": 1}, "Failed to convert string to dictionary"
    test_dict = check_type_dict('exact_count=1')
    assert test_dict == {"exact_count": "1"}, "Failed to convert a string with KVs separated by space to dictionary"
    test_dict = check_type_dict('exact_count=1,exact_count=2')
    assert test_dict == {"exact_count": "2"}, "Failed to convert a string with multiple KVs to dictionary"
    test_dict = check_type_dict('exact_count="1"')

# Generated at 2022-06-11 01:44:34.917858
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments({}, {}) == []
    assert check_required_arguments(None, None) == []

    argument_spec = {'name': {'required': True}}
    assert check_required_arguments(argument_spec, {}) == ['name']
    assert check_required_arguments(argument_spec, {'name': None}) == []
    assert check_required_arguments({'name': {'required': False}}, {}) == []



# Generated at 2022-06-11 01:44:44.757312
# Unit test for function safe_eval

# Generated at 2022-06-11 01:44:55.175032
# Unit test for function check_type_bytes

# Generated at 2022-06-11 01:45:06.250085
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(1) == 1
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1kb') == 1024
    assert check_type_bytes('1Kb') == 1024
    assert check_type_bytes('1Mb') == 1048576
    assert check_type_bytes('1Gb') == 1073741824
    assert check_type_bytes('1Tb') == 1099511627776
    assert check_type_bytes('1Pb') == 1125899906842624
    assert check_type_bytes('1Eb') == 1152921504606846976
    assert check_type_bytes('1Zb') == 1180591620717411303424
    assert check_type_bytes('1Yb') == 1208925819614629174706176
   

# Generated at 2022-06-11 01:45:11.264897
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576


# Generated at 2022-06-11 01:45:19.874727
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [['src','dest'],['src','dest','force','link','co','alias','user','reload','backup','checksum']]
    parameters = {'dest': 'Any value', 'force': 'Any value'}
    try:
        check_required_one_of(terms,parameters)
    except Exception as err:
        assert err.args[0] == "one of the following is required: src, dest"
    try:
        parameters = {'owner': 'Any value'}
        check_required_one_of(terms,parameters)
    except Exception as err:
        assert err.args[0] == "one of the following is required: src, dest"


# Generated at 2022-06-11 01:45:25.330140
# Unit test for function check_required_if
def test_check_required_if():
    parameters = {
        'state': 'present',
        'path': '/foo/bar',
        'someint': 99,
        'bool_param': False,
    }

    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]

    missing = check_required_if(requirements, parameters)
    assert missing[0]['parameter'] == 'someint'
    assert missing[0]['value'] == 99
    assert missing[0]['requirements'] == ('bool_param', 'string_param')
    assert missing[0]['missing'] == ['string_param']
    assert missing[0]['requires'] == 'all'



# Generated at 2022-06-11 01:45:28.314422
# Unit test for function check_type_bits
def test_check_type_bits():
    for human_readable, bits in [('0', 0), ('1b', 1), ('1m', 2**20), ('1k', 2**10)]:
        assert check_type_bits(human_readable) == bits


# Generated at 2022-06-11 01:45:39.768735
# Unit test for function check_required_if
def test_check_required_if():
    test_cases = [
        # Test the function with proper input.
        ("req", "arg", [["param", "val", ["arg"]], ["param1", "val1", ["arg1"], True]], None),
        # Test the function with improper input.
        ([["param", "val"], ["param1", "val1", "arg", True], []], "arg", None, TypeError),
    ]
    for (requirements, parameters, expected_result, err_type) in test_cases:
        try:
            if err_type is not None:
                check_required_if(requirements, parameters)
                assert(False)
            else:
                assert(check_required_if(requirements, parameters) == expected_result)
        except Exception as e:
            assert(type(e) == err_type)
    print

# Generated at 2022-06-11 01:45:50.682819
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("a=1, b=2") == {u"a": u"1", u"b": u"2"}
    assert check_type_dict("a=1, b=2, c=foo") == {u"a": u"1", u"b": u"2", u"c": u"foo"}
    assert check_type_dict("a=1, b=2, c='foo bar'") == {u"a": u"1", u"b": u"2", u"c": u"foo bar"}
    assert check_type_dict("a=1, b=2, c='foo \"bar'") == {u"a": u"1", u"b": u"2", u"c": u"foo \"bar"}

# Generated at 2022-06-11 01:45:53.792462
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1


# Generated at 2022-06-11 01:45:57.424986
# Unit test for function check_type_float
def test_check_type_float():
    """Unit test for function check_type_float
    """
    check_type_float_value_list = [3.0, b'3.0', '3.0', 3]
    for value in check_type_float_value_list:
        assert check_type_float(value) == 3.0

    # Function raises an exception if value is not a float
    with pytest.raises(TypeError):
        value = 'foo'
        check_type_float(value)



# Generated at 2022-06-11 01:46:07.328532
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    import pytest
    from six import StringIO
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 4
    from ansible.module_utils.common.text.formatters import HumanReadable
    display.columns = HumanReadable().fit(80)

    terms_strings = ['force', 'state']
    terms_lists = [['force', 'state'], ['key', 'key-path']]
    parameters = dict(force=True, state='present')
    parameters_multiple = dict(force=True, state='absent', key='key', key_path='/path/to/key')
    assert check_mutually_exclusive(terms_strings, parameters) == []
    assert check_mutually_exclusive(terms_strings, parameters_multiple) == [['force', 'state']]
   

# Generated at 2022-06-11 01:46:11.158036
# Unit test for function check_type_bits
def test_check_type_bits():
    if check_type_bits('1Mb') != 1048576 :
        raise AssertionError()
    if check_type_bits('1Mb') * 8 != 8388608 :
        raise AssertionError()



# Generated at 2022-06-11 01:46:15.550867
# Unit test for function check_type_float
def test_check_type_float():
    teststring=str(8.2)
    testfloat=check_type_float(teststring)
    assert isinstance(testfloat,float)


# Generated at 2022-06-11 01:46:26.019626
# Unit test for function check_type_bits
def test_check_type_bits():
    from pytest import raises
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.validation import (
        check_type_bytes,
        check_type_bits,
        check_type_str,
        check_type_jsonarg,
        check_type_dict,
        check_type_list,
    )

    assert check_type_bytes('1Mb') == 1048576
    assert check_type_bits('1Mb') == 8388608
    assert check_type_bytes('1Kb') == 1024
    assert check_type_bits('1Kb') == 8192
    assert check_type_bytes('1Gb') == 1073741824
    assert check_type_bits('1Gb') == 8589934592

    # invalid type

# Generated at 2022-06-11 01:46:32.460229
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{"a": 1, "b": 2}') == {u'a': 1, u'b': 2}
    assert safe_eval('1+1') == 2
    assert safe_eval('1+1', include_exceptions=True) == (2, None)
    assert safe_eval('1+1', {'ansible_user_dir': '/home/admin'}) == 2
    assert safe_eval('ansible_user_dir', {'ansible_user_dir': '/home/admin'}) == u'/home/admin'
    assert safe_eval('ansible_user_dirs', {'ansible_user_dirs': ['/home/admin']}) == [u'/home/admin']

# Generated at 2022-06-11 01:46:39.662666
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Parameter spec
    param_spec = {
        "arg": {
            "required": True,
            "type": "str",
        },
        "arg2": {
            "required": False,
            "type": "str",
        }
    }
    # Create parameters
    parameters = {
        "arg": "value",
    }
    # Test function execution
    result = check_required_arguments(argument_spec=param_spec, parameters=parameters)
    # Check result
    assert result == []



# Generated at 2022-06-11 01:46:50.243742
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(['test1'], dict(test1="value1"))
    assert check_mutually_exclusive([['test1', 'test2']], dict(test1="value1"))
    assert check_mutually_exclusive([['test1', 'test2']], dict(test2="value2"))
    assert check_mutually_exclusive([['test1', 'test2']], dict(test3="value3"))
    assert check_mutually_exclusive([['test1', 'test2']], dict(test3="value3"), ['root'])
    try:
        check_mutually_exclusive(['test1'], dict(test1="value1", test2="value2"))
        assert False
    except Exception:
        pass



# Generated at 2022-06-11 01:46:55.330598
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1KiB') == 1024 * 8
    assert check_type_bits('500B') == 500 * 8
    assert check_type_bits('1Mb') == 1024 * 1024 * 8
    assert check_type_bits('2Gb') == 2 * 1024 * 1024 * 1024 * 8



# Generated at 2022-06-11 01:47:02.379777
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int("1") == 1
    assert check_type_int(1.0) == 1
    assert check_type_int("1.0") == 1
    try:
        check_type_int("1s")
    except TypeError:
        pass
    else:
        assert False, "check_type_int did not catch bad input"


# Generated at 2022-06-11 01:47:13.655792
# Unit test for function check_type_bits

# Generated at 2022-06-11 01:47:24.626589
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('1Tb') == 1099511627776
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('1Pb') == 1125899906842624
    assert check_type_bits('1Eb') == 1152921504606846976
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1gb') == 1073741824
    assert check_type_bits('1tb') == 1099511627776
    assert check_type_bits('1pb') == 1125899906842624


# Generated at 2022-06-11 01:47:26.355094
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert 0 == b'0B'
# End Unit test



# Generated at 2022-06-11 01:47:34.226366
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(5) == 5
    assert check_type_bytes('5') == 5
    assert check_type_bytes('5k') == 5120
    assert check_type_bytes('5 kb') == 5120
    assert check_type_bytes('1 mb') == 1048576



# Generated at 2022-06-11 01:47:46.512725
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert not check_mutually_exclusive(None, None)
    assert not check_mutually_exclusive(None, {'a': 'b'})
    assert not check_mutually_exclusive(['a', 'b'], {'a': 'b'})
    assert not check_mutually_exclusive([['a', 'b']], {})
    assert not check_mutually_exclusive([['a', 'b']], {'a': 'b'})
    assert not check_mutually_exclusive([['a', 'b']], {'c': 'd'})

    assert check_mutually_exclusive([['a', 'b']], {'a': 'b', 'b': 'a'}) == [['a', 'b']]


# Generated at 2022-06-11 01:47:48.042539
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-11 01:47:51.769866
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """check_mutually_exclusive unit tests
    """
    print("\nRunning check_mutually_exclusive unit tests")

    # Test: One mutual exclusive group
    terms = ['state', 'force']
    parameters = {'force': 'delete', 'state': 'absent'}
    assert set(check_mutually_exclusive(terms, parameters)) == set(terms)

    # Test: One mutual exclusive group, no matches
    terms = ['state', 'force']
    parameters = {'state': 'absent'}
    assert check_mutually_exclusive(terms, parameters) == []

    # Test: Two mutual exclusive groups
    terms = [['state', 'force'], ['port', 'alias']]
    parameters = {'force': 'delete', 'state': 'absent', 'port': 8080, 'alias': 'mysql'}

# Generated at 2022-06-11 01:48:04.011585
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1024 ** 2
    assert check_type_bytes('1G') == 1024 ** 3
    assert check_type_bytes('1T') == 1024 ** 4
    assert check_type_bytes('1P') == 1024 ** 5
    assert check_type_bytes('1E') == 1024 ** 6
    assert check_type_bytes('1Z') == 1024 ** 7
    assert check_type_bytes('1Y') == 1024 ** 8
    assert check_type_bytes('1KB') == 1000
    assert check_type_bytes('1MB') == 1000 ** 2
    assert check_type_bytes('1GB') == 1000 ** 3
    assert check_type_bytes('1TB') == 1000 ** 4
    assert check_type_bytes('1PB')

# Generated at 2022-06-11 01:48:14.804332
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a":1, "b":2}') == {"a": 1, "b": 2}
    assert check_type_dict('{a:1, b:2}') == {"a": 1, "b": 2}
    assert check_type_dict('a=1, b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a=1, b=2, c={"a": 3}') == {"a": "1", "b": "2", "c": "a: 3"}
    assert check_type_dict('a=1, b=2, c=\'a=3\'') == {"a": "1", "b": "2", "c": "a=3"}

# Generated at 2022-06-11 01:48:22.610212
# Unit test for function check_type_dict
def test_check_type_dict():
    md = {'name': {'first': 'Sam', 'last': 'Smith'}, 'numbers': [1, 2, 3]}
    assert(check_type_dict(md) == md)
    assert(check_type_dict(str(md)) == md)
    md_str = r'''{'name': {'first': 'Sam', 'last': 'Smith'}, 'numbers': [1, 2, 3]}'''
    assert(check_type_dict(md_str) == md)
    md_str = r"{'name': {'first': 'Sam', 'last': 'Smith'}, 'numbers': [1, 2, 3]}"
    assert(check_type_dict(md_str) == md)


# Generated at 2022-06-11 01:48:33.793415
# Unit test for function check_type_bytes
def test_check_type_bytes():
    result = check_type_bytes('42')
    assert 42 == result
    result = check_type_bytes('42gb')
    assert 44608289792 == result
    try:
        check_type_bytes('42m')
        assert False, 'unexpected return'
    except TypeError:
        assert True
    try:
        check_type_bytes('42g')
        assert False, 'unexpected return'
    except TypeError:
        assert True
    try:
        check_type_bytes('42 k')
        assert False, 'unexpected return'
    except TypeError:
        assert True
    try:
        check_type_bytes('42K')
        assert False, 'unexpected return'
    except TypeError:
        assert True

# Generated at 2022-06-11 01:48:42.685162
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'someint': 99, 'bool_param': True}
    try:
        check_required_if(requirements, parameters)
        assert False
    except TypeError as e:
        assert e.results == [{'parameter': 'someint', 'value': 99, 'requirements': ('bool_param', 'string_param'), 'missing': ['string_param'], 'requires': 'all'}]



# Generated at 2022-06-11 01:48:49.348806
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    parameters = dict(
        b='foo',
        c='foo',
        d='foo',
        e=['foo', 'bar'],
        f={'g': 'foo'}
    )

    group1 = ['a', 'b']
    group2 = ['c', ['d', 'e'], [['f']]]

    check_mutually_exclusive(group1, parameters)

    ex_groups = [['a', 'b'], ['c', ['d', 'e'], [['f']]]]
    check_mutually_exclusive(ex_groups, parameters)

    for group in (group1, group2):
        with pytest.raises(TypeError) as ex:
            check_mutually_exclusive(group, parameters)

        assert "parameters are mutually exclusive" in to_native(ex.value)



# Generated at 2022-06-11 01:48:56.488133
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int( '1' ) == 1
    try:
        check_type_int('a')
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-11 01:49:02.016409
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1kB') == 1024
    assert check_type_bytes('3mb') == 3145728
    assert check_type_bytes('2KiB') == 2048
    assert check_type_bytes('3MiB') == 3145728
    with pytest.raises(TypeError):
        check_type_bytes('foo')



# Generated at 2022-06-11 01:49:05.857046
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert len(check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3, 'd': 4})) == 2

# Generated at 2022-06-11 01:49:12.381634
# Unit test for function check_type_int
def test_check_type_int():
    assert(check_type_int(7) == 7)
    assert(check_type_int(7.0) == 7)
    assert(check_type_int('7') == 7)
    assert(check_type_int('7.0') == 7)
    with pytest.raises(TypeError):
        check_type_int('invalid')
    with pytest.raises(TypeError):
        check_type_int([])
    with pytest.raises(TypeError):
        check_type_int({})



# Generated at 2022-06-11 01:49:22.255309
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1mB') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1MB') == 1048576
    assert check_type_bits('1MBi') == 1048576
    assert check_type_bits('1Mi') == 1048576

    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1kB') == 1024
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1KB') == 1024
    assert check_type_bits('1KBi') == 1024
    assert check_type_bits('1Ki') == 1024

    assert check_type_bits('1b') == 1

# Generated at 2022-06-11 01:49:26.997946
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == check_type_int('1Mb') * 8
    assert check_type_bits('10Mb') == check_type_int('1M') * 80


# Generated at 2022-06-11 01:49:36.886296
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1kB') == 1024
    assert check_type_bits('1MB') == 1048576
    assert check_type_bits('1GB') == 1073741824
    assert check_type_bits('1TB') == 1099511627776
    assert check_type_bits('1PB') == 1125899906842624
    assert check_type_bits('1Kb') == 1024 * 8
    assert check_type_bits('1Mb') == 1048576 * 8
    assert check_type_bits('1Gb') == 1073741824 * 8
    assert check_type_bits('1Tb') == 1099511627776 * 8
    assert check_type_bits('1Pb') == 1125899906842624 * 8


# Generated at 2022-06-11 01:49:48.194438
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():

    assert check_mutually_exclusive(None, {}) == []
    assert check_mutually_exclusive([], {}) == []

    try:
        check_mutually_exclusive([["a", "b"]], {"a": 1, "b": 1})
        assert False, "Should have thrown an exception"
    except TypeError:
        pass

    try:
        check_mutually_exclusive([["a", "b"]], {"a": 1, "b": 1, "c": 1})
        assert False, "Should have thrown an exception"
    except TypeError:
        pass

    assert check_mutually_exclusive([["a", "b"]], {"a": 1}) == []
    assert check_mutually_exclusive([["a", "b"]], {"c": 1}) == []


# Generated at 2022-06-11 01:49:57.624389
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.2) == 1.2
    assert check_type_float(3) == 3.0
    assert check_type_float('3.1') == 3.1
    assert check_type_float(b'3') == 3.0
    assert check_type_float(None) == None
    try:
        check_type_float(set())
    except TypeError as e:
        assert str(e) == "'set' cannot be converted to a float"
    else:
        assert False, "check_type_float did not throw expected TypeError"


# Generated at 2022-06-11 01:50:03.275679
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1+2') == 3
    assert safe_eval('a', locals={'a': 'b'}) == 'b'
    assert safe_eval('dict(a=1)') == {'a': 1}
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('1') == 1
    assert safe_eval('"string"') == "string"
    # Check that literals are evaluated properly
    assert safe_eval('False') is False
    assert safe_eval('True') is True
    assert safe_eval('None') is None
    assert safe_eval('a+1', locals={'a': 3}) == 4
    assert safe_eval('a', locals={'a': 3}) == 3

# Generated at 2022-06-11 01:50:08.724806
# Unit test for function check_type_bytes
def test_check_type_bytes():
    size = '1M'
    expected = 1048576
    result = check_type_bytes(size)
    assert result == expected

