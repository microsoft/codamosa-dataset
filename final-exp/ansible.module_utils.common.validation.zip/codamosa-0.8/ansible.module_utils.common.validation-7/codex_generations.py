

# Generated at 2022-06-11 01:40:49.725769
# Unit test for function check_required_by
def test_check_required_by():
    d = dict(
        one='1',
        two='2',
        three='3',
        four='4',
        five='5',
        six='6',
        seven='7',
    )
    r = dict(
        one='four',
        two='four',
        three='four five six',
    )
    try:
        check_required_by(r, d)

    except:
        raise AssertionError("test_check_required_by failed. Should success")
    r['one'] = 'four five six'
    try:
        check_required_by(r, d)

    except TypeError as e:
        assert str(e) == "missing parameter(s) required by 'one': five, six"


# Generated at 2022-06-11 01:40:52.935233
# Unit test for function check_required_by

# Generated at 2022-06-11 01:41:00.761469
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {
        'ansible_host': '127.0.0.1',
        'ansible_port': '22',
        'ansible_username': 'root',
    }
    requirements = {
        'ansible_host': ['ansible_port'],
        'ansible_username': ['ansible_host', 'ansible_port'],
    }

    # test check_required_by function
    check_required_by(requirements, parameters)


# Generated at 2022-06-11 01:41:09.511264
# Unit test for function check_type_bytes
def test_check_type_bytes():
    result = check_type_bytes('2.5Mb')
    assert isinstance(result, int)
    result = check_type_bytes('2.5G')
    assert isinstance(result, int)
    result = check_type_bytes('2G')
    assert isinstance(result, int)
    result = check_type_bytes('2M')
    assert isinstance(result, int)
    result = check_type_bytes('2K')
    assert isinstance(result, int)
    result = check_type_bytes('2.5Mb')
    assert isinstance(result, int)


# Generated at 2022-06-11 01:41:17.045737
# Unit test for function check_required_together
def test_check_required_together():
    """Tests function check_required_together"""
    terms = [['num1', 'num2'], ['num3', 'num4']]
    parameters = {'num1': 1, 'num3': 0}
    options_context = ["a", "b"]
    check_required_together(terms, parameters, options_context)
    err_msg = '^parameters are required together: num1, num2 found in a -> b$'
    assertRegexpMatches(check_required_together(terms, parameters, options_context), err_msg)
    return True


# Generated at 2022-06-11 01:41:24.618481
# Unit test for function check_type_dict
def test_check_type_dict():
    test_var = check_type_dict('k1=v1,k2=v2,k3=v3')
    assert test_var.__len__() == 3
    assert test_var['k1'] == 'v1'
    assert test_var['k2'] == 'v2'
    assert test_var['k3'] == 'v3'


# Generated at 2022-06-11 01:41:27.112090
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Positive test cases
    assert check_type_bytes('10G') == 10737418240
    assert check_type_bytes('6B') == 6
    assert check_type_bytes('8g') == 8589934592
    assert check_type_bytes('1073741824') == 1073741824
    # Negative test cases
    assert check_type_bytes('10GBB') is None
    assert check_type_bytes('10TB') is None

# Generated at 2022-06-11 01:41:38.562565
# Unit test for function check_required_by
def test_check_required_by():
    test_parameters = {}
    test_requirements = {}

    #Test case 1
    test_parameters = {'parameter1': 'value1', 'parameter2': 'value2'}
    test_requirements = {'parameter1': ['parameter2']}
    assert check_required_by(test_requirements, test_parameters) == {}

    #Test case 2
    test_parameters = {'parameter1': 'value1'}
    test_requirements = {'parameter1': ['parameter2']}
    assert check_required_by(test_requirements, test_parameters) == {'parameter1': ['parameter2']}

    #Test case 3
    test_parameters = {'parameter1': 'value1', 'parameter2': 'value2'}
    test

# Generated at 2022-06-11 01:41:44.188176
# Unit test for function check_required_by
def test_check_required_by():
    try:
        check_required_by({'a':['b','c']}, {'a':'foo', 'b':'bar'})
    except TypeError:
        pass
    else:
        fail("Failed to raise TypeError on missing requirement")

    try:
        check_required_by({'a':['b','c']}, {'a':'foo', 'b':'bar', 'c':'bar'})
    except TypeError:
        fail("Raised TypeError unexpectedly")



# Generated at 2022-06-11 01:41:56.397632
# Unit test for function check_required_if
def test_check_required_if():
    try:

        invalid_requirements_dict_invalid_type = {'key': 'value'}
        check_required_if(invalid_requirements_dict_invalid_type, {})
        assert False, "invalid_requirements_dict didn't throw an error"

    except Exception as e:
        assert e.message == ("requirements should be a list of lists or tuples, and each list or tuple should have 3 or 4 items."), e.message


# Generated at 2022-06-11 01:42:12.741663
# Unit test for function check_required_arguments
def test_check_required_arguments():
    check_required_arguments({}, {})
    check_required_arguments({'req1': {}}, {'req1': None})
    check_required_arguments({'req1': {'required': True}}, {'req1': None})
    check_required_arguments({'req1': {'required': True}}, {'req1': None, 'req2': None})
    check_required_arguments({'req1': {'required': False}}, {'req1': None})
    check_required_arguments({'req1': {'required': False}}, {})
    try:
        check_required_arguments({'req1': {'required': True}}, {})
        raise AssertionError('missing required argument did not raise error')
    except TypeError:
        pass



# Generated at 2022-06-11 01:42:21.643051
# Unit test for function check_required_arguments
def test_check_required_arguments():
    required_args = dict(
        name=dict(required=True),
        state=dict(required=True),
        force=dict(required=False),
    )
    missing_args = dict(
        state=dict(required=True),
        force=dict(required=False),
    )
    wrong = dict(
        name=dict(required=True),
        state=dict(required=True),
    )
    correct = dict(
        name=dict(required=True),
        state=dict(required=True),
        force=dict(required=False),
    )

    assert check_required_arguments(required_args, wrong) == ['name']
    assert check_required_arguments(required_args, correct) == []
    assert check_required_arguments(missing_args, wrong) == []
    assert check

# Generated at 2022-06-11 01:42:32.121056
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    # Parameter state is set to present, but path is missing
    parameters = {'state': 'present'}
    missing_path = check_required_if(requirements, parameters)
    assert missing_path == [{'parameter': 'state', 'value': 'present', 'requirements': ('path',), 'missing': ['path'], 'requires': 'any'}]
    # Parameter state is set to present, but path is present - assertion passes
    parameters = {'state': 'present', 'path': '/root'}
    missing_path = check_required_if(requirements, parameters)
    assert missing_path == []
    # Parameter someint is set

# Generated at 2022-06-11 01:42:43.593611
# Unit test for function check_required_if
def test_check_required_if():
    REQ = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
        ['int_one_of', 1, ('any_int1', 'any_int2'), True],
        ['int_all_of', 2, ('any_int1', 'any_int2'), False],
    ]
    # Check with no requirements
    try:
        check_required_if(None, {})
    except TypeError:
        assert False

    # Check with no requirements but a parameter set
    try:
        check_required_if(None, {'someint': 99})
    except TypeError:
        assert False

    # Check with requirements but no parameters set

# Generated at 2022-06-11 01:42:44.700212
# Unit test for function check_required_one_of
def test_check_required_one_of():
    raise SkipTest




# Generated at 2022-06-11 01:42:55.837814
# Unit test for function check_type_float
def test_check_type_float():
    assert isinstance(check_type_float(1.2), float)
    assert isinstance(check_type_float('1.2'), float)
    assert isinstance(check_type_float(1), float)
    assert isinstance(check_type_float(b'1.2'), float)
    assert isinstance(check_type_float(u'1.2'), float)
    assert isinstance(check_type_float(True), float)
    assert isinstance(check_type_float(False), float)
    assert isinstance(check_type_float([1, 2, 3]), float)
    assert isinstance(check_type_float({1:2}), float)
    assert isinstance(check_type_float(None), float)

# Generated at 2022-06-11 01:43:02.985603
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('["foo", "bar"]') == ['foo', 'bar']
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('foo bar') == 'foo bar'
    assert safe_eval('foo.bar()', include_exceptions=True)[1] is not None



# Generated at 2022-06-11 01:43:10.619343
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import human_to_bytes

    import pytest


# Generated at 2022-06-11 01:43:19.267753
# Unit test for function check_required_by
def test_check_required_by():
    # Tests check_required_by function
    dict = {'key_1': ['required_1', 'required_2'], 'key_2': ['required_3', 'required_4']}
    parameters = {'required_1': 'value1', 'required_2': 'value2', 'required_3': 'value3', 'required_4': 'value4'}
    options_context = None
    result = check_required_by(dict, parameters)
    if result is None:
        print("test_check_required_by  passed")
    else:
        print("test_check_required_by  failed")



# Generated at 2022-06-11 01:43:31.889455
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    parameters1 = {'one': 'cheese'}
    parameters2 = {'one': 'cheese', 'two': 'cheese'}
    parameters3 = {'one': 'cheese', 'two': 'cheese', 'three': 'cheese', 'four': 'cheese'}
    parameters4 = {'five': 'cheese', 'six': 'cheese'}

    try:
        result = check_mutually_exclusive([['one', 'two']], parameters1)
        assert result == []
    except Exception as e:
        pytest.fail("Unexpected exception: {}".format(e))

    with pytest.raises(TypeError):
        check_mutually_exclusive([['one', 'two']], parameters2)


# Generated at 2022-06-11 01:43:47.184975
# Unit test for function check_type_dict
def test_check_type_dict():
    # single value
    assert check_type_dict("key=value") == {"key": "value"}
    # multiple values
    assert check_type_dict("key1=value1, key2=value2") == {"key1": "value1", "key2": "value2"}
    # multiple values with spaces
    assert check_type_dict("key1=value1, key2=value2") == {"key1": "value1", "key2": "value2"}
    # multiple values with spaces
    assert check_type_dict("key1=value1, key2=value2") == {"key1": "value1", "key2": "value2"}
    # multiple values with spaces

# Generated at 2022-06-11 01:43:57.997865
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive([['a', 'b']], {'a': '1', 'b': '2'}) is None
    assert check_mutually_exclusive([['a', 'b']], {'a': '1', 'c': '2'}) is None
    try:
        check_mutually_exclusive([['a', 'b']], {'a': '1', 'b': '2', 'c': '2'})
    except Exception as e:
        assert e.args[0] == 'parameters are mutually exclusive: b|c'


# Generated at 2022-06-11 01:44:08.248140
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    """Test that check_missing_parameters properly raises or returns based on parameters given."""
    from ansible.playbook.play_context import PlayContext
    from ansible.cli.adhoc import AdHocCLI as Cli
    from ansible.module_utils.common.collections import ImmutableDict

    # cli args are required to build a PlayContext
    cli = Cli(args=['ansible', '-m', 'fake_module', '-a', 'key=value'])
    cli.parse()
    args = ImmutableDict(**cli.args.__dict__)
    # create a PlayContext, required by the module
    play_context = PlayContext(**args.copy())
    play_context.check_mode = False
    # create a dict of params

# Generated at 2022-06-11 01:44:14.035693
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert(check_type_bytes('123') == 123)
    assert(check_type_bytes('2kb') == 2048)
    assert(check_type_bytes('2mb') == 2097152)
    assert(check_type_bytes('2gb') == 2147483648)
    assert(check_type_bytes('2tb') == 2199023255552)



# Generated at 2022-06-11 01:44:24.762064
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(123) == 123
    assert safe_eval('123') == 123
    assert safe_eval('2^6') == 64
    assert safe_eval('2**6') == 64
    assert safe_eval('1+2*3**(4^5)//6') == 1
    assert safe_eval('len([[1, 2, 3]])') == 1
    assert safe_eval('[1,2,3,4][-1]') == 4
    assert safe_eval('{"foo": "bar"}') == {u'foo': u'bar'}
    assert safe_eval('{"foo": "bar"}', include_exceptions=True) == (u'{"foo": "bar"}', None)
    assert safe_eval('foo()') == u'foo()'



# Generated at 2022-06-11 01:44:32.951715
# Unit test for function check_required_by
def test_check_required_by():
    result = check_required_by({'a': ['b', 'c']}, {'a': 'value', 'b': 'value', 'c': 'value'})
    assert(result == {})

    result = check_required_by({'a': ['b', 'c']}, {'a': 'value', 'b': 'value', 'c': None})
    assert(result == {'a': ['c']})

    result = check_required_by({'a': ['b', 'c']}, {'a': 'value', 'b': 'value'})
    assert(result == {})

    result = check_required_by({'a': ['b', 'c']}, {'a': 'value'})
    assert(result == {})


# Generated at 2022-06-11 01:44:40.571363
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils import basic

    data_structure = {
        "parameters": {
            "a": "a",
            "b": "b",
            "c": {
                "c1": "c1",
                "c2": "c2"
            }
        },
        "terms": [
            ["a", "b"],
            ["c1", "c2"],
            ["m", "n", "o"]
        ]
    }

    # test with single group of mutually exclusive terms

# Generated at 2022-06-11 01:44:44.970150
# Unit test for function check_type_dict
def test_check_type_dict():
    t = dict
    assert type(check_type_dict(t({'a': 'b'}))) == type(t({'a': 'b'}))
    assert type(check_type_dict('{}')) == type(t({'a': 'b'}))



# Generated at 2022-06-11 01:44:55.208309
# Unit test for function check_required_arguments
def test_check_required_arguments():
    """Ensure parameters are checked for required arguments"""
    modules_utils = AnsibleModuleUtils(
        argument_spec={
            'required1': {'required': True},
            'required2': {'required': True},
            'required3': {'other_required': True},
            'required4': {'other_required': True},
            'required5': {'required': True},
            'optional1': {'required': False},
            'optional2': {'required': False},
        }
    )

    # Check required arguments
    assert modules_utils.check_required_arguments({}, {}) == ['required1', 'required2', 'required5']

    # Check optional arguments

# Generated at 2022-06-11 01:45:03.491808
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('value') == "value"
    assert safe_eval('42') == 42
    assert safe_eval('42.0') == 42.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('["foo", "bar"]') == ["foo", "bar"]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('value.test()') == 'value.test()'
    assert safe_eval('import foo') == 'import foo'



# Generated at 2022-06-11 01:45:11.403919
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'param1': 'test1', 'param2': 'test2'}
    required_parameters = ['param1', 'param3']
    try:
        check_missing_parameters(parameters, required_parameters)
    except:
        False
    else:
        True


# Generated at 2022-06-11 01:45:20.794525
# Unit test for function check_required_by
def test_check_required_by():
    result, parameters, option_context = {}, {}, []
    requirements = None,
    assert check_required_by(requirements, parameters, option_context) == result

    parameters = {"device": "vlan", "vlan_id": "10"}
    requirements = {"device": "vlan", "vlan_id": None, "vlan_name": None}
    assert check_required_by(requirements, parameters, option_context) == result

    requirements = {"vlan_id": "vlan_name"}
    assert check_required_by(requirements, parameters, option_context) == result

    requirements = {"device": "vlan", "vlan_id": "vlan_name"}
    assert check_required_by(requirements, parameters, option_context) == {"device": ["vlan_name"]}


# Generated at 2022-06-11 01:45:27.252356
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # test invalid values

    # no conversion should be done for non string type
    for value in [b'4K', 4]:
        result = check_type_bytes(value)
        assert result == value

    # test valid values
    for value in ['4K', '4M', '4G']:
        result = check_type_bytes(value)
        assert result == 4*1024*1024*1024



# Generated at 2022-06-11 01:45:38.220530
# Unit test for function check_required_by
def test_check_required_by():
    def test_required_by(requirements, params, expected_result,
                         options_context=None):
        # TODO: Remove this stub once calling this outside of a module is possible
        class StubModule(object):
            def fail_json(self, *args, **kwargs):
                raise TypeError(to_native(args[0]))

        options_context = options_context or []
        result = check_required_by(requirements, params, options_context)
        assert result == expected_result

    # test_required_by('arg_name', {}, {}, ['arg_name'])
    test_required_by({}, {}, {})
    test_required_by(None, {}, {})

    # test_required_by('arg_name', create_params, {'arg_name': []}, ['arg_name

# Generated at 2022-06-11 01:45:49.434406
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(10) == 10
    assert check_type_float(10.01) == 10.01
    assert check_type_float('10.01') == 10.01
    assert check_type_float(b'10.01') == 10.01
    assert check_type_float(b"10.01") == 10.01
    assert check_type_float(u"10.01") == 10.01
    assert check_type_float(u'10.01') == 10.01
    try:
        check_type_float('ten')
    except TypeError as e:
        a_val = to_native(e)
    assert a_val == "'ten' cannot be converted to a float"


# Generated at 2022-06-11 01:45:55.108595
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{}') == {}
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    # do not allow method calls to modules
    assert safe_eval('json.dumps(result)') == 'json.dumps(result)'
    # do not allow imports
    assert safe_eval('import os') == 'import os'



# Generated at 2022-06-11 01:46:06.223428
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('1 + 1') == 2
    assert safe_eval('{}') == {}
    assert safe_eval('foo') == 'foo'
    assert safe_eval('{1, 2, 3}') == {1, 2, 3}
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('dict([("foo", "bar")])') == {"foo": "bar"}
    assert safe_eval('import foo') == 'import foo'
    assert safe_eval('foo.bar()') == 'foo.bar()'

# Generated at 2022-06-11 01:46:18.334902
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes("10B") == 10
    assert check_type_bytes("10KB") == 10000
    assert check_type_bytes("1.3MB") == 1300000
    assert check_type_bytes("0.3GB") == 300000000
    assert check_type_bytes("0.3TB") == 300000000000
    assert check_type_bytes("0.3PB") == 300000000000000
    assert check_type_bytes("0.3EB") == 3000000000000000000
    assert check_type_bytes("-1.4EB") == -14000000000000000000
    assert check_type_bytes("-1TB") == -1000000000000
    assert check_type_bytes("-1B") == -1
    assert check_type_bytes("-1.1B") == -1

# Generated at 2022-06-11 01:46:19.232938
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576


# Generated at 2022-06-11 01:46:26.427331
# Unit test for function check_required_together
def test_check_required_together():
    _terms = [
        ['netmask', 'prefix'],
        ['netmask', 'prefix', 'ipv4address']
    ]
    _parameters = {
        'netmask': '255.255.255.0',
        'prefix': '24',
        'foo': 'bar'
    }
    assert check_required_together(_terms, _parameters) == []

    _terms = [
        ['netmask', 'prefix', 'ipv4address']
    ]

    assert check_required_together(_terms, _parameters) == [_terms[0]]



# Generated at 2022-06-11 01:46:40.733247
# Unit test for function check_type_dict
def test_check_type_dict():
    test_value_dict = {'k1': 'v1', 'k2': 'v2'}
    result = check_type_dict(test_value_dict)
    # Expect True if the function can convert the given dict to a string type
    assert isinstance(result, dict)
    assert result['k1'] == 'v1'
    assert result['k2'] == 'v2'
    test_value_list = ['k1=v1', 'k2=v2']
    result = check_type_dict(test_value_list)
    # Expect True if the function can convert the given list to a string type
    assert isinstance(result, dict)
    assert result['k1'] == 'v1'
    assert result['k2'] == 'v2'

# Generated at 2022-06-11 01:46:42.144662
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float("1") == 1.0


# Generated at 2022-06-11 01:46:47.788321
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('123B') == 123
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1024 * 1024
    assert check_type_bytes('1G') == 1024 * 1024 * 1024
    assert check_type_bytes('1T') == 1024 * 1024 * 1024 * 1024
    asse

# Generated at 2022-06-11 01:46:59.790773
# Unit test for function check_required_one_of
def test_check_required_one_of():
    result = check_required_one_of([['a', 'b']], {}, options_context=None)
    print("return is: %s" % result)
    result = check_required_one_of([('a', 'b', 'c')], {}, options_context=None)
    print("return is: %s" % result)
    #result = check_required_one_of([('a', 'b', 'c')], {'a': 1}, options_context=['options'])
    #print("return is: %s" % result)
    # this should cause the code to raise an exception
    #result = check_required_one_of([('a', 'b', 'c')], {}, options_context=['options'])
    #print("return is: %s" % result)



# Generated at 2022-06-11 01:47:08.316726
# Unit test for function safe_eval
def test_safe_eval():
    value = "dict(changed=False, failed=False)"
    expected = dict(changed=False, failed=False)
    result = safe_eval(value)
    assert result == expected
    value = "dict(changed=False, failed=False, ansible=2.9)"
    expected = dict(changed=False, failed=False, ansible=2.9)
    result = safe_eval(value)
    assert result == expected
    value = "dict(changed=False, failed=False, ansible=2.9, foo='bar')"
    expected = dict(changed=False, failed=False, ansible=2.9, foo='bar')
    result = safe_eval(value)
    assert result == expected

# Generated at 2022-06-11 01:47:18.052367
# Unit test for function check_required_by
def test_check_required_by():
    # Pass
    spec = {
        "subnets": {
            "required": True,
            "type": "str",
            "requirements": {
                "subnet_name": [
                    "subnet_address",
                    "subnet_netmask"
                ]
            }
        },
        "subnet_name": {
            "required": False,
            "type": "str"
        },
        "subnet_address": {
            "required": False,
            "type": "str"
        },
        "subnet_netmask": {
            "required": False,
            "type": "str"
        }
    }

# Generated at 2022-06-11 01:47:21.888141
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments({'foo': {'required': True}}, {'foo': None}) == []
    assert check_required_arguments({'foo': {'required': True}}, {}) == ['foo']



# Generated at 2022-06-11 01:47:29.213139
# Unit test for function check_type_bytes
def test_check_type_bytes():  # noqa
    assert check_type_bytes('42') == 42
    assert check_type_bytes('42B') == 42
    assert check_type_bytes('42b') == 42
    assert check_type_bytes('42KB') == 42 * 1024
    assert check_type_bytes('42mb') == 42 * 1024 * 1024
    assert check_type_bytes('42MB') == 42 * 1024 * 1024
    assert check_type_bytes('42mB') == 42 * 1024 * 1024
    assert check_type_bytes('42GB') == 42 * 1024 * 1024 * 1024
    assert check_type_bytes('42gb') == 42 * 1024 * 1024 * 1024
    assert check_type_bytes('42G') == 42 * 1024 * 1024 * 1024
    assert check_type_bytes('42T') == 42 * 1024 * 1024 * 1024 * 1024
   

# Generated at 2022-06-11 01:47:36.226324
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {'a': '1'}
    requirements = {'b': ['a']}
    result = check_required_by(requirements, parameters)
    assert result == {}

    parameters = {'b': '1'}
    result = check_required_by(requirements, parameters)
    assert result == {'b': ['a']}

    requirements = {'b': u'a'}
    result = check_required_by(requirements, parameters)
    assert result == {'b': ['a']}



# Generated at 2022-06-11 01:47:48.142531
# Unit test for function check_type_int
def test_check_type_int():
    # integer_types is tuple(int, long)
    assert isinstance(check_type_int(3), integer_types)
    assert isinstance(check_type_int("3"), integer_types)
    # Verify that check_type_int is returning int types, not long
    assert check_type_int("3").__class__.__name__ == 'int'
    # check_type_int test attributes:
    # * expected to return int
    # * expected to raise TypeError if string cannot be converted to int
    assert check_type_int.__name__ == 'check_type_int'

# Generated at 2022-06-11 01:48:03.587140
# Unit test for function check_required_if
def test_check_required_if():
    """Unit test of check_required_if"""
    requirements1 = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]

    parameters1 = {
        'state': 'present',
        'path': '/tmp/blabla',
        'bool_param': True,
    }

    result1 = check_required_if(requirements1, parameters1)
    assert len(result1) == 1
    assert result1[0]['parameter'] == 'someint'
    assert result1[0]['missing'] == ['string_param']


# Generated at 2022-06-11 01:48:14.526963
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('2Kb') == 2048
    assert check_type_bits('2b') == 2
    assert check_type_bits('1') == 1
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1G') == 1073741824
    assert check_type_bits('1Tb') == 1099511627776
    assert check_type_bits('1T') == 1099511627776
    assert check_type_bits('1Pb') == 1125899906842624
    assert check_type_bits('1P') == 1125899906842624
    assert check_type_bits('1Eb')

# Generated at 2022-06-11 01:48:20.018019
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1 mb') == 1048576
    assert check_type_bits('1 MB') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1') == 1
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mib') == 1048576



# Generated at 2022-06-11 01:48:24.891250
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = dict()
    argument_spec['foo'] = dict(required=True)
    assert check_required_arguments(argument_spec, dict()) == ['foo']
    assert check_required_arguments(argument_spec, dict(foo='foo')) == []
    assert check_required_arguments(dict(foo=dict(required=False)), dict()) == []



# Generated at 2022-06-11 01:48:32.684792
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(4) == 4
    assert safe_eval('4') == 4
    assert safe_eval('[1,2]') == [1, 2]
    assert safe_eval('{"a":1}') == {"a": 1}
    assert safe_eval('None') is None
    assert safe_eval(None) is None
    assert safe_eval('"test"') == "test"
    assert safe_eval('test.test') == 'test.test'
    assert safe_eval('import test') == 'import test'



# Generated at 2022-06-11 01:48:44.019833
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1, 2, 3, 4]") == [1, 2, 3, 4]
    assert safe_eval("{'a': 1, 'b': 2, 'c': 3, 'd': 4}") == {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert safe_eval("'I am a string'") == 'I am a string'
    assert safe_eval("'I am a \"string\"'") == 'I am a "string"'
    assert safe_eval("({'a': 1, 'b': 2}, ['c', 'd', 'e'], 'f')") == ({'a': 1, 'b': 2}, ['c', 'd', 'e'], 'f')
    assert safe_eval("1 + 2") == 3

# Generated at 2022-06-11 01:48:55.680422
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('a=3,b=4') == {'a':'3','b':'4'}
    assert check_type_dict('{"a":3,"b":4}') == {'a':3,'b':4}
    assert check_type_dict('{"a":"b=4"}') == {'a':'b=4'}
    assert check_type_dict('{"a":"b=4,c=5"}') == {'a':'b=4,c=5'}
    assert check_type_dict({'a': 3, 'b': 4}) == {'a':3,'b':4}
    with pytest.raises(TypeError) as excinfo:
        check_type_dict(1)

# Generated at 2022-06-11 01:49:05.604618
# Unit test for function check_type_dict
def test_check_type_dict():
    # Testing strings
    assert check_type_dict("{'a': '1'}") == {'a': '1'}
    assert check_type_dict("a='1', b='2'") == {'a': '1', 'b': '2'}
    assert check_type_dict("a='1', b='2'") == {'a': '1', 'b': '2'}
    assert check_type_dict("a='1', b='2', c='3'") == {'a': '1', 'b': '2', 'c': '3'}
    assert check_type_dict("{'a':'1','b':'2','c':'3'}") == {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-11 01:49:09.046897
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Gb') == 1073741824
# end of function test_check_type_bits()

# Generated at 2022-06-11 01:49:13.973272
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int("1") == 1

    try:
        check_type_int("string")
    except TypeError:
        pass
    else:
        assert False, "Expect to blurt out TypeError here"


# Generated at 2022-06-11 01:49:25.304079
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("123") == 123
    assert safe_eval("123.1") == 123.1
    assert safe_eval("True") == True
    assert safe_eval("False") == False
    assert safe_eval("true") == "true"
    assert safe_eval("false") == "false"
    assert safe_eval("null") == "null"
    assert safe_eval("'abc'") == 'abc'
    assert safe_eval("123 + 123") == 123 + 123
    assert safe_eval("123 + 12 + 3") == 123 + 12 + 3
    assert safe_eval("123.1 + 123.1") == 123.1 + 123.1
    assert safe_eval("123.1 + 1.2 + 3.3") == 123.1 + 1.2 + 3.3

# Generated at 2022-06-11 01:49:31.344407
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {'a': {'required': True}, 'b': {'required': False}}
    module_args = {'a': 1}
    check_required_arguments(argument_spec, module_args)
    try:
        check_required_arguments(argument_spec, {})
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-11 01:49:36.827608
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b']]
    parameters = {'a': 'A', 'b': 'B'}
    check_required_together(terms, parameters)
    parameters = {'a': 'A', 'b': 'B', 'c': 'C'}
    check_required_together(terms, parameters)
    parameters = {'a': 'A', 'c': 'C'}
    try:
        check_required_together(terms, parameters)
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-11 01:49:48.154994
# Unit test for function check_type_dict

# Generated at 2022-06-11 01:49:50.906101
# Unit test for function check_type_bits
def test_check_type_bits():
    bits = check_type_bits('1Mb')
    assert isinstance(bits, int)
    assert bits == 1048576



# Generated at 2022-06-11 01:50:03.517433
# Unit test for function check_type_bits
def test_check_type_bits():
    assert 1048576 == check_type_bits('1Mb')
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1.5kb') == 1536
    assert check_type_bits('1.5K') == 1536
    assert check_type_bits('1.5MB') == 1572864
    assert check_type_bits('1.5gbit') == 1966080
    assert check_type_bits('1.5 TB') == 1610612736
    assert check_type_bits('1.5Bit') == 1
    assert check_type_bits('1.5MBit') == 165150
    assert check_type_bits('1.5 GBit') == 1610612736
    assert check_type_bits('1.5 tbit') == 1610612736
    assert check