

# Generated at 2022-06-11 01:40:53.232025
# Unit test for function check_required_one_of
def test_check_required_one_of():
    res = check_required_one_of([['test1', 'test2']], {'test1': 'test1'})
    assert res == []
    try:
        check_required_one_of([['test1', 'test2']], {})
    except TypeError as e:
        assert "one of the following is required: test1, test2" in str(e)
        assert "found in " not in str(e)
    else:
        assert False, "Expecting TypeError"
    try:
        check_required_one_of([['test1', 'test2']], {}, ['test3'])
    except TypeError as e:
        assert "one of the following is required: test1, test2" in str(e)
        assert "found in test3" in str(e)

# Generated at 2022-06-11 01:41:02.885541
# Unit test for function check_required_arguments
def test_check_required_arguments():
    testpara = {'required': {'arg1': '', 'arg2': ''}}
    # Test: Required arguments are not in the parameter dictionary
    try:
        check_required_arguments(testpara, {'arg1': '', 'arg2': ''})
    except TypeError as e:
        assert e.args[0] == "missing required arguments: None"
    # Test: Required arguments are all in the parameter dictionary
    try:
        check_required_arguments(testpara, {'arg1': '', 'arg2': '', 'arg3': '', 'arg4': ''})
    except TypeError:
        assert False



# Generated at 2022-06-11 01:41:11.862259
# Unit test for function check_required_arguments
def test_check_required_arguments():
    """ Unit test for function check_required_arguments

    :return: None
    """

    argument_spec = dict(
        foo=dict(
            required=True,
        ),
        bar=dict(
            required=False,
        ),
    )

    parameters = dict(
        foo=1,
    )

    result = check_required_arguments(argument_spec, parameters)
    assert result == []

    parameters = dict(
        bar=1,
    )

    result = check_required_arguments(argument_spec, parameters)
    assert result == ['foo']



# Generated at 2022-06-11 01:41:17.202831
# Unit test for function check_required_by
def test_check_required_by():
    requirements = dict(
        one=dict(two=['three', 'four']),
        five='six'
    )
    parameters = dict(
        one='testing',
        two='testing',
        three='testing',
        six='testing'
    )
    options_context = ['test_context']
    assert check_required_by(requirements, parameters, options_context) == dict()

# Generated at 2022-06-11 01:41:30.611394
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # supporting inittest
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule({}, {'state': 'present', 'config': 'yes', 'force': 'no', 'foo': 'bar'})
    assert check_mutually_exclusive(['force', 'config'], m.params) is None
    try:
        assert check_mutually_exclusive(['force', 'config', 'state'], m.params)
    except TypeError as e:
        assert repr(e) == "TypeError('parameters are mutually exclusive: force|config|state',)"

# Generated at 2022-06-11 01:41:41.575466
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_native

    def _check_safe_eval(input_str):
        try:
            val = safe_eval(input_str)
        except Exception as e:
            val = to_native(e)
        return val

    def _check_safe_eval_bool(input_str):
        try:
            val = boolean(safe_eval(input_str, ignore_errors=True))
        except Exception as e:
            val = to_native(e)
        return val


# Generated at 2022-06-11 01:41:49.484233
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # Arrange
    parameters = {}
    required_parameters = ['name', 'path', 'test_variable']

    # Act
    try:
        check_missing_parameters(parameters, required_parameters)
    except TypeError as exception:
        # Assert
        assert exception.args[0] == "missing required arguments: %s" % ', '.join(required_parameters)
        # Cleanup
    else: raise Exception('Did not raise a TypeError')



# Generated at 2022-06-11 01:42:01.453976
# Unit test for function check_required_if
def test_check_required_if():
    parameters = dict(
        state=dict(
            type='str',
            choices=['present', 'absent', 'started', 'stopped']),
        name=dict(
            type=str),
        path=dict(
            type=str),
        bool_param=dict(
            type=bool),
        string_param=dict(
            type=str),
        someint=dict(
            type=int)
    )

# Generated at 2022-06-11 01:42:06.908373
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {}
    required_parameters = ['required1', 'required2']
    assert check_missing_parameters(parameters, required_parameters) == required_parameters
    parameters = {'required1': 1, 'required2': 2}
    assert check_missing_parameters(parameters, required_parameters) == []
    parameters = {'non-required1': 1, 'required2': 2}
    assert check_missing_parameters(parameters, required_parameters) == ['required1']



# Generated at 2022-06-11 01:42:11.993332
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'a': {'required': True},
        'b': {'required': False},
    }
    parameters = {
        'a': True,
    }
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as ex:
        return False
    return True


# Generated at 2022-06-11 01:42:25.276668
# Unit test for function check_type_bits
def test_check_type_bits():
    answer = check_type_bits('1Mb')
    if answer == 1048576:
        print("Passed check_type_bits 1, 1048576")
    else:
        print("Failed check_type_bits 1, 1048576")

    #test 2
    try:
        answer = check_type_bits({'Mb':"1"})
    except TypeError:
        print("Passed check_type_bits 2:{'Mb':'1'}")
    else:
        print("Failed check_type_bits 2:{'Mb':'1'}")



# Generated at 2022-06-11 01:42:26.686136
# Unit test for function check_required_if
def test_check_required_if():
    assert [] == check_required_if(None, {})


# Generated at 2022-06-11 01:42:34.784349
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with single list
    assert check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2}) == []
    assert check_mutually_exclusive(['a', 'b'], {'a': 1}) == []
    assert check_mutually_exclusive(['a', 'b'], {'b': 1}) == []
    assert check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2}) == []
    # Test with list of lists
    assert check_mutually_exclusive([('a', 'b'), ('c', 'd')], {'a': 1, 'c': 2}) == []

# Generated at 2022-06-11 01:42:46.691724
# Unit test for function safe_eval
def test_safe_eval():
    (result, exception) = safe_eval('[1,2,3]', include_exceptions=True)
    assert (result == [1,2,3] and exception is None)
    result = safe_eval('[1,2,3]')
    assert (result == [1,2,3])
    (result, exception) = safe_eval('[1,2,3', include_exceptions=True)
    assert (result == '[1,2,3' and isinstance(exception, ValueError))
    result = safe_eval('[1,2,3')
    assert (result == '[1,2,3')
    (result, exception) = safe_eval('[1,2,3]', locals={'a':1}, include_exceptions=True)

# Generated at 2022-06-11 01:42:56.626966
# Unit test for function check_type_bits
def test_check_type_bits():
    """Unit test for function check_type_bits"""
    assert (check_type_bits('1Mb'), ) == (1048576, )
    assert (check_type_bits('1Mib'), ) == (1048576, )
    assert (check_type_bits('1Mbit'), ) == (1048576, )
    assert (check_type_bits('1M'), ) == (1048576, )
    assert (check_type_bits('1Mbyte'), ) == (1048576, )
    assert (check_type_bits('1MB'), ) == (1048576, )
    assert (check_type_bits('1MBit'), ) == (1048576, )
    assert (check_type_bits('1234'), ) == (1234, )

# Generated at 2022-06-11 01:43:07.255719
# Unit test for function safe_eval
def test_safe_eval():

    include_exceptions = True
    assert safe_eval('1 + 1', include_exceptions=include_exceptions) == (2, None)
    assert safe_eval('import os', include_exceptions=include_exceptions) == ('import os', None)
    assert safe_eval('import datetime', include_exceptions=include_exceptions) == ('import datetime', None)
    assert safe_eval('datetime.date.today()', include_exceptions=include_exceptions) == ('datetime.date.today()', None)
    assert safe_eval("{'a': 1, 'b': 2}", include_exceptions=include_exceptions) == ({"a": 1, "b": 2}, None)

# Generated at 2022-06-11 01:43:12.257816
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = ['test1', 'test2']
    parameters = {'test1': 'test1', 'test2': 'test2'}
    try:
        check_mutually_exclusive(terms, parameters)
    except Exception as e:
        assert e.args[0] == 'parameters are mutually exclusive: test1|test2'



# Generated at 2022-06-11 01:43:14.917300
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1B') == 8
# End Unit test for function check_type_bits



# Generated at 2022-06-11 01:43:24.780339
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """Test check_mutually_exclusive function"""
    from pytest import raises
    from ansible.module_utils.common.text.converters import to_text

    param = {'method': 'password', 'username': 'admin', 'password': 'admin'}

    # Test simple mutually exclusive with single value in list
    me_list = ['password', 'username']
    check_mutually_exclusive(me_list, param)

    # Test simple mutually exclusive with multiple values in list
    me_list = ['password', 'username']
    check_mutually_exclusive(me_list, param)


    # Test single list of multiple mutually exclusive with single value in each list
    me_list = [['method', 'username'], ['method', 'password']]
    check_mutually_exclusive(me_list, param)

    # Test multiple

# Generated at 2022-06-11 01:43:35.188462
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # one level
    assert check_mutually_exclusive(['foo', 'bar'], {'foo': [1, 2], 'bar': 3}) == []
    assert check_mutually_exclusive(['foo', 'bar'], {'foo': [1, 2], 'baz': 3}) == []
    assert check_mutually_exclusive(['foo', 'bar'], {'foo': [1, 2], 'bar': 3, 'baz': 4}) != []

    # two levels
    assert check_mutually_exclusive([['foo', 'bar'], ['baz', 'zoo']], {'foo': [1, 2], 'bar': 3, 'baz': 4, 'zoo': [1, 2, 3]}) == []

# Generated at 2022-06-11 01:43:46.085076
# Unit test for function check_required_if
def test_check_required_if():
    parameters = dict(
        id='xyz',
        backup_config=True,
        backup_name='mybackup',
        max_backups=5,
    )
    requirements = [
        ['backup_config', True, ('backup_name', 'max_backups')],
        ['backup_config', True, ('id', 'max_backups'), True],
    ]

    results = check_required_if(requirements, parameters)
    assert results == []

    parameters['backup_name'] = None
    results = check_required_if(requirements, parameters)
    assert len(results) == 1
    assert results[0]['missing'] == ['backup_name']
    assert results[0]['requires'] == 'all'
    assert results[0]['parameter'] == 'backup_config'

# Generated at 2022-06-11 01:43:48.083039
# Unit test for function check_required_if
def test_check_required_if():
    import pytest

    raise pytest.UsageError("Unit test not yet implemented")



# Generated at 2022-06-11 01:43:54.530941
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb')==1048576
    assert check_type_bits('1kb')==1024
    assert check_type_bits('1gb')==1073741824
    assert check_type_bits('1tb')==1099511627776
    assert check_type_bits('1pb')==1125899906842624
    assert check_type_bits('1eb')==1152921504606846976


# Generated at 2022-06-11 01:43:55.959063
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-11 01:44:02.831272
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/path/to/file',
        'someint': 99
    }
    result = check_required_if(requirements, parameters)
    assert result == []

    # Test with option context
    result = check_required_if(requirements, parameters, options_context=['backup'])
    assert result == []

    parameters = {
        'state': 'present',
        'someint': 99
    }
    with pytest.raises(TypeError) as exc:
        check_required_if(requirements, parameters)

# Generated at 2022-06-11 01:44:15.059075
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('2K') == 2048
    assert check_type_bytes('2Ki') == 2048
    assert check_type_bytes('1m') == 1000000
    assert check_type_bytes('2M') == 2000000
    assert check_type_bytes('2Mi') == 2097152
    assert check_type_bytes('1g') == 1000000000
    assert check_type_bytes('2G') == 2000000000
    assert check_type_bytes('2Gi') == 2147483648
    assert check_type_bytes('1t') == 1000000000000
    assert check_type_bytes('2T') == 2000000000000
    assert check_type_bytes('2Ti') == 2199023255552
    assert check_type_bytes('1p')

# Generated at 2022-06-11 01:44:19.752804
# Unit test for function check_required_if
def test_check_required_if():
    # Spec is None
    requirements = None
    parameters = {}
    assert check_required_if(requirements, parameters) == []

    # Parameters is None
    requirements = []
    parameters = None
    assert check_required_if(requirements, parameters) == []

    # Parameters has no specified required if
    requirements = [['state', 'present', ('path',), True]]
    parameters = {'state': 'present', 'path': '/var/foo'}
    assert check_required_if(requirements, parameters) == []

    # Parameter is not present, no required ifs evaluated
    requirements = [['state', 'present', ('path',)], ['someint', 99, ('bool_param', 'string_param')]]
    parameters = {'state': 'present', 'path': '/var/foo'}
    assert check_required_

# Generated at 2022-06-11 01:44:25.036187
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1024 * 1024
    assert check_type_bytes('512K') == 512 * 1024
    assert check_type_bytes('1G') == 1024 * 1024 * 1024

_TYPE_VALIDATOR = {
    'dict': check_type_dict,
    'str': check_type_str,
    'path': check_type_path,
    'list': check_type_list,
    'bool': check_type_bool,
    'int': check_type_int,
    'float': check_type_float,
    'raw': check_type_raw,
    'jsonarg': check_type_jsonarg,
    'tuple': check_type_tuple,
    'bytes': check_type_bytes,
}

# These are for implementing various types of additional checking for

# Generated at 2022-06-11 01:44:33.148272
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'require_string': 'test'}
    parameters = {'require_string': 'test_value'}
    assert not check_required_by(requirements, parameters)

    requirements = {'require_string': ['test']}
    parameters = {'require_string': 'test_value'}
    assert not check_required_by(requirements, parameters)

    requirements = {'require_string': ['test', 'test2', 'test3']}
    parameters = {'require_string': 'test_value'}
    assert check_required_by(requirements, parameters)

    requirements = {'require_string': ['test', 'test2', 'test3']}
    parameters = {'require_string': 'test_value', 'require_string2': 'test_value2'}

# Generated at 2022-06-11 01:44:40.666301
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():

    # Create a test module
    """
    - name: Test module
      options:
        mutually_exclusive:
          - {foo, bar}
          - {baz, foobar}
      required_together:
        - foo
        - bar
      required_if:
        - {'bar': 'baz'}
    """
    test_module = dict()
    test_module['options'] = dict()
    test_module['options']['mutually_exclusive'] = list()
    test_module['options']['mutually_exclusive'].append(['foo', 'bar'])
    test_module['options']['mutually_exclusive'].append(['baz', 'foobar'])
    test_module['options']['required_together'] = list()

# Generated at 2022-06-11 01:44:48.925065
# Unit test for function check_required_by
def test_check_required_by():
    try:
        check_required_by({'key':'value'}, {})
    except TypeError:
        pass

    assert check_required_by({'key':'value'}, {'key':'value'}) == {}



# Generated at 2022-06-11 01:44:52.222777
# Unit test for function check_type_bytes
def test_check_type_bytes():
    try:
        check_type_bytes(123)
    except TypeError as e:
        print(e)
        assert 'value cannot be converted to a Byte value' in str(e)


# Generated at 2022-06-11 01:45:02.642359
# Unit test for function check_type_int
def test_check_type_int():
    #Test if the function works as expected
    param_value = "10"
    assert check_type_int(param_value) == 10

    param_value = 10
    assert check_type_int(param_value) == 10

    param_value = "-10"
    assert check_type_int(param_value) == -10

    param_value = None
    assert check_type_int(param_value) == 0

    param_value = bool
    assert check_type_int(param_value) == 1

    param_value = "not an integer"
    with pytest.raises(TypeError):
        check_type_int(param_value)

    param_value = "1.0"
    with pytest.raises(TypeError):
        check_type_int(param_value)



# Generated at 2022-06-11 01:45:14.182306
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(123) == 123
    assert check_type_bytes('123') == 123
    assert check_type_bytes('123M') == 123 * 1024 * 1024
    assert check_type_bytes('123MiB') == 123 * 1024 * 1024
    assert check_type_bytes('123MB') == 123 * 1000 * 1000
    assert check_type_bytes('123 MB') == 123 * 1000 * 1000
    assert check_type_bytes('1.23GB') == 1.23 * 1000 * 1000 * 1000
    assert check_type_bytes('1.23GB') == 1.23 * 1000 * 1000 * 1000
    assert check_type_bytes('1.23  GB') == 1.23 * 1000 * 1000 * 1000
    assert check_type_bytes('1.0') == 1
    assert check_type_bytes('1.1')

# Generated at 2022-06-11 01:45:20.331849
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{1:2, 3:4}') == {1: 2, 3: 4}
    assert safe_eval('{"A":1, "B":2}') == {"A": 1, "B": 2}
    assert safe_eval('"A"') == "A"
    assert safe_eval('1') == 1
    assert safe_eval('-1') == -1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('-1.1') == -1.1
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval(1) == 1
    assert safe_eval(-1) == -1
    assert safe_eval(1.1) == 1.1

# Generated at 2022-06-11 01:45:21.863529
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits("20Mb") == 20971520
    assert check_type_bits("1.55m") == 1608896
    assert check_type_bits("1G") == 1000000000


# Generated at 2022-06-11 01:45:28.152611
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    with pytest.raises(TypeError) as exc_info:
        spec = dict(
                mutually_exclusive=[['a', 'b'], ['c', 'd'], ['e', 'f', 'g']],
                a=True,
                c=True,
                e=True
        )
        check_mutually_exclusive(spec['mutually_exclusive'], spec)
        assert len(exc_info.value) == 5
        assert exc_info.value[0] == 'parameters are mutually exclusive: a|b, c|d, e|f|g'

    spec = dict(
            mutually_exclusive=[['a', 'b'], ['c', 'd', 'e']],
            a=True,
            c=True,
            d=True
    )

# Generated at 2022-06-11 01:45:39.607635
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(11.1) == 11.1
    assert check_type_float(10) == 10.0
    assert check_type_float(10.1) == 10.1
    assert check_type_float('11.1') == 11.1
    assert check_type_float('10.0') == 10.0
    assert check_type_float(u'11.1') == 11.1
    assert check_type_float(u'10.0') == 10.0
    assert check_type_float(b'11.1') == 11.1
    assert check_type_float(b'10.0') == 10.0
    assert check_type_float(b'10') == 10.0

INVALID_VALUES = (None, [], {}, object)


# Generated at 2022-06-11 01:45:41.111033
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576


# Generated at 2022-06-11 01:45:51.742583
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # check if one of the list of tuple,if any one is present then it should return empty list
    args = (None, {})
    result = check_required_one_of(*args)
    assert result == []
    args = ([('a', 'b')], {'b': 'test_value'})
    result = check_required_one_of(*args)
    assert result == []
    args = ([('a', 'b')], {'b': 'test_value', 'c': 'test_value'})
    result = check_required_one_of(*args)
    assert result == []
    args = ([('a', 'b')], {})
    result = check_required_one_of(*args)
    assert result == [('a', 'b')]

# Generated at 2022-06-11 01:46:05.707615
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # Confirm an error is returned when no parameters are given and one or more
    # parameters are required
    with pytest.raises(TypeError):
        check_required_one_of([['term1', 'term2']], {})

    # Confirm an error is returned when a list of parameters are given, but none
    # are in the required list
    with pytest.raises(TypeError):
        check_required_one_of([['term1', 'term2']], {'term3': 'value'})

    # Confirm no error is returned when a list of parameters are given and at
    # least one is in the required list
    check_required_one_of([['term1', 'term2']], {'term2': 'value'})

# Generated at 2022-06-11 01:46:17.870761
# Unit test for function check_required_together
def test_check_required_together():
    from pytest import raises
    terms = [
        ('name', 'type'),
        ('host', 'port'),
    ]
    parameters = {'name': 'test_name'}
    assert check_required_together(terms, parameters) == []

    parameters = {'type': 'test_type'}
    assert check_required_together(terms, parameters) == []

    parameters = {'name': 'test_name', 'type': 'test_type'}
    assert check_required_together(terms, parameters) == []

    parameters = {'name': 'test_name', 'type': 'test_type', 'host': 'test_host'}
    assert check_required_together(terms, parameters) == []


# Generated at 2022-06-11 01:46:27.658426
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{{lookup('env','HOME')}}") == "{{lookup('env','HOME')}}"
    assert safe_eval("{{lookup('pipe','echo foo')}}") == "{{lookup('pipe','echo foo')}}"
    assert safe_eval("{{lookup('pipe','echo foo')}}", include_exceptions=True)[0] == "{{lookup('pipe','echo foo')}}"
    assert safe_eval("{{lookup('pipe','echo foo')}}", include_exceptions=True)[1] is None
    assert safe_eval("3+3") == 6
    assert safe_eval("'hello'") == "hello"
    assert safe_eval("['a','b']") == ['a','b']

# Generated at 2022-06-11 01:46:38.436700
# Unit test for function check_required_by
def test_check_required_by():
    requirements = dict(key1=['key2', 'key3'], key3=['key1'], key4=['key2', 'key3'])
    parameters = dict(key1='value1', key2='value2', key3='value3')
    assert check_required_by(requirements, parameters) == dict()
    parameters = dict(key1='value1', key2='value2')
    assert check_required_by(requirements, parameters) == dict(key1=['key3'], key4=['key3'])
    parameters = dict(key1='value1', key3='value3')
    assert check_required_by(requirements, parameters) == dict(key1=['key2'], key4=['key2'])
    parameters = dict(key2='value2', key3='value3')


# Generated at 2022-06-11 01:46:42.548997
# Unit test for function check_type_bits
def test_check_type_bits():
    """test function check_type_bits."""
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1.5Mb') == 1572864
    assert check_type_bits('10') == 10
    assert check_type_bits(1) == 1



# Generated at 2022-06-11 01:46:54.253671
# Unit test for function check_type_float
def test_check_type_float():

    try:
        check_type_float(value=10.2)
    except TypeError:
        assert False, "should not throw an exception"

    try:
        check_type_float(value="10.2")
    except TypeError:
        assert False, "should not throw an exception"

    try:
        check_type_float(value=b"10.2")
    except TypeError:
        assert False, "should not throw an exception"

    try:
        check_type_float(value=u"10.2")
    except TypeError:
        assert False, "should not throw an exception"

    try:
        check_type_float(value=b"x")
        assert False, "should not throw an exception"
    except:
        assert True



# Generated at 2022-06-11 01:47:05.186299
# Unit test for function check_type_float
def test_check_type_float():
    # True cases
    assert check_type_float(1) == 1
    assert check_type_float(1.0) == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(u'1') == 1.0
    assert check_type_float(u'1.0') == 1.0
    # False cases
    try:
        assert check_type_float('a') == 1.0
    except TypeError:
        assert True
    try:
        assert check_type_float([]) == 1.0
    except TypeError:
        assert True

# Generated at 2022-06-11 01:47:09.951005
# Unit test for function check_required_one_of
def test_check_required_one_of():
    module = dict(
        option_1='foo',
        option_2='bar',
        option_3='baz'
    )
    terms = [['option_1', 'option_2', 'option_3']]
    assert check_required_one_of(terms, module) == []



# Generated at 2022-06-11 01:47:17.474239
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int('0') == 0
    assert check_type_int('1') == 1
    assert check_type_int(1) == 1
    with pytest.raises(TypeError):
        check_type_int(True)
    with pytest.raises(TypeError):
        check_type_int(False)
    with pytest.raises(TypeError):
        check_type_int([])
    with pytest.raises(TypeError):
        check_type_int(())
    with pytest.raises(TypeError):
        check_type_int({})    



# Generated at 2022-06-11 01:47:22.156214
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('123') == 123
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824



# Generated at 2022-06-11 01:47:30.493101
# Unit test for function check_type_bytes
def test_check_type_bytes():
    s='20M'
    ss=check_type_bytes(s)
    assert ss==20971520


# Generated at 2022-06-11 01:47:38.649936
# Unit test for function check_type_bytes
def test_check_type_bytes():
    """
    Unit test for core_boolean
    """
    myvalues = ['10B', '10KB', '10MB', '10GB', '10TB', '10PB', '10EB', '10ZB', '10YB', '10BB']
    myreturns = [10, 10240, 10485760, 10737418240, 10995116277760, 11258999068426240, 1152921504606846976, 1180591620717411303424, 1208925819614629174706176, 1237940039285380274899124224]
    myi = 0
    for value in myvalues:
        humanvalue = check_type_bytes(value)
        myreturn = myreturns[myi]
        assert humanvalue == myreturn
        myi += 1

B

# Generated at 2022-06-11 01:47:50.851132
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # First test case
    # Lists of lists of mutually exclusive parameters
    terms = [['asset_type', 'type'], ['name', 'serial_number'], ['product_number', 'serial_number']]
    # Dictionary of parameters
    parameters = {'asset_type': 'host', 'product_number': '761088'}
    count = count_terms(terms, parameters)
    assert count == 0
    # Second test case
    # Lists of lists of mutually exclusive parameters
    terms = [['asset_type', 'type'], ['name', 'serial_number'], ['product_number', 'serial_number']]
    # Dictionary of parameters
    parameters = {'asset_type': 'host', 'serial_number': 'HC12345'}
    count = count_terms(terms, parameters)
    assert count == 1

# Generated at 2022-06-11 01:48:02.917349
# Unit test for function check_required_by
def test_check_required_by():
    reqs = {'a': 'b', 'c': ['d', 'e'], 'f': 'g'}
    params = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    options_context = 'test'
    assert check_required_by(reqs, params, options_context) == {}
    params = {'c': 3, 'd': 4}
    assert check_required_by(reqs, params, options_context) == {'c': ['e']}
    params = {'c': 3}
    assert check_required_by(reqs, params, options_context) == {'c': ['d', 'e']}
    params = {'c': 3, 'e': 5}
    assert check_required_by(reqs, params, options_context) == {}

# Generated at 2022-06-11 01:48:14.045113
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('0') == 0
    assert safe_eval('3.7') == 3.7
    assert safe_eval(u"{'foo': 'bar'}") == {'foo': 'bar'}
    assert safe_eval(r"""{'foo\n': 'bar'}""") == {'foo\n': 'bar'}
    assert safe_eval(r"""{'foo\\n': 'bar'}""") == {'foo\\n': 'bar'}
    assert safe_eval(r"""{'foo\"': 'bar'}""") == {'foo\"': 'bar'}
    assert safe_eval(r"""{'foo\'': 'bar'}""") == {'foo\'': 'bar'}

# Generated at 2022-06-11 01:48:22.184587
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("[1,2,3,'a','b','c',dict(a=1,b=2,c=3)]") == \
           [1, 2, 3, 'a', 'b', 'c', dict(a=1, b=2, c=3)]
    assert safe_eval("{'a':1,'b':2,'c':3}") == {'a': 1, 'b': 2, 'c': 3}
    assert safe_eval("1 == 2") is False
    assert safe_eval("None") is None
    assert safe_eval("dict(a=1,b=2,c=3)") == dict(a=1, b=2, c=3)

# Generated at 2022-06-11 01:48:33.311537
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float('13.123') == 13.123
    assert check_type_float(13.123) == 13.123
    assert check_type_float(b'13.123') == 13.123
    assert check_type_float(13) == 13.0
    assert check_type_float(13) == 13.0
    assert check_type_float(b'13') == 13.0
    assert check_type_float('13') == 13.0
    assert check_type_float(b'13.123') == 13.123
    assert check_type_float(13.123) == 13.123
    assert check_type_float(b'13') == 13.0
    assert check_type_float('13') == 13.0
    assert check_type_float(b'13.123') == 13

# Generated at 2022-06-11 01:48:40.302137
# Unit test for function check_type_bits
def test_check_type_bits():
    print('==> Test check_type_bits():', end='')

    assert(2048 == check_type_bits('2kb'))
    assert(268435456 == check_type_bits('256mbit'))
    assert(104857600 == check_type_bits('100mb'))
    assert(104857600 == check_type_bits('100mbit'))

    print('OK')

#Unit test for function human_to_bytes

# Generated at 2022-06-11 01:48:48.550168
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # lists, tuples, and all other types are converted to lists
    assert check_required_one_of([['a', 'b']], {'a': 1}) == []
    assert check_required_one_of(['a', 'b'], {'a': 1}) == []
    assert check_required_one_of([('a', 'b')], {'a': 1}) == []
    # if any one of the elements is found, then it's ok
    assert check_required_one_of([['a', 'b']], {'b': 1}) == []
    assert check_required_one_of([['a', 'b']], {'a': 1, 'b': 1}) == []
    assert check_required_one_of([['a', 'b', 'c']], {'a': 1}) == []
    assert check

# Generated at 2022-06-11 01:48:57.101799
# Unit test for function check_type_float
def test_check_type_float():
    for t in [1, 1.0, '1', '1.0']:
        assert isinstance(check_type_float(t), float), \
            "expected float from '%s' got '%s'" % (t, type(t))
    assert isinstance(check_type_float(None), float), "expected float from None"
    assert isinstance(check_type_float(True), float), "expected float from True"
    assert isinstance(check_type_float(False), float), "expected float from False"


# Generated at 2022-06-11 01:49:08.060961
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """Function check if check_mutually_exclusive() works as expected"""
    # create a dict and test it
    try:
        terms = [['file', 'content']]
        parameters = {'file': 'myfile', 'content': 'mycontent'}
        result = check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        result = e.args[0]
    assert result == "parameters are mutually exclusive: file|content"

    # create a dict and test it
    terms = [['file', 'content'], ['state', 'force']]
    parameters = {'file': 'myfile', 'content': 'mycontent', 'force': False}
    result = check_mutually_exclusive(terms, parameters)
    assert result == []

    # create a dict and test it

# Generated at 2022-06-11 01:49:13.461487
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1') == 1
    assert check_type_bits('1Mb') == 131072
    assert check_type_bits('300Gb') == 3906250
    assert check_type_bits('1Tb') == 134217728
    assert check_type_bits('1Pb') == 137438953472
    assert check_type_bits('1Eb') == 140737488355328
    with pytest.raises(TypeError):
        check_type_bits('1Zb')



# Generated at 2022-06-11 01:49:17.863490
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [('network_id', 'ip_address')]
    parameters = {'network_id': 'net_uuid'}
    options_context = ['network_uuid']
    result = check_required_one_of(terms, parameters, options_context)
    assert result == []



# Generated at 2022-06-11 01:49:23.714694
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    t = [["name", "force", "aliases", "state"]]
    p = {"name": "foo", "force": True}

    assert check_mutually_exclusive(t, p) == []

    p = {"name": "foo", "force": True, "aliases": {"ansible": "foo"}}
    try:
        check_mutually_exclusive(t, p)
        assert False
    except TypeError as e:
        assert to_native(e) == "parameters are mutually exclusive: force|aliases found in name"



# Generated at 2022-06-11 01:49:35.461145
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(1) == 1
    assert check_type_bytes(u'') == b''
    assert check_type_bytes(u'1') == b'1'
    assert check_type_bytes(b'1') == b'1'
    assert check_type_bytes(u'true') == b'true'
    assert check_type_bytes(True) == True
    assert check_type_bytes(u'1b') == 1
    assert check_type_bytes(u'1B') == 1
    assert check_type_bytes(u'1k') == 1024
    assert check_type_bytes(u'1K') == 1024
    assert check_type_bytes(u'1m') == 1024 ** 2
    assert check_type_bytes(u'1M') == 1024 ** 2
    assert check_

# Generated at 2022-06-11 01:49:46.808057
# Unit test for function safe_eval
def test_safe_eval():
    import pdb
    # when used as a boolean test then safe_eval should return a boolean
    test_cases = [
        ([1, 2], True),
        ([], False),
        ('test', True),
        ('', False),
        (1, True),
        (0, False),
        (None, False),
    ]
    for test_data, expected_result in test_cases:
        result = safe_eval(test_data)
        assert bool(result) == expected_result, 'expected %s, got %s' % (expected_result, result)

    # now using the original intent of safe_eval

# Generated at 2022-06-11 01:49:50.632726
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(123) == 123
    assert check_type_bytes(None) == None
    assert check_type_bytes('') == 0
    assert check_type_bytes('12kb') == 12288



# Generated at 2022-06-11 01:49:52.616430
# Unit test for function check_type_bits
def test_check_type_bits():
    result = check_type_bits("1Mb")
    assert result == 1048576


# Generated at 2022-06-11 01:50:03.946303
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(
        terms=[['a', 'b'], ['x', 'y']],
        parameters=dict(a='a', x='x')
    ) == []

    assert check_mutually_exclusive(
        terms=[['a', 'b'], ['x', 'y']],
        parameters=dict(a='a', b='b')
    ) == [['a', 'b']]

    assert check_mutually_exclusive(
        terms=[['a', 'b'], ['x', 'y']],
        parameters=dict(a='a', b='b', x='x')
    ) == [['a', 'b'], ['x', 'y']]



# Generated at 2022-06-11 01:50:13.681869
# Unit test for function check_type_int
def test_check_type_int():
    try:
        check_type_int("2")
    except TypeError:
        print("Conversion of string to int caused TypeError")
    else:
        return True
    try:
        check_type_int(5)
    except TypeError:
        print("Integer datatype passed to check_type_int caused TypeError")
    else:
        return True
    try:
        check_type_int("A")
    except TypeError:
        pass
    else:
        return False
    try:
        check_type_int("2.5")
    except TypeError:
        pass
    else:
        return False
    try:
        check_type_int("True")
    except TypeError:
        pass
    else:
        return False
    return True