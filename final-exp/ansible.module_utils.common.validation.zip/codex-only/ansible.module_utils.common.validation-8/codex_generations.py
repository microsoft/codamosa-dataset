

# Generated at 2022-06-22 22:12:11.881254
# Unit test for function check_type_str
def test_check_type_str():
    check_type_str('bob')
    check_type_str(1)
    check_type_str(None)
    check_type_str(['test'])
    check_type_str(('test',))
    check_type_str(dict(a='b'))
    check_type_str('test', allow_conversion=False)
    check_type_str(1, allow_conversion=False)
    check_type_str(None, allow_conversion=False)
    check_type_str(['test'], allow_conversion=False)
    check_type_str(('test',), allow_conversion=False)
    check_type_str(dict(a='b'), allow_conversion=False)

# Generated at 2022-06-22 22:12:14.107319
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw("test") == "test"
    assert check_type_raw([1, 2]) == [1, 2]


# Generated at 2022-06-22 22:12:15.361553
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int('10') == 10



# Generated at 2022-06-22 22:12:23.929914
# Unit test for function check_type_bool
def test_check_type_bool():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec={}, supports_check_mode=False)
    # True for any value that starts with an "y", "t", "1"
    assert True == check_type_bool(1)
    assert True == check_type_bool(True)
    assert True == check_type_bool("1")
    assert True == check_type_bool("true")
    assert True == check_type_bool("yes")
    assert True == check_type_bool("y")
    assert True == check_type_bool("t")
    assert True == check_type_bool("on")
    assert True == check_type_bool("True")
    assert True == check_type_bool("YES")
    assert True == check_type_bool("yEs")

# Generated at 2022-06-22 22:12:33.657867
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("this=that") == {'this': 'that'}
    assert check_type_dict("this=that,and=another") == {'this': 'that', 'and': 'another'}
    assert check_type_dict("this=that,and=another,bool=no") == {'this': 'that', 'and': 'another', 'bool': 'no'}
    assert check_type_dict("this=that,and=another,bool=yes") == {'this': 'that', 'and': 'another', 'bool': 'yes'}
    assert check_type_dict("this=that,and=another,bool=True") == {'this': 'that', 'and': 'another', 'bool': 'True'}

# Generated at 2022-06-22 22:12:36.956540
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2}) == [['a', 'b']]



# Generated at 2022-06-22 22:12:39.907446
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg(['foo','bar']) == '["foo", "bar"]'
    assert check_type_jsonarg('["foo", "bar"]') == '["foo", "bar"]'



# Generated at 2022-06-22 22:12:44.945085
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'name': ['one', 'two', 'three']}
    parameters = {'name': 'foo', 'one': 'bar', 'two': 'bar', 'three': 'bar'}
    a = check_required_by(requirements, parameters)
    print(a)
    parameters = {'name': 'foo', 'two': 'bar'}
    a = check_required_by(requirements, parameters)
    print(a)



# Generated at 2022-06-22 22:12:56.171625
# Unit test for function check_type_dict

# Generated at 2022-06-22 22:12:58.503316
# Unit test for function check_type_raw
def test_check_type_raw():
    """If function check_type_raw returns the raw value then the test passed """
    value = {"key":"val"}
    assert check_type_raw(value) == value



# Generated at 2022-06-22 22:13:01.382313
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw("/dev/null") == "/dev/null"


# Generated at 2022-06-22 22:13:09.063753
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits("1mb") == 1048576
    assert check_type_bits("1024") == 1024
    assert check_type_bits("-1mb") == -1048576
    assert check_type_bits("-1024") == -1024
    assert check_type_bits("1") == 1
    assert check_type_bits("0") == 0
    assert check_type_bits("0.5") == 0.5
    assert check_type_bits("-1") == -1
    assert check_type_bits("-0.5") == -0.5
    assert check_type_bits("1K") == 1024
    assert check_type_bits(" 1K") == 1024
    assert check_type_bits("1K ") == 1024
    assert check_type_bits("1Kb") == 1024

# Generated at 2022-06-22 22:13:11.794047
# Unit test for function check_type_raw
def test_check_type_raw():
    assert(check_type_raw("String") == "String")
    assert(check_type_raw(5) == 5)
    assert(check_type_raw(True) == True)



# Generated at 2022-06-22 22:13:18.372985
# Unit test for function check_required_arguments
def test_check_required_arguments():
    from ansible.module_utils.basic import AnsibleModule
    """Test required arg evaluation.

    Expected conditions:
    - 'required' is true only for 'test_required'
    - 'test_required' is present
    - 'test_not_required' is not present

    Expected result:
    - Required args check is successful.
    """
    argument_spec = {
        'test_required': {'required': True},
        'test_not_required': {'required': False},
    }
    parameters = {
        'test_required': 'foo',
        # 'test_not_required' is not present
    }
    try:
        check_required_arguments(argument_spec, parameters)
    except Exception as e:
        module = AnsibleModule(argument_spec=argument_spec)

# Generated at 2022-06-22 22:13:26.225203
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(0.01) == 0.01
    assert check_type_float(0) == 0
    assert check_type_float('0.5') == 0.5
    assert check_type_float(u'1.5') == 1.5
    assert check_type_float(bytearray(b'2')) == 2.0
    assert check_type_float(b'3.1') == 3.1


# Generated at 2022-06-22 22:13:36.140548
# Unit test for function check_type_bytes
def test_check_type_bytes():
    from Units import Units
    from ansible.module_utils.six import StringIO
    kbytes = 1024
    mbytes = kbytes * 1024
    gbytes = mbytes * 1024
    abbr_expected = [(b'0', 0), (b'-1k', -1 * kbytes), (b'1.5M', int(1.5 * mbytes)),
                     (b'+1.5G', int(1.5 * gbytes)), (b'0.5k', 512), (b'5M', 5 * mbytes),
                     (b'5g', 5 * gbytes), (b'2 TB', 2 * Units.TB), (b'2 TiB', 2 * (Units.TB / Units.iB)),
                     (b'2.5 TiB', 2.5 * (Units.TB / Units.iB))]

# Generated at 2022-06-22 22:13:43.641541
# Unit test for function check_required_together
def test_check_required_together():
    terms = [
        ('name', 'domain', 'type'),
        ('name', 'domain'),
        ('name', 'type')
    ]
    # Everything is OK
    parameters = (
        'name',
        'domain',
        'type',
    )
    check_required_together(terms, parameters)

    # Missing 'type'
    parameters = (
        'name',
        'domain',
    )
    try:
        check_required_together(terms, parameters)
    except TypeError as e:
        #print("Exception: ", str(e))
        assert str(e) == "parameters are required together: name, domain, type"
    except Exception:
        assert False, "Wrong exception raised!"

    # Missing 'domain'
    parameters = (
        'name',
        'type',
    )


# Generated at 2022-06-22 22:13:55.790724
# Unit test for function check_type_str
def test_check_type_str():
    # type(None) is NoneType
    # In Python 3.x NoneType is not a subclass of string_type (unicode)
    # so we have to use isinstance()
    tests = [
        (u'str', 'str'),
        (b'str', 'str'),
        (None, TypeError),
        (1, TypeError),
        (1.0, TypeError),
        (set(), TypeError),
        (dict(), TypeError),
        (list(), TypeError),
    ]
    for test, expected in tests:
        if isinstance(expected, Exception):
            with pytest.raises(expected):
                check_type_str(test)
        else:
            result = check_type_str(test)
            assert result == expected
    # Test when allow_conversion=False

# Generated at 2022-06-22 22:13:58.744667
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True) is True
    assert check_type_bool('t') is True
    assert check_type_bool('f') is False



# Generated at 2022-06-22 22:14:08.321729
# Unit test for function check_type_float
def test_check_type_float():
    for i in range(-1000, 1000):
        (result, exc) = safe_eval(i, float(), include_exceptions=True)
        assert result == float(i), "i = %s" % i
        assert exc is None, "i = %s" % i
    (result, exc) = safe_eval(1000, float(), include_exceptions=True)
    assert result == float(1000), "i = %s" % 1000
    assert exc is None, "i = %s" % 1000
    (result, exc) = safe_eval('1000', float(), include_exceptions=True)
    assert result == float('1000'), "i = %s" % '1000'
    assert exc is None, "i = %s" % '1000'

# Generated at 2022-06-22 22:14:18.213828
# Unit test for function count_terms
def test_count_terms():
    params = {'a': 1, 'b': 2, 'x': 'foo', 'y': ['bar', 'baz'], 'z': {'qux': 1, 'quux': 2}}
    assert count_terms('a', params) == 1
    assert count_terms(['a'], params) == 1
    assert count_terms(['a', 'b'], params) == 2
    assert count_terms(['a', 'b', 'c'], params) == 2


# The validator must be a callable that takes the
# value as the only argument and returns true for
# a valid value. If the validator throws an
# exception the value is invalid

# Generated at 2022-06-22 22:14:27.678407
# Unit test for function check_type_list
def test_check_type_list():
    # Check for list
    assert check_type_list(['s', 'e', 'l', 'e', 'c', 't']) == ['s', 'e', 'l', 'e', 'c', 't']

    # Check for string
    assert check_type_list('s,e,l,e,c,t') == ['s', 'e', 'l', 'e', 'c', 't']

    # Check for int
    assert check_type_list(1) == ['1']

    # Check for float
    assert check_type_list(1.0) == ['1.0']

    # Check for boolean
    try:
        check_type_list(True)
        assert False
    except:
        assert True

    # Check for None

# Generated at 2022-06-22 22:14:38.605877
# Unit test for function check_required_by
def test_check_required_by():
    parameters = dict()
    requirements = dict()

    # Neither parameters nor requirements are set - success
    assert check_required_by(requirements, parameters) == {}

    # Set requirements and empty parameters - failure
    requirements = {'a': 'b'}
    try:
        check_required_by(requirements, parameters)
    except TypeError:
        pass

    # Set requirements and parameters that fail requirements - failure
    parameters = {'a': 'b'}
    try:
        check_required_by(requirements, parameters)
    except TypeError:
        pass

    # Set requirements and parameters that pass requirements - success
    parameters['b'] = 'c'
    assert check_required_by(requirements, parameters) == {}

    # Set multiple requirements and parameters that all pass - success

# Generated at 2022-06-22 22:14:41.160375
# Unit test for function check_type_bits
def test_check_type_bits():
    for unit in prefix_text:
        for base in bases:
            assert check_type_bits(str(base) + unit) == math.pow(bases[base], prefixes[unit])


# Generated at 2022-06-22 22:14:52.641308
# Unit test for function check_required_one_of
def test_check_required_one_of():
    """
    check the function works with
    :param Terms: List of lists of terms to check. For each list of terms, at
        least one is required.
    :param parameters: Dictionary of parameters
    :kwarg options_context: List of strings of parent key names if ``terms`` are
        in a sub spec.

    :returns: Empty list or raises :class:`TypeError` if the check fails.
    """
    params = {"a": ["a", "b", "c"], "b": "b", "c": "c"}
    terms = [("a", "b"), ("a", "c")]
    # Check that the function allways returns when parameters are valid
    assert check_required_one_of(terms, params) == []

    # Check that the function raises the error when parameters are not valid

# Generated at 2022-06-22 22:15:02.931630
# Unit test for function check_required_arguments
def test_check_required_arguments():
    from ansible.module_utils.common.text.converters import jsonify

    class ArgumentSpec(object):
        def __init__(self, required, default):
            self.required = required
            self.default = default


# Generated at 2022-06-22 22:15:11.228716
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": 1}') == {'a': 1}
    assert check_type_dict('a=1') == {'a': '1'}
    assert check_type_dict('a=1, b=2') == {'a': '1', 'b': '2'}
    assert check_type_dict('a=1, b=2, c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {'a': '1', 'b': '2', 'c': '3', 'd': '4'}



# Generated at 2022-06-22 22:15:19.454092
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(0.0) == 0.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float(2) == 2.0
    assert check_type_float("3.0") == 3.0
    assert check_type_float(u"4.0") == 4.0
    assert check_type_float(b"5.0") == 5.0
    assert check_type_float(b"6") == 6.0
    assert check_type_float(u"7") == 7.0
    assert check_type_float(u"8") == 8.0
    assert check_type_float(b"9") == 9.0
    assert check_type_float(10) == 10.0

# Generated at 2022-06-22 22:15:28.152120
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("{'a': 1, 'b': 2, 1: ['r', 'f', 'd']}") == {'a': 1, 'b': 2, 1: ['r', 'f', 'd']}
    assert safe_eval("['a', 1, ['r', 'f', 'd']]") == ['a', 1, ['r', 'f', 'd']]
    assert safe_eval("[1]") == [1]
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("'abcd'") == 'abcd'


# Generated at 2022-06-22 22:15:39.025453
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{\"a\": 1, \"b\": 2}") == {"a": 1, "b": 2}
    assert check_type_dict('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert check_type_dict('a=1, b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('c=1, d=2') == {"c": "1", "d": "2"}
    assert check_type_dict('a="b, c", d=2') == {"a": "b, c", "d": "2"}
    assert check_type_dict('a="b, \\"c\\""') == {"a": 'b, "c"'}

# Generated at 2022-06-22 22:15:49.121083
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # None or empty parameters should not cause an exception
    check_missing_parameters(None)
    check_missing_parameters({})
    check_missing_parameters(None,[])
    check_missing_parameters({},[])
    check_missing_parameters({'a':'b'})
    check_missing_parameters({'a':'b'},[])
    # If any thing is missing then it should raise an exception
    try:
        check_missing_parameters({},['c'])
        assert False
    except TypeError:
        pass
    try:
        check_missing_parameters({'a':'b'},['c'])
        assert False
    except TypeError:
        pass

# Generated at 2022-06-22 22:15:50.081379
# Unit test for function count_terms
def test_count_terms():
    pass



# Generated at 2022-06-22 22:15:54.721758
# Unit test for function check_type_int
def test_check_type_int():
    # Test happy path
    assert check_type_int("1234") == 1234
    assert check_type_int(1234) == 1234
    # Test unhappy path
    try:
        check_type_int("abc")
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-22 22:16:01.546642
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    check_type_jsonarg("")
    check_type_jsonarg("[]")
    check_type_jsonarg("{}")
    check_type_jsonarg("{'a': 1}")
    check_type_jsonarg("[]")
    check_type_jsonarg("[1,2,3]")
    with pytest.raises(TypeError) as exc:
        check_type_jsonarg({})
    assert "cannot be converted" in str(exc.value)
    with pytest.raises(TypeError) as exc:
        check_type_jsonarg([])
    assert "cannot be converted" in str(exc.value)
    #TODO: this is not json, should it raise error
    check_type_jsonarg("'[1,2,3]'")
# end of unit test


# Generated at 2022-06-22 22:16:04.816411
# Unit test for function check_type_bits
def test_check_type_bits():
    value = '1Mb'
    answer = 1048576
    assert check_type_bits(value) == answer
    return "check_type_bits passed"

# Generated at 2022-06-22 22:16:12.434153
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = [['one', 'two'], ['three', 'four', 'five'], ['six']]
    parameters = {'one': 1, 'two': 2, 'three': 3}
    result = check_mutually_exclusive(terms, parameters)
    assert len(result) == 0

    # Mutual exclusion failure
    parameters = {'one': 1}
    result = check_mutually_exclusive(terms, parameters)
    assert len(result) == 0
    parameters = {'one': 1, 'two': 2}
    try:
        result = check_mutually_exclusive(terms, parameters)
        assert False
    except TypeError:
        pass



# Generated at 2022-06-22 22:16:24.808119
# Unit test for function check_required_if
def test_check_required_if():
    # test for any
    try:
        check_required_if([['a', 'b', ('c',)],
                           ['a', 'b', ('d',)]],
                          {'a': 'b'})
    except TypeError as e:
        assert 'is b but any of the following are missing: c, d' in e.args[0]
    else:
        raise Exception('Test failed: check_required_if does not work for any')
    # test for all

# Generated at 2022-06-22 22:16:30.103090
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argspec = {
        'foo': {'required': False, 'type': 'str'},
        'bar': {'required': True, 'type': 'str'},
    }

    parameters = {}
    result = check_required_arguments(argspec, parameters)
    assert result == ['bar']

    parameters = {'bar': 'baz'}
    result = check_required_arguments(argspec, parameters)
    assert result == []


# Generated at 2022-06-22 22:16:41.247861
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a':'test', 'b':'test', 'c':'test', 'd':'test'}
    assert check_required_together(terms, parameters) == []
    parameters = {'a':'test', 'b':'test'}
    assert check_required_together(terms, parameters) == []
    parameters = {'a':'test', 'b':'test', 'c':'test'}
    assert check_required_together(terms, parameters) == [ ['c', 'd'] ]
    terms = [{'a', 'b'}, {'c', 'd'}]
    parameters = {'a':'test', 'b':'test', 'c':'test', 'd':'test'}
    assert check_

# Generated at 2022-06-22 22:16:48.626435
# Unit test for function check_required_one_of
def test_check_required_one_of():
    from copy import deepcopy
    from ansible.module_utils.common.validation import check_required_one_of, check_mutually_exclusive
    from ansible.module_utils.six import string_types

    # check_mutually_exclusive function
    assert len(check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3})) == 0
    assert len(check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3, 'd': 4})) == 1

# Generated at 2022-06-22 22:16:55.098551
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = dict(
        param1=dict(required=False),
        param2=dict(required=True),
    )
    empty_parameters = dict()
    nonexisting_parameter = dict(param1='value')
    existing_parameter = dict(param2='value')
    try:
        check_required_arguments(argument_spec, empty_parameters)
        assert False
    except TypeError:
        assert True
    try:
        check_required_arguments(argument_spec, nonexisting_parameter)
        assert False
    except TypeError:
        assert True
    try:
        check_required_arguments(argument_spec, existing_parameter)
        assert True
    except TypeError:
        assert False
    # TODO: more tests -- required isn't a boolean, required is None, etc

# Generated at 2022-06-22 22:17:01.971632
# Unit test for function check_type_float
def test_check_type_float():
    # Check whether the function returns a float
    assert isinstance(check_type_float('1'), float)
    assert isinstance(check_type_float(1), float)
    assert isinstance(check_type_float(1.0), float)

    # Check whether the function raises TypeError if the value is not a float, int, str or bytes
    with pytest.raises(TypeError):
        check_type_float(b'\xe8')


# Generated at 2022-06-22 22:17:06.300722
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {"name": "test_name", "path": "test_path"}
    required_parameters_1 = ["name", "path"]
    assert check_missing_parameters(parameters, required_parameters_1) == []
    required_parameters_2 = ["name", "path", "state"]
    assert check_missing_parameters(parameters, required_parameters_2) == ['state']



# Generated at 2022-06-22 22:17:08.867916
# Unit test for function check_required_together
def test_check_required_together():
    params = {'first': 'Tom', 'last': 'Jones'}
    check_required_together([('first', 'last')], params)


# Generated at 2022-06-22 22:17:09.968792
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576


# Generated at 2022-06-22 22:17:15.668430
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(u'1.0') == 1.0
    assert check_type_float(u'1') == 1.0
    assert check_type_float(u'1.1') == 1.1
    assert check_type_float('') == 0.0
    assert check_type_

# Generated at 2022-06-22 22:17:24.245318
# Unit test for function check_type_dict
def test_check_type_dict():
    # pylint: disable=W8202
    def verify(input_, expected, error=None):
        """Verify that check_type_dict() produces the expected output for the given input.

        :arg input_: input value for check_type_dict()
        :type input_: str or dict
        :arg expected: expected dict of key-value pairs in the output
        :type expected: dict
        :arg error: value of exception raised by check_type_dict()
        :type error: None or str
        """
        if error is not None:
            with pytest.raises(TypeError, match=r'^%s$' % error):
                check_type_dict(input_)
        else:
            if isinstance(input_, dict):
                assert input_ is check_type_dict(input_)
           

# Generated at 2022-06-22 22:17:32.483701
# Unit test for function check_required_together
def test_check_required_together():
    x = check_required_together([('a', 'b')], {'a': True})
    assert len(x) == 0
    x = check_required_together([('a', 'b')], {'b': True})
    assert len(x) == 0
    x = check_required_together([('a', 'b')], {'a': True, 'b': True})
    assert len(x) == 0
    x = check_required_together([('a', 'b')], {})
    assert len(x) == 1



# Generated at 2022-06-22 22:17:37.599768
# Unit test for function check_type_int
def test_check_type_int():
    passed = failed = 0
    for value in ['1', '2', 3, 4, 5.0, 6.0]:
        if check_type_int(value) == int(value):
            passed += 1
        else:
            failed += 1
    assert passed == 6, "check_type_int passed {}/6 tests: {}".format(passed, failed)



# Generated at 2022-06-22 22:17:44.561682
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    testInput = [
        '{ "key": "value"}',
        {"key": "value"},
        ]
    testOutput = [
        '{ "key": "value"}',
        '{"key": "value"}',
        ]
    for i in range(0, len(testInput)):
        assert check_type_jsonarg(testInput[i]) == testOutput[i]



# Generated at 2022-06-22 22:17:46.853569
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(10) == 10
    

# Generated at 2022-06-22 22:17:50.035781
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int('1') == 1


# Generated at 2022-06-22 22:17:57.459560
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('one', {'one': 1, 'two': 2}) == 1
    assert count_terms(['one', 'two'], {'one': 1, 'two': 2}) == 2
    assert count_terms(['one', 'three'], {'one': 1, 'two': 2}) == 1
    assert count_terms('three', {'one': 1, 'two': 2}) == 0



# Generated at 2022-06-22 22:18:00.193686
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together([['a', 'b'], ['b', 'c']], {'a': 1, 'b': 2, 'c': 3})



# Generated at 2022-06-22 22:18:03.253458
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw("raw_value") == "raw_value"
    assert check_type_raw(1) == 1
    assert check_type_raw(True) is True



# Generated at 2022-06-22 22:18:10.396043
# Unit test for function check_type_list
def test_check_type_list():
    """Test check_type_list"""
    assert check_type_list(['test']) == ['test']
    assert check_type_list('test') == ['test']
    assert check_type_list('test,test2') == ['test', 'test2']
    assert check_type_list(1) == ['1']
    assert check_type_list(1.0) == ['1.0']
    try:
        check_type_list(1.0) == ['1.1']
        assert False
    except TypeError:
        assert True
    try:
        check_type_list({'test': 'test'})
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-22 22:18:17.927306
# Unit test for function check_type_dict
def test_check_type_dict():
    dict_str = '''
    {
        "key1": "value1",
        "key2" : 2,
        "key3" : {
            "key4": 3
        }
    }
    '''
    dict_str_json = json.loads(dict_str)
    dict_str_kv = dict(key1="value1", key2=2, key3=dict(key4=3))
    assert (check_type_dict(dict_str_json) == dict_str_json)
    assert (check_type_dict(dict_str_kv) == dict_str_kv)
    assert (check_type_dict(dict_str) == dict_str_json)



# Generated at 2022-06-22 22:18:23.773170
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = dict(
        required_arg1=dict(required=True, type='str'),
        required_arg2=dict(required=True, type='int'))
    parameters = dict(required_arg1='value1', required_arg2=0)
    assert not check_required_arguments(argument_spec, parameters, ['any_context'])
    parameters = dict(required_arg1='value1')
    try:
        check_required_arguments(argument_spec, parameters, ['any_context'])
    except TypeError as e:
        assert e.args[0] == "missing required arguments: required_arg2"
    else:
        raise Exception("check_required_arguments did not raise an error")

# Generated at 2022-06-22 22:18:30.462739
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(0.4) == 0.4
    assert check_type_float(1) == 1.0
    assert check_type_float('0.4') == 0.4
    assert check_type_float('1') == 1.0
    assert check_type_float(b'0.4') == 0.4
    assert check_type_float(b'1') == 1.0
    assert_raises(TypeError, check_type_float, {}) == 0.4


# Generated at 2022-06-22 22:18:42.316343
# Unit test for function check_required_together
def test_check_required_together():
    assert {} == check_required_together(None, {})
    assert {} == check_required_together([('a', 'b'), ('c', 'd')], {'a':1, 'b':1})
    assert {} == check_required_together([('a', 'b'), ('c', 'd')], {'a':None, 'b':1})
    assert {} == check_required_together([('a', 'b'), ('c', 'd')], {'a':1, 'b':None})

    test_passed = False
    try:
        check_required_together([('a', 'b'), ('c', 'd')], {'a':1})
    except TypeError:
        test_passed = True
    assert test_passed == True

    test_passed = False

# Generated at 2022-06-22 22:18:52.984104
# Unit test for function check_type_raw
def test_check_type_raw():
    test_value = None
    expected_result = None
    observed_result = check_type_raw(test_value)
    assert observed_result == expected_result

    test_value = 'string'
    expected_result = 'string'
    observed_result = check_type_raw(test_value)
    assert observed_result == expected_result

    test_value = ['a', 'list']
    expected_result = ['a', 'list']
    observed_result = check_type_raw(test_value)
    assert observed_result == expected_result

    test_value = {'a': 'dict'}
    expected_result = {'a': 'dict'}
    observed_result = check_type_raw(test_value)
    assert observed_result == expected_result

    test_value = True
    expected_result

# Generated at 2022-06-22 22:18:55.139142
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    expected = '[1, 2]'
    value = [1, 2]
    assert check_type_jsonarg(value) == expected


# Generated at 2022-06-22 22:19:07.365874
# Unit test for function check_required_together
def test_check_required_together():
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name

    from ansible.module_utils.common.validation import check_required_together

    def test_function(terms, parameters, options_context=None):
        results = check_required_together(terms, parameters, options_context)
        if results:
            raise TypeError('test fail results: ' + str(results))
    test_function([('a', 'b')], {'a': 1, 'b': 2})
    test_function([('d', 'e')], {'a': 1, 'b': 2})
    test_function([('a', 'b'), ('d', 'e')], {'a': 1, 'b': 2})

# Generated at 2022-06-22 22:19:10.697795
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('foo', dict(foo='bar')) == 1
    assert count_terms(['foo', 'bar'], dict(foo='bar')) == 1
    assert count_terms(('foo', 'bar'), dict(foo='bar', bar='baz')) == 2



# Generated at 2022-06-22 22:19:17.918341
# Unit test for function check_required_together
def test_check_required_together():
    # mock parameters
    parameters = {
        'param_a': 'test_a',
        'param_b': 'test_b',
        'param_c': 'test_c',
        'param_d': 'test_d',
        'param_e': 'test_e',
    }
    # all parameters are required
    terms = [
        ['param_a', 'param_b', 'param_c'],
        ['param_d', 'param_e'],
    ]
    result = check_required_together(terms, parameters)
    assert len(result) == 0
    # only one parameter is required in param_d, param_e
    parameters.pop('param_d')
    result = check_required_together(terms, parameters)
    assert len(result) == 1
    # two parameters are required in param

# Generated at 2022-06-22 22:19:23.185772
# Unit test for function count_terms
def test_count_terms():
    test_dict = dict(a=1, b=2, c=3, d=4)
    assert count_terms('a', test_dict) == 1
    assert count_terms('b', test_dict) == 1
    assert count_terms('c', test_dict) == 1
    assert count_terms('d', test_dict) == 1
    assert count_terms(['a'], test_dict) == 1
    assert count_terms(['a', 'b'], test_dict) == 2



# Generated at 2022-06-22 22:19:26.343428
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1)==1
    assert check_type_int('1')==1
    assert check_type_int('1.1') is None

# Generated at 2022-06-22 22:19:33.875429
# Unit test for function check_type_list
def test_check_type_list():
    expected_result = [0, 1, 2, 3, 4]
    result = check_type_list([0, 1, 2, 3, 4])
    assert result == expected_result
    result = check_type_list(0)
    expected_result = ['0']
    assert result == expected_result
    result = check_type_list('0,1,2,3,4')
    assert result == expected_result


# Generated at 2022-06-22 22:19:35.305874
# Unit test for function check_required_together
def test_check_required_together():
    pass



# Generated at 2022-06-22 22:19:45.267320
# Unit test for function check_required_together
def test_check_required_together():
    terms = [('one', 'two'), ('three', 'four')]
    parameters = {'one': 'test1', 'two': 'test2'}
    options_context = ['top', 'level']
    assert check_required_together(terms, parameters, options_context) == []

    parameters = {'three': 'test3'}
    assert check_required_together(terms, parameters, options_context) != []

    parameters = {'one': 'test1', 'two': 'test2', 'three': 'test3'}
    assert check_required_together(terms, parameters, options_context) == []

    parameters = {'three': 'test3', 'four': 'test4'}
    assert check_required_together(terms, parameters, options_context) == []


# Generated at 2022-06-22 22:19:53.204955
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Global spec
    argument_spec = dict(
        param1=dict(type='str', required='yes'),
        param2=dict(type='str', required='no'),
        param3=dict(type='str', required=False),
        param4=dict(type='str', required=True),
        param5=dict(type='str', required=True, aliases=['param6'])
    )
    parameters = dict(param1='value1', param2='value2', param3='value3', param4='value4', param5='value5')
    res = check_required_arguments(argument_spec, parameters)
    assert res == [], 'check_required_arguments function failed for valid inputs'


# Generated at 2022-06-22 22:20:00.992912
# Unit test for function check_required_together
def test_check_required_together():
    param = {'vserver':'ansible', 'name':'ansible', 'cifs_server':'ansible'}
    data = [('vserver', 'name', 'cifs_server')]
    try:
        check_required_together(data, param)
    except TypeError as e:
        assert False, "Function: Check required together is not working"
    except Exception as e:
        assert False, "Function: Check required together is not working"


# Generated at 2022-06-22 22:20:12.962336
# Unit test for function check_type_str
def test_check_type_str():
    def do_test_check_type_str(value, allow_conversion, expected_return_value, prefix='', param=None,
                               should_fail=False):
        try:
            ret_value = check_type_str(value, allow_conversion, param=param, prefix=prefix)
            assert ret_value == expected_return_value
        except TypeError as exc:
            if not should_fail:
                raise
            assert "is not a string and conversion is not allowed" in to_native(exc)
        else:
            if should_fail:
                raise AssertionError("Should have failed but did not")
    do_test_check_type_str("test", True, "test")
    do_test_check_type_str(5, True, "5")
    do_test_check_type_str

# Generated at 2022-06-22 22:20:20.539595
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg([1,2,3]) == '[1, 2, 3]'
    assert check_type_jsonarg('[1,2,3]') == '[1, 2, 3]'
    # This raises TypeError, so testing with try/except
    try:
        assert check_type_jsonarg(123) == '[1, 2, 3]'
    except TypeError as e:
        assert str(e) == '<type \'int\'> cannot be converted to a json string'
    else:
        assert False


# FIXME: Trying to port an enum requires a bit of tweaking
#        Right now we can't say a param is a number or a string

# Generated at 2022-06-22 22:20:31.115218
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1KB') == 1024
    assert check_type_bytes('1MB') == 1024 * 1024
    assert check_type_bytes('1GB') == 1024 * 1024 * 1024
    assert check_type_bytes('1TB') == 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1PB') == 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1EB') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1ZB') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1YB') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1f') == 1

# Generated at 2022-06-22 22:20:41.560145
# Unit test for function check_required_one_of
def test_check_required_one_of():
    import pytest
    options = {}
    exceptions = False
    with pytest.raises(TypeError) as excinfo:
        check_required_one_of([['state']],options)
    assert 'one of the following is required' in str(excinfo.value)
    with pytest.raises(TypeError) as excinfo:
        check_required_one_of([['state'],['validate_certs']],options)
    assert 'one of the following is required' in str(excinfo.value)
    options['state'] = 'present'
    with pytest.raises(TypeError) as excinfo:
        check_required_one_of([['state'],['validate_certs']],options)
    assert 'one of the following is required' in str(excinfo.value)

# Generated at 2022-06-22 22:20:46.708822
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list([1, 2, 3]) == [1, 2, 3]
    assert check_type_list('1,2,3') == ['1', '2', '3']
    assert check_type_list(1) == ['1']
    assert check_type_list('a') == ['a']
    try:
        check_type_list({1, 2, 3})
    except TypeError as e:
        assert str(e) == 'set cannot be converted to a list'



# Generated at 2022-06-22 22:20:52.387341
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Function check_type_bytes takes a value and returns the bytes equivalent
    def check_type_bytes(value):
        return to_bytes(value)
    # Test positive conditions
    positive_conditions = {
        'bytes': 1,
        'KB': 1024,
        'MB': 1048576,
        'GB': 1073741824,
        'TB': 1099511627776,
        'PB': 1125899906842624,
        'EB': 1152921504606847000,
        '50': 50,
    }
    for input_string, expected_bytes in six.iteritems(positive_conditions):
        # Passes strings which should be converted to bytes
        if isinstance(input_string, string_types):
            assert isinstance(check_type_bytes(input_string), int)
        #

# Generated at 2022-06-22 22:20:56.623772
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Test INPUT variable type text
    assert check_type_bytes('1') == 1
    assert check_type_bytes(0) == 0
    assert check_type_bytes(1) == 1
    assert check_type_bytes('1024') == 1024
    assert check_type_bytes(1024) == 1024
    assert check_type_bytes(1024.0) == 1024
    # Test INPUT variable with units
    assert check_type_bytes('1Mb') == 1048576
    assert check_type_bytes('1MB') == 1048576
    assert check_type_bytes('1gb') == 1073741824
    assert check_type_bytes('1Gb') == 1073741824
    assert check_type_bytes('1tb') == 1099511627776
    assert check_type_bytes('1Tb') == 10995

# Generated at 2022-06-22 22:21:05.705276
# Unit test for function check_type_dict
def test_check_type_dict():
    dict_under_test = dict(a=1, b=2, c=3)
    dict_string = "{'a': 1, 'b': 2, 'c': 3}"
    key_value = "a=1, b=2, c=3"
    key_value_single = "a=1"
    key_value_quoted = 'a="1,2,3"'
    key_value_json = '{ "a": "1,2,3", "b": "4,5,6" }'
    dict_string_invalid = "{'a': 1, 'b': 2, 'c': 3"    # missing ending }
    dict_with_no_value = "{'a': , 'b': 2, 'c': 3}"

    # Testing a valid dictionary

# Generated at 2022-06-22 22:21:14.654671
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    from ansible.module_utils.parsing.convert_bool import boolean
    # check required_parameters
    required_parameters = ['vlanid', 'ipaddr', 'type']

    # test missing some params
    args = dict(vlanid=120, type='internal')
    missing_params = check_missing_parameters(args, required_parameters)
    assert missing_params == ['ipaddr'], "Wrong missing parameter list returned: %s" % missing_params

    # test missing some params
    args = dict(vlanid=120)
    missing_params = check_missing_parameters(args, required_parameters)
    assert missing_params == ['ipaddr', 'type'], "Wrong missing parameter list returned: %s" % missing_params

    # test missing all params
    missing_params = check

# Generated at 2022-06-22 22:21:23.160575
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('hostname', {'hostname': 'localhost'}) == 1
    assert count_terms('hostname', {'hostname': 'localhost', 'version': '1.2.3'}) == 1
    assert count_terms('hostname', {'hostname': 'localhost', 'version': '1.2.3', 'name': 'test'}) == 1
    assert count_terms('hostname', {'version': '1.2.3', 'name': 'test'}) == 0
    assert count_terms(['hostname', 'version'], {'version': '1.2.3', 'name': 'test'}) == 1
    assert count_terms(['hostname', 'version', 'name'], {'version': '1.2.3', 'name': 'test'}) == 2



# Generated at 2022-06-22 22:21:31.848811
# Unit test for function check_required_by
def test_check_required_by():
    # Simple case, no requirement
    parameters = {'a': '1', 'b': '2', 'c': '3'}
    requirements = {}
    result = check_required_by(requirements, parameters)
    assert result == {}

    # Normalization of requirement, single string to list
    parameters = {'a': '1', 'b': '2', 'c': '3'}
    requirements = {'a': 'b'}
    result = check_required_by(requirements, parameters)
    assert result == {}

    # Missing requirement
    parameters = {'a': '1', 'c': '3'}
    requirements = {'a': ['b', 'd']}

# Generated at 2022-06-22 22:21:37.605024
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('10K') == 10240
    assert check_type_bytes('2048') == 2048
    assert check_type_bytes('4096M') == 4398046511104
    assert check_type_bytes('1024G') == 1125899906842624
    assert check_type_bytes('-12T') == -12884901888
    assert check_type_bytes('3P') == 31525197391593473
    assert check_type_bytes('-24E') == -2658455991569831744654692615953842176
    assert check_type_bytes('12Z') == 1342879521461618688
    assert check_type_bytes('-10Y') == -1125977586746556928

    #check to see if integer representation of bytes works
   

# Generated at 2022-06-22 22:21:43.152036
# Unit test for function check_type_str
def test_check_type_str():
    '''Test check_type_str works with common cases'''
    assert check_type_str(123) == '123'
    assert check_type_str(123, False) == '123'
    assert check_type_str('test') == 'test'
    assert check_type_str('test', False) == 'test'
    assert check_type_str(True) == 'True'
    assert check_type_str(True, False) == 'True'
    assert check_type_str(None) == 'None'
    assert check_type_str(None, False) == 'None'


# FIXME: The param and prefix parameters here are coming from AnsibleModule._check_type_bool()
#        which is using those for the warning messaged based on string conversion warning settings.
#        Not sure how to deal with that here since

# Generated at 2022-06-22 22:21:50.914169
# Unit test for function check_type_str
def test_check_type_str():
    # scenario 1
    value = 'test'
    # expected results
    expect_result = 'test'
    # test
    result = check_type_str(value)
    # assert to expected result
    assert result == expect_result
    # scenario 2
    value = b'test'
    # expected results
    expect_result = 'test'
    # test
    result = check_type_str(value)
    # assert to expected result
    assert result == expect_result
    # scenario 3
    value = b'test'
    # expected results
    expect_result = 'test'
    # test
    result = check_type_str(value, allow_conversion=False)
    # assert to expected result
    assert result == expect_result
    # scenario 4
    value = {'test': 'test'}
    #

# Generated at 2022-06-22 22:21:57.421363
# Unit test for function check_type_list
def test_check_type_list():
    value = check_type_list([1,2,3])
    assert value[0] == 1
    assert value[1] == 2
    assert value[2] == 3

    value = check_type_list(1)
    assert value[0] == '1'

    value = check_type_list('1,2,3')
    assert value[0] == '1'
    assert value[1] == '2'
    assert value[2] == '3'


# Generated at 2022-06-22 22:22:04.546330
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("my_hostname") == "my_hostname"
    assert safe_eval("{{ 'my_hostname' }}") == "my_hostname"
    assert safe_eval("{{ 'my_hostname' }}", include_exceptions=True) == ("my_hostname", None)
    assert safe_eval("'a'.upper()", include_exceptions=True) == ("'a'.upper()", None)
    assert safe_eval("import os", include_exceptions=True) == ("import os", None)
    assert safe_eval("1+1", include_exceptions=True) == (2, None)

