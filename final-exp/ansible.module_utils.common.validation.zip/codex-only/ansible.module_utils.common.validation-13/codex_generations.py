

# Generated at 2022-06-22 22:12:08.650843
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str("foo") == "foo"
    assert check_type_str("foo", param="bar", prefix="") == "foo"
    try:
        check_type_str(100, False)
    except TypeError as e:
        assert "is not a string" in to_native(e)
        assert "'100' is not a string" in to_native(e)
    except Exception as e:
        assert False, "Unexpected exception %s" % e
    try:
        check_type_str(100, False, "bar", "")
    except TypeError as e:
        assert "is not a string" in to_native(e)
        assert "'100' is not a string" in to_native(e)
        assert "bar" in to_native(e)

# Generated at 2022-06-22 22:12:15.146850
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float('1234.56') == 1234.56

# Generated at 2022-06-22 22:12:21.903460
# Unit test for function check_required_together
def test_check_required_together():
    param = {
        'elem1' : 'elem1',
        'elem2' : 'elem2'
    }
    # Error case : Check for 'elem1' and 'elem2' but 'elem2' is not found
    param_err = {
        'elem1' : 'elem1'
    }
    term = [['elem1', 'elem2']]
    # function should not return any value if no error is found
    res = check_required_together(term, param)
    assert res == []
    # function should raise TypeError if elem1, elem2 is not present

# Generated at 2022-06-22 22:12:26.444315
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    """
    Test check_missing_parameters
    """
    assert check_missing_parameters(
        {'a': 1, 'b': 2}, ['a']) == []
    assert check_missing_parameters(
        {}, ['a']) == ['a']
    assert check_missing_parameters(
        {'a': '', 'b': 2}, ['a']) == []
    assert check_missing_parameters(
        {'a': None, 'b': 2}, ['a']) == ['a']
    assert check_missing_parameters(
        {'a': 0, 'b': 2}, ['a']) == []
    assert check_missing_parameters(
        {'a': False, 'b': 2}, ['a']) == []



# Generated at 2022-06-22 22:12:31.902780
# Unit test for function check_type_bits
def test_check_type_bits():
    correct_value = 1048576
    value_to_test = '1Mb'
    if check_type_bits(value_to_test) != correct_value:
        raise AssertionError("check_type_bits incorrect, %s != %s" %(check_type_bits(value_to_test),correct_value))


# Generated at 2022-06-22 22:12:32.971695
# Unit test for function check_type_raw
def test_check_type_raw():
    """Test function check_type_raw"""
    assert check_type_raw('test') == 'test'



# Generated at 2022-06-22 22:12:37.189922
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together(["a","b"], {"a":1,"b":2}) is None
    assert check_required_together(["a","b"], {"b":2}) == "a"



# Generated at 2022-06-22 22:12:41.844829
# Unit test for function check_type_list
def test_check_type_list():
    assert [3] == check_type_list(3)
    assert ['3'] == check_type_list(3.0)
    assert ['one', 'two', 'three'] == check_type_list('one,two,three')
    assert ['one', 'two', 'three'] == check_type_list(['one', 'two', 'three'])


# Generated at 2022-06-22 22:12:49.804167
# Unit test for function check_required_if
def test_check_required_if():
    parameter = {'state': 'present', 'path': '/tmp', 'someint': 99}
    requirement = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
        ['someint', 100, ('required_param',)],
    ]
    assert check_required_if(requirement, parameter) == []
    parameter['someint'] = 100
    assert check_required_if(requirement, parameter) == [{'requires': 'all', 'parameter': 'someint', 'value': 100, 'requirements': ('required_param',), 'missing': ['required_param']}]
    parameter.pop('path')

# Generated at 2022-06-22 22:13:00.431274
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    key = b'f39b7fcdc8e90e81'
    vault = VaultLib(key)
    encrypted_value = vault.encrypt('string')
    assert check_type_jsonarg({"a": encrypted_value}) == to_bytes('{"a": "%s"}' % encrypted_value)
    assert check_type_jsonarg(["a", encrypted_value]) == to_bytes('["a", "%s"]' % encrypted_value)
    assert check_type_jsonarg(encrypted_value) == to_bytes('"%s"' % encrypted_value)



# Generated at 2022-06-22 22:13:11.120161
# Unit test for function check_required_if
def test_check_required_if():
    (ret, err) = check_required_if(None, {'unused_key':'unused_value'},
                                   options_context=None)
    assert not ret
    assert err is None

    # test positive case
    (ret, err) = check_required_if([['foo', 'bar', ('baz',), True],
                                    ['foo', 'bar', ('baz',), True]],
                                   {'foo': 'bar', 'baz': 'qaz'},
                                   options_context=None)
    assert not ret
    assert err is None

    # test negative case where no requirements should be met

# Generated at 2022-06-22 22:13:13.189352
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int('1') == 1
    assert check_type_int(1) == 1
    with pytest.raises(TypeError):
        assert check_type_int('1.0')
    assert check_type_int(1.0) == 1
    with pytest.raises(TypeError):
        assert check_type_int(None)


# Generated at 2022-06-22 22:13:17.873506
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by(requirements={'a': ['b', 'c']},
                             parameters={'a': '1', 'b': '2'}) == {}
    assert check_required_by(requirements={'a': ['b', 'c']},
                             parameters={'b': '2'}) == {'a': ['b', 'c']}
    assert check_required_by(requirements={'a': ['b', 'c']},
                             parameters={'a': '1'}) == {'a': ['b', 'c']}



# Generated at 2022-06-22 22:13:25.192654
# Unit test for function check_required_if
def test_check_required_if():
    # Some sample data
    argument_spec = dict(
        state=dict(type='str', required=True),
        required_one_of=dict(type='bool', required=True),
        required_if=dict(type='int', required=True),
        required_all_of=dict(type='bool', required=False),
        missing=dict(type='bool', required=False)
    )
    # Test case 1
    parameters = dict(
        state='present',
        required_one_of='True',
        required_if=99
    )
    # Test case 2
    parameters_2 = dict(
        state='absent',
        required_one_of='True',
        required_if=99
    )

    # Test case 3

# Generated at 2022-06-22 22:13:27.889857
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('a') == 'a'
    assert check_type_raw(1) == 1
    assert check_type_raw(False) is False



# Generated at 2022-06-22 22:13:34.645644
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('[{"host":"host01","port":80}]') == '[{"host": "host01", "port": 80}]'
    assert check_type_jsonarg('wibble') == 'wibble'
    assert check_type_jsonarg([]) == '[]'
    assert check_type_jsonarg({}) == '{}'
    assert check_type_jsonarg(['a']) == '["a"]'



# Generated at 2022-06-22 22:13:38.992925
# Unit test for function check_required_arguments
def test_check_required_arguments():
    spec = dict(test_dict=dict(required=True, type='str'))
    assert check_required_arguments(spec, dict(test_dict='foo')) == []
    try:
        check_required_arguments(spec, dict())
    except TypeError:
        pass



# Generated at 2022-06-22 22:13:49.710769
# Unit test for function check_type_dict
def test_check_type_dict():
    ''' Unit test for function check_type_dict '''
    try:
        check_type_dict('')
        raise Exception('test_check_type_dict: expect to get an exception, did not get an exception')
    except TypeError as exp:
        if str(exp) != "'<class 'str'>' cannot be converted to a dict":
            raise Exception('test_check_type_dict: expect to get an exception, got a different one: ' + str(exp))

# Generated at 2022-06-22 22:13:55.451173
# Unit test for function check_required_together
def test_check_required_together():
    # Success case
    parameters = {"foo": "bar", "baz": "quux"}
    terms = (["foo", "baz"],)
    assert [] == check_required_together(terms, parameters)
    # Failure case
    parameters = {"foo": "bar"}
    terms = (["foo", "baz"],)
    assert [] != check_required_together(terms, parameters)


# Generated at 2022-06-22 22:14:00.287998
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('1,2,3') == ['1', '2', '3']
    assert check_type_list(1) == ['1']
    assert check_type_list('1') == ['1']
    assert check_type_list([1]) == [1]
    assert check_type_list(['1']) == ['1']



# Generated at 2022-06-22 22:14:11.068128
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(None) == []
    assert check_type_list([]) == []
    assert check_type_list('') == ['']
    assert check_type_list('foo') == ['foo']
    assert check_type_list('foo,bar') == ['foo', 'bar']
    assert check_type_list([1]) == ['1']
    assert check_type_list(['foo']) == ['foo']
    assert check_type_list([1, 'foo']) == ['1', 'foo']
    assert check_type_list(1) == ['1']
    assert check_type_list(1.0) == ['1.0']
    assert check_type_list(bool()) == ['False']



# Generated at 2022-06-22 22:14:23.950910
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('a=b') == dict(a='b')
    assert check_type_dict('a=b,c=d') == dict(a='b', c='d')
    assert check_type_dict("a='b,c'") == dict(a='b,c')
    assert check_type_dict('a="b,c"') == dict(a='b,c')
    assert check_type_dict('a="b,c",d=e') == dict(a='b,c', d='e')
    # Add tests for multi-line dict values
    assert check_type_dict('a={\'b\': 1}') == dict(a=dict(b=1))

# Generated at 2022-06-22 22:14:36.537692
# Unit test for function check_type_bool
def test_check_type_bool():
    test_data = {'1' : True, 'on' : True, 1: True, '0' : False, 0 : False, 'n' : False, 'f' : False, 'false' : False, 'true' : True, 'y' : True, 't' : True, 'yes' : True, 'no' : False, 'off' : False}
    for key, value in test_data.items():
        assert check_type_bool(key) == value, "%s does not equal to %s" % (key, value)
    #raise TypeError
    with pytest.raises(TypeError):
        check_type_bool('boolean')
    with pytest.raises(TypeError):
        check_type_bool([])
    with pytest.raises(TypeError):
        check_type_bool({})

# Generated at 2022-06-22 22:14:41.092302
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('string') == 'string'
    assert safe_eval('1+1') == 2
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a": "b"}') == {u'a': u'b'}



# Generated at 2022-06-22 22:14:52.602289
# Unit test for function check_type_int
def test_check_type_int():
    class ReturnInt(object):
        def __init__(self, return_value):
            self.return_value = return_value

        def __int__(self):
            return self.return_value
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(ReturnInt(1)) == 1

    try:
        check_type_int(1.1)
        assert False, 'Should have thrown a TypeError'
    except TypeError as e:
        if 'cannot be converted to an int' not in to_native(e):
            assert False, 'to_native(e) should have contained "cannot be converted to an int"'


# Generated at 2022-06-22 22:14:56.264562
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(0) == 0
    assert check_type_raw(1) == 1
    assert check_type_raw('string') == 'string'
    assert check_type_raw(u'unicode') == u'unicode'
    assert check_type_raw(True) == True
    assert check_type_raw(False) == False



# Generated at 2022-06-22 22:15:00.037379
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # Valid Scenario
    params = {
        'state': 'present',
        'profile': 'test',
        'lb_af': 'ipv4-ucast-only',
        'vrid': None,
        'oper': 'enable',
        'vip': '2.2.2.2'
    }
    check_required_one_of([('state', 'profile')], params)



# Generated at 2022-06-22 22:15:05.526100
# Unit test for function check_type_path
def test_check_type_path():
    test_value_pass = '$HOME/.ansible_test/123.txt'
    test_value_fail = int(1)
    try:
        assert check_type_path(test_value_pass) == '/root/.ansible_test/123.txt'
        assert check_type_path(test_value_fail)
    except TypeError as e:
        assert 'cannot be converted to a path' in str(e)


# Generated at 2022-06-22 22:15:10.318519
# Unit test for function check_type_bool

# Generated at 2022-06-22 22:15:14.574009
# Unit test for function count_terms
def test_count_terms():
    test_dict = {'a': 'toast', 'b': 'toast', 'c': 'jam', 'd': 'jam', 'e': 'jam', 'f': 'peanut butter'}
    terms = ['toast', 'soup']
    expected = 1
    result = count_terms(terms, test_dict)
    assert result == expected



# Generated at 2022-06-22 22:15:18.766579
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'one': 1, 'two': 2, 'three': 3}
    required_parameters = ['one', 'two']
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert len(missing_params) == 0

    missing_params = check_missing_parameters(parameters, ['four'])
    assert len(missing_params) == 1



# Generated at 2022-06-22 22:15:24.893673
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1MB') == 1048576
    assert check_type_bytes('1 Mb') == 1048576
    assert check_type_bytes('1 Megabytes') == 1048576
    assert check_type_bytes(1048576) == 1048576
    try:
        check_type_bytes('1 XXX') == None
    except TypeError:
        assert True
    else:
        assert False
# End of unit test for function check_type_bytes



# Generated at 2022-06-22 22:15:28.981998
# Unit test for function check_type_float
def test_check_type_float():
    value_list = [1, 1.2, "1.2", "1", 1.0]

# Generated at 2022-06-22 22:15:38.313349
# Unit test for function check_type_float
def test_check_type_float():
    test_data = [('foo', '%s cannot be converted to a float'),
                 (b'foo', '%s cannot be converted to a float'),
                 (['foo'], '%s cannot be converted to a float'),
                 (1, 1.0),
                 (1.0, 1.0),
                 ('1', 1.0),
                ]

    for value,expected in test_data:
        if isinstance(expected, string_types):
            assert_raises_regexp(TypeError, expected % type(value), check_type_float, value)
        else:
            assert check_type_float(value) == expected



# Generated at 2022-06-22 22:15:43.131408
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'param1': '', 'param2': '', 'param3': '', 'param4': ''}
    required_parameters = ['param1', 'param2', 'param3']
    assert check_missing_parameters(parameters, required_parameters) == []

# Generated at 2022-06-22 22:15:48.895284
# Unit test for function check_required_by
def test_check_required_by():
    data = {'state': 'present', 'name': 'Test'}
    test_data = {'state': ['present', 'absent'], 'name': 'Test'}
    data2 = {'state': 'present'}
    key_list = ['name']
    assert check_required_by(test_data, data) == {}
    assert check_required_by(test_data, data2, key_list) == {'state': ['name']}



# Generated at 2022-06-22 22:15:55.153644
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(['test', 'foo'], {'test': 'abc', 'abc': 'xyz'}) == 1
    assert count_terms(['test', 'abc'], {'test': 'abc', 'abc': 'xyz'}) == 2
    assert count_terms(['test', 'xyz'], {'test': 'abc', 'abc': 'xyz'}) == 0



# Generated at 2022-06-22 22:16:05.707189
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True) is True
    assert check_type_bool(False) is False
    assert check_type_bool(1) is True
    assert check_type_bool(0) is False
    assert check_type_bool('True') is True
    assert check_type_bool('False') is False
    assert check_type_bool('1') is True
    assert check_type_bool('0') is False
    assert check_type_bool('t') is True
    assert check_type_bool('f') is False
    assert check_type_bool('true') is True
    assert check_type_bool('false') is False
    assert check_type_bool('y') is True
    assert check_type_bool('n') is False
    assert check_type_bool('yes') is True
    assert check_

# Generated at 2022-06-22 22:16:09.626954
# Unit test for function check_type_list
def test_check_type_list():
    assert [1] == check_type_list(1)
    assert ['1'] == check_type_list('1')
    assert ['1', '2'] == check_type_list('1,2')
    assert ['1', '2'] == check_type_list(['1', '2'])



# Generated at 2022-06-22 22:16:16.733114
# Unit test for function check_required_one_of
def test_check_required_one_of():
    spec = {
        'fields': {
            'field': {
                'required': True, 'type': 'str'
            },
            'other_field': {
                'required': True, 'type': 'str'
            },
        },
        # Options spec
        'options_spec': {
            'require_one_of': (
                ['field', 'other_field'],
            ),
        }
    }
    metadata = {}
    parameters = {}
    result = check_required_one_of(spec['options_spec']['require_one_of'], parameters, options_context=spec['options_spec'].get('options_context'))
    assert(result == [['field', 'other_field']])

    parameters = dict(field='a')

# Generated at 2022-06-22 22:16:18.334056
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576


# AnsibleModule related class and methods used to support AnsibleModule
# validation.  These are kept separate as options module maybe used without
# AnsibleModule

# Generated at 2022-06-22 22:16:28.851354
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('100') == 100
    assert check_type_bytes(100) == 100
    assert check_type_bytes(100.0) == 100
    assert check_type_bytes('100B') == 100
    assert check_type_bytes('100KB') == 102400
    assert check_type_bytes('100KiB') == 102400
    assert check_type_bytes('100MB') == 104857600
    assert check_type_bytes('100MiB') == 104857600
    assert check_type_bytes('100GB') == 107374182400
    assert check_type_bytes('100GiB') == 107374182400
    assert check_type_bytes('100TB') == 109951162777600
    assert check_type_bytes('100TiB') == 109951162777600
   

# Generated at 2022-06-22 22:16:38.938764
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('hello world') == b'hello world'
    assert check_type_str(b'hello world') == b'hello world'
    with pytest.raises(TypeError):
        check_type_str(10)
    with pytest.raises(TypeError):
        check_type_str(10, allow_conversion=False)


# FIXME: The param and prefix parameters here are coming from AnsibleModule._check_type_bool()
#        which is using those for the warning messaged based on boolean conversion warning settings.
#        Not sure how to deal with that here since we don't have config state to query.

# Generated at 2022-06-22 22:16:50.285562
# Unit test for function check_required_by
def test_check_required_by():
    req = dict(a=["b", "c"])
    with pytest.raises(TypeError) as e:
        check_required_by(req, dict())
    assert str(e.value) == "missing parameter(s) required by 'a': b, c"
    with pytest.raises(TypeError) as e:
        check_required_by(req, dict(a="foo", b="bar"))
    assert str(e.value) == "missing parameter(s) required by 'a': c"
    with pytest.raises(TypeError) as e:
        check_required_by(req, dict(a="foo", c="bar"))
    assert str(e.value) == "missing parameter(s) required by 'a': b"

# Generated at 2022-06-22 22:16:53.126655
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(12) == 12
    assert check_type_float(12.0) == 12.0
    assert check_type_float(u"12") == 12.0
    assert check_type_float(b"12") == 12.0
    assert check_type_float(b"12.0") == 12.0
    assert check_type_float(u"12.0") == 12.0
    assert check_type_float(u"12.0") == 12.0



# Generated at 2022-06-22 22:17:00.736081
# Unit test for function check_type_raw
def test_check_type_raw():
    assert 'a' == check_type_raw('a')
    assert 1 == check_type_raw(1)
    assert 1.1 == check_type_raw(1.1)
    assert [1,2] == check_type_raw([1,2])
    assert (1,2) == check_type_raw((1,2))
    assert {'a':1} == check_type_raw({'a':1})
    assert True == check_type_raw(True)
    assert False == check_type_raw(False)

# Generated at 2022-06-22 22:17:07.126690
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        # parameter, value, requirements, is_one_of
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    # Missing all requirements
    parameters = {
        'someint': 99,
        'state': 'present',
    }
    try:
        check(requirements, parameters)
    except TypeError as e:
        result = e.results
        assert result[0]['parameter'] == 'someint'
        assert result[0]['missing'] == ['bool_param', 'string_param']
        assert result[0]['requires'] == 'all'
    else:
        assert False, "TypeError was not raised"

    # Missing one of the requirements

# Generated at 2022-06-22 22:17:10.705979
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(b'1') == 1
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(u'1.0') == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1
    try:
        check_type_float(b'one')
        assert False
    except TypeError:
        assert True
    try:
        check_type_float(u'one')
        assert False
    except TypeError:
        assert True
    try:
        check_type_float('one')
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-22 22:17:13.697095
# Unit test for function safe_eval
def test_safe_eval():

    # test for safe_eval is in test/units/test_module.py
    # test_module, test_module_utils.TestUtilsModule
    pass



# Generated at 2022-06-22 22:17:16.237844
# Unit test for function check_type_path
def test_check_type_path():
    # Test with a valid string
    path = '~/test.txt'
    assert check_type_path(path) == os.path.expanduser(os.path.expandvars(path))
    # Test with an invalid type
    with pytest.raises(TypeError):
        check_type_path(1)



# Generated at 2022-06-22 22:17:20.357423
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Function call should succeed
    value = check_type_bytes('1KB')
    assert value == 1024

    # Function call should fail
    try:
        check_type_bytes('1')
    except TypeError:
        pass
    else:
        raise Exception("Expected failure did not happen")


# Generated at 2022-06-22 22:17:31.656483
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('1') is True
    assert check_type_bool('on') is True
    assert check_type_bool(1) is True
    assert check_type_bool('0') is False
    assert check_type_bool('n') is False
    assert check_type_bool('f') is False
    assert check_type_bool('False') is False
    assert check_type_bool(0) is False
    assert check_type_bool('true') is True
    assert check_type_bool('y') is True
    assert check_type_bool('t') is True
    assert check_type_bool('yes') is True
    assert check_type_bool('no') is False
    assert check_type_bool('off') is False

# Generated at 2022-06-22 22:17:38.113138
# Unit test for function check_type_path
def test_check_type_path():
    original = '/tmp/ansible.cfg'
    original_expanded = os.path.expanduser(os.path.expandvars(original))
    converted = check_type_path(original)
    if not original == converted:
        raise TypeError('%s could not be converted to a string' % type(original))
    if not converted == original_expanded:
        raise TypeError('%s could not be converted to an expanded path' % type(original))


# Generated at 2022-06-22 22:17:44.010958
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1.2) == 1.2
    assert check_type_float(1.23456789) == 1.23456789
    assert check_type_float(1.6) == 1.6
    assert check_type_float(2) == 2.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.2') == 1.2
    assert check_type_float('1') == 1.0
    assert check_type_float('1.2') == 1.2
    assert check_type_float('1.23456789') == 1.23456789


# Generated at 2022-06-22 22:17:45.582683
# Unit test for function check_type_bytes
def test_check_type_bytes():
    value = check_type_bytes('512')
    assert value == 512



# Generated at 2022-06-22 22:17:51.544870
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['test_param1', 'test_param2']], {'test_param1': 2})
    assert check_required_one_of([('test_param1', 'test_param2')], {'test_param1': 2})


# Generated at 2022-06-22 22:17:58.162894
# Unit test for function check_required_together
def test_check_required_together():
    parameters = dict(
        state='absent',
        face_name='Swiss721BT-Bold',
        font_family='Swiss721BT',
        font_style='Bold'
    )
    terms = [tuple(parameters.keys())]
    assert check_required_together(terms, parameters) == []

    parameters = dict(state='absent', face_name='Swiss721BT-Bold')
    terms = [tuple(parameters.keys())]
    try:
        check_required_together(terms, parameters)
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError was not thrown')


# Generated at 2022-06-22 22:18:05.315584
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Valid values
    assert check_type_bytes('10') == 10
    assert check_type_bytes('10B') == 10
    assert check_type_bytes('10b') == 10
    assert check_type_bytes('10kb') == 10240
    assert check_type_bytes('10 Kb') == 10240
    assert check_type_bytes('10Kb') == 10240
    assert check_type_bytes('10MB') == 10485760
    assert check_type_bytes('10KiB') == 10240
    assert check_type_bytes('10MiB') == 10485760
    assert check_type_bytes('10 MB') == 10485760
    assert check_type_bytes('10 GiB') == 10737418240
    # Invalid values

# Generated at 2022-06-22 22:18:16.610409
# Unit test for function check_type_dict
def test_check_type_dict():
    # Check for a string which is a json data
    assert check_type_dict("{\"key\": \"value\"}") == {"key": "value"}

    # Check for a string which is a key-value pair separated by a comma
    assert check_type_dict("key=value") == {"key": "value"}

    # Check for a string which is a key-value pair separated by a comma and space
    assert check_type_dict("key=value, key1=value1") == {"key": "value", "key1": "value1"}

    # Check for a string which is a key-value pair separated by a comma, space and double quote
    assert check_type_dict("key=\"value\", key1=\"value1\"") == {"key": "value", "key1": "value1"}

    # Check for a string which is a key-value

# Generated at 2022-06-22 22:18:27.095355
# Unit test for function check_required_by
def test_check_required_by():
    import unittest

    class TestCheckRequiredBy(unittest.TestCase):
        """A test case for the check_required_by function"""

        def test_type_error_raised(self):
            requirements = {'key1': 'foo', 'key2': ['bar', 'baz']}
            parameters = {
                'key1': 'foo',
                'key2': 'bar',
                'key3': 'blah'
            }
            self.assertRaises(TypeError, check_required_by, requirements, parameters)

        def test_no_error_raised(self):
            requirements = {'key1': ['foo', 'bar'], 'key2': ['foo']}

# Generated at 2022-06-22 22:18:33.319695
# Unit test for function check_required_arguments
def test_check_required_arguments():
    """ Unit test for function check_required_arguments """
    args = {
        'foo': {'required': False, 'type': 'str'},
        'bar': {'required': True, 'type': 'str'},
    }
    params = {'foo': 'hey', 'bar': 'world'}
    context = ['top', 'middle', 'bottom']
    check_required_arguments(args, params, options_context=context)
    assert True


# Generated at 2022-06-22 22:18:38.100629
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(False) is False
    assert check_type_raw(True) is True
    assert check_type_raw(1) is 1
    assert check_type_raw(0) is 0
    assert check_type_raw(None) is None
    assert check_type_raw('foo') is 'foo'
    assert check_type_raw(u'foo') is u'foo'
    assert check_type_raw({'foo': 'bar'}) == {'foo': 'bar'}
    assert check_type_raw(set(['foo'])) == set(['foo'])
    assert check_type_raw(['foo']) == ['foo']
    assert check_type_raw(('foo',)) == ('foo',)
    assert check_type_raw(object()) is not None


# Generated at 2022-06-22 22:18:39.452191
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(1) == 1
    assert check_type_raw(True) is True
    assert check_type_raw('-01.234') == '-01.234'


# Generated at 2022-06-22 22:18:50.300281
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(2.0) == 2
    assert check_type_int(5) == 5
    assert check_type_int('6') == 6
    assert check_type_int('7') != 7.0
    assert check_type_int('8') != 8.0
    assert check_type_int(False) == 0
    assert check_type_int(True) == 1
    assert check_type_int('some_text') == 0
    assert check_type_int('some_text') != 0.0
    with pytest.raises(TypeError):
        check_type_int(u'7.2')
    with pytest.raises(TypeError):
        check_type_int('7.2')
    with pytest.raises(TypeError):
        check_type_int({})

# Generated at 2022-06-22 22:18:51.608014
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1 GiB') == 1073741824
    assert check_type_bytes('1 KiB') == 1024
    assert check_type_bytes('1 MiB') == 1048576


# Generated at 2022-06-22 22:18:54.479981
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{ "foo": "bar" }') == '{ "foo": "bar" }'
    assert check_type_jsonarg(['foo', 'bar']) == json.dumps(['foo', 'bar'])



# Generated at 2022-06-22 22:19:07.281469
# Unit test for function check_type_dict
def test_check_type_dict():

    assert check_type_dict("a=1,b=2") == {"a": "1", "b": "2"}
    assert check_type_dict("a=1,b=2,") == {"a": "1", "b": "2"}
    assert check_type_dict("a=1,b=2, ") == {"a": "1", "b": "2"}
    assert check_type_dict("a=1, b=2") == {"a": "1", "b": "2"}
    assert check_type_dict("a=1, b=2,") == {"a": "1", "b": "2"}
    assert check_type_dict("a=1,b=2 b=3") == {"a": "1", "b": "2 b=3"}

# Generated at 2022-06-22 22:19:19.489410
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('100B') == b'100B'

_TYPE_CHECKER = {
    'bool': check_type_bool,
    'dict': check_type_dict,
    'float': check_type_float,
    'int': check_type_int,
    'list': check_type_list,
    'bytes': check_type_bytes,
    'str': check_type_str,
    'path': check_type_path,
    'raw': check_type_raw,
}


# Generated at 2022-06-22 22:19:28.690461
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1 MB') == 1048576
    assert check_type_bits('1 Mb') == 1048576
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1 Kb') == 1024
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1b') == 1



# Generated at 2022-06-22 22:19:30.739460
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('one', dict(one=1, two=1, three=1)) == 1


# Generated at 2022-06-22 22:19:40.438389
# Unit test for function check_type_float

# Generated at 2022-06-22 22:19:51.333568
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('hi', allow_conversion=False) == 'hi'
    assert check_type_str(u'hi', allow_conversion=False) == u'hi'
    assert check_type_str(10) == "10"
    assert check_type_str(10.5) == "10.5"
    assert check_type_str([1, 2, 3]) == "[1, 2, 3]"
    assert check_type_str({'a': 1, 'b': 2}) == "{'a': 1, 'b': 2}"

    assert check_type_str('hi', allow_conversion=True) == 'hi'
    assert check_type_str(u'hi', allow_conversion=True) == 'hi'

# Generated at 2022-06-22 22:20:03.783729
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('~/foo') == os.path.expanduser('~/foo')
    assert check_type_path('$HOME/bar') == os.path.expandvars('$HOME/bar')
    assert check_type_path('{0}/baz/qux'.format(os.path.expanduser('~'))) == os.path.expanduser('~/baz/qux')
    assert check_type_path('/some/absolute/path') == '/some/absolute/path'
    assert check_type_path(os.path.expandvars('$TRANBOX_HOME/bin')) == os.path.expandvars('$TRANBOX_HOME/bin')
    assert check_type_path('/') == '/'


# Generated at 2022-06-22 22:20:11.642547
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    with pytest.raises(TypeError) as excinfo:
        check_missing_parameters({}, ['name', 'job'])
    assert 'missing required arguments: name, job' in str(excinfo.value)
    assert check_missing_parameters({'name':'alex'}, ['name', 'job']) == []
    assert check_missing_parameters({'name':'alex', 'job':'engineer'}, ['name', 'job']) == []



# Generated at 2022-06-22 22:20:13.786160
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('foo') == os.path.expanduser(os.path.expandvars('foo'))



# Generated at 2022-06-22 22:20:22.133943
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    assert check_missing_parameters({'a': 1, 'b': 2});
    assert check_missing_parameters({'a': 1, 'b': 2}, ['a', 'b']);
    assert check_missing_parameters({'a': 1, 'b': 2}, ['a']);
    assert check_missing_parameters({'a': 1, 'b': 2}, ['b']);

    assert_raises(TypeError, check_missing_parameters, {'a': 1, 'b': 2}, ['c']);
    assert_raises(TypeError, check_missing_parameters, {'a': 1, 'b': 2}, ['c', 'd']);
    assert_raises(TypeError, check_missing_parameters, {'a': 1, 'b': 2}, ['a', 'b', 'c']);

# Generated at 2022-06-22 22:20:25.226675
# Unit test for function check_type_raw
def test_check_type_raw():
    """Unit test for check_type_raw"""
    assert check_type_raw(True) == True
    assert check_type_raw(False) == False
    assert check_type_raw('1') == '1'
    assert check_type_raw(1) == 1


# Generated at 2022-06-22 22:20:34.673969
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert check_type_dict({"a": 1, "b": 2, "c": "foo"}) == {"a": 1, "b": 2, "c": "foo"}
    assert check_type_dict('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert check_type_dict('{"a": "foo"}') == {"a": "foo"}
    assert check_type_dict('{"a": "foo"}') == {"a": "foo"}
    assert check_type_dict('a=1, b=2, c="foo"') == {"a": "1", "b": "2", "c": "foo"}

# Generated at 2022-06-22 22:20:39.556883
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{"a":1}') == '{"a":1}'
    assert check_type_jsonarg({'a':1}) == '{"a":1}'
    assert check_type_jsonarg(['a', 1]) == '["a",1]'
    assert check_type_jsonarg({'a':[1,2]}) == '{"a":[1,2]}'



# Generated at 2022-06-22 22:20:41.874008
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {'one': 1, 'two': 2}
    terms = [['one', 'two'], ['three']]
    check_required_together(terms, parameters)



# Generated at 2022-06-22 22:20:47.220540
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    # Tests for string
    assert check_type_jsonarg('{"a": "b"}') == '{"a": "b"}'
    # Tests for dict
    assert check_type_jsonarg({'a': 'b'}) == '{"a": "b"}'
    # Tests for list
    assert check_type_jsonarg(['a', 'b']) == '["a", "b"]'
    # Tests for tuple
    assert check_type_jsonarg(('a', 'b')) == '["a", "b"]'



# Generated at 2022-06-22 22:20:52.737935
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list([]) == []
    assert check_type_list(None) == None
    assert check_type_list('abc') == ['abc']
    assert check_type_list('abc,123') == ['abc', '123']
    assert check_type_list(123) == ['123']
    assert check_type_list(123.0) == ['123.0']



# Generated at 2022-06-22 22:20:58.735410
# Unit test for function check_type_list
def test_check_type_list():
    """Test that check_type_list() works as expected."""
    from collections import Iterable
    from collections import Mapping
    from collections import Sequence
    from collections import Set

    # check_type_list() should return a list for everything iterable and for
    # everything that is not an iterable or a mapping or a set.
    #
    # Since the function does not accept an iterable that contains a
    # non-iterable or a mapping or a set, we test only iterables of strings
    # and integers.
    #
    # That leaves mappings and sets.  The function returns a list of the values
    # in the mapping or set so here we test a mapping and a set of strings and
    # a mapping and set of integers.
    #
    # Once we have established that we have a list, we take a slice of the list
   

# Generated at 2022-06-22 22:21:07.105473
# Unit test for function check_type_str
def test_check_type_str():
    check_type_str(None, allow_conversion=True)
    check_type_str(None, allow_conversion=False)
    check_type_str('hello', allow_conversion=True)
    check_type_str('hello', allow_conversion=False)
    check_type_str(u'hello', allow_conversion=False)
    check_type_str(999, allow_conversion=True)
    check_type_str(999, allow_conversion=False)
    # Can't test TypeError because the code exits on error.
    #check_type_str(True, allow_conversion=False, msg='True is a bool and conversion is not allowed')


# Generated at 2022-06-22 22:21:14.121150
# Unit test for function count_terms
def test_count_terms():
    terms = 'test'
    parameters = {'test': 'val', 'test2': 'val2'}
    assert(count_terms(terms, parameters) == 1)

    terms = ['test', 'test2']
    parameters = {'test': 'val', 'test2': 'val2'}
    assert(count_terms(terms, parameters) == 2)


# Generated at 2022-06-22 22:21:22.343678
# Unit test for function count_terms
def test_count_terms():
    # Test with one term
    assert count_terms('name', {'name': 'test_vm', 'cpus': 2}) == 1
    # Test with multiple terms
    assert count_terms(['name', 'cpus'], {'name': 'test_vm', 'cpus': 2}) == 2
    # Test with no matches
    assert count_terms(['name', 'cpus'], {'memory': 2048}) == 0
    # Test with duplicate terms
    assert count_terms(['name', 'name'], {'name': 'test_vm'}) == 1

# TODO: The function name is misleading, as it's not just network_params

# Generated at 2022-06-22 22:21:26.193716
# Unit test for function check_type_str
def test_check_type_str():
    test_value = [1,2,3]
    assert to_native(test_value) == str(check_type_str(test_value))



# Generated at 2022-06-22 22:21:28.636941
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('100') == 100
    assert check_type_bytes(100) == 100
    assert check_type_bytes('100B') == 100
    assert check_type_bytes('100M') == 104857600



# Generated at 2022-06-22 22:21:33.460834
# Unit test for function check_type_float
def test_check_type_float():
    "Unit test for function check_type_float"
    # Test cases
    case_input = [ 1.1, "1.1", 2, "2", "Fail" ]
    case_output = [ 1.1, 1.1, 2, 2, "Fail" ]
    case_expected = [
        (float, 1.1),
        (float, 1.1),
        (int, 2),
        (int, 2),
        (str, "Fail"),
    ]
    case_expected_error = [
        None,
        None,
        None,
        None,
        TypeError('%s cannot be converted to a float' % type(case_input[4])),
    ]
    # Code to execute
    case_result = []
    case_result_error = []

# Generated at 2022-06-22 22:21:38.997463
# Unit test for function check_type_float
def test_check_type_float():
    assert(0.0 == check_type_float(0))
    assert(0.0 == check_type_float('0'))
    assert(0.0 == check_type_float(0.0))
    assert(0.0 == check_type_float('0.0'))
    assert(1.0 == check_type_float(1.0))
    assert(1.0 == check_type_float('1.0'))
    assert(1.0 == check_type_float(1))
    assert(1.0 == check_type_float('1'))
    assert(3.1415 == check_type_float(3.1415))
    assert(3.1415 == check_type_float('3.1415'))

# Generated at 2022-06-22 22:21:48.402899
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    from ansible.compat.tests import unittest
    from ansible.module_utils import basic

    class CheckArgs(unittest.TestCase):
        def test_check_type_jsonarg(self):
            data = {'json_arg': True}
            basic._ANSIBLE_ARGS = json.dumps(data)
            self.assertEqual(check_type_jsonarg(data['json_arg']), 'true')

    suite = unittest.TestLoader().loadTestsFromTestCase(CheckArgs)
    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-22 22:21:49.769680
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits("1Mb") == 1048576



# Generated at 2022-06-22 22:21:55.104980
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    if version_info[0] == 3:
        # Python3, add explicit test for bytes
        assert check_type_jsonarg(b'"hello"') == b'"hello"'
    assert check_type_jsonarg('"hello"') == '"hello"'



# Generated at 2022-06-22 22:21:59.184559
# Unit test for function check_type_int
def test_check_type_int():
    with pytest.raises(TypeError):
        assert check_type_int("test")
    with pytest.raises(TypeError):
        assert check_type_int(1.1)
    with pytest.raises(TypeError):
        assert check_type_int(True)
    assert check_type_int(1) == 1
    assert check_type_int("1") == 1
