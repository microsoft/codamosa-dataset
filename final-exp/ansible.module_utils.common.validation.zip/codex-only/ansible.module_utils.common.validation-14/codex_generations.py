

# Generated at 2022-06-22 22:12:08.284120
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {}
    parameters['state'] = 'present'
    parameters['name'] = 'test_name'
    parameters['type'] = 'OVF10'
    required_parameters = ['state', 'name', 'type', 'depool_after_test']
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == ['depool_after_test']



# Generated at 2022-06-22 22:12:10.276184
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-22 22:12:20.512160
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    from ansible.module_utils.basic import jsonify
    input_string1 = '["a", "b", {"key": "value"}, ["a", "b"]]'
    input_string2 = '["a", "b"]'
    input_string3 = '[1, "b"]'
    input_string4 = '["a", 2]'
    input_string5 = '{"key": "value"}'
    input_string6 = '{"key": 1}'
    input_string7 = '{"key": {"key2": "value2"}}'
    input_string8 = '{"key": ["a", "b"]}'
    input_string9 = '[1, {"key": "value"}]'

# Generated at 2022-06-22 22:12:28.358056
# Unit test for function check_required_one_of
def test_check_required_one_of():
    parameters = {
        'a': 'test',
        'b': 'test2'
    }

    term1 = ['a', 'b']
    term2 = ['c', 'd']
    terms = [term1, term2]
    options_context = ['test']
    assert check_required_one_of(terms, parameters, options_context=options_context) == []
    parameters = {
        'a': 'test',
        'b': 'test2',
        'c': 'test3',
        'd': 'test4'
    }
    assert check_required_one_of(terms, parameters, options_context=options_context) == []
    parameters = {
        'a': 'test',
        'b': 'test2',
        'c': 'test3'
    }
    assert check_required

# Generated at 2022-06-22 22:12:38.245058
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('david', {'david': 'm', 'james': 'm'}) == 1
    assert count_terms('david', {'david': 'm', 'james': 'm', 'david': 'm'}) == 1
    assert count_terms(['david','james'], {'david': 'm', 'james': 'm'}) == 2
    assert count_terms('david', {'david': 'm', 'james': 'm', 'daniel': 'm', 'jonathan': 'm'}) == 1
    assert count_terms(['david','james','matthew'], {'david': 'm', 'james': 'm', 'daniel': 'm', 'jonathan': 'm'}) == 2

# Generated at 2022-06-22 22:12:41.414950
# Unit test for function check_required_arguments
def test_check_required_arguments():
    parameters = {'state': 'present', 'service': 'test'}
    argument_spec = {'state': {'required': True}, 'service': {'required': True}}
    missing = check_required_arguments(argument_spec, parameters)
    assert len(missing) == 0
    parameters = {'state': 'present'}
    argument_spec = {'state': {'required': True}, 'service': {'required': True}}
    missing = check_required_arguments(argument_spec, parameters)
    assert len(missing) > 0
    assert 'service' in missing


# Generated at 2022-06-22 22:12:53.997517
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('a,b,c') == ['a', 'b', 'c']
    assert check_type_list('a,b,c,d') == ['a', 'b', 'c', 'd']
    assert check_type_list(['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
    assert check_type_list('a') == ['a']
    assert check_type_list(b'a') == ['a']
    assert check_type_list(['a']) == ['a']
    assert check_type_list(123) == ['123']
    assert check_type_list(123.) == ['123.0']

    try:
        check_type_list(object())
    except TypeError:
        pass

# Generated at 2022-06-22 22:12:58.469901
# Unit test for function check_type_bool
def test_check_type_bool():
    test_list = [ '1', 'on', 1, '0', 0, 'n', 'f', 'false', 'true', 'y', 't', 'yes', 'no', 'off' ]
    for x in test_list:
        if not check_type_bool(x):
            return False
    if check_type_bool(None):
        return False
    return True


# Generated at 2022-06-22 22:12:59.844848
# Unit test for function check_type_bits
def test_check_type_bits():
    assert_equals(human_to_bytes('1Mb', isbits=True), 1048576)



# Generated at 2022-06-22 22:13:06.639921
# Unit test for function check_type_int
def test_check_type_int():
    assert(check_type_int("7") == 7)
    assert(check_type_int("7.2") == 7)
    assert(check_type_int(7) == 7)
    assert(check_type_int(7.2) == 7)
    try:
        check_type_int("7.2a")
        assert(False)
    except TypeError:
        assert(True)
# End unit test


# Generated at 2022-06-22 22:13:14.955271
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{"a":1}') == '{"a":1}'
    assert check_type_jsonarg(('a',)) == '["a"]'
    assert check_type_jsonarg(['a']) == '["a"]'
    assert check_type_jsonarg({'a': 1}) == '{"a": 1}'
    assert check_type_jsonarg(['a', 2]) == '["a", 2]'
    assert check_type_jsonarg({'a': 1, 'b': 2, 'c': 3}) == '{"a": 1, "b": 2, "c": 3}'



# Generated at 2022-06-22 22:13:22.863143
# Unit test for function safe_eval
def test_safe_eval():

    value = 'os.getcwd()'
    expected = {'failed': True}
    result = safe_eval(value)
    assert result == expected

    value = 'import os'
    result = safe_eval(value)
    assert result == expected

    value = 'True'
    expected = True
    result = safe_eval(value)
    assert result == expected

    value = 'false'
    expected = 'false'
    result = safe_eval(value)
    assert result == expected

    value = '[]'
    expected = []
    result = safe_eval(value)
    assert result == expected



# Generated at 2022-06-22 22:13:28.073269
# Unit test for function check_type_raw
def test_check_type_raw():
    """check_type_raw: returns the raw value"""
    assert check_type_raw('raw') == 'raw'
    assert check_type_raw('1') == '1'
    assert check_type_raw(1) == 1
    assert check_type_raw(1.0) == 1.0

# Generated at 2022-06-22 22:13:34.082699
# Unit test for function check_type_list
def test_check_type_list():
    assert [] == check_type_list([])
    assert ['a'] == check_type_list('a')
    assert ['1'] == check_type_list(1)
    assert ['1.2'] == check_type_list(1.2)
    assert ['a', 'b', 'c'] == check_type_list('a,b,c')


# Generated at 2022-06-22 22:13:42.405682
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("") == ""
    assert safe_eval("True") is True
    assert safe_eval("true") is True
    assert safe_eval("TRUE") is True
    assert safe_eval("False") is False
    assert safe_eval("false") is False
    assert safe_eval("FALSE") is False
    assert safe_eval("1") == 1
    assert safe_eval("-1") == -1
    assert safe_eval("1.1") == 1.1
    assert safe_eval("-1.1") == -1.1
    assert safe_eval("1, 1") == (1, 1)
    assert safe_eval("1, -1") == (1, -1)
    assert safe_eval("1.1, 1.1") == (1.1, 1.1)
    assert safe_

# Generated at 2022-06-22 22:13:49.710369
# Unit test for function check_required_together
def test_check_required_together():
    terms = [('name', 'state')]
    parameters = dict(
        name='test',
        state='absent'
    )
    assert check_required_together(terms, parameters) == []

    parameters = dict(
        name='test'
    )
    assert check_required_together(terms, parameters) != []



# Generated at 2022-06-22 22:14:00.101051
# Unit test for function check_type_str
def test_check_type_str():
    ansible_mock = MagicMock()
    ansible_mock._check_type_string.return_value = ('FAILURE', None)
    # Start test failure path
    # 1. Call without allow_conversion flag set
    try:
        check_type_str(42, allow_conversion=False)
    except TypeError as e:
        assert 'is not a string and conversion is not allowed' in to_native(e)
    else:
        assert True == False, 'check_type_str() should have thrown a TypeError for incoming value (42) not being a string.'
    # End test failure path

    # Start test success path
    assert check_type_str('Test String', allow_conversion=True) == 'Test String'

# Generated at 2022-06-22 22:14:08.818279
# Unit test for function check_type_raw
def test_check_type_raw():
    value = "boo"
    assert check_type_raw(value) == "boo"
    value = 123
    assert check_type_raw(value) == 123
    value = ["boo"]
    assert check_type_raw(value) == ["boo"]
    value = {"boo": "bar"}
    assert check_type_raw(value) == {"boo": "bar"}
    value = True
    assert check_type_raw(value) == True


# Generated at 2022-06-22 22:14:11.773833
# Unit test for function count_terms
def test_count_terms():
    terms = list(['key1', 'key2', 'key1'])
    parameters = {'key1': 'value1', 'key2': 'value2'}
    assert count_terms(terms, parameters) == 2



# Generated at 2022-06-22 22:14:22.299754
# Unit test for function check_type_path
def test_check_type_path():
    curdir = os.path.dirname(os.path.abspath(__file__))
    expdir = os.path.expanduser("~/ansible/test")
    datadir = os.environ['ANSIBLE_DATA']
    # Should work with relative paths
    value = check_type_path("~/ansible/test")
    assert value == expdir
    # Should work with absolute paths
    value = check_type_path("%s/data/ansible_test" % datadir)
    assert value == "%s/data/ansible_test" % datadir
    # Should work with path variables
    if "ANSIBLE_DATA" in os.environ:
        value = check_type_path("${ANSIBLE_DATA}/ansible_test")

# Generated at 2022-06-22 22:14:28.210977
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert_raises(TypeError, check_type_float, {'yaml_error': 'invalid_type'})



# Generated at 2022-06-22 22:14:39.143004
# Unit test for function check_type_dict
def test_check_type_dict():
    # If you have a string that is a dictionary, pass it as is.
    assert check_type_dict('{"a":1}') == {'a': 1}
    # If the string contains a space then the string is evaluated as a
    # dictionary.
    assert check_type_dict('a=1') == {'a': '1'}
    assert check_type_dict('a = 1') == {'a': '= 1'}
    assert check_type_dict('a = 1, b = 2') == {'a': '= 1', 'b': '= 2'}
    assert check_type_dict('a=1, b=2') == {'a': '1', 'b': '2'}

# Generated at 2022-06-22 22:14:42.175827
# Unit test for function check_type_list
def test_check_type_list():
    # Test when value is a list
    value = [1]
    assert check_type_list(value) == value

    # Test when value is a comma separated string
    value = '1,2'
    assert check_type_list(value) == ['1', '2']

    # Test when value is int/float
    value = 1
    assert check_type_list(value) == ['1']

    # Test when value is a string
    value = 'foo'
    with pytest.raises(TypeError):
        check_type_list(value)



# Generated at 2022-06-22 22:14:49.670104
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('a,b,c') == ['a', 'b', 'c']
    assert check_type_list(['a', 'b']) == ['a', 'b']
    assert check_type_list(0) == ['0']
    assert check_type_list(0.0) == ['0.0']
    assert check_type_list(True) == ['True']
    assert check_type_list(None) == ['']



# Generated at 2022-06-22 22:14:50.960070
# Unit test for function check_type_float
def test_check_type_float():
    value = '0.01'
    assert isinstance(check_type_float(value), float)
    assert check_type_float(value) == 0.01



# Generated at 2022-06-22 22:14:58.425832
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(['a', 'b'], {'a': 'foo', 'b': 'bar'}) == 2
    assert count_terms('a', {'a': 'foo'}) == 1
    assert count_terms('a', {'a': 'foo', 'b': 'bar'}) == 1
    assert count_terms('a', {}) == 0



# Generated at 2022-06-22 22:15:09.657890
# Unit test for function check_type_list
def test_check_type_list():
    v = ['a', 'b', 'c']
    v1 = 'a'
    v2 = '1'
    v3 = 'a,b,c'
    v4 = '1,2,3'
    v5 = 11
    v6 = 11.0
    assert check_type_list(v) == ['a', 'b', 'c']
    assert check_type_list(v1) == ['a']
    assert check_type_list(v2) == ['1']
    assert check_type_list(v3) == ['a', 'b', 'c']
    assert check_type_list(v4) == ['1', '2', '3']
    assert check_type_list(v5) == ['11']
    assert check_type_list(v6) == ['11.0']




# Generated at 2022-06-22 22:15:10.430442
# Unit test for function check_type_raw
def test_check_type_raw():
    assert_equal(check_type_raw(value=True), True)



# Generated at 2022-06-22 22:15:13.392920
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    from ansible.module_utils.common.collections import is_sequence
    assert is_sequence(check_type_jsonarg('[1, 2, 3]'))
    assert isinstance(check_type_jsonarg('{ "a_value": 42 }'), dict)



# Generated at 2022-06-22 22:15:23.359399
# Unit test for function check_type_int
def test_check_type_int():
    if check_type_int(5) == 5:
        return True
    raise Exception( "check_type_int({0}) is {1}".format(5,check_type_int(5)) )
    if check_type_int('5') == 5:
        return True
    raise Exception( "check_type_int('5') is {0}".format(check_type_int('5')) )
    try:
        if check_type_int(True) == True:
            raise Exception( "check_type_int(True) is {0}".format(check_type_int(True)) )
    except:
        return True

# Generated at 2022-06-22 22:15:35.492902
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """
    Test check_mutually_exclusive function in basic scenarios
    """
    try:
        check_mutually_exclusive((('a', 'b'), ('c', 'd')), {'a': '1', 'c': '3'})
    except Exception as e:
        assert False, "Did not expect exception for below input: {}".format(e)

    try:
        check_mutually_exclusive((('a', 'b'), ('c', 'd')), {'a': '1', 'b': '2'})
        assert False, "Should have seen exception for below input: {}".format(e)
    except TypeError as e:
        assert e.args[0].startswith('parameters are mutually exclusive: '), "Expected a TypeError exception with a message starting with 'parameters are mutually exclusive: '"


# Generated at 2022-06-22 22:15:39.318159
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    params = [parameters, required_parameters]
    result = check_missing_parameters(parameters, required_parameters)
    if parameters is not None:
        if required_parameters is None:
            assert result == []
        elif required_parameters:
            print(result)
            assert result == 'missing_parameters'


# Generated at 2022-06-22 22:15:45.333946
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path("test/test") == "test/test"
    assert check_type_path("") == ""
    assert check_type_path("~/test/test") == os.path.expanduser("~/test/test")
    assert check_type_path("${HOME}/test/test") == os.path.expandvars("${HOME}/test/test")


# Generated at 2022-06-22 22:15:48.715581
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('') == []
    assert check_type_list('a') == ['a']
    assert check_type_list('a,b,c') == ['a', 'b', 'c']
    assert check_type_list([1, 2, 3]) == [1, 2, 3]
    assert check_type_list(123) == ['123']
    assert check_type_list(1.23) == ['1.23']
    try:
        check_type_list({'a': 'b'})
    except TypeError:
        pass
    else:
        fail('Expected exception')


# Generated at 2022-06-22 22:15:59.852573
# Unit test for function check_type_float
def test_check_type_float():
    # positive assertions
    assert(check_type_float(1) == 1.0)
    assert(check_type_float("1") == 1.0)
    assert(check_type_float(1.0) == 1.0)
    assert(check_type_float("1.0") == 1.0)
    assert(check_type_float("1k") == 1.0)
    # negative assertions
    with pytest.raises(TypeError):
        check_type_float("")
    with pytest.raises(TypeError):
        check_type_float("a")
    with pytest.raises(TypeError):
        check_type_float("k")
    with pytest.raises(TypeError):
        check_type_float("1.2k")

# Generated at 2022-06-22 22:16:10.241644
# Unit test for function check_type_bool
def test_check_type_bool():
    test_list = [
        #  '0', '1', 'on', 'off', 'yes', 'no', 'y', 'n', 't', 'f', True, False, 1, 0, 0.0, 1.1
        ( '0', False ),
        ( '1', True ),
        ( 'on', True ),
        ( 'off', False ),
        ( 'yes', True ),
        ( 'no', False ),
        ( 'y', True ),
        ( 'n', False ),
        ( 't', True ),
        ( 'f', False ),
        ( True, True ),
        ( False, False ),
        ( 1, True ),
        ( 0, False ),
        ( 0.0, False ),
        ( 1.1, True ),
    ]


# Generated at 2022-06-22 22:16:17.088176
# Unit test for function check_type_dict
def test_check_type_dict():
    assert {"a": "a"} == check_type_dict("a=a")
    assert {"a": "a", "b": "b"} == check_type_dict("a=a, b=b")
    assert {"a": "a"} == check_type_dict("'a=a'")
    assert {"a": "a"} == check_type_dict('"a=a"')
    assert {"a": "a=a"} == check_type_dict("'a=a=a'")
    assert {"a": "a=a"} == check_type_dict('"a=a=a"')
    assert {"a": "a"} == check_type_dict("{\"a\": \"a\"}")
    assert {"a": "b"} == check_type_dict("{a: b}")

# Generated at 2022-06-22 22:16:24.467433
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    """Unit test for function check_type_jsonarg"""
    assert check_type_jsonarg('{"a": 1}') == '{"a": 1}'
    assert check_type_jsonarg(['a', 1]) == '[\n  "a",\n  1\n]'
    assert check_type_jsonarg('a') == 'a'
    assert check_type_jsonarg(1) == '1'
    assert_raises(TypeError, check_type_jsonarg, None)


# Generated at 2022-06-22 22:16:29.770362
# Unit test for function check_type_bool
def test_check_type_bool():

    # truthy
    truthy = ['1', 'on', 1, 'true', 't', 'yes', 'y']
    for val in truthy:
        assert check_type_bool(val) is True

    # falsy
    falsy = ['0', 'off', 0, 'false', 'f', 'no', 'n']
    for val in falsy:
        assert check_type_bool(val) is False



# Generated at 2022-06-22 22:16:33.898241
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'a': 1, 'd': 3}
    assert [] == check_missing_parameters(parameters, ['a', 'b', 'c'])



# Generated at 2022-06-22 22:16:37.602007
# Unit test for function check_type_int
def test_check_type_int():
    assert isinstance(check_type_int('1'), int)
    assert isinstance(check_type_int(1), int)
    with pytest.raises(TypeError):
        check_type_int(True)


# Generated at 2022-06-22 22:16:48.802222
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1024') == 1024
    assert check_type_bytes('1024') == check_type_bytes(1024)
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1024 * 1024
    assert check_type_bytes('1G') == 1024 * 1024 * 1024
    assert check_type_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1Ki') == 1024
    assert check_type_bytes('1Mi') == 1024 * 1024
    assert check_type_bytes('1Gi') == 1024 * 1024 * 1024
    assert check_type_bytes('1Ti') == 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1KB') == 1000
    assert check_type_bytes('1MB') == 1000 * 1000

# Generated at 2022-06-22 22:16:54.267684
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """Unit tests for function check_mutually_exclusive"""
    # check_mutually_exclusive
    # test with list of lists
    check_terms = [['a', 'b'], ['c', 'd']]
    params = {
        'a': 'foo',
        'b': 'bar',
        'c': 'baz',
        'd': 'bat',
    }
    result = check_mutually_exclusive(check_terms, params)
    assert result == []
    # test with list
    check_terms = ['a', 'b']
    result = check_mutually_exclusive(check_terms, params)
    assert result == []
    # test when check fails

# Generated at 2022-06-22 22:17:04.097058
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('1') is True
    assert check_type_bool('on') is True
    assert check_type_bool(1) is True
    assert check_type_bool('0') is False
    assert check_type_bool(0) is False
    assert check_type_bool('n') is False
    assert check_type_bool('f') is False
    assert check_type_bool('false') is False
    assert check_type_bool('true') is True
    assert check_type_bool('y') is True
    assert check_type_bool('t') is True
    assert check_type_bool('yes') is True
    assert check_type_bool('no') is False
    assert check_type_bool('off') is False
    # in a dictionary

# Generated at 2022-06-22 22:17:11.573656
# Unit test for function check_type_str
def test_check_type_str():
    # Test strings
    cases = [
        'foo',
        'baz',
        u'unicode',
        'uÿnicode',
        'surrogate\udcff',
        'surrogate\ud800',
        'surrogate\udcff\ud800',
        'surrogate\udcff\ud800\udcff',
    ]
    for case in cases:
        result = check_type_str(case)
        assert isinstance(result, string_types)
        assert result == case

    # Test bytes

# Generated at 2022-06-22 22:17:13.628445
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Valid Inputs
    for value in ["1TB", "128M", "7.5M", "1kb", "1"]:
        assert check_type_bytes(value)
    # Invalid Inputs
    for value in [None, 1, [1, 2, 3]]:
        with pytest.raises(TypeError):
            check_type_bytes(value)



# Generated at 2022-06-22 22:17:20.959069
# Unit test for function check_type_int
def test_check_type_int():
    if check_type_int(1) != 1:
        return False
    if check_type_int(1.1) != 1:
        return False
    if check_type_int('1') != 1:
        return False
    if check_type_int('-1') != -1:
        return False
    try:
        check_type_int('1a')
        return False
    except TypeError:
        pass
    try:
        check_type_int('a')
        return False
    except TypeError:
        pass
    return True



# Generated at 2022-06-22 22:17:32.506927
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # fail: more than one in list
    terms = [['a', 'b'], ['b', 'c']]
    parameters = {'a': 1, 'b': 1, 'c': 1}
    try:
        check_mutually_exclusive(terms, parameters)
        raise Exception('Error check_mutually_exclusive failed to raise')
    except TypeError:
        pass

    # fail: more than one in list
    terms = [['a', 'b'], ['b', 'c']]
    parameters = {'a': 1, 'c': 1}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        raise Exception('Error check_mutually_exclusive failed to raise')

    # pass: none in list

# Generated at 2022-06-22 22:17:35.911402
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float("1.0") == 1.0
    assert check_type_float(1) == 1.0



# Generated at 2022-06-22 22:17:42.249539
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('10') == 10
    assert check_type_bytes('10 B') == 10
    assert check_type_bytes('10 B') == 10
    assert check_type_bytes('10M') == 10485760
    assert check_type_bytes('10 KiB') == 10240
    assert check_type_bytes('10 GiB') == 104857600
    assert check_type_bytes('10 GiB') == 104857600
    assert check_type_bytes('10 GiB') == 104857600

    with pytest.raises(TypeError):
        check_type_bytes(None)


# **kwargs is used here to support **kwargs in AnsibleModule argument_spec

# Generated at 2022-06-22 22:17:47.610295
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict({"a": "b"}) == {"a": "b"}
    assert check_type_dict("a=b, c=d") == {"a": "b", "c": "d"}
    assert check_type_dict('\'a\': "b"') == {"a": "b"}
    assert check_type_dict('"a": "b"') == {"a": "b"}



# Generated at 2022-06-22 22:17:49.211728
# Unit test for function check_type_float
def test_check_type_float():
    result=check_type_float(1.0)
    assert result==1.0



# Generated at 2022-06-22 22:17:57.922066
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive([['one', 'two', 'three'], ['four', 'five']], {'one': 'value', 'five': 'value'}) == [], 'Check passed with unique values'
    try:
        check_mutually_exclusive([['one', 'two', 'three'], ['four', 'five']], {'one': 'value', 'two': 'value'})
        assert False, 'Check should have raised TypeError with duplicate values'
    except TypeError:
        assert True, 'Check correctly raised a TypeError with duplicate values'


# Generated at 2022-06-22 22:18:02.861866
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    with pytest.raises(TypeError):
        check_missing_parameters({'name':'key'}, ['name', 'otherkey'])
        check_missing_parameters({}, ['name', 'otherkey'])

    assert check_missing_parameters({'name':'key'}, ['name', 'otherkey']) == []



# Generated at 2022-06-22 22:18:06.921184
# Unit test for function count_terms
def test_count_terms():
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert count_terms('b', parameters) == 1
    assert count_terms(['a', 'b'], parameters) == 2
    assert count_terms(['a', 'b', 'd'], parameters) == 2



# Generated at 2022-06-22 22:18:17.269941
# Unit test for function check_required_if
def test_check_required_if():
    """Unit test for function check_required_if"""
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'path': '/foo', 'state': 'present'}
    result = check_required_if(requirements, parameters)
    assert result == []

    parameters = {'path': '/foo', 'state': 'present', 'someint': 99}
    result = check_required_if(requirements, parameters)
    assert len(result) == 1
    assert result[0]['parameter'] == 'someint'
    assert result[0]['value'] == 99
    assert is_iterable(result[0]['requirements'])

# Generated at 2022-06-22 22:18:24.271963
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    assert check_missing_parameters({'a': 1}, ['a']) == []
    assert check_missing_parameters({'a': 1}, ['b']) == ['b']
    assert check_missing_parameters({'a': 1}, ['a', 'b']) == ['b']
    assert check_missing_parameters({'a': 1}, ['b', 'c']) == ['b', 'c']
    assert check_missing_parameters({'a': 1}, []) == []



# Generated at 2022-06-22 22:18:26.499929
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-22 22:18:29.650401
# Unit test for function check_type_path
def test_check_type_path():
    assert '~/my folder' == check_type_path('~/my folder')
    assert '/home/my_user/my folder' == check_type_path('$HOME/my folder')
    assert ' /bin/my folder' == check_type_path(' /bin/my folder')



# Generated at 2022-06-22 22:18:31.796189
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576


# Generated at 2022-06-22 22:18:32.957476
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(u"b'bar'") == u"b'bar'"



# Generated at 2022-06-22 22:18:43.770379
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('/foo/bar') == os.path.expanduser(os.path.expandvars('/foo/bar'))
    assert check_type_path('~/foo/bar') == os.path.expanduser(os.path.expandvars('~/foo/bar'))
    assert check_type_path('$HOME/foo/bar') == os.path.expanduser(os.path.expandvars('$HOME/foo/bar'))
    assert check_type_path(u'/foo/bar',) == os.path.expanduser(os.path.expandvars(u'/foo/bar'))

# Generated at 2022-06-22 22:18:54.015078
# Unit test for function check_type_bool
def test_check_type_bool():
    # "0", "n", "no", and "false" will be False
    assert check_type_bool("0") == False
    assert check_type_bool("n") == False
    assert check_type_bool("no") == False
    assert check_type_bool("false") == False
    # "1", "y", "yes", "true", and "on" will be True
    assert check_type_bool("1") == True
    assert check_type_bool("y") == True
    assert check_type_bool("yes") == True
    assert check_type_bool("true") == True
    assert check_type_bool("on") == True
    # Integer and Float will be True for non-zero, False for 0
    assert check_type_bool(1) == True

# Generated at 2022-06-22 22:18:57.189330
# Unit test for function check_type_dict
def test_check_type_dict():
    test_input = "name='abc',age=10"
    exp_output = dict()
    exp_output['name'] = 'abc'
    exp_output['age'] = '10'
    assert exp_output == check_type_dict(test_input)



# Generated at 2022-06-22 22:19:08.694971
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('1') == True
    assert check_type_bool(1) == True
    assert check_type_bool('on') == True
    assert check_type_bool('t') == True
    assert check_type_bool('true') == True
    assert check_type_bool('yes') == True
    assert check_type_bool('0') == False
    assert check_type_bool(0) == False
    assert check_type_bool('off') == False
    assert check_type_bool('f') == False
    assert check_type_bool('false') == False
    assert check_type_bool('n') == False
    assert check_type_bool('no') == False
    assert check_type_bool(None) == False
    assert check_type_bool('None') == False
    assert check_

# Generated at 2022-06-22 22:19:15.898141
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('a=1, b=2') == dict(a='1', b='2')
    assert check_type_dict('{"a":"1", "b":"2"}') == dict(a='1', b='2')
    assert check_type_dict('[1,2,3]') == [1,2,3]
    assert check_type_dict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert check_type_dict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert check_type_dict(check_type_dict('a=1, b=2')) == dict(a='1', b='2')



# Generated at 2022-06-22 22:19:22.468366
# Unit test for function count_terms
def test_count_terms():
    """Unit test for function count_terms"""
    # Given
    parameters = {'foo': 'bar', 'bar': 'baz'}

    # When/Then
    assert count_terms('foo', parameters) == 1
    assert count_terms(['foo'], parameters) == 1
    assert count_terms(['bar'], parameters) == 1
    assert count_terms(['baz'], parameters) == 0
    assert count_terms(['baz', 'bat'], parameters) == 0
    assert count_terms(['foo', 'bar'], parameters) == 2



# Generated at 2022-06-22 22:19:32.016699
# Unit test for function check_required_if
def test_check_required_if():
    # Test 1, error conditions
    params = {'key1': 1, 'key2': 'yes'}
    requirements = [['key1', 1, ('key2',)], ['key3', 'yes', ('key1', 'key2')]]
    try:
        check_required_if(requirements, params)
        assert False
    except TypeError as e:
        assert e.results[0]['parameter'] == 'key1'
        assert e.results[0]['value'] == 1
        assert e.results[0]['missing'] == []
        assert e.results[0]['requirements'] == ('key2',)
        assert e.results[0]['requires'] == 'all'

        assert e.results[1]['parameter'] == 'key3'
        assert e.results[1]['value']

# Generated at 2022-06-22 22:19:36.779363
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(('a', 'c'), {'a': 1, 'b': 2, 'c': 3}) == 2
    assert count_terms(['a', 'c'], {'a': 1, 'b': 2, 'c': 3}) == 2



# Generated at 2022-06-22 22:19:42.211149
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('abc') == 'abc'

    with pytest.raises(TypeError) as exc:
        check_type_str(123)
    assert str(exc.value) == "'123' is not a string and conversion is not allowed"

    assert check_type_str(123, allow_conversion=True) == '123'



# Generated at 2022-06-22 22:19:50.977988
# Unit test for function safe_eval
def test_safe_eval():
    # Test calls
    safe_eval('5 + 10') == 15
    safe_eval('-(5 + 10)') == -15
    safe_eval('import os', include_exceptions=True) == ('import os', None)
    safe_eval('import os') == 'import os'
    safe_eval('os.name') == 'os.name'
    safe_eval('datetime.datetime.now()') == 'datetime.datetime.now()'
    safe_eval('True') == True
    safe_eval('False') == False
    safe_eval('None') == None
    safe_eval("'Welcome'") == 'Welcome'
    safe_eval("u'Welcome'") == u'Welcome'
    safe_eval('u"Welcome"') == u'Welcome'



# Generated at 2022-06-22 22:19:55.841783
# Unit test for function check_required_together
def test_check_required_together():
    parameters = dict(a=1, b=1, c=1, d=1, e=1)
    terms = [['a' , 'b'], ['c', 'd', 'e']]
    if check_required_together(terms, parameters):
        return True
    else:
        return False


# Generated at 2022-06-22 22:19:57.756336
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw("test") == "test"



# Generated at 2022-06-22 22:20:10.315372
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Test '1MB'
    assert check_type_bytes('1MB') == 1048576
    # Test '1TB'
    assert check_type_bytes('1TB') == 1099511627776
    # Test '1GB'
    assert check_type_bytes('1GB') == 1073741824
    # Test '1PB'
    assert check_type_bytes('1PB') == 1125899906842624
    # Test '10B'
    assert check_type_bytes('10B') == 10
    # Test 1 byte
    assert check_type_bytes(1) == 1
    # Test '1MB, 1GB'
    assert check_type_bytes('1MB, 1GB') == 1.073741824
    # Test ' 1 MB, 1 GB '

# Generated at 2022-06-22 22:20:17.491008
# Unit test for function check_type_str
def test_check_type_str():
    obj = AnsibleModuleTest()
    assert isinstance(obj.ansible_module.check_type_str(), string_types)
    assert obj.ansible_module.check_type_str('test') == 'test'
    assert obj.ansible_module.check_type_str(u'test') == 'test'
    assert obj.ansible_module.check_type_str(1) == '1'
    try:
        obj.ansible_module.check_type_str(1, allow_conversion=False)
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-22 22:20:23.280131
# Unit test for function check_type_str
def test_check_type_str():
    from ansible.module_utils.six import PY3
    assert check_type_str(True) == 'True'
    if PY3:
        with pytest.raises(TypeError):
            check_type_str(b'foo')
    else:
        assert check_type_str(b'foo') == 'foo'
    assert check_type_str(10) == '10'
    with pytest.raises(TypeError):
        check_type_str(10, allow_conversion=False)
    assert check_type_str(u'yes') == 'yes'



# Generated at 2022-06-22 22:20:28.388340
# Unit test for function check_required_if
def test_check_required_if():
    import pytest
    argument_spec = dict(
        state=dict(type='str', required=False, default='present'),
        name=dict(type='str', required=True),
        someint=dict(type='int', required=True),
        bool_param=dict(type='str', required=False, default=False),
        string_param=dict(type='str', required=False, default=""),
        required_if=[
            ['state', 'present', ('path',), True],
            ['someint', 99, ('bool_param', 'string_param')],
        ])

    parameters = dict(
        state='present',
        name='test',
        someint=99,
        bool_param=False,
        string_param='',
    )


# Generated at 2022-06-22 22:20:35.941087
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1) == 1.0
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float('1.1') == 1.1
    assert type(check_type_float('1.1')) == float
    assert type(check_type_float(1.1)) == float
    try:
        check_type_float('bad')
    except TypeError:
        pass
    else:
        assert False, "check_type_float(b'bad') did not raise TypeError"
    assert check_type_float(None) == 0.0
    assert check_type_float(True) == 1.0



# Generated at 2022-06-22 22:20:37.661148
# Unit test for function check_type_raw
def test_check_type_raw():
    data = u'ABC'
    result = check_type_raw(data)
    assert result == data



# Generated at 2022-06-22 22:20:44.613812
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float("123.456") == 123.456
    assert check_type_float(123.456) == 123.456
    assert check_type_float(123) == 123.0
    assert check_type_float(b"123.456") == 123.456
    assert check_type_float(b"123") == 123.0
    assert check_type_float("123") == 123.0
    assert check_type_float("cannot_convert") == None
    assert check_type_float("cannot_convert") == None
    assert check_type_float("cannot_convert") == None



# Generated at 2022-06-22 22:20:46.676703
# Unit test for function check_required_by
def test_check_required_by():
    SUT = check_required_by(requirements={'key1': ['key2'], 'key2': ['key3']}, parameters={'key1': 0, 'key2': 0})
    assert SUT == {}



# Generated at 2022-06-22 22:20:52.142757
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]

    parameters = {'state': 'present'}
    try:
        check_required_if(requirements, parameters)
    except TypeError as ex:
        message = str(ex)
        assert message == "missing required arguments: path"
    else:
        pytest.fail("TypeError not raised")

    parameters = {'state': 'absent', 'someint': 99}
    try:
        check_required_if(requirements, parameters)
    except TypeError as ex:
        message = str(ex)
        assert message == "someint is 99 but all of the following are missing: bool_param, string_param"

# Generated at 2022-06-22 22:21:04.540238
# Unit test for function check_required_together

# Generated at 2022-06-22 22:21:13.646352
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.formatters import human_to_bytes
    def fail_on_error(result):
        if not result['changed']:
            msg = "failed to report failure: {0}".format(result['msg'])
            raise AssertionError(msg)

    option_spec = dict(
        mutex=dict(type='list', elements='str')
    )

# Generated at 2022-06-22 22:21:16.035098
# Unit test for function check_type_dict
def test_check_type_dict():
    """Check if function check_type_dict() works as expected."""
    assert False


# Generated at 2022-06-22 22:21:21.371834
# Unit test for function check_type_dict
def test_check_type_dict():
    # given
    data = "a=b, b=b"
    # when
    result = check_type_dict(data)
    # then
    assert sorted(result.items()) == sorted([("a","b"), ("b","b")])

# Generated at 2022-06-22 22:21:27.294313
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('foo') == 'foo'
    assert check_type_str(1) == '1'
    assert check_type_str(None) == 'None'

    with pytest.raises(TypeError):
        check_type_str(1, allow_conversion=False)



# Generated at 2022-06-22 22:21:37.923251
# Unit test for function check_required_arguments
def test_check_required_arguments():
    params = {'one': '1', 'two': '2'}
    arg_spec = {
        'one': {'required': True, 'type': 'str'},
        'two': {'required': True, 'type': 'str'},
    }

    assert check_required_arguments(arg_spec, params) == []

    params = {'one': '1', 'three': '3'}
    assert check_required_arguments(arg_spec, params) == ['two']

    arg_spec = {
        'one': {'required': False, 'type': 'str'},
        'two': {'required': True, 'type': 'str'},
    }
    assert check_required_arguments(arg_spec, params) == ['two']

    params = {}
    assert check_required_arguments

# Generated at 2022-06-22 22:21:46.225227
# Unit test for function check_required_together
def test_check_required_together():
    assert ['parameters are required together: a, b', 'parameters are required together: b, c'] ==  check_required_together(
                    terms=[('a', 'b'), ('b', 'c')], parameters={'a': 'a'}, options_context='' 
    )
    assert [] == check_required_together(
                    terms=[('a', 'b'), ('b', 'c')], parameters={'a': 'a', 'b': 'b'}, options_context=''
    )


# Generated at 2022-06-22 22:21:56.201377
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {'param3': '3', 'param4': '4'}
    terms = [['param1', 'param2'], ['param3', 'param4'], ['param5']]
    results = check_required_together(terms, parameters)
    assert results == [['param1', 'param2'], ['param5']], "Test 1: check_required_together fail"
    terms = [['param1', 'param2'], ['param3'], ['param4']]
    results = check_required_together(terms, parameters)
    assert results == [['param1', 'param2'],['param3'], ['param4']], "Test 2: check_required_together fail"
    parameters = {'param1': '1', 'param2': '2'}

# Generated at 2022-06-22 22:22:05.031898
# Unit test for function check_required_arguments
def test_check_required_arguments():
    parameters = {'arg1': 'val1', 'arg2': 'val2'}
    argument_spec = {'arg1': {'required': False}, 'arg2': {'required': True}, 'arg3': {'required': True}}
    # No Exception
    assert [] == check_required_arguments(argument_spec, parameters)
    argument_spec = {'arg1': {'required': True}, 'arg2': {'required': True}}
    # Exception
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert str(e) == "missing required arguments: arg1"
    # Exception