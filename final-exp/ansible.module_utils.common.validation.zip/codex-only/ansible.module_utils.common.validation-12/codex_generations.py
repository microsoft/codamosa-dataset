

# Generated at 2022-06-22 22:12:01.944080
# Unit test for function check_type_bits
def test_check_type_bits():
    assert_equal(check_type_bits('1Kb'), 1024)



# Generated at 2022-06-22 22:12:11.822163
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """unit test for function check_mutually_exclusive"""
    # Simple test case
    terms = ["foo", "bar"]
    parameters = {"foo": 1, "bar": 2}
    results = check_mutually_exclusive(terms, parameters)
    assert results == []

    # Test case where mutually exclusive
    results = check_mutually_exclusive(terms, parameters)
    assert results == [], 'check_mutually_exclusive returned {}'.format(results)

    # Test case where mutually exclusive, but with options_context argument
    terms = ["foo", "bar"]
    parameters = {"foo": 1, "bar": 2}
    options_context = ["object", "properties"]
    results = check_mutually_exclusive(terms, parameters, options_context)
    assert results == [["foo", "bar"]]

    # Test case where not mutually

# Generated at 2022-06-22 22:12:20.014201
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True) == True
    assert check_type_bool(False) == False
    assert check_type_bool('yes') == True
    assert check_type_bool('true') == True
    assert check_type_bool('on') == True
    assert check_type_bool(1) == True
    assert check_type_bool('no') == False
    assert check_type_bool('false') == False
    assert check_type_bool('off') == False
    assert check_type_bool(0) == False
    assert check_type_bool('nope') == False
    assert check_type_bool('n') == False
    assert check_type_bool('f') == False
    assert check_type_bool('0') == False
    assert check_type_bool('1') == True
    assert check

# Generated at 2022-06-22 22:12:27.556279
# Unit test for function count_terms
def test_count_terms():
    given_terms = ['foo', 'bar']
    given_parameters = {'foo': 'boo', 'baz': 'quux'}

    result = count_terms(given_terms, given_parameters)
    assert result == 1

    given_terms = ['foo', 'bar']
    given_parameters = {'foo': 'boo', 'bar': 'quux'}
    result = count_terms(given_terms, given_parameters)
    assert result == 2



# Generated at 2022-06-22 22:12:34.463343
# Unit test for function check_type_bytes
def test_check_type_bytes():
    '''
    Test case to check the conversion of human readable string to bytes.
    '''
    set_unit_test = True
    ansible = AnsibleModule(argument_spec={})
    if set_unit_test:
        try:
            test_input = '2k'
            expected_output = 2048
            assert check_type_bytes(test_input) == expected_output
        except AssertionError:
            raise AssertionError('check_type_bytes failed to convert string to bytes')
    else:
        ansible.exit_json(changed=False)


# Generated at 2022-06-22 22:12:35.942128
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('$HOME') == check_type_str('$HOME')
    assert check_type_path('~/some_path') == check_type_str('~/some_path')


# Generated at 2022-06-22 22:12:45.650274
# Unit test for function check_required_if
def test_check_required_if():
    parameters = {'someint': 99, 'bool_param': True}
    requirements = [['someint', 99, ('bool_param', 'string_param')]]
    results = check_required_if(requirements, parameters)
    missing = results[0]
    assert missing['parameter'] == 'someint'
    assert missing['value'] == 99
    assert missing['requirements'] == ('bool_param', 'string_param')
    assert missing['missing'] == ['string_param']
    assert missing['requires'] == 'all'

    parameters = {'someint': 99, 'bool_param': True}
    requirements = [['someint', 99, ('bool_param', 'string_param'), True]]
    results = check_required_if(requirements, parameters)
    missing = results[0]

# Generated at 2022-06-22 22:12:52.808151
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('state', {'state': 'present', 'name': 'foo'}) == 1
    assert count_terms(('state', 'name'), {'state': 'present', 'name': 'foo'}) == 2
    assert count_terms(('state', 'name'), {'state': 'present', 'names': 'foo'}) == 1
    assert count_terms(('state', 'name'), {'states': 'present', 'names': 'foo'}) == 0



# Generated at 2022-06-22 22:12:57.984620
# Unit test for function check_type_path
def test_check_type_path():
    module = AnsibleModule(dict())
    os.environ['HOME'] = '/fake/home/'
    test_paths = [
        ('/fake/home/.fake', '/fake/home/.fake'),
        ('/fake/home/fake', '/fake/home/fake')
    ]
    for test in test_paths:
        res = check_type_path(test[0])
        assert res == test[1]

# Generated at 2022-06-22 22:13:02.354670
# Unit test for function check_required_together
def test_check_required_together():
    """check_required_together(terms, parameters, options_context=None):
    """
    results = []
    test_params = {'key1':'value1', 'key2':'value2'}
    test_required_values = [['key1','key3'],['key1','key2']]
    results = check_required_together(test_required_values,test_params)
    assert results == []
    test_required_values = [['key1','key2','key3']]
    try:
        results = check_required_together(test_required_values,test_params)
    except TypeError as e:
        results = str(e)
    assert results == "parameters are required together: key1, key2, key3"

# Generated at 2022-06-22 22:13:05.135414
# Unit test for function check_required_together
def test_check_required_together():
    terms = [('a', 'b'), ('a', 'c')]
    parameters = {'a': 1}
    msg = "parameters are required together: %s" % ', '.join(terms)
    assert check_required_together(terms, parameters) == []



# Generated at 2022-06-22 22:13:15.577253
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{}') == '{}'
    assert check_type_jsonarg('[]') == '[]'
    assert check_type_jsonarg('"{}"') == '"{}"'
    assert check_type_jsonarg('"[]"') == '"[]"'
    assert check_type_jsonarg([]) == '[]'
    assert check_type_jsonarg({}) == '{}'
    assert check_type_jsonarg('{ "foo": "bar" }') == '{ "foo": "bar" }'
    assert check_type_jsonarg(['foo', 'bar']) == '["foo", "bar"]'
    assert check_type_jsonarg({'foo': 'bar'}) == '{"foo": "bar"}'

# Generated at 2022-06-22 22:13:24.483453
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')]
    ]
    parameters = {'someint': 99, 'bool_param': True}
    assert len(check_required_if(requirements, parameters)) == 1
    assert check_required_if(requirements, parameters)[0]['missing'] == ['string_param']
    assert check_required_if(requirements, parameters)[0]['parameter'] == 'someint'
    assert check_required_if(requirements, parameters)[0]['value'] == 99
    assert check_required_if(requirements, parameters)[0]['requirements'] == ('bool_param', 'string_param')

# Generated at 2022-06-22 22:13:33.669094
# Unit test for function check_type_float
def test_check_type_float():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils import types
    import six
    # check_type_float can convert a float and int
    # type to a float
    float_type = check_type_float(1.1)
    ansible_assert(float_type == 1.1, \
        "float_type is not a float")
    int_type = check_type_float(1)
    ansible_assert(int_type == 1.0, \
        "int_type is not a float")
    # check_type_float can convert a string
    # type to a float
    float_str_type = check_type_float('1.1')

# Generated at 2022-06-22 22:13:38.324338
# Unit test for function check_required_one_of
def test_check_required_one_of():
    parameters = dict(test1=True, test2=False)
    terms = [['test1', 'test2']]
    check_required_one_of(terms, parameters)
    parameters = dict()
    terms = [['test1', 'test2']]
    try:
        check_required_one_of(terms, parameters)
    except Exception:
        pass



# Generated at 2022-06-22 22:13:48.158281
# Unit test for function check_type_path
def test_check_type_path():
    from ansible.module_utils.six.moves import builtins

# Generated at 2022-06-22 22:13:55.362210
# Unit test for function check_type_list
def test_check_type_list():
    try:
        assert check_type_list(["a", "b", "c"]) == ["a", "b", "c"]
        assert check_type_list(["a,b,c"]) == ["a,b,c"]
        assert check_type_list("a,b,c")  == ["a","b","c"]
        assert check_type_list(1)  == ["1"]
    except AssertionError as e:
        raise AssertionError(str(e))


# Generated at 2022-06-22 22:13:59.693107
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    params = {'foo': 1, 'bar': 2}
    required_params = ('foo',)
    
    try:
        check_missing_parameters(params, required_params)
        assert False, "Exception must be raised"
    except TypeError as e:
        assert str(e) == "missing required arguments: bar"
    else:
        assert False, "Exception must be raised"


# Generated at 2022-06-22 22:14:11.686327
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True)
    assert check_type_bool(False)
    assert check_type_bool('1')
    assert check_type_bool('true')
    assert check_type_bool('t')
    assert check_type_bool('y')
    assert check_type_bool('yes')
    assert check_type_bool(1)
    assert check_type_bool(0)
    assert check_type_bool('on')
    assert check_type_bool('off')
    assert check_type_bool('0')
    assert check_type_bool('n')
    assert check_type_bool('f')
    assert check_type_bool('false')
    assert not check_type_bool('2')
    assert not check_type_bool('10')

# Generated at 2022-06-22 22:14:22.154919
# Unit test for function check_type_list
def test_check_type_list():
    assert(check_type_list(['a']) == ['a'])
    assert(check_type_list(['a,b']) == ['a','b'])
    assert(check_type_list('a,b') == ['a','b'])
    assert(check_type_list(1) == ['1'])
    assert(check_type_list(1.5) == ['1.5'])
    try:
        check_type_list(1.5+1.5j)
        assert("function check_type_list that handles complex number should not return")
    except TypeError:
        pass
    try:
        check_type_list({'a':'b'})
        assert("function check_type_list that handles dictionary should not return")
    except TypeError:
        pass

# Generated at 2022-06-22 22:14:30.220666
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([], {}) == []
    assert check_required_one_of([('test1', 'test2'), ('test3', 'test4')],
                                 dict(test1='test1', test4='test4')) == []
    try:
        check_required_one_of([('test1', 'test2'), ('test3', 'test4')], {})
        assert False, "should have failed"
    except TypeError as e:
        assert "one of the following is required: test1, test2 found in" in to_native(e)

# Generated at 2022-06-22 22:14:36.182008
# Unit test for function check_type_int
def test_check_type_int():
    try:
        check_type_int(4)
        check_type_int("-4")
    except:
        raise AssertionError("check_type_int should not raise error")
    try:
        check_type_int("4.4")
        raise AssertionError("check_type_int should raise error")
    except:
        pass


# Generated at 2022-06-22 22:14:42.207876
# Unit test for function check_type_bool
def test_check_type_bool():
  assert check_type_bool(1) == True
  assert check_type_bool("1") == True
  assert check_type_bool("on") == True
  assert check_type_bool(0) == False
  assert check_type_bool("0") == False
  assert check_type_bool("off") == False
  #assert check_type_bool("aa") == False
  assert check_type_bool("aa") == True
  assert check_type_bool(1.1) == False
  assert check_type_bool(True) == True
  assert check_type_bool(False) == False


# Generated at 2022-06-22 22:14:45.690773
# Unit test for function check_type_bool
def test_check_type_bool():
    assert(True == check_type_bool(True))
    assert(True == check_type_bool('True'))
    assert(False == check_type_bool(False))
    assert(False == check_type_bool('False'))
    assert(False == check_type_bool(0))
    try:
        check_type_bool(['a'])
        assert(False)
    except TypeError:
        assert(True)


# Generated at 2022-06-22 22:14:46.575374
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-22 22:14:52.397367
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    import json
    test_string = '{"foo": "bar"}'
    test_string = check_type_jsonarg(test_string)
    assert isinstance(json.loads(test_string), dict)
    test_dict = {"foo": "bar"}
    test_dict = check_type_jsonarg(test_dict)
    assert isinstance(json.loads(test_dict), dict)



# Generated at 2022-06-22 22:15:02.932553
# Unit test for function check_required_if
def test_check_required_if():
    assert check_required_if([['state', 'present', ('path',), True]]) == []
    assert check_required_if([['someint', 99, ('bool_param', 'string_param')]]) == []
    assert check_required_if([['state', 'present', ('path',), True]], {u'state': u'present', u'path': u'/tmp'}) == []
    assert check_required_if([['someint', 99, ('bool_param', 'string_param')]], {u'someint': 99, u'bool_param': u'true', u'string_param': u'abc'}) == []

# Generated at 2022-06-22 22:15:07.589411
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('"hello"') == 'hello'
    # do not allow method calls to modules
    assert safe_eval('str.replace("", "")') == 'str.replace("", "")'
    # do not allow imports
    assert safe_eval('import os') == 'import os'



# Generated at 2022-06-22 22:15:13.042257
# Unit test for function count_terms
def test_count_terms():
    # Setup
    terms = ['count_terms', 'count_terms2']
    parameters = {'count_terms': 'count_terms', 'count_terms2': 'count_terms2', 'count_terms3': 'count_terms3'}

    # Test
    result = count_terms(terms, parameters)

    # Assert
    assert result == 2, "Should have returned 2"


# Generated at 2022-06-22 22:15:16.614259
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg(['a']) == '["a"]'
# End unit test for function check_type_jsonarg



# Generated at 2022-06-22 22:15:18.106537
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-22 22:15:27.434686
# Unit test for function check_required_one_of
def test_check_required_one_of():
    try:
        check_required_one_of([['a', 'b']], {})
    except TypeError as e:
        assert "one of the following is required: a, b" in str(e)
    assert check_required_one_of([['a', 'b']], {'a': 'foo'}) is None
    assert check_required_one_of([['a', 'b']], {'a': 'foo', 'b': 'bar'}) is None
    assert check_required_one_of([['a', 'b']], {'b': 'foo'}) is None
    assert check_required_one_of([(('a', 'b'), ('c', 'd'))], {'e': 'foo'}) is None

# Generated at 2022-06-22 22:15:38.463332
# Unit test for function check_type_raw
def test_check_type_raw():
    check_type_raw_value = check_type_raw('value')
    return check_type_raw_value


SPEC_TYPE_BOOL = 'bool'
SPEC_TYPE_BOOL_OR_STR = 'bool_or_str'
SPEC_TYPE_BYTES = 'bytes'
SPEC_TYPE_DICT = 'dict'
SPEC_TYPE_FLOAT = 'float'
SPEC_TYPE_INT = 'int'
SPEC_TYPE_LIST = 'list'
SPEC_TYPE_PATH = 'path'
SPEC_TYPE_RAW = 'raw'
SPEC_TYPE_STR = 'str'
SPEC_TYPE_STR_OR_LIST = 'str_or_list'
SPEC_TYPE_STR_OR_LIST_OR_DICT = 'str_or_list_or_dict'
SPEC_TYPE_LIST_OR_BOOL

# Generated at 2022-06-22 22:15:49.082783
# Unit test for function check_type_dict
def test_check_type_dict():
    # Test with built-in types.
    assert check_type_dict({'a': 1}) == {'a': 1}
    assert check_type_dict(['a', 'b']) == {'a': 'b'}
    assert check_type_dict(['a', 'b', 'c']) == {'a': 'b', 'c': ''}
    assert check_type_dict('a=b, c=') == {'a': 'b', 'c': ''}
    assert check_type_dict('a=b, "c"=d') == {'a': 'b', 'c': 'd'}
    assert check_type_dict('a=b, "c"="d"') == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-22 22:15:59.975385
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('"1"') == '1'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"k1": "v1", "k2": "v2"}') == {'k1': 'v1', 'k2': 'v2'}
    assert safe_eval('{"k1": "v1", "k2": "v2", "k3": {"k4": "v4"}}') == {'k1': 'v1', 'k2': 'v2', 'k3': {'k4': 'v4'}}

# Generated at 2022-06-22 22:16:11.142974
# Unit test for function check_required_arguments
def test_check_required_arguments():
    try:
        check_required_arguments(dict(a=dict(required=True), b=dict(required=True)), dict())
        assert False, "did not raise TypeError"
    except TypeError:
        pass

    try:
        check_required_arguments(dict(a=dict(required=True), b=dict(required=True)), dict(a=1))
        assert False, "did not raise TypeError"
    except TypeError:
        pass

    assert check_required_arguments(dict(a=dict(required=True), b=dict(required=True)), dict(a=1, b=2)) == []
    assert check_required_arguments(dict(a=dict(required=False)), dict()) == []

# Generated at 2022-06-22 22:16:21.233687
# Unit test for function check_required_together
def test_check_required_together():
    params = dict(
        one=1,
        two=2,
        three=3,
        four=4,
        five=5,
    )
    # should not raise error
    check_required_together([("one", "two"), ("four", "five")], params)
    # should raise error
    try:
        check_required_together([("one", "two"), ("three", "four")], params)
    except TypeError as e:
        assert "parameters are required together: one, two" in str(e)
    else:
        assert False, "check_required_together should raise error"


# Generated at 2022-06-22 22:16:24.038093
# Unit test for function check_required_together
def test_check_required_together():
    tests = []
    # run tests
    results = []
    #use a list of tuples instead to make the output more readable
    check_required_together(tests, results)
    assert results == []


# Generated at 2022-06-22 22:16:28.673144
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list([]) == []
    assert check_type_list(['a']) == ['a']
    assert check_type_list('a') == ['a']
    assert check_type_list('a,b') == ['a', 'b']
    assert check_type_list(1) == ['1']



# Generated at 2022-06-22 22:16:40.446556
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('abc') == 'abc'
    assert check_type_str(u'abc') == "abc"
    assert check_type_str(1) == "1"
    assert check_type_str(['a', 'b', 'c']) == "['a', 'b', 'c']"
    assert check_type_str(('a', 'b', 'c')) == "('a', 'b', 'c')"
    assert check_type_str({'a': 'b'}) == "{'a': 'b'}"
    assert check_type_str(set(['a', 'b'])) == "set(['a', 'b'])"
    assert check_type_str(set(['a', 'b']), allow_conversion=False)

# Generated at 2022-06-22 22:16:44.834082
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(10) == 10
    assert check_type_int('10') == 10
    assert check_type_int('10') == 10
    assert check_type_int('10.0') == 10
    assert check_type_int(10.0) == 10
    assert check_type_int(10.5) == 10
    assert check_type_int('10.5') == 10

# Generated at 2022-06-22 22:16:50.994265
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('/tmp') == '/tmp'
    assert check_type_path('~/yum.conf') == '/etc/yum.conf'
    assert check_type_path('$HOME/yum.conf') == '/etc/yum.conf'
    assert check_type_path(None) == None
    assert check_type_path(True) == 'True'
    try:
        check_type_path(123)
        assert False
    except TypeError:
        pass


# Generated at 2022-06-22 22:17:01.706409
# Unit test for function safe_eval
def test_safe_eval():
    value = 'True'
    assert safe_eval(value)

    value = 'False'
    assert not safe_eval(value)

    value = '1'
    assert isinstance(safe_eval(value), integer_types)

    value = '"1"'
    assert isinstance(safe_eval(value), string_types)

    value = '1.1'
    assert isinstance(safe_eval(value), float)

    value = '[1, 2, 3]'
    assert isinstance(safe_eval(value), list)

    value = '{"a": "b"}'
    assert isinstance(safe_eval(value), dict)

    value = '{"a": [1, 2, 3], "b": [4, 5, 6]}'
    assert isinstance(safe_eval(value), dict)


# Generated at 2022-06-22 22:17:14.196656
# Unit test for function check_required_arguments
def test_check_required_arguments():
    spec = {
        'test': {
            'required': True,
            'type': 'str'
        },
        'test2': {
            'required': True,
            'type': 'str'
        },
        'test3': {
            'required': True,
            'type': 'str'
        }
    }

    parameters = {}
    assert check_required_arguments(spec, parameters) == ['test', 'test2', 'test3']

    parameters = {'test': 'test_value'}
    assert check_required_arguments(spec, parameters) == ['test2', 'test3']

    parameters = {'test': 'test_value', 'test2': 'test2_value'}
    assert check_required_arguments(spec, parameters) == ['test3']


# Generated at 2022-06-22 22:17:19.990357
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    missing_params = []
    parameters = dict(param1='param1', param2='param2')
    required_parameters = ['param1', 'param2']
    assert check_missing_parameters(parameters, required_parameters) == missing_params
    parameters = dict(param1='param1')
    required_parameters = ['param1', 'param2']
    try:
        check_missing_parameters(parameters, required_parameters)
    except TypeError as e:
        missing_params = ['param2']
        assert 'missing required arguments: %s' % ', '.join(missing_params) == to_native(e)

    # Raise TypeError when required_parameters is None
    required_parameters = None

# Generated at 2022-06-22 22:17:31.030225
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # Testing check_missing_parameters with missing params
    parameters = dict(
        foo='bar',
        baz=None,
    )
    required_parameters = [
        'foo',
        'bar',
        'baz',
    ]
    with pytest.raises(TypeError):
        check_missing_parameters(parameters, required_parameters)
    # Testing check_missing_parameters without missing params
    parameters = dict(
        foo='bar',
        baz='buzz',
    )
    required_parameters = [
        'foo',
        'bar',
        'baz',
    ]

    assert check_missing_parameters(parameters, required_parameters) == []



# Generated at 2022-06-22 22:17:35.281448
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'power': 'on'}
    required_parameters = ['power', 'network']
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params[0] == 'network'



# Generated at 2022-06-22 22:17:38.142716
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(True)
    assert check_type_raw(False)
    assert check_type_raw(list())
    assert check_type_raw(dict())
    assert check_type_raw(int(1))
# END Unit tests for function check_type_raw



# Generated at 2022-06-22 22:17:42.586005
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    required_parameters = ['req1', 'req2', 'req3']
    parameters = {'req2': 1}
    if check_missing_parameters(parameters, required_parameters):
        print("Failed to raise exception for missing parameters")
        return False
    parameters = {'req1': 1, 'req2': 1, 'req3': 1}
    if check_missing_parameters(parameters, required_parameters):
        print("Raised exception for no missing parameters")
        return False
    return True



# Generated at 2022-06-22 22:17:51.199633
# Unit test for function check_required_by
def test_check_required_by():
    # Test Single
    requirements = {'required_by': 'single_parameter'}
    # Test List
    requirements = {'required_by': ['single_parameter','single_parameter']}

    # Fail
    parameters = dict(required_by=None)
    result = check_required_by(requirements, parameters)
    assert result == {'required_by': ['single_parameter']}

    # Fail
    parameters = dict(required_by='parameter_with_a_value')
    result = check_required_by(requirements, parameters)
    assert result == {'required_by': ['single_parameter']}

    # Pass
    parameters = dict(required_by='parameter_with_a_value', single_parameter='parameter_with_a_value')
    result = check_required_by

# Generated at 2022-06-22 22:17:59.209975
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('a') == '"a"'
    assert check_type_jsonarg('a,b') == '"a,b"'
    assert check_type_jsonarg(['a', 'b']) == '["a", "b"]'
    assert check_type_jsonarg({'a': 1, 'b':2}) == '{"a": 1, "b": 2}'
test_check_type_jsonarg()



# Generated at 2022-06-22 22:18:08.638545
# Unit test for function check_required_if

# Generated at 2022-06-22 22:18:15.531455
# Unit test for function check_type_raw
def test_check_type_raw():
    """Unit test check_type_raw"""
    check_type_raw(123)

# Generated at 2022-06-22 22:18:20.168232
# Unit test for function check_type_bool
def test_check_type_bool():
    for i in ('1', 'on', 1, '0', 0, 'n', 'f', 'false', 'true', 'y', 't', 'yes', 'no', 'off'):
        assert check_type_bool(i) == boolean(i)


# Generated at 2022-06-22 22:18:29.345716
# Unit test for function check_required_one_of
def test_check_required_one_of():
    result = check_required_one_of([['name', 'display_name', 'id'], ['role'], ['type']], {'name': 'foo', 'type': 'type_value'})
    assert(not result)
    try:
        check_required_one_of([['name', 'display_name', 'id'], ['role'], ['type']], {})
        assert(False)
    except:
        pass
    try:
        check_required_one_of([['name', 'display_name', 'id'], ['role'], ['type']], {'role': 'r', 'type': 'type_value'})
        assert(False)
    except:
        pass

# Generated at 2022-06-22 22:18:41.385821
# Unit test for function check_required_one_of
def test_check_required_one_of():
    from ansible.module_utils.common.validation import check_required_one_of
    terms = [(['ip_address', 'hostname'])]
    parameters = {'hostname': 'localhost'}
    result = check_required_one_of(terms, parameters)
    assert result == [], "Result {0} is empty".format(result)
    terms = [(['ip_address', 'hostname'])]
    parameters = {'hostname': 'localhost', 'ip_address': '10.0.0.1'}
    result = check_required_one_of(terms, parameters)
    assert result == [], "Result {0} is empty".format(result)
    terms = [(['ip_address', 'hostname'])]
    parameters = {'ip_address': '10.0.0.1'}

# Generated at 2022-06-22 22:18:52.839425
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Make sure we can convert a number ending with 'b'.
    v = check_type_bytes('1b')
    assert(v == 1)
    # Negative value will be rounded down to 0.
    v = check_type_bytes('-1b')
    assert(v == 0)
    # Make sure we can convert a number ending with 'B'.
    v = check_type_bytes('1B')
    assert(v == 1)
    # Make sure we can convert a number ending with 'k'.
    v = check_type_bytes('5k')
    assert(v == 5120)
    # Make sure we can convert a number ending with 'm'.
    v = check_type_bytes('1M')
    assert(v == 1048576)
    # Make sure we can convert a number ending with 'g'.

# Generated at 2022-06-22 22:19:00.758850
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1B') == 1
    assert check_type_bytes('1KB') == 1024
    assert check_type_bytes('1MB') == 1048576
    assert check_type_bytes('1GB') == 1073741824
    assert check_type_bytes('1TB') == 1099511627776
    assert check_type_bytes('1PB') == 1125899906842624
    assert check_type_bytes('1EB') == 1152921504606846976
    assert check_type_bytes('1ZB') == 1180591620717411303424
    assert check_type_bytes('1YB') == 1208925819614629174706176
    assert check_type_bytes('1.0B') == 1
    assert check_type_bytes('1.0KB') == 1024


# Generated at 2022-06-22 22:19:11.285907
# Unit test for function check_type_bits
def test_check_type_bits():
    # Test for valid values
    value = check_type_bits('1kb')
    assert value == 1024
    value = check_type_bits('1kB')
    assert value == 1024
    value = check_type_bits('1Kb')
    assert value == 1024
    value = check_type_bits('1KB')
    assert value == 1024
    value = check_type_bits('5Mb')
    assert value == 5242880
    value = check_type_bits('5MB')
    assert value == 5242880
    value = check_type_bits('1Gb')
    assert value == 1073741824
    value = check_type_bits('1GB')
    assert value == 1073741824
    value = check_type_bits('1Tb')
    assert value == 1099511627776
    value

# Generated at 2022-06-22 22:19:17.298292
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('2Gb') == 2147483648
    assert check_type_bits('3tb') == 3221225472
    assert check_type_bits('4pB') == 536870912



# Generated at 2022-06-22 22:19:20.367266
# Unit test for function count_terms
def test_count_terms():
    parameters = {'test': 'test', 'test1': 'test1', 'test2': 'test2'}
    terms = ['test', 'test1', 'test2', 'test3']
    assert count_terms(terms, parameters) == 3



# Generated at 2022-06-22 22:19:31.148402
# Unit test for function check_required_one_of
def test_check_required_one_of():

    parameters = {'param_a' : True, 'param_b' : True, 'param_c' : True, 'param_d' : True}

    terms = [['param_a', 'param_b'], ['param_c', 'param_d']]
    assert(check_required_one_of(terms, parameters) == [])

    parameters = {'param_a' : True, 'param_b' : True, 'param_c' : False, 'param_d' : False}
    terms = [['param_a', 'param_b'], ['param_c', 'param_d']]
    assert(check_required_one_of(terms, parameters) == [])


# Generated at 2022-06-22 22:19:41.183752
# Unit test for function check_type_bytes
def test_check_type_bytes():
    """Test function check_type_bytes"""
    # Test function with data which can be converted
    assert check_type_bytes(0) == 0
    assert check_type_bytes('1B') == 1
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1kB') == 1024
    assert check_type_bytes('1KB') == 1024
    assert check_type_bytes('1MB') == 1048576
    assert check_type_bytes('1GB') == 1073741824
    assert check_type_bytes('1TB') == 1099511627776
    assert check_type_bytes('1PB') == 1125899906842624
    assert check_type_bytes('1EB') == 1152921504606846976
    assert check_type_bytes('1ZB') == 118059

# Generated at 2022-06-22 22:19:48.740439
# Unit test for function check_type_bytes
def test_check_type_bytes():
    tests = [
        (80, 80),
        ('80', 80),
        ('80B', 80),
        ('1KB', 1024),
        ('1M', 1048576),
        ('1Mb', 1048576),
        ('1.3M', 1376256),
        ('1.8MB', 1835008),
        ('10G', 10737418240),
        ('10Gb', 10737418240),
        ('12.4G', 13258995712),
    ]
    for test in tests:
        assert check_type_bytes(test[0]) == test[1]



# Generated at 2022-06-22 22:19:56.626812
# Unit test for function check_type_list
def test_check_type_list():
    print(check_type_list(['item1', 'item2']))
    print(check_type_list('item1,item2'))
    print(check_type_list(1))
    print(check_type_list(1.0))
    print(check_type_list('1'))
    print(check_type_list('1.0'))
    #print(check_type_list(['item1', 1]))


# Generated at 2022-06-22 22:20:09.553668
# Unit test for function check_required_by
def test_check_required_by():
    result = check_required_by(requirements={}, parameters={})
    assert not result, \
        "Lists of requirements and parameters are both empty. Result should be an empty dict."

    result = check_required_by(requirements={"a": "b"}, parameters={"a": True, "b": False})
    assert not result, \
        "Parameters are the same as requirements. Result should be an empty dict."

    result = check_required_by(requirements={"a": ["b", "c"]}, parameters={"a": True, "b": False})
    assert not result, \
        "List in requirements. Result should be an empty dict."

    with pytest.raises(TypeError):
        check_required_by(requirements={"a": "b"}, parameters={"a": True})

# Generated at 2022-06-22 22:20:19.085185
# Unit test for function check_type_str
def test_check_type_str():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    module = AnsibleModule(argument_spec=dict(
        normal=dict(type='str'),
        converted=dict(type='str', allow_conversion=True),
        error_raised=dict(type='str', allow_conversion=False),
        int=dict(type='int'),
    ))

# Generated at 2022-06-22 22:20:28.662318
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('1') is True
    assert check_type_bool('on') is True
    assert check_type_bool('True') is True
    assert check_type_bool('yes') is True
    assert check_type_bool('y') is True
    assert check_type_bool('t') is True
    assert check_type_bool('0') is False
    assert check_type_bool('n') is False
    assert check_type_bool('f') is False
    assert check_type_bool('False') is False
    assert check_type_bool('false') is False
    assert check_type_bool('no') is False
    assert check_type_bool('off') is False
    assert check_type_bool('1.0') is True
    assert check_type_bool(1) is True

# Generated at 2022-06-22 22:20:38.540647
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters_1 = {'param1': 'a', 'param2': 'b'}
    required_parameters_1 = ['param1', 'param2']
    assert check_missing_parameters(parameters_1, required_parameters_1) == []
    parameters_2 = {'param1': 'a', 'param2': 'b'}
    required_parameters_2 = ['param1']
    assert check_missing_parameters(parameters_2, required_parameters_2) == []
    parameters_3 = {'param1': 'a'}
    required_parameters_3 = ['param2']
    assert check_missing_parameters(parameters_3, required_parameters_3) == ['param2']


# Generated at 2022-06-22 22:20:45.953183
# Unit test for function check_required_if
def test_check_required_if():
    from ansible.module_utils.common.text.formatters import to_text
    params = dict(
        state='present',
        path='/www/index.html'
    )
    # If state=present, then path is required.
    # Missing 'path' in params.
    requirements = [
        ['state', 'present', ('path',)],
    ]
    try:
        check_required_if(requirements, params)
    except TypeError as e:
        assert to_text(e) == "missing required arguments: path"
    else:
        assert False, "Exception was not raised"

    # If state=present, then path is required.
    # Params contains path
    params = dict(
        state='present',
        path='/www/index.html'
    )

# Generated at 2022-06-22 22:20:51.703831
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('2 + 3') == 5
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval('[ 1 + 1, 2 + 2, 3 + 3]') == [2, 4, 6]
    assert safe_eval('1 == 1') is True
    assert safe_eval('2 != 1') is True
    assert safe_eval('1 + 1 == 2') is True
    assert safe_eval('(1 + 1) * 2 == 4') is True
    assert safe_eval('(1 + 1) * 2 == 2')

# Generated at 2022-06-22 22:21:00.346796
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('a') == ['a'], 'a is already a list'
    assert check_type_list('a,b') == ['a','b'], 'a,b is already a list'
    assert check_type_list(1) == ['1'], '1 is already a list'
    assert check_type_list(1.1) == ['1.1'], '1 is already a list'



# Generated at 2022-06-22 22:21:10.004673
# Unit test for function check_type_bool
def test_check_type_bool():
    print("Running unit test for function check_type_bool")
    assert check_type_bool(True) == True, "check_type_bool failed for bool True"
    assert check_type_bool(False) == False, "check_type_bool failed for bool False"
    assert check_type_bool('1') == True, "check_type_bool failed for string '1'"
    assert check_type_bool('on') == True, "check_type_bool failed for string 'on'"
    assert check_type_bool(1) == True, "check_type_bool failed for int 1"
    assert check_type_bool('0') == False, "check_type_bool failed for string '0'"
    assert check_type_bool(0) == False, "check_type_bool failed for int 0"
    assert check_type_

# Generated at 2022-06-22 22:21:13.872879
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('a', {'a': '1', 'b': '2'}) == 1
    assert count_terms(['a', 'b'], {'a': '1', 'b': '2'}) == 2
    assert count_terms('a', {'c': '1', 'b': '2'}) == 0



# Generated at 2022-06-22 22:21:15.564415
# Unit test for function check_type_raw
def test_check_type_raw():
    """Test function check_type_raw"""
    value = "bogus"
    result = check_type_raw(value)
    assert result == value


# Generated at 2022-06-22 22:21:22.903099
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(['foo'], dict(foo=1)) == 1
    assert count_terms(['foo'], dict(bar=1)) == 0
    assert count_terms(['foo', 'bar'], dict(foo=1, bar=1)) == 2
    assert count_terms(['foo', 'bar'], dict(bar=1)) == 1
    assert count_terms(('foo', 'bar'), dict(bar=1)) == 1



# Generated at 2022-06-22 22:21:28.973084
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('10B') == 10
    assert check_type_bytes('10K') == 10 * 1024
    assert check_type_bytes('10M') == 10 * 1024 * 1024
    assert check_type_bytes('10G') == 10 * 1024 * 1024 * 1024
    try:
        check_type_bytes('10P')
        assert False
    except TypeError:
        pass
    try:
        check_type_bytes('10')
        assert False
    except TypeError:
        pass



# Generated at 2022-06-22 22:21:39.174962
# Unit test for function safe_eval
def test_safe_eval():
    retval = safe_eval('1+1')
    assert retval == 2
    assert isinstance(retval, integer_types)

    retval = safe_eval('"foo"')
    assert retval == 'foo'
    assert isinstance(retval, string_types)

    retval = safe_eval('[1,2,3]')
    assert retval == [1, 2, 3]
    assert isinstance(retval, list)

    retval = safe_eval('True')
    assert retval is True
    assert isinstance(retval, bool)

    retval = safe_eval(u"u'foo'")
    assert retval == u'foo'
    assert isinstance(retval, text_type)

    retval = safe_eval(u"[u'foo', u'bar']")

# Generated at 2022-06-22 22:21:48.826798
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('foo', {'foo': 'bar'}) == 1
    assert count_terms(['foo'], {'foo': 'bar'}) == 1
    assert count_terms(['foo'], {'bar': 'foo'}) == 0
    assert count_terms(['foo', 'bar'], {'foo': 'bar'}) == 1
    assert count_terms(['foo', 'bar'], {'foo': 'bar', 'bar': 'foo'}) == 2
    assert count_terms(['foo', 'bar'], {'foo': 'bar', 'bar': 'foo', 'baz': 'foo'}) == 2



# Generated at 2022-06-22 22:22:00.850072
# Unit test for function check_type_dict
def test_check_type_dict():
    # Create a test dict and then convert to json, check the dict from json
    # and check that dict from json is the same as the original dict
    test_dict = { "key1" : "value1", "key2" : "value2" }
    json_dict = json.dumps(test_dict)
    dict_from_json = check_type_dict(json_dict)
    assert test_dict == dict_from_json
    # Test that a dict can be passed as is, and get it back again
    dict_from_dict = check_type_dict(test_dict)
    assert test_dict == dict_from_dict
    # Test that a string in kev=value format can be passed and get a dict back again
    str_test = "key1=val1,key2=val2"
    dict_from_