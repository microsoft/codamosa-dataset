

# Generated at 2022-06-22 22:12:08.554409
# Unit test for function check_required_together
def test_check_required_together():
    terms = [
        ['a'],
        ['b', 'c']
    ]
    parameters = {
        'a': 'something',
        'c': 'something'
    }
    try:
        check_required_together(terms, parameters)
    except TypeError as e:
        assert to_native(e) == 'parameters are required together: b, c'
    else:
        pytest.fail("expected exception")



# Generated at 2022-06-22 22:12:19.831678
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('a=1, b=2') == {'a': '1', 'b': '2'}
    assert check_type_dict('a=1, b=2, c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert check_type_dict('a') == {'a': None}
    assert check_type_dict('a=b=c') == {'a': 'b=c'}
    assert check_type_dict("a='b=c'") == {'a': 'b=c'}
    assert check_type_dict("a=\"b=c\"") == {'a': 'b=c'}

# Generated at 2022-06-22 22:12:30.400721
# Unit test for function count_terms
def test_count_terms():
    parameters = {
        'is_not': False,
        'is': True,
        'is_present': True,
        'is_absent': False,
        'is_enabled': True
    }
    assert count_terms(['is_enabled'], parameters) == 1
    assert count_terms(['is_enabled', 'is_present'], parameters) == 2
    assert count_terms(['is_enabled', 'is_present', 'is_absent'], parameters) == 2
    assert count_terms(['is_absent', 'is_enabled', 'is_present'], parameters) == 2
    assert count_terms(['is_absent', 'is_present', 'is_present'], parameters) == 2

# Generated at 2022-06-22 22:12:35.406507
# Unit test for function check_type_float
def test_check_type_float():

    assert isinstance(check_type_float(3.0), float)
    #TODO: Exception cause is None
    with pytest.raises(Exception):
        assert isinstance(check_type_float('3.0a'), float)


# Generated at 2022-06-22 22:12:43.188195
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('[1,2,3]') == '[1,2,3]'
    assert check_type_jsonarg(['[1,2,3]']).strip() == '[1,2,3]'
    assert check_type_jsonarg(json.loads('[1,2,3]')).strip() == '[1,2,3]'
    assert check_type_jsonarg(json.dumps(['[1,2,3]'])).strip() == '[1,2,3]'
    assert check_type_jsonarg(['[1,2,3]']) == '[1,2,3]'



# Generated at 2022-06-22 22:12:50.704153
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('a', locals={}, include_exceptions=False) == 'a'
    assert safe_eval('a', locals={}, include_exceptions=True) == ('a', None)

    assert safe_eval('1', locals={}, include_exceptions=False) == 1
    assert safe_eval('1', locals={}, include_exceptions=True) == (1, None)

    assert safe_eval('1+1', locals={}, include_exceptions=False) == 1+1
    assert safe_eval('1+1', locals={}, include_exceptions=True) == (1+1, None)

    assert safe_eval("'foo bar baz'", locals={}, include_exceptions=False) == 'foo bar baz'

# Generated at 2022-06-22 22:13:00.399149
# Unit test for function check_required_by
def test_check_required_by():
    params = {'type': 'docker', 'username': 'jsmith', 'password': 'supersecret'}
    try:
        check_required_by({'username': ['password']}, params)
    except TypeError as e:
        assert "parameters are required together: username, password" in str(e)
    else:
        assert False, "Expected TypeError with message."

    try:
        check_required_by({'type': ['password']}, params)
    except TypeError as e:
        assert 'missing parameter(s) required by \'type\': password' in str(e)
    else:
        assert False, "Expected TypeError with message."



# Generated at 2022-06-22 22:13:10.743636
# Unit test for function check_required_arguments
def test_check_required_arguments():
    parameter_spec_dict = {
        'example1': {'required': True},
        'example2': {'required': False},
        'example3': {'required': False},
        'example4': {'required': True},
        'example5': {'required': False},
    }
    parameters_dict = {
        'example1': 1,
        'example2': 2,
        'example5': 5,
    }
    # Verify that the required arguments are missing
    assert check_required_arguments(parameter_spec_dict, parameters_dict) == ['example4']

    # Verify that no argument is missing
    parameters_dict['example4'] = 4
    assert check_required_arguments(parameter_spec_dict, parameters_dict) == []



# Generated at 2022-06-22 22:13:18.572284
# Unit test for function check_required_together
def test_check_required_together():
    test_parameters = {}
    test_spec = {}
    assert check_required_together(test_spec, test_parameters) == []

    test_parameters = {'a': 1}
    test_spec = [('a', 'b')]
    assert check_required_together(test_spec, test_parameters) == []

    test_parameters = {'a': 1}
    test_spec = [('a', 'b', 'c')]
    assert check_required_together(test_spec, test_parameters) == [('a', 'b', 'c')]



# Generated at 2022-06-22 22:13:25.886946
# Unit test for function check_required_by
def test_check_required_by():
    requirements = dict(
        state=['target'],
        target=['source'],
        source=['target'],
    )
    parameters = dict(
        state='present',
        target='/path/to/target',
        source='/path/to/source',
    )

    assert {} == check_required_by(requirements, parameters)

    # Missing target parameter
    parameters = dict(
        state='present',
        source='/path/to/source',
    )
    try:
        check_required_by(requirements, parameters)
    except TypeError as e:
        assert 'missing parameter(s) required by' in to_native(e)
    else:
        raise AssertionError("Expected 'TypeError' exception")



# Generated at 2022-06-22 22:13:30.030403
# Unit test for function check_type_int
def test_check_type_int():
    for value in int_values:
        assert isinstance(check_type_int(value), integer_types)

    for value in non_int_values:
        assert_raises(TypeError, check_type_int, value)

# Generated at 2022-06-22 22:13:39.967690
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert not check_required_one_of(terms=[('a', 'b'), ('c', 'd')], parameters={'a': 1, 'c': 2})
    assert not check_required_one_of(terms=[('a', 'b'), ('c', 'd')], parameters={'a': 1, 'b': 2, 'c': 2, 'd': 2})
    assert not check_required_one_of(terms=[], parameters={'a': 1, 'b': 2, 'c': 2, 'd': 2})
    assert not check_required_one_of(terms=None, parameters={'a': 1, 'b': 2, 'c': 2, 'd': 2})

    from ansible.module_utils import basic


# Generated at 2022-06-22 22:13:46.160238
# Unit test for function check_required_by
def test_check_required_by():
    # Test required for
    res = check_required_by({'test1': 'test2', 'test2': 'test3',
                             'test3': 'test4'}, {'test1': 'test2', 'test3': 'test4'})
    assert len(res) == 0

    res = check_required_by({'test1': 'test2', 'test2': 'test3',
                             'test3': 'test4'}, {})
    assert len(res) == 0
    res = check_required_by({'test1': ['test2', 'test3'], 'test2': 'test3',
                             'test3': 'test4'}, {'test1': 'test2', 'test3': 'test4'})
    assert len(res) == 0

# Generated at 2022-06-22 22:13:57.465215
# Unit test for function check_required_if
def test_check_required_if():
    spec = dict(
        state=dict(default='present', choices=['absent', 'present']),
        name=dict(type='str', required=True),
        path=dict(),
        mode=dict(),
        someint=dict(type='int'),
        somebool=dict(type='bool', default=False),
        somestr=dict(type='str'),
        required_if=[
            ['state', 'present', ('path',), True],
            ['someint', 99, ('somestr',)],
        ],
    )
    parameters = dict(
        state='present',
        name='myitem',
        path='/some/path',
        somestr='hello',
    )
    # Test that it doesn't blow up, should be ok

# Generated at 2022-06-22 22:14:07.094245
# Unit test for function check_type_dict
def test_check_type_dict():
    test_dict = {'no_equal': 'no_equal', 'equal_value': 'equal_value', 'equal_key=equal_value': 'equal_key=equal_value'}
    test_dict_pretty = '{"no_equal":"no_equal","equal_value":"equal_value","equal_key=equal_value":"equal_key=equal_value"}'
    test_dict_string = 'no_equal=no_equal, equal_key=equal_value'
    test_dict_spaced = 'no_equal  = no_equal , equal_key =equal_value'
    all_test_dict = [test_dict, test_dict_pretty, test_dict_string, test_dict_spaced]

# Generated at 2022-06-22 22:14:16.365310
# Unit test for function check_required_together
def test_check_required_together():
    parameters = dict(
        one='1',
        two='2'
    )
    terms = [['one', 'two']]

    expected = []
    result = check_required_together(terms, parameters)
    assert result == expected

    parameters = dict(
        one='1'
    )
    terms = [['one', 'two']]

    expected = [['one', 'two']]
    with pytest.raises(TypeError) as e:
        check_required_together(terms, parameters)
    assert e.value.args[0] == "parameters are required together: one, two"

    parameters = dict(
        one='1',
        two='2',
        three='3'
    )
    terms = [['one', 'two'], ['two', 'three']]

    expected = []
   

# Generated at 2022-06-22 22:14:21.334049
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[10, 20]') == [10, 20]
    assert safe_eval('{"k1": "v1"}') == {'k1': 'v1'}
    assert safe_eval('10') == 10
    assert safe_eval('"test"') == 'test'



# Generated at 2022-06-22 22:14:29.748753
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('') == 0
    assert check_type_bits('1') == 1
    assert check_type_bits('0') == 0
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('1Tb') == 1099511627776
    assert check_type_bits('1Pb') == 1125899906842624
    assert check_type_bits('1Eb') == 1152921504606846976
    assert check_type_bits('1Zb') == 1180591620717411303424
    assert check_type_bits('1Yb') == 1208925819614629174706176
    assert check

# Generated at 2022-06-22 22:14:38.376730
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(1) == True
    assert check_type_bool(0) == False
    assert check_type_bool('1') == True
    assert check_type_bool('0') == False
    assert check_type_bool('yes') == True
    assert check_type_bool('no') == False
    assert check_type_bool('on') == True
    assert check_type_bool('off') == False
    assert check_type_bool('true') == True
    assert check_type_bool('false') == False
    assert check_type_bool('y') == True
    assert check_type_bool('n') == False



# Generated at 2022-06-22 22:14:44.481788
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg("{\"a\": 1,\"b\": 2}") == jsonify(dict(a=1, b=2))
    assert check_type_jsonarg("[{\"a\": 1},{\"b\": 2}]") == jsonify(dict(a=1, b=2))
    assert check_type_jsonarg("{\"a\": 1,\"b\": 2}") == "{\"a\": 1,\"b\": 2}"
    assert check_type_jsonarg("[{\"a\": 1},{\"b\": 2}]") == "[{\"a\": 1},{\"b\": 2}]"


# Generated at 2022-06-22 22:14:47.696317
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    value = '\'{"foo":"bar"}\''
    actual = check_type_jsonarg(value)
    expected = "'{\"foo\":\"bar\"}'"
    assert actual == expected


# Generated at 2022-06-22 22:14:57.342588
# Unit test for function check_required_if
def test_check_required_if():
    parameters = {"state": "present", "path": "/tmp/foo", "someint": 99}
    # one of case and all of case, should pass
    requirements = [
        ["state", "present", [("path",)], True],
        ["someint", 99, [("bool_param", "string_param")], False]
    ]
    results = check_required_if(requirements, parameters)
    assert len(results) == 0
    # all of case, should fail
    requirements = [
        ["state", "present", [("string_param",)], False],
        ["someint", 99, [("bool_param", "string_param")], False]
    ]

# Generated at 2022-06-22 22:15:08.866115
# Unit test for function check_type_list
def test_check_type_list():
    # test with list input
    v = check_type_list(['a', 'b', 'c'])
    assert v == ['a', 'b', 'c']

    # test with single element that is not a string
    v = check_type_list(1)
    assert v == ['1']

    # test with single element that is a string without commas,
    v = check_type_list('a')
    assert v == ['a']

    # test with single element that is a string with commas
    v = check_type_list('a,b,c')
    assert v == ['a', 'b', 'c']

    # test with dictionary input that can't be cast to a list
    with pytest.raises(TypeError) as e:
        check_type_list({'a': 'b'})

# Generated at 2022-06-22 22:15:18.071575
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ['path'], True],
        ['someint', 99, ['bool_param', 'string_param']]
    ]

    test_parameters = {
        'state': 'present',
        'someint': 99
    }
    # with only valid parameters
    result = check_required_if(requirements, test_parameters)
    assert result == []
    # with only one valid parameter
    test_parameters['bool_param'] = True
    result = check_required_if(requirements, test_parameters)
    assert result == []
    # with invalid parameters
    test_parameters['string_param'] = 'abc'
    result = check_required_if(requirements, test_parameters)
    assert result == []
    # with valid parameters in one condition and invalid in

# Generated at 2022-06-22 22:15:24.689396
# Unit test for function check_type_float
def test_check_type_float():
    if sys.version_info[0] < 3:
        assert check_type_float(u'3.14') == 3.14
    else:
        assert check_type_float(u'3.14') == 3.14
    assert check_type_float(b'3.14') == 3.14
    assert check_type_float(3.14) == 3.14
    assert check_type_float(314) == 314.0
    assert check_type_float('314') == 314.0



# Generated at 2022-06-22 22:15:30.550446
# Unit test for function check_type_float
def test_check_type_float():
    tests = [('10', 10.0, 'number'), ('10.0', 10.0, 'number'), ('10.0.0', 10.0, 'number'), ('true', 10.0, 'boolean'), ('false', 0.0, 'boolean'), ('foo', 1.0, 'string'), ('10.0foo', 10.0, 'number')]
    print('Testing ')
    for test_string, expected, type in tests:
        result = check_type_float(test_string)
        print('Test string : ' + test_string + '. Type: ' + type + '. Expected: ' + str(expected) + '. Output: ' + str(result))
        assert result == expected


# Generated at 2022-06-22 22:15:40.555258
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # No terms
    assert check_mutually_exclusive(None, {"a": 1, "b": 2, "c": 3, "d": 4}) == []

    # Existing terms
    assert check_mutually_exclusive(["a", "b"], {"a": 1, "b": 2}) == ["a", "b"]
    assert check_mutually_exclusive(["a", "b"], {"a": 1, "c": 2}) == []
    assert check_mutually_exclusive(["a", "b"], {"a": 1, "b": 2, "c": 3}) == ["a", "b"]
    assert check_mutually_exclusive(["a", "b", "c"], {"a": 1, "b": 2, "c": 3}) == ["a", "b", "c"]

    # Multiple terms
    assert check_mutually

# Generated at 2022-06-22 22:15:49.963981
# Unit test for function check_required_one_of
def test_check_required_one_of():

    # Return empty list on success
    assert check_required_one_of(None, {}) == []

    # Works with 2 dimensional list too
    assert check_required_one_of([['test1']], {'test1': 'test1'}) == []

    # Raise TypeError on invalid input
    try:
        check_required_one_of([['test1', 'test2']], {'test1': 'test1'})
    except TypeError as e:
        assert str(e) == 'one of the following is required: test1, test2'
    else:
        assert False

    # options_context works as expected

# Generated at 2022-06-22 22:15:57.942163
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(10) == 10.0
    assert check_type_float("10") == 10.0
    assert check_type_float(10.5) == 10.5
    assert check_type_float("10.5") == 10.5
    assert check_type_float(b"10") == 10.0
    assert check_type_float(b"10.5") == 10.5
    assert check_type_float("text") == 0.0
    assert_raises(TypeError, check_type_float, [5])



# Generated at 2022-06-22 22:16:10.804872
# Unit test for function check_type_int
def test_check_type_int():
    #Tests for functions check_type_int() in module module_utils.basic
    #Test case 1: Check when value is given as integer
    print("Test case 1: Check when value is given as integer")
    print("Expected result : value, Given result : " + str(check_type_int(5)))
    #Test case 2: Check when value is given as string
    print("Test case 2: Check when value is given as string")
    print("Expected result : value, Given result : " + str(check_type_int('5')))
    #Test case 3: Check when value is given as other than string and integer
    print("Test case 3: Check when value is given as other than string and integer")

# Generated at 2022-06-22 22:16:23.325970
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True) is True
    assert check_type_bool(False) is False
    assert check_type_bool(1) is True
    assert check_type_bool(0) is False
    assert check_type_bool('1') is True
    assert check_type_bool('0') is False
    assert check_type_bool('on') is True
    assert check_type_bool('off') is False
    assert check_type_bool('true') is True
    assert check_type_bool('yes') is True
    assert check_type_bool('false') is False
    assert check_type_bool('no') is False
    assert check_type_bool('n') is False
    assert check_type_bool('y') is True
    assert check_type_bool('t') is True

# Generated at 2022-06-22 22:16:27.079732
# Unit test for function check_type_path
def test_check_type_path():
    value = '$HOME/foo'
    result = check_type_path(value)
    assert result == os.path.expanduser(os.path.expandvars(value))
    value = '$HOMEfoo'
    result = check_type_path(value)
    assert result == os.path.expanduser(os.path.expandvars(value))



# Generated at 2022-06-22 22:16:30.833012
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # Function must return an empty list
    # Because it does not check for missing parameters in reality
    assert check_missing_parameters({}, []) == []



# Generated at 2022-06-22 22:16:41.829620
# Unit test for function check_required_if
def test_check_required_if():
    # Test 1, None is not returned
    input = [['state', 'present', ('path',), True]]
    assert check_required_if(input, {}) is not None
    # Test 2, None is returned
    input = [['state', 'present', ('path',), True]]
    assert check_required_if(input, {'state': 'present', 'path': '/test'}) is None
    # Test 3, None is not returned
    input = [['state', 'present', ('path',), True],
             ['someint', 99, ['bool_param', 'string_param']]]
    assert check_required_if(input, {'state': 'present', 'path': '/test'}) is not None

# Generated at 2022-06-22 22:16:45.749689
# Unit test for function count_terms
def test_count_terms():
    terms = ['state', 'aaa', 'enabled']
    parameters = {'aaa': 'test', 'state': 'present', 'enabled': False}
    assert count_terms(terms, parameters) == 3
    terms = ['state', 'not_present']
    parameters = {'state': 'present', 'enabled': False}
    assert count_terms(terms, parameters) == 1



# Generated at 2022-06-22 22:16:51.596030
# Unit test for function check_required_one_of
def test_check_required_one_of():
    correct = check_required_one_of([['a', 'b', 'c']], dict(a=True))
    assert correct == []

    error = check_required_one_of([['a', 'b', 'c']], dict())
    assert error == [['a', 'b', 'c']]

    error_2 = check_required_one_of([('a', 'b', 'c')], dict())
    assert error_2 == [['a', 'b', 'c']]

    error_3 = check_required_one_of([('a', 'b', 'c')], dict(a=True, b=True, c=True))
    assert error_3 == []

    error_4 = check_required_one_of([('a', 'b', 'c')], dict(a=True, c=True))
   

# Generated at 2022-06-22 22:17:02.424354
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('foo') == 'foo'
    assert safe_eval('123') == 123
    assert safe_eval('1.23') == 1.23
    assert safe_eval('True') is True
    assert safe_eval('"string"') == 'string'
    assert safe_eval("'string'") == 'string'
    assert safe_eval('{}') == {}
    assert safe_eval('[]') == []
    assert safe_eval('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert safe_eval('[1, 2]') == [1, 2]
    assert safe_eval('None') is None
    assert safe_eval('foo', include_exceptions=True) == ('foo', None)

# Generated at 2022-06-22 22:17:15.233872
# Unit test for function check_type_dict
def test_check_type_dict():
    check_type_dict('k1=v1,k2=v2')
    check_type_dict('k1=v1,k2="v2,v3"')
    check_type_dict('k1=v1,k2="v2,v3",k3=v3')
    check_type_dict('k1=v1,k2="v2,v3",k3="v3,v4",k4=v4')
    check_type_dict('k1=v1,k2="v2,v3",k3="v3,v4",k4=v4,k5=v5')

# Generated at 2022-06-22 22:17:22.001278
# Unit test for function count_terms
def test_count_terms():
    parameters = ['b', 'b', 'a', 'a', 'a', 'a', 'a', 'a']
    terms = 'a'
    result = 7
    assert count_terms(terms, parameters) == result
    terms = ['a', 'b']
    result = 8
    assert count_terms(terms, parameters) == result
    terms = ['C', 'c']
    result = 0
    assert count_terms(terms, parameters) == result
    terms = 'C'
    result = 0
    assert count_terms(terms, parameters) == result



# Generated at 2022-06-22 22:17:33.334596
# Unit test for function check_type_int
def test_check_type_int():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import int2byte

    class Struct:
        pass

    test_value = Struct()
    test_value.dummy = "Dummy"
    test_value1 = b"123"
    test_value2 = '  123  '
    test_value3 = '  123.123  '
    test_value4 = b"  123  "
    test_value5 = '  123  '
    test_value6 = '  -123  '
    test_value7 = '  -123  '
    test_value8 = '  300  '
    test_value9 = '  4100  '
    test_value10 = [chr(i) for i in range(256)]

# Generated at 2022-06-22 22:17:40.287109
# Unit test for function check_type_str
def test_check_type_str():
    value = "string"
    strings = ["string", 'string', "string"]
    assert check_type_str(value, allow_conversion=True) == value
    assert check_type_str(value, allow_conversion=False) == value
    assertRaisesRegexp(TypeError, "'{0!r}' is not a string and conversion is not allowed".format(strings[0]), check_type_str, strings[0], allow_conversion=False)
    assertRaisesRegexp(TypeError, "'{0!r}' is not a string and conversion is not allowed".format(strings[1]), check_type_str, strings[1], allow_conversion=False)

# Generated at 2022-06-22 22:17:49.916206
# Unit test for function safe_eval
def test_safe_eval():
    # string
    assert safe_eval('foo') == 'foo'
    # unicode string
    assert safe_eval('Д') == 'Д'
    # bytes
    assert safe_eval(b'foo') == b'foo'
    # int
    assert safe_eval('1') == 1
    # float
    assert safe_eval('1.0') == 1.0
    # bool
    assert safe_eval('True') is True
    # list
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    # tuple
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    # dict
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    # long int

# Generated at 2022-06-22 22:17:59.922766
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(1) == ["1"]
    assert check_type_list("1") == ["1"]
    assert check_type_list("1,2,3") == ["1", "2", "3"]
    assert check_type_list([1, 2, 3]) == [1, 2, 3]
    assert check_type_list([1]) == [1]
    assert check_type_list({"a": 1}) == ["{'a': 1}"]
    assert check_type_list(True) == ['True']
    assert check_type_list(None) == ['None']



# Generated at 2022-06-22 22:18:05.202896
# Unit test for function safe_eval

# Generated at 2022-06-22 22:18:16.536354
# Unit test for function check_required_if
def test_check_required_if():
    parameters = {
        'state': 'present',
        'path': '/path/to/file.txt',
        'someint': 99,
        'bool_param': True
    }
    argument_spec = {
        'state': {'required': True, 'choices': ['present', 'absent']},
        'path': {'required': False},
        'someint': {'required': True},
        'bool_param': {'required': False},
        'string_param': {'required': False}
    }
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    missing = check_required_if(requirements, parameters, options_context=None)

# Generated at 2022-06-22 22:18:25.612751
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('["foo", "bar"]') == '["foo", "bar"]'
    assert check_type_jsonarg(['foo', 'bar']) == '["foo", "bar"]'
    assert check_type_jsonarg('{"foo": "bar", "baz": "qux"}') == '{"foo": "bar", "baz": "qux"}'
    assert check_type_jsonarg({'foo': 'bar', 'baz': 'qux'}) == '{"baz": "qux", "foo": "bar"}'

# FIXME: This is temporary until we have sorted out all of the utf-8 vs bytes vs str issues

# Generated at 2022-06-22 22:18:32.081319
# Unit test for function count_terms
def test_count_terms():
    assert count_terms("key1", {"key1": True}) == 1
    assert count_terms(["key1", "key2"], {"key1": True}) == 1
    assert count_terms(["key1", "key2"], {"key1": True, "key2": True}) == 2
    assert count_terms(["key1", "key2"], {"key1": True, "key2": True, "key3": True}) == 2
    assert count_terms(["key1", "key2"], {"key3": True}) == 0
    assert count_terms("key1", dict()) == 0
    assert count_terms(["key1"], dict()) == 0



# Generated at 2022-06-22 22:18:43.227072
# Unit test for function check_required_if
def test_check_required_if():
    # Check missing parameters with requirement is_one_of=False
    requirements = [
        ('state', 'present', ('path',), False)
    ]
    parameters = {}
    options_context = ['aa','bb']
    try:
        check_required_if(requirements=requirements, parameters=parameters, options_context=options_context)
    except TypeError as e:
        assert e.args[0] == "state is present but all of the following are missing: path found in aa -> bb"
    # Check missing parameters with requirement is_one_of=True
    requirements = [
        ('state', 'present', ('path',), True)
    ]
    parameters = {}

# Generated at 2022-06-22 22:18:46.936935
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {"key1": ["param_5", "param_6"]}
    parameters = {"key1": "param1", "param_5": "param5"}
    assert check_required_by(requirements, parameters) == {"key1": ["param_6"]}



# Generated at 2022-06-22 22:18:54.819390
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('a,b,c') == ['a', 'b', 'c']
    assert check_type_list(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert check_type_list(['a']) == ['a']
    assert check_type_list(['a', 'b']) == ['a', 'b']
    assert check_type_list('a') == ['a']
    assert check_type_list(1) == ['1']
    assert check_type_list(1.2) == ['1.2']



# Generated at 2022-06-22 22:19:07.322761
# Unit test for function check_type_dict
def test_check_type_dict():
    # Simple dict
    obj = {'d': 1}
    assert check_type_dict(obj) == obj

    # Dict with string values
    obj = {'a': 'b', 'c': 'd'}
    assert check_type_dict(obj) == obj

    # Dict with boolean values
    obj = {'a': True, 'b': False}
    assert check_type_dict(obj) == obj

    # String with JSON dict
    obj = '{"a":1,"b":2}'
    assert check_type_dict(obj) == json.loads(obj)

    # String with key=value pairs
    obj = 'a=1, b=2'

# Generated at 2022-06-22 22:19:18.884172
# Unit test for function check_type_list
def test_check_type_list():
    assert [1,2,3] == check_type_list([1,2,3])
    assert [1] == check_type_list(1)
    assert [1] == check_type_list(1.0)
    assert ["1"] == check_type_list("1")
    assert ["1"] == check_type_list("1,2")
    assert [1] == check_type_list(1, True)
    assert ["1"] == check_type_list(1, False)
    assert ["1"] == check_type_list(1.0, False)
    assert ["1"] == check_type_list("1", False)
    assert ["1"] == check_type_list("1,2,3", False)


# Generated at 2022-06-22 22:19:30.719035
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"k1":"v1", "k2": [1, 2, 3]}') == {"k1": "v1", "k2": [1, 2, 3]}
    assert check_type_dict('k1=v1, k2=[1, 2, 3]') == {"k1": "v1", "k2": "[1, 2, 3]"}
    assert check_type_dict('{"k1":"v1", "k2": {"k3": "v3", "k4": "v4"}}')\
        == {"k1": "v1", "k2": {"k3": "v3", "k4": "v4"}}

# Generated at 2022-06-22 22:19:40.900148
# Unit test for function check_required_together
def test_check_required_together():
    t1 = (
        ('iam_group', 'iam_name'),
        ('iam_group','iam_system'),
    )
    t2 = (
        ('iam_group', 'iam_name'),
        ('iam_group','iam_system'),
        ('iam_group','iam_system','iam_name'),
    )
    t3 = (
        ('iam_group', 'iam_name'),
        ('iam_group','iam_system'),
        ('iam_group'),
    )
    # Unit test for function check_required_together
    p1 = {'iam_group': 'ansadmin', 'iam_name': 'Ansuser'}
    p2 = {'iam_group': 'ansadmin', 'iam_system': 'Ansuser'}

# Generated at 2022-06-22 22:19:51.619037
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():

    def check_ctx(terms):
        parameters = {'a': 'value', 'b': 'value', 'c': 'value'}

        try:
            check_mutually_exclusive(terms, parameters)
        except TypeError:
            return True


    assert check_ctx(['a', 'b', 'c'])
    assert not check_ctx(['a', 'b'])

    def check_nested_ctx(terms):
        parameters = {'host': 'value', 'user': 'value', 'password': 'value'}

        try:
            check_mutually_exclusive(terms, parameters, options_context=['connection'])
        except TypeError:
            return True


    assert check_nested_ctx([['host', 'user', 'password']])

# Generated at 2022-06-22 22:20:04.083591
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1048576') == 1048576
    assert check_type_bytes('1048576B') == 1048576
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1KB') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1MB') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1GB') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1TB') == 1099511627776
    assert check_type_bytes('1P') == 11258999068426

# Generated at 2022-06-22 22:20:15.565310
# Unit test for function check_type_path
def test_check_type_path():
    test_input = [
        '~/ansible/',
        '{{ home }}/ansible/',
        '/tmp/',
        '.',
        '../',
        '',
        '/'
    ]
    test_output = [
        '/{0}/ansible/'.format(os.environ['HOME'].lstrip('/')),
        '{0}/ansible/'.format(os.environ['HOME']),
        '/tmp/',
        '{0}/'.format(os.getcwd()),
        '{0}/../'.format(os.getcwd()),
        '{0}/'.format(os.getcwd()),
        '/'
    ]

# Generated at 2022-06-22 22:20:23.854283
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    from nose.tools import assert_raises
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean

# Generated at 2022-06-22 22:20:28.379409
# Unit test for function check_type_bits
def test_check_type_bits():
    a = check_type_bits('1Kb')
    b = check_type_bits('1Mb')
    assert a == 1024 and b == 1048576



# Generated at 2022-06-22 22:20:30.063549
# Unit test for function check_type_bits
def test_check_type_bits():
    bytevalue = check_type_bits('1Mb')
    assert bytevalue == 1048576



# Generated at 2022-06-22 22:20:33.757836
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1 Mb') == 1048576
    with pytest.raises(TypeError):
        check_type_bits("1")


# Generated at 2022-06-22 22:20:34.437289
# Unit test for function check_type_dict
def test_check_type_dict():
    pass



# Generated at 2022-06-22 22:20:38.377339
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = [['a','b','c']]
    parameters = {'a':'1', 'b':'2', 'c':'3'}
    options = ['something']
    check_mutually_exclusive(terms, parameters, options)
# End unit test for function check_mutually_exclusive



# Generated at 2022-06-22 22:20:40.784361
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'foo': 'bar'}
    required_parameters = ['foo', 'baz']
    assert check_missing_parameters(parameters, required_parameters) == ['baz']



# Generated at 2022-06-22 22:20:45.330191
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('') == 0
    assert check_type_bytes(1) == 1
    assert check_type_bytes('1') == 1
    assert check_type_bytes(1.1) == 1
    assert check_type_bytes('1.1') == 1
    assert check_type_bytes('1 B') == 1
    assert check_type_bytes('1 KiB') == 1024



# Generated at 2022-06-22 22:20:49.900338
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = dict(version='1.1', command='update')
    required_parameters = ['version', 'command', 'age']
    with pytest.raises(TypeError):
        check_missing_parameters(parameters, required_parameters)

# Generated at 2022-06-22 22:20:55.445196
# Unit test for function count_terms
def test_count_terms():
    assert(count_terms("foo", {"foo": "bar"}) == 1)
    assert(count_terms(["foo"], {"foo": "bar"}) == 1)
    assert(count_terms(["foo"], {"foobar": "bar"}) == 0)
    assert(count_terms(["foo", "bar"], {"foobar": "bar"}) == 1)
    assert(count_terms(["foo", "foobar"], {"foobar": "bar"}) == 2)



# Generated at 2022-06-22 22:20:56.351457
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-22 22:21:06.515095
# Unit test for function safe_eval
def test_safe_eval():
    # Check basic strings
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None

    # Check empty list and dict
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}

    # Check lists
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('[1, True, 3]') == [1, True, 3]
    assert safe_eval('[1, True, None]') == [1, True, None]

    # Check dicts
    assert safe_eval('{"a":1, "b":2, "c":3}') == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-22 22:21:11.380109
# Unit test for function check_required_by
def test_check_required_by():
    def _test_check_required_by(parameters, requirements, expected_result):
        """Unit test helper function for check_required_by function"""
        assert check_required_by(requirements, parameters) == expected_result

    _test_check_required_by(
        parameters={
            'foo': 'bar',
            'hello': 'world',
            'foo1': 'bar1',
        },
        requirements={
            'foo': ['hello'],
            'foo1': ['hello']
        },
        expected_result={}
    )


# Generated at 2022-06-22 22:21:21.210464
# Unit test for function check_required_if
def test_check_required_if():
    parameters = {"state": "present", "path": "/path/to/file", "someint": 99}
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    exp_results = [
        {
            'parameter': 'someint',
            'value': 99,
            'requirements': ('bool_param', 'string_param'),
            'missing': ['bool_param', 'string_param'],
            'requires': 'all',
        }
    ]
    results = check_required_if(requirements, parameters)

    assert json.loads(json.dumps(results)) == json.loads(json.dumps(exp_results))



# Generated at 2022-06-22 22:21:26.081360
# Unit test for function check_type_bytes
def test_check_type_bytes():
    bytes_str = "20G"
    bytes_res = check_type_bytes(bytes_str)
    assert bytes_res == 2155872256



# Generated at 2022-06-22 22:21:32.630728
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {"required_by_A": ["A", "B"], "required_by_B": ["C", "D"]}
    parameters = {"A": 1, "B": 2, "C": 3, "D": 4}
    assert check_required_by(requirements, parameters) == {}
    parameters["B"] = None
    assert check_required_by(requirements, parameters) == {"required_by_A": ["C", "D"]}


# Generated at 2022-06-22 22:21:37.682003
# Unit test for function check_type_dict

# Generated at 2022-06-22 22:21:49.219846
# Unit test for function check_type_list
def test_check_type_list():
    # Test with the expected input types
    assert ['a', 'b', 'c'] == check_type_list(['a', 'b', 'c'])
    assert ['a', 'b', 'c'] == check_type_list('a,b,c')
    assert ['a', 'b', 'c'] == check_type_list('a, b,   c ')
    assert ['1', '2', '3'] == check_type_list(1)
    assert ['1', '2', '3'] == check_type_list(1.0)
    assert ['1', '2', '3'] == check_type_list(1.123)
    assert ['0', '0', '1'] == check_type_list(0.000123)
    # Test with the expected input types

# Generated at 2022-06-22 22:21:59.316992
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{}') == {}
    assert safe_eval('foo') == 'foo'
    assert safe_eval('localhost') == 'localhost'
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval("'foo'") == 'foo'
    assert safe_eval('foo.bar()', include_exceptions=True) == ('foo.bar()', None)
    assert safe_eval('import foo', include_exceptions=True) == ('import foo', None)
    assert safe_eval('[1, 2]') == [1, 2]
    assert safe_eval('[1, 2]', locals={'foo': 42}) == [1, 2]
    assert safe_eval('{1, 2}') == {1, 2}

# Generated at 2022-06-22 22:22:03.118666
# Unit test for function check_type_int
def test_check_type_int():
    res = check_type_int(1)
    assert res == 1

    res = check_type_int('1')
    assert res == 1

    with pytest.raises(TypeError):
        check_type_int(1.2)

    with pytest.raises(TypeError):
        check_type_int('a')

    with pytest.raises(TypeError):
        check_type_int({})

