

# Generated at 2022-06-22 22:12:08.362094
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = dict(required_one=dict(required=True),
                         required_two=dict(required=True),
                         optional_one=dict(required=False),
                         optional_two=dict(required=False))
    parameters = dict(required_one='foo',
                      optional_one=True)
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == ['required_two']



# Generated at 2022-06-22 22:12:17.057182
# Unit test for function check_required_arguments
def test_check_required_arguments():
    import pytest

    # required argument defined in argument_spec and present in parameters
    argument_spec = {
        "argument1": {"required": True, "type": "str"}
    }
    parameters = {"argument1": "value1"}
    result = check_required_arguments(argument_spec,parameters)
    assert result == []

    # required argument not defined in argument_spec
    argument_spec = {
        "argument1": {"type": "str"}
    }
    result = check_required_arguments(argument_spec,parameters)
    assert result == []

    # required argument defined in argument_spec but not present in parameters
    argument_spec = {
        "argument1": {"required": True, "type": "str"},
        "argument2": {"required": True, "type": "str"}
    }
   

# Generated at 2022-06-22 22:12:25.418923
# Unit test for function check_type_float
def test_check_type_float():
    '''Check for float in the given value'''
    print(check_type_float(1.1))
    print(check_type_float(float(1.1)))
    print(check_type_float('1.1'))
    try:
        print(check_type_float('a'))
    except TypeError:
        print('Unable to convert to float')

test_check_type_float()


# Generated at 2022-06-22 22:12:35.761709
# Unit test for function check_required_one_of
def test_check_required_one_of():
    my_required_one_of_terms = [['my_para_1', 'my_para_2'], ['my_para_3']]
    my_parameters = {'my_para_1': 'abc', 'my_para_2': 'def'}
    try:
       check_required_one_of(my_required_one_of_terms,my_parameters)
    except Exception as e:
       assert False, e
    my_required_one_of_terms = [['my_para_1', 'my_para_2'], ['my_para_3']]
    my_parameters = {'my_para_1': 'abc', 'my_para_2': 'def', 'my_para_3': 'xyz'}

# Generated at 2022-06-22 22:12:43.782310
# Unit test for function check_required_together
def test_check_required_together():
    params = {'a':1,'b':2}
    found_error = False
    try:
        check_required_together([['c','d']], params)
    except TypeError:
        found_error = True
    assert not found_error

    found_error = False
    try:
        check_required_together([['a','c']], params)
    except TypeError:
        found_error = True
    assert found_error

    found_error = False
    try:
        check_required_together([['a','b','c']], params)
    except TypeError:
        found_error = True
    assert found_error



# Generated at 2022-06-22 22:12:49.218032
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'bool_param': True}
    result = check_required_if(requirements, parameters)
    assert result == [{'missing': ['string_param'], 'requires': 'all', 'parameter': 'someint', 'value': 99, 'requirements': ('bool_param', 'string_param')}]



# Generated at 2022-06-22 22:12:55.070994
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str("str") == "str"
    assert check_type_str(123456789) == "123456789"
    assert check_type_str(123456789, allow_conversion=False) == "123456789"
    with pytest.raises(TypeError) as excinfo:
        check_type_str(123456789, allow_conversion=False)
    assert 'is not a string and conversion is not allowed' in to_native(excinfo.value)



# Generated at 2022-06-22 22:13:06.837594
# Unit test for function safe_eval
def test_safe_eval():
    # Passes
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{1: [[1, 2], 2, 3, 4], 2: [1, 2, 3, 4]}') == {1: [[1, 2], 2, 3, 4], 2: [1, 2, 3, 4]}
    assert safe_eval('True') is True
    assert safe_eval('2 ** 4') == 16
    assert safe_eval('v + 3', {'v': 3}) == 6
    assert safe_eval('"True"') == 'True'
    assert safe_eval('False') is False

    # Fails
    assert safe_eval('[1, 2, 3] + [4, 5, 6]') == '[1, 2, 3] + [4, 5, 6]'

# Generated at 2022-06-22 22:13:12.569849
# Unit test for function check_type_bool
def test_check_type_bool():
    test_value = [('1', True), ('on', True), (1, True), ('0', False), (0, False), ('n', False), ('f', False),
                  ('false', False), ('true', True), ('y', True), ('t', True), ('yes', True), ('no', False),
                  ('off', False)]
    for value in test_value:
        assert check_type_bool(value[0]) == value[1]




# Generated at 2022-06-22 22:13:13.249118
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(1) == 1



# Generated at 2022-06-22 22:13:18.190855
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Bytes
    assert check_type_bytes(100) == 100
    assert check_type_bytes('101') == 101
    # KiloBytes
    assert check_type_bytes('1K') == 1024
    # MegaBytes
    assert check_type_bytes('1M') == 1024 * 1024
    # GigaBytes
    assert check_type_bytes('1G') == 1024 * 1024 * 1024
    # TeraBytes
    assert check_type_bytes('1T') == 1024 * 1024 * 1024 * 1024
    # 100 KiloBytes
    assert check_type_bytes('100K') == 100 * 1024
    # 1.5 MegaBytes
    assert check_type_bytes('1.5M') == int(1024 * 1024 * 1.5)
    # Negative values not allowed
    with pytest.raises(TypeError):
        check

# Generated at 2022-06-22 22:13:29.945778
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('yes') is True
    assert check_type_bool('yeS') is True
    assert check_type_bool('Y') is True
    assert check_type_bool('1') is True
    assert check_type_bool('t') is True
    assert check_type_bool('true') is True
    assert check_type_bool('TRUE') is True

    assert check_type_bool('no') is False
    assert check_type_bool('NO') is False
    assert check_type_bool('n') is False
    assert check_type_bool('off') is False
    assert check_type_bool('OFF') is False
    assert check_type_bool('f') is False
    assert check_type_bool('0') is False
    assert check_type_bool('false') is False

# Generated at 2022-06-22 22:13:37.194527
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(['name', 'type'], {'name': 'test', 'type': 'test', 'other': 'test'}) == 2
    assert count_terms(['name', 'type'], {'name': 'test', 'other': 'test'}) == 1
    assert count_terms('name', {'name': 'test', 'type': 'test', 'other': 'test'}) == 1
    assert count_terms('name', {'type': 'test', 'other': 'test'}) == 0



# Generated at 2022-06-22 22:13:40.692456
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {
            'required': True,
            'type': 'str'
        }
    }
    parameters = {
        'required_arg': 'foo'
    }
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []

    parameters = {
    }
    missing = check_required_arguments(argument_spec, parameters)
    assert len(missing) == 1
    assert missing[0] == 'required_arg'



# Generated at 2022-06-22 22:13:46.649789
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Empty argument_spec and parameters
    argument_spec = {}
    parameters = {}
    result = check_required_arguments(argument_spec, parameters)
    assert result == [], "check_required_arguments failed with empty argument_spec and parameters"

    # Empty argument_spec
    argument_spec = {}
    parameters = {'key': 'val'}
    result = check_required_arguments(argument_spec, parameters)
    assert result == [], "check_required_arguments failed with empty argument_spec"

    # Empty parameters
    argument_spec = {'key': {'required': True}}
    parameters = {}
    result = check_required_arguments(argument_spec, parameters)
    assert result == ['key'], "check_required_arguments failed with empty parameters"

    # Non-empty argument_spec and parameters

# Generated at 2022-06-22 22:13:51.967505
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('10B') == 10
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1KB') == 1024
    assert check_type_bytes('1mb') == 1024 * 1024
    assert check_type_bytes('1MB') == 1024 * 1024
    assert check_type_bytes('1G') == 1024 * 1024 * 1024
    assert check_type_bytes('1gb') == 1024 * 1024 * 1024
    assert check_type_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1TB') == 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1P') == 1024 * 1024 * 1024 * 1024 * 1024

# Generated at 2022-06-22 22:14:01.364462
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float('1') == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float(bytes(b'1.0')) == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(u'1.0') == 1.0

    assert check_type_float('1.1') == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float(bytes(b'1.1')) == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(u'1.1') == 1.

# Generated at 2022-06-22 22:14:11.760056
# Unit test for function check_required_one_of
def test_check_required_one_of():
    from ansible.module_utils.basic import AnsibleModule

    def test_function_mock(module_args, module_name, module_path, check_invalid_arguments=True,
                           supports_check_mode=True, **kwargs):
        module = AnsibleModule(argument_spec=module_args, check_invalid_arguments=check_invalid_arguments,
                               supports_check_mode=supports_check_mode)
        return module.exit_json(changed=True)


# Generated at 2022-06-22 22:14:15.878151
# Unit test for function check_type_path
def test_check_type_path():
    value1 = b"/home/$USER/some_file"
    value1_expanded = os.path.expanduser(os.path.expandvars(value1))
    assert check_type_path(value1) == value1_expanded

    value2 = b"/home/${USER}/some_file"
    value2_expanded = os.path.expanduser(os.path.expandvars(value2))
    assert check_type_path(value2) == value2_expanded

    value3 = 1024
    with pytest.raises(TypeError):
        assert check_type_path(value3) == value3

# Generated at 2022-06-22 22:14:24.345039
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(True) == 1
    assert check_type_int(False) == 0
    assert check_type_int('1') == 1
    assert check_type_int(1) == 1
    assert check_type_int(1.0) == 1
    assert check_type_int(1.1) == 1
    assert_raises(TypeError, check_type_int, [1, 2, 3])
    assert_raises(TypeError, check_type_int, 'test')
    assert_raises(TypeError, check_type_int, None)



# Generated at 2022-06-22 22:14:27.391169
# Unit test for function count_terms
def test_count_terms():
    """Test that count_terms returns the correct number of occurrences
    """

    terms = ['foo', 'bar', 'baz']
    parameters = ['foo', 'bar', 'baz', 'baz', 'baz']
    assert count_terms(terms, parameters) == 3



# Generated at 2022-06-22 22:14:30.073464
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('123') == '123'
    assert check_type_raw(123) == 123

# Generated at 2022-06-22 22:14:40.578684
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # Function that calls check_missing_parameters
    def check_param_names():
        parameters = {'name':'test_name'}
        return check_missing_parameters(parameters, required_parameters = ['name', 'key'])
    try:
        # Case : required parameters not passed
        assert check_param_names() == []
    except Exception as e:
        print(e)
        sys.exit(1)
    try:
        # Case : all required paramters passed
        parameters = {'name':'test_name', 'key':'test_key'}
        assert check_missing_parameters(parameters,required_parameters = ['name', 'key']) == []
    except Exception as e:
        print(e)
        sys.exit(1)

# Generated at 2022-06-22 22:14:52.023998
# Unit test for function check_required_by
def test_check_required_by():
    d1 = {
        "foo": "abc",
        "bar": "bcd",
    }
    d2 = {
        "foo": "abc",
    }
    d3 = {
        "bar": "bcd",
    }

    # test case 1:  all keys are present
    try:
        check_required_by({"foo": "bar"}, d1)
    except TypeError:
        assert False, "check_required_by raised TypeError unexpectedly!"

    # test case 2:  key "foo" not specified
    try:
        check_required_by({"foo": "bar"}, d2)
    except TypeError:
        assert False, "check_required_by raised TypeError unexpectedly!"

    # test case 3:  key "bar" not specified

# Generated at 2022-06-22 22:15:02.901203
# Unit test for function check_type_dict
def test_check_type_dict():
  assert check_type_dict({'a':'1', 'b':'2'}) == {'a':'1', 'b':'2'}
  assert check_type_dict('{a=1, b=2}') == {'a':'1', 'b':'2'}
  assert check_type_dict('{a:1, b:2}') == {'a':'1', 'b':'2'}
  assert check_type_dict('"a=1", "b=2"') == {'a=1', 'b=2'}
  assert check_type_dict('a=1, b=2') == {'a':'1', 'b':'2'}
  assert check_type_dict('a=1') == {'a':'1'}

  # Test bad inputs
 

# Generated at 2022-06-22 22:15:06.476001
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str(u"This is a string") == u"This is a string"
    assert check_type_str(u"This is a string", False) == u"This is a string"
    assert check_type_str(u"This is a string", True) == u"This is a string"
    assert check_type_str(["This", "is", "a", "string"], True) == u"This is a string"


# FIXME: The param and prefix parameters here are coming from AnsibleModule._check_type_list()
#        which is using those for the warning messaged based on string conversion warning settings.
#        Not sure how to deal with that here since we don't have config state to query.

# Generated at 2022-06-22 22:15:09.857658
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('/tmp/') == '/tmp/'
    assert check_type_path('${HOME}') == os.getenv('HOME')
    assert check_type_path('~') == os.path.expanduser('~')
    assert check_type_path('file') == 'file'



# Generated at 2022-06-22 22:15:13.989615
# Unit test for function check_type_list
def test_check_type_list():
    # returns a list
    # a string
    assert check_type_list('a') == ['a']
    # a comma separated string
    assert check_type_list('a,b') == ['a', 'b']
    # an int
    assert check_type_list(1) == ['1']
    # a float
    assert check_type_list(1.1) == ['1.1']
    # a list
    assert check_type_list(['a', 'b']) == ['a', 'b']
    # a nested list
    assert check_type_list([['a', 'b'], ['c', 'd']]) == [['a', 'b'], ['c', 'd']]
    # a tuple
    assert check_type_list(('a', 'b')) == ['a', 'b']


# Generated at 2022-06-22 22:15:20.470642
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576, "Failed to convert '1Mb' to 1048576"
    try:
        check_type_bits(13.37)
    except TypeError as e:
        assert str(e) == "<class 'float'> cannot be converted to a Bit value", "Failed to raise error for float"


# Generated at 2022-06-22 22:15:24.139728
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = None
    parameters = {}
    assert check_required_one_of(terms, parameters) == []

    terms = (("foo", "bar"),)
    assert check_required_one_of(terms, parameters) == [("foo", "bar")]



# Generated at 2022-06-22 22:15:36.677466
# Unit test for function check_type_bool
def test_check_type_bool():
    assert isinstance(check_type_bool(True), bool)
    assert isinstance(check_type_bool('1'), bool)
    assert isinstance(check_type_bool('on'), bool)
    assert isinstance(check_type_bool(1), bool)
    assert isinstance(check_type_bool('0'), bool)
    assert isinstance(check_type_bool(0), bool)
    assert isinstance(check_type_bool('n'), bool)
    assert isinstance(check_type_bool('f'), bool)
    assert isinstance(check_type_bool('false'), bool)
    assert isinstance(check_type_bool('true'), bool)
    assert isinstance(check_type_bool('y'), bool)
    assert isinstance(check_type_bool('t'), bool)

# Generated at 2022-06-22 22:15:47.437983
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('str(1)') == 'str(1)'
    assert safe_eval('1') == 1
    assert safe_eval('{"foo": "bar"}') == {u'foo': u'bar'}
    assert safe_eval('{"a": 1, "b": 2}') == {u'a': 1, u'b': 2}
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('[1, {"foo": "bar"}, 3]') == [1, {u'foo': u'bar'}, 3]
    assert safe_eval('["foo", "bar"]') == [u'foo', u'bar']

# Generated at 2022-06-22 22:15:52.706717
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1)==1
    assert check_type_int('1')==1
    with pytest.raises(TypeError):
        check_type_int(1.1)
    with pytest.raises(TypeError):
        check_type_int('1.1')


# Generated at 2022-06-22 22:16:00.660849
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg(['{ "a":[1, 2, 3], "b":2 }']) == '{"a": [1, 2, 3], "b":2}'
    assert check_type_jsonarg({'a': [1, 2, 3], 'b': 2}) == '{"a": [1, 2, 3], "b":2}'
    assert check_type_jsonarg([{'a': 123, 'b': 234}]) == '[{"a": 123, "b": 234}]'
    assert check_type_jsonarg('{ "a":[1, 2, 3], "b":2 }') == '{"a": [1, 2, 3], "b":2}'

# Generated at 2022-06-22 22:16:10.829245
# Unit test for function check_required_if

# Generated at 2022-06-22 22:16:23.325778
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval("'text'") == 'text'
    assert safe_eval("'text'", include_exceptions=True) == ('text', None)
    assert safe_eval('1') == 1
    assert safe_eval('1', include_exceptions=True) == (1, None)
    assert safe_eval('1.1') == 1.1
    assert safe_eval('1.1', include_exceptions=True) == (1.1, None)
    assert safe_eval('["1", "2"]') == ["1", "2"]
    assert safe_eval('["1", "2"]', include_exceptions=True) == (["1", "2"], None)
    assert safe_eval('{"1": "1", "2": "2"}') == {"1": "1", "2": "2"}
   

# Generated at 2022-06-22 22:16:31.557248
# Unit test for function check_required_by
def test_check_required_by():
    from ansible.module_utils.common.validation import check_required_by

    assert check_required_by(None, {}) == {}
    assert check_required_by({"a": "b"}, {}) == {"a": ["b"]}
    assert check_required_by({"a": ["b", "c"]}, {}) == {"a": ["b", "c"]}
    assert check_required_by({"a": "b"}, {"a": None}) == {"a": ["b"]}
    assert check_required_by({"a": ["b", "c"]}, {"a": None}) == {"a": ["b", "c"]}
    assert check_required_by({"a": "b"}, {"a": "d"}) == {"a": ["b"]}

# Generated at 2022-06-22 22:16:34.651778
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int('123') == 123
    assert check_type_int(123) == 123



# Generated at 2022-06-22 22:16:44.735449
# Unit test for function check_type_bool
def test_check_type_bool():
    # Test valid bool types:
    assert check_type_bool(1) is True
    assert check_type_bool(True) is True
    assert check_type_bool(0) is False
    assert check_type_bool(False) is False
    assert check_type_bool('1') is True
    assert check_type_bool('on') is True
    assert check_type_bool('0') is False
    assert check_type_bool('n') is False
    assert check_type_bool('false') is False
    assert check_type_bool('true') is True
    assert check_type_bool('y') is True
    assert check_type_bool('t') is True
    assert check_type_bool('yes') is True
    assert check_type_bool('no') is False

# Generated at 2022-06-22 22:16:53.964610
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Successful test
    check = []
    check.append(['a'])
    check.append(['b'])
    check.append(['c', 'd'])
    parameters = {'a': 2, 'b': 3, 'c': 4}
    result = check_mutually_exclusive(check, parameters)
    assert not result

    # Unsuccessful test
    check = []
    check.append(['a'])
    check.append(['b'])
    check.append(['c', 'd'])
    parameters = {'a': 2, 'b': 3, 'c': 4, 'd': 5}
    try:
        result = check_mutually_exclusive(check, parameters)
        assert not result
    except TypeError:
        assert True



# Generated at 2022-06-22 22:16:57.248335
# Unit test for function check_type_float
def test_check_type_float():
    # Default
    assert check_type_float(1.0) == 1.0
    assert check_type_float(float(1)) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    with pytest.raises(TypeError):
        check_type_float(True)
    with pytest.raises(TypeError):
        check_type_float({'a': 1})
    with pytest.raises(TypeError):
        check_type_float('a')


# Generated at 2022-06-22 22:17:05.377384
# Unit test for function check_mutually_exclusive

# Generated at 2022-06-22 22:17:06.803553
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int('10') == 10
    assert check_type_int(10) == 10


# Generated at 2022-06-22 22:17:18.152437
# Unit test for function check_type_dict
def test_check_type_dict():
    value1 = 'key1=value1, key2=value2'
    value2 = '{"key1": "value1", "key2": "value2"}'
    value3 = {'key1': 'value1', 'key2': 'value2'}

    assert check_type_dict(value1) == check_type_dict(value2) == check_type_dict(value3)

    value4 = 'key1: value1, key2: value2'
    assert check_type_dict(value4) != check_type_dict(value1)

    value5 = 'key1=value1, key2=value2, key3=value3'
    value6 = '{"key1": "value1", "key2": "value2", "key3": "value3"}'


# Generated at 2022-06-22 22:17:25.572015
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("['foo', {'bar': ('baz', None, 1.0, 2)}]") == ['foo', {'bar': ('baz', None, 1.0, 2)}]
    assert safe_eval("{'foo':['bar', ('baz',)}]") == {'foo': ['bar', ('baz',)]}
    assert safe_eval("foo") == "foo"
    assert safe_eval('foo.bar("baz")') == "foo.bar(\"baz\")"
    assert safe_eval('import os') == 'import os'
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1 + 1]') == [2]
    assert safe_eval('"foo" + "bar"') == "foobar"

# Generated at 2022-06-22 22:17:34.095509
# Unit test for function check_required_if
def test_check_required_if():
    parameters = dict(
        a='a', b='b', c='c', d='d'
    )
    requirements = [
        ['a', 'a', ('b',)],
        ['b', 'b', ('a', 'c')]
    ]
    try:
        check_required_if(requirements, parameters)
    except TypeError as e:
        assert e.results == [
            {
                'parameter': 'b',
                'value': 'b',
                'requirements': ('a', 'c'),
                'missing': ['a'],
                'requires': 'all',
            }
        ]
    else:
        assert False, "Error not raised when expected"



# Generated at 2022-06-22 22:17:36.700464
# Unit test for function count_terms
def test_count_terms():
    test_dict = {'sex': 'male', 'age': '14', 'state': 'New York'}
    test_key = 'sex'
    result = count_terms(test_key, test_dict)
    assert result == 1



# Generated at 2022-06-22 22:17:48.724538
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int("123") == 123
    assert check_type_int("-123") == -123
    assert check_type_int("0xFF") == 255
    assert check_type_int("0123") == 83
    assert check_type_int("0o123") == 83
    assert check_type_int("0b101011") == 43
    assert check_type_int("0b11") == 3
    assert check_type_int("0B1") == 1
    assert check_type_int("0B11") == 3
    assert check_type_int("0B0") == 0
    assert check_type_int("0B1001") == 9
    assert check_type_int("12e3") == 12000
    assert check_type_int("12e+3") == 12000
    assert check

# Generated at 2022-06-22 22:17:51.300924
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert check_type_list('a,b,c') == ['a', 'b', 'c']
    assert check_type_list('a') == ['a']
    assert check_type_list(1) == ['1']
    assert check_type_list(1.234) == ['1.234']



# Generated at 2022-06-22 22:18:00.135693
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('[1,2]') == '[1,2]'
    assert check_type_jsonarg([1, 2]) == '[1,2]'
    assert check_type_jsonarg(('[1,2]')) == '[1,2]'
    assert check_type_jsonarg(('a', 'b')) == '["a","b"]'
    assert check_type_jsonarg('{"a":"b"}') == '{"a":"b"}'
    assert check_type_jsonarg({'a': 'b'}) == '{"a":"b"}'
    assert check_type_jsonarg(('{"a":"b"}')) == '{"a":"b"}'
    assert check_type_jsonarg("{'a':'b'}") == '{"a":"b"}'
    assert check_type_json

# Generated at 2022-06-22 22:18:07.597648
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int('3') == 3
    assert check_type_int(5) == 5
    assert check_type_int(3.8) == 3

    # TypeError test
    try:
        assert check_type_int('3.8')
    except TypeError as e:
        assert e == TypeError('%s cannot be converted to an int' % type('3.8'))
    try:
        assert check_type_int(['hi'])
    except TypeError as e:
        assert e == TypeError('%s cannot be converted to an int' % type(['hi']))




# Generated at 2022-06-22 22:18:10.938723
# Unit test for function check_type_bytes
def test_check_type_bytes():
    for value in ['10 bytes', '1kb', '1 mb']:
        check_type_bytes(value)


# Generated at 2022-06-22 22:18:17.085278
# Unit test for function check_type_float
def test_check_type_float():
    _describe("_params are int, str, bytes and float")
    _value(check_type_float(1))
    _value(check_type_float("1"))
    _value(check_type_float(b"1"))
    _value(check_type_float(1.0))
    _describe("_params are not int, str, bytes and float")
    _error(TypeError, check_type_float(True))
    _error(TypeError, check_type_float(complex(1,1)))


# Generated at 2022-06-22 22:18:19.510816
# Unit test for function check_type_path
def test_check_type_path():
    assert "~" in check_type_path("~")
    assert "~" in check_type_path("$$")
    assert "$" not in check_type_path("~")
    assert "$" in check_type_path("$USER")
    assert "~" not in check_type_path("/home/$USER")



# Generated at 2022-06-22 22:18:28.824725
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("{u'foo': u'bar'}") == {u'foo': u'bar'}
    assert safe_eval("[u'foo', u'bar']") == [u'foo', u'bar']
    assert safe_eval("['foo', 'bar']") == ['foo', 'bar']
    assert safe_eval("['foo', u'bar']") == ['foo', u'bar']
    assert safe_eval("None") is None
    assert safe_eval("u'foo'") == u'foo'
    assert safe_eval("'foo'") == 'foo'
    assert safe_eval("u'foo'") == u'foo'
    assert safe_eval("foo") == 'foo'
    assert safe_

# Generated at 2022-06-22 22:18:33.308933
# Unit test for function count_terms
def test_count_terms():
    parameters = dict(
        one=1, two=2, three=3, four=4, five=5
    )

    assert count_terms('one', parameters) == 1
    assert count_terms('two', parameters) == 1
    assert count_terms('not_exist', parameters) == 0
    assert count_terms(['one'], parameters) == 1
    assert count_terms(['one', 'five'], parameters) == 2
    assert count_terms(['not_exist'], parameters) == 0
# end unit test



# Generated at 2022-06-22 22:18:44.030541
# Unit test for function check_type_dict
def test_check_type_dict():
  assert check_type_dict('a=b') == {'a': 'b'}
  assert check_type_dict('a=b,c=d') == {'a': 'b', 'c': 'd'}
  assert check_type_dict('a=b,a=d') == {'a': 'b,a=d'}
  assert check_type_dict('a=b, c=d') == {'a': 'b', 'c': 'd'}
  assert check_type_dict('a=b, c=d ') == {'a': 'b', 'c': 'd'}
  assert check_type_dict(' a = b , c = d ') == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-22 22:18:53.113768
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('foo', {'foo': 'bar'}) == 1
    assert count_terms('foo', {'bar': 'foo'}) == 0
    assert count_terms('foo', {'foo': 'bar', 'foo1': 'bar1'}) == 1
    assert count_terms('foo', {'foo': 'bar', 'foo1': 'foo'}) == 1

    assert count_terms(['foo'], {'foo': 'bar'}) == 1
    assert count_terms(['foo', 'ok'], {'foo': 'bar'}) == 1
    assert count_terms(['foo', 'ok'], {'foo': 'bar', 'ok': 'ok'}) == 2



# Generated at 2022-06-22 22:19:05.710568
# Unit test for function check_type_str
def test_check_type_str():
    try:
        assert(check_type_str(None) == "None")
    except TypeError as e:
        assert(str(e) == "'NoneType' is not a string and conversion is not allowed")
    assert(check_type_str('z')=='z')
    assert(check_type_str(b'z')=='z')
    assert(check_type_str(True)=='True')
    assert(check_type_str(7)=='7')
    assert(check_type_str(7,allow_conversion=False)=='7')


# FIXME: The param and prefix parameters here are coming from AnsibleModule._check_type_bool()
#        which is using those for the warning messaged based on string conversion warning settings.
#        Not sure how to deal with that here since we don't have

# Generated at 2022-06-22 22:19:13.129340
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    with pytest.raises(TypeError):
        check_type_float('test')
    with pytest.raises(TypeError):
        check_type_float(complex(1,1))


# Generated at 2022-06-22 22:19:17.848904
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{"a": "b"}') == '{"a": "b"}'
    assert check_type_jsonarg('{"a": "b", "c": [1, 2, 3]}') == '{"a": "b", "c": [1, 2, 3]}'
    assert check_type_jsonarg(['a', 'b']) == '["a", "b"]'
    assert check_type_jsonarg({'a': 'b'}) == '{"a": "b"}'


# Generated at 2022-06-22 22:19:19.174876
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('foo') == 'foo'



# Generated at 2022-06-22 22:19:22.880213
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('test', {'key': 'value', 'test': 'value'}) == 1



# Generated at 2022-06-22 22:19:25.746642
# Unit test for function check_type_int
def test_check_type_int():
    print("\nEntering test_check_type_int")
    print("\nExiting test_check_type_int")


# Generated at 2022-06-22 22:19:30.379509
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(None) == None
    assert check_type_list(1) == [str(1)]
    assert check_type_list('string') == ['string']
    assert check_type_list([1]) == [1]
    assert check_type_list('1,2,3') == ['1', '2', '3']
    assert check_type_list('1') == ['1']


# Generated at 2022-06-22 22:19:32.604898
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1MB') == 1048576


# Generated at 2022-06-22 22:19:43.075579
# Unit test for function safe_eval
def test_safe_eval():

    # test1: test if returns expected value
    ansible_module_util = AnsibleModuleUtil()
    ansible_module_util.safe_eval = safe_eval
    key = 'foo'
    value = 'True'
    result = ansible_module_util.safe_eval(value)
    if result:
        ansible_module_util.exit_json(changed=True, foo=result)
    ansible_module_util.fail_json(msg="Test 1: The expected value %s was not returned." % value)

    # test2: test if returns expected value
    ansible_module_util = AnsibleModuleUtil()
    ansible_module_util.safe_eval = safe_eval
    key = 'foo'
    value = 'False'

# Generated at 2022-06-22 22:19:44.740934
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(None) == None
    assert check_type_raw(1) == 1



# Generated at 2022-06-22 22:19:51.334686
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int('1') == 1
    assert check_type_int('10') == 10
    assert check_type_int(10) == 10
    try:
        check_type_int('10123d')
    except TypeError:
        assert True
    else:
        assert False
    assert check_type_int(['10123']) == 10123
    assert check_type_int(('10123')) == 10123


# Generated at 2022-06-22 22:20:03.783901
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(1024) == 1024
    assert check_type_bytes("1024") == 1024
    assert check_type_bytes("1K") == 1024
    assert check_type_bytes("1M") == 1024 * 1024
    assert check_type_bytes("1G") == 1024 * 1024 * 1024
    assert check_type_bytes("1.5K") == 1024 + 512
    assert check_type_bytes("1.5M") == 1024 * 1024 + 1024 * 512
    assert check_type_bytes("1.5G") == 1024 * 1024 * 1024 + 1024 * 512 * 1024
    assert check_type_bytes("1T") == 1024 * 1024 * 1024 * 1024
    assert check_type_bytes("1P") == 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes("1E") == 1024 * 1024 * 1024

# Generated at 2022-06-22 22:20:11.145871
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{"key": "value"}') == '{"key": "value"}'
    assert check_type_jsonarg('[1,2,3]') == '[1,2,3]'
    assert check_type_jsonarg(['a', 'b']) == '["a", "b"]'
    assert check_type_jsonarg({'key': 'value'}) == '{"key": "value"}'


# Generated at 2022-06-22 22:20:15.279834
# Unit test for function count_terms
def test_count_terms():
    f = count_terms

    assert f('bar', {'foo': 1, 'bar': 2}) == 1
    assert f(['bar', 'baz'], {'foo': 1, 'bar': 2, 'baz': 3}) == 2
    assert f('blah', {}) == 0



# Generated at 2022-06-22 22:20:23.144199
# Unit test for function check_type_dict
def test_check_type_dict():

    # value as a dict
    print("\nCase 1: value as a dict")
    test_obj = {"a":1, "b":2}
    print(test_obj)
    print(check_type_dict(test_obj))

    # value as a string starting with {
    print("\nCase 2: value as a string starting with {")
    test_obj = "{\"a\":1, \"b\":2}"
    print(test_obj)
    print(check_type_dict(test_obj))

    # value as a string starting with not {
    print("\nCase 3: value as a string starting with not {")
    test_obj = '{"a":1, "b":2}'
    print(test_obj)
    print(check_type_dict(test_obj))

    # value as a

# Generated at 2022-06-22 22:20:32.428063
# Unit test for function check_type_float
def test_check_type_float():
    '''
    check_type_float unit test
    '''
    assert check_type_float(1) == 1
    assert check_type_float('1') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0') == 1.0
    with pytest.raises(TypeError):
        check_type_float(None)
    with pytest.raises(TypeError):
        check_type_float([1])
    with pytest.raises(TypeError):
        check_type_float({'a':1})



# Generated at 2022-06-22 22:20:42.201185
# Unit test for function check_required_one_of
def test_check_required_one_of():
    parameters = {"name": "test", "state": "present"}
    terms = [["name"]]
    results = []
    results = check_required_one_of(terms, parameters)
    assert not results
    parameters = {"name": "test"}
    terms = [["name"], ["state"]]
    results = []
    results = check_required_one_of(terms, parameters)
    assert not results
    parameters = {'name': 'test', 'state': 'present'}
    terms = [['name', 'id'], ['state']]
    results = []
    results = check_required_one_of(terms, parameters)
    assert not results
    parameters = {'name': 'test'}
    terms = [['name', 'id'], ['state']]
    results = []
    results = check_required_

# Generated at 2022-06-22 22:20:45.216704
# Unit test for function count_terms
def test_count_terms():
    d = dict(a=1, b=2, c=3)
    for terms in (['a'], ['d'], ['a', 'a']):
        assert count_terms(terms, d) == len(set(terms).intersection(d))



# Generated at 2022-06-22 22:20:53.752395
# Unit test for function check_required_by
def test_check_required_by():
    data = {'foo': {'required_by': 'bar'}}
    parameters = dict(foo='foo', bar='bar')
    result = check_required_by(data, parameters)
    assert result == {}
    parameters = dict(foo='foo', bar='bar', baz='baz')
    result = check_required_by(data, parameters)
    assert result == {}
    parameters = dict(bar='bar', baz='baz')
    try:
        result = check_required_by(data, parameters)
    except Exception:
        pass
    else:
        assert 1 == 0



# Generated at 2022-06-22 22:21:01.453752
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path("") == ""
    assert check_type_path("/") == "/"
    assert check_type_path("/tmp") == "/tmp"
    assert check_type_path("/tmp/") == "/tmp"
    assert check_type_path("~/") == os.path.expanduser("~")
    assert check_type_path("~/tmp") == os.path.expanduser("~") + "/tmp"
    assert check_type_path("$HOME/") == os.path.expandvars("$HOME")
    assert check_type_path("$HOME/tmp") == os.path.expandvars("$HOME") + "/tmp"
    assert check_type_path("${HOME}/") == os.path.expandvars("${HOME}")
    assert check_

# Generated at 2022-06-22 22:21:09.832264
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(1) == True
    assert check_type_bool('1') == True
    assert check_type_bool('true') == True
    assert check_type_bool('false') == False
    assert check_type_bool('on') == True
    assert check_type_bool('off') == False
    assert check_type_bool('yes') == True
    assert check_type_bool('no') == False
    assert check_type_bool(0) == False
    assert check_type_bool('0') == False
    with pytest.raises(TypeError):
        check_type_bool('test')


# Generated at 2022-06-22 22:21:15.963174
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('/tmp/file.txt') == os.path.expanduser(os.path.expandvars('/tmp/file.txt'))
    assert check_type_path('$HOME/file.txt') == os.path.expanduser(os.path.expandvars('$HOME/file.txt'))
    assert check_type_path('~/file.txt') == os.path.expanduser(os.path.expandvars('~/file.txt'))
    assert check_type_path(None) == os.path.expanduser(os.path.expandvars('None'))


# Generated at 2022-06-22 22:21:23.566339
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('foo') == 'foo'


TYPE_CHECKER = {
    'list': check_type_list,
    'dict': check_type_dict,
    'bool': check_type_bool,
    'int': check_type_int,
    'float': check_type_float,
    'raw': check_type_raw,
    'path': check_type_path,
    'str': check_type_str
}



# Generated at 2022-06-22 22:21:28.911087
# Unit test for function check_required_one_of
def test_check_required_one_of():

    try:
        check_required_one_of([['test', 'new']], {}, ['test'])
        assert False
    except TypeError as e:
        assert to_native(e) == "one of the following is required: test, new found in test"
    try:
        check_required_one_of([['test', 'new']], {'new': 'test'}, ['test'])
        assert True
    except TypeError as e:
        assert False


# Generated at 2022-06-22 22:21:39.122188
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo') == 'foo'
    assert safe_eval('') == ''
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('"foo.bar()"') == 'foo.bar()'
    assert safe_eval('{}') == {}
    assert safe_eval('[]') == []

# Generated at 2022-06-22 22:21:44.211082
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(None) == None
    assert check_type_raw('Yo') == 'Yo'
    assert check_type_raw(3) == 3
    assert check_type_raw([3]) == [3]


# Generated at 2022-06-22 22:21:50.134673
# Unit test for function check_type_bool
def test_check_type_bool():
    '''
    This function tests that the check_type_bool function returns the correct output for different types of input
    '''
    assert check_type_bool(True) == True
    assert check_type_bool('True') == True
    assert check_type_bool(1) == True
    assert check_type_bool('false') == False
    assert check_type_bool(0) == False
    assert check_type_bool('notabool') == False


# Generated at 2022-06-22 22:21:53.561448
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {
        'name' : 'Test-server',
        'host' : 'host-ip',
    }
    terms = [('name', 'host')]
    check_required_together(terms, parameters, options_context=None)


# Generated at 2022-06-22 22:22:02.985551
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1B') == 1
    assert check_type_bytes('10MB') == 10485760
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('2M') == 2097152
    assert check_type_bytes('3K') == 3072
    assert check_type_bytes(2000) == 2000
    assert check_type_bytes('555') == 555
    assert check_type_bytes(555555555) == 555555555
    assert check_type_bytes(555.555) == 555
    assert check_type_bytes('555.555') == 555
    assert check_type_bytes('.555') == 0
    assert check_type_bytes('.55') == 0
    assert check_type_bytes('.55555') == 0

