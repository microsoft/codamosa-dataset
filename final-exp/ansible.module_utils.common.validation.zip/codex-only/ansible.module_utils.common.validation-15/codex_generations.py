

# Generated at 2022-06-22 22:12:11.732125
# Unit test for function check_required_by
def test_check_required_by():
    specifications = {}
    paramters = {}
    assert check_required_by(specifications, paramters) == {}
    specifications = {
        "param1": "param2",
        "param3": ("param2", "param1")
    }
    parameters = {}
    assert check_required_by(specifications, parameters) == {}
    parameters = {
        "param1": "value1",
        "param2": "value2"
    }
    assert check_required_by(specifications, parameters) == {}
    parameters = {
        "param1": "value1"
    }
    try:
        check_required_by(specifications, parameters)
    except TypeError as e:
        assert str(e) == "missing parameter(s) required by 'param1': param2"

# Generated at 2022-06-22 22:12:15.396729
# Unit test for function check_type_bytes
def test_check_type_bytes():
  try:
    answer = 1024
    my_bytes = convert_byte_string_to_bytes(answer)
    assert my_bytes == '1K'
    my_bytes = check_type_bytes(my_bytes)
    assert my_bytes == 1024
  except:
    print('test_check_type_bytes failed')


# Generated at 2022-06-22 22:12:19.710033
# Unit test for function check_required_together
def test_check_required_together():
    """This function is to test check_required_together function"""
    assert check_required_together([['name']],[{'name': 'test'}]) == []
    assert check_required_together([['name', 'duration']],[{'name': 'test'}]) == [['name', 'duration']]
    assert check_required_together([['name', 'duration']],[{'duration': '20'}]) == [['name', 'duration']]


# Generated at 2022-06-22 22:12:25.789371
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(5) == 5
    assert check_type_float(5.3) == 5.3
    assert check_type_float("5") == 5
    assert check_type_float("5.3") == 5.3
    assert check_type_float(u"5") == 5
    assert check_type_float(u"5.3") == 5.3
    assert check_type_float(b"5") == 5
    assert check_type_float(b"5.3") == 5.3
    assert check_type_float(b"test") is None
    assert check_type_float("test") is None
    assert check_type_float(u"test") is None
    assert check_type_float(dict()) is None
    assert check_type_float(list()) is None


# Generated at 2022-06-22 22:12:36.219397
# Unit test for function check_required_if
def test_check_required_if():
    parameters = dict(
        state='present',
        path='/tmp/file.txt',
        bool_param=True,
        string_param='foo',
        someint=99
    )
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    options_context = None
    results = check_required_if(requirements, parameters, options_context)
    assert(len(results) == 0)

    parameters = dict(
        state='present',
        path='/tmp/file.txt',
        bool_param=True,
        someint=99
    )


# Generated at 2022-06-22 22:12:43.946979
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('foo') == 'foo'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": "b"}') == {"a": "b"}
    assert safe_eval('1 + 1') == 2
    assert safe_eval('{"a": "{{var}}"}', dict(var="foo")) == {"a": "foo"}
    assert safe_eval('import foo') == 'import foo'
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('import foo') == 'import foo'



# Generated at 2022-06-22 22:12:47.782918
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(10) == 10
    assert check_type_int("1") == 1
    assert raises(TypeError, check_type_int, ["a", "list"]) is not None


# Generated at 2022-06-22 22:12:54.984543
# Unit test for function check_type_str
def test_check_type_str():
    assert '2' == check_type_str(2)
    assert '2019-09-01' == check_type_str(datetime.date(2019, 9, 1))
    assert '2019-09-01 10:35:10' == check_type_str(datetime.datetime(2019, 9, 1, 10, 35, 10))
    assert 'a' == check_type_str(u'a')
    assert 'a' == check_type_str(b'a')
    with pytest.raises(TypeError):
        check_type_str([])

# Generated at 2022-06-22 22:13:05.632302
# Unit test for function check_type_bool
def test_check_type_bool():
    print(check_type_bool(True))
    print(check_type_bool('1'))
    print(check_type_bool('on'))
    print(check_type_bool('0'))
    print(check_type_bool(0))
    print(check_type_bool('f'))
    print(check_type_bool('false'))
    print(check_type_bool('true'))
    print(check_type_bool('y'))
    print(check_type_bool('t'))
    print(check_type_bool('yes'))
    print(check_type_bool('no'))
    print(check_type_bool('off'))


# Generated at 2022-06-22 22:13:09.722847
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {'a': '1', 'b': '2', 'c': '3'}
    terms = [('a', 'b'), ('b', 'a'), ('b', 'c')]
    if check_required_together(terms, parameters):
        print("check_required_together() pass unit test.")


# Generated at 2022-06-22 22:13:12.505517
# Unit test for function check_type_float
def test_check_type_float():
    assert(check_type_float(1) == 1.0)
    assert(check_type_float('1.2') == 1.2)



# Generated at 2022-06-22 22:13:18.451591
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {
        '<a>': '<b>',
        '<c>': ['<d>', '<e>']
        }
    parameters = {
        '<c>': 1,
        '<d>': 2,
        }
    result = check_required_by(requirements, parameters)
    assert result == {'<c>': ['<e>']}
    parameters['<e>'] = 3
    result = check_required_by(requirements, parameters)
    assert result == {}
    parameters = {
        '<c>': 1,
        }
    result = check_required_by(requirements, parameters)
    assert result == {'<c>': ['<d>', '<e>']}



# Generated at 2022-06-22 22:13:24.481781
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    assert check_missing_parameters(dict(a=1, b=2), ['a', 'b']) == []
    assert_raises(TypeError, check_missing_parameters, dict(a=1, b=2), ['b', 'c'])
    assert check_missing_parameters(dict(a=1, b=2), ['a', 'b', 'c', 'd']) == ['c', 'd']
    assert check_missing_parameters(dict(a=1, b=2), []) == []
    assert check_missing_parameters(dict(), ['a', 'b']) == ['a', 'b']



# Generated at 2022-06-22 22:13:33.665554
# Unit test for function check_required_if

# Generated at 2022-06-22 22:13:36.991591
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    missing_parameters = ['missing_param']
    with pytest.raises(TypeError):
        check_missing_parameters({'param': 'not_missing'}, missing_parameters)



# Generated at 2022-06-22 22:13:40.783760
# Unit test for function check_type_float
def test_check_type_float():
    assert 1.1 == check_type_float(1.1)
    assert 2.2 == check_type_float(2.2)
    assert "3.3" == check_type_float("3.3")
    assert 4.4 == check_type_float(0)
    assert Exception == type(check_type_float(4))


# Generated at 2022-06-22 22:13:50.870198
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('"string"') == "string"
    assert safe_eval("{'a': 'b'}") == {'a': 'b'}
    assert safe_eval("({'a': 'b'}, 'c')") == ({'a': 'b'}, 'c')
    assert safe_eval("'string'") == "string"
    assert safe_eval("'string with embedded \"quotes\"'") == 'string with embedded "quotes"'
    assert safe_eval("'string with embedded \'quotes\''") == "string with embedded 'quotes'"
    assert safe_eval("'string with embedded \"\'quotes\"\''") == 'string with embedded "\'quotes"\''

# Generated at 2022-06-22 22:13:59.802905
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/some/path'}
    errors = check_required_if(requirements, parameters)
    assert len(errors) == 0

    parameters['state'] = 'present'
    parameters['path'] = None
    try:
        check_required_if(requirements, parameters)
        assert False, 'check_required_if should have failed'
    except TypeError as te:
        assert 'path' in te.args[0]

    parameters['state'] = 'absent'

# Generated at 2022-06-22 22:14:09.730493
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg([1, 2, 3]) == '[1, 2, 3]'
    assert check_type_jsonarg((1, 2, 3)) == '(1, 2, 3)'
    assert check_type_jsonarg([]) == '[]'
    assert check_type_jsonarg({}) == '{}'
    assert check_type_jsonarg({'foo': 'bar'}) == '{"foo": "bar"}'
    assert check_type_jsonarg({'foo': 'bar', 'baz': 'qux'}) == '{"foo": "bar", "baz": "qux"}'



# Generated at 2022-06-22 22:14:12.694599
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('item1,item2') == ['item1', 'item2']
    assert check_type_list([1,2,3]) == [1,2,3]
    assert check_type_list(42) == ['42']



# Generated at 2022-06-22 22:14:19.090959
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('a') == 'a'
    assert check_type_str(2, allow_conversion=True) == '2'
    assert check_type_str(2, allow_conversion=False) is None
test_check_type_str()



# Generated at 2022-06-22 22:14:22.531445
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('foo', {'foo': 1, 'bang': 2, 'baz': 3}) == 1
    assert count_terms('foo', {'foo': {'foo': 1}, 'bang': 2, 'baz': 3}) == 1
    assert count_terms(['foo', 'bang'], {'foo': 1, 'bang': 2, 'baz': 3}) == 2



# Generated at 2022-06-22 22:14:27.235455
# Unit test for function check_type_int
def test_check_type_int():
    """Unit test for function check_type_int"""
    assert check_type_int(10) == 10
    assert check_type_int('10') == 10
    assert  check_type_int(10.0) == 10
    assert check_type_int(10.5) == 10
    assert check_type_int('10.5') == 10
    assert check_type_int('hello') == TypeError


# Generated at 2022-06-22 22:14:38.334460
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"json":"test"}') == {"json": "test"}
    with pytest.raises(TypeError) as excinfo:
        check_type_dict('some variable=value')
    assert "dictionary requested, could not parse JSON or key=value" in to_native(excinfo.value)
    assert check_type_dict('some variable=value', allow_conversion=True) == "some variable=value"
    assert check_type_dict('{"json":"test","json2":"2"}') == {"json": "test", "json2": "2"}
    assert check_type_dict('{json="test",json2="2"}') == {"json": "test", "json2": "2"}

# Generated at 2022-06-22 22:14:42.572601
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg([1,2,3]) == b'[1, 2, 3]'
    assert check_type_jsonarg((1,2,3)) == b'[1, 2, 3]'
    assert check_type_jsonarg({'a': 1, 'b': 'c'}) == b'{"a": 1, "b": "c"}'
    assert check_type_jsonarg('hello') == b'"hello"'



# Generated at 2022-06-22 22:14:49.715506
# Unit test for function check_required_by
def test_check_required_by():
    # Tests
    # parameters = dict(
    #     id=1,
    #     name='test',
    #     state='present',
    # )
    # requirements = dict(
    #     id=dict(required_by='name')
    # )
    # options_context = ['module1', 'module1_submodule', 'module2']
    # print(check_required_by(requirements, parameters, options_context))
    pass



# Generated at 2022-06-22 22:14:58.057645
# Unit test for function check_required_if
def test_check_required_if():
    requirements_one_of = [['state', 'absent', ['host', 'port']], ['state', 'present', ['host', 'port']]]
    parameters = {'host': '1.2.3.4', 'port': '80'}
    options_context = ['one_of']
    try:
        check_required_if(requirements_one_of, parameters, options_context)
    except TypeError as e:
        assert "found in one_of" in str(e)
    try:
        check_required_if(requirements_one_of, {'host': '1.2.3.4'}, options_context)
    except TypeError as e:
        assert "found in one_of" in str(e)


# Generated at 2022-06-22 22:15:09.243987
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float('1.3') == 1.3
    assert check_type_float('-1.3') == -1.3
    assert check_type_float('inf') == float('inf')
    assert check_type_float('nan') == float('nan')
    assert check_type_float(1.3) == 1.3
    assert check_type_float(1) == 1.0
    assert check_type_float(-1) == -1.0
    assert check_type_float(0.0) == 0.0
    assert check_type_float(-0.0) == -0.0
    assert check_type_float(float('inf')) == float('inf')
    assert check_type_float(float('nan')) == float('nan')



# Generated at 2022-06-22 22:15:11.113442
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576


# Generated at 2022-06-22 22:15:18.695507
# Unit test for function check_type_raw
def test_check_type_raw():
    from ansible.module_utils import basic
    from ansible.module_utils.common.data_loader import DataLoader
    from ansible.module_utils.common.validation import check_type_raw

    basic._ANSIBLE_ARGS = None
    loader = DataLoader()
    int_value_test = 8
    assert check_type_raw(int_value_test) == int_value_test

    string_value_test = "some_string"
    assert check_type_raw(string_value_test) == string_value_test

    raw_data = loader.load_from_file("tests/test_data/net_command/raw_data.json")
    assert check_type_raw(raw_data) == raw_data



# Generated at 2022-06-22 22:15:21.861990
# Unit test for function count_terms
def test_count_terms():
    params = dict(
        foo=1,
        bar=2,
        baz=3
    )
    assert count_terms('foo', params) == 1
    assert count_terms('foc', params) == 0
    assert count_terms(['foo', 'bar'], params) == 2



# Generated at 2022-06-22 22:15:23.761436
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(1) == ['1']
    assert check_type_list(1.0) == ['1.0']
    assert check_type_list(['a list']) == ['a list']
    assert check_type_list('1,2,3') == ['1', '2', '3']


# Generated at 2022-06-22 22:15:35.015434
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{"a": "a", "b": ["a", 2]}') == '{"a": "a", "b": ["a", 2]}'
    assert check_type_jsonarg('["a", "b", 1]') == '["a", "b", 1]'
    assert check_type_jsonarg({'a': 'a', 'b': ['a', 2]}) == '{"a": "a", "b": ["a", 2]}'
    assert check_type_jsonarg(['a', 'b', 1]) == '["a", "b", 1]'

    with pytest.raises(TypeError):
        assert check_type_jsonarg(0)



# Generated at 2022-06-22 22:15:46.875509
# Unit test for function check_type_bool
def test_check_type_bool():
    if check_type_bool('true') != True:
        raise AssertionError("Failed to convert string to bool")
    if check_type_bool('false') != False:
        raise AssertionError("Failed to convert string to bool")
    if check_type_bool('1') != True:
        raise AssertionError("Failed to convert string to bool")
    if check_type_bool('0') != False:
        raise AssertionError("Failed to convert string to bool")
    if check_type_bool(1) != True:
        raise AssertionError("Failed to convert int to bool")
    if check_type_bool(0) != False:
        raise AssertionError("Failed to convert int to bool")



# Generated at 2022-06-22 22:15:58.029576
# Unit test for function check_required_if
def test_check_required_if():
    import pytest
    from ansible.module_utils.common.text.converters import to_text

    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present'}
    with pytest.raises(TypeError) as err:
        check_required_if(requirements, parameters)
        assert 'missing required arguments: path' in to_text(err.value)

    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'someint': 99}

# Generated at 2022-06-22 22:16:08.320667
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    #assert check_type_int('a') == 'a'
    #assert check_type_int('1a') == '1a'
    #assert check_type_int('a1') == 'a1'
    #assert check_type_int(1.1) == 1.1
    #assert check_type_int('1.1') == '1.1'
    #assert check_type_int('a1.1') == 'a1.1'
    #assert check_type_int('1.1a') == '1.1a'
    assert check_type_int(True) == 1
    assert check_type_int(False) == 0
    #assert check_type_int('1.1a

# Generated at 2022-06-22 22:16:15.933368
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('1') == '1'
    assert check_type_raw(True) is True
    assert check_type_raw(1) == 1


# Generated at 2022-06-22 22:16:27.691153
# Unit test for function check_required_one_of
def test_check_required_one_of():
    test_parameter = {'name': 'test_name', 'type':'test_type'}
    options_context = ["required_one_of"]
    terms = [['type', 'name']]
    # count_terms returns number of terms found in the parameters
    # check_required_one_of should return empty list if at least one term is
    # found.
    try:
        # Valid test case
        check_required_one_of(terms, test_parameter, options_context)
    except TypeError as e:
        # TypeError should not be raised if at least one of the terms is
        # found in parameters.
        assert False, "{0}".format(e)
    # Invalid test case

# Generated at 2022-06-22 22:16:34.500674
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'a': None, 'b': None}
    required_parameters = ['a', 'b', 'c']
    result = check_missing_parameters(parameters, required_parameters)
    assert result == ['c'], 'check_missing_parameters() failed'


# Generated at 2022-06-22 22:16:37.370523
# Unit test for function check_type_bits
def test_check_type_bits():
    try:
        check_type_bits('1Mb')
    except TypeError:
        print('Test failed')
        raise
test_check_type_bits()


# Generated at 2022-06-22 22:16:43.436254
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('a,b,c') == ['a', 'b', 'c']
    assert check_type_list('abc') == ['abc']
    assert check_type_list([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-22 22:16:51.505498
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict({"k": "v"}) == {"k": "v"}
    assert check_type_dict('{"k1": "v1", "k2": "v2"}') == {"k1": "v1", "k2": "v2"}
    assert check_type_dict('k1=v1, k2=v2') == {"k1": "v1", "k2": "v2"}
    assert check_type_dict('k1="v1", k2="v2"') == {"k1": "v1", "k2": "v2"}
    assert check_type_dict('k1=v1 k2=v2') == {"k1": "v1", "k2": "v2"}

# Generated at 2022-06-22 22:17:02.336554
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments({"a": {"required": True}, "b": {"required": True}, "c": {}}, {}) == ['a', 'b']
    assert check_required_arguments({"a": {"required": True}, "b": {"required": True}, "c": {}}, {"b": True}) == ['a']
    assert check_required_arguments({"a": {"required": True}, "b": {"required": True}, "c": {}}, {"b": True, "a": True}) == []
    assert check_required_arguments({"a": {"required": True}, "b": {"required": True}, "c": {}}, {"b": True, "a": True, "c": True}) == []

# Generated at 2022-06-22 22:17:15.150571
# Unit test for function safe_eval
def test_safe_eval():
    import sys
    assert safe_eval("7") == 7
    assert safe_eval("['foo', 'bar']") == ['foo', 'bar']
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval("7", include_exceptions=True) == (7, None)
    assert safe_eval("['foo', 'bar']", include_exceptions=True) == (['foo', 'bar'], None)
    assert safe_eval('{"foo": "bar"}', include_exceptions=True) == ({'foo': 'bar'}, None)
    assert safe_eval("{foo}", include_exceptions=True) == ('{foo}', None)

# Generated at 2022-06-22 22:17:22.884843
# Unit test for function check_type_float

# Generated at 2022-06-22 22:17:32.835417
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'a': {'required': True},
        'b': {'required': False},
        'c': {'required': True},
    }
    parameters = {'a': 1, 'c': 2, 'b': 3}
    # no exception should be raised
    check_required_arguments(argument_spec, parameters)

    # 'a' is required and is missing. An exception should be raised
    parameters = {'b': 2, 'c': 3}
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert to_native(e) == "missing required arguments: a, c"
    else:
        assert False, "TypeError was not raised"



# Generated at 2022-06-22 22:17:34.779040
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int("123") == 123
    assert check_type_int(123) == 123



# Generated at 2022-06-22 22:17:41.824528
# Unit test for function check_required_together
def test_check_required_together():
    parameters = dict(foo=1, bar=2, baz=3)
    # missing parameters
    terms = dict(required_together=[[('foo', 'bar'), ('bar', 'baz')]])
    result = check_required_together(terms.get("required_together"), parameters)
    assert result == []

    # missing parameters
    terms = dict(required_together=[[('foo', 'bar'), ('bar', 'baz'), ('test', 'test_2')]])
    try:
        result = check_required_together(terms.get("required_together"), parameters)
    except TypeError as e:
        assert "the following is required: foo, bar, baz, test, test_2" == str(e)



# Generated at 2022-06-22 22:17:50.874489
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils import basic
    import pytest

    # Test that function is doing what it is supposed to do
    # Test passed arguements
    assert safe_eval(True, include_exceptions=True) == (True, None)
    assert safe_eval(False, include_exceptions=True) == (False, None)
    assert safe_eval('True', include_exceptions=True) == (True, None)
    assert safe_eval('False', include_exceptions=True) == (False, None)
    assert safe_eval('string', include_exceptions=True) == ('string', None)
    assert safe_eval('123', include_exceptions=True) == (123, None)
    assert safe_eval('123.0', include_exceptions=True) == (123.0, None)
    assert safe

# Generated at 2022-06-22 22:18:03.700559
# Unit test for function check_type_bool
def test_check_type_bool():
    cases = [
        ('1', True),
        ('on', True),
        (1, True),
        ('0', False),
        (0, False),
        ('n', False),
        ('f', False),
        ('false', False),
        ('true', True),
        ('y', True),
        ('t', True),
        ('yes', True),
        ('no', False),
        ('off', False),
    ]
    for value, expected_bool in cases:
        msg = '{0!r} should be {1!r}'.format(value, expected_bool)
        assert check_type_bool(value) == expected_bool, msg


# FIXME: The param and prefix parameters here are coming from AnsibleModule._check_type_string()
#        which is using those for the warning messaged based on string

# Generated at 2022-06-22 22:18:11.347440
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('foo') == 'foo'
    assert safe_eval('1+1') == 2
    assert safe_eval('[1,2]') == [1,2]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('None') is None
    assert safe_eval('foo_module.bar()') == 'foo_module.bar()'
    assert safe_eval('1+1', include_exceptions=True) == (2, None)
    assert safe_eval('[1,2]', include_exceptions=True) == ([1,2], None)
    assert safe_eval('{"foo": "bar"}', include_exceptions=True) == ({'foo': 'bar'}, None)

# Generated at 2022-06-22 22:18:12.239905
# Unit test for function check_type_raw
def test_check_type_raw():
    result = check_type_raw('value')
    assert result == 'value'


# Generated at 2022-06-22 22:18:16.316951
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int("5") == 5
    assert check_type_int(5) == 5
    assert check_type_int("5.5") == 5
    assert check_type_int(5.5) == 5
    assert check_type_int("0") == 0
    assert check_type_int(0) == 0


# Generated at 2022-06-22 22:18:26.868928
# Unit test for function check_required_if
def test_check_required_if():
    res = check_required_if([['state', 'present', ('path',), True],
                             [1, 2, ('a',)]],
                            {'state': 'present', 'path': True})
    assert res == []
    with pytest.raises(TypeError):
        check_required_if([['state', 'present', ('path',), True],
                           [1, 2, ('a',)]],
                          {'state': 'present', 'path': False})
    with pytest.raises(TypeError):
        check_required_if([['state', 'present', ('path',)],
                           ['a', 'b', ('c', 'd')]],
                          {'state': 'present'})

# Generated at 2022-06-22 22:18:27.936247
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0



# Generated at 2022-06-22 22:18:32.497561
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{"a": "b"}') == '{"a": "b"}'
    assert check_type_jsonarg({"a": "b"}) == '{"a": "b"}'
    assert check_type_jsonarg(["a", "b"]) == '["a", "b"]'
    with pytest.raises(TypeError) as excinfo:
        check_type_jsonarg(1)
    excinfo.match('1 cannot be converted to a json string')



# Generated at 2022-06-22 22:18:33.829271
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('check_raw') == 'check_raw'
    assert check_type_raw(10) == 10



# Generated at 2022-06-22 22:18:36.160814
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(None) == "None"
    assert check_type_raw(1) == 1
    assert check_type_raw(True) == True
    assert check_type_raw("str") == "str"
    assert check_type_raw({"k1": 1}) == {"k1": 1}


# Generated at 2022-06-22 22:18:38.617219
# Unit test for function check_type_str
def test_check_type_str():
    with pytest.raises(TypeError):
        check_type_str(None)
    assert check_type_str('yes') is 'yes'
    assert check_type_str(True) is 'True'

# Generated at 2022-06-22 22:18:46.581558
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1 Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1 Mb') == 1048576
    assert check_type_bits('1 MB') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1 mb') == 1048576
    assert check_type_bits('1mbit') == 1048576
    assert check_type_bits('1 mbit') == 1048576
    assert check_type_bits('1mbit') == 1048576
    assert check_type_bits('1 mbit') == 1048576
    assert check_type_bits('1 Mb') == 1048576
   

# Generated at 2022-06-22 22:18:51.880995
# Unit test for function check_required_arguments
def test_check_required_arguments():
    spec = dict(
        a=dict(required=True),
        b=dict(required=True),
        c=dict()
    )
    params = dict(a=1)
    missing = check_required_arguments(spec, params)
    assert missing == ['b']



# Generated at 2022-06-22 22:18:54.373074
# Unit test for function check_type_path
def test_check_type_path():
    value = '~/c'
    expected = os.path.expanduser(os.path.expandvars(value))
    assert check_type_path(value) == expected


# Generated at 2022-06-22 22:19:07.283063
# Unit test for function check_required_arguments
def test_check_required_arguments():

    exprect_result = (None,
        [{'required': True, 'default': None, 'type': 'str', 'aliases': ['name', 'schema_name']}],
        [{'required': True, 'default': None, 'type': 'str', 'aliases': ['name', 'schema_name']}],
        [{'name': 'name', 'required': True}, {'name': 'schema_name', 'required': True}])

    my_dict = {'a': 1, 'b': 2}
    test_dict = {}
    test_dict['a'] = my_dict['a']
    result_dict = check_required_arguments(my_dict, test_dict)
    assert result_dict == exprect_result

    test_dict['b'] = my_dict['b']
    result

# Generated at 2022-06-22 22:19:13.944298
# Unit test for function check_required_by
def test_check_required_by():
    # Test 1.
    # Test that it does not throw exception when there is a key in parameters
    # and in the requirements section.
    requirements = {
        'key1': ['foo', 'bar'],
        'key2': ['baz']
    }
    parameters = {
        'key1': 'foo',
        'key2': 'baz'
    }
    result = check_required_by(requirements, parameters)
    assert not result

    # Test 2.
    # Test that it throws exception when there is a key in parameters
    # but not in the requirements section.
    requirements = {
        'key1': ['foo', 'bar'],
        'key2': ['baz']
    }

# Generated at 2022-06-22 22:19:23.573315
# Unit test for function check_required_arguments
def test_check_required_arguments():
    def check_success(params, module_params=None):
        parameter_spec = {'param1': {'required': True},
                          'param2': {'required': False},
                          'param3': {'required': False}}
        assert [] == check_required_arguments(parameter_spec, params, module_params)

    def check_failure(params, module_params=None):
        parameter_spec = {'param1': {'required': True, 'type': 'str'},
                          'param2': {'required': False},
                          'param3': {'required': False}}
        try:
            check_required_arguments(parameter_spec, params, module_params)
        except TypeError as e:
            assert e.args[0] == "missing required arguments: param1"

# Generated at 2022-06-22 22:19:32.575736
# Unit test for function check_required_one_of
def test_check_required_one_of():
    params = {'name': 'test_name', 'state': 'absent', 'arg1':'test1', 'arg2':'test2', 'arg3':'test3'}
    not_satisfied = [['name','state'],['arg1','arg2','arg3']]
    assert [] == check_required_one_of(not_satisfied,params)
    satisfied = [['name','state'],['arg','arg2','arg1']]

# Generated at 2022-06-22 22:19:36.860258
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {"a": "b", "c": "d"}
    terms = (("a", "b"), ("b", "c"))
    result = check_required_together(terms,parameters)
    assert result == []


# Generated at 2022-06-22 22:19:47.042278
# Unit test for function check_type_float
def test_check_type_float():
    check_type_float(12)
    assert check_type_float("12.0") == 12.0
    assert check_type_float(12.0) == 12.0
    assert check_type_float(b"12.0") == 12.0
    assert check_type_float(u"12.0") == 12.0
    assert check_type_float(u"12") == 12
    assert check_type_float(b"12") == 12
    #assert check_type_float(12.0) == 12
    with pytest.raises(TypeError):
        check_type_float(None)
    with pytest.raises(TypeError):
        check_type_float("hello")
    with pytest.raises(TypeError):
        check_type_float("12.0.0")
   

# Generated at 2022-06-22 22:19:50.532803
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    with raises(TypeError):
        assert check_type_int('a')



# Generated at 2022-06-22 22:20:03.204729
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('abc') == 'abc'
    assert check_type_str(u'abc') == 'abc'
    assert check_type_str(b'abc') == 'abc'

    assert check_type_str({'foo': 'bar'}) == "{'foo': 'bar'}"
    assert check_type_str(['foo', 'bar']) == "['foo', 'bar']"
    assert check_type_str(('foo', 'bar')) == "('foo', 'bar')"

    assert check_type_str(['foo', 1]) == "['foo', 1]"
    assert check_type_str(['foo', 1], allow_conversion=False) == "['foo', 1]"

# Generated at 2022-06-22 22:20:14.791262
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('[ "a", "b", "c" ]') == '[ "a", "b", "c" ]'
    assert check_type_jsonarg('{"a": "1", "b": "2"}') == '{"a": "1", "b": "2"}'
    assert check_type_jsonarg(['a', 'b', 'c']) == '[ "a", "b", "c" ]'
    assert check_type_jsonarg({'a': '1', 'b': '2'}) == '{"a": "1", "b": "2"}'
    assert check_type_jsonarg( ('a', 'b', 'c') ) == '[ "a", "b", "c" ]'
    assert check_type_jsonarg( {1: '1', 2: '2'} )

# Generated at 2022-06-22 22:20:19.629085
# Unit test for function check_type_float
def test_check_type_float():
    f = check_type_float
    assert f(1.23) == 1.23
    assert f('1.23') == 1.23
    assert f(b'1.23') == 1.23
    assert f(1) == 1.0
    try:
        f(None)
    except TypeError:
        pass
    else:
        assert False, "TypeError should have been raised"



# Generated at 2022-06-22 22:20:24.120685
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576 * 8
    try:
        check_type_bits('1')
    except TypeError:
        pass


# Generated at 2022-06-22 22:20:34.179233
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{}') == {}
    assert safe_eval('1') == 1
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1, "foo", False]') == [1, "foo", False]
    assert safe_eval('(1, "foo", False)') == (1, "foo", False)
    assert safe_eval('{1:False,"foo":[1]}') == {1: False, "foo": [1]}

    # input is evaluated string, not casted
    assert safe_eval('{"foo":"bar"}') == {"foo":"bar"}
    assert safe_eval('foo') == 'foo'



# Generated at 2022-06-22 22:20:42.991427
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [["a", "b", "c"]]
    parameters = {"a": 1, "b": 2}
    result = check_required_one_of(terms, parameters)
    assert result == []
    parameters = {"a": []}
    result = check_required_one_of(terms, parameters)
    assert result == []
    parameters = {"d": 1}
    try:
        check_required_one_of(terms, parameters)
    except TypeError as msg:
        assert 'required' in to_native(msg)
    else:
        raise Exception("TypeError Not Raised")
    terms = [["a", "b", "c"], ["test", "one"]]
    result = check_required_one_of(terms, parameters)
    assert result == []
    parameters = {"test": "one"}
   

# Generated at 2022-06-22 22:20:53.906748
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('[{"key": "value"}]') == '[{"key": "value"}]'
    assert check_type_jsonarg('{"key": "value"}') == '{"key": "value"}'
    assert check_type_jsonarg(['{"key": "value"}']) == '["{\\"key\\": \\"value\\"}"]'
    assert check_type_jsonarg(['key', 'value']) == '["key", "value"]'
    assert check_type_jsonarg(('key', 'value')) == '["key", "value"]'
    assert check_type_jsonarg({'key': 'value'}) == '{"key": "value"}'



# Generated at 2022-06-22 22:20:55.981913
# Unit test for function check_type_path
def test_check_type_path():
    path = "/tmp/foo/bar"
    result = check_type_path(path)
    assert isinstance(result, string_types)
    assert path == result


# Generated at 2022-06-22 22:21:04.784890
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'somekey': 'some_value'}
    required_parameters = ['somekey']
    # Check that parameters is a dictionary
    with pytest.raises(TypeError) as exec_info:
        check_missing_parameters('invalid', required_parameters)
    assert 'must be of type' in str(exec_info.value)
    # Check that required_parameters is a list
    with pytest.raises(TypeError) as exec_info:
        check_missing_parameters(parameters, 'invalid')
    assert 'must be of type' in str(exec_info.value)
    # Check that all required parameters are present in parameters
    with pytest.raises(TypeError) as exec_info:
        check_missing_parameters(parameters, ['some_new_key'])


# Generated at 2022-06-22 22:21:13.871774
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('""') == '""'
    assert check_type_jsonarg('"foo"') == '"foo"'
    assert check_type_jsonarg('["a","b"]') == '["a","b"]'
    assert check_type_jsonarg(['a','b']) == '["a", "b"]'
    assert check_type_jsonarg(('a','b')) == '["a", "b"]'
    assert check_type_jsonarg({'a':'b'}) == '{"a": "b"}'
    assert check_type_jsonarg(['a', {'b':'c'}]) == '["a", {"b": "c"}]'

# Generated at 2022-06-22 22:21:18.304594
# Unit test for function check_type_raw
def test_check_type_raw():
    assert type(check_type_raw(1)) is int
    assert type(check_type_raw("test")) is str
    assert type(check_type_raw(True)) is bool
    assert type(check_type_raw({})) is dict
    assert type(check_type_raw([])) is list


# Generated at 2022-06-22 22:21:28.560190
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg("") == ""
    assert check_type_jsonarg("abc") == "abc"
    assert check_type_jsonarg("{}") == "{}"
    assert check_type_jsonarg("[]") == "[]"

    assert check_type_jsonarg("{ \"a\": \"b\" }") == "{ \"a\": \"b\" }"
    assert check_type_jsonarg("{ \"a\": \"b\"}") == "{ \"a\": \"b\"}"
    assert check_type_jsonarg("{\"a\": \"b\" }") == "{\"a\": \"b\" }"
    assert check_type_jsonarg("{\"a\": \"b\"}") == "{\"a\": \"b\"}"

    assert check_type_jsonarg("[1,2,3]") == "[1,2,3]"

# Generated at 2022-06-22 22:21:33.370812
# Unit test for function check_type_float
def test_check_type_float():
    # Test 1, int
    num1 = 321
    assert check_type_float(num1) == num1

    # Test 2, float
    num2 = 321.123
    assert check_type_float(num2) == num2

    # Test 3, string
    num3 = "123.321"
    assert check_type_float(num3) == float(num3)

    # Test 4, binary
    num4 = b"123.321"
    assert check_type_float(num4) == float(num4)

    # Test 5, string
    num5 = "321"
    assert check_type_float(num5) == float(num5)

    # Test 6, binary
    num6 = b"321"
    assert check_type_float(num6) == float(num6)


# Generated at 2022-06-22 22:21:38.884646
# Unit test for function check_type_path
def test_check_type_path():
    assert 'c:\\temp' == check_type_path('c:\\temp')
    assert 'c:\\temp' == check_type_path(b'c:\\temp')
    assert 'c:\\temp' == check_type_path(b'c:\\temp')
    assert 'c:\\temp' == check_type_path('c:/temp')
    assert 'c:\\temp' == check_type_path(b'c:/temp')
    assert 'c:\\temp' == check_type_path('$TEMP/temp')
    assert 'c:\\temp' == check_type_path(b'$TEMP/temp')
    assert 'c:\\temp' == check_type_path('${TEMP}/temp')

# Generated at 2022-06-22 22:21:48.272004
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments({"test": {"required": True}}, {"test": 1}) == []
    assert check_required_arguments({"test": {"required": True}}, {"TEST": 1}) == []
    assert check_required_arguments({"test": {"required": True}}, {"test": None}) == []
    assert check_required_arguments({"test": {"required": True}}, {}) == ["test"]
    assert check_required_arguments({"test": {"required": False}}, {}) == []

# end of unit test for check_required_arguments



# Generated at 2022-06-22 22:21:58.215517
# Unit test for function check_required_one_of
def test_check_required_one_of():
    result = type_check.check_required_one_of([['test', 'tst']], {})
    assert result == [('test', 'tst')]
    result = type_check.check_required_one_of([['test', 'tst']], {'test': 'test'})
    assert result == []
    result = type_check.check_required_one_of([['test', 'tst']], {'tst': 'tst'})
    assert result == []
    result = type_check.check_required_one_of([['test', 'tst']], {'tst': 'tst', 'test': 'test'})
    assert result == []

# Generated at 2022-06-22 22:22:09.787631
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('true') == True
    assert check_type_bool('false') == False
    assert check_type_bool('on') == True
    assert check_type_bool('off') == False
    assert check_type_bool('1') == True
    assert check_type_bool('0') == False
    assert check_type_bool(1) == True
    assert check_type_bool(0) == False
    assert check_type_bool('t') == True
    assert check_type_bool('f') == False
    assert check_type_bool('y') == True
    assert check_type_bool('yes') == True
    assert check_type_bool('n') == False
    assert check_type_bool('no') == False
