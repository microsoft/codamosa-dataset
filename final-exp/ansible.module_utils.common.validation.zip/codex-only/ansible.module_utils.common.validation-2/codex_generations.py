

# Generated at 2022-06-22 22:12:05.998196
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("['foo', 'bar', 'baz']") == ['foo', 'bar', 'baz']
    # Uses literal_eval, so not actually safe since we can import os
    assert safe_eval("__import__('os').system('echo Hi from safe_eval')") == "__import__('os').system('echo Hi from safe_eval')"
    # literal_eval prohibits method calls
    assert safe_eval("'hi'.upper()") == "'hi'.upper()"


# Generated at 2022-06-22 22:12:15.721277
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    assert [] == check_missing_parameters({'some_param': 'some_value'})
    assert [] == check_missing_parameters({'some_param': 'some_value'}, None)
    assert [] == check_missing_parameters({'some_param': 'some_value'}, [])
    assert ['some_param'] == check_missing_parameters({'No_some_param': 'some_value'}, ['some_param'])
    assert ['some_param', 'some_param1'] == check_missing_parameters({'No_some_param': 'some_value'}, ['some_param', 'some_param1'])
    assert ['some_param'] == check_missing_parameters({}, ['some_param'])



# Generated at 2022-06-22 22:12:23.957553
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{'test': 'dict'}") == {'test': 'dict'}
    assert check_type_dict("{'test': 'dict', 'another': 'key'}") == {'test': 'dict', 'another': 'key'}
    assert check_type_dict("'test': 'dict'}") == {'test': 'dict'}
    assert check_type_dict("test='dict'") == {'test': 'dict'}
    assert check_type_dict("test='dict', another='key'") == {'test': 'dict', 'another': 'key'}
    assert check_type_dict("test='dict', another='key\\'s'") == {'test': 'dict', 'another': "key's"}

# Generated at 2022-06-22 22:12:32.859297
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['name', 'state']]
    parameters = {
        'name': 'test',
        'state': 'present'
    }

    # This one should pass
    assert len(check_required_together(terms, parameters)) == 0

    # This one should fail
    parameters = {
        'name': 'test',
        'state': 'present',
        'test': 'test'
    }
    try:
        check_required_together(terms, parameters)
        assert False, 'Should be an exception.'
    except TypeError as e:
        assert 'parameters are required together: name, state' in to_native(e)

    # This one should also fail
    parameters = {
        'name': 'test'
    }

# Generated at 2022-06-22 22:12:41.038101
# Unit test for function check_type_str
def test_check_type_str():

   # Verify that a string that is a string is a string
   assert check_type_str('string') == 'string'

   # Verify that a string that is not a string is converted to a string
   assert check_type_str(42) == '42'
   assert check_type_str(True) == 'True'

   # Verify that a string that is not a string is not converted to a string when conversion is not allowed
   assert check_type_str(42, False) == '42'
   assert check_type_str(True, False) == 'True'

# Generated at 2022-06-22 22:12:49.377700
# Unit test for function check_required_if
def test_check_required_if():
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.common.validation import check_required_if

    # case 1: missing required parameter at all
    parameters = {}
    requirements = [['test_parameter', 'test_value', ['requirement_1', 'requirement_2']],
                    ['test_parameter1', 'test_value1', ['requirement_11', 'requirement_12']]]
    assert check_required_if(requirements, parameters) == []

    # case 2: missing required parameter when parameter is specified
    parameters = {'test_parameter': 'test_value'}

# Generated at 2022-06-22 22:12:50.681642
# Unit test for function check_type_bool
def test_check_type_bool():
    pass



# Generated at 2022-06-22 22:12:51.980385
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('valid') == 'valid'



# Generated at 2022-06-22 22:12:56.505396
# Unit test for function check_type_raw
def test_check_type_raw():
    for i in range(0, 5):
        assert check_type_raw(i) == i
        assert check_type_raw("%s" % i) == i
    assert check_type_raw(True)
    assert check_type_raw("True")
    assert check_type_raw(False)
    assert check_type_raw("False")


# Generated at 2022-06-22 22:13:02.870904
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(True) is True
    assert check_type_raw(False) is False
    assert check_type_raw(0) == 0
    assert check_type_raw(1) == 1
    assert check_type_raw(b'foo') == b'foo'
    assert check_type_raw('foo') == 'foo'



# Generated at 2022-06-22 22:13:07.845275
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('state', {'state': 'present', 'header': 'something'}) == 1
    assert count_terms(['state', 'header'], {'state': 'present'}) == 1
    assert count_terms(['state', 'header'], {'state': 'present', 'header': 'something'}) == 2



# Generated at 2022-06-22 22:13:15.949935
# Unit test for function check_required_together
def test_check_required_together():
    '''check_required_together function tests'''
    params = dict(a="a", b="b")
    res = check_required_together([('a', 'b'), ('c', 'd')], params)
    assert res == [], res

    params = dict(a="a", b="b", c="c")
    res = check_required_together([('a', 'b'), ('b', 'c')], params)
    assert res == [], res

    params = dict(a="a")
    res = check_required_together([('a', 'b'), ('b', 'c')], params)
    assert res == [('b', 'c')], res

    params = dict(a="a", c="c")
    res = check_required_together([('a', 'b'), ('b', 'c')], params)


# Generated at 2022-06-22 22:13:26.473912
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg(dict(a=1, b=2)) == '{"a": 1, "b": 2}'
    assert check_type_jsonarg(jsonify(dict(a=1, b=2))) == '{"a": 1, "b": 2}'
    assert check_type_jsonarg("{\"a\":1,\"b\":2}") == '{"a": 1, "b": 2}'
    assert check_type_jsonarg("{a:1,b:2}") == '{"a": 1, "b": 2}'
    assert check_type_jsonarg(['a', 'b']) == '["a", "b"]'
    assert check_type_jsonarg(jsonify(["a", "b"])) == '["a", "b"]'
    assert check_type_json

# Generated at 2022-06-22 22:13:36.378672
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1KB') == 1024
    assert check_type_bytes('1 Kb') == 1024
    assert check_type_bytes('1 kB') == 1024
    assert check_type_bytes('1kb') == 1024
    assert check_type_bytes('1km') == 1024000
    assert check_type_bytes('1KiB') == 1024
    assert check_type_bytes('1kb') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1mb') == 1048576
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1mb') == 1048576
    assert check_type_bytes('1gb') == 1073741824
    assert check_type_bytes('1 gib') == 107374

# Generated at 2022-06-22 22:13:43.781566
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # Test with parameters is None
    with pytest.raises(TypeError) as te:
        check_missing_parameters(parameters=None, required_parameters=["param1", "param2"])
    assert "'param1'" in to_text(te.value)
    assert "parameters are required" in to_text(te.value)

    # Test with required_parameters is None
    assert check_missing_parameters(parameters={}, required_parameters=None) == []

    # Test with required_parameters is empty list
    assert check_missing_parameters(parameters={}, required_parameters=[]) == []

    # Test with all required parameters exist

# Generated at 2022-06-22 22:13:50.834408
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('count', []) == 0
    assert count_terms('count', ['count']) == 1
    assert count_terms('count', ['test']) == 0
    assert count_terms(['counT', 'test'], ['test']) == 1
    assert count_terms(['counT', 'test', 'count'], ['test', 'count']) == 2


# Generated at 2022-06-22 22:13:52.777508
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw("testing") == "testing"


# Generated at 2022-06-22 22:14:00.745574
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg("foobar") == "foobar"
    assert check_type_jsonarg("'foo.bar'") == "\"foo.bar\""
    assert check_type_jsonarg("{'key': 'value'}") == "{\n    \"key\": \"value\"\n}"
    assert check_type_jsonarg("[1, 2, 3]") == "[\n    1, \n    2, \n    3\n]"
    assert check_type_jsonarg([1, 2, 3]) == "[\n    1, \n    2, \n    3\n]"
    assert check_type_jsonarg({"key": "value"}) == "{\n    \"key\": \"value\"\n}"
    assert check_type_jsonarg({"key": ["value1", "value2"]})

# Generated at 2022-06-22 22:14:11.758815
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Since check_mutually_exclusive is used in AnsibleModule.__init__, it
    # depends on objects which are not available during unittest.
    # To skip the unit test of check_mutually_exclusive,
    # we have to raise 'SkipTest' exception.
    # See the following references.
    #
    # - https://docs.pytest.org/en/latest/skipping.html
    # - https://docs.pytest.org/en/latest/skipping.html#skipping-during-collect
    raise unittest.SkipTest('skip unit test for check_mutually_exclusive')

    # Test for groups of mutually exclusive parameters
    # Parameters: a=1, b=1 => Failed
    # Parameters: a=1,         => Success
    # Parameters:     b=1,     => Success
    test_

# Generated at 2022-06-22 22:14:22.198340
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('{"bar": "foo"}') == {'bar': 'foo'}
    assert safe_eval('1 + 2 * 3') == 7
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('import foo') == 'import foo'
    # The following two should raise an exception if called directly, but no
    # exception should be raised when called through safe_eval.
    assert safe_eval('"foo" + "bar"') == 'foobar'
    assert safe_eval

# Generated at 2022-06-22 22:14:30.248048
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('1,2,3') == ['1', '2', '3']
    assert check_type_list('1,2,3') != ['1', '2', '3', '4']
    assert check_type_list(1) != [1,2,3]
    assert check_type_list(1) == ['1']
    assert check_type_list(['1', 2, 3]) == ['1', 2, 3]
    assert check_type_list([1, 2, 3]) != ['1', 2, 3]
    assert check_type_list(1.1) != ['1', 2, 3]
    assert check_type_list(1.1) == ['1.1']

# FIXME: The param and prefix parameters here are coming from AnsibleModule._check_type_bool()


# Generated at 2022-06-22 22:14:40.669834
# Unit test for function check_required_together
def test_check_required_together():
    # Parameters
    parameters = dict(param1='one', param2='two', param3='three')
    # test 1
    terms1 = [('param1','param2','param3')]
    result = check_required_together(terms1, parameters)
    assert result is not None

    # test 2
    terms2 = [('param1', 'param2'),('param3', 'param1')]
    result = check_required_together(terms2, parameters)
    assert result is not None

    # test 3
    terms3 = [('param3', 'param4'), ('param5', 'param1')]
    result = check_required_together(terms3, parameters)
    assert result is not None

    # test 4
    parameters4 = dict(param1='one', param4='four')

# Generated at 2022-06-22 22:14:44.365011
# Unit test for function check_type_float
def test_check_type_float():
    assert (check_type_float(1) == 1.0)
    assert (check_type_float(1.1) == 1.1)
    assert (check_type_float('1.1') == 1.1)
    assert (check_type_float(b'1.1') == 1.1)
    assert (check_type_float('a') == 1.0)



# Generated at 2022-06-22 22:14:51.225206
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(['test'], {'test': 1}) == 1
    assert count_terms(['test'], {}) == 0
    assert count_terms(['test', 'test2'], {'test': 1}) == 1
    assert count_terms(['test', 'test2'], {'test': 1, 'test2': 2}) == 2
    assert count_terms(['test', 'test2'], {'test': 1, 'test3': 2}) == 1


# Generated at 2022-06-22 22:15:00.581186
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments({'key1': {'required': True}}, {'key1': 'value1'}) == []
    assert check_required_arguments({'key1': {'required': True}}, {}) == ['key1']
    assert check_required_arguments({'key1': {'required': True}, 'key2': {'required': False}}, {}) == ['key1']
    assert check_required_arguments({'key1': {'required': True}}, {'key1': 'value1', 'key2': 'value2'}) == []



# Generated at 2022-06-22 22:15:09.752121
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('100') == 100
    assert check_type_bytes('1T') == 1024 * 1024 * 1024 * 1024 * 1
    assert check_type_bytes('1KB') == 1000 * 1
    assert check_type_bytes('1MB') == 1000 * 1000 * 1
    assert check_type_bytes('1GB') == 1000 * 1000 * 1000 * 1
    assert check_type_bytes('1TB') == 1000 * 1000 * 1000 * 1000 * 1
    assert check_type_bytes('1PB') == 1000 * 1000 * 1000 * 1000 * 1000 * 1


# Functions for complex_args, complex_args_parsed and complex_args_missing

# Generated at 2022-06-22 22:15:13.285055
# Unit test for function check_type_int
def test_check_type_int():
    assert isinstance(check_type_int(1), integer_types), "1 is an integer"
    assert isinstance(check_type_int('1'), integer_types), "'1' is an integer"
    with pytest.raises(TypeError):
        check_type_int('A')
test_check_type_int()



# Generated at 2022-06-22 22:15:19.745922
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path("/path/to/file") == "/path/to/file"
    with pytest.raises(TypeError) as error_obj:
        check_type_path("/path/to/file/%s")
    assert "cannot be converted to a string" in str(error_obj.value)



# Generated at 2022-06-22 22:15:24.853819
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('a', {'a': 1, 'b': 2, 'c': 3}) == 1
    assert count_terms(['a', 'b'], {'a': 1, 'b': 2, 'c': 3}) == 2
    assert count_terms(['a', 'b', 'c', 'd'], {'a': 1, 'b': 2, 'c': 3}) == 3



# Generated at 2022-06-22 22:15:35.256784
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = dict(
        foo=None,
        bar="present",
        baz=123,
    )
    # Test when all required parameters are present
    result = check_missing_parameters(parameters, ["foo", "bar"])
    assert result == []

    # Test when some required parameters are missing
    try:
        check_missing_parameters(parameters, ["foo", "bur"])
    except TypeError as e:
        assert str(e) == "missing required arguments: bur"

    # Test when no parameters are missing
    result = check_missing_parameters(parameters, [])
    assert result == []



# Generated at 2022-06-22 22:15:47.278438
# Unit test for function check_required_one_of
def test_check_required_one_of():
    parms = {}

    try:
        result = check_required_one_of([['a', 'b']], parms)
    except TypeError as e:
        print(e)
        assert e

    parms = {'a': 1}
    result = check_required_one_of([['a', 'b']], parms)
    assert result == []

    parms = {'b': 1}
    result = check_required_one_of([['a', 'b']], parms)
    assert result == []

    parms = {'c': 1}
    try:
        result = check_required_one_of([['a', 'b']], parms)
    except TypeError as e:
        print(e)
        assert e

    parms = {}

# Generated at 2022-06-22 22:15:58.574980
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('data/test.txt') == 'data/test.txt'
    assert check_type_path(u'data/test.txt') == u'data/test.txt'
    assert check_type_path('/data/test.txt') == '/data/test.txt'
    assert check_type_path(u'/data/test.txt') == u'/data/test.txt'
    assert check_type_path('~/data/test.txt') == os.path.expanduser('~/data/test.txt')
    assert check_type_path(u'~/data/test.txt') == os.path.expanduser(u'~/data/test.txt')

# Generated at 2022-06-22 22:16:08.552924
# Unit test for function check_type_bool
def test_check_type_bool():
    x=True
    y=False
    print(x)
    print(y)
    assert x
    assert not y
    assert check_type_bool('1') == True
    assert check_type_bool('on') == True
    assert check_type_bool('0') == False
    assert check_type_bool('n') == False
    assert check_type_bool('f') == False
    assert check_type_bool('false') == False
    assert check_type_bool('true') == True
    assert check_type_bool('y') == True
    assert check_type_bool('t') == True
    assert check_type_bool('yes') == True
    assert check_type_bool('no') == False
    assert check_type_bool('off') == False


# Generated at 2022-06-22 22:16:16.105116
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('foo') == os.path.expanduser(os.path.expandvars('foo'))
    assert check_type_path('foo{0}bar'.format(os.path.sep)) == os.path.expanduser(os.path.expandvars('foo{0}bar'.format(os.path.sep)))
    assert check_type_path('/foo') == os.path.expanduser(os.path.expandvars('/foo'))
    assert check_type_path(r'C:\foo') == os.path.expanduser(os.path.expandvars(r'C:\foo'))
    assert check_type_path('c:foo') == os.path.expanduser(os.path.expandvars('c:foo'))


# Generated at 2022-06-22 22:16:27.891354
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True) == True
    assert check_type_bool('1') == True
    assert check_type_bool('on') == True
    assert check_type_bool('true') == True
    assert check_type_bool('t') == True
    assert check_type_bool('y') == True
    assert check_type_bool('yes') == True
    assert check_type_bool(1) == True
    assert check_type_bool(False) == False
    assert check_type_bool('0') == False
    assert check_type_bool('off') == False
    assert check_type_bool('false') == False
    assert check_type_bool('n') == False
    assert check_type_bool('f') == False
    assert check_type_bool(0) == False



# Generated at 2022-06-22 22:16:40.261087
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('0') is False
    assert check_type_bool(0) is False
    assert check_type_bool('n') is False
    assert check_type_bool('f') is False
    assert check_type_bool('false') is False
    assert check_type_bool('1') is True
    assert check_type_bool(1) is True
    assert check_type_bool('on') is True
    assert check_type_bool('y') is True
    assert check_type_bool('t') is True
    assert check_type_bool('true') is True
    assert check_type_bool('yes') is True
    assert check_type_bool('no') is False
    assert check_type_bool('off') is False

# Generated at 2022-06-22 22:16:41.475110
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-22 22:16:46.280708
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(1) == 1
    assert check_type_raw(1.2) == 1.2
    assert check_type_raw("hello") == "hello"
    assert check_type_raw([1, 2, 3]) == [1, 2, 3]
    assert check_type_raw({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}


# Generated at 2022-06-22 22:16:51.447225
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('test', {'test': 'a', 'test2': 'b', 'test3': 'c'}) == 1
    assert count_terms('test', {'test': 'a', 'test2': 'b', 'test': 'c'}) == 1
    assert count_terms(['test', 'test2'], {'test': 'a', 'test2': 'b', 'test3': 'c'}) == 2
    assert count_terms(['test', 'test2', 'test4'], {'test': 'a', 'test2': 'b', 'test3': 'c'}) == 2
    assert count_terms(['test', 'test2', 'test4'], {}) == 0



# Generated at 2022-06-22 22:16:56.879614
# Unit test for function check_type_dict
def test_check_type_dict():
    some_dict = {"key1":"value1","key2":"value2"}
    test_string = {"key1":"value1","key2":"value2"}
    test_string1 = "key1=value1, key2=value2"
    test_string2 = "key1='value1', key2='value2'"
    test_string3 = 'key1="value1", key2="value2"'
    test_string4 = "key1='value1', key2='value2',key3='value3,value3a'"
    test_string5 = "key1='value1', key2='value2',key3='value3,value3a',key4='value4',key5='value5'"

# Generated at 2022-06-22 22:17:07.475263
# Unit test for function check_type_str
def test_check_type_str():
    assert(check_type_str('test_string') == 'test_string')
    assert(check_type_str(u'test_unicode') == u'test_unicode')
    assert(check_type_str(u'test_unicode', allow_conversion=True) == u'test_unicode')
    assert(check_type_str(b'test_bytes', allow_conversion=True) == u'test_bytes')
    assert(check_type_str(123) == '123')
    assert(check_type_str(123, allow_conversion=True) == '123')
    assert(check_type_str(123, allow_conversion=False) == '123')
    with pytest.raises(TypeError):
        check_type_str(123, allow_conversion=False)
   

# Generated at 2022-06-22 22:17:10.071573
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str("good") == "good"
    assert check_type_str(42) == "42"
    with pytest.raises(TypeError):
        check_type_str(42, False)



# Generated at 2022-06-22 22:17:17.286169
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    json_string = "{'a': 'test', 'b': [1, 2, 3]}"
    json_dict = {'a': 'test', 'b': [1, 2, 3]}
    json_list = ['a', 'test', 'b', [1, 2, 3]]

    assert check_type_jsonarg(json_string) == json_string
    assert check_type_jsonarg(json_dict) == json_string
    assert check_type_jsonarg(json_list) == json_string



# Generated at 2022-06-22 22:17:19.978800
# Unit test for function check_required_one_of
def test_check_required_one_of():
    parameter = {'a': 'a', 'b': 'b'}
    check_required_one_of([['a', 'x'], ['x', 'y']], parameter)



# Generated at 2022-06-22 22:17:25.451702
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # No parameters given
    assert check_missing_parameters({}, ['foo', 'spam']) == []
    # 1 required parameter missing
    assert check_missing_parameters({'foo': 'foo_value'}, ['foo', 'spam']) == ['spam']



# Generated at 2022-06-22 22:17:32.111934
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    assert [] == check_missing_parameters({'a': 1, 'b': 2}, ['a'])
    try:
        check_missing_parameters({'a': 1, 'b': 2}, ['a', 'c'])
        assert False
    except TypeError as e:
        assert 'missing required arguments: c' in to_native(e)



# Generated at 2022-06-22 22:17:35.507742
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(0) == 0
    assert check_type_raw([0]) == [0]
    assert check_type_raw(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert check_type_raw('a') == 'a'



# Generated at 2022-06-22 22:17:38.848414
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(['test1', 'test3'], {'test1': 'test1', 'test2': 'test2', 'test3': 'test3'}) == 2
    assert count_terms(['test1', 'test4'], {'test1': 'test1', 'test2': 'test2', 'test3': 'test3'}) == 1



# Generated at 2022-06-22 22:17:41.595924
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('$HOME/test') == os.path.join(os.environ['HOME'],'test')
    with pytest.raises(TypeError) as exc:
        check_type_path(['a', 'b', 'c'])
    assert "cannot be converted to a string" in str(exc)



# Generated at 2022-06-22 22:17:50.312189
# Unit test for function check_type_str
def test_check_type_str():
    """
    Function check_type_str() test cases
    """
    # Try to convert a non-string type to string
    assert check_type_str("123") == "123"
    assert check_type_str(12345) == "12345"
    assert check_type_str(None) == "None"

    # Try to convert a non-string type to string but conversion is not allowed
    try:
        check_type_str(12345, allow_conversion=False)
        assert False, "  >>  Failed to raise TypeError for 12345"
    except TypeError:
        pass

    # Try to convert a non-string type pointing to a string to string
    assert check_type_str(["text"]) == "[\"text\"]"


# Generated at 2022-06-22 22:18:00.434664
# Unit test for function check_type_dict
def test_check_type_dict():
    try:
        check_type_dict({'a': 1, 'b': 2})
        assert True
    except TypeError:
        assert False

    try:
        check_type_dict('a=1, b=2, c=3')
        assert True
    except TypeError:
        assert False

    try:
        check_type_dict('a=1')
        assert True
    except TypeError:
        assert False

    try:
        check_type_dict('"a=1, b=2, c=3"')
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-22 22:18:09.348640
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True)
    assert not check_type_bool(False)
    assert check_type_bool('True')
    assert check_type_bool('true')
    assert check_type_bool('t')
    assert check_type_bool('y')
    assert check_type_bool('yes')
    assert check_type_bool('on')
    assert check_type_bool('1')
    assert not check_type_bool('False')
    assert not check_type_bool('false')
    assert not check_type_bool('f')
    assert not check_type_bool('n')
    assert not check_type_bool('no')
    assert not check_type_bool('off')
    assert not check_type_bool('0')
    assert not check_type_bool(0)

# Generated at 2022-06-22 22:18:17.848471
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('"string"') == '"string"'
    assert check_type_jsonarg('true') == 'true'
    assert check_type_jsonarg('1') == '1'
    assert check_type_jsonarg(1) == '1'
    assert check_type_jsonarg(['a', 'b']) == '["a", "b"]'
    assert check_type_jsonarg(('a', 'b')) == '["a", "b"]'
    assert check_type_jsonarg({'a': 'b'}) == '{"a": "b"}'
    assert check_type_jsonarg({'a': [1,2]}) == '{"a": [1, 2]}'



# Generated at 2022-06-22 22:18:23.716187
# Unit test for function check_type_dict
def test_check_type_dict():
    # Testing dict string with quotes and escapes
    # {'foo': 'bar', 'baz': 'qux'}
    test_dict_str = '\'{\\\'foo\\\': \\\'bar\\\', \\"baz\\\':\' "\\\'qux\\\'"}\''
    test_dict = {u'foo': u'bar', u'baz': u'qux'}
    assert check_type_dict(test_dict_str) == test_dict, \
        'check_type_dict failed to properly convert dict string with quotes and escapes'

    # Testing dict string in key=value format
    # {'foo': 'bar', 'baz': 'qux'}
    test_dict_str = 'foo=bar, baz = qux'

# Generated at 2022-06-22 22:18:35.356275
# Unit test for function check_type_bits
def test_check_type_bits():
    assert(check_type_bits('1Mb') == 1048576)
    assert(check_type_bits('1MB') == 1048576)
    assert(check_type_bits('1mb') == 1048576)
    assert(check_type_bits('1mbit') == 1048576)
    assert(check_type_bits('1Mb') == 1048576)
    assert(check_type_bits('1MB') == 1048576)
    assert(check_type_bits('2kb') == 2048)
    assert(check_type_bits('2kb') == 2048)
    assert(check_type_bits('1kb') == 1024)
    assert(check_type_bits('1kb') == 1024)
    assert(check_type_bits('1Kb') == 1024)

# Generated at 2022-06-22 22:18:43.730448
# Unit test for function check_type_str
def test_check_type_str():

    param = 'parameter'
    prefix = prefix
    # make sure the returns are the same by using both methods
    test_values = {
        u'byte string': b'byte string',
        u'string': u'string',
        u'unicode': u'unicode',
        u'none': None
    }
    for value in test_values:
        assert check_type_str(value, True, param, prefix) == to_native(value, errors='surrogate_or_strict')
    # make sure an exception is thrown when conversion is not allowed
    for value in test_values:
        try:
            result = check_type_str(value, False, param, prefix)
        except TypeError:
            continue
        raise ValueError("Expected TypeError for value: {0}".format(value))


# Generated at 2022-06-22 22:18:53.905296
# Unit test for function check_required_if
def test_check_required_if():
    # If a parameter has a specific value, then a list of parameters
    # should be present or missing.

    # If the following are present, then string_param and bool_param
    # should also be present.
    tested_input = [['state', 'present', ('path',), True],
                    ['someint', 99, ('bool_param', 'string_param')]]
    parameters = dict(state='absent', bool_param=False, path='path')

    result = check_required_if(tested_input, parameters)
    assert len(result) == 2
    assert result[0]['missing'] == ['path']
    assert result[0]['requires'] == 'any'
    assert result[0]['parameter'] == 'state'
    assert result[0]['value'] == 'present'

# Generated at 2022-06-22 22:18:57.678495
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('name', {'name': 'foo'}) == 1
    assert count_terms(['name', 'display_name'], {'name': 'foo'}) == 1
    assert count_terms(['name', 'display_name'], {'name': 'foo', 'display_name': 'bar'}) == 2



# Generated at 2022-06-22 22:19:08.735626
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # Test case 1:
    _parameters = {"a": 1, "b": 2}
    _terms = [("a", "b")]
    _options_context = ["test_context"]
    _result = check_required_one_of(_terms, _parameters, _options_context)
    assert _result == []

    # Test case 2:
    _parameters = {"a": 1, "b": 2}
    _terms = [("c", "b")]
    _options_context = ["test_context"]
    result = None
    try:
        check_required_one_of(_terms, _parameters, _options_context)
    except TypeError as e:
        result = e
    assert result is not None

    # Test case 3:
    _parameters = {"a": 1, "b": 2}

# Generated at 2022-06-22 22:19:16.193994
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([('a', 'b'), ('c', 'd')], {'a': 1, 'b': 1}) == []
    assert check_required_one_of([('a', 'b'), ('c', 'd')], {'a': 1, 'b': 1, 'e': 1}) == []
    assert check_required_one_of([('a', 'b'), ('c', 'd')], {'c': 1, 'd': 1, 'e': 1}) == []
    assert check_required_one_of([('a', 'b'), ('c', 'd')], {'e': 1}) == [['a', 'b'], ['c', 'd']]

# Generated at 2022-06-22 22:19:21.215548
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path(1234) == '1234'
    assert check_type_path(12.34) == '12.34'
    assert check_type_path(r'"12\.34"') == '12.34'
    assert check_type_path('\'"12\\.34"\'') == '12.34'
    assert check_type_path('"12.34"') == '12.34'
    assert posixpath.normpath(check_type_path('$HOME/12.34')) == posixpath.normpath(os.path.expanduser('$HOME/12.34'))
    assert posixpath.normpath(check_type_path('~/12.34')) == posixpath.normpath(os.path.expanduser('~/12.34'))
   

# Generated at 2022-06-22 22:19:31.478689
# Unit test for function count_terms
def test_count_terms():
    arg1 = 'state'
    arg2 = {'state': 'present', 'name': 'foo'}
    result = count_terms(arg1, arg2)
    assert result == 1
    arg1 = ['state', 'name']
    result = count_terms(arg1, arg2)
    assert result == 2
    arg1 = ['state', 'name', 'last_name']
    result = count_terms(arg1, arg2)
    assert result == 2
    arg1 = 'last_name'
    result = count_terms(arg1, arg2)
    assert result == 0
    arg1 = 'name'
    arg2 = {'name': ['foo', 'bar'], 'state': 'present'}
    result = count_terms(arg1, arg2)
    assert result == 1

# Generated at 2022-06-22 22:19:41.325902
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    assert check_missing_parameters(
        parameters={'action': 'get'}, required_parameters=['action']
    ) == []
    assert check_missing_parameters(
        parameters={'action': 'get'}, required_parameters=['missing']
    ) == ['missing']
    assert check_missing_parameters(parameters={'action': 'get'}) == []
    assert check_missing_parameters(parameters={}, required_parameters=[]) == []
    assert check_missing_parameters(
        parameters={'action': 'get'}, required_parameters=['action', 'missing']
    ) == ['missing']



# Generated at 2022-06-22 22:19:49.239806
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    dirty = {"test":[1, 2, 3]}
    clean = check_type_jsonarg(dirty)
    assert isinstance(clean, (text_type, binary_type))
    assert clean == '{"test": [1, 2, 3]}'
    clean = check_type_jsonarg("test")
    assert isinstance(clean, (text_type, binary_type))
    assert clean == "test"
    dirty = ["test"]
    clean = check_type_jsonarg(dirty)
    assert isinstance(clean, (text_type, binary_type))
    assert clean == '[\n  "test"\n]'



# Generated at 2022-06-22 22:19:51.485699
# Unit test for function check_type_bool
def test_check_type_bool():
    res = check_type_bool("True")
    assert res == True


# Generated at 2022-06-22 22:19:53.342324
# Unit test for function check_type_raw
def test_check_type_raw():
    obj = 123
    assert check_type_raw(obj) == 123



# Generated at 2022-06-22 22:20:00.698608
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int(-1) == -1
    assert check_type_int('1') == 1
    assert check_type_int('-1') == -1
    with pytest.raises(TypeError):
        check_type_int('abc')
    with pytest.raises(TypeError):
        check_type_int(1.1)



# Generated at 2022-06-22 22:20:12.740910
# Unit test for function check_type_bytes
def test_check_type_bytes():
    import pytest
    with pytest.raises(TypeError):
        check_type_bytes('t')
    check_type_bytes('1')
    check_type_bytes('2B')
    check_type_bytes('2b')
    check_type_bytes('1K')
    check_type_bytes('1k')
    check_type_bytes('1M')
    check_type_bytes('1m')
    check_type_bytes('1G')
    check_type_bytes('1g')
    check_type_bytes('1T')
    check_type_bytes('1t')
    check_type_bytes('1P')
    check_type_bytes('1p')
    check_type_bytes('1E')
    check_type_bytes('1e')

# Generated at 2022-06-22 22:20:14.831072
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(1) == 1
    assert check_type_raw('a string') == 'a string'



# Generated at 2022-06-22 22:20:22.133892
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {
        'net.ipv4.tcp_keepalive_time': 600
    }
    required_parameters = ['net.ipv4.tcp_keepalive_intvl', 'net.ipv4.tcp_keepalive_time']
    try:
        check_missing_parameters(parameters, required_parameters)
    except TypeError as e:
        assert "missing required arguments: net.ipv4.tcp_keepalive_intvl" in str(e)
    else:
        assert False, "Should've failed"

# Generated at 2022-06-22 22:20:31.756083
# Unit test for function check_required_if
def test_check_required_if():
    parameters = {'state': 'present', 'path': '/etc/sudoers', 'reboot': False}
    requirements = [
        ['state', 'present', ('path',), True],
    ]
    with pytest.raises(TypeError) as exc:
        check_required_if(requirements, parameters, 'test')
    assert "path of the following are missing: " in str(exc.value)
    assert exc.value.results == [
        {'parameter': 'state', 'value': 'present', 'requirements': ('path',), 'missing': [], 'requires': 'any'}
    ]
    requirements = [
        ['state', 'present', ('path',), True],
        ['state', 'present', ('not_a_key',), False],
    ]

# Generated at 2022-06-22 22:20:42.167013
# Unit test for function check_required_if
def test_check_required_if():
    #Case-1 : Value of parameter is 'None'
    parameters = {'state': None, 'path': 'test_path', 'bool_param': True}
    requirements = [['state', 'present', ('path',), True]]
    result = check_required_if(requirements, parameters)
    assert result == []

    #case-2 : Value of parameter is not 'None' but its not present in parameters
    parameters = {'someint': 100, 'path': 'test_path', 'bool_param': True}
    requirements = [['state', 'present', ('path',), True]]
    result = check_required_if(requirements, parameters)
    assert result == []

    #Case-3 : Value of parameter is not 'None' and its present in parameters

# Generated at 2022-06-22 22:20:48.070006
# Unit test for function count_terms
def test_count_terms():
    # Test Not Iterable
    assert count_terms('first', {'first': 'one', 'second': 'two'}) == 1
    # Test Iterable
    assert count_terms(['first'], {'first': 'one', 'second': 'two'}) == 1
    assert count_terms(['first', 'second'], {'first': 'one', 'second': 'two'}) == 2
    assert count_terms(['first', 'third'], {'first': 'one', 'second': 'two'}) == 1
    assert count_terms(['third', 'fourth'], {'first': 'one', 'second': 'two'}) == 0



# Generated at 2022-06-22 22:20:56.675722
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True) == True
    assert check_type_bool(False) == False
    assert check_type_bool(1) == True
    assert check_type_bool(['1']) == True
    assert check_type_bool(0) == False
    assert check_type_bool(['0']) == False
    assert check_type_bool('yes') == True
    assert check_type_bool('no') == False
    assert check_type_bool('y') == True
    assert check_type_bool('n') == False
    assert check_type_bool('True') == True
    assert check_type_bool('False') == False
    assert check_type_bool('true') == True
    assert check_type_bool('false') == False
    assert check_type_bool('  true  ')

# Generated at 2022-06-22 22:21:00.538584
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{"mykey":"myvalue"}') == '{"mykey":"myvalue"}'
    assert check_type_jsonarg('[1, 2, 3, 4]') == '[1, 2, 3, 4]'

# FIXME: not sure how to unittest this as it has randomness

# Generated at 2022-06-22 22:21:10.311067
# Unit test for function check_type_bytes
def test_check_type_bytes():
    """Validates that the check_type_bytes function returns a valid Byte size."""
    assert check_type_bytes('10') == 10
    assert check_type_bytes('10G') == 10737418240
    assert check_type_bytes('10M') == 10485760
    assert check_type_bytes('10K') == 10240
# End unit tests.

DEFAULT_TYPE_COMMON_ARGS = {
    # FIXME: remove bare=True in Ansible 2.11
    'path': dict(type='path', aliases=['dest', 'name', 'destination'], bare=True),
    'state': dict(type='str', choices=['absent', 'present'], default='present'),
    'force': dict(type='bool', default=False),
}

DEFAULT_TYPE_BOOL_NO_

# Generated at 2022-06-22 22:21:13.697751
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(5.0) == 5.0
    assert check_type_float('5.0') == 5.0


# Generated at 2022-06-22 22:21:22.982138
# Unit test for function count_terms
def test_count_terms():
    """Test count_terms function."""
    _arg_dict = {u'foo': u'bar', u'baz': u'qux'}
    assert count_terms(u'foo', _arg_dict) == 1
    assert count_terms(u'bar', _arg_dict) == 0
    assert count_terms([u'foo', u'bar'], _arg_dict) == 1
    assert count_terms([u'bar', u'baz'], _arg_dict) == 1
    assert count_terms([u'bar', u'baz'], _arg_dict) == 1
    assert count_terms([u'bar', u'qux', u'baz'], _arg_dict) == 2

# Generated at 2022-06-22 22:21:26.987691
# Unit test for function check_type_raw
def test_check_type_raw():
    check_type_raw_mock = MagicMock(return_value="test")
    assert check_type_raw(check_type_raw_mock) == "test"
    check_type_raw_mock.assert_called_once_with()



# Generated at 2022-06-22 22:21:37.661915
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{overwritten_by_data}') == '{overwritten_by_data}'
    assert check_type_jsonarg(['{overwritten_by_data}']) == '["{overwritten_by_data}"]'
    assert check_type_jsonarg({}) == '{}'
    assert check_type_jsonarg({'a':'{overwritten_by_data}'}) == '{"a": "{overwritten_by_data}"}'
    assert check_type_jsonarg({'a': ['{overwritten_by_data}']}) == '{"a": ["{overwritten_by_data}"]}'

# Generated at 2022-06-22 22:21:48.910447
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    # Test string
    s = '''[{"a": "b"}, {"c": "d"}]'''
    result = check_type_jsonarg(s)
    assert result == s
    # Test list
    l = [{'a': 'b'}, {'c': 'd'}]
    result = check_type_jsonarg(l)
    assert json.loads(result) == l
    # Test tuple
    t = ({"a": "b"}, {"c": "d"})
    result = check_type_jsonarg(t)
    assert json.loads(result) == list(t)
    # Test dict
    d = {"a": "b"}
    result = check_type_jsonarg(d)
    assert json.loads(result) == d



# Generated at 2022-06-22 22:21:58.971240
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with a single term that is mutually exclusive
    parameters = {'foo': 'bar', 'baz': 'qux'}
    terms = ['foo', 'baz']
    check_mutually_exclusive(terms, parameters)

    # Test with a single term that is not mutually exclusive
    parameters = {'foo': 'bar'}
    terms = ['foo']
    check_mutually_exclusive(terms, parameters)

    # Test with multiple terms that are mutually exclusive
    parameters = {'foo': 'bar', 'baz': 'qux', 'hello': 'world'}
    terms = ['foo', 'baz', 'hello']
    check_mutually_exclusive(terms, parameters)

    # Test with multiple terms that are not mutually exclusive

# Generated at 2022-06-22 22:22:03.265534
# Unit test for function check_type_int
def test_check_type_int():
    lst = [1, 3, 5, 7, 9]
    lst1 = ["1", "3", "5", "7", "9"]
    for i in lst:
        assert check_type_int(i) == i
    for j in lst1:
        assert check_type_int(j) == int(j)
    try:
        check_type_int("ABC")
    except TypeError as e:
        assert e.message == "'ABC' cannot be converted to an int"
