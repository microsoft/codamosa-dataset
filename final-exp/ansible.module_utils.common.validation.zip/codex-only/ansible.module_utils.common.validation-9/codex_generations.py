

# Generated at 2022-06-22 22:12:05.253532
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824


# Generated at 2022-06-22 22:12:09.767431
# Unit test for function check_type_path
def test_check_type_path():
    test_path = '$HOME/test_file'
    home = os.environ['HOME']
    assert check_type_path(test_path) == home + '/test_file'

# Generated at 2022-06-22 22:12:12.645739
# Unit test for function check_type_path
def test_check_type_path():
  assert check_type_path('~/') == os.path.expanduser('~/')
  assert check_type_path('$HOME') == os.path.expandvars('$HOME')


# Generated at 2022-06-22 22:12:18.803093
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('string') == 'string'
    assert check_type_str(u'string') == 'string'

    assert check_type_str(12345) == '12345'
    assert check_type_str(12345, allow_conversion=False) == '12345'

    with pytest.raises(TypeError) as execinfo:
        check_type_str(12345, allow_conversion=False)
    msg = "'12345' is not a string and conversion is not allowed"
    assert msg == to_native(execinfo.value)
# end unit test



# Generated at 2022-06-22 22:12:22.069645
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = ['a', 'b', 'c', 'e']
    results = check_required_together(terms, parameters)
    assert len(results) == 1
    parameters = {'a': 'a', 'b': 'b'}
    results = check_required_together(terms, parameters)
    assert len(results) == 0


# Generated at 2022-06-22 22:12:24.572683
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('/usr') == '/usr'
    assert check_type_path('~/usr') == os.path.expanduser('~/usr')
    assert check_type_path('$PATH') == os.path.expandvars('$PATH')
    with pytest.raises(TypeError):
        check_type_path(10)

# Generated at 2022-06-22 22:12:30.534148
# Unit test for function check_required_together
def test_check_required_together():
    # Test case with empty list
    assert check_required_together([], {}) == []

    # Test case with full requirements
    assert check_required_together([('foo', 'bar')], {'foo': 'f', 'bar': 'b'}) == []

    # Test case with missing field
    with pytest.raises(TypeError):
        check_required_together([('foo', 'bar')], {'foo': 'f'})



# Generated at 2022-06-22 22:12:33.540680
# Unit test for function check_type_int
def test_check_type_int():
    value=1
    assert check_type_int(value)==1
    value='1'
    assert check_type_int(value)==1
    value=True
    try:
        check_type_int(value)
        assert False
    except TypeError:
        assert True
    value='ab'
    try:
        check_type_int(value)
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-22 22:12:39.005608
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('foo', {'foo': 'bar', 'baz': 'quz'}) == 1
    assert count_terms('foo', {'baz': 'quz'}) == 0
    assert count_terms(['foo', 'baz'], {'foo': 'bar', 'baz': 'quz'}) == 2



# Generated at 2022-06-22 22:12:44.496920
# Unit test for function check_type_path
def test_check_type_path():
    assert not os.path.exists(check_type_path('not-exists-dir'))
    assert check_type_path('not-exists-dir') == u'not-exists-dir'
    assert check_type_path(u'not-exists-dir') == u'not-exists-dir'
    assert not os.path.exists(check_type_path(u'not-exists-dir'))
    try:
        check_type_path(123)
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-22 22:12:55.620430
# Unit test for function check_required_if
def test_check_required_if():
    def Test_check_required_if(requirements, parameters, msg, test_type):
        try:
            check_required_if(requirements, parameters)
        except Exception as err:
            assert msg in str(err)
            assert isinstance(err, test_type)
        else:
            assert False, 'Test failed'

    # Test 1: Error for key not in requirements
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = dict(
        state = 'present',
        bool_param = True,
        string_param = "Hello"
    )
    msg = 'missing required arguments: path'
    Test_check_required_if(requirements, parameters, msg, TypeError)

    #

# Generated at 2022-06-22 22:13:07.459324
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'first_name': 'Test', 'last_name': 'Test2'}
    required_parameters = ['first_name', 'last_name']
    assert(check_missing_parameters(parameters, required_parameters) == [])
    
    parameters['first_name'] = None
    assert(check_missing_parameters(parameters, required_parameters) == ['first_name'])
    
    parameters['first_name'] = 'Test'
    parameters['last_name'] = None
    assert(check_missing_parameters(parameters, required_parameters) == ['last_name'])
    
    parameters['first_name'] = None
    parameters['last_name'] = None

# Generated at 2022-06-22 22:13:15.797706
# Unit test for function check_required_one_of
def test_check_required_one_of():
    parameters = {'a': '1',
                  'b': '2'}
    terms = [['a', 'b']]
    check_required_one_of(terms=terms, parameters=parameters)

    parameters = {'a': '1',
                  'b': '2'}
    terms = [['a', 'c']]
    with pytest.raises(TypeError):
        check_required_one_of(terms=terms, parameters=parameters)

    parameters = {'a': '1',
                  'b': '2'}
    terms = [['a', 'b'],
             ['c', 'd']]
    check_required_one_of(terms=terms, parameters=parameters)

    parameters = {'a': '1',
                  'b': '2'}

# Generated at 2022-06-22 22:13:24.481185
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    from ansible.module_utils.common.text.converters import to_text
    test_inputs = ['foo', ['foo', 'bar', 'baz'], ['a', 'b'], ['a', 'b', 'c']]
    test_parameters = {'foo': 'string', 'bar': 'other string', 'baz': 'string'}
    for test_input in test_inputs:
        if is_iterable(test_input):
            result = check_mutually_exclusive(test_input, test_parameters)
            assert result == []
        else:
            try:
                check_mutually_exclusive(test_input, test_parameters)
                raise AssertionError(to_text('TypeError not raised for {0}'.format(test_input)))
            except TypeError:
                pass

# Generated at 2022-06-22 22:13:30.385934
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int("1") == 1
    with pytest.raises(TypeError):
        check_type_int("one")
    with pytest.raises(TypeError):
        check_type_int(1.1)
    with pytest.raises(TypeError):
        check_type_int(True)
    with pytest.raises(TypeError):
        check_type_int(None)


# Generated at 2022-06-22 22:13:40.262824
# Unit test for function check_required_arguments
def test_check_required_arguments():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'foo': 'bar'}, argument_spec={'foo': dict(required=False)})
    if check_required_arguments(module.argument_spec, module.params, options_context=[]):
        raise AssertionError("Expected check_required_arguments to return []")
    try:
        check_required_arguments(module.argument_spec, module.params, options_context=['bar'])
        raise AssertionError("Expected check_required_arguments to bail")
    except TypeError:
        pass
    module = AnsibleModule({'foo': 'bar'}, argument_spec={'foo': dict(required=False), 'bar': dict(required=True)})

# Generated at 2022-06-22 22:13:41.248941
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1


# Generated at 2022-06-22 22:13:51.848800
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('"C:\\test"') == 'C:\\test'
    assert check_type_path('~') == os.path.expanduser('~')
    assert check_type_path('$HOME') == os.path.expanduser('$HOME')
    assert check_type_path('$HOME/test') == os.path.expanduser('$HOME/test')

    try:
        check_type_path(1)
    except TypeError:
        pass
    else:
        assert False == 'Type check failed'



# Generated at 2022-06-22 22:14:01.258131
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    import pytest
    from parameter_validation import check_mutually_exclusive
    from ansible.module_utils.six import string_types, text_type

    assert check_mutually_exclusive(None, dict()) == []
    assert check_mutually_exclusive([['a']], dict()) == []

    # single terms
    with pytest.raises(TypeError):
        check_mutually_exclusive(['a', 'b'], dict(a=True, b=True))
    assert check_mutually_exclusive(['a', 'b'], dict(a=True, b=False)) == []
    assert check_mutually_exclusive(['a', 'b'], dict(a=False, b=True)) == []

    # grouped terms

# Generated at 2022-06-22 22:14:11.758612
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('"a"') == 'a'
    assert safe_eval('[1,2]') == [1, 2]
    assert safe_eval('{"k": "v"}') == {'k': 'v'}

    assert safe_eval('{"k": {"k2": "v2"}}') == {'k': {'k2': 'v2'}}

    assert safe_eval('{"k": {"k2": "v2"}}', include_exceptions=True) == ({'k': {'k2': 'v2'}}, None)

    assert safe_eval('{"k": "{{v1}}"}') == {"k": "{{v1}}"}

# Generated at 2022-06-22 22:14:16.683331
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('True') is True
    assert check_type_bool('true') is True
    assert check_type_bool('yes') is True
    assert check_type_bool('1') is True
    assert check_type_bool('on') is True

    assert check_type_bool('False') is False
    assert check_type_bool('false') is False
    assert check_type_bool('no') is False
    assert check_type_bool('0') is False
    assert check_type_bool('off') is False

    assert check_type_bool(True) is True
    assert check_type_bool(False) is False

    try:
        check_type_bool('sd')
    except TypeError as e:
        assert "cannot be converted to a bool" in to_native(e)



# Generated at 2022-06-22 22:14:22.792906
# Unit test for function check_required_arguments
def test_check_required_arguments():
    try:
        argument_spec = {
            'options': {'required': True},
        }
        parameters = {'something': None}
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert 'missing required arguments: options' in text_type(e)
        return
    raise Exception("Incorrect arguments did not raise a TypeError")



# Generated at 2022-06-22 22:14:27.946206
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Success
    assert(check_type_bytes('1M') == 1048576)
    # Failure
    try:
        check_type_bytes(1)
        assert(0)
    except TypeError:
        assert(1)


# Generated at 2022-06-22 22:14:38.829499
# Unit test for function check_required_one_of
def test_check_required_one_of():
    from ansible.module_utils.common.validation import check_required_one_of
    from six import StringIO
    try:
        check_required_one_of([['a', 'b'], ['b', 'c']], {'a': 'x', 'b': 'x'})
    except TypeError as e:
        raise AssertionError('Unexpected result: {0}'.format(e))
    try:
        check_required_one_of([['a', 'b'], ['b', 'c']], {'a': 'x', 'b': 'x', 'd': 'y'})
    except TypeError as e:
        raise AssertionError('Unexpected result: {0}'.format(e))

# Generated at 2022-06-22 22:14:41.936838
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    """Test for using function check_missing_parameters"""
    parameters = dict()
    parameters["a"] = 1
    parameters["b"] = 2
    res = check_missing_parameters(parameters, ["a", "b", "c"])
    assert(res == ["c"])


# Generated at 2022-06-22 22:14:47.348267
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg(u'{"foo":1}') == u'"{\\"foo\\":1}"'
    assert check_type_jsonarg({'foo':1}) == '{"foo":1}'
    assert check_type_jsonarg(['foo']) == '["foo"]'



# Generated at 2022-06-22 22:14:56.376512
# Unit test for function check_required_arguments
def test_check_required_arguments():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE

    argument_spec = {
        "arg1": {"required": True, "type": "str"},
        "arg2": {"required": False, "type": "str"},
        }

    parameters = {
        "arg1": "value1",
        "arg2": "value2",
    }

    try:
        check_required_arguments(argument_spec, parameters)
    except Exception as e:
        raise AssertionError('Exception raised when required parameters are provided: %s' % e)


# Generated at 2022-06-22 22:15:05.656820
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    try:
        check_missing_parameters({'a': 1}, ['a', 'b'])
    except Exception as e:
        pass
    else:
        raise AssertionError('Expected Exception')

    try:
        check_missing_parameters({'a': 1}, ['b'])
    except Exception as e:
        pass
    else:
        raise AssertionError('Expected Exception')

    try:
        check_missing_parameters({'a': 1, 'b': 'b'}, ['a', 'b'])
    except Exception as e:
        raise AssertionError('Unexpected Exception')



# Generated at 2022-06-22 22:15:06.808658
# Unit test for function count_terms
def test_count_terms():
    result = count_terms("access", {"access": "key", "secret": "secret key"})
    assert result == 1



# Generated at 2022-06-22 22:15:10.194861
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1MB') == 1048576
    assert check_type_bits('1mb') == 1048576



# Generated at 2022-06-22 22:15:18.524196
# Unit test for function check_required_if
def test_check_required_if():
    dict = dict()
    dict['key1'] = 'value1'

    # test 1
    req_if = list()
    req_if.append(['key1', 'value1', ('key2',), True])
    check_required_if(req_if, dict)

    # test 2
    req_if = list()
    req_if.append(['key1', 'value2', ('key2',)])
    check_required_if(req_if, dict)

    # test 3
    req_if = list()
    req_if.append(['key1', 'value1', ('key2', 'key3')])
    check_required_if(req_if, dict)

    # test 4
    req_if = list()

# Generated at 2022-06-22 22:15:24.458165
# Unit test for function check_type_str
def test_check_type_str():
    """Test for function 'check_type_str'
    """
    TEST_DATA = [
        ("string", True, "string"),
        (True, True, "True"),
        (False, False, "'False' is not a string and conversion is not allowed"),
        (None, False, "'None' is not a string and conversion is not allowed"),
        (["a", "list"], True, "['a', 'list']"),
        ((1, 2, 3), True, "(1, 2, 3)")
    ]
    for value, allow_conversion, expected in TEST_DATA:
        try:
            result = check_type_str(value, allow_conversion)
        except Exception as e:
            result = e.args[0]
        assert result == expected



# Generated at 2022-06-22 22:15:33.769179
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Test required parameters not defined
    argument_spec = {'required_parameter': {'required': True}}
    parameters = {}
    try:
        check_required_arguments(argument_spec, parameters)
    except Exception as e:
        assert 'missing required arguments' in str(e)
    # Test required parameters defined
    try:
        check_required_arguments(argument_spec, parameters, options_context=['ansible_network_os'])
    except Exception as e:
        assert 'missing required arguments' in str(e)



# Generated at 2022-06-22 22:15:36.540520
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw("value") == "value"
    assert check_type_raw(True) == True
    assert check_type_raw(1) == 1



# Generated at 2022-06-22 22:15:47.154017
# Unit test for function check_type_str
def test_check_type_str():
    """Ensure to_native return the correct output"""
    # Check that we raise a TypeError if the value not a string and conversion is not allowed.
    value1 = "hello"
    assert value1 == check_type_str(value1)
    value2 = 42
    assert isinstance(check_type_str(value2, allow_conversion=True), string_types)
    with pytest.raises(TypeError) as execinfo:
        check_type_str(value2, allow_conversion=False)
    assert "is not a string and conversion is not allowed" in str(execinfo.value)

    # Check force_native flag is respected by the `check_type_str` function
    value3 = u'\u00aa'
    result3 = check_type_str(value3, allow_conversion=True)


# Generated at 2022-06-22 22:15:58.409544
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('a=1') == {'a': '1'}
    assert check_type_dict('a=1,b=2,c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert check_type_dict('a=1,b=2,c=3,d="abc,def" ') == {'a': '1', 'b': '2', 'c': '3', 'd': 'abc,def'}
    assert check_type_dict('a=1,b=2,c=3,d="abc,def",e=\'abc,def\'') == {'a': '1', 'b': '2', 'c': '3', 'd': 'abc,def', 'e': 'abc,def'}
    assert check_

# Generated at 2022-06-22 22:16:03.656553
# Unit test for function check_type_raw
def test_check_type_raw():
    from ansible.module_utils.basic import AnsibleModule
    # Check if value 1 is returned
    module = AnsibleModule({'test': 1})
    assert 1 == check_type_raw(module.params.get('test'))

# Generated at 2022-06-22 22:16:13.854514
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('1') == True
    assert check_type_bool('on') == True
    assert check_type_bool('0') == False
    assert check_type_bool('n') == False
    assert check_type_bool(1) == True
    assert check_type_bool(0) == False
    assert check_type_bool(True) == True
    assert check_type_bool(False) == False
    with pytest.raises(TypeError) as excinfo:
        check_type_bool('not bool')
    assert 'cannot be converted to a bool' in str(excinfo)


_check_type_num_re = re.compile('^[-+]?[0-9]+$')



# Generated at 2022-06-22 22:16:25.968641
# Unit test for function safe_eval
def test_safe_eval():
    # assert that only non-function code gets evaluated
    assert safe_eval('1+1') == 2
    assert safe_eval('0 or 1') == 1
    assert safe_eval('[1,2,3]+[4,5,6]') == [1, 2, 3, 4, 5, 6]
    assert safe_eval('{"foo":"bar"}') == {"foo": "bar"}
    assert safe_eval('1+1', include_exceptions=True)[0] == 2
    assert safe_eval('x.append(1)', include_exceptions=True)[1] is not None
    assert safe_eval('import sys', include_exceptions=True)[1] is not None
    assert safe_eval('None') is None
    assert safe_eval('True') is True
    assert safe_eval(1) == 1

# Generated at 2022-06-22 22:16:28.946973
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('') == ''
    assert check_type_str('hello world') == 'hello world'
    assert check_type_str(b'foo bar') == 'foo bar'
    assert check_type_str(b'foo bar', allow_conversion=False) == 'foo bar'
    with pytest.raises(TypeError) as err:
        check_type_str(123)
    with pytest.raises(TypeError) as err:
        check_type_str([1, 2, 3])



# Generated at 2022-06-22 22:16:40.573407
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
    assert check_type_list('a,b,c,d') == ['a', 'b', 'c', 'd']
    assert check_type_list(('a', 'b', 'c', 'd')) == ['a', 'b', 'c', 'd']
    assert check_type_list(1) == ['1']
    assert check_type_list(1.0) == ['1.0']
    assert check_type_list('1') == ['1']
    assert check_type_list('1.1') == ['1.1']
    assert check_type_list(['a']) == ['a']

# Generated at 2022-06-22 22:16:45.225084
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argspec = dict(a=dict(required=True, type='str'),
                   b=dict(required=False, type='str'))
    assert [] == check_required_arguments(argspec, dict(a='a'))
    assert [] == check_required_arguments(argspec, dict(a='a', b='b'))
    assert ['a'] == check_required_arguments(argspec, dict(b='b'))



# Generated at 2022-06-22 22:16:47.264954
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{"key":"value"}') == '{"key":"value"}'
    assert check_type_jsonarg({"key":"value"}) == '{"key":"value"}'



# Generated at 2022-06-22 22:16:51.178113
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(0x10) == 16
    assert check_type_int('0x10') == 16
    assert check_type_int(0b10) == 2
    assert check_type_int('0b10') == 2



# Generated at 2022-06-22 22:16:54.206541
# Unit test for function count_terms
def test_count_terms():

    terms = ['term1', 'term2', 'term4']
    parameters = {'term1': 'value1', 'term3': 'value3'}

    assert count_terms(terms, parameters) == 1



# Generated at 2022-06-22 22:16:58.860607
# Unit test for function count_terms
def test_count_terms():
    parameters = dict(
        foo='bar',
        bar='baz',
        baz='qux'
    )
    assert count_terms('bar', parameters) == 1
    assert count_terms(['bar', 'baz'], parameters) == 2



# Generated at 2022-06-22 22:17:03.025423
# Unit test for function check_type_bits
def test_check_type_bits():
    if check_type_bits('1Mb') == 1048576:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-22 22:17:04.271362
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('here') == 'here'



# Generated at 2022-06-22 22:17:12.847333
# Unit test for function count_terms
def test_count_terms():
    """Unit test for function count_terms"""

    parameters = {'a': 'b', 'c': 'd', 'a': 'e', 'd': 'e'}

    # This test uses integers, strings, and lists as values
    values = [2, ['a', 'b'], 'a']

    # This test iterates through the values list,
    # and compares the count to the number of occurrences
    # of the value in the parameters dictionary
    for index, value in enumerate(values):
        assert index + 1 == count_terms(value, parameters)


# Generated at 2022-06-22 22:17:22.436368
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test the safe_eval function
    '''
    assert safe_eval(10) == 10
    assert safe_eval('20') == 20
    assert safe_eval('30.5') == 30.5
    assert safe_eval('"forty"') == 'forty'
    assert safe_eval("'fifty'") == 'fifty'
    assert safe_eval('"sixty"') != 60
    assert safe_eval("'seventy'") != 70
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('dict(a=1,b=2,c=3)') == dict(a=1, b=2, c=3)
    assert safe_eval("{'a':1,'b':2,'c':3}") == dict

# Generated at 2022-06-22 22:17:33.372511
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(['a']) == ['a']
    assert check_type_list(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert check_type_list(u'a') == ['a']
    assert check_type_list(u'a,b,c') == ['a', 'b', 'c']
    assert check_type_list(['a,b,c']) == ['a,b,c']
    assert check_type_list(0) == ['0']
    assert check_type_list(1.1) == ['1.1']
    fail_types = {
        dict(): 'is not iterable',
        None: 'cannot be converted to a list',
    }


# Generated at 2022-06-22 22:17:41.579567
# Unit test for function check_required_arguments
def test_check_required_arguments():
    try:
        check_required_arguments(argument_spec={'required': {'required': True}}, parameters={})
    except TypeError as e:
        assert e.args[0] == "missing required arguments: required"
    else:
        assert False, "no exception raised"
    try:
        check_required_arguments(argument_spec={'required': {'required': True}, 'not_required': {'required': False}}, parameters={'required': 'required'})
    except:
        assert False, "unexpected exception"
    try:
        check_required_arguments(argument_spec={'required': {'required': True}, 'not_required': {'required': False}}, parameters={'not_required': 'not'})
    except:
        assert False, "unexpected exception"

# Generated at 2022-06-22 22:17:50.752312
# Unit test for function check_required_one_of
def test_check_required_one_of():
    parameters = [
        {'key': 'a'},
        {'key': 'b', 'key2': 'b2'},
        {'key': 'c', 'key2': 'c2'},
        {'key': 'd', 'key2': 'd2'},
        {'key': 'e', 'key2': 'e2', 'key3': 'e3'}
    ]

    for param in parameters:
        try:
            check_required_one_of([['key']], param)
        except TypeError as exc:
            assert "key is required" in str(exc)
        else:
            assert False


# Generated at 2022-06-22 22:18:00.640449
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    """Test for function check_missing_parameters()
    """
    # handle None for required_parameters arg
    result = check_missing_parameters({})
    assert result == []

    # check for missing required parameters
    result = check_missing_parameters({'a': 1}, ['a', 'b'])
    assert result == []

    # fail if required parameter is missing
    failed = False
    try:
        check_missing_parameters({'a': 1}, ['a', 'b'])
    except TypeError:
        failed = True
    assert failed



# Generated at 2022-06-22 22:18:09.502636
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(3.5) == 3.5
    assert check_type_float(3) == 3.0
    assert check_type_float(3.) == 3.0
    assert check_type_float("3") == 3.0
    assert check_type_float(u"3") == 3.0
    assert check_type_float(b"3") == 3.0
    assert check_type_float("3.5") == 3.5
    assert check_type_float(u"3.5") == 3.5
    assert check_type_float(b"3.5") == 3.5
    assert check_type_float(b"3.5.6") == 3.5
    assert check_type_float(b"3.5/3.5") == 3.5
    assert check_

# Generated at 2022-06-22 22:18:15.223556
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str("test") == "test"
    assert check_type_str("test", allow_conversion=True) == "test"
    assert check_type_str("test", allow_conversion=False) == "test"
    assert check_type_str("test", param="test_parameter") == "test"
    assert check_type_str(1) == "1"
    assert check_type_str(1, allow_conversion=True) == "1"
    assert check_type_str(1, allow_conversion=False) == "1"
    assert check_type_str(1, param="test_parameter") == "1"

    with pytest.raises(TypeError):
        check_type_str(1, allow_conversion=False)


# Generated at 2022-06-22 22:18:21.005882
# Unit test for function check_type_bool
def test_check_type_bool():
    for value, expected_result in [
        ('yes', True),
        ('no', False),
        (1, True),
        (0, False),
        ('1', True),
        ('0', False),
        (True, True),
        (False, False),
    ]:
        assert expected_result == check_type_bool(value)


# Generated at 2022-06-22 22:18:25.656539
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Success
    assert (check_required_arguments(dict(
        foo=dict(required=True)
    ), dict(foo=1))) == []

    # Failure
    try:
        check_required_arguments(dict(
            foo=dict(required=True)
        ), dict())
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-22 22:18:30.270191
# Unit test for function check_type_str
def test_check_type_str():
    from ansiblemodule import AnsibleModule
    value = [1]
    module = AnsibleModule(argument_spec=dict(default=dict(default=value)))
    module.fail_json = lambda *args: args
    module.warn = lambda *args: args
    try:
        value = check_type_str(value, allow_conversion=False, param=None, prefix='')
    except TypeError:
        pass
    else:
        assert False, "Expected TypeError"

    value = [1]
    try:
        value = check_type_str(value, allow_conversion=True, param=None, prefix='')
    except TypeError:
        assert False, "Unexpected TypeError"

    assert value == "[1]"
# end unit test for function check_type_str



# Generated at 2022-06-22 22:18:33.653059
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path(u'/home/%h/.vimrc') == os.path.join(os.path.expanduser('~'),'.vimrc')


# Generated at 2022-06-22 22:18:44.232674
# Unit test for function check_required_one_of
def test_check_required_one_of():
    param_set1 = {'a': 1, 'b': 2, 'c': 3}
    terms1 = [['a', 'b'], ('c', 'd')]
    result = check_required_one_of(terms1, param_set1)
    assert result == []

    param_set2 = {'a': 1, 'b': 2, 'c': 3}
    terms2 = [['a', 'b'], ('c', 'd', 'e')]
    result = check_required_one_of(terms2, param_set2)
    assert result == []

    param_set3 = {'a': 1, 'c': 3}
    terms3 = [['a', 'b'], ('c', 'd', 'e')]

# Generated at 2022-06-22 22:18:51.095778
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    value = '["hello", "world"]'
    result = check_type_jsonarg(value)
    assert result == value
    value = {"a":"b"}
    result = check_type_jsonarg(value)
    assert result == jsonify(value)



# Generated at 2022-06-22 22:18:53.027021
# Unit test for function check_type_bits
def test_check_type_bits():
    ''' check_type_bits is a function to assert if a string
    contains a human-readable string value.
    '''
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('3MB') == 3145728

# Generated at 2022-06-22 22:18:54.224301
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('raw') == 'raw'


# Generated at 2022-06-22 22:19:07.282004
# Unit test for function check_required_by
def test_check_required_by():
    require_by_dict = {
        "exclude": "selected",
        "recurse": "parent",
    }
    parameters = {
        "exclude": [],
        "recurse": 1,
        "parent": "foo",
        "selected": [],
    }
    results = check_required_by(require_by_dict, parameters, options_context=["test_check_required_by"])
    assert not results
    parameters2 = {
        "exclude": [],
        "recurse": 1,
    }
    results2 = check_required_by(require_by_dict, parameters2, options_context=["test_check_required_by"])
    assert results2 == {'recurse': ['parent']}

# Generated at 2022-06-22 22:19:13.385188
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    m_e = check_mutually_exclusive
    params = dict(a=1, b=2, c=3, d=4, e=5)
    assert not m_e([['a', 'b'], ['c', 'd'], ['e']], params)
    assert not m_e([['a'], ['a']], params)
    with pytest.raises(TypeError) as exc:
        m_e([['a', 'b']], params)
    assert 'mutually exclusive' in str(exc)
    with pytest.raises(TypeError) as exc:
        m_e([['a', 'c']], params)
    assert 'mutually exclusive' in str(exc)


# Generated at 2022-06-22 22:19:23.592099
# Unit test for function safe_eval
def test_safe_eval():
    # single line
    assert safe_eval("1 + 1") == 2
    # multiple lines
    assert safe_eval("""
        1 + 1
        """) == 2
    # use of local var
    assert safe_eval("a", locals=dict(a=1)) == 1
    # function call
    assert safe_eval("max(1, 2, 3)") == 3
    # string
    assert safe_eval("'1'") == '1'
    # single quote
    assert safe_eval("'a'") == 'a'
    # double quote
    assert safe_eval('"a"') == 'a'
    # newline inside single quotes
    assert safe_eval("'a\\nb'") == 'a\nb'
    # newline inside double quotes

# Generated at 2022-06-22 22:19:30.301765
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('1') == True
    assert check_type_bool(1) == True
    assert check_type_bool('True') == True
    assert check_type_bool('true') == True
    assert check_type_bool(True) == True
    assert check_type_bool('0') == False
    assert check_type_bool(0) == False
    assert check_type_bool('False') == False
    assert check_type_bool('false') == False
    assert check_type_bool(False) == False


# Generated at 2022-06-22 22:19:32.307027
# Unit test for function check_type_raw
def test_check_type_raw():
    for value in [1, "", "foo", {"foo": "bar"}, ["foo", "bar"]]:
        assert value == check_type_raw(value)



# Generated at 2022-06-22 22:19:37.430008
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('a,b,c') == ['a', 'b', 'c']
    assert check_type_list('a') == ['a']
    assert check_type_list([1,2,3,4]) == [1,2,3,4]


# Generated at 2022-06-22 22:19:41.212623
# Unit test for function check_required_one_of
def test_check_required_one_of():
    params={'name': 'Bob', 'shape': 'square'}
    require = [['name','shape']]
    try:
        ansible.module_utils.basic.check_required_one_of(require, params)
    except Exception as e:
        print(e)


# Generated at 2022-06-22 22:19:46.104442
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'required_param': 'present'}
    required_parameters = ['required_param']
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == []
    required_parameters = ['missing_param']
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == ['missing_param']



# Generated at 2022-06-22 22:19:53.770942
# Unit test for function check_required_together
def test_check_required_together():
    params = dict(a=1, b=2, c=3, d=4, e=5)
    test_spec = {
        'required_together': [
            ['a', 'b'],
        ]
    }

    try:
        check_required_together(test_spec['required_together'], params)
    except TypeError:
        assert False
    else:
        assert True

    test_spec = {
        'required_together': [
            ['a', 'b'],
            ['a', 'c'],
        ]
    }

    try:
        check_required_together(test_spec['required_together'], params)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-22 22:20:01.529462
# Unit test for function safe_eval
def test_safe_eval():
    examples = {
        '2 + 3': 5,
        'foo': 'foo',
        'foo.bar()': 'foo.bar()',
        'import os': 'import os',
        'a.decode()': 'a.decode()',
        'b.encode().decode()': 'b.encode().decode()',
    }
    for key, value in examples.items():
        assert safe_eval(key) == value



# Generated at 2022-06-22 22:20:13.376723
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{"a":123,"b":[1,2,3]}') == {"a": 123, "b": [1, 2, 3]}
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a":123,"b":[1,2,3]}', include_exceptions=True) == ({"a": 123, "b": [1, 2, 3]}, None)
    assert safe_eval('{"a":123,"b":[1,2,3]') == {"a": 123, "b": [1, 2, 3]}
    assert safe_eval('{"a":123,"b":[1,2,3]', include_exceptions=True) == ('{"a":123,"b":[1,2,3]', None)

# Generated at 2022-06-22 22:20:17.762820
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('test') == 'test'
    try:
        check_type_str({}, allow_conversion=False)
    except TypeError:
        pass
    else:
        assert False
    assert check_type_str(1) == '1'
    # TODO: write test for when check_type_str is called with a subclass of string



# Generated at 2022-06-22 22:20:23.650511
# Unit test for function count_terms
def test_count_terms():
    my_dict = {'test1': 'test1value', 'test2': 'test2value'}
    assert count_terms('test1', my_dict) == 1
    assert count_terms(['test1', 'test2'], my_dict) == 2
    assert count_terms(['test1', 'test3'], my_dict) == 1
    assert count_terms(['test3'], my_dict) == 0
    assert count_terms(['test3', 'test4'], my_dict) == 0



# Generated at 2022-06-22 22:20:26.969894
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('foo', {'foo': 'bar', 'bar': 'foo'}) == 1
    assert count_terms('foo', {'foo': 'bar', 'baz': 'foo'}) == 2
    assert count_terms(['foo', 'bar'], {'foo': 'bar', 'baz': 'foo'}) == 2
    assert count_terms(['foo', 'bar'], {'foo': 'bar', 'baz': 'bar'}) == 2



# Generated at 2022-06-22 22:20:37.616061
# Unit test for function check_required_by
def test_check_required_by():
    args = dict(
        req_key=dict(type='str', required=True),
        opt_key=dict(type='str'),
        req_by_opt_key=dict(type='str', required_if=[['opt_key', 'apples']]),
        req_by_req_key=dict(type='str', required_if=[['req_key', 'oranges']]),
        req_by_multiple=dict(type='str', required_if=[['req_key', 'oranges'], ['opt_key', 'apples']]),
        req_or=dict(type='str', required_if=[['req_key', 'oranges'], ['opt_key', 'apples', 'peaches']]),
    )


# Generated at 2022-06-22 22:20:38.175236
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    pass



# Generated at 2022-06-22 22:20:44.649815
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int("1") == 1
    try:
        check_type_int([])
        assert False, 'check_type_int([]) should failed'
    except TypeError:
        pass
    try:
        check_type_int(None)
        assert False, 'check_type_int(None) should failed'
    except TypeError:
        pass
    try:
        check_type_int({})
        assert False, 'check_type_int({}) should failed'
    except TypeError:
        pass


# Generated at 2022-06-22 22:20:55.207405
# Unit test for function check_required_by
def test_check_required_by():
    """
    Unit tests for check_required_by
    """
    def run_test_case(test_case):
        # Unpack the test case tuple
        (test_description, params, required_by, expected_result, expected_exception) = test_case
        print("{0}:".format(test_description))
        if expected_exception is not None:
            try:
                check_required_by(required_by, params)
                print('Expected: {0}'.format(expected_exception.__name__))
                print('Actual: No exception thrown.')
                print('FAILED:')
            except Exception as actual_exception:
                if isinstance(actual_exception, expected_exception):
                    print('Expected: {0}'.format(expected_exception.__name__))
                   

# Generated at 2022-06-22 22:20:59.576520
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {"name": "test", "state": "test"}
    required_parameters = ["name", "state"]
    result = check_missing_parameters(parameters, required_parameters)
    assert result == []
    parameters = {"name": "test"}
    required_parameters = ["name", "state"]
    result = check_missing_parameters(parameters, required_parameters)
    assert result == ['state']



# Generated at 2022-06-22 22:21:08.367102
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'arg1': {'required': True},
        'arg2': {'required': True},
        'arg3': {'required': True},
        'arg4': {'required': False},
    }
    parameters = {
        'arg1': 'a1',
        'arg2': 'a2',
        'arg3': 'a3',
    }
    options_context = ['foo', 'bar']
    missing = check_required_arguments(argument_spec, parameters, options_context)
    assert missing == []
    parameters.pop('arg2')
    options_context.append('test_check_required_arguments')

# Generated at 2022-06-22 22:21:16.112351
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('k1=v1, k2=v2, k3=v3') == {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}
    assert check_type_dict('k1=v1, k2=v2, k3=v3, k4="v,4"') == {'k1': 'v1', 'k2': 'v2', 'k3': 'v3', 'k4': 'v,4'}
    assert check_type_dict('k1=v1, k2=v2, k3=v3, k4=\'v,4\'') == {'k1': 'v1', 'k2': 'v2', 'k3': 'v3', 'k4': 'v,4'}
   

# Generated at 2022-06-22 22:21:27.783042
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('1,2,3') == ['1', '2', '3']
    assert check_type_list(['1', '2', '3']) == ['1', '2', '3']
    assert check_type_list(['1']) == ['1']
    assert check_type_list('1') == ['1']
    assert check_type_list(1) == ['1']
    assert check_type_list(1.123) == ['1.123']
    assert check_type_list(['1','2']) == ['1','2']
    assert check_type_list('1,2') == ['1','2']
    assert check_type_list(['1','2','3']) == ['1', '2', '3']

# Generated at 2022-06-22 22:21:32.091532
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg(['a', 'b']) == '["a", "b"]'
    assert check_type_jsonarg(['a', 'b', {'c': 'd'}]) == '["a", "b", {"c": "d"}]'



# Generated at 2022-06-22 22:21:36.151458
# Unit test for function check_type_int
def test_check_type_int():
    int_list = {'000': 0, '1': 1, '-1': -1, '000.000': TypeError, '1.1': TypeError, '-1.1': TypeError}
    for key, value in list(int_list.items()):
        if isinstance(value, int):
            assert check_type_int(key) == value
        else:
            try:
                check_type_int(key)
            except TypeError:
                pass
            else:
                raise AssertionError("check_type_int failed to raise TypeError")



# Generated at 2022-06-22 22:21:42.631791
# Unit test for function check_type_bool
def test_check_type_bool():
    for false_values in [False, '0', 'n', 'f', 'false', 'off']:
        assert False == check_type_bool(false_values)
    for true_values in [True, '1', 'on', 1, 'y', 't', 'yes']:
        assert True == check_type_bool(true_values)



# Generated at 2022-06-22 22:21:54.104784
# Unit test for function check_required_by
def test_check_required_by():
    param = {'a': None, 'b': None}
    require = {'a': ['b']}
    check_required_by(require, param)
    param = {'a': None, 'b': 'c'}
    require = {'a': ['b']}
    try:
        check_required_by(require, param)
    except:
        assert True
    else:
        assert False
    param = {}
    require = {}
    check_required_by(require, param)
    param = {'a': 'b'}
    require = {}
    check_required_by(require, param)
    param = {'a': 'b', 'c': 'd'}
    require = {'a': ['b', 'c']}
    check_required_by(require, param)

# Generated at 2022-06-22 22:22:02.050865
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(1) == 1
    assert safe_eval('1') == 1
    assert safe_eval('"a"') == "a"
    assert safe_eval('"a" if True else "b"') == "a"
    assert safe_eval('"a".replace("a","b")') == '"a".replace("a","b")'
    assert safe_eval('"a" if "import os" else "b"') == '"a" if "import os" else "b"'
    assert safe_eval('"a" if "os.system()" else "b"') == '"a" if "os.system()" else "b"'

