

# Generated at 2022-06-22 22:12:11.913014
# Unit test for function check_type_str
def test_check_type_str():
    # Attempt to convert a handful of items
    for i in (1, 1.0, [1], {'foo': 'bar'}, (1,), None):
        try:
            check_type_str(i)
        except TypeError as e:
            assert 'is not a string and conversion is not allowed' in to_native(e)
            continue
        assert isinstance(i, string_types)

    # Ensure the default allows conversion
    try:
        check_type_str('this is a string')
    except TypeError:
        assert False, 'Should not have raised an exception'

    # Now ensure that we can convert a non-string but with allow_conversion=True
    for i in (1, 1.0, [1], {'foo': 'bar'}, (1,), None):
        converted = check_type_str

# Generated at 2022-06-22 22:12:18.920575
# Unit test for function check_required_together
def test_check_required_together():
    """
    :return:
    """
    parameters_one = {'param_a': 'hello'}
    parameters_two = {'param_a': 'hello', 'param_b': 'goodbye'}
    possible_terms = [['param_a'], ['param_a'], ['param_a', 'param_b']]
    assert [] == check_required_together(possible_terms, parameters_two)
    with pytest.raises(TypeError):
        check_required_together(possible_terms, parameters_one)


# Generated at 2022-06-22 22:12:25.134463
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str(None, allow_conversion=True, param='foo', prefix='') == 'None'
    assert check_type_str(None, allow_conversion=False, param='foo', prefix='') is None
    assert check_type_str('foo', allow_conversion=False, param='foo', prefix='') == 'foo'
    assert check_type_str(1, allow_conversion=True, param='foo', prefix='') == '1'
    assert check_type_str(1, allow_conversion=False, param='foo', prefix='') == '1'
    assert check_type_str([], allow_conversion=False, param='foo', prefix='') == '[]'

# Generated at 2022-06-22 22:12:32.236399
# Unit test for function check_required_one_of
def test_check_required_one_of():
    parameters = dict(
      one=1,
      two=2,
      three=3
    )
    terms = [
      ['one', 'two'],
      ['three', 'four'],
      ['six','seven','eight']
    ]
    try:
      check_required_one_of(terms,parameters)
    except:
      return False
    return True
print('Check required one of: ', test_check_required_one_of())



# Generated at 2022-06-22 22:12:34.594286
# Unit test for function check_type_list
def test_check_type_list():
    value = 2
    check_type_list(value)



# Generated at 2022-06-22 22:12:43.602454
# Unit test for function check_type_list
def test_check_type_list():
  #Expected output: ['3', '4']
  v0 = check_type_list(3)
  #Expected output: ['3.0']
  v1 = check_type_list(3.0)
  #Expected output: [3, 4]
  v2 = check_type_list([3, 4])
  #Expected output: ['3,4']
  v3 = check_type_list('3,4')
  #Expected output: ['1,2,3,4']
  v4 = check_type_list(['1,2', '3,4'])
  #Expected output: ['one', 'two']
  v5 = check_type_list([1, 'one', 2, 'two'])



# Generated at 2022-06-22 22:12:50.966749
# Unit test for function check_required_together
def test_check_required_together():

    test_params = {'a': 'A', 'b': 'B', 'c': 'C'}

    assert [] == check_required_together(
        (), test_params)

    assert [] == check_required_together(
        [['a', 'b', 'c']], test_params)

    assert [] == check_required_together(
        [['a'], ['b']], test_params)

    assert [] == check_required_together(
        [['a'], ['b', 'c']], test_params)

    assert [['a', 'b']] == check_required_together(
        [['a', 'b'], ['c']], test_params)

    assert [['a']] == check_required_together(
        [['a', 'b'], ['c'], ['a']], test_params)

# Generated at 2022-06-22 22:13:01.423155
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    # Check that the function returned the very value in case its type is bytes, string
    cases = [
        (b'{"key": "value"}', b'{"key": "value"}'),
        (b'[1, 2, 3, 4]', b'[1, 2, 3, 4]'),
        (b'', b''),
        (u'{"key": "value"}', u'{"key": "value"}'),
        (u'[1, 2, 3, 4]', u'[1, 2, 3, 4]'),
        (u'', u'')
    ]
    for case in cases:
        assert check_type_jsonarg(case[0]) == case[1]

    # Check that the function return the JSON string of non-string value

# Generated at 2022-06-22 22:13:08.963939
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {}
    parameters = {}
    options_context = []
    # success case
    assert check_required_arguments(argument_spec, parameters, options_context) == []
    # fail case
    argument_spec['path'] = {}
    argument_spec['path']['required'] = True
    with pytest.raises(TypeError) as excinfo:
        check_required_arguments(argument_spec, parameters, options_context)
    assert "missing required arguments" in str(excinfo.value)



# Generated at 2022-06-22 22:13:14.134858
# Unit test for function check_type_str
def test_check_type_str():
    """Rudimentary test that functions correctly."""
    assert check_type_str('a test') == 'a test'
    assert check_type_str('a test', False) == 'a test'
    assert check_type_str(b'a test', True) == 'a test'
    with pytest.raises(TypeError) as exc:
        check_type_str(b'a test', False)
    assert 'not a string' in str(exc)



# Generated at 2022-06-22 22:13:19.743577
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('abcd') == 'abcd'
    assert check_type_str(b'abcd', allow_conversion=True) == 'abcd'
    assert check_type_str(u'abcd', allow_conversion=True) == 'abcd'
    assert check_type_str(b'abcd', allow_conversion=False) == 'abcd'
    assert check_type_str(u'abcd', allow_conversion=False) == 'abcd'

    # Invalid conversion
    assert check_type_str(b'abcd\xe5', allow_conversion=False) == None
    assert check_type_str(u'abcd\xe5', allow_conversion=False) == None

    # No conversion allowed

# Generated at 2022-06-22 22:13:31.249328
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{"a":[1, 2]}', include_exceptions=True) == ({'a': [1, 2]}, None)
    assert safe_eval('{"a":[1, 2]}') == {'a': [1, 2]}
    assert safe_eval('1+1') == 2
    assert safe_eval('[1, 2]+[3, 4]') == [1, 2, 3, 4]
    assert safe_eval('{"a":1+1}') == {'a': 2}
    assert safe_eval('1+1') == 2
    assert safe_eval('1+1') == 2
    assert safe_eval('1+1') == 2
    assert safe_eval('1+1') == 2
    assert safe_eval('foo') == 'foo'

# Generated at 2022-06-22 22:13:36.408019
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list([1,2,3]) == [1,2,3]
    assert check_type_list("1,2,3") == ['1', '2', '3']
    assert check_type_list(1) == ['1']
    assert_raises(TypeError, check_type_list, {'a':'b'})



# Generated at 2022-06-22 22:13:43.811833
# Unit test for function check_type_bool
def test_check_type_bool():
    # True
    assert check_type_bool('1') is True
    assert check_type_bool(1) is True
    assert check_type_bool('true') is True
    assert check_type_bool('on') is True
    assert check_type_bool('y') is True
    assert check_type_bool('yes') is True
    assert check_type_bool('t') is True
    assert check_type_bool('True') is True
    assert check_type_bool('On') is True
    assert check_type_bool('Y') is True
    assert check_type_bool('Yes') is True
    assert check_type_bool('T') is True
    # False
    assert check_type_bool('0') is False
    assert check_type_bool(0) is False

# Generated at 2022-06-22 22:13:55.834462
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = [['a', 'b'], ['b', 'c'], ['a', 'c']]
    parameters = dict(a=1, b=2, c=3)
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        raise AssertionError("Expectation is no exception but got %s" % e)

    parameters = dict(a=1, b=2, c=3, d=4)
    terms = [['a', 'd'], ['b', 'c'], ['a', 'c']]
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        raise AssertionError("Expectation is no exception but got %s" % e)


# Generated at 2022-06-22 22:14:03.003667
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'b': 1}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'e': 1}) == [['a', 'b'], ['c', 'd']]
    assert check_required_one_of([('a', 'b'), ('c', 'd')], {'b': 1}) == []
    assert check_required_one_of([('a', 'b'), ('c', 'd')], {'e': 1}) == [['a', 'b'], ['c', 'd']]



# Generated at 2022-06-22 22:14:08.125703
# Unit test for function check_required_together
def test_check_required_together():
    try:
        check_required_together(
            terms=[[['a', 'b'], ['c', 'd'], ['e', 'f']]],
            parameters={'b': 'global_path'}
        )
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-22 22:14:11.634372
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(['1', '2', '3'], {'1': 'a', '2': 'b', '3': 'c'}) == 3
    # Test a string is iterable
    assert count_terms('1', {'1': 'a'}) == 1



# Generated at 2022-06-22 22:14:19.732782
# Unit test for function count_terms
def test_count_terms():
    """Test for count_terms function"""

    assert count_terms(['abc', 'def'], {'abc': '123', 'def': '3', 'ghi': 'jkl'}) == 2
    assert count_terms('abc', {'abc': '123', 'def': '3', 'ghi': 'jkl'}) == 1



# Generated at 2022-06-22 22:14:24.445095
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    from collections import OrderedDict
    assert check_type_jsonarg('foo') == 'foo'
    assert check_type_jsonarg('["foo"]') == '["foo"]'
    assert check_type_jsonarg('{"foo": "bar"}') == '{"foo": "bar"}'
    assert check_type_jsonarg(['foo']) == '["foo"]'
    assert check_type_jsonarg(OrderedDict([('foo', 'bar')])) == '{"foo": "bar"}'


# Generated at 2022-06-22 22:14:28.378694
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('foo') == 'foo'
    assert check_type_raw(1) == 1
    assert check_type_raw(['foo']) == ['foo']



# Generated at 2022-06-22 22:14:34.302916
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('a') == 'a'
    assert check_type_path(u'a') == 'a'
    assert check_type_path(b'a') == 'a'
    assert check_type_path(1) == '1'
    assert check_type_path(1.1) == '1.1'
    assert check_type_path(False) == 'False'
    assert check_type_path(['a']) == '[a]'
    assert check_type_path({'a': 'b'}) == "{'a': 'b'}"
    assert check_type_path({'a': 'b'}) == "{'a': 'b'}"

    p = '~/test'
    assert check_type_path(p) == os.path.expanduser(p)


# Generated at 2022-06-22 22:14:42.391798
# Unit test for function safe_eval
def test_safe_eval():
    test_pass = safe_eval("{'a': 'b', 'c': 1}")
    assert isinstance(test_pass, dict)
    assert test_pass['a'] == 'b'
    assert test_pass['c'] == 1
    test_fail = safe_eval("{'a': 'b', 'c': 1} | fail", include_exceptions=True)
    assert isinstance(test_fail, tuple)
    assert test_fail[1] is not None
    assert test_fail[0] == "{'a': 'b', 'c': 1} | fail"
    test_fails_meth = safe_eval("subprocess.call('echo')", include_exceptions=True)
    assert isinstance(test_fails_meth, tuple)

# Generated at 2022-06-22 22:14:51.542794
# Unit test for function check_required_arguments
def test_check_required_arguments():
    try:
        check_required_arguments(argument_spec={'test_arg': {'required': True}}, parameters={})
    except Exception as e:
        assert 'missing required arguments: test_arg' in to_native(e)
    else:
        assert False

    try:
        check_required_arguments(argument_spec={}, parameters={'test_arg': None})
    except Exception as e:
        assert 'missing required arguments: ' in to_native(e)
    else:
        assert False

    assert check_required_arguments(argument_spec={}, parameters={}) == []



# Generated at 2022-06-22 22:14:59.718910
# Unit test for function check_type_path
def test_check_type_path():
    """Unit test for function check_type_path"""

    value = "/tmp"
    result = check_type_path(value)
    assert result == value

    value = 5
    try:
        result = check_type_path(value)
    except Exception:
        assert isinstance(result, TypeError)

    value = "~/test"
    result = check_type_path(value)
    assert result == os.path.expanduser(value)



# Generated at 2022-06-22 22:15:08.994638
# Unit test for function check_type_path
def test_check_type_path():
    "Unitest for function check_type_path"
    assert check_type_path("") == os.path.expanduser(os.path.expandvars(""))
    assert check_type_path("~/") == os.path.expanduser(os.path.expandvars("~/"))
    assert isinstance(check_type_path("~/"), str)
    assert isinstance(check_type_path(u"~/"), unicode)
    assert check_type_path("$HOME") == os.path.expanduser(os.path.expandvars("$HOME"))
    assert check_type_path("$HOME/") == os.path.expanduser(os.path.expandvars("$HOME/"))
    assert check_type_path("~$HOME/") == os.path.exp

# Generated at 2022-06-22 22:15:15.714867
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(2.0) == 2.0
    assert check_type_float('1') == 1.0
    assert check_type_float(u'3') == 3.0
    assert check_type_float(b'4') == 4.0
    with pytest.raises(TypeError):
        check_type_float(None)
    with pytest.raises(TypeError):
        check_type_float([])
    with pytest.raises(TypeError):
        check_type_float({})


# Generated at 2022-06-22 22:15:23.581101
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('~/.ansible/roles') == os.path.expanduser('~/.ansible/roles')
    assert check_type_path('$HOME/.ansible/roles') == os.path.expanduser('$HOME/.ansible/roles')
    assert check_type_path(b'/tmp/some/\xe4\xbd\xa0\xe5\xa5\xbd.txt') == '/tmp/some/\xe4\xbd\xa0\xe5\xa5\xbd.txt'



# Generated at 2022-06-22 22:15:31.332960
# Unit test for function count_terms
def test_count_terms():
    assert count_terms("my_var", dict(my_var=1)) == 1
    assert count_terms("my_var", dict(my_var=1, my_var1=1)) == 1
    assert count_terms("my_var", dict(my_var=1, my_var2=1)) == 1
    assert count_terms(["my_var", "my_var1"], dict(my_var=1, my_var1=1)) == 2



# Generated at 2022-06-22 22:15:37.545553
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(None) == False
    assert check_type_bool(True) == True
    assert check_type_bool(False) == False
    assert check_type_bool('foo') == False
    assert check_type_bool('0') == False
    assert check_type_bool('1') == True
    assert check_type_bool(0) == False
    assert check_type_bool(1) == True



# Generated at 2022-06-22 22:15:44.568372
# Unit test for function check_type_raw
def test_check_type_raw():
    """Unit for check_type_raw"""
    assert check_type_raw(3) == 3
    assert check_type_raw(3.4) == 3.4
    assert check_type_raw("string") == "string"
    assert check_type_raw(b"string") == b"string"
    assert check_type_raw([1, 2, 3]) == [1, 2, 3]
    assert check_type_raw({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}


# Generated at 2022-06-22 22:15:50.604191
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('foo') == os.path.expanduser(os.path.expandvars('foo'))
    assert check_type_path('foo') == os.path.expanduser(os.path.expandvars('foo'))
    assert check_type_path(123) == os.path.expanduser(os.path.expandvars('123'))


# FIXME: This code is a carbon copy of the code in
#        AnsibleModule._check_type_string(), if you fix this code you
#        should fix that code as well

# Generated at 2022-06-22 22:15:55.528160
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    pytest.skip()
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common._collections_compat import Mapping
    parameters = {'name': 'foo'}
    required_parameters = ['name', 'state']
    with pytest.raises(TypeError) as missing_params_test:
        check_missing_parameters(parameters, required_parameters)
    assert "missing required arguments: state" == missing_params_test.value.args[0]


# Generated at 2022-06-22 22:16:06.101641
# Unit test for function check_required_if
def test_check_required_if():
    # Testing for the case when is_one_of is True
    result = check_required_if([['state', 'present', ('path'), True]], {'state':'present', 'path':'ansible'} )
    assert(len(result) == 0)

    result = check_required_if([['state', 'present', ('path'), True]], {'state':'present'} )
    assert(len(result) == 1)
    assert(result[0]['parameter'] == 'state')
    assert(result[0]['value'] == 'present')
    assert(len(result[0]['missing']) == 1)
    assert(result[0]['missing'][0] == 'path')
    assert(result[0]['requires'] == 'any')

    # Testing for the case when is_one_of

# Generated at 2022-06-22 22:16:11.695489
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(4) == 4.0
    assert check_type_float(4.2) == 4.2
    assert check_type_float('4') == 4.0
    assert check_type_float('4.2') == 4.2
    pytest.raises(TypeError, check_type_float, [1,2,3])
    pytest.raises(TypeError, check_type_float, {'a': 1, 'b': 2})


# Generated at 2022-06-22 22:16:23.822603
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("'foo'") == 'foo'
    assert safe_eval("['a', 'b', 'c']") == ['a', 'b', 'c']
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'a': 1, 'b': 2, 'c': 3}") == {'a': 1, 'b': 2, 'c': 3}
    assert safe_eval("{'a': 'foo', 'b': 'bar', 'c': 'baz'}") == {'a': 'foo', 'b': 'bar', 'c': 'baz'}

# Generated at 2022-06-22 22:16:28.035950
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('10Mb') == 10485760
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1MB') == 1048576
    assert check_type_bits('1048576') == 1048576
    assert check_type_bits('10485760') == 10485760
    assert check_type_bits('1G') == 1073741824
    assert check_type_bits('1.5G') == 1572864000
    assert check_type_bits('1Tb') == 1099511627776
    assert check_type_bits('1b') == 1
    assert check_type_bits('1K') == 1024
    assert check_type_bits('8192') == 8

# Generated at 2022-06-22 22:16:40.296021
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('0') == 0
    assert check_type_bits('1') == 1
    assert check_type_bits('1.1') == 1
    assert check_type_bits('1b') == 1
    assert check_type_bits('2b') == 2
    assert check_type_bits('1k') == 1024
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1kbp') == 1024
    assert check_type_bits('2kb') == 2048
    assert check_type_bits('2kbp') == 2048
    assert check_type_bits('1kbit') == 1024
    assert check_type_bits('1kbits') == 1024
    assert check_type_bits('2kbit') == 2048

# Generated at 2022-06-22 22:16:47.870517
# Unit test for function check_required_by
def test_check_required_by():
    specs = {
        'argument_spec': dict(
            test_vars=dict(type='dict'),
            test_var1=dict(type='str'),
            test_var2=dict(type='int', required_by=dict(test_vars=('test_var1', 'test_var3'))),
            test_var3=dict(type='str', required_by=dict(test_vars='test_var4')),
        )
    }
    spec_class = dict2class(**specs)
    spec_obj = spec_class()
    test_vars = dict(test_var1='var1', test_var2=2, test_var4='var4')

# Generated at 2022-06-22 22:16:54.709071
# Unit test for function check_type_dict
def test_check_type_dict():

    assert check_type_dict('{"a":"b"}') == {'a':'b'}
    assert check_type_dict('{"a":"b", "c":"d", "e":"f"}') == {'a':'b', 'c':'d', 'e':'f'}
    assert check_type_dict('a=b') == {'a':'b'}
    assert check_type_dict('a=b c=d') == {'a':'b', 'c':'d'}
    assert check_type_dict('a=b, c=d') == {'a':'b', 'c':'d'}
    assert check_type_dict('a=b, c=d, e=f') == {'a':'b', 'c':'d', 'e':'f'}

# Generated at 2022-06-22 22:17:00.392733
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    assert [], check_missing_parameters(dict(a='yay', b='foo'), ['a', 'b'])
    with pytest.raises(TypeError) as cm:
        check_missing_parameters(dict(a='yay', b='foo'), ['a', 'b', 'c'])
    assert "missing required arguments: c" == str(cm.value)



# Generated at 2022-06-22 22:17:05.836257
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1MB') == 1048576
    assert check_type_bits('1 mb') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1 Mb') == 1048576
    assert check_type_bits('1') == 1


# Generated at 2022-06-22 22:17:17.243705
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'name': 'me', 'age': '18'}
    parameters = {'name': 'me', 'age': '18'}
    result = check_required_by(requirements, parameters)
    assert result == {}
    requirements = {'name': 'me'}
    parameters = {'name': 'me'}
    result = check_required_by(requirements, parameters)
    assert result == {}
    requirements = {'age': '18'}
    parameters = {'name': 'me', 'age': '18'}
    result = check_required_by(requirements, parameters)
    assert result == {}
    requirements = {'name': 'me'}
    parameters = {'age': '18'}
    result = check_required_by(requirements, parameters)

# Generated at 2022-06-22 22:17:25.118961
# Unit test for function check_required_arguments
def test_check_required_arguments():
    parameters = {
        'name': 'test_params',
        'state': 'present',
        'subkey': {
            'subkey1': 'subvalue1',
            'subkey2': 'subvalue2',
        },
    }
    argument_spec = {
        'name': {'required': True},
        'state': {'required': True},
        'subkey': {
            'subkey1': {'required': True},
            'subkey2': {'required': True},
        },
    }
    # If a required parameter is 'None'
    temp_para = parameters.copy()
    temp_para['name'] = None
    assert(check_required_arguments(argument_spec, temp_para) == ['name'])
    # If more than one required parameters are missing
    temp

# Generated at 2022-06-22 22:17:36.131100
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{"foo": "bar"}') == '{"foo": "bar"}'
    assert check_type_jsonarg('[1, 2, 3]') == '[1, 2, 3]'
    assert check_type_jsonarg('["foo", "bar"]') == '["foo", "bar"]'
    assert check_type_jsonarg({"foo": "bar"}) == '{"foo": "bar"}'
    assert check_type_jsonarg([1, 2, 3]) == '[1, 2, 3]'
    assert check_type_jsonarg(["foo", "bar"]) == '["foo", "bar"]'
# end of unit test for function check_type_jsonarg()


# Generated at 2022-06-22 22:17:48.558438
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(1) == 1
    assert check_type_bytes('1 m') == 1048576
    assert check_type_bytes('1 mib') == 1048576
    assert check_type_bytes('1 mb') == 1048576
    assert check_type_bytes('1 mbyte') == 1048576
    assert check_type_bytes('1 megabyte') == 1048576
    assert check_type_bytes('2 kibibytes') == 2048
    assert check_type_bytes('1 kibibit') == 128
    assert check_type_bytes('1 k') == 1024
    assert check_type_bytes('1 ki') == 1024
    assert check_type_bytes('1 kb') == 1000
    assert check_type_bytes('1 kbyte') == 1000

# Generated at 2022-06-22 22:17:53.616084
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together(
        [('param1', 'param2')],
        {'param1': '1'}
    ) == []

    assert check_required_together(
        [('param1', 'param2')],
        {'param1': '1', 'param2': '2'}
    ) == []

    assert check_required_together(
        [('param1', 'param2'), ('param3', 'param4')],
        {'param1': '1', 'param2': '2', 'param3':'3', 'param4':'4'}
    ) == []


# Generated at 2022-06-22 22:18:01.012284
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(terms=None, parameters=dict()) == []
    assert check_mutually_exclusive(terms=[['a', 'b']], parameters=dict(a=1)) == []
    assert check_mutually_exclusive(terms=[['a', 'b']], parameters=dict(b=1)) == []
    assert check_mutually_exclusive(terms=[['a', 'b']], parameters=dict(a=1, b=1)) == [['a', 'b']]



# Generated at 2022-06-22 22:18:07.022714
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    assert check_missing_parameters(dict(x=1), ['x']) == []
    assert check_missing_parameters(dict(x=1), ['y']) == ['y']
    assert check_missing_parameters(dict(x=1), ['y', 'z']) == ['y', 'z']
    assert check_missing_parameters(dict(x=1), []) == []
    assert check_missing_parameters(dict(), ['x']) == ['x']



# Generated at 2022-06-22 22:18:13.588816
# Unit test for function check_type_float
def test_check_type_float():
    assert isinstance(check_type_float("1.5"), float)
    with pytest.raises(TypeError):
        assert check_type_float("A")
    assert isinstance(check_type_float(u"1.5"), float)
    assert isinstance(check_type_float(1.5), float)
    assert isinstance(check_type_float(1), float)


# Generated at 2022-06-22 22:18:20.962325
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('~/foo') == os.path.expanduser('~/foo')
    assert check_type_path('$HOME/foo/bar') == os.path.expanduser('~/foo/bar')

    # If the path is a unicode string and the charset is None, it should return unicode
    path = to_text('~/foo', encoding=None)
    assert check_type_path(path) == path

    # If the path is a unicode string and the charset is not None, it should return a string
    path = to_text('~/foo', encoding='utf-8')
    assert check_type_path(path) == os.path.expanduser('~/foo')

    # If the path is a string and the charset is None, it should return a string

# Generated at 2022-06-22 22:18:26.292420
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    parameters = dict(gather_facts=True, tasks=[dict(debug=dict())])
    assert check_mutually_exclusive(
        terms=['tasks.gather_facts', 'tasks.debug'], parameters=parameters,
    )
    # test with list of lists
    assert check_mutually_exclusive(
        terms=[['tasks.gather_facts', 'tasks.debug']], parameters=parameters,
    )



# Generated at 2022-06-22 22:18:31.336802
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [['a', 'b'],['c', 'd']]
    parameters = {'a': 1, 'c': 2}
    check_required_one_of(terms, parameters)
    parameters = {'c': 2}
    check_required_one_of(terms, parameters)

    parameters = {'e': 2}
    try:
        check_required_one_of(terms, parameters)
    except TypeError as e:
        assert 'is required' in e.args[0]
    


# Generated at 2022-06-22 22:18:41.740621
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    # test for normal cases
    assert check_type_jsonarg(u'[{"a":"b"}]') == u'[{"a":"b"}]'

    # test for list
    assert check_type_jsonarg([{"a":"b"}]) == u'[{"a": "b"}]'

    # test for tuple
    assert check_type_jsonarg(([{"a":"b"}],)) == u'[{"a": "b"}]'

    # test for dict
    assert check_type_jsonarg({"a":"b"}) == u'{"a": "b"}'

    # test for invalid type
    with pytest.raises(TypeError):
        check_type_jsonarg(123)



# Generated at 2022-06-22 22:18:52.941687
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(14) == 14
    assert check_type_bytes('14') == 14
    assert check_type_bytes('3K') == 3 * 2**10
    assert check_type_bytes('1M') == 2**20
    assert check_type_bytes('1G') == 2**30
    assert check_type_bytes('0.5k') == int(.5 * 2**10)
    assert check_type_bytes('0.5K') == int(.5 * 2**10)
    assert check_type_bytes('0.5m') == int(.5 * 2**20)
    assert check_type_bytes('0.5M') == int(.5 * 2**20)
    assert check_type_bytes('0.5g') == int(.5 * 2**30)
    assert check

# Generated at 2022-06-22 22:19:00.815896
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('fred') == 'fred'
    assert check_type_str(u'fred') == 'fred'
    assert check_type_str(1) == '1'
    # NOTE: assertRaisesRegexp is deprecated
    with pytest.raises(TypeError) as excinfo:
        check_type_str(1, allow_conversion=False)
    assert "is not a string" in to_native(excinfo.value)
    assert "'1' is not a string and conversion is not allowed" == to_native(excinfo.value)


# FIXME: The param and prefix parameters here are coming from AnsibleModule._check_type_bool()
#        which is using those for the warning messaged based on string conversion warning settings.
#        Not sure how to deal with that here since we don't have config state

# Generated at 2022-06-22 22:19:03.314188
# Unit test for function check_type_int
def test_check_type_int():
    # valid cases
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1

    # invalid cases
    # bool type
    try:
        check_type_int(True)
    except TypeError:
        pass
    else:
        assert False

    # float type
    try:
        check_type_int('1.0')
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-22 22:19:13.349268
# Unit test for function check_required_together
def test_check_required_together():
    good1 = ['one', 'two']
    good2 = ['three', 'four']
    good_parameters = {'one': 1, 'two': 2, 'three': 3, 'four': 4}
    bad1 = ['one', 'two']
    bad2 = ['three', 'four']
    bad_parameters = {'one': 1, 'three': 3, 'four': 4}

    if check_required_together((good1, good2), good_parameters):
        raise Exception("Good test case failed")
    try:
        check_required_together((bad1, bad2), bad_parameters)
        raise Exception("Bad test case passed")
    except TypeError as e:
        pass



# Generated at 2022-06-22 22:19:17.969679
# Unit test for function check_required_together
def test_check_required_together():
    params = [{'a': 'A'}, {'b': 'B'}, {'a': 'A', 'b': 'B'}]
    err_msg = 'parameters are required together: a, b'
    for param in params:
        try:
            result = check_required_together([['a', 'b']], param, [])
        except TypeError as e:
            assert str(e) == err_msg, "param[%s]: %s" % (param, str(e))



# Generated at 2022-06-22 22:19:29.834461
# Unit test for function check_required_if

# Generated at 2022-06-22 22:19:40.438782
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by({'a': 'b'}, {'a': 'foo', 'b': 'bar'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'foo'}) == {'a': ['b']}
    assert check_required_by({'a': 'b'}, {}) == {'a': ['b']}
    assert check_required_by({'a': ['b', 'c']}, {'a': 'foo'}) == {'a': ['b', 'c']}
    assert check_required_by({'a': ['b', 'c']}, {'a': 'foo', 'b': 'bar'}) == {'a': ['c']}

# Generated at 2022-06-22 22:19:47.514216
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(["a", "b"], {"a": "", "b": ""}) == 2
    assert count_terms("a", {"a": "", "b": ""}) == 1
    assert count_terms("a", {"a": "", "b": "", "c": "", "d": ""}) == 1
    assert count_terms("a", {"b": "", "c": "", "d": ""}) == 0
    assert count_terms(["a", "b"], {"c": "", "d": ""}) == 0



# Generated at 2022-06-22 22:19:54.471960
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    test_terms = [
        ['iface', 'ifaces'],
        ['state', 'force'],
        ['name', 'address'],
    ]
    for test_parameters in [
        dict(iface='eth0'),
        dict(iface='eth0', state='present'),
        dict(iface='eth0', force=True),
        dict(ifaces=dict(eth0=dict())),
        dict(ifaces=dict(eth0=dict()), state='present'),
        dict(ifaces=dict(eth0=dict()), force=True),
    ]:
        assert check_mutually_exclusive(test_terms, test_parameters) == []


# Generated at 2022-06-22 22:20:06.984399
# Unit test for function check_required_if
def test_check_required_if():
    def _run_test(req, inp, exp):
        try:
            ans = check_required_if(req, inp)
        except TypeError as e:
            ans = e.results

        assert ans == exp

    # Test empty and missing requirements
    _run_test(None, {}, [])
    _run_test([], {}, [])

    # Test minimal requirements and input
    _run_test([['foo', 'bar', ['baz']]], {}, [{'parameter': 'foo',
                                                'value': 'bar',
                                                'requirements': ['baz'],
                                                'missing': ['baz'],
                                                'requires': 'all'}])

# Generated at 2022-06-22 22:20:12.123006
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    """Tests the function check_missing_parameters"""
    parameters = { 'name' : 'foo', 'state' : 'present' }
    required_parameters = [ 'name', 'state' ]
    result = check_missing_parameters(parameters, required_parameters)
    assert result == []


# Generated at 2022-06-22 22:20:21.045597
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1024') == 1024
    assert check_type_bits('1KB') == 1024
    assert check_type_bits('1kB') == 1024
    assert check_type_bits('1MB') == (1024 * 1024)
    assert check_type_bits('1Mb') == (1024 * 1024)
    assert check_type_bits('1GB') == (1024 * 1024 * 1024)
    assert check_type_bits('1Gb') == (1024 * 1024 * 1024)
    assert check_type_bits('1TB') == (1024 * 1024 * 1024 * 1024)
    assert check_type_bits('1Tb') == (1024 * 1024 * 1024 * 1024)
    assert check_type_bits('1PB') == (1024 * 1024 * 1024 * 1024 * 1024)
    assert check_type_bits('1Pb')

# Generated at 2022-06-22 22:20:25.949314
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    assert check_missing_parameters({}, None) == []
    assert check_missing_parameters({'foo': 'bar'}, ['foo']) == []
    try:
        check_missing_parameters({}, ['foo'])
    except TypeError as e:
        assert to_native(e) == 'missing required arguments: foo'


# Generated at 2022-06-22 22:20:36.788628
# Unit test for function check_required_arguments
def test_check_required_arguments():
    params = {'name': 'Test', 'path': '/'}

    # Test good with no required
    test_arg_spec = dict(
        required=False,
        name=dict(type='str'),
        path=dict(type='str'),
    )
    missing = check_required_arguments(test_arg_spec, params)
    assert missing == []

    # Test good with required
    test_arg_spec = dict(
        name=dict(type='str', required=True),
        path=dict(type='str'),
    )
    missing = check_required_arguments(test_arg_spec, params)
    assert missing == []

    # Test bad with required

# Generated at 2022-06-22 22:20:45.830700
# Unit test for function check_required_if
def test_check_required_if():
    import pytest

    with pytest.raises(TypeError) as error:
        check_required_if(
            requirements=[
                ['state', 'present', ('path',), True],
                ['someint', 99, ('bool_param', 'string_param')],
            ],
            parameters={
                'path': '/somepath',
                'someint': 99
            }
        )
    # check the message
    expected_message = 'string_param is required'
    assert expected_message in str(error.value)
    # check the result
    assert error.value.results == [{'required': 'any',
                                    'requirements': ('bool_param', 'string_param'),
                                    'parameter': 'someint',
                                    'missing': ['string_param'],
                                    'value': 99}]




# Generated at 2022-06-22 22:20:55.663267
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together([('a', 'b'), ('c', 'd'), ('e', 'f')], {'c': 'd'}) == []
    assert check_required_together([('a', 'b'), ('c', 'd'), ('e', 'f')], {'a': 'b'}) == []
    assert check_required_together([('a', 'b'), ('c', 'd'), ('e', 'f')], {'a': 'b', 'e': 'f'}) == [['c', 'd']]
    assert check_required_together([('a', 'b'), ('c', 'd'), ('e', 'f')], {'a': 'b', 'c': 'd'}) == []

# Generated at 2022-06-22 22:21:00.449211
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('True') == True
    assert check_type_bool('Yes') == True
    assert check_type_bool(1) == True
    assert check_type_bool('False') == False
    assert check_type_bool('No') == False
    assert check_type_bool(0) == False
    assert check_type_bool(False) == False
    assert_raises(TypeError, check_type_bool, 'a') == False



# Generated at 2022-06-22 22:21:06.912583
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True)
    assert check_type_bool('True')
    assert check_type_bool(1)
    assert not check_type_bool('false')
    assert not check_type_bool(False)
    assert not check_type_bool(0)
    assert not check_type_bool(None)
    assert_raises(TypeError,check_type_bool, 'not a boolean')
    assert_raises(TypeError,check_type_bool, 'not a boolean')



# Generated at 2022-06-22 22:21:19.049007
# Unit test for function check_type_bits
def test_check_type_bits():
    # sample input : '1Mb'
    # expected output : 1048576
    assert check_type_bits('1Mb') == 1048576
    # sample input : '1tb'
    # expected output : 1099511627776
    assert check_type_bits('1tb') == 1099511627776
    # sample input : '1g'
    # expected output : 1073741824
    assert check_type_bits('1g') == 1073741824
    # sample input : '1k'
    # expected output : 1024
    assert check_type_bits('1k') == 1024
    # sample input : '1gb'
    # expected output : 9223372036854775807
    assert check_type_bits('1gb') == 9223372036854775807
    # sample input : '

# Generated at 2022-06-22 22:21:25.186837
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('1') == True
    assert check_type_bool('on') == True
    assert check_type_bool(1) == True
    assert check_type_bool('0') == False
    assert check_type_bool(0) == False
    assert check_type_bool('n') == False
    assert check_type_bool('f') == False
    assert check_type_bool('false') == False
    assert check_type_bool('true') == True
    assert check_type_bool('y') == True
    assert check_type_bool('t') == True
    assert check_type_bool('yes') == True
    assert check_type_bool('no') == False
    assert check_type_bool('off') == False
    with pytest.raises(TypeError):
        check_type_

# Generated at 2022-06-22 22:21:30.381611
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1MB') == 1048576
    assert check_type_bits('1 mb') == 1048576
    assert check_type_bits('1 Mb') == 1048576
    assert check_type_bits('1 M') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('8.5G') == 9223372036854771712
    assert check_type_bits('8.5G') == 9223372036854771712
    assert check_type_bits('8.5Gb') == 9223372036854771712
    assert check_type_bits(8.5*1024) == 8796093022208

    # Unit test for check_

# Generated at 2022-06-22 22:21:32.112651
# Unit test for function check_type_float
def test_check_type_float():
  assert check_type_float(5) == 5.0
  assert check_type_float('5.0') == 5.0
  with pytest.raises(TypeError):
    check_type_float('5..0')


# Generated at 2022-06-22 22:21:43.794797
# Unit test for function check_required_one_of
def test_check_required_one_of():
    parameters = {'a': 'a', 'c': 'c'}

    try:
        check_required_one_of([['a'], ['b', 'c']], parameters)
        assert False
    except TypeError as e:
        assert "{0} found in ".format(e) not in str(e)

    try:
        check_required_one_of([['b'], ['b', 'c']], parameters)
        assert False
    except TypeError as e:
        assert "{0} found in ".format(e) not in str(e)

    try:
        check_required_one_of([['a', 'b']], parameters)
        assert False
    except TypeError as e:
        assert "{0} found in ".format(e) not in str(e)


# Generated at 2022-06-22 22:21:51.988673
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    missing_params = ['user', 'password']
    parameters = {'user': 'root', 'password': '123'}
    required_parameters = ['user', 'password', 'action']
    expected_result = []
    assert expected_result == check_missing_parameters(parameters, required_parameters)
    missing_params = ['action']
    parameters = {'user': 'root', 'password': '123'}
    expected_result = missing_params
    assert expected_result == check_missing_parameters(parameters, required_parameters)



# Generated at 2022-06-22 22:21:58.395093
# Unit test for function check_type_float
def test_check_type_float():
    assert_equal(check_type_float(1), 1.0, 'an integer should be converted to a float')
    assert_equal(check_type_float('1'), 1.0, 'a string integer should be converted to a float')
    assert_raises(TypeError, check_type_float, {'a': 1})
    assert_equal(check_type_float(1.0), 1.0, 'a float should be converted to a float')
    assert_equal(check_type_float('1.0'), 1.0, 'a string float should be converted to a float')
    assert_equal(check_type_float('1.0'), 1.0, 'a bytes float should be converted to a float')
    assert_raises(TypeError, check_type_float, ['1.0'])

# Generated at 2022-06-22 22:22:04.193830
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(u'1') == 1.0

    with pytest.raises(TypeError):
        check_type_float([])
    with pytest.raises(TypeError):
        check_type_float({})
    with pytest.raises(TypeError):
        check_type_float(object())

