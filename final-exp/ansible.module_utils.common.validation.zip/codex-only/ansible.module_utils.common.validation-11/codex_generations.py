

# Generated at 2022-06-22 22:12:04.545521
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Test for valid values and conversion
    assert check_type_bytes('1 KB') == 1024
    assert check_type_bytes('100MB') == 104857600

    # Test for invalid values and conversion
    with pytest.raises(TypeError):
        check_type_bytes('100T')



# Generated at 2022-06-22 22:12:13.045515
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [('state', 'present', ('path',), True), ('someint', 99, ('bool_param', 'string_param'))]
    parameters = {'path': '/some/path', 'bool_param': True}
    results = check_required_if(requirements, parameters)
    assert len(results) == 1
    assert results[0]['parameter'] == 'someint'
    assert results[0]['value'] == 99
    assert results[0]['requirements'] == ('bool_param', 'string_param')
    assert results[0]['missing'] == ['string_param']
    assert results[0]['requires'] == 'all'
    parameters['string_param'] = 'some_string'
    results = check_required_if(requirements, parameters)
    assert len(results) == 0



# Generated at 2022-06-22 22:12:16.275229
# Unit test for function check_type_raw
def test_check_type_raw():
    types = [
        'string',
        123,
        True,
        {'key': 'value'},
        ['value1','value2'],
    ]
    for i in types:
        assert i is check_type_raw(i)


# Generated at 2022-06-22 22:12:23.809666
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    list = ['a','b','c']
    new_list = check_type_jsonarg(list)
    if json.loads(new_list) != list:
        raise AssertionError("The returned list is not equal to the original list")

    dict = {'a':'b','c':'d'}
    new_dict = check_type_jsonarg(dict)
    # Convert to dict as jsonify returns an OrderedDict
    if dict != json.loads(new_dict):
        raise AssertionError("The returned dictionary is not equal to the original dictionary")

    string = 'string'
    new_string = check_type_jsonarg(string)
    if new_string != string:
        raise AssertionError("The returned string is not equal to the original string")



# Generated at 2022-06-22 22:12:27.380805
# Unit test for function check_type_int
def test_check_type_int():
    try:
        check_type_int("abc")
    except Exception as e:
        print("Expected Exception: ", e)


# Generated at 2022-06-22 22:12:32.353217
# Unit test for function count_terms
def test_count_terms():
    d = dict(a=1, b=2, c=3)
    terms = ['a', 'c']
    assert count_terms(terms, d) == 2
    assert count_terms(terms, dict(a=1, b=2, c=3)) == 2
    assert count_terms(terms, dict(a=1, b=2, d=3)) == 1



# Generated at 2022-06-22 22:12:36.780532
# Unit test for function check_required_if
def test_check_required_if():
    req = [
        ['state', 'present', ('path'), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]

    # If in the first case of the requirement (path),
    # atleast one of the requirements should be present.
    # For that reason, bool_param should be present
    param = {'state': 'present', 'bool_param': True}
    check_required_if(req, param)

    # If in the second case of the requirement (someint),
    # both the requirements (bool_param & string_param)
    # should be present.
    # For that reason, bool_param and string_param should
    # be present

# Generated at 2022-06-22 22:12:43.858397
# Unit test for function check_type_bytes
def test_check_type_bytes():
    for v, r in [('1MB', 1048576), ('1.1MB', 1048576), ('1 mb', 1048576), ('1 M', 1048576), ('1.5 kB', 1536),
                 ('-2 MB', -2097152), ('-2.5kb', -2560), ('-2.5 KB', -2560), ('0.5MB', 512000), ('0.5 KB', 512),
                 ('0.5kb', 512), (0, 0), (1, 1)]:
        assert check_type_bytes(v) == r


# Generated at 2022-06-22 22:12:54.732814
# Unit test for function check_required_one_of
def test_check_required_one_of():
    valid_set1 = [
            ('data_int', 'data_json'),
            ('data_int', 'data_string'),
            ('data_int', 'data_json', 'data_string'),
            ('data_json', 'data_string'),
            ]
    valid_set2 = [
            ('data_json', 'data_string'),
            ('data_json', 'data_int', 'data_string'),
            ('data_int', 'data_string'),
            ('data_int', 'data_json'),
            ]
    invalid_set = [
            ('data_json', 'data_string'),
            ('data_json', 'data_int', 'data_string'),
            ]

# Generated at 2022-06-22 22:13:06.511535
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments({'arg1': {}, 'arg2': {}, 'arg3': {}}, {}) == ['arg1', 'arg2', 'arg3']
    assert check_required_arguments({'arg1': {}, 'arg2': {}, 'arg3': {}}, {'arg1': 1, 'arg2': 'foo'}) == ['arg3']
    assert check_required_arguments({'arg1': {}, 'arg2': {}, 'arg3': {}, 'arg4': {}}, {'arg1': 1, 'arg2': 'foo'}) == ['arg3', 'arg4']
    assert check_required_arguments({'arg1': {'required': True}, 'arg2': {'required': True}, 'arg3': {}}, {}) == ['arg1', 'arg2']
    assert check

# Generated at 2022-06-22 22:13:15.241748
# Unit test for function check_type_str
def test_check_type_str():
    # FIXME: param and prefix are not used here
    #        Should probably use config here for warnings?
    _param = None
    _prefix = ''
    check_type_str('foo')
    check_type_str(123)
    check_type_str(True)
    check_type_str(b'bar')

    check_type_str('foo', True)
    assert check_type_str(123, True) == '123'
    assert check_type_str(True, True) == 'True'
    assert check_type_str(b'bar', True) == 'bar'
    assert check_type_str(True, False) == 'True'
    # Test a bad value will fail with allow_conversion=False
    assert check_type_str(object(), False) == 'object'




# Generated at 2022-06-22 22:13:19.065715
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('a,b,c') == ['a', 'b', 'c']
    assert check_type_list(1) == ['1']



# Generated at 2022-06-22 22:13:26.495102
# Unit test for function check_type_list
def test_check_type_list():
    try:
        assert check_type_list('abc') == ['abc']
        assert check_type_list(['abc']) == ['abc']
        assert check_type_list(['abc','def']) == ['abc','def']
        assert check_type_list('abc,def,ghi') == ['abc','def','ghi']
        assert check_type_list(5) == ['5']
        assert check_type_list(['5','4']) == ['5','4']
    except:
        assert False, "Invalid list passed for check_type_list"


# FIXME: The param and prefix parameters here are coming from AnsibleModule._check_type_string()
#        which is using those for the warning messaged based on string conversion warning settings.
#        Not sure how to deal with that here since we don't have config state

# Generated at 2022-06-22 22:13:32.757381
# Unit test for function check_type_str
def test_check_type_str():
    # Pass a literal value for convenience of testing
    for allow in [True, False]:
        assert check_type_str("hello", allow) == "hello"

    try:
        check_type_str(5, allow_conversion=False)
        assert False, 'should have raised exception'
    except TypeError:
        pass
    try:
        check_type_str(5, allow_conversion=True)
        assert False, 'should have raised exception'
    except TypeError:
        pass

    assert check_type_str(u'hello', allow_conversion=True) == u'hello'

# Generated at 2022-06-22 22:13:40.598842
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1024') == 1024
    assert check_type_bytes('10MB') == 10485760
    assert check_type_bytes('10 MiB') == 10485760
    assert check_type_bytes('10 GB') == 10737418240
    assert check_type_bytes('10G') == 10737418240
    assert check_type_bytes('10 GiB') == 10737418240
    assert check_type_bytes('4K') == 4096
    assert check_type_bytes('4 KiB') == 4096
    assert check_type_bytes('4KiB') == 4096
    # Empty value
    assert check_type_bytes('') == 0



# Generated at 2022-06-22 22:13:45.530180
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('1')
    assert check_type_bool('on')
    assert check_type_bool(1)
    assert not check_type_bool(0)
    assert not check_type_bool('0')
    assert not check_type_bool('n')
    assert not check_type_bool('f')
    assert not check_type_bool('false')
    assert check_type_bool('true')
    assert check_type_bool('y')
    assert check_type_bool('t')
    assert check_type_bool('yes')
    assert not check_type_bool('no')
    assert not check_type_bool('off')



# Generated at 2022-06-22 22:13:49.067697
# Unit test for function check_type_path
def test_check_type_path():
    assert os.path.expanduser(os.path.expandvars("~/.ansible")) == check_type_path("~/.ansible")



# Generated at 2022-06-22 22:13:53.482139
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('foo') == os.path.expanduser(os.path.expandvars('foo'))
    with pytest.raises(TypeError, match='int cannot be converted to a string'):
        check_type_path(1)


# Generated at 2022-06-22 22:13:59.262354
# Unit test for function check_required_if
def test_check_required_if():

    requirements=[
            ['state', 'present', ('path',), True],
            ['someint', 99, ('bool_param', 'string_param')]
    ]
    parameters = {'state': 'present', 'path': True, 'bool_param': True}
    assert check_required_if(requirements,parameters) == []

    parameters = {'state': 'present', 'path': True, 'bool_param': True, 'string_param': 'present'}
    assert check_required_if(requirements, parameters) == []


# Generated at 2022-06-22 22:14:04.672537
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg("{}") == "{}"
    assert check_type_jsonarg('{"foo": "bar"}') == '{"foo": "bar"}'
    assert check_type_jsonarg(['foo', 'bar']) == '["foo", "bar"]'
    assert check_type_jsonarg({'foo': 'bar'}) == '{"foo": "bar"}'
    assert check_type_jsonarg(['foo', {'bar': 'baz'}]) == '["foo", {"bar": "baz"}]'
    assert check_type_jsonarg(True) == 'true'
    assert check_type_jsonarg(None) == 'null'
    assert check_type_jsonarg(1) == '1'



# Generated at 2022-06-22 22:14:10.377421
# Unit test for function check_type_float
def test_check_type_float():
    for i in range(100):
        assert check_type_float(i * 0.01) == i * 0.01
        assert check_type_float(str(i * 0.01)) == i * 0.01
        assert check_type_float(b(str(i * 0.01))) == i * 0.01



# Generated at 2022-06-22 22:14:15.724471
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'one': {'required': False},
        'two': {'required': True},
        'three': {'required': True},
        'four': {'required': False}
    }
    parameters = {
        'one': 1,
        'three': 3
    }
    assert check_required_arguments(argument_spec, parameters) == ['two']

    parameters = {
        'one': 1,
        'two': 2,
        'four': 4
    }
    assert check_required_arguments(argument_spec, parameters) == ['three']

    parameters = {
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4
    }
    assert check_required_arguments(argument_spec, parameters) == []


# Generated at 2022-06-22 22:14:22.251520
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    import json
    params = {'param1': 'value1', 'param2': 'value2'}
    try:
        check_missing_parameters(params, ['param1', 'param2', 'param3'])
    except TypeError as e:
        e = json.loads(str(e))
        assert e['msg'] == "missing required arguments: param3"
        assert e['exception'] == 'TypeError'



# Generated at 2022-06-22 22:14:25.649776
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(['a', 'b'], {'a': 1, 'b': 2, 'c': 3}) == 2



# Generated at 2022-06-22 22:14:31.643526
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    """
    This is a test for the check_missing_parameters() function.
    """
    missing_params = []
    if missing_params:
        msg = "missing required arguments: %s" % ', '.join(missing_params)
        raise TypeError(to_native(msg))

    return missing_params

# Generated at 2022-06-22 22:14:39.106593
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # Check with no required parameters defined and empty parameters
    assert check_missing_parameters({}).__len__() == 0
    # Check with no required parameters defined and non-empty parameters
    assert check_missing_parameters({'foo': 'bar'}).__len__() == 0
    # Check with one required parameter and empty parameters
    assert check_missing_parameters({}, ['foo']).__len__() == 1
    # Check with one required parameter and non-empty parameters
    assert check_missing_parameters({'foo': 'bar'}, ['foo']).__len__() == 0



# Generated at 2022-06-22 22:14:45.315204
# Unit test for function check_type_bool
def test_check_type_bool():
    # Test for check_type_bool
    valid_true = ('1', 'on', 1, 'yes', 'true', 't', 'y')
    valid_false = ('0', 'off', 0, 'false', 'f', 'no', 'n')
    for value in valid_true:
        assert check_type_bool(value) == True

    for value in valid_false:
        assert check_type_bool(value) == False

    invalid_values = ('2', '3', 'on3', 'true false', 'true,false', '1,0', 2, 1.1, (1, 0), [])
    for value in invalid_values:
        with pytest.raises(TypeError):
            check_type_bool(value)



# Generated at 2022-06-22 22:14:54.981097
# Unit test for function check_required_together
def test_check_required_together():
    # test for success cases
    params = ['a', 'b', 'c', 'd']
    assert check_required_together(terms=[['a', 'b']], parameters=params) == []
    assert check_required_together(terms=[['a', 'b']], parameters=params) == []
    assert check_required_together(terms=[['a', 'b'], ['a', 'c']], parameters=params) == []
    assert check_required_together(terms=[['a', 'b'], ['b', 'd']], parameters=params) == []
    assert check_required_together(terms=[['a', 'b'], ['b', 'd'], ['c', 'd']], parameters=params) == []
    assert check_required_together(terms=[['a', 'b']], parameters=params) == []
    assert check_

# Generated at 2022-06-22 22:14:58.564050
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(None) is None
    assert check_type_raw([]) == []
    assert check_type_raw({}) == {}
    assert check_type_raw(1) == 1
    assert check_type_raw(1.1) == 1.1
    assert check_type_raw('a') == 'a'



# Generated at 2022-06-22 22:15:01.391202
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1


# Generated at 2022-06-22 22:15:06.289611
# Unit test for function check_required_by
def test_check_required_by():
    check_required_by({'key1': 'key2', 'key3': ['key4', 'key5']}, {'key1': 'value1'})  # no exception
    check_required_by({'key1': 'key2', 'key3': ['key4', 'key5']}, {'key3': 'value3'})  # no exception
    check_required_by({'key1': 'key2', 'key3': ['key4', 'key5']}, {'key2': 'value2', 'key1': 'value1'})  # no exception
    check_required_by({'key1': 'key2', 'key3': ['key4', 'key5']}, {'key3': 'value3', 'key4': 'value4'})  # no exception


# Generated at 2022-06-22 22:15:09.544191
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    assert check_missing_parameters(parameters={}, required_parameters=['a']) == []
    assert check_missing_parameters(parameters={'a': 1}, required_parameters=['a']) == []
    assert check_missing_parameters(parameters={'a': 1}, required_parameters=['b', 'a']) == []
    assert check_missing_parameters(parameters={'a': 1}, required_parameters=['b', 'c']) == ['b', 'c']



# Generated at 2022-06-22 22:15:18.249356
# Unit test for function check_type_float
def test_check_type_float():
    assert type(check_type_float(0)) is float
    assert type(check_type_float(2.2)) is float
    assert type(check_type_float(3.5)) is float
    assert type(check_type_float('2.2')) is float
    assert type(check_type_float(b'3.5')) is float
    assert type(check_type_float(u'3.5')) is float
    assert type(check_type_float(2)) is float
    assert type(check_type_float('2')) is float
    assert type(check_type_float(b'3')) is float
    assert type(check_type_float(u'3')) is float

# Generated at 2022-06-22 22:15:24.139581
# Unit test for function check_required_one_of
def test_check_required_one_of():
    try:
        from ansible.module_utils.common.validation import check_required_one_of
        parameters = {'parameter_one': 'value', 'parameter_two': 'value'}
        terms = [['parameter_three'], ['parameter_four']]  #fail
        check_required_one_of(terms, parameters)
    except Exception as ex:
        print(ex.message)
        raise ex


# Generated at 2022-06-22 22:15:29.620693
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('Hello World') == 'Hello World'
    assert check_type_raw(20) == 20
    assert check_type_raw(['a', 'b']) == ['a', 'b']
    assert check_type_raw(dict(a=1, b=2)) == dict(a=1, b=2)



# Generated at 2022-06-22 22:15:38.000080
# Unit test for function check_type_str
def test_check_type_str():
    assert isinstance(check_type_str(True, allow_conversion=False), bool)
    try:
        check_type_str(False, allow_conversion=True)
        raise Exception('check_type_str OK')
    except TypeError:
        pass
    else:
        raise Exception('check_type_str Failed')
    assert isinstance(check_type_str(100, allow_conversion=True), str)
    assert isinstance(check_type_str(100, allow_conversion=False), int)



# Generated at 2022-06-22 22:15:46.077084
# Unit test for function check_required_together
def test_check_required_together():
    """Unit test for function check_required_together"""

    terms = [['foo', 'bar']]
    parameters = {'bar': 'baz', 'food': 'tasty'}
    assert check_required_together(terms, parameters) == []

    parameters = {'foo': 'baz'}
    try:
        check_required_together(terms, parameters)
        assert False, 'should have raised'
    except TypeError as e:
        assert "parameters are required together: foo, bar" in str(e)



# Generated at 2022-06-22 22:15:54.435381
# Unit test for function safe_eval
def test_safe_eval():
    datatype = type
    datatypes = "['list', 'str']"
    datastructure = "'str'"
    datastructures = "['list', 'str', ('tuple', 'of', 'str')]"
    assert type(safe_eval('datatypes')) == type(datatype(datatypes))
    assert type(safe_eval('datastructure')) == type(datatype(datastructure))
    assert type(safe_eval('datatypes')) == type(datatype(datastructures))
    assert safe_eval('datatypes') == safe_eval(datatypes)
    assert safe_eval('datastructure') == safe_eval(datastructure)
    assert safe_eval('datatypes') == safe_eval(datastructures)

# Generated at 2022-06-22 22:16:01.483340
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]

    # Test that 'someint' is required to be present in the parameter list
    # when set to value of 99
    parameters = {
        'state': 'present',
        'path': 'some_path',
    }
    result = check_required_if(requirements, parameters)
    assert len(result) == 0

    parameters = {
        'someint': 99,
        'state': 'present'
    }
    try:
        result = check_required_if(requirements, parameters)
    except TypeError as e:
        assert e.args[0].startswith('someint is 99')

# Generated at 2022-06-22 22:16:11.338403
# Unit test for function check_required_by
def test_check_required_by():
    # Test execution
    requirements = {'key1': ['param1', 'param2']}
    parameters = {'key1': 'value1', 'param1': 'value2'}
    assert check_required_by(requirements, parameters) == {}
    # Test execution
    requirements = {'key1': ['param1', 'param2']}
    parameters = {'key1': 'value1', 'param1': None}
    assert check_required_by(requirements, parameters) == {'key1': ['param2']}
    # Test execution
    requirements = {'key1': ['param1', 'param2']}
    parameters = {'key1': None, 'param1': None}
    assert check_required_by(requirements, parameters) == {}



# Generated at 2022-06-22 22:16:19.296934
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['param1', 'param2']], {'param1': 'a'}) == []
    assert check_required_one_of([['param1', 'param2']], {'param2': 'b'}) == []
    try:
        assert check_required_one_of([['param1', 'param2']], {})
    except TypeError:
        pass
    else:
        raise AssertionError("TypeError not raised")



# Generated at 2022-06-22 22:16:23.105162
# Unit test for function check_type_raw
def test_check_type_raw():
    raw_list = [
        'some raw',
        1,
        None,
        True,
        {'a': 1}
    ]

    for raw in raw_list:
        assert(check_type_raw(raw) == raw)


# Generated at 2022-06-22 22:16:31.394694
# Unit test for function check_type_bool
def test_check_type_bool():
    test_list = [
        (1, True),
        (0, False),
        (False, False),
        (True, True),
        ('T', True),
        ('F', False),
        ('N', False),
        ('Y', True),
        ('1', True),
        ('0', False),
        ('f', False),
        ('n', False),
        ('t', True),
        ('y', True),
        ('on', True),
        ('off', False),
        ('yes', True),
        ('no', False)
    ]
    for (v, res) in test_list:
        assert check_type_bool(v) == res


# Generated at 2022-06-22 22:16:42.137858
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('1') is True
    assert check_type_bool('true') is True
    assert check_type_bool('TRUE') is True
    assert check_type_bool('on') is True
    assert check_type_bool('ON') is True
    assert check_type_bool('y') is True
    assert check_type_bool('yes') is True
    assert check_type_bool('Y') is True
    assert check_type_bool('YES') is True
    assert check_type_bool(1) is True
    assert check_type_bool(True) is True

    assert check_type_bool('0') is False
    assert check_type_bool('false') is False
    assert check_type_bool('FALSE') is False
    assert check_type_bool('f') is False

# Generated at 2022-06-22 22:16:49.270354
# Unit test for function check_required_together
def test_check_required_together():
    try:
        assert check_required_together([('a', 'b', 'c')], {"a": 1, "b": 2}) == []
    except TypeError:
        assert False
    try:
        assert check_required_together([('a', 'b', 'c')], {"a": 1}) == [('a', 'b', 'c')]
    except TypeError:
        assert True
    try:
        assert check_required_together([('a', 'b', 'c')], {"a": 1, "b": 2, "c": 3}) == []
    except TypeError:
        assert False
    try:
        assert check_required_together([('a', 'b', 'c')], {"d": 4}) == [('a', 'b', 'c')]
    except TypeError:
        assert True



# Generated at 2022-06-22 22:16:51.736606
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float("3.14") == 3.14
    assert check_type_float("6") == 6.0
    assert check_type_float("4.2") == 4.2
    assert check_type_float("-1") == -1.0
    assert check_type_float("123.4567") == 123.4567
    assert check_type_float("-56.78") == -56.78


# Generated at 2022-06-22 22:17:02.619112
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('1')
    assert check_type_bool('on')
    assert check_type_bool(1)
    assert not check_type_bool('0')
    assert not check_type_bool('n')
    assert not check_type_bool(0)
    assert not check_type_bool('f')
    assert not check_type_bool('false')
    assert check_type_bool('true')
    assert check_type_bool('y')
    assert check_type_bool('t')
    assert check_type_bool('yes')
    assert not check_type_bool('no')
    assert not check_type_bool('off')
    assert isinstance(check_type_bool(True), bool)
    assert isinstance(check_type_bool(False), bool)
    assert check_type_

# Generated at 2022-06-22 22:17:15.235785
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'param1': ['param1', 'param2', 'param3'], 'param2': ['param1', 'param2', 'param3'], 'param3': ['param1', 'param2', 'param3']}
    parameters = {'param1': True, 'param2': True, 'param3': False, 'param4': True}
    options_context = ['content', 'options']
    #Test case with valid requirements:
    requirement_dict = check_required_by(requirements, parameters, options_context)
    assert requirement_dict == {}
    #Test case with invalid requirements:
    parameters = {'param1': True, 'param4': True}
    requirement_dict = check_required_by(requirements, parameters, options_context)

# Generated at 2022-06-22 22:17:24.019626
# Unit test for function check_type_bytes

# Generated at 2022-06-22 22:17:35.549701
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    from ansible.module_utils import basic
    parameters = {'name': 'test'}
    required_parameters = ['name', 'test']
    if __name__ == '__main__':
        basic._ANSIBLE_ARGS = None
    basic.ANSIBLE_METADATA = {'status': ['preview'], 'supported_by': 'community', 'version': '1.0'}
    basic.DOCUMENTATION = '''
---
module: test_check_missing_parameters
author:
  - "Your Name (@yourhandle)"
version_added: "2.4"
short_description: This is my test module
description:
  - This module does amazing things
options:
  name:
    description:
      - This is a message to send to the world
    required: true
    type: string
'''

# Generated at 2022-06-22 22:17:39.199865
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'WL_FQDN': 'www.weblogic.com'}
    required_parameters = ['WL_FQDN', 'WL_USER']
    assert(check_missing_parameters(parameters, required_parameters) == ['WL_USER'])


# Generated at 2022-06-22 22:17:48.764358
# Unit test for function check_type_str
def test_check_type_str():
    try:
        check_type_str('hi')
    except:
        pytest.fail("check_type_str('hi') should not throw exception")
    try:
        check_type_str({'a':1}, allow_conversion=True)
    except:
        pytest.fail("check_type_str({'a':1}) should not throw exception")
    with pytest.raises(Exception):
        check_type_str({'a':1})



# FIXME: The param and prefix parameters here are coming from AnsibleModule._check_type_list()
#        which is using those for the warning messaged based on list conversion warning settings.
#        Not sure how to deal with that here since we don't have config state to query.

# Generated at 2022-06-22 22:17:52.539560
# Unit test for function check_required_by
def test_check_required_by():
    parameters = dict(a="a_value", b="b_value")
    requirements = dict(a="b")
    # should pass
    assert check_required_by(requirements, parameters) == {}
    # should fail
    requirements = dict(a="missing_req")
    with pytest.raises(TypeError):
        check_required_by(requirements, parameters)
    # should pass
    requirements = dict(a=["missing_req"])
    assert check_required_by(requirements, parameters) == {}



# Generated at 2022-06-22 22:17:58.811292
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(['a', 'b', 'c'], {'a': 1, 'b': 2, 'c': 3, 'd': 4}) == 3
    assert count_terms(['a', 'b'], {'c': 3, 'd': 4}) == 0
    assert count_terms('a', {'a': 1, 'b': 2, 'c': 3}) == 1



# Generated at 2022-06-22 22:18:05.710431
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state':'present'}
    expected_err = "path is required when state is present"
    options_context = ['path']
    try:
        check_required_if(requirements, parameters, options_context)
        assert False
    except TypeError as e:
        assert expected_err in to_native(e)



# Generated at 2022-06-22 22:18:16.675464
# Unit test for function safe_eval
def test_safe_eval():
    # Test for valid use cases
    assert safe_eval('{{var}}') == '{{var}}'
    assert safe_eval('hello') == 'hello'
    assert safe_eval('hello %s' % os.path.sep, include_exceptions=True) == 'hello %s' % os.path.sep
    assert safe_eval('1+1') == 2
    assert safe_eval('[1,2]') == [1,2]
    assert safe_eval('{1:2}') == {1:2}
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('(1)') == 1
    # Test for invalid use cases
    assert safe_eval('import json') == 'import json'

# Generated at 2022-06-22 22:18:22.496830
# Unit test for function count_terms
def test_count_terms():
    """Unit test for count_terms"""
    assert count_terms('test', {'test': 1, 'something': 1}) == 1
    assert count_terms('test', {'test': 1, 'something': 1, 'test2': 1}) == 2
    assert count_terms(('test', 'something'), {'test': 1, 'something': 1, 'test2': 1}) == 2



# Generated at 2022-06-22 22:18:28.752940
# Unit test for function check_type_raw
def test_check_type_raw():
    result = check_type_raw(1)
    expected = 1
    assert result == expected
    result = check_type_raw("1")
    expected = "1"
    assert result == expected
    try:
        result = check_type_raw(None)
    except:
        expected = "No none values are allowed"
        raise


VALID_ATTRIBUTE_NAME_PATTERN = re.compile(r'[a-z_][a-z0-9_]*$', re.I)



# Generated at 2022-06-22 22:18:39.261445
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int('123') == 123
    assert check_type_int(789) == 789
    assert check_type_int(789.0) == 789
    assert check_type_int(789.5) == 789
    assert check_type_int(789.9) == 789
    # assert check_type_int(789.1) == 789
    assert check_type_int('789.1') == 789
    # assert check_type_int(789.9) == 789
    assert check_type_int('789.9') == 789
    with pytest.raises(TypeError):
        check_type_int('string')



# Generated at 2022-06-22 22:18:50.104377
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True) == True
    assert check_type_bool(False) == False
    assert check_type_bool(1) == True
    assert check_type_bool(0) == False
    assert check_type_bool('1') == True
    assert check_type_bool('0') == False
    assert check_type_bool('t') == True
    assert check_type_bool('f') == False
    assert check_type_bool('true') == True
    assert check_type_bool('false') == False
    assert check_type_bool('yes') == True
    assert check_type_bool('no') == False
    assert check_type_bool('y') == True
    assert check_type_bool('n') == False
    assert check_type_bool('') == False
    assert check_

# Generated at 2022-06-22 22:18:56.261496
# Unit test for function check_type_list
def test_check_type_list():
  assert check_type_list(["Nikhil", "Vikram"]) == ["Nikhil", "Vikram"]
  assert check_type_list("Nikhil") == ["Nikhil"]
  assert check_type_list(1) == ["1"]
  assert check_type_list(1.0) == ["1.0"]
  assert check_type_list("Nikhil,Vikram") == ["Nikhil", "Vikram"]
  try:
    check_type_list(2+3j)
  except TypeError as e:
    assert str(e) == 'complex cannot be converted to a list'


# Generated at 2022-06-22 22:19:07.975453
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert check_type_dict('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert check_type_dict('a=1, b=2, c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert check_type_dict('a="1", b=2, c=\'3\'') == {'a': '1', 'b': '2', 'c': '3'}
    # Note this is not a typo, the dictionary must be wrapped in double quotes
    # for the escaped single quote to be valid syntax.

# Generated at 2022-06-22 22:19:15.547725
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True) is True
    assert check_type_bool(False) is False
    assert check_type_bool('1') is True
    assert check_type_bool('on') is True
    assert check_type_bool(1) is True
    assert check_type_bool('0') is False
    assert check_type_bool(0) is False
    assert check_type_bool('n') is False
    assert check_type_bool('f') is False
    assert check_type_bool('false') is False
    assert check_type_bool('true') is True
    assert check_type_bool('y') is True
    assert check_type_bool('t') is True
    assert check_type_bool('yes') is True
    assert check_type_bool('no') is False
    assert check_

# Generated at 2022-06-22 22:19:24.008405
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test basic mutually exclusive situations
    params = {'a': 1, 'b': 2}
    check_mutually_exclusive([['a', 'b']], params)
    try:
        check_mutually_exclusive([['a', 'b', 'c']], params)
        assert False
    except TypeError:
        assert True
    # Test nested mutually exclusive
    params['c'] = 3
    params['d'] = 4
    params['e'] = 5
    params['f'] = 6
    check_mutually_exclusive([['a', 'b'], ['c', 'd'], ['e', 'f']], params)
    try:
        check_mutually_exclusive([['a', 'b'], ['c', 'd', 'e']], params)
        assert False
    except TypeError:
        assert True
    #

# Generated at 2022-06-22 22:19:36.505674
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1b') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1m') == 1024 ** 2
    assert check_type_bytes('1g') == 1024 ** 3
    assert check_type_bytes('1t') == 1024 ** 4
    # check_type_bytes('1p') == 1024 ** 5
    # check_type_bytes('1e') == 1024 ** 6
    # check_type_bytes('1z') == 1024 ** 7
    # check_type_bytes('1y') == 1024 ** 8
    with pytest.raises(TypeError):
        check_type_bytes('1a')

# Unsupported types will just return the value unchanged
# (The idea is to allow callers to attempt to validate any unknown types,
# and to allow additional types

# Generated at 2022-06-22 22:19:42.033695
# Unit test for function check_type_bytes
def test_check_type_bytes():
    "Unit test for function check_type_bytes"
    assert check_type_bytes('200b') == 200
    assert check_type_bytes('400kb') == 400 * 1024
    assert check_type_bytes('12345') == 12345
    assert check_type_bytes('12345mb') == 12345 * 1024 * 1024
    assert check_type_bytes('2gb') == 2 * 1024 * 1024 * 1024
    assert check_type_bytes('3tb') == 3 * 1024 * 1024 * 1024 * 1024



# Generated at 2022-06-22 22:19:51.127538
# Unit test for function safe_eval
def test_safe_eval():

    assert safe_eval('7') == 7
    assert safe_eval('-7') == -7
    assert safe_eval('7.') == 7.0
    assert safe_eval('-7.0') == -7.0
    assert safe_eval('True')
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"foo": 42}') == {'foo': 42}
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('complex(1,2)') == 1 + 2j

# Generated at 2022-06-22 22:19:57.756734
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {'a':'a', 'b':'b'}
    terms = [('a', 'b', 'c')]
    results = check_required_together(terms, parameters)
    assert not results
    parameters = {'a':'a'}
    terms = [('a', 'b', 'c')]
    results = check_required_together(terms, parameters)
    assert results



# Generated at 2022-06-22 22:20:04.030202
# Unit test for function check_type_path
def test_check_type_path():
    value1 = '/usr/local/bin'
    value2 = '$HOMEDIR/local/bin'
    value3 = '~/local/bin'
    assert check_type_path(value1) == '/usr/local/bin'
    assert check_type_path(value2) == '/root/local/bin'
    assert check_type_path(value3) == '/root/local/bin'


# Generated at 2022-06-22 22:20:10.559676
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(15) == 15
    assert check_type_raw(['a', 'list']) == ['a', 'list']
    assert check_type_raw('a string') == 'a string'
    assert check_type_raw(u'a unicode string') == u'a unicode string'
# End unit test for function check_type_raw



# Generated at 2022-06-22 22:20:19.904105
# Unit test for function check_required_if
def test_check_required_if():
        # Checking when requirement parameters are valid
        parameters = {'path': '/some/path', 'state': 'present'}
        results = check_required_if([['state', 'present', ('path',), True]], parameters)
        assert results == []

        parameters = {'path': '/some/path', 'state': 'present', 'bool_param': True, 'string_param': 'SomeValue'}
        results = check_required_if([['someint', 99, ('bool_param', 'string_param')]], parameters)
        assert results == []

        parameters = {'path': '/some/path', 'bool_param': True, 'string_param': 'SomeValue'}
        results = check_required_if([['someint', 99, ('bool_param', 'string_param')]], parameters)
        assert results == []

       

# Generated at 2022-06-22 22:20:21.809537
# Unit test for function check_type_list
def test_check_type_list():
    pass



# Generated at 2022-06-22 22:20:27.767360
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together(terms=[('a', 'b')], parameters={'a': 'av', 'b': 'bv'}) == []
    assert check_required_together(terms=[('a', 'b')], parameters={'a': 'av'}) == [('a', 'b')]
    assert check_required_together(terms=[('a', 'b')], parameters={'c': 'cv'}) == [('a', 'b')]



# Generated at 2022-06-22 22:20:32.496300
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [('a', 'b', 'c', 'd')]
    d = dict(a=10, b=20, c=30)
    rtn = check_required_one_of(terms, d)
    assert rtn == []
    d = dict(e=10, f=20, g=30)
    with pytest.raises(TypeError):
        check_required_one_of(terms, d)



# Generated at 2022-06-22 22:20:41.599486
# Unit test for function check_type_str
def test_check_type_str():
    result = check_type_str('test')
    assert result == "test"
    result = check_type_str(b'test')
    assert result == "test"
    result = check_type_str(b'test\xe2\x80\x9d')
    assert result == "test”"
    result = check_type_str(b'test\xe2\x80\x9d', allow_conversion=False)
    assert isinstance(result, TypeError)
    result = check_type_str(b'test\xff')
    assert result == "test\xff"
    result = check_type_str(b'test\xff', allow_conversion=False)
    assert isinstance(result, TypeError)



# Generated at 2022-06-22 22:20:54.410540
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of(terms=None, parameters={'name': 'test'}) == []
    assert check_required_one_of(terms=None, parameters={'name': None}) == []
    assert check_required_one_of(terms=[('a', 'b')], parameters={'a':'a_value', 'b': 'b_value'}) == []
    assert check_required_one_of(terms=[('a', 'b')], parameters={'a':'a_value', 'b': None}) == []

    try:
        assert check_required_one_of(terms=[('a', 'b')], parameters={'a':None, 'b': None})
    except TypeError as e:
        assert "one of the following is required: a, b" == to_native(e)


# Generated at 2022-06-22 22:21:05.265500
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list("") == [""]
    assert check_type_list("a") == ["a"]
    assert check_type_list("a,b") == ["a", "b"]
    assert check_type_list("  a,  b ") == ["a", "b"]
    assert check_type_list(["a"]) == ["a"]
    assert check_type_list([1]) == ["1"]
    assert check_type_list([1, "a"]) == ["1", "a"]
    assert check_type_list([]) == []
    assert check_type_list(1) == ["1"]
    assert check_type_list(1.1) == ["1.1"]

# Generated at 2022-06-22 22:21:14.272088
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True) == True
    assert check_type_bool(False) == False
    assert check_type_bool(1) == True
    assert check_type_bool(0) == False
    assert check_type_bool("True") == True
    assert check_type_bool("False") == False
    assert check_type_bool("true") == True
    assert check_type_bool("false") == False
    assert check_type_bool("t") == True
    assert check_type_bool("f") == False
    assert check_type_bool("yes") == True
    assert check_type_bool("no") == False
    assert check_type_bool("y") == True
    assert check_type_bool("n") == False
    assert check_type_bool("on") == True
    assert check_

# Generated at 2022-06-22 22:21:23.443076
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    test_none_terms = check_mutually_exclusive(None, [1,2,3])
    assert test_none_terms is None
    try:
        test_fail_terms = check_mutually_exclusive([['a', 'b']], {'a':1, 'b':2})
        assert False
    except TypeError:
        assert True
    try:
        test_fail_terms = check_mutually_exclusive([['a', 'b']], {'a':1, 'b':2}, options_context=['foo', 'bar'])
        assert False
    except TypeError as e:
        assert e.args[0] == 'parameters are mutually exclusive: a|b found in foo -> bar'


# Generated at 2022-06-22 22:21:34.193800
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{'a':1}") == {'a': 1}
    assert check_type_dict("{u'a': u'b'}") == {'a': 'b'}
    assert check_type_dict("a=1,b=2") == {'a': '1', 'b': '2'}
    assert check_type_dict("a=1 b=2") == {'a': '1', 'b': '2'}
    assert check_type_dict('a=1, b="hello, world"') == {'a': '1', 'b': '"hello, world"'}
    assert check_type_dict('a="foo\\\\bar"') == {'a': '"foo\\\\bar"'}

# Generated at 2022-06-22 22:21:40.228874
# Unit test for function check_required_if
def test_check_required_if():
    module_args = {
        'valid_param1': 'value1',
        'valid_param2': 'value2',
        'conditional_param1': 'value1',
        'conditional_param2': 'value2'
    }

    # Test with is_one_of set to True.
    missing = check_required_if([
        ['conditional_param1', 'value1', ['conditional_param2'], True]
    ], module_args)
    assert not missing

    # Conditional param 'conditional_param2' is missing
    # raise exception

# Generated at 2022-06-22 22:21:47.506624
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{}') == '{}'
    assert check_type_jsonarg(['{}']) == '["{}"]'
    assert check_type_jsonarg('["{}"]') == '["{}"]'
    assert check_type_jsonarg(1) == '1'
    assert check_type_jsonarg(None) == 'null'
    assert check_type_jsonarg([None]) == '[null]'


# Generated at 2022-06-22 22:21:57.836947
# Unit test for function check_type_dict
def test_check_type_dict():
    test_dict1 = "{'k1': 2, 'a': 'b'}"
    test_dict2 = "k1=2, a='b'"
    test_dict3 = "{'k1': 2, 'a': 'b'}"
    test_dict4 = "{'k1': 2, 'a': 'b'}"

    my_dict1 = check_type_dict(test_dict1)
    my_dict2 = check_type_dict(test_dict2)
    my_dict3 = check_type_dict(test_dict3)
    my_dict4 = check_type_dict(test_dict4)

    assert my_dict1 == my_dict2 == my_dict3 == my_dict4



# Generated at 2022-06-22 22:22:00.463998
# Unit test for function check_type_int
def test_check_type_int():
    check_type_int(1)
    check_type_int("123")
    try:
        check_type_int("abc")
    except TypeError:
        pass
    else:
        assert False, "Should have thrown TypeError when passing in a string"
