

# Generated at 2022-06-20 16:26:14.616524
# Unit test for function check_required_one_of
def test_check_required_one_of():
    try:
        options_context = ['']
        parameters = {'state': 'present'}
        terms = [('name', 'names')]
        check_required_one_of(terms, parameters, options_context)
    except TypeError as e:
        assert "found in" in str(e)


# Generated at 2022-06-20 16:26:18.835882
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['a', 'b']], {'a': 1}) == []
    assert check_required_one_of([('a', 'b')], {'a': 1}) == []
    assert check_required_one_of([('a', 'b')], {'b': 1}) == []
    assert check_required_one_of([('a', [1, 2])], {'b': 1}) == []



# Generated at 2022-06-20 16:26:30.010358
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together(
        [
            ['a', 'b'],
            ['c', 'd']
        ], {
            'a': 1,
            'c': 1,
            'b': 1,
            'd': 1
        }
    ) == []
    try:
        check_required_together(
            [
                ['a', 'b'],
                ['c', 'd']
            ], {
                'a': 1,
                'c': 1,
                'b': 1
            }
        )
    except TypeError as e:
        assert 'parameters are required together: c, d' == str(e)

# Generated at 2022-06-20 16:26:33.622577
# Unit test for function check_type_int
def test_check_type_int():
    for value in [1, 2.0, '3', '4.0']:
        assert check_type_int(value) == int(value)
    for value in [1.1, '3.1', 'a']:
        try:
            check_type_int(value)
            assert False
        except TypeError:
            pass


# Generated at 2022-06-20 16:26:43.472528
# Unit test for function check_type_str
def test_check_type_str():
    """Unit test for function check_type_str"""
    if sys.version_info[0] < 3 and sys.version_info[1] <= 5:
        assert check_type_str(b'foo') == u'foo'
        assert check_type_str(u'foo') == u'foo'
        with pytest.raises(Exception) as excinfo:
            assert check_type_str(b'foo', allow_conversion=False)
        assert 'does not match' in str(excinfo.value)
        with pytest.raises(Exception) as excinfo:
            assert check_type_str(u'foo', allow_conversion=False)
        assert 'does not match' in str(excinfo.value)
    else:
        assert check_type_str(b'foo') == 'foo'

# Generated at 2022-06-20 16:26:55.031083
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(['a', 'b'], {'a': True, 'b': False}) == []
    assert check_mutually_exclusive([['a', 'b']], {'a': True, 'b': False}) == []
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': True, 'b': False, 'c': False}) == []
    assert check_mutually_exclusive([['a', 'b'], ['a', 'c']], {'a': True, 'b': False, 'c': False}) == [['a', 'c']]

# Generated at 2022-06-20 16:27:06.287228
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('a,b,c') == ['a', 'b', 'c']
    assert check_type_list(' a, b, c ') == ['a', 'b', 'c']
    assert check_type_list(1) == ['1']
    assert check_type_list('1') == ['1']
    assert check_type_list(1.1) == ['1.1']
    assert check_type_list(['a', 'b']) == ['a', 'b']
    try:
        check_type_list(('a', 'b'))
        assert False, "Expected exception from check_type_list"
    except TypeError:
        pass

# Generated at 2022-06-20 16:27:07.755181
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw("some_value") == "some_value"



# Generated at 2022-06-20 16:27:10.798872
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'arg1':'value'}
    required_parameters = ['arg1']
    assert check_missing_parameters(parameters, required_parameters) == []

    parameters = {'arg1':'value'}
    required_parameters = ['arg1','arg2']
    assert check_missing_parameters(parameters, required_parameters) == ['arg2']



# Generated at 2022-06-20 16:27:16.282694
# Unit test for function check_type_dict
def test_check_type_dict():
    # test_check_type_dict_converted_to_dict_1
    assert check_type_dict('key1=value1, key2=value2') == {'key1':'value1','key2':'value2'}
    # test_check_type_dict_converted_to_dict_2
    assert check_type_dict('key1=value1,key2=value2') == {'key1':'value1','key2':'value2'}
    # test_check_type_dict_converted_to_dict_3
    assert check_type_dict('"key1"=value1,"key2"=value2') == {'key1':'value1','key2':'value2'}
    # test_check_type_dict_converted_to_dict_4
    assert check

# Generated at 2022-06-20 16:27:37.632211
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['X', 'Y', 'Z'], ['A', 'B', 'C']], {'X': 'val'}) == []
    assert check_required_one_of([['X', 'Y', 'Z'], ['A', 'B', 'C']], {'X': 'val', 'A': 'val'}) == []
    assert check_required_one_of([['X', 'Y', 'Z'], ['A', 'B', 'C']], {'X': 'val', 'Z': 'val'}) == []
    assert check_required_one_of([['X', 'Y', 'Z'], ['A', 'B', 'C']], {'X': 'val', 'Z': 'val', 'B': 'val'}) == []

# Generated at 2022-06-20 16:27:41.428512
# Unit test for function check_type_list
def test_check_type_list():
    assert ['a', 'b', 'c'] == check_type_list(['a', 'b', 'c'])
    assert ['a', 'b', 'c'] == check_type_list('a,b,c')
    assert ['3'] == check_type_list(3)
    assert ['3.14'] == check_type_list(3.14)



# Generated at 2022-06-20 16:27:43.578639
# Unit test for function check_type_raw
def test_check_type_raw():
    """Returns the raw value for test cases with testinfra."""
    value = 'test'
    assert check_type_raw(value) == 'test'

# Generated at 2022-06-20 16:27:51.140403
# Unit test for function check_type_dict
def test_check_type_dict():
    d = check_type_dict('{"a": 1, "b": 2}')
    assert d['a'] == 1
    assert d['b'] == 2
    d = check_type_dict('a=1, b=2')
    assert d['a'] == '1'
    assert d['b'] == '2'
    d = check_type_dict('a=1, b=2, c, d=2')
    assert d['a'] == '1'
    assert d['b'] == '2'
    assert d['c'] == ''
    assert d['d'] == '2'
    d = check_type_dict('a="1, 2", b=2')
    assert d['a'] == '"1, 2"'
    assert d['b'] == '2'

# Generated at 2022-06-20 16:28:00.220673
# Unit test for function check_required_if
def test_check_required_if():
    from ansible.module_utils.common.text.formatters import boolean

    # #########################################
    # # Test cases where condition is True
    # #########################################

    # When condition is true,
    # and when is_one_of is False, all requirements should be present
    requirements = [
        ['state', 'present', ('path',), False],
        ['someint', 99, ('bool_param', 'string_param'), False],
    ]

    # Case 1: When all required parameters are present
    parameters = dict(state='present', path='/tmp', someint=99,
                      bool_param=True, string_param='test')
    results = check_required_if(requirements, parameters)
    assert len(results) == 0, results

    # Case 2: When all required parameters are not present

# Generated at 2022-06-20 16:28:07.579308
# Unit test for function check_required_by

# Generated at 2022-06-20 16:28:19.579480
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list("a") == ["a"]
    assert check_type_list("a,b,c") == ["a", "b", "c"]
    assert check_type_list(["a", "b", "c"]) == ["a", "b", "c"]
    assert check_type_list("1") == ["1"]
    assert check_type_list("1,2,3") == ["1", "2", "3"]
    assert check_type_list([1, 2, 3]) == ["1", "2", "3"]
    assert check_type_list(1) == ["1"]
    assert check_type_list([1, 2.0, 3.5]) == ["1", "2.0", "3.5"]

# Generated at 2022-06-20 16:28:24.280510
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('y') == 'y'
    assert check_type_raw(1) == 1
    assert check_type_raw(['y']) == ['y']
    assert check_type_raw(['y', 1]) == ['y', 1]
    assert check_type_raw({'a': 'b'}) == {'a': 'b'}
    assert check_type_raw(True) == True

# Generated at 2022-06-20 16:28:34.965975
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(u'True') is True
    assert safe_eval(u'False') is False
    assert safe_eval(u'[1, 2, 3]') == [1, 2, 3]
    assert safe_eval(u'{"a": "b"}') == {u'a': u'b'}
    assert safe_eval(u'none') == u'none'

    # check we have good exception handling
    assert safe_eval(u"{'a':'b'") is not None
    assert safe_eval(u"foo()") == u"foo()"

    # make sure we don't allow malicious code execution
    assert safe_eval(u"__import__('os').system('echo got rick rolled')") == u"__import__('os').system('echo got rick rolled')"



# Generated at 2022-06-20 16:28:39.140433
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(u'1.0') == 1.0


# Generated at 2022-06-20 16:28:51.806901
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('["foo", "bar"]') == ["foo", "bar"]
    assert safe_eval('True', include_exceptions=True) == (True, None)
    assert safe_eval('False', include_exceptions=True) == (False, None)
    assert safe_eval('None', include_exceptions=True) == (None, None)
    assert safe_eval('module.func()', include_exceptions=True)[0] == 'module.func()'
    assert safe_eval('module.func()', include_exceptions=True)[1] is None
    assert safe_eval('import foo', include_exceptions=True)[0] == 'import foo'

# Generated at 2022-06-20 16:28:59.892844
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(["a", "b", "c"]) == ["a", "b", "c"]
    assert check_type_list("a") == ["a"]
    assert check_type_list("a,b,c") == ["a", "b", "c"]
    assert check_type_list(123) == ["123"]
    assert check_type_list(123.456) == ["123.456"]
    try:
        check_type_list({"a": "1"})
        assert False
    except TypeError:
        pass



# Generated at 2022-06-20 16:29:07.781030
# Unit test for function check_required_if

# Generated at 2022-06-20 16:29:10.625213
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(True)
    assert check_type_raw(False)
    assert check_type_raw(None)
    assert check_type_raw('some string')
    assert check_type_raw(1)
    assert check_type_raw(1.2)
    assert check_type_raw(['a', 'list'])
    assert isinstance(check_type_raw({'a': 'dict'}), dict)



# Generated at 2022-06-20 16:29:18.049413
# Unit test for function check_type_path
def test_check_type_path():
    # Testing with valid path
    testPath1 = '/home/joe/test_folder/testfile.txt'
    assert check_type_path(testPath1) == testPath1
    # Testing with invalid path
    testPath2 = '~/joe/test_folder/testfile.txt'
    assert check_type_path(testPath2) == os.path.expanduser(testPath2)


# Generated at 2022-06-20 16:29:27.238401
# Unit test for function check_required_together
def test_check_required_together():
    try:
        check_required_together(None, {'a': 1})
        assert True
    except:
        assert False
    try:
        check_required_together([], {'a': 1})
        assert True
    except:
        assert False
    try:
        check_required_together([['a']], {'a': 1})
        assert True
    except:
        assert False
    try:
        check_required_together([('a', 'b')], {'a': 1, 'b': 1})
        assert True
    except:
        assert False
    try:
        check_required_together([('a', 'b'), ('c', 'd')], {'a': 1, 'b': 1, 'c': 1, 'd': 1})
        assert True
    except:
        assert False

# Generated at 2022-06-20 16:29:34.278287
# Unit test for function check_type_float
def test_check_type_float():

    # Test convergence to float
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0

    # Test ValueError
    with pytest.raises(TypeError):
        check_type_float(False)


# Generated at 2022-06-20 16:29:42.398460
# Unit test for function check_required_by
def test_check_required_by():

    # test parameters
    params = {'key1': 'value1', 'key2': ''}

    # test requirements
    reqs = {'key1': 'key2'}

    # should raise TypeError because required key is missing in params
    try:
        check_required_by(reqs, params)
    except TypeError as e:
        assert "missing parameter(s) required by 'key1': key2" in to_native(e)

    # should not raise TypeError because required key is in params
    params['key2'] = 'value2'
    check_required_by(reqs, params)

    # test requirements
    reqs = {'key1': ['key2', 'key3']}

    # should raise TypeError because required key is missing in params
    params['key2'] = ''

# Generated at 2022-06-20 16:29:51.822297
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{"asdf":"qwer"}') == {'asdf': 'qwer'}
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('1 == 1') is True
    assert safe_eval('0x3e8') == 1000
    assert safe_eval('"a" * 4') == 'aaaa'
    assert safe_eval('"a" + "b"') == 'ab'
    assert safe_eval('{}') == {}
    assert safe_eval('1 or 2') == 1
    assert safe_eval('0 or 2') == 2
    assert safe_eval('1 and 2') == 2
    assert safe_eval('0 and 2') == 0
    assert safe_eval('3 in [1, 2, 3]') is True
    assert safe

# Generated at 2022-06-20 16:29:58.127927
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('foo') == 'foo'
    assert check_type_raw(1) == 1
    assert check_type_raw(1.4) == 1.4
    assert check_type_raw(True) is True
    assert check_type_raw([]) == []
    assert check_type_raw({}) == {}
    assert check_type_raw({'foo': 'bar'}) == {'foo': 'bar'}
    # Test with None
    assert check_type_raw(None) is None



# Generated at 2022-06-20 16:30:13.613007
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{ "foo" : { "bar" : "bam" } }') == '{ "foo" : { "bar" : "bam" } }'
    assert check_type_jsonarg(['foo', 'bar', 'bam']) == '["foo", "bar", "bam"]'
    assert check_type_jsonarg(('foo', 'bar', 'bam')) == '["foo", "bar", "bam"]'
    assert check_type_jsonarg({'foo': 'bar', 'bam': 'baz'}) == '{"bam": "baz", "foo": "bar"}'
    assert isinstance(check_type_jsonarg({'foo': 'bar', 'bam': 'baz'}), string_types)



# Generated at 2022-06-20 16:30:22.215056
# Unit test for function check_required_one_of
def test_check_required_one_of():
    para = {}
    para['a'] = 2
    para['b'] = 2
    para['c'] = 2
    para['d'] = 2
    para['e'] = 2
    para['f'] = 2
    para['g'] = 2
    para['h'] = 2
    para['i'] = 2
    try:
        check_required_one_of(['a','b','c'], para)
        check_required_one_of(['d','e','f'], para)
        check_required_one_of(['g','h','i'], para)
    except TypeError as e:
        pass

    try:
        para['z'] = 1
    except TypeError as e:
        pass
    else:
        raise TypeError("Error")

    

# Generated at 2022-06-20 16:30:26.537077
# Unit test for function check_required_together
def test_check_required_together():
    result = check_required_together(
        [
            ('test_answer', 'test_question'),
            ('test_answer',),
        ],
        {'test_answer': '42'},
        options_context = ['test_question']
    )
    assert result == []


# Generated at 2022-06-20 16:30:32.329656
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str("test", True) == "test"
    assert check_type_str("test", False) == "test"
    assert check_type_str("test", False) == "test"
    result = check_type_str(12345, True)
    assert result == "12345"
    assert check_type_str(12345, False) == "12345"



# Generated at 2022-06-20 16:30:40.025821
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('a'), ['a']
    assert check_type_list('a, b'), ['a', 'b']
    assert check_type_list(['a', 'b']), ['a', 'b']
    assert check_type_list(1), ['1']
    assert check_type_list(2.2), ['2.2']



# Generated at 2022-06-20 16:30:47.573564
# Unit test for function check_type_float
def test_check_type_float():
    dict_list = []
    dict_list.append({'value': 2, 'expected_output': float(2)})
    dict_list.append({'value': 2.0, 'expected_output': 2.0})
    dict_list.append({'value': '2.0', 'expected_output': float(2.0)})
    dict_list.append({'value': '1.234567890123456789', 'expected_output': float(1.234567890123456789)})
    dict_list.append({'value': 'not a number', 'expected_output': TypeError})

    def test_check_type_float_helper(dict_unit_test):
        """Unit test helper function for check_type_float"""

# Generated at 2022-06-20 16:30:57.915814
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('2GB') == 16384 * 1024 * 1024
    assert check_type_bits('3Gb') == 3 * 1024 * 1024 * 1024
    assert check_type_bits('4kb') == 4 * 1024
    assert check_type_bits('5Kbit') == 625
    assert check_type_bits('6Kb') == 6144
    assert check_type_bits('7kb') == 7168
    assert check_type_bits('8Mb') == 8 * 1024 * 1024 * 8
    assert check_type_bits('8KB') == 8 * 1024 * 8
    assert check_type_bits('8Kbit') == 1000
    assert check_type_bits('8Kb') == 8192

# Generated at 2022-06-20 16:31:09.411918
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576, \
        "check_type_bits('1Mb') returned %s, but it should return 1048576" % check_type_bits('1Mb')
    assert check_type_bits('0.5Mb') == 524288, \
        "check_type_bits('0.5Mb') returned %s, but it should return 524288" % check_type_bits('0.5Mb')
    assert check_type_bits('1.5Mb') == 1572864, \
        "check_type_bits('1.5Mb') returned %s, but it should return 1572864" % check_type_bits('1.5Mb')

# Generated at 2022-06-20 16:31:17.100419
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    ctja = check_type_jsonarg
    assert ctja('{}') == '{}'
    assert ctja('{"foo":"bar"}') == '{"foo":"bar"}'
    assert ctja({"foo":"bar"}) == '{"foo":"bar"}'
    assert ctja(['foo', 'bar']) == '["foo", "bar"]'
    assert ctja(['foo', {'bar':'baz'}, 'froz']) == '["foo", {"bar": "baz"}, "froz"]'
    assert ctja((('foo', 'bar'), ('bar', 'baz'))) == '{"foo": "bar", "bar": "baz"}'
    assert ctja([]) == '[]'

# Generated at 2022-06-20 16:31:24.918099
# Unit test for function check_type_bool
def test_check_type_bool():
    #check_type_bool('')
    assert check_type_bool('') is False
    assert check_type_bool(' ') is True
    assert check_type_bool('1') is True
    assert check_type_bool('0') is False
    assert check_type_bool('on') is True
    assert check_type_bool('off') is False
    assert check_type_bool(None) is False
    assert check_type_bool(1) is True
    assert check_type_bool(0) is False


# Generated at 2022-06-20 16:31:31.065930
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(1) == 1
    assert check_type_raw("1") == "1"


# Generated at 2022-06-20 16:31:31.905761
# Unit test for function check_type_raw
def test_check_type_raw():
    """Returns the raw value"""
    x = check_type_raw(10)
    assert x == 10


# Generated at 2022-06-20 16:31:36.310788
# Unit test for function check_type_dict
def test_check_type_dict():
    # THIS FUNCTION IS NOT PART OF AnsibleModule API
    # It is used to test check_type_dict when the value is a string.
    # It is called by test_utils
    #
    # arg is defined here to prevent pylint warning W0621 'redefining name
    # from outer scope
    arg = {}
    arg[0] = "a=1, b='2', c=3"
    arg[1] = False
    arg[2] = "{'a':1, 'b':'2', 'c':3}"
    arg[3] = True
    arg[4] = "a=1"
    arg[5] = "a"
    arg[6] = 'a'
    arg[7] = 'a'
    arg[8] = 'a'

# Generated at 2022-06-20 16:31:43.946694
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo', include_exceptions=True) == ('foo', None)
    assert safe_eval('foo.bar()', include_exceptions=True) == ('foo.bar()', None)
    assert safe_eval('import foo', include_exceptions=True) == ('import foo', None)
    assert safe_eval('[1, 2, 3]', include_exceptions=True) == ([1, 2, 3], None)



# Generated at 2022-06-20 16:31:48.191108
# Unit test for function check_type_path
def test_check_type_path():
    assert os.path.expanduser('~/test.test') == check_type_path('~/test.test')
    assert os.path.expanduser(os.path.expandvars('$HOME/test.test')) == check_type_path('$HOME/test.test')



# Generated at 2022-06-20 16:31:59.326937
# Unit test for function safe_eval
def test_safe_eval():
    import os


# Generated at 2022-06-20 16:32:07.593186
# Unit test for function safe_eval
def test_safe_eval():
    value = '{"a": 1}'
    expected = {'a': 1}
    assert safe_eval(value) == expected

    from datetime import datetime
    value = 'datetime(2001, 2, 3, 4, 5)'
    expected = datetime(2001, 2, 3, 4, 5)
    assert safe_eval(value) == expected

    value = 'a.b()'
    expected = 'a.b()'
    assert safe_eval(value) == expected

    value = 'import os'
    expected = 'import os'
    assert safe_eval(value) == expected



# Generated at 2022-06-20 16:32:14.070183
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {}
    required_parameters = []
    missing_params = check_missing_parameters(parameters, required_parameters)
    if len(missing_params) != 0:
        print("guru991")
    parameters = dict(name="my-vol")
    required_parameters = ["name"]
    missing_params = check_missing_parameters(parameters, required_parameters)
    if len(missing_params) != 0:
        print("guru992")
    parameters = dict(name="my-vol", size=16)
    required_parameters = ["name"]
    missing_params = check_missing_parameters(parameters, required_parameters)
    if len(missing_params) != 0:
        print("guru993")
test_check_missing_parameters()



# Generated at 2022-06-20 16:32:15.817706
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('foo') == 'foo'



# Generated at 2022-06-20 16:32:19.881160
# Unit test for function check_type_bytes
def test_check_type_bytes():
    try:
        check_type_bytes("22GB")
        assert False, "Unit test check_type_bytes did not raise TypeError, a ValueError was raised instead"
    except TypeError:
        pass
# END Unit test for function check_type_bytes



# Generated at 2022-06-20 16:32:34.974117
# Unit test for function check_required_one_of
def test_check_required_one_of():
    list_of_lists = [("state", "file", "module"), ("path", "content")]
    params = {"name": "test", "module": "foo", "state": "present"}
    assert check_required_one_of(list_of_lists, params) == []

    list_of_lists = [("state", "file", "module"), ("path", "content")]
    params = {"name": "test", "module": "foo"}
    with pytest.raises(TypeError):
        assert check_required_one_of(list_of_lists, params) == []

    list_of_lists = [("state", "file", "module"), ("path", "content")]
    params = {"name": "test", "state": "present"}

# Generated at 2022-06-20 16:32:47.725655
# Unit test for function check_type_bool
def test_check_type_bool():
    result = check_type_bool(True)
    assert result is True

    result = check_type_bool(1)
    assert result is True

    result = check_type_bool('1')
    assert result is True

    result = check_type_bool('on')
    assert result is True

    result = check_type_bool(False)
    assert result is False

    result = check_type_bool(0)
    assert result is False

    result = check_type_bool('0')
    assert result is False

    result = check_type_bool('off')
    assert result is False

    try:
        check_type_bool('foo')
        assert False
    except Exception as e:
        assert type(e) is TypeError
# END Unit test for function check_type_bool


# Generated at 2022-06-20 16:32:56.740747
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list([0, 1, 2]) == [0, 1, 2]
    assert check_type_list(1) == ['1']
    assert check_type_list(1.0) == ['1.0']
    assert check_type_list('1') == ['1']
    assert check_type_list('1,2') == ['1', '2']
    assert check_type_list('1,2,3') == ['1', '2', '3']
    assert check_type_list(['1','2','3']) == ['1','2','3']



# Generated at 2022-06-20 16:33:07.371520
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = [['key1', 'key2'], ['key3', 'key4']]
    parameters = {'key1': 1, 'key3': 1}
    result = check_mutually_exclusive(terms, parameters)
    assert result == []

    parameters = {'key1': 1, 'key2': 1}
    from nose.tools import assert_raises
    with assert_raises(TypeError) as cm:
        check_mutually_exclusive(terms, parameters)
    assert_equal(
        str(cm.exception),
        "parameters are mutually exclusive: key1|key2"
        )
    assert_equal(
        str(cm.exception),
        "parameters are mutually exclusive: key1|key2 found in key1 -> key2"
        )



# Generated at 2022-06-20 16:33:12.482656
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    try:
        check_mutually_exclusive(['a', 'b'], dict(a=1, b=2))
    except TypeError:
        pass
    else:
        assert False, "Failed to raise TypeError"

    assert check_mutually_exclusive(None, dict(a=1, b=2)) == []
    assert check_mutually_exclusive(['a', 'b'], dict(a=1)) == []
    assert check_mutually_exclusive(['a', 'b', ['c', 'd']], dict(a=1, c=2)) == []



# Generated at 2022-06-20 16:33:14.419349
# Unit test for function check_required_by
def test_check_required_by():
    with pytest.raises(TypeError):
        check_required_by({u'pytest': u'hello'}, {})



# Generated at 2022-06-20 16:33:15.405455
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576


# Generated at 2022-06-20 16:33:22.073149
# Unit test for function check_required_one_of
def test_check_required_one_of():
    try:
        check_required_one_of("", [])
        assert False
    except TypeError:
        assert True

    try:
        check_required_one_of(None, [])
        assert True
    except TypeError:
        assert False

    try:
        check_required_one_of([], [])
        assert True
    except TypeError:
        assert False

    try:
        check_required_one_of([["a", "b"]], ["a"])
        assert True
    except TypeError:
        assert False

    try:
        check_required_one_of([["a", "b"], ["c"]], ["a", "d"])
        assert True
    except TypeError:
        assert False


# Generated at 2022-06-20 16:33:33.989829
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('/etc/hosts') == '/etc/hosts'
    assert check_type_path('/etc/{{ansible_hostname}}/hosts') == '/etc/{{ansible_hostname}}/hosts'
    assert check_type_path('/etc/$HOSTNAME/hosts') == '/etc/$HOSTNAME/hosts'
    assert check_type_path('~/.ansible/tmp/ansible-tmp-1423796390.97-147729857856000/mysql') == '~/.ansible/tmp/ansible-tmp-1423796390.97-147729857856000/mysql'

# Generated at 2022-06-20 16:33:45.805521
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {
        'foo': ['bar', 'baz'],
        'bar': 'foo',
        'baz': ['bar', 'foo'],
        'qux': 'quux',
    }

    parameters = {
        'foo': 'foo value',
        'qux': 'qux value',
    }

    result = check_required_by(requirements, parameters)
    assert result == {'foo': ['baz'], 'bar': ['foo'], 'baz': ['foo']}, result

    parameters = {
        'foo': 'foo value',
        'bar': 'bar value',
        'baz': 'baz value',
        'qux': 'qux value',
    }

    result = check_required_by(requirements, parameters)
    assert result == {}, result



# Generated at 2022-06-20 16:33:56.782807
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1MB') == 8388608
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1m') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1mbit') == 1048576
    assert check_type_bits('1mbit') == 1048576
    assert check_type_bits('1mbit') == 1048576
    assert check_type_bits('1Mbits') == 1048576

# Generated at 2022-06-20 16:34:07.165504
# Unit test for function check_type_str
def test_check_type_str():
    my_bool = True
    my_int = 123
    my_float = 3.14159
    my_none = None
    my_string = "123"
    my_unicode = u'\u2713'
    my_byte_string = b"\xc3\xab"
    my_byte_bytes = b"\xc4\xab"
    my_byte = bytes(bytearray((233,))).decode('utf-8')

    # Parametrized test cases

# Generated at 2022-06-20 16:34:10.844065
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('null', {'null': None}) == 1
    assert count_terms('null', {'null': None, 'null2': None}) == 2
    assert count_terms(['null', 'null2'], {'null': None, 'null2': None}) == 2
    assert count_terms(['null'], {'null2': None}) == 0
    assert count_terms(['null', 'null2'], {'null': None, 'null2': None, 'null3': None}) == 2



# Generated at 2022-06-20 16:34:21.257684
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(None) == [None], 'Should return a single item list'
    assert check_type_list(['a']) == ['a'], 'Should return a single item list'
    assert check_type_list(['a', 'b']) == ['a', 'b'], 'Should return a list'
    assert check_type_list('a') == ['a'], 'Should return a single item list'
    assert check_type_list('a,b') == ['a', 'b'], 'Should return a list'
    assert check_type_list(1) == ['1'], 'Should return a single item list'
    assert check_type_list([1, 2]) == [1, 2], 'Should return a list'

# Generated at 2022-06-20 16:34:26.001078
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('1') == '1'
    assert check_type_str(1) == '1'
    assert check_type_str(1.1, allow_conversion=False) == '1.1'


# Generated at 2022-06-20 16:34:35.399024
# Unit test for function check_required_together
def test_check_required_together():
    assert [
        'a',
        'b',
    ] == check_required_together([[
        'a',
        'b',
    ]], {
        'a': 1,
        'b': 2,
    })
    assert [] == check_required_together([[
        'a',
        'b',
    ]], {
        'a': 1,
        'c': 3,
    })
    assert [] == check_required_together([[
        'a',
        'b',
    ]], {})
    assert [
        'a',
        'b',
    ] == check_required_together([[
        'a',
        'b',
    ]], {
        'a': 1,
    })



# Generated at 2022-06-20 16:34:43.331117
# Unit test for function check_required_by
def test_check_required_by():
    # no required parameters
    _requirements = {}
    _params = {'a': 1, 'b': 2, 'c': 3}
    result = check_required_by(_requirements, _params)
    assert result == {}

    # a is not provided and is required by b and c
    _requirements = {'b': ['a'], 'c': ['a']}
    result = check_required_by(_requirements, _params)
    assert result == {'b': ['a'], 'c': ['a']}

    # a is provided and is required by b and c
    _params['a'] = 'test'
    result = check_required_by(_requirements, _params)
    assert result == {}

    # a is required by b and c, and b is required by d

# Generated at 2022-06-20 16:34:46.576382
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.2) == 1.2
    assert check_type_float('1.2') == 1.2
    assert check_type_float(b'1.2') == 1.2
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(1) == 1.0



# Generated at 2022-06-20 16:34:51.693622
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{'foo':'bar'}") == dict(foo='bar')
    assert check_type_dict(dict(a=1)) == dict(a=1)
    assert check_type_dict("a=1, b=2,c=3") == dict(a=1, b=2, c=3)
    assert check_type_dict("a=1 b=2  c=3") == dict(a=1, b=2, c=3)
    assert check_type_dict('"a=1" "b=2" "c=3"') == dict(a=1, b=2, c=3)
    assert check_type_dict('"a=1,b=2" "c=3"') == dict(a="1,b=2", c=3)

# Generated at 2022-06-20 16:34:58.173684
# Unit test for function check_type_list
def test_check_type_list():
    test_list_str = "str1,str2,str3"
    test_list_list = ["str1", "str2", "str3"]
    assert check_type_list(test_list_str) == test_list_list
    test_num = 1
    assert check_type_list(test_num) == [str(test_num)]



# Generated at 2022-06-20 16:35:02.597844
# Unit test for function check_required_one_of
def test_check_required_one_of():
    pass



# Generated at 2022-06-20 16:35:10.420967
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(7) == 7
    assert check_type_int("7") == 7
    with pytest.raises(TypeError):
        check_type_int(7.69)
    with pytest.raises(TypeError):
        check_type_int("7.69")
    with pytest.raises(TypeError):
        check_type_int("seven")


# FIXME: This should raise a TypeError in Python 2 if the value is a unicode string
# and not a str, but the str() conversion isn't handled in __call__ in module_utils/basic.py

# Generated at 2022-06-20 16:35:17.922907
# Unit test for function check_type_bool
def test_check_type_bool():
    from ansible.module_utils.basic import AnsibleModule
    import pytest
    module = AnsibleModule(
        argument_spec=dict(
            check_type_bool=dict(type='str', required=True),
        ),
    )
    check_type_bool = module.check_type_bool
    def check_with_type(v, type_name):
        try:
            b = check_type_bool(v)
            assert b == boolean(v)
        except TypeError:
            with pytest.raises(TypeError):
                check_type_bool(v)
    # boolean(v) only accepts string or int/float
    def check(v, b=None):
        if b is None:
            b = v
        check_with_type(v, 'bool')
        check_with_type

# Generated at 2022-06-20 16:35:30.056463
# Unit test for function check_type_bytes
def test_check_type_bytes():
    '''test bytes'''
    # Test the following cases:
    #   10 bytes
    #   1024 bytes
    #   1024 KiB
    #   1024 K
    #   1024 MiB
    #   1024 M
    #   1024 GiB
    #   1024 G
    #   1024 TiB
    #   1024 T
    #   1024 PiB
    #   1024 P
    #   1024e1 bytes
    #   1024e2 bytes
    #   1024e3 bytes
    #   1024e4 bytes
    #   1024e5 bytes
    #   1024e6 bytes
    #   1024e7 bytes
    assert check_type_bytes("10") == 10
    assert check_type_bytes("1024") == 1024

# Generated at 2022-06-20 16:35:38.024008
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    res = check_type_jsonarg("json string")
    assert res == '"json string"'
    res = check_type_jsonarg("{\"key1\": \"value1\", \"key2\": \"value2\"}")
    assert res == '{"key1": "value1", "key2": "value2"}'
    res = check_type_jsonarg("[\"item1\", \"item2\", \"item3\"]")
    assert res == '["item1", "item2", "item3"]'
    res = check_type_jsonarg(["item1", "item2", "item3"])
    assert res == '["item1", "item2", "item3"]'
    res = check_type_jsonarg(("item1", "item2", "item3"))