

# Generated at 2022-06-20 16:26:24.624347
# Unit test for function check_type_bytes
def test_check_type_bytes():
    """
    Unit test for check_type_bytes()
    """
    assert check_type_bytes("1G") == 1073741824
    assert check_type_bytes("1024") == 1024
    assert check_type_bytes("0") == 0

    try:
        check_type_bytes("1G b")
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-20 16:26:35.581145
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # Test Error case
    params = {'b': 'b'}
    terms = [['a', 'b', 'c']]
    result = check_required_one_of(terms, params)
    assert result == []
    # Test Error case
    terms = [['a', 'b']]
    result = check_required_one_of(terms, params)
    assert result == []
    # Test Error case
    params = {'c': 'c'}
    result = check_required_one_of(terms, params)
    assert result == []
    # Test OK case
    params = {'a': 'a'}
    result = check_required_one_of(terms, params)
    assert result == []
# Unit test end



# Generated at 2022-06-20 16:26:44.646575
# Unit test for function check_required_together
def test_check_required_together():
    module = AnsibleModule(
        argument_spec=dict(
            foo=dict(),
            bar=dict(),
            baz=dict(),
            foobar=dict(),
        ),
        mutually_exclusive=(
            ('foo', 'bar'),
            ('bar', 'baz'),
            ('baz', 'foo'),
        ),
        required_together=(
            ('foo', 'foobar'),
            ('bar', 'foobar'),
            ('baz', 'foobar'),
        )
    )

    # Test no exception is raised if the required parameters are present
    module.params = dict(foo='a', foobar='foobar')
    assert list() == check_required_together(module._required_together, module.params)

    # Test exception is raised if the required parameters are not present
    module.params = dict(foo='a')

# Generated at 2022-06-20 16:26:46.661631
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('/root/.ssh/id_rsa') == '/root/.ssh/id_rsa'
    assert check_type_path('~/.ssh/id_rsa') == os.path.expanduser('~/.ssh/id_rsa')


# Generated at 2022-06-20 16:26:57.772453
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {}
    assert(check_required_together([['a'], ['b']], parameters) == [])
    parameters = dict(a=1)
    assert(check_required_together([['a'], ['b']], parameters) == [])
    parameters = dict(b=1)
    assert(check_required_together([['a'], ['b']], parameters) == [])
    parameters = dict(a=1, b=2)
    assert(check_required_together([['a'], ['b']], parameters) == [])
    parameters = dict(a=1, b=2, c=3)
    assert(check_required_together([['a'], ['b']], parameters) == [])
    parameters = dict(a=1, c=3)

# Generated at 2022-06-20 16:27:09.715250
# Unit test for function check_required_if
def test_check_required_if():
    from ansible.module_utils.common.text.formatters import validate_param_value

    required_if = [
        ['state', 'present', ('path',)],
        ['someint', 99, ('bool_param', 'string_param')],
        ['someint', 100, ('other_param',), True],
    ]
    parameters = {
        'bool_param': True,
        'someint': 99,
        'other_param': True,
        'state': 'present',
    }
    res = check_required_if(required_if, parameters)

    assert res == [], "check_required_if should succeed"

    parameters['someint'] = 100
    with pytest.raises(TypeError) as exception:
        check_required_if(required_if, parameters)

# Generated at 2022-06-20 16:27:17.191603
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together([('a','b')], { 'a' : 1 }) == []
    assert check_required_together([('a','b')], { 'b' : 1 }) == []
    assert check_required_together([('a','b')], { 'a' : 1, 'b' : 1 }) == []
    assert check_required_together([('a','b')], {}) == [('a','b')]
    assert check_required_together([('a','b'),('c')], { 'a' : 1 }) == [('c')]
    assert check_required_together([('a','b')], { 'a' : 1, 'c' : 1 }) == [('a','b')]


# Generated at 2022-06-20 16:27:18.202256
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(True) is True


# Generated at 2022-06-20 16:27:29.615347
# Unit test for function check_required_if
def test_check_required_if():
    # . . . . . . . . . . . . . . . . . . . . . . . . . .
    # test cases and expected results
    # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
    # Test cases

    # Test 1: Test good parameter sate
    requirements = [
        ['state', 'present', ('path',), False],
        ['someint', 99, ('bool_param', 'string_param'), True],
    ]
    parameters = dict(
        state='present',
        path='/foo',
        someint=99,
        bool_param='yes',
    )
    expected_results = []
    result = check_required_if(requirements, parameters, options_context=None)

# Generated at 2022-06-20 16:27:36.570578
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    module = None
    parameters = {'src': '/path/to/src_file', 'dest': '/path/to/dest_file'}
    required_parameters = ['src', 'dest']
    result = check_missing_parameters(parameters, required_parameters)
    assert result == []

    required_parameters = ['src', 'dest', 'dst']
    with pytest.raises(TypeError) as excinfo:
        result = check_missing_parameters(parameters, required_parameters)
    assert excinfo.value.args[0] == "missing required arguments: dst"


# Generated at 2022-06-20 16:27:49.640768
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('a') == 'a'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval('dict(a=1, b=2)') == {'a': 1, 'b': 2}
    assert safe_eval('1 + 2') == '1 + 2'
    assert safe_eval('import os') == 'import os'
    assert safe_eval('[1, 2, 3]', include_exceptions=True) == ([1, 2, 3], None)
    assert safe_eval('{"a": "b"}', include_exceptions=True) == ({'a': 'b'}, None)

# Generated at 2022-06-20 16:27:53.571821
# Unit test for function check_type_bool
def test_check_type_bool():
    pass

# FIXME: The param and prefix parameters here are coming from AnsibleModule._check_type_string()
#        which is using those for the warning messaged based on string conversion warning settings.
#        Not sure how to deal with that here since we don't have config state to query.

# Generated at 2022-06-20 16:27:58.436349
# Unit test for function check_required_if
def test_check_required_if():
    terms = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')]
    ]
    parameters = {'someint': 99, 'path': '/some/path'}
    result = check_required_if(terms, parameters)
    assert len(result) == 1
    assert result[0]['missing'] == ['string_param']


# Generated at 2022-06-20 16:28:08.706738
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1+2') == 3
    assert safe_eval('["foo", "bar"]') == ["foo", "bar"]
    assert safe_eval('{"a": "foo", "b": "bar"}') == {"a": "foo", "b": "bar"}
    assert safe_eval('{"a": {"b": [1, 2, 3]}, "c": "bar"}') == {"a": {"b": [1, 2, 3]}, "c": "bar"}
    assert safe_eval('[{"a": "foo", "b": [1, 2, 3]}, {"c": "bar"}]') == [{"a": "foo", "b": [1, 2, 3]}, {"c": "bar"}]

# Generated at 2022-06-20 16:28:20.648148
# Unit test for function check_required_arguments
def test_check_required_arguments():
    try:
        check_required_arguments(None, {'first': 'first'})
    except TypeError as e:
        assert "missing required arguments" in to_native(e)
        assert "NoneType" in to_native(e)

    try:
        check_required_arguments({'first': {}, 'second': {'required': True}}, {'first': 'first'})
    except TypeError as e:
        assert "missing required arguments: second" in to_native(e)

    assert check_required_arguments({'first': {'required': True}}, {'first': 'first'}) == []
    assert check_required_arguments({'first': {'required': False}}, {'first': 'first'}) == []
    assert check_required_arguments({}, {}) == []



# Generated at 2022-06-20 16:28:31.232993
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path(None) == None
    assert check_type_path(1) == None
    assert check_type_path(True) == None
    assert check_type_path(False) == None
    assert check_type_path({'key': 'val'}) == None
    assert check_type_path([1, 2, 3]) == None
    assert check_type_path(1.0) == None
    assert check_type_path('/tmp') == '/tmp'
    assert check_type_path('~/tmp') == '/home/vagrant/tmp'
    assert check_type_path('$HOME/tmp') == '/home/vagrant/tmp'



# Generated at 2022-06-20 16:28:37.648177
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('~/foo.cfg') == os.path.expanduser('~/foo.cfg')
    assert check_type_path('') == os.path.expandvars('')
    assert check_type_path(None) == os.path.expandvars(None)
    assert check_type_path('/tmp') == os.path.expandvars('/tmp')



# Generated at 2022-06-20 16:28:44.672668
# Unit test for function check_type_str
def test_check_type_str():
    assert("test1" == check_type_str("test1")), "\"test1\" == check_type_str(\"test1\") is False"
    assert("test2" == check_type_str(["test2"])), "\"test2\" == check_type_str([\"test2\"]) is False"
    with pytest.raises(TypeError):
        check_type_str([], False)
    with pytest.raises(TypeError):
        check_type_str([3], False)
    assert("[1, 2, 3]" == check_type_str([1, 2, 3])), "\"[1, 2, 3]\" == check_type_str([1, 2, 3]) is False"

# Generated at 2022-06-20 16:28:52.003859
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg("{\"test\": \"123\"}") == '{"test": "123"}'
    assert check_type_jsonarg("\"{\\\"test\\\": \\\"123\\\"}\"") == '{"test": "123"}'
    assert check_type_jsonarg(["test", "123"]) == '["test", "123"]'
    assert check_type_jsonarg("null") == "null"



# Generated at 2022-06-20 16:29:02.555853
# Unit test for function check_type_list
def test_check_type_list():
    assert ['a'] == check_type_list('a')
    assert ['a', 'b', 'c'] == check_type_list('a,b,c')
    assert ['1'] == check_type_list('1')
    assert ['1'] == check_type_list(1)
    assert [str(1)] == check_type_list(1)
    assert [str(1)] == check_type_list(1.0)
    assert [str(1)] == check_type_list(1.0)
    assert ['a'] == check_type_list(['a'])
    assert ['a'] == check_type_list(('a',))

    try:
        check_type_list(0)
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-20 16:29:17.255169
# Unit test for function check_required_together
def test_check_required_together():
    test_parameters = {
        'one': 1,
        'two': 2
    }
    bad_test_group = ('one', 'three')
    good_test_group = ('one', 'two')

    # check when we have a bad group but no other good groups
    try:
        check_required_together([bad_test_group], test_parameters)
    except TypeError:
        pass
    else:
        raise AssertionError("check_required_together did not raise exception when it should")

    # check when we have a bad group but another good group
    try:
        check_required_together([bad_test_group, good_test_group], test_parameters)
    except TypeError:
        raise AssertionError("check_required_together raised exception when it should not")

    # check when we have

# Generated at 2022-06-20 16:29:25.742757
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list([1,2,3]) == [1,2,3]
    assert check_type_list(1) == ['1']
    assert check_type_list(1.0) == ['1.0']
    assert check_type_list('1') == ['1']
    assert check_type_list('1,2') == ['1', '2']
    assert check_type_list('1,2,3,4') == ['1', '2', '3', '4']
    try:
        check_type_list({})
    except TypeError:
        assert True
    else:
        assert False, 'check_type_list({}) should raise TypeError'


# Generated at 2022-06-20 16:29:30.783709
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    with pytest.raises(TypeError):
        check_type_bits('apple')
    return


# XXX: Split this into its own module with other common fact functions
# XXX: add documentation for this function

# Generated at 2022-06-20 16:29:37.892878
# Unit test for function check_type_raw
def test_check_type_raw():
    from ansible.compat.tests.mock import patch, MagicMock

    with patch.object(check_type, "check_type_str") as mock_check_type_str:
        check_type_raw("input_value")

    # The following line is to ensure that no code paths were missed
    # by the above with statement. If any code path was missed, this
    # will throw an AttributeError
    mock_check_type_str.assert_called_once_with("input_value")


# Generated at 2022-06-20 16:29:48.300235
# Unit test for function check_required_arguments
def test_check_required_arguments():
    parameters = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    spec1 = {'key1': {'required': True, 'type': 'str'}}
    spec2 = {'key1': {'required': True, 'type': 'str'}, 'key2': {'required': True, 'type': 'str'}}
    spec3 = {'key1': {'required': True, 'type': 'str'}, 'key2': {'required': False, 'type': 'str'}}
    spec4 = {'key1': {'type': 'str'}}
    spec5 = {'key4': {'required': True, 'type': 'str'}}
    spec6 = {'key4': {'required': False, 'type': 'str'}}
    spec

# Generated at 2022-06-20 16:29:49.990830
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{"foo": "bar"}') == jsonify({"foo": "bar"})
    assert check_type_jsonarg({"foo": "bar"}) == jsonify({"foo": "bar"})



# Generated at 2022-06-20 16:29:55.601306
# Unit test for function check_type_int
def test_check_type_int():
    assert (check_type_int(3) == 3)
    assert (check_type_int('3') == 3)
    try:
        check_type_int([])
    except TypeError:
        pass
    try:
        check_type_int('')
    except TypeError:
        pass
    try:
        check_type_int(None)
    except TypeError:
        pass
    try:
        check_type_int(True)
    except TypeError:
        pass


# Generated at 2022-06-20 16:30:06.645087
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(-1) == True
    assert check_type_bool(0) == False
    assert check_type_bool(1) == True
    assert check_type_bool(5) == True
    assert check_type_bool(-5) == True
    assert check_type_bool(False) == False
    assert check_type_bool(True) == True
    assert check_type_bool('y') == True
    assert check_type_bool('t') == True
    assert check_type_bool('yes') == True
    assert check_type_bool('no') == False
    assert check_type_bool('off') == False
    assert check_type_bool('on') == True
    assert check_type_bool('true') == True
    assert check_type_bool('false') == False
    assert check_

# Generated at 2022-06-20 16:30:14.973320
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('test') == u'test'
    assert check_type_str(u'test') == u'test'
    assert check_type_str(1) == u'1'
    assert check_type_str(1.0) == u'1.0'
    assert check_type_str(None) == u'None'
    assert check_type_str(True) == u'True'
    assert check_type_str(datetime.datetime.now()) == unicode(datetime.datetime.now())
    pytest.raises(TypeError, check_type_str, 1, allow_conversion=False)
    pytest.raises(TypeError, check_type_str, 1.0, allow_conversion=False)

# Generated at 2022-06-20 16:30:20.665510
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{name:John}') == {'name': 'John'}
    assert check_type_dict('{"name":"John"}') == {'name': 'John'}
    assert check_type_dict('name=John') == {'name': 'John'}
    assert check_type_dict('name=John,age=22') == {'name': 'John', 'age': '22'}
    assert check_type_dict('name="John Smith"') == {'name': '"John Smith"'}
    assert check_type_dict('name="John Smith",age=22') == {'name': '"John Smith"', 'age': '22'}
    assert check_type_dict('"name=John Smith"') == {'"name': 'John Smith"'}

# Generated at 2022-06-20 16:30:30.107053
# Unit test for function check_type_int
def test_check_type_int():
    assert (check_type_int(5) == 5)
    assert (check_type_int(5.0) == 5)
    assert (check_type_int('5') == 5)
    try:
        check_type_int('test_string')
    except TypeError:
        pass
    else:
        raise AssertionError('unexpected behavior')



# Generated at 2022-06-20 16:30:37.876566
# Unit test for function check_type_jsonarg

# Generated at 2022-06-20 16:30:39.457505
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"key": "value"}') == {'key': 'value'}
    # ensure check_type_dict is returning a dict and not the json loader
    assert isinstance(check_type_dict('{"key": "value"}'), dict)



# Generated at 2022-06-20 16:30:46.939156
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of(None, {}) == []
    assert check_required_one_of([], {}) == []
    assert check_required_one_of([("a", "b"), ("c", "d")], {}) == [("a", "b"), ("c", "d")]
    assert check_required_one_of([("a", "b"), ("c", "d")], {"e": "f"}) == [("a", "b"), ("c", "d")]
    assert check_required_one_of([("a", "b"), ("c", "d")], {"a": "f"}) == [("c", "d")]
    assert check_required_one_of([("a", "b"), ("c", "d")], {"b": "f"}) == [("c", "d")]

# Generated at 2022-06-20 16:30:49.804700
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(float(1)) == 1.0
    assert check_type_float("1.0") == 1.0
    assert check_type_float(b"1.0") == 1.0
    assert check_type_float(1) == 1.0
    with pytest.raises(TypeError):
        check_type_float("hello")



# Generated at 2022-06-20 16:30:51.274246
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(42), 42


# Generated at 2022-06-20 16:30:59.216045
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Test with a required parameter.
    argument_spec = dict(
        required_parameter=dict(required=True, type='str')
    )
    parameters = dict(required_parameter='foo')
    assert check_required_arguments(argument_spec, parameters) == []

    # Test with a required parameter missing.
    argument_spec = dict(
        required_parameter=dict(required=True, type='str')
    )
    parameters = dict()
    with pytest.raises(TypeError):
        check_required_arguments(argument_spec, parameters) == []

    # Test with a required parameter missing, but it's still in the argument_spec.
    argument_spec = dict(
        required_parameter=dict(required=True, type='str')
    )

# Generated at 2022-06-20 16:31:01.039213
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Call function check_type_bytes
    result = check_type_bytes('10G')
    # Check if the expected result is equal to the actual result
    assert result == 10737418240



# Generated at 2022-06-20 16:31:08.305311
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str("1") == "1"
    assert check_type_str(1, allow_conversion=True) == '1'
    with pytest.raises(TypeError):
        check_type_str(1, allow_conversion=False)


# FIXME: The param and prefix parameters here are coming from AnsibleModule._check_type_bool()
#        which is using those for the warning messaged based on bool conversion warning settings.
#        Not sure how to deal with that here since we don't have config state to query.

# Generated at 2022-06-20 16:31:14.805306
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('foo') is False
    assert check_type_bool('false') is False
    assert check_type_bool('0') is False
    assert check_type_bool(0) is False
    assert check_type_bool('1') is True
    assert check_type_bool(1) is True
    assert check_type_bool(1.1) is True
    assert check_type_bool('true') is True
    assert check_type_bool('no') is False
    assert check_type_bool('yes') is True
    assert check_type_bool('n') is False
    assert check_type_bool('y') is True
    assert check_type_bool('off') is False
    assert check_type_bool('on') is True
    assert check_type_bool(True) is True

# Generated at 2022-06-20 16:31:32.755712
# Unit test for function check_required_one_of

# Generated at 2022-06-20 16:31:37.080728
# Unit test for function check_type_dict
def test_check_type_dict():
    """Unit tests for AnsibleModule()'s check_type_dict() method."""
    module = AnsibleModule(argument_spec={})
    # Test a dict
    data = {'foo': 'bar'}
    result = module._check_type_dict(data)
    assert data == result, "check_type_dict converted a dict to something not a dict"
    # Test a string
    data = '{"foo": "bar"}'
    assert module._check_type_dict(data) == {'foo': 'bar'}, "check_type_dict did not convert a JSON string to a dict"
    data = 'foo=bar'
    assert module._check_type_dict(data) == {'foo': 'bar'}, "check_type_dict did not convert a simple dict string to a dict"

# Generated at 2022-06-20 16:31:43.399253
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 0, 'b': 0}
    options_context = None
    results = check_mutually_exclusive(terms, parameters, options_context)
    assert len(results) > 0

    parameters = {'a': 0, 'b': 1}
    results = check_mutually_exclusive(terms, parameters, options_context)
    assert len(results) == 0



# Generated at 2022-06-20 16:31:48.921755
# Unit test for function check_type_bool
def test_check_type_bool():
    for (value, result) in (
            ('1', True), ('on', True), (1, True),
            ('0', False), (0, False), ('n', False), ('f', False),
            ('false', False), ('true', True), ('y', True), ('t', True),
            ('yes', True), ('no', False), ('off', False)):
        assert check_type_bool(value) == result


# Generated at 2022-06-20 16:31:53.167319
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('a') == 'a'
    assert check_type_str(1, True) == '1'
    assert check_type_str(1, False)



# Generated at 2022-06-20 16:31:58.807923
# Unit test for function check_required_one_of
def test_check_required_one_of():
    check_required_one_of([['a', 'b'], ['c']], {'d': True})
    try:
        check_required_one_of([['a', 'b'], ['c']], {'d': True})
        assert False, "Should have raised exception if required args are not in the given module params"
    except TypeError:
        assert True, "Raised exception when required args not found in the given module params"



# Generated at 2022-06-20 16:32:00.024562
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(True)
    assert check_type_raw(1)
    assert check_type_raw(('a', 'b', 'c'))


# Generated at 2022-06-20 16:32:09.885154
# Unit test for function safe_eval
def test_safe_eval():
    from tests.unit.compat import unittest

    class SafeEvalTestCase(unittest.TestCase):
        """Unit test cases for safe_eval()"""

# Generated at 2022-06-20 16:32:11.996898
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw("/tmp/") == "/tmp/"


# Generated at 2022-06-20 16:32:14.446316
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0


# Generated at 2022-06-20 16:32:30.178178
# Unit test for function check_type_str
def test_check_type_str():
    test_values = [
        'test',
        u'test',
    ]
    for value in test_values:
        assert check_type_str(value) == value
        assert check_type_str(value, allow_conversion=False) == value

    test_values = [
        b'test',
        1,
        [1, 2, 3],
        {'one': 1},
    ]
    for value in test_values:
        with pytest.raises(TypeError) as error:
            check_type_str(value)
        assert 'is not a string and conversion is not allowed' in to_native(error.value)

        assert check_type_str(value, allow_conversion=True) == to_native(value)



# Generated at 2022-06-20 16:32:37.843367
# Unit test for function check_required_one_of
def test_check_required_one_of():
    data = dict(foo='bar',baz='qux')
    assert check_required_one_of((('foo', 'baz', 'quux'),), data)
    try:
        check_required_one_of((('foo', 'baz', 'quux'),), data, options_context=('foo',))
    except TypeError as e:
        assert e.args[0] == "one of the following is required: foo, baz, quux found in foo"
    assert check_required_one_of((('foo', 'baz', 'quux'),('foo','baz')), data)
    assert not check_required_one_of((('foo', 'baz', 'quux'),('foo','bar')), data)



# Generated at 2022-06-20 16:32:49.147852
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    try:
        check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2})
    except TypeError as e:
        assert "parameters are mutually exclusive" in to_native(e)
    else:
        assert False, "This should have thrown an error"

    assert check_mutually_exclusive(['a', 'b'], {'a': 1}) == []

    # test a more complex list of lists
    try:
        check_mutually_exclusive(['a', 'b', ['c', 'd', 'e'], ['f', 'g']], {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}, ['options'])
    except TypeError as e:
        assert "parameters are mutually exclusive" in to_native(e)


# Generated at 2022-06-20 16:33:00.014177
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['b', 'c'], ['d', 'e']]
    parameters = dict(b=1, c=2)
    assert check_required_together(terms, parameters) == [], 'Test 1: check_required_together() Fails when all the required params are present'

    terms = [['b', 'c'], ['d', 'e']]
    parameters = dict(b=1, c=2, d=2)
    assert check_required_together(terms, parameters) == [], 'Test 2: check_required_together() Fails when all the required params are present'

    terms = [['b', 'c'], ['d', 'e']]
    parameters = dict(b=1, c=2, d=2, e=3, x='')
    assert check_required_together(terms, parameters)

# Generated at 2022-06-20 16:33:06.821551
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(3) == 3
    assert check_type_int('3') == 3
    assert check_type_int(3.0) == 3
    assert check_type_int('3.0') == 3
    assert check_type_int(True) == 1
    assert check_type_int(False) == 0
    assert check_type_int('True') == 1
    assert check_type_int('False') == 0


# Generated at 2022-06-20 16:33:13.738817
# Unit test for function check_required_by
def test_check_required_by():
    options = dict(
        A=1,
        B=2,
        C=3,
        D=4,
        E=None,
        F=None,
    )
    requirements = dict(
        A=['B', 'C'],
        B=[],
        C=['D'],
        D=['A', 'E', 'F'],
    )

    checker = ArgSpec([], requirements=requirements)
    checker._check_required_by(options)

    options['C'] = None
    with pytest.raises(TypeError):
        checker._check_required_by(options)
    options['C'] = 3

    options['D'] = None
    with pytest.raises(TypeError):
        checker._check_required_by(options)

# Generated at 2022-06-20 16:33:17.059545
# Unit test for function check_type_int
def test_check_type_int():

    assert check_type_int(1) == 1
    assert check_type_int('1') == 1

    with pytest.raises(TypeError):
        check_type_int(1.1)
    with pytest.raises(TypeError):
        check_type_int('not_int')



# Generated at 2022-06-20 16:33:24.456462
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {'vpc_id': '', 'cidrs': [], 'vpc_name': '', 'cidr_size': ''}
    assert [] == check_required_together([('vpc_id', 'vpc_name'), ('cidrs', 'cidr_size')], parameters)
    parameters = {'vpc_id': '', 'cidrs': [], 'vpc_name': ''}
    assert [('cidrs', 'cidr_size')] == check_required_together([('vpc_id', 'vpc_name'), ('cidrs', 'cidr_size')], parameters)
    parameters = {'vpc_id': '', 'cidrs': [], 'cidr_size': ''}
    assert [('vpc_id', 'vpc_name')]

# Generated at 2022-06-20 16:33:36.216030
# Unit test for function check_type_bool
def test_check_type_bool():
    # check_type_bool() should raise an exception if the argument is not one of the supported types
    for invalid in (None, [], tuple(), set(), "{}", object()):
        assert_raises(TypeError, check_type_bool, invalid)
    # check_type_bool() should raise an exception if the argument is a string that does not look like
    # a boolean
    for invalid in ("", " ", "not a boolean"):
        assert_raises(TypeError, check_type_bool, invalid)
    # check_type_bool() should return a boolean when passed a boolean
    for valid in (True, False):
        assert check_type_bool(valid) is valid
    # check_type_bool() should return a boolean when passed an integer

# Generated at 2022-06-20 16:33:40.802258
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(23) == 23
    assert check_type_float(23.0) == 23.0
    assert check_type_float("23") == 23.0
    assert check_type_float(b"23") == 23.0
    assert check_type_float(u"23") == 23.0
    assert check_type_float("23.1") == 23.1
    assert check_type_float("234324324") == 234324324.0
    assert check_type_float("234324324.1") == 234324324.1
    assert check_type_float("-234324324") == -234324324.0
    assert check_type_float("-234324324.1") == -234324324.1

# Generated at 2022-06-20 16:33:53.914794
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['a', 'b']], {'a': 1}) == []
    assert check_required_one_of([('a', 'b')], {'a': 1}) == []
    assert check_required_one_of([['a', 'b']], {'c': 1}) == [['a', 'b']]
    assert check_required_one_of([('a', 'b')], {'c': 1}) == [['a', 'b']]
    assert check_required_one_of([('a', 'b'),('c', 'd')], {'e': 1}) == [['a', 'b'], ['c', 'd']]

# Generated at 2022-06-20 16:34:04.891081
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Handle empty spec and parameters with no error
    spec = {}
    parameters = {}
    assert check_required_arguments(spec, parameters) == []
    # Handle missing required parameters
    spec = {'name': {'required': True}}
    parameters = {}
    try:
        check_required_arguments(spec, parameters)
    except TypeError as e:
        assert 'missing required arguments: name' in to_native(e)
    else:
        assert False, "Should have thrown an error"
    # Handle all parameters provided with no error
    spec = {'name': {'required': True}}
    parameters = {'name': 'test'}
    assert check_required_arguments(spec, parameters) == []
    # Handle no parameters required
    spec = {'name': {'required': False}}
    parameters = {}


# Generated at 2022-06-20 16:34:09.024297
# Unit test for function check_required_together
def test_check_required_together():
    param = dict(state=1, param1='hello', param2="world")
    terms = [['param1', 'param2']]
    result = check_required_together(terms, param)
    assert not result, result



# Generated at 2022-06-20 16:34:13.556235
# Unit test for function check_type_float
def test_check_type_float():
    input_list = ['a', '!@#$%^&*', '', None, True]
    for input in input_list:
        try:
            float(input)
        except TypeError:
            pass



# Generated at 2022-06-20 16:34:17.350161
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw() == None
    assert check_type_raw(True) == True
    assert check_type_raw(False) == False
    assert check_type_raw(2) == 2
    assert check_type_raw(20.0) == 20.0


# Generated at 2022-06-20 16:34:22.832258
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(3) ==3
    assert check_type_float(3.5) ==3.5
    assert check_type_float('3') ==3
    assert check_type_float('3.5') ==3.5
    try:
        check_type_float('abc')
        assert False
    except TypeError:
        assert True
    try:
        check_type_float(None)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-20 16:34:27.467496
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {'param1': 'value1', 'param2': 'value2'}
    terms = [['param1', 'param2']]
    options_context = ['context1', 'context2']
    result = check_required_together(terms, parameters, options_context)
    assert result == []
    parameters = {'param1': 'value1'}
    terms = [['param1', 'param2']]
    options_context = ['context1']
    result = check_required_together(terms, parameters, options_context)
    assert result == [['param1', 'param2']]



# Generated at 2022-06-20 16:34:32.248311
# Unit test for function check_type_raw
def test_check_type_raw():
    '''Unit test for function check_type_raw'''
    assert check_type_raw('a') == 'a'
    assert check_type_raw(1) == 1
    assert check_type_raw({}) == {}
    assert check_type_raw([]) == []
    assert check_type_raw(3.14) == 3.14



# Generated at 2022-06-20 16:34:40.265152
# Unit test for function count_terms
def test_count_terms():
    test_cases = [
        {'terms': ['asdf'], 'parameters': {'asdf': 'asdf'}, 'output': 1},
        {'terms': ['asdf', 'asdfff'], 'parameters': {'asdf': 'asdf'}, 'output': 1},
        {'terms': ['asdf', 'fdsa'], 'parameters': {'asdf': 'asdf', 'fdsa': 'fdsa'}, 'output': 2},
    ]
    for test_case in test_cases:
        output = count_terms(test_case['terms'], test_case['parameters'])
        assert output == test_case['output'], 'count_terms should return {}'.format(test_case['output'])



# Generated at 2022-06-20 16:34:49.061807
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {'param1': '1', 'param2': '2', 'param3': '3', 'param4': '4'}
    requirements = {'param1': ['param3']}
    assert {} == check_required_by(requirements, parameters)

    parameters = {'param1': '1', 'param3': '3', 'param4': '4'}
    requirements = {'param1': ['param3']}
    assert {'param1': ['param3']} == check_required_by(requirements, parameters)

    parameters = {'param1': '1', 'param3': '3', 'param4': '4'}
    requirements = {'param1': 'param3'}
    assert {'param1': ['param3']} == check_required_by(requirements, parameters)


# Generated at 2022-06-20 16:35:02.734635
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(['a', 'b']) == ['a', 'b'], 'Failed to return a list when a list was passed'
    assert check_type_list('a,b') == ['a', 'b'], 'Failed to return a list from comma separated string'
    assert check_type_list('a') == ['a'], 'Failed to return a list from a single string'
    assert check_type_list(1) == ['1'], 'Failed to return a list from a single int'
    assert check_type_list(1.0) == ['1.0'], 'Failed to return a list from a single float'



# Generated at 2022-06-20 16:35:06.776600
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float('1.23') == 1.23
    assert check_type_float(1.23) == 1.23
    assert check_type_float(u'1.23') == 1.23
    assert check_type_float(1) == 1.0
    assert check_type_float(b'1.23') == 1.23
    assert check_type_float(True) == 1.0
    try:
        check_type_float(None)
    except TypeError:
        pass
    else:
        assert 0, 'check_type_float("None") should have failed'
    try:
        check_type_float("invalid")
    except TypeError:
        pass
    else:
        assert 0, 'check_type_float("invalid") should have failed'



# Generated at 2022-06-20 16:35:15.491417
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits("1k") == 1024
    assert check_type_bits("100Mb") == (100 * 1024 * 1024)
    assert check_type_bits("1Gb") == (1024 * 1024 * 1024)
    assert check_type_bits("1Tb") == (1024 * 1024 * 1024 * 1024)
    assert check_type_bits("1Pb") == (1024 * 1024 * 1024 * 1024 * 1024)
    assert check_type_bits("1Eb") == (1024 * 1024 * 1024 * 1024 * 1024 * 1024)
    assert check_type_bits("1Zb") == (1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024)
    assert check_type_bits("1Yb") == (1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024)


# Generated at 2022-06-20 16:35:26.617751
# Unit test for function check_required_if
def test_check_required_if():
    requirements = None
    parameters = {'key1': 'val1'}
    assert check_required_if(requirements, parameters) == []

    # Testing case when 'is_one_of', 'req_all' & 'req_none' are set to True
    requirements = [
        ['key1', 'val1', ['key2', 'key3'], True],
        ['key1', 'val1', ['key4', 'key5'], True],
        ['key1', 'val1', ['key6', 'key7'], True]
    ]
    parameters = {'key1': 'val1'}
    assert check_required_if(requirements, parameters) == []
    parameters = {'key1': 'val1', 'key3': 'val3'}
    assert check_required_if(requirements, parameters)

# Generated at 2022-06-20 16:35:32.996874
# Unit test for function check_type_int
def test_check_type_int():
    result = check_type_int(22)
    assert result == 22
    result = check_type_int('22')
    assert result == 22
    try:
        result = check_type_int('22.0')
    except(TypeError):
        assert True
    else:
        assert False
    try:
        result = check_type_int(None)
    except(TypeError):
        assert True
    else:
        assert False



# Generated at 2022-06-20 16:35:34.397557
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by({'a': 'b'}, {'a': True, 'b': True}) == {}



# Generated at 2022-06-20 16:35:44.718773
# Unit test for function check_type_bytes