

# Generated at 2022-06-20 16:26:47.414636
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {'a': 1, 'b': 2}
    terms = [['a', 'b'], ['c', 'd']]
    assert not check_required_together(terms, parameters)
    parameters1 = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_together(terms, parameters1)
    parameters2 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert not check_required_together(terms, parameters2)
    parameters3 = {'a': 1, 'c': 3}
    assert check_required_together(terms, parameters3)



# Generated at 2022-06-20 16:26:58.437018
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1}') == {"a": 1}
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('[1, 2, 3]', include_exceptions=True) == ([1, 2, 3], None)
    assert safe_eval('["a", "b", "c"]', include_exceptions=True) == (["a", "b", "c"], None)
    assert safe_eval('{"a": 1, "b": 2}', include_exceptions=True) == ({"a": 1, "b": 2}, None)

# Generated at 2022-06-20 16:27:10.337816
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits("1Kb") == 1024
    assert check_type_bits("1Mb") == 1048576
    assert check_type_bits("1Gb") == 1073741824
    assert check_type_bits("1Tb") == 1099511627776
    assert check_type_bits("1Pb") == 1125899906842624
    assert check_type_bits("1B") == 1
    assert check_type_bits("1") == 1
    assert check_type_bits("1Mb") == 1048576
    assert check_type_bits("1Kib") == 1024
    assert check_type_bits("1Mib") == 1048576
    assert check_type_bits("1Gib") == 1073741824
    assert check_type_bits("1Tib") == 10995116

# Generated at 2022-06-20 16:27:16.057165
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path(12345) == '12345'
    assert check_type_path('$ANSIBLE_CONFIG') == os.path.expanduser(os.path.expandvars(os.environ["ANSIBLE_CONFIG"]))
    assert check_type_path('~/test') == os.path.expanduser('~/test')
    assert check_type_path(True, ) == 'True'
    assert check_type_path(False) == 'False'



# Generated at 2022-06-20 16:27:21.461926
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {"a": 1, "b": 2}
    requirements = {"a": ["b"]}
    result = check_required_by(requirements=requirements, parameters=parameters)
    assert result == {}
    parameters = {"a": 1}
    with pytest.raises(TypeError) as excinfo:
        check_required_by(requirements=requirements, parameters=parameters)
    assert str(excinfo.value) == "missing parameter(s) required by 'a': b"
    requirements = {"b": ["a"]}
    result = check_required_by(requirements=requirements, parameters=parameters)
    assert result == {}
    parameters = {"a": 1, "b": 2}
    requirements = {"a": "b"}

# Generated at 2022-06-20 16:27:24.408892
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    check_mutually_exclusive([['a', 'b']], {'a': 1, 'b': 2}, "stack")


# Generated at 2022-06-20 16:27:34.365681
# Unit test for function count_terms
def test_count_terms():
    """
    :returns: True if function count_terms returns expected number of occurrences.
    """
    # Dictionary to test counting
    parameters = {u'kwd1': u'val1', u'kwd2': u'val2', u'kwd3': u'val3', u'kwd4': u'val4', u'kwd5': u'val5'}

    # Verify correct total number of occurrences for terms in parameters
    assert count_terms(u'kwd2', parameters) == 1
    assert count_terms([u'kwd1', u'kwd2'], parameters) == 2
    assert count_terms(u'val4', parameters) == 1
    assert count_terms([u'val1', u'val5'], parameters) == 2

# Generated at 2022-06-20 16:27:45.002176
# Unit test for function check_required_if
def test_check_required_if():
    from ansible.modules.network.nxos import nxos_feature

    spec = {
        'nxos_feature': nxos_feature._ARGUMENT_SPEC,
    }
    module = AnsibleModule(argument_spec=spec)
    result = check_required_if([
        ['state', 'present', ['feature_config']],
    ], dict(state='present', feature_config='config'))
    assert result == []
    result = check_required_if([
        ['state', 'present', ['feature_config']],
    ], dict(state='present'))
    assert result == []
    result = check_required_if([
        ['state', 'present', ['feature_config']],
    ], dict(state='present', some_param='config'))
    assert result == []
    result = check

# Generated at 2022-06-20 16:27:49.574766
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    from ansible.module_utils.basic import AnsibleModule
    import json
    params = {'name' : 'test', 'age' : 5}
    required_params = ['name', 'age']
    try:
        test = check_missing_parameters(params, required_params)
        assert test == [], "This should pass"
    except Exception as e:
        raise AssertionError("This should pass")

    params = {'age' : 5}
    required_params = ['name', 'age']
    try:
        test = check_missing_parameters(params, required_params)
        assert test == "This test should fail", "This should fail"
    except Exception as e:
        assert test == "missing required arguments: name", "This should fail"


# Generated at 2022-06-20 16:27:59.004530
# Unit test for function check_required_together
def test_check_required_together():
    spec_check_required_together = dict (
        check_required_together = [
            ['bar', 'baz'],
            ['foo']
        ]
    )
    # Tests for check_required_together
    parameters_check_required_together_foo_1 = dict (
        foo = 'test'
    )
    result_check_required_together_foo_1 = check_required_together(
        spec_check_required_together['check_required_together'],
        parameters_check_required_together_foo_1)
    assert result_check_required_together_foo_1 == None

    parameters_check_required_together_bar_baz_1 = dict (
        bar = 'test',
        baz = 'test'
    )
    result_check_required_together_bar_baz_1 = check

# Generated at 2022-06-20 16:28:10.759513
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = dict(ansible_host=1)
    required_parameters = ['ansible_host']
    assert check_missing_parameters(parameters, required_parameters) == []

    parameters = dict()
    required_parameters = ['ansible_host']
    assert check_missing_parameters(parameters, required_parameters) == ['ansible_host']



# Generated at 2022-06-20 16:28:22.933898
# Unit test for function check_type_dict
def test_check_type_dict():
    # No error
    check_type_dict({"a": 'b'})
    check_type_dict('{"a": "b"}')
    check_type_dict('a=b, c=d')
    check_type_dict('a=b')
    check_type_dict(' a=b ')
    check_type_dict('a = b, c = d , e = f')
    check_type_dict('a = b, \'c\' = d, "e" = f')
    # Error
    with pytest.raises(TypeError):
        check_type_dict('a=b, c')
    with pytest.raises(TypeError):
        check_type_dict('a==b')

# Generated at 2022-06-20 16:28:34.097616
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1+1') == 2
    assert safe_eval('1 + 1') == 2
    assert safe_eval('foo') == 'foo'
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1, 2]') == [1, 2]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('-1') == -1
    assert safe_eval('-1.1') == -1.1

    assert safe_eval('import x') == 'import x'

# Generated at 2022-06-20 16:28:40.669837
# Unit test for function check_required_by
def test_check_required_by():
    # list of requirements
    requirements = {'name': 'state', 'state': ['present', 'absent']}
    # list of parameters
    parameters = {'name': 'test file', 'state': 'present'}
    # run test
    result = check_required_by(requirements, parameters)
    # verify that no exceptions raised
    assert isinstance(result, dict)
    assert not result



# Generated at 2022-06-20 16:28:46.150087
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    test_parameters = {}
    test_required_parameters = ['A', 'B', 'C']

    assert check_missing_parameters(test_parameters,
                                    test_required_parameters) == test_required_parameters
    test_parameters = {'A': 1}
    assert check_missing_parameters(test_parameters,
                                    test_required_parameters) == test_required_parameters[1:]


# Generated at 2022-06-20 16:28:53.007463
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg({'a':1}) == '{\'a\': 1}'
    assert check_type_jsonarg(dict(a=1)) == '{\'a\': 1}'
    assert check_type_jsonarg('{"a":1}') == '{"a":1}'


# Generated at 2022-06-20 16:29:03.325640
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [["a", "b", "c"], ["d", "e"], ("f", "g")]
    params = dict(a="test")
    assert check_required_one_of(terms, params) == []

    params = dict(f="test")
    assert check_required_one_of(terms, params) == []

    params = dict()
    try:
        check_required_one_of(terms, params)
    except TypeError as e:
        assert e.args[0] == "one of the following is required: a, b, c"

    try:
        params = dict()
        check_required_one_of(terms, params)
    except TypeError as e:
        assert e.args[0] == "one of the following is required: a, b, c"



# Generated at 2022-06-20 16:29:13.083585
# Unit test for function check_required_by
def test_check_required_by():
    params = dict(name='some name', src='/path/to/file',
                  state='present')
    requirements = dict(state=dict(required='present', choices=['present', 'absent']),
                        src=dict(required=['state', 'present']),)
    assert check_required_by(dict(state=dict(required='present', choices=['present', 'absent']),
                                  src=dict(required=['state', 'present']),), params) == {}
    params = dict(name='some name', state='present')
    assert check_required_by(dict(state=dict(required='present', choices=['present', 'absent']),
                                  src=dict(required=['state', 'present']),), params) == {'src': ['state']}

# Generated at 2022-06-20 16:29:14.679978
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg("a string") == "a string"
    assert check_type_jsonarg(['a string']) == '["a string"]'
    assert check_type_jsonarg({"a": "string"}) == '{"a": "string"}'

# Generated at 2022-06-20 16:29:17.934728
# Unit test for function check_type_str
def test_check_type_str():
    try:
        check_type_str(dict(a=1), allow_conversion=False)
        raise AssertionError("Unreachable code")
    except TypeError:
        pass
    try:
        check_type_str(dict(a=1))
    except TypeError:
        raise AssertionError("Use of surrogateescape enabled")
    check_type_str("abc", allow_conversion=False)
    check_type_str("abc")



# Generated at 2022-06-20 16:29:25.024205
# Unit test for function check_type_path
def test_check_type_path():
    value = '/home/zhaoxu.fang/zhaoxu.fang'
    result = check_type_path(value)
    assert value == result


# Generated at 2022-06-20 16:29:37.319230
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict({}) == {}
    assert check_type_dict("") == {}
    assert check_type_dict("{}") == {}
    assert check_type_dict("{\"a\": 1}") == {"a": 1}
    assert check_type_dict("a='b'") == {'a': 'b'}
    assert check_type_dict("a=1") == {'a': '1'}
    assert check_type_dict("a=1, b=2") == {'a': '1', 'b': '2'}
    assert check_type_dict("a='b,c'") == {'a': 'b,c'}
    assert check_type_dict("a='b, c'") == {'a': 'b, c'}

# Generated at 2022-06-20 16:29:47.362085
# Unit test for function check_required_one_of
def test_check_required_one_of():
    import os
    import tempfile
    import shutil
    import ansible.module_utils.basic

    # Create a temp directory
    temp_dir = tempfile.mkdtemp()
    # Create a temp file
    fd, temp_path = tempfile.mkstemp()
    # Write data to it
    os.write(fd, b'foo')
    # Close the file
    os.close(fd)
    # Create a ansible module

# Generated at 2022-06-20 16:29:53.532148
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('/tmp/file') == '/tmp/file'
    assert check_type_path('test/a.cfg') == os.getcwd() + '/test/a.cfg'
    assert check_type_path('~/test/a.cfg') == os.path.expanduser('~') + '/test/a.cfg'
    assert check_type_path('$HOME/test/a.cfg') == os.path.expandvars('$HOME') + '/test/a.cfg'


# Generated at 2022-06-20 16:30:04.347960
# Unit test for function check_type_dict
def test_check_type_dict():
    for test in [{'a': 1}, "{'a': 1}", "{'a': 1, 'b': 2}", "{'a': 1, 'b': 2}",
              "a=1, b=2, c=3", "a='1', b='2', c='3'", "'a=1', b='2', c='3'",
              "a='1', b=\"2\", c='3'"]:
        assert check_type_dict(test) == {'a': '1', 'b': '2', 'c': '3'}

# Generated at 2022-06-20 16:30:08.423846
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together([["a", "b"]], dict(a=3, b=4)) == []
    assert check_required_together([["a", "b"]], dict(a=3)) == [["a", "b"]]
    assert check_required_together([["a", "b"]], dict(a=0, b=4)) == []
    assert check_required_together([["a", "b"]], dict(a=0, c=4)) == []
    assert check_required_together([["a", "b"]], dict(b=0, c=4)) == [["a", "b"]]



# Generated at 2022-06-20 16:30:20.125587
# Unit test for function check_type_float
def test_check_type_float():
    """Unit test for function check_type_float"""
    # Given number literal
    assert check_type_float(1.0) == 1.0
    # Given number literal
    assert check_type_float(1) == 1.0
    # Given number literal
    assert check_type_float(12) == 12.0
    # Given number literal
    assert check_type_float('1.0') == 1.0
    # Given number literal
    assert check_type_float('1') == 1.0
    # Given number literal
    assert check_type_float('12') == 12.0
    # Given number literal
    assert check_type_float(b'1.0') == 1.0
    # Given number literal
    assert check_type_float(b'1') == 1.0
    # Given number literal

# Generated at 2022-06-20 16:30:26.792610
# Unit test for function check_type_path
def test_check_type_path():
    expected = "/tmp/test_directory/hello"
    sample1 = '/tmp/test_directory/hello'
    sample2 = "~/test_directory/hello"
    sample3 = "$HOME/test_directory/hello"

    assert expected == check_type_path(sample1)
    assert expected == check_type_path(sample2)
    assert expected == check_type_path(sample3)


# Generated at 2022-06-20 16:30:36.098241
# Unit test for function check_type_str
def test_check_type_str():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes, to_text
    assert check_type_str(123) == u'123'
    assert check_type_str(123, allow_conversion=False) == u'123'
    # test ascii
    assert check_type_str(to_bytes(u'123')) == u'123'
    assert check_type_str(to_bytes(u'abc'), allow_conversion=False) == u'abc'
    # test utf-8
    assert check_type_str(to_bytes(u'\u20ac', encoding='utf-8')) == u'\u20ac'

# Generated at 2022-06-20 16:30:42.816869
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list("1,2,3") == ['1','2','3']
    assert check_type_list("1") == ['1']
    assert check_type_list("1.0") == ['1.0']
    assert check_type_list([1,2,3]) == [1,2,3]
    assert check_type_list(1) == ['1']
    assert check_type_list(1.5) == ['1.5']



# Generated at 2022-06-20 16:30:49.262548
# Unit test for function check_type_raw
def test_check_type_raw():
    test = 'abc'
    check_type_raw(test) == test



# Generated at 2022-06-20 16:30:55.317946
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1MB') == 1048576
    assert check_type_bytes('2MiB') == 2097152
    assert check_type_bytes('3KB') == 3072
    assert check_type_bytes('4KiB') == 4096
    assert check_type_bytes('5mb') == 5242880
    assert check_type_bytes('6k') == 6144
    assert_raises(TypeError, check_type_bytes, 'one')



# Generated at 2022-06-20 16:31:06.804712
# Unit test for function safe_eval
def test_safe_eval():
    """Unit tests for safe_eval()
    """
    from ansible.module_utils.six import PY3
    assert safe_eval('["foo", "bar"]') == ['foo', 'bar']
    assert safe_eval('{"foo": "bar", "blah": "meh"}') == {'foo': 'bar', 'blah': 'meh'}
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('foo') == 'foo'
    assert safe_eval('1') == 1
    assert safe_eval('1') == 1
    if not PY3:
        assert safe_eval('1L') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('True') is True
    assert safe_eval('true') == 'true'

# Generated at 2022-06-20 16:31:16.255980
# Unit test for function check_required_arguments
def test_check_required_arguments():
    """Unit test for function check_required_arguments
    """
    argument_spec = {
        'foo': {'required': True},
        'bar': {'required': False}
    }

    missing = check_required_arguments(argument_spec, {'bar': 'somevalue'})
    assert missing == []

    missing = check_required_arguments(argument_spec, {'foo': 'somevalue'})
    assert missing == []

    missing = check_required_arguments(argument_spec, {'bar': 'somevalue', 'foo': 'somevalue'})
    assert missing == []

    try:
        missing = check_required_arguments(argument_spec, {})
        assert False
    except TypeError:
        pass

# Generated at 2022-06-20 16:31:19.617520
# Unit test for function check_type_bytes
def test_check_type_bytes():
    test_str = "42GiB"
    test_bytes = check_type_bytes(test_str)
    assert test_bytes == 45359967045888, "check_type_bytes() Failed to cast '%s' to bytes" % (test_str)



# Generated at 2022-06-20 16:31:30.801819
# Unit test for function check_required_together
def test_check_required_together():
    # check_required_together will return true for the following parameters
    parameters = {'a': 'a', 'b': 'b', 'c': 'c'}
    assert True == check_required_together(terms=None, parameters=parameters)
    assert True == check_required_together(terms=[['a', 'b']], parameters=parameters)
    assert True == check_required_together(terms=[['a', 'b'], ['b', 'c']], parameters=parameters)

    # check_required_together will return false for the following parameters
    parameters = {'a': 'a'}
    assert False == check_required_together(terms=[[['a', 'b'], ['b', 'c']]], parameters=parameters)



# Generated at 2022-06-20 16:31:38.897849
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Create a simple list
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 'test_a', 'c': 'test_c'}

    result = check_mutually_exclusive(terms, parameters)
    assert result == []

    # Create a simple list
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 'test_a', 'b': 'test_b'}

    result = check_mutually_exclusive(terms, parameters)
    assert result == [['a', 'b']]

    # Create a nested list
    terms = [['a', 'b'], ['c', ['d', 'e']]]

# Generated at 2022-06-20 16:31:43.722630
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw("string") == "string"
    assert check_type_raw(["list"]) == ["list"]
    assert check_type_raw(("tuple",)) == ("tuple",)
    assert check_type_raw(123) == 123
    assert check_type_raw({"k": "v"}) == {"k": "v"}
    assert check_type_raw("1") == "1"
    assert check_type_raw("true") == "true"
    assert check_type_raw("yes") == "yes"
    assert check_type_raw("no") == "no"
    assert check_type_raw("on") == "on"
    assert check_type_raw("off") == "off"



# Generated at 2022-06-20 16:31:51.428719
# Unit test for function check_required_if
def test_check_required_if():
    # Case 1: Pass
    parameters = dict(state='present', path='/tmp/ansible')
    requirements = [['state', 'present', ('path',), True]]
    results = []
    results = check_required_if(requirements, parameters)
    assert results == []

    # Case 2: Fail
    parameters = dict(state='present')
    requirements = dict(state='present', path='/tmp/ansible')
    results = []
    results = check_required_if(requirements, parameters)
    assert results[0]['missing'] == ['path']



# Generated at 2022-06-20 16:31:59.109244
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    """
    check_type_jsonarg function return the jsonified value for the corresponding given type
    """
    assert check_type_jsonarg(dict(['a', 'b'])) == '{"a": "b"}'
    assert check_type_jsonarg(dict(['a', 1])) == '{"a": 1}'
    assert check_type_jsonarg(dict(['a', True])) == '{"a": true}'
    assert check_type_jsonarg(dict(['a', None])) == '{"a": null}'

# Generated at 2022-06-20 16:32:11.181506
# Unit test for function check_required_together
def test_check_required_together():
    parameters = dict(
        acidburn=1,
        zerocool=0,
        crashoverride=1,
        alex=0,
        kate=1,
        kristen=0,
        kristen2=0,
        kristen3=1,
        kristen4=0,
        kristen5=0,
        kristen6=1,
        kristen7=1,
        kristen8=0,
        kristen9=1,
        kristen10=0,
    )

# Generated at 2022-06-20 16:32:21.063274
# Unit test for function check_type_int
def test_check_type_int():
    strval = "2"
    intval = 2
    boolval = True
    floatval = 1.0
    dictval = {'value': 'test'}
    listval = ['a', 'b']

    assert check_type_int(strval) == 2
    assert check_type_int(intval) == 2
    assert check_type_int(boolval) == 1
    assert check_type_int(floatval) == 1

    try:
        check_type_int(dictval)
        assert False
    except TypeError:
        pass

    try:
        check_type_int(listval)
        assert False
    except TypeError:
        pass



# Generated at 2022-06-20 16:32:29.500245
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('3+4') == 7
    assert safe_eval('[3,4]') == [3, 4]
    assert safe_eval('[3,4]', include_exceptions=True) == ([3, 4], None)
    assert safe_eval('{"foo":"bar"}') == {'foo': 'bar'}
    assert safe_eval('{"foo":"bar"}', include_exceptions=True) == ({'foo': 'bar'}, None)
    assert safe_eval('3.4') == 3.4
    assert safe_eval('3.4', include_exceptions=True) == (3.4, None)
    assert safe_eval('import os') == 'import os'
    assert safe_eval('import os', include_exceptions=True) == ('import os', None)

# Generated at 2022-06-20 16:32:33.727097
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [['required1','required2']]
    parameters = dict(required3=3)
    with pytest.raises(TypeError) as excinfo:
        check_required_one_of(terms, parameters)
    assert 'one of the following is required: required1, required2' in str(excinfo)


# Generated at 2022-06-20 16:32:40.456127
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list([1,2,3]) == [1,2,3]
    assert check_type_list(1) == ['1']
    assert check_type_list('1') == ['1']
    assert check_type_list('1,2') == ['1', '2']
    with pytest.raises(TypeError):
        check_type_list(['1', {'id':1}])


# Generated at 2022-06-20 16:32:41.130103
# Unit test for function check_type_jsonarg

# Generated at 2022-06-20 16:32:48.915405
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(['foo', 'bar'], {'foo': 'bar', 'baz': 'qux'}) == 1
    assert count_terms(['foo', 'baz'], {'foo': 'bar', 'baz': 'qux'}) == 2
    assert count_terms(['foo'], {'foo': 'bar', 'baz': 'qux'}) == 1
    assert count_terms(['foo', 'foo'], {'foo': 'bar', 'baz': 'qux'}) == 1



# Generated at 2022-06-20 16:32:59.793709
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['one', 'two'], ['three', 'four']]
    parameters = {'one': 1, 'three': 3}
    options_context = None
    results = check_required_together(terms, parameters, options_context)
    assert results == []
    parameters = {'one': 1}
    results = check_required_together(terms, parameters, options_context)
    try:
        assert results == [terms[0]]
    except TypeError as e:
        assert "parameters are required together: one, two" in str(e)
    parameters = {'three': 3}
    results = check_required_together(terms, parameters, options_context)
    try:
        assert results == [terms[1]]
    except TypeError as e:
        assert "parameters are required together: three, four" in str

# Generated at 2022-06-20 16:33:03.196895
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg(['--wait', '120']) == '["--wait", "120"]'

# Generated at 2022-06-20 16:33:11.529453
# Unit test for function check_type_bool
def test_check_type_bool():
    from ansible.module_utils.basic import AnsibleModule
    import pytest

    good_values = {
        'true': True, 'True': True, 'TRUE': True,
        'false': False, 'False': False, 'FALSE': False,
        'y': True, 'Y': True, 'yes': True, 'Yes': True, 'YES': True,
        'n': False, 'N': False, 'no': False, 'No': False, 'NO': False,
        't': True, 'T': True, 'f': False, 'F': False,
        'on': True, 'On': True, 'ON': True,
        'off': False, 'Off': False, 'OFF': False,
        1: True, True: True, 0: False, False: False}


# Generated at 2022-06-20 16:33:18.976868
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('/root') == '/root'


# Generated at 2022-06-20 16:33:25.962953
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(2) == 2
    assert check_type_int('3') == 3
    assert check_type_int('0x3') == 3
    assert check_type_int('-3') == -3
    assert check_type_int(2.2) == 2
    assert check_type_int('1.8') == 1
    assert check_type_int(2) == 2
    assert check_type_int('3') == 3
    assert check_type_int(3.3) == 3
    assert check_type_int('0x3') == 3
    assert check_type_int('-3') == -3
    assert check_type_int(2.2) == 2
    assert check_type_int('1.8') == 1
    assert check_type_int(True) == 1

# Generated at 2022-06-20 16:33:32.691311
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path("~/path") == os.path.expanduser("~/path")
    assert check_type_path("/root/path") == "/root/path"
    assert check_type_path("$HOME/path") == os.path.expandvars("$HOME/path")
    assert check_type_path("${HOME}/path") == os.path.expandvars("${HOME}/path")


# Generated at 2022-06-20 16:33:43.353151
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():

    # Test: Mutually exclusive parameters
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 'ansible', 'b': 'ansible', 'c': 'ansible', 'd': 'ansible'}
    assert count_terms(['a', 'b'], parameters) == 2
    test = check_mutually_exclusive(terms, parameters)
    assert isinstance(test, list)
    assert test == []

    # Test: Invalid options - mutually exclusive parameters
    try:
        check_mutually_exclusive([['a', 'b']], parameters)
    except TypeError:
        pass
    try:
        check_mutually_exclusive(['a', 'b'], parameters)
    except TypeError:
        pass


# Generated at 2022-06-20 16:33:47.542501
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(2) == 2
    assert check_type_int(2.1) == 2
    assert check_type_int("2") == 2
    assert check_type_int("2.1") == 2



# Generated at 2022-06-20 16:33:51.516482
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1MiB') == 1048576
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('1Gib') == 1073741824


# Generated at 2022-06-20 16:33:58.079046
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    def func1(a, b=3, c=4):
        return a+b+c

    def func2(a, b, c=4):
        return a+b+c


# Generated at 2022-06-20 16:34:01.817441
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms_list = [['a','b','c'],['d','e','f']]
    parameters = {'a':'1','d':'2','g':'3'}
    check_mutually_exclusive(terms_list,parameters)



# Generated at 2022-06-20 16:34:13.604195
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('test', True) == 'test'
    assert check_type_str(True, True) == 'True'
    assert check_type_str(1, True) == '1'
    assert check_type_str(b'bytes', True) == 'bytes'
    assert check_type_str(u'unicode', True) == 'unicode'

    with pytest.raises(TypeError):
        check_type_str(True, False)
    with pytest.raises(TypeError):
        check_type_str(1, False)
    with pytest.raises(TypeError):
        check_type_str(b'bytes', False)
    with pytest.raises(TypeError):
        check_type_str(u'unicode', False)



# Generated at 2022-06-20 16:34:22.732559
# Unit test for function check_type_float
def test_check_type_float():
    assert isinstance(check_type_float(1), float)
    assert isinstance(check_type_float("1"), float)
    assert isinstance(check_type_float(1.0), float)
    assert isinstance(check_type_float("1.0"), float)
    assert isinstance(check_type_float("1.0s"), float)
    assert isinstance(check_type_float("1.0m"), float)
    assert isinstance(check_type_float("1.0h"), float)
    assert isinstance(check_type_float("1.0d"), float)
    assert isinstance(check_type_float("1.0w"), float)
    assert isinstance(check_type_float("1.0y"), float)
    assert check_type_float(1.0) == 1.0


# Generated at 2022-06-20 16:34:33.267311
# Unit test for function check_type_float

# Generated at 2022-06-20 16:34:37.950511
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by({'a': ['b', 'c']}, {'a': True, 'b': True, 'c': True}) == {}
    assert check_required_by({'a': 'b'}, {'a': True, 'b': True}) == {}
    assert check_required_by({'a': ['b', 'c']}, {'a': True, 'b': True}) == {'a': ['c']}


# Generated at 2022-06-20 16:34:47.930258
# Unit test for function check_type_path
def test_check_type_path():
    assert not check_type_path(None)
    assert not check_type_path(False)
    assert "~" == check_type_path('~')
    assert "~" == check_type_path(u'\u03bc')
    assert "~" == check_type_path(u'\N{GREEK SMALL LETTER MU}')
    assert "/" == check_type_path('/')
    assert "/" == check_type_path('/tmp/../')
    assert "/tmp/toast" == check_type_path('/tmp/toast')
    assert "/tmp/toast" == check_type_path('/tmp/./toast')
    assert "/tmp/toast" == check_type_path('/tmp/../tmp/toast')



# Generated at 2022-06-20 16:34:54.201390
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {"test": None}
    required_parameters = ["test"]

    try:
        check_missing_parameters(parameters, required_parameters)
    except:
        assert True
    else:
        assert False

    parameters["test"] = "bob"
    try:
        check_missing_parameters(parameters, required_parameters)
    except:
        assert False
    else:
        assert True



# Generated at 2022-06-20 16:35:01.041638
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{"a":"b"}') == '{"a":"b"}'
    assert check_type_jsonarg('[1,2,3]') == '[1,2,3]'
    assert check_type_jsonarg([1,2,3]) == '[1, 2, 3]'
    assert check_type_jsonarg({'a':1}) == '{"a": 1}'
    raises(TypeError, check_type_jsonarg, None)



# Generated at 2022-06-20 16:35:07.709874
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes("1M") == 1048576
    assert check_type_bytes("2.5K") == 2560
    assert check_type_bytes("3k") == 3072
    assert check_type_bytes("4.5") == 4
    assert check_type_bytes("5G") == 5368709120
    with pytest.raises(TypeError):
        check_type_bytes("9Xyzz")



# Generated at 2022-06-20 16:35:12.650499
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('raw') == 'raw'
    assert check_type_raw(u'unicode_str') == u'unicode_str'
    assert check_type_raw(1) == 1
    assert check_type_raw(True) == True
    assert isinstance(check_type_raw([]), list)
    assert isinstance(check_type_raw({}), dict)


# Generated at 2022-06-20 16:35:21.116308
# Unit test for function check_required_arguments
def test_check_required_arguments():
    arguments_spec = {
        'path': {'required': True},
        'state': {'required': False, 'default': 'file'},
    }
    # Test the happy path
    try:
        check_required_arguments(arguments_spec, {'path': 'INVALID'})
    except TypeError:
        assert False, 'test failed function check_required_arguments'
    # Test the unhappy path
    try:
        check_required_arguments(arguments_spec, {})
        assert False, 'test failed function check_required_arguments'
    except TypeError:
        assert True, 'test successful function check_required_arguments'


# Generated at 2022-06-20 16:35:28.881502
# Unit test for function check_required_arguments
def test_check_required_arguments():
    required = {'required': True}
    argument_spec = {
        'required_arg': required,
        'optional_arg': {}
    }
    parameters = {
        'optional_arg': "test"
    }
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert e.args[0] == "missing required arguments: required_arg"
    else:
        assert False



# Generated at 2022-06-20 16:35:30.302514
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('raw') == 'raw'
    assert check_type_raw(123) == 123



# Generated at 2022-06-20 16:35:45.721345
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.converters import to_text
    assert(safe_eval('123') == 123)
    assert(safe_eval('[1, 2, 3]') == [1, 2, 3])
    assert(safe_eval('{ "a": 1, "b": "foo" }') == {'a': 1, 'b': 'foo'})
    assert(safe_eval('"foo"') == "foo")
    assert(safe_eval('123', include_exceptions=True) == (123, None))
    assert(safe_eval('[1, 2, 3]', include_exceptions=True) == ([1, 2, 3], None))