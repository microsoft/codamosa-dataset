

# Generated at 2022-06-20 16:26:12.061274
# Unit test for function check_required_arguments
def test_check_required_arguments():
    try:
        check_required_arguments({'a': {'required': True}}, {})
    except TypeError as e:
        assert to_native(e) == "missing required arguments: a"
    else:
        assert False, "check_required_arguments didn't raise TypeError"



# Generated at 2022-06-20 16:26:19.546115
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    from units.mock.procenv import ModuleTestCase
    from ansible.module_utils.common.validation import check_mutually_exclusive

    class TestValidationCheckMutuallyExclusiveCase(ModuleTestCase):
        def test_check_mutually_exclusive(self, *args, **kwargs):
            def run_func(terms, params, options_context=None):
                return check_mutually_exclusive(terms, params, options_context)

            def gen_exception(terms, params, options_context=None):
                with self.assertRaises(TypeError):
                    check_mutually_exclusive(terms, params, options_context)

            self.assertEqual(run_func(None, {}), [])
            self.assertEqual(run_func([['one', 'two']], dict(one=True)), [])

# Generated at 2022-06-20 16:26:28.306420
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list([]) == []
    assert check_type_list('') == []
    assert check_type_list(',') == []
    assert check_type_list(2) == ['2']
    assert check_type_list('2') == ['2']
    assert check_type_list('2,3') == ['2', '3']
    try:
        check_type_list({})
        assert False, "Expected to raise TypeError"
    except TypeError as e:
        assert "{!r} cannot be converted to a list".format({}) in str(e)



# Generated at 2022-06-20 16:26:39.135999
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Passing test for check_required_arguments
    argument_spec = dict(
        first=dict(type='str', required=True),
        second=dict(type='str', required=False),
        third=dict(type='str', required=True),
    )
    parameters = {'first': 'one', 'second': 'two', 'third': 'three'}
    missing = check_required_arguments(argument_spec, parameters)
    assert not missing
    # Failing test for check_required_arguments
    parameters = {'first': 'one', 'second': 'two'}
    try:
        missing = check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert 'third' in to_native(e)



# Generated at 2022-06-20 16:26:50.670179
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'ipv4': ['subnet', 'netmask'], 'ipv6': ['subnet6', 'prefix6']}
    parameters = {'ipv4': 'true', 'subnet': '10.10.10.0', 'netmask': '255.255.255.0', 'ipv6': 'false'}
    assert check_required_by(requirements, parameters) == {}
    parameters = {'ipv4': 'true', 'subnet': '10.10.10.0', 'ipv6': 'false'}
    assert check_required_by(requirements, parameters) == {'ipv4': ['netmask']}

# Generated at 2022-06-20 16:27:00.418339
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('True') is True
    assert safe_eval('True and False') is False
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.bar') == 'foo.bar'
    assert safe_eval('foo.bar("what")') == 'foo.bar("what")'
    assert safe_eval("'''bar'''") == 'bar'
    assert safe_eval("'''\"bar\"'''") == '"bar"'
    assert safe_eval("'''\nbar\n'''") == '\nbar\n'
    assert safe_eval("'bar'") == 'bar'
    assert safe_eval("'\"bar\"'") == '"bar"'

# Generated at 2022-06-20 16:27:11.884995
# Unit test for function check_type_str
def test_check_type_str():

    # Our first test will pass, but with a DeprecationWarning
    with pytest.warns(DeprecationWarning):
        assert check_type_str('foo') == 'foo'

    # Now we will get a TypeError because allow_conversion is False
    with pytest.raises(TypeError) as execinfo:
        check_type_str(u'foo', False)
    assert to_native(execinfo.value) == "'foo' is not a string and conversion is not allowed"

    # Verify conversion is working
    assert check_type_str(u'foo', True) == u'foo'
    assert check_type_str(1, True) == u'1'
    assert check_type_str(['foo'], True) == u"[u'foo']"



# Generated at 2022-06-20 16:27:19.281049
# Unit test for function check_required_one_of

# Generated at 2022-06-20 16:27:28.181044
# Unit test for function check_required_if
def test_check_required_if():
    sample_argument_spec = dict(
        required_if=[
            ['state', 'present', ('path',), True],
            ['someint', 99, ('bool_param', 'string_param')],
        ],
    )
    sample_parameters = dict(
        path = '/tmp',
        state = 'present',
        someint = 99,
        bool_param = True
    )
    try:
        check_required_if(sample_argument_spec, sample_parameters, options_context=None)
    except TypeError as e:
        pass


# Generated at 2022-06-20 16:27:36.650548
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = ['a', 'b', 'c']
    parameters = {'a': 1, 'b': 2}
    options_context = ['foo', 'bar']
    results = check_mutually_exclusive(terms, parameters, options_context)
    assert(results == [])

    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3}
    options_context = ['foo', 'bar']
    try:
        results = check_mutually_exclusive(terms, parameters, options_context)
    except TypeError as e:
        results = e
    assert(results == TypeError('parameters are mutually exclusive: a|b found in foo -> bar'))



# Generated at 2022-06-20 16:27:47.415483
# Unit test for function check_type_int
def test_check_type_int():
    assert(check_type_int(1) == 1)
    assert(check_type_int(0) == 0)
    assert(check_type_int(-1) == -1)
    assert(check_type_int("1") == 1)
    assert(check_type_int("0") == 0)
    assert(check_type_int("-1") == -1)
    with pytest.raises(TypeError):
        check_type_int("test")
    with pytest.raises(TypeError):
        check_type_int(False)
    with pytest.raises(TypeError):
        check_type_int(True)
    with pytest.raises(TypeError):
        check_type_int(None)



# Generated at 2022-06-20 16:27:58.513242
# Unit test for function check_required_if

# Generated at 2022-06-20 16:28:08.717794
# Unit test for function safe_eval
def test_safe_eval():
    # passing a string
    assert safe_eval("'test'") == 'test'
    assert safe_eval("['test', 'test2']") == ['test', 'test2']
    assert safe_eval("{'a': 'test', 'b': ['test', 'test2']}") == {'a': 'test', 'b': ['test', 'test2']}
    assert safe_eval("'test'.replace('e', 'a')") == 'tast'
    assert safe_eval(r"'te\st'.replace('e\s', 'a')") == 'tast'
    # passing an unicode string
    assert safe_eval(u"'\xc3\xa9'") == '\xc3\xa9'

# Generated at 2022-06-20 16:28:20.648117
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = dict(
        state=dict(type='str', required=True),
        name=dict(type='str', required=True),
        force=dict(type='bool', required=False),
    )
    parameters = dict(state='present', name='foo')
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []

    parameters = dict(state='present', name='foo', force=True)
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []

    parameters = dict(state='present')
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert 'name' in e.message
        assert 'required arguments' in e.message
    else:
        assert False

    parameters

# Generated at 2022-06-20 16:28:31.890948
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together([[('a', 'b'), 'c']], {'a': 0, 'b': 0, 'c': 0})
    assert check_required_together([[('a', 'b'), 'c']], {'b': 0, 'c': 0})
    assert check_required_together([[('a', 'b'), 'c']], {'a': 0, 'c': 0})
    # case of unexpected type
    assert check_required_together([[('a', 'b'), 'c']], {'a': 0, 'b': 0, 'c': 0}) == []
    assert check_required_together([[('a', 'b'), 'c']], {'a': 0, 'b': 0}) != []



# Generated at 2022-06-20 16:28:35.160763
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # test with all required parameters present
    parameters={"param1": "value1", "param2": "value2", "param3": "value3"}
    required_parameters=["param1", "param2", "param3"]
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == []

    # test with only one required parameter present
    parameters={"param1": "value1"}
    required_parameters=["param1", "param2", "param3"]
    with pytest.raises(TypeError):
        check_missing_parameters(parameters, required_parameters)



# Generated at 2022-06-20 16:28:38.906197
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0
    assert check_type_float(2.2) == 2.2
    assert check_type_float("1") == 1.0
    assert check_type_float("2.2") == 2.2
    assert check_type_float(b"2.2") == 2.2



# Generated at 2022-06-20 16:28:41.849657
# Unit test for function check_required_arguments
def test_check_required_arguments():
    missing = []
    try:
        check_required_arguments({"required": True}, {"required": False})
    except TypeError as e:
        assert 'missing required arguments' in str(e)


# Generated at 2022-06-20 16:28:45.864271
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('/test') == '/test'
    try:
        check_type_path(dict())
    except TypeError as e:
        assert "%s cannot be converted to a path" % type(dict()) in str(e)
# End of unit test for function check_type_path



# Generated at 2022-06-20 16:28:49.385586
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(True) is True
    assert check_type_raw(1) == 1
    assert check_type_raw('1') == '1'


# Generated at 2022-06-20 16:29:03.803980
# Unit test for function check_required_if
def test_check_required_if():
    res = check_required_if([
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ], {'state': 'present', 'path': 'hello'})
    assert res == []

    res = check_required_if([
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ], {'state': 'present', 'path': 'hello', 'bool_param': True})
    assert res == []

    res = check_required_if([
        ['someint', 99, ('bool_param', 'string_param')],
    ], {'state': 'present', 'path': 'hello', 'bool_param': True})
    assert res == []


# Generated at 2022-06-20 16:29:13.388046
# Unit test for function check_required_by
def test_check_required_by():
    # Should pass
    requirements = {'param_one': 'param_two'}
    parameters = {'param_one': 'value_one', 'param_two': 'value_two'}
    assert check_required_by(requirements, parameters) == {}

    # Should raise TypeError with message stating  missing parameter required by
    # 'param_one'
    requirements = {'param_one': 'param_two'}
    parameters = {'param_one': 'value_one'}
    msg = "missing parameter(s) required by 'param_one': param_two"

# Generated at 2022-06-20 16:29:23.809292
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # pylint: disable=protected-access
    dict1 = dict(one=0, two=0, three=0)
    dict2 = dict(one=0, two=0, three='test')
    dict3 = dict(one=0, two='test', three='test')
    dict4 = dict(one='test', two='test', three='test')
    dict5 = dict(one='test')
    dict6 = dict(one=0)
    dict7 = dict()
    list1 = ['one', 'two']
    list2 = ['one', 'two', 'three']
    list3 = ['one']
    tuple1 = ('one', 'two')
    tuple2 = ('one', 'two', 'three')
    tuple3 = ('one',)
    # check if function returns empty list when given empty parameters

# Generated at 2022-06-20 16:29:35.511166
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path', 'group'), True]
    ]
    parameters = {'state': 'present', 'path': '/foo', 'group': 'foo'}
    options_context = ['state']
    assert check_required_if(requirements, parameters, options_context) == []

    requirements = [
        ['state', 'present', ('path', 'group')]
    ]
    parameters = {'state': 'present', 'path': '/foo', 'group': 'foo'}
    options_context = ['state']
    assert check_required_if(requirements, parameters, options_context) == []

    requirements = [
        ['state', 'present', ('path', 'group'), True]
    ]

# Generated at 2022-06-20 16:29:43.087686
# Unit test for function check_type_path
def test_check_type_path():
    with pytest.raises(Exception):
        check_type_path(None)
    assert check_type_path('/tmp') == '/tmp'
    assert check_type_path('~/tmp') == '{0}/tmp'.format(os.path.expanduser('~'))
    assert check_type_path('$HOME/tmp') == '{0}/tmp'.format(os.environ['HOME'])
    with pytest.raises(Exception):
        check_type_path(['a', 'b'])
    with pytest.raises(Exception):
        check_type_path(['a', 'b'])
    with pytest.raises(Exception):
        check_type_path({'a', 'b'})

# Generated at 2022-06-20 16:29:50.238386
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {
        'state': ['type','options'],
        'type': ['options'],
        'prop': ['rbdpool','rbdname']
    }
    parameters = {
        'state': 'present',
        'options': 'blah',
        'prop': 'test'
    }
    options_context = ['prop']
    results = {
        'type': ['options'],
        'prop': ['rbdpool', 'rbdname']
    }
    assert results == check_required_by(requirements, parameters, options_context)



# Generated at 2022-06-20 16:29:52.964766
# Unit test for function check_type_bits
def test_check_type_bits():
    assert(2048 == check_type_bits("2Kb"))
    assert(1048576 == check_type_bits("1Mb"))
    assert(2097152 == check_type_bits("2Mb"))


# Generated at 2022-06-20 16:29:56.876412
# Unit test for function count_terms
def test_count_terms():
    parameters = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    assert count_terms(['a', 'b', 'd'], parameters) == 2
    assert count_terms(['b', 'c'], parameters) == 2
    assert count_terms(['a', 'd'], parameters) == 1
    assert count_terms('d', parameters) == 0
    assert count_terms(None, parameters) == 0



# Generated at 2022-06-20 16:30:08.143762
# Unit test for function check_required_by
def test_check_required_by():
    # Parameter 1, requirements is a dictionary
    requirements = {"key1": "value1",
                    "key2": "value2"}
    # Parameter 2, parameters is also a dictionary
    parameters = {"key1": "value1",
                  "key2": "value2",
                  "key3": "value3"}
    # Call the function with correct parameters
    result = check_required_by(requirements, parameters)
    assert result == {}
    # Call the function with only one key in requirements
    requirements = {"key1": "value1"}
    parameters = {"key1": "value1",
                  "key2": "value2",
                  "key3": "value3"}
    result = check_required_by(requirements, parameters)
    assert result == {}
    # Call the function with requirements as a list

# Generated at 2022-06-20 16:30:15.856999
# Unit test for function check_type_bool
def test_check_type_bool():
    assert (check_type_bool(True) == True)
    assert (check_type_bool(False) == False)
    assert (check_type_bool('false') == False)
    assert (check_type_bool('True') == True)
    assert (check_type_bool('0') == False)
    assert (check_type_bool('1') == True)
    with pytest.raises(TypeError):
        assert (check_type_bool('2') == False)
    with pytest.raises(TypeError):
        assert (check_type_bool('') == False)
    assert (check_type_bool(0) == False)
    assert (check_type_bool(1) == True)
    assert (check_type_bool(2) == True)

# Generated at 2022-06-20 16:30:33.126028
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('~/ansible/test') == os.path.expanduser('~/ansible/test')
    assert check_type_path('/home/test') == '/home/test'
    assert check_type_path('$HOME') == os.path.expandvars('$HOME')
    with pytest.raises(TypeError) as type_err:
        check_type_path(['/home/test1', '/home/test2'])
    assert str(type_err.value) == "['/home/test1', '/home/test2'] cannot be converted to a string"
    with pytest.raises(TypeError) as type_err:
        check_type_path({'test1' : '/home/test1', 'test2': '/home/test2'})

# Generated at 2022-06-20 16:30:36.117286
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('/home/user') == '/home/user'


# Generated at 2022-06-20 16:30:45.827125
# Unit test for function check_required_one_of
def test_check_required_one_of():
    '''
    There is no real use for a None object in the terms list. But check_required_one_of
    can handle it.
    '''
    assert len(check_required_one_of(None, None)) == 0
    assert len(check_required_one_of([],None)) == 0

    parameter_dict = {'option1': 'value1', 'option2': None}
    '''
    Test when term is a single list, and option1 and option2 are both required
    '''
    terms_list = [['option1','option2']]
    assert len(check_required_one_of(terms_list, parameter_dict)) == 0

    '''
    Test when term is a single list or tuple, and option1 is required
    '''
    terms_list = [['option1']]
   

# Generated at 2022-06-20 16:30:52.526043
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1MB') == 1048576
    assert check_type_bytes('1GB') == 1073741824
    assert check_type_bytes(1024) == 1024
    try:
        check_type_bytes('1KB')
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-20 16:31:03.952811
# Unit test for function check_required_arguments
def test_check_required_arguments():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils._text import to_native
    from ansible.module_utils.common.validation import check_required_arguments
    from ansible.module_utils.common.validation import check_type_spec
    from ansible.module_utils.common.validation import validate_argument_spec
    from ansible.module_utils.parsing.convert_bool import boolean

    argument_spec = check_type_spec({
        'foo': {'required': True},
        'bar': {'required': False},
    })

    try:
        check_required_arguments(argument_spec, dict())
    except TypeError as exc:
        assert to_native(exc) == "missing required arguments: foo"
    else:
        assert False

# Generated at 2022-06-20 16:31:11.474703
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # test failure
    parameters = dict(foo='bar')
    required_parameters = ['foo', 'bar']
    try:
        check_missing_parameters(parameters, required_parameters)
    except TypeError as e:
        assert to_native(e) == 'missing required arguments: bar'
    # test success
    parameters = dict(foo='bar', zoo='foo')
    required_parameters = ['foo', 'zoo']
    assert check_missing_parameters(parameters, required_parameters) == []


# Generated at 2022-06-20 16:31:13.914894
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [["a","b"], ["a","b", "c"],"d"]
    parameters = {"a": 1}
    check_required_one_of(terms, parameters)


# Generated at 2022-06-20 16:31:20.831670
# Unit test for function check_required_one_of
def test_check_required_one_of():
    parameters = dict(
        b=1,
        c=2,
        d=3,
        e=4,
        f=5
    )
    terms = [('b', 'c'), ('d', 'e', 'f')]
    assert check_required_one_of(terms, parameters) == []

    parameters = dict(
        b=1,
        c=2,
        d=3,
        e=4,
        f=5
    )
    terms = [('a', 'b', 'c'), ('d', 'e', 'f')]
    assert check_required_one_of(terms, parameters) == []

    parameters = dict(
        b=1,
        c=2,
        d=3,
        e=4,
        f=5
    )

# Generated at 2022-06-20 16:31:30.106618
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {
        'hello': 'world',
        'a': 'b',
        'c': 'd'
    }
    requirements = {
        'a': 'b',
        'c': [ 'hello' ],
        'd': 'e'
    }
    options_context = ['greeting', 'object']
    a,b,c = check_required_by(requirements, parameters, options_context)

# Generated at 2022-06-20 16:31:31.802071
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('~/test') == '/home/test_user/test'



# Generated at 2022-06-20 16:31:44.919349
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    arguments = dict(
        params=dict(required=True, type='dict'),
        workspace=dict(required=True)
    )
    parameters = dict(
        params={},
        workspace=dict(
            database=dict(
                db_name='db_name',
                host_name='host_name',
                host_port='host_port',
                login_name='login_name',
                login_password='login_password',
                schema_name='schema_name'
            ),
            file_name='file_name'
        )
    )
    missing_params = check_missing_parameters(parameters, arguments.keys())
    print(missing_params)

# Generated at 2022-06-20 16:31:47.831174
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("k1=v1,k2=v2") == {'k1': 'v1', 'k2': 'v2'}



# Generated at 2022-06-20 16:31:59.067602
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('key1=value1,key2=value2') == {'key1': 'value1', 'key2': 'value2'}
    assert check_type_dict('key1=value1, key2=value2') == {'key1': 'value1', 'key2': 'value2'}
    assert check_type_dict('key1="value1", key2=value2') == {'key1': 'value1', 'key2': 'value2'}
    assert check_type_dict('key1="value1", key2="value2"') == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-20 16:32:03.399246
# Unit test for function check_required_if
def test_check_required_if():
    parameters = {'key': 'present'}
    requirements = [['key', 'present', ['requirements'],]]
    options_context = ['options_context']
    try:
        result = check_required_if(requirements, parameters, options_context)
    except TypeError as ve:
        result = ve.args[0]
    expected_result = ("key is present but all of the following are missing: requirements found in options_context")
    assert result == expected_result


# Generated at 2022-06-20 16:32:08.916476
# Unit test for function check_type_str
def test_check_type_str():

    assert check_type_str('test') == 'test'
    assert check_type_str(u'test') == u'test'
    assert check_type_str(b'test',allow_conversion=False) == b'test'

    with pytest.raises(TypeError):
        check_type_str(1)

    assert check_type_str(1,allow_conversion=True)=='1'
    assert check_type_str(b'test',allow_conversion=True)=='test'


# Generated at 2022-06-20 16:32:18.310803
# Unit test for function check_type_list
def test_check_type_list():
    list_value = [1,2,3]
    string_value = "1,2,3"
    int_value = 1
    float_value = 1.11
    bad_value = "hello"

    assert check_type_list(list_value) == list_value
    assert check_type_list(string_value) == list_value
    assert check_type_list(int_value) == ['1']
    assert check_type_list(float_value) == ['1.11']

    with pytest.raises(TypeError):
        check_type_list(bad_value)



# Generated at 2022-06-20 16:32:24.551708
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(['foo', 'bar']) == ['foo', 'bar']
    assert check_type_list('foo,bar') == ['foo', 'bar']
    assert check_type_list(123) == ['123']
    try:
        check_type_list(None)
        assert False
    except TypeError:
        assert True
    try:
        check_type_list({})
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-20 16:32:34.153257
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    from ansible.module_utils.basic import AnsibleModule
    def test_func(arg1=None, arg2=None, arg3=None):
        params = dict(arg1=arg1, arg2=arg2, arg3=arg3)
        check_missing_parameters(params, ['arg2'])

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    try:
        test_func(arg1="one")
    except TypeError as e:
        assert "missing required arguments: arg2" in e.message
    else:
        assert False, "Should have raised"



# Generated at 2022-06-20 16:32:42.013503
# Unit test for function count_terms
def test_count_terms():
    # Test a list of keys
    parameters = [
        'a',
        'b',
        'c',
        'd',
    ]

    terms = ['a', 'b', 'c']

    assert count_terms(terms, parameters) == 3

    # Test a string of keys
    parameters = [
        'a',
        'b',
        'c',
        'd',
    ]

    terms = 'b'

    assert count_terms(terms, parameters) == 1


# Generated at 2022-06-20 16:32:48.747897
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(['list','value']) == ['list','value']
    assert check_type_list(['list']) == ['list']
    assert check_type_list('list,value') == ['list','value']
    assert check_type_list('list') == ['list']
    assert check_type_list(123) == ['123']
    assert check_type_list(123.1) == ['123.1']


# Generated at 2022-06-20 16:33:01.736637
# Unit test for function check_required_by
def test_check_required_by():
    # single string value
    requirements = {'key': 'value'}
    parameters = {'key': 'value', 'value': 'test'}
    result = check_required_by(requirements, parameters)
    assert result == {}
    parameters = {'key': 'value'}
    with pytest.raises(TypeError):
        check_required_by(requirements, parameters)

    # list of string values
    requirements = {'key': ['value1', 'value2']}
    parameters = {'key': 'value1', 'value1': 'test', 'value2': 'test'}
    result = check_required_by(requirements, parameters)
    assert result == {}
    parameters = {'key': 'value1', 'value1': 'test'}

# Generated at 2022-06-20 16:33:10.508954
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Validate that a module correctly has it's required parameters
    data = {
        'name': 'foo',
        'val': 'bar',
        'state': 'present'
    }
    argument_spec = {
        'name': {'required': True, 'type': 'str'},
        'val': {'required': True, 'type': 'str'},
        'state': {'required': True, 'type': 'str'},
        'address': {'required': False, 'type': 'str'}
    }
    assert check_required_arguments(argument_spec, data) == []
    # Fail if module is missing required arguments
    data = {
        'name': 'foo',
        'state': 'present'
    }
    assert check_required_arguments(argument_spec, data)

# Generated at 2022-06-20 16:33:18.343009
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True)
    assert check_type_bool(False)
    assert check_type_bool('1')
    assert check_type_bool('true')
    assert check_type_bool('on')
    assert check_type_bool('yes')
    assert check_type_bool('y')
    assert check_type_bool('t')
    assert check_type_bool(1)
    assert not check_type_bool('0')
    assert not check_type_bool('false')
    assert not check_type_bool('off')
    assert not check_type_bool('no')
    assert not check_type_bool('n')
    assert not check_type_bool('f')
    assert not check_type_bool(0)



# Generated at 2022-06-20 16:33:23.280959
# Unit test for function check_type_float
def test_check_type_float():
    float1 = 5.00
    float2 = 5
    float3 = "5"
    float4 = "5.00"
    float5 = b"5.00"
    float6 = "7"
    float7 = "7.00"
    float8 = b"7.00"
    
    assert check_type_float(float1) == 5.00
    assert check_type_float(float2) == 5.00
    assert check_type_float(float3) == 5.0
    assert check_type_float(float4) == 5.0
    assert check_type_float(float5) == 5.0
    assert check_type_float(float6) == 7.0
    assert check_type_float(float7) == 7.0
    assert check_type_float(float8) == 7

# Generated at 2022-06-20 16:33:30.121105
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(['a', 'b', 'c'], {'a': 1, 'b': 2, 'c': 3}) == 3
    assert count_terms('a', {'a': 1, 'b': 2, 'c': 3}) == 1
    assert count_terms('d', {'a': 1, 'b': 2, 'c': 3}) == 0
    assert count_terms('d', {}) == 0



# Generated at 2022-06-20 16:33:40.670810
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    # Basic list test
    test_list = ["test_string", 1, True]
    json_test_list = check_type_jsonarg(test_list)
    assert isinstance(json_test_list, text_type)
    assert json_test_list == '[\n  "test_string",\n  1,\n  true\n]'
    # List test with whitespace
    test_list = ["test_string", 1, True]
    json_test_list = check_type_jsonarg(test_list)
    assert isinstance(json_test_list, text_type)
    assert json_test_list == '[\n  "test_string",\n  1,\n  true\n]'
    # Basic dict test

# Generated at 2022-06-20 16:33:52.092259
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True) is True
    assert check_type_bool(False) is False
    assert check_type_bool('true') is True
    assert check_type_bool('false') is False
    assert check_type_bool('yes') is True
    assert check_type_bool('no') is False
    assert check_type_bool('y') is True
    assert check_type_bool('n') is False
    assert check_type_bool('t') is True
    assert check_type_bool('f') is False
    assert check_type_bool('1') is True
    assert check_type_bool('0') is False
    assert check_type_bool(1) is True
    assert check_type_bool(0) is False
    assert check_type_bool('on') is True
    assert check_

# Generated at 2022-06-20 16:33:58.654467
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    required_parameters = ['a','b','c','d']
    test_dict = {"a":1,"b":0}
    missing_params = check_missing_parameters(test_dict, required_parameters)
    assert missing_params == ['c','d']
    return



# Generated at 2022-06-20 16:34:08.873352
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # Test that a single missing parameter is caught
    params = {'first' : 'present', 'second': 'present'}
    required = ['first', 'second', 'third']
    with pytest.raises(TypeError) as exc:
        check_missing_parameters(params, required)
    assert 'third' in str(exc.value)

    # Test that multiple missing parameters are caught
    params = {'first' : 'present', 'second': 'present'}
    required = ['first', 'third', 'fourth']
    with pytest.raises(TypeError) as exc:
        check_missing_parameters(params, required)
    assert 'third, fourth' in str(exc.value)

    # Test that no missing parameters are not caught
    params = {'first' : 'present', 'second': 'present'}


# Generated at 2022-06-20 16:34:20.195052
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True) is True
    assert check_type_bool(False) is False
    assert check_type_bool(1) is True
    assert check_type_bool(0) is False
    assert check_type_bool('True') is True
    assert check_type_bool('False') is False
    assert check_type_bool('true') is True
    assert check_type_bool('false') is False
    assert check_type_bool('yes') is True
    assert check_type_bool('no') is False
    assert check_type_bool('y') is True
    assert check_type_bool('n') is False
    assert check_type_bool('t') is True
    assert check_type_bool('f') is False
    assert check_type_bool('on') is True
    assert check_

# Generated at 2022-06-20 16:34:36.382048
# Unit test for function check_required_if

# Generated at 2022-06-20 16:34:44.069630
# Unit test for function check_type_str
def test_check_type_str():
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    try:
        import __main__
        main = __main__
    except ImportError:
        main = {}

    # Initialize an instance of this module with minimal arguments
    module = AnsibleModule(
        argument_spec = {},
    )
    # Set module args
    module.params = {}
    # Connect to the module
    conn = Connection(module._socket_path)
    # Set the connection in the main module where the AnsibleModule is looking
    # for it. This is only needed for testing, in actual use the connection
    # would already be set in __main__ by the action plugin or other code that
    # is calling the module.
    main.ansible_connection = conn
    #

# Generated at 2022-06-20 16:34:45.907579
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0



# Generated at 2022-06-20 16:34:50.349864
# Unit test for function check_type_str
def test_check_type_str():
    assert isinstance(check_type_str('test'), six.string_types)
    assert check_type_str(1, allow_conversion=False) == 1
    assert check_type_str(1) == '1'
    assert check_type_str(1, allow_conversion=False, param='_param', prefix='foo') == 1
    assert check_type_str(1, param='_param', prefix='foo') == '1'


# Generated at 2022-06-20 16:34:51.595030
# Unit test for function check_type_float
def test_check_type_float():
    with pytest.raises(TypeError) as error:
        check_type_float('11')
    assert "cannot be converted to a float" in str(error.value)



# Generated at 2022-06-20 16:34:58.985619
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True)
    assert check_type_bool('true')
    assert check_type_bool(1)
    assert not check_type_bool(False)
    assert not check_type_bool('false')
    assert not check_type_bool(0)

    try:
        check_type_bool(1.0)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-20 16:35:02.347707
# Unit test for function check_type_raw
def test_check_type_raw():
    value = 'raw'
    raw = check_type_raw(value)
    assert raw == 'raw', "raw is expected but got {}".format(raw)


# Generated at 2022-06-20 16:35:04.179740
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw("raw") == "raw"
    assert check_type_raw(1) == 1



# Generated at 2022-06-20 16:35:13.556692
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg("[1,2,3]") == '[1,2,3]'
    assert check_type_jsonarg("{'a':1}") == '{"a":1}'
    assert check_type_jsonarg(['a', 'b', 'c']) == '["a", "b", "c"]'
    assert check_type_jsonarg({'a': 'b', 'c': 'd'}) == '{"a": "b", "c": "d"}'
    assert check_type_jsonarg("") == ''
    assert check_type_jsonarg(None) == 'null'
    try:
        check_type_jsonarg(1)
        assert False, "this should not have happened"
    except TypeError:
        pass



# Generated at 2022-06-20 16:35:16.063619
# Unit test for function check_type_float
def test_check_type_float():
    check_type_float(3.14)
    #check_type_float('3.14')
    check_type_float(3)
    #check_type_float(b'3.14')



# Generated at 2022-06-20 16:35:33.216252
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # test case for converting bytes, kB and MB.
    assert check_type_bytes(100) == 100
    assert check_type_bytes(1024) == 1024
    assert check_type_bytes(1024*1024) == 1024 * 1024

    # test case for converting kB to bytes
    assert check_type_bytes('1kB') == 1000
    assert check_type_bytes('1kB') == 1000
    assert check_type_bytes('1KB') == 1000

    # test case for converting MB to bytes
    assert check_type_bytes('1MB') == 1024 * 1024
    assert check_type_bytes('1MiB') == 1024 * 1024
    assert check_type_bytes('1m') == 1024 * 1024

    # test case for converting negative number
    assert check_type_bytes(-1) == -1

    # test case for converting bytes

# Generated at 2022-06-20 16:35:40.538568
# Unit test for function check_required_together
def test_check_required_together():
    parms = {'paramA': 'value', 'paramB': 'value'}
    terms = [['paramA', 'paramB'], ['paramC', 'paramD']]
    assert (check_required_together(terms, parms) == [])
    parms = {'paramA': 'value', 'paramB': 'value'}
    terms = [['paramA', 'paramC'], ['paramB', 'paramD']]
    assert (check_required_together(terms, parms) == [['paramA', 'paramC']])

