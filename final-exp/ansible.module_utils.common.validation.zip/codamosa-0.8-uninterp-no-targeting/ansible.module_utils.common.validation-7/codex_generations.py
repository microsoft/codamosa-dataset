

# Generated at 2022-06-20 16:26:18.442314
# Unit test for function check_required_one_of
def test_check_required_one_of():
    parameters = {'a': 1, 'b': 2, 'c': 4, 'e': 5}
    terms = [['a', 'b'], ['c']]
    results = check_required_one_of(terms, parameters)
    assert not results



# Generated at 2022-06-20 16:26:20.421232
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-20 16:26:28.624441
# Unit test for function count_terms
def test_count_terms():
    assert 1 == count_terms('a', dict(a=1, b=2))
    assert 0 == count_terms('a', dict(b=2, c=3))
    assert 0 == count_terms('a', dict())
    assert 2 == count_terms(['a', 'b'], dict(a=1, b=2))
    assert 1 == count_terms(['a', 'b'], dict(b=2, c=3))
    assert 0 == count_terms(['a', 'b'], dict(c=3, d=4))
# END OF count_terms UNIT TESTS



# Generated at 2022-06-20 16:26:34.258041
# Unit test for function check_type_path
def test_check_type_path():
    check_type_path('abc')
    check_type_path(u'abc')
    check_type_path(b'abc')
    check_type_path(123)
    check_type_path(1.0)
    check_type_path([1,2,3])
    check_type_path({'a':1})



# Generated at 2022-06-20 16:26:43.903086
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param', 'path'), True]
    ]
    parameters = {
        'state': 'present',
        'someint': 99,
        'bool_param': True
    }
    options_context = ''
    results = check_required_if(requirements, parameters, options_context)
    assert len(results) == 1
    result = results[0]
    assert result['parameter'] == 'someint'
    assert result['value'] == 99
    assert result['requirements'] == ('bool_param', 'string_param', 'path')
    assert result['missing'] == ['string_param', 'path']
    assert result['requires'] == 'any'



# Generated at 2022-06-20 16:26:55.231190
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by(None, {}) == {}
    assert check_required_by({}, {'param1': 'test1'}) == {}
    assert check_required_by({'param1': {'param2', 'param3'}}, {'param1': 'test1', 'param2': 'test2'}) == {}
    assert check_required_by({'param1': {'param2', 'param3'}}, {'param1': 'test1'}) == {}
    assert check_required_by({'param1': {'param2', 'param3'}}, {'param1': 'test1', 'param2': 'test2', 'param3': None}) == {}

# Generated at 2022-06-20 16:26:59.071411
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    try:
        check_missing_parameters(parameters={}, required_parameters=['test'])
    except TypeError as e:
        assert 'missing' in str(e)
    else:
        assert False, 'missed required parameter "test"'



# Generated at 2022-06-20 16:27:03.437421
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('value') == 'value'
    assert check_type_raw(['value', 'another']) == ['value', 'another']
    assert check_type_raw(True) is True



# Generated at 2022-06-20 16:27:13.674173
# Unit test for function check_required_together
def test_check_required_together():
    assert [] == check_required_together([['one', 'two']], {'one': True, 'two': True})
    assert [] == check_required_together([['one', 'two', 'three']], {'one': True, 'three': True})
    assert [] == check_required_together([['one', 'two', 'three']], {'two': True})
    assert [] == check_required_together([['one', 'two'], ['one', 'three'], ['one', 'four'], ['three', 'four']],
                                         {'one': True, 'four': True})

    try:
        check_required_together([['one', 'two']], {'one': True})
        assert False
    except TypeError:
        pass

# Generated at 2022-06-20 16:27:21.041868
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1000') == 1000
    #assert check_type_bits('10000000') == 10000000
    assert check_type_bits('1Mb') == 1048576 #Mb = 1024 * 1024 = 1048576
    assert check_type_bits('1mb') == 1048576

    try:
        check_type_bits('1a')
        assert False
    except TypeError:
        assert True

# unit test for function check_type_bytes

# Generated at 2022-06-20 16:27:36.656271
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list("") == ['']
    assert check_type_list("1,2,3,4") == ['1', '2', '3', '4']
    assert check_type_list(1) == ['1']
    assert check_type_list(["one", "two"]) == ['one', 'two']
    try:
        check_type_list("one,two,three,four") == ['one', 'two', 'three', 'four']
    except TypeError:
        pass
    else:
        raise Exception("Should raise TypeError")


# FIXME: The param and prefix parameters here are coming from AnsibleModule._check_type_path()
#        which is using those for the warning messaged based on string conversion warning settings.
#        Not sure how to deal with that here since we don't have config state

# Generated at 2022-06-20 16:27:46.744742
# Unit test for function check_type_bits
def test_check_type_bits():
    assert(check_type_bits('1Mb') == 1048576)
    assert(check_type_bits('1 Mb') == 1048576)
    assert(check_type_bits('1M') == 1000000)
    assert(check_type_bits('1mb') == 1048576)
    assert(check_type_bits('1mbit') == 1048576)
    assert(check_type_bits('1m') == 1048576)
    assert(check_type_bits('1mib') == 1048576)
    assert(check_type_bits('1mibit') == 1048576)
    assert(check_type_bits('1048576') == 1048576)
    assert(check_type_bits('1048576b') == 1048576)

# Generated at 2022-06-20 16:27:58.397910
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(1) == True
    assert check_type_bool(0) == False
    assert check_type_bool('on') == True
    assert check_type_bool('1') == True
    assert check_type_bool('off') == False
    assert check_type_bool('0') == False
    assert check_type_bool('y') == True
    assert check_type_bool('n') == False
    assert check_type_bool('true') == True
    assert check_type_bool('false') == False
    assert check_type_bool('yes') == True
    assert check_type_bool('no') == False
    assert check_type_bool(True) == True
    assert check_type_bool(False) == False

# Generated at 2022-06-20 16:28:08.096384
# Unit test for function check_required_one_of
def test_check_required_one_of():
    spec = {'type': 'dict',
            'options': {
                'foobar': {'type': 'str', 'required': True},
                'spam': {'type': 'str', 'required': True},
                'eggs': {'type': 'str', 'required': True}
                }
            }
    param_hash = {'foobar': 'foo', 'spam': 'spam'}
    try:
        check_required_one_of([['foobar', 'spam'], ['eggs']], param_hash)
        raise AssertionError('check_required_one_of should have failed')
    except TypeError as e:
        assert to_native(e).find('one of the following is required') != -1



# Generated at 2022-06-20 16:28:20.068225
# Unit test for function safe_eval
def test_safe_eval():
    # literal_eval accepts
    assert safe_eval("True") is True
    assert safe_eval("10") == 10
    assert safe_eval("10.5") == 10.5
    assert safe_eval("'hello world'") == 'hello world'
    assert safe_eval('"hello world"') == 'hello world'
    assert safe_eval("(1, 2, 'a')") == (1, 2, 'a')
    assert safe_eval("[1, 2, 'a']") == [1, 2, 'a']
    assert safe_eval("{1, 2, 'a'}") == {1, 2, 'a'}
    assert safe_eval("{1: 2, 3: 'a'}") == {1: 2, 3: 'a'}
    # literal_eval rejects

# Generated at 2022-06-20 16:28:28.321419
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('a', dict(a=1, b=2, c=3)) == 1
    assert count_terms(['a', 'c'], dict(a=1, b=2, c=3)) == 2
    assert count_terms('z', dict(a=1, b=2, c=3)) == 0
    assert count_terms(['a', 'c', 'z'], dict(a=1, b=2, c=3)) == 2


# Generated at 2022-06-20 16:28:33.880970
# Unit test for function check_type_str
def test_check_type_str():
    """
    Check that default behavior is to convert and return string.
    """
    val = 'test string'
    converted = check_type_str(val)
    assert isinstance(converted, string_types)
    assert val == converted
    """
    Check that explicit conversion to string works.
    """
    val = b'test string'
    converted = check_type_str(val, True)
    assert isinstance(converted, string_types)
    assert val == converted
    """
    Check that explicit no conversion returns TypeError.
    """
    val = b'test string'
    try:
        check_type_str(val, False)
    except TypeError:
        assert True
        return
    assert False


# FIXME: The param and prefix parameters here are coming from AnsibleModule._check_type_string()

# Generated at 2022-06-20 16:28:41.395856
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True)
    assert check_type_bool('on')
    assert check_type_bool(1)
    assert check_type_bool('1')
    assert check_type_bool('yes')
    assert check_type_bool('y')
    assert check_type_bool('t')
    assert check_type_bool('true')
    assert not check_type_bool(False)
    assert not check_type_bool('off')
    assert not check_type_bool(0)
    assert not check_type_bool('0')
    assert not check_type_bool('no')
    assert not check_type_bool('n')
    assert not check_type_bool('f')
    assert not check_type_bool('false')



# Generated at 2022-06-20 16:28:44.773857
# Unit test for function check_type_path
def test_check_type_path():
    # test with a string
    value = "test"
    assert check_type_path(value) == value
    # test with a bytes
    value = b"test"
    assert check_type_path(value) == value.decode()


# Generated at 2022-06-20 16:28:49.405066
# Unit test for function check_type_int
def test_check_type_int():
    assert isinstance(check_type_int("3"), int), "Conversion of string to int"
    assert isinstance(check_type_int(5), int), "Conversion of int to int"
    # assert isinstance(check_type_int("a"), TypeError), "Non-convertable string to int"
    # assert isinstance(check_type_int(3.3), TypeError), "Non-convertable float to int"



# Generated at 2022-06-20 16:29:03.367958
# Unit test for function check_required_if
def test_check_required_if():
    from ansible.module_utils.basic import AnsibleModule
    # Check that if one requirement is met and one is not, the requirement is met (is_one_of = True)
    requirements = [
            ['state', 'present', ('path', 'dest'), True],
        ]
    module = AnsibleModule({'state': 'present', 'path': '/tmp/file'}, check_invalid_arguments=False)
    check_required_if(requirements, module.params)

    # Check that if one requirement is met and one is not, the requirement is not met (is_one_of = False)
    requirements = [
            ['state', 'present', ('path', 'dest'), False],
        ]

# Generated at 2022-06-20 16:29:13.122264
# Unit test for function check_required_if
def test_check_required_if():
    from ansible.module_utils.six import PY3

# Generated at 2022-06-20 16:29:15.055403
# Unit test for function check_type_raw
def test_check_type_raw():
    """Test check_type_raw function"""
    assert check_type_raw(dict()) == dict()



# Generated at 2022-06-20 16:29:19.914161
# Unit test for function check_type_str
def test_check_type_str():

    # Test with str
    test_str = 'test_str'
    result = check_type_str(test_str, allow_conversion=True)
    assert result == test_str
    result = check_type_str(test_str, allow_conversion=False)
    assert result == test_str

    # Test with unicode
    test_unicode = u'test_unicode'
    result = check_type_str(test_unicode, allow_conversion=True)
    assert result == test_unicode
    result = check_type_str(test_unicode, allow_conversion=False)
    assert result == test_unicode

    # Test with bytearray
    test_bytearray = bytearray(b'test_bytearray')

# Generated at 2022-06-20 16:29:28.625686
# Unit test for function check_required_if
def test_check_required_if():
    try:
        requirements = [['state', 'present', ('path',), True], ['someint', 99, ('bool_param', 'string_param')]]
        parameters = {'state': 'present', 'path': '/var/something'}
        check_required_if(requirements, parameters)
        requirements = [['state', 'present', ('path',)], ['someint', 99, ('bool_param', 'string_param')]]
        parameters = {'state': 'present', 'path': '/var/something'}
        try:
            check_required_if(requirements, parameters)
            assert False, "Fails to throw exception for missing param"
        except TypeError as e:
            assert True, "Fails to throw exception for missing param"
    except Exception as e:
        assert False, "Fails to validate missing param"



# Generated at 2022-06-20 16:29:34.993285
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = [['name', 'first'], ['name', 'last']]
    parameters = {'name': 'ansible', 'state': 'present'}
    with pytest.raises(TypeError) as excinfo:
        check_mutually_exclusive(terms, parameters)
    assert 'parameters are mutually exclusive: name|first, name|last' in to_native(excinfo)



# Generated at 2022-06-20 16:29:42.779117
# Unit test for function check_required_arguments
def test_check_required_arguments():
    #test case: one required argument not present in parameters
    argspec = dict(my_argument = dict(required = True),
                   my_other_argument = dict(required = False))
    parameters = dict(my_other_argument = True)
    missing = check_required_arguments(argspec, parameters)
    assert(missing[0] == 'my_argument')

    #test case: two required arguments not present in parameters
    argspec2 = dict(my_argument = dict(required = True),
                    my_other_argument = dict(required = True),
                    my_third_argument = dict(required = False))
    parameters2 = dict(my_third_argument = True)
    missing2 = check_required_arguments(argspec2, parameters2)
    assert(missing2[0] == 'my_argument')

# Generated at 2022-06-20 16:29:52.153612
# Unit test for function check_required_if
def test_check_required_if():
    assert check_required_if([['state', 'present', ('path',)]], {'state': 'present', 'path': '/var/tmp'}) == []
    assert check_required_if([['state', 'present', ('path',)]], {'state': 'present'}) == [{'missing': ['path'], 'requires': 'all', 'parameter': 'state', 'value': 'present', 'requirements': ('path',)}]
    assert check_required_if([['state', 'present', ('path',)]], {'state': 'changed'}) == []
    assert check_required_if([['state', 'present', ('path', 'pattern')]], {'state': 'present', 'path': '/var/tmp', 'pattern': '.*'}) == []

# Generated at 2022-06-20 16:29:57.098614
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'ip':  {'required': False, 'type': 'str'},
        'netmask':  {'required': False, 'type': 'str'},
        'network': {'required': True, 'type': 'str'}
    }
    parameters = {}
    options_context = None
    assert check_required_arguments(argument_spec, parameters, options_context) == ['network']



# Generated at 2022-06-20 16:30:08.394946
# Unit test for function check_required_if
def test_check_required_if():
        missing = {'missing': [], 'requires': 'all', 'parameter': 'someint', 'value': 99, 'requirements': ('bool_param', 'string_param')}
        missing1 = {'missing': [], 'requires': 'all', 'parameter': 'someint', 'value': 99, 'requirements': ('bool_param', 'string_param')}
        results = [missing,missing1]
        assert results == check_required_if([
                                                ['someint',99,('bool_param','string_param')]
                                            ], {
                                                'someint': 99
                                            })
        results = [missing]

# Generated at 2022-06-20 16:30:19.940034
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """ Tests for function check_mutually_exclusive."""
    source = {'module': 'net_system',
              'state': 'present',
              'name': 'ansible'}

    # Test exclude_none_parameters when the arguments are not mutually exclusive.
    check_mutually_exclusive(terms=['src', 'dest'], parameters=source)

    # Test exclude_none_parameters when the arguments are mutually exclusive.
    try:
        check_mutually_exclusive(terms=['src', 'dest'], parameters=source)
    except TypeError:
        pass



# Generated at 2022-06-20 16:30:31.975890
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    params = {'first': 'ok', 'second': 'ok', 'third': 'ok'}
    spec = {'spec': ['first', ['second', 'third']]}
    exc = {'spec': ['first', 'second', 'third']}
    assert check_mutually_exclusive(exc['spec'], params) == []
    assert check_mutually_exclusive(spec['spec'], params) == []
    assert check_mutually_exclusive([['first', 'second', 'third']], params) == []

    exc['spec'][0] = 'fourth'
    assert check_mutually_exclusive(exc['spec'], params) == []
    assert check_mutually_exclusive(spec['spec'], params) == []

# Generated at 2022-06-20 16:30:44.467216
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 'foo', 'b': 'bar'}
    try:
        check_mutually_exclusive(terms, parameters)
    except:
        raise Exception('check_mutually_exclusive test 1 failed!')

    parameters = {'a': 'foo', 'b': 'bar', 'e': 'bar'}
    try:
        check_mutually_exclusive(terms, parameters)
    except:
        raise Exception('check_mutually_exclusive test 2 failed!')

    terms = [['a', 'b']]
    check_mutually_exclusive(terms, parameters)

    parameters = {'a': 'foo', 'b': 'bar'}

# Generated at 2022-06-20 16:30:54.871702
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('') == 0
    assert check_type_bytes('1024') == 1024
    assert check_type_bytes('10KB') == 10240
    assert check_type_bytes('10MB') == 10485760
    assert check_type_bytes('10GB') == 10737418240
    assert check_type_bytes('10TB') == 10995116277760
    assert check_type_bytes('10PB') == 11258999068426240
    assert check_type_bytes('10EB') == 11529215046068469760
    assert check_type_bytes('1024') == check_type_bytes('1KB')



# Generated at 2022-06-20 16:31:05.253722
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('first line', ['first line', 'second line']) == 1
    assert count_terms(['first line'], ['first line', 'second line']) == 1
    assert count_terms(['first line', 'second line'], ['first line', 'second line']) == 2
    assert count_terms(['first line', 'second line', 'undocumented employee'], ['first line', 'second line']) == 2
    assert count_terms(['first line', 'second line', 'undocumented employee'], ['first line', 'second line', 'undocumented employee']) == 3
    assert count_terms(['first line', 'second line'], ['first line', 'second line', 'undocumented employee']) == 2



# Generated at 2022-06-20 16:31:06.434396
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('one', {'one': 'two', 'three': 'four'}) == 1



# Generated at 2022-06-20 16:31:12.739409
# Unit test for function safe_eval
def test_safe_eval():
    # Test literal_eval for different data types
    assert safe_eval("[0,1,2]") == [0, 1, 2]
    assert safe_eval("'string'") == 'string'
    assert safe_eval("['a', 'b', 'c']") == ['a', 'b', 'c']
    assert safe_eval("{'a':'b', 'c':'d'}") == {'a': 'b', 'c': 'd'}
    assert safe_eval("{'a': 'b', 'c': 'd'}") == {'a': 'b', 'c': 'd'}
    assert safe_eval("['a', 'b', 'c']") == ['a', 'b', 'c']

# Generated at 2022-06-20 16:31:16.960552
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("a=b,c=d") == {'a': 'b', 'c': 'd'}, 'a=b,c=d -> a=b, c=d'
    assert check_type_dict("a='b,b',c=o\'d,d") == {'a': 'b,b', 'c': 'o\'d,d'}, 'a=\'b,b\',c=o\'d,d -> a=b,b, c=o\'d,d'
    assert check_type_dict("a={'b': 'c'}") == {'a': {'b': 'c'}}, 'a=\'b,b\',c=o\'d,d -> a=b,b, c=o\'d,d'

# Generated at 2022-06-20 16:31:27.886107
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [["a", "b"], ["c", "d"]]
    parameters = {}
    assert check_required_one_of(terms, parameters) == [["a", "b"], ["c", "d"]]
    parameters = {"a": 123}
    assert check_required_one_of(terms, parameters) == [["c", "d"]]
    parameters = {"b": 123}
    assert check_required_one_of(terms, parameters) == [["c", "d"]]
    parameters = {"a": 123, "b": 123}
    assert check_required_one_of(terms, parameters) == [["c", "d"]]
    parameters = {"x": 123}
    assert check_required_one_of(terms, parameters) == [["a", "b"], ["c", "d"]]

# Generated at 2022-06-20 16:31:37.195674
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('nothing special') == 'nothing special'
    assert safe_eval('1+1') == 2
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"a": "b"}') == {"a": "b"}
    assert safe_eval('{"a": ["b",{"c":"d" }]}') == {"a": ["b",{"c":"d" }]}
    assert safe_eval('[1,2,3]', include_exceptions=True) == ([1,2,3], None)
    assert safe_eval('[1,2,3,]', include_exceptions=True) == ('[1,2,3,]', None)

# Generated at 2022-06-20 16:31:43.091431
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('my_file') == 'my_file'
    assert check_type_path('$HOME/my_file') == os.path.expanduser('$HOME/my_file')


# Generated at 2022-06-20 16:31:49.874316
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Check response with missing parameter
    assert ['name'] == check_required_arguments({'name': {'required': True}, 'age': {'required': False}},
                                                {'age': '39'})
    # Check response with no missing parameters
    assert [] == check_required_arguments({'name': {'required': True}, 'age': {'required': False}},
                                          {'name': 'Arun', 'age': '39'})
    # Check response with no required parameters
    assert [] == check_required_arguments({'name': {'required': False}, 'age': {'required': False}},
                                          {'name': 'Arun', 'age': '39'})
    # Check response with no required parameters

# Generated at 2022-06-20 16:31:59.683323
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test "terms" as single list
    params = {
        'client_cert': 'test',
        'client_key': 'test',
    }

    try:
        check_mutually_exclusive(['client_cert', 'client_key'], params)
    except TypeError:
        pass
    else:
        fail("Expected TypeError")

    # Test "terms" as list of lists
    params = {
        'key1': 'test',
        'key2': 'test',
    }

    try:
        check_mutually_exclusive([['key1', 'key2']], params)
    except TypeError:
        pass
    else:
        fail("Expected TypeError")



# Generated at 2022-06-20 16:32:00.738515
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
# End unit test for function check_type_bits



# Generated at 2022-06-20 16:32:05.040732
# Unit test for function check_type_path
def test_check_type_path():
    import os

    current_path = os.path.join(os.getcwd(), 'test/test_utils_basic')
    assert check_type_path(current_path) == current_path
    assert check_type_path(b'test/test_utils_basic') == current_path
    assert check_type_path(u'test/test_utils_basic') == current_path
    assert check_type_path('test/test_utils_basic') == current_path
    assert check_type_path('~/test/test_utils_basic') == os.path.expanduser('~/test/test_utils_basic')
    assert check_type_path('$HOME/test/test_utils_basic') == os.path.expandvars('$HOME/test/test_utils_basic')
    assert check_type

# Generated at 2022-06-20 16:32:16.249866
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('1')
    assert check_type_bool(1)
    assert not check_type_bool('0')
    assert not check_type_bool(0)
    assert not check_type_bool('n')
    assert not check_type_bool('f')
    assert not check_type_bool('false')
    assert check_type_bool('true')
    assert check_type_bool('y')
    assert check_type_bool('yes')
    assert check_type_bool('t')
    assert not check_type_bool('no')
    assert not check_type_bool('off')
    assert check_type_bool(True)
    assert not check_type_bool(False)
    assert not check_type_bool(None)
    assert check_type_bool(True)

# Generated at 2022-06-20 16:32:26.226020
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    def assert_mutually_exclusive(parameters, specs, expected_exc_msg, *options_context):
        try:
            check_mutually_exclusive(specs, parameters, options_context)
            raise AssertionError("Expected exception, but got none")
        except TypeError as e:
            if str(e) != expected_exc_msg:
                raise AssertionError("Expected exception message: %s, but got: %s" % (expected_exc_msg, str(e)))

    assert_mutually_exclusive(
        {'a': 1, 'b': 2},
        [['a', 'b']],
        "parameters are mutually exclusive: a|b"
    )


# Generated at 2022-06-20 16:32:30.508593
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(20) == 20
    assert check_type_int("20") == 20
    assert check_type_int(True) == 1
    assert check_type_int(False) == 0
    assert check_type_int(None) == 0


# Generated at 2022-06-20 16:32:42.107923
# Unit test for function check_type_bytes
def test_check_type_bytes():
    import tests.unit

    def test_accepted_values():
        assert check_type_bytes('1 KiB') == 1024
        assert check_type_bytes('1MiB') == 1048576
        assert check_type_bytes('1GiB') == 1073741824
        assert check_type_bytes('1 TiB') == 1099511627776
        assert check_type_bytes('1PiB') == 1125899906842624
        assert check_type_bytes('1EiB') == 1152921504606846976
        assert check_type_bytes('1K') == 1000
        assert check_type_bytes('1M') == 1000000
        assert check_type_bytes('1G') == 1000000000
        assert check_type_bytes('1T') == 1000000000000

# Generated at 2022-06-20 16:32:53.026203
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(0.1) == 0.1
    assert isinstance(check_type_float(0.1), float)
    assert check_type_float(b'0.1') == 0.1
    assert check_type_float(u'0.1') == 0.1
    assert check_type_float(1) == 1.0
    assert isinstance(check_type_float(1), float)
    assert check_type_float(1.1) == 1.1
    assert isinstance(check_type_float(1.1), float)
    with pytest.raises(TypeError):
        assert check_type_float(['0.1'])
    with pytest.raises(TypeError):
        assert check_type_float({'0.1'})

# Generated at 2022-06-20 16:33:02.696384
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments({"a": {"required": True}, "b": {"required": False}}, {"a": "A"}) == []
    try:
        check_required_arguments({"a": {"required": True}, "b": {"required": False}}, {"c": "C"})
    except TypeError as e:
        assert str(e) == "missing required arguments: a"


# Generated at 2022-06-20 16:33:05.803278
# Unit test for function check_type_dict
def test_check_type_dict():
    # Test case : empty string
    try:
        check_type_dict("")
    except TypeError:
        assert True
    else:
        assert False

    # Test case : string that can not be converted to dictionary
    try:
        check_type_dict("'A=B'")
    except TypeError:
        assert True
    else:
        assert False

    # Test case: string with key-value pairs, string to be converted to dictionary
    assert check_type_dict("A=B,C=D") == {'A': 'B', 'C': 'D'}

# Generated at 2022-06-20 16:33:14.908098
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval("import os")
    assert result == "import os", "safe_eval() test failed"
    result = safe_eval("os.system('ls -l')")
    assert result == "os.system('ls -l')", "safe_eval() test failed"
    result = safe_eval("random.sample(range(10), 10)")
    assert result == "random.sample(range(10), 10)", "safe_eval() test failed"
    result = safe_eval("{'abc': 10, 'def': 20, 'xyz': 30}")
    assert result == {'abc': 10, 'def': 20, 'xyz': 30}, "safe_eval() test failed"
    result = safe_eval("['a', 'b', 'c']")

# Generated at 2022-06-20 16:33:21.128198
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {'req_1': {'required': True}, 'req_2': {'required': True}, 'opt_1': {'required': False}}
    parameters = {'req_1': 1, 'req_2': 2}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == [], "Test failed, there should be no missing arguments"

    parameters = {'req_1': 1}
    try:
        missing = check_required_arguments(argument_spec, parameters)
    except TypeError as exc:
        assert 'missing required arguments: req_2' in str(exc)
    else:
        assert False, "TypeError should have been raised"



# Generated at 2022-06-20 16:33:23.314188
# Unit test for function check_type_float
def test_check_type_float():
    test_data = ["1000", "1000.0", 10.00, 1000, 10]
    for i in test_data:
        check_type_float(i)


# Generated at 2022-06-20 16:33:29.510163
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('raw') == 'raw'
    assert check_type_raw(u'unicode') == u'unicode'
    assert check_type_raw(123456789) == 123456789
    assert check_type_raw(123.45) == 123.45
    assert check_type_raw(True) is True



# Generated at 2022-06-20 16:33:39.773843
# Unit test for function check_type_int
def test_check_type_int():

    # if isinstance(value, integer_types):
    assert check_type_int(7000) == 7000
    assert check_type_int('7000') == 7000

# Generated at 2022-06-20 16:33:51.643060
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg("''") == "''"
    assert check_type_jsonarg("[1, 2]") == "[1, 2]"
    assert check_type_jsonarg("true") == "true"
    assert check_type_jsonarg(True) == "true"
    assert check_type_jsonarg("false") == "false"
    assert check_type_jsonarg(False) == "false"
    assert check_type_jsonarg("1") == "1"
    assert check_type_jsonarg(1) == "1"
    assert check_type_jsonarg("0") == "0"
    assert check_type_jsonarg(0) == "0"
    assert check_type_jsonarg("null") == "null"
    assert check_type_jsonarg(None) == "null"
   

# Generated at 2022-06-20 16:34:04.069960
# Unit test for function check_type_dict
def test_check_type_dict():
    # Test string
    assert isinstance(check_type_dict("key1=value1,key2=value2"), dict) \
        == True, 'Fail: test_check_type_dict() #1'
    assert isinstance(check_type_dict("key1=value1,key2=value2,key3="), dict) \
        == True, 'Fail: test_check_type_dict() #2'
    assert isinstance(check_type_dict("key1=value1,key2=value2,key3,key4=value4"), dict) \
        == True, 'Fail: test_check_type_dict() #3'

# Generated at 2022-06-20 16:34:11.950646
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('foo,bar') == ['foo', 'bar']
    assert check_type_list(['foo', 'bar']) == ['foo', 'bar']
    assert check_type_list(123) == ['123']
    try:
        check_type_list({'foo': 'bar'})
        assert False, "When a dict is passed the check_type_list, the function should raise an exception"
    except TypeError:
        pass


# Generated at 2022-06-20 16:34:24.487185
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by({'a': ['b', 'c']}, {'a': 'a', 'b': 'b'}) == {}
    assert check_required_by({'a': ['b', 'c']}, {'a': 1, 'b': 'b', 'c': 'c'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'a', 'b': 'b'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 1, 'b': 'b'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 1}) == {'a': ['b']}

# Generated at 2022-06-20 16:34:31.178849
# Unit test for function check_type_int
def test_check_type_int():
    class TestSource:

        def __init__(self, val):
            self.val = val

        def __oct__(self):
            return str(self.val)

        __index__ = __oct__

        def __int__(self):
            return self.val

        def __long__(self):
            return self.val

        def __index__(self):
            return self.val

    # test basic ints
    assert check_type_int(0) == 0
    assert check_type_int(1) == 1
    assert check_type_int(42) == 42
    assert check_type_int(10000) == 10000
    # test ints from other classes
    assert check_type_int(TestSource(0)) == 0
    assert check_type_int(TestSource(42)) == 42
    assert check

# Generated at 2022-06-20 16:34:32.477760
# Unit test for function check_type_path
def test_check_type_path():
    """Test the type and the return value of function check_type_path"""
    raise NotImplementedError


# Generated at 2022-06-20 16:34:33.743255
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-20 16:34:36.842320
# Unit test for function check_type_raw
def test_check_type_raw():
    """Test function check_type_raw."""
    result = check_type_raw(None)
    assert result is None

    result = check_type_raw("foo")
    assert result == "foo"

    result = check_type_raw(1)
    assert result == 1



# Generated at 2022-06-20 16:34:44.434187
# Unit test for function check_type_bytes
def test_check_type_bytes():
    if not check_type_bytes('1') == 1:
        raise Exception('Test Failed')
    if not check_type_bytes('1T') == 1099511627776:
        raise Exception('Test Failed')
    if not check_type_bytes('1t') == 1099511627776:
        raise Exception('Test Failed')
    if not check_type_bytes('1K') == 1024:
        raise Exception('Test Failed')
    if not check_type_bytes('1kb') == 1024:
        raise Exception('Test Failed')
    if not check_type_bytes('1kb') == 1024:
        raise Exception('Test Failed')
    if not check_type_bytes('1.5k') == 1536:
        raise Exception('Test Failed')
    if not check_type_bytes('1.5kb') == 1536:
        raise

# Generated at 2022-06-20 16:34:46.171203
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    value = '{"key1": "value1"}'
    assert check_type_jsonarg(value) == value

    value = ['key1', 'value1']
    assert check_type_jsonarg(value) == '["key1", "value1"]'


# Generated at 2022-06-20 16:34:50.248769
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(12) == 12
    assert check_type_float('12') == 12
    assert check_type_float(12.0) == 12.0
    assert check_type_float('12.0') == 12.0
    assert check_type_float(12.0) == 12.0
    assert check_type_float('12.0') == 12.0
    assert check_type_float('12.0') == 12.0
    assert check_type_float(to_text('12.0')) == 12.0
    assert check_type_float(to_bytes('12.0')) == 12.0
    with pytest.raises(TypeError):
        check_type_float(['12.0'])
    with pytest.raises(TypeError):
        check_type_float

# Generated at 2022-06-20 16:34:55.927282
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    import subprocess


# Generated at 2022-06-20 16:35:07.622418
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by({"a": "b"}, {"a": 1}) == {"a": []}
    assert check_required_by({"a": "b"}, {"a": 1, "b": 2}) == {"a": []}
    assert check_required_by({"a": "b"}, {"a": 1, "c": 2}) == {}
    assert check_required_by({"a": "b"}, {"a": 1, "b": None}) == {"a": []}
    assert check_required_by({"a": "b"}, {"a": None}) == {"a": ["b"]}
    assert check_required_by({"a": "b"}, {"c": None}) == {}

# Generated at 2022-06-20 16:35:18.072579
# Unit test for function safe_eval
def test_safe_eval():
    from ansible.module_utils.common.text.formatters import to_bytes

    def err(msg, x, y):
        raise AssertionError('{0}: got {1} but expected {2}'.format(msg, repr(x), repr(y)))


# Generated at 2022-06-20 16:35:30.152355
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("{ 'a' : 'b' }") == {'a': 'b'}

    value = "[i for i in range(3)]"
    assert safe_eval(value) == [0, 1, 2]

    # disallowed
    assert safe_eval("open('/tmp').readlines()") == "open('/tmp').readlines()"
    assert safe_eval("import sys") == "import sys"

    # check exceptions
    assert safe_eval("open('/tmp').readlines()", include_exceptions=True) == ("open('/tmp').readlines()", None)

# Generated at 2022-06-20 16:35:38.052143
# Unit test for function check_type_dict
def test_check_type_dict():
    print (check_type_dict("{'a'='b','c'='d','e'=1,'f'=2}"))  # {'a': 'b', 'c': 'd', 'e': 1, 'f': 2}
    print (check_type_dict("'a'='b', 'c'='d', 'e'=1, 'f'=2"))  # {'a': 'b', 'c': 'd', 'e': '1', 'f': '2'}
    print (check_type_dict("a='b', c='d', e=1, f=2"))  # {'a': 'b', 'c': 'd', 'e': '1', 'f': '2'}
    print (check_type_dict("a=b, c=d, e, f"))  # {'