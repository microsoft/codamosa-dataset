

# Generated at 2022-06-20 16:26:15.199483
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('a')=='a'
    assert check_type_raw(['a','b'])==['a','b']
    assert check_type_raw(True) is True
    assert check_type_raw(False) is False
    assert check_type_raw(1)==1
    assert check_type_raw(1.0)==1.0
    assert check_type_raw(None) is None


# Generated at 2022-06-20 16:26:21.384759
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(1024) == 1024
    assert check_type_bytes(1024.0) == 1024.0
    assert check_type_bytes('1024') == 1024
    assert check_type_bytes('1024K') == 1024 * 1024
    assert check_type_bytes('1024M') == 1024 * 1024 * 1024
    assert check_type_bytes('1024G') == 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1024T') == 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1024P') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1024Ki') == 1024 * 1024
    assert check_type_bytes('1024KiB') == 1024 * 1024
    assert check_type_bytes('1024Mi') == 1024 * 1024 * 1024 * 1024
   

# Generated at 2022-06-20 16:26:32.280637
# Unit test for function check_type_list
def test_check_type_list():
    # value is a list, no conversion happens
    list_val = [1, 2, 3]
    assert check_type_list(list_val) == [1, 2, 3]
    # value is a string, split on comma
    str_val = "1,2,3"
    assert check_type_list(str_val) == [1, 2, 3]
    # value is a number, return as single item list
    num_val = 12
    assert check_type_list(num_val) == [12]
    # value is an integer
    int_val = 12
    assert check_type_list(int_val) == [12]
    # value is NoneType, conversion is not allowed
    assert check_type_list(None) == [None]
    # value is a boolean, conversion is not allowed

# Generated at 2022-06-20 16:26:37.585317
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1') == 1
    assert check_type_bytes(1) == 1
    # FIXME: use py.test's raises here instead of raw try/except https://github.com/ansible/ansible/issues/26438
    try:
        check_type_bytes('1y')
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-20 16:26:40.722559
# Unit test for function check_type_dict
def test_check_type_dict():
    assert {} == check_type_dict({})
    assert {'a': 'b'} == check_type_dict('a=b')
    assert {'a': 'b'} == check_type_dict('"a"="b"')



# Generated at 2022-06-20 16:26:46.400924
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():

    terms = [
        ['param1', 'param2'],
        ['param3', 'param4'],
    ]
    parameters = {
        'param1': 'val1',
        'param3': 'val3',
    }

    check_mutually_exclusive(terms, parameters)



# Generated at 2022-06-20 16:26:53.616207
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    with pytest.raises(TypeError) as excinfo:
        check_type_bytes('10x')
    assert 'cannot be converted to a Byte value' in str(excinfo.value)


# Generated at 2022-06-20 16:27:03.437650
# Unit test for function check_type_str
def test_check_type_str():
    # Test string values
    assert isinstance(check_type_str('abc', True), string_types)
    assert isinstance(check_type_str('abc', False), string_types)
    assert isinstance(check_type_str(u'abc', True), string_types)
    assert isinstance(check_type_str(u'abc', False), string_types)
    assert isinstance(check_type_str(b'abc', True), string_types)
    assert isinstance(check_type_str(b'abc', False), string_types)

    # Test conversion values
    assert isinstance(check_type_str(123, True), string_types)
    assert isinstance(check_type_str(123, False), string_types)

# Generated at 2022-06-20 16:27:06.003857
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {
        'name': 'Test',
        'path': '/foo/bar'
    }
    requirements = {
        'path': 'name'
    }

# Generated at 2022-06-20 16:27:15.302067
# Unit test for function safe_eval
def test_safe_eval():
    """
    This is an unit test for the safe_eval function in module_utils.basic.py

    The purpose of this test is to identify bugs in the safe_eval function that
    could break modules.

    The test is performed by checking if the safe_eval function will return the
    expected value or not.
    """

    # Declaration of variables used in the unit test
    function_return_values = []
    function_exceptions = []
    # This is the list of elements to test the safe_eval function with

# Generated at 2022-06-20 16:27:32.624294
# Unit test for function safe_eval
def test_safe_eval():

    def func():
        pass

    func.__name__ = 'func1'

    test_data = [
        # test_string, expected, exception
        ('func()', 'func()', None),
        ('func2()', 'func2()', None),
        ('func1', func, None),
        ('import func2', 'import func2', None),
        ('func1()', 'func1()', None),
        ('func1', func, None),
        ('{"test key": {"test key2": "test value"}}', {'test key': {'test key2': 'test value'}}, None),
        ('[1, 2]', [1, 2], None),
    ]

# Generated at 2022-06-20 16:27:42.962055
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Normal cases
    for h in('1M', '1k', '1G', '5MB', '5K', '5GB', '5',
             '1KiB', '1mib', '1gib', '2mib', '2MiB', '2Mi', '2Ki', '1ki', '1Ki'):
        assert isinstance(human_to_bytes(h), int)
        assert human_to_bytes(h) == human_to_bytes(h.lower())

    # Abnormal cases
    for h in('foo', '123 foo', '123.123M', '123.123 MiB'):
        with pytest.raises(TypeError):
            check_type_bytes(h)



# Generated at 2022-06-20 16:27:48.549679
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together(None, {}) == []
    assert check_required_together([], {}) == []
    assert check_required_together([(['a', 'b']), (['c'])], {'a': True}) == [(['c'])]
    assert check_required_together([(['a', 'b']), (['c'])], {'a': True}, ['foo']) == [(['c'])]
    # The following should not raise a TypeError...
    check_required_together([(['a', 'b']), (['c'])], {'a': True, 'b': True})
    check_required_together([(['a', 'b']), (['c'])], {'a': True, 'b': True, 'c': True})

# Generated at 2022-06-20 16:27:53.619065
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str(None) == None
    assert check_type_str(1) == "1"
    assert check_type_str(True) == "True"

    try:
        check_type_str(1, allow_conversion=False)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-20 16:27:56.561181
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int("1") == 1
    with pytest.raises(TypeError):
        check_type_int(None)
    with pytest.raises(TypeError):
        check_type_int(['a','b'])
    with pytest.raises(TypeError):
        check_type_int(1.2)
    with pytest.raises(TypeError):
        check_type_int("1.2")



# Generated at 2022-06-20 16:28:06.850879
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """
    Function for unit testing check_mutually_exclusive(terms, parameters)
    Returns nothing
    """
    # Return value when terms is None
    terms = None
    parameters = []
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pytest.fail("check_mutually_exclusive with None as first argument raised a TypeError")

    # Return value when all elements of the list are present in parameters
    terms = [['a', 'b', 'c'], ['a', 'd', 'e']]
    parameters = ['a', 'b', 'c', 'd', 'e']
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pytest.fail("check_mutually_exclusive with parameters present in the list raised a TypeError")

   

# Generated at 2022-06-20 16:28:11.037757
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    from ansible.module_utils.common._collections_compat import Mapping
    parameters = {'a': '1', 'b': '2'}
    result = check_missing_parameters(parameters, required_parameters=['a'])
    assert isinstance(result, list)
    assert len(result) == 0

    result = check_missing_parameters(parameters, required_parameters=['a', 'b'])
    assert isinstance(result, list)
    assert len(result) == 0

    with pytest.raises(TypeError):
        check_missing_parameters(parameters, required_parameters=['c'])

    with pytest.raises(TypeError):
        check_missing_parameters(parameters, required_parameters=['c', 'a', 'b'])


# Generated at 2022-06-20 16:28:14.592177
# Unit test for function check_type_path
def test_check_type_path():
    assert isinstance(check_type_path('/bin/sh'), string_types)
# End unit test section


# Generated at 2022-06-20 16:28:17.225951
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576

# FIXME: Not sure if this is a public api or not?

# Generated at 2022-06-20 16:28:25.663842
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    params = {'foo': 1, 'bar': 2}
    assert check_mutually_exclusive([['foo', 'bar']], params) == []
    assert check_mutually_exclusive([['baz']], params) == []
    try:
        check_mutually_exclusive([['foo', 'bar'], ['foo', 'qux']], params)
        assert False, "two mutually exclusive terms where not detected"
    except TypeError:
        assert True
    try:
        check_mutually_exclusive([['foo', 'bar'], ['baz', 'qux']], params)
        assert False, "mutually exclusive terms where detected when none existed"
    except TypeError:
        assert True

# Generated at 2022-06-20 16:28:35.808848
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg(False) == 'false'
    assert check_type_jsonarg(1.1) == '1.1'
    assert check_type_jsonarg(1) == '1'
    assert check_type_jsonarg('string') == '"string"'
    assert check_type_jsonarg([1, 2, 3]) == '[1, 2, 3]'
    assert check_type_jsonarg({'a':1, 'b':2}) == '{"a": 1, "b": 2}'



# Generated at 2022-06-20 16:28:43.719676
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('') == u''
    assert check_type_str(b'bytes') == u'bytes'
    assert check_type_str(b'bytes', allow_conversion=False)
    assert_raises(TypeError, check_type_str, b'bytes', allow_conversion=True)
    assert_raises(TypeError, check_type_str, 1234)
    assert_raises(TypeError, check_type_str, 1234, allow_conversion=True)


# Generated at 2022-06-20 16:28:55.051459
# Unit test for function check_mutually_exclusive

# Generated at 2022-06-20 16:29:05.047330
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float("1") == 1.0
    assert check_type_float("1.0") == 1.0
    assert check_type_float(True) == 1.0
    assert check_type_float(False) == 0.0
    assert check_type_float(u"1.0") == 1.0
    assert check_type_float(b"1.0") == 1.0
    assert check_type_float(b"1") == 1.0

    try:
        check_type_float("a")
    except TypeError as e:
        assert "cannot be converted to a float" == to_native(e)



# Generated at 2022-06-20 16:29:10.645820
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1tb') == 1099511627776
    assert check_type_bits('1TB') == 1099511627776
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('1.20Mb') == 126976
    assert check_type_bits('10Gb') == 10737418240
    assert check_type_bits('5g') == 5000000000
    assert check_type_bits('1.5G') == 1500000000
    assert check_type_bits('1gbit') == 1073741824

# Generated at 2022-06-20 16:29:22.457757
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('1') is True
    assert check_type_bool('on') is True
    assert check_type_bool('0') is False
    assert check_type_bool('off') is False
    assert check_type_bool(1) is True
    assert check_type_bool(0) is False
    assert check_type_bool(True) is True
    assert check_type_bool(False) is False
    assert check_type_bool('n') is False
    assert check_type_bool('f') is False
    assert check_type_bool('false') is False
    assert check_type_bool('true') is True
    assert check_type_bool('y') is True
    assert check_type_bool('t') is True
    assert check_type_bool('yes') is True
    assert check_

# Generated at 2022-06-20 16:29:32.877791
# Unit test for function check_type_list
def test_check_type_list():
    # check_type_list should return a list
    #with assertRaises(TypeError) :
    #    check_type_list(3)

    # check_type_list should return a list
    #with assertRaises(TypeError) :
    #    check_type_list(3.5)

    # check_type_list should split a comma-separated string (without spaces)
    assert check_type_list('foo,bar') == ['foo', 'bar']

    # check_type_list should return an int as a list
    assert check_type_list(3) == ['3']

    # check_type_list should return an float as a list
    assert check_type_list(3.5) == ['3.5']

    # check_type_list should return a list when given a list
    assert check_type

# Generated at 2022-06-20 16:29:41.535611
# Unit test for function check_required_arguments
def test_check_required_arguments():
    parameters = {}
    argument_spec = {}
    argument_spec['required1'] = {'required': True, 'type': 'str'}
    argument_spec['required2'] = {'required': True, 'type': 'str'}
    argument_spec['required3'] = {'required': True, 'type': 'str'}
    argument_spec['optional1'] = {'required': False, 'type': 'str'}
    argument_spec['optional2'] = {'required': False, 'type': 'str'}
    argument_spec['optional3'] = {'required': False, 'type': 'str', 'default': 'default'}

    result = check_required_arguments(argument_spec, parameters)
    assert sorted(result) == ['required1', 'required2', 'required3']
    parameters['required1']

# Generated at 2022-06-20 16:29:46.841437
# Unit test for function check_type_str
def test_check_type_str():
    # Test ansible.module_utils.basic.check_type_str
    assert check_type_str('hello') == 'hello'
    assert check_type_str(u'hello') == u'hello'
    assert check_type_str('hello', allow_conversion=False) == 'hello'
    assert check_type_str(u'hello', allow_conversion=False) == u'hello'
    assert check_type_str(None, allow_conversion=False) == u'None'
    assert check_type_str(3) == u'3'
    assert check_type_str(1, allow_conversion=False) == u'1'
    assert check_type_str([1, 2], allow_conversion=False) == u'[1, 2]'

# Generated at 2022-06-20 16:29:53.890567
# Unit test for function check_type_bytes
def test_check_type_bytes():
    try:
        from unittest import mock
    except ImportError:
        from unittest.mock import mock
    with mock.patch('ansible.module_utils.common.human_to_bytes',) as m:
        m.side_effect = (1, 2, 3)
        assert check_type_bytes(None) == 1
        assert check_type_bytes(None) == 2
        assert check_type_bytes(None) == 3
        m.assert_any_call(None)
        m.assert_any_call(None)
        m.assert_any_call(None)



# Generated at 2022-06-20 16:30:09.467423
# Unit test for function check_type_dict
def test_check_type_dict():
    import os
    import tempfile

# Generated at 2022-06-20 16:30:16.816382
# Unit test for function check_required_if
def test_check_required_if():
    parms = dict(a=2, b=1, c=3)
    reqs = ['a', 'b', 'c']
    assert check_required_if([['a', 2, reqs]], parms) == []

    parms = dict(a=2, c=3)
    try:
        check_required_if([['a', 2, reqs]], parms)
        assert False
    except TypeError as e:
        assert e.results[0] == {'parameter': 'a', 'value': 2, 'requirements': reqs, 'missing': ['b'], 'requires': 'all'}


# Generated at 2022-06-20 16:30:23.489879
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [('state', 'present', ('path',), True), ('someint', 99, ('bool_param', 'string_param'))]
    parameters = dict(state='present', path='/var/logs')
    assert check_required_if(requirements, parameters) == []
    requirements = [('state', 'present', ('path',), True), ('someint', 99, ('bool_param', 'string_param'))]
    parameters = dict(state='present', path='/var/logs', bool_param='false')
    assert check_required_if(requirements, parameters) == []
    requirements = [('state', 'present', ('path',), True), ('someint', 99, ('bool_param', 'string_param'))]

# Generated at 2022-06-20 16:30:34.098823
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Here are the argument_specs that we will pass in to the function
    argument_spec = {
        "arg1": {
            "type": "string",
            "required": True
            },
        "arg2": {
            "type": "string"
            }
        }
    # Test case 1:
    # Here we will pass an empty dictionary as the parameters, and we expect to
    # get an exception telling us that arg1 is missing.
    params = {}
    try:
        check_required_arguments(argument_spec, params, options_context=[])
    except TypeError as e:
        assert to_native(e) == u"missing required arguments: arg1"
    else:
        assert False, "Expected exception was not raised"

    # Test case 2:
    # Here we will pass a dictionary that contains

# Generated at 2022-06-20 16:30:35.237404
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    with pytest.raises(TypeError):
        check_type_bits('1M')

# Generated at 2022-06-20 16:30:41.154798
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {'param1': {'required': True}, 'param2': {}}
    parameters = {'param2': 'test'}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == ['param1']
    parameters = {'param1': 'test'}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []



# Generated at 2022-06-20 16:30:45.190986
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1MB') == 1048576
    assert check_type_bytes('1kB') == 1024
    assert check_type_bytes('1KB') == 1024
    assert check_type_bytes('1GB') == 1073741824
    assert check_type_bytes('1TB') == 1099511627776
    assert check_type_bytes('-1TB') == -1099511627776
    assert check_type_bytes(-1) == -1
    with pytest.raises(TypeError):
        check_type_bytes('-1TBx')
    with pytest.raises(TypeError):
        check_type_bytes(1)


# Generated at 2022-06-20 16:30:50.517016
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('.') == os.path.expanduser(os.path.expandvars('.'))
    with pytest.raises(TypeError, match="cannot be converted to a string"):
        check_type_path(1)


# Generated at 2022-06-20 16:30:58.845467
# Unit test for function check_required_together
def test_check_required_together():
    # create a parameter dictionary
    params = dict(instance_state="absent")
    # create a list of lists of parameter names
    terms = [('instance_name', 'host_name'), ('instance_state', 'host_name')]

    # function check_required_together succeeds with list of parameters
    result = check_required_together(terms, params)
    assert result == []

    # function check_required_together fails with list of parameters
    params = dict(instance_state="absent")
    terms = [('instance_name', 'host_name'), ('instance_state', 'instance_name')]
    with pytest.raises(TypeError) as excinfo:
        result = check_required_together(terms, params)
        assert 'parameters are required together: instance_name, instance_state' in str(excinfo.value)

# Generated at 2022-06-20 16:31:01.936754
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    # Test that it returns the value if it is a string
    result = check_type_jsonarg('test')
    assert result == 'test'

    # Test that it jsonifies the value it is a dict/list
    result = check_type_jsonarg({'test': 1})
    assert result == '{\n    "test": 1\n}'

    # Test that it raises a TypeError in case of invalid data
    with pytest.raises(TypeError):
        check_type_jsonarg(2)



# Generated at 2022-06-20 16:31:09.821134
# Unit test for function check_type_bits
def test_check_type_bits():
    type_bits = check_type_bits('1Mb')
    assert type_bits == 1048576


# Generated at 2022-06-20 16:31:11.187132
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(1) == 1



# Generated at 2022-06-20 16:31:19.179505
# Unit test for function check_required_if
def test_check_required_if():
    # Create a sample requirements and parameters
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters1 = {'state': 'present', 'path': '/usr/local/bin'}
    parameters2 = {'state': 'absent', 'someint': 99, 'bool_param': True}
    parameters3 = {'state': 'absent', 'someint': 99}
    parameters4 = {'state': 'absent', 'someint': 99, 'bool_param': True, 'string_param': 'hello'}
    parameters5 = {'state': 'absent', 'someint': 99, 'bool_param': True, 'string_param': 'hello', 'path':'/usr/local/'}

    #

# Generated at 2022-06-20 16:31:23.997300
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1') == 1
    assert check_type_int('1.0') == 1

    try:
        check_type_int(1.1)
        assert False
    except TypeError:
        pass

    try:
        check_type_int('1.1')
        assert False
    except TypeError:
        pass

    try:
        check_type_int('a')
        assert False
    except TypeError:
        pass

    try:
        check_type_int({})
        assert False
    except TypeError:
        pass



# Generated at 2022-06-20 16:31:34.593311
# Unit test for function check_required_if
def test_check_required_if():

    # missing all when all needs to be present
    all_missing = [['bool_param', True, ('string_param',)]]
    check_required_if(all_missing, {'bool_param': True})

    # Test all required
    all_present = [['bool_param', True, ('string_param', 'int_param')]]
    check_required_if(all_present, {'bool_param': True, 'string_param': 'foo', 'int_param': 1})

    # Test all required, missing one
    all_present_missing_one = [['bool_param', True, ('string_param', 'int_param')]]

# Generated at 2022-06-20 16:31:41.426594
# Unit test for function check_required_arguments
def test_check_required_arguments():
    missing = []
    # Test no required arguments
    argument_spec = {}
    parameters = {}
    try:
        missing = check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert False, "No exception should be raised"
    assert not missing

    # Test 1 required argument, missing
    argument_spec = {'require_one': {'required': True}}
    parameters = {}
    try:
        missing = check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert "[{'require_one': {'required': True}}]" in to_native(e)
    assert missing == ['require_one']

    # Test 1 required argument, present
    argument_spec = {'require_one': {'required': True}}

# Generated at 2022-06-20 16:31:46.936523
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    '''
    Unit test for function check_missing_parameters
    '''
    parameters = {
        'required_param': True,
        'not_required_param': False
    }
    required_params = ['required_param']
    assert check_missing_parameters(parameters, required_params) == []

    required_params = ['required_param', 'another_required_param']
    assert check_missing_parameters(parameters, required_params) == ['another_required_param']


# Generated at 2022-06-20 16:31:55.598530
# Unit test for function check_type_list
def test_check_type_list():
    # Unit case for string
    assert check_type_list('a,b,c') == ['a', 'b', 'c']

    # Unit case for int
    assert check_type_list(1) == ['1']

    # Unit case for float
    assert check_type_list(1.1) == ['1.1']

    # Unit case for list
    assert check_type_list(['a', 'b']) == ['a', 'b']

    # Unit case for other type
    with pytest.raises(TypeError):
        check_type_list(object)



# Generated at 2022-06-20 16:32:02.477302
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('1 == 1') is True
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo', {}, include_exceptions=True) == ('foo', None)
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("{'a': 1, 'b': 2}", {}, include_exceptions=True) == ("{'a': 1, 'b': 2}", None)
    # do not allow method calls to modules

# Generated at 2022-06-20 16:32:10.419366
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(0) == False
    assert check_type_bool(1) == True
    assert check_type_bool(2) == True
    assert check_type_bool('1') == True
    assert check_type_bool('0') == False
    assert check_type_bool('True') == True
    assert check_type_bool('TRUE') == True
    assert check_type_bool('true') == True
    assert check_type_bool('False') == False
    assert check_type_bool('FALSE') == False
    assert check_type_bool('false') == False
    assert check_type_bool('yes') == True
    assert check_type_bool('no') == False
    assert check_type_bool('y') == True
    assert check_type_bool('n') == False

# Generated at 2022-06-20 16:32:25.230842
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1", include_exceptions=True) == (1, None)
    assert safe_eval("'1'", include_exceptions=True) == ("1", None)
    assert safe_eval("1+1", include_exceptions=True) == (2, None)
    assert safe_eval("'1'+'1'", include_exceptions=True) == ("11", None)
    assert safe_eval("'0x123'") == "0x123"
    assert safe_eval("'0x123'", include_exceptions=True) == ("0x123", None)
    assert safe_eval("0x123", include_exceptions=True) == (291, None)
    assert safe_eval("0o123", include_exceptions=True) == (83, None)

# Generated at 2022-06-20 16:32:36.008461
# Unit test for function check_required_arguments
def test_check_required_arguments():
    from collections import namedtuple
    ArgumentSpec = namedtuple('ArgumentSpec', ['required'], verbose=False)
    assert len(check_required_arguments({}, {})) == 0, "no required arguments"

    assert 'foobar' in check_required_arguments(
        {'foobar': ArgumentSpec(required=True)}, {}),\
        "single required argument is missing"

    assert len(check_required_arguments(
        {'foobar': ArgumentSpec(required=False)}, {})) == 0,\
        "single optional argument is missing"

    assert len(check_required_arguments(
        {'foobar': ArgumentSpec(required=False)}, {'foobar': 'baz'})) == 0,\
        "single optional argument is present"


# Generated at 2022-06-20 16:32:39.678764
# Unit test for function check_type_path
def test_check_type_path():
    data = 'test1'
    result = check_type_path(data)
    assert result == os.path.expanduser(os.path.expandvars(data))


# Generated at 2022-06-20 16:32:43.711832
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    m_params = {'foo': 'bar'}
    r_params = ('foo', 'baz')
    # No exception raised
    check_missing_parameters(m_params, r_params)
    # Exception raised
    r_params = ('foo', 'baz', 'new')
    with pytest.raises(TypeError) as exc:
        check_missing_parameters(m_params, r_params)
    assert 'new' in str(exc)



# Generated at 2022-06-20 16:32:52.460668
# Unit test for function check_required_one_of
def test_check_required_one_of():
    #case 1: when terms is not specified
    parameters={'a': 1, 'b': 2, 'c': 3}
    error_msg="parameters are mutually exclusive: a|b, c|e"
    check_required_one_of(None, parameters)

    #case 2: when at least any terms are satisfied
    terms=[[1,2], [2,3]]
    count_terms=2
    check_required_one_of(terms, parameters)

    #case 3: when no terms are satisfied
    terms=[[4], [3]]
    count_terms=1
    error_msg="one of the following is required: 4, 3"
    result=check_required_one_of(terms, parameters)
    assert result == error_msg



# Generated at 2022-06-20 16:32:56.956710
# Unit test for function safe_eval
def test_safe_eval():
    assert literal_eval('["foo", "bar"]') == safe_eval('["foo", "bar"]')
    assert literal_eval('[1,2,3]') == safe_eval('[1,2,3]')



# Generated at 2022-06-20 16:33:05.992821
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('file.txt') == os.path.expanduser(os.path.expandvars('file.txt'))
    assert check_type_path('/file.txt') == os.path.expanduser(os.path.expandvars('/file.txt'))
    assert check_type_path('$PATH/file.txt') == os.path.expanduser(os.path.expandvars('$PATH/file.txt'))
    assert check_type_path('~/file.txt') == os.path.expanduser(os.path.expandvars('~/file.txt'))



# Generated at 2022-06-20 16:33:07.284165
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(5) == 5



# Generated at 2022-06-20 16:33:10.324414
# Unit test for function check_type_bool
def test_check_type_bool():
    test_data = [('True', True), ('false', False), ('foo', False), ('1', True), ('0', False)]
    for input_val, output_val in test_data:
        assert check_type_bool(input_val) == output_val



# Generated at 2022-06-20 16:33:15.281465
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('one,two,three') == ['one', 'two', 'three']
    assert check_type_list(['one', 'two', 'three']) == ['one', 'two', 'three']
    assert check_type_list(10) == ['10']



# Generated at 2022-06-20 16:33:34.032116
# Unit test for function check_type_dict
def test_check_type_dict():
    # The check_type_dict function maintains the same behaviour as a pre-existing
    # function it replaces. This is a test to ensure the replacement function
    # provides the same result as the original.

    # Tests that the function accepts a dict
    value = {'test': 'dict'}
    assert check_type_dict(value) == value

    # Tests that the function accepts a string that parseable as dict
    value = '{"test": "dict"}'
    assert check_type_dict(value) == {u'test': u'dict'}

    # Tests that the function accepts a string that parseable as dict
    value = 'test=dict'
    assert check_type_dict(value) == {'test': 'dict'}

    # Tests that the function raises a TypeError when passed a string that is not parseable as dict

# Generated at 2022-06-20 16:33:42.174068
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    """Test function check_type_jsonarg"""
    TESTS = (
        '["a","b"]',
        {'a': 'a', 'b': 'b'},
        ['a', 'b'],
        ['a', {'c': 'd', 'e': 'f'}],
    )

    for t in TESTS:
        jsonified = check_type_jsonarg(t)
        assert isinstance(jsonified, string_types)
        result, exc = safe_eval(jsonified, dict(), include_exceptions=True)
        assert exc is None



# Generated at 2022-06-20 16:33:47.337320
# Unit test for function check_type_bytes
def test_check_type_bytes():
    sample_string = '1.5MB'
    assert check_type_bytes(sample_string) == 1572864, "Failed to Convert human-readable string to bytes"
    assert isinstance(check_type_bytes(sample_string), int), "Failed to Convert human-readable string to bytes"



# Generated at 2022-06-20 16:33:50.190833
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1M') == 8388608


# Generated at 2022-06-20 16:33:51.556049
# Unit test for function check_type_path
def test_check_type_path():
    assert "." == check_type_path(".")

# Generated at 2022-06-20 16:34:03.978933
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("a=1,b=2") == {'a': '1', 'b': '2'}
    assert check_type_dict("a='1',b='2'") == {'a': '1', 'b': '2'}
    assert check_type_dict("a='1', b='2'") == {'a': '1', 'b': '2'}
    assert check_type_dict("a=\"1\", b=\"2\"") == {'a': '1', 'b': '2'}
    assert check_type_dict("{a:'1',b:'2'}") == {u'a': u'1', u'b': u'2'}

# Generated at 2022-06-20 16:34:15.772564
# Unit test for function check_type_bool
def test_check_type_bool():
    test_data = [True, 'True', 'true', 'TRUE', '1', 1, 'on', 'ON', 'yeS', 'YeS', 'n', 'no', 'N', 'NO', False, 'False', 'false', 'FALSE', '0', 0, 'off', 'OFF', 'nO', 'No']
    for v in test_data:
        assert check_type_bool(v) is True
    for v in test_data:
        assert check_type_bool(v) is True
    test_data_false = ['2', 2, 'foo']
    for v in test_data_false:
        try:
            check_type_bool(v)
        except Exception as e:
            assert type(e) is TypeError
            assert str(e) == '%s cannot be converted to a bool'

# Generated at 2022-06-20 16:34:21.410066
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"key": "value"}') == dict(key='value')
    assert check_type_dict('a=b,c=d') == dict(a='b', c='d')
    assert check_type_dict('{a=b,c=d}') == dict(a='b', c='d')
    assert check_type_dict(dict(a=b,c=d)) == dict(a='b', c='d')



# Generated at 2022-06-20 16:34:32.746488
# Unit test for function safe_eval
def test_safe_eval():
    test_truthy_boolstring_to_python = ['true', 'TRUE', 't', '1', 'yes', 'y']
    test_falsy_boolstring_to_python = ['false', 'FALSE', 'f', '0', 'no', 'n']

    for test_boolstring in test_truthy_boolstring_to_python:
        assert(safe_eval(test_boolstring) == True)

    for test_boolstring in test_falsy_boolstring_to_python:
        assert(safe_eval(test_boolstring) == False)

    test_truthy_bool_to_ansible = [True, 'true', 'True', 'True', 'TRUE', 'TRUE',  '1', 'YES', 'yes', 'Yes', 'Y', 'y']
    test_falsy

# Generated at 2022-06-20 16:34:41.037891
# Unit test for function check_required_by
def test_check_required_by():
    try:
        check_required_by({'a': ['b']}, {})
    except Exception as e:
        if not isinstance(e, TypeError):
            raise
    try:
        check_required_by({'a': ['b']}, {'c': None})
    except Exception as e:
        if not isinstance(e, TypeError):
            raise
    try:
        check_required_by({'a': 'b'}, {})
    except Exception as e:
        if not isinstance(e, TypeError):
            raise
    try:
        check_required_by({'a': 'b'}, {'c': None})
    except Exception as e:
        if not isinstance(e, TypeError):
            raise

# Generated at 2022-06-20 16:34:54.923451
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters_value = dict()
    parameters_value['argument'] = 'value'
    parameters_value['argument_2'] = 'value_2'
    required_parameters_value = ['argument', 'argument_2', 'argument_3']
    returned_value = check_missing_parameters(parameters_value, required_parameters_value)
    expected_value = ['argument_3']
    assert returned_value == expected_value



# Generated at 2022-06-20 16:34:58.884660
# Unit test for function check_required_together
def test_check_required_together():
    terms = [[['foo', 'bar']]]
    parameters = dict(foo='foo')
    options_context = ['ansible']
    result = check_required_together(terms, parameters, options_context)
    assert not result


# Generated at 2022-06-20 16:35:07.351351
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    test_data = [
        None, [], [1], [1,2,3], [1,'test',3],
        {'test': True}, {'test': True, 'ansible_test': False},
        {1: True, 2: True}, {'test':{1:True}, 2:True},
    ]
    params = {}
    result = check_missing_parameters(params, test_data)
    assert result == []
    params['test'] = True
    result = check_missing_parameters(params, test_data)
    assert result == []



# Generated at 2022-06-20 16:35:15.879792
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"k1": "v1"}') == {"k1": "v1"}
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('1+2') == 3
    assert safe_eval('-3') == -3
    assert safe_eval('2.0') == 2.0
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval('None') == None
    assert safe_eval("'tuple'") == 'tuple'
    assert safe_eval("'list'") == 'list'
    assert safe_eval("'dict'") == 'dict'

# Generated at 2022-06-20 16:35:22.282348
# Unit test for function check_type_str
def test_check_type_str():
    # This is an example of calling check_type_str
    assert check_type_str(5) == '5'

# FIXME: The param and prefix parameters here are coming from AnsibleModule._check_type_bytes()
#        which is using those for the warning messaged based on string conversion warning settings.
#        Not sure how to deal with that here since we don't have config state to query.

# Generated at 2022-06-20 16:35:27.770690
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert(check_type_bytes('1 b') == 1)
    assert(check_type_bytes('1 g') == 1073741824)
    assert(check_type_bytes('1kb') == 1024)
    assert(check_type_bytes('1kb') == 1024)
    assert(check_type_bytes('1KB') == 1024)
    assert(check_type_bytes('1MB') == 1048576)
    assert(check_type_bytes('1Mb') == 1048576)
    assert(check_type_bytes('1GB') == 1073741824)
    assert(check_type_bytes('1Gb') == 1073741824)
    assert(check_type_bytes('1Tb') == 1099511627776)
    assert(check_type_bytes('1TB') == 1099511627776)


# Generated at 2022-06-20 16:35:29.002250
# Unit test for function count_terms
def test_count_terms():
    terms = ('one', 'two', 'three')
    parameters = {'one': True, 'two': False, 'three': True}
    assert count_terms(terms, parameters) == 2



# Generated at 2022-06-20 16:35:34.871468
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    tstr = 'test'
    tlist = ['test']
    assert check_mutually_exclusive([[tstr], [tstr]], {}) == []
    assert check_mutually_exclusive([[tstr], [tlist]], {}) == []
    assert check_mutually_exclusive([[tstr], [tstr]], {'test': None}) == [['test']]
    assert check_mutually_exclusive([[tstr], [tlist]], {'test': None}) == [['test']]



# Generated at 2022-06-20 16:35:45.009245
# Unit test for function check_required_by
def test_check_required_by():
    ''' Test for function check_required_by.
    Test for a simple case, where both parameters exist.
    Test for the case where parameter y does not exist
    '''
    requirements = {'x': 'y'}
    parameters = {'x': 'y'}
    result = check_required_by(requirements, parameters)
    assert(result == {})

    parameters = {'x': 'y', 'y': None}
    result = check_required_by(requirements, parameters)
    assert(result == {})

    parameters = {'x': 'y'}
    try:
        result = check_required_by(requirements, parameters)
    except TypeError as e:
        err = "missing parameter(s) required by 'x': y"
        assert(err == str(e))
