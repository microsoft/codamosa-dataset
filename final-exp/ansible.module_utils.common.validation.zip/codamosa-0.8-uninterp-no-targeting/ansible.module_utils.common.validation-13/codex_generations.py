

# Generated at 2022-06-20 16:26:19.784962
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(terms=None) == []
    assert check_mutually_exclusive(terms=['a', 'b'], parameters={'a': 1}) == []
    assert check_mutually_exclusive(terms=['a', 'b'], parameters={'a': 1, 'b': 2}) != []
    assert check_mutually_exclusive(terms=[['a', 'b'], ['c', 'd']], parameters={'a': 1, 'b': 2, 'c': 3}) != []
# End unit test



# Generated at 2022-06-20 16:26:30.792823
# Unit test for function check_required_if
def test_check_required_if():
    """ Unit tests for check_required_if """
    assert check_required_if([('a', 'a', 'b'), ('b', 'b', 'c')], {'a': 'a', 'b': 'b', 'd': 'd'}) == []
    assert check_required_if([('a', 'a', 'b'), ('b', 'b', 'c')], {'a': 'a', 'b': 'a'}) == [{'missing': ['c'], 'requires': 'all', 'parameter': 'b', 'value': 'b', 'requirements': ['c']}]

# Generated at 2022-06-20 16:26:34.441746
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    with pytest.raises(TypeError):
        check_type_bits('')



# Generated at 2022-06-20 16:26:38.978588
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1kB') == 1024
    assert check_type_bytes('1MB') == 1024 * 1024
    assert check_type_bytes('1GB') == 1024 * 1024 * 1024
    assert check_type_bytes('1TB') == 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1PB') == 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1EB') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024



# Generated at 2022-06-20 16:26:50.493199
# Unit test for function check_type_dict
def test_check_type_dict():
    my_dict = check_type_dict('{"a": "value", "b": "value2"}')
    if my_dict != {"a": "value", "b": "value2"}:
        raise AssertionError("Dictionnary is not correctly parsed")
    my_dict = check_type_dict('a = value, b = value2')
    if my_dict != {"a": "value", "b": "value2"}:
        raise AssertionError("Dictionnary is not correctly parsed")
    my_dict = check_type_dict('a:value, b:value2')
    if my_dict != {"a": "value", "b": "value2"}:
        raise AssertionError("Dictionnary is not correctly parsed")

# Generated at 2022-06-20 16:26:58.516270
# Unit test for function check_required_arguments
def test_check_required_arguments():
    """Unit test for function check_required_arguments"""

    parameters = {'required_argument': 'present'}
    argument_spec = {
        'required_argument': {'required': True},
        'optional_argument': {'required': False}
    }

    # Success case
    missing = check_required_arguments(argument_spec, parameters)
    assert len(missing) == 0

    # Failure case
    parameters.pop('required_argument')
    missing = check_required_arguments(argument_spec, parameters)
    assert len(missing) == 1



# Generated at 2022-06-20 16:27:07.837448
# Unit test for function check_required_one_of
def test_check_required_one_of():
    t1 = [('a', 'b'), ('c', 'd')]
    p1 = {'d': 'd'}
    r1 = check_required_one_of(t1, p1)
    assert r1 == []

    t1 = [('a', 'b'), ('c', 'd')]
    p1 = {}
    try:
        r1 = check_required_one_of(t1, p1)
        assert False
    except TypeError as e:
        assert "one of the following is required: a, b" in str(e)



# Generated at 2022-06-20 16:27:13.253430
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('this,is,a,test') == ['this', 'is', 'a', 'test']
    assert check_type_list([1,2,'foo']) == [1,2,'foo']
    assert check_type_list(1.3) == ['1.3']
    try:
        check_type_list(True)
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-20 16:27:16.980324
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('345KiB') == 358400
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1.5TiB') == 1649267441664
    assert check_type_bytes('1P') == 1125899906842624
    # Check exception for invalid input
    with pytest.raises(TypeError):
        assert check_type_bytes('1.5T')
    with pytest.raises(TypeError):
        assert check_type_bytes('1t')



# Generated at 2022-06-20 16:27:18.681904
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576


# Generated at 2022-06-20 16:27:27.353034
# Unit test for function check_type_list
def test_check_type_list():

    # existing list value
    value = list(range(12))
    result = check_type_list(value)
    assert result == value

    # comma-delimited string
    value = "this,is,a,list,of,strings"
    result = check_type_list(value)
    assert result == value.split(",")

    # float
    value = 3.14
    result = check_type_list(value)
    assert result == [str(value)]

    # integer
    value = 12
    result = check_type_list(value)
    assert result == [str(value)]

    # no change
    value = 'This is a string'
    result = check_type_list(value)
    assert result == [value]



# Generated at 2022-06-20 16:27:29.523982
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert 'Error' in check_required_one_of([['test1', 'test2']],{'test1':'test2'})


# Generated at 2022-06-20 16:27:35.047037
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float('1.0') == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float('1') == 1
    assert check_type_float(1) == 1
    assert check_type_float('1') == 1
    assert check_type_float('-1') == -1
    assert check_type_float('-1.1') == -1.1
    assert check_type_float('asdf') is None


# Generated at 2022-06-20 16:27:39.309307
# Unit test for function check_type_str
def test_check_type_str():
    check_type_str('string')
    assert_raises(TypeError, lambda: check_type_str('string', allow_conversion=False))
    check_type_str(1, allow_conversion=True)



# Generated at 2022-06-20 16:27:44.204574
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('10B') == 10
    assert check_type_bytes('10G') == 10737418240
    assert check_type_bytes('10M') == 10485760
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes(10) == 10

# Generated at 2022-06-20 16:27:50.441585
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{"key":"value"}') == '{"key":"value"}'
    assert check_type_jsonarg('["one","two"]') == '["one","two"]'
    assert check_type_jsonarg(['one', 'two']) == '["one","two"]'
    assert check_type_jsonarg('"value"') == '"value"'
    assert check_type_jsonarg(123) == '123'
    assert check_type_jsonarg(123.4) == '123.4'
    assert check_type_jsonarg({"key": "value"}) == '{"key": "value"}'



# Generated at 2022-06-20 16:27:51.769820
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-20 16:28:00.702215
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b', 'c'], ('b', 'c')]
    parameters = dict(a=1, b=2, c=3)
    assert check_required_together(terms, parameters) == []

    terms = [['a', 'b', 'c'], ('b', 'c')]
    parameters = dict(a=1, c=3)
    assert check_required_together(terms, parameters) == [(('b', 'c'),)]

    terms = [['a', 'b', 'c'], ('d', 'e')]
    parameters = dict(a=1, c=3, d=4)
    assert check_required_together(terms, parameters) == [(('a', 'b', 'c'),)]

    terms = [['a', 'b', 'c'], ('d', 'e')]

# Generated at 2022-06-20 16:28:04.356463
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together([], {}) == []
    assert check_required_together([['name', 'state']], {'name': 'foo'}) == []
    assert check_required_together([['name', 'state']], {'state': 'present'}) == \
           [['name', 'state']]



# Generated at 2022-06-20 16:28:10.608611
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {
        'network_device_facts': ['identity_file'],
        'network_device_config': ['identity_file'],
        'network_device_facts_aggregate': ['identity_file'],
        'network_device_config_aggregate': ['identity_file'],
    }
    parameters = {
        'identity_file': '/path/to/id_file',
        'network_device_facts': True,
        'network_device_config': True,
    }
    result = check_required_by(requirements, parameters)
    assert result == {}
    parameters = {
        'identity_file': '/path/to/id_file',
        'network_device_facts': False,
        'network_device_config': True,
    }
    result = check_required

# Generated at 2022-06-20 16:28:24.313558
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():

    # Case-1: Mutually exclusive parameters not provided
    terms = ["test"]
    parameters = {}
    result = check_mutually_exclusive(terms, parameters)
    assert result == []

    # Case-2: All mutually exclusive parameters provided
    terms = ["test"]
    parameters = {"test": "value"}
    result = check_mutually_exclusive(terms, parameters)
    assert result == []

    # Case-3: Mutually exclusive parameters provided
    terms = ["test", ["test1", "test2"]]
    parameters = {"test": "value", "test1": "value", "test2": "value"}
    try:
        result = check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        if "parameters are mutually exclusive" in to_native(e):
            result = True

# Generated at 2022-06-20 16:28:34.187591
# Unit test for function check_required_together
def test_check_required_together():
    try:
        check_required_together([['a', 'b']], {})
        assert False, "Nothing specified, one of a or b is required"
    except TypeError as e:
        if 'required together' not in str(e):
            raise

    try:
        check_required_together([['a', 'b']], {'a': 'a'})
    except Exception:
        raise

    try:
        check_required_together([['a', 'b']], {'b': 'b'})
    except Exception:
        raise

    try:
        check_required_together([['a', 'b']], {'a': 'a', 'b': 'b'})
    except Exception:
        raise



# Generated at 2022-06-20 16:28:36.586920
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('abc') == 'abc'
    assert check_type_raw(b'abc') == b'abc'



# Generated at 2022-06-20 16:28:41.472451
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path(b'/tmp') == '/tmp'
    assert check_type_path('/tmp') == '/tmp'
    assert check_type_path(5) == '5'
    with pytest.raises(TypeError):
        check_type_path(dict())



# Generated at 2022-06-20 16:28:53.007382
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert check_type_list('a,b,c') == ['a', 'b', 'c']
    try:
        check_type_list(['a', 'b,c'])
        assert False, 'Expected error'
    except TypeError:
        pass
    try:
        check_type_list(1)
        assert False, 'Expected error'
    except TypeError:
        pass
    try:
        check_type_list(None)
        assert False, 'Expected error'
    except TypeError:
        pass
    try:
        check_type_list(False)
        assert False, 'Expected error'
    except TypeError:
        pass



# Generated at 2022-06-20 16:28:54.280958
# Unit test for function count_terms
def test_count_terms():
    terms = ['one', 'three']
    count = count_terms(terms, dict(one=1, two=2, three=3, four=4))
    assert count == 2



# Generated at 2022-06-20 16:28:54.952384
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('foo') == 'foo'



# Generated at 2022-06-20 16:29:04.934890
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    from ansible.module_utils._text import to_native
    # Test regular json string
    json_str = json.dumps({'a': 'hello', 'b': 'world'})
    assert check_type_jsonarg(json_str) == json_str
    # Test list
    json_str = '[1,2,3,4]'
    assert check_type_jsonarg(json_str) == json_str
    json_list = json.loads(json_str)
    assert check_type_jsonarg(json_list) == json_str
    # Test tuple
    json_str = '(1,2,3,4)'
    assert check_type_jsonarg(json_str) == json_str
    json_tuple = tuple(json.loads(json_str))

# Generated at 2022-06-20 16:29:09.030347
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('1,2,3,4') == ['1', '2', '3', '4']
    assert check_type_list(['1,2', '3, 4']) == ['1,2', '3, 4']
    assert check_type_list(1) == ['1']
    assert check_type_list(1.0) == ['1.0']
    with pytest.raises(TypeError):
        check_type_list(1, '1.0')


# Generated at 2022-06-20 16:29:17.283019
# Unit test for function check_required_if
def test_check_required_if():
    # pylint: disable=missing-docstring
    def _run_test(requirements, parameters, expected_results):
        results = check_required_if(requirements, parameters)
        assert results == expected_results

    # Test when "is_one_of" is False
    requirements = [['param1', 'present', ['param2', 'param3']]]
    parameters = {'param1': 'present'}
    expected_results = [{'missing': ['param2', 'param3'], 'requires': 'all', 'parameter': 'param1', 'value': 'present', 'requirements': ['param2', 'param3']}]
    _run_test(requirements, parameters, expected_results)

    # Test when param2 is present

# Generated at 2022-06-20 16:29:29.231424
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('10B') == 10
    assert check_type_bytes('10KiB') == 10240
    assert check_type_bytes('20GB') == 20000000000
    assert check_type_bytes('20MB') == 20971520
    assert check_type_bytes('20GiB') == 21474836480
    assert check_type_bytes('20MiB') == 20971520
    assert check_type_bytes('20TB') == 2e+12
    assert check_type_bytes('20TiB') == 2199023255552
    assert check_type_bytes('20EB') == 2.0e+15
    assert check_type_bytes('20EiB') == 2.27e+18
    assert check_type_bytes('20PB') == 2.0e+18
    assert check

# Generated at 2022-06-20 16:29:39.784856
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(True) == True
    assert check_type_bool(False) == False
    assert check_type_bool(0) == False
    #assert check_type_bool('0') == False
    #assert check_type_bool('1') == True
    #assert check_type_bool('f') == False
    #assert check_type_bool('F') == False
    #assert check_type_bool('n') == False
    #assert check_type_bool('N') == False
    #assert check_type_bool('y') == True
    #assert check_type_bool('Y') == True
    #assert check_type_bool('t') == True
    #assert check_type_bool('T') == True
    #assert check_type_bool('off') == False
    #assert check_type

# Generated at 2022-06-20 16:29:48.332451
# Unit test for function check_required_together
def test_check_required_together():
    terms = [('arg1', 'arg2'), ('arg1', 'arg3'), ('arg1', 'arg4')]
    parameters = {'arg1': True, 'arg2': True, 'arg3': True, 'arg4': True}
    test = check_required_together(terms, parameters)
    assert test == []

    parameters = {'arg1': True, 'arg2': True, 'arg4': True}
    test = check_required_together(terms, parameters)
    assert test == [('arg1', 'arg2'), ('arg1', 'arg3'), ('arg1', 'arg4')]



# Generated at 2022-06-20 16:29:50.473396
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argspec = {'required_arg': {'required': True}}
    with raises(TypeError):
        check_required_arguments(argspec, {})



# Generated at 2022-06-20 16:29:54.453440
# Unit test for function check_required_together
def test_check_required_together():
    params = dict(
        a=1,
        b=2,
        c=3
    )
    terms = [['a', 'b'], ['b', 'c']]
    assert check_required_together(terms, params) == []

    del params['b']
    assert check_required_together(terms, params) != []



# Generated at 2022-06-20 16:30:04.347243
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(b'1') == 1.0
    with raises(TypeError):
        check_type_float(1+2j)
    assert check_type_float(1+2j) == 1.0


# Generated at 2022-06-20 16:30:11.676131
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("foo") == "foo"
    assert safe_eval("42") == 42
    assert safe_eval("False") is False
    assert safe_eval("True") is True
    assert safe_eval("None") is None
    assert safe_eval("['a', 'b']") == ['a', 'b']
    # code is not evaluated
    assert safe_eval("1 + 2") == "1 + 2"
    # dict/set literals not allowed
    assert safe_eval("{1:2}") == "{1:2}"
    assert safe_eval("{1,2}") == "{1,2}"



# Generated at 2022-06-20 16:30:16.298711
# Unit test for function check_type_list
def test_check_type_list():
    assert ['a', 'b', 'c'] == check_type_list([['a', 'b', 'c']])
    assert ['a', 'b', 'c'] == check_type_list(('a,b,c',))
    assert ['a', 'b', 'c'] == check_type_list(('a', 'b', 'c'))
    assert [1] == check_type_list(1)
    assert [1] == check_type_list(1.0)



# Generated at 2022-06-20 16:30:18.368521
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw("string") == "string"
    assert check_type_raw(2) == 2


# Generated at 2022-06-20 16:30:30.315242
# Unit test for function check_required_by
def test_check_required_by():
    import pytest

# Generated at 2022-06-20 16:30:40.942929
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw("foo") == "foo"
    assert check_type_raw(123) == 123
    assert check_type_raw("[[1, 2], [3, 4]]") == "[[1, 2], [3, 4]]"

# Generated at 2022-06-20 16:30:42.259581
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = dict(vpc_id='vpc-1')
    assert check_missing_parameters(parameters, ['vpc_id']) == []


# Generated at 2022-06-20 16:30:43.232693
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Gb') == 1073741824



# Generated at 2022-06-20 16:30:48.640826
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('test', {'test': 'pass'}) == 1
    assert count_terms(['test', 'other'], {'test': 'pass'}) == 1
    assert count_terms(['test', 'other'], {'test': 'pass', 'other': 'pass'}) == 2



# Generated at 2022-06-20 16:30:50.413730
# Unit test for function check_type_bits
def test_check_type_bits():
   assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-20 16:30:58.794625
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # test valid no conflict
    parameters = {"state": "present", "name": "foo"}
    assert check_mutually_exclusive([['state', 'name']], parameters) == []
    parameters = {"force": True, "name": "foo"}
    assert check_mutually_exclusive([['state', 'name']], parameters) == []
    parameters = {"force": True, "name": "foo"}
    assert check_mutually_exclusive([['state', 'name'], ['force', 'name']], parameters) == []
    # test conflict
    parameters = {"state": "present", "name": "foo", "force": True}

# Generated at 2022-06-20 16:31:00.121965
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(terms=['key1', 'key2'], parameters={'key1': {}, 'key3': {}}) == 1



# Generated at 2022-06-20 16:31:10.564728
# Unit test for function check_required_if
def test_check_required_if():
    # check_required_if test case: check required parameters if key is present
    parameters = {"key": "val1", "key1": "val1"}
    requirements = [
        ['key', 'val1', ('key1', 'key2')]
    ]
    result = check_required_if(requirements, parameters)
    if not result:
        print("Passed test case 1")
    else:
        print("Failed test case 1")
    # check_required_if test case: check required parameters if key is not present
    parameters = {"key": None, "key1": "val1"}
    result = check_required_if(requirements, parameters)
    if not result:
        print("Passed test case 2")
    else:
        print("Failed test case 2")
    # check_required_if test case:

# Generated at 2022-06-20 16:31:18.787868
# Unit test for function safe_eval
def test_safe_eval():
    """Unit test for function safe_eval"""
    # Test cases for integer expressions
    assert safe_eval('0') == 0
    assert safe_eval('1') == 1
    assert safe_eval('+1') == 1
    assert safe_eval('-1') == -1
    assert safe_eval('1+1') == 2
    assert safe_eval('1-1') == 0
    assert safe_eval('1*1') == 1
    assert safe_eval('1/1') == 1
    # Test cases for float expressions
    assert safe_eval('0.0') == 0.0
    assert safe_eval('1.1') == 1.1
    assert safe_eval('+1.1') == 1.1
    assert safe_eval('-1.1') == -1.1

# Generated at 2022-06-20 16:31:24.202452
# Unit test for function check_required_by
def test_check_required_by():
    dictvalue = dict()
    dictvalue.update(dict(param1 = '1', args1 = '1', args2 = '2', param2 = '2'))
    dictvalue.update(dict(param3 = '3', args3 = '3', param4 = '4'))
    data = dict(param1='1', args1='1', args2='2', param2='2', param3='3', args3='3')
    assert check_required_by(dictvalue, data) == {}
    data = dict(param1='1', args1='1', args2='2', param2='2', param3='3', args3='3', param4='4')
    assert check_required_by(dictvalue, data) == {}

# Generated at 2022-06-20 16:31:33.218099
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('test=test') == dict(test='test')
    assert check_type_dict({'test': 'test'}) == dict(test='test')
    with pytest.raises(TypeError):
        check_type_dict([])


# Generated at 2022-06-20 16:31:40.228782
# Unit test for function check_type_float
def test_check_type_float():
    t = check_type_float(1)
    assert isinstance(t, float)
    t = check_type_float(1.0)
    assert isinstance(t, float)
    t = check_type_float('1')
    assert isinstance(t, float)
    assert t == 1.0
    t = check_type_float('1.0')
    assert isinstance(t, float)
    assert t == 1.0
    t = check_type_float(b'1')
    assert isinstance(t, float)
    assert t == 1.0



# Generated at 2022-06-20 16:31:45.961319
# Unit test for function safe_eval
def test_safe_eval():
    LOCALS = {'ansible_version': '2.1.0.0'}
    value = 'ansible_version[0:3]'
    assert safe_eval(value, locals=LOCALS) == '2.1'
    value = 'import os'
    assert safe_eval(value, locals=LOCALS) == 'import os'
    value = "os.system('echo blah blah')"
    assert safe_eval(value, locals=LOCALS) == "os.system('echo blah blah')"



# Generated at 2022-06-20 16:31:57.840969
# Unit test for function check_required_if
def test_check_required_if():
    for requirements in [
        [
            ['state', 'present', 'path', False],
            ['state', 'present', ['path', 'force'], False],
            ['someint', 99, ['bool_param', 'string_param'], False],
        ],
        [
            ['state', 'present', 'path', True],
            ['state', 'present', ['path', 'force'], True],
            ['someint', 99, ['bool_param', 'string_param'], True],
        ],
    ]:
        parameters = dict(
            path='foo',
            state='present',
        )
        check_required_if(requirements,parameters)
        parameters = dict(
            path='foo',
            force=True,
            state='present',
        )
        check_required_if(requirements,parameters)

# Generated at 2022-06-20 16:32:04.374715
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(1) == 1
    assert check_type_bytes('250B') == 250
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176

# Generated at 2022-06-20 16:32:06.406849
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path("~") == os.path.expanduser("~")


# Generated at 2022-06-20 16:32:12.303901
# Unit test for function check_type_str
def test_check_type_str():
    try:
        check_type_str(1)
    except TypeError:
        pass
    assert check_type_str(1, allow_conversion=True) == u'1'
    assert check_type_str('1', allow_conversion=True) == u'1'
    assert check_type_str(1, allow_conversion=False) == None
    assert check_type_str('1', allow_conversion=False) == u'1'


# Generated at 2022-06-20 16:32:15.736541
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    assert check_missing_parameters(dict(foo='bar'), required_parameters=['foo']) == []
    assert check_missing_parameters(dict(foo='bar', bar='baz'), required_parameters=['foo']) == []
    try:
        assert check_missing_parameters(dict(), required_parameters=['foo']) == ['foo']
    except TypeError as e:
        assert "missing required arguments: foo" in to_native(e)
    else:
        assert False, 'should have raised a TypeError'



# Generated at 2022-06-20 16:32:19.614552
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    params = dict(param1='foo', param2='bar')
    required_params = ['param1', 'param2']
    assert len(check_missing_parameters(params, required_params)) == 0

    params = dict(param1='foo')
    assert len(check_missing_parameters(params, required_params)) == 1

    params = dict(param2='foo')
    assert len(check_missing_parameters(params, required_params)) == 1



# Generated at 2022-06-20 16:32:23.306282
# Unit test for function check_required_one_of
def test_check_required_one_of():
    result = check_required_one_of([["option1", "option2"]],
                                   {"option1": True, "option2": True},
                                   ["terminal", "system"])
    assert result == []



# Generated at 2022-06-20 16:32:36.080547
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = [["a", "b"]]
    parameters = {"a": "test", "b": "test"}
    try:
        check_mutually_exclusive(terms=terms, parameters=parameters)
        raise TestFailException("Failed to raise an exception")
    except TypeError:
        pass
    terms = [["a"]]
    parameters = {"a": "test"}
    try:
        check_mutually_exclusive(terms=terms, parameters=parameters)
    except TypeError:
        raise TestFailException("Raised an exception for valid parameters")



# Generated at 2022-06-20 16:32:48.089913
# Unit test for function check_type_dict
def test_check_type_dict():
    STR_TRUE = 'true'
    STR_FALSE = 'false'

    assert check_type_dict("{'a':'b'}") == {'a': 'b'}
    assert check_type_dict("{'a':%s}" % STR_TRUE) == {'a': True}
    assert check_type_dict("{'a':%s}" % STR_FALSE) == {'a': False}
    assert check_type_dict("'a':'b'") == {'a': 'b'}
    assert check_type_dict("a='b'") == {'a': 'b'}
    assert check_type_dict("a") == {'a': None}
    assert check_type_dict("'a'") == {'a': None}

# Generated at 2022-06-20 16:32:53.958983
# Unit test for function check_type_float
def test_check_type_float():
 assert check_type_float(123.0) == 123.0
 assert check_type_float(123) == 123.0
 assert check_type_float('123') == 123.0
 assert check_type_float('123.0') == 123.0
 try:
  check_type_float('123a')
  assert False
 except TypeError:
  pass


# Generated at 2022-06-20 16:32:59.374238
# Unit test for function check_type_float
def test_check_type_float():
    assert isinstance(check_type_float(1.1), float)
    assert isinstance(check_type_float(1), float)
    assert isinstance(check_type_float('1.1'), float)
    assert isinstance(check_type_float('1'), float)
    assert isinstance(check_type_float(b'1.1'), float)
    assert isinstance(check_type_float(b'1'), float)



# Generated at 2022-06-20 16:33:02.757756
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('a') == 'a'
    assert check_type_raw(1) == 1



# Generated at 2022-06-20 16:33:11.280832
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    try:
        check_mutually_exclusive(
            [
                ['name', 'log'],
                ['content', 'src'],
            ],
            {
                'name': 'foo',
                'log': True,
            }
        )
    except TypeError as e:
        assert 'parameters are mutually exclusive: name|log' in str(e)
    else:
        assert False, 'TypeError not raised'

    try:
        check_mutually_exclusive(
            [
                ['name', 'log'],
                ['content', 'src'],
            ],
            {
                'content': 'foo',
                'src': '/tmp/foo',
            }
        )
    except TypeError as e:
        assert 'parameters are mutually exclusive: content|src' in str(e)

# Generated at 2022-06-20 16:33:15.323216
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(None) == None
    assert check_type_float(type(None)) == None
    assert check_type_float(1) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1.0*10**100) == 1.0*10**100
    assert check_type_float(1.0*10**-100) == 1.0*10**-100
    assert check_type_float(10**100) == 10**100
    assert check_type_float(10**-100) == 10**-100
    assert check_type_float("1") == 1.0
    assert check_type_float("1.0") == 1.0
    assert check_type_float("1.0*10**100") == 1.

# Generated at 2022-06-20 16:33:16.013104
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('value') == 'value'



# Generated at 2022-06-20 16:33:17.441480
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-20 16:33:22.405309
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{'foo':'bar','bar':'baz'}") == {"foo": "bar", "bar": "baz"}
    assert check_type_dict("foo='bar',bar='baz'") == {"foo": "bar", "bar": "baz"}
    assert check_type_dict("foo='bar bar2',bar='baz'") == {"foo": "bar bar2", "bar": "baz"}
    assert check_type_dict("{'foo':'bar bar2','bar':'baz'}") == {"foo": "bar bar2", "bar": "baz"}
    assert check_type_dict("foo='bar bar2',bar='baz,baz2'") == {"foo": "bar bar2", "bar": "baz,baz2"}
    # check that

# Generated at 2022-06-20 16:33:33.986671
# Unit test for function check_required_arguments
def test_check_required_arguments():
    try:
        print(check_required_arguments({"a": {"required": True}}, {}))
        assert False
    except TypeError as e:
        assert e.args[0] == "missing required arguments: a"

    try:
        print(check_required_arguments({"a": {"required": False}}, {}))
        assert True
    except TypeError as e:
        assert False


# Generated at 2022-06-20 16:33:39.225955
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():

    assert check_type_jsonarg(['a']) == '["a"]'
    assert check_type_jsonarg((1,2,3)) == '[1,2,3]'
    assert check_type_jsonarg({'a': 1}) == '{"a":1}'
    assert check_type_jsonarg("") == ""
    assert check_type_jsonarg(" ") == " "



# Generated at 2022-06-20 16:33:42.168111
# Unit test for function check_type_int
def test_check_type_int():
    expected = 12
    actual = check_type_int(expected)
    assert expected == actual



# Generated at 2022-06-20 16:33:48.459575
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = dict(foo=dict(type='str', required=True),
                         bar=dict(type='str'),
                         bam=dict(type='str', required=True))
    parameters = dict(bar='bar')
    try:
        check_required_arguments(argument_spec, parameters)
    except Exception as ex:
        assert str(ex) == "missing required arguments: foo, bam"



# Generated at 2022-06-20 16:33:54.930514
# Unit test for function safe_eval
def test_safe_eval():
    assert isinstance(safe_eval('{}'), dict)
    assert isinstance(safe_eval('{"k1": "v1"}'), dict)
    assert isinstance(safe_eval('{"k1": "v1", "k2": 2}'), dict)
    assert safe_eval('{"k1": "v1", "k2": 2}') == {"k1": "v1", "k2": 2}
    assert isinstance(safe_eval('["v1", 2]'), list)
    assert isinstance(safe_eval('"v1"'), text_type)
    assert safe_eval('"v1"') == u"v1"
    assert isinstance(safe_eval('2'), integer_types)
    assert isinstance(safe_eval('2.0'), float)
    assert safe_eval('2') == 2


# Generated at 2022-06-20 16:34:05.524224
# Unit test for function check_required_together
def test_check_required_together():
    # Check that no errors are raised when check_required_together is called with valid terms and parameters
    assert check_required_together([("a", "b")], {"a": 1, "b": 2}) == []
    assert check_required_together([("a", "b")], {"a": 1, "b": 2, "c": 3}) == []
    assert check_required_together([("a", "b")], {"b": 2, "c": 3}) == []
    assert check_required_together([("a", "b")], {"c": 3}) == []
    assert check_required_together([("a", "b"), ("c", "d")], {"a": 1, "b": 2, "c": 3, "d": 4}) == []

# Generated at 2022-06-20 16:34:07.255335
# Unit test for function check_type_raw
def test_check_type_raw():
    value = check_type_raw("hello world")
    assert value == "hello world"

# Generated at 2022-06-20 16:34:10.839629
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('a', ['a', 'b', 'c']) == 1
    assert count_terms(['a', 'b'], ['a', 'b', 'c']) == 2



# Generated at 2022-06-20 16:34:21.257478
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list((1,2,3)) == [1,2,3]
    assert check_type_list(['a',2,3]) == ['a',2,3]
    assert check_type_list([1.1,2.2,3.3]) == [1.1,2.2,3.3]
    assert check_type_list('a,b,c') == ['a', 'b', 'c']
    assert check_type_list('1,2,3') == ['1', '2', '3']
    assert check_type_list('1,2') == ['1', '2']
    assert check_type_list('3') == ['3']
    assert check_type_list(3) == ['3']

# Generated at 2022-06-20 16:34:32.593415
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    from nose.plugins.attrib import attr

    @attr('unit')
    def test_empty_terms():
        assert check_mutually_exclusive(None, {'parameter': 'value'}) == []

    @attr('unit')
    def test_no_conflicts():
        assert check_mutually_exclusive(['a', 'b', 'c'], {'a': 'foo', 'b': 'bar'}) == []
        assert check_mutually_exclusive(['a', 'b'], {'a': 'foo', 'b': 'bar'}) == []

    @attr('unit')
    def test_single_parameter_conflict():
        assert check_mutually_exclusive(['a', 'b'], {'a': 'foo', 'b': 'foo'}) != []

# Generated at 2022-06-20 16:34:53.314347
# Unit test for function check_required_together
def test_check_required_together():
    """Ensure check_required_together raises TypeError when necessary"""
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': '1', 'c': '2'}
    try:
        check_required_together(terms, parameters)
    except TypeError as e:
        assert 'parameters are required together: b, c' in str(e)
    else:
        raise Exception("Did not raise TypeError")
    parameters = {'a': '1'}
    try:
        check_required_together(terms, parameters)
    except TypeError as e:
        assert 'parameters are required together: b' in str(e)
    else:
        raise Exception("Did not raise TypeError")

# Generated at 2022-06-20 16:35:04.770015
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1') == 1
    assert check_type_int(-1) == -1
    assert check_type_int(-1.0) == -1
    assert check_type_int('-1') == -1
    assert check_type_int(True) == 1
    assert check_type_int('True') == 1
    assert check_type_int(0) == 0
    assert check_type_int(0.0) == 0
    assert check_type_int('0') == 0
    assert check_type_int(False) == 0
    assert check_type_int('False') == 0
    assert check_type_int(None) == 0
    assert check_type_int

# Generated at 2022-06-20 16:35:09.162155
# Unit test for function check_required_arguments
def test_check_required_arguments():
    from ansible.module_utils.common.validation import check_required_arguments
    try:
        check_required_arguments({"a": {"required": True}, "b": {"required": False}}, {'a': '1'})
    except:
        return False
    return True



# Generated at 2022-06-20 16:35:11.915396
# Unit test for function check_type_int
def test_check_type_int():
    def class_check_type_int(a):
        print(check_type_int(a))

    class_check_type_int('0')
    class_check_type_int(0)



# Generated at 2022-06-20 16:35:19.500195
# Unit test for function check_type_path
def test_check_type_path():
    """Function check_type_path requires one argument, which can be a string.
    An expanded path is returned, which tests that a path location can be read in as a string,
    expanded, and then returned as a path for further processing.
    """
    string_value = "./test/data/one.txt"
    assert check_type_path(string_value) == "/home/ansible/ansible/test/data/one.txt"
    # test that the function cannot be called without arguments
    with pytest.raises(TypeError):
        check_type_path()


# Generated at 2022-06-20 16:35:31.163085
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    from ansible.compat.tests import unittest

    class TestCheckTypeJsonarg(unittest.TestCase):
        def test_string(self):
            value = "spam"
            self.assertEqual(check_type_jsonarg(value), value)

        def test_unicode_text(self):
            value = u"spam"
            self.assertEqual(check_type_jsonarg(value), value)

        def test_list(self):
            value = ["spam", "eggs"]
            self.assertEqual(check_type_jsonarg(value), jsonify(value))

        def test_tuple(self):
            value = ("spam", "eggs")
            self.assertEqual(check_type_jsonarg(value), jsonify(value))


# Generated at 2022-06-20 16:35:39.027974
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(0) == False
    assert check_type_bool(1) == True
    assert check_type_bool("0") == False
    assert check_type_bool("1") == True
    assert check_type_bool("True") == True
    assert check_type_bool("False") == False
    assert check_type_bool("true") == True
    assert check_type_bool("false") == False
    assert check_type_bool("FALSE") == False
    assert check_type_bool("TRUE") == True
    assert check_type_bool("t") == True
    assert check_type_bool("f") == False
    assert check_type_bool("yes") == True
    assert check_type_bool("on") == True
    assert check_type_bool("off") == False