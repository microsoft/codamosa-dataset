

# Generated at 2022-06-20 16:26:14.678790
# Unit test for function check_required_one_of
def test_check_required_one_of():
    check_required_one_of([('ip', 'host')], {'ip': '1.1.1.1'})
    check_required_one_of([('ip', 'host')], {'host': 'hostname'})
    try:
        check_required_one_of([('ip', 'host')], {})
    except TypeError as err:
        pass
    else:
        assert False, "Expected a TypeError exception"



# Generated at 2022-06-20 16:26:21.598507
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('key_one', {'key_one': 'val_one', 'key_two': 'val_two', 'key_three': 'val_three'}) == 1
    assert count_terms('key_two', {'key_one': 'val_one', 'key_two': 'val_two', 'key_three': 'val_three'}) == 1
    assert count_terms('key_three', {'key_one': 'val_one', 'key_two': 'val_two', 'key_three': 'val_three'}) == 1
    assert count_terms(['key_one', 'key_two'], {'key_one': 'val_one', 'key_two': 'val_two', 'key_three': 'val_three'}) == 2

# Generated at 2022-06-20 16:26:24.014786
# Unit test for function check_required_one_of
def test_check_required_one_of():
  params = {'state': 'absent', 'admin_state': 'absent'}
  terms = [['name', 'provider']]
  check_required_one_of(terms, params, None)


# Generated at 2022-06-20 16:26:29.224629
# Unit test for function count_terms
def test_count_terms():
    """Unit test for _helpers.count_terms
    """
    assert count_terms([1, 2, 3], [3, 4, 5]) == 1
    assert count_terms(1, [3, 4, 5]) == 0
    assert count_terms(1, [1, 4, 5]) == 1



# Generated at 2022-06-20 16:26:40.103071
# Unit test for function check_required_by
def test_check_required_by():
    # pylint: disable=missing-docstring
    # Test one required by one
    parameters = dict(
        image='1',
        size='2',
        password='1'
    )
    requirements = dict(
        image='password'
    )
    assert check_required_by(requirements, parameters) == {}

    parameters = dict(
        image='1',
        size='2'
    )
    requirements = dict(
        image='password'
    )
    try:
        check_required_by(requirements, parameters)
    except TypeError as e:
        assert str(e) == "missing parameter(s) required by 'image': password"
    else:
        assert False # We should always get an error

    # Test two required by one

# Generated at 2022-06-20 16:26:52.686245
# Unit test for function check_type_dict
def test_check_type_dict():
    # This should not raise an exception
    dict_str = '{"name": "pedro", "age":25}'
    check_type_dict(dict_str)

    # This should not raise an exception
    dict_str = 'name=pedro, age=25'
    check_type_dict(dict_str)

    dict_str = 'name="pedro", age=25'
    try:
        check_type_dict(dict_str)
        assert False, "Should have thrown an exception. dict_str is invalid JSON"
    except Exception:
        pass

    dict_str = 'name=pedro, age=25'
    result = check_type_dict(dict_str)
    assert isinstance(result, dict), "Should be a dict"


# Generated at 2022-06-20 16:26:55.801616
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw('1234') == '1234'
    assert check_type_raw(1234) == 1234
    assert check_type_raw(True) == True
    assert check_type_raw(False) == False
    assert check_type_raw(None) == None



# Generated at 2022-06-20 16:27:07.604771
# Unit test for function check_type_list
def test_check_type_list():
    # string with comma
    mystr1 = "this,is,a,list"
    # string without comma
    mystr2 = "this is a list"
    # comma number
    mystr3 = "1,2,3,4.5"
    # int number
    myint = 1
    # float number
    myfloat = 1.0
    # list
    mylist = [1,2,3,4]
    assert check_type_list(mystr1) == ["this","is","a","list"], "Unexpected output"
    assert check_type_list(mystr2) == ["this is a list"], "Unexpected output"
    assert check_type_list(mystr3) == ["1","2","3","4.5"], "Unexpected output"

# Generated at 2022-06-20 16:27:17.664276
# Unit test for function check_type_bool
def test_check_type_bool():
    assert (check_type_bool('1') is True)
    assert (check_type_bool(1) is True)
    assert (check_type_bool('on') is True)
    assert (check_type_bool('0') is False)
    assert (check_type_bool(0) is False)
    assert (check_type_bool('n') is False)
    assert (check_type_bool('f') is False)
    assert (check_type_bool('no') is False)
    assert (check_type_bool('false') is False)
    assert (check_type_bool('y') is True)
    assert (check_type_bool('t') is True)
    assert (check_type_bool('yes') is True)
    assert (check_type_bool('true') is True)

# Generated at 2022-06-20 16:27:23.716983
# Unit test for function count_terms
def test_count_terms():
    def check(terms, parameters, expected):
        actual = count_terms(terms, parameters)
        assert actual == expected, '%r != %r' % (actual, expected)

    check('required', dict(required='y', not_required='n'), 1)
    check('required', dict(not_required='n'), 0)
    check(['required', 'not_required'], dict(required='y', not_required='n'), 2)
    check(['required', 'not_required'], dict(required='n'), 1)



# Generated at 2022-06-20 16:27:40.398548
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path', ), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/etc/passwd',
        'someint': 99,
        'bool_param': 'true',
    }
    expected_result = []
    result = check_required_if(requirements, parameters)
    assert expected_result == result

    requirements = [
        ['state', 'present', ('path', ), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]

# Generated at 2022-06-20 16:27:45.933900
# Unit test for function check_type_bool
def test_check_type_bool():
    # Positive test cases
    assert check_type_bool('1') is True
    assert check_type_bool('on') is True
    assert check_type_bool(1) is True
    assert check_type_bool('0') is False
    assert check_type_bool(0) is False
    assert check_type_bool('n') is False
    assert check_type_bool('f') is False
    assert check_type_bool('false') is False
    assert check_type_bool('true') is True
    assert check_type_bool('y') is True
    assert check_type_bool('t') is True
    assert check_type_bool('yes') is True
    assert check_type_bool('no') is False
    assert check_type_bool('off') is False

    # Negative test case

# Generated at 2022-06-20 16:27:46.608299
# Unit test for function check_type_raw
def test_check_type_raw():
    value = check_type_raw("test")
    assert value == "test"


# Generated at 2022-06-20 16:27:53.381025
# Unit test for function check_type_bytes
def test_check_type_bytes():
    bytes_test_values = {"1G": 1073741824, "1M": 1048576, "500": 500, "500.1": 500.1, u"1G": 1073741824}
    for i, j in bytes_test_values.items():
        assert check_type_bytes(i) == j


# Generated at 2022-06-20 16:27:55.922408
# Unit test for function check_type_path
def test_check_type_path():
    path = '~/Desktop'
    assert check_type_path(path) == os.path.expanduser(path)
#=========================================================


# Generated at 2022-06-20 16:28:01.257511
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
    }
    assert check_required_arguments(argument_spec, {}) == ['required_arg']
    assert check_required_arguments(argument_spec, {'required_arg': 'present'}) == []
    assert check_required_arguments(argument_spec, {'required_arg': None}) == []
    assert check_required_arguments(argument_spec, {'extra_arg': 'present'}) == ['required_arg']



# Generated at 2022-06-20 16:28:05.562277
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments(
        {'foo': {'required': True}}, {'foo': 'foo_value'}) == []
    try:
        check_required_arguments(
            {'foo': {'required': True}}, {})
    except TypeError as e:
        assert to_native(e) == "missing required arguments: foo"
        assert True
    else:
        assert False, "TypeError not raised on missing required argument"



# Generated at 2022-06-20 16:28:11.398956
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes(1) == 1
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1m') == 1024 * 1024
    assert check_type_bytes('1g') == 1024 * 1024 * 1024
    assert check_type_bytes('0.5k') == 512
    assert check_type_bytes('0.5K') == 512
    assert check_type_bytes('0.1m') == 1024 * 102
    assert check_type_bytes('0.1M') == 1024 * 102
    assert check_type_bytes('0.1g') == 1024 * 1024 * 102
    assert check_type_bytes('0.1G') == 1024 * 1024 * 102
    assert check

# Generated at 2022-06-20 16:28:23.479612
# Unit test for function check_required_one_of
def test_check_required_one_of():
    parameters = {}
    required_one_of = [['a', 'b']]
    results = check_required_one_of(required_one_of, parameters)
    assert results == [['a', 'b']]
    parameters = {'a': 1, 'b': 2}
    results = check_required_one_of(required_one_of, parameters)
    assert results == []
    parameters = {'a': 1, 'b': None}
    results = check_required_one_of(required_one_of, parameters)
    assert results == []
    parameters = {'a': 1, 'b': 2, 'c': 3}
    results = check_required_one_of(required_one_of, parameters)
    assert results == []
    parameters = {'b': 2, 'c': 3}
    results

# Generated at 2022-06-20 16:28:29.267109
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Known quantities
    assert check_type_bytes('1') == 1
    assert check_type_bytes('2k') == 2048
    assert check_type_bytes('3M') == 3145728
    assert check_type_bytes('4g') == 4294967296
    # Error handling
    # assert_raises(TypeError, check_type_bytes, True)
    assert_raises(TypeError, check_type_bytes, ['some', 'list'])
    assert_raises(TypeError, check_type_bytes, {'some': 'dict'})
    assert_raises(TypeError, check_type_bytes, (1, 2, 3, 4))
    assert_raises(TypeError, check_type_bytes, 'badvalue')


# Generated at 2022-06-20 16:28:39.224059
# Unit test for function count_terms
def test_count_terms():
    # pylint: disable=redefined-outer-name
    terms = ['foo', 'bar']
    parameters = {'foo': 'baz', 'bar': 'baz'}

    # Test with a list of terms
    count = count_terms(terms, parameters)
    assert count == 2

    # Test with a single string
    count = count_terms(terms[0], parameters)
    assert count == 1

    # Test with a single string
    count = count_terms('blah', parameters)
    assert count == 0



# Generated at 2022-06-20 16:28:45.609480
# Unit test for function check_required_arguments
def test_check_required_arguments():
    missing = []
    assert missing == check_required_arguments(
            {'arg1': {'required': True}, 'arg2': {'required': False}},
            {'arg1': 'val1', 'arg2': 'val2'})
    try:
        check_required_arguments(
                {'arg1': {'required': True}, 'arg2': {'required': False}},
                {'arg1': 'val1'})
    except TypeError:
        return
    assert False


# Generated at 2022-06-20 16:28:57.569202
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # We accept 0 arg function
    argument_spec = {
        'a': {},
        'b': {},
    }
    assert len(check_required_arguments(argument_spec, {})) == 2

    # We accept 1 required arg
    argument_spec = {
        'a': {'required': True},
        'b': {},
    }
    assert len(check_required_arguments(argument_spec, {})) == 1
    assert len(check_required_arguments(argument_spec, {'a': 1})) == 0

    # We accept 1 required arg of 2
    argument_spec = {
        'a': {'required': True},
        'b': {'required': True},
    }
    assert len(check_required_arguments(argument_spec, {})) == 2

# Generated at 2022-06-20 16:29:06.716861
# Unit test for function safe_eval
def test_safe_eval():
    # test for imports
    result, error = safe_eval("import_module('os')", include_exceptions=True)
    assert result == "import_module('os')"
    assert isinstance(error, NameError)
    # test for method calls
    result, error = safe_eval("datetime.datetime.now()", include_exceptions=True)
    assert result == "datetime.datetime.now()"
    assert isinstance(error, NameError)
    # test for variable names
    result, error = safe_eval("os", include_exceptions=True)
    assert result == "os"
    assert isinstance(error, NameError)
    # test for datetime

# Generated at 2022-06-20 16:29:15.161096
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments(
        dict(a=dict(required=True), b=dict(required=False)), dict(a=10, b=20)) == []
    assert check_required_arguments(
        dict(a=dict(required=True), b=dict(required=False)), dict(a=10)) == []
    assert check_required_arguments(
        dict(a=dict(required=False)), dict(a=10, b=20)) == []
    try:
        check_required_arguments(
            dict(a=dict(required=True), b=dict(required=False)), dict(b=10))
    except TypeError as e:
        assert str(e) == 'missing required arguments: a'



# Generated at 2022-06-20 16:29:25.259526
# Unit test for function check_type_dict
def test_check_type_dict():
    from ansible.compat.tests import unittest

    class TestCheckTypeDict(unittest.TestCase):

        def test_empty_value(self):
            from ansible.module_utils.common import check_type_dict
            self.assertEquals(check_type_dict(""), {})

        def test_str(self):
            from ansible.module_utils.common import check_type_dict
            value = "k=v"
            self.assertEquals(check_type_dict(value), {'k': 'v'})

        def test_str_list(self):
            from ansible.module_utils.common import check_type_dict
            value = "k1=v1,k2=v2, k3= v3 ,k4 =v4"

# Generated at 2022-06-20 16:29:34.606356
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(0) == 0
    assert check_type_int(1) == 1
    assert check_type_int('0') == 0
    assert check_type_int('1') == 1
    assert check_type_int('-1') == -1
    assert check_type_int('01') == 1
    assert check_type_int('-01') == -1
    raises(TypeError, check_type_int, '0.0')
    raises(TypeError, check_type_int, '0.1')


# Generated at 2022-06-20 16:29:42.594336
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # Test with a list of tuple
    my_result = check_required_one_of([('a', 'b'), ('c', 'd'), ('e', 'f')], {'a':1, 'c': 2})
    assert my_result == []
    # Test with a list of list
    my_result = check_required_one_of([['a', 'b'], ['c', 'd'], ['e', 'f']], {'a':1, 'c': 2})
    assert my_result == []
    # Test with one tuple missing
    try:
        my_result = check_required_one_of([('a', 'b'), ('c', 'd'), ('e', 'f')], {'a':1})
    except TypeError:
        my_result = ['e', 'f']

# Generated at 2022-06-20 16:29:47.661397
# Unit test for function check_type_bits

# Generated at 2022-06-20 16:29:55.350240
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    term_fail_list = [["foo", "bar"], ["baz", "bam"]]
    term_pass_list = [["foo", "bar"], ["bam", "baz"]]
    terms_pass_dict = {"foo": "bar", "baz": "bam"}
    terms_fail_dict = {"foo": "bar", "baz": "bam", "bar": "bar"}
    try:
        check_mutually_exclusive(term_fail_list, terms_fail_dict)
    except TypeError:
        pass
    else:
        raise AssertionError()
    try:
        check_mutually_exclusive(term_pass_list, terms_pass_dict)
    except TypeError:
        raise AssertionError()
    else:
        pass

# Generated at 2022-06-20 16:30:08.850158
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    from ansible.module_utils.basic import AnsibleModule

    try:
        params = {"one": None, "two": 2, "three": 3, "four": 4}
        required_parameters = ["one", "three"]
        module = AnsibleModule(argument_spec={})
        check_missing_parameters(params, required_parameters)
    except TypeError as err:
        assert to_native(err) == "missing required arguments: one"


# -- PYTHON 2/3 COMPATIBILITY

# https://docs.python.org/2/library/functions.html#reduce
try:
    reduce  # attempt to evaluate reduce
except NameError:
    from functools import reduce  # fallback on functools


# -- IS IT AN ITERABLE?

# http://stackoverflow.

# Generated at 2022-06-20 16:30:16.395242
# Unit test for function check_type_dict
def test_check_type_dict():
    result1 = check_type_dict("")
    result1 = check_type_dict("name=Cisco")
    result1 = check_type_dict("name=Cisco,ip=10.10.10.10")
    result1 = check_type_dict("{name:Cisco,ip:10.10.10.10}")
    result1 = check_type_dict("{name:Cisco, ip:10.10.10.10}")
    result1 = check_type_dict("{name:Cisco, ip:10.10.10.10, }")
    try:
        result1 = check_type_dict("{name:Cisco, ip:10.10.10.10, } ")
    except TypeError as exception:
        print("Exception:", exception)

# Generated at 2022-06-20 16:30:17.425055
# Unit test for function check_missing_parameters
def test_check_missing_parameters():

    from difflib import unified_diff


# Generated at 2022-06-20 16:30:21.443807
# Unit test for function check_type_dict
def test_check_type_dict():

    assert check_type_dict("{'a':1, 'b':2}") == {'a':1, 'b':2}
    assert check_type_dict("a=1, b=2") == {'a':'1', 'b':'2'}
    assert check_type_dict("a=1,b=2") == {'a':'1', 'b':'2'}
    assert check_type_dict("a='1,2',b=2") == {'a':'1,2', 'b':'2'}
    assert check_type_dict("a=\"1,2\",b=2") == {'a':'1,2', 'b':'2'}

# Generated at 2022-06-20 16:30:23.706065
# Unit test for function check_type_raw
def test_check_type_raw():
    result = check_type_raw('test')
    assert('test' == result)



# Generated at 2022-06-20 16:30:34.257699
# Unit test for function check_type_str
def test_check_type_str():
    # Testing without conversion
    try:
        check_type_str(None, allow_conversion=False)
    except TypeError as e:
        assert e.args[0] == "'None' is not a string and conversion is not allowed"
    try:
        check_type_str(9, allow_conversion=False)
    except TypeError as e:
        assert e.args[0] == "'9' is not a string and conversion is not allowed"
    try:
        check_type_str({'key': 'value'}, allow_conversion=False)
    except TypeError as e:
        assert e.args[0] == "'{'key': 'value'}' is not a string and conversion is not allowed"

    # Testing with conversion
    assert check_type_str(None, allow_conversion=True) is None

# Generated at 2022-06-20 16:30:39.315747
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(10) == 10.0
    assert check_type_float('10') == 10.0
    assert check_type_float(b'10') == 10.0
    assert check_type_float(wbt(b'10')) == 10.0


# Generated at 2022-06-20 16:30:45.956184
# Unit test for function count_terms
def test_count_terms():

    parameters = [
        {
            'name': 'User name',
            'description': 'User name',
            'value': 'ansible',
        },
        {
            'name': 'Address',
            'description': 'Address',
            'value': '127.0.0.42',
        },
        {
            'name': 'Port',
            'description': 'Port',
            'value': 80,
        },
    ]

    test_terms = [
        'name',
        'value',
    ]

    assert count_terms(test_terms, parameters) == 3



# Generated at 2022-06-20 16:30:53.090867
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(['a', 'b']) == ['a', 'b']
    assert check_type_list('a') == ['a']
    assert check_type_list(1) == ['1']
    assert check_type_list('a,b') == ['a', 'b']
    assert_raises(TypeError, check_type_list, {'a': 1})



# Generated at 2022-06-20 16:31:02.387401
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('a') == ['a']
    assert check_type_list('a,b') == ['a', 'b']
    assert check_type_list(['a']) == ['a']
    assert check_type_list(['a', 'b']) == ['a', 'b']
    assert check_type_list(1) == ['1']
    assert_raises(TypeError, check_type_list, {'a': 1})
    assert_raises(TypeError, check_type_list, ('a', 'b'))
    assert_raises(TypeError, check_type_list, 1.1)


# Generated at 2022-06-20 16:31:15.397600
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(0) == 0
    assert check_type_float(0.0) == 0.0
    assert check_type_float(0.2) == 0.2
    assert check_type_float(1.0) == 1.0
    assert check_type_float(2.0) == 2.0
    assert check_type_float("0") == 0.0
    assert check_type_float("0.0") == 0.0
    assert check_type_float("0.2") == 0.2
    assert check_type_float("1.0") == 1.0
    assert check_type_float("2.0") == 2.0
    # FIXME: This is currently not raising a TypeError when it should.
    # raise_type_error_msg = r"'#' cannot be converted

# Generated at 2022-06-20 16:31:18.266706
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(2.1) == 2.1
    assert check_type_float(2) == 2.0
    assert check_type_float(u'2.1') == 2.1
    assert check_type_float(b'2.1') == 2.1
    assert check_type_float(2.0) == 2.0
    assert_raises(TypeError, check_type_float, [])
    assert_raises(TypeError, check_type_float, None)


# Generated at 2022-06-20 16:31:19.812720
# Unit test for function check_type_raw
def test_check_type_raw():
    value = 'abc'
    returned = check_type_raw(value)
    assert value == returned

# Generated at 2022-06-20 16:31:27.936358
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import PY3
    import sys

    if PY3:
        kwargs = {'encoding': sys.getdefaultencoding()}
    else:
        kwargs = {}

    try:
        check_missing_parameters({'b': 'bar'}, ['a'])
    except AnsibleError as e:
        assert e.args[0] == 'missing required arguments: a'



# Generated at 2022-06-20 16:31:33.040232
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    "test jsonify when value is list, tuple and dict"
    assert check_type_jsonarg([1, 2, 3]) == "[1, 2, 3]"
    assert check_type_jsonarg((1, 2, 3)) == "[1, 2, 3]"
    assert check_type_jsonarg({1: 2}) == '{\"1\": 2}'


# Generated at 2022-06-20 16:31:40.469699
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{"foo": "bar"}', include_exceptions=True) == ({'foo': 'bar'}, None)
    assert safe_eval('{"foo": "bar"}', include_exceptions=False) == ({'foo': 'bar'})
    assert safe_eval('[1,2,3]', include_exceptions=True) == ([1, 2, 3], None)
    assert safe_eval('[1,2,3]', include_exceptions=False) == ([1, 2, 3])
    assert safe_eval('1+1', include_exceptions=True) == (2, None)
    assert safe_eval('1+1', include_exceptions=False) == (2)
    assert safe_eval('foo.bar()', include_exceptions=True) == ('foo.bar()', None)
   

# Generated at 2022-06-20 16:31:47.536353
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(['a', 'b'], {'a': 1, 'b': 2, 'c': 3}) == 2
    assert count_terms('a', {'a': 1, 'b': 2, 'c': 3}) == 1
    assert count_terms(['a', 'b', 'missing'], {'a': 1, 'b': 2, 'c': 3}) == 2
    assert count_terms(['a', 'b'], {'a': 1, 'b': 2, 'c': 3}) == 2
    assert count_terms('a', None) == 0
    assert count_terms(['a', 'b'], None) == 0


# Generated at 2022-06-20 16:31:58.862360
# Unit test for function check_type_bytes
def test_check_type_bytes():
    """
    Test check_type_bytes()
    """
    #create a set of input/output pairs
    test_pairs = {
        '100': 100,
        '100 b': 100,
        '100b': 100,
        '100.5kb': 102400.5,
        '100.5 kB': 102400.5,
        '100.5 kb': 102400.5,
        '100.5 mb': 104857600.0,
        '100.5 mB': 104857600.0,
        '100.5 mb': 104857600.0,
    }
    for test_input, expected_output in test_pairs.items():
        #test the function and assert the output matches the expected output
        assert check_type_bytes(test_input) == expected_output

    #

# Generated at 2022-06-20 16:32:02.967383
# Unit test for function check_type_bool
def test_check_type_bool():
    # Unit test for check_type_bool
    # check_type_bool should return a Boolean True or False
    # according to the value passed. It should raise a TypeError
    # if the value can't be converted to a Boolean
    assert check_type_bool('1')
    assert not check_type_bool('0')
    assert check_type_bool('yes')
    assert not check_type_bool('no')
    assert check_type_bool('True')
    assert not check_type_bool('False')
    assert check_type_bool(1)
    assert not check_type_bool(0)
    assert check_type_bool(True)
    assert not check_type_bool(False)
    assert not check_type_bool('ok')
    assert_raises(TypeError, check_type_bool, 'ok')

# Generated at 2022-06-20 16:32:11.644349
# Unit test for function check_required_one_of
def test_check_required_one_of():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.text.converters import (
        to_native
    )

    FAIL = 'validated_required_one_of_failed'

    try:
        mutex_terms = [
            ('mutex0', 'mutex1'),
        ]
        check_mutually_exclusive(mutex_terms, dict(mutex0='foo', mutex1='bar'), options_context=['foo'])
        assert False
    except TypeError as e:
        assert to_native(e) == 'parameters are mutually exclusive: mutex0|mutex1 found in foo'


# Generated at 2022-06-20 16:32:21.286539
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    module = None
    # 1. test parameters has all required params
    parameters = {'one': 1, 'two': 'two', 'three': True}
    required_parameters = ['one', 'two', 'three']
    result = check_missing_parameters(parameters, required_parameters)
    assert [] == result
    # 2. test parameters has missing required params
    parameters = {'one': 1, 'three': True}
    required_parameters = ['one', 'two', 'three']
    is_success = False
    try:
        result = check_missing_parameters(parameters, required_parameters)
    except:
        is_success = True
    assert is_success


# Generated at 2022-06-20 16:32:29.636864
# Unit test for function check_type_dict
def test_check_type_dict():
    dict_str = "k1=v1,k2=v2"
    dict_str2 = "{k1:v1,k2:v2}"
    dict_str3 = "{\"k1\": \"v1\", \"k2\": \"v2\"}"
    dict_dict = {'k1': 'v1', 'k2': 'v2'}
    dict_res1 = check_type_dict(dict_str)
    dict_res2 = check_type_dict(dict_str2)
    dict_res3 = check_type_dict(dict_str3)
    dict_res4 = check_type_dict(dict_dict)
    assert dict_res1 == dict_dict
    assert dict_res2 == dict_dict
    assert dict_res3 == dict_dict
    assert dict_res4 == dict

# Generated at 2022-06-20 16:32:40.412534
# Unit test for function check_type_dict
def test_check_type_dict():
    from ansible.module_utils.common._text import to_text
    from ansible.module_utils.common.collections import is_sequence
    for value in ['{"key": "value"}', 'key=value', 'k1=v1, k2=v2', "{'key': 'value'}", 'k1=v1,k2=v2,k3=v3']:
        # value is a string
        assert isinstance(check_type_dict(value), dict)
        # value is a string with a unicode
        assert isinstance(check_type_dict(to_text(value)), dict)
        # value is a list of dicts
        dict_list = [check_type_dict(value), check_type_dict(value)]
        assert is_sequence(dict_list)

# Generated at 2022-06-20 16:32:50.975714
# Unit test for function check_required_if
def test_check_required_if():
    in_parameters = dict(
        state='present',
        path='/test/path',
        someint=99,
        bool_param=True
    )
    requirement = [
        ['state', 'present', ('path',)],
        ['someint', 99, ('bool_param', 'string_param')]
    ]
    check_required_if(requirement, in_parameters)
    in_parameters_missing_param = dict(
        state='present',
        path='/test/path',
    )
    with pytest.raises(TypeError) as err:
        check_required_if(requirement, in_parameters_missing_param)
    assert "someint is 99 but all of the following are missing: bool_param, string_param" in str(err)
    in_parameters_one

# Generated at 2022-06-20 16:33:00.839047
# Unit test for function check_required_if
def test_check_required_if():
    params = {
     'param1' : 'val1',
     'param2' : 'val2',
     'param3' : 'val3',
     'param4' : 'val4',
     'someint' : 99
    }
    # test for required_if = [['someint', 99, ('param1', 'param2'), False]]
    requirements = [['someint', 99, ('param1', 'param2'), False]]
    results = check_required_if(requirements, params)
    assert not results

    params = {
     'param2' : 'val2',
     'param3' : 'val3',
     'param4' : 'val4',
     'someint' : 99
    }
    results = check_required_if(requirements, params)
    assert len(results) == 1

# Generated at 2022-06-20 16:33:07.122397
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('10B') == 10
    assert check_type_bytes('10K') == 10240
    assert check_type_bytes('10M') == 10485760
    assert check_type_bytes('10G') == 10737418240
    assert check_type_bytes('10T') == 10995116277760
    assert check_type_bytes('10P') == 11258999068426240
    assert check_type_bytes('10E') == 11529215046068469760
    assert check_type_bytes('10KiB') == 10240
    assert check_type_bytes('10MiB') == 10485760
    assert check_type_bytes('10GiB') == 10737418240
    assert check_type_bytes('10TiB') == 10995116277760
    assert check

# Generated at 2022-06-20 16:33:16.230406
# Unit test for function check_type_bool
def test_check_type_bool():
    value1 = 1
    value2 = '1'
    value3 = 'on'
    value4 = 'whatever'
    value5 = 0
    value6 = '0'
    value7 = 'n'
    value8 = 'f'
    value9 = 'false'
    value10 = 'true'
    value11 = 'y'
    value12 = 't'
    value13 = 'yes'
    value14 = 'no'
    value15 = 'off'

    assert check_type_bool(value1) is True
    assert check_type_bool(value2) is True
    assert check_type_bool(value3) is True
    assert check_type_bool(value4) is False
    assert check_type_bool(value5) is False
    assert check_type_bool(value6) is False

# Generated at 2022-06-20 16:33:21.422245
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{"blah": "blah"}') == '{"blah": "blah"}'
    assert check_type_jsonarg('["a", "b"]') == '["a", "b"]'
    assert check_type_jsonarg(['a', 'b']) == '["a", "b"]'
    try:
        check_type_jsonarg(2)
        raise Exception('should not have gotten here')
    except TypeError as e:
        pass


# Generated at 2022-06-20 16:33:23.239177
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('~/temp') == os.path.expanduser('~/temp')


# Generated at 2022-06-20 16:33:24.452430
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-20 16:33:41.231584
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assertEqual(check_type_bytes('10B'), 10)
    assertEqual(check_type_bytes('20b'), 20)
    assertEqual(check_type_bytes('10KB'), 10240)
    assertEqual(check_type_bytes('10kB'), 10240)
    assertEqual(check_type_bytes('10MB'), 10485760)
    assertEqual(check_type_bytes('10mB'), 10485760)
    assertEqual(check_type_bytes('1GB'), 1073741824)
    assertEqual(check_type_bytes('3Gb'), 3221225472)
    assertEqual(check_type_bytes('1TB'), 1099511627776)
    assertEqual(check_type_bytes('1tb'), 1099511627776)

# Generated at 2022-06-20 16:33:52.171389
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by(
        requirements={
            'param1': ['param1_required1', 'param1_required2'],
            'param2': 'param2_required1'},
        parameters={'param1': 'foo', 'param2': 'bar'},
        options_context=['foo', 'bar']) == {}

    try:
        check_required_by(
            requirements={'param1': ['param1_required1', 'param1_required2'],
                           'param2': 'param2_required1'},
            parameters={'param1': 'foo'},
            options_context=['foo', 'bar'])
        assert 'check_required_by did not throw an exception'
    except TypeError:
        pass



# Generated at 2022-06-20 16:34:04.575813
# Unit test for function check_type_dict

# Generated at 2022-06-20 16:34:11.949563
# Unit test for function check_required_together
def test_check_required_together():
    test_params = {'one': 1, 'two': 2, 'three': 3}
    passed_list = [['one', 'two'], ['three']]
    failed_list = [['one', 'two'], ['four']]
    assert check_required_together(passed_list, test_params) == []
    assert check_required_together(failed_list, test_params) == [['one', 'two'], ['four']]


# Generated at 2022-06-20 16:34:18.078818
# Unit test for function check_type_bool
def test_check_type_bool():
    values = [True, False, 1, 0, '1', '0', 'on', 'off', 'true', 'false', 'yes', 'no', 'y', 'n', 't', 'f']
    for value in values:
        assert check_type_bool(value) == boolean(value)
    try:
        check_type_bool('foo')
    except TypeError as e:
        assert 'cannot be converted to a bool' in str(e)


# Generated at 2022-06-20 16:34:22.608164
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('(1,2,3)') == (1, 2, 3)
    assert safe_eval('[False, False, True]') == [False, False, True]
    assert safe_eval('{"a":1}') == {"a": 1}



# Generated at 2022-06-20 16:34:25.983069
# Unit test for function check_type_int
def test_check_type_int():
    try:
        assert check_type_int(1) == 1
        assert check_type_int("1") == 1
        assert check_type_int(2) == 2
        assert check_type_int("3") == 3
    except Exception as e:
        print("test_check_type_int: Exception: " + str(e))
        raise
test_check_type_int()


# Generated at 2022-06-20 16:34:34.554431
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments(dict(a=dict(required=True))) == ['a']
    assert check_required_arguments(dict(a=dict(required=False))) == []
    assert check_required_arguments(dict(a=dict(required=True)), dict(a=1)) == []
    assert check_required_arguments(dict(a=dict(required=True), b=dict(required=True)), dict(a=1,b=1)) == []
    assert check_required_arguments(dict(a=dict(required=True), b=dict(required=True)), dict(a=1)) == ['b']



# Generated at 2022-06-20 16:34:42.687550
# Unit test for function check_type_dict
def test_check_type_dict():
    values = [
        'a=b',
        '{"a": "b", "c": "d"}',
        '\'a\'=b',
        '{\'a\': \'b\', \'c\': \'d\'}',
        'a="b"',
        '{\'a\': "b", \'c\': "d"}',
        'a="b,c"',
        '{\'a\': "b,c", \'c\': "d"}',
        'a=\'b\',c=\'d\'',
        '{\'a\': \'b,c\', \'c\': \'d\'}',
    ]

# Generated at 2022-06-20 16:34:48.626881
# Unit test for function check_type_dict
def test_check_type_dict():
    string = "key=value,key2=value2,key3=value3"
    assert check_type_dict(string) == dict(x.split("=", 1) for x in string.split(","))
    string = '{"key": "value", "key2": "value2", "key3": "value3"}'
    assert check_type_dict(string) == {u'key2': u'value2', u'key3': u'value3', u'key': u'value'}
    string = "value"
    assert check_type_dict(string) == {"value": None}

# Generated at 2022-06-20 16:35:04.678658
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Empty is fine
    check_required_arguments({}, {})
    # Required fields missing
    try:
        check_required_arguments({'x': {'required': True}}, {})
        assert False
    except TypeError:
        pass
    # Required field present
    check_required_arguments({'x': {'required': True}}, {'x': 1})
    # Not required fields missing
    check_required_arguments({'x': {'required': False}}, {})
    # Not required fields present
    check_required_arguments({'x': {'required': False}}, {'x': 1})



# Generated at 2022-06-20 16:35:06.990024
# Unit test for function check_type_raw
def test_check_type_raw():
    value = 'raw'
    rst = check_type_raw(value)
    assert rst == value


# Generated at 2022-06-20 16:35:12.219447
# Unit test for function check_required_together
def test_check_required_together():
    # Create list of parameters
    parameters = ['ip_version', 'cidr', 'mask', 'network']
    # Create list of terms to check
    terms = [['ip_version', 'cidr', 'mask'], ['ip_version', 'cidr', 'network']]
    # Raise exception if one parameter from a list of terms is missing in the parameters
    assert check_required_together(terms, parameters) == []



# Generated at 2022-06-20 16:35:18.827584
# Unit test for function check_required_by

# Generated at 2022-06-20 16:35:30.793226
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool(1) is True
    assert check_type_bool(0) is False
    assert check_type_bool('1') is True
    assert check_type_bool('0') is False
    assert check_type_bool('yes') is True
    assert check_type_bool('no') is False
    assert check_type_bool('true') is True
    assert check_type_bool('false') is False
    assert check_type_bool('t') is True
    assert check_type_bool('f') is False
    assert check_type_bool('y') is True
    assert check_type_bool('n') is False
    assert check_type_bool('on') is True
    assert check_type_bool('off') is False
    assert check_type_bool('true ') is True
    assert check

# Generated at 2022-06-20 16:35:38.419231
# Unit test for function check_required_by
def test_check_required_by():
    result = check_required_by({'required': {'key1'}})
    # returns dictionary if either key or value is missing
    assert type(result) is dict
    result = check_required_by({'key1': 'key2'})
    # returns dictionary if either key or value is missing
    assert type(result) is dict
    # returns None if required key and value are both found
    result = check_required_by({'key1': {'key2'}})
    assert result is None
    # returns dictionary of missing keys if required key exists and missing keys are found
    result = check_required_by({'key1': {'key2', 'key3'}})
    assert result == {'key1': ['key2', 'key3']}
    # returns None if key is missing and no checking is done