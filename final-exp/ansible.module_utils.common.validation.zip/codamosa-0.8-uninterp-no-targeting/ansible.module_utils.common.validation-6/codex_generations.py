

# Generated at 2022-06-20 16:26:33.950115
# Unit test for function check_type_str
def test_check_type_str():
    try:
        check_type_str(None)
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError not raised')

    value = 'test_value'
    assert value == check_type_str(value)
    assert value == check_type_str(value, False)
    assert value == check_type_str(value, True)
    assert value == check_type_str(value, True, 'param', 'prefix')

    value = 5
    assert '5' == check_type_str(value, True)
    assert '5' == check_type_str(value, True, 'param', 'prefix')
    try:
        check_type_str(value)
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError not raised')
   

# Generated at 2022-06-20 16:26:38.058447
# Unit test for function check_type_bits
def test_check_type_bits():
    assert isinstance(check_type_bits('1Mb'), int)
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == human_to_bytes('1Mb', isbits=True)



# Generated at 2022-06-20 16:26:48.719884
# Unit test for function check_type_float
def test_check_type_float():
    assert_equal(check_type_float(1.1), 1.1)
    assert_equal(check_type_float('1.1'), 1.1)
    assert_equal(check_type_float(1), 1.0)
    assert_equal(check_type_float(None), 'None is not a float')
    if PY2:
        assert_equal(check_type_float(b'1.1'), '1.1 is not a float')
    assert_equal(check_type_float('one'), 'one is not a float')
    assert_equal(check_type_float([]), '[] is not a float')
    assert_equal(check_type_float([]), '[] is not a float')



# Generated at 2022-06-20 16:26:54.836118
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # check_required_one_of(terms, parameters, options_context=None)
    test_para = {'param1':'value1', 'param2':'value2'}
    test_terms = [['param1'],['param2'],['param3']]
    try:
        check_required_one_of(test_terms, test_para)
    except:
        assert False

    test_terms = [['param3'],['param4']]
    try:
        check_required_one_of(test_terms, test_para)
        assert False
    except:
        pass

    test_terms = [['param1','param2','param3']]
    try:
        check_required_one_of(test_terms, test_para)
    except:
        assert False


# Generated at 2022-06-20 16:27:02.182292
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2})
    check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 1, 'c': 2})

    try:
        check_mutually_exclusive([['a', 'b'], ['c', 'b']], {'a': 1, 'b': 2})
    except TypeError as e:
        assert to_native(e) == "parameters are mutually exclusive: a|b, c|b"


# Generated at 2022-06-20 16:27:12.870681
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path(b'/tmp') == '/tmp'
    assert check_type_path(b"~") == "/root"
    assert check_type_path(b"~/test") == "/root/test"
    assert check_type_path(b"$HOME/test") == "/root/test"
    assert check_type_path(b"${HOME}/test") == "/root/test"
    assert check_type_path(b"${HOME}/test/..") == "/root"
    assert check_type_path(b"$HOME/test../") == "/root"
    assert check_type_path(b"${HOME}/test../") == "/root"
    assert check_type_path(b"${HOME}/test/../") == "/root"

# Generated at 2022-06-20 16:27:19.888882
# Unit test for function check_type_path
def test_check_type_path():
    """
    Unit test for function check_type_path
    """
    path = "../hello"
    assert os.path.expanduser(os.path.expandvars(path)) == check_type_path(path)
    path = "/hello"
    assert os.path.expanduser(os.path.expandvars(path)) == check_type_path(path)
    path = "~/hello"
    assert os.path.expanduser(os.path.expandvars(path)) == check_type_path(path)
    path = r"\hello"
    assert os.path.expanduser(os.path.expandvars(path)) == check_type_path(path)
    path = "hello"

# Generated at 2022-06-20 16:27:31.647429
# Unit test for function check_type_float
def test_check_type_float():
    """
    Basic unit test for function check_type_float
    """
    #Test type float
    value = 1.5
    result = check_type_float(value)
    assert result == value

    #Test type int
    value = 1
    result = check_type_float(value)
    assert result == value
    
    #Test type string
    value = "1.5"
    result = check_type_float(value)
    assert result == value

    #Test type byte
    value = b"1.5"
    result = check_type_float(value)
    assert result == value
    
    #Test exception
    value = [1, 2]
    try:
        check_type_float(value)
        ok = False
    except TypeError as e:
        ok = True

# Generated at 2022-06-20 16:27:39.345604
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Prepare
    args= {"arg1": {"required": True}}
    params = {"arg1": "value1"}
    # Call
    result=check_required_arguments(args,params)
    # Verify
    assert(result == [])

    # Prepare
    args= {"arg1": {"required": True}, "arg2": {"required":True}}
    params = {"arg1": "value1"}
    # Call
    result=check_required_arguments(args,params)
    # Verify
    assert(result == ["arg2"])


# Generated at 2022-06-20 16:27:46.479755
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # if terms is empty then return result
    assert check_required_one_of(None, {}) == []
    # if tuple (term1, term2) and (term1, term2, term3) provided,
    # it raises TypeError if both are missing
    try:
        check_required_one_of([('term1', 'term2'), ('term1', 'term2', 'term3')], {}) == []
    except TypeError:
        pass
    # if term1 and term3 provided, it raises TypeError because term2 is missing from provided terms
    try:
        check_required_one_of([('term1', 'term2'), ('term1', 'term2', 'term3')], {'term1': 'value1', 'term3': 'value3'})
    except TypeError:
        pass
    # if

# Generated at 2022-06-20 16:27:59.701896
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():

    # check_mutually_exclusive(terms, parameters)  is a function that returns empty list
    # if the check passed, or raises TypeError if the check fails
    terms1 = [["aaa", "bbb"], ["ccc", "ddd"]]
    parameters1 = {"aaa": 1, "bbb": 1, "eee": 1, "fff": 1}
    try:
        assert check_mutually_exclusive(terms1, parameters1) == []
    except TypeError:
        raise Exception("check_mutually_exclusive did not perform as expected")

    parameters2 = {"aaa": 1, "bbb": 1, "ccc": 1, "ddd": 1}

# Generated at 2022-06-20 16:28:03.699270
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    class MockString(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return self.value


# Generated at 2022-06-20 16:28:08.423014
# Unit test for function check_required_by
def test_check_required_by():
    module_args = dict(
        shared_secret='foo',
        backup_create='bar',
        backup='baz',
        backup_window='quz'
    )
    requirements = dict(backup_create=['backup'],
                        backup_window=['backup'],
                        backup=['shared_secret'])

    context = []
    assert check_required_by(requirements, module_args, context) == dict(backup=['shared_secret'])



# Generated at 2022-06-20 16:28:20.249971
# Unit test for function count_terms
def test_count_terms():
    """Unit tests for count_terms function."""
    assert count_terms("test", {"t": 0, "e": 1, "s": 2, "t": 3}) == 1
    assert count_terms("test", {"t": 0, "e": 1, "s": 2, "t": 3, "test": 4}) == 2
    assert count_terms("test", {"test": 4}) == 1

    assert count_terms("test", {"test": "4"}) == 1
    assert count_terms("4", {"test": "4"}) == 0

    assert count_terms("test", {"test": 4, "testing": 5}) == 1
    assert count_terms(["test", "test2"], {"test": 4, "testing": 5}) == 1

# Generated at 2022-06-20 16:28:32.395695
# Unit test for function check_required_together
def test_check_required_together():
    terms = [
        ('a', 'b'),
        ('c', 'd'),
        ('e', 'f'),
        ('a', 'c', 'e')
    ]
    # test case 1: all parameters are valid without duplicates
    parameters = dict(a=1, b=2, c=3, d=4, e=5, f=6)
    assert [] == check_required_together(terms, parameters)

    # test case 2: a is duplicate, e and f are missing
    parameters = dict(a=1, a=2, b=3, d=4, c=5)
    expected_result = [('a', 'c', 'e')]
    assert expected_result == check_required_together(terms, parameters)

    # test case 3: a is duplicate, d is missing

# Generated at 2022-06-20 16:28:37.604776
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(['a', 'b']) == ['a', 'b']
    assert check_type_list('a') == ['a']
    assert check_type_list('a,b') == ['a', 'b']
    assert check_type_list(0) == ['0']
    assert check_type_list(1.1) == ['1.1']
    assert check_type_list(None) == ['None']
    # Test only with py26
    if sys.version_info[:2] == (2, 6):
        assert True == False



# Generated at 2022-06-20 16:28:39.053354
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('a', dict(a=1, b=1)) == 1


# Generated at 2022-06-20 16:28:39.681136
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    pass


# Generated at 2022-06-20 16:28:46.690545
# Unit test for function count_terms
def test_count_terms():
    """Function to verify that the numbers match"""
    # pylint: disable=missing-docstring
    assert count_terms(None, None) == 0
    assert count_terms('test', {'test': 'value'}) == 1
    assert count_terms(['test'], {'test': 'value'}) == 1
    assert count_terms(['test'], {'test1': 'value', 'test2': 'value'}) == 0
    assert count_terms(['test1', 'test2'], {'test1': 'value', 'test2': 'value'}) == 2



# Generated at 2022-06-20 16:28:52.044607
# Unit test for function check_type_int
def test_check_type_int():
    assert isinstance(check_type_int(1), int)
    with pytest.raises(TypeError):
        check_type_int([1])
    with pytest.raises(TypeError):
        check_type_int('1.0')
    with pytest.raises(TypeError):
        check_type_int(1.0)

# FIXME: The param and prefix parameters here are coming from AnsibleModule._check_type_path()
#        which is using those for the warning messaged based on path conversion warning settings.
#        Not sure how to deal with that here since we don't have config state to query.

# Generated at 2022-06-20 16:29:05.824186
# Unit test for function check_type_dict
def test_check_type_dict():
    data = "{'name':'A'}"
    result = check_type_dict(data)
    assert isinstance(result, dict)
    assert result['name'] == 'A'
    result = check_type_dict("name=A")
    assert isinstance(result, dict)
    assert result['name'] == 'A'
    with pytest.raises(TypeError):
        check_type_dict(1)
    with pytest.raises(TypeError):
        check_type_dict("name=A,age=10,name=B")
    with pytest.raises(TypeError):
        check_type_dict("name")


# Generated at 2022-06-20 16:29:10.074395
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M')
    assert check_type_bytes('1m')
    assert check_type_bytes('1g')
    assert check_type_bytes('1G')
    assert check_type_bytes('1 t')
    assert check_type_bytes('1 T')
    assert check_type_bytes('1 b')
    assert check_type_bytes('1 B')
    assert check_type_bytes('1 kb')
    assert check_type_bytes('1 kB')
    assert check_type_bytes('1 K')
    assert check_type_bytes(1)



# Generated at 2022-06-20 16:29:21.631171
# Unit test for function check_type_list
def test_check_type_list():
    for input in [
        '',
        'a',
        'a,b,c',
        'a, b, c',
        [1],
        [1, 2, 3]
    ]:
        assert check_type_list(input)

# Generated at 2022-06-20 16:29:25.693108
# Unit test for function check_type_int
def test_check_type_int():
    # check type int with string type
    assert check_type_int("123") == 123

    # check type int with int type
    assert check_type_int(123) == 123

    # check type int with float
    try:
        check_type_int(1.12)
        assert False
    except TypeError:
        assert True
    except:
        assert False

    # check type int with float type string
    try:
        check_type_int("1.12")
        assert False
    except TypeError:
        assert True
    except:
        assert False

    # check type int with true
    try:
        check_type_int(True)
        assert False
    except TypeError:
        assert True
    except:
        assert False

    # check type int with true type string

# Generated at 2022-06-20 16:29:30.362392
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    check_mutually_exclusive(
        [['name', 'id'], ['freeform_tags', 'defined_tags']],
        {'name': 'foo', 'freeform_tags': {'a': 'b'}}
    )



# Generated at 2022-06-20 16:29:40.476589
# Unit test for function check_required_if
def test_check_required_if():
    # Test variable
    requirements_list = [
        ['state', 'present', ('path',), True]
    ]
    parameters_dict = {
        'state': 'present',
        'path': '/root/testfile'
    }

    # Test function
    result = check_required_if(requirements_list, parameters_dict)

    assert result == [], 'check_required_if should return results.'

    # Test function
    requirements_list = [
        ['state', 'present', ('path',), True]
    ]
    parameters_dict = {
        'state': 'present',
        'path': '/root/testfile',
        'mode': '0755'
    }

    result = check_required_if(requirements_list, parameters_dict)


# Generated at 2022-06-20 16:29:50.530845
# Unit test for function check_required_arguments
def test_check_required_arguments():
    import tempfile

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-20 16:30:00.040683
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms= [['password', 'ssh_key_file'],'enabled']
    parameters= {'username': 'bob', 'password': '123'}
    assert not check_required_one_of(terms=terms,parameters=parameters)
    parameters= {'enabled':'yes'}
    assert not check_required_one_of(terms=terms,parameters=parameters)
    parameters= {'username': 'bob', 'password': '123','enabled':'yes'}
    assert not check_required_one_of(terms=terms,parameters=parameters)
    parameters= {'username': 'bob', 'ssh_key_file': '/root/test.pem','enabled':'yes'}
    assert not check_required_one_of(terms=terms,parameters=parameters)

# Generated at 2022-06-20 16:30:04.302479
# Unit test for function count_terms
def test_count_terms():
    ''' test the count_terms function '''
    terms = ['a', 'b', 'c']
    parameters = {'a': 'present', 'b': 'present', 'c': 'present'}
    result = count_terms(terms, parameters)
    assert result == 3



# Generated at 2022-06-20 16:30:10.449560
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(u'1.0') == 1.0
    assert check_type_float(1) == 1.0
    try:
        check_type_float(None)
    except TypeError:
        pass
    except Exception:
        assert False, "Invalid exception thrown"
    else:
        assert False, "No exception thrown"



# Generated at 2022-06-20 16:30:17.396980
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(2) == 2
    assert check_type_int("3") == 3
    assert check_type_int("3.0") == 3
    with pytest.raises(TypeError):
        check_type_int("string")



# Generated at 2022-06-20 16:30:22.417664
# Unit test for function check_type_dict
def test_check_type_dict():
    a = {'a':'b'}
    b = {"a":"b"}
    c = "key=val"
    d = "key='val'"
    e = '''key='val, with spaces' '''
    f = '''key2=val2,key1= val1'''

    assert(check_type_dict(a) == {'a': 'b'})
    assert(check_type_dict(b) == {'a': 'b'})
    assert(check_type_dict(c) == {'key': 'val'})
    assert(check_type_dict(d) == {'key': "val"})
    assert(check_type_dict(e) == {'key': "val, with spaces"})

# Generated at 2022-06-20 16:30:33.277277
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # 1. test required one of several
    parameters = {'one': 1, 'two': 2, 'three': 3, 'four': 4}
    terms = [['one', 'three'], ['two', 'four']]
    check_required_one_of(terms, parameters)

    # 2. test required one of several, should fail
    parameters = {'one': 1, 'two': 2, 'three': 3}
    terms = [['one', 'three'], ['two', 'four']]
    try:
        check_required_one_of(terms, parameters)
    except TypeError as e:
        pass
    else:
        assert False, 'Should fail, required one of groups do not match'

    # 3. test required one of one

# Generated at 2022-06-20 16:30:40.249639
# Unit test for function check_type_int
def test_check_type_int():
	if check_type_int(12) == 12:
		print("check_type_int test 1 passed")
	if check_type_int("12") == 12:
		print("check_type_int test 2 passed")
	if check_type_int("pear") == None:
		print("check_type_int test 3 passed")
		
		


# Generated at 2022-06-20 16:30:44.536396
# Unit test for function check_type_dict
def test_check_type_dict():
    def verify_dict(value, expected):
        result = check_type_dict(value)
        assert result == expected, '%s != %s' % (result, expected)

    # Test basic parsing to a dictionary
    verify_dict("key=value", {"key": "value"})
    verify_dict("key1=value1,key2=value2", {"key1": "value1", "key2": "value2"})
    verify_dict("key1=value1,key2=value2,key3=value3", {"key1": "value1", "key2": "value2", "key3": "value3"})

    # Test lists

# Generated at 2022-06-20 16:30:55.626051
# Unit test for function safe_eval
def test_safe_eval():
    # successful eval
    assert safe_eval('{}') == {}
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(True, False)') == (True, False)
    assert safe_eval('-123') == -123
    assert safe_eval('1 == 1') is True
    assert safe_eval('a', locals={'a': 'Hello, World!'}) == 'Hello, World!'

    # value is not string
    assert safe_eval(123) == 123

    # string contains method calls
    assert safe_eval('foo.bar()') == 'foo.bar()'

    # string contains imports
    assert safe_eval('import foo') == 'import foo'



# Generated at 2022-06-20 16:31:07.113157
# Unit test for function check_required_if

# Generated at 2022-06-20 16:31:14.258672
# Unit test for function check_required_together
def test_check_required_together():
    terms=[[u'state', u'port'], [u'state', u'protocol'], [u'state', u'path']]
    parameters = {u'provider': {u'host': u'localhost', u'port': u'5001', u'password': None, u'username': u'admin'}, u'name': u'Test', u'path': u'/some/path', u'protocol': u'http'}
    options_context=None
    results=check_required_together(terms,parameters,options_context)
    print(results)

# Generated at 2022-06-20 16:31:18.680242
# Unit test for function check_type_bytes
def test_check_type_bytes():
    for item in ['1', '1kb', '1mb', '1gb', '1tb', '1pb']:
        assert check_type_bytes(item) is not None
    for item in [1, 1.0, [], {}, ()]:
        try:
            check_type_bytes(item)
            raise Exception
        except TypeError:
            pass



# Generated at 2022-06-20 16:31:24.918373
# Unit test for function check_type_bool
def test_check_type_bool():
    str1 = 'yes'
    str2 = 'no'
    str3 = 'maybe'

    assert(check_type_bool(str1))
    assert(not check_type_bool(str2))

    # FIXME: We probably don't want to allow this
    assert(check_type_bool(str3))


# Generated at 2022-06-20 16:31:38.021389
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg("{\"a\":[1, 2, 3]}") == "{\"a\":[1, 2, 3]}"
    assert check_type_jsonarg("[1, 2, 3]") == "[1, 2, 3]"
    assert check_type_jsonarg("{\"a\":1, \"b\":2}") == "{\"a\":1, \"b\":2}"
    a = {'a': ['b']}
    assert check_type_jsonarg(a) == "{\"a\":[\"b\"]}"
    a = ['b']
    assert check_type_jsonarg(a) == "[\"b\"]"
    a = 1
    assert check_type_jsonarg(a) == "1"


# Generated at 2022-06-20 16:31:43.505213
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('42') == 42
    assert check_type_bytes(42) == 42
    assert check_type_bytes('42k') == 43008
    assert check_type_bytes('1kb') == 1000
    assert check_type_bytes('1k', binary=False) == 1024
    assert check_type_bytes('42kb', binary=False) == 43520
    assert check_type_bytes('42K') == 43008
    assert check_type_bytes('42K', binary=False) == 43520
    assert check_type_bytes('42M') == 44040192
    assert check_type_bytes('42M', binary=False) == 45097156608
    assert check_type_bytes('42G') == 4503599627370496
    assert check_type_bytes('42T', binary=False) == 4

# Generated at 2022-06-20 16:31:46.715356
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'a': 1, 'b': 2}
    required_params = ['a', 'b', 'c']
    result = check_missing_parameters(parameters=parameters, required_parameters=required_params)
    print(result)


# Generated at 2022-06-20 16:31:56.650364
# Unit test for function check_type_float
def test_check_type_float():
    # Value is a float
    assert check_type_float(1.1) == 1.1
    # Value is an int
    assert check_type_float(1) == 1.0
    # Value is a string
    assert check_type_float('1.0') == 1.0
    assert check_type_float('1') == 1.0
    # Value is bytes
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1') == 1.0
    # Value is not an int or float
    with pytest.raises(TypeError):
        check_type_float('answer')


# Generated at 2022-06-20 16:32:05.111297
# Unit test for function check_required_by
def test_check_required_by():
    """Simple unittest to check the check_required_by function

    """
    spec = {"a": ["c", "d"],
            "v": ["e", "f"],
            "x": "y"}
    #missing_req = check_required_by(spec)
    #assert len(missing_req) == 3, missing_req
    missing_req = check_required_by(spec, {"v": "e"})
    assert len(missing_req) == 2, missing_req
    assert "f" in missing_req["v"]
    missing_req = check_required_by(spec, {"v": "e", "c": "e"})
    assert len(missing_req) == 1, missing_req
    assert "d" in missing_req["a"]


# Generated at 2022-06-20 16:32:08.955440
# Unit test for function check_type_raw
def test_check_type_raw():
    ''' check_type_raw should return the value sent to it '''
    assert check_type_raw('foo') == 'foo'
    assert check_type_raw(1) == 1
    assert check_type_raw([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-20 16:32:18.310873
# Unit test for function check_required_one_of
def test_check_required_one_of():
    '''
    Test function check_required_one_of for specific use cases
    '''
    terms = [('a', 'b', 'c')]
    parameters = {'a': True, 'b': False, 'd': True}
    result = check_required_one_of(terms, parameters)
    assert len(result) == 0

    parameters = {'a': False, 'b': False, 'd': False}
    try:
        result = check_required_one_of(terms, parameters)
    except TypeError as e:
        assert True
    else:
        assert False



# Generated at 2022-06-20 16:32:23.010985
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    with pytest.raises(TypeError):
        check_type_int('a')
    with pytest.raises(TypeError):
        check_type_int(None)


# Generated at 2022-06-20 16:32:29.464736
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {
        'username': 'user1',
        'password': 'pass1'
    }
    terms = [
       ('username', 'password')
    ]
    options_context = [
        'parameters'
    ]
    assert check_required_together(terms, parameters, options_context) == []


# Generated at 2022-06-20 16:32:35.507755
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0
    assert check_type_float(0) == 0.0
    assert check_type_float(0.0) == 0.0
    assert check_type_float("1") == 1.0
    assert check_type_float(b"1") == 1.0
    assert check_type_float("1.1") == 1.1
    assert check_type_float("foo") == None
    assert check_type_float("1,1") == None



# Generated at 2022-06-20 16:32:44.942709
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('10KB') == 10240
    assert check_type_bytes(10240) == 10240
    assert check_type_bytes('10MB') == 10485760
    assert check_type_bytes('10GB') == 10737418240
    with pytest.raises(TypeError):
        check_type_bytes(10.0)



# Generated at 2022-06-20 16:32:55.395165
# Unit test for function check_type_str
def test_check_type_str():
    """Verify that the function check_type_str returns original value if it is a string, the value converted to a string if allow_conversion=True,
    or raises a TypeError if allow_conversion=False."""
    assert check_type_str('string') == 'string'
    assert check_type_str(b'bytes', allow_conversion=True) == 'bytes'
    assert check_type_str(True) == 'True'
    assert check_type_str(False) == 'False'
    assert check_type_str(3) == '3'

    try:
        check_type_str(3)
        pytest.fail()
    except TypeError:
        assert True


# Generated at 2022-06-20 16:32:57.874818
# Unit test for function check_type_list
def test_check_type_list():

    
    assert check_type_list('a,b,c,d') == ['a','b','c','d']
    assert check_type_list('a') == ['a']
    assert check_type_list(1) == ['1']
    


# Generated at 2022-06-20 16:33:08.891092
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list([0,1,2,3]) == [0,1,2,3]
    assert check_type_list("0,1,2,3") == ['0','1','2','3']
    assert check_type_list("0") == ['0']

# Generated at 2022-06-20 16:33:19.077682
# Unit test for function check_required_together
def test_check_required_together():
    # None check
    assert check_required_together(None, None) == []

    # Zero check
    assert check_required_together([], {}) == []

    # One set check
    assert check_required_together([['foo', 'bar']], {'bar':'test'}) == []

    # Two set check
    assert check_required_together([['foo'], ['bar']], {'foo':'test', 'bar':'test'}) == []

    # One of set check
    assert check_required_together([['foo', 'bar'], ['foo', 'baz']], {'bar':'test', 'baz':'test'}) == []

    # No param in set check
    try:
        check_required_together([['foo', 'bar']], {})
        assert False
    except TypeError:
        pass

# Generated at 2022-06-20 16:33:24.380314
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    test_value1 = '{ "name": "testing123"}'
    test_value2 = {'name': 'testing456'}
    if check_type_jsonarg(test_value1) == '{ "name": "testing123"}':
        assert True
    else:
        assert False
    if check_type_jsonarg(test_value2) == '{ "name": "testing456"}':
        assert True
    else:
        assert False


# Generated at 2022-06-20 16:33:27.951216
# Unit test for function check_type_float
def test_check_type_float():
    assert(check_type_float(None) is None)
    assert(check_type_float(1.1) == 1.1)
    assert(check_type_float(1) == 1.0)
    assert(check_type_float(u"1.1") == 1.1)
    assert(check_type_float(b"1.1") == 1.1)
    assert(check_type_float("1.1") == 1.1)
    assert(isinstance(check_type_float(1.1), float))
    try:
        check_type_float([])
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-20 16:33:38.049760
# Unit test for function check_required_one_of
def test_check_required_one_of():
    check_required_one_of([('a', 'b')], {'a': None}) == []
    check_required_one_of([('a', 'b')], {'b': None}) == []
    check_required_one_of([('a', 'b', 'c')], {'a': None, 'b': None}) == []
    check_required_one_of([('a', 'b', 'c')], {'a': None, 'b': None, 'c': None}) == []
    check_required_one_of([('a', 'b')], {'c': None}, ['options-context']) == [('a', 'b')]
    check_required_one_of([('a', 'b')], {'c': None}, ['options-context']) == [('a', 'b')]

# Generated at 2022-06-20 16:33:50.052898
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{"foo":"bar"}') == jsonify({'foo': 'bar'})
    assert check_type_jsonarg(json.dumps({'foo': 'bar'}, ensure_ascii=False)) == jsonify({'foo': 'bar'})
    assert check_type_jsonarg(['foo', 'bar']) == jsonify(['foo', 'bar'])
    with pytest.raises(TypeError):
        check_type_jsonarg(5.5)



# Generated at 2022-06-20 16:33:51.467232
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw("") == "", "Unable to return raw"


# Generated at 2022-06-20 16:34:06.461931
# Unit test for function safe_eval
def test_safe_eval():
    #test for literal_eval exception
    assert safe_eval("'example'") == "example"
    assert safe_eval("[1,2,3]") == [1,2,3]
    assert safe_eval(json.dumps({"a": "b", "c": "d"})) == {"a": "b", "c": "d"}
    assert safe_eval("1") == 1
    assert safe_eval("1.2") == 1.2
    assert safe_eval("True") is True
    assert safe_eval(".1234") == .1234
    assert safe_eval("-5") == -5
    #fail fast - method calls to modules are not allowed
    assert safe_eval("os.getpid()") == "os.getpid()"
    #fail fast - imports are not allowed
    assert safe_eval

# Generated at 2022-06-20 16:34:12.471805
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('on') == True
    assert check_type_bool('1') == True
    assert check_type_bool(1) == True
    assert check_type_bool('off') == False
    assert check_type_bool('0') == False
    assert check_type_bool(0) == False
    assert check_type_bool('true') == True
    assert check_type_bool('false') == False
    assert check_type_bool(True) == True
    assert check_type_bool(False) == False
    assert check_type_bool(True) is True
    assert check_type_bool(False) is False
    assert check_type_bool(True) == True
    assert check_type_bool(False) == False
    assert check_type_bool(True) == True
    assert check_

# Generated at 2022-06-20 16:34:17.490545
# Unit test for function check_type_bytes
def test_check_type_bytes():
    """
    Test for function check_type_bytes
    """
    assert check_type_bytes('1 KB') == 1024
    assert check_type_bytes('1 kB') == 1000
    assert check_type_bytes(
        '1.5 KB') == 1536
    assert check_type_bytes(
        '1.5 kB') == 1500



# Generated at 2022-06-20 16:34:26.229721
# Unit test for function check_type_bool
def test_check_type_bool():
    result = check_type_bool('1')
    assert result == True
    result = check_type_bool('on')
    assert result == True
    result = check_type_bool(1)
    assert result == True
    result = check_type_bool('0')
    assert result == False
    result = check_type_bool(0)
    assert result == False

    try:
        check_type_bool('foo')
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-20 16:34:33.414578
# Unit test for function check_type_dict
def test_check_type_dict():
    """Unit test for function check_type_dict"""
    # Case1:
    # Value is a dict
    test_dict = {'key1': 'value1', 'key2': 'value2'}
    dict1 = check_type_dict(test_dict)
    assert dict1 is test_dict

    # Case2:
    # Value is a string
    dict2 = check_type_dict('{"key1": "value1", "key2": "value2"}')
    assert dict2 == test_dict

    # Case3:
    # Value is a string, with key=value
    dict3 = check_type_dict('key1=value1, key2=value2')
    assert dict3 == test_dict

    # Case4:
    # Value is a string, with key=value, with more space
    dict4

# Generated at 2022-06-20 16:34:35.449095
# Unit test for function count_terms
def test_count_terms():
    terms = ['a', 'b']
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert count_terms(terms, parameters) == 2



# Generated at 2022-06-20 16:34:43.361155
# Unit test for function count_terms
def test_count_terms():
    assert(count_terms("foo", {"bar": "baz", "foo": "bar"})) == 1
    assert(count_terms("foo", {"bar": "baz", "foo": "bar", "foo": "baz"})) == 1
    assert(count_terms("foo", {"bar": "baz", "foo": "bar"}) == 1)
    assert(count_terms("", {"bar": "baz", "foo": "bar"}) == 0)
    assert(count_terms("foo", {}) == 0)
    assert(count_terms(["foo"], {"bar": "baz", "foo": "bar", "foo": "baz"})) == 1
    assert(count_terms(["foo", "bar"], {"bar": "baz", "foo": "bar", "foo": "baz"})) == 2
   

# Generated at 2022-06-20 16:34:48.504986
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    # Test for string
    try:
        check_type_jsonarg('{"a": 1}')
    except TypeError:
        raise
    # Test for dict
    try:
        check_type_jsonarg({'a': 1})
    except TypeError:
        raise
    # Test for exception for unexpected type
    try:
        check_type_jsonarg(('a', 1))
    except TypeError:
        pass


# Generated at 2022-06-20 16:34:59.738165
# Unit test for function check_required_by
def test_check_required_by():
    """Parameter requirements"""

    # simple case
    requirements = dict(a=['b'])
    parameters = dict(a='foo')
    assert check_required_by(requirements, parameters) == dict(a=['b'])
    parameters['b'] = 'foo'
    assert check_required_by(requirements, parameters) == {}

    # multiple requirements (with single-item list)
    requirements = dict(a=('b',), c=('d',))
    parameters = dict(a='foo', c='foo')
    assert check_required_by(requirements, parameters) == dict(a=['b'], c=['d'])
    parameters['b'] = 'foo'
    parameters['d'] = 'foo'
    assert check_required_by(requirements, parameters) == {}



# Generated at 2022-06-20 16:35:04.589404
# Unit test for function check_required_by
def test_check_required_by():
    params = {'a': 'bar', 'b': 'foo'}
    reqs = {'a': ('b', 'c'), 'd': ('b', 'c')}
    result = check_required_by(requirements=reqs, parameters=params)
    assert result == {'a': ['c']}



# Generated at 2022-06-20 16:35:24.391794
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict({'one': 1, 'two': 2}) == {'one': 1, 'two': 2}
    assert check_type_dict('one=1,two=2') == {'one': '1', 'two': '2'}
    assert check_type_dict('one=1, two=2') == {'one': '1', ' two': '2'}
    assert check_type_dict('one=1,two=2,') == {'one': '1', 'two': '2', '': ''}
    assert check_type_dict('one=1,\'two\'=2') == {'one': '1', 'two': '2'}
    assert check_type_dict('one=1,"two"=2') == {'one': '1', 'two': '2'}
   

# Generated at 2022-06-20 16:35:31.431963
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float("1") == 1.0
    assert check_type_float(b"1") == 1.0
    with pytest.raises(TypeError) as exc:
        check_type_float(['1'])
    assert exc.value.args[0] == "list objects cannot be converted to a float"



# Generated at 2022-06-20 16:35:39.027780
# Unit test for function check_type_bool
def test_check_type_bool():
    assert check_type_bool('1')
    assert check_type_bool('True')
    assert check_type_bool('TRUE')
    assert check_type_bool('true')
    assert check_type_bool('0') == False
    assert check_type_bool('False') == False
    assert check_type_bool('FALSE') == False
    assert check_type_bool('false') == False
    assert check_type_bool(1)
    assert check_type_bool(0) == False
    assert check_type_bool(True)
    assert check_type_bool(False) == False
    assert check_type_bool('n') == False
    assert check_type_bool('f') == False
    assert check_type_bool('N') == False
    assert check_type_bool('F') == False
   