

# Generated at 2022-06-20 16:26:18.729247
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg('{"foo": "bar"}') == '{"foo": "bar"}'
    assert check_type_jsonarg(['{"foo": "bar"}']) == '["{\\"foo\\": \\"bar\\"}"]'
    assert check_type_jsonarg(['{"foo": "bar"}', '{"baz": "qux"}']) == '["{\\"foo\\": \\"bar\\"}", "{\\"baz\\": \\"qux\\"}"]'


# Generated at 2022-06-20 16:26:24.486742
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():

    # test empty values
    options_context = []
    terms = None
    parameters = None
    assert check_mutually_exclusive(terms, parameters, options_context) == []

    # test expected
    options_context = []
    terms = [['api_key'],
             ['username', 'password']]
    parameters = {'api_key': 'value',
                  'state': 'present'}
    assert check_mutually_exclusive(terms, parameters, options_context) == []

    # test failed
    options_context = []
    terms = [['api_key'],
             ['username', 'password']]
    parameters = {'api_key': 'value',
                  'username': 'value',
                  'password': 'value',
                  'state': 'present'}


# Generated at 2022-06-20 16:26:36.782891
# Unit test for function check_type_str
def test_check_type_str():
    from ansible.module_utils._text import to_text
    expected = "Ansible"
    for value in (expected, u(expected), b(expected)):
        assert check_type_str(value) == to_text(expected)

    assert check_type_str(1, allow_conversion=True) == '1'
    assert check_type_str(['a'], allow_conversion=True) == "'a'"
    assert check_type_str([None], allow_conversion=True) == 'None'

    with pytest.raises(TypeError):
        check_type_str(1)
    with pytest.raises(TypeError):
        check_type_str(['a'])
    with pytest.raises(TypeError):
        check_type_str([None])



# Generated at 2022-06-20 16:26:39.683440
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by(
        {'key': ['other']},
        {'key': 'value', 'key2': 'value2', 'key3': 'value3'},
        ['top level']
    ) is None



# Generated at 2022-06-20 16:26:51.466407
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # Validation tests
    parameters = {'a': 1, 'b': 2, 'd': 4}
    terms = [('a', 'b'), ('c', 'd')]  # Only one of ('a', 'b') OR ('c', 'd') should be found
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': 1, 'b': 2}
    assert check_required_one_of(terms, parameters) == []
    assert check_required_one_of([('a')], parameters) == []

    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    terms = [('a', 'b'), ('c', 'd')]

# Generated at 2022-06-20 16:26:58.150776
# Unit test for function check_required_together
def test_check_required_together():
    terms = [
        ("a", "b"),
        ("c",)
    ]
    parameters = {
        "a": "test",
        "c": "test"
    }
    assert check_required_together(terms, parameters) == []
    parameters = {
        "a": "test"
    }
    try:
        check_required_together(terms, parameters)
    except TypeError:
        pass
    else:
        assert False



# Generated at 2022-06-20 16:27:09.983772
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("") == {}
    assert check_type_dict("k1=v1") == {'k1': 'v1'}
    assert check_type_dict("k1=v1, k2=v2") == {'k1': 'v1', 'k2': 'v2'}
    assert check_type_dict("k1='v1', k2='v2'") == {'k1': 'v1', 'k2': 'v2'}
    assert check_type_dict("k1=\"v1\", k2=\"v2\"") == {'k1': 'v1', 'k2': 'v2'}

# Generated at 2022-06-20 16:27:14.546440
# Unit test for function check_required_arguments
def test_check_required_arguments():
    specs = {'one': {'required': True}, 'two': None}
    params = {'one': None}
    assert check_required_arguments(specs, params) == []
    params = {}
    assert check_required_arguments(specs, params) == ['one']
    # TODO: extend this test once other argument_specs are implemented



# Generated at 2022-06-20 16:27:17.928242
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1

    try:
        check_type_int('one')
        raise AssertionError
    except TypeError:
        pass

    try:
        check_type_int(None)
        raise AssertionError
    except TypeError:
        pass

    try:
        check_type_int(1.0)
        raise AssertionError
    except TypeError:
        pass



# Generated at 2022-06-20 16:27:23.574197
# Unit test for function check_required_one_of
def test_check_required_one_of():
    try:
        check_required_one_of(terms=(('a', 'b'), ('c', 'd')), parameters={'e': 'f'})
    except TypeError as e:
        assert to_native(e) == "one of the following is required: a, b found in"
        assert to_native(e) == "one of the following is required: c, d found in"
    else:
        raise AssertionError('check_required_one_of should raise an exception')

# Generated at 2022-06-20 16:27:34.254723
# Unit test for function check_type_str
def test_check_type_str():
    # Test with allow_conversion=True
    assert check_type_str(42, allow_conversion=True) == '42'
    # Test with allow_conversion=False
    with pytest.raises(TypeError):
        check_type_str(42, allow_conversion=False)



# Generated at 2022-06-20 16:27:43.008691
# Unit test for function check_required_together
def test_check_required_together():
    parameters={'host':'hostname', 'port':'port_number'}
    terms= [['host', 'port'], ['host', 'port_number']]
    options_context=['host','port','port_number']
    assert (check_required_together(terms,parameters,options_context)==[])
    parameters={'host':'hostname'}
    terms= [['host', 'port'], ['host', 'port_number']]
    options_context=['host','port','port_number']
    assert (check_required_together(terms,parameters,options_context)==[['host', 'port']])



# Generated at 2022-06-20 16:27:46.399009
# Unit test for function count_terms
def test_count_terms():
    """Test function count_terms"""
    terms = ['name', 'login_user', 'ansible_network_os']
    parameters = {
        'name': 'test',
        'login_user': 'admin'
    }
    assert count_terms(terms, parameters) == 2
    assert count_terms(['login_password', 'ansible_network_os'], parameters) == 0



# Generated at 2022-06-20 16:27:54.702815
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('test') == 'test'
    assert check_type_str(u'test') == 'test'

    with pytest.raises(TypeError):
        check_type_str(object())
    with pytest.raises(TypeError):
        check_type_str(False)

    assert check_type_str(object(), allow_conversion=True) == "<class 'object'>"


# Generated at 2022-06-20 16:27:55.486942
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list('A,B') == ['A', 'B']


# Generated at 2022-06-20 16:27:59.465139
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg(["*", "*"]) == '["*", "*"]'
    assert check_type_jsonarg([{"*": []}]) == '[{"*": []}]'
    assert check_type_jsonarg({"*": []}) == '{"*": []}'
    assert check_type_jsonarg({"*": []}) == '{"*": []}'
    assert check_type_jsonarg(5) == '5'
    assert check_type_jsonarg(5.0) == '5.0'
    assert check_type_jsonarg(True) == 'true'
    assert check_type_jsonarg(None) == 'null'
    assert check_type_jsonarg(['[{', '*', '}]']) == '["[{", "*", "}]"]'

# Generated at 2022-06-20 16:28:04.973887
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    check_terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': True, 'b': True, 'd': True}
    assert count_terms(check_terms, parameters) == 2
    assert count_terms(check_terms, parameters)[0] == ['a', 'b']
    assert count_terms(check_terms, parameters)[1] == ['c', 'd']


# Generated at 2022-06-20 16:28:13.914902
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    assert check_type_jsonarg(json.dumps(["one", "two"])) == '["one", "two"]'
    assert check_type_jsonarg(["one", "two"]) == '["one", "two"]'
    try:
        check_type_jsonarg(100)
    except TypeError:
        return True

check_type_jsonarg.__test__ = False



# Generated at 2022-06-20 16:28:22.968805
# Unit test for function check_required_by
def test_check_required_by():
    data = {'a': '1'}
    options_context = None

    requirements_false = {'a': ['b'], 'c': 'd'}
    result_false = check_required_by(requirements_false, data, options_context)
    assert result_false == {}

    requirements_true = {'a': ['b'], 'c': ['d']}
    try:
        result_true = check_required_by(requirements_true, data, options_context)
        assert False
    except Exception as e:
        assert 'missing parameter' in e.message



# Generated at 2022-06-20 16:28:34.189216
# Unit test for function check_type_str

# Generated at 2022-06-20 16:28:40.485544
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments({"test": {"required": True}}, {"test": 1}) == []



# Generated at 2022-06-20 16:28:49.371041
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int(-1) == -1
    assert check_type_int(0) == 0
    assert check_type_int('1') == 1
    assert check_type_int('-1') == -1
    assert check_type_int('0') == 0
    with pytest.raises(TypeError):
        check_type_int(True)
        check_type_int(None)
        check_type_int(object)
        check_type_int('none')
        check_type_int('true')
        check_type_int('abc')
    # Test for string of a float can pass in with check_type_int
    assert check_type_int('3.0') == 3
    assert check_type_int('-3.0')

# Generated at 2022-06-20 16:28:52.952428
# Unit test for function check_type_path
def test_check_type_path():
    value = '/Users/root/ansible/testdir'
    assert check_type_path(value) == '/Users/root/ansible/testdir'


# Generated at 2022-06-20 16:29:01.135234
# Unit test for function count_terms
def test_count_terms():
    assert count_terms('test', {'test': 'value'}) == 1
    assert count_terms(['test'], {'test': 'value'}) == 1
    assert count_terms(['test'], {'not_test': 'value'}) == 0
    assert count_terms(['test', 'other'], {'test': 'value', 'other': False, 'extra': 'value'}) == 2
    assert count_terms(['test', 'other'], {'test': 'value', 'other': False, 'extra': 'value'}) == 2
# End unit test for function count_terms



# Generated at 2022-06-20 16:29:02.115724
# Unit test for function check_type_raw
def test_check_type_raw():
    value = "raw_string"
    returnvalue = check_type_raw(value)
    assert returnvalue == "raw_string"


# Generated at 2022-06-20 16:29:12.525071
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'a':1}
    required_parameters = ['a', 'b', 'c']
    with pytest.raises(TypeError) as err:
        check_missing_parameters(parameters, required_parameters)
    assert to_native(err.value) == "missing required arguments: b, c"
    # no required parameters
    parameters = {'a':1}
    required_parameters = None
    assert check_missing_parameters(parameters, required_parameters) == []
    # all required parameters are in the parameters
    parameters = {'a':1, 'b':2, 'c':3}
    required_parameters = ['a', 'b', 'c']
    assert check_missing_parameters(parameters, required_parameters) == []


# Generated at 2022-06-20 16:29:22.952468
# Unit test for function check_required_together
def test_check_required_together():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping
    params = dict(
        required_together_test=dict(
            k1='v1',
            k2='v2',
        ),
    )
    assert basic.check_required_together([('k1', 'k2')], params) == []
    assert basic.check_required_together([('k1', 'k3')], params) == [('k1', 'k3')]

    params = dict(
        required_together_test=dict(
            k1='v1',
        ),
    )
    assert basic.check_required_together([('k1', 'k2')], params) == [('k1', 'k2')]



# Generated at 2022-06-20 16:29:34.141245
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(5.5) == 5.5
    assert check_type_float(5) == 5.0
    assert check_type_float(5.5) == float(5.5)
    assert check_type_float('5.5') == float(5.5)
    assert check_type_float(u'5.5') == float(5.5)
    assert check_type_float(b'5.5') == float(5.5)
    assert check_type_float(b'5') == float(5)
    assert check_type_float(b'5.7') == float(5.7)
    assert_raises(TypeError, check_type_float, '5.7.8')

# Generated at 2022-06-20 16:29:36.355169
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    list_params = ['name','state','path','owner','group','mode']
    parameters = {'name': 'abc'}
    check_missing_parameters(parameters, list_params)



# Generated at 2022-06-20 16:29:38.772262
# Unit test for function check_type_path
def test_check_type_path():
    value = '~/test'
    assert check_type_path(value) == os.path.expanduser(os.path.expandvars(value))

# Generated at 2022-06-20 16:29:45.831529
# Unit test for function check_type_path
def test_check_type_path():
    # Test with a non path.
    value = check_type_path(None)
    assert value == None

    # Test with a path
    path = '/var'
    value = check_type_path(path)
    assert value == '/var'


# Generated at 2022-06-20 16:29:51.317219
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    # Check text_type
    assert check_type_jsonarg(u'{}') == '{}'
    assert check_type_jsonarg(u'[]') == '[]'
    assert check_type_jsonarg(u'["a","b","c"]') == '["a","b","c"]'
    assert check_type_jsonarg(u'{"a":1,"b":2,"c":3}') == '{"a":1,"b":2,"c":3}'
    # Check bytes_type
    assert check_type_jsonarg(b'{}') == '{}'
    assert check_type_jsonarg(b'[]') == '[]'
    assert check_type_jsonarg(b'["a","b","c"]') == '["a","b","c"]'
    assert check_type_json

# Generated at 2022-06-20 16:29:53.353713
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(["a", "b"], ["a", "b"]) == 2
    assert count_terms(["a", "b"], ["b", "c"]) == 1



# Generated at 2022-06-20 16:30:04.209641
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Test a valid value
    assert check_type_bytes('1.23T') == 1330812073472
    # Test an invalid value
    try:
        check_type_bytes('a.23T')
        assert False
    except TypeError:
        pass


# FIXME: remove once all module repos have been moved to ansible-base

# Generated at 2022-06-20 16:30:05.555755
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-20 16:30:07.098758
# Unit test for function check_type_raw
def test_check_type_raw():
    assert check_type_raw(1) == 1



# Generated at 2022-06-20 16:30:15.069907
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments(
            {'required': {'required': True, 'type': 'str'}}
            , {'required': 'yes'}
            ) == []
    assert check_required_arguments(
            {'required': {'required': True, 'type': 'str'}}
            , {'required': 'yes'}
            , ['ansible_facts']
            ) == []
    try:
        assert check_required_arguments(
                {'required': {'required': True, 'type': 'str'}}
                , {'missing': 'yes'}
                ) == [], "check should have failed with missing argument"
    except TypeError:
        pass

# Generated at 2022-06-20 16:30:18.172904
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('$HOME/ansible') == os.path.expanduser('$HOME/ansible')


# Generated at 2022-06-20 16:30:22.828539
# Unit test for function check_type_int
def test_check_type_int():
    assert isinstance(check_type_int(1), int)
    assert isinstance(check_type_int('1'), int)
    try:
        assert check_type_int(True)
    except TypeError as e:
        assert isinstance(e, TypeError)



# Generated at 2022-06-20 16:30:33.611687
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str('string') == 'string'
    assert check_type_str(u'unicode') == u'unicode'
    assert check_type_str(u'unicode', allow_conversion=False) == u'unicode'
    with pytest.raises(TypeError):
        check_type_str(('tuple',))
    with pytest.raises(TypeError):
        check_type_str(('tuple',), allow_conversion=False)
    assert check_type_str(b'string') == 'string'
    assert check_type_str(b'unicode') == 'unicode'
    assert check_type_str(b'unicode', allow_conversion=False) == 'unicode'
    with pytest.raises(TypeError):
        check_type_

# Generated at 2022-06-20 16:30:46.768989
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{}') == {}
    assert safe_eval('{"k1": "v1"}') == {'k1': 'v1'}
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('1') == 1
    assert safe_eval('1.5') == 1.5
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('"a"') == 'a'
    assert safe_eval('a') == 'a'



# Generated at 2022-06-20 16:30:53.070957
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(42) == 42
    assert check_type_int("42") == 42
    assert check_type_int("42.1") == 42
    assert check_type_int("42.9") == 42


# Generated at 2022-06-20 16:30:59.142001
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    from ansible.module_utils.common.validation import check_mutually_exclusive
    assert not check_mutually_exclusive([['param1', 'param2']], {'param2': 'foo'})
    assert not check_mutually_exclusive([['param1', 'param2']], {'param1': 'foo'})
    assert check_mutually_exclusive([['param1', 'param2']], {'param2': 'foo', 'param1': 'bar'})
    assert check_mutually_exclusive([['param1', 'param2']], {'param1': 'foo', 'param2': 'bar'})



# Generated at 2022-06-20 16:31:04.248722
# Unit test for function check_required_if
def test_check_required_if():
   # Check for all parameters are required
   check_required_if([['state', 'present', ('path',), False]], {'state':'present','path':'/tmp'})
   check_required_if([['state', 'present', ('path',), False]], {'state':'present'}) # This is a case where state is present and path is missing
   # Check for any parameter is required
   check_required_if([['state', 'present', ('path',), True]], {'state':'present'})
   # Check for list of parameter is required
   check_required_if([['state', 'present', ['path', 'path2']]], {'state':'present','path2':'/tmp'})

# Generated at 2022-06-20 16:31:08.393920
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(u'1') == 1.0
    assert check_type_float(b'1') == 1.0

# Generated at 2022-06-20 16:31:09.532094
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1234) == 1234

# Generated at 2022-06-20 16:31:17.278933
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():

    test_dict = {"this is a test": "of a nested value"}
    test_list = ["this", "is", "a", "test", "of", "a", "nested", "value"]
    test_tuple = ("this", "is", "a", "test", "of", "a", "nested", "value")
    test_set = {"this", "is", "test", "of", "a", "nested", "value"}

    assert check_type_jsonarg(test_dict) == json.dumps(test_dict)
    assert check_type_jsonarg(test_list) == json.dumps(test_list)
    assert check_type_jsonarg(test_tuple) == json.dumps(test_tuple)

# Generated at 2022-06-20 16:31:23.277191
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test successful run
    check_mutually_exclusive([['a'], ['b', 'c']], dict(a=True, b=True))
    check_mutually_exclusive(None, dict(a=True, b=True))

    # Test failure
    check_mutually_exclusive([['a'], ['b', 'c']], dict(a=True, b=True, c=True))



# Generated at 2022-06-20 16:31:29.334446
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    list_of_options = [["first_option", "second_option"]]
    params = {"first_option": "option1", "second_option": "option2"}
    check_mutually_exclusive(list_of_options, params)
    params = {"first_option": "option1", "second_option": "option1"}
    check_mutually_exclusive(list_of_options, params)



# Generated at 2022-06-20 16:31:31.901773
# Unit test for function count_terms
def test_count_terms():
    terms = ['a', 'b']
    parameters = {'a': 'yes', 'c': 'no'}
    assert count_terms(terms, parameters) == 1



# Generated at 2022-06-20 16:31:42.626990
# Unit test for function check_required_arguments
def test_check_required_arguments():
    if __name__ == '__main__':
        argument_spec = {
            'foo': {'required': True},
            'bar': {'required': False},
        }
        parameters = {
            'foo': 'foo'
        }
        assert check_required_arguments(argument_spec, parameters) == []
        assert check_required_arguments(argument_spec, {}) == ['foo']



# Generated at 2022-06-20 16:31:49.636895
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(3) == 3
    assert check_type_int('3') == 3
    with pytest.raises(TypeError):
        check_type_int('apple')
    with pytest.raises(TypeError):
        check_type_int([])
    with pytest.raises(TypeError):
        check_type_int({})
    with pytest.raises(TypeError):
        check_type_int(None)
    with pytest.raises(TypeError):
        check_type_int(False)
    with pytest.raises(TypeError):
        check_type_int((3,))
    with pytest.raises(TypeError):
        check_type_int([3])

# Generated at 2022-06-20 16:31:59.867375
# Unit test for function check_type_path
def test_check_type_path():
    assert check_type_path('~/foo') == os.path.expanduser('~/foo')
    assert check_type_path('$HOME/foo') == os.path.expandvars('$HOME/foo')
    assert check_type_path('$HOME') == os.path.expandvars('$HOME')
    assert check_type_path('~') == os.path.expanduser('~')
    assert check_type_path('{0}/foo'.format(os.environ['HOME'])) == os.path.expanduser('~/foo')
    assert check_type_path('{0}'.format(os.environ['HOME'])) == os.path.expanduser('~')


# Generated at 2022-06-20 16:32:02.547682
# Unit test for function check_type_path
def test_check_type_path():
    path = '/home/praj/Desktop/python-programming-for-sysadmin'
    assert check_type_path(path) == os.path.expanduser(os.path.expandvars(path))
# test check_type_path ends


# Generated at 2022-06-20 16:32:11.396380
# Unit test for function check_required_if
def test_check_required_if():
    # Test for requirements where all conditions must be met
    requirements = [['state', 'present', ('path',), True],
                    ['someint', 99, ('bool_param', 'string_param')]]
    parameters = dict(state='absent', path='/', someint=99)
    try:
        check_required_if(requirements, parameters)
    except TypeError as e:
        assert str(e) == "missing required arguments: bool_param, string_param"
    parameters = dict(state='present', path='/', someint=3)
    try:
        check_required_if(requirements, parameters)
    except TypeError as e:
        assert str(e) == "missing required arguments: bool_param, string_param"

    # Test for requirements where any condition must be met

# Generated at 2022-06-20 16:32:21.109666
# Unit test for function check_type_path
def test_check_type_path():
    # Test with strings
    assert check_type_path("test") == os.path.expanduser("test")
    assert check_type_path("a/b/c/d") == os.path.expanduser("a/b/c/d")
    assert check_type_path("~") == os.path.expanduser("~")
    assert check_type_path("$HOME") == os.path.expandvars("$HOME")

    # Test with strings that expanduser() and expandvars() do nothing to
    assert check_type_path("$HOME~") == "~"
    assert check_type_path("~$HOME") == "$HOME"


# Generated at 2022-06-20 16:32:29.491289
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Testing for expected behavior
    spec = {'required': {'required': True},
            'optional': {'required': False},
            }
    # Missing none
    params = {'required': 1,
              'optional': 2,
              }
    missing = check_required_arguments(spec, params)
    assert not missing

    # Missing required
    params = {'optional': 2,
              }
    try:
        missing = check_required_arguments(spec, params)
    except TypeError as e:
        assert e.args[0] == "missing required arguments: required"
    else:
        assert False, 'Expected TypeError'

    # Missing required, optional present
    params = {'required': 1,
              }

# Generated at 2022-06-20 16:32:38.965219
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
            ['state', 'present', ('path',), True],
            ['someint', 99, ('bool_param', 'string_param')],
            ['someint', 100, ('bool_param', 'string_param')],
            ['someint', 101, ('bool_param', 'string_param'), True]
    ]

    result = []
    parameters = {
        'state': 'present',
        'someint': 99
    }

    try:
        result = check_required_if(requirements, parameters)
    except TypeError as e:
        result = e.results


# Generated at 2022-06-20 16:32:45.801283
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1) == 1.0
    assert check_type_float('1.1') == 1.1
    with pytest.raises(TypeError):
        check_type_float(['1', '1'])
    with pytest.raises(TypeError):
        check_type_float({'1': '1'})


# Generated at 2022-06-20 16:32:52.463435
# Unit test for function check_type_jsonarg
def test_check_type_jsonarg():
    test_json = {'a':1,'b':2}
    test_json_str = json.dumps(test_json)
    assert check_type_jsonarg(test_json) == test_json_str
    assert check_type_jsonarg(test_json_str) == test_json_str
    # Test with list
    test_list = [1,2,3]
    test_list_str = json.dumps(test_list)
    assert check_type_jsonarg(test_list) == test_list_str
    assert check_type_jsonarg(test_list_str) == test_list_str



# Generated at 2022-06-20 16:33:05.951327
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # Test 1
    # When all required parameters are present
    params1 = {'a': 1, 'b': 2}
    assert check_required_one_of([['a', 'b']], params1) == []
    # Test 2
    # When all required parameters are missing
    params2 = {'c': 1, 'd': 2}
    try:
        assert check_required_one_of([['a', 'b']], params2) == []
        assert False
    except:
        assert True

    # Test 3
    # When atleast one of required parameters is present
    params3 = {'a': 1, 'd': 2}
    assert check_required_one_of([['a', 'b']], params3) == []



# Generated at 2022-06-20 16:33:09.549878
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = dict()
    required = ['foo', 'bar']
    try:
        check_missing_parameters(parameters, required)
        assert False, 'TypeError not raised'
    except TypeError as e:
        assert 'missing required arguments: foo, bar' in to_native(e)


# Generated at 2022-06-20 16:33:19.800328
# Unit test for function check_required_by
def test_check_required_by():
    parameters_1 = {'name':'Jack', 'age':'18'}
    requirements_1 = {'name':['age']}
    result = check_required_by(requirements_1, parameters_1)
    assert result == {}

    parameters_1 = {'name':'Jack', 'age':'18'}
    requirements_1 = {'name':'age'}
    result = check_required_by(requirements_1, parameters_1)
    assert result == {}

    parameters_2 = {}
    requirements_2 = {'name':['age']}
    result = check_required_by(requirements_2, parameters_2)
    assert result == {}

    parameters_2 = {'name':None}
    requirements_2 = {'name':['age']}

# Generated at 2022-06-20 16:33:24.393232
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
    ]
    parameters = {'state': 'present', 'path': '/var/log/ansible.log'}
    result = check_required_if(requirements, parameters)
    assert result == []
    parameters = {'state': 'present'}
    try:
        check_required_if(requirements, parameters)
    except TypeError as e:
        assert "found in None" in to_native(e)


# Generated at 2022-06-20 16:33:27.353929
# Unit test for function check_type_list
def test_check_type_list():
    assert check_type_list(None) == None



# Generated at 2022-06-20 16:33:37.464940
# Unit test for function check_type_bool
def test_check_type_bool():
    try:
        check_type_bool(True)
    except TypeError as e:
        print('Error: %s' % e)
        sys.exit(1)

    try:
        check_type_bool(None)
    except TypeError:
        pass
    else:
        print('Error: None should raise TypeError')
        sys.exit(1)

    try:
        check_type_bool('True')
    except TypeError as e:
        print('Error: %s' % e)
        sys.exit(1)

    try:
        check_type_bool('true')
    except TypeError as e:
        print('Error: %s' % e)
        sys.exit(1)


# Generated at 2022-06-20 16:33:42.318645
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'a': 4, 'b': 5, 'c': 6}
    required_parameters = ['a', 'b']
    missing = check_missing_parameters(parameters, required_parameters)
    assert len(missing) == 0



# Generated at 2022-06-20 16:33:52.777161
# Unit test for function check_type_dict
def test_check_type_dict():
    dict1 = {'a': 1, 'b': 2}
    dict2 = {'a': 1, 'b': 2 , 'c': "3,d=4"}
    dict3 = {'a': 1, 'b': 2 , 'c': "3,d=4", 'e': "'f'"}
    dict4 = {'a': 1, 'b': 2 , 'c': "3,d=4", 'e': "'f'", 'g': '"h"'}
    dict5 = {'a': 1, 'b': 2 , 'c': "3,d=4", 'e': "'f'", 'g': '"h"', 'i': 'j'}

# Generated at 2022-06-20 16:34:04.671526
# Unit test for function check_type_str
def test_check_type_str():
    assert 'abc' == check_type_str('abc')
    assert 'abc' == check_type_str(u('abc'))
    assert 'abc' == check_type_str(MockFileHandle())

    assert '123' == check_type_str(123)
    assert '' == check_type_str(None)
    assert '[]' == check_type_str([])
    assert '{}' == check_type_str({})

    with pytest.raises(TypeError):
        check_type_str(['abc'])

    with pytest.raises(TypeError):
        check_type_str('abc', allow_conversion=False)

    with pytest.raises(TypeError):
        check_type_str(123, allow_conversion=False)



# Generated at 2022-06-20 16:34:16.464768
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {'ip_addr':'10.10.10.10','subnet':'255.255.255.0'}
    req_parameters = [['ip_addr','subnet'],['subnet','ip_addr']]
    check_required_together(req_parameters,parameters)
    parameters = {'ip_addr':'10.10.10.10'}
    try:
        check_required_together(req_parameters,parameters)
    except TypeError as err:
        assert str(err) == "parameters are required together: ['ip_addr', 'subnet'] found in args"
    parameters = {'ip_addr':'10.10.10.10','subnet':'255.255.255.0','port':'443'}

# Generated at 2022-06-20 16:34:24.751453
# Unit test for function check_type_str
def test_check_type_str():
    assert check_type_str(None, allow_conversion=False) is None
    assert check_type_str('string') == 'string'
    assert check_type_str(1, allow_conversion=True) == '1'



# Generated at 2022-06-20 16:34:34.589469
# Unit test for function check_required_together
def test_check_required_together():
    result = check_required_together([['a', 'b']], {'a':1})
    assert result == []
    
    try:
        check_required_together([['a', 'b']], {'a':1, 'b':0})
        assert False
    except TypeError as ex:
        assert ex.args[0] == "parameters are required together: a, b"

    #try:
    #    check_required_together([['a', 'b']], {'a':1, 'b':1, 'c':1})
    #    assert False
    #except TypeError as ex:
    #    assert ex.args[0] == "parameters are required together: a, b, c"
    



# Generated at 2022-06-20 16:34:37.696868
# Unit test for function check_type_float
def test_check_type_float():
    assert isinstance(check_type_float(1.0),float)
    assert check_type_float(1.0) == 1.0
    assert isinstance(check_type_float('1.0'),float)
    assert check_type_float('1.0') == 1.0
    assert isinstance(check_type_float(1),float)
    assert check_type_float(1) == 1.0
    assert isinstance(check_type_float(b'1.0'),float)
    assert check_type_float(b'1.0') == 1.0


# Generated at 2022-06-20 16:34:44.941393
# Unit test for function check_type_int
def test_check_type_int():
    assert (check_type_int(10) == 10)
    assert (check_type_int('20') == 20)

# Generated at 2022-06-20 16:34:49.060330
# Unit test for function check_required_one_of
def test_check_required_one_of():
    d={'a':'a','b':'b','c':'c','d':'d','e':'e','f':'f','g':'g','h':'h','i':'i','j':'j','k':'k'}
    terms = [['a','b'],['c','d'],['e','f']]
    result_true = check_required_one_of(terms,d)
    assert result_true == []
    result_false = check_required_one_of(None,d)
    assert result_false == []


# Generated at 2022-06-20 16:34:57.803009
# Unit test for function check_type_str
def test_check_type_str():
    # Test for string
    assert check_type_str("test") == "test"
    # Test for non-string, non-allow_conversion
    with pytest.raises(TypeError) as excinfo:
        check_type_str(1, allow_conversion=False)
    # Test for non-string, allow_conversion
    assert check_type_str(1, allow_conversion=True) == "1"
    # Test for non-string w/surrogate error
    assert check_type_str("\udcf1") == "\\udcf1"



# Generated at 2022-06-20 16:34:59.639520
# Unit test for function safe_eval
def test_safe_eval():
    _test_safe_eval(True)
    _test_safe_eval(False)

# Generated at 2022-06-20 16:35:10.540425
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('.1Mb') == 104858
    assert check_type_bits('0.1Mb') == 104858
    assert check_type_bits('0.1M') == 104858
    assert check_type_bits('0.25M') == 262144
    assert check_type_bits('0M') == 0
    assert check_type_bits('.0M') == 0
    assert check_type_bits('00.00M') == 0
    assert check_type_bits('.1') == 1
    assert check_type_bits('100b') == 100
    assert check_type_bits('100') == 100

# Generated at 2022-06-20 16:35:14.741062
# Unit test for function count_terms
def test_count_terms():
    assert count_terms(['name', 'state'], {'name': 'foo', 'state': 'present'}) == 2
    assert count_terms('name', {'name': 'foo', 'state': 'present'}) == 1
    assert count_terms(['name', 'state', 'age'], {'name': 'foo', 'state': 'present'}) == 2



# Generated at 2022-06-20 16:35:21.115418
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = dict(param1='value1', param2='value2')
    required_parameters = ['param1', 'param2']
    assert check_missing_parameters(parameters, required_parameters) == []
    required_parameters = ['param1', 'param2', 'param3']
    assert check_missing_parameters(parameters, required_parameters) == ['param3']
    assert check_missing_parameters(parameters, None) == []



# Generated at 2022-06-20 16:35:35.616484
# Unit test for function check_required_if
def test_check_required_if():
    """ Test for function ``_check_required_if`` """
    parameters = {
        'key1': 'val1'
    }
    requirements = [
        ['key1', 'val1', ('key2',)],
    ]
    check_required_if(requirements, parameters)
    parameters = {
        'key3': 'val3'
    }
    requirements = [
        ['key1', 'val1', ('key2',)],
    ]
    check_required_if(requirements, parameters)
    parameters = {
        'key1': 'val1',
        'key2': 'val2'
    }
    requirements = [
        ['key1', 'val1', ('key2',)],
    ]
    check_required_if(requirements, parameters)