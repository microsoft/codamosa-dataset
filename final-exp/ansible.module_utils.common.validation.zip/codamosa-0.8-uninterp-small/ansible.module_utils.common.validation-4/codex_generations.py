

# Generated at 2022-06-24 21:07:21.202689
# Unit test for function check_required_arguments
def test_check_required_arguments():

    req_arg = {'var_0': {'required': True, 'type': 'bool'}, 'var_1': {'required': False, 'type': 'bool'}}
    params = {'var_0': False}
    result = check_required_arguments(req_arg, params)
    assert [] == result

    req_arg = {'var_0': {'required': False, 'type': 'bool'}, 'var_1': {'required': False, 'type': 'bool'}}
    params = {'var_0': False}
    result = check_required_arguments(req_arg, params)
    assert [] == result

    # Verify TypeError is raised if a required argument is missing

# Generated at 2022-06-24 21:07:23.705959
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Test for function check_required_arguments
    argument_spec = {"name": {"required": True, "type": "str"}}
    parameters = {"name": "Tom", "age": 20}
    options_context = None
    expected_result = []
    actual_result = check_required_arguments(argument_spec, parameters, options_context)
    assert actual_result == expected_result


# Generated at 2022-06-24 21:07:32.605822
# Unit test for function check_required_together
def test_check_required_together():
    test_args = (
        [('b', 'c'), ['a', 'b', 'c']],
        {'a':None, 'b':None},
        )
    with pytest.raises(TypeError) as excinfo:
        check_required_together(*test_args)
    assert "parameters are required together: b, c" in str(excinfo.value)
    test_args = (
        [('b', 'c'), ['a', 'b', 'c']],
        {'a':None, 'b':None, 'c':None},
        )
    assert check_required_together(*test_args) == []
    test_args = (
        [('b', 'c'), ['a', 'b', 'c']],
        {'a':None},
        )

# Generated at 2022-06-24 21:07:43.483009
# Unit test for function check_required_if
def test_check_required_if():
    # This test checks each of the requirements in the required_if
    # spec as if they were arguments provided to the module.
    # Only one requirement is tested at a time.
    dict_0 = dict(
        mybool=True,
        mylist=list(),
        mydict=dict(),
        mystring='',
        myint=0,
        myfloat=0.0,
    )
    dict_1 = dict(
        mybool=False,
        mylist=list([42]),
        mydict=dict(key='value'),
        mystring='string',
        myint=42,
        myfloat=4.2,
    )
    for key in dict_0:
        req = [key, True, ('missing_param',)]
        dict_0['missing_param'] = None

# Generated at 2022-06-24 21:07:47.010885
# Unit test for function check_type_dict
def test_check_type_dict():
    bool_0 = False
    var_0 = check_type_dict(bool_0)
    print(bool_0, var_0)

# Script mode
if __name__ == '__main__':
    test_check_type_dict()

# Generated at 2022-06-24 21:07:53.359301
# Unit test for function check_required_by
def test_check_required_by():
    x = dict()
    x = {'req': 'test2'}
    x = check_parameter_dict(x)
    return x



# Generated at 2022-06-24 21:07:55.216257
# Unit test for function check_required_together
def test_check_required_together():
    # input data for test case
    input = [('a','b','c'), ('a','b','c')]

    # result data for test case
    result = check_required_together(input)

    # Unit test assert statement
    assert result == input



# Generated at 2022-06-24 21:08:00.011016
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # q_0 = None
    # q_1 = None
    # rc = check_required_arguments(q_0, q_1)
    assert False



# Generated at 2022-06-24 21:08:02.690276
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {}
    parameters = {}
    options_context = []
    assert check_required_arguments(argument_spec, parameters, options_context) == []



# Generated at 2022-06-24 21:08:04.922980
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments(['foo']) == ['foo']


# Generated at 2022-06-24 21:08:22.323676
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # TODO:
    # print(bytes(1))
    print(check_type_bytes(1.2))

# Generated at 2022-06-24 21:08:27.400811
# Unit test for function check_required_if
def test_check_required_if():
    var_0 = 'X'
    var_1 = 'X'
    check_required_if(var_1, var_0)
    check_required_if(var_0, var_1)


# Generated at 2022-06-24 21:08:29.908345
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits(131072) == 131072


# Generated at 2022-06-24 21:08:31.319983
# Unit test for function check_required_arguments
def test_check_required_arguments():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 21:08:36.711357
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    try:
        test_case_0()
    except Exception as e:
        assert False, e.message


# Generated at 2022-06-24 21:08:46.516373
# Unit test for function safe_eval
def test_safe_eval():
    """
        test function safe_eval
        safe_eval should return x, when x is a string
        safe_eval should return error, when string contains method call
        safe_eval should return error, when string contains import statement
    """

# Generated at 2022-06-24 21:08:48.262004
# Unit test for function check_type_int
def test_check_type_int():
    # Test type
    input = '1'
    output = 1
    # Test case
    assert output == check_type_int(input)


# Generated at 2022-06-24 21:08:53.014222
# Unit test for function check_required_by
def test_check_required_by():

    # Setup
    requirements = {'required': ['a', 'b']}
    parameters = {'a': 'foo', 'b': 'bar'}

    # Test
    test_func(requirements, parameters)



# Generated at 2022-06-24 21:09:01.361059
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = "parameters are mutually exclusive: X|Y found in a -> b"
    str_1 = 'X'
    str_2 = "parameters are mutually exclusive: X|Y"
    str_3 = 'Z'

    try:
        test_case_0()
    except TypeError as e:
        if str_0 == str(e):
            #print("test case 0 passed!")
            pass
        else:
            print("test case 0 failed!")
            print("expected: {0}".format(str_0))
            print("actual  : {0}".format(str(e)))

# Generated at 2022-06-24 21:09:02.421831
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # place your testing code here.
    test_case_0()
    return


# Generated at 2022-06-24 21:09:08.189928
# Unit test for function check_type_dict
def test_check_type_dict():
    string_0 = '{a=b, b=c}'
    var_1 = check_type_dict(string_0)


# Generated at 2022-06-24 21:09:14.823578
# Unit test for function check_required_if
def test_check_required_if():
    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    list_0 = [('abcdefghijklmnopqrstuvwxyz', 'abcdefghijklmnopqrstuvwxyz')]
    var_0 = check_required_if(str_0, list_0)


# Generated at 2022-06-24 21:09:20.534196
# Unit test for function check_type_float
def test_check_type_float():
    params = [
        '1',
        1,
        1.0
    ]
    for param in params:
        assert check_type_float(param) == float(param)

    non_float_params = [
        dict(),
        [1, 2],
        'abc'
    ]

    for param in non_float_params:
        with raises(TypeError):
            check_type_float(param)



# Generated at 2022-06-24 21:09:23.122021
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():

    #Testing for TypeError

    str_0 = 'X'
    with pytest.raises(TypeError):
        check_mutually_exclusive(str_0, str_0)


# Generated at 2022-06-24 21:09:31.162204
# Unit test for function check_required_if
def test_check_required_if():
    # Test if function can identify when there are missing parameters.
    assert check_required_if([['key1'],['key2']],{'key1':'val1','key2':'val2'}) == []
    # Test if function can identify when there are missing parameters.
    assert check_required_if([['key1'],['key2']],{'key1':'val1'}) is not None
    # Test if function can identify when there are missing parameters.
    assert check_required_if([['key1'],['key2']],{'key1':'val1'}) == []



# Generated at 2022-06-24 21:09:34.284975
# Unit test for function check_type_int
def test_check_type_int():
    value = 'Y'
    res = check_type_int(value)
    print(str(res))


if __name__ == '__main__':
    test_check_type_int()

# Generated at 2022-06-24 21:09:43.814677
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1"), 1
    assert safe_eval("1.0"), 1.0
    assert safe_eval("'test'"), 'test'

    # Test tuple
    assert safe_eval("(1,2)"), (1,2)
    assert safe_eval("[1,2]"), [1,2]
    assert safe_eval("{'key':'value'}"), {'key':'value'}

    # Test dict
    dict_0 = dict()
    dict_0['key'] = 'value'
    assert safe_eval("{'key':'value'}"), dict_0

    # Test string

# Generated at 2022-06-24 21:09:46.877096
# Unit test for function check_required_by
def test_check_required_by():
    str_0 = 'X'
    str_1 = 'Y'
    var_0 = check_required_by(str_0, str_1)
    assert var_0 == None



# Generated at 2022-06-24 21:09:54.890997
# Unit test for function check_required_by
def test_check_required_by():
    """Function check_required_by tests."""
    str_0 = 'X'
    str_1 = 'a'
    str_2 = 'b'
    str_3 = 'c'
    str_4 = 'd'
    str_5 = 'X'
    str_6 = 'Y'
    str_7 = 'a'
    str_8 = 'b'
    str_9 = 'c'
    str_10 = 'd'
    str_11 = 'X'
    str_12 = 'Y'
    var_0 = {str_0: str_1}
    var_1 = {str_2: str_3}
    var_2 = {str_4: str_5}
    var_3 = {str_6: str_7}

# Generated at 2022-06-24 21:10:05.686391
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    with open("data/test_check_mutually_exclusive.json") as json_file:
        test_cases = json.load(json_file)
        for i, test_case in enumerate(test_cases):
            if test_case["input"] == "":
                continue
            if "variables" in test_case:
                vars = test_case["variables"]
                if isinstance(vars, list):
                    for var in vars:
                        exec(var + ' = test_case["input"]')
                else:
                    exec(vars + ' = test_case["input"]')
            if "setup" in test_case:
                for stmt in test_case["setup"]:
                    exec(stmt)
            # The last expression in the function body is the return value.

# Generated at 2022-06-24 21:10:19.726146
# Unit test for function check_required_by
def test_check_required_by():
    str_0 = 'X'
    var_0 = check_required_by(str_0, str_0)


# Generated at 2022-06-24 21:10:30.423855
# Unit test for function check_type_bits
def test_check_type_bits():
    # unit tests for check_type_bits
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('2.5kb') == 2560
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('frank') == 'frank'
    assert check_type_bits(1024) == 1024

# Generated at 2022-06-24 21:10:33.631699
# Unit test for function safe_eval
def test_safe_eval():
    value_0 = ""
    result_0 = safe_eval(value_0)
    assert result_0 is None


# Generated at 2022-06-24 21:10:42.950641
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval(jsonify({'a': 1, 'b': 'c', 'd': 4}))
    assert result == {u'a': 1, u'b': u'c', u'd': 4}
    result = safe_eval(jsonify([0, 2]))
    assert result == [0, 2]
    result = safe_eval('[1, 2, 3]')
    assert result == [1, 2, 3]
    result = safe_eval('{}')
    assert result == {}
    result = safe_eval('[0, 1, 2, "3"]')
    assert result == [0, 1, 2, "3"]
    result = safe_eval(jsonify('0x04'))
    assert result == '0x04'
    result = safe_eval('[]')
    assert result == []

# Generated at 2022-06-24 21:10:50.250390
# Unit test for function safe_eval
def test_safe_eval():
    assert(safe_eval("'one'.capitalize()") == "'one'.capitalize()")
    assert(safe_eval("1+1") == 2)
    assert(safe_eval("{'one': 1}")["one"] == 1)
    assert(safe_eval("['one', 'two']")[1] == 'two')




# Generated at 2022-06-24 21:10:52.401242
# Unit test for function check_required_if
def test_check_required_if():
    try:
        list_0 = list()
        # Call function 'check_required_if'
        # Raises an exception and exits
        check_required_if(list_0, list_0)
    except NameError:
        pass



# Generated at 2022-06-24 21:11:02.924771
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('2 + 3') == 2 + 3
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('["a", "b", "c"]') == ['a', 'b', 'c']
    assert safe_eval('{"key": "value"}') == {'key': 'value'}
    assert safe_eval('X') == 'X'
    assert safe_eval('import os') == 'import os'
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('("a", "b", "c")') == ('a', 'b', 'c')



# Generated at 2022-06-24 21:11:05.991722
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert 'X' == check_mutually_exclusive('X', 'X')


# Generated at 2022-06-24 21:11:17.489942
# Unit test for function check_type_bits
def test_check_type_bits():
    #assert 1048576 == check_type_bits('1Mb')
    print(check_type_bits('1Mb'))
    #assert 1048576 == check_type_bits('1MB')
    print(check_type_bits('1MB'))
    #assert 1048576 == check_type_bits('1M')
    print(check_type_bits('1M'))
    print(check_type_bits('3.14M'))
    #assert 1048576 == check_type_bits('1.0M')
    print(check_type_bits('1.0M'))
    #assert 1048576 == check_type_bits('1.0Mb')
    print(check_type_bits('1.0Mb'))
    #assert 1048576 == check_type_bits('1.00

# Generated at 2022-06-24 21:11:18.767952
# Unit test for function check_type_bits
def test_check_type_bits():
    value = '1Mb'
    var_0 = check_type_bits(value)


# Generated at 2022-06-24 21:11:27.807320
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'X'
    var_1 = safe_eval(str_0)
    assert var_1 == 'X'



# Generated at 2022-06-24 21:11:38.469761
# Unit test for function check_type_dict
def test_check_type_dict():
    # Example of json_str with value
    json_str = '''{"key": "value"}'''
    # Example of string_str with value
    string_str = "key=value"
    # Example of int_var with value
    int_var = 123
    # Example of float_var with value
    float_var = 123.4
    # Example of boolean_var with value
    boolean_var = True
    # Example of list_var with value
    list_var = [1, 2, 3]
    # Example of tuple_var with value
    tuple_var = (1, 2, 3)

    # Calling check_type_dict with arguments (json_str)
    result_0 = check_type_dict(json_str)
    print(result_0)

    # Calling check_type_dict with arguments (string_

# Generated at 2022-06-24 21:11:40.989994
# Unit test for function safe_eval
def test_safe_eval():
    # Test for following code:
    # literal_eval(value)
    var_0 = '3'
    var_1 = safe_eval(var_0)
    assert type(var_1) == int


# Generated at 2022-06-24 21:11:45.174944
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # test_case_0
    str_0 = 'X'
    var_0 = check_mutually_exclusive(str_0, str_0)

if __name__ == '__main__':
    test_check_mutually_exclusive()

# Generated at 2022-06-24 21:11:48.699060
# Unit test for function check_required_by
def test_check_required_by():
    str_0 = 'X'
    str_1 = '\u0104\u0105'
    str_2 = '\u0104\u0105'
    var_0 = check_required_by(str_0, str_1)


# Generated at 2022-06-24 21:11:57.388226
# Unit test for function check_required_if
def test_check_required_if():
    str_0 = 'X'
    str_1 = 'Y'
    str_2 = 'Z'
    param_0 = [str_0, str_1, str_2]
    param_1 = param_0
    param_2 = param_1
    param_3 = param_2
    #
    # check_required_if(requirements, parameters, options_context=None):
    # Check parameters that are conditionally required
    #
    # Raises TypeError if the check fails
    #
    # :arg requirements: List of lists specifying a parameter, value, parameters
    #     required when the given parameter is the specified value, and optionally
    #     a boolean indicating any or all parameters are required.
    #
    # :Example:
    #
    # .. code-block:: python
    #
    #     required_

# Generated at 2022-06-24 21:12:01.847095
# Unit test for function check_required_arguments
def test_check_required_arguments():
    str_0 = 'X'
    str_1 = 'X'
    str_2 = 'X'
    str_3 = 'X'
    str_4 = 'X'
    str_5 = 'X'
    str_6 = 'X'
    str_7 = 'X'
    str_8 = 'X'
    str_9 = 'X'


# Generated at 2022-06-24 21:12:08.242194
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    test_case_0()

# Import of test_check_mutually_exclusive fails because self is not known.
# def test_import_check_mutually_exclusive():
#    import ansible_collections.ansible.netcommon.tests.unit.compat.param_utils


# Generated at 2022-06-24 21:12:09.408244
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    try:
        test_case_0()
    except TypeError as e:
        print(e)


# Generated at 2022-06-24 21:12:16.592972
# Unit test for function check_type_int
def test_check_type_int():
    s_0 = 'abc'
    i_0 = 2
    res_0 = check_type_int(i_0)
    res_1 = check_type_int(s_0)
    res_2 = check_type_int(True)
    assert res_0 == i_0
    assert res_1 == s_0
    assert res_2 == True


# Generated at 2022-06-24 21:12:23.578954
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    test_0 = 'X'
    test_case_0()

if __name__ == '__main__':
    test_check_mutually_exclusive()

# Generated at 2022-06-24 21:12:27.197806
# Unit test for function check_required_by
def test_check_required_by():
    # Test case for check_required_by
    str_0 = 'X'
    var_0 = check_required_by(str_0, str_0, str_0)


# Generated at 2022-06-24 21:12:37.114748
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('[1, 2, 3, 4]') == [1, 2, 3, 4]
    assert safe_eval('"Accelerated"') == "Accelerated"
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('null') is None
    assert safe_eval("'Accelerated'") == "Accelerated"
    assert safe_eval("1") == 1
    assert safe_eval("1.2") == 1.2
    assert safe_eval("[1, 2, '3', {4: '4'}]") == [1, 2, '3', {4: '4'}]
    assert safe_eval

# Generated at 2022-06-24 21:12:38.288261
# Unit test for function check_type_int
def test_check_type_int():
    var_1 = check_type_int('1')


# Generated at 2022-06-24 21:12:46.253632
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together('X', 'Y') == None
    assert check_required_together('X', 'Y', 'Z') == None
    assert check_required_together('X', 'Y') == None
    assert check_required_together('X', 'Y', 'Z') == None
    assert check_required_together('X', 'Y') == None
    assert check_required_together('X', 'Y', 'Z') == None
    assert check_required_together('X', 'Y') == None
    assert check_required_together('X', 'Y', 'Z') == None
    assert check_required_together('X', 'Y') == None
    assert check_required_together('X', 'Y', 'Z') == None
    assert check_required_together('X', 'Y') == None

# Generated at 2022-06-24 21:12:55.248514
# Unit test for function check_required_by
def test_check_required_by():
    str_0 = 'X'
    str_1 = 'X'
    str_2 = 'X'
    str_3 = 'X'
    str_4 = 'X'
    str_5 = 'X'
    str_6 = 'X'
    str_7 = 'X'
    str_8 = 'X'
    str_9 = 'X'
    str_10 = 'X'
    str_11 = 'X'
    str_12 = 'X'
    str_13 = 'X'
    str_14 = 'X'
    str_15 = 'X'
    str_16 = 'X'
    str_17 = 'X'
    str_18 = 'X'
    str_19 = 'X'
    str_20 = 'X'
    str_21 = 'X'
   

# Generated at 2022-06-24 21:12:59.929690
# Unit test for function check_required_together
def test_check_required_together():
    str_0 = 'X'
    str_1 = 'X'
    str_2 = str_2
    tup_0 = (str_0, str_1, str_2)
    var_0 = check_required_together(str_0, str_0)
    var_1 = check_required_together(str_0, str_0, tup_0)


# Generated at 2022-06-24 21:13:06.952367
# Unit test for function check_required_arguments
def test_check_required_arguments():
    args = {"arg_1": {"required": True, "type": "str"}}
    kwargs = {}
    type_error_msg = 'missing required arguments: arg_1'
    try:
        check_required_arguments(args, kwargs)
    except TypeError as err:
        assert(err.args[0] == type_error_msg)
    kwargs = {"arg_1": "val_1"}
    try:
        check_required_arguments(args, kwargs)
    except:
        assert(False)


# Generated at 2022-06-24 21:13:07.555007
# Unit test for function check_type_dict
def test_check_type_dict():
    pass

# Generated at 2022-06-24 21:13:14.746106
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Build list of type tuples for argument_spec
    argument_spec = [(str_0, str_0)]

    # Build list of type tuples for parameters
    parameters = [(str_0, str_0)]

    result = check_required_arguments(argument_spec, parameters)

    # Check type of result
    assert(isinstance(result, list))


# Generated at 2022-06-24 21:13:24.344510
# Unit test for function check_type_int
def test_check_type_int():
    var_0 = check_type_int('1')
    var_1 = check_type_int(1)
    var_2 = check_type_int('1a')


# Generated at 2022-06-24 21:13:25.882205
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1KB') == 8192


# Generated at 2022-06-24 21:13:27.581730
# Unit test for function check_type_bytes
def test_check_type_bytes():
    str_0 = 'X'
    var_0 = check_type_bytes(str_0)
    print('var_0=', var_0)


# Generated at 2022-06-24 21:13:32.470521
# Unit test for function check_type_bits
def test_check_type_bits():
    # assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('1Tb') == 1099511627776
    assert check_type_bits('1Pb') == 1125899906842624


# Generated at 2022-06-24 21:13:37.190240
# Unit test for function check_required_by
def test_check_required_by():
    str_0 = 'X'
    str_1 = 'X'
    str_2 = 'X'
    var_0 = check_required_by(str_0, str_1, str_2)
    assert var_0 == None


# Generated at 2022-06-24 21:13:40.185323
# Unit test for function check_type_int
def test_check_type_int():
    # Tests with:
    # Input: value = 'X'
    # Output: not an int
    str_0 = 'X'
    var_0 = check_type_int(str_0)


# Generated at 2022-06-24 21:13:42.095931
# Unit test for function check_type_dict
def test_check_type_dict():
    str_0 = '{"a": 1}'
    var_0 = check_type_dict(str_0)


# Generated at 2022-06-24 21:13:52.192639
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = 'a'
    str_1 = 'a'
    var_0 = check_mutually_exclusive(str_0, str_1)
    str_0 = 'a'
    str_1 = 'a'
    var_0 = check_mutually_exclusive(str_0, str_1)
    str_0 = 'a'
    str_1 = 'a'
    var_0 = check_mutually_exclusive(str_0, str_1)
    str_0 = 'a'
    str_1 = 'a'
    var_0 = check_mutually_exclusive(str_0, str_1)
    str_0 = 'a'
    str_1 = 'a'
    var_0 = check_mutually_exclusive(str_0, str_1)
    str_0

# Generated at 2022-06-24 21:13:54.392007
# Unit test for function check_type_bits
def test_check_type_bits():
    value = '1Mb'
    result = check_type_bits(value)
    assert result == 1048576, result


# Generated at 2022-06-24 21:13:59.422070
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('foo') == 'foo'
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('import foo') == 'import foo'
    assert safe_eval('1 2') == '1 2'


# Generated at 2022-06-24 21:14:05.128301
# Unit test for function check_required_if
def test_check_required_if():
    str_0 = 'X'
    test_case_0()


# Generated at 2022-06-24 21:14:06.154980
# Unit test for function check_type_int
def test_check_type_int():
	test_case_0()


# Generated at 2022-06-24 21:14:10.383694
# Unit test for function check_required_by
def test_check_required_by():
    # Test with a string parameter
    str_0 = 'string'
    result = check_required_by(str_0, str_0)
    assert result is None
    # Test with a string parameter
    str_1 = 'str'
    result = check_required_by(str_1, str_0)
    assert result == 'string'
    # Test with an integer parameter
    int_0 = 5
    result = check_required_by(int_0, int_0)
    assert result is None
    # Test with an integer parameter
    int_1 = 6
    result = check_required_by(int_1, int_0)
    assert result == 5
    # Test with a float parameter
    float_0 = 4.5
    result = check_required_by(float_0, float_0)

# Generated at 2022-06-24 21:14:11.824106
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'X'
    result = safe_eval(str_0)


# Generated at 2022-06-24 21:14:15.234924
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    try:
        test_case_0()
    except Exception as err:
        print(err)
        raise



# Generated at 2022-06-24 21:14:21.031975
# Unit test for function check_type_float
def test_check_type_float():
    value = 0
    var_1 = check_type_float(value)
    assert var_1 == 0
    assert check_type_float(1) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0

test_check_type_float()

test_case_0()

# Generated at 2022-06-24 21:14:29.847738
# Unit test for function check_type_float
def test_check_type_float():
    value = 1.0
    result = check_type_float(value)
    assert result == value

    value = b'1.0'
    result = check_type_float(value)
    assert result == 1.0

    value = '1.0'
    result = check_type_float(value)
    assert result == 1.0

    value = 1
    result = check_type_float(value)
    assert result == 1.0

    value = "1"
    result = check_type_float(value)
    assert result == 1.0

    value = 9.0
    result = check_type_float(value)
    assert result == value

    value = b'9.0'
    result = check_type_float(value)
    assert result == 9.0

    value = '9.0'

# Generated at 2022-06-24 21:14:31.444411
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = 'X'
    var_0 = check_mutually_exclusive(str_0, str_0)


# Generated at 2022-06-24 21:14:42.701352
# Unit test for function check_required_arguments
def test_check_required_arguments():
    str_0 = jsonify(('str_0', 'str_1', 'str_2'))
    dict_0 = {'str_0': 'str_0', 'str_2': 'str_2'}
    tup_0 = 'str_3'
    var_1 = check_required_arguments(dict_0, dict_0)
    dict_1 = {tup_0: tup_0, 'str_2': 'str_2'}
    tup_1 = 'str_1'
    tup_2 = 'str_0'
    tup_3 = 'str_3'
    var_2 = check_required_arguments(dict_0, dict_1)
    var_3 = check_required_arguments(dict_1, dict_0)

# Generated at 2022-06-24 21:14:47.449010
# Unit test for function check_type_dict
def test_check_type_dict():
    str_0 = 'X'
    assert check_type_dict(str_0) == 'X'


# Generated at 2022-06-24 21:15:03.751780
# Unit test for function check_required_if
def test_check_required_if():
    str_0 = 'X'
    str_1 = 'Y'
    str_2 = 'X'
    str_3 = 'Z'
    str_4 = 'Y'
    str_5 = 'X'
    dict_0 = {'a': str_0}
    dict_1 = {'a': str_1}
    dict_2 = {'b': str_2}
    dict_3 = {'b': str_3}
    dict_4 = {'b': str_4}
    dict_5 = {'a': str_5}
    dict_6 = {'b': str_2}
    check_required_if([str_0, str_1, dict_0, dict_1, dict_2], dict_5)


# Generated at 2022-06-24 21:15:11.565556
# Unit test for function check_required_together
def test_check_required_together():

    # Test two required together
    str_0 = 'X'
    str_1 = 'Y'
    str_2 = 'Z'
    var_1 = (list([str_0]), list([str_1]), list([str_2]))
    str_3 = list([str_0, str_1])
    var_2 = check_required_together(var_1, str_3)

    # Test three required together
    str_4 = list([str_0, str_1, str_2])
    var_3 = check_required_together(var_1, str_4)

    # Test two not required together
    str_5 = list([str_0])
    var_4 = check_required_together(var_1, str_5)

    # Test two required together, one missing
    str_6 = list

# Generated at 2022-06-24 21:15:13.241848
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert safe_eval('abc')=='abc'
    assert safe_eval('3+3')==6

# Generated at 2022-06-24 21:15:23.710055
# Unit test for function check_required_together
def test_check_required_together():
    str_0 = 'X'
    str_1 = 'X'
    str_2 = 'X'
    str_3 = 'X'
    str_4 = 'X'
    str_5 = 'X'
    str_6 = 'X'
    str_7 = 'X'
    str_8 = 'X'
    var_0 = check_required_together(str_0, str_1)
    var_1 = check_required_together(str_2, str_3)
    var_2 = check_required_together(str_4, str_5)
    var_3 = check_required_together(str_6, str_7)
    var_4 = check_required_together(str_8, str_5)


# Generated at 2022-06-24 21:15:29.362512
# Unit test for function check_required_together
def test_check_required_together():
    str_0 = 'X'
    str_1 = 'XX'
    str_2 = 'XXX'

    var_0 = check_required_together(str_0, str_0)
    print(var_0)


# Generated at 2022-06-24 21:15:35.309500
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576, "check_type_bits('1Mb') != 1048576"


# Generated at 2022-06-24 21:15:46.704175
# Unit test for function check_type_bytes

# Generated at 2022-06-24 21:15:50.562041
# Unit test for function check_required_if
def test_check_required_if():
    str_0 = 'X'
    str_1 = 'Y'
    bool_0 = False
    var_0 = check_required_if(str_0, str_1, bool_0)
    var_1 = check_required_if(str_0, str_1, str_1)


# Generated at 2022-06-24 21:15:59.477784
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_1 = 'X'
    str_2 = '1'
    str_3 = 'Y'
    str_4 = 'Z'
    str_5 = 'a'
    str_6 = 'b'
    
    # Expected values
    expected_exc = None
    expected_res = [str_6]
    expected_res_1 = []

    # Use variables
    dict_1 = {str_1: str_2, str_3: str_4}
    dict_2 = {str_1: str_2}

    # Test cases
    try:
        # Test 1
        test_check_mutually_exclusive(str_5, dict_1)

    except Exception as e:
        assert type(e) == expected_exc
        assert e.args == expected_exc.args

# Generated at 2022-06-24 21:16:09.395098
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    check_mutually_exclusive(None, None)
    check_mutually_exclusive(None, 'X')
    check_mutually_exclusive('X', 'X')
    check_mutually_exclusive('X', 'Y')
    check_mutually_exclusive('X', 'AY')
    check_mutually_exclusive('Y', 'X')
    check_mutually_exclusive(['X'], 'X')
    check_mutually_exclusive(['Y'], 'X')
    check_mutually_exclusive(['X'], 'Y')
    check_mutually_exclusive(['X'], 'AY')
    check_mutually_exclusive(['X'], 'X')
    check_mutually_exclusive(['Y'], 'Y')
    check_mutually_exclusive(['X'], 'AY')
    check_mut

# Generated at 2022-06-24 21:16:18.159114
# Unit test for function check_type_bits
def test_check_type_bits():
    test_val = "1MB"
    ans_val = 1048576
    output = check_type_bits(test_val)
    assert(output == ans_val)
    #assert(check_type_bits(test_val) == ans_val)


# Generated at 2022-06-24 21:16:26.872944
# Unit test for function check_required_if
def test_check_required_if():
    # Arrange
    class object_type():
        def __init__(self):
            self.parameters = dict()
            self.parameters['instance_type'] = 'ec2'
            self.parameters['instance_id'] = 'i-12345678'
            self.parameters['image_id'] = 'ami-12345678'
            self.data = dict()
            self.data['required_if'] = list()
            self.data['required_if'].append(['instance_type', 'ec2', ('instance_id',)])
            self.data['required_if'].append(['instance_type', 'ec2', ('image_id',)])
            self.data['required_if'].append(['instance_type', 'ec2', ('instance_id', 'image_id')])
            # Act

# Generated at 2022-06-24 21:16:32.809753
# Unit test for function check_required_by

# Generated at 2022-06-24 21:16:44.520372
# Unit test for function check_type_bits
def test_check_type_bits():
    try:
        assert human_to_bytes('1Mb', isbits=True) == 1048576
    except AssertionError as e:
        raise AssertionError(str(e) + '\nExpected value: 1048576\nActual value: ' + str(human_to_bytes('1Mb', isbits=True)))

    try:
        assert check_type_bits('1Mb') == 1048576
    except AssertionError as e:
        raise AssertionError(str(e) + '\nExpected value: 1048576\nActual value: ' + str(check_type_bits('1Mb')))
