

# Generated at 2022-06-24 21:07:14.781476
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    list_0 = []
    var_0 = check_mutually_exclusive(list_0)



# Generated at 2022-06-24 21:07:21.297000
# Unit test for function check_required_one_of
def test_check_required_one_of():

    # Unit test for function check_required_one_of

    # check_required_one_of(terms, parameters, options_context=None)
    list_0 = ["name"]
    list_1 = []
    result = check_required_one_of(list_0, list_1)
    assert result == [], "Expected [] to be identical to result"
    list_0 = []
    list_1 = ["name"]
    result = check_required_one_of(list_0, list_1)
    assert result == [], "Expected [] to be identical to result"
    list_0 = ["name"]
    list_1 = ["name"]
    result = check_required_one_of(list_0, list_1)
    assert result == [], "Expected [] to be identical to result"
    list_

# Generated at 2022-06-24 21:07:23.463511
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval('[str(x) for x in range(5)]')
    assert result == ['0', '1', '2', '3', '4']



# Generated at 2022-06-24 21:07:26.781712
# Unit test for function check_type_bits
def test_check_type_bits():
    # Test with expected values
    value = '1G'
    result = check_type_bits(value)

    # Test with a value that raises a ValueError
    value2 = '1Giga'
    with pytest.raises(TypeError):
        check_type_bits(value2)
        

# Generated at 2022-06-24 21:07:29.331224
# Unit test for function check_required_arguments
def test_check_required_arguments():
    list_0 = {}
    list_1 = ['a', 'b', 'c']
    var_0 = check_required_arguments(list_0, list_1)


# Generated at 2022-06-24 21:07:34.208760
# Unit test for function check_required_by
def test_check_required_by():
    requirements  = {"key1" : ["var1", "var2"],
                     "key2" : ["var3", "var4"],
                     "key3" : "var5" }
    parameters = {"key1" : "var1",
                  "key2" : "var3" }
    # Example case 1
    try:
        check_required_by(requirements, parameters)
    except TypeError as e:
        print(e)
        assert True
    else:
        assert False
    return


# Generated at 2022-06-24 21:07:43.625445
# Unit test for function safe_eval
def test_safe_eval():
    # test for dict input
    expected_result = {'a': 1, 'b': 2}
    value = '{a: 1, b: 2}'
    result = safe_eval(value)
    assert result == expected_result

    # test for empty string
    expected_result = ''
    value = ""
    result = safe_eval(value)
    assert result == expected_result

    # test for string
    expected_result = 'abc'
    value = "abc"
    result = safe_eval(value)
    assert result == expected_result

    # test for list
    expected_result = ['abc', 'def']
    value = "['abc', 'def']"
    result = safe_eval(value)
    assert result == expected_result

    # test for int
    expected_result = 1

# Generated at 2022-06-24 21:07:53.218149
# Unit test for function check_type_bits
def test_check_type_bits():

    # Example 1:
    var_0 = '1Mb'
    var_1 = check_type_bits(var_0)
    # assert var_1 == 1048576

    # Example 2:
    var_0 = '1Tb'
    var_1 = check_type_bits(var_0)
    # assert var_1 == 1099511627776

    # Example 3:
    var_0 = '1Gb'
    var_1 = check_type_bits(var_0)
    # assert var_1 == 1073741824

    # Example 4:
    var_0 = '1Kb'
    var_1 = check_type_bits(var_0)
    # assert var_1 == 1024

    # Example 5:
    var_0 = '1b'
    var_1 = check_

# Generated at 2022-06-24 21:07:56.763562
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    list_0 = []
    list_1 = []
    list_1.append('list_0')
    list_1.append('list_1')
    list_1.append('list_2')
    options_context = []
    options_context.append('list_1')
    options_context.append('list_1')
    options_context.append('list_1')
    var_0 = check_mutually_exclusive(list_0, list_1, options_context)
    print(var_0)


# Generated at 2022-06-24 21:08:01.902254
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval("[\"hello\",\"world\"]")
    assert result == ["hello", "world"]

    result = safe_eval("{\"hello\": 1}")
    assert result == {"hello": 1}

    result = safe_eval("b'hello'")
    assert isinstance(result, binary_type)

    result = safe_eval("s'hello'")
    assert result == "hello"

    result = safe_eval("[\"hello\", \"world\"]")
    assert result == ["hello", "world"]

    result = safe_eval("1")
    assert result == 1

    # disallow code execution
    result = safe_eval("import json; json.loads('{}')")
    assert result == "import json; json.loads('{}')"


# Generated at 2022-06-24 21:08:17.847729
# Unit test for function check_type_dict
def test_check_type_dict():
    assert (check_type_dict(dict({'var_0': 'str_0'})) == dict({'var_0': 'str_0'}))
    assert (check_type_dict('var_0=str_0') == dict({'var_0': 'str_0'}))
    assert (check_type_dict('var_0=str_0, var_1=str_1') == dict({'var_0': 'str_0', 'var_1': 'str_1'}))
    assert (check_type_dict('var_0="str,0"') == dict({'var_0': '"str,0"'}))
    assert (check_type_dict('var_0="str\\"0"') == dict({'var_0': '"str\\"0"'}))

# Generated at 2022-06-24 21:08:27.593078
# Unit test for function check_required_by
def test_check_required_by():
    #data for test
    data_0 = {
        'key' : 'value',
        'key2' : 'value2'
        }
    data_1 = None
    data_2 = {
        'key' : 'value',
        'key2' : 'value2',
        'key3' : 'value3'
        }
    data_3 = {
        'key' : 'value'
        }
    data_4 = {
        'key2' : 'value2'
        }
    data_5 = {
        'key3' : 'value3'
        }
    data_6 = {
        'key' : 'value',
        'key2' : 'value2',
        'key3' : 'value3',
        'key4' : 'value4'
        }
    data

# Generated at 2022-06-24 21:08:36.902483
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'a': 'b', 'c': ['d', 'e']}
    parameters = {'a': 'b', 'b': 'c', 'c': 'd', 'd': 'e', 'e': 'f'}
    bool_0 = check_required_by(requirements, parameters)
    assert bool_0 == False, bool_0
    requirements = {'a': 'b', 'c': ['d']}
    bool_0 = check_required_by(requirements, parameters)
    assert bool_0 == False, bool_0
    requirements = {'a': 'b', 'c': ['d', 'e'], 'd': 'f'}
    bool_0 = check_required_by(requirements, parameters)
    assert bool_0 == False, bool_0

# Generated at 2022-06-24 21:08:46.693696
# Unit test for function safe_eval
def test_safe_eval():
    assert(safe_eval("[1, 2, 3]") == "[1, 2, 3]")
    assert(safe_eval("'hi'") == 'hi')
    assert(safe_eval("hi") == 'hi')
    assert(safe_eval("{'hi': 2}") == {'hi': 2})
    assert(safe_eval("2") == 2)
    assert(safe_eval("1 + 2 + 3") == 6)
    assert(safe_eval("False") == False)
    assert(safe_eval("-1") == -1)

    assert(safe_eval("file('/etc/passwd')") == "file('/etc/passwd')")
    assert(safe_eval("[1, 2, 3.") == "[1, 2, 3.")

# Generated at 2022-06-24 21:08:49.162654
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {'a': None, 'b': None}
    terms = ['a', 'c']
    result = check_required_together(terms, parameters)
    assert len(result) == 1 or len(result) == 0


# Generated at 2022-06-24 21:08:50.273920
# Unit test for function check_type_bits
def test_check_type_bits():
    assert 524288 == check_type_bits('0.5Mb')


# Generated at 2022-06-24 21:08:56.354771
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'name': 'ISP_BNG', 'state': 'present', 'password': 'Embe1mpls'}
    required_parameters = ['name', 'password', 'state']
    try:
        check_missing_parameters(parameters, required_parameters)
    except Exception:
        pass


# Generated at 2022-06-24 21:09:01.461119
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # simple test
    argspec = { 'var_0': {'required': False}, 'var_1': {'required': True} }
    params = { 'var_0': 'foo' }
    check_required_arguments(argspec, params)


# Generated at 2022-06-24 21:09:09.228155
# Unit test for function check_type_float
def test_check_type_float():
    try:
        assert check_type_float(1) == 1
    except AssertionError:
        print("Test 1 failed!\n")
    try:
        assert check_type_float("1") == 1
    except AssertionError:
        print("Test 2 failed!\n")
    try:
        assert check_type_float(b"1") == 1
    except AssertionError:
        print("Test 3 failed!\n")


# Generated at 2022-06-24 21:09:20.130754
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    list_0 = ['name', 'state', 'count']
    dict_0 = {'count': '2', 'name': 'test', 'state': 'absent'}
    options_context_0 = ['test']
    try:
        result = check_mutually_exclusive(list_0, dict_0, options_context_0)
        failed("Expected an exception, got nothing")
    except TypeError as e:
        pass
    list_1 = ['name', 'state', 'count']
    dict_1 = {'count': '2'}
    options_context_1 = None
    result = check_mutually_exclusive(list_1, dict_1, options_context_1)
    if result:
        result_0 = result[0]

# Generated at 2022-06-24 21:09:29.915165
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    dict_0 = dict()
    list_0 = []
    check_missing_parameters(dict_0, list_0)


# Generated at 2022-06-24 21:09:39.995544
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    list_0 = []
    list_1 = ['a', 'b', 'c']
    list_2 = ['d', 'e', 'f']
    list_3 = ['g', 'h', 'i', 'j']
    list_4 = ['a', 'b', 'c']
    list_5 = ['a', 'b', 'c']
    dict_0 = dict()
    list_6 = [list_1, list_2, list_3]
    list_7 = ['a', 'b', 'c']
    list_8 = ['a', 'b', 'c']
    dict_1 = dict()
    list_9 = [list_7, list_8]
    list_10 = ['a', 'b', 'c']
    list_11 = ['a', 'b', 'c']
    dict_2

# Generated at 2022-06-24 21:09:50.978726
# Unit test for function check_required_if
def test_check_required_if():
    # Pushes n values onto the stack.
    var_2 = [
        [
            "val_0",
            "val_1",
            [
                "val_3",
                "val_4"
            ]
        ],
        [
            "val_5",
            "val_6",
            [
                "val_7"
            ],
            True
        ]
    ]
    var_3 = {
        "val_9": "val_1",
        "key_2": "val_1"
    }
    # Pops n values off the stack.
    var_4 = check_required_if(var_2, var_3)
    test = var_4 is None
    assert test

    # Pushes n values onto the stack.

# Generated at 2022-06-24 21:09:56.558567
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        "name": {
            "required": False,
            "type": "str"
        },
        "cname": {
            "required": False,
            "type": "str"
        }
    }

    parameters = {
        "name": "test",
        "cname": True
    }

    # Test with required arg
    try:
        argument_spec["name"]["required"] = True
        check_required_arguments(argument_spec, parameters)
        assert False, "check required arguments test failed"
    except TypeError as e:
        assert str(e) == "missing required arguments: name", "check required arguments test failed"

    # Test with no required arg

# Generated at 2022-06-24 21:10:03.608785
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    """
    Tests function check_missing_parameters
    """
    if 1:

        from ansible.module_utils.common.text.formatters import check_missing_parameters

        fixture_dict_0 = {}
        fixture_list_0 = []
        # Input params
        fixture_dict_0['state'] = 'absent'
        fixture_dict_0['name'] = 'foo'

        test_object = check_missing_parameters(fixture_dict_0, fixture_list_0)
        # Test assertions



# Generated at 2022-06-24 21:10:13.750666
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Create the type spec for the module arguments
    argument_spec = dict(
        foo=dict(required=True),
        bar=dict(required=False),
        baz=dict(required=True),
        bat=dict(required=True),
        optional_role=dict(required=False, choices=['alpha', 'beta', 'gamma']),
        state=dict(default='present', choices=['present', 'absent']),
        name=dict(default=None),
    )

    # The parameters to check (some of the parameters are missing)
    parameters = dict(
        foo=True,
        bar=True,
        baz=False,
    )

    # The expected missing parameters
    expected_missing = ['bat', 'name']

    # Check if the missing parameters are correct
    missing = check_required_arguments

# Generated at 2022-06-24 21:10:24.163878
# Unit test for function safe_eval
def test_safe_eval():
    list_0 = []
    var_0 = safe_eval(list_0)
    assert var_0 == list_0, "Expect variable var_0 to be equal the list_0"
    str_0 = "value_0"
    var_0 = safe_eval(str_0)
    assert var_0 == str_0, "Expect variable var_0 to be equal the str_0"
    dict_0 = {"key_0": "value_0"}
    var_0 = safe_eval(dict_0)
    assert var_0 == dict_0, "Expect variable var_0 to be equal the dict_0"
    int_0 = 1
    var_0 = safe_eval(int_0)

# Generated at 2022-06-24 21:10:26.650054
# Unit test for function check_required_arguments

# Generated at 2022-06-24 21:10:29.343181
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('"a"') == 'a'
    assert safe_eval('1') == 1


# Generated at 2022-06-24 21:10:37.658977
# Unit test for function check_required_arguments
def test_check_required_arguments():
    list_0 = []
    dict_0 = dict()
    test_cases = [
                  (list_0, dict_0),
                  (dict_0, dict_0),
                  (list_0, list_0)]
    expected_results = [
                        list_0,
                        dict_0,
                        dict_0]
    for test_case, expected_result in zip(test_cases, expected_results):
        assertion_result = (check_required_arguments(*test_case) == expected_result)
        assert assertion_result


# Generated at 2022-06-24 21:10:50.173227
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # The purpose of this unit test is to check that the following cases will fail as there is // no required argument provided

    json_0 = r'''{
	"foo": "bar"
}'''
    dict_0 = json.loads(json_0)
    list_0 = []
    test_case_0(list_0, dict_0)


# Generated at 2022-06-24 21:10:54.124427
# Unit test for function check_required_if
def test_check_required_if():
    try:
        list_0 = ['var_1', 3, ['var_2', 'var_3'], True]
        dict_0 = {'var_1': 3, 'var_2': False, 'var_3': True}
        var_0 = check_required_if(list_0, dict_0)
        assert(False)
    except TypeError as exc:
        assert('var_1 is 3 but all of the following are missing: var_2' == exc.args[0])


# Generated at 2022-06-24 21:11:04.007116
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/home/shengwei',
        'bool_param': True,
        'string_param': "abc"
    }
    ret = check_required_if(requirements, parameters)
    assert(ret == [])

    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'absent',
        'path': '/home/shengwei',
        'bool_param': True,
        'string_param': "abc"
    }

# Generated at 2022-06-24 21:11:15.384221
# Unit test for function check_type_int
def test_check_type_int():
    f = check_type_int
    assert f("string") == "string"
    assert f("123") == 123
    assert f("1.0") == 1
    assert f("0") == 0
    assert f("00") == 0
    assert f("0.0") == 0
    assert f("off") == "off"
    assert f("n") == "n"
    assert f("false") == "false"
    assert f("f") == "f"
    assert f("no") == "no"
    assert f("0") == 0
    assert f("on") == "on"
    assert f("y") == "y"
    assert f("true") == "true"
    assert f("yes") == "yes"
    assert f("1") == 1
    assert f("t") == "t"

# Generated at 2022-06-24 21:11:21.450157
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # Create parameters
    parameters = {}

    # Create required_parameters
    required_parameters = ['foo']

    # Test case with one missing parameter
    missing_params = []
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert required_parameters == missing_params

    # Test case with no missing parameters
    parameters['foo'] = 'bar'
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == []

# unit test for type_conversion function

# Generated at 2022-06-24 21:11:28.032886
# Unit test for function check_type_dict
def test_check_type_dict():
    try:
        test_case_0()
    except TypeError as e:
        exc = str(e)
        print(exc)
        assert exc == "list cannot be converted to a dict"
    else:
        assert False


# Generated at 2022-06-24 21:11:38.643139
# Unit test for function check_required_by
def test_check_required_by():
    dict_0 = {'test': 'test'}
    dict_1 = {'test': 'test'}
    try:
        check_required_by(dict_0, dict_1)
    except Exception:
        assert False
    dict_2 = {'test': 'test'}
    dict_3 = {'test': 'test'}
    try:
        check_required_by(dict_2, dict_3)
    except Exception:
        assert False
    dict_4 = {'test': 'test'}
    dict_5 = {'test': 'test'}
    try:
        check_required_by(dict_4, dict_5)
    except Exception:
        assert False
    dict_6 = {'test': 'test'}
    dict_7 = {'test': 'test'}


# Generated at 2022-06-24 21:11:40.380092
# Unit test for function check_type_bytes
def test_check_type_bytes():

    try:
        raise TypeError("{0} cannot be converted to a Byte value".format(type(list())))
    except TypeError:
        pass

# Generated at 2022-06-24 21:11:49.507378
# Unit test for function safe_eval
def test_safe_eval():
    # Get the list of supported True types
    true_types = get_true_types()

    # Get the list of supported False types
    false_types = get_false_types()

    # Test the safe_eval function with a list of supported True types
    for item in true_types:
        result = safe_eval(item)
        assert(result)
        assert(isinstance(result, bool))

    # Test the safe_eval function with a list of supported False types
    for item in false_types:
        result = safe_eval(item)
        assert(not result)
        assert(isinstance(result, bool))

#

# Generated at 2022-06-24 21:11:58.079672
# Unit test for function check_required_if
def test_check_required_if():
    assert check_required_if(
    [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ],
    {
        'bool_param': True,
        'path': '/tmp/',
        'someint': 99,
        'state': 'present',
    }) == []

# Generated at 2022-06-24 21:12:11.909824
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    list_0 = [1, 2, 3]
    var_0 = check_mutually_exclusive([list_0], {'list_0': 1})
    assert var_0 == []
    var_0 = check_mutually_exclusive([list_0], {'list_0': 2})
    assert var_0 == []
    var_0 = check_mutually_exclusive([list_0], {'list_0': 3})
    assert var_0 == []
    var_0 = check_mutually_exclusive([list_0], {'list_0': 4})
    assert var_0 == []
    list_0 = [1, 2, 3]
    var_0 = check_mutually_exclusive([list_0], {'list_0': 1, 'dict_0': {'a': 'a'}})

# Generated at 2022-06-24 21:12:21.769484
# Unit test for function check_type_bytes
def test_check_type_bytes():
    print("Testing function check_type_bytes")
    # Test string of bytes
    assert check_type_bytes(b'F\x00\x00\x00\x00\x00') == (b'F\x00\x00\x00\x00\x00')
    # Test int value
    assert check_type_bytes(8) == (8)
    # Test str value
    assert check_type_bytes('8') == (b'8')
    # Test bytes value
    assert check_type_bytes(b'8') == (b'8')
    # Test str value
    assert check_type_bytes('1024') == (1024)
    # Test bytes value
    assert check_type_bytes(b'1024') == (1024)
    # Test str value

# Generated at 2022-06-24 21:12:33.311293
# Unit test for function check_required_arguments
def test_check_required_arguments():
    list_0 = []
    dict_0 = {'a1': 1, 'a2': 'a'}
    dict_1 = {}
    dict_2 = {'a1': 1, 'a2': 'a', 'c': 'c'}
    dict_3 = {'a1': 1, 'a2': 'a', 'a3': []}
    case_0 = {'a1': {'required': True}, 'a2': {'required': True}, 'a3': {'required': True}}
    case_1 = {'a1': {'required': True}, 'a2': {'required': True}, 'a3': {'required': False}}
    case_2 = {'a1': {'required': False}, 'a2': {'required': True}, 'a3': {'required': False}}


# Generated at 2022-06-24 21:12:38.998007
# Unit test for function check_type_dict
def test_check_type_dict():
    # Input parameters
    value_0 = "a"
    try:
        check_type_dict(value_0)
    except TypeError as error:
        print(error)


# Generated at 2022-06-24 21:12:46.709077
# Unit test for function safe_eval
def test_safe_eval():
    list_0 = []
    str_0 = "123"
    float_0 = float(str_0)
    float_1 = float(str_0)
    float_2 = float(str_0)
    float_3 = float(str_0)
    float_4 = float(str_0)
    float_5 = float(str_0)
    float_6 = float(str_0)
    float_7 = float(str_0)
    float_8 = float(str_0)
    float_9 = float(str_0)
    float_10 = float(str_0)
    float_11 = float(str_0)
    float_12 = float(str_0)
    float_13 = float(str_0)
    float_14 = float(str_0)
    float_

# Generated at 2022-06-24 21:12:50.511488
# Unit test for function check_required_together
def test_check_required_together():
    list_0 = ["test_0", "test_1", "test_2"]
    var_0 = check_required_together(list_0)


# Generated at 2022-06-24 21:12:53.242446
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    list_0 = [1,2,3]
    list_1 = [1,2,3]
    var_0 = check_mutually_exclusive(list_0, list_1)
    print(var_0)
    list_2 = [4,5,6]
    var_1 = check_mutually_exclusive(list_0, list_2)
    print(var_1)



# Generated at 2022-06-24 21:13:01.987868
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert True == check_type_bool(True)
    assert False == check_type_bool(False)

    assert True == check_type_bool(1)
    assert False == check_type_bool(0)

    assert True == check_type_bool('1')
    assert False == check_type_bool('0')

    assert True == check_type_bool('yes')
    assert False == check_type_bool('no')

    assert True == check_type_bool('true')
    assert False == check_type_bool('false')

    assert True == check_type_bool('y')
    assert False == check_type_bool('n')

    assert True == check_type_bool('t')
    assert False == check_type_bool('f')

    assert True == check_type_bool('on')

# Generated at 2022-06-24 21:13:05.512119
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test function, input and expected result
    terms = [["a", "b"], ["c"]]
    parameters = {"a": "a", "c": "c"}
    expected_result = []
    test_result = check_mutually_exclusive(terms, parameters)
    assert test_result == expected_result



# Generated at 2022-06-24 21:13:08.253376
# Unit test for function safe_eval
def test_safe_eval():
    list_0 = []
    var_0 = check_type_int(safe_eval(list_0))
    list_1 = []
    var_1 = check_type_str(safe_eval(list_1))


# Generated at 2022-06-24 21:13:12.861595
# Unit test for function safe_eval
def test_safe_eval():
   data_0 = 'abc'
   result = safe_eval(data_0)
   # check the first value is equal to the result
   assert result == 'abc'


# Generated at 2022-06-24 21:13:21.355754
# Unit test for function check_type_float
def test_check_type_float():

    # Test for float
    try:
        check_type_float(1.0)
        assert True
    except TypeError:
        assert False, 'Failed test for float'

    # Test for int
    try:
        check_type_float(1)
        assert True
    except TypeError:
        assert False, 'Failed test for int'

    # Test for str
    try:
        check_type_float('some_string')
        assert False, 'Failed to raise TypeError on str'
    except TypeError:
        assert True

    # Test for bytes
    try:
        check_type_float(b'some_bytes')
        assert False, 'Failed to raise TypeError on bytes'
    except TypeError:
        assert True



# Generated at 2022-06-24 21:13:25.188578
# Unit test for function check_required_if
def test_check_required_if():
    input_0 = []
    input_1 = []
    input_2 = []
    test = check_required_if(input_0, input_1, input_2)

    if (None is test):
        print("\nPASSED test_check_required_if")
    else:
        print("\nFAILED test_check_required_if")



# Generated at 2022-06-24 21:13:34.797547
# Unit test for function check_type_bytes
def test_check_type_bytes():
    value = None
    assert check_type_bytes(value) is None
    value = None
    assert check_type_bytes(value) is None
    value = None
    assert check_type_bytes(value) is None
    value = None
    assert check_type_bytes(value) is None
    value = None
    assert check_type_bytes(value) is None
    value = None
    assert check_type_bytes(value) is None
    value = None
    assert check_type_bytes(value) is None
    value = "3.0GB"
    assert check_type_bytes(value) == 3221225472
    value = "3.2GB"
    assert check_type_bytes(value) == 34359738368
    value = "3.5GB"
    assert check_type_bytes(value)

# Generated at 2022-06-24 21:13:39.111723
# Unit test for function check_required_if
def test_check_required_if():
    var_0 = {'bool_param': False, 'string_param': 'present', 'someint': 99}
    var_1 = [['someint', 99, ('bool_param', 'string_param')]]
    var_2 = check_required_if(var_1, var_0)


# Generated at 2022-06-24 21:13:45.249679
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive([], {}) is None
    assert check_mutually_exclusive(['a', 'b'], {}) is None
    assert check_mutually_exclusive(['a'], dict(a=1)) is None
    assert check_mutually_exclusive(['a', 'b'], dict(a=1)) is None
    assert check_mutually_exclusive(['a', 'b'], dict(b=1)) is None
    assert check_mutually_exclusive(['a', 'b'], dict(a=1, b=2)) is None
    assert check_mutually_exclusive(['a', ['b', 'c']], dict(b=1)) is None
    assert check_mutually_exclusive(['a', ['b', 'c']], dict(a=1, c=2)) is None

# Generated at 2022-06-24 21:13:52.385690
# Unit test for function check_required_by
def test_check_required_by():
    # Initialization of a requirements dictionary
    requirements = {}

    # Initialization of a parameters dictionary
    parameters = {}

    # Parameters values assignment
    requirements["requirement_1"] = ["requirement_1_value_1", "requirement_1_value_2", "requirement_1_value_3"]

    requirements["requirement_2"] = "requirement_2_value_1"

    requirements["requirement_3"] = ["requirement_3_value_1", "requirement_3_value_2"]

    parameters["requirement_1"] = "test_0"
    parameters["requirement_2"] = "test_1"
    parameters["requirement_3"] = "test_2"

    parameters["test_0"] = "test_1"
    parameters["test_1"] = "test_2"
    parameters

# Generated at 2022-06-24 21:14:00.538258
# Unit test for function safe_eval
def test_safe_eval():
    try:
        assert safe_eval('1 + 2') == 3
    except:
        print("failed")
    try:
        assert safe_eval('a + 2') == 'a + 2'
    except:
        print("failed")
    try:
        assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    except:
        print("failed")
    try:
        assert safe_eval('a', dict(a=1)) == 1
    except:
        print("failed")
    try:
        assert safe_eval('a', dict(a='1')) == '1'
    except:
        print("failed")
    try:
        assert safe_eval('"1"') == "1"
    except:
        print("failed")

# Generated at 2022-06-24 21:14:05.306410
# Unit test for function check_type_bytes
def test_check_type_bytes():
    str_0 = '1 kB'
    bytes_0 = check_type_bytes(str_0)
    print(bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_check_type_bytes()

# Generated at 2022-06-24 21:14:16.371765
# Unit test for function check_type_bits
def test_check_type_bits():
    for test_number in range(4):
        if test_number == 0:
            value = "1Mb"
            try:
                result = check_type_bits(value)
            except TypeError:
                assert True
        elif test_number == 1:
            value = "2Mb"
            try:
                result = check_type_bits(value)
            except TypeError:
                assert True
        elif test_number == 2:
            value = "3Mb"
            try:
                result = check_type_bits(value)
            except TypeError:
                assert True
        else:
            value = "4Mb"
            try:
                result = check_type_bits(value)
            except TypeError:
                assert True



# Generated at 2022-06-24 21:14:28.861074
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    list_0 = []
    list_1 = ['test', 'ans']
    var_0 = check_mutually_exclusive(list_0, list_1)
    assert var_0 == list_0

    dict_0 = dict()
    dict_1 = {'test': 'ans'}
    list_2 = ['test']
    list_3 = ['test']
    var_1 = check_mutually_exclusive(list_2, dict_0, list_3)
    assert var_1 == list_0

    list_4 = ['test', 'ans']
    list_5 = ['test']
    list_6 = ['ans']
    var_2 = check_mutually_exclusive(list_4, dict_1, list_5)
    assert var_2 == list_6


# Generated at 2022-06-24 21:14:35.701099
# Unit test for function check_required_together
def test_check_required_together():
    list_0 = []
    list_1 = [list_0]
    dict_2 = {}
    list_3 = [list_1, dict_2]
    dict_4 = {'parameters': list_3}
    list_5 = [dict_4]
    list_6 = []
    list_7 = [list_6]
    dict_8 = {}
    list_9 = [list_7, dict_8]
    dict_10 = {'options_context': list_9}
    test_case_0(list_5, dict_10)


# Generated at 2022-06-24 21:14:40.631388
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = [['x', 'y'], ['a', 'b']]
    parameters = {'x': 2, 'a': 1}
    check_mutually_exclusive(terms, parameters, None)


# Generated at 2022-06-24 21:14:47.943722
# Unit test for function check_type_float
def test_check_type_float():
    with pytest.raises(TypeError) as excinfo:
        check_type_float('hello')

    assert "cannot be converted to a float" in to_native(excinfo.value)
    float_0 = check_type_float(1.0)
    assert float_0 == 1.0
    float_1 = check_type_float(1)
    assert float_1 == 1.0
    float_2 = check_type_float('1.0')
    assert float_2 == 1.0
    float_3 = check_type_float('1')
    assert float_3 == 1.0


# Generated at 2022-06-24 21:14:54.739016
# Unit test for function check_required_together
def test_check_required_together():
    test_cases = [
        [
            [
                ['term_1', 'term_2']
            ],
            {
                'term_1': 'term_1 value'
            }
        ],
        [
            [
                ['term_1', 'term_2']
            ],
            {
                'term_1': 'term_1 value'
            }
        ],
        [
            [
                ['term_1', 'term_2']
            ],
            {
                'term_1': 'term_1 value',
                'term_2': 'term_2 value'
            }
        ]
    ]
    for case in test_cases:
        if not test_check_required_together_case(*case):
            return False

    return True


# Generated at 2022-06-24 21:15:03.781589
# Unit test for function check_required_by
def test_check_required_by():
    # pylint: disable=line-too-long
    requirements = {'a': ['b', 'c'], 'b': ['c', 'd']}
    parameters = {'a': 'yes', 'b': 'yes', 'c': 'yes'}
    options_context = ['a']
    test_check_required_by_0(requirements, parameters, options_context)

    parameters = {'a': 'yes', 'b': 'yes', 'c': None}
    options_context = ['a']
    test_check_required_by_1(requirements, parameters, options_context)

    parameters = {'a': 'yes', 'b': 'yes', 'c': None, 'd': None}
    options_context = ['a']

# Generated at 2022-06-24 21:15:08.760259
# Unit test for function check_type_bytes
def test_check_type_bytes():
    list_0 = ['', '', '', '']
    list_0[0] = '1'
    list_0[1] = list_0[0]
    list_0[2] = list_0[1]
    var_0 = check_type_bytes(list_0[2])
    var_0 = check_type_bytes(list_0[1])


# Generated at 2022-06-24 21:15:19.171410
# Unit test for function check_type_dict
def test_check_type_dict():
    # If a dict is provided, then return it
    data = {'1': '11', '2': '22', '3': '33'}
    result = check_type_dict(data)
    assert result == data
    # If a string is provided, parse it and return a dict
    data = '1=11,2=22,3=33'
    result = check_type_dict(data)
    assert result == {'1': '11', '2': '22', '3': '33'}
    # If a string is provided, parse it and return a dict
    data = "{'1': '11', '2': '22', '3': '33'}"
    result = check_type_dict(data)
    assert result == {'1': '11', '2': '22', '3': '33'}


# Generated at 2022-06-24 21:15:22.046054
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    parameters = {'a': None, 'b': None}
    terms = [['a', 'b']]
    assert check_mutually_exclusive(terms, parameters, 'context') == []



# Generated at 2022-06-24 21:15:24.358042
# Unit test for function check_type_bytes
def test_check_type_bytes():
    bytes_given = '100 MB'
    print ('Passed' if type(check_type_bytes(bytes_given)) == bytes else 'Failed')


# Generated at 2022-06-24 21:15:38.787174
# Unit test for function check_type_bits
def test_check_type_bits():
    try:
        assert(check_type_bits("1Mb") == 1048576)
    except TypeError:
        pass
    try:
        assert(check_type_bits("1b") == 1)
    except TypeError:
        pass
    try:
        assert(check_type_bits("1bit") == 1)
    except TypeError:
        pass
    # On python 3.5.2, assert raises TypeError if type of return is not integer
    assert(type(check_type_bits("1Mb")) == int)


# Generated at 2022-06-24 21:15:49.964427
# Unit test for function check_required_together
def test_check_required_together():
    # Test starting with required arguments
    list_0 = ['test']
    var_0 = check_required_together(list_0, {})
    assert var_0 is None
    # Test starting with required arguments
    list_0 = ['test']
    dict_0 = {'test': 'test'}
    var_0 = check_required_together(list_0, dict_0)
    assert var_0 is None
    # Test starting with required arguments
    bool_0 = True
    dict_0 = {'test': 'test'}
    var_0 = check_required_together({'test': bool_0}, dict_0)
    assert var_0 is None
    # Test starting with required arguments
    list_0 = [{'test', 'test2'}]

# Generated at 2022-06-24 21:15:54.802264
# Unit test for function check_type_int
def test_check_type_int():
    try:
        list_0 = []
        var_0 = check_type_int(list_0)
        # if var_0 is True, the print will be executed
        print(to_native(var_0))
    except:
        # if var_0 is False, the print will not be executed and the exception is raised
        print("The parameters are not correct")


# Generated at 2022-06-24 21:15:56.751955
# Unit test for function check_type_float
def test_check_type_float():
    print('in test_check_type_float')
    list_0 = []
    var_0 = check_type_float(list_0)
    #print(var_0)
    assert isinstance(var_0, float) == True

test_check_type_float()


# Generated at 2022-06-24 21:15:58.348569
# Unit test for function check_type_float
def test_check_type_float():
    var_0 = check_type_float(1.58)
    var_1 = check_type_float("1.58")
    var_2 = check_type_float(1)



# Generated at 2022-06-24 21:16:05.362834
# Unit test for function check_required_together
def test_check_required_together():
    # Set up mock
    terms = [("test1", "test2"), ("test2", "test3")]
    parameters = {"test1": "test1", "test2": "test2"}
    options_context = ["test1", "test2", "test3"]
    # Run test
    try:
        check_required_together(terms, parameters, options_context = options_context)
        # Success
        assert True
    except Exception:
        # Failure
        assert False


# Generated at 2022-06-24 21:16:06.328806
# Unit test for function check_required_if
def test_check_required_if():
    assert 1 == 1# later to make test

# Generated at 2022-06-24 21:16:17.633737
# Unit test for function safe_eval
def test_safe_eval():
    check_0 = safe_eval('{\'svc\': [\'driver\']}')
    assert check_0 == {'svc': ['driver']}, \
        "Error, the result should be {'svc': ['driver']}, but the value is : %s" % check_0

    check_1 = safe_eval('[\'svc\', \'haproxy\']')
    assert check_1 == ['svc', 'haproxy'], \
        "Error, the result should be ['svc', 'haproxy'], but the value is : %s" % check_1

    check_2 = safe_eval('["svc", "haproxy"]')

# Generated at 2022-06-24 21:16:19.249374
# Unit test for function check_type_int
def test_check_type_int():
    input0 = None 
    assert check_type_int(input0) == None


# Generated at 2022-06-24 21:16:21.388649
# Unit test for function check_type_bits
def test_check_type_bits():
    var_0 = check_type_bits(1)
    assert var_0 == 1



# Generated at 2022-06-24 21:16:29.931368
# Unit test for function check_type_bytes
def test_check_type_bytes():
    cases = [
        (test_case_0, )
    ]
    for c in cases:
        args = c[:-1]
        ret = check_type_bytes(*args)
        assert c[-1] == ret


# Generated at 2022-06-24 21:16:31.776009
# Unit test for function check_type_bytes
def test_check_type_bytes():
    with pytest.raises(TypeError):
        value = "8d"
        test_check_type_bytes_value = check_type_bytes(value)


# Generated at 2022-06-24 21:16:38.744899
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # Test that correct arguments not fails with no error
    assert check_required_one_of(None, {}) == []
    assert check_required_one_of([], {}) == []
    assert check_required_one_of(['test'], {}) == []
    assert check_required_one_of('test', {}) == []
    assert check_required_one_of([], {'test': None}) == []
    assert_exception_message(TypeError, 'one of the following is required: test', check_required_one_of, ['test'], {'test2': None})
    assert_exception_message(TypeError, 'one of the following is required: test, test2', check_required_one_of, [['test', 'test2']], {'test3': None})
    assert check_required_one_