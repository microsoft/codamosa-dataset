

# Generated at 2022-06-24 21:07:08.067039
# Unit test for function check_required_by
def test_check_required_by():
    # Setup
    requirements = {'time_zone': ['name']}
    parameters = {'name': 'test'}

    # Exercise
    check_required_by(requirements, parameters)

    # Verify
    check_required_by(requirements, parameters)



# Generated at 2022-06-24 21:07:12.380001
# Unit test for function check_required_by
def test_check_required_by():
    # check_required_by() examples here
    result = check_required_by(requirements, parameters)


# Generated at 2022-06-24 21:07:19.205346
# Unit test for function check_required_by
def test_check_required_by():
    # Check for correct value for required key
    requirements = {'x': ['y']}
    parameters = {'x': 'hello', 'y': 'world'}
    try:
        check_required_by(requirements, parameters)
    except TypeError as e:
        assert False, 'check_required_by unexpectedly raised an exception'
    else:
        assert True, 'check_required_by was successful'

    # Check for incorrect value for required key
    requirements = {'x': ['y']}
    parameters = {'x': 'hello', 'wrong_key': 'world'}
    with pytest.raises(TypeError) as excinfo:
        check_required_by(requirements, parameters)
    assert excinfo.value.args[0] == "missing parameter(s) required by 'x': y"

    # Check

# Generated at 2022-06-24 21:07:23.188963
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {'required': False, 'type': 'str'}
    assert check_required_arguments(argument_spec, parameters={}) == []


# Generated at 2022-06-24 21:07:28.041693
# Unit test for function safe_eval
def test_safe_eval():
    correct_output = literal_eval("[1, 2, 3]")
    (output, exception) = safe_eval("[1, 2, 3]", include_exceptions=True)
    if output == correct_output and exception is None:
        print("correct")
    else:
        print("incorrect")

if __name__ == "__main__":
    test_safe_eval()

# Generated at 2022-06-24 21:07:31.050493
# Unit test for function check_required_by
def test_check_required_by():
    list_0 = [10, 20, 30, 50]
    dict_0 = {"a": 10, "b": 20, "c": 30, "d": 50}
    test_case_0(list_0, dict_0)


# Generated at 2022-06-24 21:07:34.949410
# Unit test for function check_required_by
def test_check_required_by():
    assert(check_required_by("foo", ["foo", "bar"])) == None


# Generated at 2022-06-24 21:07:43.652732
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    float_0 = float(1.1)
    float_list = [float_0,float_0,float_0]
    float_list_list = [float_list,float_list]
    list_0 = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    float_dict = {k:v for (k,v) in zip(float_list,float_list)}
    dict_0 = {k:v for (k,v) in zip(list_0,float_list)}
    dict_1 = {k:v for (k,v) in zip(float_list,float_dict)}

# Generated at 2022-06-24 21:07:48.003962
# Unit test for function check_required_if
def test_check_required_if():
    requirements_0 = []
    key_0 = 'key_0'
    val_0 = 'val_0'
    requirements_1 = ['requirements_1']
    is_one_of_0 = False
    tuple_0 = (key_0, val_0, requirements_1, is_one_of_0)
    requirements_0.append(tuple_0)
    parameters_0 = dict()
    options_context_0 = list()
    options_context_0.append('')
    output = check_required_if(requirements_0, parameters_0, options_context_0)


# Generated at 2022-06-24 21:07:53.855605
# Unit test for function check_required_by
def test_check_required_by():
    print('\n'*5)
    print('In check_type_string.py')
    test_case_0()

if __name__ == '__main__':
    test_check_required_by()

# Generated at 2022-06-24 21:08:05.618947
# Unit test for function check_type_int
def test_check_type_int():
    float_0 = 574.9
    var_0 = check_type_int(float_0)
    assert var_0 == 574
    int_0 = 574
    var_0 = check_type_int(int_0)
    assert var_0 == 574
    str_0 = "574"
    var_0 = check_type_int(str_0)
    assert var_0 == 574
    str_0 = "574.9"
    with pytest.raises(TypeError):
        check_type_int(str_0)


# Generated at 2022-06-24 21:08:14.344152
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Check that function raises TypeError when a required parameter is missing in arguments.
    argument_spec = {'arg_0': {'required': True, 'type': 'float'}}
    parameters = {}

    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError:
        pass # check passed
    else:
        raise AssertionError('check_required_arguments did not raise TypeError for missing required parameter')

    # Check that function does not raise TypeError when a required parameter is present in arguments.
    argument_spec = {'arg_0': {'required': True, 'type': 'float'}}
    parameters = {'arg_0': 574.9}


# Generated at 2022-06-24 21:08:21.943469
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = [
        ['state', 'present'],
        ['someint', 99],
    ]
    expected = {}
    expected['key'] = 'someint'
    expected['val'] = 99
    expected['requirements'] = ('bool_param', 'string_param')
    expected['missing'] = ['bool_param', 'string_param']
    expected['requires'] = 'all'

    actual = check_required_if(requirements, parameters)
    assert actual == expected


# Generated at 2022-06-24 21:08:30.872389
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [("state", "force"), ("state", "recursive"), ("state", "links")]
    parameters = {"state": "present"}
    assert check_required_one_of(terms, parameters) == [('state', 'links')]
    parameters = {"state": "present", "force": "yes"}
    assert check_required_one_of(terms, parameters) is None
    parameters = {"state": "absent", "recursive": "yes", "links": "hard"}
    assert check_required_one_of(terms, parameters) is None
    parameters = {'state': 'absent', 'recursive': 'yes', 'force': 'yes'}
    assert check_required_one_of(terms, parameters) == [('state', 'links')]

# Generated at 2022-06-24 21:08:37.071373
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    print("START test_check_mutually_exclusive")
    test_val = 'test_val'
    # terms is None
    result = check_mutually_exclusive(None, None)
    assert result == []
    # terms is not None, but not in parameters
    result = check_mutually_exclusive(test_val, None)
    assert result == []
    # terms is not None and in parameters
    result = check_mutually_exclusive(test_val, test_val)
    assert result == 1
    print("END test_check_mutually_exclusive")

test_case_0()
test_check_mutually_exclusive()

# Generated at 2022-06-24 21:08:42.501142
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'key': 'val'}
    required_parameters = ['key', 'val']
    missing_parameters = check_missing_parameters(parameters, required_parameters)
    assert len(missing_parameters) == 0, 'test_check_missing_parameters failed'
    print('test_check_missing_parameters succeeded')
    return



# Generated at 2022-06-24 21:08:44.190229
# Unit test for function safe_eval
def test_safe_eval():
    if __name__ == '__main__':        
        test_case_0()

# END


# Generated at 2022-06-24 21:08:45.763168
# Unit test for function check_type_int
def test_check_type_int():
    float_0 = 365.0
    int_0 = check_type_int(float_0)


# Generated at 2022-06-24 21:08:48.590294
# Unit test for function check_required_arguments
def test_check_required_arguments():
  # 1 test with asserts
  argument_spec = { 'arg1': { 'required': True } }
  parameters = { 'arg1': 'teststring' }
  assert check_required_arguments(argument_spec, parameters) == []
  # 1 test without asserts


# Generated at 2022-06-24 21:08:53.700947
# Unit test for function check_required_arguments
def test_check_required_arguments():
    float_0 = 574.9
    float_1 = float(float_0)
    float_1 = float_0
    var_0 = check_type_dict(float_0)
    var_1 = check_type_dict(float_0)
    
    assert_equals(var_0, var_1)


# Generated at 2022-06-24 21:09:07.225953
# Unit test for function check_required_if
def test_check_required_if():
    # Check that a TypeError is raised if the required parameters are not present
    try:
        check_required_if([['state', 'present', ['path'], True]], {})
    except TypeError:
        pass
    # Check that a TypeError is raised if only one of the required parameters is present
    try:
        check_required_if([['state', 'present', ['path', 'test'], True]], {'path': 'test'})
    except TypeError:
        pass
    # Check that a TypeError is not raised if the required parameters are present
    try:
        check_required_if([['state', 'present', ['path', 'test'], True]], {'path': 'test', 'test': 'path'})
    except TypeError:
        assert False

    # Check that a TypeError is raised if the required parameters

# Generated at 2022-06-24 21:09:11.713188
# Unit test for function check_type_float
def test_check_type_float():
    float_value = 574.9
    result = check_type_float(float_value)
    return result



# Generated at 2022-06-24 21:09:15.845901
# Unit test for function check_type_int
def test_check_type_int():
    int_0 = 9
    int_1 = check_type_int(int_0)
    return int_1



# Generated at 2022-06-24 21:09:23.543985
# Unit test for function safe_eval

# Generated at 2022-06-24 21:09:24.453684
# Unit test for function check_type_bits
def test_check_type_bits():
    pass


# Generated at 2022-06-24 21:09:30.151279
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert True == check_mutually_exclusive(5, ['age', 'gender', 'name'])
    assert True == check_mutually_exclusive('age', ['name', 'gender'])
    assert False == check_mutually_exclusive(['age'], ['name', 'gender'])
    assert False == check_mutually_exclusive(['age', 'gender'], ['name', 'gender'])


# Generated at 2022-06-24 21:09:32.074503
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    global var_0
    print(var_0)


# Generated at 2022-06-24 21:09:33.219518
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert set(check_type_bytes('1M')) == {0, 2**20}


# Generated at 2022-06-24 21:09:36.912297
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by("") == "foo"
    assert check_required_by("") == "foo"
    assert check_required_by("") == "foo"
    assert check_required_by("") == "foo"


# Generated at 2022-06-24 21:09:43.742998
# Unit test for function safe_eval
def test_safe_eval():
    # Assert return is a string if import is present in the expression
    assert 'import' in safe_eval(safe_eval('import Ansible'))

    # Assert return is a string if a method is present in the expression
    assert 'Ansible.module_utils' in safe_eval(safe_eval('Ansible.module_utils'))

    # Assert return is a boolean True if a boolean True is passed in the expression
    assert safe_eval(safe_eval('True')) == True

    # Assert return is a boolean False if a boolean False is passed in the expression
    assert safe_eval(safe_eval('False')) == False

    # Assert return is a dict if a dict is passed in the expression

# Generated at 2022-06-24 21:09:58.037117
# Unit test for function check_type_bits
def test_check_type_bits():
    # Testing length of arguments
    args = ('1Mb')
    assert check_type_bits(*args) == 1048576

    # Testing argument type
    args = ('1Mb',)
    assert isinstance(check_type_bits(*args), int)

    # Testing multiply
    args = ('1Mb',)
    assert check_type_bits(*args) == 1048576

    # Testing addition
    args = ('1000Kb',)
    assert check_type_bits(*args) == 819200

    # Testing subtraction
    args = ('1Mb-1Kb',)
    assert check_type_bits(*args) == 1048576-1024

    # Testing division
    args = ('1Mb/1000',)
    assert check_type_bits(*args) == 1024

    # Testing remainder

# Generated at 2022-06-24 21:09:59.713511
# Unit test for function check_type_bits
def test_check_type_bits():
    str_text = '1Mb'
    res = check_type_bits(str_text)
    expected_res = 1048576

    assert res == expected_res


# Generated at 2022-06-24 21:10:11.142093
# Unit test for function check_required_if
def test_check_required_if():
    # Test with default parameters
    requirements = [
            ['param1', 'value1', ('param2', 'param3', 'param4')],
            ['param1', 'value1', ('param2', 'param3', 'param4'), True],
            ['param1', 'value1', ('param2', 'param3'), False],
            ['param1', 'value1', ('param2', 'param3'), True]
        ]
    parameters = {'param2': 'value2', 'param1': 'value1'}
    res = check_required_if(requirements, parameters)
    assert res == [], "Test should have passed"

    # Test with empty requirements
    requirements = []
    parameters = {'param2': 'value2', 'param1': 'value1'}

# Generated at 2022-06-24 21:10:20.607098
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1880974050) == 1880974050
    assert check_type_int('\x0f\x1a\x0d') == 15
    assert check_type_int(0) == 0
    assert check_type_int('9\x1d\x1e') == 9
    assert check_type_int(1795937279) == 1795937279
    assert check_type_int(15) == 15
    assert check_type_int(0) == 0
    assert check_type_int(9) == 9
    assert check_type_int(1795937279) == 1795937279


# Generated at 2022-06-24 21:10:24.734941
# Unit test for function safe_eval
def test_safe_eval():

    assert(test_case_0())


# Generated at 2022-06-24 21:10:30.556702
# Unit test for function check_required_arguments
def test_check_required_arguments():
    str_0 = 'cW5'
    str_1 = 'D2uCb-H.OJI=^z\x0b\\'
    arg_spec = {str_0: {'req' : True}}
    params = {str_0: str_1}
    co = check_required_arguments(arg_spec, params)


# Generated at 2022-06-24 21:10:37.948831
# Unit test for function check_required_if
def test_check_required_if():
    # Mock input data
    requirements_none = None
    parameters = { 'test': 1 }

    # Test function execution
    check_required_if(requirements_none, parameters)
    
    # Test function execution for error condition
    try:
        requirements_none = 'asdf'
        check_required_if(requirements_none, parameters)
    except TypeError:
        pass
    else:
        assert False, 'Expected exception not raised'



# Generated at 2022-06-24 21:10:45.873218
# Unit test for function check_required_together
def test_check_required_together():
    params = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_together([['a', 'b', 'c'], ['x', 'y']], params) == []
    assert check_required_together([['a', 'b', 'c'], ['a', 'x']], params) == []

    try:
        assert check_required_together([['a', 'b', 'c'], ['x', 'y']], {}) != []
    except Exception:
        pass

    try:
        assert check_required_together([['a', 'c'], ['x', 'y']], params) != []
    except Exception:
        pass


# Generated at 2022-06-24 21:10:47.846504
# Unit test for function check_required_by
def test_check_required_by():
    # check_required_by(requirements, parameters, options_context=None)
    assert True



# Generated at 2022-06-24 21:10:54.542678
# Unit test for function safe_eval
def test_safe_eval():
    # literal_eval (string)
    str_0 = """'foo'"""
    var_0 = safe_eval(str_0)
    assert len(var_0) == 4, "Failed to evaluate string"
    assert var_0 == "foo", "Wrong literal_eval result"
    # literal_eval (integer)
    str_1 = '2'
    var_1 = safe_eval(str_1)
    assert isinstance(var_1, int), "Failed to evaluate integer"
    assert var_1 == 2, "Wrong literal_eval result"
    # literal_eval (float)
    str_2 = '3.14'
    var_2 = safe_eval(str_2)
    assert isinstance(var_2, float), "Failed to evaluate float"
    assert var_2 == 3

# Generated at 2022-06-24 21:11:05.610801
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Ki') == 1024
    assert check_type_bytes('1Mi') == 1048576
    assert check_type_bytes('1Gi') == 1073741824
    assert check_type_bytes('1Ti') == 1099511627776
    assert check_type_bytes('1Pi') == 1125899906842624
    assert check_type_bytes

# Generated at 2022-06-24 21:11:09.357262
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together(["state"], {"state": "present"}) == []
    assert check_required_together(["key", "value"], {"key": "my_key", "value": "my_value"}) == []
    assert check_required_together(["state", "src"], {"src": "ansible", "state": "present"}) == []
    assert check_required_together(["state", "dest"], {"dest": "ansible", "state": "present"}) == []
    assert check_required_together(["state", "dest"], {"state": "present"}) == [['state', 'dest']]
    assert check_required_together(["state", "dest"], {"dest": "ansible"}) == [['state', 'dest']]

# Generated at 2022-06-24 21:11:18.737141
# Unit test for function check_type_bits
def test_check_type_bits():
    print("Test check_type_bits")
    str_0 = 'D2uCb-H.OJI=^z\x0b\\'
    var_0 = safe_eval(str_0)
    str_1 = '{}'.format(sys.version_info[0])
    str_2 = '{}'.format(sys.version_info[1])
    str_3 = '{}'.format(sys.version_info[2])
    str_4 = '{}'.format(sys.version_info.major)
    str_5 = '{}'.format(sys.version_info.minor)
    str_6 = '{}'.format(sys.version_info.micro)
    str_7 = '{}'.format(sys.version_info.major)

# Generated at 2022-06-24 21:11:29.792920
# Unit test for function check_required_together
def test_check_required_together():
    str_0 = "IxWm\x1d"
    str_1 = jsonify("A\x19\x06B\x0cT\x1a\x1dQgA\x1c\x06I")
    str_2 = '<,/"\x1aU'
    str_3 = '=_5'

# Generated at 2022-06-24 21:11:40.526795
# Unit test for function check_type_bits
def test_check_type_bits():
    assert '1Kb' == human_readable_bytes(check_type_bits('1Kb'), isbits=True)
    #assert '1048576' == check_type_bits('1Mb')
    #assert '1048576' == check_type_bits(None)
    #assert '1048576' == check_type_bits(1048576)
    #assert '1048576' == check_type_bits('1048576')
    #assert '1048576' == check_type_bits('1,048,576')
    #assert '1048576' == check_type_bits('1024Kb')
    #assert '1048576' == check_type_bits('1Mb')
    #assert '1Kb' == check_type_bits('001024')
    #assert '10Kb' == check

# Generated at 2022-06-24 21:11:44.247159
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert len(check_mutually_exclusive([['loop', 'loop_control']], {'loop_control': 'no', 'loop': 'yes'})) > 0


# Generated at 2022-06-24 21:11:53.627527
# Unit test for function check_type_bits
def test_check_type_bits():
    # Input: str: '10Gb'
    str_1 = '10Gb'
    var_1 = check_type_bits(str_1)
    print(var_1)

    # Input: str: '10'
    str_2 = '10'
    var_2 = check_type_bits(str_2)
    print(var_2)

    # Input: str: '1b'
    str_3 = '1b'
    var_3 = check_type_bits(str_3)
    print(var_3)

    # Input: str: '1.5G'
    str_4 = '1.5G'
    var_4 = check_type_bits(str_4)
    print(var_4)

    # Input: str: '1.5Gb'
    str_5

# Generated at 2022-06-24 21:11:58.629902
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()



# Generated at 2022-06-24 21:12:00.405495
# Unit test for function safe_eval
def test_safe_eval():
    func = safe_eval
    test_case_0()


# Generated at 2022-06-24 21:12:03.959416
# Unit test for function check_type_dict
def test_check_type_dict():
    str_0 = 'D2uCb-H.OJI=^z\x0b\\'
    var_0 = check_type_dict(str_0)
    assert var_0 == {'H.OJI': '^z\x0b\\'}

# Generated at 2022-06-24 21:12:10.876594
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    testcase_0 = [['a', 'b']], {'a': '1', 'b': '2'}
    try:
        result = check_mutually_exclusive(*testcase_0)
    except TypeError as err:
        print("Exception error: {0}".format(err))
        assert True
    else:
        assert False, "Should throw exception error"


# Generated at 2022-06-24 21:12:17.228307
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [('one', 'two', 'three')]
    parameters = dict(four=1)
    assert check_required_one_of(terms, parameters)
    terms = [('one', 'two', 'three')]
    parameters = dict(two=2)
    assert check_required_one_of(terms, parameters)
    terms = [('one', 'two', 'three')]
    parameters = dict(one=1)
    assert check_required_one_of(terms, parameters)
    terms = [('one', 'two', 'three')]
    parameters = dict(three=3)
    assert check_required_one_of(terms, parameters)
    terms = [('one', 'two', 'three')]
    parameters = dict(one=1, two=2, three=3)
    assert check_required_

# Generated at 2022-06-24 21:12:24.151521
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'D2uCb-H.OJI=^z\x0b\\'
    var_0 = safe_eval(str_0)

    assert var_0 == 'D2uCb-H.OJI=^z\x0b\\'


# Generated at 2022-06-24 21:12:29.566504
# Unit test for function check_type_bytes
def test_check_type_bytes():
    try:
        str_0 = 'M(X,@\x0c.W\xf8:v\x15R\xf4\x1b)M\xbe\x00\x0f\x04f@\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        bytes_0 = check_type_bytes(str_0)
    except TypeError as error_msg:
        print(error_msg)


# Generated at 2022-06-24 21:12:31.296681
# Unit test for function check_type_dict
def test_check_type_dict():
    try:
        test_case_0()
    except TypeError:
        print("Test case 0 failed")


# Generated at 2022-06-24 21:12:34.416515
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'D2uCb-H.OJI=^z\x0b\\'
    var_0 = safe_eval(str_0)


# Generated at 2022-06-24 21:12:39.054422
# Unit test for function check_type_bytes
def test_check_type_bytes():
    str_0 = 'D2uCb-H.OJI=^z\x0b\\'
    var_0 = check_type_bytes(str_0)
    print(var_0)


# Generated at 2022-06-24 21:12:44.745800
# Unit test for function check_type_bits

# Generated at 2022-06-24 21:12:54.652631
# Unit test for function check_mutually_exclusive

# Generated at 2022-06-24 21:12:58.649572
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'D2uCb-H.OJI=^z\x0b\\'
    var_0 = safe_eval(str_0)
    assert var_0 == 'D2uCb-H.OJI=^z\x0b\\'


# Generated at 2022-06-24 21:13:05.205646
# Unit test for function check_type_dict

# Generated at 2022-06-24 21:13:12.660075
# Unit test for function check_required_together
def test_check_required_together():

    terms = [['a', 'b'], ['c', 'd', 'e']]
    parameters = {'a':1, 'b':1, 'c':1, 'd':1, 'e':1}

    assert check_required_together(terms, parameters) == []

    parameters.pop('e')
    try:
        assert check_required_together(terms, parameters) == [['c', 'd', 'e']]
    except TypeError as e:
        if not str(e).endswith(("c, d, e", "c, d, e found in ")):
            assert False

    parameters.pop('b')

# Generated at 2022-06-24 21:13:16.837639
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'D2uCb-H.OJI=^z\x0b\\'
    var_0 = safe_eval(str_0)

    assert var_0 == str_0


# Generated at 2022-06-24 21:13:23.399665
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert(check_required_arguments(None, None) == [])
    assert(check_required_arguments(
        {
            "foo": {"required": True},
            "bar": {}
        },
        {
            "foo": "quux",
            "baz": "qux"
        }
    ) == [])
    try:
        check_required_arguments(
            {
                "foo": {"required": True},
                "bar": {}
            },
            {}
        )
    except TypeError:
        assert(True)


# Generated at 2022-06-24 21:13:33.264253
# Unit test for function check_required_if
def test_check_required_if():

    # Test case 0
    # Passed
    str_0 = '\x13'
    str_1 = '\\Vu\\'
    str_2 = 'n'
    str_3 = '\x1f,`\x0b'
    lst_0 = ('\x0b', '\x0b', '\x0b', '\x0b')
    var_0 = test_case_0()
    str_4 = '@\x0f'
    str_5 = '\x1f,`\x0b'
    str_6 = 'Hd$\x02'
    lst_1 = ('\x0b', '\x0b', '\x0b', '\x0b')

# Generated at 2022-06-24 21:13:40.441372
# Unit test for function check_type_float
def test_check_type_float():
    str_1 = 'I-d^\x0c]\x0ct3\x1bD\x0c\x1f$Q(\x19\x0e\x15\x0eX\x0c\n\x1d?\x1b\x17@\x14\x0c\x0c\x03\x16'
    assert check_type_float(str_1) == 5.0
    str_2 = 'd3\x0b\x16\x1f\x14~\x0c]\x0c\x1b'
    assert check_type_float(str_2) == -5.0

# Generated at 2022-06-24 21:13:50.891438
# Unit test for function check_type_bytes
def test_check_type_bytes():
    try:
        assert(check_type_bytes("abc") == "abc")
    except TypeError as te:
        print("check_type_bytes(): Exception: " + str(te))
        pass
    try:
        assert(check_type_bytes("1MB") == 1048576)
    except TypeError as te:
        print("check_type_bytes(): Exception: " + str(te))
        pass
    try:
        assert(check_type_bytes("1M") == 1048576)
    except TypeError as te:
        print("check_type_bytes(): Exception: " + str(te))
        pass
    try:
        assert(check_type_bytes("1") == 1)
    except TypeError as te:
        print("check_type_bytes(): Exception: " + str(te))
        pass


# Generated at 2022-06-24 21:13:54.115382
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except Exception:
        # if we get an exception we didn't expect, bubble it up
        raise


# Generated at 2022-06-24 21:13:56.873721
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(13.0) == 13.0
    assert check_type_float('13.0') == 13.0

    try:
        check_type_float('abc')
    except TypeError:
        pass



# Generated at 2022-06-24 21:14:00.224917
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1+1") == 2
    assert safe_eval("2*2") == 4
    assert safe_eval("True")

    assert not safe_eval("__import__('os').system('ls')")
    assert not safe_eval("os.system('ls')")

    assert safe_eval("1 + 1") == 2


# Generated at 2022-06-24 21:14:15.429795
# Unit test for function check_required_one_of

# Generated at 2022-06-24 21:14:18.350435
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float('13') == 13
    assert check_type_float(13) == 13
    assert check_type_float('') == 0
    assert check_type_float(None) == 0
    assert check_type_float('test') == 0

test_cases = [
    test_case_0,
]

if __name__ == "__main__":
    for case in test_cases:
        case()

# Generated at 2022-06-24 21:14:24.035603
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')]
    ]

    parameters = {
        'state' : 'present',
        'path' : '/path/to/file',
        'someint' : 99,
        'bool_param': True,
        'string_param': 'string'
    }

    check_required_if(requirements, parameters)

# Generated at 2022-06-24 21:14:32.765311
# Unit test for function check_required_by
def test_check_required_by():
    # Test for a basic working example
    requirements = {
        'key_0': ['param_1', 'param_2'],
        'key_1': ['param_2', 'param_3'],
    }

    parameters = {
        'param_1': 'value 1',
        'param_2': 'value 2',
    }

    assert check_required_by(requirements, parameters) == {'key_1': ['param_3']}

    # Test for when the key is not in parameters, no error is raised and the
    # result is empty
    requirements = {
        'key_0': ['param_1', 'param_2'],
        'key_1': ['param_2', 'param_3'],
    }

    parameters = {'param_1': 'value 1'}

    assert check_required

# Generated at 2022-06-24 21:14:37.166148
# Unit test for function check_type_int
def test_check_type_int():
    str_0 = 'D2uCb-H.OJI=^z\x0b\\'

    # Test when value is a string
    try:
        var_0 = check_type_int(str_0)
        assert False
    except TypeError:
        assert True

    # Test when value is an int
    var_1 = check_type_int(1)
    assert var_1 == 1

    # Test when value is a float
    try:
        var_1 = check_type_int(1.0)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-24 21:14:46.466329
# Unit test for function check_type_float
def test_check_type_float():
    # unit tests for check_type_float
    #  Verify that value is a float or convert it to a float and return it
    #  Raises :class:`TypeError` if unable to convert to a float
    #  :arg value: float, int, str, or bytes to verify or convert and return.
    #  :returns: float of given value.
    print("[INFO] Executing test_check_type_float...")
    str_0 = 'D2uCb-H.OJI=^z\x0b\\'
    float_0 = check_type_float(str_0)

# Generated at 2022-06-24 21:14:53.998581
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = safe_eval('D2uCb-H.OJI=^z\x0b\\')
    str_1 = safe_eval('')
    str_2 = safe_eval('1.0')
    str_3 = safe_eval('str_0')
    str_4 = safe_eval('False')
    str_5 = safe_eval('.join')
    str_6 = safe_eval('list')
    str_7 = safe_eval('import areallycrazylongpackagenamehere')
    assert str_0 == 'D2uCb-H.OJI=^z\x0b\\'
    assert str_1 == ''
    assert str_2 == 1.0
    assert str_3 == 'str_0'
    assert str_4 == False
    assert str_

# Generated at 2022-06-24 21:14:56.520126
# Unit test for function check_type_dict
def test_check_type_dict():
    var_0 = 'D2uCb-H.OJI=^z\x0b\\'
    var_1 = safe_eval(var_0)
    if not var_1:
        print("check_type_dict is working correctly")
    else:
        print("check_type_dict is not working correctly")


# Generated at 2022-06-24 21:14:59.346891
# Unit test for function check_type_int
def test_check_type_int():
    str_0 = 'm7\x0e^$@\x0bw\x19WE\x1d!g\x0e5]N\x7fW\x14P\x0c\x11\x0e\x0c\x1f%\x1b\x1e\x0f^\x0c'
    int_0 = check_type_int(str_0)
    print(int_0)


# Generated at 2022-06-24 21:15:10.857981
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1000 Kb') == 1024000
    assert check_type_bits('1 Gb') == 1073741824
    assert check_type_bits('1 Tb') == 1099511627776
    assert check_type_bits('1 pb') == 1125899906842624
    assert check_type_bits('1 kb') == 1024
    assert check_type_bits(1024) == 1024
    assert check_type_bits(1048576) == 1048576
    assert check_type_bits('1.0 Kb') == 1024
    assert check_type_bits('1.0E2kb') == 10240
    assert check_type_bits('1.0E+2kb') == 10240

# Generated at 2022-06-24 21:15:22.372405
# Unit test for function check_type_bytes
def test_check_type_bytes():
    case1 = '0.5K'
    case2 = '500'
    case3 = '500ms'
    case4 = '500ms'
    case5 = '500ms'
    assert human_to_bytes(case1) == 512
    assert human_to_bytes(case2) == 500
    assert human_to_bytes(case3) == 1
    assert human_to_bytes(case4) == 1
    assert human_to_bytes(case5) == 1


# Generated at 2022-06-24 21:15:24.967963
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'D2uCb-H.OJI=^z\x0b\\'
    var_0 = safe_eval(str_0)
    assert var_0 == str_0



# Generated at 2022-06-24 21:15:30.887215
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'D2uCb-H.OJI=^z\x0b\\'

    var_0 = safe_eval(str_0)
    assert var_0 == str_0

    str_0 = ''

    var_0 = safe_eval(str_0)
    assert var_0 == str_0

    str_0 = "'/test-path' + '/test-path'"

    var_0 = safe_eval(str_0)
    assert var_0 == '/test-path/test-path'

    str_0 = "'/test-path' + '/test-path'"

    var_0 = safe_eval(str_0)
    assert var_0 == '/test-path/test-path'

    str_0 = "'/test-path' + '/test-path'"

    var_

# Generated at 2022-06-24 21:15:32.537673
# Unit test for function check_required_by
def test_check_required_by():
    try:
        test_case_0()
    except NotImplementedError:
        pass


# Generated at 2022-06-24 21:15:39.476322
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {
        'a': ['b', 'c'],
        'd': 'b'
    }
    parameters = {
        'a': 'foo',
        'b': 'bar'
    }
    result = check_required_by(requirements, parameters)
    assert result == {}
    parameters = {
        'b': 'bar'
    }
    result = check_required_by(requirements, parameters)
    assert result == {'a': ['b', 'c'], 'd': ['b']}


# Generated at 2022-06-24 21:15:40.621801
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert human_to_bytes("1K") == 1024


# Generated at 2022-06-24 21:15:49.232007
# Unit test for function check_type_dict
def test_check_type_dict():
    # Assigning dictionary to var_0
    var_0 = {"a":"z","b":"x"}
    # Calling check_type_dict() with argument var_0
    var_1 = check_type_dict(var_0)

    # var_1 should be equal to var_0
    assert var_1 == var_0

    str_0 = 'D2uCb-H.OJI=^z\x0b\\'
    try:
        # Calling check_type_dict() with argument str_0
        check_type_dict(str_0)
    except:
        pass
    else:
        assert False # The function should raise exception

    str_0 = '{"date":"2019-04-24","time":"16:28:04","ip":"67.129.241.32"}'
    # Calling check_type

# Generated at 2022-06-24 21:15:56.926751
# Unit test for function check_required_one_of
def test_check_required_one_of():
    str_0 = '\x7f\x13^\x7f\x05\x7f\x0e'
    str_1 = '\x7f\x13^\x7f\x05\x7f\x0e'
    str_2 = '\x7f\x13^\x7f\x05\x7f\x0e'
    str_3 = '\x7f\x13^\x7f\x05\x7f\x0e'
    # In the following check, an error has been introduced
    check_required_one_of([[str_1, str_2, str_3]], {str_0: 'z\x0b\\'})


# Generated at 2022-06-24 21:16:03.148844
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = "'G@IuA&nIKJtVuNtA&W8Vvai+D9rnKVuUmOl"
    var_0 = safe_eval(str_0)
    assert var_0 == "'G@IuA&nIKJtVuNtA&W8Vvai+D9rnKVuUmOl"



# Generated at 2022-06-24 21:16:06.954421
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1m') == 1048576


# ==============================================================================
#
#   MAIN ENTRY POINT
#
# ==============================================================================

if __name__ == '__main__':
    print("Running test suite for Utils")
    test_case_0()
    print("Done.")

# Generated at 2022-06-24 21:16:16.400738
# Unit test for function check_type_bits
def test_check_type_bits():
    test_input = "00100100"

    # Analyzed by Python decompiler
    for (check_type_bits.__defaults__, check_type_bits.__code__,
             check_type_bits.__globals__, *_) in ((None,
             test_case_0.__code__,
             None,
             None), ):
        var_0 = check_type_bits(test_input)


if __name__ == '__main__':
    test_check_type_bits()

# Generated at 2022-06-24 21:16:22.260240
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1kb') == 1000
    assert check_type_bits('0') == 0

    with pytest.raises(TypeError):
        check_type_bits(1)
    with pytest.raises(TypeError):
        check_type_bits('x')


# Generated at 2022-06-24 21:16:24.848624
# Unit test for function check_type_float
def test_check_type_float():
    test_case_0()


# Generated at 2022-06-24 21:16:34.389741
# Unit test for function check_type_int
def test_check_type_int():
    value_0 = '3'
    value_1 = '123'
    value_2 = '2'
    value_3 = '-10'
    var_0 = check_type_int(value_0)
    assert var_0 == 3
    var_1 = check_type_int(value_1)
    assert var_1 == 123
    var_2 = check_type_int(value_2)
    assert var_2 == 2
    var_3 = check_type_int(value_3)
    assert var_3 == -10


# Generated at 2022-06-24 21:16:45.139041
# Unit test for function check_required_by
def test_check_required_by():
    # Test for no requirements
    requirements = None
    parameters = {}
    result = check_required_by(requirements, parameters)
    assert result == {}
    # Test that lists of strings work
    requirements = {
        'foo': ['baz', 'bar']
    }
    parameters = {
        'foo': 'baz'
    }
    result = check_required_by(requirements, parameters)
    assert result == {}
    # Test that only a single list item is required
    result = check_required_by(requirements, parameters,
                               options_context=['options_context_0'])
    assert result == {}
    # Test that a required list item is required
    requirements = {
        'foo': ['baz', 'bar']
    }