

# Generated at 2022-06-24 21:07:53.192249
# Unit test for function check_required_together
def test_check_required_together():

    # Test 1: Basic case
    # Test 1.0: test without options_context
    tuple_0 = (('param_0', 'param_1'), ('param_2',))
    list_0 = list(tuple_0)
    var_0 = check_required_together(list_0, {})
    assert var_0 == []

    # Test 1.1: test with options_context
    tuple_1 = (('param_0', 'param_1'), ('param_2',))
    list_1 = list(tuple_1)
    var_1 = check_required_together(list_1, {}, ['opt_1'])
    assert var_1 == []

    # Test 2: Only one parameter in the list
    # Test 2.0: test without options_context

# Generated at 2022-06-24 21:07:57.699686
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval('str')
    assert result == 'str'

    result = safe_eval('"str"')
    assert result == 'str'

    result = safe_eval('{"str": 1, "str_1": 2}', include_exceptions=True)
    assert result == ({'str': 1, 'str_1': 2}, None)

    result = safe_eval('["str", 1, 2.0, True]')
    assert result == ['str', 1, 2.0, True]

    result = safe_eval('import os')
    assert result == 'import os'

    result = safe_eval('os.path.join("foo", "bar")')
    assert result == 'os.path.join("foo", "bar")'



# Generated at 2022-06-24 21:07:58.915250
# Unit test for function check_type_bits
def test_check_type_bits():
    tuple_0 = ()
    var_0 = check_type_bits(tuple_0)


# Generated at 2022-06-24 21:08:02.582651
# Unit test for function check_type_int
def test_check_type_int():
    try:
        int_0 = check_type_int(tuple_0)
        assert False, "Expected exception not raised"
    except TypeError as e:
        assert e.message == "'tuple' cannot be converted to an int"


# Generated at 2022-06-24 21:08:11.433058
# Unit test for function check_required_arguments
def test_check_required_arguments():

    try:
        tuple_0 = ('F', 'p', 'T', 'n', 'h', 't', 'c', 'o', 'I', 'v', 'j', 's', 'u')
        dict_0 = get_random_dict(tuple_0)
        list_0 = get_random_list(tuple_0)
        str_0 = get_random_string()

        check_required_arguments(dict_0, list_0)
    except TypeError as inst:
        assert 'missing required arguments: %s' in str(inst)
        assert 'found in %s' in str(inst)
    else:
        assert False, "expected exception"



# Generated at 2022-06-24 21:08:15.702474
# Unit test for function safe_eval
def test_safe_eval():
    # Check that it returns the expected result with default arguments
    assert safe_eval('1 + 1') == 2
    # Check that it returns the expected result with modified arguments
    assert safe_eval('a', {'a': 2}) == 2
    # Check that it returns the expected result when an exception is raised
    assert safe_eval('1/0') == '1/0'



# Generated at 2022-06-24 21:08:25.747685
# Unit test for function check_required_if
def test_check_required_if():
    argument_spec = {}
    argument_spec['required_if'] = [
        ['key1', 'val1', ('key3',), True],
        ['key2', 'val2', ('key3', 'key4')],
        ['key3', 'val3', ('key5',), False]
    ]
    parameters = {'key1': 'val1', 'key2': 'val2', 'key4': 'val4'}
    results = check_required_if(argument_spec['required_if'], parameters)
    assert(type(results) == list)
    assert(len(results) == 1)
    assert(type(results[0]) == dict)
    assert(results[0]['parameter'] == 'key2')


# Generated at 2022-06-24 21:08:31.735263
# Unit test for function check_required_arguments
def test_check_required_arguments():
    
    module_args = []
    missing = check_required_arguments(module_args, {})
    # Check if 'missing' is equal to []
    if missing != []:
        print("test_check_required_arguments FAILED")
    else:
        print("test_check_required_arguments PASSED")



# Generated at 2022-06-24 21:08:39.131842
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'arg1':{'required':True},
        'arg2':{'required':False},
        'arg3':{'required':True},
        'arg4':{'required':False},
        'arg5':{'required':True},
    }
    parameter = {
        'arg1':"1",
        'arg2':"2",
        'arg3':"3",
    }
    result = check_required_arguments(argument_spec, parameter)
    assert result == ['arg5']


# Generated at 2022-06-24 21:08:49.656151
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # mutually_exclusive=[['name', 'id'], ['provider']]
    tuple_1 = ('name', 'id')
    dict_1 = {'name': 'foo', 'id': 'bar'}
    tuple_2 = ('provider',)
    dict_2 = {'id': 'foo'}
    tuple_3 = ('name', 'id')
    dict_3 = {'name': 'foo'}
    tuple_4 = ('name', 'id')
    dict_4 = {'name': 'foo', 'id': 'bar'}
    dict_5 = {'name': 'foo', 'bar': 'bar'}
    # source: src/test/test_argspec.py

# Generated at 2022-06-24 21:09:01.809356
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Case 0
    tuple_0 = ()
    parameters_0 = {}
    options_context_0 = None
    result_0 = check_mutually_exclusive(tuple_0, parameters_0, options_context_0)
    print(result_0)


# Generated at 2022-06-24 21:09:09.327243
# Unit test for function check_type_bytes
def test_check_type_bytes():
    """Test setting the value to a string will cause the value to be converted to bytes upon setting."""
    # FIXME: We can not support a bytes type in AnsibleModule since we do not support long
    #        return types via the module_common_argspec.
    #        See https://github.com/ansible/ansible/issues/24154
    #        We can not test this method because of this problem.
    pass



# Generated at 2022-06-24 21:09:11.555357
# Unit test for function check_type_bits
def test_check_type_bits():
    tuple_0 = []
    assert check_type_bits(tuple_0) == 0


# Generated at 2022-06-24 21:09:15.228908
# Unit test for function check_type_int
def test_check_type_int():
    tuple_0 = ()
    var_0 = check_type_int(tuple_0)


# Generated at 2022-06-24 21:09:21.212162
# Unit test for function check_required_arguments
def test_check_required_arguments():
    arguments = {'foo': {'required': True}}
    parameters = dict()
    msg = "missing required arguments: foo"
    with pytest.raises(TypeError) as excinfo:
        check_required_arguments(arguments, parameters)
    assert excinfo.value.message == msg



# Generated at 2022-06-24 21:09:30.097846
# Unit test for function check_required_if
def test_check_required_if():
    assert check_required_if(requirements=None, parameters='') == []
    assert check_required_if(requirements=[], parameters='') == []
    assert check_required_if(requirements=[('state', 'present', ('path',), True), ('someint', 99, ('bool_param', 'string_param'))], parameters='{"state": "present", "path": "/tmp/filename"}') == []
    assert check_required_if(requirements=[('state', 'present', ('path',), False), ('someint', 99, ('bool_param', 'string_param'))], parameters='{"state": "present", "path": "/tmp/filename"}') == []

# Generated at 2022-06-24 21:09:36.486604
# Unit test for function check_required_together
def test_check_required_together():
    # Test with no parameter
    try:
        check_required_together(None, None)
    except TypeError as e:
        print("TypeError: " + str(e))

    # Test with invalid input
    try:
        check_required_together(["a", "b", "c"], None)
    except TypeError as e:
        print("TypeError: " + str(e))


# Generated at 2022-06-24 21:09:47.071674
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():

    #Testing with valid case
    params = {'a':10, 'b':20}
    terms = ['a','b']
    try:
        check_mutually_exclusive(terms, params)
    except TypeError as e:
        assert False

    terms = [['a', 'b']]
    try:
        check_mutually_exclusive(terms, params)
    except TypeError as e:
        assert False

    #Testing with invalid case
    params = {'a':10, 'b':20, 'c':30}
    terms = ['a','b','c']
    try:
        check_mutually_exclusive(terms, params)
    except TypeError as e:
        assert True

    terms = [['a', 'b'], ['c']]

# Generated at 2022-06-24 21:09:54.656683
# Unit test for function safe_eval
def test_safe_eval():
    assert type(safe_eval('10')) is int
    assert type(safe_eval('10')) is int
    assert type(safe_eval('True')) is bool
    assert type(safe_eval('False')) is bool
    assert type(safe_eval('[1,2,3]')) is list
    assert type(safe_eval('{"a":1, "b":2, "c":3}')) is dict
    assert type(safe_eval('{"a":"1", "b":"2", "c":"3"}')) is dict
    assert type(safe_eval('{"a":1, "b":2, "c":3}')) is dict
    assert type(safe_eval('None')) is type(None)
    assert safe_eval('{"a":10}') == {"a":10}
    assert safe_

# Generated at 2022-06-24 21:10:01.234770
# Unit test for function check_required_if
def test_check_required_if():
    # These are the required parameter values
    req_param_1 = 'req_param_1'
    req_param_2 = 'req_param_2'
    req_param_3 = 'req_param_3'
    req_param_4 = 'req_param_4'

    # These are the given parameter values
    param_1 = 'param_1'
    param_2 = 'param_2'
    param_3 = 'param_3'
    param_4 = 'param_4'
    param_5 = 'param_5'
    param_6 = 'param_6'
    param_7 = 'param_7'
    param_8 = 'param_8'

    # This is a list of all of the parameter values

# Generated at 2022-06-24 21:10:15.642746
# Unit test for function check_type_int
def test_check_type_int():
    output_0 = check_type_int(1)
    assert int == type(output_0)
    assert 1 == output_0
    output_1 = check_type_int('2')
    assert int == type(output_1)
    assert 2 == output_1
    output_2 = check_type_int('3.0')
    assert int == type(output_2)
    assert 3 == output_2
    output_3 = check_type_int('4.1')
    assert int == type(output_3)
    assert 4 == output_3
    output_4 = check_type_int(5.0)
    assert int == type(output_4)
    assert 5 == output_4
    output_5 = check_type_int(6.1)
    assert int == type(output_5)
   

# Generated at 2022-06-24 21:10:24.271406
# Unit test for function check_required_together
def test_check_required_together():
    terms = None

# Generated at 2022-06-24 21:10:36.852012
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1kB') == 1000
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1KB') == 1000
    assert check_type_bits('1MB') == 1000000
    assert check_type_bits('1mb') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1mB') == 1000000
    assert check_type_bits('1gB') == 1000000000
    assert check_type_bits('1GB') == 1073741824
    assert check_type_bits('1Gb') == 8589934592
    assert check_type_bits('1gB') == 1000000000

# Generated at 2022-06-24 21:10:46.253467
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Test the following:
    #   Test setting the value to a string will cause the value to be converted to bytes upon setting.
    str_0 = 'Test setting the value to a string will cause the value to be converted to bytes upon setting.'

    bytes_0 = check_type_bytes(str_0)
    print('byte_size: ' + str(sys.getsizeof(bytes_0)))
    print('str_size: ' + str(sys.getsizeof(str_0)))
    print(bytes_0)

    # Test the following:
    #   Test setting the value directly to bytes will cause the value to be converted to an integer upon getting.
    #   Test that setting the value directly to bytes will use the bytes object.

# Generated at 2022-06-24 21:10:54.037922
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert count_terms([], {}) == 0
    assert count_terms('test', {'test': 'val'}) == 1
    assert count_terms('test', {}) == 0
    assert count_terms('test', {'test2': 'val'}) == 0
    assert count_terms('test', {'test': 'val', 'test2': 'val'}) == 1
    assert count_terms(['test', 'test2'], {'test': 'val', 'test2': 'val'}) == 2
    assert count_terms(['test', 'test2'], {'test': 'val', 'test2': 'val', 'test3': 'val'}) == 2
    assert count_terms(['test', 'test2'], {'test': 'val'}) == 1

    # When no terms are provided returns an empty list
   

# Generated at 2022-06-24 21:11:02.798887
# Unit test for function check_required_if
def test_check_required_if():
    requirement_0 = 'foo'
    requirement_1 = 'bar'
    requirement_2 = 'baz'
    requirement_3 = 'qux'
    requirement_4 = [requirement_0, requirement_1, 'qux', 'qux']
    requirement_5 = [requirement_2, requirement_3, 'qux', 'qux']
    requirement_6 = (requirement_0, requirement_1, 'qux', 'qux')
    requirement_7 = (requirement_2, requirement_3, 'qux', 'qux')
    requirement_8 = 'corge'
    requirement_9 = 'grault'
    requirement_10 = 'garply'
    requirement_11 = 'waldo'
    requirement_12 = [requirement_8, requirement_9, 'qux', 'qux']
   

# Generated at 2022-06-24 21:11:14.403953
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = 'Incorrect number of arguments to __init__()'
    with pytest.raises(Exception, match=str_0):
        check_mutually_exclusive(10, 20, 30, 40)
    str_0 = 'n of terms to check'
    with pytest.raises(TypeError, match=str_0):
        check_mutually_exclusive(10, 20)
    str_0 = 'parameters are mutually exclusive'
    with pytest.raises(TypeError, match=str_0):
        str_1 = 'Test setting the value to a string will cause the value to be converted to bytes upon setting.'
        str_2 = 'Incorrect number of arguments to __init__()'
        str_3 = 'n of terms to check'
        str_4 = 'parameters are mutually exclusive'
        check

# Generated at 2022-06-24 21:11:19.678202
# Unit test for function safe_eval
def test_safe_eval():
    assert 1 == 1
    assert safe_eval('False') == False
    assert safe_eval('True') == True
    assert safe_eval('1') == 1
    assert safe_eval('1 + 2') == 3



# Generated at 2022-06-24 21:11:21.265356
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert(check_type_bytes(str_0) == b'Test setting the value to a string will cause the value to be converted to bytes upon setting.')


# Generated at 2022-06-24 21:11:23.047998
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    
    # 
    # Testing the argument None, parameters:
    # 
    #  None
    return True

# Generated at 2022-06-24 21:11:37.935272
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    params_0 = {
        'sh' : 'nonde',
        'nonde' : 'sh'
    }
    terms_0 = ['sh', 'nonde']
    assert check_mutually_exclusive(terms_0, params_0) == [term_0]

    params_1 = {
        'info' : 'hogehoge',
        'error' : 'hogehoge'
    }
    terms_1 = [
        ['info', 'error'],
        ['sh', 'nonde']
    ]
    assert check_mutually_exclusive(terms_1, params_1) == [terms_1[0]]

    params_2 = {
        'hoge' : 'hogehoge',
        'fuga' : 'hogehoge'
    }

# Generated at 2022-06-24 21:11:40.696574
# Unit test for function check_type_bits
def test_check_type_bits():
    str_0 = 'Test setting the value to a string will cause the value to be converted to bytes upon setting.'
    # Output: 752
    print(check_type_bits(str_0))

if __name__ == '__main__':
    test_check_type_bits()

# Generated at 2022-06-24 21:11:45.126968
# Unit test for function check_type_float
def test_check_type_float():
    str_0 = 'Test setting the value to a string will cause the value to be converted to bytes upon setting.'
    #assert check_type_float(str_0) == 0.1
    #assert False # TODO: implement your test here


# Generated at 2022-06-24 21:11:48.762869
# Unit test for function check_required_together
def test_check_required_together():
    str_0 = 'Test setting the value to a string will cause the value to be converted to bytes upon setting.'

# Generated at 2022-06-24 21:11:56.389480
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = None
    parameters = None
    assert check_required_one_of(terms, parameters) == []

    terms = [['a', 'b'], ['c', 'd', 'e']]
    parameters = None
    assert check_required_one_of(terms, parameters) == [['a', 'b'], ['c', 'd', 'e']]

    terms = [['a', 'b'], ['c', 'd', 'e']]
    parameters = dict()
    assert check_required_one_of(terms, parameters) == [['a', 'b'], ['c', 'd', 'e']]

    terms = [['a', 'b'], ['c', 'd', 'e']]
    parameters = dict(b=123)

# Generated at 2022-06-24 21:12:00.689913
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # parameters = {}
    # required_parameters = None
    # assert (check_missing_parameters(parameters, required_parameters) == None)
    test_case_0()


# Generated at 2022-06-24 21:12:01.969617
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576



# Generated at 2022-06-24 21:12:04.779174
# Unit test for function check_type_bits
def test_check_type_bits():
    # Test case 1
    str_1 = '1024k'
    result_1 = check_type_bits(str_1)
    assert result_1 == 1048576

    # Test case 2
    str_2 = '1Mb'
    result_2 = check_type_bits(str_2)
    assert result_2 == 1048576



# Generated at 2022-06-24 21:12:07.411990
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(True) == True
    assert safe_eval(10) == 10
    assert safe_eval('10') == 10
    assert safe_eval('10', include_exceptions=True) == (10, None)


# Generated at 2022-06-24 21:12:13.708674
# Unit test for function check_required_if
def test_check_required_if():
    parameters = {}
    req = []
    req.append({
        'key': 'state',
        'val': 'present',
        'requirements': ('path',),
        'is_one_of': True,
    })
    req.append({
        'key': 'someint',
        'val': 99,
        'requirements': ('bool_param', 'string_param'),
    })
    options_context = ["asdf", "qwer"]
    expected = [
        {
            'parameter': 'someint',
            'value': 99,
            'requirements': ('bool_param', 'string_param'),
            'missing': ['bool_param', 'string_param'],
            'requires': 'all',
        }
    ]
    result = check_required_if(req, parameters, options_context)

# Generated at 2022-06-24 21:12:28.172064
# Unit test for function check_type_bytes

# Generated at 2022-06-24 21:12:37.579330
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'a':'b', 'c':'d'}
    parameters = {'a':'b', 'c':'d'}
    options_context = ['test1', 'test2']
    assert check_required_by(requirements, parameters, options_context) == {}
    requirements = {'a':'b', 'c':'d'}
    parameters = {'a':'b', 'e':'f'}
    options_context = ['test1', 'test2']
    assert check_required_by(requirements, parameters, options_context) == {}
    requirements = {'a':'b', 'c':'d'}
    parameters = {'a':'b', 'd':'e'}
    options_context = ['test1', 'test2']

# Generated at 2022-06-24 21:12:43.024805
# Unit test for function check_required_together
def test_check_required_together():
    terms = [('(0, 1, 2)', '<class \'list\'>'), ('(0, 1, 2)', '<class \'list\'>')]
    parameters = {'<class \'list\'>': 3, '(0, 1, 2)': 3, '__exception__': False, '__ansible_module_name__': 'Test module'}
    assert (check_required_together(terms, parameters) == []), "Failed to check required together"



# Generated at 2022-06-24 21:12:46.389249
# Unit test for function check_required_if
def test_check_required_if():
    assert check_required_if(requirements=[['state', 'present', ('path',), True]],
            parameters={})


# Generated at 2022-06-24 21:12:51.169510
# Unit test for function check_type_bytes
def test_check_type_bytes():
    str_0 = 'Test setting the value to a string will cause the value to be converted to bytes upon setting.'
    value = check_type_bytes(str_0)
    assert(value == b'Test setting the value to a string will cause the value to be converted to bytes upon setting.')


# Generated at 2022-06-24 21:12:53.582793
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('2mb') == 2097152

# Generated at 2022-06-24 21:12:56.804857
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together('Test setting the value to a string will cause the value to be converted to bytes upon setting.','A string object is an ordered collection of characters, starting with index 0.') == None


# Generated at 2022-06-24 21:13:02.213009
# Unit test for function check_required_if
def test_check_required_if():
    assert check_required_if() == None



# Generated at 2022-06-24 21:13:03.280102
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = str_0
    result = check_missing_parameters(parameters)
    print(result)


# Generated at 2022-06-24 21:13:11.231534
# Unit test for function check_type_bytes
def test_check_type_bytes():
    str_0 = 'Test setting the value to a string will cause the value to be converted to bytes upon setting.'
    try:
        check_type_bytes(str_0)
    except TypeError:
        print('good')
    else:
        print('bad')
    str_0 = 'Test setting the value to a string will cause the value to be converted to bytes upon setting.'
    try:
        check_type_bytes(str_0)
    except TypeError:
        print('good')
    else:
        print('bad')
    str_0 = 'Test setting the value to a string will cause the value to be converted to bytes upon setting.'
    try:
        check_type_bytes(str_0)
    except TypeError:
        print('good')
    else:
        print('bad')

# Generated at 2022-06-24 21:13:24.680122
# Unit test for function check_required_together
def test_check_required_together():
    terms = ['test_0', 'test_1', 'test_2']
    parameters = {'test_1': 'value_0', 'test_2': 'value_1'}
    options_context = 'test_0'
    assert check_required_together(terms, parameters, options_context) is None
    assert check_required_together(terms, parameters) is None
    parameters = {'test_1': 'value_0', 'test_2': 'value_1', 'test_3': 'value_2'}
    try:
        check_required_together(terms, parameters)
    except TypeError:
        pass
    else:
        assert False
    try:
        check_required_together(terms, parameters, options_context)
    except TypeError:
        pass
    else:
        assert False

# Unit

# Generated at 2022-06-24 21:13:33.607972
# Unit test for function check_required_if
def test_check_required_if():
    requirements = []

    parameters = dict()

    # Test with valid parameters
    try:
        check_required_if(requirements, parameters)
    except Exception as e:
        print("Exception in user code:")
        print('-' * 60)
        traceback.print_exc(file=sys.stdout)
        print('-' * 60)
        raise
    # Test with invalid parameters
    requirements = None
    try:
        check_required_if(requirements, parameters)
    except Exception as e:
        print("Exception in user code:")
        print('-' * 60)
        traceback.print_exc(file=sys.stdout)
        print('-' * 60)
        raise



# Generated at 2022-06-24 21:13:43.731396
# Unit test for function check_required_if
def test_check_required_if():
    # Testing exceptions
    requirements = [
        [
            'parameter_0',
            str_0,
            (
                'parameter_1',
            ),
            True,
        ],
        [
            'someint',
            99,
            (
                'bool_param',
                'string_param',
            ),
        ],
    ]

    parameters = {
        'bool_param': False,
        'parameter_0': 'Test setting the value to a string will cause the value to be converted to bytes upon setting.',
        'parameter_1': 'parameter_1',
        'someint': 99,
    }

    options_context = [
        'someint',
    ]

# Generated at 2022-06-24 21:13:47.088535
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = ['a', 'v']
    parameters = {'b':'c'}
    options_context = {'a':'b'}
    check_mutually_exclusive(terms, parameters, options_context)



# Generated at 2022-06-24 21:13:53.868608
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = "10"
    str_1 = '10'
    str_2 = '100'
    str_3 = 'test string'
    str_4 = "test"
    str_5 = "True"
    str_6 = '1'
    str_7 = "string with 5"
    str_8 = "False"
    str_9 = "true"
    ret_0 = safe_eval(str_0)
    ret_1 = safe_eval(str_1)
    ret_2 = safe_eval(str_2)
    ret_3 = safe_eval(str_3)
    ret_4 = safe_eval(str_4)
    ret_5 = safe_eval(str_5)
    ret_6 = safe_eval(str_6)
    ret_7 = safe_eval

# Generated at 2022-06-24 21:14:01.379245
# Unit test for function check_required_together

# Generated at 2022-06-24 21:14:11.680045
# Unit test for function check_required_if
def test_check_required_if():
    debug_0 = test_case_0()

# Generated at 2022-06-24 21:14:19.118680
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    parameters = {
        'x': "apple", 
        'y': "cherry"
    }

    terms = [
        {
            'x': "apple", 
            'z': "pineapple"
        }, 
        {
            'a': "orange", 
            'b': "grapefruit"
        }
    ]

    # Call method
    # Check whether the result is as expected
    assert (result == expected)


# Generated at 2022-06-24 21:14:26.575801
# Unit test for function check_required_if
def test_check_required_if():
    # Create args
    args = {}
    args['requirements'] = {}

    # Call method
    try:
        check_required_if(**args)
    except Exception as e:
        assert 'missing required arguments: requirements' in str(e)
    else:
        assert False, 'ExpectedException was not thrown'


# Generated at 2022-06-24 21:14:28.159575
# Unit test for function check_required_if
def test_check_required_if():
    assert False


# Generated at 2022-06-24 21:14:42.908101
# Unit test for function check_required_together
def test_check_required_together():
    str_0 = 'l'
    var_0 = check_required_together(str_0, str_0)
    assert var_0 == []

    str_1 = 'l'
    var_1 = check_required_together(str_1, str_1)
    assert var_1 == []

    str_2 = 'l'
    var_2 = check_required_together(str_2, str_2)
    assert var_2 == []

    str_3 = 'l'
    var_3 = check_required_together(str_3, str_3)
    assert var_3 == []

    str_4 = 'l'
    var_4 = check_required_together(str_4, str_4)
    assert var_4 == []

    str_5 = 'l'

# Generated at 2022-06-24 21:14:52.053514
# Unit test for function check_required_if
def test_check_required_if():
    a = ['name', 'a', ['b'], False]
    b = ['name', 'a', ['b'], False]
    c = ['name', 'a', ['b'], False]
    d = ['name', 'a', ['b'], False]
    e = ['name', 'a', ['b'], False]
    param = ['name', 'a', ['b'], False]
    param = ['name', 'a', ['b'], False]
    param = ['name', 'a', ['b'], False]
    param = ['name', 'a', ['b'], False]
    param = ['name', 'a', ['b'], False]
    param = ['name', 'a', ['b'], False]
    param = ['name', 'a', ['b'], False]

# Generated at 2022-06-24 21:14:54.867122
# Unit test for function check_required_together
def test_check_required_together():
    str_0 = 'l'
    var_0 = check_required_together(str_0, str_0)
    assert var_0 == []


# Generated at 2022-06-24 21:15:01.280217
# Unit test for function check_required_arguments
def test_check_required_arguments():
    str_1 = str()
    str_2 = str()
    var_0 = check_required_arguments(str_1, str_2)
    print("test_check_required_arguments: TEST 1")
    print(var_0)
    print("test_check_required_arguments: TEST 2")
    print(str_2)
    print("test_check_required_arguments: TEST 3")
    print(str_1)
    return var_0


# Generated at 2022-06-24 21:15:10.500444
# Unit test for function safe_eval
def test_safe_eval():
    result = safe_eval('1+1')
    assert result == 2
    result = safe_eval('1+1', include_exceptions=True)
    assert result[0] == 2
    assert result[1] is None
    result = safe_eval('1+1', include_exceptions=True, locals={'a': 2})
    assert result[0] == 3
    assert result[1] is None
    result = safe_eval('1+1', include_exceptions=True, locals={'a': 'a'})
    assert result[0] == '1+1'
    assert isinstance(result[1], TypeError)
    result = safe_eval('import os')
    assert result == 'import os'
    result = safe_eval('import os', include_exceptions=True)

# Generated at 2022-06-24 21:15:16.843884
# Unit test for function check_type_dict
def test_check_type_dict():
    char_0 = 'l'
    list_0 = [char_0]
    char_1 = 'l'
    tuple_0 = (char_0, list_0, char_1)
    char_2 = 'l'
    tuple_1 = (char_0, list_0, char_1)
    tuple_2 = (char_0, tuple_0, tuple_1)
    str_0 = 'l'
    var_0 = check_type_dict(str_0)
    str_1 = 'l'
    var_1 = check_type_dict(str_1, str_1)
    str_2 = 'l'
    var_2 = check_type_dict(str_2)


# Generated at 2022-06-24 21:15:26.230569
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert(check_type_bytes(52)) == 52
    assert(check_type_bytes(32)) == 32
    assert(check_type_bytes(12)) == 12
    assert(check_type_bytes(72)) == 72
    assert(check_type_bytes(72)) == 72
    assert(check_type_bytes(72)) == 72
    assert(check_type_bytes('l')) == 'l'
    assert(check_type_bytes('l')) == 'l'
    assert(check_type_bytes('l')) == 'l'
    assert(check_type_bytes('l')) == 'l'
    assert(check_type_bytes('l')) == 'l'
    assert(check_type_bytes('l')) == 'l'
    assert(check_type_bytes(82)) == 82

# Generated at 2022-06-24 21:15:30.050487
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # test 0
    str_0 = 'l'
    str_1 = 'l'
    var_0 = check_missing_parameters(str_0, str_1)
    assert var_0 == []



# Generated at 2022-06-24 21:15:35.364136
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = 'l'
    var_0 = check_mutually_exclusive(str_0, str_0)


# Generated at 2022-06-24 21:15:38.520417
# Unit test for function check_required_together
def test_check_required_together():
    var_1 = 'b'
    var_0 = check_required_together(var_1, var_1, var_1)

    assert var_0 is not None


# Generated at 2022-06-24 21:15:49.688187
# Unit test for function check_required_together
def test_check_required_together():
    str_0 = 'secret key'
    str_1 = ['secret key', 'access key']
    str_2 = 'access key'
    str_3 = 'alicloud_rds'
    str_4 = 'alicloud_nas_access_group_attachment'
    str_5 = 'alicloud_nas_access_rule'
    str_6 = 'alicloud_nas_mount_target'
    str_7 = 'alicloud_nas_filesystem'
    str_8 = 'alicloud_nas_access_group'
    str_9 = 'alicloud_oss_bucket_info'
    str_10 = 'alicloud_ram_group_policy'
    str_11 = 'alicloud_ram_user_group_membership'


# Generated at 2022-06-24 21:15:50.997692
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576


# Generated at 2022-06-24 21:15:55.971662
# Unit test for function check_required_if
def test_check_required_if():
    str_0 = 'c'
    str_1 = 'X'
    str_2 = 'r'
    var_0 = (str_1, str_0, str_2)
    str_3 = 'R'
    dict_0 = dict(a=str_3)
    assert check_required_if([var_0], dict_0)


# Generated at 2022-06-24 21:15:57.803273
# Unit test for function check_type_dict
def test_check_type_dict():

    # Case 0
    str_0 = 'l'
    var_0 = check_type_dict(str_0)


# Generated at 2022-06-24 21:16:07.362135
# Unit test for function check_required_together
def test_check_required_together():
    str_0 = 'l'
    var_0 = check_required_together(str_0, str_0)
    assert(var_0 == None)
    str_1 = 'j'
    var_1 = check_required_together(str_0, str_1)
    assert(var_1 == None)
    str_2 = 't'
    var_2 = check_required_together(str_1, str_2)
    assert(var_2 == None)
    str_3 = 'h'
    var_3 = check_required_together(str_2, str_3)
    assert(var_3 == None)
    str_4 = 'f'
    var_4 = check_required_together(str_3, str_4)
    assert(var_4 == None)
    str_5

# Generated at 2022-06-24 21:16:10.009218
# Unit test for function check_required_together
def test_check_required_together():
    res = check_required_together('l', 'l')
    assert res is not None


# Generated at 2022-06-24 21:16:14.227718
# Unit test for function check_required_if
def test_check_required_if():
    assert check_required_if('test')
    assert check_required_if('test')
    assert check_required_if('test')
    assert check_required_if('test')
    assert check_required_if('test')
    assert check_required_if('test')
    assert check_required_if('test')
    assert check_required_if('test')
    assert check_required_if('test')
    assert check_required_if('test')


# Generated at 2022-06-24 21:16:25.661965
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1024b') == 1024
    assert check_type_bits('1024') == 1024
    assert check_type_bits('1k') == 1024
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1K') == 1024
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1m') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1G') == 1073741824
    assert check_type_bits('1Gb') == 1073741824

# Generated at 2022-06-24 21:16:27.961146
# Unit test for function check_required_together
def test_check_required_together():
    print("test_check_required_together")
    try:
        test_case_0()
    except TypeError as expected:
        pass


# Generated at 2022-06-24 21:16:35.142972
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits("1048576") == 8388608
    assert check_type_bits("1Mb") == 8388608
    assert check_type_bits("1M") == 8388608
    assert check_type_bits("1Mib") == 1048576
    assert check_type_bits("1Mi") == 1048576

try:
    # Unit test for function check_type_bytes
    def test_check_type_bytes():
        assert check_type_bytes("1048576") == 1048576
        assert check_type_bytes("1M") == 1048576
        assert check_type_bytes("1Mib") == 1310720
        assert check_type_bytes("1Mi") == 1310720
except:
    pass

if __name__ == '__main__':
    test_case_