

# Generated at 2022-06-24 21:07:16.065488
# Unit test for function check_required_arguments
def test_check_required_arguments():
    args = {'arg_2': {'required': False},
            'arg_1': {'required': True}}
    params = {'arg_1': 1}

    assert check_required_arguments(args, params) == []


# Generated at 2022-06-24 21:07:17.770224
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {}
    parameters = {}
    try:
        check_required_by(requirements, parameters)
    except:
        pass


# Generated at 2022-06-24 21:07:25.514227
# Unit test for function check_type_bits
def test_check_type_bits():
    int_0 = 1
    var_0 = check_type_bits(int_0)
    assert var_0 == 8

    int_1 = 2
    var_1 = check_type_bits(int_1)
    assert var_1 == 16

    int_2 = 3
    var_2 = check_type_bits(int_2)
    assert var_2 == 24


# Generated at 2022-06-24 21:07:26.745076
# Unit test for function check_type_dict
def test_check_type_dict():
    data = '{ "name": "value"  }'
    result = check_type_dict(data)
    print("\nResult is: "+ str(result))


# Generated at 2022-06-24 21:07:28.356396
# Unit test for function check_type_dict
def test_check_type_dict():
    str_0 = "key_0=value_0, key_1=value_1"
    dict_0 = check_type_dict(str_0)
    assert dict_0.get("key_0") == "value_0"


# Generated at 2022-06-24 21:07:35.663220
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(50) == 50
    assert check_type_bytes(50.50) == 50.5
    assert check_type_bytes('50') == 50
    assert check_type_bytes('50.50') == 50.5
    assert check_type_bytes('50KB') == 50000
    assert check_type_bytes('50KBs') == 50000
    assert check_type_bytes('50K') == 50 * 1024
    assert check_type_bytes('50Ks') == 50 * 1024
    assert check_type_bytes('50MB') == 50000000
    assert check_type_bytes('50MBs') == 50000000
    assert check_type_bytes('50M') == 50 * 1024 * 1024
    assert check_type_bytes('50Ms') == 50 * 1024 * 1024

# Generated at 2022-06-24 21:07:41.356290
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {'required': True, 'type': 'dict', 'default': None}
    parameters = {'required': True, 'type': 'dict', 'default': None}
    try:
        assert check_required_arguments(argument_spec, parameters) == []
    except TypeError:
        assert check_required_arguments(argument_spec, parameters) == None


# Generated at 2022-06-24 21:07:46.580355
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')]
    ]

    parameters = [
        ['state', 'path'],
        ['someint', 'sub_param'],
        ['sub_param', 'sub_param'],
        ['sub_param', 'sub_param']
    ]

    options_context = ['someint']

    test_case_0()
    ret_1 = check_required_if(requirements, parameters, options_context)
    print(ret_1)
    return ret_1

if __name__ == '__main__':
    test_check_required_if()

# Generated at 2022-06-24 21:07:55.302622
# Unit test for function check_required_if
def test_check_required_if():
    list_0 = []
    dict_0 = {}
    str_0 = "    {#            "
    str_1 = '7'
    str_2 = str_1
    str_3 = ','
    list_0.append(str_3)
    list_0.append(str_2)
    str_4 = ','.join(list_0)
    str_5 = str_4
    str_6 = str_4
    str_7 = str_4
    list_1 = []
    list_1.append(str_7)
    list_1.append(str_6)
    list_1.append(str_5)
    tuple_0 = tuple(list_1)
    list_2 = []
    list_2.append(str_2)

# Generated at 2022-06-24 21:08:03.662624
# Unit test for function check_missing_parameters
def test_check_missing_parameters():

    # parameters
    parameters = {}

    # required_parameters
    required_parameters = []

    # actual result
    expected_result = []

    # testing with empty list
    actual_result = check_missing_parameters(parameters, required_parameters)

    # compare the expected and actual results
    assert expected_result == actual_result


    # parameters
    parameters = {'a':1, 'b':2}

    # required_parameters
    required_parameters = ['a', 'b']

    # actual result
    expected_result = []

    # testing with existing required parameters
    actual_result = check_missing_parameters(parameters, required_parameters)

    # compare the expected and actual results
    assert expected_result == actual_result


    # parameters

# Generated at 2022-06-24 21:08:21.997067
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('9999999999999999999999999999999999999999999999999999999') == '9999999999999999999999999999999999999999999999999999999'

# Generated at 2022-06-24 21:08:29.603540
# Unit test for function check_required_if
def test_check_required_if():
    # Input
    requirement_0 = [
            ['state', 'present', ('path',), True],
            ['someint', 99, ('bool_param', 'string_param')],
        ]
    parameters_0 = {'path': 'hello world'}

    try:
        # Action
        result_0 = check_required_if(requirement_0, parameters_0)
        print(result_0)
    except Exception:
        pass

if __name__ == "__main__":
    test_case_0()
    test_check_required_if()

# Generated at 2022-06-24 21:08:35.368636
# Unit test for function check_required_if
def test_check_required_if():
    argument_spec = dict(
        backup=dict(required=False, type='bool'),
        name=dict(required=True),
        state=dict(default='present', choices=['absent', 'present']),
        wipe=dict(required=False, type='bool', default=False),
    )
    parameters = dict(
        backup=True,
        name='test-name',
        state='present',
        wipe=False
    )
    options_context = None
    requirements = [
        ['state', 'absent', ('wipe',), False],
    ]
    result = check_required_if(requirements, parameters, options_context)
    assert result == []


# Generated at 2022-06-24 21:08:42.614823
# Unit test for function check_required_if
def test_check_required_if():
    list_0 = []
    list_0.append(['string_arg', [], ['string_arg_0']])
    list_0.append(['string_arg', [], ['string_arg_1'], 2])
    list_0.append(['string_arg', [], ['string_arg_2'], 3])
    list_0.append(['string_arg', [], ['string_arg_3'], 4])
    list_0.append(['string_arg', [], ['string_arg_4'], 5])
    list_0.append(['string_arg', [], ['string_arg_5'], 6])
    list_0.append(['string_arg', [], ['string_arg_6'], 7])

# Generated at 2022-06-24 21:08:44.312659
# Unit test for function check_required_if
def test_check_required_if():

    result = check_required_if(requirements=None, parameters={})
    assert result == []



# Generated at 2022-06-24 21:08:46.514090
# Unit test for function check_type_bits
def test_check_type_bits():
    int_0 = -350
    var_0 = safe_eval(int_0)

    # assert that the variable is integer
    assert isinstance(var_0, int)



# Generated at 2022-06-24 21:08:51.881357
# Unit test for function check_required_if
def test_check_required_if():
    test_0 = []
    test_0.append(['state', 'present', ('path',), True])
    test_0.append(['someint', 99, ('bool_param', 'string_param')])
    test_1 = {}
    test_1['state'] = 'present'
    test_1['path'] = 'path'
    test_1['someint'] = 99

    check_required_if(test_0, test_1)


# Generated at 2022-06-24 21:08:56.988759
# Unit test for function check_required_if
def test_check_required_if():
    test_dict = {'param': 'thisisrequired'}
    test_requirement = [['param', 'thisisrequired', ['required'], False]]
    if check_required_if(test_requirement, test_dict):
        raise Exception('required_if test failed')


# Generated at 2022-06-24 21:09:01.569228
# Unit test for function check_type_dict
def test_check_type_dict():
    # test string to dict
    str_dict = 'k1=v1, k2=v2, k3=v3'
    ret_dict = check_type_dict(str_dict)
    assert len(ret_dict) == 3
    assert ret_dict['k1'] == 'v1'
    assert ret_dict['k2'] == 'v2'
    assert ret_dict['k3'] == 'v3'

    # test string to dict, set with json
    str_dict = '{"k1": "v1", "k2": "v2", "k3": "v3"}'
    ret_dict = check_type_dict(str_dict)
    assert len(ret_dict) == 3
    assert ret_dict['k1'] == 'v1'

# Generated at 2022-06-24 21:09:02.577156
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits("1Mb") == 1048576


# Generated at 2022-06-24 21:09:13.667944
# Unit test for function check_required_if
def test_check_required_if():
    check_required_if(1, 2)


# Generated at 2022-06-24 21:09:15.996211
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = []
    parameters = {
        "comment": "200",
        "state": "200",
    }
    options_context = None
    results = check_mutually_exclusive(terms, parameters, options_context)
    assert len(results) == 0
    return 0


# Generated at 2022-06-24 21:09:21.103864
# Unit test for function check_required_by
def test_check_required_by():
    int_0 = 0
    int_1 = 1
    str_2 = "2"
    str_3 = "3"

    var_0 = {"0": str_3, "1": int_1}
    var_1 = {"0": int_0}
    var_2 = check_required_by(var_0, var_1)
    print(var_2)

    var_3 = {"0": str_3}
    var_4 = {"0": int_0}
    var_5 = check_required_by(var_3, var_4)
    print(var_5)

    var_6 = {"0": str_2}
    var_7 = {"0": int_1}
    var_8 = check_required_by(var_6, var_7)

# Generated at 2022-06-24 21:09:26.427058
# Unit test for function check_type_dict
def test_check_type_dict():
    var_1 = "k1=v1"
    var_2 = check_type_dict(var_1)
    print(var_2)

    var_3 = "k1=v1, k2=v2"
    var_4 = check_type_dict(var_3)
    print(var_4)

    print(var_4["k1"])
    # print(var_4["k3"])


# Generated at 2022-06-24 21:09:36.152022
# Unit test for function safe_eval
def test_safe_eval():
    int_0 = -350
    str_0 = '"foo"'
    str_1 = '12345'
    int_1 = 12345
    str_2 = '0x539'
    str_3 = '0b10110011001'
    str_4 = '0o2363'
    str_5 = '0o'
    str_6 = '0b'
    str_7 = '0x'
    str_8 = '1.2e+2'
    str_9 = '1.2e-2'
    str_10 = '1.2e'
    str_11 = '1.2e+'
    str_12 = '1.2e-3'
    var_0 = safe_eval(int_0)
    var_1 = safe_eval(str_0)


# Generated at 2022-06-24 21:09:38.858467
# Unit test for function check_type_bits
def test_check_type_bits():
        # Failed to evaluate, should raise a TypeError
        try:
            test_case_0()
        except TypeError as e:
            pass
        else:
            print("Failed to raise a TypeError")

        # Successful evaluation
        check_type_bits('1Mb')


# Generated at 2022-06-24 21:09:45.080971
# Unit test for function check_required_together
def test_check_required_together():
    # Arrange
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a':1, 'b':2, 'c':3, 'd':4}

    # Call under test
    result = check_required_together(terms, parameters)

    # Assert
    assert result == []



# Generated at 2022-06-24 21:09:53.109356
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval(0) == 0
    assert safe_eval('0') == 0
    assert safe_eval('-350') == -350
    assert safe_eval('1.1') == 1.1
    assert safe_eval('2.2e2') == 220.0
    assert safe_eval('3.3e-3') == 0.0033
    assert safe_eval('0x01') == 1
    assert safe_eval('0b11') == 3
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval("'Hello World!'") == 'Hello World!'
    assert safe_eval("'Hello World!', 'UTF-8'") == b'Hello World!'

# Generated at 2022-06-24 21:09:56.107003
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('k1=v1, k2=v2') == {"k1": "v1", "k2": "v2"}, "check_type_dict does not return the correct value"


# Generated at 2022-06-24 21:10:05.685180
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # test normal case
    check = check_mutually_exclusive(['a', 'b'], {'a': 'test', 'b': 'test'})
    assert check == []

    # test TOO_MANY_TERMS
    try:
        check = check_mutually_exclusive(['a', 'b'], {'a': 'test', 'b': 'test', 'c': 'test'})
        assert False
    except TypeError as e:
        assert "parameters are mutually exclusive: a|b" in str(e)

    # test EMPTY_TERMS
    check = check_mutually_exclusive(None, {'a': 'test', 'b': 'test'})
    assert check == []



# Generated at 2022-06-24 21:10:10.498380
# Unit test for function check_type_bits
def test_check_type_bits():
    check_type_bits(int_0)
    return var_0

# Generated at 2022-06-24 21:10:20.966135
# Unit test for function check_required_together
def test_check_required_together():
  assert check_required_together(['a','b','c'],{'a':1,'b':2,'c':3}) == []
  assert check_required_together(['a','b','c'],{'a':1,'b':2}) == [['a','b','c']]
  assert check_required_together(['a','b','c'],{'a':1,'c':3}) == [['a','b','c']]
  assert check_required_together(['a','b','c'],{'b':2,'c':3}) == [['a','b','c']]
  assert check_required_together(['a','b','c'],{'a':1,'b':2,'c':3}) == []

# Generated at 2022-06-24 21:10:30.478436
# Unit test for function safe_eval
def test_safe_eval():
    int_0 = 300
    bool_0 = True
    str_0 = "def(x):return x"
    int_1 = 300
    dict_0 = {"a": str_0,"b": bool_0}
    str_1 = "a"
    list_0 = ["candle", str_0, int_1, "a"]
    str_2 = "def(x):return x"
    str_3 = "a"

    dict_1 = {"a": str_1, "b": list_0, "c": bool_0, "d": int_1, "e": dict_0, "f": str_2, "g": str_3}
    var_0 = safe_eval(int_0)
    var_1 = safe_eval(str_0)

# Generated at 2022-06-24 21:10:38.046019
# Unit test for function check_type_bytes

# Generated at 2022-06-24 21:10:45.579173
# Unit test for function safe_eval
def test_safe_eval():
    # user_input: -350
    # safe_eval(-350)
    testcase_0()
    testcase_1()
    testcase_2()
    testcase_3()
    testcase_4()
    testcase_5()
    testcase_6()
    testcase_7()
    testcase_8()
    testcase_9()
    testcase_10()
    testcase_11()
    testcase_12()
    testcase_13()
    testcase_14()
    testcase_15()
    testcase_16()
    testcase_17()
    testcase_18()
    testcase_19()


# Generated at 2022-06-24 21:10:46.958591
# Unit test for function check_type_bytes
def test_check_type_bytes():
    test_case_0()


# Generated at 2022-06-24 21:10:56.740399
# Unit test for function check_type_dict
def test_check_type_dict():
    var_1 = 0
    # default value for the var_2
    var_2 = False
    lst_0 = []
    lst_0.append('foo')
    lst_0.append('bar')
    var_3 = 'foo=bar,' + lst_0[0] + '=' + lst_0[1]
    var_4 = '{' + lst_0[0] + ':' + lst_0[1] + ',}'
    # check the type if var_1 is a int
    (var_0, var_2) = check_type_dict(var_1, var_2)
    assert(var_2 == True)
    # check the type if var_3 is a string
    var_3 = check_type_dict(var_3)

# Generated at 2022-06-24 21:10:58.239048
# Unit test for function check_required_together
def test_check_required_together():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 21:11:08.491668
# Unit test for function check_required_arguments
def test_check_required_arguments():

    # Set up mock
    expected_result = None
    expected_result_error = False
    expected_result_list = None

    argument_spec = {}

    # Invoke method
    result = check_required_arguments(argument_spec, parameters)
    if result != expected_result:
        print('Unexpected result returned.\nGot: ' + str(result) +
              '\nExpected: ' + str(expected_result))
        sys.exit(1)
    if isinstance(result, Exception):
        print('Exception raised when calling ' +
              'check_required_arguments:\n' + str(result))
        sys.exit(1)

# Generated at 2022-06-24 21:11:10.249680
# Unit test for function check_type_int
def test_check_type_int():
    int_0 = -350
    var_0 = check_type_int(int_0)



# Generated at 2022-06-24 21:11:23.689866
# Unit test for function check_required_together
def test_check_required_together():
    int_0 = -350
    var_0 = safe_eval(int_0)

    int_1 = -350
    var_1 = safe_eval(int_1)

    int_2 = -350
    var_2 = safe_eval(int_2)

    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()

    dict_0['var_0'] = var_0
    dict_1['var_1'] = var_1
    dict_2['var_2'] = var_2

    list_0 = ["var_0", "var_1"]
    list_1 = ["var_0", "var_2"]
    list_2 = ["var_1", "var_2"]

    list_3 = [list_0, list_1, list_2]



# Generated at 2022-06-24 21:11:31.074157
# Unit test for function check_type_int
def test_check_type_int():
    print("Testing check_type_int()")
    # Test 1
    int_0 = -350
    assert check_type_int(int_0) == -350

    # Test 2
    string_0 = "Fun"
    try:
        assert check_type_int(string_0) == None
    except TypeError as te:
        print("TypeError: " + str(te))
    except:
        print("Exception: " + str(sys.exc_info()[0]))


# Generated at 2022-06-24 21:11:40.547260
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # AssertionError raised for check_required_arguments(
    #     argument_spec={'ip_address': {'required': True, 'type': 'str'}}, parameters={}, options_context=[])
    try:
        check_required_arguments(
            argument_spec={'ip_address': {'required': True, 'type': 'str'}}, parameters={}, options_context=[])
    except AssertionError as e:
        print(e)
    # No Exception raised for check_required_arguments(
    #     argument_spec={'ip_address': {'required': True, 'type': 'str'}}, parameters={'ip_address': '127.0.0.1'},
    #     options_context=[])

# Generated at 2022-06-24 21:11:43.828009
# Unit test for function check_type_dict
def test_check_type_dict():
    try:
        int_0 = -350
        var_0 = safe_eval(int_0)
        assert True
    except:
      assert False

# Generated at 2022-06-24 21:11:53.246498
# Unit test for function check_required_by
def test_check_required_by():
    int_0 = -350
    int_1 = 522
    int_2 = 522
    int_3 = 522
    int_4 = 522
    int_5 = 522
    int_6 = 522
    var_0 = {}
    var_0["ssh_key"] = int_0
    var_0["remote_user"] = int_1
    var_0["hostname"] = int_2
    var_0["server"] = int_3
    var_0["port"] = int_4
    var_0["cmd"] = int_5
    var_1 = {}
    var_1["ssh_key"] = "ssh_key"
    var_1["remote_user"] = "remote_user"
    var_1["server"] = "server"

# Generated at 2022-06-24 21:11:55.081789
# Unit test for function check_required_arguments
def test_check_required_arguments():
    vars_0 = {}
    result = check_required_arguments(vars_0)
    assert result


# Generated at 2022-06-24 21:12:00.802071
# Unit test for function safe_eval
def test_safe_eval():
    int_0 = json.load(open('../../tests/unit/module_utils/parsing/convert_bool/int_0.json'))['int_0']
    var_0 = safe_eval(int_0)
    assert int_0 == var_0
    int_1 = json.load(open('../../tests/unit/module_utils/parsing/convert_bool/int_1.json'))['int_1']
    var_1 = safe_eval(int_1)
    assert int_1 == var_1
    str_0 = json.load(open('../../tests/unit/module_utils/parsing/convert_bool/str_0.json'))['str_0']
    var_2 = safe_eval(str_0)

# Generated at 2022-06-24 21:12:05.211113
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'test_0':['test1_0', 'test2_0'], 'test_1':['test1_1', 'test2_1']}
    parameters = {'test_0': 'test1_0'}

    results = check_required_by(requirements, parameters)
    assert results == {'test_0': ['test2_0']}



# Generated at 2022-06-24 21:12:10.680056
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """
    >>!check_mutually_exclusive(terms, parameters, options_context=None)
    """
    function_name = "check_mutually_exclusive"
    terms = None
    parameters = {}
    options_context = []
    result = check_mutually_exclusive(terms, parameters, options_context)
    expected_result = []
    print("result of the function call: ")
    print(result)
    print("expected result of the function call: ")
    print(expected_result)
    print("result matches expected result: ")
    print(result == expected_result)
    print("\n")


# Generated at 2022-06-24 21:12:16.369035
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    description = "Check mutually exclusive terms against argument parameters"
    # Start by setting up the test case data
    results_0 = None
    terms_0 = None
    parameters_0 = dict()
    options_context_0 = None
    # Call the function under test
    try:
        results_0 = check_mutually_exclusive(terms_0, parameters_0, options_context_0)
    except Exception as e:
        print(description, ":Exception:", e.__doc__, e)
    else:
        print(description, ":results:", results_0)


if __name__ == "__main__":
    test_case_0()
    test_check_mutually_exclusive()

# Generated at 2022-06-24 21:12:30.428371
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int("-350") == True
    #assert check_type_int("str_0") == True
    #assert check_type_int("str_1") == True
    #assert check_type_int("str_2") == True
    #assert check_type_int("str_3") == True
    #assert check_type_int("str_4") == True
    #assert check_type_int("str_5") == True
    #assert check_type_int("str_6") == True
    #assert check_type_int("str_7") == True
    #assert check_type_int("str_8") == True
    #assert check_type_int("str_9") == True


# Generated at 2022-06-24 21:12:38.790427
# Unit test for function check_required_together
def test_check_required_together():
    """Unit test for function check_required_together"""
    from ansible.module_utils.common.text.converters import to_native
    term_0 = [u'task', u'roles']
    parameter_0 = {u'task': u'provision', u'roles': u'lb,web_server'}
    options_context_0 = []
    result_0 = check_required_together(term_0, parameter_0, options_context_0)

# Generated at 2022-06-24 21:12:43.910898
# Unit test for function check_required_by
def test_check_required_by():
    requirements_0 = {
        "key_0": [
            "value_0",
            "value_1",
            "value_2"
        ],
        "key_1": "value_1"
    }
    parameters_0 = {
        "key_0": "value_0",
        "key_1": None
    }
    check_required_by(requirements_0, parameters_0)


# Generated at 2022-06-24 21:12:48.013010
# Unit test for function check_type_bytes
def test_check_type_bytes():
    input_value = -350
    expected_value = -350
    actual_value = check_type_bytes(input_value)
    assert expected_value == actual_value


# Generated at 2022-06-24 21:12:50.831016
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')]]
    parameters = {"path":"path","state":"present"}
    check_required_if(requirements, parameters)



# Generated at 2022-06-24 21:12:58.371223
# Unit test for function safe_eval
def test_safe_eval():
    if safe_eval('-350') == -350 :
        print("unit test-1 PASS")
    else:
        print("unit test-1 FAIL")

    if safe_eval('hello') == "hello" :
        print("unit test-2 PASS")
    else:
        print("unit test-2 FAIL")

    if safe_eval('hello', locals()) == "hello" :
        print("unit test-3 PASS")
    else:
        print("unit test-3 FAIL")

    test_case_0()

# parse_kv

# Generated at 2022-06-24 21:13:02.731433
# Unit test for function check_type_bits
def test_check_type_bits():
    int_0 = 125
    int_1 = 128
    str_0 = "128mb"
    run_test(test_case_0, int_0)
    run_test(test_case_0, int_1)
    run_test(test_case_0, str_0)


# Generated at 2022-06-24 21:13:10.660345
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = 1
    var_1 = True
    var_2 = "test"
    var_3 = [1, 2, 3.0, True, var_2]
    var_4 = ('a', False, 2.4)
    # Note: Dicts and sets do not have a specified ordering.
    # So we must convert them to lists to compare against each other
    var_5 = {'key_0': var_1, 'key_1': var_2, 'key_2': var_3}
    var_6 = {1, 2, 3, 'a', var_3}
    test_0 = safe_eval(var_0)
    assert test_0 == var_0
    test_1 = safe_eval(var_1)
    assert test_1 == var_1
    test_2 = safe_

# Generated at 2022-06-24 21:13:15.001559
# Unit test for function safe_eval
def test_safe_eval():
    try:
        test_case_0()
    except (TypeError, ValueError) as e:
        assert False, "safe_eval raised %r unexpectedly" % (e,)


# Generated at 2022-06-24 21:13:24.945496
# Unit test for function check_type_bits
def test_check_type_bits():
    print(check_type_bits('1Mb'))
    print(check_type_bits('1024KiB'))
    print(check_type_bits('0.5Gib'))
    print(check_type_bits('5G'))
    print(check_type_bits('5000000000'))
    print(check_type_bits('1TB'))
    print(check_type_bits('10'))
    print(check_type_bits('1KiB'))
    print(check_type_bits('500B'))
    print(check_type_bits('0'))
    print(check_type_bits('2MB'))
    print(check_type_bits('2048KiB'))
    print(check_type_bits('1024k'))

# Generated at 2022-06-24 21:13:33.666219
# Unit test for function check_type_dict
def test_check_type_dict():
    # Check for the case in which a dictionary is passed to the function.
    val_0 = {'key': 'var'}
    try:
        check_type_dict(val_0)
    except TypeError:
        print('fail')

if __name__ == '__main__':
    test_check_type_dict()

# Generated at 2022-06-24 21:13:38.303895
# Unit test for function safe_eval
def test_safe_eval():
    '''
    Test case for safe_eval. Input is int_0, want to get result = -350
    :return:
    '''
    int_0 = -350
    result = safe_eval(int_0)
    print(result)


# Generated at 2022-06-24 21:13:46.409773
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # check_mutually_exclusive(terms, parameters, options_context=None)
    # assert check_mutually_exclusive() == "???"

    # test case 0
    terms = [["ip", "ip-address", "ip_address"], ["ipv4", "ipv4-address", "ipv4_address", "ip4"], ["ipv6", "ipv6-address", "ipv6_address", "ip6"]]


# Generated at 2022-06-24 21:13:53.568158
# Unit test for function check_type_dict
def test_check_type_dict():

    dict_0 = {"a":"b"}
    dict_1 = check_type_dict(dict_0)
    #print(dict_1)

    dict_2 = "a=b, c=d"
    dict_3 = check_type_dict(dict_2)
    #print(dict_3)

    dict_4 = '''{
    "ip": "10.1.1.1",
    "mask": "255.255.255.0",
    "gateway": "10.1.1.254",
    "dns1": "10.1.1.254",
    "dns2": "10.1.1.1"}'''
    dict_5 = check_type_dict(dict_4)
    #print(dict_5)


# Generated at 2022-06-24 21:14:01.133107
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Declare parameters expected by function
    terms = None
    parameters = None

    # Test function and verify expectations
    assert check_mutually_exclusive(terms, parameters) == []

# Unit test:
#   - function: safe_eval
#   - arguments:
#       - value: '350'
#   - test cases:
#       0: test case with argument value '350' and expectation 350
#       1: test case with argument value 'foobar' and expectation 'foobar'
#       2: test case with argument value '350' and expectation 350
#       3: test case with argument value 'foobar' and expectation 'foobar'
#       4: test case with argument value '350' and expectation 350
#       5: test case with argument value 'foobar' and expectation 'foobar'
#       6: test case with argument value '350

# Generated at 2022-06-24 21:14:11.611248
# Unit test for function check_required_by
def test_check_required_by():
    # Set up mock
    requirements = {
        "requirements_1": "requirement_2",
        "requirements_2": ["requirement_2", "requirement_3"],
        "requirements_3": ["requirements_4", "requirements_5", "requirements_6"],
        "requirements_4": "requirements_5",
        "requirements_5": "requirements_6",
        "requirements_6": ["requirements_7", "requirements_8"],
        "requirements_7": "requirements_8"
    }

# Generated at 2022-06-24 21:14:21.286426
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Set up mock
    check_mutually_exclusive('mock', 'mock', 'mock')
    # Set up mock
    with pytest.raises(ValueError):
        check_mutually_exclusive('mock', 'mock')
        check_mutually_exclusive('mock', 'mock')
        check_mutually_exclusive('mock', 'mock')
        check_mutually_exclusive('mock', 'mock')
        check_mutually_exclusive('mock', 'mock')
        check_mutually_exclusive('mock', 'mock')
        check_mutually_exclusive('mock', 'mock')



# Generated at 2022-06-24 21:14:26.107374
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    parameters = {"parameters": {"key1": "val1"}}
    terms = ["key1"]
    #result = check_mutually_exclusive(terms, parameters)
    result = check_mutually_exclusive(["parameters", "key1"], parameters)
    print(result)


# Generated at 2022-06-24 21:14:26.903281
# Unit test for function safe_eval
def test_safe_eval():
    assert -350 == safe_eval(-350)


# Generated at 2022-06-24 21:14:30.030620
# Unit test for function safe_eval
def test_safe_eval():
    print("function name: " + test_safe_eval.__name__)
    test_case_0()

test_safe_eval()


# Generated at 2022-06-24 21:14:39.875819
# Unit test for function safe_eval
def test_safe_eval():
    try:
        result = safe_eval(str_0)
        assert False
    except NameError:
        assert True



# Generated at 2022-06-24 21:14:48.817830
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2}) == []
    assert check_mutually_exclusive(['a', 'b'], {'a': 1}) == []
    assert check_mutually_exclusive(['a', 'b'], {'b': 2}) == []
    assert check_mutually_exclusive(['a', 'b'], {}) == []
    assert check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2}) == []
    assert check_mutually_exclusive(['a', 'b'], {'a': 1}) == []
    assert check_mutually_exclusive(['a', 'b'], {'b': 2}) == []
    assert check_mutually_exclusive(['a', 'b'], {})

# Generated at 2022-06-24 21:14:53.756586
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    check = ['a', 'b']
    parameters = {'a': 'toast', 'b': 'bread'}
    options_context = ['a', 'b']
    result = check_mutually_exclusive(check, parameters, options_context)
    assert result is not None
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] == ['a', 'b']

if __name__ == '__main__':
    test_case_0()
    test_check_mutually_exclusive()

# Generated at 2022-06-24 21:15:03.129237
# Unit test for function safe_eval
def test_safe_eval():
    value_0 = 'string'
    value_1 = 'string'
    value_2 = 'string'
    value_3 = 'string'
    value_4 = 'string'
    value_5 = 'string'
    value_6 = 'string'
    value_7 = 'string'
    value_8 = 'string'
    value_9 = 'string'
    value_10 = 'string'
    value_11 = 'string'
    value_12 = 'string'
    value_13 = 'string'
    value_14 = 'string'
    value_15 = 'string'
    value_16 = 'string'
    value_17 = 'string'
    value_18 = 'string'
    result = safe_eval(value_0)

# Generated at 2022-06-24 21:15:08.178685
# Unit test for function check_type_bits
def test_check_type_bits():
    value_0 = '1Mb'
    # Verify the expected output
    assert human_to_bytes(value_0, True) == 1048576, 'The expected output != the actual output'
    print('Expected Output: ' + str(1048576) + ' Actual Output: ' + str(human_to_bytes(value_0, True)))
    
# Function call for unit test
test_check_type_bits()


# Generated at 2022-06-24 21:15:15.578808
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'function name: '
    str_1 = 'safe_eval'
    str_2 = 'test_ansible_module_utils_common_collections'
    str_3 = 'test_ansible_module_utils_common_collections.py'
    str_4 = 'test_ansible_module_utils_common_collections.py:test_safe_eval'
    str_5 = 'test_ansible_module_utils_common_collections.py:test_safe_eval:9'
    str_6 = 'test_ansible_module_utils_common_collections.py:test_safe_eval:12'
    str_7 = 'test_ansible_module_utils_common_collections.py:test_safe_eval:13'

# Generated at 2022-06-24 21:15:21.155184
# Unit test for function check_required_by
def test_check_required_by():
    str_0 = 'missing parameter(s) required by \'c\': b'
    # Set parameters
    requirements = {str_0: ['a']}
    parameters = {'a': 3, 'b': 2}
    options_context = ['options']

    # Call check_required_by
    result = check_required_by(requirements, parameters, options_context)
    # assert None


# Generated at 2022-06-24 21:15:28.721090
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert count_terms(('key1', 'key2'), {'key1': 1, 'key2': 2}) == 2
    assert count_terms('key1', {'key2': 1}) == 0
    assert count_terms('key1', {'key2': 1}) == 0
    assert count_terms(('key1', 'key2'), {'key1': 1, 'key2': 2}) == 2
    assert count_terms('key1', {'key2': 1}) == 0
    assert count_terms(('key1', 'key2'), {'key1': 1, 'key2': 2}) == 2
    assert count_terms('key1', {'key2': 1}) == 0
    assert check_mutually_exclusive((('key1', 'key2'),), {'key1': 1, 'key2': 2}) == []

# Generated at 2022-06-24 21:15:31.803513
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # param: terms
    terms = None
    # param: parameters
    parameters = {}
    # param: options_context
    options_context = None

    # Test function
    check_required_one_of(terms, parameters, options_context)



# Generated at 2022-06-24 21:15:39.439540
# Unit test for function safe_eval
def test_safe_eval():
    with open("safe_eval_0.json", "r") as fd:

        # read the input parameters from JSON file
        input_params = json.load(fd)

        # set the optional parameters to default values
        include_exceptions = None

        # set the mandatory parameters
        value = input_params["value"]

        # execute the module
        return_value = safe_eval(value, include_exceptions=include_exceptions)

        # read the expected output from JSON file
        expected_output = json.load(fd)

        # verify the output
        assert return_value == expected_output


# Generated at 2022-06-24 21:15:46.570437
# Unit test for function safe_eval
def test_safe_eval():
    value = '''
            from ansible.module_utils.six import string_types, text_type
            if isinstance(data, string_types):
                data = text_type(data)
    '''
    result, exc = safe_eval(value, include_exceptions=True)
    assert not exc
    assert result == value


# Generated at 2022-06-24 21:15:49.697525
# Unit test for function check_type_bits
def test_check_type_bits():
    # Test for the case of string '1Mb'
    test_val = '1Mb'
    test_return = check_type_bits(test_val)
    assert test_return == 1048576


# Generated at 2022-06-24 21:15:58.646108
# Unit test for function check_type_dict
def test_check_type_dict():
    # Getting the function name
    function_name = inspect.stack()[0][3]

    # Creating a dict object
    dict_obj = dict()

    # Checking if the function executed successfully
    if check_type_dict(dict_obj) is None:
        print("%s: passed" % (function_name))
    else:
        print("%s: failed" % (function_name))

    # Creating a string object
    str_obj = 'key1=value1, key2=value2'

    # Checking if the function executed successfully
    if check_type_dict(str_obj) == {'key1': 'value1', 'key2': 'value2'}:
        print("%s: passed" % (function_name))
    else:
        print("%s: failed" % (function_name))



# Generated at 2022-06-24 21:16:03.872587
# Unit test for function check_type_dict
def test_check_type_dict():
    # Json or Key:value
    assert check_type_dict('{"key": "value"}') == {"key": "value"}
    assert check_type_dict('key:value') == {'key': 'value'}
    assert check_type_dict('key=value') == {'key': 'value'}
    assert check_type_dict('key1:value1, key2=value2') == {'key1': 'value1', 'key2': 'value2'}

    # Invalid input
    try:
        check_type_dict('{"key: "value"}')
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-24 21:16:05.655425
# Unit test for function check_type_float
def test_check_type_float():
    ret_0 = check_type_float(str_0)
    assert(len(ret_0) > 0)


# Generated at 2022-06-24 21:16:08.560554
# Unit test for function check_type_float
def test_check_type_float():
    assert (check_type_float(str_0) == None)


# Generated at 2022-06-24 21:16:10.452656
# Unit test for function check_type_bits
def test_check_type_bits():

    # call function
    str_0 = 'function name: '

# Generated at 2022-06-24 21:16:12.874428
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = None
    parameters = None
    options_context = None
    assert check_mutually_exclusive(terms, parameters, options_context) == []


# Generated at 2022-06-24 21:16:17.049959
# Unit test for function check_type_bytes
def test_check_type_bytes():
    import re
    str_0 = 'function name: '
    ret_2 = check_type_str(str_0)
    assert(ret_2 == str_0)
    ret_3 = check_type_bytes(str_0)
    assert(ret_3 == str_0)



# Generated at 2022-06-24 21:16:20.325803
# Unit test for function check_required_by
def test_check_required_by():
    str_0 = 'function name: '
    requirements = {'test_key': 'test_value'}
    parameters = {'test_key': 'test_value2'}
    check_result = check_required_by(requirements, parameters)
    assert check_result == {}


# Generated at 2022-06-24 21:16:27.489638
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = "function name: "
    assert safe_eval(str_0) == str_0


# Generated at 2022-06-24 21:16:29.624398
# Unit test for function check_type_bytes
def test_check_type_bytes():
    bytes_0 = check_type_bytes('function name:')
    bytes_1 = check_type_bytes('')
    assert bytes_1 == 0
    assert bytes_0 == 1129


# Generated at 2022-06-24 21:16:36.686866
# Unit test for function safe_eval
def test_safe_eval():
    #pylint: disable=W0612
    #pylint: disable=W0212
    #pylint: disable=W0105

    # Mock exit_json module
    def mock_fail_json(msg):
        return

    def mock_exit_json(changed=False, **kwargs):
        pass

    # Mock AnsibleModule class

# Generated at 2022-06-24 21:16:38.122275
# Unit test for function check_required_together
def test_check_required_together():
    str_0 = 'function name: '
