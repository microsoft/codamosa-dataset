

# Generated at 2022-06-24 21:07:05.280479
# Unit test for function check_required_arguments
def test_check_required_arguments():
    res = check_required_arguments()

    # assertion: res should be an instance of list
    assert isinstance(res, list)



# Generated at 2022-06-24 21:07:11.789360
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # test case 0:
    list_0 = ['a', 'b']
    dict_0 = {'a': 1, 'b': 2}
    var_0 = check_mutually_exclusive(list_0, dict_0)
    assert var_0 == []
    # test case 1:
    list_0 = ['a', 'b']
    dict_0 = {'a': 1, 'b': 2, 'c': 3}
    var_0 = check_mutually_exclusive(list_0, dict_0)
    assert var_0 == []
    # test case 2:
    list_0 = ['a', 'b']
    dict_0 = {'a': 1, 'b': 2, 'c': 3}
    list_2 = ['a', 'b']
    list_3 = ['c']
    list

# Generated at 2022-06-24 21:07:15.299536
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Try to call the function with incorrect number of parameters
    try:
        check_mutually_exclusive(list_0)
    except TypeError as e:
        print(e)

    try:
        check_mutually_exclusive(list_0, var_0, list_0)
    except TypeError as e:
        print(e)


# Generated at 2022-06-24 21:07:21.100576
# Unit test for function check_required_by
def test_check_required_by():
    try:
        test_0 = {
            "key_0": ["missing_0"],
        }

        test_1 = {
            "key_1": "missing_1",
        }

        test_2 = {}

        check_required_by(test_0, test_1)
        check_required_by(test_1, test_0)
        check_required_by(test_2, test_1)
        check_required_by(test_0, test_2)
        check_required_by(test_0, test_0)

    except TypeError as e:
        print(e)
    except ValueError as e:
        print(e)


# Generated at 2022-06-24 21:07:24.512575
# Unit test for function check_type_bits
def test_check_type_bits():
    var_0 = '1Mb'
    var_1 = human_to_bytes(var_0, True)
    var_2 = to_native(var_1)
    print("%s" % (var_2))


# Generated at 2022-06-24 21:07:26.664591
# Unit test for function check_required_arguments
def test_check_required_arguments():
    var_0 = {}
    var_1 = check_required_arguments(var_0)
    assert var_1 == []


# Generated at 2022-06-24 21:07:34.441747
# Unit test for function check_required_arguments
def test_check_required_arguments():
    list_0 = []
    dict_2 = {"a": 1, "b": list_0}
    dict_4 = {}
    dict_3 = {"a": 1}
    try:
        check_required_arguments(dict_2, dict_3)
    except TypeError as exc:
        var_0 = exc.args[0]
        # result = "missing required arguments: %s" % ", ".join(sorted(missing))
        # result = "missing required arguments: %s" % ", ".join(sorted([]))
        # result = "missing required arguments: %s" % ""
        # result = "missing required arguments: "
        test_result = (var_0 == "missing required arguments: ")
    else:
        test_result = True

    assert test_result == True

test_case_0

# Generated at 2022-06-24 21:07:41.697198
# Unit test for function check_required_arguments
def test_check_required_arguments():
    list_0 = []
    list_1 = []
    testdict_0 = {'required': False, 'type': 'dict'}
    testdict_1 = {'required': True, 'type': 'int'}

    # Test case where dictionary arguments are not in the required order
    testdict_0[list_0[0]] = testdict_0
    testdict_1[list_1[0]] = testdict_1
    var_0 = check_required_arguments(testdict_0, testdict_1)


# Generated at 2022-06-24 21:07:45.522587
# Unit test for function check_required_by
def test_check_required_by():
    list_0 = [{"type": "dict", "required_by": {"test": ["test1", "test2"]}}, {"type": "dict", "required_by": {"test": ["test1", "test2"]}}]
    var_0 = check_required_by(list_0, {})


# Generated at 2022-06-24 21:07:54.475137
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval({"a": 1}) == {"a": 1}
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("foo") == "foo"
    assert safe_eval("a.b(foo)") == "a.b(foo)"
    assert safe_eval("import foo") == "import foo"
    assert safe_eval(["a", "b", "c"]) == ["a", "b", "c"]
    assert safe_eval(b"foo") == b"foo"
    assert safe_eval({"a": 1}, include_exceptions=True)[0] == {"a": 1}

# Generated at 2022-06-24 21:08:11.598407
# Unit test for function check_required_arguments
def test_check_required_arguments():
    parameter_list = [[{'foo': {'required': True}}, {}, None],
                      [{'foo': {'required': True}}, {'foo': 'bar'}, None],
                      [{'foo': {'required': False}}, {}, None],
                      [{'foo': {'required': False}}, {'foo': 'bar'}, None],
                      [{'foo': {'required': True}}, {'bar': 'baz'}, None],
                      [None, {'foo': 'bar'}, None],
                      [None, {}, None],
                      ]
    for parameters in parameter_list:
        try:
            check_required_arguments(*parameters)
        except Exception:
            return 0
    return 1



# Generated at 2022-06-24 21:08:13.696360
# Unit test for function check_required_arguments
def test_check_required_arguments():
    var_0 = safe_eval('1')
    with pytest.raises(TypeError):
        check_required_arguments(var_0, var_0)


# Generated at 2022-06-24 21:08:18.691959
# Unit test for function check_required_if
def test_check_required_if():
    parameters = dict(state = 'present', path = '/etc/hosts')
    requirements = [(['state', 'present', ('path',), True])]
    options_context = 'none'
    result = check_required_if(requirements, parameters, options_context)
    assert isinstance(result, list)

# Generated at 2022-06-24 21:08:22.644907
# Unit test for function check_type_bytes
def test_check_type_bytes():
    """
    Test:
    1. 
    """
    var_0 = check_type_bytes(2)
    print(var_0)



# Generated at 2022-06-24 21:08:31.153617
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # define parameters 
    argument_spec = {}
    parameters = {}
    options_context =[]
    

    # check if there is a return of an empty list
    var_0 = check_required_arguments(argument_spec, parameters, options_context)
    assert var_0 == [], f"Expected {[]}, but got: {var_0}"
    # test for the case where required arg is not in arg spec
    argument_spec = {'required_arg':{'required': False, 'type': 'str'}}
    var_0 = check_required_arguments(argument_spec, parameters, options_context)
    assert var_0 == [], f"Expected {[]}, but got: {var_0}"
    # test for the case where required arg is in arg spec

# Generated at 2022-06-24 21:08:32.637245
# Unit test for function check_required_arguments
def test_check_required_arguments():
    print("Start test case 0")
    test_case_0()
    print("End test case 0")



# Generated at 2022-06-24 21:08:36.386804
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    raise NotImplementedError

## Unit test for function check_required_arguments

# Generated at 2022-06-24 21:08:37.317713
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(2) == 2


# Generated at 2022-06-24 21:08:47.071616
# Unit test for function check_type_dict
def test_check_type_dict():
    # see https://www.dexterindustries.com/GoPiGo/programming/python-programming-for-the-raspberry-pi-gopigo/
    # Absolute Test #1 - String with no equal signs
    dict_1 = '{"key1": "value1", "key2": "value2"}'
    dict_2 = 'key1=value1,key2=value2'
    dict_4 = 'a b c'
    dict_5 = '{"a": "b"}'
    dict_6 = '\'a\': \'b\''
    dict_7 = '"a": "b"'
    dict1 = check_type_dict(dict_1)
    dict2 = check_type_dict(dict_2)
    dict3 = check_type_dict(dict_3)

# Generated at 2022-06-24 21:08:52.246788
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Check if assertion fails when required arguments are supplied
    argument_spec = {
        'argument_one': {'required': True},
        'argument_two': {'required': False}
    }
    arguments = {
        'argument_one': 'Value',
        'argument_two': 'Another Value'
    }
    try:
        assert check_required_arguments(argument_spec, arguments) == 'Failed'
    except:
        assert True
    # Check if assertion passes when all required arguments are supplied
    argument_spec = {
        'argument_one': {'required': True},
        'argument_two': {'required': False}
    }
    arguments = {
        'argument_one': 'Value'
    }

# Generated at 2022-06-24 21:09:00.403510
# Unit test for function check_type_bytes
def test_check_type_bytes():
    str_0 = 'zQP\x00\x00\x00\x00\x00\x00'
    var_0 = check_type_bytes(str_0)
    assert var_0 == 74016


# Generated at 2022-06-24 21:09:02.340418
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(['a', 'b'], {'a': 'value1', 'b': 'value2'}) == []


# Generated at 2022-06-24 21:09:06.586895
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    
    print('I am in test_check_mutually_exclusive')
    test_case_0()


# Generated at 2022-06-24 21:09:10.739495
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    with pytest.raises(TypeError) as excinfo:
        str_0 = 'ixh=GD^VL'
        test_case_0()
    with pytest.raises(TypeError) as excinfo:
        str_0 = 'ixh=GD^VL'
        test_case_0()

# Generated at 2022-06-24 21:09:14.323190
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = 'Hv&3@4W8J+GM'
    var_0 = check_mutually_exclusive(str_0, str_0)
    assert var_0 == []



# Generated at 2022-06-24 21:09:25.549175
# Unit test for function check_type_bits
def test_check_type_bits():
    var_0 = {'key1': '5m'}
    var_1 = {'key2': '5Mb'}
    var_2 = {'key3': '5.4Mb'}
    var_3 = {'key4': '5MbX'}

    assert check_type_bits(var_0) == 5242880
    assert check_type_bits('5Mb') == 5242880
    assert check_type_bits(var_1) == 5242880
    assert check_type_bits('5.4Mb') == 5598720
    assert check_type_bits(var_2) == 5598720
    with pytest.raises(TypeError):
        check_type_bits(var_3)

# Generated at 2022-06-24 21:09:31.762176
# Unit test for function check_type_bytes
def test_check_type_bytes():
    str_0 = 'PYPu9jL\x7fz,H'
    var_0 = check_type_bytes(str_0)


# Generated at 2022-06-24 21:09:33.091112
# Unit test for function check_required_together
def test_check_required_together():
    test_case_0()



# Generated at 2022-06-24 21:09:42.556946
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = 'IpqF3qV4E4'
    str_1 = 'QYNAurR-O5'
    str_2 = '-e'
    str_3 = 'u4%a'
    str_4 = ')'
    str_5 = 'zvkH'
    str_6 = 'xn$'
    var_0 = list()
    var_0.append(str_0)
    var_0.append(str_1)
    var_0.append(str_2)
    var_0.append(str_3)
    var_0.append(str_4)
    var_0.append(str_5)
    var_0.append(str_6)
    var_1 = list()
    var_1.append(str_3)


# Generated at 2022-06-24 21:09:49.018804
# Unit test for function check_type_float
def test_check_type_float():
    assert callable(check_type_float)

# Generated at 2022-06-24 21:09:55.296849
# Unit test for function check_type_int
def test_check_type_int():
    int_0 = check_type_int('0')
    assert(int_0 == 0)
    pass


# Generated at 2022-06-24 21:10:04.175685
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    frm = [
        (
            {'a': 'b'},  # parameters
            ['a'],  # required_parameters
        ),
        (
            {'a': 'b'},  # parameters
            [],  # required_parameters
        ),
        (
            {},  # parameters
            ['a'],  # required_parameters
        ),
    ]
    to = [
        [],
        [],
        ['a'],
    ]
    for f, t in zip(frm, to):
        assert check_missing_parameters(*f) == t


# Generated at 2022-06-24 21:10:15.317184
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'ixh=GD^VL'
    var_0 = safe_eval(str_0)
    assert var_0 == str_0

    str_1 = 'ixh=GD^VL'
    var_1 = safe_eval(str_1)
    assert var_1 == str_1

    str_2 = 'ixh=GD^VL'
    var_2 = safe_eval(str_2)
    assert var_2 == str_2

    str_3 = 'ixh=GD^VL'
    var_3 = safe_eval(str_3)
    assert var_3 == str_3

    str_4 = 'ixh=GD^VL'
    var_4 = safe_eval(str_4)
    assert var_4 == str_4


# Generated at 2022-06-24 21:10:18.317028
# Unit test for function check_type_dict
def test_check_type_dict():
    if __name__ == '__main__':
        str_0 = 'ixh=GD^VL'
        var_0 = check_required_together(str_0, str_0)

# Generated at 2022-06-24 21:10:19.456766
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert True


# Generated at 2022-06-24 21:10:25.985934
# Unit test for function check_required_by
def test_check_required_by():
    str_0 = 'cgt_'
    str_1 = '+#v'
    str_2 = 'T88'
    str_3 = str_0 + str_2 + str_2
    str_4 = str_1 + 'Y' + str_1 + str_0
    str_5 = str_0 + str_1 + str_2 + str_2
    str_6 = str_4 + str_4 + str_5
    str_7 = str_2 + str_2 + '+' + 'o'
    str_8 = str_1 + str_1 + str_2 + str_2
    str_9 = str_3 + str_3 + str_8 + str_5
    str_10 = str_6 + str_6 + str_9

    assert str_10 == check_required_by

# Generated at 2022-06-24 21:10:38.207723
# Unit test for function check_required_by
def test_check_required_by():
    input_0 = {
        'well': (
            'oh',
            'hi',
        ),
        {
            'gold': 'five',
        }: (
            'one',
            'two',
            'three',
        ),
    }
    input_1 = {
        'one': '1',
        'two': '2',
        'three': '3',
        'gold': '5',
        'oh': '0',
    }
    if not check_required_by(requirements=input_0, parameters=input_1):
        print("False Positive!")
    input_2 = {
        'one': '1',
        'two': '2',
        'three': '3',
        'gold': '5',
    }

# Generated at 2022-06-24 21:10:42.948216
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    str_0 = 'foo bar'
    str_1 = check_missing_parameters(str_0)
    assert str_1 == 'foo'
    str_2 = ixh != GD^VL
    str_1 = check_missing_parameters(str_0,str_2)
    assert str_1 == ['foo']


# Generated at 2022-06-24 21:10:48.638211
# Unit test for function check_type_bytes
def test_check_type_bytes():
    string_1 = ''
    sp_1 = '\x00'
    string_2 = 'A'
    sp_2 = '\x00'
    string_3 = 'AB'
    sp_3 = '\x00'
    string_4 = 'ABC'
    sp_4 = '\x00'
    string_5 = 'ABCD'
    sp_5 = '\x00'
    string_6 = 'ABCDE'
    sp_6 = '\x00'
    string_7 = 'ABCDEF'
    sp_7 = '\x00'
    string_8 = 'ABCDEFG'
    sp_8 = '\x00'
    string_9 = 'ABCDEFGH'
    sp_9 = '\x00'
    string_10 = 'ABCDEFGHI'
    sp

# Generated at 2022-06-24 21:10:56.169971
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # option1, option2, option3
    # option1
    str_0 = 'ixh=GD^VL'
    param_0 = 'ixh=GD^VL'
    ret_0 = check_mutually_exclusive(str_0, param_0)
    print("ret_0 = ", ret_0)
    # option2
    str_1 = ['ixh=GD^VL', 'ixh=GD^VL', 'ixh=GD^VL']
    param_1 = 'ixh=GD^VL'
    ret_1 = check_mutually_exclusive(str_1, param_1)
    print("ret_1 = ", ret_1)
    # option3
    str_2 = ['ixh=GD^VL', 'ixh=GD^VL', 'ixh=GD^VL']
    param_

# Generated at 2022-06-24 21:11:18.580191
# Unit test for function check_required_if
def test_check_required_if():
    str_0 = {}
    str_1 = 'Xy6x}o'
    str_2 = 'V_eZ|1'
    str_0[str_1] = {'path': str_1, 'required': True}
    var_0 = check_required_if(str_0[str_1], str_0[str_1])
    str_0[str_2] = str_2
    var_1 = check_required_if(str_0[str_2], str_0[str_1])

    lst_0 = {}
    lst_1 = [str_0[str_2], 'eMw`Y-']
    lst_2 = '@9"sb$'
    str_0[str_2] = lst_0[lst_1[0]]
   

# Generated at 2022-06-24 21:11:21.492340
# Unit test for function check_type_float
def test_check_type_float():
    inp1 = '59376.98'
    expected_result = 59376.98
    assert check_type_float(inp1) == expected_result
    inp2 = '0'
    expected_result2 = 0.0
    assert check_type_float(inp2) == expected_result2


# Generated at 2022-06-24 21:11:32.617124
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = 'dr>Bw|'
    str_1 = '6<X[!=JU,!A>-y#P'
    str_2 = '0Jx`%cI'
    str_3 = 'O;o'
    str_4 = 'hJQ,>lwA7'
    str_5 = '%2v`8W`{,hTe'
    str_6 = 'Tpw.b'
    str_7 = '^+'
    str_8 = ':z'
    str_9 = 'K'
    str_10 = 'H'
    str_11 = 'Dh(M4'
    str_12 = '8j'
    str_13 = 'i'
    str_14 = 'W]7O'

# Generated at 2022-06-24 21:11:35.851858
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = 'ixh=GD^VL'
    var_0 = check_mutually_exclusive(str_0, str_0)
    assert(var_0 == [])
    
    


# Generated at 2022-06-24 21:11:38.765690
# Unit test for function check_type_bits
def test_check_type_bits():
    value = '1Mb'
    bytes = check_type_bits(value)
    assert bytes == 1048576


# Generated at 2022-06-24 21:11:44.762129
# Unit test for function safe_eval

# Generated at 2022-06-24 21:11:53.984365
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of(None, None) == []
    assert check_required_one_of(str(), str()) == []
    assert check_required_one_of(str(), None) == []
    assert check_required_one_of(None, str()) == []
    assert check_required_one_of(True, str()) == []
    assert check_required_one_of(int(), str()) == []
    assert check_required_one_of(float(), str()) == []
    assert check_required_one_of(type(None), str()) == []
    assert check_required_one_of(type(str()), str()) == []
    assert check_required_one_of(dict(), str()) == []
    assert check_required_one_of(list(), str()) == []
    assert check_required_one

# Generated at 2022-06-24 21:11:59.873604
# Unit test for function check_required_by
def test_check_required_by():
    check_required_by('aa','aa')
    check_required_by('aa','aa','bb')
    check_required_by('aa','aa','bb','cc')


test_case_0()
test_check_required_by()


# Generated at 2022-06-24 21:12:02.247264
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = 'ixh=GD^VL'
    list_0 = check_mutually_exclusive(str_0, str_0)
# test_case_0()


# Generated at 2022-06-24 21:12:10.642097
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = '#\x19\t\x18'
    str_1 = '\x04\t\x1e\x02'
    str_2 = '\x04\t\x1e\x02\x1a\x19\x04\x04\x02\x1b\x1b\x11\x1b\x1b\x1e\x1a\x1d\x1e\x10\x1c\x1a\x0c'

# Generated at 2022-06-24 21:12:15.716815
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # check_mutually_exclusive('noqa', 'noqa')
    check_mutually_exclusive('noqa', 'noqa')



# Generated at 2022-06-24 21:12:25.789882
# Unit test for function check_type_bits
def test_check_type_bits():
    print('Testing check_type_bits...')
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('3315') == 1110
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('1Tb') == 1099511627776
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('-32Gb') == -34359738368
    assert check_type_bits('1') == 1
    assert check_type_bits('0') == 0
    assert check_type_bits('-1024') == -1024
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('3315Mib') == 1110

# Generated at 2022-06-24 21:12:30.515762
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = [
        'j^[Zf',
        [
            'QjKL',
            '=Q*n',
            '>C%m'
            ]
        ]
    var_0 = check_mutually_exclusive(str_0, str_0)
    assert len(var_0) == 0


# Generated at 2022-06-24 21:12:39.671476
# Unit test for function check_required_arguments
def test_check_required_arguments():
    str_0 = 'ixh=GD^VL'
    str_1 = None
    str_2 = None
    str_3 = '"f--Fzb%c$Hd=*v'
    str_4 = 'ixh=GD^VL'
    str_5 = 'eBw'
    str_6 = 'ixh=GD^VL'
    str_7 = '*yR'
    str_8 = 'aWO\x7f\x04-rcz7\x04'
    str_9 = 'ixh=GD^VL'
    var_0 = check_required_arguments(str_0, str_0)
    var_1 = check_required_arguments(str_1, str_1)

# Generated at 2022-06-24 21:12:41.755094
# Unit test for function check_required_one_of
def test_check_required_one_of():
    if __name__ == '__main__':
        print('Testing_1')
        test_case_0()


# Generated at 2022-06-24 21:12:47.588561
# Unit test for function check_type_int
def test_check_type_int():
    str_0 = 'y2Kf'
    str_1 = 'B>7l<#C'
    var_0 = check_type_int(str_0)
    var_1 = check_type_int(str_1)


# Generated at 2022-06-24 21:12:55.756053
# Unit test for function check_required_one_of
def test_check_required_one_of():
    print("check_required_one_of")
    assert check_required_one_of(None, None) == []
    assert check_required_one_of([], None) == []
    with pytest.raises(TypeError):
        check_required_one_of([('foo',)], {'bar': 'baz'})
    assert check_required_one_of([('foo', 'bar')], {'foo': 'baz'}) == []
    assert check_required_one_of([('foo', 'bar')], {'bar': 'baz'}) == []
    assert check_required_one_of([('foo', 'bar')], {'foo': 'baz', 'bar': 'baz'}) == []

# Generated at 2022-06-24 21:13:03.212023
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """ Check that mutually exclusive parameters can be detected properly
    """
    list_0 = []
    list_1 = []
    list_2 = []
    list_3 = []
    list_4 = []
    list_5 = []
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict

# Generated at 2022-06-24 21:13:13.064771
# Unit test for function check_required_one_of
def test_check_required_one_of():
    str_0 = '[dm=ZJF7, ra)'
    var_0 = check_required_one_of(str_0, str_0)
    int_0 = len(var_0)
    assert int_0 == 0

    str_0 = 'dv'
    var_0 = check_required_one_of(str_0, str_0)
    int_0 = len(var_0)
    assert int_0 == 0

    str_0 = 'l4'
    var_0 = check_required_one_of(str_0, str_0)
    int_0 = len(var_0)
    assert int_0 == 0

    str_0 = 'EY'
    var_0 = check_required_one_of(str_0, str_0)
    int_0 = len

# Generated at 2022-06-24 21:13:21.881868
# Unit test for function check_type_dict
def test_check_type_dict():
    # Test with a string
    value_str = '{ \"name\": \"Rajesh\" }'
    result_str = check_type_dict(value_str)
    assert result_str == {u'name': u'Rajesh'}

    # Test with a dict
    value_dict = { u'name': u'Rajesh' }
    result_dict = check_type_dict(value_dict)
    assert result_dict == {u'name': u'Rajesh'}

    # Test with a string with key value separation
    value_str = 'name=Rajesh'
    result_str = check_type_dict(value_str)
    assert result_str == { u'name': u'Rajesh' }

    # Test exceptions

# Generated at 2022-06-24 21:13:28.020910
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = 'G$=yL-N'
    var_0 = check_required_together(str_0, str_0)



# Generated at 2022-06-24 21:13:36.545741
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    dict_0 = dict()
    dict_0['endpoint'] = None
    dict_0['nagios_context'] = 'ixh=GD^VL'
    dict_0['nagios_command'] = 'ixh=GD^VL'
    list_0 = list()
    list_0.append(None)
    list_0.append('ixh=GD^VL')
    list_0.append('ixh=GD^VL')
    tuple_0 = (None, 'ixh=GD^VL', 'ixh=GD^VL')
    result = check_mutually_exclusive(tuple_0, dict_0)
    if result:
        print("test 1 ok")
    else:
        print("test 1 fail")
    result = check_mutually_exclusive(None, dict_0)

# Generated at 2022-06-24 21:13:44.073712
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # str
    str_0 = 'ixh=GD^VL'
    check_required_arguments(str_0, str_0)
    # str
    str_0 = '19LW'
    check_required_arguments(str_0, str_0)
    # list
    list_0 = [6, 8, 8, 2, 7, 6, 0, 'G', 9, 8, 1]
    check_required_arguments(list_0, list_0)
    # str
    str_0 = '8gv1'
    check_required_arguments(str_0, str_0)
    # tuple
    tuple_0 = ('',)
    check_required_arguments(tuple_0, tuple_0)
    # list

# Generated at 2022-06-24 21:13:46.227729
# Unit test for function check_type_float
def test_check_type_float():
    str_0 = '^3lEx'
    var_0 = check_type_float(str_0)
    print('return value: '+str(var_0))


# Generated at 2022-06-24 21:13:53.446901
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # parameters with required true
    argument_spec = {
        'required_parameter': {'required': True},
        'optional_parameter': {}
    }
    parameters = {}
    missing = check_required_arguments(argument_spec, parameters)
    assert set(missing) == set(['required_parameter']), 'Check required failed'
    assert len(missing) == 1, 'Check required failed'

    parameters = {'optional_parameter': 'hello'}
    missing = check_required_arguments(argument_spec, parameters)
    assert set(missing) == set(['required_parameter']), 'Check required failed'
    assert len(missing) == 1, 'Check required failed'

    parameters = {'required_parameter': 'hello'}
    missing = check_required_arguments(argument_spec, parameters)

# Generated at 2022-06-24 21:13:54.626896
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert True
    # assert False # TODO: implement your test here


# Generated at 2022-06-24 21:13:57.063787
# Unit test for function check_type_bytes
def test_check_type_bytes():
    str_0 = 'a'
    var_0 = check_type_bytes(str_0)
    if var_0 == ord('a'):
        return True
    return False


# Generated at 2022-06-24 21:13:59.830248
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = 'ixh=GD^VL'
    str_1 = 'w>#0y(|B'
    str_2 = '=0D'
    var_0 = check_mutually_exclusive(str_0, str_1, str_2)


# Generated at 2022-06-24 21:14:03.797179
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    #assert check_mutually_exclusive(str_0, str_0) == 
    print('UNIT TEST FOR FUNCTION check_mutually_exclusive')
    # Test case 0
    print('TEST CASE 0')
    str_0 = 'ixh=GD^VL'
    var_0 = check_mutually_exclusive(str_0, str_0)
    assert var_0 == []
    
if __name__ == '__main__':
    test_case_0()
    test_check_mutually_exclusive()

# Generated at 2022-06-24 21:14:08.535993
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # ensure function throws an exception for invalid input
    try:
        check_mutually_exclusive(arg_0, arg_1)
    except Exception as e:
        assert type(e) == TypeError

    # ensure function returns expected value
    assert check_mutually_exclusive(arg_0, arg_1) == ret_3


# Generated at 2022-06-24 21:14:17.085579
# Unit test for function check_type_bits
def test_check_type_bits():
    str_0 = '1Mb'
    int_0 = 1048576
    int_1 = check_type_bits(str_0)
    assert int_0 == int_1

    str_1 = '1Mb^'
    int_2 = -1
    try:
        int_2 = check_type_bits(str_1)
    except TypeError:
        pass
    assert int_2 == -1

# Generated at 2022-06-24 21:14:26.784486
# Unit test for function check_required_if
def test_check_required_if():
    str_0 = 'QO^EK'
    str_1 = 'b_zc7'
    tuple_0 = (str_1, str_0)
    list_0 = [str_1]
    str_2 = '_c%$P'
    str_3 = '#-JG|'
    str_4 = 'Kv'
    str_5 = ':+ja'
    tuple_1 = (str_5, str_4)
    str_6 = 'I)b:+'
    str_7 = 'X]}Dd'
    list_1 = [str_2, str_3, str_6, str_7]
    str_8 = 'RxB'
    str_9 = 'ipz4'
    tuple_2 = (str_9, str_8)


# Generated at 2022-06-24 21:14:29.375884
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576


# Generated at 2022-06-24 21:14:39.854795
# Unit test for function check_type_bits

# Generated at 2022-06-24 21:14:42.568272
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    term_0 = ['ab']
    param_0 = {'ab': 1}
    result = check_mutually_exclusive(term_0, param_0)

    print(result)

    #-----------------------------------------------------------------------------------


# Generated at 2022-06-24 21:14:47.561745
# Unit test for function check_type_bytes
def test_check_type_bytes():
    str_0 = "8e6"
    var_0 = check_type_bytes(str_0)


# Generated at 2022-06-24 21:14:49.603907
# Unit test for function check_required_arguments
def test_check_required_arguments():
    str_1 = 'zNL$e`p\\'
    var_1 = check_required_arguments(str_1, str_1)


# Generated at 2022-06-24 21:14:55.322063
# Unit test for function check_type_bits
def test_check_type_bits():
    str_0 = '1Mb'

    try:
        var_0 = check_type_bits(str_0)
    except Exception:
        var_0 = None
    assert var_0 == 1048576


# Generated at 2022-06-24 21:14:57.189184
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits(10, 10, True) == 10485760


# Generated at 2022-06-24 21:14:59.072773
# Unit test for function check_type_dict
def test_check_type_dict():
    str_0 = 'k1=v1, k2=v2'
    dict_0 = check_type_dict(str_0)

    assert(dict_0 == {'k1': 'v1', 'k2': 'v2'})


# Generated at 2022-06-24 21:15:07.877206
# Unit test for function check_type_bytes
def test_check_type_bytes():
    str_0 = 'ixh=GD^VL'
    var_0 = check_type_bytes(str_0)


# Generated at 2022-06-24 21:15:16.675696
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = safe_eval('123')
    assert var_0 == 123

    var_1 = safe_eval('(123)')
    assert var_1 == 123

    var_2 = safe_eval('[123]')
    assert var_2 == [123]

    var_3 = safe_eval('{123:456}')
    assert var_3 == {123: 456}

    var_4 = safe_eval('import os')
    assert var_4 == 'import os'

    var_5 = safe_eval('os.path.join')
    assert var_5 == 'os.path.join'

    var_6 = safe_eval('[[123]]')
    assert var_6 == [[123]]

    var_7 = safe_eval('["123"]')
    assert var_7 == ["123"]

    var

# Generated at 2022-06-24 21:15:26.083406
# Unit test for function check_required_arguments
def test_check_required_arguments():

    # Test case 0
    # str_0 = 'ixh=GD^VL'
    # var_0 = check_required_together(str_0, str_0)

    str_0 = '"M<M6UOvQa'
    var_0 = check_required_together(str_0, str_0)
    assert var_0 == "parameters are required together: %s" % ', '.join(str_0)

    # Test case 1
    str_0 = "7>uI-fBeDY"
    str_1 = "`I.`[A-;Cp"
    var_0 = check_required_together(str_0, str_1)
    assert var_0 == "parameters are required together: %s" % ', '.join(str_0)

    # Test case 2


# Generated at 2022-06-24 21:15:29.142467
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = 'ixh=GD^VL'
    var_0 = count_terms(str_0, str_0)
    assert var_0 == 1


# Generated at 2022-06-24 21:15:30.093743
# Unit test for function check_required_arguments
def test_check_required_arguments():
    test_case_0()

# Generated at 2022-06-24 21:15:39.808973
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():

    #test for str
    str_1 = '["a","b"]'
    var_1 = check_mutually_exclusive(str_1, str_1)
    str_2 = '["a","c","b"]'
    var_2 = check_mutually_exclusive(str_2, str_2)

    #test for list
    list_1 = ['a', 'b']
    var_3 = check_mutually_exclusive(list_1, list_1)
    list_2 = ['a','c','b']
    var_4 = check_mutually_exclusive(list_2, list_2)

    assert var_0 == "success"
    assert var_1 == "['a', 'b']"
    assert var_2 == "['a', 'b', 'c']"

# Generated at 2022-06-24 21:15:45.003690
# Unit test for function check_type_bytes
def test_check_type_bytes():
    var_0 = check_type_bytes('-1')
    assert var_0 == -1

    try:
        check_type_bytes('1K')
    except TypeError:
        pass
    else:
        assert False, "Expected assertion"


# Generated at 2022-06-24 21:15:54.181279
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = 'a!$fgbXeP0'
    str_1 = 'G.z!@*p'
    str_2 = 'q^LH2'
    dict_0 = {}
    dict_0['xx'] = 0
    dict_1 = {}
    dict_1['xx'] = 0
    dict_1['xx'] = 1
    dict_2 = {}
    dict_2['xx'] = 0
    dict_2['xx'] = 1
    dict_2['xx'] = 2
    dict_3 = {}
    dict_3['xx'] = 0
    dict_3['xx'] = 1
    dict_3['xx'] = 2
    dict_3['xx'] = 3
    dict_4 = {}
    dict_4['xx'] = 0
    dict_4['xx'] = 1

# Generated at 2022-06-24 21:16:01.763968
# Unit test for function check_type_bytes
def test_check_type_bytes():
    arg_data = {}
    arg_data['required_together'] = ['ixh=GD^VL']
    arg_data['required_if'] = ['ixh=GD^VL']
    arg_data['required_together'] = ['ixh=GD^VL']
    arg_data['required_if'] = ['ixh=GD^VL']
    arg_data['required_together'] = ['ixh=GD^VL']
    arg_data['required_if'] = ['ixh=GD^VL']
    arg_data['required_together'] = ['ixh=GD^VL']
    arg_data['required_if'] = ['ixh=GD^VL']
    arg_data['required_together'] = ['ixh=GD^VL']
    arg_data['required_if'] = ['ixh=GD^VL']
    arg

# Generated at 2022-06-24 21:16:08.588332
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1+1') == 2
    assert safe_eval('{1: [1, 2, 3], 2: (1, 2, 3)}') == {1: [1, 2, 3], 2: (1, 2, 3)}
    assert safe_eval('set([1, 2, 3, 4, 5])') == set([1, 2, 3, 4, 5])
    assert safe_eval('1 + 1') == 2
    assert safe_eval('["abc", "def"]') == ['abc', 'def']
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval('{"a": "b"', include_exceptions=True) == ('{"a": "b"', None)



# Generated at 2022-06-24 21:16:27.794295
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert not check_required_arguments(None, {})
    # required, not present
    assert check_required_arguments({'test': dict(required=True)}, {}) == ['test']
    # required, present
    assert not check_required_arguments({'test': dict(required=True)}, {'test': 'value'})
    # not required, present
    assert not check_required_arguments({'test': dict(required=False)}, {'test': 'value'})
    # not required, not present
    assert not check_required_arguments({'test': dict(required=False)}, {})



# Generated at 2022-06-24 21:16:32.957490
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(['--help', '--version'],
                                    {'--help': '-h'}) == []
    assert check_mutually_exclusive(['--help', '--version'],
                                    {'--help': '-h', '--version': '--version'}) == ['--help', '--version']



# Generated at 2022-06-24 21:16:34.762117
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    var_0 = check_mutually_exclusive(None, None)



# Generated at 2022-06-24 21:16:37.748310
# Unit test for function check_required_by
def test_check_required_by():
    str_0 = 'YPUyW^LJVT'
    result_0 = check_required_by(str_0, str_0)

    assert result_0 == str_0


# Generated at 2022-06-24 21:16:43.780287
# Unit test for function check_type_float
def test_check_type_float():
    """
    Arguments: TypeError
    Expected Result: 
    """
    try:
        str_0 = 'uC7EfsoG'
        var_0 = check_type_float(str_0)
        print(var_0 == None)
    except Exception as e:
        print(e)
