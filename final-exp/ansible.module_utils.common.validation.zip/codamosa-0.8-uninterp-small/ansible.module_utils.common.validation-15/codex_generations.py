

# Generated at 2022-06-24 21:07:31.528296
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {'required': False, 'type': 'str'}
    parameters = {'required': 'str'}
    options_context = None
    expected_results = []
    actual_results = check_required_arguments(argument_spec, parameters, options_context)
    assert expected_results == actual_results


# Generated at 2022-06-24 21:07:42.422116
# Unit test for function check_required_if
def test_check_required_if():
    list_1 = list()
    list_1.append('var_5')
    list_1.append('var_6')
    list_1.append('var_7')
    dict_7 = dict()
    dict_7.update({'var_1': 'var_8'})
    dict_7.update({'var_2': 'var_9'})
    dict_7.update({'required_if': 'var_10'})
    dict_7.update({'options_context': 'var_11'})
    dict_8 = dict()
    dict_8.update({'list_1': 'var_12'})
    dict_8.update({'parameters': 'var_13'})
    dict_8.update({'options_context': 'var_14'})

# Generated at 2022-06-24 21:07:44.988358
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert '1k' == check_type_bytes('1024')
    assert '3g' == check_type_bytes('3221225472')


# Generated at 2022-06-24 21:07:47.256900
# Unit test for function check_type_float
def test_check_type_float():
    tuple_0 = None
    var_0 = check_type_float(tuple_0)
    try:
        tuple_0 = set()
        var_0 = check_type_float(tuple_0)
    # Exception has occurred.
    except TypeError as exception:
        var_1 = type(exception)
        print("TypeError:")



# Generated at 2022-06-24 21:07:56.008154
# Unit test for function check_required_together
def test_check_required_together():
    tuple_0 = ('element_0', 'element_1', 'element_2')
    list_0 = ['element_0', 'element_1', 'element_2']
    list_1 = [tuple_0, list_0]
    dict_0 = {'element_0':0, 'element_1':1, 'element_2':2}
    var_0 = check_required_together(list_1, dict_0)
# End of unit test for function check_required_together


# Generated at 2022-06-24 21:08:00.899764
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # check_mutually_exclusive is checked in test_case_0

    # check_mutually_exclusive with default arguments
    tuple_1 = None
    tuple_2 = None
    var_1 = check_mutually_exclusive(tuple_1, tuple_2)
    assert var_1 == None

    # check_mutually_exclusive with explicit arguments
    tuple_3 = None
    tuple_4 = None
    tuple_5 = None
    var_2 = check_mutually_exclusive(tuple_3, tuple_4, tuple_5)
    assert var_2 == None

# Generated at 2022-06-24 21:08:09.206325
# Unit test for function safe_eval
def test_safe_eval():
    # Assign constant
    tuple_0 = None
    tuple_1 = "abc"
    tuple_2 = "import foo"
    tuple_3 = "object.method()"
    # Assert with constant
    assert safe_eval(tuple_0) == tuple_0
    assert safe_eval(tuple_1) == tuple_1
    assert safe_eval(tuple_2) == tuple_2
    assert safe_eval(tuple_3) == tuple_3
    assert safe_eval(tuple_3,include_exceptions=True)[0] == tuple_3



# Generated at 2022-06-24 21:08:11.246049
# Unit test for function check_required_if
def test_check_required_if():
    # Test no.1
    tuple_0 = None
    var_0 = check_required_if(tuple_0)


# Generated at 2022-06-24 21:08:14.256931
# Unit test for function check_required_arguments
def test_check_required_arguments():
    try:
        arguments = {'arg_1': {'default': 'default_value', 'required': True}}
        parameters = {}
        output = check_required_arguments(arguments, parameters)
        print ("Output : %s" % str(output))

        parameters = {'arg_1': 'value_1'}
        output = check_required_arguments(arguments, parameters)
        print ("Output : %s" % str(output))
    except TypeError:
        pass



# Generated at 2022-06-24 21:08:25.021607
# Unit test for function check_type_bytes
def test_check_type_bytes():
    print("Testing function check_type_bytes")
    assert check_type_bytes("1000T") == bytes(1000000000000)
    assert check_type_bytes("1000") == bytes(1000)
    assert check_type_bytes("1k") == bytes(1024)
    assert check_type_bytes("1M") == bytes(1048576)
    assert check_type_bytes("1G") == bytes(1073741824)
    assert check_type_bytes("1T") == bytes(1099511627776)
    assert check_type_bytes("1P") == bytes(1125899906842624)
    assert check_type_bytes("1E") == bytes(1152921504606846976)
    assert check_type_bytes("0T") == bytes(0)
    assert check_type_bytes("0G")

# Generated at 2022-06-24 21:08:36.124707
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(None, {'a': 1, 'b': 2, 'c': 3}) is None
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3, 'd': 4}) is None
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}) is None
    try:
        check_mutually_exclusive([['a', 'b']], {'a': 1, 'b': 2})
        assert False
    except TypeError:
        pass


# Generated at 2022-06-24 21:08:39.112930
# Unit test for function check_required_arguments
def test_check_required_arguments():
    tmp, err = check_required_arguments.__wrapped__({"arg_0" : {"required" : True}}, {"arg_1" : "test_value_1"})
    if err:
        print(err)
    else:
        print(tmp)


# Generated at 2022-06-24 21:08:47.747486
# Unit test for function check_mutually_exclusive

# Generated at 2022-06-24 21:08:57.991176
# Unit test for function check_required_if
def test_check_required_if():
    print('\nChecking check_required_if\n')
    
    req_1 = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    para_1 = {
        'name': 'test',
        'state': 'present',
        'path': '/test',
        'bool_param': 'test',
    }
    print('Test case 1: ', end = '')
    try:
        ans = check_required_if(req_1, para_1)
        print('Passed')
    except:
        print('Failed')
        return False

# Generated at 2022-06-24 21:08:59.060508
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(float(1.2))


# Generated at 2022-06-24 21:09:04.453374
# Unit test for function safe_eval
def test_safe_eval():
    value = "'Hello World'"
    locals = None
    include_exceptions = False
    result = safe_eval(value, locals, include_exceptions)
    assert (result == 'Hello World'), "Function safe_eval returned %s" % repr(result)
    value = 16
    locals = None
    include_exceptions = True
    result = safe_eval(value, locals, include_exceptions)
    assert (result == (16, None)), "Function safe_eval returned %s" % repr(result)



# Generated at 2022-06-24 21:09:08.562869
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [('state', 'present', ('path',), True), ('someint', 99, ('bool_param', 'string_param'))]
    parameters = {"state": "present", "path": "/path/to/file", "someint": 99}
    # Call function
    result = check_required_if(requirements, parameters)
    # print "result : %s" % result
    # print "type of result : %s" % type(result)
    # assert result == []


# Generated at 2022-06-24 21:09:14.344414
# Unit test for function check_type_float
def test_check_type_float():
    # these should pass:
    # test that valid float is left intact
    assert check_type_float(1.1) == 1.1
    # test that number in a string is converted correctly
    assert check_type_float("1.1") == 1.1
    # test that number in a unicode string is converted correctly
    assert check_type_float(u"1.1") == 1.1
    # test that number in a binary string is converted correctly
    assert check_type_float(b"1.1") == 1.1
    # test that number in a number is converted correctly
    assert check_type_float(9) == 9.0
    # test that True is converted correctly
    assert check_type_float(True) == 1.0
    # test that False is converted correctly

# Generated at 2022-06-24 21:09:21.169561
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(None, "{'a': 1, 'b': 2}") == []
    assert check_mutually_exclusive(["a", "b"], "{'a': 1}") == []
    # AssertionError: parameters are mutually exclusive: a, b found in None <- ('a', 'b')


# Generated at 2022-06-24 21:09:30.069415
# Unit test for function check_required_if
def test_check_required_if():
    tuple_0 = [
        [
            "foo",
            5,
            [
                "quux",
                "mux",
            ],
        ],
    ]
    var_0 = check_required_if(tuple_0, {"foo": 5, "mux": 0})
    tuple_1 = [
        [
            "bar",
            "qix",
            [
                "baz",
            ],
        ],
    ]
    var_1 = check_required_if(tuple_1, {"bar": "qix", "baz": "qux"})
    tuple_2 = [
        [
            "foo",
            5,
            [
                "quux",
                "mux",
                "quux",
            ],
            True,
        ],
    ]
    var_

# Generated at 2022-06-24 21:09:43.879120
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    try:
        check_mutually_exclusive(terms=None, parameters={})
    except TypeError as e:
        print("TypeError: ", e)

    assert check_mutually_exclusive(terms=None, parameters={}) == []

    # Check if check_mutually_exclusive return None when terms is None and parameters is {}
    try:
        check_mutually_exclusive(terms=None, parameters={})
    except TypeError as e:
        print("TypeError: ", e)

    assert check_mutually_exclusive(terms=None, parameters={}) == []

    # Check if check_mutually_exclusive raises TypeError when terms is None and parameters is the string "dict"
    try:
        check_mutually_exclusive(terms=None, parameters="dict")
    except TypeError as e:
        print("TypeError: ", e)

# Generated at 2022-06-24 21:09:46.915798
# Unit test for function check_type_dict
def test_check_type_dict():
    dict_0 = {}
    dict_0['key'] = 'value'
    dict_0['key2'] = 'value2'
    dict_1 = check_type_dict(dict_0)
    assert dict_1['key'] == 'value'
    assert dict_1['key2'] == 'value2'


# Generated at 2022-06-24 21:09:50.563463
# Unit test for function check_required_together
def test_check_required_together():
    terms = (('field1', 'field2', 'field3'),)
    parameters = {'field1': 1}
    options_context = ['check_required_together']
    # TODO: Implement the rest of this test
    #assert check_required_together(terms, parameters, options_context)
    return


# Generated at 2022-06-24 21:09:58.541736
# Unit test for function check_type_int
def test_check_type_int():
    print()
    # The following example values will be used for function 'check_type_int'
    # check_type_int(123)
    # check_type_int('123')
    # check_type_int(123.45)
    # check_type_int([1, 2, 3])
    # check_type_int(None)

    # Example 1:
    tuple_0 = 123
    # Call function 'check_type_int'
    try:
        var_0 = check_type_int(tuple_0)
    except TypeError as exc:
        var_0 = exc

    assert int == type(var_0)

    # Example 2:
    tuple_0 = '123'
    # Call function 'check_type_int'

# Generated at 2022-06-24 21:10:10.275626
# Unit test for function check_required_together
def test_check_required_together():
    # Test with list of list as input
    parameters = {"param1": "1", "param2": "2", "param3": "3"}
    terms = [["param1", "param2"], ["param3"]]
    result = check_required_together(terms, parameters)
    assert not result

    parameters = {"param1": "1", "param2": "2", "param4": "4"}
    terms = [["param1", "param2"], ["param3"]]
    result = check_required_together(terms, parameters)
    assert result == [["param1", "param2"]]
    
    # Test with list of tuple as input
    terms = [("param1", "param2"), ("param3")]
    result = check_required_together(terms, parameters)

# Generated at 2022-06-24 21:10:11.864730
# Unit test for function safe_eval
def test_safe_eval():
    ast_0 = None
    result_0 = safe_eval(ast_0)


# Generated at 2022-06-24 21:10:19.370455
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Test arguments and results
    params = dict()
    params['username'] = "user_0"
    params['password'] = "user_passwd"
    params['timeout'] = 60
    params['host'] = "remote_host"
    argument_spec = dict()
    argument_spec['host'] = dict()
    argument_spec['host']['required'] = True
    argument_spec['host']['type'] = 'str'
    argument_spec['host']['default'] = None
    argument_spec['username'] = dict()
    argument_spec['username']['required'] = True
    argument_spec['username']['type'] = 'str'
    argument_spec['username']['default'] = None
    argument_spec['password'] = dict()

# Generated at 2022-06-24 21:10:25.943732
# Unit test for function check_required_together
def test_check_required_together():
    class TestClass(object):
        def check(self, a, b, c):
            return check_required_together((('a', 'b'), ('b', 'c')),
                                           {'a': a, 'b': b, 'c': c})

    test = TestClass()
    test.check(2, 3, 4) # pass
    try:
        test.check(2, 3) # missing c
    except TypeError as e:
        assert e.args[0] == "parameters are required together: a, b"
    else:
        assert False, "Missing required together (c)"

    try:
        test.check(2, None, 4) # missing b
    except TypeError as e:
        assert e.args[0] == "parameters are required together: b, c"

# Generated at 2022-06-24 21:10:29.597819
# Unit test for function check_required_by
def test_check_required_by():
    requirements = ""
    parameters = ""
    options_context = ""
    result = check_required_by(requirements, parameters, options_context)
    assert result is None


# Generated at 2022-06-24 21:10:39.850268
# Unit test for function check_required_by
def test_check_required_by():
    requirements_0 = {'test_key_0': 'test_value_0'}
    parameters_0 = {'test_key_0': 'test_value_0'}
    options_context_0 = None
    result = check_required_by(requirements_0, parameters_0, options_context_0)
    assert result == {}
    requirements_1 = {'test_key_0': 'test_value_0'}
    parameters_1 = {'test_key_0': 'test_value_0'}
    options_context_1 = None
    result = check_required_by(requirements_1, parameters_1, options_context_1)
    assert result == {}
    requirements_2 = {'test_key_0': ['test_value_0', 'test_value_1']}
    parameters

# Generated at 2022-06-24 21:10:52.559756
# Unit test for function safe_eval
def test_safe_eval():
    dict_0 = {'ssh_password': '123456'}
    tuple_0 = None
    tuple_0 = safe_eval(dict_0, None, True)
    var_0 = check_type_raw(tuple_0)
    assert isinstance(var_0, tuple)
    dict_0 = {'ssh_password': '123456'}
    var_1 = None
    var_1 = safe_eval(dict_0, None)
    check_type_raw(var_1)
    assert isinstance(var_1, dict)
    dict_0 = {'ssh_password': '123456'}
    var_2 = safe_eval(dict_0, None, True)
    check_type_raw(var_2)
    assert isinstance(var_2, tuple)

# Generated at 2022-06-24 21:10:58.516776
# Unit test for function check_type_int
def test_check_type_int():
    value = check_type_int('20')
    if value != 20:
        print("error, function returned unexpected result")
    value = check_type_int(20)
    if value != 20:
        print("error, function returned unexpected result")
    try:
        value = check_type_int([20])
    except TypeError:
        value = 0
    if value != 0:
        print("error, function returned unexpected result")


# Generated at 2022-06-24 21:10:59.838162
# Unit test for function check_type_bits
def test_check_type_bits():
    try:
        test_case_0()
    except TypeError as error:
        var_0 = error
        assert False


# Test runner

# Generated at 2022-06-24 21:11:01.387352
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(float(1.0)) == 1.0


# Generated at 2022-06-24 21:11:07.709054
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # This will  never raise an exception
    assert check_type_bytes('0.2') == 0.2

    try:
        check_type_bytes('a')
    except TypeError as exc:
        assert 'str' in str(exc)
    else:
        assert False, 'Expected a TypeError to be raised'



# Generated at 2022-06-24 21:11:13.511329
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # TODO: why doesn't check_type_bytes
    # check for types such as string_types, bytes, or unicode?
    #assert(check_type_bytes("b'\\x00\\xb0\\x00\\x00\\x00\\x00\\x00\\x00'") == b'\x00\xb0\x00\x00\x00\x00\x00\x00')
    assert(check_type_bytes("8b") == 8)



# Generated at 2022-06-24 21:11:19.877119
# Unit test for function check_type_dict
def test_check_type_dict():
    value = 'aaa=1, bbb=2, ccc=3'
    expected = {'aaa': '1','bbb': '2','ccc': '3'}
    result = check_type_dict(value)
    assert_equal(expected,result)



# Generated at 2022-06-24 21:11:30.417935
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # parametrize() is used by pytest to provide different parameters for
    # function check_required_arguments for each execution.
    # All the parameters are defined here.

    # Argument specification (dict)
    # Case 0
    argument_spec_0 = {'required': False, 'type': 'str', 'choices': ['present', 'absent']}

    # Parameters (dict)
    # Case 0
    parameters_0 = {'state': 'present'}

    # Options context
    options_context_0 = None

    # Run function check_required_arguments with its arguments
    check_required_arguments(argument_spec_0, parameters_0, options_context_0)


# Generated at 2022-06-24 21:11:35.692224
# Unit test for function check_type_bits
def test_check_type_bits():
    arg_value = "10wB"
    expected = 5120
    actual = check_type_bits(arg_value)
    assert actual == expected


# Generated at 2022-06-24 21:11:43.185859
# Unit test for function check_required_together
def test_check_required_together():
    # Check for arguments
    try:
        assert len(sys.argv) > 1
    except AssertionError as e:
        print('Missing parameter(s)!')
        usage()
        sys.exit(1)

    # Check if the parameters are valid
    if not sys.argv[1].startswith('--'):
        print('Invalid parameters!')
        usage()
        sys.exit(1)
    else:
        # Extract the parameters
        option = sys.argv[1][2:]

        # Check if the parameters are valid
        if option == 'help':
            usage()
        elif option == 'test':
            # Execute the unit tests
            test_case_0()
        else:
            print('Invalid parameters!')
            usage()
            sys.exit(1)

# Generated at 2022-06-24 21:11:50.321008
# Unit test for function check_type_int
def test_check_type_int():
    # Raises: TypeError
    with pytest.raises(TypeError):
        check_type_int(6.2)
    # Raises: TypeError
    with pytest.raises(TypeError):
        check_type_int('foo')


# Generated at 2022-06-24 21:11:51.992943
# Unit test for function safe_eval
def test_safe_eval():
    tuple_0 = None
    var_0 = safe_eval(tuple_0)


# Generated at 2022-06-24 21:11:55.544165
# Unit test for function check_type_float
def test_check_type_float():
    assert 1.1 == check_type_float(1.1)
    assert 2.1 == check_type_float(2)
    assert 1.1 == check_type_float("1.1")
    try:
        assert 1.1 == check_type_float(b"1.1")
    except:
        pass

# Generated at 2022-06-24 21:12:01.212542
# Unit test for function check_required_together
def test_check_required_together():
    # check_required_together(terms, parameters, options_context=None)
    tup_0 = None
    dic_0 = None
    str_0 = "abcd"
    tup_1 = (
        dic_0,
    )
    tup_2 = (
        str_0,
    )
    tup_3 = (
        tup_2,
    )
    tup_4 = (
        tup_1,
    )
    tup_5 = (
        tup_4,
    )
    tup_6 = (
        tup_3,
    )
    tup_7 = (
        tup_6,
    )
    tup_8 = (
        tup_7,
    )

# Generated at 2022-06-24 21:12:07.272757
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert(check_required_arguments(tuple_0, var_0) == bool_0)
    assert(check_required_arguments(tuple_0, var_0) == bool_0)


# Generated at 2022-06-24 21:12:13.650928
# Unit test for function check_required_if
def test_check_required_if():
    tuple_0 = (None, None, None)
    tuple_1 = ('someint', 99, ('bool_param', 'string_param'))
    tuple_2 = ('state', 'present', ('path',), True)
    tuple_3 = ('state', 'present', ('path',), True)
    tuple_4 = ('someint', 99, ('bool_param', 'string_param'))
    tuple_5 = ('state', 'present', ('path',), True)
    tuple_6 = ('someint', 99, ('bool_param', 'string_param'))
    list_0 = [tuple_0, tuple_1, tuple_2, tuple_3, tuple_4, tuple_5, tuple_6]

# Generated at 2022-06-24 21:12:22.540110
# Unit test for function safe_eval
def test_safe_eval():
    tuple_0 = None
    var_0 = safe_eval(tuple_0, None, True)
    assert isinstance(var_0, tuple)
    assert len(var_0) == 2
    (var_1, var_2) = var_0
    assert var_1 is None
    assert var_2 is None
    tuple_1 = (0,)
    var_0 = safe_eval(tuple_1, var_0, True)
    assert isinstance(var_0, tuple)
    assert len(var_0) == 2
    (var_3, var_4) = var_0
    assert var_3 == 0
    assert var_4 is None
    tuple_2 = (0, 1)
    var_0 = safe_eval(tuple_2, var_0, True)

# Generated at 2022-06-24 21:12:26.433105
# Unit test for function check_required_together
def test_check_required_together():
    """
    Unit test for ansible.module_utils.parsing.convert_bool.check_required_together

    """
    assert count_terms(tuple_0, var_0) == tuple_0


# Generated at 2022-06-24 21:12:34.710768
# Unit test for function check_required_together
def test_check_required_together():
    parameters = dict()
    parameters['src'] = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'
    parameters['dst'] = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'

    terms = None
    try:
        check_required_together(terms, parameters)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 21:12:38.373589
# Unit test for function check_type_bytes
def test_check_type_bytes():
    bytes_0 = check_type_bytes('512')
    print(bytes_0)


# Generated at 2022-06-24 21:12:43.265427
# Unit test for function check_type_bytes
def test_check_type_bytes():
    value_0 = "foo"
    # Call function check_type_bytes with argument value_0
    assert check_type_bytes(value_0)



# Generated at 2022-06-24 21:12:47.340573
# Unit test for function check_required_together
def test_check_required_together():
    str_0 = 'i want to test that the function check_required_together can get the right result\n'
    # check_required_together
    print(str_0)


# Generated at 2022-06-24 21:12:55.657297
# Unit test for function check_type_bits
def test_check_type_bits():
    str_0 = '\n    Unit test for ansible.module_utils.parsing.convert_bool.check_type_bits\n\n    '
    str_1 = '\n    :kwarg options_context: List of key names that contain ``requirements`` if ``requirements`` is in a nested dictionary\n\n    '

# Generated at 2022-06-24 21:13:03.163673
# Unit test for function check_required_if
def test_check_required_if():
    mock_True_0 = MagicMock(spec=bool, return_value=True)
    mock_False_0 = MagicMock(spec=bool, return_value=False)
    mock_mock_open_0 = mock_open()
    mock_mock_open_1 = mock_open()
    mock_mock_open_2 = mock_open()
    mock_mock_open_3 = mock_open()
    mock_mock_open_4 = mock_open()
    mock_mock_open_5 = mock_open()
    # Mock the module to be used for introspection
    mock_module_0 = MagicMock()
    # Ensure that the module is always the same for each test
    mock_module_0.params = {}
    mock_module_0.params = {}


# Generated at 2022-06-24 21:13:11.123559
# Unit test for function check_required_if
def test_check_required_if():
    input_val_0 = {'path': 'ansible', 'bool_param': False, 'string_param': 'ansible'}
    input_val_1 = {'path': 'ansible'}
    input_val_2 = {'state': 'present', 'path': 'ansible', 'bool_param': True, 'string_param': 'ansible'}
    input_val_3 = {'someint': 2, 'bool_param': False, 'string_param': 'ansible'}
    input_val_4 = {'someint': 2, 'bool_param': False}
    input_val_5 = {'path': 'ansible', 'bool_param': False, 'string_param': 'ansible'}

# Generated at 2022-06-24 21:13:19.413633
# Unit test for function check_required_together

# Generated at 2022-06-24 21:13:26.594438
# Unit test for function check_required_arguments
def test_check_required_arguments():
    '''
    Unit test for check_required_arguments
    '''
    # Unit: simple test that checks if parameters are required
    argument_spec_0 = {'a': {'required': True}, 'b': {'required': True}}
    parameters_0 = {'a': 1}
    result_0 = check_required_arguments(argument_spec_0, parameters_0)
    assert result_0 == ['b']

    # Unit: test that checks if parameters are not required
    argument_spec_1 = {'a': {'required': False}}
    parameters_1 = {}
    result_1 = check_required_arguments(argument_spec_1, parameters_1)
    assert result_1 == []

    # Unit: test that checks if parameters are not required

# Generated at 2022-06-24 21:13:36.468722
# Unit test for function safe_eval
def test_safe_eval():
    safe_val = safe_eval('test')
    assert type(safe_val) == text_type
    safe_val = safe_eval('[1, 2, 3]')
    assert type(safe_val) == list
    safe_val = safe_eval('{"a": "b"}')
    assert type(safe_val) == dict
    safe_val = safe_eval('1')
    assert type(safe_val) == int
    safe_val = safe_eval('True')
    assert type(safe_val) == bool
    safe_val = safe_eval('{"a": ["b", "c"]}')
    assert type(safe_val) == dict
    safe_val = safe_eval('"a"')
    assert type(safe_val) == text_type
    safe_val = safe_eval('None')


# Generated at 2022-06-24 21:13:45.254731
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits(1) == 1
    assert check_type_bits("1") == 1
    assert check_type_bits("1mb") == 1048576
    assert check_type_bits("1MB") == 1048576
    assert check_type_bits("1Mb") == 1048576
    assert check_type_bits("1mbit") == 1048576 * 8
    assert check_type_bits("1Mbit") == 1048576 * 8
    assert check_type_bits("1Mbit") == 1048576 * 8
    assert check_type_bits("1Gbit") == 1048576 * 8 * 1024
    assert check_type_bits("1gbit") == 1048576 * 8 * 1024
    assert check_type_bits("1GBIT") == 1048576 * 8 * 1024

# Unit test

# Generated at 2022-06-24 21:13:55.187205
# Unit test for function check_type_float
def test_check_type_float():
    str_0 = '\n    Unit test for ansible.module_utils.parsing.convert_bool.check_type_float\n\n    '
    float_0 = 0.0
    float_1 = check_type_float(float_0)
    assert float_1 == 0.0
    
    str_1 = '2'
    float_2 = check_type_float(str_1)
    assert float_2 == 2.0
    
    int_0 = 4
    float_3 = check_type_float(int_0)
    assert float_3 == 4.0
    
    int_1 = 4
    float_4 = check_type_float(int_1)
    assert float_4 == 4.0
    
    int_2 = -1
    float_5 = check_

# Generated at 2022-06-24 21:14:03.808941
# Unit test for function check_type_dict
def test_check_type_dict():
    str_0 = '''
    Unit test for ansible.module_utils.parsing.convert_bool.check_type_dict

    '''
    str_1 = '\n    '



# Generated at 2022-06-24 21:14:05.813396
# Unit test for function check_type_bytes
def test_check_type_bytes():
    value = 'test'
    assert check_type_bytes(value) == 'test'


# Generated at 2022-06-24 21:14:09.746349
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    pass

# Generated at 2022-06-24 21:14:20.990448
# Unit test for function check_type_int
def test_check_type_int():
    ansible_description_0 = str_0
    ansible_description_1 = str_0
    ansible_description_2 = str_0
    ansible_description_3 = str_0
    ansible_description_4 = str_0
    ansible_description_5 = str_0
    ansible_description_6 = str_0
    ansible_description_7 = str_0
    ansible_description_8 = str_0
    ansible_description_9 = str_0
    ansible_description_10 = str_0
    ansible_description_11 = str_0
    ansible_description_12 = str_0
    ansible_description_13 = str_0
    ansible_description_14 = str_0
    ansible_description_15 = str_0
    ansible_description_16

# Generated at 2022-06-24 21:14:31.598149
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments({u'arg_key': {u'required': True}}, {u'arg_key': None}) == []
    assert check_required_arguments({u'arg_key': {u'required': True}}, {}) == [u'arg_key']
    assert check_required_arguments({u'arg_key': {u'required': True}}, {u'arg_key': None}) == []
    assert check_required_arguments({u'arg_key': {u'required': False}}, {u'arg_key': None}) == []
    assert check_required_arguments({u'arg_key': {u'required': False}}, {}) == []


# Generated at 2022-06-24 21:14:42.783342
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # Test the check required one of function with basic data types
    results = check_required_one_of(None, {'test_bool': '1', 'test_str': 'test_string'})
    assert results == []
    results = check_required_one_of(('test_bool',), {'test_str': 'test_string'})
    assert results == [['test_bool']]
    results = check_required_one_of((('test_bool', 'test_str'), ('test_str', 'test_int')),{'test_str': 'test_string'})
    assert results == [['test_bool', 'test_str']]
    # Test the check required one of function with complex data types

# Generated at 2022-06-24 21:14:51.195184
# Unit test for function check_type_dict
def test_check_type_dict():
    str_0 = '\n    Unit test for ansible.module_utils.parsing.convert_bool.check_type_dict\n\n    '
    # Testing the type of an if condition (line 697)
    if (isinstance(str_0, string_types)):
        
        # Assigning a Call to a Name (line 698):
        
        # Call to check_type_dict(...): (line 698)
        # Processing the call arguments (line 698)
        str_1 = '\n        Test case for ansible.module_utils.parsing.convert_bool.check_type_dict\n        '
        # Processing the call keyword arguments (line 698)
        kwargs_2 = {}
        # Getting the type of 'check_type_dict' (line 698)
        check_type_

# Generated at 2022-06-24 21:14:54.346553
# Unit test for function check_type_bytes
def test_check_type_bytes():
    args_0 = {'bytes': '1KB'}
    assert check_type_bytes(
        'bytes',
        args_0,
    ) == 1024
    str_0 = '\n    Unit test for ansible.module_utils.parsing.convert_bool.check_type_bytes\n\n    '


# Generated at 2022-06-24 21:15:03.510755
# Unit test for function safe_eval
def test_safe_eval():
    print(str_0)

    test_string = '{{foo}}'
    test_value = 'test_value'

    assert safe_eval(test_string, {'foo': test_value}, include_exceptions=True)[0] == test_value
    assert safe_eval(test_string, {'foo': test_value}, include_exceptions=True)[1] is None

    test_string = '{{foo}}'
    test_value = 7

    assert safe_eval(test_string, {'foo': test_value}, include_exceptions=True)[0] == test_value
    assert safe_eval(test_string, {'foo': test_value}, include_exceptions=True)[1] is None

    test_string = 'hello world'
    test_value = 'hello world'


# Generated at 2022-06-24 21:15:11.408315
# Unit test for function check_required_if
def test_check_required_if():
    # Test empty requirements
    assert check_required_if(None, {'key': 'val'}) == []

    # Test requirements with no missing parameters
    assert check_required_if([['key', 'val', ['key', 'val']]], {'key': 'val'}) == []

    # Test requirements with missing parameters
    results = check_required_if([['key2', 'val2', ['key2', 'val2', 'miss1']]], {'key': 'val'})
    assert len(results) == 1
    assert results[0]['parameter'] == 'key2'
    assert results[0]['value'] == 'val2'
    assert results[0]['requirements'] == ['key2', 'val2', 'miss1']
    assert results[0]['missing'] == ['miss1']
    assert results

# Generated at 2022-06-24 21:15:24.747526
# Unit test for function check_required_together
def test_check_required_together():
    int_0 = -7605
    int_1 = -525
    str_0 = '{0}_{1}'.format(int_0, int_1)
    int_2 = 0x57
    str_1 = '{0}_{1}'.format(str_0, int_2)
    int_3 = -206
    str_2 = '{0}_{1}'.format(str_1, int_3)
    int_4 = -2459
    int_5 = -2823
    str_3 = '{0}_{1}'.format(int_4, int_5)
    str_4 = '{0}_{1}'.format(str_2, str_3)
    int_6 = -4282
    int_7 = -2872

# Generated at 2022-06-24 21:15:26.706406
# Unit test for function check_type_bits
def test_check_type_bits():
    bits_0 = check_type_bits(bits_0)
    bits_1 = check_type_bits(bits_1)
    bits_2 = check_type_bits(bits_2)


# Generated at 2022-06-24 21:15:37.093689
# Unit test for function safe_eval
def test_safe_eval():
    local_var_0 = '3 + 4 * 10'
    result = safe_eval(local_var_0)
    assert result == 43, "Error in test"

    local_var_1 = "'hi' + 'a'"
    result = safe_eval(local_var_1)
    assert result == 'hia', "Error in test"

    local_var_2 = "'hi'.capitalize()"
    result = safe_eval(local_var_2)
    assert result == 'hi', "Error in test"

    local_var_3 = '''
foo = 'bar'
"%(foo)s" % dict(foo='baz')
'''
    result = safe_eval(local_var_3)
    assert result == 'baz', "Error in test"


# Generated at 2022-06-24 21:15:47.896948
# Unit test for function check_required_together

# Generated at 2022-06-24 21:15:49.315571
# Unit test for function check_type_bytes
def test_check_type_bytes():
    temp_0 = 'X'
    var_0 = check_type_bytes(temp_0)
    assert var_0 == 90


# Generated at 2022-06-24 21:15:57.568220
# Unit test for function check_required_together
def test_check_required_together():
    # int, int
    list_0 = [1, 2, 3]
    list_1 = [1, 2]
    terms = list_0, list_1
    parameters = {'a': 1, 'b': 2, 'c': 3}
    options_context = None
    try:
        result = check_required_together(terms, parameters, options_context)
    except Exception as error:
        print(error)
    else:
        print(result)

    # float, float
    list_0 = [1.2, 2.34575, 3.11]
    list_1 = [1.2, 2.34575]
    terms = list_0, list_1
    parameters = {'a': 1.2, 'b': 2.34575, 'c': 3.11}
    options_context = None

# Generated at 2022-06-24 21:15:58.766419
# Unit test for function check_type_bits
def test_check_type_bits():
    test_case_0() # 


# Generated at 2022-06-24 21:16:05.396769
# Unit test for function check_type_bits
def test_check_type_bits():
    # TODO: Add more tests
    var_0 = check_type_bits('1Mb')
    assert var_0 == 1048576
    var_1 = check_type_bits('3Mb')
    assert var_1 == 3145728
    var_2 = check_type_bits('9Mb')
    assert var_2 == 9437184
    var_3 = check_type_bits('12Gb')
    assert var_3 == 12884901888


# Generated at 2022-06-24 21:16:09.392834
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    try:
        check_mutually_exclusive(None, None)
    except Exception as e:
        print("Failed check_mutually_exclusive")



# Generated at 2022-06-24 21:16:12.734139
# Unit test for function safe_eval
def test_safe_eval():
    int_0 = -1219
    var_0 = safe_eval(-1219)


# Generated at 2022-06-24 21:16:21.825921
# Unit test for function check_type_bits

# Generated at 2022-06-24 21:16:25.898448
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # Test with the first test case from HUSB
    bytes_0 = '1000k'
    var_0 = check_type_bytes(bytes_0)


# Generated at 2022-06-24 21:16:27.284090
# Unit test for function check_required_together
def test_check_required_together():
    assert (check_required_together(int_0,int_0,int_0) is None)


# Generated at 2022-06-24 21:16:35.775353
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # str_0 = jsonify({'required': False, 'type': 'str'})
    # dict_0 = {'arg_0': str_0, 'arg_1': str_0}
    int_0 = 121718
    test_str = string_types[0]
    assert test_check_required_arguments(121718, 121718) == [], "Empty list must be returned if no argument is missing"
    # assert check_required_arguments(dict_0, {'arg_0': 'val_0'}) == [], "Empty list must be returned if no argument is missing"
    assert check_required_arguments(test_str, 121718) == [test_str], "Required argument must be listed if not provided"
    # assert check_required_arguments(dict_0, {'arg_0

# Generated at 2022-06-24 21:16:45.087753
# Unit test for function check_type_bits
def test_check_type_bits():
    int_0 = -5874
    int_1 = 5460
    # AssertionError: 0 != 1048576 
    assert check_type_bits(int_0) == 1048576

    int_0 = -5874
    int_1 = 5460
    int_2 = -4811
    # AssertionError: 0 != 1048576 
    assert check_type_bits(int_0) == 1048576

    int_0 = -5874
    int_1 = 5460
    int_2 = -4811
    # AssertionError: 0 != 1048576 
    assert check_type_bits(int_0) == 1048576

