

# Generated at 2022-06-24 21:07:09.972260
# Unit test for function check_required_if
def test_check_required_if():
    # Setup for test case 0
    req0 = ['path', None, (['a', 'b']), False]
    req1 = ['state', 'present', (['b']), False]
    requirements0 = [req0, req1]
    parameters0 = {'b': None}
    options_context0 = ['a', 'b']

    # Invoke callable method 0
    results = check_required_if(requirements0, parameters0, options_context0)

    # Check test case 0
    assert(False)

# Generated at 2022-06-24 21:07:14.094228
# Unit test for function check_required_arguments
def test_check_required_arguments():
    assert check_required_arguments('', '') == ''
    assert check_required_arguments('', '') == ''
    assert check_required_arguments('', '') == ''
    assert check_required_arguments('', '') == ''


# Generated at 2022-06-24 21:07:19.176856
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {"status_check":"stats","protocol":"http/tcp","credentials":["keyid=12345","passcode=123"],"networks":["local","internet"],"servers":["10.10.10.10","172.31.31.31"]}
    required_parameters = ["servers", "networks", "protocol"]
    # check_missing_parameters(parameters, required_parameters)


# Generated at 2022-06-24 21:07:24.474856
# Unit test for function check_type_bytes
def test_check_type_bytes():
    args = []
    with pytest.raises(TypeError) as excinfo:
        # The following call to the function originally contained an incorrect variable.
        check_type_bytes(test_case_0)
    # FIXME: The assertEqual might be wrong
    assert excinfo.value.message == "'NoneType' cannot be converted to a Byte value"

if __name__ == '__main__':
    test_check_type_bytes()

# Generated at 2022-06-24 21:07:33.065922
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert(check_mutually_exclusive(None, None) == [])
    assert(check_mutually_exclusive([None], None) == [])
    assert(check_mutually_exclusive(['foo', 'bar'], None) == [])
    assert(check_mutually_exclusive(['foo', 'bar'], {'foo': 'foo', 'bar': 'bar'}) ==[['foo', 'bar']])
    assert(check_mutually_exclusive([['foo', 'bar'], ['baz']], {'foo': 'foo', 'baz': 'baz'}) ==[])

# Generated at 2022-06-24 21:07:43.513114
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by(None, {"a": "aa"}, None) == {}
    with pytest.raises(TypeError):
        assert check_required_by({"a": "b"}, {"a": "aa"}, None)

    assert check_required_by({"a": "b"}, {"a": "aa", "b": "bb"}, None) == {}
    with pytest.raises(TypeError):
        assert check_required_by({"a": "b"}, {"a": "aa"}, None)

    assert check_required_by({"a": "b", "c": "d"}, {"a": "aa"}, None) == {"a": ["b"]}
    assert check_required_by({"a": "b", "c": "d"}, {"c": "aa"}, None) == {"c": ["d"]}
    assert check

# Generated at 2022-06-24 21:07:46.324351
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'math': {
            'required': False
        },
        'animal': {
            'required': True
        }
    }
    parameters = {
        'math': 'add'
    }
    result = check_required_arguments(argument_spec, parameters)
    assert list(result) == ['animal']



# Generated at 2022-06-24 21:07:53.211015
# Unit test for function safe_eval
def test_safe_eval():
    list_0 = ['value']
    var_0 = safe_eval(list_0)
    assert var_0 == ['value']

    list_0 = ['value', 'value', 'value']
    var_0 = safe_eval(list_0)
    assert var_0 == ['value', 'value', 'value']

    list_0 = ['value', ['value'] , 'value']
    var_0 = safe_eval(list_0)
    assert var_0 == ['value', ['value'] , 'value']


# Generated at 2022-06-24 21:07:57.527993
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {}
    parameters = {'log': 'a', 'state': 'a', 'host': 'a', 'port': 'a', 'type': 'a', 'provider': {'host': 'a', 'port': 'a', 'password': 'a', 'username': 'a'}, 'password': 'a'}
    result = check_required_arguments(argument_spec, parameters)
    assert result == []


# Generated at 2022-06-24 21:08:01.956739
# Unit test for function check_type_dict
def test_check_type_dict():
    test_dict = {'a': 'b'}
    assert check_type_dict(test_dict) == test_dict
    assert check_type_dict('{"a": "b"}') == test_dict
    assert check_type_dict('"a": "b"') == test_dict
    assert check_type_dict('a=b') == test_dict
    # assert check_type_dict('a=b, c=d') == {'a': 'b', 'c': 'd'}
    # assert check_type_dict('a=b, "c": "d"') == {'a': 'b', 'c': 'd'}
    assert check_type_dict('["a", "b"]') == ['a', 'b']


# Generated at 2022-06-24 21:08:12.826369
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    expected = []
    parameters = {}
    required_parameters = var_0
    result = check_missing_parameters(parameters, required_parameters)
    assert result == expected


# Generated at 2022-06-24 21:08:13.780344
# Unit test for function check_required_if
def test_check_required_if():
    result = check_required_if(var_0, var_0, var_0)
    print(result)



# Generated at 2022-06-24 21:08:16.539370
# Unit test for function check_required_if
def test_check_required_if():
    assert not check_required_if(var_0, var_0)


# Generated at 2022-06-24 21:08:27.546190
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = []
    var_0.append(safe_eval("12") == 12)
    var_0.append(safe_eval("foo") == "foo")
    var_0.append(safe_eval("foo") is not "foo")
    var_0.append(safe_eval("foo", include_exceptions=True) == ("foo", None))
    var_0.append(safe_eval("foo", include_exceptions=True)[0] is not "foo")
    var_0.append(safe_eval("foo", include_exceptions=True)[1] is None)
    var_0.append(safe_eval("foo", include_exceptions=True)[0] is not "foo")
    var_0.append(safe_eval("foo", include_exceptions=True)[1] is None)
    var_

# Generated at 2022-06-24 21:08:30.811916
# Unit test for function check_type_bytes
def test_check_type_bytes():
    var_1 = None
    result = check_type_bytes(var_1)
    assert result is NotImplemented



# Generated at 2022-06-24 21:08:34.884258
# Unit test for function check_required_arguments
def test_check_required_arguments():
    var_0 = {"abc": "abc", "required": True}
    var_1 = {"abc": "abc"}
    var_2 = []
    function_result = check_required_arguments(var_0, var_1, var_2)
    print(function_result)

# Main program
if __name__ == "_main":
    test_case_0()

# Generated at 2022-06-24 21:08:37.428793
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    var_0 = [["Test1", "Test2"]]
    var_1 = ["Test3"]
    if not check_mutually_exclusive(var_0,var_1):
        assert False
    print("check_mutually_exclusive function pass")


# Generated at 2022-06-24 21:08:47.137491
# Unit test for function safe_eval
def test_safe_eval():
    # simple asserts
    assert(safe_eval("1") == 1)
    assert(safe_eval("2 + 3") == 5)
    assert(safe_eval("(5, 6, 7)") == (5, 6, 7))
    assert(safe_eval("['a', 'b', 'c']") == ['a', 'b', 'c'])
    assert(safe_eval("{'a': 'b'}") == {'a': 'b'})

    # asserts that uses complex types
    assert(safe_eval("{'a': (1, 2, 3), 'b': {'c': 'd'}}") == {'a': (1, 2, 3), 'b': {'c': 'd'}})

    # asserts that uses True, False and None
    assert(safe_eval("True") is True)


# Generated at 2022-06-24 21:08:49.405938
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1MB') == 1048576
    assert check_type_bits('1MBIT') == 1048576
    assert check_type_bits('1mbit') == 1048576
    assert check_type_bits('1mb') == 1048576


# Generated at 2022-06-24 21:08:50.703933
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    var_0 = {}
    required_parameters = []
    assert check_missing_parameters(var_0,required_parameters) == []


# Generated at 2022-06-24 21:09:01.024484
# Unit test for function check_required_by
def test_check_required_by():
    var_0 = {"foo": "bar"}
    var_1 = {"foo": "bar"}
    assert var_0 == check_required_by(var_0, var_1)



# Generated at 2022-06-24 21:09:07.385212
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # Setup a simple copy of the module_params and the shared parameters
    test_params = dict(
        test_list=[list(['a']),
                   list(['b']),
                   list(['a','b']),
                   list([])]
    )
    module_params = test_params.copy()
    test_item = dict()
    test_item['test_list'] = [['a'],
                              ['b'],
                              ['a','b'],
                              []]
    result = check_required_one_of(test_item['test_list'], module_params)
    # Result should be empty if there are no errors.
    if result == []:
        pass
    else:
        var_0 = []


# Generated at 2022-06-24 21:09:08.693679
# Unit test for function check_required_one_of
def test_check_required_one_of():
    var_0 = []

    result = check_required_one_of(var_0, None)
    assert result == var_0



# Generated at 2022-06-24 21:09:14.024656
# Unit test for function check_type_dict
def test_check_type_dict():
    var_0 = [{'k1': 'v1', 'k2': 'v2'}, '{"k1": "v1", "k2": "v2"}', 'k1=v1, k2=v2', '{"k1": "v1", "k2": "v2"}', 'k1=v1, k2=v2', {'k1': 'v1', 'k2': 'v2'}]
    var_1 = check_type_dict(var_0)
    assert len(var_1) == 6




# Generated at 2022-06-24 21:09:25.216648
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    var_1 = []
    var_1.append(['compute_instance'])
    var_1.append(['compute_instance_name'])
    var_1.append(['compute_instance_template'])
    var_1.append(['compute_image'])
    var_1.append(['compute_image_family'])
    var_1.append(['compute_image_project'])
    var_1.append(['compute_instance_group_manager'])
    var_1.append(['compute_instance_group'])
    var_1.append(['compute_instance_template_image'])
    var_1.append(['compute_instance_template_image_family'])

# Generated at 2022-06-24 21:09:27.554813
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    print("Test check_mutually_exclusive(var_0)")
    assert test_case_0() == []


# Generated at 2022-06-24 21:09:29.584399
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1, 2]') == [1, 2]


# Generated at 2022-06-24 21:09:35.718261
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert count_terms(var_0, []) == 0  # Check that the count is 0
    assert not check_mutually_exclusive(var_0, [])  # Checks that a list of terms doesn't exist
    assert not check_mutually_exclusive(None, None)  # Checks for the case where both parameters are None

# Function path_dwim

# Generated at 2022-06-24 21:09:46.344566
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Create mock for spec
    spec = {
                'elements': [
                ],
                'required': False,
                'type': 'list',
                'updatable': False
            }

    # Create mock for parameters
    parameters = {
        'elements': []
    }
    try:
        check_mutually_exclusive(spec,parameters)
    except Exception as exception:
        assert False
        print(exception)


# Generated at 2022-06-24 21:09:47.595718
# Unit test for function check_required_together
def test_check_required_together():
    var_0 = []
    test_case_0()



# Generated at 2022-06-24 21:09:59.741488
# Unit test for function check_required_if
def test_check_required_if():
    req = [["key", "val", ["requirements"], False],]
    parameters = {"key": "val", "requirements": "x"}
    results = check_required_if(req, parameters)
    print("results:", results)
    assert results == []
    parameters = {"key": "val", "requirements": "x", "extra": "y"}
    results = check_required_if(req, parameters)
    print("results:", results)
    assert results == []
    req = [["key", "val", ["requirements"]],]
    parameters = {"key": "val", "requirements": "x"}
    results = check_required_if(req, parameters)
    print("results:", results)
    assert results == []

# Generated at 2022-06-24 21:10:05.931916
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    var_1 = { 'host': '192.168.1.1', 'port': '8080' }
    required_parameters = ['host', 'port']
    expected_result = []

    result = check_missing_parameters(var_1, required_parameters)
    assert result == expected_result


# Generated at 2022-06-24 21:10:06.986943
# Unit test for function check_required_if
def test_check_required_if():
    test_case_0()

# Generated at 2022-06-24 21:10:14.927287
# Unit test for function check_required_if
def test_check_required_if():
    data = json.loads(open(os.path.join(os.path.dirname(__file__), 'fixtures', 'check_required_if.json')).read())
    data_0 = data['inputs'][0]
    data_1 = data['inputs'][1]
    data_2 = data['inputs'][2]
    data_3 = data['inputs'][3]
    test_case_0()
    test_case_1(data_0,data_1,data_2,data_3)
    test_case_2(data_0,data_1,data_2,data_3)
    test_case_3(data_0,data_1,data_2,data_3)

# Generated at 2022-06-24 21:10:22.468280
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Source:
    # https://github.com/ansible/ansible/lib/ansible/module_utils/basic.py
    # lines: 1156-1205

    ## #
    #
    # Mutual exclusion options
    #
    # These options are used to validate mutually exclusive params.
    #
    # Every list represents a group of mutually exclusive params.
    #
    # example:
    # mutually_exclusive = [['timezone', 'timezone_utc'], ['force', 'match']]
    #
    # Which means either timezone or timezone_utc can be passed to the module,
    # but not both at a time. Same for force and match.

    # Test with a single term
    terms = [['timezone']]
    parameters = {'timezone': 'GMT'}
    ## # Test with multiple

# Generated at 2022-06-24 21:10:28.595734
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [('state', 'present', ('path',), True), ('someint', 99, ('bool_param', 'string_param'))]
    parameters = {'someint': 99, 'bool_param': True}
    assert check_required_if(requirements, parameters) is test_case_0()
    print("Succeed!")

if __name__ == '__main__':
    test_check_required_if()

# Generated at 2022-06-24 21:10:30.034721
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    result = check_mutually_exclusive(var_0)
    assert result == []

# Generated at 2022-06-24 21:10:38.536956
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    args = Argv()
    if len(args) > 1:
        raise Exception("This function takes no arguments")

    var_1 = [["a"], ["b"]]
    var_2 = {"a": 1, "b": 2}
    var_3 = ""
    try:
        var_4 = check_mutually_exclusive(var_1, var_2, var_3)
        if var_4:
            print(jsonify(var_4))
        else:
            print(json.dumps(False))
    except TypeError as var_5:
        print(var_5)



# Generated at 2022-06-24 21:10:40.714955
# Unit test for function check_required_by
def test_check_required_by():

    # Create the arguments
    requirements = var_0
    parameters = SectionObject()

    # Execute the function
    result = check_required_by(requirements, parameters)

    # Verify the results
    assert result == SectionObject(section)


# Generated at 2022-06-24 21:10:45.490668
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    var_1 = {
        "parameters": {
            "key_0":  1,
            "key_1":  2
        },
        "required_parameters": [
            "key_0",
            "key_1"
        ]
    }
    test_case_0()
    test_ret = check_missing_parameters(**var_1)
    print(test_ret)



# Generated at 2022-06-24 21:10:56.999451
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    func_name = "check_mutually_exclusive"
    data_list = []
    data_list.append(['parameter1',{'parameter1': 'test','parameter2': 'test'}])
    data_list.append(['parameter1'])
    data_list.append([['parameter1', 'parameter2'],{'parameter1': 'test','parameter2': 'test'}])
    data_list.append([['parameter1'],{'parameter1': 'test','parameter2': 'test'}])
    data_list.append([['parameter2'],{'parameter1': 'test','parameter2': 'test'}])

# Generated at 2022-06-24 21:11:03.922739
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Create some test data that will be the result of a templating engine
    # and that will be used as input to the Ansible module
    var_0 = ["host_1","host_3"]
    var_1 = {}

    try:
        # Call the module code with the above test data as input
        check_mutually_exclusive(var_0, var_1)
        print("Module check_mutually_exclusive worked as expected")
    except Exception as e:
        print("Module check_mutually_exclusive failed with exception: %s" % e)


# Generated at 2022-06-24 21:11:07.794740
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    try:
        test_case_0()
    except TypeError as result:
        print("TypeError")


# Generated at 2022-06-24 21:11:13.599389
# Unit test for function check_required_if
def test_check_required_if():
    requirements_0 = [
        [
            'state',
            'present',
            ['path'],
            True
        ],
        [
            'someint',
            99,
            ['bool_param', 'string_param']
        ]
    ]
    parameters_0 = {}
    options_context_0 = []
    try:
        check_required_if(requirements_0, parameters_0, options_context_0)
    except:
        pass



# Generated at 2022-06-24 21:11:23.549177
# Unit test for function check_type_float

# Generated at 2022-06-24 21:11:28.321574
# Unit test for function check_type_bytes
def test_check_type_bytes():
    var_1 = '8192'
    var_2 = '8k'
    var_3 = '8192'
    var_4 = '8KiB'
    var_5 = '8K'
    var_6 = '8KiB'
    var_7 = '8K'
    var_8 = '8k'
    var_9 = human_to_bytes(var_1)
    var_10 = human_to_bytes(var_2)
    var_11 = human_to_bytes(var_3)
    var_12 = human_to_bytes(var_4)
    var_13 = human_to_bytes(var_5)
    var_14 = human_to_bytes(var_6)
    var_15 = human_to_bytes(var_7)
    var_

# Generated at 2022-06-24 21:11:29.976803
# Unit test for function check_type_float
def test_check_type_float():
    var_1 = check_type_float(0.0)
    var_2 = check_type_float(0)
    var_3 = check_type_float('0.0')


# Generated at 2022-06-24 21:11:36.034875
# Unit test for function check_type_bytes
def test_check_type_bytes():
    var_0 = None
    # Check it raises a TypeError if it can't convert the value
    try:
        check_type_bytes(var_0)
    except TypeError:
        var_0 = True

    assert var_0 == True


# Generated at 2022-06-24 21:11:38.310909
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    try:
        assert self.check_mutually_exclusive(var_0, None, None) == None
    except Exception as e:
        print(e)


# Generated at 2022-06-24 21:11:44.896534
# Unit test for function check_required_if
def test_check_required_if():
    var_0 = ['asdf']
    var_1 = {'asdf': [1,2,3,4,5]}
    var_2 = {}
    var_3 = check_required_if(var_0,var_1)
    assert var_3 == var_2
    required_if=[
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')]
    ]

# Generated at 2022-06-24 21:11:59.395586
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    variable_0=[["test_arg_0"],["test_arg_1"]]
    variable_1= {"test_arg_0":42,"test_arg_1":"test_value_1"}
    variable_2=[["test_arg_0"]]
    variable_3= {"test_arg_0":42,"test_arg_1":"test_value_1"}
    variable_4= [["test_arg_0"]]
    var_5 = ""
    output_0 = test_case_0()
    assert var_5 == output_0
    output_1 = check_mutually_exclusive(variable_0,variable_1)
    assert var_5 == output_1
    output_2 = check_mutually_exclusive(variable_2,variable_3)
    assert var_5 == output_2


# Generated at 2022-06-24 21:12:07.760000
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('') == ''
    assert safe_eval('', include_exceptions=True) == ('', None)
    assert safe_eval('1') == 1
    assert safe_eval('2', include_exceptions=True) == (2, None)
    assert safe_eval('["1", "2"]') == ['1', '2']
    assert safe_eval('["1", "2"]', include_exceptions=True) == (['1', '2'], None)
    assert safe_eval('{"a": "1", "b": "2"}') == {u'a': u'1', u'b': u'2'}

# Generated at 2022-06-24 21:12:13.803919
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    var_1 = None
    var_2 = {u'u1': u'v1', u'u2': u'v2'}
    var_3 = None
    exp_1 = []
    exp_2 = []
    exp_3 = []
    actual_1 = check_mutually_exclusive (var_1, var_2, var_3)
    assert exp_1 == actual_1, 'Expected: %r, Actual: %r' % (exp_1, actual_1)
    actual_2 = check_mutually_exclusive (var_2, var_2, var_3)
    assert exp_2 == actual_2, 'Expected: %r, Actual: %r' % (exp_2, actual_2)

# Generated at 2022-06-24 21:12:19.645401
# Unit test for function check_type_bits
def test_check_type_bits():
    assert True == check_type_bits(value = 1)

    assert True == check_type_bool(value = 1)

    assert True == check_type_bytes(value = 1)

    assert True == check_type_float(value = 1)

    assert True == check_type_int(value = 1)

    assert True == check_type_list(value = 1)

    assert True == check_type_path(value = 1)

    assert True == check_type_raw(value = 1)

    assert True == check_type_str(value = 1)

    assert '' == check_type_str(value = [])

    assert 'test' == check_type_str(value = 'test')

    assert 'test' == check_type_str(value = [test])


# Generated at 2022-06-24 21:12:29.394690
# Unit test for function check_required_together
def test_check_required_together():
    # mock some parameters
    term = [
        "term1",
        "term3",
        "term5",
        "term7",
        "term9",
    ]
    parameters = [
        "term1",
        "term2",
        "term3",
        "term5",
        "term7",
        "term9",
    ]
    options_context = [
        "term1",
        "term2",
        "term3",
        "term4",
    ]
    # test case 0
    result = check_required_together(term, parameters, options_context)
    var_0 = []
    assert result == var_0



# Generated at 2022-06-24 21:12:38.857532
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float("0.0") == 0.0, "check_type_float returned an unexpected value."
    assert check_type_float("0.0") == 0.0, "check_type_float returned an unexpected value."
    assert check_type_float("0") == 0.0, "check_type_float returned an unexpected value."
    assert check_type_float("0") == 0.0, "check_type_float returned an unexpected value."
    assert check_type_float("test") == 0.0, "check_type_float returned an unexpected value."
    assert check_type_float("test") == 0.0, "check_type_float returned an unexpected value."
    assert check_type_float("test") == 0.0, "check_type_float returned an unexpected value."
    assert check_type_

# Generated at 2022-06-24 21:12:45.960055
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    var = [0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0,0,0,1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0]
    var_0 = test_case_0()
    check_mutually_exclusive(var,var_0)



# Generated at 2022-06-24 21:12:47.696246
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert test_case_0 == check_mutually_exclusive()


# Generated at 2022-06-24 21:12:54.957383
# Unit test for function check_required_arguments
def test_check_required_arguments():

	# Input parameters
	argument_spec = {

	}
	parameters = {

	}
	options_context = []

	# Performing the test
	result = check_required_arguments(argument_spec, parameters, options_context)

	# Checking the output
	assert result == []


# Generated at 2022-06-24 21:12:59.644699
# Unit test for function check_type_float
def test_check_type_float():
    var_0 = []
    var_0.append("()")
    var_0.append("('')")
    var_0.append("('testing')")
    var_0.append("(b'')")
    var_0.append("(b'testing')")
    var_0.append("(1.0)")
    var_0.append("(1)")
    var_0.append("('1.0')")
    var_0.append("('1')")
    var_0.append("(1.1)")
    var_0.append("(1.01)")
    var_0.append("(1.11)")
    var_0.append("(11.11)")
    var_0.append("(1.11e-1)")
    var_0.append

# Generated at 2022-06-24 21:13:15.269275
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = []
    assert(safe_eval(var_0) == var_0)
    var_0 = []
    var_1 = dict()
    assert(safe_eval(var_0, var_1) == var_0)
    var_0 = 'foo'
    var_1 = dict()
    var_1['foo'] = 'foo'
    assert(safe_eval(var_0, var_1) == var_1['foo'])
    var_0 = 'foo'
    var_1 = dict()
    var_1['foo'] = 'bar'
    assert(safe_eval(var_0, var_1) == var_1['foo'])
    var_0 = 'foo'
    var_1 = dict()
    var_1['foo'] = 'foo'

# Generated at 2022-06-24 21:13:18.264631
# Unit test for function check_required_if
def test_check_required_if():
    var_0 = []
    var_1 = {}
    print(check_required_if(var_0, var_1))


# Generated at 2022-06-24 21:13:24.129595
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    arg1 = []
    arg2 = {}
    arg3 = None
    ret = check_mutually_exclusive(arg1, arg2, arg3)
    assert ret == []



# Generated at 2022-06-24 21:13:31.688164
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = '42'
    assert True == isinstance(safe_eval(var_0), integer_types)

    var_1 = '1.1'
    assert True == isinstance(safe_eval(var_1), float)

    var_2 = "['test']"
    assert True == isinstance(safe_eval(var_2), list)

    var_3 = "'test'"
    assert True == isinstance(safe_eval(var_3), string_types)

    var_4 = "True"
    assert True == isinstance(safe_eval(var_4), integer_types)



# Generated at 2022-06-24 21:13:42.335514
# Unit test for function check_type_bits
def test_check_type_bits():
    var_0 = []
    def func_0(arg_0, arg_1):
        try:
            var_0.append(check_type_bits(arg_0, arg_1))
        except TypeError:
            pass

    test_cases = dict()
    test_cases[0] = dict()
    test_cases[0]['args'] = [0]
    test_cases[0]['types'] = check_type_bool
    test_cases[1] = dict()
    test_cases[1]['args'] = [1]
    test_cases[1]['types'] = check_type_bool
    test_cases[2] = dict()
    test_cases[2]['args'] = [0]
    test_cases[2]['types'] = check_type_path

# Generated at 2022-06-24 21:13:49.203394
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    var_0 = []
    var_1 = "test_value"
    var_2 = None
    var_3 = []

    result = check_mutually_exclusive(var_0, var_1, var_2)
    assert result == var_3
    # Error message should be empty as function should never raise Exception
    assert not result



# Generated at 2022-06-24 21:13:58.336402
# Unit test for function check_required_if
def test_check_required_if():
    print("Testing function check_required_if")
    parameters = ['param1', 'param2', 'param3']
    requirements = [['param2', 'False', ('param4', 'param5', 'param6')],
                    ['param1', 'False', ('param4', 'param5', 'param6')],
                    ['param2', 'True', ('param4', 'param5', 'param6')]]
    options_context = ""
    try:
        assert(check_required_if(requirements, parameters, options_context) == [])
    except Exception as e:
        print("Unit test for function check_required_if failed")


# Generated at 2022-06-24 21:14:02.307722
# Unit test for function check_type_bytes
def test_check_type_bytes():
    var_0 = check_type_bytes('1mb')
    assert var_0 == 1048576


# Generated at 2022-06-24 21:14:12.002624
# Unit test for function safe_eval
def test_safe_eval():
    print("Start to Unit test function safe_eval")
    # case_0:
    try:
        print("[case_0]")
        var_0 = []
        result = safe_eval(var_0, include_exceptions=False)
        if result == var_0:
            print("[case_0] passed\n")
        else:
            print("[case_0] failed\n")
    except Exception as e:
        print("[case_0] failed\n")

    # case_1:

# Generated at 2022-06-24 21:14:17.188445
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert count_terms([u"ansible_facts", u"ansible_distribution"], {}) == 0
    assert count_terms([u"ansible_facts", u"ansible_distribution"], {u"ansible_distribution": "blah"}) == 1
    assert count_terms([u"ansible_facts", u"ansible_distribution"], {u"ansible_facts": "blah"}) == 1


# Generated at 2022-06-24 21:14:32.593280
# Unit test for function check_type_int
def test_check_type_int():
    var_1 = check_type_int()
    var_1 = check_type_int("10")
    var_1 = check_type_int("10.1")


# Generated at 2022-06-24 21:14:43.737252
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    args = {}
    if __name__ == '__main__':
        try:
            check_mutually_exclusive()
        except TypeError as e:
            assert 'missing 1 required positional argument' in str(e)
    # Check that args are not required.
    with pytest.raises(TypeError) as exc:
        check_mutually_exclusive(var_0)
    assert "missing 1 required positional argument" in str(exc.value)
# test_case_1
    var_0 = {}
    var_1 = None
    if __name__ == '__main__':
        try:
            check_mutually_exclusive(var_0, var_1)
        except TypeError as e:
            assert 'missing 1 required positional argument' in str(e)
    # Check that args are not required.

# Generated at 2022-06-24 21:14:44.246104
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert True



# Generated at 2022-06-24 21:14:49.217738
# Unit test for function check_required_one_of
def test_check_required_one_of():

    # Test cases for function check_required_one_of
    var = [4,5,6]
    terms = [3,4,5]
    parameters = {"test": 1, "test2": "Hello"}
    options_context = []
    assert check_required_one_of(terms, parameters, options_context) == var


# Generated at 2022-06-24 21:15:01.814923
# Unit test for function check_required_one_of
def test_check_required_one_of():
    var_0 = ['foo', 'bar']
    var_1 = []
    test_case = {
        'var_0' : ['foo', 'bar'],
        'var_1' : [],
    }

    ret = check_required_one_of(test_case['var_0'], test_case['var_1'])
    assert ret and ret == []

    # Unit test for function check_required_one_of
    var_0 = ['foo', 'bar']
    var_1 = {'foo': 3}
    test_case = {
        'var_0': ['foo', 'bar'],
        'var_1': {'foo': 3},
    }

    ret = check_required_one_of(test_case['var_0'], test_case['var_1'])

# Generated at 2022-06-24 21:15:08.251284
# Unit test for function check_type_int
def test_check_type_int():
    var_0 = []
    var_1 = "hello"
    var_2 = 5
    var_3 = "5"
    assert check_type_int(var_1) == 5
    assert check_type_int(var_2) == 5
    assert check_type_int(var_3) == 5
    try:
        check_type_int(var_0)
    except TypeError:
        var_0 = 1
    assert var_0 == 1



# Generated at 2022-06-24 21:15:09.056411
# Unit test for function check_type_float
def test_check_type_float():
    pass


# Generated at 2022-06-24 21:15:11.979045
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Initialize the parameters for test
    terms = []
    parameters = {}
    options_context = []

    # Execute function check_mutually_exclusive
    results = check_mutually_exclusive(
        terms, parameters, options_context)
    assert results == []



# Generated at 2022-06-24 21:15:13.284577
# Unit test for function check_type_int
def test_check_type_int():
    var_0 = []
    var_0 = check_type_int(var_0)


# Generated at 2022-06-24 21:15:16.757772
# Unit test for function check_type_bytes
def test_check_type_bytes():
    value = None
    assert None == check_type_bytes(value), "Value expected to be {} instead of {}".format(None, check_type_bytes(value))


# Generated at 2022-06-24 21:15:34.005496
# Unit test for function check_required_if
def test_check_required_if():
    # Argument spec dictionary containing all parameters and their specification.
    args = {u'one': {u'required': False, u'choices': [u'present', u'absent'], u'type': u'str'}}
    # Dictionary of parameters.
    params = {u'one': u'absent'}
    options_context = None
    # List of lists specifying a parameter, value, parameters required when the given parameter is the specified value, and optionally a boolean indicating any or all parameters are required.
    requirements = [[u'one', u'present', (u'two',), False]]
    check_required_if(requirements, params, options_context)



# Generated at 2022-06-24 21:15:39.847533
# Unit test for function check_type_bytes
def test_check_type_bytes():
    str_0 = '64M'
    var_0 = human_to_bytes(str_0)
    var_1 = check_type_bytes(str_0)
    assert var_0 == var_1, "var_0({}) != var_1({})".format(var_0, var_1)

if __name__ == "__main__":
    #test_case_0()
    #test_check_type_bytes()
    pass

# Generated at 2022-06-24 21:15:49.179219
# Unit test for function safe_eval
def test_safe_eval():
    var_1 = '[1, 2]'
    result = safe_eval(var_1)
    assert type(result) == list, "Expected type(result) == list, got {}".format(type(result))
    assert result == [1, 2], "Expected result == [1, 2], got {}".format(result)

    var_2 = '{1: "dd", 2: "ddd"}'
    result = safe_eval(var_2)
    assert type(result) == dict, "Expected type(result) == dict, got {}".format(type(result))
    assert result == {1: "dd", 2: "ddd"}, "Expected result == {1: \"dd\", 2: \"ddd\"}, got {}".format(result)


# Generated at 2022-06-24 21:15:57.460963
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '[1, 2]'
    var_0 = safe_eval(str_0)
    assert var_0 == [1, 2]
    str_0 = '["a", "b"]'
    var_0 = safe_eval(str_0)
    assert var_0 == ["a", "b"]
    str_0 = '[1, "a"]'
    var_0 = safe_eval(str_0)
    assert var_0 == [1, "a"]
    str_0 = '["a", 1]'
    var_0 = safe_eval(str_0)
    assert var_0 == ["a", 1]
    str_0 = "['a', 'b']"
    var_0 = safe_eval(str_0)
    assert var_0 == ["a", "b"]
    str

# Generated at 2022-06-24 21:16:03.866347
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert(check_type_bytes('100b') == 100)
    assert(check_type_bytes('100B') == 100)
    assert(check_type_bytes('100') == 100)
    assert(check_type_bytes('100 kb') == 102400)
    assert(check_type_bytes('100 MB') == 104857600)
    assert(check_type_bytes('100 GB') == 107374182400)
    assert(check_type_bytes('100 TB') == 109951162777600)
    assert(check_type_bytes('100 PB') == 112589990684262400)
    assert(check_type_bytes('100 EB') == 115292150460684697600)
    assert(check_type_bytes('2K') == 2048)

# Generated at 2022-06-24 21:16:07.007900
# Unit test for function check_type_float
def test_check_type_float():
    # Try:
    if True:
        try:
            test_case_0()
        except (BaseException) as e:
            logging.error(e)

if __name__ == '__main__':
    test_check_type_float()

# Generated at 2022-06-24 21:16:13.053570
# Unit test for function check_type_bits
def test_check_type_bits():
    str_0 = '10Mb'
    var_0 = check_type_bits(str_0)
    print('var_0', var_0)


# Generated at 2022-06-24 21:16:21.471563
# Unit test for function check_required_if
def test_check_required_if():
    # Unit test for check_required_if with assertion disabled
    str_1 = 'any'
    str_2 = 'all'
    list_0 = [str_1, str_2]
    for item0 in list_0:
        str_0 = '{0}'.format(item0)
        try:
            check_required_if(str_0)
        except:
            pass
        finally:
            pass
    # Unit test for check_required_if with assertion enabled
    if bool(get_env_var('solaris_11')):
        str_0 = '{0}'.format(item0)
        try:
            check_required_if(str_0)
        except:
            pass
        finally:
            pass


# Generated at 2022-06-24 21:16:25.647048
# Unit test for function check_type_bytes
def test_check_type_bytes():
    var_0 = check_type_bytes('128kb')
    var_1 = check_type_bytes('0')
    var_2 = check_type_bytes('-10')


# Generated at 2022-06-24 21:16:31.759984
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Calling check_mutually_exclusive with arguments
    # (list_of_lists, dictionary_of_parameters, list_of_strings)
    params = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], params) == []
    assert check_mutually_exclusive([['a', 'b'], ['b', 'c']], params) == [['b', 'c']]
    assert check_mutually_exclusive([['a', 'b'], ['b', 'c']], params, ['options']) == [['b', 'c']]
    assert check_mutually_exclusive([['a', 'b']], params) == []

