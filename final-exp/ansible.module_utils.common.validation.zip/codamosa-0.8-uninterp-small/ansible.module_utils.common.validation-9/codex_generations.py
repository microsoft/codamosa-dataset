

# Generated at 2022-06-24 21:07:29.496734
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {'required': {'required': True}, 'not_required': {'required': False}}
    parameters = {'required': 'value', 'not_required': 'value'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'not_required': 'value'}
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert "missing required arguments: required" in to_native(e)


# Generated at 2022-06-24 21:07:31.763516
# Unit test for function check_required_if
def test_check_required_if():
    assert not check_required_if(requirements=['required', 'param', 'val', 'stuff'], parameters={'param': 'val'})


# Generated at 2022-06-24 21:07:37.393681
# Unit test for function check_required_by
def test_check_required_by():
    requirements_0 = {
        'key': 'value',
    }
    parameters_0 = {
        'key': 'value',
    }
    options_context_0 = None
    result = check_required_by(requirements_0, parameters_0, options_context_0)
    assert result == {}


# Generated at 2022-06-24 21:07:39.511098
# Unit test for function check_type_bytes
def test_check_type_bytes():
    value = 10
    assert check_type_bytes(value) == 10


# Generated at 2022-06-24 21:07:48.568907
# Unit test for function check_required_by
def test_check_required_by():
    # Boiler plate
    module = AnsibleModule(
        argument_spec = dict(
        )
    )
    # No arguments (None)
    assert check_required_by(None, {}, None) == dict()
    # Empty dict
    assert check_required_by(dict(), {}, None) == dict()

    # Actual tests
    assert check_required_by(dict(foo=["bar"]), dict(foo='fizz', bar='buzz'), None) == dict()
    assert check_required_by(dict(foo=["bar"]), dict(foo='fizz', baz='buzz'), None) == dict(foo=['bar'])
    assert check_required_by(dict(foo=["bar"], foobar=['fizzbuzz']), dict(foo='fizz', baz='buzz'), None) == dict

# Generated at 2022-06-24 21:07:54.548542
# Unit test for function safe_eval
def test_safe_eval():
    bool_0 = False
    str_0 = 'x'
    var_0 = safe_eval(bool_0)
    # print(var_0)
    assert var_0 == False
    var_0 = safe_eval(str_0)
    # print(var_0)
    assert var_0 == 'x'


# Generated at 2022-06-24 21:08:00.447495
# Unit test for function check_required_if
def test_check_required_if():
    test_case_0()


# Generated at 2022-06-24 21:08:11.160719
# Unit test for function check_required_by
def test_check_required_by():
    # check that calling with args matching the spec throws expected errors
    # bool --> List of string_types
    bool_0 = True
    bool_1 = False
    # Check that a required arg is reported as an error
    try:
        check_required_by(bool_0, bool_1)
    except TypeError as e:
        assert 'missing the required boolean argument' in str(e)
    # Check that a required arg is reported as an error
    try:
        check_required_by(bool_1, bool_0)
    except TypeError as e:
        assert 'missing the required boolean argument' in str(e)
    # Check that a required arg is reported as an error

# Generated at 2022-06-24 21:08:13.496002
# Unit test for function check_required_if
def test_check_required_if():
    # given
    requirements = [["param_0", "val_0", ["req_0"], True]]
    parameters = {
        "param_0": "val_0",
        "req_0": "test",
    }

    # when
    result = check_required_if(requirements, parameters)

    # then
    assert(result == [])



# Generated at 2022-06-24 21:08:15.852459
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes("1") == 1
    assert check_type_bytes("1B") == 1
    assert check_type_bytes("1 KB") == 1024
    assert check_type_bytes("1 K") == 1000
    assert check_type_bytes("1 Kib") == 1024



# Generated at 2022-06-24 21:08:27.752382
# Unit test for function check_required_if
def test_check_required_if():
    # Testing parameter 'requirements'
    requirements = [
        {
            'key': 'state',
            'val': 'present',
            'requirements': ('path',),
            'is_one_of': True
        },
        {
            'key': 'someint',
            'val': 79,
            'requirements': ('bool_param', 'string_param')
        }
    ]
    # Testing parameter 'parameters'
    parameters = {
        'bool_param': 'explicit',
        'string_param': 'explicit',
        'someint': 79,
        'state': 'present'
    }
    # Testing parameter 'options_context'
    options_context = [
        'NetworkDescription'
    ]
    # SUT

# Generated at 2022-06-24 21:08:35.175918
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    import json
    import ast

    with open('/tmp/test_playbook_1.json', 'r') as myfile:
        data = myfile.read()

    obj = json.loads(data)
    #parameters = obj['parameters']

    for each in obj['spec']['spec']['1']['2']['options']:
        parameters = each['options']
        print(parameters)
        mutually_exclusive_options = {key: ast.literal_eval(value) for (key, value) in each['mutually_exclusive'].iteritems()}
        print(mutually_exclusive_options)
        for exclusive_option_group in mutually_exclusive_options.values():
            check_mutually_exclusive(exclusive_option_group, parameters)


# Generated at 2022-06-24 21:08:44.727905
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    # Testing range of parameters
    # check_missing_parameters() expected to return list
    parameters = dict()
    assert isinstance(check_missing_parameters(parameters, []), list)

    # check_missing_parameters() expected to return list
    parameters = dict(a=True)
    assert isinstance(check_missing_parameters(parameters, []), list)

    # check_missing_parameters() expected to return list
    parameters = dict(a=True)
    assert isinstance(check_missing_parameters(parameters, ['a', 'b']), list)

    # check_missing_parameters() expected to return list
    parameters = dict(a=True, b=False)
    assert isinstance(check_missing_parameters(parameters, ['a', 'b']), list)

    # Testing for TypeError

# Generated at 2022-06-24 21:08:50.580770
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], dict(a=1, b=2)) == []
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], dict(a=1, b=2, c=2)) == [('c', 'd')]
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], dict(a=1, c=2)) == []
    assert check_mutually_exclusive(None, dict(a=1, c=2)) == []
    assert check_mutually_exclusive([['a', 'b']], dict(a=1, b=2)) == []

# Generated at 2022-06-24 21:08:53.616724
# Unit test for function safe_eval
def test_safe_eval():
    # test_case ansible.module_utils.facts.safe_eval : False rval
    test_case_0()



# Generated at 2022-06-24 21:09:01.964020
# Unit test for function safe_eval
def test_safe_eval():
    # Testing 'var_0'
    bool_0 = True
    var_0 = safe_eval(bool_0)
    assert var_0 == True

    # Testing 'var_1'
    str_0 = 'True'
    var_1 = safe_eval(str_0)
    assert var_1 == True

    # Testing 'var_2'
    str_0 = 'False'
    var_2 = safe_eval(str_0)
    assert var_2 == False

    # Testing 'var_3'
    num_0 = 0
    var_3 = safe_eval(num_0)
    assert var_3 == 0

    # Testing 'var_4'
    str_0 = '0'
    var_4 = safe_eval(str_0)
    assert var_4 == 0

    # Testing

# Generated at 2022-06-24 21:09:07.125916
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # bool_0 = True
    # test_0 = check_mutually_exclusive(bool_0, var_0)
    # assert test_0 is None
    assert True



# Generated at 2022-06-24 21:09:14.297544
# Unit test for function check_required_if

# Generated at 2022-06-24 21:09:20.333944
# Unit test for function check_required_if
def test_check_required_if():
    requirements = []
    requirements.append(["state", "present", "path", True])
    requirements.append(["someint", 99, ("bool_param", "string_param")])
    parameters = {}
    assert check_required_if(requirements, parameters) == []


# Generated at 2022-06-24 21:09:25.286951
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    validate_fail_tests = [
        [ [ 'b', 'c' ], { 'a': 1, 'b': 2, 'c': 3 } ]
    ]

    for test in validate_fail_tests:
        try:
            check_mutually_exclusive(test[0], test[1])
        except TypeError as e:
            assert "parameters are mutually exclusive" in str(e)
        else:
            assert False

    validate_pass_tests = [
        [ [ 'b', 'c' ], { 'a': 1, 'b': 2 } ],
        [ [ 'a', 'b', 'c' ], { 'c': 1 } ],
        [ [ 'b', 'c' ], { 'a': 1, 'b': 2, 'c': 3, 'd': 4 } ]
    ]


# Generated at 2022-06-24 21:09:31.149266
# Unit test for function check_type_bytes
def test_check_type_bytes():
    str_0 = ' '
    var_0 = check_type_bytes(str_0)


# Generated at 2022-06-24 21:09:40.705245
# Unit test for function safe_eval
def test_safe_eval():
    # Make sure the function runs without error
    safe_eval('1')
    safe_eval(1)
    # Make sure the function runs without error
    # Make sure the function returns the expected result
    assert safe_eval('True') == True
    # Make sure the function returns the expected result
    assert safe_eval('False') == False
    # Make sure the function returns the expected result
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    # Make sure the function returns the expected result
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    # Make sure the function returns the expected result
    assert safe_eval('[1, 2, 3][1]') == 2
    # Make sure the function returns the expected result
    assert safe_

# Generated at 2022-06-24 21:09:49.853277
# Unit test for function safe_eval
def test_safe_eval():
    # testing a simple example scenario
    result = safe_eval('"3"')
    assert result == '3'
    # testing a simple example scenario
    result = safe_eval('5')
    assert result == 5
    # testing a simple example scenario
    result = safe_eval('-5')
    assert result == -5
    # testing a simple example scenario
    result = safe_eval('-5.5')
    assert result == -5.5
    # testing a simple example scenario
    result = safe_eval('True')
    assert result == True
    # testing a simple example scenario
    result = safe_eval('False')
    assert result == False

# Generated at 2022-06-24 21:09:50.721301
# Unit test for function check_type_bits

# Generated at 2022-06-24 21:09:58.604387
# Unit test for function check_required_arguments
def test_check_required_arguments():
    str_0 = '}N'
    str_1 = 'I'
    str_2 = '|D'
    str_3 = ')'
    str_4 = ']'
    str_5 = 'f'
    str_6 = 'i'
    str_7 = 'C'
    str_8 = ','
    str_9 = '@'
    str_10 = ':'
    var_0 = check_required_arguments(str_0,str_1)
    var_1 = check_required_arguments(str_2,str_3)
    var_2 = check_required_arguments(str_4,str_5)
    var_3 = check_required_arguments(str_6,str_7)

# Generated at 2022-06-24 21:10:02.682329
# Unit test for function check_type_dict
def test_check_type_dict():
    dict_1 = {1:'a', 2:'b', 3:'c'}
    dict_2 = {'key_1': 'value_1', 'key_2': 'value_2', 'key_3': 'value_3'}
    dict_3 = '1=a, 2=b, 3=c'
    dict_4 = 'key_1=value_1, key_2=value_2, key_3=value_3'

    dict_5 = check_type_dict(dict_1)
    dict_6 = check_type_dict(dict_2)
    dict_7 = check_type_dict(dict_3)
    dict_8 = check_type_dict(dict_4)

    print(dict_5)
    print(dict_6)
    print(dict_7)

# Generated at 2022-06-24 21:10:13.283837
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'test_0'
    bool_0 = bool(str_0)
    bool_1 = bool(bool_0)
    bool_2 = bool(bool_1)
    bool_3 = bool(var_0)
    bool_4 = bool(bool_3)
    bool_5 = bool(bool_4)
    bool_6 = bool(bool_5)
    str_1 = 'test_1'
    bool_7 = bool(str_1)
    bool_8 = bool(bool_7)
    bool_9 = bool(bool_8)
    bool_10 = bool(bool_9)
    bool_11 = bool(bool_10)
    bool_12 = bool(bool_11)
    bool_13 = bool(bool_12)

# Generated at 2022-06-24 21:10:24.136802
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('True') == True
    assert safe_eval('"True"') == 'True'
    assert safe_eval('True', include_exceptions=True) == (True, None)
    assert safe_eval('1+1') == 2
    assert safe_eval('[True, False]') == [True, False]
    assert safe_eval('{"key": True}') == {'key': True}
    assert safe_eval('{True, False}') == {True, False}
    assert safe_eval('{True: False}') == {True: False}
    assert safe_eval('True or False') == True
    assert safe_eval('True and False') == False
    assert safe_eval('"""True"""') == 'True'

# Generated at 2022-06-24 21:10:26.598429
# Unit test for function check_type_bits
def test_check_type_bits():
    str_0 = '1Mb'
    var_0 = human_to_bytes(str_0, True)
    assert var_0 == 1048576


# Generated at 2022-06-24 21:10:29.237198
# Unit test for function check_required_together
def test_check_required_together():
    #
    #
    assert True == check_required_together(str_0, str_0)

# Generated at 2022-06-24 21:10:37.123424
# Unit test for function safe_eval
def test_safe_eval():
    print(safe_eval('3'))
    print(safe_eval('[1,2,3]'))
    print(safe_eval('{"a":1,"b":2}'))
    print(safe_eval('[3][0]'))
    print(safe_eval('{"a":1,"b":2}["a"]'))
    print(safe_eval('{"a":1,"b":2}["a"]+1'))



# Generated at 2022-06-24 21:10:42.258507
# Unit test for function check_required_together
def test_check_required_together():
    str_0 = 'g'
    var_0 = check_required_together(str_0, str_0)
    str_1 = 'z'
    str_2 = 'g'
    var_1 = check_required_together(str_1, str_2)
    assert var_0 == var_1


# Generated at 2022-06-24 21:10:46.582759
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '$1'
    var_0 = safe_eval(str_0)
    if type(var_0) is str:
        str_1 = var_0
        print(str_1)


# Generated at 2022-06-24 21:10:47.793309
# Unit test for function check_type_bits
def test_check_type_bits():
    input1 = '1Mb'
    expected_output = 1048576
    output = check_type_bits(input1)
    assert output == expected_output


# Generated at 2022-06-24 21:10:50.179547
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = "'adc"
    var_0 = safe_eval(str_0)
    ans_0 = 'adc'
    assert var_0 == ans_0


# Generated at 2022-06-24 21:10:57.549926
# Unit test for function check_type_float
def test_check_type_float():
    value = '1.1'
    # Call check_type_float with appropriate arguments
    try:
        result = check_type_float(value)
    except Exception as e:
        print(e)
    else:
        print("Result = ", result, "Expected = ", 1.1)


# Generated at 2022-06-24 21:11:05.433459
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = '\"{\\\"test\\\": \\\"test\\\"}\"'
    var_0 = safe_eval(str_0)
    assert type(var_0) == dict
    assert var_0 == {"test": "test"}

    str_0 = '\"test\"'
    var_0 = safe_eval(str_0)
    assert type(var_0) == str
    assert var_0 == "test"

    str_0 = None
    var_0 = safe_eval(str_0)
    assert var_0 == None

    str_0 = '1'
    var_0 = safe_eval(str_0)
    assert type(var_0) == int
    assert var_0 == 1

    str_0 = 'None'

# Generated at 2022-06-24 21:11:14.397421
# Unit test for function check_type_float
def test_check_type_float():
    value = 1.5
    returned = check_type_float(value)
    assert returned == 1.5
    value = True
    returned = check_type_float(value)
    assert returned == 1.0
    value = 1
    returned = check_type_float(value)
    assert returned == 1.0
    value = '1'
    returned = check_type_float(value)
    assert returned == 1.0
    value = '1.5'
    returned = check_type_float(value)
    assert returned == 1.5
    value = []
    returned = check_type_float(value)
    assert returned == 0.0


# Generated at 2022-06-24 21:11:18.366383
# Unit test for function check_type_int
def test_check_type_int():
    str_0 = "0x"
    #pass
    #pass


# Generated at 2022-06-24 21:11:26.142645
# Unit test for function safe_eval
def test_safe_eval():
    # Parameter data type testing
    var_0 = safe_eval('abc')
    assert type(var_0) == str
    var_1 = safe_eval('1')
    assert type(var_1) == int
    
    # Line coverage testing
    var_2 = safe_eval('')
    assert type(var_2) == str

    # Exception testing
    var_3 = safe_eval('1-1')
    assert type(var_3) == int

    # Branch coverage testing
    var_4 = safe_eval('abc')
    assert type(var_4) == str


# Generated at 2022-06-24 21:11:38.099947
# Unit test for function check_type_bytes
def test_check_type_bytes():
    arg = "10"
    expected_result = 10
    result = check_type_bytes(arg)
    print(result)
    assert result == expected_result, "Expected {}, Got {}".format(expected_result, result)



# Generated at 2022-06-24 21:11:48.897958
# Unit test for function check_required_if
def test_check_required_if():
    import unittest
    import mock
    class test_check_required_if(unittest.TestCase):
        def test_it_should_assert_on_missing_parameters(self):
            requirements = [('name','asdf','parameter')]
            parameters = {}
            try:
                check_required_if(requirements, parameters)
            except TypeError:
                e = sys.exc_info()[1]
                self.assertEqual(e.results[0]['missing'], ['parameter'])
            else:
                self.fail('Expected exception')
        def test_it_should_not_assert_on_present_parameters(self):
            requirements = [('name','asdf','parameter')]
            parameters = {'parameter': 'value'}

# Generated at 2022-06-24 21:11:51.313153
# Unit test for function check_type_int
def test_check_type_int():
    # Test case 1
    str_0 = '9'
    var_0 = check_type_int(str_0)
    print(var_0)


# Generated at 2022-06-24 21:11:53.286883
# Unit test for function check_required_together
def test_check_required_together():
    str_0 = 'g'
    var_0 = check_required_together(str_0, str_0)


# Generated at 2022-06-24 21:11:54.137575
# Unit test for function safe_eval
def test_safe_eval():
    safe_eval(123)


# Generated at 2022-06-24 21:12:01.853136
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'g'
    str_1 = 'g'
    str_2 = 'h'
    str_3 = 'f'
    str_4 = 'g'
    str_5 = 'g'
    str_6 = 'h'
    dict_0 = dict()
    boolean_0 = boolean('True')
    boolean_1 = boolean('True')
    boolean_2 = boolean('False')
    boolean_3 = boolean('True')
    boolean_4 = boolean('False')
    boolean_5 = boolean('True')
    boolean_6 = boolean('True')
    boolean_7 = boolean('False')
    boolean_8 = boolean('False')
    boolean_9 = boolean('True')
    boolean_10 = boolean('True')
    boolean_11 = boolean('False')

# Generated at 2022-06-24 21:12:03.056872
# Unit test for function safe_eval
def test_safe_eval():
    # Nothing to test for now
    assert True


# Generated at 2022-06-24 21:12:10.693690
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # The following call to check_required_arguments will fail with a non-empty list
    # change the value of the first argument to [] and the function will return
    # successfully
    str_0 = 'g'
    str_1 = 'g'
    str_2 = 'g'
    str_3 = 'g'
    str_4 = 'g'
    str_5 = 'g'
    str_6 = 'g'
    str_7 = 'g'
    str_8 = 'g'
    str_9 = 'g'
    str_10 = 'g'
    str_11 = 'g'
    str_12 = 'g'
    str_13 = 'g'
    str_14 = 'g'
    str_15 = 'g'
    str_16 = 'g'
    str_17

# Generated at 2022-06-24 21:12:14.997289
# Unit test for function check_type_float
def test_check_type_float():
    # Caught an exception of type <type 'exceptions.TypeError'>
    # (test_check_type_float)
    str_0 = unhexlify('')
    try:
        float_0 = float(str_0)
    except ValueError:
        pass
    str_1 = 'u{}'.format('>')
    float_1 = 0.834389415933
    float_2 = float(str_1)
    str_3 = 'X\xcb\xab\xe1'
    float_3 = float(str_3)
    str_4 = '\xce\x9f\xcf\x8e\xf3'
    float_4 = float(str_4)
    str_5 = '_\x99\xc9\x87\xd7'
    float

# Generated at 2022-06-24 21:12:22.294292
# Unit test for function safe_eval
def test_safe_eval():
    # Test for correct values
    assert safe_eval('50', locals=None, include_exceptions=False) == 50
    assert safe_eval('50.0', locals=None, include_exceptions=False) == 50.0
    # In case of a exception
    assert safe_eval('50.0', locals=None, include_exceptions=True) == (50.0, None)
    # In case of error
    assert safe_eval('asdf', locals=None, include_exceptions=False) == 'asdf'
    assert safe_eval('"asdf"', locals=None, include_exceptions=False) == 'asdf'



# Generated at 2022-06-24 21:12:30.493995
# Unit test for function check_type_float
def test_check_type_float():
    str_0 = 'g'
    int_0 = check_type_float(str_0)
    print(int_0)


# Generated at 2022-06-24 21:12:32.349817
# Unit test for function check_required_together
def test_check_required_together():
    try:
        test_case_0()
    except TypeError as e:
        print(e)


# Generated at 2022-06-24 21:12:35.274091
# Unit test for function check_type_dict
def test_check_type_dict():
    str_0 = "foo=bar"
    result_0 = check_type_dict(str_0)
    print(result_0)


# Generated at 2022-06-24 21:12:38.649463
# Unit test for function check_required_together
def test_check_required_together():
    str_0 = 'g'
    var_0 = check_required_together(str_0, str_0)


# Generated at 2022-06-24 21:12:46.524096
# Unit test for function check_required_if
def test_check_required_if():
    params_1 = {
        'warning': 'xx',
        'error': '31',
        'min': '2',
        'max': '15',
        'messages': 'msg',
        'type': 'persistent',
        'state': 'absent',
        'name': 'test',
        'datagrid_id': '1234',
        'metric_id': '5678'}
    params_0 = {
        'warning': 'xx',
        'error': '31',
        'min': '2',
        'max': '15',
        'messages': 'msg',
        'type': 'persistent',
        'state': 'absent',
        'name': 'test',
        'datagrid_id': '1234',
        'metric_id': '5678'}

# Generated at 2022-06-24 21:12:50.396836
# Unit test for function check_type_bits
def test_check_type_bits():
    value = '1Mb' 
    expected_result = 1048576
    result = check_type_bits(value) 
    assert result == expected_result


# Generated at 2022-06-24 21:12:55.176952
# Unit test for function check_type_bytes
def test_check_type_bytes():
    # given string `size` and unit `B`
    size = "1"
    unit = "B"
    # when call check_type_bytes
    result = check_type_bytes(size + unit)
    # then result == 1
    assert result == 1



# Generated at 2022-06-24 21:12:59.270055
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    str_0 = 'h'
    str_1 = 'i'
    var_0 = check_mutually_exclusive(str_0, str_1)
    assert var_0 == []
    var_1 = check_mutually_exclusive(str_0, str_1, str_0)
    assert var_1 == []


# Generated at 2022-06-24 21:13:02.800574
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of({'a': 5, 'b': 7}, {'a': 5}) == [{'b': 7}]
    assert check_required_one_of({'a': 5, 'b': 7}, {'b': 7}) == [{'a': 5}]


# Generated at 2022-06-24 21:13:05.716783
# Unit test for function check_type_int
def test_check_type_int():
    str_0 = 'i'
    str_1 = '0'
    str_2 = '4'
    int_0 = check_type_int(str_0)
    int_1 = check_type_int(str_1)
    int_2 = check_type_int(str_2)


# Generated at 2022-06-24 21:13:17.306211
# Unit test for function check_type_bits
def test_check_type_bits():
    # string to check
    str_to_check = '1Mb'
    var_to_check = check_type_bits(str_to_check)
    if var_to_check == 0:
        print('Error in check_type_bits!')


# Generated at 2022-06-24 21:13:26.698751
# Unit test for function safe_eval

# Generated at 2022-06-24 21:13:34.908635
# Unit test for function safe_eval
def test_safe_eval():
    # should return result of literal eval if no exception
    assert(safe_eval('{"test": "a"}') == literal_eval('{"test": "a"}'))
    # should return result of literal eval if exception
    assert(safe_eval('{"test": "a"}}') == '{"test": "a"}}')
    # should return input if 'import' statement found
    assert(safe_eval('import os') == 'import os')
    # should return input if method call found
    assert(safe_eval('a.b()') == 'a.b()')
    # should return result of literal eval if no exception
    assert(safe_eval(json.dumps({"test": "a"})))


# Generated at 2022-06-24 21:13:39.366259
# Unit test for function check_type_dict
def test_check_type_dict():
    # init args
    value = 'g'

    # call the test function
    # test_case_0

# Generated at 2022-06-24 21:13:46.560261
# Unit test for function safe_eval
def test_safe_eval():
    # This comment is placed before the function definition to stop the linter
    assert safe_eval('[1,2,3]', include_exceptions=True) == ([1,2,3], None)
    assert safe_eval('[1,2,3]', include_exceptions=False) == [1,2,3]
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"present": True}') == {"present": True}
    assert safe_eval('False') == False
    assert safe_eval('module.function()', include_exceptions=False) == 'module.function()'
    assert safe_eval('import foo', include_exceptions=False) == 'import foo'



# Generated at 2022-06-24 21:13:53.644068
# Unit test for function check_type_bits
def test_check_type_bits():

    # Testing a json
    test_json = '{"a": 1}'
    print("Testing function check_type_bits, with value %s" % test_json)
    result = check_type_bits(test_json)

    # Testing a string
    test_string = "string"
    print("Testing function check_type_bits, with value %s" % test_string)
    result = check_type_bits(test_string)

    #Testing a float
    test_float = 1.0
    print("Testing function check_type_bits, with value %f" % test_float)
    result = check_type_bits(test_float)

    #Testing a integer
    test_int = 1
    print("Testing function check_type_bits, with value %d" % test_int)
    result = check_type_

# Generated at 2022-06-24 21:13:55.140928
# Unit test for function check_type_bits
def test_check_type_bits():
    s = '1.2Mb'
    assert check_type_bits(s) == 1228800

# Generated at 2022-06-24 21:13:57.270075
# Unit test for function check_type_float
def test_check_type_float():
    str_0 = '1'
    float_0 = check_type_float(str_0)
    assert float_0 == 1.0



# Generated at 2022-06-24 21:13:59.491380
# Unit test for function safe_eval
def test_safe_eval():
    var_0 = safe_eval("[1,2,3,4,5]")
    assert isinstance(var_0, list)

# Enum type for check_required_together

# Generated at 2022-06-24 21:14:00.793034
# Unit test for function safe_eval
def test_safe_eval():
    value = '200'
    expected = 200
    actual = safe_eval(value)
    assert actual == expected


# Generated at 2022-06-24 21:14:10.028734
# Unit test for function check_type_int
def test_check_type_int():
    try:
        assert check_type_int('c') == 99, 'Expected 99 to equal 99'
    except TypeError as err:
        print('TypeError: ', err)


# Generated at 2022-06-24 21:14:12.134761
# Unit test for function check_required_together
def test_check_required_together():
    str_0 = 'g'
    str_1 = 'g'
    var_0 = check_required_together(str_0, str_1)
    pass


# Generated at 2022-06-24 21:14:22.572197
# Unit test for function check_required_by
def test_check_required_by():
    # Data initialization
    #str_0 = '{"a":"b","c":{"d":"e","f":"g"}}'
    str_0 = '{"a":"b","d":"e","f":"g"}'
    #dict_0 = json.loads(str_0)
    dict_0 = str_0
    #str_1 = '["a"]'
    str_1 = '{"a":["c"]}'
    dict_1 = eval(str_1)
    #Expected result
    str_2 = 'a'
    #Call the function
    result = check_required_by(dict_1, dict_0)
    #Is the expected result equal to our result?
    assert result == str_2


# Generated at 2022-06-24 21:14:23.579614
# Unit test for function check_type_bytes
def test_check_type_bytes():
    str_0 = 'g'
    var_0 = check_type_bytes(str_0)



# Generated at 2022-06-24 21:14:27.065103
# Unit test for function check_type_dict
def test_check_type_dict():
    # unit tests for check_type_dict
    check_type_dict('{"k1": "v1", "k2": "v2"}')
    check_type_dict('k1=v1, k2=v2')


# Generated at 2022-06-24 21:14:29.882274
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    call_func = check_mutually_exclusive('g', 'g')
    assert call_func == []


# Generated at 2022-06-24 21:14:40.685599
# Unit test for function check_required_by
def test_check_required_by():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = 'm'
    str_4 = '1'
    str_5 = 'k'
    str_6 = 'o'
    str_7 = '7'
    str_8 = 'P'
    str_9 = 'T'
    str_10 = 'x'
    str_11 = 'C'
    str_12 = '4'
    str_13 = 'D'
    str_14 = 'J'
    str_15 = 'V'
    str_16 = 'v'
    str_17 = 'z'
    str_18 = 'a'
    str_19 = '5'
    str_20 = 'l'
    str_21 = 'r'
    str_22 = '/'

# Generated at 2022-06-24 21:14:47.363160
# Unit test for function check_type_bits
def test_check_type_bits():
    bits = check_type_bits('1Mb')
    assert bits == 1048576
    bits = check_type_bits('1 gb')
    assert bits == 1073741824
    bits = check_type_bits('1 gbps')
    assert bits == 1048576
    bits = check_type_bits('1000Gb')
    assert bits == 1073741824000
    bits = check_type_bits('1000Gbps')
    assert bits == 1048576000
    bits = check_type_bits(0)
    assert bits == 0


# Generated at 2022-06-24 21:14:51.682268
# Unit test for function check_required_arguments
def test_check_required_arguments():
    module_arg_spec = {'a': {'required': True, 'type': 'str'},
                       'b': {'required': False, 'type': 'str'},
                       'c': {'required': False, 'type': 'str'}}
    args = {'a': '1'}
    missing_args = check_required_arguments(module_arg_spec, args)
    assert missing_args == []


# Generated at 2022-06-24 21:14:53.552305
# Unit test for function check_type_dict
def test_check_type_dict():
    str_0 = '{a:1,b:2, c: 3}'
    
    var_0 = check_type_dict(str_0)
    assert assert_equal(var_0, {'a': '1', 'b': '2', ' c': ' 3'})


# Generated at 2022-06-24 21:15:00.908753
# Unit test for function check_type_int
def test_check_type_int():
    str_0 = '4'
    var_0 = check_type_int(str_0)
    int_0 = 3
    assert(var_0 == int_0)


# Generated at 2022-06-24 21:15:10.973110
# Unit test for function check_type_dict
def test_check_type_dict():
    """
    Unit test for function check_type_dict
    """

    #
    # NOTE: This test is only here to make sure we achieve 100% test coverage.
    #       Check_type_dict is implemented in the actual "ansible.module_utils.common" module
    #       This import is done at the top of this module
    #
    var_0 = check_type_dict(str_0=str_0)
    check_missing_parameters(str_0=str_0, str_1=str_1)
    check_type_list(str_0=str_0, str_1=str_1)
    check_type_str(str_0=str_0, str_1=str_1)

# Generated at 2022-06-24 21:15:12.086926
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by('k', 'k') == True


# Generated at 2022-06-24 21:15:18.135052
# Unit test for function check_type_bits
def test_check_type_bits():
    assert(type(check_type_bits("0")) == int)
    assert(check_type_bits("0") == 0)
    assert(type(check_type_bits("1M")) == int)
    assert(check_type_bits("1M") == 8388608)
    assert(type(check_type_bits("2B")) == int)
    assert(check_type_bits("2b") == 2)
    assert(type(check_type_bits("3KiB")) == int)
    assert(check_type_bits("3KB") == 24576)
    assert(type(check_type_bits("4MB")) == int)
    assert(check_type_bits("4M") == 4194304)
    assert(type(check_type_bits("5GB")) == int)

# Generated at 2022-06-24 21:15:26.925786
# Unit test for function check_required_arguments
def test_check_required_arguments():
    str_0 = 'u'
    str_1 = 'm'
    str_2 = '^'
    str_4 = ''
    str_5 = '~'
    str_6 = 'd'
    str_7 = 'M'
    str_8 = 'Z'
    str_9 = 'Q'
    str_10 = '5'
    str_11 = ','
    str_13 = 'o'
    str_14 = 't'
    str_15 = 'F'
    str_16 = 'c'
    str_17 = 'q'
    str_18 = 'x'
    str_19 = '0'
    str_20 = 'j'
    str_21 = 'r'
    str_22 = '7'
    str_23 = 'X'
    str_24

# Generated at 2022-06-24 21:15:30.440985
# Unit test for function check_type_bits
def test_check_type_bits():
    str_0 = '1Mb'
    int_0 = 1048576
    int_1 = check_type_bits(str_0)
    assert int_0 == int_1


# Generated at 2022-06-24 21:15:39.861856
# Unit test for function check_required_if
def test_check_required_if():
    print('Testing function check_required_if')
    str_0 = 'g'
    str_1 = 'q'
    list_0 = []
    str_2 = 'd'
    str_3 = 'i'
    # 1
    list_0.append([str_0, str_1, list_0, False])
    # 2
    list_0.append([str_2, str_3, list_0, False])
    # 3
    list_0.append([str_0, str_1, list_0, True])
    # 4
    list_0.append([str_2, str_3, list_0, True])
    list_1 = [str_0, str_1]
    # 5
    list_0.append([str_0, str_1, list_1, False])

# Generated at 2022-06-24 21:15:40.951774
# Unit test for function check_type_bytes
def test_check_type_bytes():
    var_1 = check_type_bytes(str_0)



# Generated at 2022-06-24 21:15:42.423040
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict(1) == {1}


# Generated at 2022-06-24 21:15:46.278646
# Unit test for function check_required_arguments
def test_check_required_arguments():
    str_0 = 'g'
    var_0 = check_required_arguments(str_0, str_0)
    assert var_0 == []


# Generated at 2022-06-24 21:16:01.964829
# Unit test for function check_type_bytes
def test_check_type_bytes():
    start = time.time()
    print("\n*** Starting Unit Tests ***")
    print("Starting test_check_type_bytes function Unit test")
    # test_case_0()
    # test_case_1()
    # test_case_2()
    end = time.time()
    print("\n*** Unit Test Completed in {0:.2f}s ***".format(end - start))



# Generated at 2022-06-24 21:16:04.577484
# Unit test for function check_required_by
def test_check_required_by():

    req_0 = {'a': 'b'}
    str_0 = 'g'
    var_0 = check_required_by(req_0, str_0)


# Generated at 2022-06-24 21:16:13.285908
# Unit test for function check_required_by
def test_check_required_by():
    # Input parameters
    str_0 = 'a'
    str_1 = 'c'
    str_0 = 'e'
    str_0 = 'g'
    var_0 = check_required_together(str_0, str_0)
    var_0 = check_required_by(str_0, str_0)
    str_0 = 'f'
    str_0 = 'b'
    var_0 = check_required_together(str_0, str_0)
    var_0 = check_required_by(str_0, str_0)


# Generated at 2022-06-24 21:16:18.328674
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test case 0
    # Assign param variable
    str_0 = 'g'
    # Call function
    var_0 = check_mutually_exclusive(str_0, str_0)
    # Test case 1
    # Assign param variable
    str_0 = ''
    # Call function
    var_0 = check_mutually_exclusive(str_0, str_0)



# Generated at 2022-06-24 21:16:26.995761
# Unit test for function safe_eval
def test_safe_eval():
    str_0 = 'g'
    bool_0 = not None
    bool_1 = bool_0 == bool_0
    if bool_1:
        int_0 = 0
        int_1 = 0
        while (int_0 < int_1):
            int_0 += 1
            if (int_0 == int_1):
                result_0 = var_0
            else:
                int_1 = int_0
                int_0 += 1
    int_2 = 10
    if (int_2 < int_1):
        str_1 = '\x53\x68\x61\x72\x65\x64\x20\x54\x72\x69\x6d\x2e\x27'

# Generated at 2022-06-24 21:16:35.757082
# Unit test for function safe_eval
def test_safe_eval():
    # Test cases
    res = safe_eval('"Hello world"')
    assert res == "Hello world"

    res = safe_eval('"Hello world"', include_exceptions=True)
    assert res == ("Hello world", None)

    res = safe_eval('pytest.test_case_0()')
    assert res == "g"

    res = safe_eval('pytest.test_case_0()', include_exceptions=True)
    assert res == ("g", None)

    res = safe_eval('import os')
    assert res == "import os"

    res = safe_eval('"Hello world" + "!"')
    assert res == "Hello world!"

    res = safe_eval('"Hello world" + "!"', include_exceptions=True)
    assert res == ("Hello world!", None)

   

# Generated at 2022-06-24 21:16:45.788825
# Unit test for function check_required_arguments
def test_check_required_arguments():
    str_0 = 'g'
    str_1 = b'\xe4\xbd\xa0\xe5\xa5\xbd'
    str_2 = 'hello'
    str_3 = '{'
    int_0 = 0
    float_0 = 1.0
    int_1 = 10
    float_1 = 0.0
    int_2 = 2
    float_2 = 3.0
    # default value
    default_0 = str()
    # bool-type value
    bool_0 = True
    # str-type value
    str_4 = 'test'
    # str-type value
    str_5 = 'test'
    # str-type value
    str_6 = 'test'
    # str-type value
    str_7 = 'test'
    # list-type value