

# Generated at 2022-06-24 21:07:41.774645
# Unit test for function safe_eval
def test_safe_eval():
    # Check if type of value is string_types
    try:
        # Check if the function returned by safe_eval function is a string_types
        assert isinstance(safe_eval(
            "value"), string_types)
    except Exception:
        print("Got exception")
        raise Exception

    # Check if the function returned by safe_eval function is a string_types
    try:
        assert isinstance(safe_eval(b"value"), string_types)
    except Exception:
        print("Got exception")
        raise Exception



# Generated at 2022-06-24 21:07:47.483610
# Unit test for function check_required_if
def test_check_required_if():
    bytes_0 = b'\x1e\x86\x9c\xc5\x03\xaf\x00\xa3\x00\xe3\xe0\x8b\xb2\xfb\x83\x84\xcb1\x94\xed\x00\x82\xa0\xd9\x00O\xc6\x82\x00\x1a\x838\x80\xf1\xd0\x82\xf8\xaa\xa0\xfd\xc3\x8b\x80'
    bytes_1 = b'?\x8f\x08'
    bytes_2 = b'\xc0\x00\xaa\xc5\x01\xb5\x02'

# Generated at 2022-06-24 21:07:58.163285
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    with pytest.raises(TypeError) as e:
        check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2})

    assert "parameters are mutually exclusive:" in str(e)

    assert check_mutually_exclusive('a', {'a': 1}) == []
    assert check_mutually_exclusive(['a', 'b'], {'b': 2}) == []

    with pytest.raises(TypeError) as e:
        check_mutually_exclusive([['a', 'b', 'c'], ['d', 'e']], {'a': 1, 'e': 2, 'b': 3})

    assert "parameters are mutually exclusive: a|b|c found in a -> b -> c" in str(e)


# Generated at 2022-06-24 21:08:00.404796
# Unit test for function check_type_dict
def test_check_type_dict():
    buffer_0 = "abc"
    buffer_1 = "abc"
    dict_0 = check_type_dict(buffer_0)
    dict_1 = check_type_dict(buffer_1)


# Generated at 2022-06-24 21:08:11.119475
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    test_0_1 = '\x12'
    test_0_2 = '\x12'
    test_0_3 = {'\x12': '\x12', '\x12': count_terms(test_0_1, test_0_2)}
    test_0_4 = '\x12'
    test_0_5 = '\x12'
    test_0_6 = {'\x12': '\x12', '\x12': count_terms(test_0_4, test_0_5)}
    test_0_7 = '\x12'
    test_0_8 = '\x12'
    test_0_9 = {'\x12': '\x12', '\x12': count_terms(test_0_7, test_0_8)}
   

# Generated at 2022-06-24 21:08:13.622382
# Unit test for function check_required_if
def test_check_required_if():
    try:
        test_case_0()
    except TypeError as exc:
        if not exc.args[0]:
            raise AssertionError('Exception did not contain an error message!')



# Generated at 2022-06-24 21:08:16.499187
# Unit test for function check_type_int
def test_check_type_int():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-24 21:08:26.502911
# Unit test for function check_required_together
def test_check_required_together():
    # Testcase_1
    var_test = {}
    var_test['k1'] = 'test1'
    var_test['k2'] = 'test2'
    var_test['k3'] = 'test3'

    var_term = [('k1', 'k3')]
    var_result = check_required_together(var_term, var_test)
    print("Testcase_1:", var_result)

    # Testcase_2
    var_test = {}
    var_test['k1'] = 'test1'
    var_test['k2'] = 'test2'
    var_test['k4'] = 'test4'

    var_term = [('k1', 'k3')]
    var_result = check_required_together(var_term, var_test)
   

# Generated at 2022-06-24 21:08:36.607367
# Unit test for function check_required_by
def test_check_required_by():
    from ansible.module_utils.parsing.convert_bool import boolean

    # Test scenario with missing requirements
    test_requirements = {
        'state': 'present',
        'vlan_name': "hello_world",
        'vlan_id': 1000,
        'interfaces': [ 'Ethernet1', 'Ethernet2' ],
    }
    test_parameters = {
        'state': 'present',
        'vlan_name': "hello_world",
        'vlan_id': 1000,
        #'interfaces': [ 'Ethernet1', 'Ethernet2' ],
        'interface': 'Ethernet1',
    }

    try:
        check_required_by(test_requirements, test_parameters)
    except TypeError:
        pass

# Generated at 2022-06-24 21:08:40.436685
# Unit test for function check_required_together
def test_check_required_together():
    bytes_0 = b'+e.\x8d\x06'
    str_0 = str(bytes_0)
    var_0 = check_required_together(str_0, bytes_0)
    return var_0


# Generated at 2022-06-24 21:09:00.178463
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parent_arguments = dict(dest='iam')
    required_params = ['src','force','mode','recursive','_ansible_check_mode','_ansible_verbose_always']
    try:
        test_case_0()
    except Exception as e:
        print('Exception: {}'.format(e))
    try:
        check_missing_parameters(parent_arguments,required_params)
    except Exception as e:
        print('Exception: {}'.format(e))
    parent_arguments = dict(src='/etc/passwd',mode='0777',_ansible_check_mode=True,_ansible_verbose_always=True)

# Generated at 2022-06-24 21:09:06.892144
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('"foo"') == "foo"
    assert safe_eval("['foo', 'bar']") == ['foo', 'bar']
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('true') is True
    assert safe_eval('false') is False
    assert safe_eval('none') is None
    assert safe_eval('boolean(1)') == 1
    assert safe_eval('boolean(0)') == 0
    assert safe_eval('boolean(-1)') == -1
    assert safe_

# Generated at 2022-06-24 21:09:08.020505
# Unit test for function check_required_if
def test_check_required_if():
    # Testing for TypeError raised for empty requirements
    test_case_0()


# Generated at 2022-06-24 21:09:19.838905
# Unit test for function safe_eval
def test_safe_eval():
    bytes_0 = b'{\''
    bytes_1 = b'}'
    bytes_2 = b'E'
    bytes_3 = b''
    bytes_4 = b'e<!\x1b'
    bytes_5 = b'3'
    bytes_6 = b'`'
    bytes_7 = b'x'
    bytes_8 = b'\xb6'
    bytes_9 = b'\x88'
    dict_0 = dict()
    dict_1 = dict()
    dict_0['\x88'] = json.loads(b'\x17\x1a')
    dict_0[b':S\x9d\xe1'] = json.loads(b'\x17\x1a')

# Generated at 2022-06-24 21:09:24.103192
# Unit test for function check_required_together
def test_check_required_together():
    bytes_0 = b'\x87\xfb\x88\xf8\x8f\xb5\x9c\x88\x8b\x87\xfb\xbf\x96\x8f\xf5i\x9bX\xb1\xb8\x89\x87\xfb\xfc\x8e\x87\xfb\x9b\xa9\x8f\xf5i\x9b'
    list_0 = []
    var_0 = check_required_together(bytes_0, list_0)
    assert var_0 == []



# Generated at 2022-06-24 21:09:27.042712
# Unit test for function check_required_by
def test_check_required_by():
    try:
        test_case_0()
    except AssertionError:
        print("UnitTest Failed: check_required_by")


# Generated at 2022-06-24 21:09:29.052284
# Unit test for function check_required_if
def test_check_required_if():
    assert _test_check_required_if_default() == None


# Generated at 2022-06-24 21:09:39.486351
# Unit test for function safe_eval
def test_safe_eval():
    bytes_0 = b'\x0bD\x95\xcc\t\xad\x0f'
    bytes_1 = b'\x0bD\x95\xcc\t\xad\x0f'
    bytes_2 = b'\x0bD\x95\xcc\t\xad\x0f'
    bytes_3 = b'+e.\x8d\x06'
    bytes_4 = b'+e.\x8d\x06'
    bytes_5 = b'+e.\x8d\x06'
    bytes_6 = b'+e.\x8d\x06'
    bytes_7 = b'+e.\x8d\x06'

# Generated at 2022-06-24 21:09:43.042414
# Unit test for function check_required_arguments
def test_check_required_arguments():
    """ Test function check_required_arguments """
    # Setup test values
    argument_spec = {"arg1": {"required": True}, "required": {"required": True}}
    parameters = {"arg1": "required"}

    # Call test function
    missing = check_required_arguments(argument_spec, parameters)

    # Verify Results
    assert missing == []


# Generated at 2022-06-24 21:09:45.344130
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict({}) == {}
    assert check_type_dict('') == {}
    assert check_type_dict('k1=v1,k2=v2') == {'k1': 'v1', 'k2': 'v2'}


# Generated at 2022-06-24 21:10:00.696933
# Unit test for function check_type_bits

# Generated at 2022-06-24 21:10:11.679955
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576, 'check_type_bits(\'1Mb\') should return 1048576'
    assert check_type_bits('1M') == 1048576, 'check_type_bits(\'1M\') should return 1048576'
    assert check_type_bits('10M') == 10485760, 'check_type_bits(\'10M\') should return 10485760'
    assert check_type_bits('100') == 100, 'check_type_bits(\'100\') should return 100'
    assert check_type_bits('100Mb') == 104857600, 'check_type_bits(\'100Mb\') should return 104857600'

# Generated at 2022-06-24 21:10:17.687106
# Unit test for function check_required_if
def test_check_required_if():
    bytes_0 = b'+e.\x8d\x06'

    with pytest.raises(TypeError):
        check_required_if(bytes_0, bytes_0)


# Generated at 2022-06-24 21:10:20.274606
# Unit test for function check_required_if
def test_check_required_if():
    var_0 = b'+e.\x8d\x06'
    var_1 = b'+e.\x8d\x06'
    var_2 = check_required_if(var_1, var_1)


# Generated at 2022-06-24 21:10:22.377551
# Unit test for function check_type_dict
def test_check_type_dict():
    print ('The unit test for function check_type_dict is offered by Ansible')
    print ('Please implement unit test in test/unit/plugins/modules/utils_check_type_dict.py')


# Generated at 2022-06-24 21:10:26.623757
# Unit test for function safe_eval
def test_safe_eval():
    bytes_0 = b'\x8a\xfc\x9bL\x90\xdb}I\x0c\xc1\xdc\x94'
    var_0 = safe_eval(bytes_0)
    assert var_0 == bytes_0


# Generated at 2022-06-24 21:10:38.466894
# Unit test for function check_required_if
def test_check_required_if():
    if "module_arg_spec" in globals():
        global module_arg_spec
        module_arg_spec = False
    if "url_0" in globals():
        global url_0
        url_0 = False
    if "url_1" in globals():
        global url_1
        url_1 = False

    # This function is called from test_cases.py.
    # Data is defined in test_cases.py.
    def test_check_required_if_inner(arg, arg_spec):
        param = arg.pop('parameter', None)
        expected_result = json.loads(arg.pop('expected_result'))
        requirements = [x.values() for x in expected_result['requirements']]

# Generated at 2022-06-24 21:10:42.693124
# Unit test for function check_required_by
def test_check_required_by():
    bytes_0 = b'#\xa4\xb0\x81\xbd\xa7\x1c\xa2'
    int_0 = int()
    dict_0 = dict(int_0)
    var_0 = check_required_by(dict_0, dict_0)


# Generated at 2022-06-24 21:10:52.097698
# Unit test for function safe_eval
def test_safe_eval():
    bytes_0 = b'+e.\x8d\x06'
    safe_0 = safe_eval(bytes_0)
    safe_1 = safe_eval(b'+e.\x8d\x06', None, False)
    safe_2 = safe_eval(b'+e.\x8d\x06', None, True)
    assert safe_0 == safe_1
    assert safe_1 == safe_2
    assert type(safe_0) == type(safe_1)
    assert type(safe_1) == type(safe_2)
    assert safe_0 == bytes_0
    assert safe_1 == bytes_0
    assert safe_2 == bytes_0
    assert type(safe_0) == binary_type
    assert type(safe_1) == binary_type

# Generated at 2022-06-24 21:11:01.443196
# Unit test for function check_required_by
def test_check_required_by():
    req_data = {"security_group_ids": ["zone"]}
    param_data = {"zone": "test_zone", "security_group_ids": ["test_security_group_ids"]}
    result = check_required_by(req_data, param_data)
    assert len(result) == 0

    param_data = {"zone": "test_zone"}
    result = check_required_by(req_data, param_data)
    assert len(result) == 1



# Generated at 2022-06-24 21:11:10.137827
# Unit test for function check_type_dict
def test_check_type_dict():
    dict_0 = dict()
    dict_1 = dict()
    dict_1['foo'] = 1
    dict_1['bar'] = 'bar'
    dict_2 = dict()
    dict_2['foo'] = 1
    dict_2['bar'] = 'bar'
    dict_3 = dict()
    dict_3['foo'] = 1
    dict_3['bar'] = 'bar'
    dict_4 = dict()
    dict_4['foo'] = 1
    dict_4['bar'] = 'bar'
    dict_5 = dict()
    dict_5['foo'] = 1
    dict_5['bar'] = 'bar'
    dict_6 = dict()
    dict_6['foo'] = 1
    dict_6['bar'] = 'bar'
    dict_7 = dict()
    dict_

# Generated at 2022-06-24 21:11:18.716541
# Unit test for function check_type_float
def test_check_type_float():
    list_0 = []
    bytes_0 = b'\xb2\x84\xd7\xec\x1d\x19\x04'
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['foo'] = 'bar'
    dict_1[1] = dict_2
    float_0 = float(dict_1[1]['foo'])
    assert float_0 == float(dict_1[1]['foo'])

    str_0 = str(float_0)
    assert str_0 == str(float_0)
    dict_3 = dict()
    dict_3[1] = 'bar'
    dict_3['foo'] = float_0


# Generated at 2022-06-24 21:11:29.732852
# Unit test for function safe_eval
def test_safe_eval():
    # Check that 'safe_eval' returns True with correct value
    assert safe_eval('1') == 1
    # Check that 'safe_eval' returns True with correct value
    assert safe_eval('5') == 5
    # Check that 'safe_eval' returns True with correct value
    assert safe_eval('tests') == 'tests'
    # Check that 'safe_eval' returns True with correct value
    assert safe_eval('tests') == 'tests'
    # Check that 'safe_eval' returns True with correct value
    assert safe_eval(u'tests') == u'tests'
    # Check that 'safe_eval' returns True with correct value
    assert safe_eval(u'tests') == u'tests'
    assert safe_eval(text_type(u'tests')) == text_type(u'tests')
    # Check that

# Generated at 2022-06-24 21:11:35.665300
# Unit test for function check_required_if

# Generated at 2022-06-24 21:11:45.671095
# Unit test for function safe_eval
def test_safe_eval():
    my_str = "str"
    result = safe_eval(my_str)
    assert result == "str"
    # str
    my_str_2 = '"str"'
    result = safe_eval(my_str_2)
    assert result == "str"
    # list
    my_list_1 = [1,2,3]
    result = safe_eval(my_list_1)
    assert result == [1, 2, 3]
    # list 2
    my_list_2 = "[1, 2, 3]"
    result = safe_eval(my_list_2)
    assert result == [1, 2, 3]
    # dict
    my_dict_1 = {'key': 'value'}
    result = safe_eval(my_dict_1)

# Generated at 2022-06-24 21:11:51.247713
# Unit test for function check_required_if
def test_check_required_if():
    bytes_0 = b'+e.\x8d\x06'
    var_0 = check_required_if(bytes_0, bytes_0)
    assert var_0 == []

# Generated at 2022-06-24 21:11:52.970991
# Unit test for function check_required_if
def test_check_required_if():
    try:
        test_case_0()
    except TypeError:
        pass


# Generated at 2022-06-24 21:11:59.240898
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Gb') == 1073741824


# Generated at 2022-06-24 21:12:00.717830
# Unit test for function check_required_if
def test_check_required_if():
    try:
        test_case_0()
    except:
        assert False



# Generated at 2022-06-24 21:12:05.906132
# Unit test for function check_required_by
def test_check_required_by():
    # Testing with a string as the key
    dict_0 = {'a': 'b'}
    dict_1 = {'a': 'b', 'b': 'c'}
    dict_2 = {'a': 'b', 'b': 'c', 'c': 'd'}
    dict_3 = {'a': 'b', 'b': 'c', 'c': 'e'}
    # check_required_by should return an empty dictionary here
    assert check_required_by(dict_0, dict_1) == {}
    assert check_required_by(dict_0, dict_2) == {}
    assert check_required_by(dict_0, dict_3) == {}

    # Testing with a list as the key
    dict_0 = {'a': ['b', 'c']}

# Generated at 2022-06-24 21:12:15.339788
# Unit test for function check_required_by
def test_check_required_by():
    int_0 = int('-3')
    bytes_0 = b'\x9b\x9f\x9c\x9e\x9a'
    bytes_1 = b'\x9b\x9f\x9c\x9e\x9a'
    bytes_2 = b'\x9a\x9b\x9c\x9e\x9d'
    # AssertionError: Check failed
    # test_case_0()
    # AssertionError: Check failed
    # test_case_1()
    # AssertionError: Check failed
    # test_case_2()
    # AssertionError: Check failed
    # test_case_3()



# Generated at 2022-06-24 21:12:20.706974
# Unit test for function safe_eval
def test_safe_eval():
    global result
    from ansible.compat.tests import unittest

    class TestSafeEval(unittest.TestCase):
        """ Tests for safe_eval function """

        def setUp(self):
            self.TEST_JINJA2_TEMPLATE = """{{123}}"""
            self.TEST_PYTHON_TEMPLATE = "123"
            self.TEST_VAL = "{{ 123 }}"
            self.TEST_VALUE = 123
            self.TEST_JSON_VAL = '{"value": 123}'
            self.TEST_JSON_VALUE = {"value": 123}
            self.TEST_INT = 123

            self.TEST_BAD_JINJA2_TEMPLATE = "{{ import os }}"
            self.TEST_BAD_PYTH

# Generated at 2022-06-24 21:12:23.912094
# Unit test for function check_required_together
def test_check_required_together():
    print("Testing function check_required_together")
    assert check_required_together(['first_param', 'second_param']) == None

# Testing check_required_if

# Generated at 2022-06-24 21:12:26.482604
# Unit test for function check_required_if
def test_check_required_if():
    try:
        test_case_0()
    except Exception as e:
        print('Exception:', e)


# Generated at 2022-06-24 21:12:36.757895
# Unit test for function check_required_if
def test_check_required_if():
    with open("test_check_required_if_data") as f:
        lines = f.readlines()
        f.close()

    lines.pop()
    lines.pop(0)
    lines.pop(0)

    test_cases = []
    while lines:
        arguments = []
        parameters = []
        var_0 = lines.pop(0).strip()
        if var_0 == "Parameters:":
            for i in range(0,2):
                arguments.append(lines.pop(0).strip())

            for i in range(0,3):
                parameters.append(lines.pop(0).strip())
        test_cases.append([arguments, parameters])

    for test_case in test_cases:
        arg = test_case[0]
        param = test_case[1]


# Generated at 2022-06-24 21:12:38.287478
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576, "unit testing failed"
    pass


# Generated at 2022-06-24 21:12:44.315873
# Unit test for function safe_eval
def test_safe_eval():
    assert(safe_eval(["import sys, os"]) == ["import sys, os"])
    assert(safe_eval("import sys, os") == "import sys, os")
    assert(safe_eval("[1, 2, 3]") == [1, 2, 3])
    assert(safe_eval(json.dumps({"1": "2"})) == {"1": "2"})
    assert(safe_eval('json.dumps({"1": "2"})') == 'json.dumps({"1": "2"})')


# Generated at 2022-06-24 21:12:46.180287
# Unit test for function check_required_if
def test_check_required_if():
    assert test_case_0() == 0

# Generated at 2022-06-24 21:12:51.871010
# Unit test for function safe_eval
def test_safe_eval():
    bytes_0 = b'\x00\x00\x00'
    unicode_0 = 'ascii'
    try:
        # Call function safe_eval
        safe_eval(bytes_0, unicode_0)
    except:
        # Test failed
        raise AssertionError("Test failed")
    else:
        # Test passed
        pass


# Generated at 2022-06-24 21:12:54.762738
# Unit test for function check_type_bytes
def test_check_type_bytes():
    bytes_0 = b'+e.\x8d\x06'
    var_0 = check_type_bytes(bytes_0)


# Generated at 2022-06-24 21:13:01.708517
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('10Mb') == 10485760


# Generated at 2022-06-24 21:13:06.789491
# Unit test for function check_type_int
def test_check_type_int():
    print('Testing check_type_int')
    test_var = ['a', 'A', 0, 1, -1, '0', '1', '-1']
    test_var_is_string = [True, True, False, False, False, True, True, True]
    test_var_is_int = [False, False, True, True, True, False, False, False]
    test_var_is_negative = [False, False, False, False, True, False, False, True]
    for i in range(len(test_var)):
        if test_var_is_string[i]:
            test_case = test_var[i]
            var_0 = check_type_int(test_case)
            assert isinstance(var_0, int)

# Generated at 2022-06-24 21:13:08.410319
# Unit test for function safe_eval
def test_safe_eval():
    # Initialize the class
    test_case_0()



# Generated at 2022-06-24 21:13:14.820915
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    list_0 = ['a', 'b']
    dict_0 = {'key_3': 'value_3', 'key_4': 'value_4', 'key_5': 'value_5'}
    var_2 = check_mutually_exclusive(list_0, dict_0)


# Generated at 2022-06-24 21:13:20.621303
# Unit test for function check_type_bytes
def test_check_type_bytes():
    try:
        int_1 = '1K'
        var_1 = check_type_bytes(int_1)
        assert var_1 == 1024, "Assert instance var_1 is equal to '1024'"
    except Exception as e:
        print("[x] " + type(e).__name__ + ": " + str(e))


# Generated at 2022-06-24 21:13:22.574725
# Unit test for function check_type_bits
def test_check_type_bits():
    try:
        assert check_type_bits('1Mb') == 1048576
    except TypeError:
        assert False
    except:
        assert False


# Generated at 2022-06-24 21:13:23.654098
# Unit test for function check_type_bits
def test_check_type_bits():
    result = check_type_bits(2)
    assert result == 2



# Generated at 2022-06-24 21:13:29.843909
# Unit test for function check_required_by
def test_check_required_by():
    # Define input parameters
    # Each member of requirements should be dictionary item
    requirements = {
        'name' : {
            'created': 'created_time',
            'updated': 'updated_time',
            'state': 'state'
        }
    }
    # Each member of parameters should be dictionary item
    parameters = {
        'name' : 'test1',
        'fields' : 'field1',
        'created_time' : 'now()',
        'updated_time' : 'now()',
        'state' : 'present'
    }

    # Define expected output
    expected_output = {}
    # Define expected exception
    try:
        expected_exception = None
    except TypeError as e:
        expected_exception = e
    # Execute test
    result = check_required_by

# Generated at 2022-06-24 21:13:36.143786
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a','b']]
    parameters = {'a':1,'b':2,'c':3}
    options_context = None
    ret = check_required_together(terms, parameters, options_context=None)
    if ret == []:
        pass
    else:
        raise Exception("check_required_together fails.")
    parameters_0 = {}
    try:
        ret = check_required_together(terms, parameters_0, options_context=None)
        raise Exception("check_required_together fails.")
    except TypeError:
        pass


# Generated at 2022-06-24 21:13:40.526496
# Unit test for function check_type_float
def test_check_type_float():
    int_0 = 1
    float_0 = check_type_float(int_0)
    print(f"check_type_float({int_0}) = {float_0}")



# Generated at 2022-06-24 21:13:48.747467
# Unit test for function check_required_if
def test_check_required_if():
    required_if = [['key', 'val', ['required']]]
    parameters = {'key': 'val'}
    options_context = ['core']
    try:
        check_required_if(required_if, parameters, options_context)
    except TypeError as e:
        #print(e)
        print("Expected exception: %s" % (e))


# Generated at 2022-06-24 21:13:49.400154
# Unit test for function check_required_by
def test_check_required_by():
    assert True



# Generated at 2022-06-24 21:13:55.789074
# Unit test for function check_type_bytes
def test_check_type_bytes():
    try:
        test_case_0()
    except:
        traceback.print_exc()

if __name__ == '__main__':
    test_check_type_bytes()

# Generated at 2022-06-24 21:13:57.432100
# Unit test for function check_type_bytes
def test_check_type_bytes():
    actual = check_type_bytes(123)
    expected = 123
    assert actual == expected, 'Expected different value %s but got %s' % (expected, actual)


# Generated at 2022-06-24 21:14:07.870849
# Unit test for function check_type_dict
def test_check_type_dict():
    print('Unit test function check_type_dict' )

    dict_0 = {'apple':20,'orange':15,'banana':10}
    temp_0 = check_type_dict(dict_0)
    assert_equal(temp_0, dict_0)

    dict_1 = 'apple=20,orange=15,banana=10'
    temp_1 = check_type_dict(dict_1)
    assert_equal(temp_1, dict_0)

    dict_2 = '{"apple":20,"orange":15,"banana":10}'
    temp_2 = check_type_dict(dict_2)
    assert_equal(temp_2, dict_0)

    dict_3 = '{apple=20,orange=15,banana=10}'
    temp_3 = check_type_dict

# Generated at 2022-06-24 21:14:16.668473
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{}") == {}
    assert check_type_dict("") == {}
    assert check_type_dict("{'a':1}") == {'a':1}
    assert check_type_dict("'a'='1'") == {'a':'1'}
    assert check_type_dict("'a'='1'") == {'a':'1'}
    assert check_type_dict("1=1") == {'1':'1'}
    assert check_type_dict("'1'=1") == {'1':'1'}
    assert check_type_dict("1='1'") == {'1':'1'}
    assert check_type_dict("1='1'") == {'1':'1'}

# Generated at 2022-06-24 21:14:17.962698
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("True") == True


# Generated at 2022-06-24 21:14:21.493508
# Unit test for function check_type_bits
def test_check_type_bits():
    for test_data in [
        ('1Mb', 1048576),
        ('2Tb', 2147483648),
    ]:
        assert check_type_bits(test_data[0]) == test_data[1]



# Generated at 2022-06-24 21:14:25.789401
# Unit test for function check_required_if
def test_check_required_if():
    int_0 = True
    var_0 = safe_eval(int_0)
    int_1 = check_required_if([[var_0]], [var_0])
    print(int_1)

# Generated at 2022-06-24 21:14:30.104039
# Unit test for function check_type_bytes
def test_check_type_bytes():
    int_0 = '1Kb'
    var_0 = check_type_bytes(int_0)
    assert(var_0 == 1024)
    int_0 = '2MB'
    var_0 = check_type_bytes(int_0)
    assert(var_0 == 2097152)


# Generated at 2022-06-24 21:14:43.100979
# Unit test for function check_required_together
def test_check_required_together():
    # Test normal operation
    terms = [['key_1', 'key_2'], ['key_3', 'key_4']]
    parameters = {'key_1': True, 'key_2': True, 'key_3': True, 'key_4': True}
    options_context = None
    results = check_required_together(terms, parameters, options_context)
    assert results is None

    # Test error condition
    terms = [['key_1', 'key_2'], ['key_3', 'key_4']]
    parameters = {'key_1': True, 'key_2': False, 'key_3': True, 'key_4': True}
    options_context = None
    results = check_required_together(terms, parameters, options_context)
    assert results is not None



# Generated at 2022-06-24 21:14:51.455384
# Unit test for function check_required_if
def test_check_required_if():
    # Set up test cases
    requirements_0 = [('foo', 'bar', ('baz',), True)]
    parameters_0 = {'foo': 'bar'}

    # Evaluate test cases
    try:
        test_case_0()
    except:
        # This shouldn't happen
        raise Exception('Test case 0 failed')

    try:
        check_required_if(requirements_0, parameters_0)
    except TypeError as e:
        # This shouldn't happen
        raise Exception('Test case 1 failed')
    except:
        raise Exception('Test case 2 failed')

    try:
        check_required_if(requirements_0, {'foo': 'other'})
    except TypeError as e:
        # This shouldn't happen
        raise Exception('Test case 3 failed')

# Generated at 2022-06-24 21:14:58.090895
# Unit test for function check_required_if
def test_check_required_if():
    int_0 = True
    try:
        requirements = [
            [int_0, True, ('int_1', 'int_2')],
        ]
        parameters = {'int_0': True, }
        result = check_required_if(requirements, parameters)
    except TypeError as e:
        pass
    else:
        raise AssertionError('Expected TypeError, received {!r}'.format(result))


# Generated at 2022-06-24 21:14:59.844104
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int('test_value') == 'test_value', 'check_type_int(\'test_value\') should return \'test_value\''
    assert check_type_int(1) == 1, 'check_type_int(1) should return 1'


# Generated at 2022-06-24 21:15:02.273736
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(True) == 1
    assert check_type_int(False) == 0
    assert check_type_int(10) == 10
    assert check_type_int('10') == 10

    #Test exception
    try:
        check_type_int('10abc')
        assert False
    except TypeError as e:
        #print(e)
        assert e



# Generated at 2022-06-24 21:15:04.725106
# Unit test for function check_type_int
def test_check_type_int():
    result = check_type_int("")
    assert result == 0



# Generated at 2022-06-24 21:15:06.001310
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1024B') == 1024


# Generated at 2022-06-24 21:15:10.246036
# Unit test for function check_type_bits
def test_check_type_bits():
    try:
        assert check_type_bits('1Mb') == 1048576
    except:
        assert False



# Generated at 2022-06-24 21:15:11.116237
# Unit test for function safe_eval
def test_safe_eval():
    test_case_0()


# Generated at 2022-06-24 21:15:12.228433
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes(u'123') == 123



# Generated at 2022-06-24 21:15:20.555173
# Unit test for function check_required_if
def test_check_required_if():
    parameters = {"key": "val", "someint": 99, "bool_param": True}
    requirements = [["someint", 99, ("bool_param", "string_param")]]
    options_context = []
    expected_result = []
    actual_result = check_required_if(requirements, parameters, options_context)
    assert actual_result == expected_result


# Generated at 2022-06-24 21:15:21.537472
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert True


# Generated at 2022-06-24 21:15:27.851587
# Unit test for function check_type_bytes
def test_check_type_bytes():
    var_1 = "1024"
    var_2 = human_to_bytes(var_1)
    print(var_2)


# Generated at 2022-06-24 21:15:28.747453
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits(True) == None


# Generated at 2022-06-24 21:15:32.047023
# Unit test for function check_type_float
def test_check_type_float():
    # test function call with various valid argument types
    print(check_type_float(1.0))
    print(check_type_float('1.0'))
    print(check_type_float(1))

    # test function fails as expected with various invalid argument types
    try:
        print(check_type_float(1))
    except TypeError as err:
        print('TypeError:', err)

if __name__ == "__main__":
    test_check_type_float()

# Generated at 2022-06-24 21:15:35.723612
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    l = [1,2,3]
    d = {"1":1,"2":2}
    option = [l,]
    try:
        check_mutually_exclusive(option,d)
    finally:
        assert True


# Generated at 2022-06-24 21:15:36.944330
# Unit test for function check_required_together
def test_check_required_together():
    pass


# Generated at 2022-06-24 21:15:39.048752
# Unit test for function check_required_by
def test_check_required_by():
    try:
       var_0 = test_case_0()
    except:
       print("Fail - test_check_required_by")



# Generated at 2022-06-24 21:15:45.221287
# Unit test for function check_type_bytes
def test_check_type_bytes():
    int_0 = 0
    if check_type_bytes(int_0) != 0:
        var_0 = 1
        assert False

    int_1 = 0
    if check_type_bytes(int_1) != 0:
        var_0 = 1
        assert False


# Generated at 2022-06-24 21:15:52.384606
# Unit test for function check_type_bits
def test_check_type_bits():
    expected_var_0 = 1048576
    var_0 = check_type_bits('1Mb')
    if var_0 != expected_var_0:
        msg = 'Expected %s to be %s got %s instead.' % ('check_type_bits(\'1Mb\')', repr(expected_var_0), repr(var_0))
        raise AssertionError(msg)


# Generated at 2022-06-24 21:15:58.216097
# Unit test for function check_type_int
def test_check_type_int():
    assert(check_type_int(int_0) != check_type_int(var_0))

    try:
        check_type_int(var_0)
    except TypeError:
        return True
    else:
        return False


# Generated at 2022-06-24 21:16:07.595251
# Unit test for function check_type_bits
def test_check_type_bits():
    # SOURCE LINE 42
    # Testing: Convert a human-readable string bits value to bits in integer.
    # Example: ``check_type_bits('1Mb')`` returns integer 1048576.
    # Returns: None
    # Raises: :class:`TypeError` if unable to covert the value.
    #
    #
    #
    # setup for test_case_0
    int_0 = 1048576
    str_0 = '1048576'
    # Testing: Convert a human-readable string bits value to bits in integer. Example: ``check_type_bits('1Mb')`` returns integer 1048576. Returns: None Raises: :class:`TypeError` if unable to covert the value.
    #
    int_1 = 10
    str_1 = '10'
    # Testing: Convert a human-readable

# Generated at 2022-06-24 21:16:13.189993
# Unit test for function check_type_bits
def test_check_type_bits():
    # Test case 0
    print("Test case 0")
    int_0 = True
    var_0 = check_type_bits(int_0)
    for val in var_0:
        print(val)


# Generated at 2022-06-24 21:16:21.832636
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == (1 + 1)
    assert safe_eval(True) == True
    assert safe_eval('True') == True
    assert safe_eval('False') == False
    assert safe_eval(42) == 42
    assert safe_eval('42') == 42
    assert safe_eval('42.0') == 42.0
    assert safe_eval('[1,2]') == [1,2]
    assert safe_eval('(1,2)') == (1,2)
    assert safe_eval('1,2') == (1,2)
    assert safe_eval('a', locals={'a':1}) == 1
    assert safe_eval('os.getcwd()') == os.getcwd()

# Generated at 2022-06-24 21:16:26.040159
# Unit test for function check_required_together
def test_check_required_together():

    try:
        terms = ['eth1', 'eth2']
        parameters = {'eth1': 1, 'eth2': 11}
        options_context = ['']
        results = check_required_together(terms, parameters, options_context)
    except TypeError as e:
        assert to_native(e) == 'parameters are required together: eth1, eth2'
    else:
        assert False


# Generated at 2022-06-24 21:16:29.565116
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    terms = ['test']
    params = {'test': '1'}

    assert (check_mutually_exclusive(terms, params) == [])



# Generated at 2022-06-24 21:16:31.713563
# Unit test for function check_type_bits
def test_check_type_bits():
    print("Testing function check_type_bits")
    try:
        test_case_0()
        print ("Test case 0 passed")
    except:
        print ("Test case 0 failed")


# Generated at 2022-06-24 21:16:34.214452
# Unit test for function check_type_float
def test_check_type_float():
    metrics = []
    a = 1
    v = check_type_float(a)
    print(type(v))
    #assert v == int
    #dummy_bool = False
    #assert dummy_bool


# Generated at 2022-06-24 21:16:42.366122
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together([['a', 'b'], ['c', 'd']], {'a': True}) == \
        []
    assert check_required_together([['a', 'b'], ['c', 'd']], {'a': True, 'c': True}) == \
        []
    assert check_required_together([['a', 'b'], ['c', 'd']], {'a': True, 'c': False}) == \
        [['c', 'd']]