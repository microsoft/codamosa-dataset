

# Generated at 2022-06-16 23:09:50.279145
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int("1") == 1
    assert check_type_int(1.0) == 1
    assert check_type_int("1.0") == 1
    assert check_type_int("1.1") == 1
    assert check_type_int("1.9") == 1
    assert check_type_int("-1") == -1
    assert check_type_int("-1.0") == -1
    assert check_type_int("-1.1") == -1
    assert check_type_int("-1.9") == -1
    assert check_type_int("1e1") == 10
    assert check_type_int("1e-1") == 0
    assert check_type_int("1e-2") == 0


# Generated at 2022-06-16 23:09:56.044674
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': '1', 'b': '2', 'c': '3'}
    options_context = ['a', 'b']
    results = check_required_together(terms, parameters, options_context)
    assert results == [['c', 'd']]


# Generated at 2022-06-16 23:10:07.460581
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }

    # Test missing required argument
    parameters = {'optional_arg': 'value'}
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert 'missing required arguments: required_arg' in to_native(e)
    else:
        assert False, 'check_required_arguments did not raise TypeError'

    # Test missing required argument with options_context
    parameters = {'optional_arg': 'value'}
    try:
        check_required_arguments(argument_spec, parameters, options_context=['foo'])
    except TypeError as e:
        assert 'missing required arguments: required_arg found in foo'

# Generated at 2022-06-16 23:10:17.350923
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': 'test'}
    assert check_required_if(requirements, parameters) == []
    parameters = {'state': 'present', 'path': 'test', 'bool_param': True}
    assert check_required_if(requirements, parameters) == []
    parameters = {'state': 'present', 'path': 'test', 'string_param': 'test'}
    assert check_required_if(requirements, parameters) == []
    parameters = {'state': 'present', 'path': 'test', 'bool_param': True, 'string_param': 'test'}

# Generated at 2022-06-16 23:10:28.851777
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """Unit test for function check_mutually_exclusive"""
    # Test for mutually exclusive parameters
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': '1', 'b': '2', 'c': '3', 'd': '4'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        assert e.args[0] == "parameters are mutually exclusive: a|b, c|d"

    # Test for mutually exclusive parameters in sub spec
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': '1', 'b': '2', 'c': '3', 'd': '4'}

# Generated at 2022-06-16 23:10:40.957825
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
        'required_arg_with_default': {'required': True, 'default': 'default_value'},
        'optional_arg_with_default': {'required': False, 'default': 'default_value'},
    }
    parameters = {'required_arg': 'value'}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []
    parameters = {'optional_arg': 'value'}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []
    parameters = {'required_arg_with_default': 'value'}
    missing = check_required_arguments(argument_spec, parameters)

# Generated at 2022-06-16 23:10:49.668933
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together([['a', 'b']], {'a': 1, 'b': 2}) == []
    assert check_required_together([['a', 'b']], {'a': 1}) == [['a', 'b']]
    assert check_required_together([['a', 'b']], {'b': 2}) == [['a', 'b']]
    assert check_required_together([['a', 'b']], {}) == [['a', 'b']]
    assert check_required_together([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3, 'd': 4}) == []

# Generated at 2022-06-16 23:11:01.457389
# Unit test for function check_required_if
def test_check_required_if():
    # Test for check_required_if function
    # Test for required_if with is_one_of=True
    requirements = [['state', 'present', ('path',), True]]
    parameters = {'state': 'present'}
    assert check_required_if(requirements, parameters) == []
    parameters = {'state': 'present', 'path': '/tmp'}
    assert check_required_if(requirements, parameters) == []
    parameters = {'state': 'present', 'path': '/tmp', 'other': 'other'}
    assert check_required_if(requirements, parameters) == []
    parameters = {'state': 'present', 'other': 'other'}

# Generated at 2022-06-16 23:11:11.318769
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
    }
    options_context = ['test']
    try:
        check_required_if(requirements, parameters, options_context)
    except TypeError as e:
        assert e.results == [
            {
                'parameter': 'someint',
                'value': 99,
                'requirements': ('bool_param', 'string_param'),
                'missing': ['string_param'],
                'requires': 'all',
            }
        ]
        assert e.args[0]

# Generated at 2022-06-16 23:11:16.724948
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {
        'key1': ['key2', 'key3'],
        'key2': ['key4', 'key5'],
        'key3': ['key6', 'key7'],
    }
    parameters = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
        'key4': 'value4',
        'key5': 'value5',
        'key6': 'value6',
        'key7': 'value7',
    }
    result = check_required_by(requirements, parameters)
    assert result == {}


# Generated at 2022-06-16 23:11:34.875364
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("'1'") == '1'
    assert safe_eval("'1.0'") == '1.0'
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("1 + 1") == "1 + 1"
    assert safe_eval("1.0 + 1.0") == "1.0 + 1.0"
    assert safe_eval("'1' + '1'")

# Generated at 2022-06-16 23:11:41.022935
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float('1.1e1') == 1.1e1
    assert check_type_float(b'1.1e1') == 1.1e1
    assert check_type_float('1.1e+1') == 1.1

# Generated at 2022-06-16 23:11:49.393147
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2

# Generated at 2022-06-16 23:11:59.489129
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': '1', 'b': '2', 'c': '3'}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': '1', 'b': '2', 'c': '3', 'd': '4'}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': '1', 'b': '2', 'd': '4'}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': '1', 'b': '2'}) == []

# Generated at 2022-06-16 23:12:11.060139
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == check_type_bits('1M')
    assert check_type_bits('1Mb') == check_type_bits('1048576')
    assert check_type_bits('1Mb') == check_type_bits('1048576b')
    assert check_type_bits('1Mb') == check_type_bits('1048576bits')
    assert check_type_bits('1Mb') == check_type_bits('1048576bit')
    assert check_type_bits('1Mb') == check_type_bits('1048576B')

# Generated at 2022-06-16 23:12:15.248210
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1B') == 1
    assert check_type_bytes('1KB') == 1024
    assert check_type_bytes

# Generated at 2022-06-16 23:12:29.169325
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert check_type_dict('a=1, b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a=1, b=2, c=3') == {"a": "1", "b": "2", "c": "3"}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {"a": "1", "b": "2", "c": "3", "d": "4"}

# Generated at 2022-06-16 23:12:40.451436
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('"1"') == "1"
    assert safe_eval('"1.0"') == "1.0"
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('1.0.__class__') == '1.0.__class__'
    assert safe_eval('1.0.__class__()') == '1.0.__class__()'

# Generated at 2022-06-16 23:12:53.505436
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('"foo"') == "foo"
    assert safe_eval("'foo'") == "foo"
    assert safe_eval("'foo'", include_exceptions=True) == ("'foo'", None)
    assert safe_eval("'foo'", include_exceptions=True)[0] == "'foo'"
    assert safe_eval("'foo'", include_exceptions=True)[1] is None

# Generated at 2022-06-16 23:13:02.601500
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(1.5) == 1
    assert check_type_int('1.5') == 1
    assert check_type_int(1.6) == 1
    assert check_type_int('1.6') == 1
    assert check_type_int(1.4) == 1

# Generated at 2022-06-16 23:13:21.418282
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1B') == 1
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736

# Generated at 2022-06-16 23:13:34.022728
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
        'required_arg_with_default': {'required': True, 'default': 'default_value'},
        'optional_arg_with_default': {'required': False, 'default': 'default_value'}
    }
    parameters = {'required_arg': 'value'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'value'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'required_arg_with_default': 'value'}
    assert check_required_arguments(argument_spec, parameters) == []

# Generated at 2022-06-16 23:13:45.914811
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float('1.1e1') == 11.0
    assert check_type_float(b'1.1e1') == 11.0
    assert check_type_float('1.1e-1') == 0.11
    assert check_type

# Generated at 2022-06-16 23:13:53.495200
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('import os', include_exceptions=True) == ('import os', None)
    assert safe_eval('os.path', include_exceptions=True) == ('os.path', None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == '1 + 1'

# Generated at 2022-06-16 23:14:06.199342
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {'key1': 'value1', 'key2': 'value2'}
    requirements = {'key1': ['key2']}
    assert check_required_by(requirements, parameters) == {}

    parameters = {'key1': 'value1'}
    requirements = {'key1': ['key2']}
    assert check_required_by(requirements, parameters) == {'key1': ['key2']}

    parameters = {'key1': 'value1', 'key2': 'value2'}
    requirements = {'key1': 'key2'}
    assert check_required_by(requirements, parameters) == {}

    parameters = {'key1': 'value1'}
    requirements = {'key1': 'key2'}

# Generated at 2022-06-16 23:14:15.154544
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert check_type_dict('a=1, b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a=1, b=2, c=3') == {"a": "1", "b": "2", "c": "3"}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {"a": "1", "b": "2", "c": "3", "d": "4"}

# Generated at 2022-06-16 23:14:27.030371
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg1': {'required': True},
        'required_arg2': {'required': True},
        'optional_arg1': {'required': False},
        'optional_arg2': {'required': False},
    }
    parameters = {
        'required_arg1': 'value1',
        'required_arg2': 'value2',
    }
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []

    parameters = {
        'required_arg1': 'value1',
    }
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == ['required_arg2']

    parameters = {
        'optional_arg1': 'value1',
    }

# Generated at 2022-06-16 23:14:39.698250
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1024 * 1024
    assert check_type_bytes('1G') == 1024 * 1024 * 1024
    assert check_type_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1P') == 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1E') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1Ki') == 1024
    assert check_type_bytes('1Mi') == 1024 * 1024
    assert check_type_bytes('1Gi') == 1024 * 1024 * 1024
    assert check_type_bytes('1Ti') == 1024 * 1024 * 1024 * 1024
    assert check

# Generated at 2022-06-16 23:14:52.269352
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1Ki') == 1024
    assert check_type_bytes('1Mi') == 1048576
    assert check_type_bytes('1Gi') == 1073741824


# Generated at 2022-06-16 23:14:54.307466
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'param1': 'value1', 'param2': 'value2'}
    required_parameters = ['param1', 'param2', 'param3']
    assert check_missing_parameters(parameters, required_parameters) == ['param3']



# Generated at 2022-06-16 23:15:11.085371
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float("1") == 1.0
    assert check_type_float(b"1") == 1.0
    assert check_type_float("1.0") == 1.0
    assert check_type_float(b"1.0") == 1.0
    assert check_type_float("1.1") == 1.1
    assert check_type_float(b"1.1") == 1.1
    assert check_type_float("1.1e1") == 11.0
    assert check_type_float(b"1.1e1") == 11.0
    assert check_type_float("1.1e-1") == 0.11
    assert check

# Generated at 2022-06-16 23:15:24.474145
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:15:33.435019
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('"1"') == '1'
    assert safe_eval('"1.0"') == '1.0'
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('{"a": "b"}.a') == 'b'
    assert safe_eval('1.0.as_integer_ratio()') == '1.0.as_integer_ratio()'

# Generated at 2022-06-16 23:15:45.935022
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1Ki') == 1024
    assert check_type_bytes('1Mi') == 1048576
    assert check_

# Generated at 2022-06-16 23:15:58.321930
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": "b"}') == {"a": "b"}
    assert check_type_dict('a=b, c=d') == {"a": "b", "c": "d"}
    assert check_type_dict('a=b, c=d, e="f,g"') == {"a": "b", "c": "d", "e": "f,g"}
    assert check_type_dict('a=b, c=d, e="f,g,h"') == {"a": "b", "c": "d", "e": "f,g,h"}

# Generated at 2022-06-16 23:16:06.526057
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') != 8388608
    assert check_type_bits('1Mb') != 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:16:17.702846
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736
    assert check_type_bytes('1.5T') == 1649267441664
    assert check_type

# Generated at 2022-06-16 23:16:27.713224
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736
    assert check_type_bytes('1.5T') == 1649267441664
    assert check_type

# Generated at 2022-06-16 23:16:40.536826
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864


# Generated at 2022-06-16 23:16:50.451183
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:17:02.422670
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:17:07.960492
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1mbit') == 1048576
    assert check_type_bits('1mbits') == 1048576
    assert check_type_bits('1m') == 1048576
    assert check_type_bits('1') == 1
    assert check_type_bits('1b') == 1
    assert check_type_bits('1bit') == 1
    assert check_type_bits('1bits') == 1
    assert check_type_bits('1b') == 1
    assert check_type_bits('1') == 1
    assert check_type_bits('1.5mb') == 1572864


# Generated at 2022-06-16 23:17:14.916935
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'present'}
    assert check_required_arguments(argument_spec, parameters) == []

    parameters = {'optional_arg': 'present'}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']



# Generated at 2022-06-16 23:17:27.134745
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a":1}') == {"a": 1}
    assert safe_eval('{"a":1}', include_exceptions=True) == ({"a": 1}, None)
    assert safe_eval('{"a":1', include_exceptions=True) == ('{"a":1', None)
    assert safe_eval('{"a":1}', include_exceptions=True) == ({"a": 1}, None)

# Generated at 2022-06-16 23:17:38.171687
# Unit test for function check_required_by
def test_check_required_by():
    # Test 1:
    # Test case:
    #   requirements: {'key1': ['key2', 'key3']}
    #   parameters: {'key1': 'value1', 'key2': 'value2'}
    # Expected result:
    #   result: {'key1': ['key3']}
    requirements = {'key1': ['key2', 'key3']}
    parameters = {'key1': 'value1', 'key2': 'value2'}
    result = check_required_by(requirements, parameters)
    assert result == {'key1': ['key3']}

    # Test 2:
    # Test case:
    #   requirements: {'key1': ['key2', 'key3']}
    #   parameters: {'key1': 'value1', 'key2':

# Generated at 2022-06-16 23:17:47.225944
# Unit test for function check_required_by
def test_check_required_by():
    # Test with no requirements
    assert check_required_by(None, {}) == {}
    # Test with no parameters
    assert check_required_by({'key': 'value'}, {}) == {}
    # Test with no missing parameters
    assert check_required_by({'key': 'value'}, {'key': 'value'}) == {}
    # Test with missing parameters
    assert check_required_by({'key': 'value'}, {'key': 'value', 'value': 'key'}) == {'key': ['value']}
    # Test with missing parameters and multiple requirements
    assert check_required_by({'key': ['value', 'value2']}, {'key': 'value', 'value': 'key'}) == {'key': ['value2']}
    # Test with missing parameters and multiple requirements and multiple keys
    assert check

# Generated at 2022-06-16 23:17:58.466575
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float("1") == 1.0
    assert check_type_float(b"1") == 1.0
    assert check_type_float(u"1") == 1.0
    assert check_type_float(u"1.0") == 1.0
    assert check_type_float(u"1.1") == 1.1
    assert check_type_float(u"1.1e1") == 11.0
    assert check_type_float(u"1.1e-1") == 0.11
    assert check_type_float(u"1.1e+1") == 11.0

# Generated at 2022-06-16 23:18:08.320529
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(1.5) == 1.5
    assert check_type_float(1.5) == 1.5
    assert check_type_float('1.5') == 1.5
    assert check_type_float(b'1.5') == 1.5
    assert check_type_float(1.5e6) == 1.5e6
    assert check_type_float('1.5e6') == 1.5e6
    assert check_type_float(b'1.5e6') == 1.5e6


# Generated at 2022-06-16 23:18:19.935850
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864


# Generated at 2022-06-16 23:18:30.731409
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'd': 4}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    assert check_required_together(terms, parameters) == []

# Generated at 2022-06-16 23:18:45.374813
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('"foo" + "bar"') == "foobar"
    assert safe_eval('"foo" + "bar"', include_exceptions=True) == ("foobar", None)

# Generated at 2022-06-16 23:18:56.323361
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504

# Generated at 2022-06-16 23:19:07.940445
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("'1'") == '1'
    assert safe_eval("'1.0'") == '1.0'
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("{'a':1,'b':2}") == {'a': 1, 'b': 2}
    assert safe_eval("1.0.__add__(2.0)") == "1.0.__add__(2.0)"
    assert safe_eval("import os") == "import os"
    assert safe_