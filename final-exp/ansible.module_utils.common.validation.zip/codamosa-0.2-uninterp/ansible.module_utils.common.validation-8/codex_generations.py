

# Generated at 2022-06-16 23:10:05.971952
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/tmp/test'}
    result = check_required_if(requirements, parameters)
    assert result == []

    parameters = {'state': 'present', 'someint': 99}
    try:
        result = check_required_if(requirements, parameters)
    except TypeError as e:
        result = e.results
    assert result == [{'missing': ['bool_param', 'string_param'], 'requires': 'all', 'parameter': 'someint', 'value': 99, 'requirements': ('bool_param', 'string_param')}]


# Generated at 2022-06-16 23:10:17.040594
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/some/path'}
    assert check_required_if(requirements, parameters) == []
    parameters = {'state': 'present', 'path': '/some/path', 'bool_param': True}
    assert check_required_if(requirements, parameters) == []
    parameters = {'state': 'present', 'path': '/some/path', 'bool_param': True, 'string_param': 'some string'}
    assert check_required_if(requirements, parameters) == []

# Generated at 2022-06-16 23:10:28.851160
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:10:41.007572
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736
    assert check_type_bytes('1.5T') == 1649267441664
    assert check_type

# Generated at 2022-06-16 23:10:49.730028
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
    }
    options_context = ['test_check_required_if']
    result = check_required_if(requirements, parameters, options_context)
    assert result == []
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
        'string_param': 'test',
    }
    result = check_required_if(requirements, parameters, options_context)
    assert result

# Generated at 2022-06-16 23:11:01.492512
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
    }
    assert check_required_if(requirements, parameters) == []

    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
        'string_param': 'test',
    }
    assert check_required_if(requirements, parameters) == []


# Generated at 2022-06-16 23:11:11.565852
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
    }
    results = check_required_if(requirements, parameters)
    assert len(results) == 1
    assert results[0]['parameter'] == 'someint'
    assert results[0]['value'] == 99
    assert results[0]['requirements'] == ('bool_param', 'string_param')
    assert results[0]['missing'] == ['string_param']
    assert results[0]['requires'] == 'all'


# Generated at 2022-06-16 23:11:19.866593
# Unit test for function check_required_by
def test_check_required_by():
    # Test case 1:
    #   requirements = {'key1': ['key2', 'key3'], 'key4': 'key5'}
    #   parameters = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4', 'key5': 'value5'}
    #   options_context = None
    #   expected_result = {}
    requirements = {'key1': ['key2', 'key3'], 'key4': 'key5'}
    parameters = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4', 'key5': 'value5'}
    options_context = None
    expected_result = {}

# Generated at 2022-06-16 23:11:31.509317
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {'a': 'a', 'b': 'b', 'c': 'c'}
    requirements = {'a': ['b', 'c']}
    result = check_required_by(requirements, parameters)
    assert result == {}

    parameters = {'a': 'a', 'c': 'c'}
    requirements = {'a': ['b', 'c']}
    result = check_required_by(requirements, parameters)
    assert result == {'a': ['b']}

    parameters = {'a': 'a', 'b': 'b'}
    requirements = {'a': ['b', 'c']}
    result = check_required_by(requirements, parameters)
    assert result == {'a': ['c']}

    parameters = {'a': 'a'}

# Generated at 2022-06-16 23:11:36.333660
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    from ansible.module_utils.common.text.converters import to_text
    try:
        check_mutually_exclusive([['a', 'b']], {'a': 'foo', 'b': 'bar'})
    except TypeError as e:
        assert to_text(e) == "parameters are mutually exclusive: a|b"



# Generated at 2022-06-16 23:11:47.756661
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'a': 'b'}
    required_parameters = ['a', 'b']
    assert check_missing_parameters(parameters, required_parameters) == []

    parameters = {'a': 'b'}
    required_parameters = ['a', 'b', 'c']
    try:
        check_missing_parameters(parameters, required_parameters)
    except TypeError as e:
        assert to_native(e) == "missing required arguments: c"



# Generated at 2022-06-16 23:11:58.938767
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504

# Generated at 2022-06-16 23:12:10.354282
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('{"a": 1, "b": 2}', include_exceptions=True) == ({"a": 1, "b": 2}, None)

# Generated at 2022-06-16 23:12:18.718099
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'param1': 'value1', 'param2': 'value2'}
    required_parameters = ['param1', 'param2', 'param3']
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == ['param3']
    parameters = {'param1': 'value1', 'param2': 'value2', 'param3': 'value3'}
    required_parameters = ['param1', 'param2', 'param3']
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == []



# Generated at 2022-06-16 23:12:26.055285
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval("'foo'") == 'foo'
    assert safe_eval("['foo', 'bar']") == ['foo', 'bar']
    assert safe_eval("('foo', 'bar')") == ('foo', 'bar')
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}
    assert safe_eval("{'foo': 'bar', 'baz': 'qux'}") == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-16 23:12:31.793875
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo', include_exceptions=True) == ('foo', None)
    assert safe_eval('foo', include_exceptions=True)[0] == 'foo'
    assert safe_eval('foo', include_exceptions=True)[1] is None
    assert safe_eval('foo.bar()') == 'foo.bar()'

# Generated at 2022-06-16 23:12:42.330726
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Test for missing required arguments
    argument_spec = {'arg1': {'required': True}, 'arg2': {'required': True}}
    parameters = {'arg1': 'value1'}
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert 'missing required arguments: arg2' in str(e)
    else:
        assert False, "check_required_arguments should have raised TypeError"

    # Test for no missing required arguments
    argument_spec = {'arg1': {'required': True}, 'arg2': {'required': True}}
    parameters = {'arg1': 'value1', 'arg2': 'value2'}

# Generated at 2022-06-16 23:12:55.519456
# Unit test for function check_required_arguments

# Generated at 2022-06-16 23:12:59.585056
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb')

# Generated at 2022-06-16 23:13:06.386317
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1B') == 1
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_

# Generated at 2022-06-16 23:13:19.007368
# Unit test for function check_required_together
def test_check_required_together():
    # Test for valid input
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': '1', 'b': '2', 'c': '3', 'd': '4'}
    assert check_required_together(terms, parameters) == []
    # Test for invalid input
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': '1', 'b': '2', 'c': '3'}
    assert check_required_together(terms, parameters) == [['c', 'd']]



# Generated at 2022-06-16 23:13:26.493109
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864


# Generated at 2022-06-16 23:13:37.030852
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504606846976
    assert check_type_bytes('1z') == 1180591620717411303424
    assert check_type_bytes('1y') == 1208925819614629174706176
    assert check_type_bytes(1) == 1
    assert check_type_bytes(1.0) == 1
    assert check_type_bytes

# Generated at 2022-06-16 23:13:48.856451
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:14:00.531668
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:14:12.207987
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:14:24.846262
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:14:37.688048
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1Mi') == 8388608
    assert check_type_bits('1MiB') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1Mi') == 8388608
    assert check_type_bits('1MiB') == 8388608


# Generated at 2022-06-16 23:14:42.095134
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:14:49.014756
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1Mbits') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 10

# Generated at 2022-06-16 23:15:00.338724
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {'a': 'a', 'b': 'b', 'c': 'c'}
    terms = [['a', 'b'], ['b', 'c']]
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 'a', 'b': 'b', 'c': 'c'}
    terms = [['a', 'b'], ['b', 'c'], ['a', 'c']]
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 'a', 'b': 'b', 'c': 'c'}
    terms = [['a', 'b'], ['b', 'c'], ['a', 'c'], ['a', 'b', 'c']]
    assert check_required_together(terms, parameters) == []
   

# Generated at 2022-06-16 23:15:11.829271
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1.0 + 1.0') == 2.0
    assert safe_eval('1 + 1.0') == 2.0
    assert safe_eval('1.0 + 1') == 2.0

# Generated at 2022-06-16 23:15:24.574417
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg1': {'required': True},
        'required_arg2': {'required': True},
        'optional_arg1': {'required': False},
        'optional_arg2': {'required': False},
    }
    parameters = {
        'required_arg1': 'value1',
        'required_arg2': 'value2',
        'optional_arg1': 'value3',
    }
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []
    parameters = {
        'required_arg1': 'value1',
        'optional_arg1': 'value3',
    }
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == ['required_arg2']



# Generated at 2022-06-16 23:15:33.537727
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{'a': 'b'}") == {'a': 'b'}
    assert check_type_dict("a=b") == {'a': 'b'}
    assert check_type_dict("a=b,c=d") == {'a': 'b', 'c': 'd'}
    assert check_type_dict("a=b,c=d,e=f") == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert check_type_dict("a=b, c=d, e=f") == {'a': 'b', 'c': 'd', 'e': 'f'}

# Generated at 2022-06-16 23:15:40.625027
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:15:54.064638
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('["foo", "bar"]') == ['foo', 'bar']
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None


# Generated at 2022-06-16 23:16:04.872003
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert check_type_dict('a=1, b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a=1, b=2, c=3') == {"a": "1", "b": "2", "c": "3"}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {"a": "1", "b": "2", "c": "3", "d": "4"}

# Generated at 2022-06-16 23:16:16.372112
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864


# Generated at 2022-06-16 23:16:20.663725
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int("1") == 1
    assert check_type_int("1.0") == 1
    assert check_type_int(1.0) == 1
    assert check_type_int(1.1) == 1
    assert check_type_int("1.1") == 1
    assert check_type_int("1.1.1") == 1
    assert check_type_int("1.1.1.1") == 1
    assert check_type_int("1.1.1.1.1") == 1
    assert check_type_int("1.1.1.1.1.1") == 1
    assert check_type_int("1.1.1.1.1.1.1") == 1

# Generated at 2022-06-16 23:16:29.640518
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": "b"}') == {'a': 'b'}
    assert check_type_dict('a=b, c=d') == {'a': 'b', 'c': 'd'}
    assert check_type_dict('a=b, c=d, e=f') == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert check_type_dict('a=b, c=d, e=f, g=h') == {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}

# Generated at 2022-06-16 23:16:42.719093
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    options_context = ['a', 'b']
    assert check_required_together(terms, parameters, options_context) == []

    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_together(terms, parameters, options_context) == [['c', 'd']]

    parameters = {'a': 1, 'c': 3}
    assert check_required_together(terms, parameters, options_context) == [['a', 'b'], ['c', 'd']]



# Generated at 2022-06-16 23:16:53.792809
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:17:02.296912
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1") == 1
    assert safe_eval("'1'") == '1'
    assert safe_eval("1.0") == 1.0
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("{'a': 1, 'b': 2}", include_exceptions=True) == ({'a': 1, 'b': 2}, None)

# Generated at 2022-06-16 23:17:15.039451
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float('1.1') == 1.1
    assert check_type_float('1.1e1') == 11.0
    assert check_type_float('1.1e-1') == 0.11
    assert check_type_float('1.1e+1') == 11.0
    assert check_type_float('-1.1e+1') == -11.0
   

# Generated at 2022-06-16 23:17:27.265813
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864


# Generated at 2022-06-16 23:17:33.321299
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1.1') == 1.1
    assert safe_eval('1.1', include_exceptions=True) == (1.1, None)
    assert safe_eval('1.1', include_exceptions=True)[0] == 1.1
    assert safe_eval('1.1', include_exceptions=True)[1] is None
    assert safe_eval('True') is True

# Generated at 2022-06-16 23:17:44.530910
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:17:51.367703
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']



# Generated at 2022-06-16 23:17:55.389760
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['a', 'b']], {'a': 1}) == []
    assert check_required_one_of([['a', 'b']], {'b': 1}) == []
    assert check_required_one_of([['a', 'b']], {'a': 1, 'b': 1}) == []
    assert check_required_one_of([['a', 'b']], {'c': 1}) == [['a', 'b']]



# Generated at 2022-06-16 23:18:05.945281
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736
    assert check_type_bytes('1.5T') == 1649267441664
    assert check_type

# Generated at 2022-06-16 23:18:20.892693
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/foo/bar'}
    results = check_required_if(requirements, parameters)
    assert results == []

    parameters = {'state': 'present', 'path': '/foo/bar', 'someint': 99}
    results = check_required_if(requirements, parameters)
    assert results == []

    parameters = {'state': 'present', 'path': '/foo/bar', 'someint': 99, 'bool_param': True}
    results = check_required_if(requirements, parameters)
    assert results == []


# Generated at 2022-06-16 23:18:31.429546
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('foo.bar()', include_exceptions=True)[0] == 'foo.bar()'
    assert safe_eval('foo.bar()', include_exceptions=True)[1] is None

# Generated at 2022-06-16 23:18:42.399833
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1024 * 1024
    assert check_type_bytes('1G') == 1024 * 1024 * 1024
    assert check_type_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1P') == 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1E') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1Ki') == 1024
    assert check_type_bytes('1Mi') == 1024 * 1024
    assert check_type_bytes('1Gi') == 1024 * 1024 * 1024
    assert check_type_bytes('1Ti') == 1024 * 1024 * 1024 * 1024
    assert check

# Generated at 2022-06-16 23:18:54.338665
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with a single term
    terms = ['a']
    parameters = {'a': 'a'}
    assert check_mutually_exclusive(terms, parameters) == []
    parameters = {'a': 'a', 'b': 'b'}
    assert check_mutually_exclusive(terms, parameters) == []
    parameters = {'a': 'a', 'b': 'b', 'c': 'c'}
    assert check_mutually_exclusive(terms, parameters) == []
    parameters = {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}
    assert check_mutually_exclusive(terms, parameters) == []
    parameters = {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd', 'e': 'e'}


# Generated at 2022-06-16 23:19:02.071931
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('import foo') == 'import foo'
    assert safe_eval('1', include_exceptions=True) == (1, None)

# Generated at 2022-06-16 23:19:14.358485
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504606846976