

# Generated at 2022-06-16 23:09:52.116116
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('["foo", "bar"]') == ['foo', 'bar']
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('1.0.foo()') == '1.0.foo()'
    assert safe_eval('import foo') == 'import foo'
    assert safe_eval('1.0.foo()', include_exceptions=True) == ('1.0.foo()', None)

# Generated at 2022-06-16 23:10:00.968599
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'present'}
    missing = check_required_arguments(argument_spec, parameters)
    assert len(missing) == 0

    parameters = {'optional_arg': 'present'}
    missing = check_required_arguments(argument_spec, parameters)
    assert len(missing) == 1
    assert 'required_arg' in missing



# Generated at 2022-06-16 23:10:11.024268
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test that check_mutually_exclusive raises TypeError when terms are not mutually exclusive
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': '1', 'b': '2', 'c': '3', 'd': '4'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        assert e.args[0] == "parameters are mutually exclusive: a|b, c|d"
    # Test that check_mutually_exclusive does not raise TypeError when terms are mutually exclusive
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': '1', 'c': '3', 'd': '4'}
    assert check_mutually_exclusive(terms, parameters) == []


# Generated at 2022-06-16 23:10:19.103501
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo', include_exceptions=True) == ('foo', None)
    assert safe_eval('foo', include_exceptions=True)[0] == 'foo'
    assert safe_eval('foo', include_exceptions=True)[1] is None
    assert safe_eval('foo.bar()') == 'foo.bar()'

# Generated at 2022-06-16 23:10:29.041443
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'c': 2}
    check_required_one_of(terms, parameters)
    parameters = {'a': 1, 'c': 2, 'd': 3}
    check_required_one_of(terms, parameters)
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    check_required_one_of(terms, parameters)
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    check_required_one_of(terms, parameters)
    parameters = {'c': 1, 'd': 2}
    check_required_one_of(terms, parameters)

# Generated at 2022-06-16 23:10:41.013514
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('foo.bar()', include_exceptions=True) == ('foo.bar()', None)
    assert safe

# Generated at 2022-06-16 23:10:47.155480
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'present'}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []

    parameters = {'optional_arg': 'present'}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == ['required_arg']



# Generated at 2022-06-16 23:10:59.921941
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by({'a': 'b'}, {'a': 'foo', 'b': 'bar'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'foo'}) == {'a': ['b']}
    assert check_required_by({'a': 'b'}, {'a': 'foo', 'b': None}) == {'a': ['b']}
    assert check_required_by({'a': 'b'}, {'a': 'foo', 'b': ''}) == {'a': ['b']}
    assert check_required_by({'a': 'b'}, {'a': 'foo', 'b': []}) == {'a': ['b']}

# Generated at 2022-06-16 23:11:11.285871
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1m') == 1048576
    assert check_type_bits('1mib') == 1048576
    assert check_type_bits('1m') == 1048576
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('1G') == 1073741824
    assert check_type_bits('1Gib') == 1073741824
    assert check_type_bits('1G') == 1073741824

# Generated at 2022-06-16 23:11:20.295962
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": "b"}') == {"a": "b"}
    assert check_type_dict('a=b,c=d') == {"a": "b", "c": "d"}
    assert check_type_dict('a=b,c=d,e=f') == {"a": "b", "c": "d", "e": "f"}
    assert check_type_dict('a=b, c=d, e=f') == {"a": "b", "c": "d", "e": "f"}
    assert check_type_dict('a=b, c=d, e=f, g=h') == {"a": "b", "c": "d", "e": "f", "g": "h"}

# Generated at 2022-06-16 23:11:43.037620
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1Ki') == 1024
    assert check_type_bytes('1Mi') == 1048576
    assert check_type_bytes('1Gi') == 1073741824


# Generated at 2022-06-16 23:11:54.928923
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{'a':1}") == {'a': 1}
    assert check_type_dict("a=1,b=2") == {'a': '1', 'b': '2'}
    assert check_type_dict("a=1,b=2,c=3") == {'a': '1', 'b': '2', 'c': '3'}
    assert check_type_dict("a=1,b=2,c=3,d=4") == {'a': '1', 'b': '2', 'c': '3', 'd': '4'}

# Generated at 2022-06-16 23:12:01.313495
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1

# Generated at 2022-06-16 23:12:05.354496
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:12:15.772018
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
    }
    options_context = []
    results = check_required_if(requirements, parameters, options_context)
    assert results == []

    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
        'string_param': 'test',
    }
    results = check_required_if(requirements, parameters, options_context)
    assert results == []


# Generated at 2022-06-16 23:12:29.299850
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': 'some/path', 'someint': 99}
    assert check_required_if(requirements, parameters) == []
    parameters = {'state': 'present', 'path': 'some/path', 'someint': 99, 'bool_param': True}
    assert check_required_if(requirements, parameters) == []
    parameters = {'state': 'present', 'path': 'some/path', 'someint': 99, 'string_param': 'some_string'}
    assert check_required_if(requirements, parameters) == []

# Generated at 2022-06-16 23:12:40.583190
# Unit test for function check_required_together

# Generated at 2022-06-16 23:12:53.653737
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504606846976

# Generated at 2022-06-16 23:13:02.700007
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/tmp/test'}
    assert check_required_if(requirements, parameters) == []

    parameters = {'state': 'present', 'path': '/tmp/test', 'someint': 99}
    assert check_required_if(requirements, parameters) == []

    parameters = {'state': 'present', 'path': '/tmp/test', 'someint': 99, 'bool_param': True}
    assert check_required_if(requirements, parameters) == []


# Generated at 2022-06-16 23:13:11.784793
# Unit test for function check_required_if

# Generated at 2022-06-16 23:13:26.071799
# Unit test for function check_required_if
def test_check_required_if():
    # Test for check_required_if function
    # Test for required_if with all requirements
    requirements = [['state', 'present', ('path',), True]]
    parameters = {'state': 'present', 'path': '/tmp/test'}
    assert check_required_if(requirements, parameters) == []
    # Test for required_if with any requirements
    requirements = [['state', 'present', ('path', 'path1'), False]]
    parameters = {'state': 'present', 'path': '/tmp/test'}
    assert check_required_if(requirements, parameters) == []
    # Test for required_if with missing requirements
    requirements = [['state', 'present', ('path', 'path1'), False]]
    parameters = {'state': 'present', 'path': '/tmp/test', 'path1': None}
   

# Generated at 2022-06-16 23:13:32.842860
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("'1'") == '1'
    assert safe_eval("'1.0'") == '1.0'
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("1 + 2") == "1 + 2"
    assert safe_eval("1.0 + 2.0") == "1.0 + 2.0"

# Generated at 2022-06-16 23:13:41.434106
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:13:52.760987
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736
    assert check_type_bytes('1.5T') == 1649267441664
    assert check_type

# Generated at 2022-06-16 23:14:05.429914
# Unit test for function check_required_one_of
def test_check_required_one_of():
    parameters = {'a': 1, 'b': 2, 'c': 3}
    terms = [['a', 'b'], ['a', 'c']]
    assert check_required_one_of(terms, parameters) == []

    parameters = {'a': 1, 'b': 2, 'c': 3}
    terms = [['a', 'b'], ['b', 'c']]
    assert check_required_one_of(terms, parameters) == []

    parameters = {'a': 1, 'b': 2, 'c': 3}
    terms = [['a', 'b'], ['b', 'd']]
    assert check_required_one_of(terms, parameters) == [['b', 'd']]

    parameters = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-16 23:14:14.687434
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:14:22.035400
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'value'}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []

    parameters = {'optional_arg': 'value'}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == ['required_arg']



# Generated at 2022-06-16 23:14:34.562737
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by({'a': ['b', 'c']}, {'a': 'foo', 'b': 'bar'}) == {}
    assert check_required_by({'a': ['b', 'c']}, {'a': 'foo', 'b': 'bar', 'c': 'baz'}) == {}
    assert check_required_by({'a': ['b', 'c']}, {'a': 'foo'}) == {'a': ['b', 'c']}
    assert check_required_by({'a': ['b', 'c']}, {'a': 'foo', 'c': 'baz'}) == {'a': ['b']}

# Generated at 2022-06-16 23:14:44.282772
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504

# Generated at 2022-06-16 23:14:55.147439
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)

# Generated at 2022-06-16 23:15:11.792198
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("'1'") == '1'
    assert safe_eval("'1.0'") == '1.0'
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("[1, 2]") == [1, 2]
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("1 + 2") == "1 + 2"
    assert safe_eval("1.0 + 2.0") == "1.0 + 2.0"
    assert safe_eval("'1' + '2'")

# Generated at 2022-06-16 23:15:16.791585
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'not_required_arg': {'required': False},
    }
    parameters = {'required_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'not_required_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']



# Generated at 2022-06-16 23:15:27.988168
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}
    requirements = {'a': ['b', 'c'], 'd': 'c'}
    assert check_required_by(requirements, parameters) == {}
    parameters = {'a': 'a', 'b': 'b', 'c': 'c'}
    requirements = {'a': ['b', 'c'], 'd': 'c'}
    assert check_required_by(requirements, parameters) == {'d': ['c']}
    parameters = {'a': 'a', 'b': 'b', 'c': 'c'}
    requirements = {'a': ['b', 'c'], 'd': ['c', 'e']}
    assert check_required_by(requirements, parameters)

# Generated at 2022-06-16 23:15:37.295458
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(True) == 1
    assert check_type_int(False) == 0
    assert check_type_int('True') == 1
    assert check_type_int('False') == 0
    assert check_type_int('true') == 1
    assert check_type_int('false') == 0
    assert check_type

# Generated at 2022-06-16 23:15:50.570181
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1Mi') == 8388608
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1Mi') == 8388608
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1Mi') == 8388608
   

# Generated at 2022-06-16 23:16:02.386472
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_

# Generated at 2022-06-16 23:16:14.853872
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(u'1.0') == 1.0
    assert check_type_float(u'1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0

# Generated at 2022-06-16 23:16:22.707338
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('-2') == -2
    assert safe_eval('1.2') == 1.2
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval("'bar'") == 'bar'
    assert safe_eval('["foo", "bar"]') == ['foo', 'bar']
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('import foo') == 'import foo'
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)

# Generated at 2022-06-16 23:16:28.461000
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'not_required_arg': {'required': False}
    }
    parameters = {'required_arg': 'present'}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []

    parameters = {'not_required_arg': 'present'}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == ['required_arg']



# Generated at 2022-06-16 23:16:33.324853
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:16:47.817448
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with a single list
    try:
        check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2})
    except TypeError:
        pass
    else:
        assert False, "check_mutually_exclusive() did not raise TypeError"

    # Test with a list of lists
    try:
        check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3, 'd': 4})
    except TypeError:
        pass
    else:
        assert False, "check_mutually_exclusive() did not raise TypeError"

    # Test with a list of lists and a single list

# Generated at 2022-06-16 23:16:58.649723
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("'1'") == '1'
    assert safe_eval("'1.0'") == '1.0'
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("[1,2,3]") == [1, 2, 3]
    assert safe_eval("{'a':1,'b':2}") == {'a': 1, 'b': 2}
    assert safe_eval("1.0.__add__(2.0)") == "1.0.__add__(2.0)"
    assert safe_eval("import os") == "import os"
    assert safe_

# Generated at 2022-06-16 23:17:11.212723
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {'a': 'b', 'c': 'd'}
    requirements = {'a': ['c']}
    result = check_required_by(requirements, parameters)
    assert result == {}

    parameters = {'a': 'b'}
    requirements = {'a': ['c']}
    result = check_required_by(requirements, parameters)
    assert result == {'a': ['c']}

    parameters = {'a': 'b', 'c': 'd'}
    requirements = {'a': 'c'}
    result = check_required_by(requirements, parameters)
    assert result == {}

    parameters = {'a': 'b'}
    requirements = {'a': 'c'}
    result = check_required_by(requirements, parameters)

# Generated at 2022-06-16 23:17:20.224974
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504

# Generated at 2022-06-16 23:17:26.544680
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {'required_arg': {'required': True},
                     'not_required_arg': {'required': False}}
    parameters = {'required_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'not_required_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']



# Generated at 2022-06-16 23:17:34.087287
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:17:45.074859
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1Mib') == 1048576
    assert check_type_bytes('1MiB') == 1048576
    assert check_type_bytes('1MB') == 1000000
    assert check_type_bytes('1Mb') == 1000000
    assert check_type_bytes('1m') == 1000000
    assert check_type_bytes('1k') == 1000
    assert check_type_bytes('1K') == 1000
    assert check_type_bytes('1kib') == 1024
    assert check_type_bytes('1KiB') == 1024
    assert check_type_bytes('1KB') == 1000
    assert check_type_bytes('1Kb') == 1000
    assert check_type_bytes('1') == 1

# Generated at 2022-06-16 23:17:56.641794
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int(1.1) == 1
    assert check_type_int(1.9) == 1
    assert check_type_int(1.999999) == 1
    assert check_type_int(2) == 2
    assert check_type_int(2.0) == 2
    assert check_type_int(2.1) == 2
    assert check_type_int(2.9) == 2
    assert check_type_int(2.999999) == 2
    assert check_type_int(3) == 3
    assert check_type_int(3.0) == 3

# Generated at 2022-06-16 23:18:06.981245
# Unit test for function check_required_if
def test_check_required_if():
    parameters = {'state': 'present', 'path': '/tmp/test', 'someint': 99, 'bool_param': True}
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    results = check_required_if(requirements, parameters)
    assert len(results) == 1
    assert results[0]['parameter'] == 'someint'
    assert results[0]['value'] == 99
    assert results[0]['requirements'] == ('bool_param', 'string_param')
    assert results[0]['missing'] == ['string_param']
    assert results[0]['requires'] == 'all'


# Generated at 2022-06-16 23:18:18.466210
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """Test check_mutually_exclusive function"""
    # Test with a single list
    terms = ['a', 'b']
    parameters = {'a': 1, 'b': 2}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        assert "parameters are mutually exclusive" in str(e)

    # Test with a list of lists
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        assert "parameters are mutually exclusive" in str(e)

    # Test with a list of lists and options_context

# Generated at 2022-06-16 23:18:34.235522
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test 1: Test with a single list of terms
    terms = ['a', 'b']
    parameters = {'a': 'a', 'b': 'b'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pass
    else:
        raise AssertionError('check_mutually_exclusive() failed to raise TypeError')

    # Test 2: Test with a list of lists of terms
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pass

# Generated at 2022-06-16 23:18:38.451136
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576

# Generated at 2022-06-16 23:18:51.040154
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive([['a', 'b']], {'a': 1, 'b': 2}) == [['a', 'b']]
    assert check_mutually_exclusive([['a', 'b']], {'a': 1}) == []
    assert check_mutually_exclusive([['a', 'b']], {'b': 2}) == []
    assert check_mutually_exclusive([['a', 'b']], {}) == []
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3, 'd': 4}) == [['a', 'b'], ['c', 'd']]

# Generated at 2022-06-16 23:19:01.409110
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') != 8388608
    assert check_type_bits('1Mb') != 10485760
    assert check_type_bits('1Mb') != 104857600
    assert check_type_bits('1Mb') != 1048576000
    assert check_type_bits('1Mb') != 10485760000
    assert check_type_bits('1Mb') != 104857600000
    assert check_type_bits('1Mb') != 1048576000000
    assert check_type_bits('1Mb') != 10485760000000
    assert check_type_bits('1Mb') != 104857600000000
    assert check_

# Generated at 2022-06-16 23:19:13.743117
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504