

# Generated at 2022-06-16 23:09:43.931341
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by({'a': 'b'}, {'a': 'foo', 'b': 'bar'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'foo'}) == {'a': ['b']}
    assert check_required_by({'a': 'b'}, {'b': 'foo'}) == {'a': ['b']}
    assert check_required_by({'a': 'b'}, {'a': 'foo', 'b': 'bar', 'c': 'baz'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'foo', 'b': 'bar', 'c': 'baz', 'd': 'qux'}) == {}

# Generated at 2022-06-16 23:09:51.443849
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'foo'}
    try:
        check_required_arguments(argument_spec, parameters)
        assert False
    except TypeError as e:
        assert 'missing required arguments: required_arg' in str(e)



# Generated at 2022-06-16 23:10:03.647053
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg1': {'required': True},
        'required_arg2': {'required': True},
        'optional_arg1': {'required': False},
        'optional_arg2': {'required': False},
    }
    parameters = {'required_arg1': 'value1', 'required_arg2': 'value2'}
    missing = check_required_arguments(argument_spec, parameters)
    assert len(missing) == 0

    parameters = {'required_arg1': 'value1'}
    try:
        missing = check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert 'required_arg2' in str(e)
    else:
        assert False, "TypeError not raised"

    parameters = {}

# Generated at 2022-06-16 23:10:12.612134
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'key1': ['key2', 'key3'], 'key4': 'key5'}
    parameters = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4', 'key5': 'value5'}
    result = check_required_by(requirements, parameters)
    assert result == {}

    requirements = {'key1': ['key2', 'key3'], 'key4': 'key5'}
    parameters = {'key1': 'value1', 'key2': 'value2', 'key4': 'value4', 'key5': 'value5'}
    result = check_required_by(requirements, parameters)
    assert result == {'key1': ['key3']}


# Generated at 2022-06-16 23:10:24.887989
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': None}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': None, 'd': 4}
    assert check_required_together(terms, parameters) == [['c', 'd']]

# Generated at 2022-06-16 23:10:31.023709
# Unit test for function check_required_if
def test_check_required_if():
    # Test with a single requirement
    requirements = [['state', 'present', ('path',)]]
    parameters = {'state': 'present'}
    results = check_required_if(requirements, parameters)
    assert results == []
    parameters = {'state': 'present', 'path': '/tmp/test'}
    results = check_required_if(requirements, parameters)
    assert results == []
    parameters = {'state': 'present', 'path': None}
    results = check_required_if(requirements, parameters)
    assert results == []
    parameters = {'state': 'present', 'path': ''}
    results = check_required_if(requirements, parameters)
    assert results == []
    parameters = {'state': 'present', 'path': False}

# Generated at 2022-06-16 23:10:42.698488
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3}
    options_context = ['options']
    results = check_required_together(terms, parameters, options_context)
    assert results == []

    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    results = check_required_together(terms, parameters, options_context)
    assert results == []

    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 0}
    results = check_required_together(terms, parameters, options_context)
    assert results == []

    parameters = {'a': 1, 'b': 2, 'c': 0, 'd': 0}
    results = check

# Generated at 2022-06-16 23:10:50.540502
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
        'required_arg_with_default': {'required': True, 'default': 'default'},
    }
    parameters = {'required_arg': 'value', 'optional_arg': 'value'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'value'}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']
    assert check_required_arguments(argument_spec, parameters, options_context=['foo']) == ['required_arg']
    parameters = {'required_arg_with_default': 'value', 'optional_arg': 'value'}
    assert check_required_arg

# Generated at 2022-06-16 23:11:01.813011
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('{"foo": "bar", "baz": "qux"}') == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-16 23:11:11.992910
# Unit test for function check_required_if

# Generated at 2022-06-16 23:11:27.204804
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": "b"}') == {"a": "b"}
    assert check_type_dict('a=b') == {"a": "b"}
    assert check_type_dict('a=b, c=d') == {"a": "b", "c": "d"}
    assert check_type_dict('a=b, c=d, e=f') == {"a": "b", "c": "d", "e": "f"}
    assert check_type_dict('a=b, c=d, e=f, g=h') == {"a": "b", "c": "d", "e": "f", "g": "h"}

# Generated at 2022-06-16 23:11:36.236221
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # Test case 1:
    #   terms = [('a', 'b'), ('c', 'd')]
    #   parameters = {'a': 1, 'c': 2}
    #   options_context = None
    #   expected_result = []
    #   expected_msg = None
    terms = [('a', 'b'), ('c', 'd')]
    parameters = {'a': 1, 'c': 2}
    options_context = None
    expected_result = []
    expected_msg = None
    try:
        result = check_required_one_of(terms, parameters, options_context)
    except TypeError as e:
        result = None
        msg = to_native(e)
    assert result == expected_result
    assert msg == expected_msg

    # Test case 2:
    #   terms

# Generated at 2022-06-16 23:11:47.198163
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:11:55.370809
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'value'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'value'}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']
    parameters = {}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']



# Generated at 2022-06-16 23:12:03.499201
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/foo',
        'someint': 99,
        'bool_param': True,
    }
    results = check_required_if(requirements, parameters)
    assert len(results) == 0

    parameters = {
        'state': 'present',
        'path': '/tmp/foo',
        'someint': 99,
        'bool_param': True,
        'string_param': 'foo',
    }
    results = check_required_if(requirements, parameters)
    assert len(results) == 0


# Generated at 2022-06-16 23:12:15.036521
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"a":1}') == {"a":1}
    assert safe_eval('1') == 1
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('import foo') == 'import foo'
    assert safe_eval('[1,2,3]', include_exceptions=True) == ([1,2,3], None)
    assert safe_eval('{"a":1}', include_exceptions=True) == ({"a":1}, None)
    assert safe

# Generated at 2022-06-16 23:12:23.041237
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:12:34.990850
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a":1,"b":2}') == {"a":1,"b":2}
    assert check_type_dict('a=1, b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a=1, b=2, c=3') == {"a": "1", "b": "2", "c": "3"}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {"a": "1", "b": "2", "c": "3", "d": "4"}

# Generated at 2022-06-16 23:12:44.808999
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
   

# Generated at 2022-06-16 23:12:51.180023
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive([['a', 'b']], {'a': 1, 'b': 2}) == [['a', 'b']]
    assert check_mutually_exclusive([['a', 'b']], {'a': 1}) == []
    assert check_mutually_exclusive([['a', 'b']], {'a': 1, 'b': 2, 'c': 3}) == [['a', 'b']]
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3, 'd': 4}) == [['a', 'b'], ['c', 'd']]

# Generated at 2022-06-16 23:13:03.212677
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1m') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1Mbits') == 1048576
    assert check_type_bits('1Mbits') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1m') == 1048576
   

# Generated at 2022-06-16 23:13:12.168285
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0


# Generated at 2022-06-16 23:13:15.911548
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1) == 1.0
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(u'1.1') == 1.1
    try:
        check_type_float(None)
        assert False
    except TypeError:
        pass


# Generated at 2022-06-16 23:13:25.467482
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1024 * 1024
    assert check_type_bytes('1M') == 1024 * 1024
    assert check_type_bytes('1g') == 1024 * 1024 * 1024
    assert check_type_bytes('1G') == 1024 * 1024 * 1024
    assert check_type_bytes('1t') == 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1p') == 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1P') == 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_

# Generated at 2022-06-16 23:13:32.002048
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'present'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'present'}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']



# Generated at 2022-06-16 23:13:40.978986
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"a":1}') == {"a":1}
    assert safe_eval('"abc"') == "abc"
    assert safe_eval('"abc"', include_exceptions=True) == ("abc", None)
    assert safe_eval('abc', include_exceptions=True) == ("abc", None)
    assert safe_eval('import os', include_exceptions=True) == ("import os", None)

# Generated at 2022-06-16 23:13:51.706190
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1M') == 1048576

# Generated at 2022-06-16 23:14:04.972549
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict({'a': 'b'}) == {'a': 'b'}
    assert check_type_dict('a=b') == {'a': 'b'}
    assert check_type_dict('a=b, c=d') == {'a': 'b', 'c': 'd'}
    assert check_type_dict('a=b, c=d, e=f') == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert check_type_dict('a=b, c=d, e=f, g=h') == {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}

# Generated at 2022-06-16 23:14:14.357211
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': 1, 'b': 2}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': 1}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'c': 3}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'c': 3, 'd': 4}


# Generated at 2022-06-16 23:14:26.258601
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1B') == 1
    assert check_type_bytes('1024') == 1024
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736

# Generated at 2022-06-16 23:14:41.150424
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {'a': '1', 'b': '2', 'c': '3'}
    requirements = {'a': ['b', 'c']}
    assert check_required_by(requirements, parameters) == {}

    parameters = {'a': '1', 'b': '2', 'c': None}
    requirements = {'a': ['b', 'c']}
    assert check_required_by(requirements, parameters) == {'a': ['c']}

    parameters = {'a': '1', 'b': None, 'c': '3'}
    requirements = {'a': ['b', 'c']}
    assert check_required_by(requirements, parameters) == {'a': ['b']}

    parameters = {'a': '1', 'b': None, 'c': None}
    requirements

# Generated at 2022-06-16 23:14:52.725109
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a":1,"b":2}') == {"a":1,"b":2}
    assert check_type_dict('a=1, b=2') == {"a":"1", "b":"2"}
    assert check_type_dict('a=1, b=2, c=3') == {"a":"1", "b":"2", "c":"3"}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {"a":"1", "b":"2", "c":"3", "d":"4"}
    assert check_type_dict('a=1, b=2, c=3, d=4, e=5') == {"a":"1", "b":"2", "c":"3", "d":"4", "e":"5"}
    assert check_

# Generated at 2022-06-16 23:14:59.055823
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb')

# Generated at 2022-06-16 23:15:11.186294
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1") == 1
    assert safe_eval("1 + 1") == 2
    assert safe_eval("1 + 1", include_exceptions=True) == (2, None)
    assert safe_eval("1 + 1", include_exceptions=True)[0] == 2
    assert safe_eval("1 + 1", include_exceptions=True)[1] is None
    assert safe_eval("1 + 1", include_exceptions=True) == (2, None)
    assert safe_eval("1 + 1", include_exceptions=True)[0] == 2
    assert safe_eval("1 + 1", include_exceptions=True)[1] is None
    assert safe_eval("1 + 1", include_exceptions=True) == (2, None)

# Generated at 2022-06-16 23:15:24.476045
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)

# Generated at 2022-06-16 23:15:33.472677
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1B') == 1
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1Ki') == 1024
    assert check_type_

# Generated at 2022-06-16 23:15:39.965802
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:15:53.208569
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    options_context = None
    results = check_required_together(terms, parameters, options_context)
    assert results == []
    parameters = {'a': 1, 'b': 2, 'c': 3}
    results = check_required_together(terms, parameters, options_context)
    assert results == [['c', 'd']]
    parameters = {'a': 1, 'c': 3}
    results = check_required_together(terms, parameters, options_context)
    assert results == [['a', 'b'], ['c', 'd']]

# Generated at 2022-06-16 23:16:04.338318
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0


# Generated at 2022-06-16 23:16:16.011778
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 1, 'c': 1}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 1, 'd': 1}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 1, 'c': 1, 'd': 1}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 1}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'c': 1, 'd': 1}) == []

# Generated at 2022-06-16 23:16:29.240661
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(1.1)

# Generated at 2022-06-16 23:16:42.049585
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("'1'") == '1'
    assert safe_eval("'1.0'") == '1.0'
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("1.0.__class__") == "1.0.__class__"
    assert safe_eval("1.0.__class__()") == "1.0.__class__()"


# Generated at 2022-06-16 23:16:52.874302
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
    }
    options_context = ['test_context']
    results = check_required_if(requirements, parameters, options_context)
    assert results == []

    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
    }

# Generated at 2022-06-16 23:17:03.492883
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": "b"}') == {"a": "b"}
    assert check_type_dict('a=b,c=d') == {"a": "b", "c": "d"}
    assert check_type_dict('a=b,c=d,e=f') == {"a": "b", "c": "d", "e": "f"}
    assert check_type_dict('a=b,c=d,e=f,g=h') == {"a": "b", "c": "d", "e": "f", "g": "h"}

# Generated at 2022-06-16 23:17:15.697159
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_

# Generated at 2022-06-16 23:17:27.731683
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with a single list
    terms = ['a', 'b']
    parameters = {'a': 'foo', 'b': 'bar'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pass
    else:
        assert False, "check_mutually_exclusive should have raised TypeError"

    # Test with a list of lists
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 'foo', 'b': 'bar', 'c': 'baz', 'd': 'qux'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pass
    else:
        assert False, "check_mutually_exclusive should have raised TypeError"

    # Test with a list of

# Generated at 2022-06-16 23:17:38.493788
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1b') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1kb') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1mb') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1gb') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1tb') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1pb') == 1125899906842624
   

# Generated at 2022-06-16 23:17:46.375595
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {'a': 'b', 'c': 'd'}
    requirements = {'a': ['c']}
    result = check_required_by(requirements, parameters)
    assert result == {}

    parameters = {'a': 'b'}
    requirements = {'a': ['c']}
    result = check_required_by(requirements, parameters)
    assert result == {'a': ['c']}

    parameters = {'a': 'b'}
    requirements = {'a': 'c'}
    result = check_required_by(requirements, parameters)
    assert result == {'a': ['c']}



# Generated at 2022-06-16 23:17:57.796743
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1.0) == 1.0

# Generated at 2022-06-16 23:18:07.873825
# Unit test for function check_required_if

# Generated at 2022-06-16 23:18:22.719003
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert check_type_dict("a=1, b=2") == {'a': '1', 'b': '2'}
    assert check_type_dict("a=1, b=2, c=3") == {'a': '1', 'b': '2', 'c': '3'}
    assert check_type_dict("a=1, b=2, c=3, d=4") == {'a': '1', 'b': '2', 'c': '3', 'd': '4'}

# Generated at 2022-06-16 23:18:32.856359
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1')

# Generated at 2022-06-16 23:18:40.563620
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Test with no argument_spec
    assert check_required_arguments(None, {}) == []

    # Test with no required arguments
    assert check_required_arguments({'a': {'required': False}}, {}) == []

    # Test with required arguments
    assert check_required_arguments({'a': {'required': True}}, {}) == ['a']

    # Test with required arguments and parameters
    assert check_required_arguments({'a': {'required': True}}, {'a': 'b'}) == []



# Generated at 2022-06-16 23:18:52.831700
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:19:04.255133
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float('1.1.1') == 1.1
    assert check_type_float(b'1.1.1') == 1.1
    assert check_type_float('a') == 1.0

# Generated at 2022-06-16 23:19:16.652968
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # Test case 1:
    #   terms = [('a', 'b'), ('c', 'd')]
    #   parameters = {'a': '1', 'b': '2'}
    #   expected_result = []
    #   expected_error = None
    terms = [('a', 'b'), ('c', 'd')]
    parameters = {'a': '1', 'b': '2'}
    expected_result = []
    expected_error = None
    try:
        result = check_required_one_of(terms, parameters)
    except Exception as e:
        result = None
        error = e
    assert result == expected_result
    assert error == expected_error

    # Test case 2:
    #   terms = [('a', 'b'), ('c', 'd')]
    #   parameters