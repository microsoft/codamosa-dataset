

# Generated at 2022-06-16 23:09:50.074169
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with single list
    terms = ['a', 'b']
    parameters = {'a': 1, 'b': 2}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pass
    else:
        raise AssertionError('check_mutually_exclusive() did not raise TypeError')

    # Test with list of lists
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pass
    else:
        raise AssertionError('check_mutually_exclusive() did not raise TypeError')

    # Test with list of lists and options_context
   

# Generated at 2022-06-16 23:10:02.090401
# Unit test for function check_required_if
def test_check_required_if():
    # Testcase 1
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/tmp/test'}
    options_context = None
    result = check_required_if(requirements, parameters, options_context)
    assert result == []

    # Testcase 2
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/tmp/test', 'someint': 99}
    options_context = None
    result = check_required_if(requirements, parameters, options_context)

# Generated at 2022-06-16 23:10:11.749264
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
        'required_arg_with_default': {'required': True, 'default': 'default_value'},
        'optional_arg_with_default': {'required': False, 'default': 'default_value'},
    }
    parameters = {
        'required_arg': 'value',
        'optional_arg': 'value',
        'required_arg_with_default': 'value',
        'optional_arg_with_default': 'value',
    }
    missing = check_required_arguments(argument_spec, parameters)
    assert len(missing) == 0

# Generated at 2022-06-16 23:10:24.033472
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('"1"') == '1'
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('{"a": 1, "b": 2}', include_exceptions=True) == ({"a": 1, "b": 2}, None)

# Generated at 2022-06-16 23:10:30.413175
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {'required_arg': {'required': True},
                     'not_required_arg': {'required': False}}
    parameters = {'required_arg': 'foo'}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []

    parameters = {'not_required_arg': 'foo'}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == ['required_arg']



# Generated at 2022-06-16 23:10:41.912522
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by(requirements={'a': 'b'}, parameters={'a': 'b'}) == {}
    assert check_required_by(requirements={'a': 'b'}, parameters={'a': 'b', 'b': 'c'}) == {}
    assert check_required_by(requirements={'a': 'b'}, parameters={'a': 'b', 'b': None}) == {}
    assert check_required_by(requirements={'a': 'b'}, parameters={'a': 'b', 'b': 'c', 'c': 'd'}) == {}
    assert check_required_by(requirements={'a': 'b'}, parameters={'a': 'b', 'b': None, 'c': 'd'}) == {}

# Generated at 2022-06-16 23:10:50.184137
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
        'required_arg_with_default': {'required': True, 'default': 'foo'},
        'required_arg_with_default_none': {'required': True, 'default': None},
        'optional_arg_with_default': {'required': False, 'default': 'foo'},
        'optional_arg_with_default_none': {'required': False, 'default': None},
    }

# Generated at 2022-06-16 23:11:01.810287
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/tmp/test'}
    results = check_required_if(requirements, parameters)
    assert len(results) == 0

    parameters = {'state': 'present', 'path': '/tmp/test', 'someint': 99}
    results = check_required_if(requirements, parameters)
    assert len(results) == 0

    parameters = {'state': 'present', 'path': '/tmp/test', 'someint': 99, 'bool_param': True}
    results = check_required_if(requirements, parameters)
    assert len(results) == 0


# Generated at 2022-06-16 23:11:11.992072
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(3.14) == 3.14
    assert check_type_float(3) == 3.0
    assert check_type_float('3.14') == 3.14
    assert check_type_float(b'3.14') == 3.14
    assert check_type_float(u'3.14') == 3.14
    assert check_type_float('3') == 3.0
    assert check_type_float(b'3') == 3.0
    assert check_type_float(u'3') == 3.0
    try:
        check_type_float('3.14.15')
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-16 23:11:17.231720
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 1, 'c': 3}
    assert check_required_together(terms, parameters) == [['a', 'b']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}

# Generated at 2022-06-16 23:11:32.302667
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1b') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1kb') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1mb') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1gb') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1tb') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1pb') == 1125899906842624
   

# Generated at 2022-06-16 23:11:42.344168
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2}) == []
    assert check_mutually_exclusive([['a', 'b']], {'a': 1, 'b': 2}) == [['a', 'b']]
    assert check_mutually_exclusive([['a', 'b', 'c']], {'a': 1, 'b': 2}) == []
    assert check_mutually_exclusive([['a', 'b', 'c']], {'a': 1, 'b': 2, 'c': 3}) == [['a', 'b', 'c']]



# Generated at 2022-06-16 23:11:53.520385
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('a=b, c=d') == {'a': 'b', 'c': 'd'}
    assert check_type_dict('a=b, c=d, e=f') == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert check_type_dict('a=b, c=d, e=f, g=h') == {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}
    assert check_type_dict('a=b, c=d, e=f, g=h, i=j') == {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h', 'i': 'j'}

# Generated at 2022-06-16 23:11:59.985786
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'present'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'present'}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']
    parameters = {}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']



# Generated at 2022-06-16 23:12:11.623327
# Unit test for function check_required_one_of
def test_check_required_one_of():
    parameters = {'a': '1', 'b': '2'}
    terms = [['a', 'b']]
    assert check_required_one_of(terms, parameters) == []

    parameters = {'a': '1'}
    terms = [['a', 'b']]
    assert check_required_one_of(terms, parameters) == []

    parameters = {'b': '2'}
    terms = [['a', 'b']]
    assert check_required_one_of(terms, parameters) == []

    parameters = {'c': '3'}
    terms = [['a', 'b']]
    try:
        check_required_one_of(terms, parameters)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-16 23:12:20.884700
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert check_type_dict('a=1, b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a=1, b=2, c=3') == {"a": "1", "b": "2", "c": "3"}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {"a": "1", "b": "2", "c": "3", "d": "4"}

# Generated at 2022-06-16 23:12:32.014918
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)

# Generated at 2022-06-16 23:12:39.357826
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_param': {'required': True},
        'optional_param': {'required': False},
    }
    parameters = {'required_param': 'present'}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []
    parameters = {'optional_param': 'present'}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == ['required_param']



# Generated at 2022-06-16 23:12:52.713115
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[]') == []
    assert safe_eval('{}') == {}
    assert safe_eval('{"a": 1}') == {"a": 1}
    assert safe_eval('"a"') == "a"
    assert safe_eval('"a"', include_exceptions=True) == ("a", None)
    assert safe_eval('1.0', include_exceptions=True) == (1.0, None)
    assert safe_eval('1', include_exceptions=True) == (1, None)

# Generated at 2022-06-16 23:13:02.123529
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1.5k') == 1536
    assert check_type_bytes('1.5M') == 1572864


# Generated at 2022-06-16 23:13:15.917103
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_

# Generated at 2022-06-16 23:13:25.466816
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736
    assert check_type_bytes('1.5T') == 1649267441664
    assert check_type

# Generated at 2022-06-16 23:13:36.442626
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"a":1,"b":2}') == {"a":1,"b":2}
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('import foo') == 'import foo'

# Generated at 2022-06-16 23:13:45.866316
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'foo'}
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert "missing required arguments: required_arg" in to_native(e)
    else:
        assert False, "check_required_arguments did not raise TypeError"



# Generated at 2022-06-16 23:13:53.425925
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('{"foo": "bar", "baz": "qux"}') == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-16 23:14:06.149040
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together([['a', 'b']], {'a': 1, 'b': 2}) == []
    assert check_required_together([['a', 'b']], {'a': 1}) == [['a', 'b']]
    assert check_required_together([['a', 'b']], {'b': 2}) == [['a', 'b']]
    assert check_required_together([['a', 'b']], {'c': 3}) == []
    assert check_required_together([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3, 'd': 4}) == []
    assert check_required_together([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-16 23:14:15.122973
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/foo',
        'someint': 99,
        'bool_param': True,
    }
    results = check_required_if(requirements, parameters)
    assert len(results) == 0

    parameters = {
        'state': 'present',
        'someint': 99,
        'bool_param': True,
    }
    try:
        results = check_required_if(requirements, parameters)
    except TypeError as e:
        assert len(e.results) == 1
        assert e.results[0]['parameter'] == 'state'
        assert e

# Generated at 2022-06-16 23:14:26.982494
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': 'some/path',
        'someint': 99,
        'bool_param': True,
    }
    assert check_required_if(requirements, parameters) == []

    parameters = {
        'state': 'present',
        'path': 'some/path',
        'someint': 99,
        'bool_param': True,
        'string_param': 'some string',
    }
    assert check_required_if(requirements, parameters) == []


# Generated at 2022-06-16 23:14:39.653177
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int(1.1) == 1
    assert check_type_int(1.9) == 1
    assert check_type_int(1.5) == 1
    assert check_type_int(1.6) == 1
    assert check_type_int(1.4) == 1
    assert check_type_int(1.5) == 1
    assert check_type_int(1.6) == 1
    assert check_type_int(1.4) == 1
    assert check_type_int(1.5) == 1

# Generated at 2022-06-16 23:14:52.267311
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/tmp/test'}
    results = check_required_if(requirements, parameters)
    assert results == []
    parameters = {'state': 'present', 'someint': 99, 'bool_param': True}
    results = check_required_if(requirements, parameters)
    assert results == []
    parameters = {'state': 'present', 'someint': 99, 'bool_param': True, 'string_param': 'test'}
    results = check_required_if(requirements, parameters)
    assert results == []

# Generated at 2022-06-16 23:15:02.522778
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('import os') == 'import os'
    assert safe_eval('import os', include_exceptions=True) == ('import os', None)
    assert safe_eval('import os', include_exceptions=True)[0] == 'import os'
    assert safe_eval('import os', include_exceptions=True)[1] is None
    assert safe_eval('os.system("echo hello")') == 'os.system("echo hello")'

# Generated at 2022-06-16 23:15:13.116297
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1p') == 1125899

# Generated at 2022-06-16 23:15:24.260680
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/some/path',
        'someint': 99,
        'bool_param': True,
    }
    result = check_required_if(requirements, parameters)
    assert result == [
        {
            'parameter': 'someint',
            'value': 99,
            'requirements': ('bool_param', 'string_param'),
            'missing': ['string_param'],
            'requires': 'all',
        }
    ]



# Generated at 2022-06-16 23:15:33.278689
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2

# Generated at 2022-06-16 23:15:39.767764
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Test with no required arguments
    argument_spec = {
        'arg1': {'required': False},
        'arg2': {'required': False},
        'arg3': {'required': False}
    }
    parameters = {
        'arg1': 'value1',
        'arg2': 'value2',
        'arg3': 'value3'
    }
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []

    # Test with one required argument
    argument_spec = {
        'arg1': {'required': False},
        'arg2': {'required': True},
        'arg3': {'required': False}
    }

# Generated at 2022-06-16 23:15:53.057367
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736
    assert check_type_bytes('1.5T') == 1649267441664
    assert check_type

# Generated at 2022-06-16 23:15:59.037164
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'param1': 'value1', 'param2': 'value2'}
    required_parameters = ['param1', 'param2', 'param3']
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == ['param3']



# Generated at 2022-06-16 23:16:06.755734
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2}) == []
    assert check_mutually_exclusive(['a', 'b'], {'a': 1}) == []
    assert check_mutually_exclusive(['a', 'b'], {'b': 2}) == []
    assert check_mutually_exclusive(['a', 'b'], {}) == []
    assert check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2, 'c': 3}) == [['a', 'b']]

# Generated at 2022-06-16 23:16:17.825603
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'd': 4}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': 1, 'c': 3, 'd': 4}
    assert check_required_together(terms, parameters) == [['a', 'b']]

# Generated at 2022-06-16 23:16:27.790660
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 1, 'c': 2}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 1}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'c': 2}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 1, 'c': 2, 'e': 3}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'e': 3}) == [['a', 'b'], ['c', 'd']]
    assert check_required

# Generated at 2022-06-16 23:16:42.894304
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736
    assert check_type_bytes('1.5T') == 1649267441664
    assert check_type

# Generated at 2022-06-16 23:16:50.481872
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with a single list
    terms = ['a', 'b']
    parameters = {'a': 1, 'b': 2}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pass
    else:
        assert False, "check_mutually_exclusive() did not raise TypeError"

    # Test with a list of lists
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pass
    else:
        assert False, "check_mutually_exclusive() did not raise TypeError"

    # Test with a list of lists and a list

# Generated at 2022-06-16 23:17:00.289215
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1 + 1") == 2
    assert safe_eval("1 + 1", include_exceptions=True) == (2, None)
    assert safe_eval("1 + 1", include_exceptions=True)[0] == 2
    assert safe_eval("1 + 1", include_exceptions=True)[1] is None
    assert safe_eval("1 + 1", include_exceptions=True) == (2, None)
    assert safe_eval("1 + 1", include_exceptions=True)[0] == 2
    assert safe_eval("1 + 1", include_exceptions=True)[1] is None
    assert safe_eval("1 + 1", include_exceptions=True) == (2, None)
    assert safe_eval("1 + 1", include_exceptions=True)[0] == 2
    assert safe_

# Generated at 2022-06-16 23:17:12.765959
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['a', 'b']], {'a': 'foo'}) == []
    assert check_required_one_of([['a', 'b']], {'b': 'foo'}) == []
    assert check_required_one_of([['a', 'b']], {'a': 'foo', 'b': 'foo'}) == []
    assert check_required_one_of([['a', 'b']], {}) == [['a', 'b']]
    assert check_required_one_of([['a', 'b']], {'c': 'foo'}) == [['a', 'b']]
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 'foo', 'c': 'foo'}) == []
    assert check_

# Generated at 2022-06-16 23:17:25.224852
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(u'1.0') == 1.0
    assert check_type_float(u'1') == 1.0
    assert check_type_float(u'1.0') == 1.0
    assert check_type_float(u'1') == 1.0
    assert check_type_float(u'1.0') == 1.0
    assert check_type_float(u'1') == 1.0
    assert check_type_

# Generated at 2022-06-16 23:17:34.882440
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert check_type_dict('a=1, b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a=1, b=2, c=3') == {"a": "1", "b": "2", "c": "3"}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {"a": "1", "b": "2", "c": "3", "d": "4"}

# Generated at 2022-06-16 23:17:45.535980
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)

# Generated at 2022-06-16 23:17:57.132712
# Unit test for function check_required_if
def test_check_required_if():
    # Test for is_one_of = True
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
    }
    assert check_required_if(requirements, parameters) == []
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
        'string_param': 'test',
    }
    assert check_required_if(requirements, parameters) == []

# Generated at 2022-06-16 23:18:07.385467
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("'1'") == '1'
    assert safe_eval("'1.0'") == '1.0'
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("1 + 2") == "1 + 2"
    assert safe_eval("1.0 + 2.0") == "1.0 + 2.0"

# Generated at 2022-06-16 23:18:18.861135
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int("1") == 1
    assert check_type_int(1.0) == 1
    assert check_type_int("1.0") == 1
    assert check_type_int("1.1") == 1
    assert check_type_int("-1") == -1
    assert check_type_int("-1.1") == -1
    assert check_type_int("0x1") == 1
    assert check_type_int("0x1.1") == 1
    assert check_type_int("0x1.1p1") == 3
    assert check_type_int("0x1.1p-1") == 1
    assert check_type_int("0x1.1p+1") == 3
    assert check_type

# Generated at 2022-06-16 23:18:32.279545
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:18:38.979007
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:18:51.549982
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert check_type_dict('a=1, b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a=1, b=2, c=3') == {"a": "1", "b": "2", "c": "3"}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {"a": "1", "b": "2", "c": "3", "d": "4"}

# Generated at 2022-06-16 23:19:02.170094
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1Ki') == 1024
    assert check_type_bytes('1Mi') == 1048576
    assert check_

# Generated at 2022-06-16 23:19:14.399125
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')