

# Generated at 2022-06-16 23:09:44.337081
# Unit test for function check_required_together
def test_check_required_together():
    assert check_required_together([('a', 'b'), ('c', 'd')], {'a': 1, 'b': 2, 'c': 3, 'd': 4}) == []
    assert check_required_together([('a', 'b'), ('c', 'd')], {'a': 1, 'b': 2, 'c': 3}) == [('c', 'd')]
    assert check_required_together([('a', 'b'), ('c', 'd')], {'a': 1, 'c': 3}) == [('a', 'b'), ('c', 'd')]
    assert check_required_together([('a', 'b'), ('c', 'd')], {'a': 1}) == [('a', 'b'), ('c', 'd')]

# Generated at 2022-06-16 23:09:56.045489
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """Test check_mutually_exclusive function"""
    # pylint: disable=unused-argument
    def test_function(module, terms, parameters, options_context=None):
        """Test function for check_mutually_exclusive"""
        return check_mutually_exclusive(terms, parameters, options_context)

    # Test with None terms
    assert test_function(None, None, None) == []

    # Test with empty terms
    assert test_function(None, [], None) == []

    # Test with single term
    assert test_function(None, ['a'], {'a': 1}) == []
    assert test_function(None, ['a'], {'a': 1, 'b': 2}) == []
    assert test_function(None, ['a'], {'b': 2}) == []

    # Test with multiple

# Generated at 2022-06-16 23:10:07.460590
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test that a single list of terms is accepted
    terms = ['a', 'b']
    parameters = {'a': 'foo', 'b': 'bar'}
    assert check_mutually_exclusive(terms, parameters) == []

    # Test that a list of lists of terms is accepted
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 'foo', 'b': 'bar', 'c': 'baz', 'd': 'qux'}
    assert check_mutually_exclusive(terms, parameters) == []

    # Test that a single list of terms is rejected
    terms = ['a', 'b']
    parameters = {'a': 'foo', 'b': 'bar', 'c': 'baz'}

# Generated at 2022-06-16 23:10:12.761233
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {'a': 'a', 'b': 'b', 'c': 'c'}
    requirements = {'a': 'b', 'b': 'c', 'c': 'd'}
    result = check_required_by(requirements, parameters)
    assert result == {'a': ['c'], 'b': ['d']}



# Generated at 2022-06-16 23:10:25.021058
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'key1': ['key2', 'key3']}
    parameters = {'key1': 'value1', 'key2': 'value2'}
    result = check_required_by(requirements, parameters)
    assert result == {'key1': ['key3']}

    parameters = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    result = check_required_by(requirements, parameters)
    assert result == {}

    requirements = {'key1': 'key2'}
    parameters = {'key1': 'value1', 'key2': 'value2'}
    result = check_required_by(requirements, parameters)
    assert result == {}

    requirements = {'key1': 'key2'}

# Generated at 2022-06-16 23:10:32.408595
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('import foo') == 'import foo'



# Generated at 2022-06-16 23:10:44.793218
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:10:57.941082
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a":1,"b":2}') == {"a": 1, "b": 2}
    assert check_type_dict('a=1, b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a=1, b=2, c=3') == {"a": "1", "b": "2", "c": "3"}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {"a": "1", "b": "2", "c": "3", "d": "4"}

# Generated at 2022-06-16 23:11:07.611722
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'a': ['b', 'c'], 'd': 'e'}
    parameters = {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd', 'e': 'e'}
    assert check_required_by(requirements, parameters) == {}
    parameters = {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}
    assert check_required_by(requirements, parameters) == {}
    parameters = {'a': 'a', 'b': 'b', 'd': 'd', 'e': 'e'}
    assert check_required_by(requirements, parameters) == {}
    parameters = {'a': 'a', 'b': 'b', 'd': 'd'}

# Generated at 2022-06-16 23:11:16.156276
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'key1': ['key2', 'key3'], 'key4': 'key5'}
    parameters = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4', 'key5': 'value5'}
    assert check_required_by(requirements, parameters) == {}
    parameters = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}
    assert check_required_by(requirements, parameters) == {'key4': ['key5']}
    parameters = {'key1': 'value1', 'key2': 'value2', 'key4': 'value4', 'key5': 'value5'}

# Generated at 2022-06-16 23:11:34.302903
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/some/path',
        'someint': 99,
        'bool_param': True,
    }
    result = check_required_if(requirements, parameters)
    assert result == [{'missing': ['string_param'], 'requires': 'all', 'parameter': 'someint', 'value': 99, 'requirements': ('bool_param', 'string_param')}]

    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]

# Generated at 2022-06-16 23:11:46.321555
# Unit test for function check_required_if
def test_check_required_if():
    assert check_required_if([['state', 'present', ('path',), True]], {'state': 'present', 'path': '/tmp'}) == []
    assert check_required_if([['state', 'present', ('path',), True]], {'state': 'present'}) == [{'missing': ['path'], 'requires': 'any', 'parameter': 'state', 'value': 'present', 'requirements': ('path',)}]
    assert check_required_if([['state', 'present', ('path',), True]], {'state': 'absent'}) == []
    assert check_required_if([['state', 'present', ('path',), True]], {'state': 'present', 'path': '/tmp', 'other': 'value'}) == []

# Generated at 2022-06-16 23:11:54.537649
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'a': 1, 'b': 2}
    required_parameters = ['a', 'b', 'c']
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == ['c']
    parameters = {'a': 1, 'b': 2, 'c': 3}
    required_parameters = ['a', 'b', 'c']
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == []



# Generated at 2022-06-16 23:12:02.637057
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1kb') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1mb') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1gb') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1tb') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1pb') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504606846976
    assert check_type_bytes

# Generated at 2022-06-16 23:12:14.153554
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/path/to/file'}
    assert check_required_if(requirements, parameters) == []

    parameters = {'state': 'present', 'path': '/path/to/file', 'bool_param': True}
    assert check_required_if(requirements, parameters) == []

    parameters = {'state': 'present', 'path': '/path/to/file', 'bool_param': True, 'someint': 99}
    assert check_required_if(requirements, parameters) == []


# Generated at 2022-06-16 23:12:19.237369
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'param1': 'value1', 'param2': 'value2'}
    required_parameters = ['param1', 'param2']
    assert check_missing_parameters(parameters, required_parameters) == []

    parameters = {'param1': 'value1'}
    required_parameters = ['param1', 'param2']
    assert check_missing_parameters(parameters, required_parameters) == ['param2']



# Generated at 2022-06-16 23:12:30.189603
# Unit test for function check_required_if
def test_check_required_if():
    # Test case 1:
    # Check if the function returns empty list if requirements is None
    assert check_required_if(None, None) == []

    # Test case 2:
    # Check if the function returns empty list if requirements is empty list
    assert check_required_if([], None) == []

    # Test case 3:
    # Check if the function returns empty list if requirements is empty tuple
    assert check_required_if((), None) == []

    # Test case 4:
    # Check if the function returns empty list if requirements is empty dict
    assert check_required_if({}, None) == []

    # Test case 5:
    # Check if the function returns empty list if requirements is empty string
    assert check_required_if('', None) == []

    # Test case 6:
    # Check if the function returns empty list if requirements is

# Generated at 2022-06-16 23:12:35.141984
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
   

# Generated at 2022-06-16 23:12:45.096125
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/foo',
        'someint': 99,
        'bool_param': True,
    }
    results = check_required_if(requirements, parameters)
    assert len(results) == 0

    parameters = {
        'state': 'present',
        'path': '/tmp/foo',
        'someint': 99,
        'bool_param': True,
        'string_param': 'foo',
    }
    results = check_required_if(requirements, parameters)
    assert len(results) == 0


# Generated at 2022-06-16 23:12:56.989747
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True
    }
    try:
        check_required_if(requirements, parameters)
    except TypeError as e:
        assert e.results == [
            {
                'parameter': 'someint',
                'value': 99,
                'requirements': ('bool_param', 'string_param'),
                'missing': ['string_param'],
                'requires': 'all',
            }
        ]
    else:
        assert False, "check_required_if should have raised TypeError"




# Generated at 2022-06-16 23:13:10.330273
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float("1") == 1.0
    assert check_type_float(b"1") == 1.0
    assert check_type_float("1.0") == 1.0
    assert check_type_float(b"1.0") == 1.0
    assert check_type_float("1.0e1") == 10.0
    assert check_type_float(b"1.0e1") == 10.0
    assert check_type_float("1.0e-1") == 0.1
    assert check_type_float(b"1.0e-1") == 0.1
    assert check_type_float("1.0e+1") == 10

# Generated at 2022-06-16 23:13:21.507034
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'key1': ['key2', 'key3'], 'key4': 'key5'}
    parameters = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4', 'key5': 'value5'}
    options_context = ['test']
    result = check_required_by(requirements, parameters, options_context)
    assert result == {}

    parameters = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}
    result = check_required_by(requirements, parameters, options_context)
    assert result == {'key4': ['key5']}


# Generated at 2022-06-16 23:13:34.223088
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:13:43.637573
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['a', 'b']], {'a': 1}) == []
    assert check_required_one_of([['a', 'b']], {'b': 1}) == []
    assert check_required_one_of([['a', 'b']], {'a': 1, 'b': 1}) == []
    assert check_required_one_of([['a', 'b']], {}) == [['a', 'b']]
    assert check_required_one_of([['a', 'b']], {'c': 1}) == [['a', 'b']]



# Generated at 2022-06-16 23:13:50.742877
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'present'}
    missing = check_required_arguments(argument_spec, parameters)
    assert len(missing) == 0

    parameters = {'optional_arg': 'present'}
    missing = check_required_arguments(argument_spec, parameters)
    assert len(missing) == 1
    assert missing[0] == 'required_arg'



# Generated at 2022-06-16 23:14:03.725381
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:14:11.850935
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'foo'}
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert str(e) == "missing required arguments: required_arg"
    else:
        assert False, "check_required_arguments did not raise TypeError"



# Generated at 2022-06-16 23:14:24.468961
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == check_type_bits('1M') / 8
    assert check_type_bits('1Mb') == check_type_bits('1Mb') / 8
    assert check_type_bits('1Mb') == check_type_bits('1Mb') / 8
    assert check_type_bits('1Mb') == check_type_bits('1Mb') / 8
    assert check_type_bits('1Mb') == check_type_bits('1Mb') / 8
    assert check_type_bits('1Mb') == check_type_bits('1Mb') / 8

# Generated at 2022-06-16 23:14:37.265124
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with a single list
    terms = ['a', 'b']
    parameters = {'a': 1, 'b': 2}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        assert "parameters are mutually exclusive: a|b" in to_native(e)

    # Test with a list of lists
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        assert "parameters are mutually exclusive: a|b, c|d" in to_native(e)

    # Test with a list of lists and a single list

# Generated at 2022-06-16 23:14:43.894260
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {
            'required': True,
            'type': 'str'
        },
        'optional_arg': {
            'required': False,
            'type': 'str'
        }
    }
    parameters = {
        'required_arg': 'foo'
    }
    assert check_required_arguments(argument_spec, parameters) == []

    parameters = {
        'optional_arg': 'foo'
    }
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']



# Generated at 2022-06-16 23:14:57.141310
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert check_type_dict('a=1, b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a=1, b=2, c=3') == {"a": "1", "b": "2", "c": "3"}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {"a": "1", "b": "2", "c": "3", "d": "4"}

# Generated at 2022-06-16 23:15:04.056644
# Unit test for function check_required_together
def test_check_required_together():
    terms = [
        ('a', 'b'),
        ('c', 'd')
    ]
    parameters = {
        'a': 1,
        'b': 2,
        'c': 3
    }
    options_context = ['a', 'b']
    results = check_required_together(terms, parameters, options_context)
    assert results == [('c', 'd')]



# Generated at 2022-06-16 23:15:14.111205
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float("1") == 1.0
    assert check_type_float(b"1") == 1.0
    assert check_type_float(u"1") == 1.0
    assert check_type_float(u"1.0") == 1.0
    assert check_type_float(u"1.1") == 1.1
    assert check_type_float(u"1.1.1") == 1.1
    assert check_type_float(u"1.1.1.1") == 1.1
    assert check_type_float(u"1.1.1.1.1") == 1.1

# Generated at 2022-06-16 23:15:25.863087
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1m') == 8388608
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1Mi') == 8388608
    assert check_type_bits('1mib') == 1048576
    assert check_type_bits('1mi') == 8388608
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('1G') == 8589934592
    assert check_type_bits('1gb') == 1073741824
    assert check_type_bits('1g') == 85899345

# Generated at 2022-06-16 23:15:35.943079
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    options_context = None
    assert check_required_together(terms, parameters, options_context) == []
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_together(terms, parameters, options_context) == [['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'd': 4}
    assert check_required_together(terms, parameters, options_context) == [['c', 'd']]
    parameters = {'a': 1, 'c': 3, 'd': 4}

# Generated at 2022-06-16 23:15:47.133140
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive(['a', 'b'], {'a': 1}) == []
    assert check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2}) == [['a', 'b']]
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 1, 'c': 2}) == []
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3}) == [['a', 'b'], ['c', 'd']]



# Generated at 2022-06-16 23:15:59.587018
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    """Unit test for function check_mutually_exclusive"""
    # Test with a single list
    terms = ['a', 'b']
    parameters = {'a': 'a', 'b': 'b'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pass
    else:
        raise AssertionError('check_mutually_exclusive did not raise TypeError')

    # Test with a list of lists
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 'a', 'b': 'b'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pass
    else:
        raise AssertionError('check_mutually_exclusive did not raise TypeError')

    # Test

# Generated at 2022-06-16 23:16:07.075541
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1e1') == 11.0
    assert check_type_float('1.1e1') == 11.0
    assert check_type_float(b'1.1e-1') == 0.11
   

# Generated at 2022-06-16 23:16:18.067074
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {'a': 'a', 'b': 'b', 'c': 'c'}
    terms = [['a', 'b'], ['a', 'c']]
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 'a', 'b': 'b', 'c': 'c'}
    terms = [['a', 'b'], ['a', 'd']]
    assert check_required_together(terms, parameters) == [['a', 'd']]
    parameters = {'a': 'a', 'b': 'b', 'c': 'c'}
    terms = [['a', 'b'], ['a', 'd'], ['e', 'f']]

# Generated at 2022-06-16 23:16:22.436322
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:16:37.529127
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1') == 8
    assert check_type_bits('1b') == 1
    assert check_type_bits(1) == 8
    assert check_type_bits(1.0) == 8
    assert check_type_bits(1.1) == 8
    assert check_type_bits(1.5) == 8
    assert check_type_bits(1.9) == 8
    assert check_type_bits(2) == 16
    assert check_type_bits(2.0) == 16
    assert check_type_bits(2.1) == 16
    assert check_type_bits(2.5) == 16

# Generated at 2022-06-16 23:16:47.091906
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1M') == 1048576

# Generated at 2022-06-16 23:16:58.377422
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1mbit') == 1048576
    assert check_type_bits('1mbits') == 1048576
    assert check_type_bits('1mbit') == 1048576
    assert check_type_bits('1mbits') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1Mbits') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1Mbits') == 1048576
    assert check_type_bits('1Mb') == 10

# Generated at 2022-06-16 23:17:10.952071
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
    }
    options_context = ['test_check_required_if']
    results = check_required_if(requirements, parameters, options_context)
    assert len(results) == 0
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
    }

# Generated at 2022-06-16 23:17:22.909018
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int('1.1') == 1
    assert check_type_int('1.9') == 1

# Generated at 2022-06-16 23:17:31.955480
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1)

# Generated at 2022-06-16 23:17:43.176009
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736
    assert check_type_bytes('1.5T') == 1649267441664
    assert check_type

# Generated at 2022-06-16 23:17:49.787624
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_

# Generated at 2022-06-16 23:18:00.596255
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('[1, 2, 3]', include_exceptions=True) == ([1, 2, 3], None)
    assert safe_eval('[1, 2, 3]', include_exceptions=True)[0]

# Generated at 2022-06-16 23:18:08.998833
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1MB') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1m') == 1048576
    assert check_type_bits('1') == 1
    assert check_type_bits('1b') == 1
    assert check_type_bits('1B') == 1
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1KB') == 1024
    assert check_type_bits('1K') == 1024
    assert check_type_bits('1k') == 1024
    assert check_type_

# Generated at 2022-06-16 23:18:23.106574
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1MB') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1m') == 1048576
    assert check_type_bits('1') == 1
    assert check_type_bits('1b') == 1
    assert check_type_bits('1B') == 1
    assert check_type_bits('1kb') == 1024
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1KB') == 1024
    assert check_type_bits('1K') == 1024
    assert check_type_bits('1k') == 1024
    assert check_type_

# Generated at 2022-06-16 23:18:33.177412
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Ki') == 1024
    assert check_type_bytes('1Mi') == 1048576
    assert check_type_bytes('1Gi') == 1073741824
    assert check_type_bytes('1Ti') == 1099511627776
    assert check_type_bytes('1Pi') == 11258

# Generated at 2022-06-16 23:18:44.723370
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('1+1') == 2
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a":1}') == {"a": 1}
    assert safe_eval('1.1+1') == 2.1
    assert safe_eval('1.1+1.1') == 2.2
    assert safe_eval('[1,2,3]+[1,2,3]') == [1, 2, 3, 1, 2, 3]
    assert safe_eval('{"a":1}+{"b":2}') == {"a": 1, "b": 2}

# Generated at 2022-06-16 23:18:54.122193
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'foo'}
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert e.args[0] == "missing required arguments: required_arg"
    else:
        assert False, "check_required_arguments did not raise TypeError"



# Generated at 2022-06-16 23:19:01.912959
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)

# Generated at 2022-06-16 23:19:14.275728
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1m') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1Mbits') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mbits') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048