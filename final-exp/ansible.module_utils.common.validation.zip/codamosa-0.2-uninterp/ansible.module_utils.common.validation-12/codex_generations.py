

# Generated at 2022-06-16 23:09:51.716826
# Unit test for function check_required_arguments

# Generated at 2022-06-16 23:10:03.974983
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with a single list of terms
    terms = ['a', 'b']
    parameters = {'a': 'foo', 'b': 'bar'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        assert e.args[0] == "parameters are mutually exclusive: a|b"

    # Test with a list of lists of terms
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 'foo', 'b': 'bar', 'c': 'baz', 'd': 'qux'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        assert e.args[0] == "parameters are mutually exclusive: a|b, c|d"

    # Test

# Generated at 2022-06-16 23:10:15.715906
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by(None, {}) == {}
    assert check_required_by({}, {}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'b'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'b', 'b': 'c'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'b', 'b': None}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'b', 'b': None, 'c': None}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'b', 'b': None, 'c': 'd'}) == {}

# Generated at 2022-06-16 23:10:28.035315
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("'1'") == '1'
    assert safe_eval("'1.0'") == '1.0'
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("(1, 2, 3)") == (1, 2, 3)
    assert safe_eval("1.0.bit_length()") == "1.0.bit_length()"

# Generated at 2022-06-16 23:10:35.694530
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/tmp/foo'}
    result = check_required_if(requirements, parameters)
    assert result == []
    parameters = {'state': 'present', 'path': '/tmp/foo', 'someint': 99}
    result = check_required_if(requirements, parameters)
    assert result == []
    parameters = {'state': 'present', 'path': '/tmp/foo', 'someint': 99, 'bool_param': True}
    result = check_required_if(requirements, parameters)
    assert result == []

# Generated at 2022-06-16 23:10:46.946169
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:10:59.750451
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('"1"') == "1"
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1,2,3]', include_exceptions=True) == ([1, 2, 3], None)
    assert safe_eval('{"a": 1, "b": 2}', include_exceptions=True) == ({'a': 1, 'b': 2}, None)
   

# Generated at 2022-06-16 23:11:11.208818
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1+1') == 2
    assert safe_eval('1+1', include_exceptions=True) == (2, None)
    assert safe_eval('1+1', include_exceptions=True)[0] == 2
    assert safe_eval('1+1', include_exceptions=True)[1] is None
    assert safe_eval('1+1', include_exceptions=True)[1] is None
    assert safe_eval('1+1', include_exceptions=True)[1] is None
    assert safe_eval('1+1', include_exceptions=True)[1] is None
    assert safe_eval('1+1', include_exceptions=True)[1] is None
    assert safe_eval('1+1', include_exceptions=True)[1]

# Generated at 2022-06-16 23:11:20.195854
# Unit test for function check_required_if
def test_check_required_if():
    """Unit test for function check_required_if"""
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/tmp/test'}
    options_context = None
    results = check_required_if(requirements, parameters, options_context)
    assert results == []

    parameters = {'state': 'present', 'path': '/tmp/test', 'someint': 99}
    results = check_required_if(requirements, parameters, options_context)
    assert results == []

    parameters = {'state': 'present', 'path': '/tmp/test', 'someint': 99, 'bool_param': True}

# Generated at 2022-06-16 23:11:31.926385
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1+1') == 2
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a":1,"b":2}') == {"a": 1, "b": 2}
    assert safe_eval('1+1', include_exceptions=True) == (2, None)
    assert safe_eval('1+1', include_exceptions=True)[0] == 2
    assert safe_eval('1+1', include_exceptions=True)[1] is None
    assert safe_eval('[1,2,3]', include_exceptions=True) == ([1, 2, 3], None)

# Generated at 2022-06-16 23:11:47.986418
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:11:52.019285
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1B') == 1
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_

# Generated at 2022-06-16 23:11:59.556796
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'foo'}
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert str(e) == "missing required arguments: required_arg"
    else:
        assert False, "check_required_arguments should have raised TypeError"



# Generated at 2022-06-16 23:12:08.360893
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {
            'required': True,
            'type': 'str'
        },
        'optional_arg': {
            'required': False,
            'type': 'str'
        }
    }
    parameters = {
        'required_arg': 'foo'
    }
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {
        'optional_arg': 'foo'
    }
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']



# Generated at 2022-06-16 23:12:12.369484
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'key1': ['key2', 'key3']}
    parameters = {'key1': 'value1', 'key2': 'value2'}
    result = check_required_by(requirements, parameters)
    assert result == {'key1': ['key3']}



# Generated at 2022-06-16 23:12:17.660955
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_one': {'required': True},
        'required_two': {'required': True},
        'not_required': {'required': False}
    }
    parameters = {
        'required_one': 'present',
        'not_required': 'present'
    }
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == ['required_two']



# Generated at 2022-06-16 23:12:25.332437
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736

# Generated at 2022-06-16 23:12:37.535274
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive([['a', 'b']], {'a': 'foo', 'b': 'bar'}) == []
    assert check_mutually_exclusive([['a', 'b']], {'a': 'foo'}) == []
    assert check_mutually_exclusive([['a', 'b']], {'b': 'bar'}) == []
    assert check_mutually_exclusive([['a', 'b']], {'c': 'baz'}) == []
    assert check_mutually_exclusive([['a', 'b']], {'a': 'foo', 'b': 'bar'}, options_context=['foo']) == []
    assert check_mutually_exclusive([['a', 'b']], {'a': 'foo'}, options_context=['foo']) == []
    assert check_mutually_exclusive

# Generated at 2022-06-16 23:12:45.055045
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by({'key1': ['required1', 'required2']}, {'key1': 'value1', 'required1': 'value2'}) == {}
    assert check_required_by({'key1': ['required1', 'required2']}, {'key1': 'value1'}) == {'key1': ['required2']}
    assert check_required_by({'key1': ['required1', 'required2']}, {'required1': 'value2'}) == {'key1': ['required1']}
    assert check_required_by({'key1': ['required1', 'required2']}, {'key1': 'value1', 'required1': 'value2', 'key2': 'value3'}) == {}

# Generated at 2022-06-16 23:12:51.504985
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float('1.1.1') == 1.1
    assert check_type_float(b'1.1.1') == 1.1
    assert check_type_float('1.1.1') == 1.1
    assert check_type_

# Generated at 2022-06-16 23:13:08.933889
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == "foo"
    assert safe_eval("'foo'") == "foo"
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {"foo": "bar"}
    assert safe_eval('{"foo": "bar", "baz": "qux"}') == {"foo": "bar", "baz": "qux"}
    assert safe_eval('{"foo": "bar", "baz": "qux", "quux": "corge"}')

# Generated at 2022-06-16 23:13:15.781464
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'd': 4}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': 1, 'c': 3, 'd': 4}
    assert check_required_together(terms, parameters) == [['a', 'b']]
    parameters = {'a': 1, 'c': 3}

# Generated at 2022-06-16 23:13:25.356185
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('foo.bar()', include_exceptions=True) == ('foo.bar()', None)

# Generated at 2022-06-16 23:13:36.404823
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None

# Generated at 2022-06-16 23:13:48.129844
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": "b"}') == {'a': 'b'}
    assert check_type_dict('a=b, c=d') == {'a': 'b', 'c': 'd'}
    assert check_type_dict('a=b, c=d, e=f') == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert check_type_dict('a=b, c=d, e=f, g=h') == {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}

# Generated at 2022-06-16 23:13:59.592604
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('"1"') == '1'
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2, "c": 3}') == {"a": 1, "b": 2, "c": 3}
    assert safe_eval('{"a": [1, 2, 3], "b": [4, 5, 6]}') == {"a": [1, 2, 3], "b": [4, 5, 6]}

# Generated at 2022-06-16 23:14:11.629005
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1m') == 8388608
    assert check_type_bits('1mbit') == 1048576
    assert check_type_bits('1mbits') == 1048576
    assert check_type_bits('1mbit') == 1048576
    assert check_type_bits('1mbits') == 1048576
    assert check_type_bits('1mib') == 1048576
    assert check_type_bits('1mibit') == 1048576
    assert check_type_bits('1mibits') == 1048576

# Generated at 2022-06-16 23:14:24.313235
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float('1.1e1') == 11.0
    assert check_type_float(b'1.1e1') == 11.0
    assert check_type_float('1.1e+1') == 11.0
    assert check_type

# Generated at 2022-06-16 23:14:37.095664
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)

# Generated at 2022-06-16 23:14:45.737530
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
   

# Generated at 2022-06-16 23:14:58.135054
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('-1') == -1
    assert safe_eval('-1.1') == -1.1
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval("'foo'") == 'foo'
    assert safe_eval("['foo', 'bar']") == ['foo', 'bar']
    assert safe_eval("('foo', 'bar')") == ('foo', 'bar')
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}

# Generated at 2022-06-16 23:15:11.035074
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb')

# Generated at 2022-06-16 23:15:24.474144
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1Mi') == 8388608
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1K') == 8192
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1Ki') == 8192
    assert check_type_bits('1Kib') == 1024
    assert check_type_bits('1b') == 1

# Generated at 2022-06-16 23:15:34.501437
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb')

# Generated at 2022-06-16 23:15:47.703162
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1024') == 1024
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736
    assert check_type_bytes('1.5T')

# Generated at 2022-06-16 23:16:00.255075
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504606846976

# Generated at 2022-06-16 23:16:04.681782
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a":1, "b":2}') == {'a': 1, 'b': 2}
    assert check_type_dict('a=1, b=2') == {'a': '1', 'b': '2'}
    assert check_type_dict('a=1, b=2, c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {'a': '1', 'b': '2', 'c': '3', 'd': '4'}

# Generated at 2022-06-16 23:16:16.193610
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert safe_eval('{"a": 1, "b": 2}', include_exceptions=True) == ({'a': 1, 'b': 2}, None)
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('[1, 2, 3]', include_exceptions=True) == ([1, 2, 3], None)

# Generated at 2022-06-16 23:16:20.235669
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:16:29.337142
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None

# Generated at 2022-06-16 23:16:43.480363
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1Mibit') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb')

# Generated at 2022-06-16 23:16:50.850328
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0


# Generated at 2022-06-16 23:17:00.545388
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(1.1)

# Generated at 2022-06-16 23:17:12.996390
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/some/path',
        'someint': 99,
        'bool_param': True,
    }
    options_context = ['some', 'context']
    try:
        check_required_if(requirements, parameters, options_context)
    except TypeError as e:
        assert e.results == [
            {
                'parameter': 'someint',
                'value': 99,
                'requirements': ('bool_param', 'string_param'),
                'missing': ['string_param'],
                'requires': 'all',
            }
        ]
        assert to_native

# Generated at 2022-06-16 23:17:23.057692
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {'key1': 'value1', 'key2': 'value2'}
    requirements = {'key1': ['key2']}
    result = check_required_by(requirements, parameters)
    assert result == {}

    parameters = {'key1': 'value1'}
    requirements = {'key1': ['key2']}
    try:
        check_required_by(requirements, parameters)
    except TypeError as e:
        assert "missing parameter(s) required by 'key1': key2" in str(e)
    else:
        assert False



# Generated at 2022-06-16 23:17:32.019367
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('import os') == 'import os'
    assert safe_eval('import os', include_exceptions=True) == ('import os', None)
    assert safe_eval('import os', include_exceptions=True)[0] == 'import os'
    assert safe_eval('import os', include_exceptions=True)[1] is None
    assert safe_eval('os.getcwd()') == 'os.getcwd()'

# Generated at 2022-06-16 23:17:43.176040
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(u'1.0') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(u'1') == 1.0
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(u'1.1') == 1.1
    assert check_type_float(b'1.1.1') == 1.1
    assert check_type_float(u'1.1.1') == 1.

# Generated at 2022-06-16 23:17:55.085515
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1.5k') == 1536
    assert check_type_bytes('1.5M') == 1572864


# Generated at 2022-06-16 23:18:05.676299
# Unit test for function check_required_one_of
def test_check_required_one_of():
    # Test with a list of lists
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'c': 1, 'd': 2}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 1, 'd': 2}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 1}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'd': 2}
    assert check_required_one_

# Generated at 2022-06-16 23:18:17.826598
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('"1"') == "1"
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1,2,3]') == [1,2,3]
    assert safe_eval('{"a":1}') == {"a":1}
    assert safe_eval('{"a":1}', include_exceptions=True) == ({"a":1}, None)
    assert safe_eval('1.1.1') == '1.1.1'
    assert safe_eval('1.1.1', include_exceptions=True) == ('1.1.1', None)
    assert safe

# Generated at 2022-06-16 23:18:31.545850
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1024 * 1024
    assert check_type_bytes('1G') == 1024 * 1024 * 1024
    assert check_type_bytes('1T') == 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1P') == 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1E') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1Ki') == 1024
    assert check_type_bytes('1Mi') == 1024 * 1024
    assert check_type_bytes('1Gi') == 1024 * 1024 * 1024
    assert check_type_bytes('1Ti') == 1024 * 1024 * 1024 * 1024
    assert check

# Generated at 2022-06-16 23:18:42.401568
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('1.1.1') == '1.1.1'
    assert safe_eval('1 + 1') == '1 + 1'
    assert safe_eval('import os') == 'import os'
    assert safe_eval('os.path') == 'os.path'
    assert safe

# Generated at 2022-06-16 23:18:48.200220
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:18:58.238944
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1b') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1kb') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1mb') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1gb') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1tb') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1pb') == 1125899906842624
   

# Generated at 2022-06-16 23:19:10.752487
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504