

# Generated at 2022-06-16 23:09:49.914150
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1m') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048

# Generated at 2022-06-16 23:09:59.200258
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False}
    }
    parameters = {'required_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == []

    parameters = {'optional_arg': 'foo'}
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert "missing required arguments: required_arg" in to_native(e)
    else:
        assert False, "check_required_arguments did not raise TypeError"



# Generated at 2022-06-16 23:10:06.290142
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {'required_arg': {'required': True, 'type': 'str'},
                     'optional_arg': {'required': False, 'type': 'str'}}
    parameters = {'required_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']



# Generated at 2022-06-16 23:10:17.196051
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 10

# Generated at 2022-06-16 23:10:28.851885
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:10:33.100245
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'param1': 'value1', 'param2': 'value2'}
    required_parameters = ['param1', 'param2', 'param3']
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == ['param3']



# Generated at 2022-06-16 23:10:41.708159
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'param1': 'value1', 'param2': 'value2'}
    required_parameters = ['param1', 'param2']
    assert check_missing_parameters(parameters, required_parameters) == []

    parameters = {'param1': 'value1', 'param2': 'value2'}
    required_parameters = ['param1', 'param2', 'param3']
    assert check_missing_parameters(parameters, required_parameters) == ['param3']



# Generated at 2022-06-16 23:10:50.081061
# Unit test for function check_required_by
def test_check_required_by():
    parameters = {'a': '1', 'b': '2', 'c': '3'}
    requirements = {'a': ['b', 'c']}
    result = check_required_by(requirements, parameters)
    assert result == {}

    parameters = {'a': '1', 'b': '2'}
    requirements = {'a': ['b', 'c']}
    result = check_required_by(requirements, parameters)
    assert result == {'a': ['c']}

    parameters = {'a': '1', 'b': '2'}
    requirements = {'a': 'b'}
    result = check_required_by(requirements, parameters)
    assert result == {}

    parameters = {'a': '1'}
    requirements = {'a': 'b'}

# Generated at 2022-06-16 23:10:56.198617
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'param1': 'value1', 'param2': 'value2'}
    required_parameters = ['param1', 'param2', 'param3']
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == ['param3']



# Generated at 2022-06-16 23:11:05.938429
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:11:20.354035
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float('1') == 1.0

# Generated at 2022-06-16 23:11:32.053757
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1.0 + 1.0') == 2.0
    assert safe_eval('1 + 1.0') == 2.0
    assert safe_eval('1.0 + 1') == 2.0
    assert safe_eval('True and False') is False

# Generated at 2022-06-16 23:11:44.445041
# Unit test for function check_required_by
def test_check_required_by():
    # Test 1: Check that a required parameter is missing
    parameters = {'param1': 'value1', 'param2': 'value2'}
    requirements = {'param1': ['param3']}
    options_context = ['options']
    try:
        check_required_by(requirements, parameters, options_context)
    except TypeError as e:
        assert 'missing parameter(s) required by \'param1\': param3' in to_native(e)
    else:
        assert False, 'check_required_by did not raise TypeError'

    # Test 2: Check that a required parameter is present
    parameters = {'param1': 'value1', 'param2': 'value2', 'param3': 'value3'}
    requirements = {'param1': ['param3']}
    options_context = ['options']

# Generated at 2022-06-16 23:11:56.600343
# Unit test for function check_required_one_of

# Generated at 2022-06-16 23:12:04.241706
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    from ansible.module_utils.common.validation import check_mutually_exclusive
    from ansible.module_utils.common.validation import count_terms
    from ansible.module_utils.common.validation import check_required_one_of
    from ansible.module_utils.common.validation import check_required_together
    from ansible.module_utils.common.validation import check_required_arguments

    # Test check_mutually_exclusive
    # Test with a single list
    terms = ['a', 'b']
    parameters = {'a': '1', 'b': '2'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pass
    else:
        assert False, "check_mutually_exclusive() did not raise TypeError"

    #

# Generated at 2022-06-16 23:12:15.665809
# Unit test for function check_required_if
def test_check_required_if():
    # Test case 1:
    #   requirements = [
    #       ['state', 'present', ('path',), True],
    #       ['someint', 99, ('bool_param', 'string_param')],
    #   ]
    #   parameters = {
    #       'state': 'present',
    #       'path': '/some/path',
    #       'someint': 99,
    #       'bool_param': True,
    #   }
    #   expected_results = []
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]

# Generated at 2022-06-16 23:12:29.216261
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('1.0') != 1
    assert safe_eval('1') != 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2, "c": 3}') == {"a": 1, "b": 2, "c": 3}
    assert safe_eval('{"a": 1, "b": 2, "c": 3}') != [1, 2, 3]

# Generated at 2022-06-16 23:12:40.494311
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 1, 'c': 2}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 1, 'd': 2}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'b': 1, 'c': 2}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'b': 1, 'd': 2}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2}) == []
    assert check_required_one_of

# Generated at 2022-06-16 23:12:53.565452
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive([['a', 'b']], {'a': 1, 'b': 2}) == [['a', 'b']]
    assert check_mutually_exclusive([['a', 'b']], {'a': 1}) == []
    assert check_mutually_exclusive([['a', 'b']], {'a': 1, 'b': 2, 'c': 3}) == [['a', 'b']]
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3, 'd': 4}) == [['a', 'b'], ['c', 'd']]

# Generated at 2022-06-16 23:13:02.635954
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': '1', 'b': '2'}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'c': '1', 'd': '2'}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': '1', 'b': '2', 'c': '1', 'd': '2'}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': '1', 'b': '2', 'c': '1'}
    assert check_required_one_of(terms, parameters) == []

# Generated at 2022-06-16 23:13:18.376440
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert check_type_dict("a=1, b=2") == {'a': '1', 'b': '2'}
    assert check_type_dict("a=1, b=2, c=3") == {'a': '1', 'b': '2', 'c': '3'}
    assert check_type_dict("a=1, b=2, c=3, d=4") == {'a': '1', 'b': '2', 'c': '3', 'd': '4'}

# Generated at 2022-06-16 23:13:26.246873
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': 1, 'c': 3}
    assert check_required_together(terms, parameters) == [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'd': 4}
    assert check_required_together(terms, parameters) == [['c', 'd']]

# Generated at 2022-06-16 23:13:33.013511
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1Mbits') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1Mbits') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1mb') == 1048576
    assert check_type_bits('1Mbit') == 1048576
    assert check_type_bits('1Mbits') == 1048576

# Generated at 2022-06-16 23:13:44.440503
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1+1') == 2
    assert safe_eval('1+1', include_exceptions=True) == (2, None)
    assert safe_eval('1+1', include_exceptions=True)[0] == 2
    assert safe_eval('1+1', include_exceptions=True)[1] is None
    assert safe_eval('1+1', include_exceptions=True) == (2, None)
    assert safe_eval('1+1', include_exceptions=True)[0] == 2
    assert safe_eval('1+1', include_exceptions=True)[1] is None
    assert safe_eval('1+1', include_exceptions=True) == (2, None)

# Generated at 2022-06-16 23:13:56.103518
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/foo',
        'someint': 99,
        'bool_param': True,
    }
    results = check_required_if(requirements, parameters)
    assert len(results) == 0

    parameters = {
        'state': 'present',
        'path': '/tmp/foo',
        'someint': 99,
        'bool_param': True,
        'string_param': 'foo',
    }
    results = check_required_if(requirements, parameters)
    assert len(results) == 0


# Generated at 2022-06-16 23:14:08.355539
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('{"foo": "bar", "baz": "qux"}') == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-16 23:14:16.391263
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
   

# Generated at 2022-06-16 23:14:21.241910
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float("1") == 1.0
    assert check_type_float(b"1") == 1.0
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float("1.1") == 1.1
    assert check_type_float(b"1.1") == 1.1
    assert check_type_float("1.1e1") == 11.0
    assert check_type_float(b"1.1e1") == 11.0
    assert check_type_float("1.1e-1") == 0.11
    assert check_type

# Generated at 2022-06-16 23:14:33.639676
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('1Tb') == 1099511627776
    assert check_type_bits('1Pb') == 1125899906842624
    assert check_type_bits('1Eb') == 1152921504606846976
    assert check_type_bits('1Zb') == 1180591620717411303424
    assert check_type_bits('1Yb') == 1208925819614629174706176
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1b') == 1
    assert check_type_bits('1') == 1
    assert check_type_bits('1.0') == 1

# Generated at 2022-06-16 23:14:43.473179
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp',
        'someint': 99,
        'bool_param': True,
    }
    results = check_required_if(requirements, parameters)
    assert len(results) == 1
    assert results[0]['parameter'] == 'someint'
    assert results[0]['value'] == 99
    assert results[0]['requirements'] == ('bool_param', 'string_param')
    assert results[0]['missing'] == ['string_param']
    assert results[0]['requires'] == 'all'



# Generated at 2022-06-16 23:14:57.100744
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1.5k') == 1536
    assert check_type_bytes('1.5M') == 1572864


# Generated at 2022-06-16 23:15:03.298982
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('(1, 2, 3)') == (1, 2, 3)
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('"foo" + "bar"') == "foobar"
    assert safe_eval('"foo" + "bar"', include_exceptions=True) == ("foobar", None)
   

# Generated at 2022-06-16 23:15:13.363921
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/some/path',
        'someint': 99,
        'bool_param': True,
    }
    results = check_required_if(requirements, parameters)
    assert len(results) == 1
    assert results[0]['parameter'] == 'someint'
    assert results[0]['value'] == 99
    assert results[0]['requirements'] == ('bool_param', 'string_param')
    assert results[0]['missing'] == ['string_param']
    assert results[0]['requires'] == 'all'



# Generated at 2022-06-16 23:15:21.829730
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:15:27.749353
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with a single list
    terms = ['a', 'b']
    parameters = {'a': 1, 'b': 2}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pass
    else:
        raise AssertionError('check_mutually_exclusive() did not raise TypeError')

    # Test with a list of lists
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pass
    else:
        raise AssertionError('check_mutually_exclusive() did not raise TypeError')

    # Test with a list of lists and options_

# Generated at 2022-06-16 23:15:32.190599
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': 1, 'b': 2}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': 1}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'b': 2}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'c': 3}
    assert check_required

# Generated at 2022-06-16 23:15:42.835424
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a":1,"b":2}') == {"a":1,"b":2}
    assert check_type_dict('a=1,b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a=1,b=2,c=3') == {"a": "1", "b": "2", "c": "3"}
    assert check_type_dict('a=1,b=2,c=3,d=4') == {"a": "1", "b": "2", "c": "3", "d": "4"}

# Generated at 2022-06-16 23:15:55.699772
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int("1") == 1
    assert check_type_int("1.1") == 1
    assert check_type_int("1.9") == 1
    assert check_type_int("-1") == -1
    assert check_type_int("-1.1") == -1
    assert check_type_int("-1.9") == -1
    assert check_type_int("1.1") == 1
    assert check_type_int("1.9") == 1
    assert check_type_int("-1.1") == -1
    assert check_type_int("-1.9") == -1
    assert check_type_int("1.1") == 1
    assert check_type_int("1.9") == 1


# Generated at 2022-06-16 23:16:05.478005
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1+1') == 2
    assert safe_eval('1+1', include_exceptions=True) == (2, None)
    assert safe_eval('1+1', include_exceptions=True)[0] == 2
    assert safe_eval('1+1', include_exceptions=True)[1] is None
    assert safe_eval('1+1', include_exceptions=True)[0] == 2
    assert safe_eval('1+1', include_exceptions=True)[1] is None
    assert safe_eval('1+1', include_exceptions=True) == (2, None)
    assert safe_eval('1+1', include_exceptions=True)[0] == 2

# Generated at 2022-06-16 23:16:16.909876
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504

# Generated at 2022-06-16 23:16:27.280895
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'foo'}
    try:
        check_required_arguments(argument_spec, parameters)
        assert False, 'check_required_arguments did not raise TypeError'
    except TypeError:
        pass



# Generated at 2022-06-16 23:16:40.223209
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'd': 4}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    assert check_required_together(terms, parameters) == []

# Generated at 2022-06-16 23:16:48.916334
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504606846976
    assert check_type_bytes('1z') == 1180591620717411303424
    assert check_type_bytes('1y') == 1208925819614629174706176
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type

# Generated at 2022-06-16 23:16:59.326211
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int('2.1') == 2
    assert check_type_int(2.1)

# Generated at 2022-06-16 23:17:11.752829
# Unit test for function check_required_by
def test_check_required_by():
    # Test with a single string
    requirements = {'key1': 'key2'}
    parameters = {'key1': 'value1', 'key2': 'value2'}
    result = check_required_by(requirements, parameters)
    assert result == {}

    # Test with a list
    requirements = {'key1': ['key2', 'key3']}
    parameters = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    result = check_required_by(requirements, parameters)
    assert result == {}

    # Test with a list and a missing value
    requirements = {'key1': ['key2', 'key3']}
    parameters = {'key1': 'value1', 'key2': 'value2'}
    result = check_required_

# Generated at 2022-06-16 23:17:24.618888
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:17:30.759275
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert check_type_dict('a=1, b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a=1, b=2, c=3') == {"a": "1", "b": "2", "c": "3"}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {"a": "1", "b": "2", "c": "3", "d": "4"}

# Generated at 2022-06-16 23:17:42.465463
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3, 'd': 4}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 1}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 1, 'c': 3}) == []

# Generated at 2022-06-16 23:17:54.699758
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('foo.bar()', include_exceptions=True) == ('foo.bar()', None)
    assert safe

# Generated at 2022-06-16 23:18:05.324899
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': 1, 'b': 2}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'c': 3, 'd': 4}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'd': 4}
    assert check_required_one_of(terms, parameters) == []


# Generated at 2022-06-16 23:18:20.799450
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1b') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1kb') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1mb') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1gb') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1tb') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1pb') == 1125899906842624
   

# Generated at 2022-06-16 23:18:31.348697
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("'1'") == '1'
    assert safe_eval("'1.0'") == '1.0'
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("1.0.__add__(2.0)") == "1.0.__add__(2.0)"
    assert safe_eval("import os") == "import os"
    assert safe

# Generated at 2022-06-16 23:18:42.405866
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a":1, "b":2}') == {"a":1, "b":2}
    assert check_type_dict('a=1, b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a=1, b=2, c=3') == {"a": "1", "b": "2", "c": "3"}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {"a": "1", "b": "2", "c": "3", "d": "4"}

# Generated at 2022-06-16 23:18:54.338742
# Unit test for function check_required_one_of
def test_check_required_one_of():
    assert check_required_one_of([['a', 'b']], {'a': 'test'}) == []
    assert check_required_one_of([['a', 'b']], {'b': 'test'}) == []
    assert check_required_one_of([['a', 'b']], {'c': 'test'}) == [['a', 'b']]
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 'test', 'c': 'test'}) == []
    assert check_required_one_of([['a', 'b'], ['c', 'd']], {'a': 'test', 'd': 'test'}) == []

# Generated at 2022-06-16 23:19:00.917397
# Unit test for function check_required_together
def test_check_required_together():
    parameters = {'a': 'a', 'b': 'b'}
    terms = [['a', 'b']]
    options_context = None
    assert check_required_together(terms, parameters, options_context) == []

    parameters = {'a': 'a'}
    terms = [['a', 'b']]
    options_context = None
    assert check_required_together(terms, parameters, options_context) == [['a', 'b']]



# Generated at 2022-06-16 23:19:12.620064
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('1.1.1') == '1.1.1'
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('import foo') == 'import foo'

