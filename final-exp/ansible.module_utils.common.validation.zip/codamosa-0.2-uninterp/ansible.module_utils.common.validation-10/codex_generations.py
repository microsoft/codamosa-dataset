

# Generated at 2022-06-16 23:10:01.195277
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864


# Generated at 2022-06-16 23:10:11.160283
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}) == []
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 'a', 'b': 'b', 'c': 'c'}) == []
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 'a', 'b': 'b'}) == []
    assert check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 'a'}) == []

# Generated at 2022-06-16 23:10:15.198402
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1m') == 1024 * 1024
    assert check_type_bytes('1g') == 1024 * 1024 * 1024
    assert check_type_bytes('1t') == 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1p') == 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1e') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1z') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1y') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1kb') == 1024
    assert check_

# Generated at 2022-06-16 23:10:27.299828
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('foo.bar()') == 'foo.bar()'

# Generated at 2022-06-16 23:10:33.109002
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'not_required_arg': {'required': False},
    }
    parameters = {'required_arg': 'present'}
    assert check_required_arguments(argument_spec, parameters) == []

    parameters = {'not_required_arg': 'present'}
    try:
        check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert 'missing required arguments: required_arg' in to_native(e)



# Generated at 2022-06-16 23:10:45.633320
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int('1.0') == 1
    assert check_type_int('-1') == -1
    assert check_type_int('-1.0') == -1
    assert check_type_int('-1.1') == -1
    assert check_type_int('-1.9') == -1
    assert check_type_int('-1.99') == -1
    assert check_type_int('-1.999') == -1
    assert check_type_int('-1.9999')

# Generated at 2022-06-16 23:10:58.938105
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert check_type_dict("a=1, b=2") == {'a': '1', 'b': '2'}
    assert check_type_dict("a=1, b=2, c=3") == {'a': '1', 'b': '2', 'c': '3'}
    assert check_type_dict("a=1, b=2, c=3, d=4") == {'a': '1', 'b': '2', 'c': '3', 'd': '4'}

# Generated at 2022-06-16 23:11:08.603070
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int('1.1') == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int(1.9) == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('0x1') == 1
    assert check_type_int('0x1.1') == 1
    assert check_type_int('0x1.9') == 1
    assert check_type_int('0x1.1p1') == 1


# Generated at 2022-06-16 23:11:16.014852
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Test with no argument_spec
    assert check_required_arguments(None, {}) == []

    # Test with no required parameters
    assert check_required_arguments({'a': {'required': False}}, {}) == []

    # Test with required parameter missing
    assert check_required_arguments({'a': {'required': True}}, {}) == ['a']

    # Test with required parameter present
    assert check_required_arguments({'a': {'required': True}}, {'a': 'b'}) == []

    # Test with required parameter present, but set to None
    assert check_required_arguments({'a': {'required': True}}, {'a': None}) == ['a']



# Generated at 2022-06-16 23:11:20.391569
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504606846976

# Generated at 2022-06-16 23:11:37.370891
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int("1") == 1
    assert check_type_int(1.0) == 1
    assert check_type_int("1.0") == 1
    assert check_type_int("1.1") == 1
    assert check_type_int("1.9") == 1
    assert check_type_int("-1") == -1
    assert check_type_int("-1.0") == -1
    assert check_type_int("-1.1") == -1
    assert check_type_int("-1.9") == -1
    assert check_type_int("0") == 0
    assert check_type_int("0.0") == 0
    assert check_type_int("0.1") == 0
    assert check_

# Generated at 2022-06-16 23:11:47.908502
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/tmp/test'}
    results = check_required_if(requirements, parameters)
    assert results == []
    parameters = {'state': 'present'}
    try:
        results = check_required_if(requirements, parameters)
    except TypeError as e:
        assert e.results == [{'parameter': 'state', 'value': 'present', 'requirements': ('path',), 'missing': ['path'], 'requires': 'any'}]
    parameters = {'someint': 99}

# Generated at 2022-06-16 23:11:58.655364
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/some/path',
        'someint': 99,
        'bool_param': True,
    }
    result = check_required_if(requirements, parameters)
    assert result == [{'missing': ['string_param'], 'requires': 'all', 'parameter': 'someint', 'value': 99, 'requirements': ('bool_param', 'string_param')}]
    parameters['string_param'] = 'some string'
    result = check_required_if(requirements, parameters)
    assert result == []


# Generated at 2022-06-16 23:12:10.034671
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [('a', 'b'), ('c', 'd')]
    parameters = {'a': 1}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'c': 1}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'e': 1}
    try:
        check_required_one_of(terms, parameters)
    except TypeError as e:
        assert str(e) == "one of the following is required: a, b"
    parameters = {'a': 1, 'c': 1}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': 1, 'c': 1, 'e': 1}

# Generated at 2022-06-16 23:12:18.028682
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:12:25.608983
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int(1.1) == 1
    assert check_type_int('1.1') == 1
    assert check_type_int(1.9) == 1
    assert check_type_int('1.9') == 1
    assert check_type_int(2) == 2
    assert check_type_int('2') == 2
    assert check_type_int(2.0) == 2
    assert check_type_int('2.0') == 2
    assert check_type_int(2.1) == 2
    assert check_type_int('2.1')

# Generated at 2022-06-16 23:12:37.745445
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/tmp/test'}
    results = check_required_if(requirements, parameters)
    assert len(results) == 0
    parameters = {'state': 'present', 'path': '/tmp/test', 'someint': 99}
    results = check_required_if(requirements, parameters)
    assert len(results) == 0
    parameters = {'state': 'present', 'path': '/tmp/test', 'someint': 99, 'bool_param': True}
    results = check_required_if(requirements, parameters)
    assert len(results) == 0

# Generated at 2022-06-16 23:12:44.937004
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
    }
    results = check_required_if(requirements, parameters)
    assert len(results) == 1
    assert results[0]['parameter'] == 'someint'
    assert results[0]['value'] == 99
    assert results[0]['requirements'] == ('bool_param', 'string_param')
    assert results[0]['missing'] == ['string_param']
    assert results[0]['requires'] == 'all'



# Generated at 2022-06-16 23:12:51.346216
# Unit test for function check_required_by

# Generated at 2022-06-16 23:13:00.095408
# Unit test for function check_required_if
def test_check_required_if():
    # Test for required_if with all requirements
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
        'string_param': 'test',
    }
    assert check_required_if(requirements, parameters) == []

    # Test for required_if with any requirements
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]

# Generated at 2022-06-16 23:13:10.612212
# Unit test for function check_required_by
def test_check_required_by():
    # Test with no requirements
    assert check_required_by(None, {}) == {}
    # Test with no parameters
    assert check_required_by({'a': 'b'}, {}) == {'a': ['b']}
    # Test with no missing parameters
    assert check_required_by({'a': 'b'}, {'a': 'a', 'b': 'b'}) == {}
    # Test with missing parameters
    assert check_required_by({'a': 'b'}, {'a': 'a'}) == {'a': ['b']}
    # Test with multiple missing parameters
    assert check_required_by({'a': ['b', 'c']}, {'a': 'a'}) == {'a': ['b', 'c']}
    # Test with multiple missing parameters and one present
    assert check_required

# Generated at 2022-06-16 23:13:21.677497
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo', include_exceptions=True) == ('foo', None)
    assert safe_

# Generated at 2022-06-16 23:13:34.365409
# Unit test for function check_required_by
def test_check_required_by():
    # Test with no requirements
    assert check_required_by(None, {}) == {}

    # Test with no parameters
    assert check_required_by({'a': 'b'}, {}) == {'a': ['b']}

    # Test with no missing parameters
    assert check_required_by({'a': 'b'}, {'a': 'a', 'b': 'b'}) == {}

    # Test with missing parameters
    assert check_required_by({'a': 'b'}, {'a': 'a'}) == {'a': ['b']}

    # Test with multiple missing parameters
    assert check_required_by({'a': ['b', 'c']}, {'a': 'a'}) == {'a': ['b', 'c']}

    # Test with multiple missing parameters

# Generated at 2022-06-16 23:13:46.013674
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1')

# Generated at 2022-06-16 23:13:57.803521
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'key1': ['key2', 'key3'], 'key4': 'key5'}
    parameters = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4', 'key5': 'value5'}
    assert check_required_by(requirements, parameters) == {}

    parameters = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4'}
    assert check_required_by(requirements, parameters) == {'key4': ['key5']}

    parameters = {'key1': 'value1', 'key2': 'value2', 'key4': 'value4', 'key5': 'value5'}

# Generated at 2022-06-16 23:14:09.907222
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by({'a': ['b', 'c']}, {'a': 'a', 'b': 'b'}) == {}
    assert check_required_by({'a': ['b', 'c']}, {'a': 'a', 'b': 'b', 'c': 'c'}) == {}
    assert check_required_by({'a': ['b', 'c']}, {'a': 'a'}) == {'a': ['b', 'c']}
    assert check_required_by({'a': ['b', 'c']}, {'a': 'a', 'b': 'b', 'c': None}) == {'a': ['c']}

# Generated at 2022-06-16 23:14:22.658848
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('1Tb') == 1099511627776
    assert check_type_bits('1Pb') == 1125899906842624
    assert check_type_bits('1Eb') == 1152921504606846976
    assert check_type_bits('1Zb') == 1180591620717411303424
    assert check_type_bits('1Yb') == 1208925819614629174706176
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1b') == 1
    assert check_type_bits('1') == 1
    assert check_type_bits('1.0') == 1

# Generated at 2022-06-16 23:14:35.400087
# Unit test for function check_required_by
def test_check_required_by():
    # Test for missing parameters
    requirements = {'key1': ['key2', 'key3']}
    parameters = {'key1': 'value1'}
    result = check_required_by(requirements, parameters)
    assert result == {'key1': ['key2', 'key3']}

    # Test for missing parameters with options_context
    requirements = {'key1': ['key2', 'key3']}
    parameters = {'key1': 'value1'}
    options_context = ['key1']
    result = check_required_by(requirements, parameters, options_context)
    assert result == {'key1': ['key2', 'key3']}

    # Test for missing parameters with options_context
    requirements = {'key1': ['key2', 'key3']}

# Generated at 2022-06-16 23:14:44.693192
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Test with no argument_spec
    assert check_required_arguments(None, {}) == []

    # Test with no required arguments
    argument_spec = {'arg1': {'required': False}}
    assert check_required_arguments(argument_spec, {}) == []

    # Test with required argument missing
    argument_spec = {'arg1': {'required': True}}
    assert check_required_arguments(argument_spec, {}) == ['arg1']

    # Test with required argument present
    argument_spec = {'arg1': {'required': True}}
    assert check_required_arguments(argument_spec, {'arg1': 'value'}) == []

    # Test with multiple required arguments
    argument_spec = {'arg1': {'required': True}, 'arg2': {'required': True}}


# Generated at 2022-06-16 23:14:55.507549
# Unit test for function check_required_by
def test_check_required_by():
    requirements = {'key1': ['key2', 'key3'], 'key4': ['key5', 'key6']}
    parameters = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4', 'key5': 'value5', 'key6': 'value6'}
    options_context = ['key1', 'key2']
    result = check_required_by(requirements, parameters, options_context)
    assert result == {}
    parameters = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3', 'key4': 'value4', 'key5': 'value5'}
    result = check_required_by(requirements, parameters, options_context)

# Generated at 2022-06-16 23:15:11.186177
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504606846976

# Generated at 2022-06-16 23:15:24.474256
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504

# Generated at 2022-06-16 23:15:34.540814
# Unit test for function check_type_int
def test_check_type_int():
    assert check_type_int(1) == 1
    assert check_type_int('1') == 1
    assert check_type_int(1.0) == 1
    assert check_type_int('1.0') == 1
    assert check_type_int('-1') == -1
    assert check_type_int('-1.0') == -1
    assert check_type_int('0x10') == 16
    assert check_type_int('0x10.0') == 16
    assert check_type_int('0o10') == 8
    assert check_type_int('0o10.0') == 8
    assert check_type_int('0b10') == 2
    assert check_type_int('0b10.0') == 2

# Generated at 2022-06-16 23:15:42.995942
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']
    parameters = {}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']



# Generated at 2022-06-16 23:15:55.747806
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1") == 1
    assert safe_eval("1.1") == 1.1
    assert safe_eval("'1'") == '1'
    assert safe_eval("'1.1'") == '1.1'
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("{'a': 1}") == {'a': 1}
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]

# Generated at 2022-06-16 23:16:05.477911
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', include_exceptions=True)[0] == 2
    assert safe_eval('1 + 1', include_exceptions=True)[1] is None
    assert safe_eval('foo') == 'foo'
    assert safe_eval('foo', include_exceptions=True) == ('foo', None)
    assert safe_eval('foo', include_exceptions=True)[0] == 'foo'
    assert safe_eval('foo', include_exceptions=True)[1] is None
    assert safe_eval('foo()') == 'foo()'

# Generated at 2022-06-16 23:16:10.528948
# Unit test for function check_missing_parameters
def test_check_missing_parameters():
    parameters = {'param1': 'value1', 'param2': 'value2'}
    required_parameters = ['param1', 'param2', 'param3']
    missing_params = check_missing_parameters(parameters, required_parameters)
    assert missing_params == ['param3']



# Generated at 2022-06-16 23:16:20.243759
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504606846976
    assert check_type_bytes('1z') == 1180591620717411303424
    assert check_type_bytes('1y') == 1208925819614629174706176
    assert check_type_bytes('1kb') == 1024
    assert check_type_bytes('1mb') == 1048576
    assert check_type

# Generated at 2022-06-16 23:16:29.337039
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float('1.1e1') == 11.0
    assert check_type_float(b'1.1e1') == 11.0
    assert check_type_float('1.1e-1') == 0.11
    assert check_type

# Generated at 2022-06-16 23:16:42.264184
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mib') == 1048576
    assert check_type_bits('1M') == 1048576

# Generated at 2022-06-16 23:16:57.284143
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with a single list
    try:
        check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2})
    except TypeError:
        pass
    else:
        raise AssertionError('check_mutually_exclusive() failed to raise TypeError')

    # Test with a list of lists
    try:
        check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3, 'd': 4})
    except TypeError:
        pass
    else:
        raise AssertionError('check_mutually_exclusive() failed to raise TypeError')

    # Test with a list of lists and a single list

# Generated at 2022-06-16 23:17:09.288841
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': '1', 'c': '2'}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': '1', 'c': '2', 'e': '3'}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'e': '3'}
    try:
        check_required_one_of(terms, parameters)
    except TypeError as e:
        assert str(e) == "one of the following is required: a, b found in "
    parameters = {'a': '1', 'b': '2', 'c': '3', 'd': '4'}

# Generated at 2022-06-16 23:17:19.156148
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with a single list
    terms = ['a', 'b']
    parameters = {'a': 1, 'b': 2}
    try:
        check_mutually_exclusive(terms, parameters)
        assert False
    except TypeError:
        assert True

    # Test with a list of lists
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    try:
        check_mutually_exclusive(terms, parameters)
        assert False
    except TypeError:
        assert True

    # Test with a list of lists
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-16 23:17:29.629849
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0.0') == 1.0
    assert check_type_float(b'1.0.0.0') == 1.0
    assert check_type_float(b'1.0.0.0.0') == 1.0
    assert check_type_float(b'1.0.0.0.0.0') == 1.0

# Generated at 2022-06-16 23:17:41.808725
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504

# Generated at 2022-06-16 23:17:54.462628
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/tmp/test'}
    results = check_required_if(requirements, parameters)
    assert results == []
    parameters = {'state': 'present', 'someint': 99, 'bool_param': True}
    results = check_required_if(requirements, parameters)
    assert results == []
    parameters = {'state': 'present', 'someint': 99, 'bool_param': True, 'string_param': 'test'}
    results = check_required_if(requirements, parameters)
    assert results == []

# Generated at 2022-06-16 23:18:05.084316
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/tmp/test'}
    assert check_required_if(requirements, parameters) == []
    parameters = {'state': 'present', 'path': '/tmp/test', 'someint': 99}
    assert check_required_if(requirements, parameters) == []
    parameters = {'state': 'present', 'path': '/tmp/test', 'someint': 99, 'bool_param': True}
    assert check_required_if(requirements, parameters) == []

# Generated at 2022-06-16 23:18:16.696567
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 1048576
   

# Generated at 2022-06-16 23:18:28.336648
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval("1") == 1
    assert safe_eval("1.0") == 1.0
    assert safe_eval("'1'") == '1'
    assert safe_eval("'1.0'") == '1.0'
    assert safe_eval("True") is True
    assert safe_eval("False") is False
    assert safe_eval("None") is None
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert safe_eval("1.0.__add__(2.0)") == "1.0.__add__(2.0)"
    assert safe_eval("import os") == "import os"
    assert safe

# Generated at 2022-06-16 23:18:36.117775
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
    }
    options_context = ['test']
    try:
        check_required_if(requirements, parameters, options_context)
    except TypeError as e:
        assert False, "check_required_if failed with error: %s" % e
    parameters['bool_param'] = False

# Generated at 2022-06-16 23:18:52.061999
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with single list
    terms = ['a', 'b']
    parameters = {'a': 'foo', 'b': 'bar'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        assert e.args[0] == "parameters are mutually exclusive: a|b"

    # Test with list of lists
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 'foo', 'b': 'bar', 'c': 'baz', 'd': 'qux'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        assert e.args[0] == "parameters are mutually exclusive: a|b, c|d"

    # Test with list of lists and options

# Generated at 2022-06-16 23:19:03.149087
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{'a': 1, 'b': 2}") == {'a': 1, 'b': 2}
    assert check_type_dict("a=1, b=2") == {'a': '1', 'b': '2'}
    assert check_type_dict("a=1, b=2, c=3") == {'a': '1', 'b': '2', 'c': '3'}
    assert check_type_dict("a=1, b='2', c=3") == {'a': '1', 'b': '2', 'c': '3'}
    assert check_type_dict("a=1, b='2', c='3'") == {'a': '1', 'b': '2', 'c': '3'}
    assert check_type_dict

# Generated at 2022-06-16 23:19:14.926064
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float('1.0') == 1