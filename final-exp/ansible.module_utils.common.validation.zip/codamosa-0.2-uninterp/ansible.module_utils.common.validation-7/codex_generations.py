

# Generated at 2022-06-16 23:10:07.330431
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
        'required_arg_with_default': {'required': True, 'default': 'foo'},
        'optional_arg_with_default': {'required': False, 'default': 'bar'},
    }
    parameters = {'required_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'required_arg_with_default': 'foo'}
    assert check_required_arguments(argument_spec, parameters) == []

# Generated at 2022-06-16 23:10:13.642029
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert check_type_dict('a=1, b=2') == {"a": "1", "b": "2"}
    assert check_type_dict('a=1, b=2, c=3') == {"a": "1", "b": "2", "c": "3"}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {"a": "1", "b": "2", "c": "3", "d": "4"}

# Generated at 2022-06-16 23:10:25.785293
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test 1: Test that a list of mutually exclusive parameters is detected
    # correctly.
    parameters = {'a': 'a', 'b': 'b'}
    terms = [['a', 'b']]
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pass
    else:
        assert False, "Mutually exclusive parameters were not detected"

    # Test 2: Test that a list of mutually exclusive parameters is detected
    # correctly.
    parameters = {'a': 'a', 'b': 'b', 'c': 'c'}
    terms = [['a', 'b'], ['a', 'c']]
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError:
        pass

# Generated at 2022-06-16 23:10:34.270219
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
    }
    options_context = ['test']
    try:
        check_required_if(requirements, parameters, options_context)
    except TypeError as e:
        assert e.results == [
            {
                'parameter': 'someint',
                'value': 99,
                'requirements': ('bool_param', 'string_param'),
                'missing': ['string_param'],
                'requires': 'all',
            }
        ]
    else:
        raise Assert

# Generated at 2022-06-16 23:10:46.178739
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('{"foo": "bar"}', include_exceptions=True) == ({'foo': 'bar'}, None)
    assert safe_eval('{"foo": "bar", "baz": "qux"}') == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-16 23:10:59.344840
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with a single list
    terms = ['a', 'b']
    parameters = {'a': 1, 'b': 2}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        assert "parameters are mutually exclusive: a|b" in str(e)

    # Test with a list of lists
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        assert "parameters are mutually exclusive: a|b, c|d" in str(e)

    # Test with a list of lists and a list

# Generated at 2022-06-16 23:11:11.288058
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
   

# Generated at 2022-06-16 23:11:20.297323
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Gb') == 1073741824
    assert check_type_bits('1Tb') == 1099511627776
    assert check_type_bits('1Pb') == 1125899906842624
    assert check_type_bits('1Eb') == 1152921504606846976
    assert check_type_bits('1Zb') == 1180591620717411303424
    assert check_type_bits('1Yb') == 1208925819614629174706176
    assert check_type_bits('1Kb') == 1024
    assert check_type_bits('1b') == 1
    assert check_type_bits('1') == 1
    assert check_type_bits('1.5Mb')

# Generated at 2022-06-16 23:11:28.567136
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'present'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'present'}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']
    parameters = {}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']



# Generated at 2022-06-16 23:11:37.222143
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with a single list of terms
    terms = ['a', 'b']
    parameters = {'a': 'foo', 'b': 'bar'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        assert 'parameters are mutually exclusive: a|b' in to_native(e)

    # Test with a list of lists of terms
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 'foo', 'b': 'bar', 'c': 'baz', 'd': 'qux'}
    try:
        check_mutually_exclusive(terms, parameters)
    except TypeError as e:
        assert 'parameters are mutually exclusive: a|b, c|d' in to_native(e)

    # Test

# Generated at 2022-06-16 23:11:56.610670
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1.0') == 2.0
    assert safe_eval('1.0 + 1') == 2.0
    assert safe_eval('1.0 + 1.0') == 2.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('"foo" + "bar"') == 'foobar'
    assert safe_eval('"foo" + "bar" + "baz"') == 'foobarbaz'

# Generated at 2022-06-16 23:12:04.293006
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:12:15.698433
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1) == 1.0
    assert check_type_float(1.0) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float('1.1e1') == 1.1e1
    assert check_type_float(b'1.1e1') == 1.1e1
    assert check_type_float('1.1e-1') == 1.1

# Generated at 2022-06-16 23:12:29.215225
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('foo.bar()', include_exceptions=True)[0] == 'foo.bar()'
    assert safe_eval('import foo', include_exceptions=True)[0] == 'import foo'
    assert safe_eval('1', include_exceptions=True)[1] is None

# Generated at 2022-06-16 23:12:40.494422
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by(None, None) == {}
    assert check_required_by({}, {}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'b'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'b', 'b': 'c'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'b', 'b': None}) == {}
    assert check_required_by({'a': 'b'}, {'a': None}) == {}
    assert check_required_by({'a': 'b'}, {}) == {}

# Generated at 2022-06-16 23:12:53.560338
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
    }
    options_context = ['test']
    result = check_required_if(requirements, parameters, options_context)
    assert result == []
    parameters = {
        'state': 'present',
        'path': '/tmp/test',
        'someint': 99,
        'bool_param': True,
        'string_param': 'test',
    }
    result = check_required_if(requirements, parameters, options_context)
    assert result == []

# Generated at 2022-06-16 23:13:04.303994
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('[1,2,3]') == [1, 2, 3]
    assert safe_eval('{"a": "b"}') == {'a': 'b'}
    assert safe_eval('{"a": "b"}', include_exceptions=True) == ({'a': 'b'}, None)
    assert safe_eval('{"a": "b"', include_exceptions=True) == ('{"a": "b"', None)
    assert safe_eval('{"a": "b"', include_exceptions=True)[0] == '{"a": "b"'
    assert safe_eval('{"a": "b"', include_exceptions=True)[1] is None
    assert safe_eval('{"a": "b"', include_exceptions=True)[1] is None

# Generated at 2022-06-16 23:13:09.474335
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict('{"a": 1, "b": 2}') == {'a': 1, 'b': 2}
    assert check_type_dict('a=1, b=2') == {'a': '1', 'b': '2'}
    assert check_type_dict('a=1, b=2, c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert check_type_dict('a=1, b=2, c=3, d=4') == {'a': '1', 'b': '2', 'c': '3', 'd': '4'}

# Generated at 2022-06-16 23:13:20.858965
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('u"foo"') == 'foo'
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('{"foo": "bar", "baz": "qux"}') == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-16 23:13:33.078675
# Unit test for function check_required_by

# Generated at 2022-06-16 23:13:50.488710
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_

# Generated at 2022-06-16 23:14:02.714100
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval("'foo'") == 'foo'
    assert safe_eval("[1, 2, 3]") == [1, 2, 3]
    assert safe_eval("{'foo': 'bar'}") == {'foo': 'bar'}
    assert safe_eval("foo.bar()") == 'foo.bar()'
    assert safe_eval("import foo") == 'import foo'

# Generated at 2022-06-16 23:14:07.301586
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': '1', 'b': '2', 'c': '3', 'd': '4'}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': '1', 'b': '2', 'c': '3'}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': '1', 'b': '2', 'd': '4'}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': '1', 'b': '2'}
    assert check_required_together(terms, parameters) == []

# Generated at 2022-06-16 23:14:15.819290
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1Z') == 1180591620717411303424
    assert check_type_bytes('1Y') == 1208925819614629174706176
    assert check_type_bytes('1KB') == 1024
    assert check_type_bytes('1MB') == 1048576
    assert check_type_bytes('1GB') == 1073741824
   

# Generated at 2022-06-16 23:14:27.255734
# Unit test for function check_type_bits
def test_check_type_bits():
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1M') == 8388608
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576
    assert check_type_bits('1Mb') == 1048576

# Generated at 2022-06-16 23:14:39.877859
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736
    assert check_type_bytes('1.5T') == 1649267441664
    assert check_type

# Generated at 2022-06-16 23:14:52.267340
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': 1, 'b': 2}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    assert check_required_together(terms, parameters) == []

# Generated at 2022-06-16 23:14:57.169704
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {
        'required_arg': {'required': True},
        'optional_arg': {'required': False},
    }
    parameters = {'required_arg': 'present'}
    assert check_required_arguments(argument_spec, parameters) == []
    parameters = {'optional_arg': 'present'}
    assert check_required_arguments(argument_spec, parameters) == ['required_arg']



# Generated at 2022-06-16 23:15:09.533448
# Unit test for function check_required_by
def test_check_required_by():
    assert check_required_by(None, {}) == {}
    assert check_required_by({}, {}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'b'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'b', 'b': 'c'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'b', 'b': None}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'b', 'b': None, 'c': 'd'}) == {}
    assert check_required_by({'a': 'b'}, {'a': 'b', 'c': 'd'}) == {'a': ['b']}
    assert check_required_

# Generated at 2022-06-16 23:15:18.865399
# Unit test for function check_required_together
def test_check_required_together():
    # Test case 1:
    #   terms = [('a', 'b'), ('c', 'd')]
    #   parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    #   result = []
    #   expected = []
    #   assert result == expected
    terms = [('a', 'b'), ('c', 'd')]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    result = check_required_together(terms, parameters)
    expected = []
    assert result == expected

    # Test case 2:
    #   terms = [('a', 'b'), ('c', 'd')]
    #   parameters = {'a': 1, 'b': 2, 'c': 3}
    #   result = []

# Generated at 2022-06-16 23:15:30.995092
# Unit test for function check_required_if
def test_check_required_if():
    requirements = [
        ['state', 'present', ('path',), True],
        ['someint', 99, ('bool_param', 'string_param')],
    ]
    parameters = {'state': 'present', 'path': '/tmp/test'}
    try:
        check_required_if(requirements, parameters)
    except TypeError as e:
        assert e.results == [{'parameter': 'someint', 'value': 99, 'requirements': ('bool_param', 'string_param'), 'missing': ['bool_param', 'string_param'], 'requires': 'all'}]
    else:
        assert False, 'check_required_if did not raise TypeError'



# Generated at 2022-06-16 23:15:39.027156
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736
    assert check_type_bytes('1.5T') == 1649267441664
    assert check_type

# Generated at 2022-06-16 23:15:52.374114
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1m') == 1048576
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1g') == 1073741824
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1t') == 1099511627776
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1p') == 1125899906842624
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1e') == 1152921504

# Generated at 2022-06-16 23:16:03.775531
# Unit test for function check_type_dict
def test_check_type_dict():
    assert check_type_dict("{'a':1,'b':2}") == {'a': 1, 'b': 2}
    assert check_type_dict("a=1,b=2") == {'a': '1', 'b': '2'}
    assert check_type_dict("a=1,b=2,c=3") == {'a': '1', 'b': '2', 'c': '3'}
    assert check_type_dict("a=1,b=2,c=3,d=4") == {'a': '1', 'b': '2', 'c': '3', 'd': '4'}

# Generated at 2022-06-16 23:16:15.964300
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1M') == 1048576
    assert check_type_bytes('1G') == 1073741824
    assert check_type_bytes('1T') == 1099511627776
    assert check_type_bytes('1P') == 1125899906842624
    assert check_type_bytes('1E') == 1152921504606846976
    assert check_type_bytes('1K') == 1024
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1.5K') == 1536
    assert check_type_bytes('1.5M') == 1572864
    assert check_type_bytes('1.5G') == 1610612736
    assert check_type_bytes('1.5T') == 1649267441664
    assert check_type

# Generated at 2022-06-16 23:16:25.569305
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': 1, 'b': 2, 'd': 4}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': 1, 'c': 3, 'd': 4}
    assert check_required_together(terms, parameters) == [['a', 'b']]

# Generated at 2022-06-16 23:16:32.007929
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with single list
    try:
        check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2})
    except TypeError as e:
        assert 'parameters are mutually exclusive: a|b' in str(e)
    else:
        assert False, "check_mutually_exclusive did not raise TypeError"

    # Test with list of lists
    try:
        check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 1, 'b': 2, 'c': 3, 'd': 4})
    except TypeError as e:
        assert 'parameters are mutually exclusive: a|b, c|d' in str(e)
    else:
        assert False, "check_mutually_exclusive did not raise TypeError"

    # Test

# Generated at 2022-06-16 23:16:37.238541
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float('1.1') == 1.1

# Generated at 2022-06-16 23:16:46.772843
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('"foo"') == 'foo'
    assert safe_eval('["foo", "bar"]') == ['foo', 'bar']
    assert safe_eval('{"foo": "bar"}') == {'foo': 'bar'}
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('foo.bar()') == 'foo.bar()'
    assert safe_eval('import foo') == 'import foo'
    assert safe_eval('1 + 1') == '1 + 1'
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)

# Generated at 2022-06-16 23:16:58.094889
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test with a single list
    try:
        check_mutually_exclusive(['a', 'b'], {'a': 'foo', 'b': 'bar'})
    except TypeError:
        pass
    else:
        raise AssertionError('check_mutually_exclusive() failed to raise TypeError')

    # Test with a list of lists
    try:
        check_mutually_exclusive([['a', 'b'], ['c', 'd']], {'a': 'foo', 'b': 'bar', 'c': 'baz', 'd': 'qux'})
    except TypeError:
        pass
    else:
        raise AssertionError('check_mutually_exclusive() failed to raise TypeError')

    # Test with a list of lists and a single list

# Generated at 2022-06-16 23:17:13.785452
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(1.1) == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(1.1) == 1.1
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(1.1)

# Generated at 2022-06-16 23:17:26.285116
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b', 'c'], ['d', 'e']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert check_required_together(terms, parameters) == [['d', 'e']]
    parameters = {'a': 1, 'b': 2, 'c': 3, 'e': 5}
    assert check_required_together(terms, parameters) == [['d', 'e']]
    parameters = {'a': 1, 'b': 2, 'c': 3}
    assert check_required_together(terms, parameters) == []

# Generated at 2022-06-16 23:17:36.658277
# Unit test for function check_required_if
def test_check_required_if():
    assert check_required_if([['state', 'present', ('path',), True]], {'state': 'present', 'path': '/tmp/foo'}) == []
    assert check_required_if([['state', 'present', ('path',), True]], {'state': 'present'}) == [{'missing': ['path'], 'requires': 'any', 'parameter': 'state', 'value': 'present', 'requirements': ('path',)}]
    assert check_required_if([['state', 'present', ('path',), True]], {'state': 'absent'}) == []
    assert check_required_if([['state', 'present', ('path',), False]], {'state': 'present', 'path': '/tmp/foo'}) == []

# Generated at 2022-06-16 23:17:46.615236
# Unit test for function check_mutually_exclusive
def test_check_mutually_exclusive():
    # Test 1: check_mutually_exclusive with single list
    # Expected result: No exception
    try:
        check_mutually_exclusive(['a', 'b'], {'a': 1})
    except Exception as e:
        raise AssertionError("Unexpected exception: %s" % e)

    # Test 2: check_mutually_exclusive with single list
    # Expected result: TypeError exception
    try:
        check_mutually_exclusive(['a', 'b'], {'a': 1, 'b': 2})
    except TypeError as e:
        pass
    except Exception as e:
        raise AssertionError("Unexpected exception: %s" % e)

    # Test 3: check_mutually_exclusive with list of lists
    # Expected result: No exception

# Generated at 2022-06-16 23:17:57.992354
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.0') == 1.0
    assert safe_eval('[1, 2]') == [1, 2]
    assert safe_eval('{"a": 1}') == {"a": 1}
    assert safe_eval('"a"') == "a"
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1 + 1', include_exceptions=True) == (2, None)
    assert safe_eval('1 + 1', locals={'a': 1}, include_exceptions=True) == (2, None)

# Generated at 2022-06-16 23:18:04.985750
# Unit test for function check_required_arguments
def test_check_required_arguments():
    argument_spec = {'required_arg': {'required': True}, 'not_required_arg': {'required': False}}
    parameters = {'required_arg': 'value'}
    missing = check_required_arguments(argument_spec, parameters)
    assert len(missing) == 0
    parameters = {'not_required_arg': 'value'}
    missing = check_required_arguments(argument_spec, parameters)
    assert len(missing) == 1
    assert 'required_arg' in missing


# Generated at 2022-06-16 23:18:15.976627
# Unit test for function check_required_arguments
def test_check_required_arguments():
    # Test with no missing arguments
    argument_spec = {'arg1': {'required': True}, 'arg2': {'required': False}}
    parameters = {'arg1': 'test'}
    missing = check_required_arguments(argument_spec, parameters)
    assert missing == []

    # Test with missing arguments
    argument_spec = {'arg1': {'required': True}, 'arg2': {'required': False}}
    parameters = {'arg2': 'test'}
    try:
        missing = check_required_arguments(argument_spec, parameters)
    except TypeError as e:
        assert e.args[0] == "missing required arguments: arg1"
    else:
        assert False, "Expected TypeError"



# Generated at 2022-06-16 23:18:27.701428
# Unit test for function check_required_one_of
def test_check_required_one_of():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 1, 'c': 2}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'a': 1}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'c': 2}
    assert check_required_one_of(terms, parameters) == []
    parameters = {'e': 3}
    try:
        check_required_one_of(terms, parameters)
    except TypeError as e:
        assert str(e) == "one of the following is required: a, b found in "
    parameters = {'a': 1, 'c': 2, 'e': 3}

# Generated at 2022-06-16 23:18:35.684399
# Unit test for function safe_eval
def test_safe_eval():
    assert safe_eval('1') == 1
    assert safe_eval('1.1') == 1.1
    assert safe_eval('True') is True
    assert safe_eval('False') is False
    assert safe_eval('None') is None
    assert safe_eval('[1, 2, 3]') == [1, 2, 3]
    assert safe_eval('{"a": 1, "b": 2}') == {"a": 1, "b": 2}
    assert safe_eval('"foo"') == "foo"
    assert safe_eval('1 + 1') == 2
    assert safe_eval('1.1 + 1.1') == 2.2
    assert safe_eval('1 + 1.1') == 2.1
    assert safe_eval('1.1 + 1') == 2.1

# Generated at 2022-06-16 23:18:48.311688
# Unit test for function check_required_together
def test_check_required_together():
    terms = [['a', 'b'], ['c', 'd']]
    parameters = {'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd'}
    assert check_required_together(terms, parameters) == []
    parameters = {'a': 'a', 'b': 'b', 'c': 'c'}
    assert check_required_together(terms, parameters) == [['c', 'd']]
    parameters = {'a': 'a', 'c': 'c', 'd': 'd'}
    assert check_required_together(terms, parameters) == [['a', 'b']]
    parameters = {'a': 'a', 'b': 'b'}
    assert check_required_together(terms, parameters) == [['c', 'd']]

# Generated at 2022-06-16 23:19:02.224495
# Unit test for function check_type_bytes
def test_check_type_bytes():
    assert check_type_bytes('1') == 1
    assert check_type_bytes('1k') == 1024
    assert check_type_bytes('1m') == 1024 * 1024
    assert check_type_bytes('1g') == 1024 * 1024 * 1024
    assert check_type_bytes('1t') == 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1p') == 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1e') == 1024 * 1024 * 1024 * 1024 * 1024 * 1024
    assert check_type_bytes('1kib') == 1024
    assert check_type_bytes('1mib') == 1024 * 1024
    assert check_type_bytes('1gib') == 1024 * 1024 * 1024
    assert check_type_bytes('1tib') == 1024 * 1024 * 1024 * 1024


# Generated at 2022-06-16 23:19:14.398727
# Unit test for function check_type_float
def test_check_type_float():
    assert check_type_float(1.0) == 1.0
    assert check_type_float(1) == 1.0
    assert check_type_float('1') == 1.0
    assert check_type_float(b'1') == 1.0
    assert check_type_float(b'1.0') == 1.0
    assert check_type_float('1.0') == 1.0
    assert check_type_float('1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_float(b'1.1') == 1.1
    assert check_type_