

# Generated at 2022-06-11 18:21:05.832480
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Test method _TextEnviron.__getitem__
    '''
    # environ is initialized in __init__.py and is a global variable
    assert isinstance(environ, _TextEnviron)

    # environ is a dictionary-like class, so we can use dictionary operations.
    # Check the length
    assert len(environ) >= 0

    # Get a key-value pair of the environment
    key, value = environ.items().__iter__().__next__()
    # The key is a text string
    assert isinstance(key, str)
    # The value is a text string
    assert isinstance(value, str)

    # Reference https://docs.python.org/3/library/functions.html#os.environ
    # os.environ['myvar'] = 'myvalue'

   

# Generated at 2022-06-11 18:21:17.127030
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # create a copy since the environ should not be changed by this test
    _env_copy = dict(os.environ)
    # test data

# Generated at 2022-06-11 18:21:26.110713
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # GIVEN an environment variable with a value
    env_var_name = 'HOME'
    env_var_value = b'/home/user\xc3\xa1'
    environ._raw_environ[env_var_name] = env_var_value
    # WHEN fetching the environment variable
    # THEN it should have the expected value
    assert environ[env_var_name] == to_text(env_var_value, encoding='utf-8', nonstring='passthru',
                                            errors='surrogate_or_strict')


# Generated at 2022-06-11 18:21:35.688802
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Tested on Python 3.6.4
    # BEGIN
    foobar_env = _TextEnviron({to_bytes('FOO'): to_bytes('foo'), to_bytes('BAR'): to_bytes('bar')})

    assert list(foobar_env.keys()) == [to_text('FOO'), to_text('BAR')]
    assert list(foobar_env.values()) == [to_text('foo'), to_text('bar')]
    assert list(foobar_env.items()) == [(to_text('FOO'), to_text('foo')), (to_text('BAR'), to_text('bar'))]

    # Test that we decode values to text
    assert foobar_env['FOO'] == to_text('foo')

    # Test that we can use the text value to get the

# Generated at 2022-06-11 18:21:46.457498
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(env={}, encoding='utf-8')

    class obj:
        def __str__(self):
            return 'example'

    env['str'] = 'example'
    env['bytes'] = to_bytes('example', encoding='utf-8')
    if PY3:
        env['bytes'] = to_bytes(b'example', encoding='utf-8')
        env['text'] = to_text('example', encoding='utf-8')
    env['nonstring'] = obj()

    # Key does not exist in _raw_environ
    try:
        value = env['unknown']
        assert 0
    except KeyError:
        pass

    # Key exists in _raw_environ but not in _value_cache
    value = env['str']
    assert value == 'example'

# Generated at 2022-06-11 18:21:53.465409
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test when the object is not in environ
    assert environ['DOESNT_EXIST'] == 'DOESNT_EXIST'

    # Test when the object is in environ
    environ['TEST_KEY'] = 'TEST_VALUE'
    #NOTE: the ansible_system_capabilities_environments_ansible_os_family key is returned by
    # AnsibleModule().run_command. It is chosen because it is known to be returned as a text string
    # on windows.
    assert environ['TEST_KEY'] == 'TEST_VALUE'

# Generated at 2022-06-11 18:22:01.746902
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    with open('test_text_env.py', 'rb') as f:
        data = f.read()
    f.close()
    if PY3:
        assert data == data.decode('utf-8')
    else:
        assert data != data.decode('utf-8')
    with open('test_text_env.py', 'wb') as f:
        f.write(data)
    f.close()
    if PY3:
        assert data == data.decode('utf-8')
    else:
        assert data != data.decode('utf-8')

# Generated at 2022-06-11 18:22:03.536375
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(encoding='utf-8')
    assert isinstance(environ['PATH'], str)
    return True

# Generated at 2022-06-11 18:22:15.813567
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Testing the function when variable is not present in the environ.
    import os
    # Test for variable which is not present in the environ
    variable = 'TEST_VARIABLE'
    if variable in environ:
        del environ[variable]
    try:
        # The function should raise KeyError
        environ[variable]
    except KeyError as e:
        # If it does raise KeyError, it should be for the correct variable
        message = e.args[0]
        assert message.strip() == variable, 'KeyError should be raised for the variable %s' %variable

    # Testing the function when variable is present in the environ

# Generated at 2022-06-11 18:22:23.770664
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    old_environ = os.environ.copy()
    os.environ.clear()
    try:
        environ = _TextEnviron()

        os.environ[b'not_unicode'] = b'\x99\xe2\x98\x83'
        result = environ['not_unicode']
        print(result)

    finally:
        os.environ.clear()
        os.environ.update(old_environ)


if __name__ == "__main__":
    print(environ)
    test__TextEnviron___getitem__()

# Generated at 2022-06-11 18:22:29.367464
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ.update({'ANSIBLE_TEST_KEY': 'ANSIBLE_TEST_VALUE'})
    value = environ.get('ANSIBLE_TEST_KEY')
    assert value == 'ANSIBLE_TEST_VALUE'

# Generated at 2022-06-11 18:22:36.630839
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:22:47.498659
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import six
    import sys

    temp_env = os.environ.copy()
    encoding = sys.getfilesystemencoding()
    # Test ability to encode bytes
    temp_env['test_key'] = b'\xff'
    assert _TextEnviron(temp_env, encoding)['test_key'] == u'\ufffd'
    # Test ability to decode str
    if six.PY3:
        temp_env['test_key'] = '\ufffd'
        assert _TextEnviron(temp_env, encoding)['test_key'] == u'\ufffd'
    else:
        temp_env['test_key'] = '\xff'
        assert _TextEnviron(temp_env, encoding)['test_key'] == u'\ufffd'
    del temp_env


#

# Generated at 2022-06-11 18:22:54.254532
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Tests that we can get a value out of __getitem__
    """
    env = {b'PATH': b'/usr/local/bin:/usr/bin:/bin'}
    _environ = _TextEnviron(env=env)
    assert _environ[u'PATH'] == u'/usr/local/bin:/usr/bin:/bin'


# Generated at 2022-06-11 18:22:56.649763
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['FOO'] = 'bar'
    assert environ['FOO'] == 'bar'


# Generated at 2022-06-11 18:23:04.396807
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six.moves import unittest
    import mock


    class Test__TextEnviron___getitem__(unittest.TestCase):
        def setUp(self):
            self.text_environ = _TextEnviron(encoding='utf-8')

        def test_getitem__with_non_existing_key(self):
            self.text_environ._raw_environ = {
                to_bytes('foo'): 'bar'
            }
            with self.assertRaises(KeyError):
                self.text_environ['bar']


# Generated at 2022-06-11 18:23:15.010244
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest
    import builtins
    class _TextEnvironTests(unittest.TestCase):
        def test_text_encode_decode(self):
            # _environ_backup = environ.copy()
            self.assertEqual(environ['LANG'], 'en_US.UTF-8')

            environ['ansible_test_bytes'] = b"\xe4\xbd\xa0\xe5\xa5\xbd"
            self.assertEqual(environ['ansible_test_bytes'], "你好")

            environ['ansible_test_unicode'] = u"\u4f60\u597d"
            self.assertEqual(environ['ansible_test_unicode'], u"\u4f60\u597d")



# Generated at 2022-06-11 18:23:16.938592
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['key'] = 'value'
    assert environ['key'] == 'value'



# Generated at 2022-06-11 18:23:27.200666
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class _EnvironMock(MutableMapping):
        def __init__(self):
            self.data = {
                'str_key': 'str_value',
                b'bytes_key': b'bytes_value'.decode('utf-8'),
                b'bytes_key_empty': ''.encode('utf-8'),  # type: bytes
                'str_key_empty': '',
                'str_key_empty_latin1': ''.encode('latin1').decode('latin1'),
                'str_key_unicode': 'مرحبا',
                'str_key_error': '\x9c'.encode('windows_1252').decode('utf-8')
            }

        def __delitem__(self, key):
            del self.data[key]



# Generated at 2022-06-11 18:23:36.245951
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    If a MutableMapping object is initialized with a Python2 byte string key and value,
    the values returned from __getitem__ should be "text" strings
    '''
    import textwrap
    if not PY3:
        os.environ['PYTHON_VERSION'] = '2'

        test_map = _TextEnviron()

        assert isinstance(test_map['PYTHON_VERSION'], str)
        assert test_map['PYTHON_VERSION'] == '2'

        # Test that the __getitem__ method caches the result for that key
        test_map._raw_environ['PYTHON_VERSION'] = '3'
        assert test_map['PYTHON_VERSION'] == '2'
        del test_map._value_cache

        # Test that the __get

# Generated at 2022-06-11 18:23:39.377637
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(environ['PATH'], str)


# Generated at 2022-06-11 18:23:51.614339
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest
    import unittest.mock

    class __getitem__TestCase(unittest.TestCase):
        @unittest.mock.patch('os.environ')
        def test_non_bytes(self, mock_os_environ):
            environ = _TextEnviron()
            os.environ['k'] = 'v'
            self.assertEqual(environ['k'], 'v')

        @unittest.mock.patch('os.environ')
        def test_bytes(self, mock_os_environ):
            environ = _TextEnviron()
            os.environ['k'] = b'v'
            self.assertEqual(environ['k'], 'v')


# Generated at 2022-06-11 18:24:02.059484
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Adapted from Python 3.6.2's Lib/test/test_os.py

    # Test #1
    os.environ['foo1'] = 'bar1'
    e = _TextEnviron({'foo2': 'bar2'}, 'latin1')

    assert os.environ['foo1'] == b'bar1'
    assert e['foo1'] == 'bar1'
    assert e['foo2'] == 'bar2'

    # Test #2
    e = _TextEnviron()
    key = 'foo1'
    value = 'ěščřžýáíé'
    e[key] = value
    assert key in e
    assert key in os.environ
    assert e[key] == value

# Generated at 2022-06-11 18:24:12.370694
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class _MockedStringEnviron(MutableMapping):
        """
        Utility class to return text strings from the environment instead of byte strings

        Mimics the behaviour of os.environ on Python3
        """
        def __init__(self, env=None, encoding=None):
            self._raw_environ = {0:0, 1:1, 2:2}
            self._value_cache = {}
            self.encoding="utf-8"
            if encoding is None:
                self.encoding="utf-8"
            else:
                self.encoding=encoding
        def __delitem__(self, key):
            del self._raw_environ[key]
        def __getitem__(self, key):
            value = self._raw_environ[key]
            if PY3:
                return value

# Generated at 2022-06-11 18:24:18.293950
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import PY3

    if PY3:
        return

    environ['TEST_UTF8'] = 'Žluťoučký koníček'
    assert environ['TEST_UTF8'] == u'Žluťoučký koníček'

# Generated at 2022-06-11 18:24:28.237618
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_cases = [
        (u'путь', u'путь'),
        (u'/foo/bar', u'/foo/bar'),
        (u'', u''),
        (u'αβγδεζηθικλμνξοπρστυφχψως', u'αβγδεζηθικλμνξοπρστυφχψως'),
    ]

    env = _TextEnviron({'PATH': test_cases[0][0]})
    text = env[u'PATH']

# Generated at 2022-06-11 18:24:39.142290
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # When the os.environ value is a text value, set it as the value returned
    text_value = 'þrír'
    mock_env = {'foo': text_value}
    environ._raw_environ = mock_env
    assert environ['foo'] == text_value

    # When the os.environ value is a byte value, decode it
    byte_value = b'\xfe\xf0\xfd\xf0'
    mock_env = {'foo': byte_value}
    environ._raw_environ = mock_env
    assert environ['foo'] == text_value

    # Validate that the cache doesn't try to decode a value that's already a text string
    environ._value_cache[text_value] = 'foo'

# Generated at 2022-06-11 18:24:49.768947
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(encoding='utf-8')
    setattr(env, '_raw_environ', {
        'foo': 'foo_value',
        'bar': 'bar_value',
    })
    setattr(env, '_value_cache', {
        'foo_value': 'foo_value',
        'bar_value': 'bar_value',
    })
    teststr = 'teststr'
    setattr(env, '_raw_environ', {
        'foo': 'foo_value',
        'bar': 'bar_value',
        'teststr': teststr
    })
    for key in ('foo', 'bar'):
        assert env[key] == getattr(env, '_value_cache')[key]

# Generated at 2022-06-11 18:25:00.816576
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env_py2 = {b'ADV_FAKE_TERM': b'1', b'DRY_RUN': b'True'}
    env_py3 = {'ADV_FAKE_TERM': '1', 'DRY_RUN': 'True'}
    env_py2_decoded = {u'ADV_FAKE_TERM': u'1', u'DRY_RUN': u'True'}
    env_py3_decoded = env_py3

    if PY3:
        assert _TextEnviron(env_py2)._raw_environ == env_py2
        assert _TextEnviron(env_py3)._raw_environ == env_py3

        assert _TextEnviron(env_py2)._value_cache == env_py2_decoded


# Generated at 2022-06-11 18:25:06.729598
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron(env={'b': 'b', 'c': 'c', 'a': 'a'})
    assert text_environ.encoding == 'utf-8'
    assert text_environ['b'] == 'b'
    assert text_environ['c'] == 'c'
    assert text_environ['a'] == 'a'
    assert text_environ.encoding == 'utf-8'

# Generated at 2022-06-11 18:25:16.103009
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''Unit test for method __getitem__ of class _TextEnviron'''
    if PY3:
        return

    # Test when no cache is present
    env = _TextEnviron({'foo': 'bar'}, encoding='ascii')
    assert env['foo'] == u'bar'

    # Test when cache is present
    env = _TextEnviron({'foo': 'bar'}, encoding='ascii')
    env['foo']
    assert env['foo'] == u'bar'


# Generated at 2022-06-11 18:25:23.994689
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    environ = _TextEnviron({
        b'ANSIBLE_MODULE_ARGS': b'{"_ansible_module_name": "test_module_args", "_ansible_module_name": "test_module_name", "kwargs": {"foo": "bar", "bar": "baz"}, "args": ["foo"]}'
    }, encoding='utf-8')

    assert environ['ANSIBLE_MODULE_ARGS'] == '{"_ansible_module_name": "test_module_args", "_ansible_module_name": "test_module_name", "kwargs": {"foo": "bar", "bar": "baz"}, "args": ["foo"]}'

# Generated at 2022-06-11 18:25:34.995278
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """
    # This test should pass for Python 2 and Python 3 on UTF-8 and ANSI enabled OSes
    #
    # A bit of background:
    # PY2:
    #     Byte strings are returned by os.environ
    #     getfilesystemencoding() defaults to returning 'mbcs' on most Windows environments
    #
    # PY3:
    #     Unicode strings are returned by os.environ
    #     getfilesystemencoding() defaults to returning 'utf-8' on most Unix environments
    #     getfilesystemencoding() defaults to returning 'mbcs' on most Windows environments
    #
    # mbcs:
    #     Unicode strings when the environment variable is set to unicode characters
    #     Byte strings when the environment variable is

# Generated at 2022-06-11 18:25:42.863761
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    real_environ = os.environ.copy()
    real_environ['TEST_ENCODING_PROCESS'] = '=?utf-8?Q?I=20chose=20Latin=20for=20the=20process?='
    environ = _TextEnviron(env=real_environ)
    assert environ['TEST_ENCODING_PROCESS'] == u'=?utf-8?Q?I=20chose=20Latin=20for=20the=20process?='

    real_environ = os.environ.copy()
    del real_environ['TEST_ENCODING_PROCESS']
    environ = _TextEnviron(env=real_environ)
    assert u'TEST_ENCODING_PROCESS' not in environ

    real_en

# Generated at 2022-06-11 18:25:52.495545
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import sys
    import unittest


# Generated at 2022-06-11 18:26:02.157039
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ._raw_environ['some_variable'] = b'test1'
    assert environ['some_variable'] == u'test1'
    environ._raw_environ['some_variable'] = b'test\xc3\xa41'
    assert environ['some_variable'] == u'test\u00e41'
    environ._raw_environ['some_variable'] = b'\xee\x80\x80'
    assert environ['some_variable'] == u'\U000e0000'
    environ._raw_environ['some_variable'] = b'\xf4\x8f\xbf\xbf'
    assert environ['some_variable'] == u'\U0010ffff'

# Generated at 2022-06-11 18:26:04.473903
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for case where a key exists
    """
    env = _TextEnviron()
    assert env['HOME'] == os.environ['HOME']


# Generated at 2022-06-11 18:26:05.722334
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ[str('LANG')] == u'en_US.UTF-8'

# Generated at 2022-06-11 18:26:15.898784
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:26:17.737253
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    t = _TextEnviron()

    assert t['HOME'] == os.environ['HOME']


# Generated at 2022-06-11 18:26:27.698065
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(env={b'FOO': b'bar'}, encoding='utf-8')
    assert env.get(b'FOO') is None
    assert env.get('FOO') is None
    assert env['FOO'] == 'bar'
    assert type(env['FOO']) == str
    assert env[b'FOO'] == 'bar'
    assert type(env[b'FOO']) == str



# Generated at 2022-06-11 18:26:38.413430
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Call the method under test
    # First, let's make sure that the cache is empty and that we can read the environment
    # correctly.
    environ._value_cache = {}
    assert environ['PWD'] == to_text(os.environ[b'PWD'], encoding=sys.getfilesystemencoding())
    assert environ._value_cache[os.environ[b'PWD']] == to_text(os.environ[b'PWD'], encoding=sys.getfilesystemencoding())
    # Now, let's try changing PWD.  We're going to do this in a really hacky way but it should
    # work for these purposes.
    environ._value_cache = {}
    pwd = os.getcwd()
    if pwd.endswith('/'):
        pwd

# Generated at 2022-06-11 18:26:50.016534
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # To do:
    # - Test for missing value
    # - Test for value that does not fit in default encoding
    # - Test for value that does not fit in specified encoding
    # - Test for when encoding is None

    test_environ = _TextEnviron({'ascii': 'ascii string', 'unicode': u'unicode string', 'binary': b'binary string'}, encoding='utf8')

    assert 'ascii string' == test_environ['ascii']
    assert u'unicode string' == test_environ['unicode']
    assert u'binary string' == test_environ['binary']

    if PY3:
        assert test_environ._raw_environ['ascii'] == b'ascii string'
        assert test_environ._raw_environ['unicode']

# Generated at 2022-06-11 18:27:00.269919
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from nose.tools import assert_equals

    # Test with the default utf8 encoding
    te = _TextEnviron()


# Generated at 2022-06-11 18:27:10.228850
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import pytest

    # Check returns a value when the value is already a text string
    environ_object = _TextEnviron({'k': 'v'})
    assert environ_object['k'] == u'v'

    # Check returns a value when the value is a binary string and not in the cache
    environ_object = _TextEnviron({'k': b'b'})
    assert environ_object['k'] == u'b'

    # Check returns a value when the value is a binary string and in the cache
    environ_object = _TextEnviron({'k': b'b'})
    assert environ_object['k'] == u'b'
    # Check the value got cached
    assert environ_object._value_cache[b'b'] == u'b'

    # Check raises a KeyError when the

# Generated at 2022-06-11 18:27:21.456923
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test case 1: Set environment variable in python2 os.environ, get value from _TextEnviron
    test_value = 'TEST VALUE'
    if PY3:
        # This is needed for any tests that are run by pytest
        # pytest sets cwd to the root of the project, and defers to os.environ for the
        # LC_ALL / LC_CTYPE values.  os.environ only returns values that are set in the
        # environment.  This makes it impossible to have our tests run as if they were running
        # with a utf-8 locale.
        os.environ['LC_ALL'] = 'C.UTF-8'
        os.environ['LC_CTYPE'] = 'C.UTF-8'
        # os.environ will automatically convert the value to unicode
        #

# Generated at 2022-06-11 18:27:22.263920
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass
    # TODO: place unit test code here

# Generated at 2022-06-11 18:27:32.891832
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test methods __getitem__ of _TextEnviron

    Unit test function for methods __getitem__ in _TextEnviron class.
    """
    # Test for single byte strings
    os.environ['KEY1'] = 'TEST'
    env = _TextEnviron()
    assert 'TEST' == env['KEY1']
    # Test for utf-8 encoded string
    os.environ['KEY2'] = 'PÁSS'.encode('utf-8')
    env = _TextEnviron()
    assert 'PÁSS' == env['KEY2']
    # Test for iso-8859-1 encoded string
    os.environ['KEY3'] = 'PÁSS'.encode('iso-8859-1')
    env = _TextEnviron()

# Generated at 2022-06-11 18:27:35.381572
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    d={'a':'b'}

    def test_case(d):
        t = _TextEnviron(d)

        assert t.__getitem__('a')=='b'

    test_case(d)

# Generated at 2022-06-11 18:27:42.098340
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = {'test1': b'ascii_value', 'test2': u'unicode_value', 'test3': 'ascii_bytes_value'}
    test_environ = _TextEnviron(env=env, encoding='ascii')

    assert test_environ['test1'] == 'ascii_value'
    assert test_environ['test2'] == 'unicode_value'
    assert test_environ['test3'] == 'ascii_bytes_value'



# Generated at 2022-06-11 18:27:55.017540
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # we must use the original os.environ as we need to test that _value_cache is populated
    environ = _TextEnviron(env=os.environ, encoding='utf-8')

    value1 = environ['PATH']
    assert isinstance(value1, str)
    assert value1 == os.environ['PATH']

    value2 = environ['PATH']
    assert isinstance(value2, str)
    assert value2 == os.environ['PATH']
    assert value1 is value2

# Generated at 2022-06-11 18:27:56.054632
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == '/home/badger'



# Generated at 2022-06-11 18:27:58.690433
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_copy = environ.copy()
    # Test both ascii and non ascii
    for text, key in (('ansible testing', 'ASCII_KEY'), ('ŠĐĆŽćžšđ', 'NON_ASCII_KEY')):
        environ_copy._raw_environ[key] = text
        assert text == environ_copy[key]



# Generated at 2022-06-11 18:28:00.316502
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == os.environ['PATH']



# Generated at 2022-06-11 18:28:05.009160
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test for a valid environment variable that is expected to be text
    os.environ['ANSIBLE_TEST_VALUE'] = 'This is a test'
    assert environ['ANSIBLE_TEST_VALUE'] == 'This is a test'

# Generated at 2022-06-11 18:28:13.231705
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # make sure we return a text type
    assert isinstance(environ['PATH'], text_type), \
    'environ[\'PATH\'] must be of type %s, but got %s instead' % (str(text_type), str(type(environ['PATH'])))

    # make sure it's safe to use the encoded form of a string
    os.environ['TEST_ONE'] = b'\xc2\xa2'
    assert environ['TEST_ONE'] == u'\xa2', \
    'environ[\'TEST_ONE\'] must return %s, but got %s instead' % (u'\xa2', environ['TEST_ONE'])

    # make sure we don't error on a str on py3
    os.environ['TEST_TWO'] = 'foo'
   

# Generated at 2022-06-11 18:28:22.358885
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:28:27.156518
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['TEST'] = 'Foo'
    assert environ['TEST'] == 'Foo'
    if not PY3:
        environ['TEST'] = b'\xe9'
        assert environ['TEST'] == '\u00e9'


# Generated at 2022-06-11 18:28:37.808191
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    _raw_environ = {b'foo': b'bar',
                    b'baz': b'qux',
                    b'quux': b'quuz',
                    }

    environ = _TextEnviron(env=_raw_environ, encoding='utf-8')

    assert environ[b'foo'] == u'bar'
    assert environ[b'baz'] == u'qux'
    assert environ[b'quux'] == u'quuz'

    new_environ = _TextEnviron(encoding='utf-8')

    try:
        new_environ[b'value']
    except KeyError:
        pass
    else:
        assert False, "KeyError for value not in environment not raised."

    return True


# Generated at 2022-06-11 18:28:41.182443
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['FOOBAR'] == ''

    os.environ['FOOBAR'] = 'bar'
    assert environ['FOOBAR'] == 'bar'



# Generated at 2022-06-11 18:29:09.540710
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Given : a text encoded in ISO8859-1
    # When : I get the corresponding value from environ
    # Then : I see the text as a unicode string
    assert prop._TextEnviron({b'key': '\xe9'.encode('iso8859-1')})['key'] == '\xe9'
    # Given : a text encoded in UTF-8
    # When : I get the corresponding value from environ
    # Then : I see the text as a unicode string
    assert prop._TextEnviron({b'key': '\xe9'.encode('utf-8')})['key'] == '\xe9'



# Generated at 2022-06-11 18:29:11.117838
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    d = _TextEnviron()
    assert d['PATH'] == environ['PATH']

# Generated at 2022-06-11 18:29:16.559906
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['FOO'] = 'bar'
    assert environ['FOO'] == 'bar'
    os.environ['FOO'] = b'bar'
    assert environ['FOO'] == 'bar'
    os.environ['FOO'] = 'bar'
    assert environ['FOO'] == 'bar'
    os.environ['FOO'] = 'bar\xff'
    assert environ['FOO'] == 'bar\ufffd'


# Generated at 2022-06-11 18:29:23.441629
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test if change in value of an environment variable is handled correctly
    environ.clear()
    del os.environ['PATH']
    os.environ['PATH'] = b'/usr/bin'
    environ['PATH'] = '/usr/bin'
    assert environ['PATH'] == u'/usr/bin'
    os.environ['PATH'] = b'/usr/bin:/usr/local/bin'
    assert environ['PATH'] == u'/usr/bin:/usr/local/bin'

# Generated at 2022-06-11 18:29:28.995298
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # setting up _raw_environ, _value_cache
    environ._raw_environ = {b'ANSIBLE_REMOTE_TMP': b"/tmp",
                            b'TERM': b'dumb'}
    environ._value_cache = {}
    environ.encoding = 'utf-8'

    assert environ[b'ANSIBLE_REMOTE_TMP'] == u"/tmp"
    assert environ[b'TERM'] == u"dumb"

    assert environ[u'ANSIBLE_REMOTE_TMP'] == u"/tmp"
    assert environ[u'TERM'] == u"dumb"



# Generated at 2022-06-11 18:29:39.549995
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:29:44.764484
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    orig_os_environ = os.environ
    try:
        os.environ = {b'foo': b'bar', u'baz': u'bat'}  # Python 2: Ignore unicode_literals
        te = _TextEnviron(env=os.environ)
        assert 'bar' == te['foo']
        assert 'bat' == te['baz']
    finally:
        os.environ = orig_os_environ

# Generated at 2022-06-11 18:29:49.860802
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert type(environ) is _TextEnviron
    environ.__init__({b'ansible_default_python_version': b'3.6',
                      b'ansible_python_interpreter': b'python3'},
                     encoding='utf-8')
    assert environ[b'ansible_default_python_version'] == u'3.6'
    assert environ[b'ansible_python_interpreter'] == u'python3'



# Generated at 2022-06-11 18:30:00.101621
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os

    # Set up tests
    # simple test, just string
    os.environ['TEST_SIMPLE'] = u'test'
    # iso-8859-1 with 'høy'
    os.environ['TEST_ISO88591'] = u'Dette er et test med høy'.encode('iso-8859-1')
    # shift-jis with '日本語'
    os.environ['TEST_SHIFTJIS'] = u'これは日本語です'.encode('shift-jis')
    # utf-8 with '日本語'
    os.environ['TEST_UTF8'] = u'これは日本語です'.encode('utf-8')
    # surrogate-escape encoding

# Generated at 2022-06-11 18:30:07.386108
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with PY3=False
    test_environ = _TextEnviron(env={b'key1': b'value1', b'key2': b'value2'}, encoding='utf-8')
    result = test_environ[b'key1']
    assert isinstance(result, type(u''))
    assert result == u'value1'
    result = test_environ[b'key2']
    assert isinstance(result, type(u''))
    assert result == u'value2'

    # Test with PY3=True
    test_environ = _TextEnviron(env={'key1': 'value1', 'key2': 'value2'}, encoding='utf-8')
    result = test_environ['key1']
    assert isinstance(result, type(u''))

# Generated at 2022-06-11 18:31:00.652091
# Unit test for method __getitem__ of class _TextEnviron