

# Generated at 2022-06-11 18:21:10.479766
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Tests for codecs that cannot store the initial raw_environ value verbatim
    # and will have to use surrogateescape to do so.
    try:
        from unittest import mock
    except ImportError:
        import mock

    _raw_environ = {'LATIN_1_STRING': b'\x80',
                    'UTF_8_STRING': b'\xed\xb0\x80'}
    _encoding = 'latin-1'


# Generated at 2022-06-11 18:21:19.278953
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # verify behavior with unicode characters in environ
    environ['LC_ALL'] = 'C.UTF-8'
    assert environ['LC_ALL'] == 'C.UTF-8'
    assert type(environ['LC_ALL']) == str

    # verify behavior with byte strings on PY3
    if PY3:
        os.environ['TEST_VAR'] = b'test'
        assert environ['TEST_VAR'] == 'test'
        assert type(environ['TEST_VAR']) == str
        del os.environ['TEST_VAR']

    # verify behavior with byte strings on PY2
    if not PY3:
        os.environ['TEST_VAR'] = 'test'
        assert environ['TEST_VAR'] == 'test'


# Generated at 2022-06-11 18:21:29.592699
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils._text import to_bytes, to_text

    environ = _TextEnviron({
        'A': 'B',
        to_bytes('C', encoding='utf-8'): to_bytes('D', encoding='utf-8'),
        'E': to_bytes('F', encoding='utf-8'),
        'G': b'H',
    })
    expected_env = OrderedDict([('A', 'B'), ('C', 'D'), ('E', 'F'), ('G', 'H')])
    assert(environ == expected_env)

# Generated at 2022-06-11 18:21:31.643113
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['test_key'] = 'test_value'
    assert environ['test_key'] == 'test_value'


# Generated at 2022-06-11 18:21:39.502659
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    testenviron = _TextEnviron({b'ANSIBLE_TEST_ENCODING': b'utf-8'})
    assert(isinstance(testenviron['ANSIBLE_TEST_ENCODING'], unicode))
    assert(testenviron['ANSIBLE_TEST_ENCODING'] == u'utf-8')

    testenviron['ANSIBLE_TEST_ENCODING'] = b'\xe3\x80\x8a\xe4\xba\xba\xe9\x96\x93\xe3\x80\x8b\xe3\x81\xae\xe4\xba\xba\xe9\x96\x93'

# Generated at 2022-06-11 18:21:44.827390
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_test = _TextEnviron({'test': 'TEST'})
    # Check if string is returned
    assert isinstance(environ_test.__getitem__('test'), str)
    # Check if value is correct
    assert environ_test.__getitem__('test') == 'TEST'
    # Check if second value is correct
    assert environ_test.__getitem__('test') == 'TEST'


# Generated at 2022-06-11 18:21:50.827997
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from sys import version_info

    os.environ.clear()
    os.environ.update({
        'ascii': 'ascii_value',
        'utf8': 'utf8_value',
        'utf8_c1': '\xc3',
        'utf8_c2': '\xc3\x97',
    })
    try:
        environ._raw_environ['utf8_cp1252'] = '\xe9'
        environ._raw_environ['utf8_cp1252_c2'] = '\xe9\x97'
    except UnicodeEncodeError:
        pass


# Generated at 2022-06-11 18:21:59.087398
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['A'] = ''
    # assure that '' is not stored as u''
    assert environ['A'] == ''
    environ['B'] = "text"
    assert environ['B'] == "text"
    environ['C'] = u"text"
    assert environ['C'] == "text"
    environ['D'] = u"\u1234"
    assert environ['D'] == u"\u1234"

if __name__ == '__main__':
    test__TextEnviron___getitem__()

# Generated at 2022-06-11 18:22:03.779752
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    _environ = _TextEnviron(encoding='utf-8')
    _environ['key'] = u'値'
    assert _environ['key'] == u'値'
    _environ['key'] = u'\uDC81'
    assert _environ['key'] == u'\ufffd'


# Generated at 2022-06-11 18:22:15.975532
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set up test environment
    def _unset(key):
        try:
            environ.pop(key)
        except KeyError:
            pass
    _unset('TEST_TEXTENVIRON_UNICODE')
    _unset('TEST_TEXTENVIRON_BYTES')
    _unset('TEST_TEXTENVIRON_INVALID')
    os.environ['TEST_TEXTENVIRON_UNICODE'] = u'L\u00E8mure'
    os.environ['TEST_TEXTENVIRON_BYTES'] = b'L\xC3\xA8mure'
    os.environ['TEST_TEXTENVIRON_INVALID'] = b'L\xC3mure'

    # Test expected success cases

# Generated at 2022-06-11 18:22:24.161867
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import unittest
    from ansible.module_utils.six import StringIO

    class TestTextEnviron(unittest.TestCase):

        def setUp(self):
            self.key = 'TEST_ENV'
            self.value = 'TEST_VALUE'
            os.environ[self.key] = self.value
            self.old_stdout = sys.stdout
            self.old_stderr = sys.stderr
            self.old_env = os.environ
            self.mock_stdout = StringIO()
            self.mock_stderr = StringIO()
            self.environ_new = _TextEnviron()

        def tearDown(self):
            sys.stdout = self.old_stdout
            sys.stderr = self.old

# Generated at 2022-06-11 18:22:33.452192
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # NOTE: isinstance(obj, MutableMapping) doesn't work for six._MovedItems, so for purposes of
    # testing we'll define a new class here.
    class __MutableMapping(MutableMapping):
        pass

    if not isinstance(environ, __MutableMapping):
        raise AssertionError("Environ should be a MutableMapping")

    environ_saved = environ._raw_environ
    environ._raw_environ = {
        "no_encoding": b"no_encoding",
        "ascii_encoding": b"ascii_encoding",
        "utf8_encoding": b"utf8_encoding",
        "latin1_encoding": b"latin1_encoding",
    }
    # PY3: nothing to

# Generated at 2022-06-11 18:22:41.212302
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import _in_doctest_environment

    if not _in_doctest_environment():
        # There's no good way to test duplicate keys in the environment without the doctest
        # environment.  Only add the duplicate key test if we're in the doctest environment.
        return

    # Make a copy of the os.environ object
    original_environ = {}
    for key, value in os.environ.items():
        if PY3:
            original_environ[key] = value
        else:
            original_environ[to_text(key, encoding='utf-8', errors='surrogate_or_strict')] = \
                    to_text(value, encoding='utf-8', errors='surrogate_or_strict')

    # Put duplicate keys into our custom

# Generated at 2022-06-11 18:22:44.756273
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a new instance of class _TextEnviron
    obj = _TextEnviron()

    # Call the method __getitem__
    result = obj.__getitem__('')

    assert result == ''



# Generated at 2022-06-11 18:22:53.010396
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import ansible.module_utils.six as six
    import copy
    environ = _TextEnviron()
    # if we are on python3, we can just use os.environ
    if six.PY3:
        environ._raw_environ = os.environ
    # We will use the accuracy of os.environ as the gold standard
    environ_gold = copy.deepcopy(os.environ)

    # Now for a variety of different key conditions check that we return the same as os.environ
    # First try a key that is not in our _raw_environ
    try:
        environ['key-not-in-environ']
    except KeyError:
        pass
    else:
        assert 0, "Should raise KeyError"

    # Now try a key that is in our _raw_environ but

# Generated at 2022-06-11 18:23:02.464912
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Test the __getitem__ method of the TextEnviron class."""

    # Set os.environ to empty
    os.environ = {}

    # Try to get an item which is not set
    assert environ['notset'] == ''

    # Set an encoded variable
    os.environ = {to_bytes('ascii_key', encoding='ascii', errors='surrogate_or_strict'):
                      to_bytes('ascii_value', encoding='ascii', errors='surrogate_or_strict')}

    # Try to get an ascii encoded variable
    assert environ['ascii_key'] == 'ascii_value'

    # Set an encoded variable

# Generated at 2022-06-11 18:23:13.911039
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_test = _TextEnviron(env={'test_value_bytes': b'abc\xe2\x98\x83'})
    assert environ_test[b'test_value_bytes'] == 'abc\u2603'
    assert environ_test['test_value_bytes'] == 'abc\u2603'

    environ_test = _TextEnviron(env={'test_value_bytes': b'abc\xe2\x98\x83', 'test_value_text': 'abc\u2603'})
    assert environ_test[b'test_value_bytes'] == 'abc\u2603'
    assert environ_test['test_value_bytes'] == 'abc\u2603'
    assert environ_test[b'test_value_text'] == 'abc\u2603'

# Generated at 2022-06-11 18:23:25.525660
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # "bytes" should be in the cache so that no conversion occurs
    environ.__setitem__('b', b'bytes')
    assert 'b' in environ
    assert environ['b'] == 'bytes'
    assert environ._value_cache[b'bytes'] == 'bytes'

    # "text" should be in the cache so that no conversion occurs
    environ.__setitem__('t', 'text')
    assert 't' in environ
    assert environ['t'] == 'text'
    assert environ._value_cache[b'text'] == 'text'

    # Here we're testing when the encoding does not match the actual value
    # Instead of re-encoding, we'll use the cached value
    environ.__setitem__('u', '\u263a')
    assert 'u' in environ

# Generated at 2022-06-11 18:23:35.031623
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    #
    # Create a dictionary with key-value pairs in bytes on Python2 since we are going to test
    # against the raw dictionary.
    #
    if PY3:
        raw_dict = {to_text('key1'): to_text('value1'), to_text('key2'): to_text('value2')}
    else:
        raw_dict = {to_bytes('key1'): to_bytes('value1'), to_bytes('key2'): to_bytes('value2')}
    text_environ = _TextEnviron(raw_dict)
    assert len(text_environ) == 2
    #
    # Ensure that _TextEnviron instance behaves like a dict
    #
    # Get key that exists in the dict, with a value that's legal utf-8

# Generated at 2022-06-11 18:23:39.750458
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(env={b'ANSIBLE_MODULES': b'foo bar baz'}, encoding='utf-8')
    assert env[b'ANSIBLE_MODULES'] == u'foo bar baz'
    assert env[u'ANSIBLE_MODULES'] == u'foo bar baz'

# Generated at 2022-06-11 18:23:47.581561
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(env={'test1': 'abc', 'test2': b'abc', 'test3': '\xe2\xb8\x83'})
    assert environ['test1'] == 'abc'
    assert environ['test2'] == 'abc'
    assert environ['test3'] == '\u2083'

# Generated at 2022-06-11 18:23:55.977478
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.compat.tests.mock import patch
    import sys
    import io

    # Note: The method __getitem__ has to be tested before environ is set to _TextEnviron
    # Make sure that the tests are run from source
    if os.path.exists(__file__):
        testfileDir = os.path.dirname(os.path.realpath(__file__))
    else:
        testfileDir = os.path.dirname(os.path.realpath('__file__'))
    assert os.path.isdir(testfileDir)

# Generated at 2022-06-11 18:24:00.438110
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    r"""
    This section tests if the desired items are returned by __getitem__
    method of class _TextEnviron
    """
    assert isinstance(environ['HOME'], str)

    test_env = _TextEnviron()
    test_env['HOME'] = 'foo'
    assert test_env['HOME'] == 'foo'


# Generated at 2022-06-11 18:24:06.862910
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Mock os.environ on the _TextEnviron class
    _TextEnviron._raw_environ = {'ANSIBLE_TEST_KEY_1': 'ANSIBLE_TEST_VALUE_1',
                                 'ANSIBLE_TEST_KEY_2': 'ANSIBLE_TEST_VALUE_2'}
    assert u'ANSIBLE_TEST_VALUE_1' == environ[u'ANSIBLE_TEST_KEY_1']
    assert u'ANSIBLE_TEST_VALUE_2' == environ[u'ANSIBLE_TEST_KEY_2']


# Generated at 2022-06-11 18:24:11.642858
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Set _TextEnviron._value_cache and _TextEnviron._raw_environ to some predefined value
    os.environ["TEST"] = "test_text"

    # Test the method __getitem__ of class _TextEnviron
    assert(environ.__getitem__("TEST") == "test_text")

# Generated at 2022-06-11 18:24:14.904106
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['var'] = b'\xe2\x9d\xa4'
    assert environ['var'] == '♥'

    del environ['var']



# Generated at 2022-06-11 18:24:24.134385
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test the default TextEnviron object
    assert isinstance(environ['PATH'], str)

    # Test the __init__ method with various valid encodings
    assert isinstance(_TextEnviron(encoding='utf-8')['PATH'], str)
    assert isinstance(_TextEnviron(encoding='ISO8859-1')['PATH'], str)
    assert isinstance(_TextEnviron(encoding='ascii')['PATH'], str)

    # Test the __init__ method with alternate data
    alternate_env = {'TEST': 'TEST'}
    assert isinstance(_TextEnviron(env=alternate_env)['TEST'], str)

    # Test the __init__ method with invalid encodings

# Generated at 2022-06-11 18:24:27.658808
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        _TextEnviron(env={to_bytes('a'): to_bytes('b', encoding='utf-8')})['a']
    except:
        return False
    else:
        return True

# Generated at 2022-06-11 18:24:30.989900
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'foo': b'bar'}, encoding='utf-8')
    assert env['foo'] == u'bar'



# Generated at 2022-06-11 18:24:37.257356
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = {
        'foo': 'bar',
        b'baz': 'buzz',
        'weird': b'\xed'
    }
    environ = _TextEnviron(test_environ, encoding='utf-8')

    assert environ['foo'] == 'bar'
    assert environ['baz'] == 'buzz'
    assert environ['weird'] == u'\xed'



# Generated at 2022-06-11 18:24:49.991122
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import types
    import random
    import string
    import timeit
    from ansible.module_utils.common._collections_compat import MutableMapping

    environ = _TextEnviron()

    assert isinstance(environ, MutableMapping), "environ is of type '%s', not 'dict'" % type(environ)

    # When requesting a key that is not present in the environment, a KeyError should be raised
    with pytest.raises(KeyError):
        dummy = environ['testKey']

    # When requesting a key that is present in the environment, the value should be returned.
    # The value should be a text object
    value = ''.join(random.choice(string.ascii_uppercase) for _ in range(10))
    os.environ['testKey'] = value

# Generated at 2022-06-11 18:24:52.136170
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    assert env['PATH'] == os.environ['PATH']



# Generated at 2022-06-11 18:25:02.215313
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test that __getitem__ returns text strings from the environment instead of byte strings
    """
    environ = _TextEnviron(encoding='utf-8')

    # Test property __getitem__
    assert environ['PWD'] == to_text(os.environ['PWD'], encoding='utf-8', nonstring='passthru',
                                     errors='surrogate_or_strict')

    # Test property __getitem__ in case incorrect key name is passed
    try:
        environ['invalid_key']
    except KeyError as ex:
        assert ex.__class__.__name__ == 'KeyError'
        assert ex.args[0] == 'invalid_key'
    except Exception as ex:
        assert False, 'unexpected exception raised: %s' % repr(ex)

# Generated at 2022-06-11 18:25:13.730465
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from subprocess import check_output
    from os import environ
    from ansible.module_utils._text import to_text

    os_encoding = check_output(['locale', 'charmap']).strip().decode('ascii')
    environ['LC_ALL'] = 'C.UTF-8'


# Generated at 2022-06-11 18:25:16.184590
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({to_bytes('test'): to_bytes('testing')})

    assert env['test'] == to_text(to_bytes('testing'))



# Generated at 2022-06-11 18:25:25.474945
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six.moves.urllib.parse import quote

    # setup of the test
    ascii_text = 'abcdefghijklmnopqrstuvwxyz'
    ascii_text_bytes = to_bytes(ascii_text)
    ascii_text_bytes_hex = '{0:x}'.format(int.from_bytes(ascii_text_bytes, byteorder='big'))
    unicode_text = u'\u2713'
    unicode_text_bytes = to_bytes(unicode_text)
    unicode_text_utf8 = unicode_text.encode('utf-8')

# Generated at 2022-06-11 18:25:36.331238
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import json
    import os

    # Set up the environment variable with a value that should fail encoding
    badvalue = u'\xe9'
    testkey = 'test_b'
    os.environ[testkey] = badvalue.encode('latin-1')
    os.putenv(testkey, badvalue.encode('latin-1'))

    # Test whether the bad value can be decoded with the default options
    assert to_text(badvalue.encode('latin-1'), errors='surrogate_or_strict') == badvalue

    # Test whether the bad value can be decoded with the default options
    assert to_text(badvalue.encode('latin-1'), errors='surrogate_or_strict') == badvalue

    # Test whether the bad value can be decoded when trying to use

# Generated at 2022-06-11 18:25:45.275639
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Mimic os.environ on python3, we are using sys.getfilesystemencoding()
    # instead of utf-8
    b_utf8_value = to_bytes(u'\u5B5C', encoding='utf-8')
    b_surrogate_value = to_bytes(u'\ud6b1', encoding='utf-8')
    b_cp437_value = to_bytes(u'\u5B5C', encoding='cp437')
    b_woe_value = to_bytes(u'\u5B5C\ud6b1', encoding='utf-8', errors='ignore')
    b_woe_value2 = to_bytes(u'\u5B5C\ud6b1', encoding='utf-8', errors='replace')
    b_woe_value3

# Generated at 2022-06-11 18:25:48.291874
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # TODO: We should probably have some tests for py2k but for now this
    # should be sufficient.
    assert environ['HOME'] == os.environ['HOME']

# Generated at 2022-06-11 18:25:55.572009
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a non-unicode environment
    byte_env_key = 'KEY_WITH_BYTE_VALUE'
    byte_env_value = b'\xC3\xB6'  # 'ö' in utf-8
    byte_env_text_value = u'\xf6'  # 'ö' in unicode
    byte_env = {byte_env_key: byte_env_value}
    byte_env_mapping = _TextEnviron(env=byte_env, encoding='utf-8')

    assert byte_env_text_value == byte_env_mapping[byte_env_key]

    # Test with a unicode environment
    text_env_key = u'KEY_WITH_UNICODE_VALUE'
    text_env_value = u'\xf6'  # 'ö

# Generated at 2022-06-11 18:26:05.234649
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({
        b'ascii': b'asciistring',
        b'non_ascii': '\xc3\xad'.encode('utf-8'),
    })

    assert isinstance(environ[b'ascii'], to_text)
    assert environ[b'ascii'] == 'asciistring'

    assert isinstance(environ[b'non_ascii'], to_text)
    assert environ[b'non_ascii'] == 'í'

# Generated at 2022-06-11 18:26:12.293002
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron({'foo': 'bar'})
    assert e['foo'] == 'bar'

    e = _TextEnviron({'foo': 'bar', 'baz': b'buzz'})
    assert e['foo'] == 'bar'
    assert e['baz'] == 'buzz'

    e = _TextEnviron({'foo': 'bar', 'baz': u'buzz'})
    assert e['foo'] == 'bar'
    assert e['baz'] == 'buzz'

# Generated at 2022-06-11 18:26:19.120715
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    :ansible_collections:
      :devops_common:

    Functional test for attribute __getitem__ of module __TextEnviron
    """
    i = _TextEnviron(env=dict(TEST_VAR='TEST_CONF_OK'))
    print(i.encoding)
    assert i['TEST_VAR'] == 'TEST_CONF_OK'
    i.encoding = 'utf-8'
    assert i['TEST_VAR'] == 'TEST_CONF_OK'
    i.encoding = 'utf-16'
    assert i['TEST_VAR'] == 'TEST_CONF_OK'
    i.encoding = 'utf-32'
    assert i['TEST_VAR'] == 'TEST_CONF_OK'

# Generated at 2022-06-11 18:26:28.287025
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This function needs to be in the __main__ namespace because things in __main__ can only be
    # imported into the __main__ namespace.
    import os

    with open(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'charmap'), 'rb') as f:
        charmap = f.read().decode('utf-8').rstrip()

    environ['TEST_US_ASCII'] = b'test'
    assert environ['TEST_US_ASCII'] == u'test'
    environ['TEST_LATIN_1'] = 't\xe9st'.encode('latin-1')
    assert environ['TEST_LATIN_1'] == u't\xe9st'

# Generated at 2022-06-11 18:26:38.901620
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Since the _TextEnviron class is a wrapper, it should contain the same keys as os.environ
    #    and return the same values as os.environ when using bytes keys
    os.environ['WORKING'] = b'\xe2\x9c\x93'
    te = _TextEnviron()
    assert os.environ['WORKING'] == te['WORKING']
    # On Python2, it should also return the same values as os.environ when using text keys
    if not PY3:
        assert os.environ['WORKING'] == te[u'WORKING']

    # On Python3, os.environ returns text strings
    # The values of all keys should be decoded as utf-8 and cached
    if PY3:
        assert isinstance(te[b'WORKING'], str)


# Generated at 2022-06-11 18:26:43.385996
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'foo': to_text(b'bar', nonstring='passthru', errors='surrogate_or_strict')})
    assert environ['foo'] == 'bar'
    assert b'bar' in environ._value_cache

# Generated at 2022-06-11 18:26:50.968616
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Init class
    enc = 'utf-8'
    env = {'key1': 'Text', 'key2': b'Bytes'}
    te = _TextEnviron(env=env, encoding=enc)
    # Test key which is native text string
    assert te['key1'] == 'Text'
    # Test key which is byte string
    if PY3:
        assert te['key2'] == b'Bytes'
    else:
        assert te['key2'] == 'Bytes'


# Generated at 2022-06-11 18:26:55.743734
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class FakeEnviron:
        def __getitem__(self, item):
            if item == 'a':
                return b'\xE5\xB0\x8F'
            raise KeyError

    env = _TextEnviron(FakeEnviron())
    assert env['a'] == u'\u5c0f'
    assert env['a'] is env['a']

# Generated at 2022-06-11 18:27:02.537814
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['test'] = 'a'
    assert 'a' == environ['test']
    environ['test'] = 'a\n'
    assert 'a\n' == environ['test']
    environ['test'] = 'a\n\n'
    assert 'a\n\n' == environ['test']
    environ['test'] = 'a\r'
    assert 'a\r' == environ['test']
    environ['test'] = 'a\r\n'
    assert 'a\r\n' == environ['test']
    environ['test'] = 'a\xa3'
    assert 'a\xa3' == environ['test']
    environ['test'] = 'a\xa3\xa3'
    assert 'a\xa3\xa3' == environ

# Generated at 2022-06-11 18:27:03.982705
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == '/home/toshio'


# Generated at 2022-06-11 18:27:17.912148
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ._raw_environ.clear()
    environ.encoding = 'ascii'
    environ._raw_environ['foo'] = b'bar'
    assert environ['foo'] == 'bar'


# Generated at 2022-06-11 18:27:23.993799
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This test assumes that the filesystem encoding on the test system is 'utf-8'
    # NOTE: It would be nice to be able to test other encodings but the encoding
    #       is currently hardcoded in _TextEnviron's __init__ method.  This test
    #       should be modified when that encoding is parameterized.
    unset_env = {}
    # By default, the env var has no value
    assert environ['TEST_VAR'] == ''
    # If we set the env var to a unicode value, we get the same value back
    # (this is a feature of os.environ on Python3)
    unset_env['TEST_VAR'] = u'\u2603'
    assert environ['TEST_VAR'] == u'\u2603'
    # If we set the env var to

# Generated at 2022-06-11 18:27:25.775628
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ["PATH"] == u"/bin:/usr/bin"

# Generated at 2022-06-11 18:27:34.912070
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Case1
    # Test with default class creation
    environ_object = _TextEnviron()
    key = 'PATH'
    if sys.version_info < (3, 0):
        assert environ_object.__getitem__(key) == os.environ.__getitem__(key).decode(sys.getfilesystemencoding())
    else:
        assert environ_object.__getitem__(key) == os.environ.__getitem__(key)

    # Case2
    # Test with default class creation but with different encoding
    environ_object = _TextEnviron(encoding='utf-8')
    key = 'PATH'

# Generated at 2022-06-11 18:27:45.044787
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Test if method __getitem__ of class _TextEnviron returns unicode values on Python2 and bytes
    on Python3
    """

# Generated at 2022-06-11 18:27:52.049832
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Replace _TextEnviron._raw_environ with object that has __getitem___ method
    class Mock_raw_environ(object):
        def __init__(self):
            self.var = {}

        def __getitem__(self, key):
            return self.var[key]

    # Create _TextEnviron object
    obj = _TextEnviron(env=Mock_raw_environ())

    # Set value for given key
    obj.var['key'] = 'value'
    # Check expected key
    assert obj['key'] == 'value'

# Generated at 2022-06-11 18:27:53.758877
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ.get('PYTHONIOENCODING') == 'UTF-8'


# Generated at 2022-06-11 18:27:55.626357
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Check that class _TextEnviron returns a text string from the environment
    # instead of a byte string
    assert isinstance(environ['PATH'], str)

# Generated at 2022-06-11 18:28:02.024210
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2
    environ = _TextEnviron(encoding='utf-8')
    environ[u'TEST_KEY'] = u'test'
    assert environ[u'TEST_KEY'] == u'test'
    assert isinstance(environ[u'TEST_KEY'], unicode)
    if PY2:
        assert environ[u'TEST_KEY'].encode('utf-8') == b'test'
    # Verify surrogates are encoded properly
    tup_utf8 = (u'\uDC68\uDCCB\uDCD0\uDCBB\uDC68\uDCCB', 'utf-8')

# Generated at 2022-06-11 18:28:06.917143
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    x = _TextEnviron(encoding='ascii', env={b'x': b'\xe4'})
    assert x[b'x'] == '\xe4'
    assert type(x[b'x']) is str
    assert x[b'foo'] == ''
    assert type(x[b'foo']) is str

# Generated at 2022-06-11 18:28:28.989902
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-11 18:28:40.266124
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import pytest
    utf8_test_var = b'\xF0\x9F\x92\xA9'
    latin1_test_var = b'\xFE'
    nonascii_test_var = b'\x01'

    os.environ[utf8_test_var] = utf8_test_var
    os.environ[latin1_test_var] = latin1_test_var
    os.environ[nonascii_test_var] = nonascii_test_var

    # utf-8 by default
    for k, v in os.environ.items():
        # Python2
        if not PY3:
            assert isinstance(k, bytes)
            assert isinstance(v, str)

# Generated at 2022-06-11 18:28:47.709177
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['UNITTEST_ENCODING_INVALID_KEY'] == to_text('ФЫВАфыва', encoding='utf-8',
                                                               nonstring='passthru',
                                                               errors='surrogate_or_strict')
    assert environ['UNITTEST_ENCODING_INVALID_KEY'] == to_text('ФЫВАфыва', encoding='utf-8',
                                                               nonstring='passthru',
                                                               errors='surrogate_or_strict')
    assert environ['UNITTEST_ENCODING_VALID_KEY'] == u'Foo'
    assert environ['UNITTEST_ENCODING_VALID_KEY'] == u'Foo'
    # Cache

# Generated at 2022-06-11 18:28:55.691267
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import pytest
    environ['LANG'] = 'en_US.UTF-8'
    assert environ['LANG'] == u'en_US.UTF-8'
    # Test that it's memoized now
    environ._raw_environ['LANG'] = 'foo_bar.baz'
    assert environ['LANG'] == u'en_US.UTF-8'
    # Test for ASCII string
    environ['LANG'] = 'foo_bar.ASCII'
    assert environ['LANG'] == u'foo_bar.ASCII'
    # Test for a surrogate pair
    environ['LANG'] = u'foo_bar.\U0001f602'
    assert environ['LANG'] == u'foo_bar.\U0001f602'
    # Test for a surrogate pair that then gets

# Generated at 2022-06-11 18:28:59.861156
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Arrange
    t_e = _TextEnviron()
    old_environ = os.environ

    # Act

    # Assert
    assert t_e['PATH'] == old_environ['PATH']


# Generated at 2022-06-11 18:29:00.931427
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Should not raise any exceptions
    # In particular, this should not raise UnicodeDecodeError
    assert isinstance(environ['PATH'], str)

# Generated at 2022-06-11 18:29:02.389281
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    result = environ['HOME']
    assert isinstance(result, unicode)



# Generated at 2022-06-11 18:29:06.127621
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['USER']
    assert "abc" == environ.get('abc', "abc")
    assert environ['abc'] == environ.get('abc', "abc")
    assert "abc" == environ.setdefault('abc', "abc")
    assert environ['abc'] == environ.setdefault('abc', "def")


# Generated at 2022-06-11 18:29:06.947394
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['TESTENVVAR'] == ''

# Generated at 2022-06-11 18:29:16.844030
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Positive tests
    # Value is bytes
    environ = _TextEnviron({b"value_is_bytes": b"abc"})
    assert environ[b"value_is_bytes"] == u"abc"
    # Value is text
    environ = _TextEnviron({b"value_is_text": u"abc"})
    assert environ[b"value_is_text"] == u"abc"
    # Value is non-ASCII
    environ = _TextEnviron({b"value_is_bytes": b"\xF0\x9F\x88\xB4"})
    assert environ[b"value_is_bytes"] == u"\U0001F004"
    # Key is text

# Generated at 2022-06-11 18:30:12.643053
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import PY3
    from io import StringIO

    # Set up a dict with some binary values

# Generated at 2022-06-11 18:30:17.412610
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    envir = _TextEnviron(env={'LEO': 'LION', 'FISH': 'BASS'}, encoding='utf-8')
    result = envir['FISH']
    assert result.__class__ == u'BASS'.__class__
    assert result == u'BASS'

# Generated at 2022-06-11 18:30:22.195548
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # setup
    environ = _TextEnviron()

    # test non string value
    environ[u'TEST_KEY'] = 42
    assert environ[u'TEST_KEY'] == u'42'
    assert type(environ[u'TEST_KEY']) == unicode


# Generated at 2022-06-11 18:30:30.637251
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ.clear()
    dict.__setitem__(environ, 'non-unicode', b'\x80')
    dict.__setitem__(environ, 'none-unicode-utf-8', '\x80')
    dict.__setitem__(environ, 'unicode', u'\u20ac')

    # Check ascii, unicode, and bytes.  All of these should be returned as unicode.
    assert environ['non-unicode'] == u'\u20ac'
    assert environ[b'non-unicode'] == u'\u20ac'
    assert environ[u'non-unicode'] == u'\u20ac'

    # If a value can be decoded as utf-8 then it will be returned as a unicode string

# Generated at 2022-06-11 18:30:40.170006
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:30:45.144200
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print('\nTest method __getitem__')
    environ = _TextEnviron()
    for c in [b'ascii', b'utf8', b'utf16']:
        environ['key'] = c
        print('Value is %s' % environ['key'])
        assert(isinstance(environ['key'], str))

# Generated at 2022-06-11 18:30:53.522962
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    u'''
    If `self._value_cache` doesn't have the key,
    then a new key should be created in `self._value_cache` with the value returned.
    For example, if GET_TEXT_ENCODING is set to 'utf-8', u'abc' will be returned.
    '''
    import io
    from ansible.module_utils.six import text_type

    os.environ['GET_TEXT_ENCODING'] = 'utf-8'
    os.environ['ENCODING_TEST_VAR'] = u'abc'

    get_text_env = _TextEnviron(encoding=os.environ['GET_TEXT_ENCODING'])
    # Initial value of self._value_cache is empty
    assert get_text_env._value_cache == {}

    # A new

# Generated at 2022-06-11 18:31:03.273416
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global environ
    # case 1. byte of 'utf-8'
    environ = _TextEnviron({'my_var': 'b1'}, encoding='utf-8')
    assert environ['my_var'] == u'b1'
    # case 2. byte of 'us-ascii'
    environ = _TextEnviron({'my_var': 'b2'}, encoding='us-ascii')
    assert environ['my_var'] == u'b2'
    # case 3. byte of 'utf-16'
    environ = _TextEnviron({'my_var': 'b3'}, encoding='utf-16')
    assert environ['my_var'] == u'b3'
    # case 4. unicode of 'utf-8'