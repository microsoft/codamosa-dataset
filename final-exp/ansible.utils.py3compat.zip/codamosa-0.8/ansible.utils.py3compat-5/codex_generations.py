

# Generated at 2022-06-11 18:21:02.826809
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        # In Python3, os.environ already returns text strings
        assert 'HOME' in environ
        assert isinstance(environ['HOME'], str)
    else:
        # In Python2, os.environ returns bytes when we're in a venv
        assert 'HOME' in environ
        assert isinstance(environ['HOME'], str)
if not PY3:
    test__TextEnviron___getitem__()

# Generated at 2022-06-11 18:21:06.694431
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env.encoding = 'utf-8'
    env['foo'] = 'bär'
    assert env['foo'] == 'bär'

# Generated at 2022-06-11 18:21:17.630571
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This test for __getitem__ mimics the tests for os.environ.__getitem__ in Python 3.5.
    # First, assume that the system and the tests are all in utf-8
    # Note that we can't use the actual os.environ for this test because it's already
    # decoded.
    enc = sys.getfilesystemencoding()
    test_environ = _TextEnviron(dict([(to_bytes('a', enc), to_bytes('b', enc))]), enc)
    # Already unicode -> pass through
    assert test_environ['a'] == u'b'

    # Make sure we can get the key even if it's in the cache
    test_environ._value_cache[to_bytes('a', enc)] = u'c'
    assert test_environ['a'] == u

# Generated at 2022-06-11 18:21:22.650355
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_ = _TextEnviron({b'foo': b'bar'})
    assert environ_['foo'] == u'bar'

    environ_ = _TextEnviron({u'foo': u'bar'})
    assert environ_['foo'] == u'bar'

# Generated at 2022-06-11 18:21:27.837089
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'value1': b'value1', b'value2': 'value2', u'value3': u'value3'})
    assert env['value1'] == 'value1'
    assert env['value2'] == u'value2'
    assert env['value3'] == u'value3'

# Generated at 2022-06-11 18:21:36.014963
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    orig_environ = environ._raw_environ

# Generated at 2022-06-11 18:21:42.144054
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Note: We're not testing the actual values of the environment variables read.  That will be
    # handled via the test_ansible_module_utils.py test case.  This test instead tests that we can
    # read them and they are converted to text.
    assert environ['SHELL'] == os.environ['SHELL']



# Generated at 2022-06-11 18:21:48.050133
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ[b'ANSIBLE_TEST_KEY'] = b'ANSIBLE_TEST_VALUE'
    if PY3:
        assert environ[b'ANSIBLE_TEST_KEY'] == 'ANSIBLE_TEST_VALUE'
    else:
        assert environ['ANSIBLE_TEST_KEY'] == u'ANSIBLE_TEST_VALUE'
        assert environ[b'ANSIBLE_TEST_KEY'] == u'ANSIBLE_TEST_VALUE'
    try:
        del os.environ['ANSIBLE_TEST_KEY']
    except NameError:
        pass



# Generated at 2022-06-11 18:21:52.112960
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron({'ANSIBLE_TEST_THAT_EVERYTHING_IS_UNICODE': u'\u00E9'})
    assert e['ANSIBLE_TEST_THAT_EVERYTHING_IS_UNICODE'] == u'\u00E9'

# Generated at 2022-06-11 18:21:55.398411
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(environ['HOME'], str)
    assert environ['HOME'].endswith('ansible')

# Generated at 2022-06-11 18:22:04.719362
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test when PY3 == True; should return same as os.environ
    env = _TextEnviron()
    assert env['PYTHONPATH'] == os.environ['PYTHONPATH']

    # Test when PY3 == False
    env = _TextEnviron(encoding='utf-8')
    assert env['PYTHONPATH'] == os.environ['PYTHONPATH']

    # Test when PY3 == False and the environment variable is encoded as something else
    env = _TextEnviron({b'PYTHONPATH': to_bytes('δοκιμή', encoding='iso-8859-7')}, encoding='utf-8')
    assert env['PYTHONPATH'] == to_text('δοκιμή', encoding='iso-8859-7')



# Generated at 2022-06-11 18:22:16.425592
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    x = _TextEnviron()
    try:
        x["ПРИВЕТ"]
    except KeyError:
        pass
    else:
        print("KeyError wasn't thrown")
    try:
        x["ПРИВЕТ"] = "МИР"
    except TypeError:
        pass
    else:
        print("TypeError wasn't thrown")

# Generated at 2022-06-11 18:22:23.661869
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import StringIO

    def _redirect_stdout():
        '''Helper function to redirect stdout'''
        sys.stdout = StringIO()

    def _restore_stdout():
        '''Helper function to restore stdout'''
        sys.stdout = sys.__stdout__

    # prepare
    class EnvironMock(object):
        def __init__(self):
            self.retval = None

        def __getitem__(self, key):
            return self.retval
    environ_mock = EnvironMock()
    text_environ = _TextEnviron(env=environ_mock)
    _redirect_stdout()

    environ_mock.retval = '\\u2211'  # sum of all positive integers, in unic

# Generated at 2022-06-11 18:22:27.714053
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['_ANSIBLERG_TEST_TEXT'] = 'value'
    assert environ['_ANSIBLERG_TEST_TEXT'] == 'value'
    del os.environ['_ANSIBLERG_TEST_TEXT']


# Generated at 2022-06-11 18:22:29.057567
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH']
    assert isinstance(environ['PATH'], str)

# Generated at 2022-06-11 18:22:36.442062
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that it works as expected in Python3
    # (i.e. just returns the value it gets from the environment)
    env_bak = dict(environ)

# Generated at 2022-06-11 18:22:46.871584
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''Test for method __getitem__ of class _TextEnviron'''
    env = _TextEnviron({'regular_var': b'foobar', 'unicode_var': b'\xbd\xb2\x3d\xbc\x20\xe2\x8c\x98'})
    assert env['regular_var'] == 'foobar'
    assert env['unicode_var'] == '½²=¼ ⌘'

    env = _TextEnviron()
    env['regular_var'] = 'foobar'
    env['unicode_var'] = '½²=¼ ⌘'
    assert env['regular_var'] == 'foobar'
    assert env['unicode_var'] == '½²=¼ ⌘'

# Generated at 2022-06-11 18:22:53.731315
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    for getitem in [environ.__getitem__, os.environ.__getitem__]:
        assert getitem('PATH') == getitem('PATH')
        assert os.path.normpath(getitem('PATH')) == os.path.normpath(os.environ['PATH'])

        # We're trying to mimic os.environ here, so use sys.getfilesystemencoding() instead of
        # utf-8
        encoding = sys.getfilesystemencoding()

        if PY3:
            # On Python3, raw bytes are in the environment and so we should get back raw bytes
            # from _TextEnviron.__getitem__.  If we get back text from _TextEnviron.__getitem__
            # then that's obviously wrong.
            assert getitem('PATH') == os.environ['PATH']


# Generated at 2022-06-11 18:23:01.910732
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # When dealing with ansible.module_utils.six.PY2, method __getitem__ of class _TextEnviron,
    # it should decode the values from environ and cache the decoded value
    if PY3:
        assert False
    class Testobject(object):
        pass
    environ.clear()
    # 1) Put a value into the environment which is in the cache
    environ["def"] = Testobject()
    assert environ["def"] == Testobject()
    # 2) Put a value into the environment which is NOT in the cache
    environ["abc"] = Testobject()
    assert environ["abc"] == Testobject()
    pass


# Generated at 2022-06-11 18:23:13.290111
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class DummyEnviron(MutableMapping):
        def __init__(self):
            self._env = {'a': b'foo',
                         'b': u'bar'}

        def __delitem__(self, key):
            del self._env[key]

        def __getitem__(self, key):
            return self._env[key]

        def __setitem__(self, key, value):
            self._env[key] = value

        def __iter__(self):
            return self._env.__iter__()

        def __len__(self):
            return len(self._env)

    te = _TextEnviron(env=DummyEnviron())

    if PY3:
        assert te['a'] == 'foo'
    else:
        assert te['a'] == u'foo'

# Generated at 2022-06-11 18:23:18.509761
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == u'/home/toshio'


# Generated at 2022-06-11 18:23:27.818024
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a mock of _TextEnviron
    original_environ = os.environ
    os.environ = {b'ASCII': b'1', b'UTF8': u'2'.encode('utf-8'),
                  b'U+7F': b'\x7f', b'U+80': b'\xc2\x80',
                  b'U+800': b'\xe0\xa0\x80',
                  }
    environ = _TextEnviron()

    assert environ['ASCII'] == '1'
    assert environ['UTF8'] == u'2'
    assert environ['U+7F'] == u'\x7f'
    assert environ['U+80'] == u'\u0080'

# Generated at 2022-06-11 18:23:36.580957
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    from ansible.module_utils._text import to_text

    test_env_var_name = "ANSIBLE_TEST_OS_ENVIRON"
    test_env_var_ascii_value = "ascii"
    test_env_var_unicode_value = u"unicode äöü"

    os.environ[test_env_var_name] = test_env_var_ascii_value
    assert test_env_var_ascii_value == environ[test_env_var_name]
    assert type(environ[test_env_var_name]) == to_text

    os.environ[test_env_var_name] = test_env_var_unicode_value.encode("utf-8")
    assert test_env_var_

# Generated at 2022-06-11 18:23:45.197380
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest
    import os

    class Test_TextEnviron(unittest.TestCase):
        def setUp(self):
            try:
                os.environ[b'test_env1'] = b'only bytes'
            except NameError:
                # Python 3.x
                os.environ['test_env1'] = 'only bytes'

            try:
                os.environ[b'test_env2'] = u'unicode \u00E9'
            except NameError:
                # Python 3.x
                os.environ['test_env2'] = u'unicode \u00E9'


# Generated at 2022-06-11 18:23:50.621477
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # set py2 env var to py2 unicode
    environ['和'] = u'ユニコード'

    if PY3:
        assert environ['和'] == u'ユニコード'
    else:
        assert environ['和'] == u'ユニコード'


# Generated at 2022-06-11 18:23:57.212761
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with default encoding (sys.getfilesystemencoding())
    del os.environ['LANG']
    del os.environ['LC_ALL']
    os.environ['LC_ALL'] = u'C.UTF-8'
    environ = _TextEnviron()

    assert(len(environ) == 1)

    os.environ['LANG'] = u'C.UTF-8'

    assert(len(environ) == 2)

    # Test with explicit encoding (utf-8)
    environ = _TextEnviron(encoding='utf-8')
    assert(len(environ) == 2)

    # Test with non-existent encoding (iso-8859-1)
    environ = _TextEnviron(encoding='iso-8859-1')

# Generated at 2022-06-11 18:24:01.176297
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron({b'foo': b'bar', u'unicode': u'\u00e9', 'nohash': 'nohash'})

    assert u'foo' == e['foo']
    assert 'nohash' == e['nohash']
    assert u'\u00e9' == e['unicode']



# Generated at 2022-06-11 18:24:03.185703
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert to_text(environ[to_bytes('PATH', 'utf-8')]) == environ[to_bytes('PATH', 'utf-8')]

# Generated at 2022-06-11 18:24:13.560235
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import sys

    # If Python >= 3, return environment variable as is
    if PY3:
        environ_backup = os.environ
        os.environ = {'FOO': 'some text'}

        te = _TextEnviron(encoding='utf-8')
        assert te['FOO'] == 'some text'

        os.environ = environ_backup

        return

    # Python 2 and not PY3
    environ_backup = os.environ
    os.environ = {'FOO': 'some text'}

    te = _TextEnviron(encoding='utf-8')
    assert te['FOO'] == u'some text'

    os.environ = environ_backup


# Generated at 2022-06-11 18:24:23.250175
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # 'utf-8' is the default encoding
    assert isinstance(environ['PATH'], unicode)
    environ._value_cache = {}
    assert isinstance(environ['PATH'], unicode)
    # On Python 2, we don't have a way to get an invalid byte sequence while preserving the
    # byte sequence.  So to test the error handling code, we'll just skip that test on Python 2.
    if not PY3:
        return

    # Test Python 3's decoding errors
    # The binary sequence is the utf-8 encoding of the 1st character in the Unicode Basic
    # Multilingual Plane, U+0080
    binary_seq = b'\x80'
    corrected_seq = to_bytes('\uFFFD', encoding='utf-8', nonstring='passthru')
    UnicodeEncodeError_raised

# Generated at 2022-06-11 18:24:39.141819
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['PYTHONIOENCODING'] = 'utf-8'
    os.environ['ANSIBLE_CONNECTION'] = u'local'
    os.environ['ANSIBLE_INVENTORY'] = '/etc/ansible/hosts'
    os.environ['ANSIBLE_FORKS'] = '5'
    os.environ['ANSIBLE_STDOUT_CALLBACK'] = u'json'
    os.environ['ANSIBLE_ROLES_PATH'] = b'/etc/ansible/roles:/usr/share/ansible/roles:/etc/ansible/roles:/usr/share/ansible/roles'
    os.environ['ANSIBLE_TOWER_HOST'] = b'localhost'
    os.environ['USER'] = u'badger'
    os.en

# Generated at 2022-06-11 18:24:45.919179
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ._raw_environ = {'one': '\xe9', 'two': u'\xe9'}
    if PY3:
        assert environ['one'] == '\xe9'
        assert environ['two'] == u'\xe9'
    else:
        assert environ['one'] == '\xe9'
        assert environ['two'] == u'\xe9'


# Generated at 2022-06-11 18:24:52.416704
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:25:02.369014
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # An attempt to read an environment variable that is not set should raise a KeyError.
    try:
        environ['NotAKey']
    except KeyError:
        pass
    else:
        raise AssertionError('os.environ.__getitem__(NotAKey) did not raise KeyError')

    # By default, Python2 will return byte strings and Python3 will return text strings.
    # If the locale is ASCII-compatible, both should return the same types of strings.
    environ['TextVar'] = 'Hello'
    py2_val = os.environ['TextVar']
    py3_val = environ['TextVar']

    if PY3:
        assert py3_val is py2_val
        assert isinstance(py3_val, str)
        assert isinstance(py2_val, bytes)


# Generated at 2022-06-11 18:25:04.387352
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == u'/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games'

# Generated at 2022-06-11 18:25:15.574321
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import sys
    import tempfile
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3

    # ensure that the PY3 env is setup correctly
    assert PY3

    # We will not be able to test non-ASCII characters on Windows because the system
    # encoding is "mbcs" (which is equivalent to cp-1252 on non-Unicode builds)
    if sys.platform.startswith('win'):
        return

    # assert the class is a subclass of MutableMapping
    assert issubclass(_TextEnviron, MutableMapping)

    # get a temporary variable

# Generated at 2022-06-11 18:25:21.801660
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['var'] = 'a'
    assert environ['var'] == 'a'
    environ['var'] = u'a'
    assert environ['var'] == 'a'
    environ['var'] = b'a'
    assert environ['var'] == 'a'
    environ['var'] = b'\xff'
    assert environ['var'] == u'\ufffd'
    environ['var'] = b'\x00'
    assert environ['var'] == u'\x00'


# Generated at 2022-06-11 18:25:32.136785
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Note: This test needs to be run with the ansible-test coverage target.  It doesn't use the
    # normal utils/module_common framework.  If this becomes more than a one-off test, we may want
    # to move it to the ansible-test framework.

    # Arrange
    try:
        # if it exists, corrupt the cache used by _TextEnviron so we can tell if it gets used or
        # not
        text_environ._value_cache[to_bytes('testkey1')] = u'garbage'
    except KeyError:
        # If the test variable has not been set by a previous test yet, don't do anything
        pass

    # Act

# Generated at 2022-06-11 18:25:36.829460
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    try:
        # test item
        item = 'ANSIBLE_TEST_FOO'
        # test value
        value = u'bar'
        # insert test item
        os.environ[item] = value
        # check item
        assert environ[item] == value
    finally:
        # remove test item
        if item in os.environ:
            del os.environ[item]

# Generated at 2022-06-11 18:25:38.782019
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from nose.tools import assert_equals

    assert_equals(u'foo'.encode('utf-8'), environ.__getitem__(u'foo'))


# Generated at 2022-06-11 18:26:00.807247
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest
    import six

    class _TextEnvironTest(unittest.TestCase):
        @classmethod
        def setUpClass(self):
            self.test_env = environ.copy()
            self.test_env.clear()

        def test__getitem__1(self):
            self.test_env["simple_key"] = "simple_value"
            self.assertEqual(self.test_env["simple_key"], "simple_value")


# Generated at 2022-06-11 18:26:03.346200
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that non-ASCII values are handled correctly
    expected = "Кириллица"
    environ['non_ascii'] = expected
    assert environ['non_ascii'] == expected


# Generated at 2022-06-11 18:26:14.004776
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six.moves import cStringIO as StringIO

    import os
    import sys
    import unittest

    class Test__TextEnviron(unittest.TestCase):
        def setUp(self):
            # Create a temporary environment for the test
            self.default_env = os.environ.copy()
            self.test_env = {ENV_VAR_NAME_1: ENV_VAR_VALUE_1,
                             ENV_VAR_NAME_BYTES: ENV_VAR_VALUE_BYTES,
                             ENV_VAR_NAME_UNICODE: ENV_VAR_VALUE_UNICODE}
            os.environ.update(self.test_env)

            # We do a lot of patching in these tests.  Collect all of

# Generated at 2022-06-11 18:26:23.829226
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    testData = [
        ["TEST_VAR", u"TEST_VALUE"],
        ["TEST_VAR_2", u"TEST\u1234VALUE"],
        ["TEST_VAR_3", u"ТЕСТ"],
    ]

    # Check handling of unicode bytes (\u1234)
    environ.clear()
    for key, value in testData:
        environ[key] = value

    # Check when the environment value is not a string
    environ.clear()
    environ['TEST_VAR'] = 123
    assert environ['TEST_VAR'] == '123'

    # Check when the environment value is None

# Generated at 2022-06-11 18:26:26.151532
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'FOO': b'bar'}, encoding='utf-8')
    assert env['FOO'] == u'bar'



# Generated at 2022-06-11 18:26:37.384376
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['TESTKEY1'] = '"Test text for getitem"\n'
    os.environ['TESTKEY2'] = '"Test text for getitem"\n'
    os.environ['TESTKEY3'] = '"Test text for getitem"\n'
    # Test that normal text is returned properly
    assert environ['TESTKEY1'] == u'"Test text for getitem"\n'
    # Test that we cache the value properly
    os.environ['TESTKEY1'] = '"Test text for getitem"\n'
    assert environ['TESTKEY1'] == u'"Test text for getitem"\n'
    os.environ['TESTKEY1'] = '"Test text for getitem"\r\n'

# Generated at 2022-06-11 18:26:43.086572
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    utf8_sequence = b'\xff'
    # invalid_utf8 is not valid UTF-8.  It's the byte sequence that would be produced by encoding
    # 0xD801 (surrogate half) with encoding 'utf-8'
    invalid_utf8 = b'\xed\xa0\x81'
    # utf8_str is a valid utf-8 string
    utf8_str = u'\uffff'

    os.environ[u'unicode_name'] = u'unicode_value'
    os.environ[utf8_sequence] = utf8_sequence

    # Unicode keys and values return back unicode objects with regular os.environ
    assert isinstance(os.environ[to_bytes('unicode_name')], unicode)

# Generated at 2022-06-11 18:26:53.962297
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Unit test for method _TextEnviron.__getitem__()
    '''
    # Test with a dict like object, but where the keys and values are already encoded to utf-8
    # bytes
    import six
    test_dict = {to_bytes('a', encoding='utf-8'): to_bytes('b', encoding='utf-8')}
    environ_obj = _TextEnviron(test_dict)
    rval = environ_obj['a']
    assert isinstance(rval, six.text_type), "Return value of _TextEnviron.__getitem__() is not a text type"
    rval = environ_obj['b']
    assert isinstance(rval, six.text_type), "Return value of _TextEnviron.__getitem__() is not a text type"



# Generated at 2022-06-11 18:26:56.719577
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == to_text(os.environ['HOME'], encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict')


# Generated at 2022-06-11 18:26:59.806942
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes, to_text
    environ = _TextEnviron()
    value = 'abc123'
    result = environ.__getitem__(value)
    assert result == to_text(value)


# Generated at 2022-06-11 18:27:32.785147
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    old_environ = _TextEnviron()
    test_environ = _TextEnviron(env={b'unicode_key': b'unicode_value',
                                     b'ascii_key': b'ascii_value',
                                     b'latin_1_key': b'\xe4\xf6\xfc',
                                     b'utf-8_key': b'\xe4\xf6\xfc\xc3\xa4\xc3\xb6\xc3\xbc',
                                     b'invalid_utf-8_key': b'invalid_utf-8\xff'}
                               )
    assert test_environ[b'unicode_key'] == u'unicode_value'

# Generated at 2022-06-11 18:27:36.177386
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == u'/home/toshio'
    assert environ.get('HOME') == u'/home/toshio'
    assert environ.get('HOME', u'/home/bob') == u'/home/toshio'
    assert 'HOME' in environ



# Generated at 2022-06-11 18:27:46.617324
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # set up the module environment
    os.environ['ANSIBLE_TESTVAR'] = 'u this is a unicode value'
    os.environ['ANSIBLE_BYTESVAR'] = 'b this is a byte string value'.encode('utf-8')
    os.environ['ANSIBLE_INVALIDVAR'] = b'\x00\x80\xa0this is an invalid byte string value\x00\x80\xa0'

    from ansible.module_utils.common._collections_compat import Mapping
    assert isinstance(environ, Mapping)
    assert environ['ANSIBLE_TESTVAR'] == u'u this is a unicode value'
    assert environ['ANSIBLE_BYTESVAR'] == u'b this is a byte string value'

# Generated at 2022-06-11 18:27:50.301008
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ[b'testenv'] = b'foobar'
    assert('foobar' == environ['testenv'])
    assert(type(environ['testenv']) == str)
    os.environ.pop(b'testenv')
    try:
        environ['testenv']
    except KeyError:
        pass
    else:
        assert(False)
    os.environ[b'testenv'] = b'\x01'
    try:
        environ['testenv']
    except UnicodeDecodeError:
        pass
    else:
        assert(False)
    os.environ.pop(b'testenv')


# Generated at 2022-06-11 18:27:58.873368
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test the case of a valid key with a byte string value
    environ = _TextEnviron({b'ANSIBLE_TEST': b'\xe9\x9d\x99\xe8\xbf\x91'})
    assert isinstance(environ['ANSIBLE_TEST'], str)
    # Test the case of a key with a unicode value
    environ = _TextEnviron({u'ANSIBLE_TEST': u'就是喜欢我'})
    assert isinstance(environ['ANSIBLE_TEST'], str)
    # Test the case of a valid key with a byte string value that has a non-utf-8 character

# Generated at 2022-06-11 18:28:03.984144
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ.__getitem__('LANG') == u'en_US.UTF-8'
    assert environ.__getitem__('SHELL') == u'/bin/bash'
    assert environ.__getitem__('TERM') == u'xterm-color'

# Generated at 2022-06-11 18:28:12.727110
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    def _check(env, encoding, key, result):
        environ = _TextEnviron(env, encoding=encoding)
        assert environ[key] == result

    # In Python3, the environment is assumed to be text, so don't do conversions
    _check({b'key': b'value'}, None, b'key', 'value')
    _check({'key': 'value'}, None, 'key', 'value')
    # In Python2, decode the environment
    _check({b'key': b'value'}, 'utf-8', b'key', u'value')
    _check({'key': 'value'}, 'utf-8', 'key', 'value')

    # Test when we specify an encoding

# Generated at 2022-06-11 18:28:21.885238
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a dict with unicode in the key and both unicode and byte strings in the values
    test_dict = {u'unicode_key': u'unicode_value', b'byte_key': 'unicode_value',
                 u'unicode_key2': 'unicode_value2', b'byte_key2': 'unicode_value2',
                 u'unicode_key3': 'unicode_value2', b'byte_key3': b'byte_value'}

    test_environ = _TextEnviron(test_dict)
    for key, value in test_dict.items():
        assert test_environ[to_text(key, encoding='utf-8', errors='strict')] == to_text(value, encoding='utf-8', errors='strict')

# Generated at 2022-06-11 18:28:29.305706
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # #1743 - Support invalid non-UTF-8 environment variable values
    if sys.platform == 'win32':
        os.environ[b'NOT_UTF8'] = b'\x80'
        assert environ[b'NOT_UTF8'] == u'\ufffd'
    else:
        os.environ[u'NOT_UTF8'] = u'\xa0'
        assert environ[u'NOT_UTF8'] == u'\u00a0'



# Generated at 2022-06-11 18:28:40.521050
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    # Note that we're not testing any case here where the value of the item changes during the
    # lifetime of the object.  That's a bit hard to test for.

    class TestException(Exception):
        pass

    class TestEnviron(object):
        def __init__(self):
            self.value = 'test_value'

        def __getitem__(self, key):
            if key != 'TEST':
                raise TestException('Unexpected key')
            return self.value

        def __setitem__(self, key, value):
            if key != 'TEST':
                raise TestException('Unexpected key')
            if value != b'test_value':
                raise TestException('Unexpected value')



# Generated at 2022-06-11 18:29:39.617615
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    orig_env = environ.copy()
    try:
        assert len(environ) == 0
        assert environ.get('foo') is None
        environ['foo'] = 'bar'
        assert len(environ) == 1
        assert environ.get('foo') == 'bar'
        environ['foo'] = None
        assert len(environ) == 0
        assert environ.get('foo') is None
    finally:
        environ.clear()
        environ.update(orig_env)



# Generated at 2022-06-11 18:29:44.842711
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_copy = dict()
    for key, value in os.environ.items():
        environ_copy[key] = value
    assert environ == environ_copy
    assert environ['PATH'] == to_text(environ_copy['PATH'], encoding='utf-8')
    del environ_copy['PATH']
    del environ['PATH']
    assert environ == environ_copy



# Generated at 2022-06-11 18:29:52.334351
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test without encoding
    text_env = _TextEnviron()
    text_value = text_env['LANG']
    print(text_value, type(text_value))  # <class 'str'>
    # test unicode environment value
    text_env['MY_UNICODE'] = '哈哈'
    text_value = text_env['MY_UNICODE']
    print(text_value, type(text_value))  # <class 'str'>
    # test utf-8 encoded string
    text_env['MY_UTF8'] = '哈哈'.encode('utf-8')
    text_value = text_env['MY_UTF8']
    print(text_value, type(text_value))  # <class 'str'>
    # test with encoding
    text_

# Generated at 2022-06-11 18:29:57.043318
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Without MutableMapping, Python 2 tests fail. But, of course, the tests work in Python 3.
    # So, let's make the tests work in Python 2.

    # Test nonstring values
    environ[b'test_0'] = 'test_0'
    assert environ[b'test_0'] == 'test_0'
    environ[b'test_1'] = to_bytes('ñØ', errors='surrogate_or_strict')
    assert environ[b'test_1'] == to_text('ñØ', errors='surrogate_or_strict')
    environ[b'test_2'] = to_bytes('\x99')
    assert environ[b'test_2'] == to_text('\x99')
    # Test nonstring keys

# Generated at 2022-06-11 18:30:05.670399
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    _TextEnviron.__getitem__() should return text string or decode bytes
    """

    # Test: Return string if already text
    my_env = _TextEnviron({'TEST_KEY': 'TEST_VALUE'})
    assert my_env['TEST_KEY'] == 'TEST_VALUE', 'When the value is already text, it should be returned as text.'

    # Test: Return decoded bytes
    my_env = _TextEnviron({'TEST_KEY': b'TEST_VALUE'})
    assert my_env['TEST_KEY'] == 'TEST_VALUE', 'Bytes should be decoded properly.'

    # Test: Return decoded with surrogateescape when decoding error can occur
    my_env = _TextEnviron({'TEST_KEY': '\u3042'})
    assert my_env

# Generated at 2022-06-11 18:30:12.026891
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Tests for method __getitem__ of class _TextEnviron
    """

    class _TestEnviron(object):
        """
        Just a mock object so we can test the __getitem__ method of _TextEnviron
        """
        def __init__(self, values):
            self.values = values

        def __getitem__(self, key):
            return self.values[key]

    def test_getitem(environ, key, value, encoding):
        test_environ = _TestEnviron(values={key: value})
        text_environ = _TextEnviron(env=test_environ, encoding=encoding)
        assert text_environ['key'] == value

    test_environ = _TestEnviron(values={'ascii': 'hello'})
    text_environ = _Text

# Generated at 2022-06-11 18:30:17.854319
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # TODO: Test all cases.
    assert environ["PYTHONPATH"]
    assert environ["USER"]
    assert environ["PATH"]
    assert environ["LANG"]
    assert environ["LANG"]
    assert environ["LC_ALL"]
    assert environ["PWD"]
    assert environ["VAGRANT_CWD"]
    assert environ["HOME"]
    assert environ["VAGRANT_HOME"]
    assert environ["USERNAME"]
    assert environ["ANSIBLE_TEST_PYTHON_VERSION"]



# Generated at 2022-06-11 18:30:22.751065
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'bstr': b'blah', u'u\xe9': u'foo'})
    assert environ[u'bstr'] == u'blah'
    assert environ[u'u\xe9'] == u'foo'



# Generated at 2022-06-11 18:30:30.920278
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.common.collections import MutableMapping
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text

    class _TextMapping(MutableMapping):
        def __init__(self, encoding=None):
            self._data = {}
            self._value_cache = {}
            # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
            # instead of utf-8
            if encoding is None:
                # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
                # instead of utf-8
                self.encoding = sys.getfilesystemencoding()
            else:
                self.encoding = encoding



# Generated at 2022-06-11 18:30:40.447956
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test for non-list items
    assert environ['PATH'] == os.environ['PATH']

    # test for utf8-string
    unprintable_string = '\xf0\x9f\x8f\x82'  # 'surfing man', see https://goo.gl/A1TUzJ
    codecs_environ = _TextEnviron()
    codecs_environ[unprintable_string] = unprintable_string
    assert codecs_environ[unprintable_string] == unprintable_string

    # test for non-utf8-string
    non_utf8_string = '\x98'
    codecs_environ = _TextEnviron()
    codecs_environ[non_utf8_string] = non_utf8_string
    assert codecs_en