

# Generated at 2022-06-11 18:21:06.382206
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import pytest
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    result = {}
    obj = _TextEnviron(result)

    # Case 1: Value is None
    with pytest.raises(TypeError):
        obj.__getitem__(None)

    # Case 2: Key is not in the environment
    assert 'key' not in obj._raw_environ
    assert obj.__getitem__('key') == ''
    assert obj._raw_environ['key'] == b''

    # Case 3: Value is a byte string
    result['key'] = b'value'
    assert 'key' in obj._raw_environ
    assert obj.__getitem__('key') == 'value'

    # Case

# Generated at 2022-06-11 18:21:17.315079
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'LANG': b'en_US.UTF-8', 'LC_ALL': 'en_US.UTF-8'})
    assert isinstance(env['LANG'], text_type)
    assert env['LANG'] == u'en_US.UTF-8'
    assert isinstance(env['LC_ALL'], text_type)
    assert env['LC_ALL'] == u'en_US.UTF-8'
    assert isinstance(env[b'LANG'], text_type)
    assert env[b'LANG'] == u'en_US.UTF-8'
    assert isinstance(env[u'LANG'], text_type)
    assert env[u'LANG'] == u'en_US.UTF-8'

# Generated at 2022-06-11 18:21:19.035731
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
  assert environ['LANG'] == 'en_US.UTF-8'


# Generated at 2022-06-11 18:21:30.978558
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Patch os.environ
    # On python2, os.environ.__getitem__ returns byte strings
    # On python3, os.environ.__getitem__ returns text strings
    # On python2, os.environ.__setitem__ converts input to byte strings
    # On python3, os.environ.__setitem__ converts input to text strings
    from mock import patch

    with patch('os.environ', {b'byte_key': b'byte_val'}):
        env = {u'text_key': u'text_val'}
        with patch('ansible.module_utils.six._TextEnviron._raw_environ', env):
            assert _TextEnviron._getitem_bytes(env, b'text_key') == u'text_val'
            assert _TextEnviron._getitem

# Generated at 2022-06-11 18:21:32.811129
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert to_text('test') == environ['test']
    assert u'test' == environ['test']

# Generated at 2022-06-11 18:21:35.869394
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    testenv = _TextEnviron(env={'testkey1': b'abc', 'testkey2': u'abc'}, encoding='utf-8')
    assert testenv['testkey1'] == u'abc'
    assert testenv['testkey2'] == u'abc'

# Generated at 2022-06-11 18:21:43.512717
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for return value of __getitem__
    assert environ["HOME"] == "/home/toshio"

    # Test for return value of __getitem__
    assert environ["PWD"] == "/home/toshio/"

    # Test for return value of __getitem__
    assert environ["LOGNAME"] == "toshio"

    # Test for return value of __getitem__
    assert environ["USER"] == "toshio"



# Generated at 2022-06-11 18:21:49.755379
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        # Test __getitem__ with unicode keys
        environ[u'unicode_key'] = u'unicode_value'
        assert environ[u'unicode_key'] == u'unicode_value'
    except Exception as e:
        raise AssertionError('Failed to test _TextEnviron.__getitem__ with unicode keys: %s' % e)
    try:
        # Test __getitem__ with byte strings keys
        environ[b'byte_key'] = u'unicode_value'
        assert environ[b'byte_key'] == u'unicode_value'
    except Exception as e:
        raise AssertionError('Failed to test _TextEnviron.__getitem__ with byte strings keys: %s' % e)

# Generated at 2022-06-11 18:22:00.612435
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    old_os_environ = os.environ
    os.environ = {b'UTF-8-BYTES': b'\xce\xba\xe1\xbd\xb9',
                  b'UTF-8-BYTES-WITH-ESCAPES': b'\\xce\\xba\\xe1\\xbd\\xb9'}
    environ = _TextEnviron()

    # Same result as os.environ on Python 3
    assert environ[b'UTF-8-BYTES'] == os.environ[b'UTF-8-BYTES']
    assert environ[b'UTF-8-BYTES'] == u'\u03ba\u1f79'

    # Escaped byte strings that are normally decoded by Python 3's os.environ are also decoded
    assert environ

# Generated at 2022-06-11 18:22:02.996704
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    for key, val in os.environ.items():
        assert os.environ[key] == environ[key]


# Generated at 2022-06-11 18:22:10.387973
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for the method _TextEnviron.__getitem__
    """
    key = u'mykey'
    os.environ[key] = b'bar'

    assert isinstance(environ[key], str)
    assert environ[key] == value

# Generated at 2022-06-11 18:22:19.686463
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes
    # Method __getitem__ has 3 catch branches: if key doesn't exist in environment, if key exists
    # but value is None, or if value is not None.
    # 1st case: 'key' is not in environment
    test_environ = _TextEnviron({'key2': 'value2'})
    try:
        test_environ['key1']
    except KeyError:
        pass
    else:
        raise AssertionError("[test__TextEnviron___getitem__] Expected exception: 'KeyError' "
                             "wasn't raised and wasn't expected to be raised.")

    # 2nd case: 'key' exists in environment but value is None
    test_environ = _TextEnviron({'key1': None})

# Generated at 2022-06-11 18:22:24.580584
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_copy = os.environ.copy()

    # test os.environ
    os.environ['ANSI_BLE'] = '\x1b[30m'
    assert os.environ['ANSI_BLE'] == '\x1b[30m'

    # test _TextEnviron
    environ_text = _TextEnviron(encoding='utf-8')
    os.environ['ANSI_BLE'] = '\x1b[30m'
    assert environ_text['ANSI_BLE'] == '\x1b[30m'
    # Restore original environment
    os.environ = environ_copy


# Generated at 2022-06-11 18:22:27.296920
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['TEST_ENVVAR'] = 'TEST VALUE'
    assert environ['TEST_ENVVAR'] == 'TEST VALUE'


# Generated at 2022-06-11 18:22:30.364795
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # setup
    test_environ = _TextEnviron({'abc': '123'})
    # execute
    result = test_environ['abc']
    # verify
    assert result == u'123'


# Generated at 2022-06-11 18:22:38.979375
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This is a test of the method __getitem__ of _TextEnviron.
    # _TextEnviron is designed to provide text versions of the environment variables
    # even in Py2.

    # The Py3 way:
    if PY3:
        # Same os.environ as we're forcing encoding to utf-8 for the test.
        assert dict(environ) == dict(os.environ)

    # Test that the getitem method passes through text on Py3
    if PY3:
        environ['foo'] = 'bar'
        assert environ['foo'] == 'bar'

    # Ensure that a non-utf-8 utf-8 byte string is decoded as utf-8 on Py2
    environ['foo'] = b'bar'
    assert environ['foo'] == 'bar'

    # Ensure that

# Generated at 2022-06-11 18:22:49.339214
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest
    import mock

    test_environ = _TextEnviron(env={'utf8_key': 'utf8_val'})
    test_environ['unicode_key'] = 'unicode_val'
    sys.modules['os'].environ = test_environ

    # This is a case for valid key and return default value
    class Test__TextEnviron___getitem___Case1(unittest.TestCase):
        def setUp(self):
            self.environ = dict(
                encoding=None,
                )

        def test_get_key_utf8_key(self):
            self.environ['key'] = 'utf8_key'
            self.environ['default'] = 'default_value'
            expected_result = 'utf8_val'

            result = _Text

# Generated at 2022-06-11 18:22:53.890542
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit tests for the _TextEnviron class.  This test checks the __getitem__ method
    """
    assert environ['PATH'] == '/usr/bin:/bin:/sbin'



# Generated at 2022-06-11 18:22:58.015135
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that using the cached value or getting the value again gives back the original value
    for key in environ:
        environ[key]
        environ[key]
        assert environ[key] == os.environ[key]


# Generated at 2022-06-11 18:23:10.264433
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert to_bytes('\u0378_\u0379', encoding='utf-8') not in os.environ
    # This source code utf-8 encodes as 0xc3 0xbe 0x5f 0xc3 0xbf, so if we pass that in and get
    # the same thing back then we don't have the surrogate error handling working and we'll
    # generate a surrogate error later on the decode
    surrogate_error_bytes = os.environ[to_bytes('\u0378_\u0379', encoding='utf-8')]
    assert surrogate_error_bytes == b'\xc3\xbe\x5f\xc3\xbf'

# Generated at 2022-06-11 18:23:26.976058
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    import sys

    if PY3:
        raise AssertionError('Need a python2 interpreter to run the unit test')

    class _TextEnviron:
        def __init__(self, env=None, encoding=None):
            if env is None:
                env = os.environ
            self._raw_environ = env
            self._value_cache = {}
            # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
            # instead of utf-8

# Generated at 2022-06-11 18:23:36.078262
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = os.environ.copy()
    # Set some unicode characters into environment variables
    env[b'ANSIBLE_STRING_VAL'] = u'Iñtërnâtiônàlizætiøn1'
    env[b'ANSIBLE_BYTE_VAL'] = b'I\xc3\xb1t\xc3\xaBrn\xc3\xa2ti\xc3\xb4n\xc3\xa0liz\xc3\xa6ti\xc3\xb8n2'
    env[b'ANSIBLE_UNDECODED_VAL'] = b'I\xe3t\xe3\xb3n\xe3\xb3liz\xe3\xb3ti\xe3\xb3n'

# Generated at 2022-06-11 18:23:39.838718
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['a'] = 'b'
    assert environ['a'] == 'b'
    environ['a'] = 'bб'
    assert environ['a'] == 'bб'



# Generated at 2022-06-11 18:23:52.043351
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b"TEST_BYTES": b"Hello"})
    assert environ['TEST_BYTES'] == u'Hello'
    environ = _TextEnviron({"TEST_UNICODE": u'\u3042'})
    assert environ['TEST_UNICODE'] == u'\u3042'
    environ = _TextEnviron({"TEST_UNICODE": b'\xe3\x81\x82'})
    assert environ['TEST_UNICODE'] == u'\u3042'
    environ = _TextEnviron({"TEST_UNICODE": b'\xe3\x81\x82'}, encoding='latin-1')

# Generated at 2022-06-11 18:24:02.512168
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test behavior when Python version <= 2.7
    class _TextEnviron_Upgrade_To_Python_3:
        def __init__(self, encoding):
            self.encoding = encoding
        def __getitem__(self, key):
            # Set the value of `self._raw_environ` since the method `__getitem__` of the class
            # _TextEnviron references `self._raw_environ`.
            self._raw_environ = {key: 'value'}
            return self._raw_environ[key]
    # Set the global variable `six.PY3` as False since Python 2.7 does not support it.
    PY3 = False
    # Set the value of `sys.getfilesystemencoding` as 'ascii' temporarily.
    old_getfilesystemencoding = sys.get

# Generated at 2022-06-11 18:24:12.606451
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ[b'VAR'] = b'testu\xEF\xBF\xBD\xEF\xBF\xBD'

# Generated at 2022-06-11 18:24:18.492181
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    var_name = 'PYTHON_TEST_UNICODE_ENV_VAR'
    environ[var_name] = 'Hello World '
    assert to_text(environ[var_name]) == 'Hello World '
    environ[var_name] = 'Hello World 2!'
    assert to_text(environ[var_name]) == 'Hello World 2!'

# Generated at 2022-06-11 18:24:25.845684
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Change the current environment
    os.environ['HELLO_TEST_ENV_KEY'] = 'I am a text string'
    assert isinstance(environ['HELLO_TEST_ENV_KEY'], str)
    assert environ['HELLO_TEST_ENV_KEY'] == 'I am a text string'

    # Test that a byte string encoded with utf-8 is properly converted to a text string
    os.environ['HELLO_TEST_ENV_KEY'] = b'I am a byte string'
    assert isinstance(environ['HELLO_TEST_ENV_KEY'], str)
    assert environ['HELLO_TEST_ENV_KEY'] == 'I am a byte string'

    # Test that a byte string encoded with non-utf-8 is correctly

# Generated at 2022-06-11 18:24:33.339654
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six.moves.builtins import unicode

    #
    # Test: Decode fails (return None)
    #

    # Test string in source encoding
    source_string = 'source_string'
    # Set environment variable to source string
    os.environ['source_string'] = source_string
    # Source string is not in the cache, decode should be called
    assert environ['source_string'] is None
    assert os.environ['source_string'] == source_string

    # Test bytes string in source encoding
    source_string = b'source_string'
    # Set environment variable to source string
    os.environ['source_string'] = source_string
    # Source string is not in the cache, decode should be called
    assert environ['source_string'] is None
    assert os

# Generated at 2022-06-11 18:24:39.707793
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ2 = _TextEnviron({b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82': b'test'},
                            encoding='utf-8')
    assert environ2['привет'] == 'test'

    environ2 = _TextEnviron({'привет': 'test'}, encoding='utf-8')
    assert environ2['привет'] == 'test'


# Generated at 2022-06-11 18:24:51.755571
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import StringIO

    # Test that non-ascii environment variable returns a text object
    non_ascii = u'\u2016'
    environ._raw_environ = {'ANSIBLE_ANSIBLE_MODULE_TEST_ENV_VAR': non_ascii}
    try:
        assert isinstance(environ['ANSIBLE_ANSIBLE_MODULE_TEST_ENV_VAR'], type(non_ascii))
    except AssertionError:
        # It appears that the surrogate_or_strict error handler is not defaulting to surrogateescape
        # on macOS.  This will generate a bogus value but can't be caught in this test.
        pass

# Generated at 2022-06-11 18:25:01.984829
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import pytest
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY2

    # Test getitem on a non-existing key
    # On Python 2 raises KeyError
    # On Python 3 raises the original KeyError
    with pytest.raises(KeyError):
        environ['SCRIPT_NOT_FOUND']

    if PY2:
        # Test set / get on a unicode key
        environ['TEST_UNICODE'] = u'bar'
        # unicode string returned
        assert u'bar' == environ[u'TEST_UNICODE']
        # byte string returned
        assert to_native('bar') == environ[to_native('TEST_UNICODE')]

        # Test set / get on a byte key
        en

# Generated at 2022-06-11 18:25:13.472326
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Note: This module is only to be used with unittest2 on python2.6.
    # It is not a replacement for the built-in unittest module on python2.7+ or python3.x
    from unittest2 import TestCase, main

    class _TextEnvironTest(TestCase):
        def setUp(self):
            self.old_environ = environ.copy()
            self.addCleanup(self._restore_env)

# Generated at 2022-06-11 18:25:21.088457
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Unit test for method ``__getitem__`` of class ``_TextEnviron``.
    """
    try:
        # Values are decoded using the provided encoding
        test_environ = _TextEnviron(encoding='utf-8')
        assert test_environ['LANG'] == u'en_US.UTF-8'
        # Values are cached so that repeated lookups of the same key (even when the value changed in
        # between) do not change the value that is returned
        assert test_environ['LANG'] == u'en_US.UTF-8'
        os.environ['LANG'] = b'foo'
        assert test_environ['LANG'] == u'en_US.UTF-8'
    finally:
        os.environ['LANG'] = b'en_US.UTF-8'

# Generated at 2022-06-11 18:25:32.048584
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    environ_copy = os.environ.copy()
    # Python version independent test for values that should be identical to the original
    os.environ["PATH"] = "/bin:/usr/bin"
    assert environ["PATH"] == "/bin:/usr/bin"
    assert environ["PATH"] == environ_copy["PATH"]
    os.environ["LANG"] = "en_US.UTF-8"
    assert environ["LANG"] == "en_US.UTF-8"
    assert environ["LANG"] == environ_copy["LANG"]

    os.environ["ANSIBLE_TEST_BYTES_KEY"] = b"\xc3\xa8\xc3\xb2\xc3\xa9"

# Generated at 2022-06-11 18:25:39.779251
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # When the key does not exist in both environ and _value_cache
    try:
        environ.__getitem__('testkey')
    # Then a KeyError should be thrown
    except KeyError as e:
        assert 'testkey' == e.args[0]

    # When the key does not exist in environ but exists in _value_cache
    environ._value_cache['testkey'] = 'testvalue'
    # Then the value in _value_cache should be returned
    assert 'testvalue' == environ.__getitem__('testkey')

    # When the key exists in environ but not in _value_cache
    environ._raw_environ['testkey'] = 'testvalue'
    # Then the value in environ should be returned

# Generated at 2022-06-11 18:25:47.106588
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test that we correctly get text back from the environment
    """
    environ = _TextEnviron({b'ANSIBLE_TEST_ENV': b'Test Value'}, encoding='utf-8')
    assert environ['ANSIBLE_TEST_ENV'] == u'Test Value'
    assert environ[b'ANSIBLE_TEST_ENV'] == u'Test Value'
    # Test that we get unicode back from the environ object
    assert isinstance(environ['ANSIBLE_TEST_ENV'], unicode)


# Generated at 2022-06-11 18:25:50.055881
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'FOO_BAR': 'yak'})
    assert env['FOO_BAR'] == 'yak'



# Generated at 2022-06-11 18:25:57.598084
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # First initialize the a reference to the actual os.environ
    myEnviron = os.environ
    # Modify environ dictionary
    os.environ['ANSIBLE_TEST_ENV_VARIABLE'] = 'test'
    # Validate the value returned by environ.__getitem__ matches with the value returned by os.environ
    assert myEnviron['ANSIBLE_TEST_ENV_VARIABLE'] == environ['ANSIBLE_TEST_ENV_VARIABLE']


# Generated at 2022-06-11 18:26:05.372733
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # First test with a basic value
    environ['FOO'] = 'bar'
    assert(environ['FOO'] == 'bar')
    # Now test with a unicode value that doesn't require decoding
    environ['FOO'] = u'☃'
    if PY3:
        assert(environ['FOO'] == u'☃')
    else:
        assert(environ['FOO'] == '☃')
    # Now test with a unicode value that *does* require decoding
    environ['FOO'] = '☃'
    if PY3:
        assert(environ['FOO'] == '☃')
    else:
        assert(environ['FOO'] == u'☃')

    # Test caching
    # First, set a value that doesn't require decoding.  It's key

# Generated at 2022-06-11 18:26:26.942423
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert to_text(b'\xE0\xBF\x80') == environ[b'\xE0\xBF\x80']
    assert to_text(b'\xE0\xBF\x80') == environ[u'\u0300']
    # Warnings from the test runner, not from the code under test
    import warnings
    with warnings.catch_warnings(record=True) as cm:
        environ[b'\xE0\xBF\x80'] == environ[u'\u0301']
    assert len(cm) == 0
    assert to_text(b'\xE0\xBF\x80') == environ[u'\u0300']

# Generated at 2022-06-11 18:26:37.793451
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = _TextEnviron()
    test_environ['TEST_VAR_TEST_GET_WITH_BINARY_DATA'] = '00111101 01111001 01110000 00111000 01110111 01101001 01101100 01101100 00101100 01001110 00111010 00111010'

# Generated at 2022-06-11 18:26:49.271189
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    old_env = os.environ.copy()
    os.environ.clear()
    test_env = {'basic': 'spam',
                'unicode': u'spâm',
                'bytes': b'sp\xc3\xa2m',
                }
    os.environ.update(test_env)

# Generated at 2022-06-11 18:26:54.482213
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({'A': u'\u263A'}, 'ascii')
    result = environ['A']
    assert result == u'?'

# Generated at 2022-06-11 18:27:01.569771
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test: __getitem__ should return a unicode string
    assert isinstance(environ['HOME'], unicode)

    # Test: __getitem__ should return the same value as os.environ for an environment variable
    # which does not contain a unicode character
    assert 'HOME' in environ
    assert environ['HOME'] == os.environ['HOME']

    # Test: __getitem__ should return the same value as os.environ for an environment variable
    # which contains a unicode character
    assert 'LANG' in environ
    assert environ['LANG'] == os.environ['LANG']

    # Test: __getitem__ should not cache the result of the os.environ lookup
    original_lang = os.environ['LANG']
    os.environ['LANG'] += 'UTF-8'

# Generated at 2022-06-11 18:27:03.618863
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    environ['foo'] = to_bytes('bar', errors='replace')

    assert environ['foo'] == 'bar'



# Generated at 2022-06-11 18:27:12.091417
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_cases = [
        (to_bytes('HELLO', 'utf-8'), to_text('HELLO', 'utf-8')),
        (to_bytes('HELLO', 'ascii'), to_text('HELLO', 'utf-8', 'surrogate_or_strict')),
        (b'HELLO', to_text('HELLO', 'utf-8', 'surrogate_or_strict')),
    ]
    for data, expected in test_cases:
        text_environ = _TextEnviron({'HELLO': data}, encoding='utf-8')
        assert text_environ['HELLO'] == expected

# Generated at 2022-06-11 18:27:22.375859
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Make sure _TextEnviron._TextEnviron.__getitem__ works"""
    # Make sure that encoding works
    import locale
    import os

    test_setting = u'ö'
    # pylint: disable=no-member,protected-access
    assert isinstance(test_setting, str)
    assert not isinstance(test_setting, bytes)

    # Test that an environment variable is returned as a text string
    os.environ['TEST_SETTING'] = to_bytes(test_setting, encoding=locale.getpreferredencoding())
    assert isinstance(os.environ['TEST_SETTING'], str)
    assert not isinstance(os.environ['TEST_SETTING'], bytes)

    # Set the environment variable and ensure that we get the correct unicode string
    test_environ = _

# Generated at 2022-06-11 18:27:32.988236
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import io
    import unittest

    class TestCase(unittest.TestCase):
        def test__TextEnviron___getitem__(self):
            if PY3:
                self.assertEqual(environ.encoding, 'utf-8')
            else:
                self.assertEqual(environ.encoding, sys.getfilesystemencoding())
            self.assertEqual(environ['HOME'], os.path.expanduser('~'))
            self.assertEqual(environ.get('HOME'), os.path.expanduser('~'))
            # Testing for surrogate_or_strict errors is a bit tough, so let's just make sure we
            # don't crash before checking for surrogate_or_strict errors
            environ['BLAH'] = u'\ue000'

# Generated at 2022-06-11 18:27:35.419496
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Check that we get the value back in text form
    environ['ANSIBLE_TEST_VALUE'] = 'value'
    assert environ['ANSIBLE_TEST_VALUE'] == 'value'



# Generated at 2022-06-11 18:28:09.605392
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Note that _TextEnviron tries to mimic what os.environ would do on Python3
    # Test that we produce the correct output when running on Python3
    if PY3:
        environ['DUMMY'] = 'value'
        # os.environ returns a string on Python3, so a _TextEnviron should do so too
        assert isinstance(environ['DUMMY'], str)
        assert environ['DUMMY'] == 'value'
    # Test that we produce the correct output when running on Python2
    else:
        # Setting a byte string should work.  The value should come back as a text string
        # encoded with sys.getfilesystemencoding()
        environ['DUMMY'] = b'value'
        assert isinstance(environ['DUMMY'], str)

# Generated at 2022-06-11 18:28:20.007293
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Populate an environment that looks like one that might have been used with Python2
    # Here are the rules:
    # - ASCII is just ascii
    # - ascii in Py2 is bytes in Py3
    # - latin-1 is utf-8 in Py2
    # - utf-8 is utf-8 in Py2
    py2_env = {'ascii': b'ascii', 'latin-1': b'\xe9', 'utf-8': to_bytes(u'\xe9', 'utf-8')}
    # Python3 os.environ doesn't do decoding either so this is the expected value

# Generated at 2022-06-11 18:28:30.824195
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_py2 = {b'name1': b'value1', b'name2': b'value2'}
    # noinspection PyArgumentList
    environ_py3 = {'name1': 'value1', 'name2': 'value2'}
    # noinspection PyArgumentList
    environ_py3_non_ascii = {'name1': 'value1', 'name2': u'value2_\u00b5'}
    # noinspection PyArgumentList
    environ_py3_non_ascii_bytes = {'name1': 'value1', 'name2': 'value2_\xc2\xb5'}


# Generated at 2022-06-11 18:28:33.563147
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Unit test for method __getitem__ of class _TextEnviron

    assert environ['PATH'] == os.environb['PATH'].decode('utf-8')



# Generated at 2022-06-11 18:28:37.596771
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    orig_environ = dict(os.environ)
    os.environ = _TextEnviron(os.environ)
    os.environ["ABC"] = "Test"
    assert os.environ["ABC"] == "Test"
    os.environ = orig_environ

# Generated at 2022-06-11 18:28:42.810319
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Normal usage
    test_environ = _TextEnviron({'key1': 'value1'})
    assert test_environ['key1'] == 'value1'

    # Key is missing
    test_environ = _TextEnviron()
    try:
        test_environ['key1']
    except KeyError:
        pass
    else:
        assert False

    # Key is in the environment
    environ['key'] = 'value'
    test_environ = _TextEnviron()
    assert test_environ['key'] == 'value'

    # Method cache is working
    test_environ = _TextEnviron({'key1': 'value1'})
    assert test_environ['key1'] == 'value1'

# Generated at 2022-06-11 18:28:53.983676
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a mock environ dictionary
    # NOTE: It's necessary to create a copy of os.environ because the method __setitem__ of
    # _TextEnviron class modifies os.environ.
    fake_environ = os.environ.copy()
    fake_environ['ANSIBLE_TEST'] = u"¡ŁüßßßèØØØØØ®⅔¾¿\u2665"
    # Create a mock _TextEnviron object with the new fake_environ
    text_environ = _TextEnviron(env=fake_environ)
    assert text_environ['ANSIBLE_TEST'] == u"¡ŁüßßßèØØØØØ®⅔¾¿\u2665"
    #

# Generated at 2022-06-11 18:29:04.756790
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import warnings
    # Setup
    from pprint import pprint
    from ansible.module_utils.common._collections_compat import MutableMapping
    orig_environ = os.environ
    os.environ = {to_bytes('LANG'): to_bytes('C'),
                  to_bytes('LC_ALL'): to_bytes('C'),
                  to_bytes('LC_CTYPE'): to_bytes('C.UTF-8')}
    # Test
    environ = _TextEnviron(os.environ)
    assert environ == {'LANG': 'C', 'LC_ALL': 'C', 'LC_CTYPE': 'C.UTF-8'}

# Generated at 2022-06-11 18:29:07.697752
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(environ.__getitem__('PATH'), str)
    assert isinstance(environ.__getitem__('ANSIBLE_CALLBACK_PLUGINS'), str)


# Generated at 2022-06-11 18:29:14.275808
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test the return value of __getitem__
    """
    # Test with a dictionary as constructor parameter
    myenv = _TextEnviron({'str': 'abc', 'bytes': b'abc', 'mixed': b'abc'.decode('utf-8')})
    assert myenv['str'] == 'abc'
    assert myenv['bytes'] == u'abc'
    assert myenv['mixed'] == u'abc'



# Generated at 2022-06-11 18:30:07.303798
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({'bytes': '\u304d\u304c'})
    assert env['bytes'] == '\u304d\u304c'

# Generated at 2022-06-11 18:30:17.776869
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # _TextEnviron should throw a KeyError if the key is not present in os.environ
    try:
        os.environ["test-key"]
        test_ok = False
        raise RuntimeError("test_key should not have been present in os.environ")
    except KeyError:
        test_ok = True

    try:
        environ["test-key"]
        test_ok = False
        raise RuntimeError("test_key should not have been present in environ")
    except KeyError:
        test_ok = test_ok and True

    # _TextEnviron should return a text string if key is present in os.environ
    os.environ["test-key"] = b'value'
    test_ok = test_ok and isinstance(environ["test-key"], str)

    # _TextEnviron should

# Generated at 2022-06-11 18:30:28.452350
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os

    # PY2: I want to make sure that the _value_cache keeps the same thing.
    # PY3: I want to make sure that the type of return value is unicode.
    environ['FOO'] = 'foo'
    if PY3:
        assert isinstance(environ['FOO'], str)
    assert environ['FOO'] == 'foo'

    # PY2: I want to make sure that the input value can encode by the specified encoding.
    # PY3: I want to make sure that the type of return value is unicode.
    environ['FOO'] = u'あいうえお'
    if PY3:
        assert isinstance(environ['FOO'], str)

# Generated at 2022-06-11 18:30:31.466347
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(os.environ, _TextEnviron)
    assert PY3 or isinstance(os.environ, MutableMapping)


# Generated at 2022-06-11 18:30:40.928068
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # testing with a regular PY3 string
    environ['key1'] = 'value1'
    if PY3:
        assert environ['key1'] == 'value1'
    else:
        assert environ['key1'] == u'value1'

    # testing with a bytes string
    environ['key2'] = b'value2'
    if PY3:
        assert environ['key2'] == 'value2'
    else:
        assert environ['key2'] == u'value2'

    # testing with a unicode string
    environ['key3'] = u'value3'
    assert environ['key3'] == u'value3'

    # testing with a non-ascii string
    environ['key4'] = 'value4-\xe9'

# Generated at 2022-06-11 18:30:50.535701
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os

    tmp_raw_environ = {b'AWS_ACCESS_KEY_ID': b'0' * 20,
                       b'ANSIBLE_DEBUG': b'true',
                       b'BYTES_VALUE' : b'\xff',
                       b'ARRAY_VALUE': b'a,b,c'}

    environ = _TextEnviron(env=tmp_raw_environ)

    assert environ['AWS_ACCESS_KEY_ID'] == u'0' * 20
    assert environ['ANSIBLE_DEBUG'] == u'true'
    assert environ['BYTES_VALUE'] == u'\xff'
    assert environ['ARRAY_VALUE'] == u'a,b,c'

# Generated at 2022-06-11 18:30:55.656518
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_bytes = os.environ
    environ_text = _TextEnviron(env=environ_bytes, encoding='utf-8')
    for byte_key, byte_value in environ_bytes.items():
        text_value = environ_text[byte_key]
        assert(isinstance(text_value, str))
        assert(text_value == byte_value.decode('utf-8'))

# Generated at 2022-06-11 18:31:02.155048
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['test_utf8_key'] = b'\xc3\x90\xc3\x91\xc3\x92\xc3\x93\xc3\x94\xc3\x95\xc3\x96'
    result = environ['test_utf8_key']
    assert isinstance(result, str), 'Expected result of type str'
    assert result == 'ÐÑÒÓÔÕÖ', 'Unexpected value of result'