

# Generated at 2022-06-11 18:21:05.327117
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'TEST_ENV': b'\xe2\x98\x83'}, encoding='utf-8')
    assert environ['TEST_ENV'] == u'\u2603'


# Generated at 2022-06-11 18:21:13.004376
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Unit test for method _TextEnviron.__getitem__"""
    import unittest
    import types

    class Test(unittest.TestCase):
        def setUp(self):
            self.environ = _TextEnviron(encoding='ascii')

        def test_getitem(self):
            self.environ['A_KEY'] = b'\x01\x02\x03\x04'
            self.assertEqual(self.environ['A_KEY'], '\x01\x02\x03\x04')

        def test_getitem_caching(self):
            self.environ['A_KEY'] = b'\x01\x02\x03\x04'

# Generated at 2022-06-11 18:21:21.509848
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:21:24.578949
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()

    value = 'value'
    key = 'key'
    env[key] = value

    assert env[key] == value



# Generated at 2022-06-11 18:21:34.586351
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    t = _TextEnviron()

    # return value of KeyError is not implemented to be tested

    # len(a) < len(b)
    x = b'1234567890'
    y = b'123456789012345'
    t._raw_environ[b'x'] = x
    t._raw_environ[b'y'] = y
    assert b'x' in t
    assert b'y' in t
    assert t[b'x'] == '1234567890'
    assert t[b'y'] == '123456789012345'

    # len(a) == len(b)
    x = b'1234567890'
    y = b'1234567890'
    t._raw_environ[b'x'] = x
    t._raw_environ

# Generated at 2022-06-11 18:21:45.458901
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:21:52.800159
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
  import os
  import sys
  import os
  import sys

  environ = _TextEnviron(encoding='utf-8')

  print(sys.version)
  print(environ['PATH'])

  # For test, we change the PATH variable to 'c:\program files'.  
  # This variable should be encoded and decoded correctly, 
  # so the output of next line should be 'c:\program files'
  environ['PATH'] = 'c:\\program files'  # I\ changed to \\
  print(environ['PATH'])

#test__TextEnviron___getitem__()

# Generated at 2022-06-11 18:21:55.736462
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    _TextEnviron.__getitem__(environ, 'LANG')


# Generated at 2022-06-11 18:22:04.292602
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    orig_environ = {to_bytes('PATH', encoding='utf-8'): to_bytes(u'/usr/bin', encoding='utf-8'),
                    to_bytes('PS1', encoding='utf-8'): to_bytes('\\u:\\w \\$', encoding='utf-8'),
                    to_bytes('LC_ALL', encoding='utf-8'): to_bytes('C', encoding='utf-8'),
                    to_bytes('LANG', encoding='utf-8'): to_bytes('C', encoding='utf-8'),
                    to_bytes('CYGWIN', encoding='utf-8'): to_bytes('nodosfilewarning', encoding='utf-8')}
    orig_text_environ = _TextEnviron(env=orig_environ, encoding='utf-8')

# Generated at 2022-06-11 18:22:08.934959
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'a': b'1', b'b': b'2'}, 'utf-8')
    assert env[b'a'] == '1'
    assert env[b'b'] == '2'

# Generated at 2022-06-11 18:22:19.758260
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_copy = environ.copy()
    variables = (
        'HOME',
        'HOMEDRIVE',
        'HOMEPATH',
        'HOSTNAME',
        'LANG',
        'PATH',
        'SESSION_MANAGER',
        'SHELL',
        'SHLVL',
        'SYSTEMDRIVE',
        'SYSTEMROOT',
        'USER',
        'USERNAME',
        'USERPROFILE',
        'WINDIR',
    )

    for name in variables:
        if name in environ_copy:
            del environ_copy[name]

    os.environ.update(environ_copy)

    environ2 = _TextEnviron(encoding='utf-8')


# Generated at 2022-06-11 18:22:26.326614
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test passthrough of unicode values
    test_environ = {u'fnord': u'\u420F'}
    environ = _TextEnviron(env=test_environ)
    assert environ[u'fnord'] == u'\u420F'

    # Test UTF-8 values
    test_environ = {'fnord': u'\u420F'.encode('utf-8')}
    environ = _TextEnviron(env=test_environ)
    assert environ[u'fnord'] == u'\u420F'

    # Test basic surrogate handling for non-existent key
    test_environ = {}
    environ = _TextEnviron(env=test_environ)
    try:
        environ[u'fnord']
    except KeyError:
        key_

# Generated at 2022-06-11 18:22:34.735023
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Tests for _TextEnviron.__getitem__
    """
    from ansible.module_utils.basic import _TextEnviron

    # Test normal data
    test_dict = {'a': 'b', 'c': 'd'}
    environ = _TextEnviron(env=test_dict, encoding='utf-8')
    assert 'b' == environ['a']
    assert 'd' == environ['c']

    # Test decoding
    test_dict = {'a': b'b', 'c': b'd'}
    environ = _TextEnviron(env=test_dict, encoding='utf-8')
    assert 'b' == environ['a']
    assert 'd' == environ['c']

    # Test non-string data

# Generated at 2022-06-11 18:22:39.303556
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ["test_getitem___key"] = b"test value with non-ascii: \xe9\xe9"
    text_environ = _TextEnviron()
    value = text_environ["test_getitem___key"]
    assert value == "test value with non-ascii: \xe9\xe9", value


# Generated at 2022-06-11 18:22:49.649338
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Verify that when the environment variable has uppercase characters, to_text returns a
    # lowercase string by default
    environ['PATH'] = 'E:\\Progra~1\\7-Zip;E:\\Progra~1\\WinSCP\;C:\\bin'
    assert environ['PATH'].startswith('e:\\Progra~1\\7-zip;e:\\Progra~1\\winscp;')

    # Verify that when the environment variable has uppercase characters, to_text returns a
    # lowercase string by default
    environ['PATH'] = 'E:\\Progra~1\\7-Zip;E:\\Progra~1\\WinSCP\;C:\\bin'

# Generated at 2022-06-11 18:22:54.742837
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PYTHONIOENCODING'] == 'utf-8'
    # Test a non-utf8 environment variable
    if 'LANG' in environ:
        assert environ['LANG'] != 'utf-8'


# Generated at 2022-06-11 18:23:02.637066
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_bak = os.environ
    try:
        os.environ = dict(HELLO="world", HELLO_BYTES=b"world")
        env = _TextEnviron(encoding='utf-8')
        assert env['HELLO'] == 'world'
        assert env['HELLO_BYTES'] == 'world'
        assert isinstance(env['HELLO_BYTES'], str)

        env = _TextEnviron(encoding='latin-1')
        assert env['HELLO_BYTES'] == b'world'.decode('latin-1')
        return 0
    finally:
        os.environ = environ_bak



# Generated at 2022-06-11 18:23:08.286593
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(encoding='utf-8')
    key = "abc"
    value = "我能吞下玻璃而不伤身体"
    os.environ[key] = value
    environ_item = environ[key]
    os.environ.pop(key)
    del environ
    assert environ_item == value

# Generated at 2022-06-11 18:23:10.526481
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(environ['PATH'], str)

# Generated at 2022-06-11 18:23:15.881713
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Example 1:
    # Empty environment, without encoding, without cache

    result = environ['random_key']

    assert result == ''
    assert 'random_key' in environ._raw_environ
    assert environ._raw_environ['random_key'] == ''
    assert 'random_key' in environ._value_cache
    assert environ._value_cache[''] == result

    # Example 2:
    # Empty environment, with encoding, with cache

    environ._value_cache[''] = u'value_from_cache'
    result = environ['random_key']

    assert result == u'value_from_cache'
    assert 'random_key' in environ._raw_environ
    assert environ._raw_environ['random_key'] == ''
    assert 'random_key' in en

# Generated at 2022-06-11 18:23:27.280438
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test exists
    assert hasattr(environ, '__getitem__')

    # Test normal items work as expected
    assert environ['PWD'] == '/Users/badger/src/ansible/hacking'

    # Test values with no encoding specified are handled

# Generated at 2022-06-11 18:23:28.123032
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    environ.__getitem__('HOME')

# Generated at 2022-06-11 18:23:36.771480
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import mock
    # Test to make sure cache keys are undecoded values
    with mock.patch.dict(environ._raw_environ, {b'TEST_KEY': b'value'}, clear=True):
        environ[b'TEST_KEY'] = b'value'
        assert environ.__getitem__(b'TEST_KEY') == u'value'

    # Test with unicode values
    with mock.patch.dict(environ._raw_environ, {b'TEST_KEY': b'value'}, clear=True):
        environ[u'TEST_KEY'] = u'value'
        assert environ.__getitem__(b'TEST_KEY') == u'value'
        assert environ.__getitem__(u'TEST_KEY') == u'value'

    #

# Generated at 2022-06-11 18:23:40.737182
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if not PY3:
        environ._raw_environ['TEST_KEY'] = to_bytes('value', encoding='utf-8')
        assert isinstance(environ['TEST_KEY'], type(u''))

# Generated at 2022-06-11 18:23:52.862708
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ[four] = to_bytes(four, encoding=environ.encoding, nonstring='strict',
                             errors='surrogate_or_strict')
    print(environ[four])
    assert environ[four] == four

# Test code to be executed when running this file
import uuid
# Test output: 'AAA'
four = u'\U0001F4A9\U0001F4A9\U0001F4A9'  # '💩💩💩'
# Test output: '💩💩'
five = u'\U0001F4A9'
# Test output: '💩💩💩💩'

# Generated at 2022-06-11 18:24:03.205591
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test helper to ensure that we're getting text values on python2
    if PY3:
        def assert_text(value):
            assert isinstance(value, str)
    else:
        def assert_text(value):
            assert isinstance(value, unicode)

    # Test plain text
    environ['FOO'] = 'bar1'
    assert_text(environ['FOO'])

    # Test unicode characters
    environ['FOO'] = u'b\u0061r2'
    assert_text(environ['FOO'])

    # Test bytestrings encoded as utf-8
    environ['FOO'] = b'b\xc3\xa1r3'
    assert_text(environ['FOO'])

    # Test bytestrings encoded as iso-8859-1


# Generated at 2022-06-11 18:24:13.999525
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # setup
    text_environ = _TextEnviron()
    env = dict(DEFAULT_CHARSET='utf-8',
               LANG='en_US.UTF-8',
               LC_ALL='en_US.UTF-8',
               LC_CTYPE='en_US.UTF-8',
               PWD='/var/tmp/ansible/roles/test_role/tasks',
               SHELL='/bin/bash')
    text_environ._raw_environ = env
    text_environ._value_cache = {}
    text_environ.encoding = 'utf-8'

    for key, value in env.items():
        # exercise
        result = text_environ.__getitem__(key)
        # verify
        assert result == value


# Generated at 2022-06-11 18:24:23.249340
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """
    # Ensure that non-string environment variables are passed through
    # without decoding (and without throwing an exception)
    # We cannot use os.environ here because it is wrapped in _TextEnviron
    # and if we try to test it this way we'll recursively call ourselves
    env = os.__dict__["environ"]
    env['PYTHONPATH'] = ':'.join(sys.path)
    t_env = _TextEnviron({'PYTHONPATH': env['PYTHONPATH']})
    a_env = t_env['PYTHONPATH']
    assert a_env == env['PYTHONPATH'], "Environment variable did not pass through"

# Generated at 2022-06-11 18:24:27.300140
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ[b'test_key'] = b'test_value'
    assert b'test_value' == environ[b'test_key']
    assert u'test_value' == environ[b'test_key']


# Generated at 2022-06-11 18:24:33.931374
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test the __getitem__ function of _TextEnviron
    """
    # pylint: disable=too-many-locals,unused-variable
    #
    # Create a dict and wrap it in _TextEnviron.  Test that keys are found & values are stringified
    #
    # Test with a python2 and python3 unicode key
    test_data = to_bytes(u'f\u00f6\u00f6', encoding='utf-8')
    test_dict = {u'a': u'value', to_text(b'a', encoding='utf-8'): to_text(test_data, encoding='utf-8')}
    text_environ = _TextEnviron(test_dict)

# Generated at 2022-06-11 18:24:44.023770
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    environ_mock = dict()
    environ_mock["key1"] = b"\xFF\xFF"
    environ_mock["key2"] = b"\x00\x00"
    text_environ = _TextEnviron(environ_mock)

    # Test
    value1 = text_environ["key1"]
    value2 = text_environ["key2"]

    # Assert 1
    assert value1 == u"\udcff\udcff"

    # Assert 2
    assert value2 == u"\0\0"


# Generated at 2022-06-11 18:24:48.653651
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = _TextEnviron({'plain_ascii': 'plain_ascii',
                                 # A UTF-8 single multi-byte char
                                 # Encoded to bytes as "0xF0 0x9F 0x8C 0x92"
                                 'unicode': to_bytes('\U0001f4C2'),
                                 # A surrogate pair encoded as a Python string
                                 # Encoded to bytes as "0xF0 0x9F 0x8C 0x92"
                                 'surrogate_unicode': to_bytes('\U0001F40D'),
                                 # A surrogate pair encoded as a Python byte string
                                 'surrogate_bytes': to_bytes('\xed\xa0\xbd\xed\xb8\x8d', 'UTF-8'),
                                 })

# Generated at 2022-06-11 18:24:52.942579
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ.clear()
    environ['TESTENV'] = 'têstvalúe'
    assert environ['TESTENV'] == u'têstvalúe'


# Generated at 2022-06-11 18:25:02.656889
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    def test_case(encoding, key, raw_value, value):
        cache = {}
        raw_environ = {key: raw_value}
        environ = _TextEnviron(env=raw_environ, encoding=encoding)
        assert environ[key] == value

    # Test with the default fs encoding
    encoding = sys.getfilesystemencoding()
    test_case(encoding, u'key1', b'value1', u'value1')
    test_case(encoding, u'key2', u'value2'.encode(encoding), u'value2')

    # Test with utf-8
    encoding = 'utf-8'
    test_case(encoding, u'key1', b'value1', u'value1')

# Generated at 2022-06-11 18:25:13.854895
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'LANG': 'sv_SE.UTF-8',
                           b'PATH': '***/***/***:/bin',
                           u'LANGUAGE': 'sv:en_US:en',
                           b'LANGUAGE': 'sv:en_US:en',
                           'LANGUAGE': 'sv:en_US:en'},
                           encoding='utf-8')

    assert environ[b'LANG'] == 'sv_SE.UTF-8'
    assert environ['LANGUAGE'] == 'sv:en_US:en'

    try:
        environ[u'LANG']
    except KeyError:
        pass

    try:
        environ[b'LANGUAGE']
    except KeyError:
        pass

# Unit

# Generated at 2022-06-11 18:25:21.293235
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    class _TextEnviron(MutableMapping):
        """
        Utility class to return text strings from the environment instead of byte strings

        Mimics the behaviour of os.environ on Python3
        """
        def __init__(self, env=None, encoding=None):
            if env is None:
                env = os.environ
            self._raw_environ = env
            self._value_cache = {}
            # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
            # instead of utf-8

# Generated at 2022-06-11 18:25:32.269762
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test passthru when encoding is sys.getfilesystemencoding()
    if os.name == 'nt':
        assert isinstance(environ[b'PATH'], str)
        assert environ[b'PATH'].encode(sys.getfilesystemencoding()) == b'C:\\Windows\\system32;C:\\Windows;C:\\Windows\\System32\\Wbem;C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\;C:\\Program Files\\Docker\\Docker\\Resources\\bin;C:\\ProgramData\\DockerDesktop\\version-bin'
    else:
        assert isinstance(environ[b'PATH'], str)

# Generated at 2022-06-11 18:25:34.672876
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    assert isinstance(env[u'LANG'], unicode)
    assert isinstance(env['LANG'], unicode)



# Generated at 2022-06-11 18:25:37.692576
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ[b'foo'] = b'bar'
    assert environ['foo'] == u'bar'
    # cached value
    os.environ[b'foo'] = b'bar'
    assert environ['foo'] == u'bar'



# Generated at 2022-06-11 18:25:47.334668
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ.clear()

# Generated at 2022-06-11 18:26:01.966801
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import sys
    from ansible.module_utils._text import to_bytes, to_text

    # test original values
    if PY3:
        assert to_bytes(environ['HOME']) == os.environ['HOME']
    else:
        # we must ensure that the original encoding is preserved
        assert to_bytes(environ['HOME']) == to_bytes(os.environ['HOME'], sys.getfilesystemencoding())

    # set some new variable
    environ['HOME'] = 'testHome'
    assert to_bytes(environ['HOME']) == b'testHome'

    # check if new variable has been set properly
    assert to_bytes(environ['HOME']) == to_bytes(os.environ['HOME'], sys.getfilesystemencoding())



# Generated at 2022-06-11 18:26:12.203602
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    from ansible.module_utils._text import to_bytes, to_text

    # The default list of environment variables is taken from the POSIX standards:
    # http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap08.html#tag_08_03
    # Add to that list some commonly defined environment variables and some commonly used
    # environment variables by Ansible.

# Generated at 2022-06-11 18:26:19.100661
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import pytest
    try:
        environ['DEFAULT_ENCODING']
    except Exception as e:
        pytest.fail(u'Failed to get environ[DEFAULT_ENCODING]: %s' % to_text(e), pytrace=True)
    if not PY3:
        try:
            environ['TEST_BYTE_ENC'] = '\xC3\xB6'.encode('utf-8')
        except Exception as e:
            pytest.fail(u'Failed to set environ[TEST_BYTE_ENC]: %s' % to_text(e), pytrace=True)

# Generated at 2022-06-11 18:26:26.942326
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(encoding='utf-8')
    # tests with valid str
    environ['test'] = 'test'
    assert isinstance(environ['test'], str)
    # tests with valid bytes
    environ['test'] = b'test'
    assert isinstance(environ['test'], str)
    # tests with surrogate pairs (unicode 4-bytes)
    environ['test'] = '\U0001F600'
    assert isinstance(environ['test'], str)
    # tests with non string
    environ['test'] = 3
    assert isinstance(environ['test'], str)

# Generated at 2022-06-11 18:26:32.911015
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test for non-ASCII value
    assert environ['PYTHONIOENCODING'] == 'utf-8'

    # test for ASCII value of a non-ascii key
    # py2: environ is a mappingproxy that returns byte strings
    if not PY3:
        assert isinstance(environ[b'ASCIICONTROL'], str)



# Generated at 2022-06-11 18:26:37.753793
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['A'] = 'B'
    assert(environ['A'] == 'B')
    environ['A'] = u'B'
    assert(environ['A'] == u'B')
    environ['A'] = b'B'
    assert(environ['A'] == u'B')


# Generated at 2022-06-11 18:26:42.189017
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ._raw_environ = os.environ.copy()
    environ._raw_environ[to_bytes('abc')] = to_bytes('def')
    assert environ[to_text('abc')] == to_text('def')



# Generated at 2022-06-11 18:26:53.242811
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import StringIO

    os.environ["TEST_STRING"] = b"\xef\xbb\xbf\x41\x41\x41\x00\x42\x42\x42"

    # Test for PY3==True
    # When PY3 == True, the value of os.environ[key] is a text string.
    # The class _TextEnviron should return a string as is.
    original_stdout, original_stderr = sys.stdout, sys.stderr

# Generated at 2022-06-11 18:27:00.708959
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_test_utf8 = _TextEnviron({b'ANSIBLE_MODULE_ARGS': to_bytes('{}', encoding='utf-8')}, 'utf-8')
    environ_test_ascii = _TextEnviron({b'ANSIBLE_MODULE_ARGS': '{}'}, 'ascii')
    if not PY3:
        # On Python2, environ_test_utf8 shall return the expected output
        assert environ_test_utf8['ANSIBLE_MODULE_ARGS'] == u'{}'
        # On Python2, environ_test_ascii shall return the expected output
        assert environ_test_ascii['ANSIBLE_MODULE_ARGS'] == u'{}'

# Generated at 2022-06-11 18:27:09.742816
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ["ascii_only"] = "a_byte_string"
    os.environ["non_ascii"] = to_bytes("æ_byte_string")

    te = _TextEnviron(encoding='utf-8')

    assert te["ascii_only"] == "a_byte_string"
    assert te["non_ascii"] == u"æ_byte_string"
    assert te.get("non_ascii") == u"æ_byte_string"
    assert te.get("non_ascii", "default") == u"æ_byte_string"
    assert te.get("missing_key", "default") == "default"

# Generated at 2022-06-11 18:27:33.494344
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Construct environment that assumes the default encoding of utf-8
    testenv = _TextEnviron(env={b'test1': 'testu8', b'test2': 'test ascii'}, encoding='utf-8')

    # Test that a unicode string can be used to find a unicode env var
    assert testenv['test1'] == u'testu8'

    # Test that a str (on py2) or unicode string (on py3) can be used to find an ascii env var
    assert testenv[u'test2'] == u'test ascii'
    if not PY3:
        assert testenv[b'test2'] == u'test ascii'

    # Test that a unicode string will return error when used to find an non-unicode env var

# Generated at 2022-06-11 18:27:38.485457
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Arrange
    encoded_value = b'\xe1\x84\x8c\xe1\x85\xb5\xe1\x86\xab\xe1\x84\x92\xe1\x85\xa1\xe1\x86\xa8'

    # Act
    result = environ.__getitem__('_')

    # Assert
    assert result == '진학'


# Generated at 2022-06-11 18:27:49.429695
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from subprocess import Popen, PIPE

    # Insert a variable in the environment which will be different if we run
    # this again.  We want this to be decoded to text.
    import datetime
    os.environ['ANSIBLE_TEST_VARIABLE'] = datetime.datetime.now().isoformat()

    # If we have Python3, we want the environ variable to be a unicode string.
    # If we have Python2, we want it to be byte strings
    if PY3:
        expected_type = str
    else:
        expected_type = bytes

    # the script that gets run by Popen
    # It can't use the global 'environ' reference because it will use the environ
    # reference of the binary that is running this script.

# Generated at 2022-06-11 18:27:58.238171
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_env_keys = [
        b'LANG',
        b'LC_ALL',
        b'LC_CTYPE',
        # Note that these are absent on my test system (Mac OS X 10.12.5)
        #b'LC_COLLATE',
        #b'LC_MESSAGES',
        #b'LC_MONETARY',
        #b'LC_NUMERIC',
        #b'LC_TIME',
    ]
    for key in test_env_keys:
        value = os.environ.get(key, None)
        assert value == environ[key], 'Expected {} under key {!a}'.format(value, key)


# Generated at 2022-06-11 18:28:04.585270
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Tests to make sure we get back text instead of bytes
    test_env = _TextEnviron({to_bytes('testitem', encoding='utf-8'): to_bytes('testvalue', encoding='utf-8')})
    assert isinstance(test_env['testitem'], str)
    assert test_env['testitem'] == 'testvalue'



# Generated at 2022-06-11 18:28:13.075108
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that when a non-unicode value is set, we get unicode
    environ['ANSIBLE_ARCHIVE_EXTRACT_PATH'] = b'/tmp/extract'
    if PY3:
        assert environ['ANSIBLE_ARCHIVE_EXTRACT_PATH'] == '/tmp/extract'
    else:
        assert environ['ANSIBLE_ARCHIVE_EXTRACT_PATH'] == u'/tmp/extract'
        assert isinstance(environ['ANSIBLE_ARCHIVE_EXTRACT_PATH'], unicode)

    # Test that when a unicode value is set, we get the same unicode
    environ['ANSIBLE_ARCHIVE_EXTRACT_PATH'] = u'/tmp/extract'
    if PY3:
        assert environ['ANSIBLE_ARCHIVE_EXTRACT_PATH']

# Generated at 2022-06-11 18:28:19.893767
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # The environment is a dict of text strings on Python3
    if PY3:
        assert isinstance(environ, dict)
        assert isinstance(environ['PATH'], str)
    # On Python2 the environment is a dict of byte strings.  When using environ to get
    # those values it returns a copy of those strings converted to text.
    else:
        assert isinstance(environ, _TextEnviron)
        assert isinstance(environ['PATH'], str)


# Generated at 2022-06-11 18:28:24.207461
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # In Python 2, os.environ returns byte strings
    assert isinstance(environ._raw_environ['HOME'], bytes)
    # In Python 3, os.environ returns text strings
    assert isinstance(environ['HOME'], unicode)
    assert environ['HOME'] == os.environ['HOME']



# Generated at 2022-06-11 18:28:35.635751
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes, to_text
    import sys

    # Python3: verify os.environ when it's fully unicode
    if PY3:
        os.environ[b'foo'] = b'\xc3\xb1\x81\x8f\xe9\x9e\xe2\x93\xb0u\xe2\x93\xb3\x89\xe2\x93\xb3\x81'
        assert os.environ[b'foo'] == '\u0171\u0081\u008f\xe9\u009e\u2030u\u2033\u0089\u2033\u0081'
        assert isinstance(os.environ[b'foo'], str)

    # Python2
    os.environ

# Generated at 2022-06-11 18:28:39.394298
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # prepare
    environ = _TextEnviron()

    # execute
    value = environ['HOME']

    # assert
    # value should be a string
    assert isinstance(value, str)

# Generated at 2022-06-11 18:29:12.205626
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['TEST'] = 'foo'
    assert environ['TEST'] == 'foo'
    if PY3:
        environ['TEST'] = u'bar'
    else:
        environ['TEST'] = b'bar'
    assert environ['TEST'] == 'bar'


# Generated at 2022-06-11 18:29:20.631974
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    raw_environ = {b'KEY1': b'value1', b'KEY2': b'\xe9\xbb\x83',
                   b'KEY3': b'\xef\xbf\xbd', b'KEY4': b'\xf0\x90\x80\x80'}
    environ = _TextEnviron(env=raw_environ, encoding='utf-8')
    assert environ['KEY1'] == u'value1'

# Generated at 2022-06-11 18:29:24.088675
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(env={'k1': 'v1'}, encoding='ascii')
    assert env['k1'] == 'v1'



# Generated at 2022-06-11 18:29:30.116882
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    entities = (
        {
            'decoded': u'TEST_VAR',
            'encoded': u'TEST_VAR',
            },
        {
            'decoded': u'Hà N?i',
            'encoded': b'H\xe0 N\u1ed9i',
            },
        {
            'decoded': u'V\xf6lker',
            'encoded': b'V\xc3\xb6lker',
            },
        {
            'decoded': u'\u65e5\u672c\u8a9e',
            'encoded': b'\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e',
            },
        )

# Generated at 2022-06-11 18:29:38.723545
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        from unittest import mock
    except ImportError:
        import mock

    with mock.patch.object(_TextEnviron, '_raw_environ') as mock_raw_environ:
        mock_raw_environ.__getitem__.return_value = 'test_value'

        test = _TextEnviron()
        mock_raw_environ.__getitem__.assert_not_called()
        assert test['test_key'] == 'test_value'
        mock_raw_environ.__getitem__.assert_called_once_with('test_key')


# Generated at 2022-06-11 18:29:42.413582
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    unicode_key = u'foo'
    unicode_value = u'bar'
    environ[unicode_key] = unicode_value
    assert environ[unicode_key] == unicode_value
    assert environ[to_bytes(unicode_key)] == unicode_value

# Generated at 2022-06-11 18:29:50.737768
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['pythonpath'] == u'/home/toshio/python3_env/bin'
    # Cache keys off of the undecoded values to handle any environment variables which change
    # during a run
    environ['pythonpath'] = "/home/toshio/python3_env/bin"
    assert environ['pythonpath'] == u'/home/toshio/python3_env/bin'

    if PY3:
        assert environ['PYTHONPATH'] == u'/home/toshio/python3_env/bin'
        # Cache keys off of the undecoded values to handle any environment variables which change
        # during a run
        environ['PYTHONPATH'] = '/home/toshio/python3_env/bin'

# Generated at 2022-06-11 18:29:53.298602
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['TEST'] = u'\u1234'
    assert isinstance(environ['TEST'], str)
    assert environ['TEST'] == u'\u1234'


# Generated at 2022-06-11 18:30:03.622249
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import six
    assert six.PY2, "This test must be run with Python2"
    # Check that we can get unicode objects out of the environment and then re-set them
    unicode_envvar_key = 'ANSIBLE_UNICODE_ENVVAR_KEY'
    unicode_envvar_value = u'\u00e0lpha'
    b_unicode_envvar_value = to_bytes(unicode_envvar_value, encoding='utf-8', nonstring='strict',
                                      errors='strict')
    environ[unicode_envvar_key] = unicode_envvar_value
    try:
        assert unicode_envvar_value == environ[unicode_envvar_key]
    finally:
        del environ[unicode_envvar_key]

   

# Generated at 2022-06-11 18:30:09.355427
# Unit test for method __getitem__ of class _TextEnviron