

# Generated at 2022-06-11 18:21:06.114084
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PAGER'] == os.environ['PAGER']
    try:
        environ['TEST_KEY'] = u'TEST_VAL'
        assert environ['TEST_KEY'] == u'TEST_VAL'
    finally:
        del environ['TEST_KEY']

# Generated at 2022-06-11 18:21:17.201164
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest
    import os
    import sys

    class Test__TextEnviron___getitem__(unittest.TestCase):
        def test_get_unicode(self):
            environ = _TextEnviron({'foo': 'bar'})
            self.assertEqual(environ['foo'], 'bar')

        @unittest.skipIf(sys.platform.startswith('win'), 'test does not work on Windows')
        def test_get_utf8(self):
            environ = _TextEnviron({'foo': b'\xc3\xa0'})
            self.assertEqual(environ['foo'], 'à')


# Generated at 2022-06-11 18:21:29.039867
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that the cache works
    environ._raw_environ['TEST_KEY'] = to_bytes('foo')
    environ._value_cache['foo'] = 'bar'
    assert environ['TEST_KEY'] == 'bar'

    # Test with unicode
    environ._raw_environ['TEST_KEY'] = to_bytes('\u2600')
    assert environ['TEST_KEY'] == '\u2600'
    del environ['TEST_KEY']

    # Test bytes that we can't decode
    environ._raw_environ['TEST_KEY'] = b'\xc2'
    assert environ['TEST_KEY'] == u'\ufffd'

    # Test with an invalid surrogate

# Generated at 2022-06-11 18:21:33.181803
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    environ._raw_environ = {b'ANSIBLE_TEXT_ENV_TEST': b'\xe7\xbd\x91\xe7\xab\x99'}
    assert environ['ANSIBLE_TEXT_ENV_TEST'] == u'\u7f51\u7ad9'



# Generated at 2022-06-11 18:21:44.948087
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_env = {
        'ANSIBLE_TEST_STR': 'doe',
        'ANSIBLE_TEST_BYTES': to_bytes('ray', encoding='utf-8'),
        'ANSIBLE_TEST_TEXT': to_text('me', encoding='utf-8'),
        'ANSIBLE_TEST_UNICODE': u'me',
    }

    # Test that calling TextEnviron.__getitem__ with a bytes key and a bytes value returns a text
    # string
    for key, value in test_env.items():
        assert isinstance(environ[key], text_type)

    # Test that calling TextEnviron.__getitem__ with a text key and a bytes value returns a text
    # string

# Generated at 2022-06-11 18:21:46.058221
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == u'/bin'


# Generated at 2022-06-11 18:21:49.400256
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['TEST_VARIABLE'] = '15'
    assert environ['TEST_VARIABLE'] == '15'
    assert type(environ['TEST_VARIABLE']) == str

# Generated at 2022-06-11 18:21:51.467275
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ._raw_environ[b'key'] = b'value'
    assert environ[b'key'] == 'value'



# Generated at 2022-06-11 18:22:02.524182
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test with a non-str value
    environ._raw_environ['abc'] = 127
    assert isinstance(environ['abc'], str), '_TextEnviron should return str objects'

    # Test with an ASCII str value
    environ._value_cache = {}
    environ._raw_environ['abc'] = 'heÏ'
    assert isinstance(environ['abc'], str), '_TextEnviron should return str objects'
    assert environ['abc'] == 'heÏ', '_TextEnviron should preserve ASCII values'

    # Test with a non-ASCII str value
    environ._value_cache = {}
    environ._raw_environ['abc'] = 'heÏ'
    assert isinstance(environ['abc'], str), '_TextEnviron should return str objects'

# Generated at 2022-06-11 18:22:11.354886
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import random
    import string
    random_key = ''.join(random.choice(string.ascii_letters) for i in range(10))
    random_value = ''.join(random.choice(string.ascii_letters) for i in range(10))
    envi = _TextEnviron({random_key: random_value})
    assert isinstance(envi[random_key], text_type)
    assert envi[random_key] == random_value


# Generated at 2022-06-11 18:22:24.450764
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['first'] = 'ONE'
    environ['second'] = 'TWO'
    result = environ['first']
    correct = 'ONE'
    assert(result == correct)

    result = environ['second']
    correct = 'TWO'
    assert(result == correct)

    environ['second'] = 'TWÓ'
    result = environ['second']
    correct = 'TWÓ'
    assert(result == correct)

    environ['THIRD'] = '\udc80'
    try:
        result = environ['THIRD']
        correct = '\udc80'
        assert(result == correct)
        raise Exception('Should have raised an exception')
    except UnicodeDecodeError:
        pass

    # Set PY3 to True to test code path that uses the raw environ


# Generated at 2022-06-11 18:22:31.752104
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Initialize the Environ instance
    env = _TextEnviron({'a': 'b'})

    # Check the value returned by the function __getitem__ on a valid key
    assert env['a'] == 'b', "function __getitem__ did not return 'b'"

    # Check the value returned by the function __getitem__ on a invalid key
    try:
        env['b']
    except KeyError:
        assert True, "function __getitem__ did not return KeyError for invalid key"
    else:
        assert False, "function __getitem__ did not return KeyError for invalid key"


# Generated at 2022-06-11 18:22:33.303187
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test = _TextEnviron()
    assert test['PATH'] == environ['PATH']

# Generated at 2022-06-11 18:22:41.212322
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Mock the raw environment so we can control what it contains

    class _RawEnviron(dict):
        def __init__(self, values):
            self._values = values

        def __getitem__(self, key):
            return self._values[key]

    values = {b'foo': b'bar',
              b'baz': b'\xe2\x98\x83'}

    # Mock the environment with the values
    raw_environ = _RawEnviron(values)
    myenviron = _TextEnviron(raw_environ, encoding='utf-8')

    # Test __getitem__
    for key in values:
        expected = to_text(values[key], errors='surrogate_or_strict',
                           encoding='utf-8')
        assert myenviron[key] == expected

# Generated at 2022-06-11 18:22:47.258844
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os_environ_backup = os.environ
    os.environ = os.environ.copy()
    os.environ['text_environ_test'] = 'hello_world'
    environ = _TextEnviron()
    assert(environ['text_environ_test'] == 'hello_world')
    del environ
    os.environ = os_environ_backup

# Generated at 2022-06-11 18:22:53.874777
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Use this global so we can change it in our tests and make sure it's not changed/cached
    global environ

    # Test with default encoding
    original_environ = dict(environ)
    to_be_deleted = set()

# Generated at 2022-06-11 18:23:02.878567
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test both python 2 and 3 compatible module value
    try:
        from __builtin__ import unicode
    except ImportError:
        unicode = str

    def test(value, expected_result):
        e = _TextEnviron()
        e['TEST_VAR'] = value
        result = e['TEST_VAR']
        assert isinstance(result, unicode)
        assert expected_result == result

    test('テスト', 'テスト')
    test('test', 'test')
    test('テスト\xe3\x81\x88\xe3\x81\x86', 'テスト\xe3\x81\x88\xe3\x81\x86')

# Generated at 2022-06-11 18:23:05.261308
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # override environ with test instance
    global environ
    env = {'test_key': u'1'}
    environ = _TextEnviron(env, encoding='utf-8')

    assert environ['test_key'] == u'1'


# Generated at 2022-06-11 18:23:15.538602
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:23:26.233714
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # No value in the cache
    os.environ['PYTHONPATH'] = '/usr/bin/python'
    environ = _TextEnviron()
    assert environ['PYTHONPATH'] == u'/usr/bin/python'
    assert environ['PYTHONPATH'] != b'/usr/bin/python'

    # Value in cache
    environ = _TextEnviron()
    os.environ['PYTHONPATH'] = '/usr/bin/python'
    assert environ['PYTHONPATH'] == u'/usr/bin/python'
    assert environ['PYTHONPATH'] != b'/usr/bin/python'
    os.environ['PYTHONPATH'] = '/usr/bin/python3'

# Generated at 2022-06-11 18:23:35.128346
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'PYTHONPATHS': b'/some/path/with/\u0e01/in/it/\xc3\xb8\xc3\x9f\xc3\xb6'})
    expected_value = u'/some/path/with/\u0e01/in/it/\xf8\xdf\xf6'
    assert environ['PYTHONPATHS'] == expected_value


# Generated at 2022-06-11 18:23:44.270085
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Provide responses to required calls to os.environ to simulate environment
    def os_environ__getitem__(key):
        if key == "PYTHONPATH":
            return "/tmp/ansible:/tmp/ansible2:/tmp/ansible3"
        elif key == "HOME":
            return "/root"
        elif key == "LANG":
            return "en_US.UTF-8"
        elif key == "SHLVL":
            return "2"
        elif key == "OLDPWD":
            return "/opt/ansible"
        elif key == "PWD":
            return "/usr/local/bin"
        elif key == "ANSIBLE_NOCOWS":
            return "True"

# Generated at 2022-06-11 18:23:49.255405
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import sys

    if PY3:
        expected = os.environ["PATH"]
        assert environ["PATH"] == expected
    else:
        expected = os._Environ.__getitem__(os.environ, "PATH")
        assert environ["PATH"] == expected



# Generated at 2022-06-11 18:23:56.561219
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os

    # test_environ = _TextEnviron({"a": "a"})
    # test_environ = _TextEnviron({"a": "a", "b": "b"})

    def test_bytes_to_text(key, value):
        test_environ = _TextEnviron({key: value})
        # print key + ' ' + value + ': ' + test_environ[key] + '\n'
        assert test_environ[key] == value.decode('utf-8')

    def test_text_to_text(key, value):
        test_environ = _TextEnviron({key: value})
        # print key + ' ' + value + ': ' + test_environ[key] + '\n'
        assert test_environ[key] == value

   

# Generated at 2022-06-11 18:24:04.386661
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Basic input to exercise the logic in __getitem__.
    # These tests are partly to make sure that the tests pass on all Python versions.
    assert environ['PATH'] == os.environ['PATH']

    # Exercise the special cases of non-string values & surrogate encoded values
    environ['TEST_VAL'] = (b'\x00\x01\x02\xFF\xFF\xFF')
    assert environ['TEST_VAL'] == u'\x00\x01\x02\xFF\xFF\xFF'
    environ['TEST_VAL'] = (b'\xED\xA0\x80\xED\xA0\x81\xED\xA0\x82\xED\xB0\x83\xED\xB0\x84')

# Generated at 2022-06-11 18:24:15.279900
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Should have empty dictionary if nothing set
    assert environ == {}

    # Should prefer values set in the text environ
    environ['test_key'] = 'test_value'
    assert environ['test_key'] == 'test_value'

    # Should return unicode values on Python2
    if not PY3:
        os.environ['test_key'] = 'test_value'
        assert environ['test_key'] == 'test_value'

    # Should use values set in the raw environ
    os.environ['test_key'] = 'test_value'
    del environ['test_key']
    assert environ['test_key'] == 'test_value'

    # Should use whatever encoding is set for the class even if it's not utf-8

# Generated at 2022-06-11 18:24:18.688327
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    eenv = _TextEnviron()
    if PY3:
        assert isinstance(eenv['ASDF'], str)
    else:
        assert isinstance(eenv['ASDF'], unicode)

# Generated at 2022-06-11 18:24:25.563873
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # :todo: check results of following commands:
    #   environ['abc']
    #   len(environ)
    #   str(environ)

    # Basic usage
    # :case: environ has the key 'abc'
    # :expect: should return the value for key 'abc'
    if 'abc' in environ.keys():
        assert environ['abc']
        assert len(environ) > 1
        assert str(environ)

    # Basic usage
    # :case: environ does not have the key 'abc'
    # :expect: should raise KeyError
    try:
        if 'abc' not in environ.keys():
            environ['abc']
    except KeyError:
        pass

# Generated at 2022-06-11 18:24:29.533347
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Check that retrieving an unset key raises KeyError
    try:
        environ['non_existent_key']
    except KeyError:
        pass
    else:
        assert False, 'Expected KeyError from getitem for unset key'
    # Check that retrieving a set key gives us the same value that we put in
    environ['mykey'] = u'this is my value'
    assert environ[b'mykey'] == u'this is my value', 'Expected same value back from getitem'
    # Check that we can get the same value back as bytes
    assert environ['mykey'] == 'this is my value', "Expected text value from getitem when using 'str' key"
    # Check that we get the value back from the cache
    environ['mykey'] = u'but this is my actual value'
   

# Generated at 2022-06-11 18:24:39.674840
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that this class works like os.environ for bytes on python 2
    # and os.environ for text on python 3
    #
    # Note that we're *not* checking for the contents of the environment on the theory that
    # environment variables are different on every system
    environ = _TextEnviron({b'abc': b'abc', b'utf8': to_bytes('h\xe9llo', encoding='utf-8')})
    # This is expected to be different on py2 vs. py3.
    if PY3:
        assert ({b'abc': b'abc', b'utf8': b'h\xe9llo'} == environ)
    else:
        assert ({b'abc': 'abc', b'utf8': 'h\xe9llo'} == environ)

    # Check that we get text from

# Generated at 2022-06-11 18:24:57.792612
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env2 = _TextEnviron(encoding='ascii')  # environment with different encoding
    # Test keys are not in environment
    env_text_key = 'env_text_key'
    env_bytes_key = 'env_bytes_key'.encode('utf-8')
    # Test keys are in environment
    env_set_before_key = 'env_set_before_key'
    env_set_after_key = 'env_set_after_key'
    os.environ[env_set_before_key] = env_set_before_key
    os.environ[env_set_after_key] = env_set_after_key.encode('utf-8')

    # Test keys are not in environment

# Generated at 2022-06-11 18:25:06.031410
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    var = u'Кириллица'

    env._value_cache = {}

# Generated at 2022-06-11 18:25:09.419481
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    #
    # MUST have an environment variable named "REAL_NAME" with value "Billy Bob"
    #
    assert environ['REAL_NAME'] == u'Billy Bob'
    return

# Generated at 2022-06-11 18:25:10.934638
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HELLO'] == u'WORLD'


# Generated at 2022-06-11 18:25:19.331049
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create test environment
    test_env = {'foo': 'foo', 'bar': 'bar'}
    for key, value in test_env.items():
        test_env[key] = to_bytes(value, encoding='utf-8', nonstring='strict')

    # Initialize _TextEnviron with test environment
    sut = _TextEnviron(env=test_env, encoding='utf-8')

    # Check that the values are returned as text
    assert type(sut['foo']) == str
    assert type(sut['bar']) == str

    # Check that we correctly return the value
    assert sut['foo'] == 'foo'
    assert sut['bar'] == 'bar'



# Generated at 2022-06-11 18:25:25.245838
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Ensure _TextEnviron is converting bytes correctly"""
    environ = _TextEnviron({b'key1': b'value1', b'key2': b'value2'}, encoding='utf-8')
    assert type(list(environ.keys())[0]) == str
    assert type(list(environ.values())[0]) == str
    assert type(list(environ.items())[0][0]) == str
    assert type(list(environ.items())[0][1]) == str

# Generated at 2022-06-11 18:25:28.555313
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    assert environ["PATH"]
    assert isinstance(environ["PATH"], str)


if __name__ == '__main__':
    test__TextEnviron___getitem__()

# Generated at 2022-06-11 18:25:38.254304
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Given:
    environ._raw_environ = {to_bytes('unicode'): to_bytes('\u20ac')}
    # Expect:
    assert environ['unicode'] == u'\u20ac'

    # Given:
    environ._raw_environ = {to_bytes('unicode'): to_bytes('\u20ac')}
    # Expect:
    assert environ['unicode'] == u'\u20ac'

    # Given:
    environ._raw_environ = {
        to_bytes('unicode'): to_bytes('\u20ac'),
        to_bytes('change_value'): to_bytes('first value')
    }
    # When:
    environ['change_value'] = 'second value'
    # Expect:

# Generated at 2022-06-11 18:25:39.555078
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == os.environ['PATH']

# Generated at 2022-06-11 18:25:42.235168
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_copy = environ.copy()
    for key, value in environ_copy.items():
        assert environ[key] == value, "Test for _TextEnviron failed"


# Generated at 2022-06-11 18:26:01.144842
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test the implementation of _TextEnviron.__getitem__

    This tests that it uses to_text with surrogates=strict and handles non-ascii values
    properly.
    """
    env = _TextEnviron({'some_string': 'foo', b'byte_string': b'bar',
                        'some_bytes': 'baz'.encode(encoding='utf-8'),
                        'unicode_string': u'b\u00E2z'}, encoding='utf-8')
    assert u'foo' == env['some_string']
    assert u'bar' == env['byte_string']
    assert u'b\u00E2z' == env['unicode_string']
    assert u'\u5b50' == env['unicode_string'][1:]

# Generated at 2022-06-11 18:26:05.878622
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Arrange
    sys.stdout.encoding = 'utf-8'
    environ['opt'] = 'value'
    environ['bopt'] = b'value'

    # Assert
    assert environ['opt'] == 'value'
    assert environ['bopt'] == 'value'
    assert isinstance(environ['opt'], str)
    assert isinstance(environ['bopt'], str)
    assert 'opt' in environ
    assert b'bopt' in environ
    assert 'bopt' in environ


# Generated at 2022-06-11 18:26:16.034707
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Testing for encoding
    environ['ANSIBLE_TEST_VAR'] = '\xE2\x98\x83'
    assert environ['ANSIBLE_TEST_VAR'] == u'\u2603'
    del environ['ANSIBLE_TEST_VAR']

    # Testing for nonstring
    environ['ANSIBLE_TEST_VAR'] = 5
    assert environ['ANSIBLE_TEST_VAR'] == 5
    del environ['ANSIBLE_TEST_VAR']

    # Testing for errors
    environ['ANSIBLE_TEST_VAR'] = '\xC3\x28'

# Generated at 2022-06-11 18:26:25.568680
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['ANSIBLE_TEST_ASCII'] = 'test_value'
    environ['ANSIBLE_TEST_UTF8'] = u'test_value_\u03a9'
    environ['ANSIBLE_TEST_LATIN1'] = u'test_value_\u03a9'.encode('iso-8859-1')

    assert environ['ANSIBLE_TEST_ASCII'] == 'test_value'
    assert environ['ANSIBLE_TEST_UTF8'] == u'test_value_\u03a9'
    assert environ['ANSIBLE_TEST_LATIN1'] == u'test_value_\ufffd'
    assert environ['ANSIBLE_DOES_NOT_EXIST'] is None

# Generated at 2022-06-11 18:26:30.588777
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set up
    dict = {"foo": "utf8withaccent", "bar": u"utf8withaccent".encode("utf8")}

    # Test
    text_environ = _TextEnviron(dict, encoding="utf8")
    result = text_environ['bar']

    # Assert
    assert result == "utf8withaccent"

# Generated at 2022-06-11 18:26:33.001520
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert 'ho' == environ['ho']
    assert u'ho' == environ['ho']



# Generated at 2022-06-11 18:26:36.145790
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['ANSIBLE_TEST_KEY'] = u'é'
    assert environ['ANSIBLE_TEST_KEY'] == u'é'



# Generated at 2022-06-11 18:26:42.487167
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['FOO'] = 'bar'
    assert environ['FOO'] == 'bar'
    environ['FOO'] = b'bar'
    assert environ['FOO'] == 'bar'
    environ['FOO'] = u'bar'
    assert environ['FOO'] == 'bar'
    environ['FOO'] = to_bytes(u'bar', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    assert environ['FOO'] == 'bar'

    # Unit test for method __setitem__
    def test__TextEnviron___setitem__():
        environ['FOO'] = 'bar'
        assert environ['FOO'] == 'bar'
        assert isinstance(environ['FOO'], str)

# Generated at 2022-06-11 18:26:53.505921
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Create a TestEnviron class to allow overriding the env value
    class TestEnviron(_TextEnviron):
        def __init__(self, env, encoding='utf-8'):
            self._raw_environ = env
            self._value_cache = {}
            self._encoding = encoding

    # Create some test values
    utf8_bytes = '\xc3\x87\xc3\xab'.encode('utf-8')
    utf8_text = utf8_bytes.decode('utf-8')

    ascii_bytes = 'abc123'.encode('ascii')
    ascii_text = ascii_

# Generated at 2022-06-11 18:26:55.715117
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'foo': 'bar'})
    assert env[b'foo'] == 'bar'
    return


# Generated at 2022-06-11 18:27:24.644926
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ[to_bytes('foo', errors='surrogate_or_strict')] = to_bytes('bar')
    assert environ[to_text('foo', errors='surrogate_or_strict')] == to_text('bar')


if __name__ == "__main__":
    test__TextEnviron___getitem__()

# Generated at 2022-06-11 18:27:28.747636
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    env['binary'] = b'\x00\x01\x02\x03\x04'
    assert env['binary'] == u'\x00\x01\x02\x03\x04'

# Generated at 2022-06-11 18:27:34.002563
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Overwrite os.environ with a dict containing byte strings
    os.environ = {b'str': b'value1', b'int': b'42'}
    # Create instance of _TextEnviron
    t_environ = _TextEnviron(env=os.environ, encoding='utf-8')
    # Test
    assert t_environ[b'str'] == 'value1'
    assert t_environ[b'int'] == '42'

# Generated at 2022-06-11 18:27:38.382238
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    tt = {"b": to_bytes("d", encoding="utf-8"), "a": to_bytes("b", encoding="utf-8"), "c": to_bytes("e", encoding="utf-8")}
    t = _TextEnviron(tt)
    assert to_text("b") == t["a"]
    assert to_text("d") == t["b"]
    assert to_text("e") == t["c"]


# Generated at 2022-06-11 18:27:49.351790
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3
    import sys

    # Create a _TextEnviron instance to be tested
    if PY3:
        # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding() instead
        # of utf-8
        text_environ = _TextEnviron(encoding=sys.getfilesystemencoding())
    else:
        text_environ = _TextEnviron(encoding='utf-8')

    # Set environment variable which can be decoded
    os.environ['test_encoding'] = 'こんにちは'

    # Check that the variable

# Generated at 2022-06-11 18:27:58.165983
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    myenviron = _TextEnviron({'ANSIBLE_MODULE_ARGS': '{"a": "b"}'}, encoding='utf-8')
    assert myenviron['ANSIBLE_MODULE_ARGS'] == '{"a": "b"}'
    assert myenviron[b'ANSIBLE_MODULE_ARGS'] == '{"a": "b"}'
    assert myenviron[b'ANSIBLE_MODULE_ARGS'.decode('ascii')] == '{"a": "b"}'
    assert myenviron[u'ANSIBLE_MODULE_ARGS'] == '{"a": "b"}'
    assert myenviron[u'ANSIBLE_MODULE_ARGS'.encode('utf-8')] == '{"a": "b"}'

# Generated at 2022-06-11 18:28:03.780841
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    u"Tests the method __getitem__ of class _TextEnviron"
    env = _TextEnviron({b'stone': b'henge', b'life': 42})
    assert to_text(env['stone']) == u'henge'
    assert env['life'] == 42


# Generated at 2022-06-11 18:28:12.604882
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(encoding='utf-8')
    # 'utf-8' is the default encoding of the environ object
    assert environ['PYTHONIOENCODING'] == 'utf-8'
    # if the encoding is non-string or non-utf-8, a surrogate value will be returned
    environ = _TextEnviron(encoding='latin-1')
    assert environ['PYTHONIOENCODING'] == u'\udc80\udc80'
    # if the value being decoded to unicode is not a string (say a number), then the value is
    # returned as is
    environ = _TextEnviron({'number': 42})
    assert environ['number'] == 42
    # if the value being decoded to unicode is not a string (say a number)

# Generated at 2022-06-11 18:28:21.999482
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test a key with value of bytes
    bytes_key = 'ä'.encode('utf-8')
    bytes_value = 'ü'.encode('utf-8')
    bytes_dict = {bytes_key: bytes_value}
    env = _TextEnviron(env=bytes_dict)
    assert env[bytes_key] == to_text(bytes_value, encoding='utf-8')

    # test a key with value of bytes and encoding=None
    env = _TextEnviron(env=bytes_dict, encoding=None)
    assert env[bytes_key] == to_text(bytes_value)

    # test a key with value of bytes and encoding=latin-1
    env = _TextEnviron(env=bytes_dict, encoding='latin-1')

# Generated at 2022-06-11 18:28:33.438996
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # pylint: disable=protected-access
    # create a temporary file and read it into a string
    with open('/tmp/testfile', 'w') as tmp_file:
        tmp_file.write('Test string')
    with open('/tmp/testfile', 'r') as tmp_file:
        text_file_content = tmp_file.read()

    # insert the file content and it's base64 encoded string as environment items
    os.environ['TESTFILE'] = text_file_content
    os.environ['TESTFILE_BASE64'] = text_file_content.encode('base64').strip()

    # calling __getitem__ on a key that is not in the environment should raise a KeyError

# Generated at 2022-06-11 18:29:41.495047
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    from ansible.module_utils._text import to_bytes, to_text

    # check if Windows here, because on Windows we need to convert
    # file system encoding and string encoding
    current_os = os.name
    if current_os == 'nt':
        import locale
        import sys

        locale.setlocale(locale.LC_ALL, 'English_United States.1252')
        fs_encoding = 'mbcs'
        str_encoding = '1252'
    else:
        fs_encoding = 'utf-8'
        str_encoding = 'utf-8'

    # check if input is byte and output is text on PY3
    if PY3:
        for key in os.environ:
            if isinstance(key, str):
                rawkey = key.encode

# Generated at 2022-06-11 18:29:49.969059
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    module = type('', (), {})()
    # Any old class will do.  This is just to make sure that the test environment has a copy of the
    # environ in case the test needs to access os.environ
    module.os = os

    # Make sure the cache starts empty
    environ._value_cache = {}

    # Test that we get a text object.
    assert isinstance(environ['PATH'], str)

    # Test that the cache is being used
    # This is not a guaranteed test as the test environment could have a text encoding version of
    # PATH in its environment.  But there's no good way to test the cache.
    assert environ['PATH'] == environ._value_cache[os.environ['PATH']]

    # Test that we can set a new value

# Generated at 2022-06-11 18:30:00.271971
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    environ['PATH'] = '/usr/bin'
    assert environ['PATH'] == '/usr/bin'

    environ['PATH'] = to_text('/usr/bin', encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict')
    assert environ['PATH'] == '/usr/bin'

    # getitem should be case-insensitive
    environ['path'] = '/usr/bin'
    assert environ['PATH'] == '/usr/bin'
    assert environ['path'] == '/usr/bin'

    environ['path'] = to_text('/usr/bin', encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict')
    assert environ['PATH'] == '/usr/bin'

# Generated at 2022-06-11 18:30:07.486241
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    u'''
    Test get item method of _TextEnviron
    '''

    # Test with a string from a utf-8 locale
    environ_new = _TextEnviron({'KEY1': 'VALUE1'})
    assert 'VALUE1' == environ_new['KEY1']

    # Test with a string from a latin-1 locale
    environ_new = _TextEnviron({'KEY1': u'VALUE1'.encode('iso-8859-1')})
    assert 'VALUE1' == environ_new['KEY1']

    # Test with a string from a utf-8 locale
    environ_new = _TextEnviron({'KEY1': u'ö'.encode('UTF-8')})
    assert u'ö' == environ_new['KEY1']

    # Test with a string from a

# Generated at 2022-06-11 18:30:17.910513
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    class DummyEnviron(MutableMapping):
        '''
        Dummy class for unit testing class _TextEnviron
        '''
        def __init__(self):
            self.keys = {}

        def __delitem__(self, key):
            del self.keys[key]

        def __getitem__(self, key):
            return self.keys.get(key, None)

        def __setitem__(self, key, value):
            self.keys[key] = value

        def __iter__(self):
            return self.keys.__iter__()

        def __len__(self):
            return self.keys.__len__()

    dummy_environ = DummyEnviron()

    dummy_environ['key1'] = 'value'
    assert environ['key1'] == 'value'


# Generated at 2022-06-11 18:30:24.830360
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This is a very basic test, it only checks if the UnicodeDecodeError is
    # handled correctly.
    # The rest of the behavior is already covered by the tests from the
    # stdlib.
    env = _TextEnviron(encoding='utf-8')
    env._raw_environ[b'ABC'] = b'\xfe'
    with pytest.raises(UnicodeDecodeError):
        env['ABC']

# Generated at 2022-06-11 18:30:28.661444
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    # try to access the value of an existing environment variable
    environ['USER']
    # try to access the value of an undefined environment variable
    try:
        environ['nocache']
    except KeyError as e:
        assert str(e) == 'nocache'



# Generated at 2022-06-11 18:30:37.670497
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    key = 'TEST_ENV_VARIABLE'
    value = 'some simple text'

    try:
        # save actual value of env var
        environ_actual = environ[key]

        # set expected value of env var
        environ[key] = value

        # test
        environ_expected = environ[key]

        assert environ_expected == value, 'The value of environment variable does not match the expected value'

    finally:
        # restore actual value of env var
        environ[key] = environ_actual


if __name__ == '__main__':
    test__TextEnviron___getitem__()

# Generated at 2022-06-11 18:30:44.271153
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes, to_text
    l_environ = _TextEnviron(env={'a': 'b'})
    assert(l_environ._raw_environ == {'a': 'b'})
    assert(l_environ.encoding == 'utf-8')
    assert('a' in l_environ)
    # test if the key is not in the object
    try:
        l_environ['b']
        assert(False)   # should have raised an exception
    except KeyError:
        assert(True)    # exception
    else:
        assert(False)   # should have raised an exception
    # test if the key is in the _TextEnviron, but not in _raw_environ

# Generated at 2022-06-11 18:30:53.307656
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Assert correct translation of value
    test_getitem = _TextEnviron({'text': 'Test'})
    value = test_getitem['text']
    assert value == u'Test'

    # Assert correct cache hit
    value = test_getitem['text']
    assert value == u'Test'

    # Assert correct cache hit value when returned
    test_getitem = _TextEnviron({'text': 'Test'})
    value = test_getitem['text']
    assert value == u'Test'

    # Assert correct cache miss value when environment is altered
    test_getitem = _TextEnviron({'text': 'Test'})
    value = test_getitem['text']
    assert value == u'Test'
    test_getitem['text'] = 'Is a test'
    value = test_get