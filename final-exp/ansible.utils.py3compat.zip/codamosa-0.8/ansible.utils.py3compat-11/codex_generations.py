

# Generated at 2022-06-11 18:21:02.468815
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # GIVEN:
    # WHEN:
    # THEN:
    assert environ['PATH']



# Generated at 2022-06-11 18:21:11.826474
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    del environ['HAM_SANDWICH']
    environ['HAM_SANDWICH'] = u"A ham and cheese sandwich"
    assert environ[b'HAM_SANDWICH'] == u"A ham and cheese sandwich"

    del environ['HAM_SANDWICH']
    environ['HAM_SANDWICH'] = u"A ham and cheese sandwich"
    assert environ[u'HAM_SANDWICH'] == u"A ham and cheese sandwich"

    del environ[u'HAM_SANDWICH']
    environ[u'HAM_SANDWICH'] = u"A ham and cheese sandwich"
    assert environ[b'HAM_SANDWICH'] == u"A ham and cheese sandwich"

    del environ[b'HAM_SANDWICH']

# Generated at 2022-06-11 18:21:20.552958
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import PY2
    # Don't test Python2, it would be an implicit pass since everything on Python2 is bytes
    # anyways.
    if PY2:
        return

    # Test 1: Item does not exist
    mock_environ = {}
    environ = _TextEnviron(env=mock_environ)
    assert 'BADGER' not in environ
    try:
        environ['BADGER']
    except KeyError:
        pass
    else:
        assert False

    # Test 2: Item exists and is ascii
    mock_environ = {b'BADGER': b'Hello there'}
    environ = _TextEnviron(env=mock_environ)
    assert 'BADGER' in environ

# Generated at 2022-06-11 18:21:26.159959
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'Foo': b'bar'}, encoding='utf-8')
    assert environ[b'Foo'] == 'bar'
    assert environ[u'Foo'] == 'bar'
    assert isinstance(environ[b'Foo'], unicode)


# Unit test to ensure that the shortcuts work

# Generated at 2022-06-11 18:21:31.211760
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
  assert b'Bytes' == environ[b'Bytes']
  assert to_bytes('Bytes', encoding='utf-8') == environ[u'Bytes']
  assert environ.get(u'Bytes') == to_bytes('Bytes', encoding='utf-8')
  assert to_bytes('Bytes', encoding='utf-8') == environ.get(b'Bytes')


# Generated at 2022-06-11 18:21:39.199635
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:21:47.694749
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # The environ object already has the needed data
    value = environ['PATH']
    assert isinstance(value, str)
    assert value == environ._raw_environ['PATH']
    # Create a temporary value from the environment
    pre_value = os.environ.get(key='TEST_ENVIRON', default='no-value')
    os.environ['TEST_ENVIRON'] = 'new-value'.encode('utf-8')
    value = environ['TEST_ENVIRON']
    assert isinstance(value, str)
    assert value == 'new-value'
    # Restore original value
    if pre_value is None:
        del os.environ['TEST_ENVIRON']
    else:
        os.environ['TEST_ENVIRON'] = pre

# Generated at 2022-06-11 18:21:56.043446
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This method is a bit tricky to test because the tests need to be able to alter the environment
    # from which the code is being run.  This is impossible to do from a running process so we
    # resort to using subprocesses to run the test code.
    from ansible.module_utils._text import to_bytes, to_native

    import subprocess
    # Test for __getitem__ on a dictionary
    encoded_value = to_bytes('Iñtërnâtiônàlizætiøn', encoding='utf-8', errors='surrogate_or_strict')
    environ['TEST'] = encoded_value
    expected = 'Iñtërnâtiônàlizætiøn'
    assert environ['TEST'] == expected

    # Test for __getitem__ on a different environment
   

# Generated at 2022-06-11 18:22:04.430806
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os_environ = os.environ.copy()

    os.environ.update({b'C3': b'\x01\x02\x03', b'C1': b'\x01\xe2\x81\x84\x01\xf2\x81\x84',
                      b'C2': b'\x01\xe2\x81\x84\x01\xf2\x81\x84'})

    assert os.environ[b'C1'] == b'\x01\xe2\x81\x84\x01\xf2\x81\x84'
    assert os.environ[b'C2'] == b'\x01\xe2\x81\x84\x01\xf2\x81\x84'

# Generated at 2022-06-11 18:22:11.623678
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    o = _TextEnviron()
    o['k1'] = u'val1'
    o['k2'] = 'val2'
    o['k3'] = b'val3'

    assert o['k1'] == u'val1'
    assert o['k2'] == u'val2'
    assert o['k3'] == u'val3'



# Generated at 2022-06-11 18:22:24.346987
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # assume that we are running in Python 2
    assert not PY3

    env = os.environ
    raw_env = os.environ
    encoding = sys.getfilesystemencoding()

    # if we are running in Python 2 and if the assumption
    # about the value of sys.getfilesystemencoding() is correct,
    # then unicode_env and utf_8_env should be the same
    unicode_env = os.environ
    utf_8_env = _TextEnviron(env, encoding='utf-8')

    assert unicode_env == utf_8_env
    assert unicode_env['PATH'] == utf_8_env['PATH']

    # add the TEST_UNIT_TEST_GETITEM_FROM_RAW_ENV variable to the
    # underlying os.en

# Generated at 2022-06-11 18:22:30.323673
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'foo': b'bar', b'baz': b'string with \xe2\x98\x83in it'}, 'utf-8')
    assert environ[b'foo'] == 'bar'
    assert environ[b'baz'] == 'string with \u2603in it'
    assert environ['foo'] == 'bar'
    assert environ['baz'] == 'string with \u2603in it'



# Generated at 2022-06-11 18:22:38.942116
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    unidict = {str(x):str(x) for x in range(10)}
    _env = _TextEnviron(env=unidict, encoding='utf-8')
    if sys.version_info < (3, 0):
        # No encoding change to test on Python2, we're already in unicode
        return

    # Don't change the unicode strings when Python3, they just need to be
    # fetched from the dict as unicode
    for key in unidict:
        assert _env[key] == key
        # Even with a non-unicode key, we're returning unicode objects
        assert type(_env[key]) is str

    # UTF-8 encoded bytes strings should be converted to unicode
    encoding = 'utf-8'
    for key in unidict:
        _env[key] = to_

# Generated at 2022-06-11 18:22:49.301436
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    _test(lambda: (b'\x80', b'\x80'), lambda: u'\uFFFD', 'ISO-8859-1')
    _test(lambda: (b'\x80', b'\x80'), lambda: u'\uFFFD', 'ISO-8859-15')
    _test(lambda: (b'\x80', b'\x80'), lambda: u'\uFFFD', 'latin1')

    _test(lambda: (b'\xC0', b'\x80'), lambda: u'\uFFFD', 'ISO-8859-1')
    _test(lambda: (b'\xC0', b'\x80'), lambda: u'\uFFFD', 'ISO-8859-15')

# Generated at 2022-06-11 18:23:01.024453
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ[to_bytes("ANSIBLE_CALLBACK_WHITELIST")] = "meta, debug"
    # The key is not cached so we get a text version of the value
    assert environ["ANSIBLE_CALLBACK_WHITELIST"] == "meta, debug"
    # Now the key is cached and we get the cached value
    assert environ["ANSIBLE_CALLBACK_WHITELIST"] == "meta, debug"
    # If we modify the raw environ, the cached value will be invalid
    environ._raw_environ[to_bytes("ANSIBLE_CALLBACK_WHITELIST")] = "meta, debug, minimal"
    # The key is not cached so we get a text version of the value

# Generated at 2022-06-11 18:23:12.409134
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import unittest
    import subprocess

    class Test_TextEnviron___getitem__(unittest.TestCase):
        def test_no_utf8(self):
            if '_ANSIBLE_TEST_ENCODING' not in os.environ:
                os.environ['_ANSIBLE_TEST_ENCODING'] = 'ascii'
            self.assertEquals(to_text(os.environ['_ANSIBLE_TEST_ENCODING']), u'ascii')
            self.assertEquals(to_text(os.environ['_ANSIBLE_TEST_ENCODING'], encoding='ascii'), u'ascii')

# Generated at 2022-06-11 18:23:24.076514
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class MockEnviron(object):
        def __init__(self, env):
            self._env = env

        def __getitem__(self, key):
            return self._env[key]

    # Should return text strings on Python3, for all values
    env = MockEnviron({b'ascii': b'ascii', 'unicode': b'\xed\xa0\x80'})
    sut = _TextEnviron(env)
    assert isinstance(sut['ascii'], str)
    assert isinstance(sut['unicode'], str)

    # Should return text strings on Python2, for all values
    env = MockEnviron({'ascii': 'ascii', 'unicode': '\xed\xa0\x80'})

# Generated at 2022-06-11 18:23:34.055759
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Python 2
    if PY3:
        return
    old_environ = os.environ
    try:
        os.environ = {'foo': u'fööbär', 'bar': 'baz', 'bletch': b'bl\xc3\xa3tz', 'gnusto': u'\u018e'}

        test_environ = _TextEnviron()

        assert test_environ['foo'] == u'fööbär'
        assert test_environ['bar'] == u'baz'
        assert test_environ['bletch'] == u'blátz'
        assert test_environ['gnusto'] == u'Ǝ'
    finally:
        os.environ = old_environ


# Generated at 2022-06-11 18:23:35.869071
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    testenv = _TextEnviron()
    assert isinstance(testenv["test_variable"], str)


# Generated at 2022-06-11 18:23:41.611128
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # set up the test case
    environ = _TextEnviron()
    environ['ANSI_COLOR'] = '\x1b[38;5;3m'

    # execute the method
    actual_output = environ['ANSI_COLOR']

    # assert the output
    expected_output = '\x1b[38;5;3m'
    assert actual_output == expected_output

# Generated at 2022-06-11 18:23:54.180290
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env1 = _TextEnviron()
    assert env1['LANG'] == u'en_US.UTF-8'
    assert type('LANG') == str

    env2 = _TextEnviron(env=dict(LANG='en_US.UTF-8'))
    assert env2['LANG'] == u'en_US.UTF-8'
    assert type('LANG') == str

    env3 = _TextEnviron(env=dict(LANG=b'en_US.UTF-8'))
    assert env3['LANG'] == u'en_US.UTF-8'
    assert type('LANG') == str

    env4 = _TextEnviron(encoding='ascii')
    assert env4['LANG'] == u'en_US.UTF-8'

# Generated at 2022-06-11 18:24:01.355327
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Note: We're using the internal _raw_environ member instead of setting an environment variable
    # on the system because the latter is not easily testable.

    # Setup
    environ._raw_environ = {b'hello': b'world', b'foo': b'bar'}

    # Verify
    assert environ[u'hello'] == 'world'
    assert environ[u'foo'] == 'bar'
    assert environ[b'hello'] == 'world'
    assert environ[b'foo'] == 'bar'



# Generated at 2022-06-11 18:24:08.925665
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # check if the function __getitem__ returns as expected
    data = {}
    data['BYTE_KEY'] = b'\xf1\xff'
    data['UNICODE_KEY'] = u'\xf1\xff'

    raw_environ = environ._raw_environ
    environ._raw_environ = data

    try:
        assert environ['BYTE_KEY'] == u'\ufffd\ufffd'
        assert environ['UNICODE_KEY'] == u'\xf1\xff'
    finally:
        environ._raw_environ = raw_environ

# Generated at 2022-06-11 18:24:11.595538
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    u_name = u'Ansible'
    environ[u_name] = u'\u2615'
    assert environ[u_name] == u'\u2615'

# Generated at 2022-06-11 18:24:17.777589
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test 1: Valid ENV
    key = 'HOME'
    assert environ[key] == os.environ[key]

    # Test 2: Invalid UTF8 ENV
    key = 'ORIGINAL_HOME'
    assert environ[key] == to_text(os.environ[key], encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict')


# Generated at 2022-06-11 18:24:26.877133
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that a simple value returns correctly
    e = _TextEnviron()
    assert e['LANG'] == u'en_US.UTF-8'
    # Test that a surrogate value returns correctly
    e = _TextEnviron({b'TEST': b'badger\xf0\x9f\xa4\x96'})
    assert e['TEST'] == u'badger\U0001f996'
    # Test that known invalid bytes are preserved which is the default behaviour
    e = _TextEnviron({b'TEST': b'\xff'})
    assert e['TEST'] == u'\ufffd'
    # Test that invisible unicode characters are preserved (e.g. zero-width-space)
    e = _TextEnviron({b'TEST': b'\xe2\x80\x8b'})

# Generated at 2022-06-11 18:24:33.768091
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HELLO'] == 'world'
    assert type(environ['HELLO']) == str
    environ['unicode'] = u'♡♪♫♬♩♫♬♭♮♯☀☂☃☄☎☏☢'
    assert environ['unicode'] == u'♡♪♫♬♩♫♬♭♮♯☀☂☃☄☎☏☢'
    assert type(environ['unicode']) == str
    # Test unencodable characters
    environ['no_encode'] = u'ab¢def'
    assert environ['no_encode'] == u'ab¢def'
    assert type(environ['no_encode']) == str


# Unit

# Generated at 2022-06-11 18:24:40.191879
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os

    # Test the os.environ type is byte_string
    textenviron = _TextEnviron()
    assert isinstance(os.environ, dict)
    # The following assertion will fail on some systems if the locale is set to an ascii encoding
    #assert isinstance(os.environ[b'LC_ALL'], to_text(type(b'')))
    assert isinstance(textenviron[b'LC_ALL'], to_text(type('')))
    assert isinstance(textenviron['LC_ALL'], to_text(type('')))


# Generated at 2022-06-11 18:24:42.273739
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'].startswith('/')



# Generated at 2022-06-11 18:24:50.908118
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Load utf-8 encoded characters into the os.environ and then retrieve them back out of the
    # _TextEnviron to ensure we get back a unicode object
    os.environ["my_unicode_variable"] = b'foo\xc3\xb1bar'
    assert environ["my_unicode_variable"] == u'foo\xf1bar'
    del os.environ["my_unicode_variable"]

    # Unicode or text parameters should be encoded to bytestring utf-8
    os.environ["my_unicode_variable"] = u'foo\xf1bar'
    assert b'my_unicode_variable=foo\xc3\xb1bar' in environ.export()
    del os.environ["my_unicode_variable"]

    os.environ["my_unicode_variable"]

# Generated at 2022-06-11 18:24:58.425902
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == u'/usr/bin:/bin:/usr/sbin:/sbin'

# Generated at 2022-06-11 18:25:00.426120
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # The same as the original os.environ on Python3
    assert environ['PATH'] == os.environ['PATH']


# Generated at 2022-06-11 18:25:03.282600
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ[b'mykey'] == u''
    os.environ[b'mykey'] = b'value'
    assert environ[b'mykey'] == u'value'


# Generated at 2022-06-11 18:25:14.410705
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Test the __getitem__ method of the _TextEnviron class

    :returns: ``True`` on success, ``False`` otherwise
    :rtype: bool
    """

    environ = _TextEnviron(encoding='utf-8')
    environ._raw_environ = {'foo': b'bar'}
    if PY3:
        if environ['foo'] != b'bar':
            print('Should return the value of the key as is if we are on Python3')
            return False
    else:
        if environ['foo'] != u'bar':
            print('Should decode to unicode with utf-8 on Python2')
            return False
    # Mimic some keys which may change in the middle of a run

# Generated at 2022-06-11 18:25:21.569802
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class DummyModule():
        pass

    module = DummyModule()
    # On a Python3 system, just need to make sure that the values returned are text
    # On a Python2 system, need to verify that the returned values are unicode and that they
    # are being decoded correctly
    if PY3:
        test_value = 'test'
    else:
        test_value = '\u00e9'.encode('utf-8')
    os.environ['DUMMY_A'] = test_value
    assert environ['DUMMY_A'] == to_text(test_value)

    del os.environ['DUMMY_A']
    try:
        environ['DUMMY_A']
    except KeyError:
        pass

# Generated at 2022-06-11 18:25:32.577604
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env_test = {}
    env_test['environment variable with ascii chars'] = 'environment variable with ascii chars'
    env_test['环境变量与汉字'] = '环境变量与汉字'
    env_test['環境變數與漢字'] = '環境變數與漢字'
    env_test['순환 변수와 한자'] = '순환 변수와 한자'

# Generated at 2022-06-11 18:25:40.070248
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test the method _TextEnviron.__getitem__
    """
    # Note that the original author of this, Toshio Kuratomi, is trying to submit this to six.  If
    # successful, the code in six will be available under six's more liberal license:
    # https://mail.python.org/pipermail/python-porting/2018-July/000539.html

    test_env = {
        u'foo': u'bar',
        b'bytekey': b'bytevalue',
        u'unicode_key': u'unicode_value',
        u'unicode_key_bytes': b'unicode_value_bytes',
        b'bytes_key': u'bytes_value',
        b'bytes_key_bytes': b'bytes_value_bytes',
    }
    test = _Text

# Generated at 2022-06-11 18:25:50.472653
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['ANSIBLE_PYTHON_INTERPRETER'] = 'C:\\Program Files (x86)\\Python37-32\\python.exe -E'
    assert environ['ANSIBLE_PYTHON_INTERPRETER'] == 'C:\\Program Files (x86)\\Python37-32\\python.exe -E'

    environ['ANSIBLE_PYTHON_INTERPRETER'] = 'C:\\Program Files (x86)\\Python37-32\\python.exe -E'
    assert environ['ANSIBLE_PYTHON_INTERPRETER'] == 'C:\\Program Files (x86)\\Python37-32\\python.exe -E'


# Generated at 2022-06-11 18:25:57.404231
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ.clear()
    key = 'TEST_KEY_1'
    value = 'TEST_VALUE_1'
    environ[key] = value
    assert environ[key] == value
    assert environ._raw_environ[key] == to_bytes(value, encoding=environ.encoding,
                                                 nonstring='strict', errors='surrogate_or_strict')
    assert environ._value_cache[value] == value


# Generated at 2022-06-11 18:26:02.520950
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ["TEST_VARIABLE"] = "TEST_VALUE"
    if PY3:
        assert environ["TEST_VARIABLE"] == "TEST_VALUE"
    else:
        assert type(environ["TEST_VARIABLE"]) == unicode
        assert environ["TEST_VARIABLE"] == u"TEST_VALUE"
    del environ["TEST_VARIABLE"]

# Generated at 2022-06-11 18:26:23.952811
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that normal values are returned as text
    test_value = b'unic\xc3\xb8de'
    environ[b'unicode_key'] = test_value
    assert environ[b'unicode_key'] == test_value.decode('utf-8')

    # Test that non-text values are returned as text when the encoding is set to 'ascii' (which
    # will fail)
    test_value = b'\xed\xbf\xbd'
    environ[b'unicode_key'] = test_value
    environ.encoding = 'ascii'
    assert environ[b'unicode_key'] == u'\ufffd'

    # Test that non-text values are returned unchanged when the encoding is set to 'ascii' and
    # nonstring is set to

# Generated at 2022-06-11 18:26:30.712445
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    class DummyEnviron(MutableMapping):
        def __init__(self):
            self.data = {'first': 'first', 'second': 'second'}

        def __getitem__(self, key):
            return self.data[key]

        def __setitem__(self, key, value):
            self.data[key] = value

        def __delitem__(self, key):
            del self.data[key]

        def __iter__(self):
            return self.data.__iter__()

        def __len__(self):
            return len(self.data)

    env = _TextEnviron(DummyEnviron())

# Generated at 2022-06-11 18:26:38.271842
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'
    assert environ['ANSIBLE_TEST_KEY'] == 'ANSIBLE_TEST_VALUE'
    assert environ['ANSIBLE_TEST_KEY'] == os.environ['ANSIBLE_TEST_KEY']
    assert type(environ['ANSIBLE_TEST_KEY']) == type(os.environ['ANSIBLE_TEST_KEY'])
    assert type(environ['ANSIBLE_TEST_KEY']) == str



# Generated at 2022-06-11 18:26:41.068725
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = {b'a': b'b'}
    _TextEnviron(env).__getitem__('a')



# Generated at 2022-06-11 18:26:44.460863
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/snap/bin'
    assert environ['HOME'] == '/home/toshio'



# Generated at 2022-06-11 18:26:55.518823
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron({'value': 'value'})
    assert e['value'] == 'value'
    assert isinstance(e['value'], text_type)
    e = _TextEnviron({'value': u'value'})
    assert e['value'] == 'value'
    assert isinstance(e['value'], text_type)
    e = _TextEnviron({'value': b'value'})
    assert e['value'] == 'value'
    assert isinstance(e['value'], text_type)
    e = _TextEnviron({'value': bytes(bytearray([0xFF]))})
    assert e['value'] == u'\ufffd'
    assert isinstance(e['value'], text_type)
    e = _TextEnviron({b'value': b'value'})

# Generated at 2022-06-11 18:27:00.078908
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['foo'] = u'BAR'
    assert environ[u'foo'] == u'BAR'
    assert environ[b'foo'] == u'BAR'
    assert environ['foo'] == u'BAR'
    assert environ[u'foo'] is environ[b'foo']
    assert environ[b'foo'] is environ['foo']
    assert environ['foo'] is environ['foo']


# Generated at 2022-06-11 18:27:01.706713
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['SOMEVAR'] = 'SOMEVALUE'
    assert environ['SOMEVAR'] == 'SOMEVALUE'

# Generated at 2022-06-11 18:27:11.759275
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class TestEnv(object):
        def __getitem__(self, key):
            return 'foo'

    testenv = TestEnv()
    env = _TextEnviron(env=testenv)
    assert env['foo'] == 'foo'

    class TestEnv(object):
        def __getitem__(self, key):
            return u'\u2212'

    testenv = TestEnv()
    env = _TextEnviron(env=testenv)
    assert env['foo'] == u'\u2212'

    class TestEnv(object):
        def __getitem__(self, key):
            return b'\xe2\x88\x92'

    testenv = TestEnv()
    env = _TextEnviron(env=testenv)

# Generated at 2022-06-11 18:27:20.038161
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == '/bin:/sbin'
    assert environ['PYTHONPATH'] == "/usr/lib/python2.7/site-packages:/usr/local/lib/python2.7/dist-packages:/usr/lib/python2.7/dist-packages"
    assert environ['PWD'] == '/home/badger'
    assert environ['LANG'] == 'en_GB.utf8'
    assert environ['NONEXISTENT'] == ''


# Generated at 2022-06-11 18:27:54.349052
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Test function to mock the os.environ, to test the __getitem__ method
    of class _TextEnviron with different types of values
    '''

    class MyDict(MutableMapping):
        def __init__(self):
            self._internal_dict = dict()

        def __getitem__(self, key):
            return self._internal_dict[key]

        def __setitem__(self, key, val):
            self._internal_dict[key] = val

        def __delitem__(self, key):
            del self._internal_dict[key]

        def __iter__(self):
            return self._internal_dict.__iter__()

        def __len__(self):
            return len(self._internal_dict)

    # Test with empty dictionary
    mydict = MyD

# Generated at 2022-06-11 18:28:00.514325
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['INPUT_STRING'] = 'abcdefghijklmnopqrstuvwxyz'
    os.environ['OUTPUT_STRING'] = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    try:
        assert environ['INPUT_STRING'] == 'abcdefghijklmnopqrstuvwxyz'
        assert environ['OUTPUT_STRING'] == 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    finally:
        del os.environ['INPUT_STRING']
        del os.environ['OUTPUT_STRING']


# Generated at 2022-06-11 18:28:04.281790
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    new_env = _TextEnviron(encoding='utf-8')
    new_env['foo'] = 'bar'
    assert new_env['foo'] == 'bar'

# Generated at 2022-06-11 18:28:11.369285
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Return value of method __getitem__
    # Class TextEnviron
    # File environ.py, line 22, in __getitem__
    #     value = self._raw_environ[key]
    # File environ.py, line 50, in __setitem__
    #     self._raw_environ[key] = to_bytes(value, encoding=self.encoding, nonstring='strict',
    # TypeError: must be str, not int
    environ["TEST"] = u"TEST"
    assert environ["TEST"] == u"TEST"



# Generated at 2022-06-11 18:28:21.144219
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ2 = _TextEnviron({'unicode_string': '\xc9',
                             'bytes_string': b'\xc9',
                             'unicode_string2': '\xc9',
                             'bytes_string2': b'\xc9',
                             'mixed_string': 'abc\xc9',
                             'mixed_string2': 'abc\xc9',
                             'mixed_bytes_string': b'abc\xc9',
                             'mixed_bytes_string2': b'abc\xc9',
                             'unicode_int': 1,
                             'bytes_int': 1,
                             'bool_true': True,
                             'bool_false': False,
                             }, encoding='utf-8')

# Generated at 2022-06-11 18:28:32.534980
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
  test_values = {
    "LANG": "en_US.UTF-8",
    "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
  }
  # Test the cache
  cached_values = {
    "LANG": "en_US.UTF-8",
    "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
    b"LANG": "en_US.UTF-8",
    b"PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
  }
  # Set up the raw env
  env = _TextEnviron()

# Generated at 2022-06-11 18:28:40.215533
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test when the environment variable value is already text
    environ['test'] = str('text')
    assert environ['test'] == str('text')

    # Test when the environment variable value is a bytes object
    environ['test'] = bytes(b'bytes')
    assert environ['test'] == str('bytes')

    # Test when the environment variable value is a bytearray object
    environ['test'] = bytearray(b'bytearray')
    assert environ['test'] == str('bytearray')

# Generated at 2022-06-11 18:28:44.707949
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import types
    environ._raw_environ = {'ansible_python_interpreter': '/home/toshio/envs/py3/bin/python3'}
    assert isinstance(environ, types.MappingProxyType)
    assert environ['ansible_python_interpreter'] == '/home/toshio/envs/py3/bin/python3'

# Generated at 2022-06-11 18:28:54.512922
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test the _TextEnviron.__getitem__() method.
    """

# Generated at 2022-06-11 18:29:03.946788
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['FOO'] = 'bar'
    os.environ['BAZ'] = b'baz'

    # Verify that getitem works
    assert environ['FOO'] == 'bar'
    assert environ['BAZ'] == b'baz'

    # Verify that the values are decoded
    assert isinstance(environ['FOO'], unicode)
    assert isinstance(environ['BAZ'], unicode)

    # Verify that the value is cached
    os.environ['BAZ'] = 'baz2'
    assert environ['BAZ'] == 'baz'

    del os.environ['FOO']
    del os.environ['BAZ']


# Generated at 2022-06-11 18:30:02.398619
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test case: environ["LANG"] will return a text in utf-8 on Python 2.x
    e = _TextEnviron(encoding="utf-8")
    assert isinstance(e["LANG"], text_type)



# Generated at 2022-06-11 18:30:11.153459
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import sys

    # NOTE: Using raw enviroment variable strings to avoid problems with tests failing on Windows
    # platforms due to different encoding defaults.

    # Use default encoding
    env = _TextEnviron()
    assert env['HOME'] == u'/root'

    # Use utf-8
    env = _TextEnviron(encoding='utf-8')
    assert env['HOME'] == u'/root'

    # Use a non-ASCII unicode string for a key
    env = _TextEnviron(encoding='utf-8')
    assert env[u'\u1234'] == u''

    # Use an non-ASCII non-unicode byte string for a key
    env = _TextEnviron(encoding='utf-8')

# Generated at 2022-06-11 18:30:19.798475
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'A': b'a\xe9'}, encoding='utf-8')
    assert environ['A'] == u'a\u00e9'

    environ = _TextEnviron({u'A': u'a\u00e9'}, encoding='utf-8')
    assert environ['A'] == u'a\u00e9'

    environ = _TextEnviron({u'A': u'a\u00e9'}, encoding='ascii')
    assert environ['A'] == u'a\u00e9'

    environ = _TextEnviron({b'A': b'a\xe9'}, encoding='ascii')
    assert environ['A'] == u'a\u00e9'

# Generated at 2022-06-11 18:30:27.674973
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['hello'] = 'world'
    assert environ['hello'] == 'world'
    environ['ascii'] = b'\x07'
    assert environ['ascii'] == '\x07'
    environ['utf-8'] = b'\xe2\x98\x83'
    assert environ['utf-8'] == '\u2603'
    environ['latin-1'] = b'\xe2\x98\x83'
    assert environ['latin-1'] == '\ufffd\ufffd\ufffd'

# Generated at 2022-06-11 18:30:38.029130
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # set up test case:
    import os
    import sys
    if sys.version_info[0] < 3:
        os.environ['ANSIBLE_TEST_TEXTENVIRON'] = '\xff' # arbitrary non-ascii char
        env_val = os.environ['ANSIBLE_TEST_TEXTENVIRON']
    else: # on Python3, os.environ already returns unicode
        os.environ['ANSIBLE_TEST_TEXTENVIRON'] = '\u0022'
        env_val = os.environ['ANSIBLE_TEST_TEXTENVIRON']
    # run test
    from ansible.module_utils.common._collections_compat import _TextEnviron
    text_environ = _TextEnviron()

# Generated at 2022-06-11 18:30:49.530304
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Test __getitem__ of class _TextEnviron"""

    # Get the expected encoding from the system
    encoding = sys.getfilesystemencoding()

    # Test reading normal utf-8 environment variables
    utf_env = _TextEnviron({b'ENV_VAR': b'\xc2\xb5'}, encoding='utf-8')
    assert utf_env['ENV_VAR'] == u'\u00b5'
    assert type(utf_env['ENV_VAR']) is unicode

    # Test reading utf-8 environment variables that cause decoding errors
    # note this is a deprecated usage of surrogates:
    # https://docs.python.org/2/howto/unicode.html#the-unicode-type

# Generated at 2022-06-11 18:30:52.133645
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['TESTING_UNICODE'] = u'\u2622'
    assert environ['TESTING_UNICODE'] == u'\u2622'
    del os.environ['TESTING_UNICODE']



# Generated at 2022-06-11 18:31:02.493486
# Unit test for method __getitem__ of class _TextEnviron