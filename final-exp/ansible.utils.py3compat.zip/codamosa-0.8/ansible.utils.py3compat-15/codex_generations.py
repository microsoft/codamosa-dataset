

# Generated at 2022-06-11 18:21:06.279772
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['a'] = 'a'
    assert environ['a'] == 'a'

    environ['b'] = '\xC3\xA0'  # à in utf-8
    assert environ['b'] == 'à'

    environ['c'] = '\xC3'  # Invalid utf-8: 0xc3 is the first byte of à but no continuation bytes
    assert environ['c'] == '\xC3'

    environ['d'] = '\xC3\xAB'  # Invalid utf-8: 0xAB is not a valid continuation byte
    assert environ['d'] == '\xC3\xAB'

    environ['e'] = u'\uBD80'  # a surrogate in the utf-16 code range
    assert environ['e'] == u

# Generated at 2022-06-11 18:21:12.257449
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({'PYTHONPATH': 'foo', 'LC_CTYPE': b'bar'}, encoding='latin-1')
    assert environ['PYTHONPATH'] == 'foo'
    assert environ['LC_CTYPE'] == 'bar'


# Generated at 2022-06-11 18:21:14.768695
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH']
    assert isinstance(environ['PATH'], str), 'Expect str for PATH'
    assert environ['PATH'] != os.environ['PATH']



# Generated at 2022-06-11 18:21:22.489597
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for env['var'] == encoding
    env = _TextEnviron({b'var': 'value'}, 'utf-8')
    assert env['var'] == 'value'

    env = _TextEnviron({b'var': 'value'}, 'utf-8')
    assert env['var'] == 'value'

    # Test for env['var'] == 'value'
    env = _TextEnviron({b'var': 'value'}, 'utf-8')
    assert env['var'] == 'value'

    # Test for env['var'] == 'value'
    env = _TextEnviron({b'var': 'value'}, 'utf-32')
    # If the bytes for 'value' in the utf-32 encoding are:
    # 0x0000
    # 0x0000
    # 0x0000
    # 0x

# Generated at 2022-06-11 18:21:28.436792
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == '/usr/bin'
    # Set a value that we can be sure will not be in the central cache
    os.environ['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'
    assert environ['ANSIBLE_TEST_KEY'] == 'ANSIBLE_TEST_VALUE'
    del os.environ['ANSIBLE_TEST_KEY']



# Generated at 2022-06-11 18:21:36.230726
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Define test environment
    os.environ['LANGUAGE'] = 'de_DE.utf-8'
    os.environ['PATH'] = '/usr/local/sbin:/usr/local/bin:/usr/bin:/usr/bin/site_perl:/usr/bin/vendor_perl:/usr/bin/core_perl'

    # Check if the method returns the expected text string
    assert(environ['LANGUAGE'] == 'de_DE.utf-8')
    assert(environ['PATH'] == '/usr/local/sbin:/usr/local/bin:/usr/bin:/usr/bin/site_perl:/usr/bin/vendor_perl:/usr/bin/core_perl')

    # Remove added environment variables
    del os.environ['LANGUAGE']

# Generated at 2022-06-11 18:21:46.939938
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for Python 2
    if not PY3:
        test = _TextEnviron()
        test._raw_environ['key'] = 'abc'
        assert test['key'] == 'abc'
        # Ensure that the string has been cached
        assert test._value_cache['abc'] == 'abc'
        # Ensure that changes to the key are handled
        test._raw_environ['key'] = 'def'
        assert test['key'] == 'def'
        assert test._value_cache['def'] == 'def'

        # Test non-ascii
        test._raw_environ['key'] = '\xe2\x99\xa5'
        assert test['key'] == '\xe2\x99\xa5'

# Generated at 2022-06-11 18:21:51.167313
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    my_environ = _TextEnviron()
    my_text_string = "abc"
    my_environ[my_text_string] = my_text_string
    assert my_environ[my_text_string] == my_text_string



# Generated at 2022-06-11 18:22:00.613659
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    with pytest.raises(KeyError):
        environ['KEY_NOT_EXIST']

    with pytest.raises(RuntimeError):
        with mock.patch.dict(environ, {'KEY_NOT_UTF8': b'\xFF'}, clear=True):
            environ['KEY_NOT_UTF8']

    if PY3:
        assert environ['PATH'] == os.environ['PATH']
    else:
        assert environ['PATH'] == os.environ['PATH'].decode('utf-8')

    assert environ['PWD'] == os.getcwd()



# Generated at 2022-06-11 18:22:06.171583
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    ue = _TextEnviron({'a': b'a', 'b': b'b'}, encoding='ascii')
    assert ue[b'a'] == 'a'
    assert ue['a'] == 'a'
    assert ue[b'b'] == 'b'
    assert ue['b'] == 'b'
    assert ue.get(b'a') == 'a'
    assert ue.get('a') == 'a'
    assert ue.get(b'b') == 'b'
    assert ue.get('b') == 'b'
    assert ue.get(b'c') is None
    assert ue.get('c') is None


# Generated at 2022-06-11 18:22:14.386341
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os._TextEnviron = _TextEnviron
    assert isinstance(os.environ, _TextEnviron)

    os.environ['test'] = 'test'
    assert os.environ['test'] == 'test'

    os.environ['int'] = '1'
    assert isinstance(os.environ['int'], unicode)
    assert int(os.environ['int']) == 1

# Generated at 2022-06-11 18:22:23.954773
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = {'abc': to_bytes('abc.def', encoding='utf-8'),
           to_bytes('ABC\xef', encoding='utf-8'): 'def.ghi'}
    env = _TextEnviron(env=env, encoding='utf-8')

    assert env['abc'] == 'abc.def'
    assert env['ABC\xef'] == u'def.ghi'

    # Test the cache
    env['AAA'] = 'aaa'
    env['BBB'] = to_bytes(u'bbb', encoding='utf-8')
    assert env['AAA'] == 'aaa'
    assert env['BBB'] == u'bbb'

# Generated at 2022-06-11 18:22:24.292184
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass

# Generated at 2022-06-11 18:22:28.120987
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == os.environ['PATH']
    assert environ['PYTHONPATH'] == os.environ['PYTHONPATH']
    assert environ['UNITTEST_VAR'] == 'unittest_value'


# Generated at 2022-06-11 18:22:35.029035
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = {b'bytestring': b'value', 'unicode_value': u'unicodestring'}
    text_env = _TextEnviron(env)
    assert text_env[b'bytestring'] == u'value'
    assert text_env['unicode_value'] == u'unicodestring'
    env['bytestring'] = u'value'
    env['unicode_value'] = b'unicodestring'
    assert text_env[b'bytestring'] == u'value'
    assert text_env['unicode_value'] == u'unicodestring'


# Generated at 2022-06-11 18:22:40.243016
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print("\nstart method test__TextEnviron___getitem__()")

    environ.clear()
    environ['test_key'] = 'test_value'

    val = environ['test_key']
    assert val == u'test_value', 'value is not unicode but %s' % type(val)

    environ.clear()
    environ.clear()

    print("\nend method test__TextEnviron___getitem__()")

# Run the unit test
test__TextEnviron___getitem__()

# Generated at 2022-06-11 18:22:43.969062
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron({'t': b'\xc2\xa2'}, encoding='utf-8')
    assert u'\xa2' == e['t']
    assert b'\xc2\xa2' == e._raw_environ['t']



# Generated at 2022-06-11 18:22:49.619436
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    # Test that we get the right value when it's right
    os.environ["ASCII_VAL"] = "ascii"
    assert env["ASCII_VAL"] == "ascii"

    os.environ["UNICODE_VAL"] = u"unicode"
    assert env["UNICODE_VAL"] == u"unicode"



# Generated at 2022-06-11 18:22:57.752768
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(encoding='utf-8')
    env['FOOBAR'] = 'FooBar'
    assert env['FOOBAR'] == 'FooBar'
    env['FOOBAR'] = b'FooBar'
    assert env['FOOBAR'] == 'FooBar'
    env['FOOBAR'] = u'FooBar'
    assert env['FOOBAR'] == 'FooBar'

# Generated at 2022-06-11 18:23:10.210193
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import pytest
    # Patch os.environ for the duration of this module
    with pytest.raises(KeyError):
        assert environ["asdf"]  # Should raise KeyError for missing key
    os.environ["asdf"] = "qwerty"
    assert environ["asdf"] == "qwerty"
    os.environ["asdf"] = b"\x80"  # b'\x80' = b'\xc2\x80' = u'\u0080'
    assert environ["asdf"] == u"\u0080"
    os.environ["asdf"] = "\x80"  # b'\x80' = b'\xc2\x80' = u'\u0080'
    assert environ["asdf"] == "\x80"
    os.en

# Generated at 2022-06-11 18:23:23.469859
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a dict
    dict_ = dict(utf8=u'\ufffd'.encode('UTF-8'), ascii='abc', latin1='abc'.encode('latin-1'))

    # Create _TextEnviron object
    obj = _TextEnviron(dict_, encoding='utf-8')

    # Verify return of __getitem__
    assert obj[u'utf8'] == u'\ufffd'
    assert obj[u'ascii'] == u'abc'
    assert obj[u'latin1'] == u'abc'

    # Verify that trying to get an invalid key raises KeyError
    try:
        obj[u'nonexistent']
    except KeyError:
        pass
    else:
        assert False

    # Verify that trying to get a key of wrong type raises TypeError

# Generated at 2022-06-11 18:23:26.908483
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import ansible.module_utils.common.text_environ
    my_env = ansible.module_utils.common.text_environ._TextEnviron()
    my_env[b"foo"] = b"bar"
    assert my_env[b"foo"] == "bar"


# Generated at 2022-06-11 18:23:35.809812
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    :caseautomation: automated
    :casecomponent: Utilities
    :caseimportance: high
    :caselevel: System
    :testtype: functional
    :setup: no
    :steps:
        1. _TextEnviron.__getitem__("PATH")
        2. _TextEnviron.__getitem__("NONEXISTENT")
    :expectedresults:
        1. Get correct PATH value
        2. Throw KeyError
    """
    environ = _TextEnviron(encoding='utf-8')

    if not isinstance(environ['PATH'], str):
        raise AssertionError("'PATH' is not a string value")

    with pytest.raises(KeyError):
        environ['NONEXISTENT']

# Generated at 2022-06-11 18:23:44.750666
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Unit test for method __getitem__ of class _TextEnviron
    '''
    from ansible.module_utils.six import assertRaisesRegex
    testobj = _TextEnviron()

    # TODO:
    # 1. test case when value is a text string
    # 2. test case when value is a bytes string
    # 3. test case when value is neither bytes nor text
    key = 'ANSIBLE_MODULE_ARGS'
    testobj.__setitem__(key, '{}')
    assert testobj.__getitem__(key) == ''
    # testing non-existent key
    assertRaisesRegex(KeyError, "The environment variable '{}' is not defined".format(key),
            testobj.__getitem__, key)


# Generated at 2022-06-11 18:23:54.461361
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # First, test that sys.stdout.encoding is used if we haven't set a default encoding
    expected_env = os.environ
    assert environ._raw_environ == expected_env

    expected_encoding = sys.getfilesystemencoding()
    assert environ.encoding == expected_encoding

    for key in expected_env.keys():
        # Test that we have the expected encoding
        expected_value = expected_env[key]
        assert isinstance(expected_value, bytes)
        actual_value = environ[key]
        assert isinstance(actual_value, unicode)
        assert actual_value == expected_value.decode(expected_encoding)

        # Test that changing the underlying environment doesn't affect our cached values
        new_value = b'\xce\xbb'
        # noinspection

# Generated at 2022-06-11 18:24:02.578377
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    bvalue = b'Hi there\xFF'
    if PY3:
        value = bvalue
    else:
        value = u'Hi there\ufffd'

    old_environ = os.environ
    try:
        os.environ = {'BYTES': bvalue, 'TEXT': value}
        text_environ = _TextEnviron(env=os.environ)
        assert len(text_environ) == len(os.environ)
        assert text_environ['BYTES'] == value
        assert text_environ['TEXT'] == value
    finally:
        os.environ = old_environ


# Generated at 2022-06-11 18:24:08.925504
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Method __getitem__ of class _TextEnviron should return text strings from the environment
    # instead of byte strings.
    environ = _TextEnviron({'test': 'text'})
    for value in environ.values():
        assert isinstance(value, str)
    for value in environ.keys():
        assert isinstance(value, str)
    for key, value in environ.items():
        assert isinstance(key, str)
        assert isinstance(value, str)



# Generated at 2022-06-11 18:24:20.148187
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    utf8_env = {'key1': 'value1',
                'key2': 'value2',
                'key3': b'value3',
                'key4': b'value4',
                'key5': b'\xa3',
                'key6': u'\xa3',
                'key7': b'\x80',
                'key8': u'\x80'}

    latin1_env = {'key1': 'value1',
                  'key2': 'value2',
                  'key3': b'value3',
                  'key4': b'value4',
                  'key5': b'\xa3',
                  'key6': u'\xa3',
                  'key7': b'\x80',
                  'key8': u'\x80'}

    utf

# Generated at 2022-06-11 18:24:30.019195
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Use text string to test
    environ = _TextEnviron()
    # Basic UTF-8 strings
    assert environ['foo'] == u'bar'
    environ['foo'] = u'é'
    assert environ['foo'] == u'é'
    # Unicode strings
    environ['foo'] = u'éxéc'
    assert environ['foo'] == u'éxéc'
    # Test that str is returned on Python3
    assert isinstance(environ['foo'], str)
    # Test that the surrogate_or_strict encoding used in the to_text
    # call can't be poisoned by the environment string
    environ['foo'] = u'a\uDCCCb'
    assert environ['foo'] == u'a\uDCCCb'
    # Test that the surrogate_or

# Generated at 2022-06-11 18:24:39.872843
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    class _TextEnviron(MutableMapping):
        """
        Utility class to return text strings from the environment instead of byte strings

        Mimics the behaviour of os.environ on Python3
        """
        def __init__(self, env=None, encoding=None):
            if env is None:
                env = os.environ
            self._raw_environ = env
            self._value_cache = {}
            # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
            # instead of utf-8

# Generated at 2022-06-11 18:24:51.278925
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six.moves import builtins
    # set up the test
    old_environ = builtins.environ
    builtins.environ = {b'key1': b'unconverted_text'}

    # test that unconverted data is converted
    environ = _TextEnviron({b'key1': b'unconverted_text', 'key2': b'unconverted_text'})
    assert 'unconverted_text' == environ['key1']

    # test that unicode characters are decoded properly
    environ = _TextEnviron({b'key1': b'\xa9'})
    assert '©' == environ['key1']

    # test that decoding errors are handled properly

# Generated at 2022-06-11 18:25:01.778042
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import StringIO
    import sys

    class _TextEnviron(MutableMapping):
        def __init__(self, env):
            self._raw_environ = env
            self._value_cache = {}

        def __delitem__(self, key):
            del self._raw_environ[key]

        def __getitem__(self, key):
            value = self._raw_environ[key]
            if PY3:
                return value

# Generated at 2022-06-11 18:25:13.186022
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # _TextEnviron object
    text = _TextEnviron()

    # _TextEnviron object
    environ = _TextEnviron(encoding='utf-8')

    # set variable in env
    os.environ['ANSIBLE_TEST_GETITEM_UTF8_STR'] = u'漢字'
    os.environ['ANSIBLE_TEST_GETITEM_UTF8_STR'] = u'漢字'

    # test varible decoded
    assert environ[u'ANSIBLE_TEST_GETITEM_UTF8_STR'] == u'漢字'

    # os.environ has no decoded string
    assert u'ANSIBLE_TEST_GETITEM_UTF8_STR' not in os.environ

    # test variable is stored in cache as und

# Generated at 2022-06-11 18:25:15.435824
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env_orig = os.environ
    try:
        os.environ = {'ANSIBLE_TEST': '\xe2\x9d\xa4\xef\xb8\x8f'}
        result = environ['ANSIBLE_TEST'] == '❤️'
    finally:
        os.environ = env_orig
    return result


# Generated at 2022-06-11 18:25:22.011695
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:25:23.116663
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ[b'foo'] == u'bar'

# Generated at 2022-06-11 18:25:26.116782
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ[b'TEST_ENV'] = 'foo'
    assert isinstance(environ[b'TEST_ENV'], text_type)
    del os.environ[b'TEST_ENV']


# Generated at 2022-06-11 18:25:36.903986
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # The state of the os.environ variable will be ``{b'PYTHONPATH': b'.:', b'TEST': b'1'}``
    os.environ[b'TEST'] = b'1'
    os.environ[b'PYTHONPATH'] = b'.:'
    assert environ[to_text('TEST')] == '1'
    assert environ[to_text('PYTHONPATH')] == '.:'
    assert environ[to_text('foo')] == ''
    assert environ[to_text('foo', nonstring='passthru')] == 'foo'
    assert environ[1] == ''
    assert environ[b'PYTHONPATH'] == '.:'
    assert environ[b'foo'] == ''

# Generated at 2022-06-11 18:25:42.460650
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import PY2
    try:
        encoding = sys.getfilesystemencoding()
        environ = _TextEnviron(encoding='utf-8')
        key = 'test_var'
        value = u'test_value'
        environ[key] = value
        assert environ[key] == value
        if PY2:
            assert type(environ[key]) == unicode
    finally:
        if key in environ:
            del environ[key]

# Generated at 2022-06-11 18:25:50.813079
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # test for normal behavior
    assert isinstance(environ['LANG'], str), 'Expected string, got %s instead' % environ['LANG'].__class__.__name__
    assert isinstance(environ['TERM'], str), 'Expected string, got %s instead' % environ['TERM'].__class__.__name__

    # test for non string behavior
    environ['TEST_VAR'] = True
    assert isinstance(environ['TEST_VAR'], str), 'Expected string, got %s instead' % environ['TEST_VAR'].__class__.__name__

# Generated at 2022-06-11 18:26:02.924422
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    The method_name is: ansible.module_utils.text_env._TextEnviron.__getitem__
    """

    # Initialize the class and set up test data
    # We need to test non-ascii characters and characters which fail to be properly encoded to bytes
    # and decoded to text.
    #
    # For non-ascii, we use the character "μ" for a 'micro' sign.  It's not likely to be the first
    # byte of a multibyte character.
    # For the character that can't be encoded to bytes, we use the unicode replacement character
    # For the character that can't be decoded to text, we use the byte with the value \255
    #

# Generated at 2022-06-11 18:26:13.773921
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # getitem calls the cache.  Make sure it returns a text object no matter what
    # the callable returns
    cache = {}
    class MockDecode(object):
        def __init__(self, retval):
            self._retval = retval
        def __call__(self, *args, **kwargs):
            return self._retval
    te = _TextEnviron(env={b'foo': b"\xc8\xaa\xc4\x81\xc4\x93"}, encoding='utf-8')
    te._value_cache = cache
    te._to_text = MockDecode(u"\u038E\u03B1\u0399")
    assert te[b'foo'] == u"\u038E\u03B1\u0399"

# Generated at 2022-06-11 18:26:23.745160
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test an environment variable with an utf-8 value
    os_environ_backup = environ._raw_environ.copy()
    os.environ['utf8_value'] = b'\xc3\xa9cole'
    assert environ['utf8_value'] == u'\xe9cole'
    environ._raw_environ = os_environ_backup.copy()
    # Test an environment variable with a surrogateescape encoded value
    os.environ['surrogateescape_value'] = b'\xff'
    assert environ['surrogateescape_value'] == u'\udcff'
    environ._raw_environ = os_environ_backup.copy()
    # Test an environment variable with a surrogateescape encoded value when decoding fails

# Generated at 2022-06-11 18:26:26.977428
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Given a _TextEnviron instance
    environ = _TextEnviron(encoding=None)
    # When I access an environment variable
    result = environ['PATH']
    # Then I get back the value as a text string
    assert isinstance(result, str)

# Generated at 2022-06-11 18:26:37.831630
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron({'bytes': b'\xe2\x98\x83', 'bytes_with_encoding': b'\xe2\x98\x83\n#\xe2\x98\x83',
                      'bytes_surrogate': b'\xff\xfd\xf4\x94\x90\xb1',
                      'unicode': '\u2713'})
    assert e['bytes'] == '☃'
    assert e['bytes_with_encoding'] == '☃\n#☃'
    assert e['bytes_with_encoding'].splitlines() == ['☃', '#☃']
    assert e['bytes_surrogate'] == '\udc94\udcb1'
    assert e['unicode'] == '\u2713'

# Generated at 2022-06-11 18:26:49.334210
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    import os

    class _TextEnviron(MutableMapping):
        """
        Utility class to return text strings from the environment instead of byte strings

        Mimics the behaviour of os.environ on Python3
        """
        def __init__(self, env=None, encoding=None):
            if env is None:
                env = os.environ
            self._raw_environ = env
            self._value_cache = {}
            # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
            # instead of utf-8

# Generated at 2022-06-11 18:26:55.561795
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(encoding='ascii')
    assert b'foo' not in env
    env[b'foo'] = b'bar'
    assert 'bar' == env[b'foo']
    assert b'foo' in env


# Generated at 2022-06-11 18:27:02.282881
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a normal key
    assert environ['PATH'] == os.environ['PATH']
    # Test with a key which has surrogates in it
    # (surrogates are valid chars in utf-8 strings)
    environ['surrogate'] = u'\uD800'
    assert environ['surrogate'] == u'\uD800'
    # Test with a key which has invalid utf-8 in it
    assert 'invalid' not in environ
    try:
        environ['invalid'] = u'\uD800'.encode('utf-8', 'surrogatepass')
    except UnicodeEncodeError:
        pass
    else:
        assert False, "Should've raised a UnicodeError"

# Generated at 2022-06-11 18:27:06.340850
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    assert environ['__FOO__'] == os.environ['__FOO__']
    os.environ['__FOO__'] = 'BAR'
    assert environ['__FOO__'] == 'BAR'



# Generated at 2022-06-11 18:27:14.570451
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''Unit test _TextEnviron.__getitem__'''

    # From the _TextEnviron docstring:
    #     "Mimics the behaviour of os.environ on Python3"
    # In Python3, os.environ is a *mappingproxy* that wraps the os._Environ
    # object. This means accessing a key on os.environ returns a Python
    # string. In Python2, os.environ is an os._Environ object. Thus, we
    # need to test that _TextEnviron mimics both of these behaviours.

    # We do this by creating a _TextEnviron object using different objects
    # as the env argument.

    # Create a _TextEnviron object using a os._Environ object as the env
    # argument.
    os_environ = dict(os.environ)
    test

# Generated at 2022-06-11 18:27:35.749018
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test case with str and bytes
    test_environ = {b'KEY': b'VAL'}
    assert _TextEnviron(test_environ)['KEY'] == 'VAL'
    # test cases with utf-8 and latin-1
    test_environ = {'KEY': 'VAL'.encode('utf-8')}
    assert _TextEnviron(test_environ, encoding='utf-8')['KEY'] == 'VAL'
    test_environ = {'KEY': 'VAL'.encode('latin-1')}
    assert _TextEnviron(test_environ, encoding='latin-1')['KEY'] == 'VAL'
    # test cases with invalid encoding
    test_environ = {'KEY': 'VAL'.encode('utf-8')}

# Generated at 2022-06-11 18:27:38.273330
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
  os.environ["test_get_value"] = "unit-test-value"
  assert environ["test_get_value"] == "unit-test-value"
  del os.environ["test_get_value"]


# Generated at 2022-06-11 18:27:48.648133
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'LC_ALL': b'en_US.UTF-8', b'PATH': b'/bin'}, encoding='utf-8')
    assert environ[u'LC_ALL'] == u'en_US.UTF-8'
    assert environ[b'PATH'] == u'/bin'
    # Make sure we cache when the value doesn't change
    assert environ[u'LC_ALL'] is environ[u'LC_ALL']
    # Make sure we cache when the value changes
    environ._raw_environ[u'LC_ALL'] = b'en_US.UTF-8'
    assert environ[u'LC_ALL'] is environ[u'LC_ALL']


# Generated at 2022-06-11 18:27:52.096230
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'ANSIBLE_FORCE_COLOR': b'3'}, encoding='ascii')
    environ.__getitem__('ANSIBLE_FORCE_COLOR')
    assert environ['ANSIBLE_FORCE_COLOR'] == '3'

# Generated at 2022-06-11 18:28:00.018863
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Give bad data and get an exception:
    class SpecialError(Exception):
        pass

    def raise_bad_data(*args, **kwargs):
        raise SpecialError('expected')

    environ._raw_environ['bad'] = 1

    # unicode/text
    environ._raw_environ['good_1'] = 'äöüÿ'
    # bytes/text
    environ._raw_environ['good_2'] = b'\xc3\xa4\xc3\xb6\xc3\xbc\xc3\xbf'
    # bytes/bytes
    environ._raw_environ['good_3'] = b'\xe4\xf6\xfc\xff'


# Generated at 2022-06-11 18:28:10.851868
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    key = 'ansible_env_test__TextEnviron__getitem__'
    text_value = '\xe9'

    # Value not in cache, encoding is utf-8
    environ._value_cache = {}
    os.environ[key] = text_value
    assert environ[key] == text_value, (
        '__getitem__ failed with utf-8, no cache, '
        'text_value: {}, environ[key]: {}'.format(text_value, environ[key])
    )

    # Value not in cache, encoding is iso-8859-1
    environ._value_cache = {}
    environ.encoding = 'iso-8859-1'
    os.environ[key] = text_value

# Generated at 2022-06-11 18:28:19.512994
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(encoding='utf-8')
    environ['ANSIBLE_CONFIG'] = '/dev/null'
    assert environ['ANSIBLE_CONFIG'] == '/dev/null'
    if PY3:
        assert isinstance(environ['ANSIBLE_CONFIG'], str)
    else:
        assert isinstance(environ['ANSIBLE_CONFIG'], unicode)
        # check for locale configuration
        environ.encoding = sys.getfilesystemencoding()
        environ['ANSIBLE_CONFIG'] = '/dev/null'
        assert isinstance(environ['ANSIBLE_CONFIG'], unicode)


# Generated at 2022-06-11 18:28:30.174676
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    if PY3:
        assert True
    else:
        orig_env = {to_text(key): to_text(value) for key, value in os.environ.items()}
        text_environ = _TextEnviron(encoding='utf-8')
        text_environ.__setitem__(u'TEST_KEY', u'TEST_VALUE')

        # check self._raw_environ has correct data
        assert to_text(text_environ._raw_environ[to_bytes(u'TEST_KEY', encoding='utf-8')]) == u'TEST_VALUE'

        # check self._value_cache has correct

# Generated at 2022-06-11 18:28:41.731363
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Latin-1, utf-8 and utf-8 with surrogateescape are all the same, for ASCII values.
    unidecode = '\xf0\x9f\x98\x80'
    utf8 = '\xf0\x9f\x98\x80'
    surrogate = '\xed\xa0\x80'
    environ['test'] = unidecode
    assert environ['test'] == u'\U0001f600'
    environ['test'] = utf8
    assert environ['test'] == u'\U0001f600'
    environ['test'] = surrogate
    assert environ['test'] == u'\U0001f600'

    # This is an ASCII string with a Latin 1 extended character
    environ['test'] = b'\xe9'
    assert environ

# Generated at 2022-06-11 18:28:48.143521
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test the caching of the text conversion
    environ['TEST_TEXT'] = b'\xe9'
    # Make sure it's the same object that was previously cached
    assert environ['TEST_TEXT'] is environ['TEST_TEXT']

    # Make sure we're getting a text type of the same underlying value
    assert environ['TEST_TEXT'] == b'\xe9'.decode('utf-8')

    # Make sure that internal cache doesn't interfere with environment changes
    environ['TEST_TEXT'] = b'\xed'
    assert environ['TEST_TEXT'] == b'\xed'.decode('utf-8')
    # Make sure it's a new object instead of the previous one
    assert environ['TEST_TEXT'] is not environ['TEST_TEXT']

    # Make sure we

# Generated at 2022-06-11 18:29:21.374667
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['TESTING'] == ''
    os.environ['TESTING'] = b'foo'
    assert environ['TESTING'] == 'foo'


# Generated at 2022-06-11 18:29:29.145572
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['ANSIBLE_TEST_VAR_1'] = 'set from python2'
    os.environ['ANSIBLE_TEST_VAR_2'] = u'set from python2'.encode('utf-8')
    assert os.environ['ANSIBLE_TEST_VAR_1'] == 'set from python2'
    assert os.environ['ANSIBLE_TEST_VAR_2'] == u'set from python2'.encode('utf-8')
    assert environ['ANSIBLE_TEST_VAR_1'] == u'set from python2'
    assert environ['ANSIBLE_TEST_VAR_2'] == u'set from python2'
    # set new variable with non ascii charactor

# Generated at 2022-06-11 18:29:33.841415
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['TESTKEY'] = 'sample value'

    try:
        assert(environ['TESTKEY'] == 'sample value')
    finally:
        del os.environ['TESTKEY']


# Generated at 2022-06-11 18:29:35.924892
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_env = environ
    assert text_env['PYTHONPATH'] == 'x'
    assert text_env['$'] == 'y'

# Generated at 2022-06-11 18:29:44.723799
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Testing on Python2
    if PY3:
        return

    # Set up a dummy environment

# Generated at 2022-06-11 18:29:49.825357
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({'key_1': 'value_1', 'key_2': 'value_2'}, encoding='utf-8')

    if PY3:
        assert env['key_1'] == 'value_1'
        assert env['key_2'] == 'value_2'
    else:
        assert env['key_1'] == u'value_1'
        assert env['key_2'] == u'value_2'



# Generated at 2022-06-11 18:30:00.056358
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:30:04.658042
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['TEST_ENV_VAR'] = 'test value'

    assert environ['TEST_ENV_VAR'] == 'test value'

    os.environ['TEST_ENV_VAR'] = b'binary value'

    assert environ['TEST_ENV_VAR'] == u'binary value'

    del os.environ['TEST_ENV_VAR']


# Generated at 2022-06-11 18:30:09.923086
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['ANSIBLE_TEST_1'] = 'F\xe9licitations!'
    os.environ['ANSIBLE_TEST_2'] = '\xe6\xb5\x8b\xe8\xaf\x95'
    os.environ['ANSIBLE_TEST_3'] = '\uc548\ub155'
    os.environ['ANSIBLE_TEST_4'] = '\u0627\u0644\u062b\u0628\u062a'
    os.environ['ANSIBLE_TEST_5'] = '\u0627\u0644\u062b\u0628\u062a'
    os.environ['ANSIBLE_TEST_6'] = '\u5bb6\u65cf'

# Generated at 2022-06-11 18:30:14.720649
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron({'b': b'bval', 't': 'tval', 'u': u'uval'}, 'latin1')
    assert e['b'] == to_text('bval', encoding='latin1')
    assert e['t'] == 'tval'
    assert e['u'] == u'uval'