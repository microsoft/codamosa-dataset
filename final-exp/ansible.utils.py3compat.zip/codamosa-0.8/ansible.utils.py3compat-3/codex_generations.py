

# Generated at 2022-06-11 18:21:10.543777
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3

    environ = {'nullbyte':('\x00'.encode('latin1')), 'bytes':'bytes',
               'unicode':u'unicode', 'surrogateescape':'\xff\xff'}
    if PY3:
        expected_nullbyte = '\x00'
        expected_bytes = 'bytes'
        expected_unicode = 'unicode'
        expected_surrogateescape = '\ufffd\ufffd'
    else:
        expected_nullbyte = '\x00'
        expected_bytes = 'bytes'
        expected_unicode = u'unicode'

# Generated at 2022-06-11 18:21:13.921503
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(encoding='utf-8')
    env_dict = {u"unicode_key": u"unicode_val"}
    environ.update(env_dict)
    assert environ['unicode_key'] == u"unicode_val"


# Generated at 2022-06-11 18:21:21.965390
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environb = {
        to_bytes('BYTE_KEY1', encoding='utf-8'): to_bytes('byte value 1', encoding='utf-8'),
        to_bytes('BYTE_KEY2', encoding='utf-8'): to_bytes('byte value 2', encoding='utf-8'),
        to_bytes('BYTE_KEY3', encoding='utf-8'): to_bytes('byte value 3', encoding='utf-8'),
        to_bytes('BYTE_KEY4', encoding='utf-8'): to_bytes('byte value 4', encoding='utf-8'),
        to_bytes('BYTE_KEY5', encoding='utf-8'): to_bytes('byte value 5', encoding='utf-8'),
    }
    os.environ = _TextEnviron(env=os.environb)

# Generated at 2022-06-11 18:21:26.876951
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    dict = {'spam': 'ham'}
    text_env = _TextEnviron(env=dict)
    if PY3:
        assert text_env['spam'] == 'ham'
    else:
        assert text_env['spam'] == u'ham'



# Generated at 2022-06-11 18:21:29.238965
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['TEST_VAR'] = 'TEST_VAR_CONTENT'
    assert environ['TEST_VAR'] == 'TEST_VAR_CONTENT'

# Generated at 2022-06-11 18:21:32.410120
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = _TextEnviron({b'foo': 'bar'}, encoding='utf-8')
    env_value = test_environ['foo']
    assert env_value == 'bar'


# Generated at 2022-06-11 18:21:39.807792
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['a'] = 'a'
    environ['b'] = 'b'
    environ['c'] = 'c'
    environ['한'] = '한'
    environ[3.14] = '3.14'
    environ[b'bytes'] = b'bytes'

    assert environ['a'] == 'a'
    assert environ['b'] == 'b'
    assert environ['c'] == 'c'
    assert environ['한'] == '한'
    assert environ[3.14] == '3.14'
    assert environ[b'bytes'] == b'bytes'
    assert environ['a'] != b'a'
    assert environ['b'] != b'b'
    assert environ['c'] != b'c'
    assert environ

# Generated at 2022-06-11 18:21:45.104088
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'keyA': b'\xC3\x84', 'keyB': u'\u00c4', 'keyC': 'abc'})
    assert to_text(environ['keyA']) == u'\u00c4'
    assert environ['keyB'] == u'\u00c4'
    assert environ['keyC'] == u'abc'



# Generated at 2022-06-11 18:21:51.757133
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    mysample = {'key': 'value'}
    testenv = _TextEnviron(env=mysample)
    assert testenv['key'] == u'value'

    mysample = {b'key': b'value'}
    testenv = _TextEnviron(env=mysample)
    assert testenv['key'] == u'value'

    mysample = {u'key': b'value'}
    testenv = _TextEnviron(env=mysample)
    assert testenv['key'] == u'value'



# Generated at 2022-06-11 18:21:54.435537
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PWD'] == os.environ['PWD']

# Generated at 2022-06-11 18:22:04.315360
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:22:08.543320
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_env = {'my_key': 'my_value'}
    my_env = _TextEnviron(env=test_env)

    assert my_env['my_key'] == 'my_value'

# Generated at 2022-06-11 18:22:18.850202
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test if the _TextEnviron class returns the same value as os.environ if the environment
    # variable is of unicode type and is correctly encoded.
    import os
    from ansible.module_utils._text import to_bytes

    # This should construct a _TextEnviron with unicode keys and values
    unicode_environ = _TextEnviron()
    # Construct the expected unicode environment variable name and value
    if PY3:
        variable_name = os.environ['PATH']
        variable_value = os.environ['PATH']
    else:
        variable_name = os.environ['PATH'].decode('utf-8')
        variable_value = os.environ['PATH'].decode('utf-8')

    # Test unicode_environ.__getitem__(unicode_variable_name)

# Generated at 2022-06-11 18:22:24.009040
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['ANSIBLE_NET_PASSPHRASE'] = b'\x80'
    try:
        assert environ['ANSIBLE_NET_PASSPHRASE'] == u'\ufffd'
    finally:
        del os.environ['ANSIBLE_NET_PASSPHRASE']

# Generated at 2022-06-11 18:22:33.272956
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    def _test_env_variable(env, expected):
        if PY3:
            assert env[b'TEST_VAR'] == env[u'TEST_VAR']
            assert env[b'TEST_VAR'] == expected
        else:
            assert env[b'TEST_VAR'] == env[u'TEST_VAR']
            assert env[b'TEST_VAR'] == expected
            assert env[u'TEST_VAR'] == expected

    env = _TextEnviron(encoding='utf-8')
    # ASCII
    env[b'TEST_VAR'] = 'foo'
    _test_env_variable(env, 'foo')
    env[u'TEST_VAR'] = u'foo'
    _test_env_variable(env, 'foo')


# Generated at 2022-06-11 18:22:35.032233
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PWD'] == u'/home/user'

# Generated at 2022-06-11 18:22:41.818018
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron

    :return: None
    """

    env = _TextEnviron(encoding='utf-8')
    # test method __getitem__ of class _TextEnviron when os.environ is None
    try:
        #get an exception, type(val) is str
        val = env["LANG"]
    except KeyError:
        pass

    # test method __getitem__ of class _TextEnviron when os.environ is not None
    env = _TextEnviron(env={"LANG":"en_US.UTF-8","LANGUAGE":"en_US:en"},encoding='utf-8')

# Generated at 2022-06-11 18:22:51.315115
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Use the `SOME_VAR_NAME` variable if it is defined, or fall back to `FOO`
    test_variable = 'SOME_VAR_NAME'
    if test_variable not in environ:
        test_variable = 'FOO'

    # If the variable is defined and will always return the same value, use that.  testinfra
    # provides "ANSIBLE_TEST_DATA_ROOT" to indicate where it is storing the test data directory.
    # The 'ansible-test-data' subdirectory of this has our test data files.  Otherwise, fall
    # back to using the environment variable defined in environ.py
    if test_variable in environ:
        test_value = environ[test_variable]
    else:
        test_value = "env_var_value"

# Generated at 2022-06-11 18:22:54.150778
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    # 
    assert environ["PATH"]

# Generated at 2022-06-11 18:23:03.010836
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Line 12
    os.environ['ANSIBLE_TEST_VAR__BYTE_STRING'] = b'\xe9'
    # Line 13
    assert environ['ANSIBLE_TEST_VAR__BYTE_STRING'] == u'\u00e9'
    # Line 14
    os.environ['ANSIBLE_TEST_VAR__TEXT_STRING'] = u'\u00e9'
    # Line 15
    assert environ['ANSIBLE_TEST_VAR__TEXT_STRING'] == u'\u00e9'
    # Line 16
    os.environ['ANSIBLE_TEST_VAR__SURROGATE_ESCAPED_STRING'] = b'abcd\xed\xa0\x80\xed\xb0\x80abcd'
    #

# Generated at 2022-06-11 18:23:13.375870
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Make sure that we get bytes back from the cache if it's been populated
    env = _TextEnviron({'A': b'b'})
    assert isinstance(env['A'], bytes)

    # Make sure that we get text back from the environ instead of text
    env = _TextEnviron({u'A': u'b'})
    assert isinstance(env[u'A'], text_type)

    env = _TextEnviron({b'A': u'b'})
    assert isinstance(env[b'A'], text_type)

# Generated at 2022-06-11 18:23:24.847420
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # type: () -> None
    import copy

    class _FakeEnviron(MutableMapping):
        """
        A fake os.environ that always returns bytes
        """
        def __init__(self, env=None):
            self._raw_environ = env
            self._value_cache = {}

        def __delitem__(self, key):
            del self._raw_environ[key]

        def __getitem__(self, key):
            return self._raw_environ[key]

        def __setitem__(self, key, value):
            self._raw_environ[key] = value

        def __iter__(self):
            return self._raw_environ.__iter__()

        def __len__(self):
            return len(self._raw_environ)

    unicode_py

# Generated at 2022-06-11 18:23:26.503393
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['LANG'] == u'zh_CN.UTF-8'


# Generated at 2022-06-11 18:23:30.268502
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    key = 'foo'
    value = u'bar'
    env = {}
    env[key] = value
    myenviron = _TextEnviron(env)
    assert myenviron[key] == value


# Generated at 2022-06-11 18:23:37.462856
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # To test we can use the environ object as the operating system's environment
    import os, tempfile
    tmp_file = tempfile.NamedTemporaryFile()

    if not isinstance(tmp_file.name, str):
        # Windows requires us to open in text mode, which will be universal newline aware
        os.environ[to_text(tmp_file.name, encoding='utf-8', errors='surrogate_or_strict')] = 'spam'
    else:
        os.environ[tmp_file.name] = 'spam'
    result = environ[tmp_file.name]
    assert result == 'spam'

    # And that we can support encoding as well
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-11 18:23:45.061496
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    r"""
    Prüft das Element 'key'
    """
    from unittest.mock import patch
    from os import environ
    from ansible.module_utils._text import to_bytes
    environ['TEST'] = 'test'
    with patch('ansible.module_utils.six.PY3', True):
        environ = _TextEnviron(encoding='utf-8')
        assert environ.__getitem__('TEST') == 'test'
    with patch('ansible.module_utils.six.PY3', False):
        environ = _TextEnviron(encoding='utf-8')
        assert environ.__getitem__('TEST') == 'test'


# Generated at 2022-06-11 18:23:47.874647
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Verify the return value of __getitem__ when called with str type key.
    """
    new_env = {"abc": "abc"}
    text_environ = _TextEnviron(env=new_env, encoding='utf-8')
    assert text_environ.__getitem__("abc") == "abc"
    assert "abc" in text_environ


# Generated at 2022-06-11 18:23:55.927201
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        pass
    else:
        try:
            # Test with a native str that is already decoded
            environ._raw_environ['foo'] = b'bar'
            assert environ['foo'] == u'bar'
            # Test with a native unicode string
            environ._raw_environ['foo'] = u'bar'
            assert environ['foo'] == u'bar'
            # Test with a native bytes object that needs decoding
            environ._raw_environ['foo'] = b'bar\xE2\x98\x86'
            assert environ['foo'] == u'bar☆'
        except:
            raise
        finally:
            del environ._raw_environ['foo']


# Generated at 2022-06-11 18:24:02.808849
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """
    tb = _TextEnviron()

    # test for normal case
    tb['name1'] = b'value1'
    assert tb['name1'] == 'value1'
    # test for non-ascii characters
    tb['name2'] = 'value2'
    assert tb['name2'] == 'value2'

    # test for failure case
    tb['name3'] = b'\x9c'
    assert tb['name3'] == u"\ufffd"



# Generated at 2022-06-11 18:24:05.493394
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Note: This test relies on the CI system having an LANG environment variable set to 'en_US.utf8'.
    assert environ['LANG'] == 'en_US.utf8'


# Generated at 2022-06-11 18:24:16.569294
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class FakeEnviron(object):
        def __getitem__(self, key):
            return key
    testdict = FakeEnviron()
    t = _TextEnviron(testdict)
    for i in range(0, 2**31, 2**17):
        key = str(i)
        assert t[key] == key
        assert isinstance(t[key], str)


# Generated at 2022-06-11 18:24:25.002504
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class TestEnviron:
        def __init__(self):
            self._dict = {}
        def __getitem__(self, key):
            return self._dict[key]
        def __setitem__(self, key, value):
            self._dict[key] = value

    environ = _TextEnviron(env=TestEnviron())
    import six
    if six.PY2:
        # Test decoding from bytes to text
        environ._raw_environ['a'] = b'alpha'
        assert isinstance(environ['a'], six.text_type)
        # Test caching of decoded value
        assert environ['a'] is environ['a']
        # Test that cached values do not change
        environ._raw_environ['a'] = b'bravo'

# Generated at 2022-06-11 18:24:33.176180
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that passing through not strings as keys works
    test_str = to_text('Приветствие')
    env = _TextEnviron(encoding='utf-8')
    env[test_str] = test_str
    assert env[test_str] == test_str

    # Test that passing through bytes that represent a unicode string works
    test_bytes = test_str.encode('utf-8')
    env = _TextEnviron(encoding='utf-8')
    env[test_bytes] = test_bytes
    assert env[test_bytes] == test_bytes

    # Test that passing through bytes that are not a unicode string works
    test_bytes = b'\x04\x35\xf0\x9f\x92\xa9\x04\x35'


# Generated at 2022-06-11 18:24:41.202964
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Tests that _TextEnviron correctly returns text values from the underlying os.environ.
    """
    if sys.platform == 'win32':
        assert isinstance(environ[u'windir'], text_type)

    # Check if surrogate_or_strict was used as the errors replacement.  We do this by purposely
    # inserting a variable into the environment with a non-UTF-8 codepoint.  If surrogate_or_strict
    # was used, this raises an exception
    os.environ[b'ANSIBLE_TEST_VALUE'] = b'\xa0'
    try:
        assert isinstance(environ[u'ANSIBLE_TEST_VALUE'], text_type)
    except UnicodeDecodeError:
        pass

# Generated at 2022-06-11 18:24:44.326812
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ.__getitem__('HOME') is not None
    assert environ.__getitem__('HOME') == u'/root'
    assert environ.__getitem__('HOME') == '/root'

# Generated at 2022-06-11 18:24:51.894565
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # read and write should be as expected when using utf-8
    environ_test = _TextEnviron({b'key1': b'value1', b'key2': b'\xc3\xbf'}, encoding='utf-8')
    assert environ_test[b'key1'] == u'value1'
    assert environ_test[b'key2'] == u'\xef\xbf\xbf'

    # read and write should be as expected when using latin-1
    environ_test = _TextEnviron({b'key1': b'value1', b'key2': b'\xff'}, encoding='latin-1')
    assert environ_test[b'key1'] == u'value1'

# Generated at 2022-06-11 18:25:02.084384
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import sys
    import pytest
    # Note that there's a bug in pytest which causes it to put an empty string at the end of
    # `os.environ.keys()` so we need to work around it
    # https://github.com/pytest-dev/pytest/issues/2742
    try:
        os.environ.keys().remove('')
    except ValueError:
        pass
    for key in os.environ.keys():
        # not PY3 && surrogateescape
        if not PY3 and sys.getfilesystemencoding() == 'utf-8':
            with pytest.raises(ValueError):
                environ[key]
        # PY3 || surrogatepass
        else:
            assert(environ[key] == os.environ[key])

# Generated at 2022-06-11 18:25:08.414048
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print("Case 1: __getitem__ return text string")
    environ = _TextEnviron({b'foo': b'bar', b'\xfe': b'\xff'}, encoding='utf-8')
    print(environ.__getitem__(b'foo'))
    print(environ.__getitem__(b'\xfe'))
    print("Success")


# Generated at 2022-06-11 18:25:16.684044
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'foo': b'foo', b'bar': b'bar'})
    assert env[b'foo'] == u'foo'
    assert env[u'foo'] == u'foo'
    assert env['foo'] == u'foo'
    assert env[b'bar'] == u'bar'
    assert env[u'bar'] == u'bar'
    assert env['bar'] == u'bar'
    assert env[b'quux'] == u'quux'
    assert env[u'quux'] == u'quux'
    assert env['quux'] == u'quux'



# Generated at 2022-06-11 18:25:25.556900
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import mock
    import sys

    if PY3:
        # The logic we're testing against is only relevant in Python2.  Under Python3, os.environ
        # already has the desired behaviour so we just need to test that we have the same behaviour
        # as os.environ.
        #
        # os.environ is a MagicMapping object and we don't subclass from it.  Thus, check the
        # functionality we need to support.
        assert isinstance(environ, MutableMapping)
        assert hasattr(environ, '__len__')
        assert hasattr(environ, '__iter__')
        assert hasattr(environ, '__setitem__')
        assert hasattr(environ, '__getitem__')
        assert hasattr(environ, '__delitem__')

# Generated at 2022-06-11 18:25:40.873853
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env_var = 'VAR'
    utf8_value = u'ümlaut'
    # 'UTF-8' is the default encoding for Python3, but let's also test other encodings
    encodings = ('UTF-8', 'ISO-8859-1', 'CP1252')
    # Ensure that the environment variable to be tested is actually not set via os.environ
    if env_var in os.environ:
        del os.environ[env_var]
    # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
    # instead of utf-8

# Generated at 2022-06-11 18:25:51.133937
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_text, to_bytes
    from types import DictType

    # environ is a global
    global environ

    class Environ(DictType):
        pass

    class os(object):
        environ = Environ()
        environ['key1'] = to_bytes('value1', errors='surrogate_or_strict')
        environ['key2'] = to_bytes('value2', errors='surrogate_or_strict')
        environ['key3'] = to_bytes('value3', errors='surrogate_or_strict')

    # PY3
    if PY3:
        environ = _TextEnviron()
        assert len(os.environ) == len(environ)
        assert environ['key1'] == to_

# Generated at 2022-06-11 18:25:56.839172
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # create the class instance
    environ = _TextEnviron()

    # test if key exists in environment
    if 'HOME' in environ:
        home_path = environ['HOME']
        assert(home_path == os.getenv('HOME'))
    else:
        print('HOME not defined in environment')



# Generated at 2022-06-11 18:25:58.233160
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['ANSIBLE_INVENTORY'] == os.environ['ANSIBLE_INVENTORY']


# Generated at 2022-06-11 18:26:05.658341
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    This method tests the __getitem__ method of _TextEnviron class.
    It invokes the common_environment method and checks for the value
    of the environment variable.
    '''
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import MutableMapping
    class _TextEnviron(MutableMapping):
        '''
        The method overrides  __getitem__ method of MutableMapping class.
        It executes the __getitem__ method of MutableMapping class.
        '''
        def __init__(self, env=None, encoding=None):
            '''
            The init method executes the init method of MutableMapping class.
            '''
            if env is None:
                env = os.environ
           

# Generated at 2022-06-11 18:26:14.684027
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['testvar'] = 'testvalue'

    if PY3:
        assert environ['testvar'] == 'testvalue'
    else:
        assert environ['testvar'] == u'testvalue'

    # Now set testvar to a non-ascii variable and see that we get back unicode
    # anyway
    os.environ['testvar'] = b'\xe4\xf6\xfc'

    if PY3:
        assert environ['testvar'] == 'äöü'
    else:
        assert environ['testvar'] == u'äöü'

    del os.environ['testvar']


# Generated at 2022-06-11 18:26:24.624208
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test the underlying behaviour of _TextEnviron by checking a separate instance
    e = _TextEnviron(encoding='utf-8')
    assert e is not environ

    # Test that it returns a text string instead of a byte string
    e['a'] = b'aaa'
    assert isinstance(e['a'], str)

    # Test that we can access an existing variable with an encoding that is different
    # from the default.  This is really checking what happens if this module's environ variable
    # is used in a script which has been called from a script with a different encoding.  The
    # environ variable shouldn't change to match the subprocess' encoding.
    os.environ[u'hello'] = b'\xe6\xb5\xb7\xe8\xa5\xbf'

# Generated at 2022-06-11 18:26:36.146824
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print('testing __TextEnviron___getitem__')

    environ = _TextEnviron({'key': 'value'})
    assert 'value' == environ['key']

    environ = _TextEnviron({'key': b'value'})
    assert 'value' == environ['key']

    environ = _TextEnviron({'key': 'value'}, encoding='latin-1')
    assert 'value' == environ['key']

    environ = _TextEnviron({'key': b'value'}, encoding='latin-1')
    assert 'value' == environ['key']

    environ = _TextEnviron({'key': b'\xe6\x97\xa5\xd1\x88'}, encoding='euc-jp')
    assert '日文' == environ['key']

# Generated at 2022-06-11 18:26:37.783709
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PYTHONPATH'] == to_text(os.environ['PYTHONPATH'], encoding='utf-8', nonstring='passthru',
                                            errors='surrogate_or_strict')

# Generated at 2022-06-11 18:26:43.341466
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    l_environ = _TextEnviron(encoding='ascii')
    # Add entry
    l_environ['TEST'] = 'abc'
    # Check key exists
    assert 'TEST' in l_environ.keys()
    # Check that added entry is correct
    assert l_environ['TEST'] == 'abc'


# Generated at 2022-06-11 18:27:10.743902
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set the locale to a utf-8 locale
    os.environ['LANG'] = 'en_US.UTF-8'
    os.environ['LC_ALL'] = 'en_US.UTF-8'

    environ_obj = _TextEnviron()
    # Accessing the variable should give a string
    assert isinstance(environ_obj["LANG"], str)
    assert isinstance(environ_obj["LC_ALL"], str)
    # The actual variable should be a byte string
    assert isinstance(os.environ["LANG"], bytes)
    assert isinstance(os.environ["LC_ALL"], bytes)
    # Bad data stored in the environment should be handled
    os.environ["LANG"] = b'bad data'
    assert environ_obj["LANG"] == u'bad data'



# Generated at 2022-06-11 18:27:17.962971
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['ANSIBLE_TEST_ENV_VAR_ONE'] = 'test one'
    assert environ['ANSIBLE_TEST_ENV_VAR_ONE'] == 'test one'
    assert type(environ['ANSIBLE_TEST_ENV_VAR_ONE']) == str
    del environ['ANSIBLE_TEST_ENV_VAR_ONE']



# Generated at 2022-06-11 18:27:21.635698
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_test = _TextEnviron()
    env_test_var = 'ANSIBLE_BLAH_BLAH_BLAH'
    environ_test[env_test_var] = 'blah_blah_blah'
    assert(type(environ_test[env_test_var]) is str)
    os.environ.pop(env_test_var)
    assert(type(environ_test[env_test_var]) is str)
    # Check that the var is set and cached
    assert(environ_test._value_cache[environ_test._raw_environ[env_test_var]] is environ_test[env_test_var])


# Generated at 2022-06-11 18:27:22.685281
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
  assert environ['HOME'] == os.environ['HOME']

# Generated at 2022-06-11 18:27:33.282593
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Must return text strings
    assert isinstance(environ['HOME'], str)

    # Must return a non-decoded utf-8 value if the environment variable contains a utf-8 string
    # and the machine encoding is something else
    if sys.getfilesystemencoding() != 'utf-8':
        os.environ['ANSIBLE_TEST_ENV'] = u'éäö'.encode('utf-8')
        assert isinstance(environ['ANSIBLE_TEST_ENV'], str)
        assert environ['ANSIBLE_TEST_ENV'] == u'éäö'.encode('utf-8')
        del os.environ['ANSIBLE_TEST_ENV']

    # Must return a decoded value if the environment variable contains bytes that match the
    # machine encoding
    os.environ

# Generated at 2022-06-11 18:27:40.333654
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    def check_getitem(env, encoding, key, value, expected_decoded, expected_exception=False,
                      expected_decoded_bytes=None):
        te = _TextEnviron(env, encoding)
        if expected_exception:
            try:
                ret = te[key]
                assert False, '_TextEnviron[{!r}] should raise exception.  Got: {!r}'.format(key, ret)
            except Exception as e:
                assert e.__class__.__name__ == expected_exception
        else:
            ret = te[key]

# Generated at 2022-06-11 18:27:50.660620
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    my_env = _TextEnviron({b'str': u'foo', b'bytes': b'\xab\xcd\xef'}, encoding='utf-8')
    assert my_env[b'str'] == 'foo'

# Generated at 2022-06-11 18:27:52.002609
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == os.environ['HOME']

# Generated at 2022-06-11 18:27:59.931614
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test decoding (and caching)
    for key in ('LC_ALL', 'LC_CTYPE', 'LANG'):
        value = environ[key]
        # The value should be a string now
        assert isinstance(value, str), "Value for %s should be a string but is %s" % (key, type(value))
        # Make sure repeated calls to the same env var get the same value
        assert environ[key] is value, ("Value for %s should be re-used from cache but is at "
                                       "address %#x instead of %#x" % (key, id(value), id(environ[key])))

    # Test that changes to self._raw_environ invalidate the cache
    # Note: we don't need to test that the cache is invalidated on a change to the value because
    # self

# Generated at 2022-06-11 18:28:10.813701
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This is required if __getitem__() is called during tests (ansible-test network --collect)
    import os
    import sys
    # This complicated set of variables is to force the UTF-8 encoding.
    # Otherwise the default locale encoding is used, which may be ascii.
    os.environ['LANG'] = 'en_US.UTF-8'
    os.environ['LC_ALL'] = 'en_US.UTF-8'
    os.environ['LC_CTYPE'] = 'en_US.UTF-8'
    os.environ['LC_MESSAGES'] = 'en_US.UTF-8'
    os.environ['LC_COLLATE'] = 'en_US.UTF-8'

# Generated at 2022-06-11 18:29:06.189977
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test empty dictionary
    environ._raw_environ = {}
    assert len(environ) == 0
    assert environ._raw_environ == {}
    assert environ._value_cache == {}
    # Test single element dictionary
    environ._raw_environ = {'key': 'value'}
    assert len(environ) == 1
    assert environ._raw_environ == {'key': 'value'}
    assert environ._value_cache == {}
    assert environ['key'] == 'value'
    assert environ._raw_environ == {'key': 'value'}
    assert environ._value_cache == {'value': 'value'}
    # Test dictionary with different values
    environ._raw_environ = {'key': 'value', 'key2': 'value2'}
   

# Generated at 2022-06-11 18:29:16.229824
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    dict_unicode = {'key1': u'value1', 'key2': 'value2'}
    dict_bytes = {'key1': 'value1', 'key2': u'value2'}
    dict_bytes = {to_bytes(k): to_bytes(v) for k, v in dict_bytes.items()}
    dict_mixed = dict_unicode.copy()
    dict_mixed.update(dict_bytes)

    # Test __getitem__ returns unicode values for a unicode environment variable
    environ = _TextEnviron(env=dict_unicode)
    for key, expected in dict_unicode.items():
        result = environ[key]
        assert(isinstance(result, unicode))
        assert(result == expected)

    # Test __getitem__ returns unicode values for

# Generated at 2022-06-11 18:29:25.956627
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    make sure that we are returning text strings from the environment on Python2
    """
    if not PY3:
        # pop the key out of the environment, so we know the value will be coming from
        # cache in __getitem__
        key = 'ANSIBLE_TEST_KEY'
        old_value = os.environ.pop(key, None)

        # Create a new _TextEnviron, so we know we're starting with a fresh cache
        t_environ = _TextEnviron()

        # check that we are setting the key as a byte string from Unicode
        t_environ[key] = u'\u203d'

        # check that we are getting the key as a text string on Python2, and that the cache is
        # working
        assert t_environ[key] == u'\u203d'

# Generated at 2022-06-11 18:29:36.234188
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Values that are already in text format are returned as-is
    environ = _TextEnviron({'a': 'value'}, 'utf-8')
    assert environ['a'] == 'value'

    # There is no cache for text strings
    environ = _TextEnviron({'a': 'value'}, 'utf-8')
    assert len(environ._value_cache) == 0

    # Values that come back as bytes are converted to text
    environ = _TextEnviron({'a': b'value'}, 'utf-8')
    assert environ['a'] == 'value'

    # There is a cache for text strings
    environ = _TextEnviron({'a': b'value'}, 'utf-8')
    assert len(environ._value_cache) == 1
    # Retrieval of bytes values is

# Generated at 2022-06-11 18:29:42.009704
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Below are not correct usage, so we cannot do it
    # environ = _TextEnviron()
    # assert isinstance(environ.items(), list)
    # assert isinstance(environ.keys(), list)
    # assert isinstance(environ.values(), list)

    # The below is correct usage
    if PY3:
        assert isinstance(environ['HOME'], str)
    else:
        assert isinstance(environ['HOME'], unicode)


# Generated at 2022-06-11 18:29:50.393771
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test the method __getitem__ of class _TextEnviron

    The __getitem__ method of class _TextEnviron, converts the byte strings gotten from the
    environment, to text strings.
    """
    # Remove all the environment variables
    if environ:
        os.system('unset ' + ' '.join(environ.keys()))

    # This string contains only ascii characters.
    ascii_string = 'Hello World!'

    # This string contains non ascii characters.
    non_ascii_string = 'Hëllô Wörld!'

    # Set the value of the TEST_ASCII_ENV environment variable
    os.environ['TEST_ASCII_ENV'] = ascii_string

    # Set the value of the TEST_NON_ASCII_ENV environment variable


# Generated at 2022-06-11 18:30:00.809280
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import PY3

    encoding = 'utf-8'
    ascii_key = 'ascii_key'
    ascii_value = 'ascii_value'
    utf8_key = to_bytes('utf8_key', encoding=encoding)
    utf8_value = to_bytes('utf8_value', encoding=encoding)

    # Test the cache and the fallback handling
    raw_environ = os.environ

    raw_environ[ascii_key] = ascii_value

    def reset_cache():
        raw_environ[ascii_key] = ascii_value

    text_environ = _TextEnviron(env=raw_environ, encoding=encoding)


# Generated at 2022-06-11 18:30:05.215031
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'foo': b'bar', b'unicode': b'\xe9'})
    assert env.encoding == 'utf-8'
    assert env[b'foo'] == 'bar'
    assert isinstance(env[b'foo'], str)
    assert env[b'unicode'] == u'\xe9'
    assert isinstance(env[b'unicode'], str)


# Generated at 2022-06-11 18:30:11.805938
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os

    test_os_environ = {
        '1': '\u0041',
        '2': '\u00c0',
        '3': b'\xc3\x80',
        '4': b'\xff',
        '5': '',
        '6': b'',
    }
    original_environ = dict(os.environ)

# Generated at 2022-06-11 18:30:19.742567
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test the method _TextEnviron.__getitem__()

    :param None:
    :return: None
    """
    # Get the test variables
    test_env = {b'test_key_a': b'test_value_A', b'test_key_b': b'test_value_B'}
    # Instantiate the class
    test_instance = _TextEnviron(env=test_env)
    # Test the method
    for i in ['test_key_a', 'test_key_b']:
        print("Unit test for method _TextEnviron.__getitem__()")
        assert test_instance.__getitem__(i)
        print("The unit test has passed")