

# Generated at 2022-06-11 18:21:10.346306
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = {
        'empty': '',
        'utf8': '\xe4\xbd\xa0\xe5\xa5\xbd',
        'cp437': '\xca\xc7\xb4\xa5',  # cp437 is the encoding of these bytes
        'surrogates': '\xed\xa0\x80\xed\xbe\x80',
    }
    text_env = _TextEnviron(env)
    assert text_env['empty'] == ''
    assert text_env['utf8'] == u'你好'
    assert text_env['cp437'] == u'ÊÇ´¥'
    assert text_env['surrogates'] == u'\udc00\ud800'

# Generated at 2022-06-11 18:21:19.421850
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron({b'ANSIBLE_TEST_UTF8': b'\xc3\xb6\xc3\xa4',  # latin1 utf-8
                      b'ANSIBLE_TEST_LATIN': b'\xf6\xe4',
                      b'ANSIBLE_TEST_INT': b'12',
                      b'ANSIBLE_TEST_BOOL': b'0',
                      b'ANSIBLE_TEST_BIN': b'\xff\xfe\xfd\xfc\xfb\xfa\xf9\xf8'})
    assert e[b'ANSIBLE_TEST_UTF8'] == u'öä'
    assert e[b'ANSIBLE_TEST_LATIN'] == u'öä'
    assert e[b'ANSIBLE_TEST_INT']

# Generated at 2022-06-11 18:21:29.312222
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['abc'] = 'ABC'
    os.environ['abc'] = b'ABC'
    os.environ['def'] = 'DEF'
    os.environ['def'] = b'DEF'
    os.environ['ghi'] = b'GHI'
    # Check that we get 'ABC' for a string key
    assert environ['abc'] == 'ABC'
    # Check that we get 'DEF' for a string key
    assert environ['def'] == 'DEF'
    # Check that we get 'GHI' for a byte string key
    assert environ['ghi'] == 'GHI'

# Generated at 2022-06-11 18:21:36.022426
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_env = {to_bytes('ANSIBLE_TEST_KEY1', 'utf-8'): to_bytes('VALUE1', 'utf-8'),
                to_bytes('ANSIBLE_TEST_KEY2', 'utf-8'): to_bytes('VALUE2', 'utf-8')}
    test_environ = _TextEnviron(test_env, encoding='utf-8')
    assert test_environ['ANSIBLE_TEST_KEY1'] == 'VALUE1'
    assert test_environ['ANSIBLE_TEST_KEY2'] == 'VALUE2'

# Generated at 2022-06-11 18:21:44.666302
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest

    _PY3_ENV = _TextEnviron({'test': 'rødgrød'}, encoding='utf-8')

    class Test__TextEnviron___getitem__(unittest.TestCase):
        def test_py2_no_cache(self):
            if PY3:
                self.skipTest('only testable on Python2')
            self.assertEqual(_PY3_ENV['test'], u'rødgrød')

    return Test__TextEnviron___getitem__


# Generated at 2022-06-11 18:21:50.698360
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
  from chardet.universaldetector import UniversalDetector

  # The test case data is made available in the test directory
  f = open(os.path.join(os.path.dirname(__file__), "data/sample_file.txt"))
  text = f.read()
  f.close()

  detector = UniversalDetector()
  detector.feed(text)
  detector.close()

  # assume that the input text is utf-8 encoded string
  my_environ = _TextEnviron(encoding=detector.result["encoding"])
  my_environ["ANSIBLE_MODULE_ARGS"] = text
  result = my_environ["ANSIBLE_MODULE_ARGS"]

  # assume that the decoded string is equivalent to the original string
  assert (text == result)

# Generated at 2022-06-11 18:22:01.709401
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_text

    class_ = _TextEnviron

    # Test ansible.module_utils.six.PY2
    if not PY3:
        # Test encoded value in the environment
        key = b'TEST_ENCODING'
        value = 'TEST_ENCODING=\xc3\xbc'
        encoded_value = value.encode('utf-8')
        os.environ[key] = encoded_value
        assert class_({key: encoded_value})[key] == to_text(encoded_value, encoding='utf-8')
        assert class_()[key] == to_text(encoded_value, encoding='utf-8')

        # Test decoded value in the environment
        key = 'TEST_DECODED'

# Generated at 2022-06-11 18:22:13.981315
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(encoding='utf-8')
    # Python 3 returns bytes
    if PY3:
        fin = open(__file__, 'rb')
        filename = fin.name
        fin.close()
    else:
        fin = open(__file__, 'r')
        filename = fin.name
        fin.close()

    # Test getting things that exist and are already text
    env['ANSIBLE_TESTING_ENCODING'] = 'utf-8'
    assert env['ANSIBLE_TESTING_ENCODING'] == 'utf-8'

    # Test getting things that exist and are binary

# Generated at 2022-06-11 18:22:23.394884
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test data from six documentation
    import os

    # Create a dictionary of byte strings
    environ = os.environ.copy()
    environ_bytes = {}
    for k, v in environ.items():
        environ_bytes[k] = v.encode('ascii')
    # Create dictionaries that we'll use
    environ_unicode = _TextEnviron(environ)
    environ_latin1 = _TextEnviron(environ_bytes)

    # Now test what we get back
    assert isinstance(environ_unicode['PATH'], str)
    assert isinstance(environ_latin1['PATH'], str)

# Generated at 2022-06-11 18:22:26.325669
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print('Test method __getitem__ of class _TextEnviron:')
    for key in environ:
        print(key, ":", environ[key])


# Generated at 2022-06-11 18:22:36.711665
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os

    os.environ['test'] = 'test'
    os.environ['int'] = '1'
    os.environ['unicode'] = '💯'

    # Python2 requires the following import to validate unicode type
    # is returned from os.environ['unicode']
    if not PY3:
        from ansible.module_utils.six import text_type

    # Validate we're able to use the Environment class to get items
    assert environ['test'] == 'test'
    assert environ['int'] == '1'
    assert environ['unicode'] == u'💯' # noqa: F821

    if not PY3:
        # Validate type returned was unicode
        assert isinstance(environ['unicode'], text_type)


# Generated at 2022-06-11 18:22:47.593645
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes, to_text

    # Create an Environ with utf8 encoding
    env = {'foo': 'bar', 'baz': u'baz', 'buz': to_bytes(u'buz')}
    if PY3:
        te = _TextEnviron(env, 'utf8')
        assert te['foo'] == 'bar'
        assert te['baz'] == u'baz'
        assert te['buz'] == u'buz'
    else:
        te = _TextEnviron(env, 'utf8')
        assert te['foo'] == u'bar'
        assert te['baz'] == u'baz'
        assert te['buz'] == u'buz'


# Generated at 2022-06-11 18:22:50.172101
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['test_key'] = ''

    assert 'test_key' in environ
    assert environ.get('test_key') == ''


# Generated at 2022-06-11 18:23:01.681341
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os

    def reset_env():
        # All of the tests are run under Python 2.x but since we're mocking a future
        # Python 3.x API, we can't always rely on the tests passing under 3.x (yet).
        #
        # The OSError: [Errno 2] No such file or directory occurs if there are
        # characters in a string which are illegal in the filesystem encoding. So
        # we'll set the variables to values which are known to be legal in the
        # filesystem encoding.
        #
        # We don't set the value to None to allow tests to verify that None isn't returned
        # by the mock.
        os.environ = {'ASCII': 'ascii'}
        # Use a unicode string that can be decoded into the filesystem encoding
        if PY3:
            os

# Generated at 2022-06-11 18:23:13.076701
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Check that we can successfully retrieve an item, and that it's a text value
    environ.clear()
    environ['THIS_IS_AN_EXAMPLE'] = 'this is an example value'
    assert isinstance(environ['THIS_IS_AN_EXAMPLE'], str)
    assert environ['THIS_IS_AN_EXAMPLE'] == 'this is an example value'
    # Check that non-ascii characters are retrieved properly
    environ.clear()
    environ['THIS_IS_AN_EXAMPLE'] = 'これは演示の例です'
    assert isinstance(environ['THIS_IS_AN_EXAMPLE'], str)

# Generated at 2022-06-11 18:23:17.741752
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """ Test code for the __getitem__ method of _TextEnviron """
    environ = _TextEnviron()
    if PY3:
        assert isinstance(environ['HOME'], str)
    else:
        assert isinstance(environ['HOME'], unicode)


# Generated at 2022-06-11 18:23:21.233871
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = _TextEnviron({'key': b'bytes'})
    assert test_environ['key'] == u'bytes'


# Generated at 2022-06-11 18:23:28.853012
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    def check_environ(env, expected):
        for key in env:
            if key in expected:
                env_value = env[key]
                assert isinstance(env_value, type(expected[key])), \
                    "Expected %s to return an %s but was %s" % (key, type(expected[key]),
                                                                type(env_value))
    # Test without caching
    env = _TextEnviron({'PYTHONPATH': '/foo/bar'})
    expected = {'PYTHONPATH': '/foo/bar'}
    check_environ(env, expected)

    # Test with caching
    env = _TextEnviron({'PYTHONPATH': '/foo/bar'})
    env['PYTHONPATH'] = '/foo/bar'

# Generated at 2022-06-11 18:23:30.788117
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['foo'] = u'bar'
    assert environ['foo'] == u'bar'


# Generated at 2022-06-11 18:23:33.588165
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    t = _TextEnviron()
    assert isinstance(t, _TextEnviron)
    assert isinstance(t['HOME'], str)
    assert isinstance(t['HOME'], str)

# Generated at 2022-06-11 18:23:38.225588
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ.clear()
    environ['test_key'] = 'test_value'
    assert environ['test_key'] == 'test_value'


# Generated at 2022-06-11 18:23:45.897477
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This test is necessary only for python 2.7
    if not PY3:
        # Test foking of the os.environ
        the_os_environ = os.environ.copy()
        # Set a control item to the original os.environ to be sure is really the original one
        the_os_environ['the_key_b'] = 'the_value_b'
        # Create a new _TextEnviron object
        the_environ = _TextEnviron(env=the_os_environ, encoding='utf-8')
        # Fetch the key from the _TextEnviron object and test for equality
        the_key = 'the_key_b'
        the_value_b = 'the_value_b'
        the_value = the_environ[the_key]

# Generated at 2022-06-11 18:23:50.529466
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Arrange
    test_class = _TextEnviron(encoding='utf-8')
    test_class._raw_environ = {'test': 'success'}

    # Act
    result = test_class.__getitem__('test')

    # Assert
    assert result == 'success'


# Generated at 2022-06-11 18:23:57.171138
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = _TextEnviron()

    if PY3:
        # On Python 3, the environment is already unicode, so no conversion should be necessary
        assert test_environ['PATH'] == os.environ['PATH']
        assert test_environ['PATH'] == test_environ._raw_environ['PATH']
        assert test_environ['PATH'] == test_environ._value_cache[test_environ._raw_environ['PATH']]
    else:
        # On Python 2, we need to do a conversion
        assert test_environ['PATH'] == to_text(os.environ['PATH'],
                                               encoding=sys.getfilesystemencoding(),
                                               errors='surrogate_or_strict')
        assert test_environ['PATH'] == test_environ._value_

# Generated at 2022-06-11 18:24:01.344802
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """
    # Test with a byte string
    byte_string = b'\x41\xc3\x91\xc3\xa1\xc3\xa9\xc3\xad\xc3\xb3'
    environ_object = _TextEnviron({'byte_string': byte_string})

# Generated at 2022-06-11 18:24:11.088014
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Assert that we get the same values as os.environ using the default encoding
    assert environ['PYTHONIOENCODING'] == os.environ['PYTHONIOENCODING']
    #
    # Assert that we do not get a UnicodeDecodeError when an environment variable is set that is
    # invalid UTF-8
    environ['BEARS_ARE_PEOPLE_TOO'] = '\x00\x07'
    os.environ['BEARS_ARE_PEOPLE_TOO'] = '\x00\x07'
    assert environ['BEARS_ARE_PEOPLE_TOO'] == os.environ['BEARS_ARE_PEOPLE_TOO']
    #
    # Ensure that we get a UnicodeDecodeError when the environment variable is unset

# Generated at 2022-06-11 18:24:22.021741
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert to_text('ä') != u'ä'
    assert 'ä'.encode('utf-8') != u'ä'
    assert to_text('ä') != to_text(b'\xc3\xa4')
    os.environ['TEST'] = 'ä'
    assert environ['TEST'] == u'ä'
    assert environ['TEST'] != to_text('ä')
    assert environ['TEST'] != to_text(b'\xc3\xa4')
    assert environ['TEST'] == to_text(b'\xc3\xa4', encoding='utf-8')

    # Try to break the code
    os.environ['TEST'] = b'\xff'

# Generated at 2022-06-11 18:24:31.488566
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        # No need to test - the native os.environ will be used and is UTF-8
        return

    os.environ.update({'tricky_char': '\xf4'})
    my_environ = _TextEnviron(env=os.environ)
    assert isinstance(my_environ['tricky_char'], str)
    assert my_environ['tricky_char'] == u'\xf4'
    my_environ['tricky_char'] = u'\xf4'
    assert my_environ['tricky_char'] == u'\xf4'
    my_environ['tricky_char'] = u'z\xf4'
    assert my_environ['tricky_char'] == u'z\xf4'

# Generated at 2022-06-11 18:24:35.361356
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['ANSIBLE'] = 'True'
    assert environ['ANSIBLE'] == 'True'
    environ['ANSIBLE'] = 'True'.encode('utf-8')
    assert environ['ANSIBLE'] == 'True'

# Generated at 2022-06-11 18:24:46.145405
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    class _TextEnviron(MutableMapping):
        """
        Utility class to return text strings from the environment instead of byte strings

        Mimics the behaviour of os.environ on Python3
        """
        def __init__(self, env=None, encoding=None):
            if env is None:
                env = os.environ
            self._raw_environ = env
            self._value_cache = {}
            # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
            # instead of utf-8

# Generated at 2022-06-11 18:24:52.136488
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({'foo': b'bar'}, encoding='utf-8')
    assert env['foo'] == 'bar'



# Generated at 2022-06-11 18:25:01.950760
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    encodings = ['utf-8', 'latin-1', 'shift-jis']
    key = 'ANSIBLE_TEST_ANSIBLE_COLLECTIONS'
    base_value = u'[{"ns": "st2", "name": "test"}]'
    test_cases = [base_value,
                  base_value.encode('utf-8'),
                  base_value.encode('latin-1'),
                  base_value.encode('shift-jis')]
    for encoding in encodings:
        # Force clean cache between tests
        environ._value_cache = {}
        print('Testing encoding %s: ' % encoding)
        for value in test_cases:
            environ[key] = value
            assert environ[key] == base_value

# Generated at 2022-06-11 18:25:13.406543
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from tests.unit.module_utils.os_environ_mock import _TextEnvironMocker
    environ_mocker = _TextEnvironMocker()

    text_environ = _TextEnviron(env=environ_mocker.get_raw_environ())
    # Test __getitem__ method with text value and no encoding
    sourcetext = 'This is a test'
    key = 'SOURCE_ENVIRON'
    environ_mocker.setitem(key, sourcetext)
    targettext = text_environ[key]
    assert(sourcetext == targettext)

    # Test __getitem__ method with text value and with encoding
    encoding = 'latin1'

# Generated at 2022-06-11 18:25:19.632968
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(env={}, encoding='utf-8')
    assert env['foo'] is None
    env['foo'] = 'bar'
    assert env['foo'] == u'bar'
    env['foo'] = 'bár'
    assert env['foo'] == u'bár'
    # Make sure it can deal with the encoding changing from under it
    env._raw_environ['foo'] = 'bâr'
    assert env['foo'] == u'bâr'
    env['foo'] = 'b\xff'
    assert env['foo'] == u'b\ufffd'

# Generated at 2022-06-11 18:25:30.092457
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Environment variable with a string value
    os.environ['AA'] = 'bb'
    assert environ['AA'] == u'bb'

    # Environment variable with a string value containing non-ASCII text
    os.environ['AA'] = 'b\u20ac'
    assert environ['AA'] == u'b\u20ac'

    # Environment variable with an integer value
    os.environ['AA'] = '12'
    assert environ['AA'] == '12'

    # Environment variable with a boolean value
    os.environ['AA'] = 'True'
    assert environ['AA'] == 'True'

    # Environment variable with a value containing non-string characters
    os.environ['AA'] = '\x00'
    assert environ['AA'] == u'\\x00'


# Unit test

# Generated at 2022-06-11 18:25:37.794230
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # get value from os.environ
    environ_value = b'UTF-8'
    os.environ[u'LANG'] = environ_value
    assert environ[u'LANG'] == u'UTF-8'
    # replace value to os.environ
    new_environ_value = b'en_US.utf8'
    os.environ[u'LANG'] = new_environ_value
    assert environ[u'LANG'] == u'en_US.utf8'
    # delete value from os.environ
    del os.environ[u'LANG']
    assert u'LANG' not in environ


# Generated at 2022-06-11 18:25:41.820650
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Because _TextEnviron is meant to mimic Python3's os.environ API, tests for Python2 and Python3
    # are separate
    if PY3:
        assert environ['HOME'] == os.environ['HOME']
    else:
        assert environ[b'HOME'] == os.environ[b'HOME']

# Generated at 2022-06-11 18:25:51.778762
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(_env={"ANSIBLE_CALLBACK_PLUGINS": "./ansible/plugins/callback/default.py"}, encoding='utf-8')
    assert environ['ANSIBLE_CALLBACK_PLUGINS'] == "./ansible/plugins/callback/default.py"
    environ = _TextEnviron(_env={b'ANSIBLE_CALLBACK_PLUGINS': b'./ansible/plugins/callback/default.py'}, encoding='utf-8')
    assert environ['ANSIBLE_CALLBACK_PLUGINS'] == "./ansible/plugins/callback/default.py"
    environ = _TextEnviron(_env={b'ANSIBLE_CALLBACK_PLUGINS': b'./ansible/plugins/callback/\x80default.py'}, encoding='utf-8')

# Generated at 2022-06-11 18:26:01.851321
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # First: Test for PY3
    # Test for correct input
    assert environ['HOME'] == os.environ['HOME'], 'Test for correct input for PY3'
    # Test for incorrect input
    try:
        environ['not-exist']
    except KeyError:
        pass
    else:
        raise Exception('Test for incorrect input for PY3')

    # Second: Test for PY2
    # Test for correct input
    assert environ['HOME'] == os.environ['HOME'], 'Test for correct input for PY2'
    # Test for incorrect input
    try:
        environ['not-exist']
    except KeyError:
        pass
    else:
        raise Exception('Test for incorrect input for PY2')
    # Test for incorrect encoding

# Generated at 2022-06-11 18:26:11.961311
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:26:27.297044
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    def check_getitem(environ_value, expected_value):
        # Create a TextEnviron object
        env = _TextEnviron(encoding='ascii')
        # Add a key to it with the given value
        env['key'] = environ_value
        # Check that value matches the expected value
        assert env['key'] == expected_value

    check_getitem(b'a normal ascii string', u'a normal ascii string')
    check_getitem(b'\xb3 some ascii chars', u'\xb3 some ascii chars')
    check_getitem(b'\xff some ascii chars', u'\xff some ascii chars')
    check_getitem(b'\xff\xff some ascii chars', u'\xff\xff some ascii chars')
   

# Generated at 2022-06-11 18:26:38.126773
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b"key1": b"value1", b"key2": b"value2", b"key3": b"value3",
                            b"key4": b"value4"}, encoding='utf-8')
    assert environ.__getitem__(b"key1") == u"value1"
    assert environ.__getitem__(b"key2") == u"value2"
    assert environ.__getitem__(b"key3") == u"value3"
    assert environ.__getitem__(b"key4") == u"value4"

    # Test if the input of the method __getitem__ is a text string

# Generated at 2022-06-11 18:26:38.959127
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    assert environ['HOME'] == '/home/test'

# Generated at 2022-06-11 18:26:46.615877
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['foo'] = b'Bar'
    assert(environ['foo'] == 'Bar')

    environ['foo'] = 'Bar'
    assert(environ['foo'] == 'Bar')

    environ['foo'] = u'Bar'
    assert(environ['foo'] == 'Bar')

    environ['foo'] = b'\xc2\xae'
    assert(environ['foo'] == u'\u00ae')

    # This should throw a UnicodeError exception
    environ['foo'] = u'\udc00'

# Generated at 2022-06-11 18:26:56.828155
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from tempfile import mkdtemp

    # Set the environment variable to use for testing and create a temporary directory in that
    # environment's encoding
    test_name = 'TEST_ENV_VAR'
    test_value = six.text_type(mkdtemp())

    # Store the original environment and create a new one for testing
    orig_environ = environ._raw_environ
    new_environ = _TextEnviron(env={})

    # Test various values for the environment, tripping various points in the code
    new_environ[test_name] = test_value
    # Test that the raw environment has been set correctly
    assert type(new_environ._raw_environ[test_name]) is bytes

# Generated at 2022-06-11 18:27:03.619778
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    def _test_on_value(value):
        local_environ = _TextEnviron(env={'FOO': value})
        assert isinstance(local_environ['FOO'], str)

    _test_on_value('python2-like-env')
    _test_on_value(b'python2-like-env')

    if PY3:
        # The following value encodes to the same binary data on both Python2 and Python3 so it is
        # not a good test
        # _test_on_value(u'python2-like-env')
        _test_on_value('python3-like-env')


# Generated at 2022-06-11 18:27:11.824451
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    raw_environ = {b'foo': b'\xc2\xa1hola',   # utf-8 for '¡hola'
                   b'bar': b'\xe1\xbd\xb9\xcf\x83\xce\xbc\xce\xb5'}  # utf-8 for 'Ᾱςμε'
    env = _TextEnviron(env=raw_environ, encoding='utf-8')
    assert env['foo'] == u'\xa1hola'
    assert env['bar'] == u'\u1fb9\u03c3\u03bc\u03b5'

# Generated at 2022-06-11 18:27:21.882435
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Test function for method __getitem__ of class _TextEnviron.
    '''
    env = _TextEnviron({b'a_key': b'a_value'})
    assert env['a_key'] == u'a_value'

    # Value is cached so gets updated
    env._raw_environ[b'a_key'] = b'new_value'
    assert env['a_key'] == u'new_value'

    # Key is deleted, so it will be newly fetched
    del env._raw_environ[b'a_key']
    env['a_key'] = u'final_value'
    assert env['a_key'] == u'final_value'



# Generated at 2022-06-11 18:27:32.152478
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Verify that the original environ can still be accessed
    assert environ['PATH'] == '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    # Verify that we can access new values
    environ['FOO'] = 'bar'
    assert environ['FOO'] == 'bar'

    # Verify that we can decode values
    environ['FOO'] = b'\xd7\xa9\xd7\xa8\xd7\x95\xd7\x9d'
    assert environ['FOO'] == u'שרום'

    # Verify that we handle surrogates correctly
    environ['FOO'] = b'\xf0\x90\x80\x80'

# Generated at 2022-06-11 18:27:39.755258
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # pylint: disable=unused-variable,too-few-public-methods,no-self-use
    import pytest
    from ansible.module_utils.six import StringIO
    import os

    # Prepare environment
    environ_utf8 = to_bytes(u'ABC\u20ac', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    os.environ[u'ANSIBLE_TEST_VAR'] = u'ABC\u20ac'

    # Test class _TextEnviron
    test_environ = _TextEnviron(encoding='utf-8')
    assert test_environ['ANSIBLE_TEST_VAR'] == u'ABC\u20ac'

# Generated at 2022-06-11 18:27:58.772794
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # An empty object of _TextEnviron class
    empty_env = _TextEnviron()
    # An empty object of _TextEnviron class
    env = _TextEnviron()
    # Method __getitem__ should return a unicode string
    env["PATH"] = "C:\\Windows\\System32"
    assert env["PATH"] == u"C:\\Windows\\System32"
    # Method __getitem__ should raise a KeyError if the key isn't present
    try:
        empty_env["PATH"]
    except KeyError:
        pass
    else:
        raise AssertionError("Method __getitem__ should raise a KeyError when the key is not present.")



# Generated at 2022-06-11 18:28:05.304726
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ.__getitem__('HOME') == u'/root'

    # Create a text dictionary to test decode of the data for python2
    env = _TextEnviron({'HOME': u'/root'})
    assert env.__getitem__('HOME') == u'/root'
    assert env.__getitem__('HOME') != '/root'



# Generated at 2022-06-11 18:28:07.959531
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_env = _TextEnviron(env={b'var': b'value'})
    assert test_env['var'] == u'value'
    assert test_env.get('var') == u'value'
    assert u'value' in test_env.values()



# Generated at 2022-06-11 18:28:11.258747
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # TODO: Create test to confirm that environment variables with ASCII values do not get cached
    #       for methods other than get
    # TODO: Create test to confirm that environment variables with ASCII values get cached for get
    assert environ['HOME'] == os.getenv('HOME')

# Generated at 2022-06-11 18:28:21.074070
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we can get an item back
    environ['TEST'] = 'item'
    assert environ['TEST'] == 'item'

    # Test that we get a text item back when using a bytes key
    environ[to_bytes('TEST2', encoding='utf-8')] = 'item2'
    assert environ[to_bytes('TEST2', encoding='utf-8')] == 'item2'

    # Test that we get a text item back when using a text key
    environ['TEST3'] = 'item3'
    assert environ['TEST3'] == 'item3'

    # Make sure we throw KeyError if the key is not found

# Generated at 2022-06-11 18:28:32.441547
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    def check(key, value, expected):
        environ[key] = value
        try:
            assert environ[key] == expected
        finally:
            del environ[key]

    # Python 3
    if PY3:
        check(u'key', u'value', u'value')
        check(u'key', b'value', u'value')
        check(u'key', 'value', u'value')
        check(u'key', b'value', u'value')
        check(b'key', b'value', u'value')
        check(b'key', 'value', u'value')
        check(b'key', u'value', u'value')

    # Python 2
    else:
        check(u'key', u'value', u'value')

# Generated at 2022-06-11 18:28:36.418571
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Normal usage
    env = _TextEnviron({'foo': u'bar'})
    assert env['foo'] == 'bar'
    # Non-ascii, latin-1, unicode
    env = _TextEnviron({'foo': b'\xe9\xe9'}, encoding='latin-1')
    assert env['foo'] == u'\xe9\xe9'
    # Non-ascii, utf-8, non-unicode
    env = _TextEnviron({'foo': b'\xe9\xe9'})
    assert env['foo'] == u'\xe9\xe9'
    # Non-ascii, latin-1, non-unicode
    env = _TextEnviron({'foo': b'\xe9\xe9'}, encoding='latin-1')


# Generated at 2022-06-11 18:28:42.171838
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Use of this method is in the TextEnviron.env_prefix function, which is called
    # in the Args class __init_ and __getattr___ methods.  In addition, it is called
    # in the EnvironmentVars class __getitem__ method.  Testing these usages is
    # sufficient to test the method.

    # Method called by Args.__init__
    class ArgsMock():
        def __init__(self):
            self.env_prefix = 'ANSIBLE_'
            self.env_separator = '_'

    # Method called by Args.__getattr__ for attributes that start with env_
    class AnsibleMock():
        def __init__(self):
            self.args = ArgsMock()

    # Method called by EnvironmentVars.__getitem__
    ansible = Ansible

# Generated at 2022-06-11 18:28:52.644500
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest

    class Test__TextEnviron__getitem__(unittest.TestCase):
        def test__TextEnviron___getitem__(self):
            # Create an environ obj
            custom_env = {'a': 'b'}
            test_env = _TextEnviron(env=custom_env, encoding='utf-8')

            # Assert the obj has been properly initialized
            self.assertIn('a', test_env)

            # Assert that the env provides a text value
            self.assertTrue(isinstance(test_env['a'], unicode))

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(Test__TextEnviron__getitem__))
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-11 18:28:54.546536
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'foo': 'bar'})
    assert (environ['foo'] == 'bar')


# Generated at 2022-06-11 18:29:29.741688
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = {
        'ansible_text': b'ansible\xE2\x9C\x93',
        'ansible_bytes': b'ansible\xE2\x9C\x93',
        'bytes_only': b'bytes_only',
    }
    environ = _TextEnviron(env)

    assert environ['ansible_text'] == u'ansible\N{CHECK MARK}'
    assert environ['ansible_bytes'] == u'ansible\N{CHECK MARK}'
    assert environ['bytes_only'] == u'bytes_only'


# Generated at 2022-06-11 18:29:31.401540
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['home'] = b'/root'
    assert environ['home'] == u'/root'

# Generated at 2022-06-11 18:29:36.208067
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Arrange
    environ.clear()
    environ._raw_environ = {'A': 'B'}

    # Act
    item = environ['A']

    # Assert
    assert item == 'B'



# Generated at 2022-06-11 18:29:44.286783
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    utf8 = 'niño'.encode('utf-8')
    ascii = 'nino'.encode('ascii')
    latin1 = 'niño'.encode('latin-1')
    latin12 = 'ni\xF1o'.encode('latin-1')

    environ = _TextEnviron({'utf': utf8,
                            'latin': latin12,
                            'ascii': ascii},
                           encoding='latin-1')
    assert environ['utf'] == 'ni\xc3\xb1o'
    assert environ['ascii'] == 'nino'
    assert environ['latin'] == 'ni\xf1o'



# Generated at 2022-06-11 18:29:52.070762
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class DummyEnviron(dict):
        pass

    text_env = _TextEnviron(DummyEnviron({b'foo': b'bar'}))
    assert text_env[b'foo'] == u'bar'

    text_env = _TextEnviron(DummyEnviron({b'foo': b'b\x00ar'}))
    assert text_env[b'foo'] == u'b\udc00ar'

    text_env = _TextEnviron(DummyEnviron({b'foo': b'b\x00ar'}), encoding='ascii')
    assert text_env[b'foo'] == u'b?ar'

    text_env = _TextEnviron(DummyEnviron({b'foo': b'b\x00ar'}), encoding=None)
    assert text_env

# Generated at 2022-06-11 18:30:00.947322
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    testenviron = _TextEnviron(encoding='utf-8', env={b'ANSIBLE_PSRP_BINARY_PATH': b'C:\\Windows\\system32\\WindowsPowerShell\\v1.0\\powershell.exe'})
    assert testenviron[b'ANSIBLE_PSRP_BINARY_PATH'] == 'C:\\Windows\\system32\\WindowsPowerShell\\v1.0\\powershell.exe'
    assert testenviron[u'ANSIBLE_PSRP_BINARY_PATH'] == u'C:\\Windows\\system32\\WindowsPowerShell\\v1.0\\powershell.exe'


# Generated at 2022-06-11 18:30:07.842401
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # If sys.getfilesystemencoding() returns a non-unicode string like 'ANSI_X3.4-1968'
    # (as is the case on Mac OS X) then using the pre-defined environ set in this file
    # will cause an error when os.environ is accessed in the test.  Explicitly set it
    # back to UTF-8 before trying the test.
    import ansible.module_utils.common.collections
    sys.getfilesystemencoding = lambda: 'UTF-8'
    import unittest
    from ansible.module_utils.six.moves import mock


# Generated at 2022-06-11 18:30:11.408262
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['foo'] = 'bar'
    assert environ['foo'] == 'bar'


# Generated at 2022-06-11 18:30:16.937375
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_env = _TextEnviron()
    del test_env['HOME']
    if 'HOME' in test_env:
        print("Can't test __TextEnviron_getitem__ without deleting HOME from the environment")
    else:
        # Since there's no HOME variable, we're going to get a KeyError
        try:
            test_env['HOME']
        except KeyError:
            print("KeyError raised successfully")
        else:
            print("Expected a KeyError to be raised")



# Generated at 2022-06-11 18:30:24.746747
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['A'] = 'B'
    assert environ['A'] == 'B'

    if PY3:
        environ['A'] = b'\xce\xb1'
        assert environ['A'] == 'α'
    else:
        from ansible.module_utils.six import b, u
        environ['A'] = b'\xce\xb1'
        if sys.getdefaultencoding() == 'ascii':
            assert environ['A'] == b
        else:
            assert environ['A'] == u