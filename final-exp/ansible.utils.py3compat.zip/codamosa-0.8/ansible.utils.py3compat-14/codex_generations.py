

# Generated at 2022-06-11 18:21:06.687077
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Case: key with no value in os.environ
    environ = _TextEnviron()

    assert environ["ABS_NOT_IN_ENVIRON"] == ""

    # Case: key with empty value in os.environ
    os.environ["ABS_ENVIRON_WITH_EMPTY_VALUE"] = ""

    assert environ["ABS_ENVIRON_WITH_EMPTY_VALUE"] == ""

    del os.environ["ABS_ENVIRON_WITH_EMPTY_VALUE"]

    # Case: key with value in os.environ
    os.environ["ABS_ENVIRON_WITH_VALUE"] = "Xyzzy"

    assert environ["ABS_ENVIRON_WITH_VALUE"] == "Xyzzy"


# Generated at 2022-06-11 18:21:17.663237
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env_orig = {b'ANSIBLE_MODULE_ARGS':b'test=1', b'ANSIBLE_VAR':b'\xe9\x99\xa4'}
    environ = _TextEnviron(env_orig, encoding='utf-8')

    assert environ['ANSIBLE_MODULE_ARGS'] == 'test=1'
    assert environ['ANSIBLE_VAR'] == '\xe9\x99\xa4'
    
    # Test nonstring parameter = True
    assert environ['ANSIBLE_MODULE_ARGS'] == 'test=1'
    environ['ANSIBLE_MODULE_ARGS'] = 1
    assert environ['ANSIBLE_MODULE_ARGS'] == '1'

    # Test nonstring parameter = False

# Generated at 2022-06-11 18:21:27.321592
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_env = {b'PATH': b'dummy', b'LANG': b'zh_CN.utf8', b'PWD': b'/var/lib/jenkins'}
    env = _TextEnviron(env=test_env)
    assert to_text(test_env[b'PATH']) == env[to_text(b'PATH')]
    assert to_text(test_env[b'LANG']) == env[to_text(b'LANG')]
    assert to_text(test_env[b'PWD']) == env[to_text(b'PWD')]

# Generated at 2022-06-11 18:21:36.373179
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # try a couple utf-8 strings for which we'll be able to decode
    environ.clear()
    environ['SOME_KEY'] = "österreich"
    assert environ['SOME_KEY'] == u"österreich"

    environ.clear()
    environ['SOME_KEY'] = "Österreich"
    assert environ['SOME_KEY'] == u"Österreich"

    # try some things that may be in environ that we don't expect to be able to decode
    environ.clear()
    environ['SOME_KEY'] = 'G\xc3\xb6del'
    assert environ['SOME_KEY'] == u'G\ufffd\ufffddel'

    environ.clear()
    environ['SOME_KEY'] = b

# Generated at 2022-06-11 18:21:45.646972
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['SOME_UTF8_VAR'] = 'der günstige'
    assert environ['SOME_UTF8_VAR'] == u'der günstige'
    environ['ANOTHER_UTF8_VAR'] = u'새롭게'
    assert environ['ANOTHER_UTF8_VAR'] == u'새롭게'
    environ['LATIN1_VAR'] = b'\x9cber teuer'
    assert environ['LATIN1_VAR'] == u'über teuer'

# Generated at 2022-06-11 18:21:54.662425
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(encoding='utf-8')
    environ2 = _TextEnviron(encoding='utf-8')

    # Strings ending in ascii characters
    assert environ['PYTHONPATH'] == environ2['PYTHONPATH']
    assert environ['PYTHONPATH'] == os.environ['PYTHONPATH']
    assert environ['PYTHONPATH'].encode('utf-8') == os.environ['PYTHONPATH']

    # Strings ending in non-ascii characters
    os.environ['TESTVAR'] = '123Ъ'
    assert environ['TESTVAR'] == os.environ['TESTVAR']

# Generated at 2022-06-11 18:22:03.860224
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping


# Generated at 2022-06-11 18:22:08.940924
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Call method under test
    rcr = environ.__getitem__('PATH')
    # Verify result
    assert isinstance(rcr, str), \
        "Type of return value from _TextEnviron.__getitem__('PATH') is not str."


# Generated at 2022-06-11 18:22:19.185611
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['ANSIBLE_CONSTANT_BAZ'] = 'Baz'
    os.environ['ANSIBLE_CHANGING_FOO_BAR1'] = 'foo'
    os.environ['ANSIBLE_CHANGING_FOO_BAR2'] = 'bar'

    assert environ['ANSIBLE_CONSTANT_BAZ'] == 'Baz'
    assert environ['ANSIBLE_CHANGING_FOO_BAR1'] == 'foo'
    assert environ['ANSIBLE_CHANGING_FOO_BAR2'] == 'bar'

    os.environ['ANSIBLE_CONSTANT_BAZ'] = b'Baz'
    os.environ['ANSIBLE_CHANGING_FOO_BAR1'] = b'foo'

# Generated at 2022-06-11 18:22:23.304332
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class DummyEnviron(object):
        def __init__(self):
            self.__environ = {'foo': b'bar', 'baz': 'qux'}

        def __getitem__(self, key):
            return self.__environ[key]

    environ = _TextEnviron(DummyEnviron())

    assert environ['foo'] == u'bar'
    assert environ['baz'] == u'qux'



# Generated at 2022-06-11 18:22:34.872665
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an environment with a non-UTF8 environment variable.
    # To do this, we'll have to have a non-UTF8 environment variable
    # in this process and then create an environment that inherits
    # our environment instead of being copy of os.environ
    utf8key = to_bytes('utf8key', encoding='utf-8')
    utf8val = to_bytes('utf8val', encoding='utf-8')
    bytearraykey = to_bytes('bytes\xffkey', encoding='iso8859-1')
    bytearrayval = to_bytes('bytes\xffval', encoding='iso8859-1')
    os.environ[utf8key] = utf8val
    os.environ[bytearraykey] = bytearrayval
    testenviron = _TextEnviron()

# Generated at 2022-06-11 18:22:44.757122
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest

    class TestEnv(unittest.TestCase):
        def setUp(self):
            self.encoding = 'utf-8'
            self.non_utf8 = '\xe9'.encode(self.encoding, errors='surrogateescape')
            self.env = _TextEnviron({b'good': 'good', b'non_utf8': self.non_utf8},
                                    encoding=self.encoding)

        def test_getitem_good(self):
            self.assertEqual(self.env[b'good'], 'good')


# Generated at 2022-06-11 18:22:53.006590
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import sys
    import unittest
    from ansible._text_compat import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    # these values are default values defined in module ansible.module_utils.common._collections_compat
    raw_environ = {b'foo': b'bar', b'bar': b'baz'}
    encoding = 'utf-8'

    class Derived_TextEnviron(MutableMapping):
        def __init__(self, env, encoding):
            self._raw_environ = env
            self._value_cache = {}
            if encoding is None:
                self.encoding = sys.getfilesystemencoding()
            else:
                self.encoding = encoding


# Generated at 2022-06-11 18:22:57.070892
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['key1'] = u'aa'
    environ['key2'] = 'bb'
    assert environ['key1'] == u'aa'
    assert environ['key2'] == 'bb'



# Generated at 2022-06-11 18:23:04.592933
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    orig_environ = environ._raw_environ

    # the value is unicode.
    environ._raw_environ = {u'foo': u'bar'}
    environ._value_cache = {}
    assert environ[u'foo'] == u'bar'
    assert len(environ._value_cache) == 1
    assert environ._value_cache[u'bar'] == u'bar'

    # The value is unicode.
    environ._value_cache = {}
    assert environ[u'foo'] == u'bar'
    assert len(environ._value_cache) == 1
    assert environ._value_cache[u'bar'] == u'bar'

    # The value is not unicode.

# Generated at 2022-06-11 18:23:14.838431
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['TEST_VAR'] = 'TEST_VALUE'
    var = environ['TEST_VAR']
    if PY3:
        assert var == 'TEST_VALUE'
    else:
        assert var == u'TEST_VALUE'

    # Test with non-ascii character
    os.environ['TEST_NON_ASCII_VAR'] = 'TEST_NON_ASCII_VALUE'
    # Convert bytes to unicode for test
    var = environ['TEST_NON_ASCII_VAR']
    if PY3:
        assert var == 'TEST_NON_ASCII_VALUE'
    else:
        assert var == u'TEST_NON_ASCII_VALUE'


# Generated at 2022-06-11 18:23:22.783674
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Method '__getitem__' must convert bytes strings read from environment to text strings.
    """
    env = _TextEnviron({b'_testValue1': b'_testValueByteString1',
                        b'_testValue2': b'_testValueByteString2'}, encoding='utf-8')
    assert env[b'_testValue1'] == '_testValueByteString1'
    assert env[b'_testValue2'] == '_testValueByteString2'



# Generated at 2022-06-11 18:23:33.940397
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_text

    environ = _TextEnviron(encoding=to_text('latin-1', 'utf-8'))

    # Test: Key is a utf-8 encoded unicode string
    key = to_text('नमस्ते', 'utf-8')
    value = b'\xe0\xa4\xa8\xe0\xa4\xae\xe0\xa4\xb8\xe0\xa5\x8d\xe0\xa4\xa4\xe0\xa5\x87'
    environ[key] = value
    assert environ[key] == to_text('नमस्ते', 'utf-8')

    # Test: Key is a ascii encoded unic

# Generated at 2022-06-11 18:23:35.443121
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == '/home/ansible'


# Generated at 2022-06-11 18:23:39.423110
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert 'abc' == environ['abc']
    assert u'abc' == environ['abc']
    assert to_text('abc') == environ['abc']
    assert to_text(b'abc') == environ['abc']

# Generated at 2022-06-11 18:23:53.738192
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'a':b'a', b'b':u'b', b'c':u'\U0001F600', u'c':b'\U0001F600'})
    assert env[b'a'] == u'a'
    assert env[u'a'] == u'a'
    assert env[b'b'] == u'b'
    assert env[u'b'] == u'b'
    assert env[b'c'] == u'\U0001F600'
    assert env[u'c'] == u'😀'

    # try to decode with surrogateescape error handler
    env = _TextEnviron({b'a':b'\xff'})
    assert env[b'a'] == u'\udcff'

    # try to decode with strict error handler

# Generated at 2022-06-11 18:24:03.290467
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Mock os.environ
    def getenv(key):
        return os.environ.get(key)

    environ = _TextEnviron(getenv, 'utf-8')

    # Basic test
    os.environ['ANSIBLE_MYVAR'] = 'ANSIBLE_MYVAR'
    assert(environ['ANSIBLE_MYVAR'] == 'ANSIBLE_MYVAR')

    # Test unicode
    os.environ['ANSIBLE_MYVAR'] = '\u4f60\u597d'
    assert(environ['ANSIBLE_MYVAR'] == '\u4f60\u597d')
    del os.environ['ANSIBLE_MYVAR']

    # Test bytes

# Generated at 2022-06-11 18:24:14.141078
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import tempfile
    import pytest
    import warnings


# Generated at 2022-06-11 18:24:23.617211
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import sys

    import pytest

    @pytest.mark.skipif(not PY3, reason='Cannot test __getitem__ if not on Python3')
    def test_python3_os_environ_type(monkeypatch):
        original_environ = os.environ
        monkeypatch.setattr(os, 'environ', _TextEnviron())
        assert isinstance(os.environ[u'test_key1'], str) is True
        assert isinstance(os.environ['test_key1'], str) is True
        assert isinstance(os.environ[u'test_key2'], str) is True
        assert isinstance(os.environ['test_key2'], str) is True


# Generated at 2022-06-11 18:24:32.332195
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Store the currnet value of the environment variable to test.  We have to store this because
    # we'll have to restore it after the test.  We also have to check if the variable is set in the
    # first place.
    if 'ANSIBLE_TESTVAR' in os.environ:
        original_value = os.environ['ANSIBLE_TESTVAR']
        restore_value = True
    else:
        original_value = None
        restore_value = False

    os.environ['ANSIBLE_TESTVAR'] = b'foo'

    if PY3:
        assert environ['ANSIBLE_TESTVAR'] == 'foo'
    else:
        assert environ['ANSIBLE_TESTVAR'] == u'foo'


# Generated at 2022-06-11 18:24:40.781378
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    The method returns a value from environ if that value is a unicode string.
    Otherwise, it decodes the value to unicode using the given encoding.

    The test checks that if the value is a unicode string, the given value will be returned.
    If the value is not a unicode string, the value will be decoded to unicode using the given
    encoding.
    """
    encoding = 'utf-8'
    env = {'a': u'\xe3\x82\xad\xe3\x83\xa3\xe3\x82\xbf',
           'b': '\xe3\x82\xad\xe3\x83\xa3\xe3\x82\xbf',
           'c': 'A'}
    _TextEnviron.__init__(env, encoding)


# Generated at 2022-06-11 18:24:50.222670
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:24:51.981080
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os

    os.environ['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'
    assert 'ANSIBLE_TEST_VALUE' == environ['ANSIBLE_TEST_KEY']

# Generated at 2022-06-11 18:25:02.120074
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = {'unicode': u'\u1234',
                    'latin1': '\xe4',
                    'utf8': u'\u1234'.encode('utf8'),
                    'stray_surrogate': 'stray \xed\xa0\x80 surrogate',
                    'stray_byte': 'stray \xc2 byte',
                    'invalid_utf8': 'invalid \xed\xa0\x80 utf8',
                    'surrogate_byte': '\xed\xa0\x80 surrogate byte'}
    encoding = 'utf8'
    _test_environ = _TextEnviron(test_environ, encoding)

    # Test the unicode string
    answer = u'\u1234'

# Generated at 2022-06-11 18:25:08.461236
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(env={"key1":to_bytes("value1"), "key2":to_bytes("value2"), "key3":to_bytes("value3")}, encoding='utf-8')
    assert env["key1"] == to_text("value1")
    assert env["key2"] == to_text("value2")
    assert env["key3"] == to_text("value3")

# Generated at 2022-06-11 18:25:17.958735
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'TPYE_STR': b'\xC3\x96\xC3\xB6\xC3\xA4'})
    assert environ['TPYE_STR'] == u'\u00D6\u00F6\u00E4'


# Generated at 2022-06-11 18:25:27.293005
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    cur_environ = dict(environ)
    expected_raw_environ = dict(environ._raw_environ)
    # Check that we can get a unicode value from it
    expected_value = to_text('Test Value', encoding='utf-8')
    environ['TEST_TO_TEXT'] = expected_value
    assert environ['TEST_TO_TEXT'] == expected_value
    assert environ._raw_environ['TEST_TO_TEXT'] == b'Test Value'

    # Check that we can get a byte string from it
    expected_value = to_bytes('Test Value', encoding='utf-8', nonstring='strict')
    environ['TEST_TO_BYTES'] = expected_value
    assert environ['TEST_TO_BYTES'] == expected_value
    assert en

# Generated at 2022-06-11 18:25:37.446567
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """
    # Tests for cases where the environment variable is not ASCII

# Generated at 2022-06-11 18:25:40.824890
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ["foobar"] = "baz"
    assert(environ["foobar"] == "baz")
    assert(environ["foobar"] == environ._raw_environ["foobar"])
    assert(type(environ["foobar"]) == str)


# Generated at 2022-06-11 18:25:51.133759
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'ANSIBLE_PYTHON_INTERPRETER': b'/usr/bin/python',
                            b'LANG': b'en_US.UTF-8',
                            b'PATH': b'/home/toshio/ansible/tools/py3-venv/bin:/home/toshio/ansible/tools/py2-venv/bin:/home/toshio/ansible/bin:/home/toshio/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin'},
                           encoding='utf-8')


# Generated at 2022-06-11 18:26:00.536029
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import platform
    from ansible.module_utils._text import to_bytes, to_native

    if platform.python_version_tuple() >= (3, ):
        return

    e = _TextEnviron()
    os.environ[b'TEST_KEY'] = b'test'
    assert e['TEST_KEY'] == u'test'
    os.environ[b'TEST_KEY'] = 'test'
    assert e['TEST_KEY'] == u'test'
    os.environ[b'TEST_KEY'] = '\xe9'
    assert e['TEST_KEY'] == u'\xe9'

# Generated at 2022-06-11 18:26:06.799710
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Unit test for method __getitem__ of class _TextEnviron"""
    # Variables
    environ = _TextEnviron(encoding='utf-8')
    system_encoding = sys.getfilesystemencoding()
    # Test
    environ['LANGUAGE'] = 'fr_FR.UTF-8'
    assert environ['LANGUAGE'] == 'fr_FR.UTF-8'
    assert isinstance(environ['LANGUAGE'], str)
    environ['ANSIBLE_TEST'] = '#¤%=¨/√'
    assert environ['ANSIBLE_TEST'] == '#¤%=¨/√'
    assert isinstance(environ['ANSIBLE_TEST'], str)

# Generated at 2022-06-11 18:26:16.197848
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import pytest

    e = _TextEnviron()

    # Test that a key that doesn't exist returns the correct Python3 behaviour
    with pytest.raises(KeyError):
        e['this_is_a_key_that_doesnt_exist']

    # Test we retrieve the value of the key if it exists
    assert to_text(os.environ[to_bytes('HOME')]) == e['HOME']

    # Test that a bytestring gets properly decoded
    assert to_text(os.environ[to_bytes('SHELL')]) == e['SHELL']

    # Test that a text string gets properly decoded
    assert to_text(os.environ[to_text('LANG')]) == e['LANG']

# Generated at 2022-06-11 18:26:26.382148
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:26:29.743528
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # assert almost equal
    testEnv = {'TEST_KEY': 'TEST_VALUE'}
    env = _TextEnviron(env=testEnv)
    assert env['TEST_KEY'] == 'TEST_VALUE'

# Generated at 2022-06-11 18:26:46.067079
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    test_env = _TextEnviron()
    test_env['key1'] = b'value1'

    # Test with key not in dictionary
    assert test_env['key2'] == 'key2'

    # Test with key in dictionary
    assert test_env['key1'] == b'value1'


# Generated at 2022-06-11 18:26:52.173549
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    key = 'ANSIBLE_TEST_KEY'
    val = 'ANSIBLE_TEST_VALUE'

    # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
    # instead of utf-8
    environ[key] = val
    assert environ[key] == val

    # Delete the test key
    del environ[key]

# Generated at 2022-06-11 18:27:00.766245
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import environscope
    import os

    my_environ_expected = {
        'spam': 'SPAM',
        'TESTING': '123',
        'bad': 'too bad',
        'unicode_var': u'\udce6',
        'unicode_var_utf8_encoded': '\xee\x81\xa6',
    }

    environ = environscope.environ

    assert os.environ['unicode_var_utf8_encoded'].decode('utf-8') == my_environ_expected['unicode_var']
    assert environ['unicode_var_utf8_encoded'] == my_environ_expected['unicode_var']

# Generated at 2022-06-11 18:27:10.860857
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ2 = _TextEnviron(encoding='utf-8')

    # Test decoding a string using the encoding specified, utf-8
    assert environ2['FOO'] == 'bar'

    # Test decoding a string using the fallback encoding, cp1252

# Generated at 2022-06-11 18:27:21.988787
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test code
    # Set up test environment variable
    os.environ['A'] = b'abc\xe1'
    os.environ['B'] = 'spam'
    os.environ['C'] = 'a\xe1c'
    os.environ['D'] = 'spam'

    # Test os.environ
    assert os.environ.get('A') != os.environ.get('C')
    assert os.environ.get('B') == os.environ.get('D')

    # Test _TextEnviron
    assert environ.get('A') == environ.get('C')
    assert environ.get('B') == environ.get('D')

    # Cleanup test environment variable
    environ.__delitem__('A')
    environ.__delitem__

# Generated at 2022-06-11 18:27:29.072371
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
        Test case for _TextEnviron.__getitem__()
    """
    environ = _TextEnviron(encoding='utf-8')
    env_test = dict(environ)
    env_test["PATH"] = "测试"
    env_test["LANG"] = "测试"
    environ._raw_environ.update(env_test)

    assert environ["PATH"] == "测试"
    assert environ["LANG"] == "测试"

# Generated at 2022-06-11 18:27:31.606483
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ._raw_environ = {'SIMPLE_VALUE': 'VALUE'}

    assert environ['SIMPLE_VALUE'] == u'VALUE'


# Generated at 2022-06-11 18:27:39.463098
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class MockOSEnviron(MutableMapping):
        def __init__(self, *args, **kwargs):
            self._dict = {}

        def __delitem__(self, key):
            del self._dict[key]

        def __getitem__(self, key):
            return self._dict[key]

        def __setitem__(self, key, value):
            self._dict[key] = value

        def __iter__(self):
            return self._dict.__iter__()

        def __len__(self):
            return len(self._dict)


# Generated at 2022-06-11 18:27:50.165421
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Expected non-text raw environment value
    non_text_raw_env = {
        # On Python2, this is type 'str'
        'true_non_text_raw_env': to_bytes('hello world')
    }

    # Expected text raw environment value
    text_raw_env = {
        # On Python2, this is type 'unicode'
        'true_text_raw_env': to_text('hello world')
    }

    # Expected non-text with surrogate escapes raw environment value
    non_text_surrogate_escapes_raw_env = {
        # On Python2, this is type 'str'
        'true_non_text_surrogate_escapes_raw_env': b'\x80\xfd\xfe\xff'
    }

    # Expected unicode

# Generated at 2022-06-11 18:27:53.758246
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ._raw_environ['test__getitem__'] = to_bytes('string', 'utf-8')
    assert environ['test__getitem__'] == 'string'
    del environ['test__getitem__']
    assert environ._value_cache == {}

# Generated at 2022-06-11 18:28:23.841929
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we cache the undecoded values of the environment variables
    os.environ['A'] = '\u1234'
    os.environ['B'] = '\u4567'
    os.environ['C'] = '\u2345'

    result = environ['A']
    assert result == '\u1234'
    assert result == environ['A']
    assert result == environ['B']
    assert result == environ['C']

    os.environ['B'] = '\u7890'
    assert result == environ['B']

    del os.environ['B']
    assert result == environ['B']

    os.environ['A'] = '\u4567'
    assert result != environ['A']



# Generated at 2022-06-11 18:28:25.205150
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PWD'] == os.getcwd()


# Generated at 2022-06-11 18:28:27.487881
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():  # noqa
    for value in environ.values():
        assert isinstance(value, str)

# Generated at 2022-06-11 18:28:33.265822
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that it returns text strings
    assert isinstance(environ['HOME'], str)

    # Test that it returns text strings
    # Note that this check is only true for UTF-8 on a non-Python3 system (or if PY3 is set)
    assert isinstance(environ['XDG_RUNTIME_DIR'], str)



# Generated at 2022-06-11 18:28:43.978862
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest
    import os

    class Test__TextEnviron___getitem__(unittest.TestCase):
        def test__no_decoding(self):
            env = _TextEnviron(env={'b': 'woot'.encode('utf-8')}, encoding=None)
            self.assertEqual(env['b'], 'woot'.encode('utf-8'))

        def test__no_decoding_str_unicode_str(self):
            env = _TextEnviron(env={'b': 'woot'}, encoding=None)
            self.assertEqual(env['b'], 'woot')

        def test__decoding(self):
            env = _TextEnviron(env={'b': 'woot'.encode('utf-8')}, encoding='utf-8')
           

# Generated at 2022-06-11 18:28:54.433735
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    myenv = _TextEnviron(env=dict(a=b"abc"), encoding='utf-8')
    assert myenv['a'] == u'abc'

    myenv = _TextEnviron(env=dict(a="abc"), encoding='utf-8')
    assert myenv['a'] == u'abc'

    myenv = _TextEnviron(env=dict(a=b"\xC3\xBC"), encoding='utf-8')
    assert myenv['a'] == u'\u00fc'

    myenv = _TextEnviron(env=dict(a=b"\xC3\xBC"), encoding='ascii')
    assert myenv['a'] == u'\ufffd\ufffd'


# Generated at 2022-06-11 18:29:01.115412
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    env[b'string_key'] = b'test'
    env[b'byte_string_key'] = b'test'
    env[b'unicode_key'] = 'test'
    env[b'unicode_byte_string_key'] = 'test'

    # When values are byte strings, they should be returned as byte strings
    assert isi

# Generated at 2022-06-11 18:29:08.261275
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes

    # Unicode environ variable
    environ['PYTHONTEST_STRING_IN_UTF8'] = u'äöüß'
    assert environ['PYTHONTEST_STRING_IN_UTF8'] == to_bytes(u'äöüß', 'utf-8', nonstring='passthru', errors='surrogate_or_strict')
    del(environ['PYTHONTEST_STRING_IN_UTF8'])

    # This should pass the test, but it's cached so we'll just del() it

# Generated at 2022-06-11 18:29:12.860171
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(env={b'/bin/sh': b'SHELL'}, encoding='utf-8')
    if PY3:
        assert environ['/bin/sh'] == 'SHELL'
    else:
        assert environ['/bin/sh'] == b'SHELL'
#


# Generated at 2022-06-11 18:29:23.207177
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a test environment dictionary with a single byte-string variable
    byte_string = b'This is a byte string'
    byte_string_var = b'PY3_MODULEUTILS_TEST__BYTE_STRING'
    byte_string_dict = {byte_string_var: byte_string}

    # Create a copy of the _TextEnviron class that uses the above test environment dictionary
    # instead of os.environ
    class _TestTextEnviron(_TextEnviron):
        def __init__(self, env):
            super(_TestTextEnviron, self).__init__(env=env)

    os.environ = byte_string_dict
    test_environ = _TestTextEnviron(byte_string_dict)

    # Get the value of the byte string using _TestTextEnviron.__getitem__

# Generated at 2022-06-11 18:30:16.265635
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(
        env={
            'ANSIBLE_TEST_KEY1': 'value1',
            'ANSIBLE_TEST_KEY2': 'value2',
        },
        encoding='utf-8',
    )
    assert environ['ANSIBLE_TEST_KEY1'] == 'value1'
    assert environ['ANSIBLE_TEST_KEY2'] == 'value2'


# Generated at 2022-06-11 18:30:26.167946
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:30:33.752150
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Verify that _TextEnviron.__getitem__ handles unicode encoding
    """
    class Env(dict):
        def __getitem__(self, key):
            return b'\xe9'

        def __iter__(self):
            return ['foo', '\xe9'].__iter__()

    env = _TextEnviron(env=Env())
    # getitem
    assert env['foo'] == u'\xe9'
    assert env['\xe9'] == u'\xe9'

    # iter
    assert u'\xe9' in env
    assert u'foo' in env



# Generated at 2022-06-11 18:30:42.404702
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # in a PY3 environment
    os_environ_backup = os.environ
    os.environ = {'ANSIBLE_INPUT_DATA_ENCODING': 'ascii'}
    os.environ = {'ANSIBLE_INPUT_DATA_ENCODING': 'latin-1'}
    os.environ = {'ANSIBLE_INPUT_DATA_ENCODING': 'utf-8'}
    os.environ = {'ANSIBLE_WILL_CREATE_TEST_VAR' : 'TESTVALUE'}
    environ_ = _TextEnviron(env=os.environ, encoding=os.environ['ANSIBLE_INPUT_DATA_ENCODING'])

# Generated at 2022-06-11 18:30:51.956035
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # We are going to cache values returned from os.environ so that we don't have to decode
    # them for every access.  We want to test the cache so we need a fresh instance of
    # _TextEnviron
    from ansible.module_utils.common._collections_compat import MutableMapping
    env = _TextEnviron()
    env['TEST_VAR'] = 'testing'

    # Check that the value returned is a text string
    assert isinstance(env['TEST_VAR'], to_text)

    # It should have decoded the value as utf-8
    assert (env['TEST_VAR'] == to_text('testing', encoding='utf-8', nonstring='passthru',
                                       errors='surrogate_or_strict'))
    # It should have cached the result


# Generated at 2022-06-11 18:30:54.386851
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert to_text(os.environ[to_bytes('HOME')]) == environ[to_bytes('HOME')]



# Generated at 2022-06-11 18:30:58.965772
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    if 'SHLVL' in os.environ:
        assert isinstance(environ['SHLVL'], str)
    else:
        assert 'SHLVL' not in environ
    assert isinstance(environ['USER'], str)
