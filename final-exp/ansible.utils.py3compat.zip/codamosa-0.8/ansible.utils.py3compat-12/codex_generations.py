

# Generated at 2022-06-11 18:21:12.168105
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'x': b'xyz'}, encoding='utf-8')
    assert isinstance(env[u'x'], str)
    assert env[u'x'] == u'xyz'

    env = _TextEnviron({'x': b'xyz'}, encoding='utf-8')
    assert isinstance(env[u'x'], str)
    assert env[u'x'] == u'xyz'

    env = _TextEnviron({u'x': b'xyz'}, encoding='utf-8')
    assert isinstance(env[u'x'], str)
    assert env[u'x'] == u'xyz'

    # Unicode Error
    env = _TextEnviron({b'x': b'\xd8'}, encoding='utf-8')

# Generated at 2022-06-11 18:21:16.230029
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['foo'] = 'bar'

    assert environ.get('foo', 42) == 'bar'
    assert environ['foo'] == 'bar'
    assert environ.get('foo') == 'bar'
    assert environ.get('foo', 42) == 'bar'


# Generated at 2022-06-11 18:21:22.900734
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({':'.join([''.join(['ACMEMODULES', str(x), str(y), str(z)])
                                  for x in range(10)])
                        : ':'.join([''.join(['ACMEMODULES', str(x), str(y), str(z)])
                                    for x in range(10)]),
                        'PATH': ':'.join([''.join(['ACMEMODULES', str(x), str(y), str(z)])
                                          for x in range(10)])},
                       encoding='utf-16')
    assert ':'.join([''.join(['ACMEMODULES', str(x), str(y), str(z)]) for x in range(10)]) == \
        env['PATH']
   

# Generated at 2022-06-11 18:21:24.971985
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['key'] = 'item'
    assert environ['key'] == 'item'



# Generated at 2022-06-11 18:21:34.920975
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Total length of the environment variables
    total_length = 0
    # Set up the _raw_environ dict
    _raw_environ = {}
    # A dict to store values from _raw_environ before and after encoding to compare
    environ_dict = {}
    # Create a _TextEnviron object
    text_env = _TextEnviron(_raw_environ, encoding='utf-8')
    # Create a dict to store the values between get and set
    value_cache = {}
    for key, value in os.environ.items():
        # Add to the total environment variable length
        total_length += len(value)
        # Convert the keys to bytes
        key_bytes = to_bytes(key, encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
        # Convert the

# Generated at 2022-06-11 18:21:45.684964
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Clear the cache so we can detect when a value is previously cached
    environ._value_cache = {}
    # Define utf-8 encoding
    environ.encoding = 'utf-8'

    # Define environment variable 'ANSI' with value 'UTF-8' and set it in the environ
    os.putenv(to_bytes('ANSI', 'utf-8'), to_bytes('UTF-8', 'utf-8'))
    assert to_bytes('ANSI', 'utf-8') in os.environ
    assert os.environ[to_bytes('ANSI', 'utf-8')] == to_bytes('UTF-8', 'utf-8')

    environ["ANSI"] = 'UTF-8'

    # Check if the value is cached

# Generated at 2022-06-11 18:21:48.284512
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Unit test for method __getitem__ of class _TextEnviron
    '''
    assert environ['HOME'] == os.environ['HOME']

# Generated at 2022-06-11 18:21:56.206880
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import io
    import unittest
    import unittest.mock
    import os

    import sys
    PY3 = sys.version_info[0] == 3
    varset = 'set' if PY3 else 'Set'
    getencoding = 'getfilesystemencoding' if PY3 else 'getdefaultencoding'

    class TestEnviron(unittest.TestCase):
        def setUp(self):
            # Some environ[key] values that we'll use
            self.byte_value = 'b'.encode('utf-8')
            self.text_value = '\u2318'
            self.text_value_with_mapping = '\u2318\udc2d'

# Generated at 2022-06-11 18:22:01.972257
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ["TEXT_VAR1"] = "text value"
    assert environ["TEXT_VAR1"] == "text value"
    # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
    # instead of utf-8
    environ["BYTE_VAR1"] = to_bytes(b"byte value", encoding=sys.getfilesystemencoding())
    assert environ["BYTE_VAR1"] == "byte value"

# Generated at 2022-06-11 18:22:14.319441
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that 'Environment key' can be used to retrieve environment values
    # and that the value is decoded using utf-8.
    import os
    import ansible.module_utils.six as six

    from ansible.module_utils.common._collections_compat import MutableMapping

    class _TextEnviron(MutableMapping):
        """
        Utility class to return text strings from the environment instead of byte strings

        Mimics the behaviour of os.environ on Python3
        """
        def __init__(self, env=None, encoding=None):
            if env is None:
                env = os.environ
            self._raw_environ = env
            self._value_cache = {}
            if encoding is None:
                self.encoding = 'utf-8'

# Generated at 2022-06-11 18:22:27.066683
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    # test for str
    key, value = 'HOME', '.'
    environ[key] = to_bytes(value, encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    assert to_text(value, encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict') == environ[key]

    # test for list
    key = 'PATH'
    value = [to_text('/tmp', encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict'),
             to_text('/run', encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict')]

# Generated at 2022-06-11 18:22:28.352519
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == '/root'

# Generated at 2022-06-11 18:22:32.627904
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # set up
    key = 'PYTHONIOENCODING'
    environ[key] = 'utf-8'
    os.environ['PYTHONIOENCODING'] = None

    # run
    result = environ[key]

    # verify
    assert result == 'utf-8'



# Generated at 2022-06-11 18:22:33.755253
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass

# Generated at 2022-06-11 18:22:38.490402
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert sys.getfilesystemencoding() == 'utf-8'
    assert environ.encoding == 'utf-8'
    assert isinstance(environ.encoding, str)
    assert environ['PATH'] == os.environ['PATH']
    assert isinstance(environ['PATH'], str)


if __name__ == '__main__':
    test__TextEnviron___getitem__()

# Generated at 2022-06-11 18:22:48.865261
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with 'utf-8' as encoding for class _TextEnviron
    environ_utf8 = _TextEnviron(encoding='utf-8')
    # Test that bytes are returned when not in PY3
    assert isinstance(environ_utf8["LANG"], bytes)
    # Test if bytes are returned in PY3
    if PY3:
        assert isinstance(environ_utf8["LANG"], str)
    # Test if the value of 'LANG' is returned
    assert environ_utf8["LANG"] == os.environ["LANG"]
    # Test for 'ascii' as encoding for class _TextEnviron
    environ_ascii = _TextEnviron(encoding='ascii')
    # Test if bytes are returned in PY3

# Generated at 2022-06-11 18:23:00.588187
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # 1. type(key) == text
    environ.clear()
    environ['key'] = value = 'value'
    assert environ['key'] == value
    assert environ._raw_environ['key'] == to_bytes(value, encoding='utf-8', nonstring='strict',
                                                   errors='surrogate_or_strict')

    # 2. type(key) == bytes
    environ.clear()
    environ[key] = value = 'value'
    assert environ['key'] == value
    assert environ._raw_environ[key] == to_bytes(value, encoding='utf-8', nonstring='strict',
                                                 errors='surrogate_or_strict')

    # 3. type(key) == other
    environ.clear()
    key = 1


# Generated at 2022-06-11 18:23:08.725125
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_str = to_bytes('фёдор', encoding='utf-8')
    test_dict = {'ascii': b'ascii',
                 'bytes': to_bytes('bytes', encoding='utf-8'),
                 'utf-8': test_str}
    env = _TextEnviron(env=test_dict, encoding='utf-8')

    # Test text string gets returned
    assert to_text(env['bytes']) == 'bytes'

    # Test unicode string gets returned
    assert env['utf-8'] == to_text(test_str)



# Generated at 2022-06-11 18:23:17.253994
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import uuid
    tmp_environ = _TextEnviron(encoding='utf-8')
    tmp_key = str(uuid.uuid4())
    tmp_value = str(uuid.uuid4())
    tmp_environ[tmp_key] = tmp_value
    assert tmp_value == tmp_environ[tmp_key]

    # When I set a value, it should be returned correctly
    tmp_environ[tmp_key] = str(uuid.uuid4())
    assert(tmp_environ[tmp_key] != tmp_value)

    # If the value is unicode, the unicode should be returned instead of a byte string
    tmp_value = u'I am unicodé'
    tmp_environ[tmp_key] = tmp_value

# Generated at 2022-06-11 18:23:27.336577
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import datetime
    from ansible.module_utils.six import ensure_binary

    env = _TextEnviron(encoding='utf-8')
    env['foo'] = 'bar'
    env['baz'] = '☃'
    env['now'] = datetime.datetime.now().isoformat(sep=' ')
    env['bignums'] = '0xabcdef567890'

    assert env['foo'] == 'bar'
    assert env['baz'] == '☃'
    assert env['now'] == datetime.datetime.now().isoformat(sep=' ')
    assert env['bignums'] == '0xabcdef567890'

    # Make sure that after decoding that the bytes value returned from the cached value is the
    # same as the original bytes value
    assert ensure_binary

# Generated at 2022-06-11 18:23:31.498383
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(environ['PATH'], str)

# Generated at 2022-06-11 18:23:40.014107
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Test for class _TextEnviron, method __getitem__
    """

    # Set the environment value to and differing value
    # Initialize
    environ = _TextEnviron(encoding='utf-8')
    environ['TEST_VAL'] = 'foobar'

    # Is the environment value still 'foobar'
    assert environ['TEST_VAL'] == 'foobar'

    # Change the environment value
    os.environ['TEST_VAL'] = 'changed'

    # Ensure the environmnet value is still 'foobar'
    assert environ['TEST_VAL'] == 'foobar'

    # Reset the environment value
    del environ['TEST_VAL']

# Generated at 2022-06-11 18:23:50.028391
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global environ
    
    environ = _TextEnviron({'A':'abc'})
    assert(environ['A'] == 'abc')

    environ = _TextEnviron({'A':b'abc'})
    assert(environ['A'] == 'abc')

    environ = _TextEnviron({'A':b'\xe9'})
    assert(environ['A'] == '\xe9')

    environ = _TextEnviron({'A':b'\xe9'.decode('utf-8')})
    assert(environ['A'] == '\xe9')

# Generated at 2022-06-11 18:23:56.213983
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    if PY3:
        str_type = str
    else:
        str_type = unicode
    assert isinstance(env[u'HOME'], str_type)
    assert isinstance(env['HOME'], str_type)
    assert isinstance(env[b'HOME'], str_type)
    # Test the string 'encoding' of the class _TextEnviron
    env = _TextEnviron(encoding='ascii')
    assert isinstance(env[u'HOME'], str_type)
    assert isinstance(env['HOME'], str_type)
    assert isinstance(env[b'HOME'], str_type)

# Generated at 2022-06-11 18:23:59.952684
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({'b_key': b'bytes_value', 't_key': 'unicode_value'})
    assert env['b_key'] == 'bytes_value'
    assert env['t_key'] == 'unicode_value'



# Generated at 2022-06-11 18:24:08.929281
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Simple get
    environ['a'] = 'a'
    assert environ['a'] == 'a'

    # Single value in cache
    environ['a'] = 'a'
    environ['b'] = 'b'
    assert environ['a'] == 'a'
    assert environ['b'] == 'b'
    assert environ._value_cache == {'a': 'a'}

    # Refetch a value in the cache
    environ['a'] = 'a'
    environ['b'] = 'b'
    assert environ['a'] == 'a'
    assert environ['b'] == 'b'
    assert environ['a'] == 'a'
    assert environ._value_cache == {'a': 'a', 'b': 'b'}

    # Change a value in the environment

# Generated at 2022-06-11 18:24:20.102304
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we are decoding
    test_env = _TextEnviron({b'ascii': b'\xe3\x81\x82',
                             b'non_ascii': b'test1 \xe3\x81\x82 test2',
                             b'unicode': u'ア'})
    assert test_env[b'ascii'] == u'あ'
    assert test_env[b'unicode'] == u'ア'
    assert test_env[b'non_ascii'] == u'test1 あ test2'
    # Test that we are caching values
    test_env._raw_environ[b'ascii'] = b'1'
    assert test_env[b'ascii'] == u'あ'

# Generated at 2022-06-11 18:24:27.153372
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This function is intended to be run directly by tests, not as part of any module's unit
    # tests.  Therefore, we do not check the ansible_module_utils directory.
    os.environ['PATH'] = '# Test string: £©€'
    env = _TextEnviron()
    assert env['PATH'] == '# Test string: £©€'
    os.environ['PATH'] = '# Test string: £'
    assert env['PATH'] == '# Test string: £©€'

# Generated at 2022-06-11 18:24:28.346423
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == os.path.expanduser('~')

# Generated at 2022-06-11 18:24:39.141965
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_test = _TextEnviron({'test1': 'test1'}, encoding='utf-32')
    assert environ_test['test1'] == u'test1'

    environ_test = _TextEnviron({'test1': 'test1'}, encoding='utf-8')
    # On PY3, the os.environ contains text, no need to decode it
    assert environ_test['test1'] == u'test1'

    environ_test = _TextEnviron({'test1': 'test1'}, encoding='utf-16')
    assert environ_test['test1'] == u'test1'

    environ_test = _TextEnviron({'test1': 'test1'}, encoding='utf-7')
    assert environ_test['test1'] == u'test1'

    #

# Generated at 2022-06-11 18:24:49.367205
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # If os.environ return bytes string on Python2
    if not PY3:
        assert isinstance(os.environ['HOME'], bytes)
    # If environ.environ return text string on Python2
    if not PY3:
        assert isinstance(environ['HOME'], str)



# Generated at 2022-06-11 18:25:00.738925
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest
    from ansible.module_utils._text import to_bytes

    class _Environ(MutableMapping):
        def __init__(self, values, encoding=None):
            self.values = values
            self.encoding = encoding

        def __len__(self):
            return len(self.values)

        def __getitem__(self, key):
            return to_bytes(self.values[key], encoding=self.encoding, nonstring='passthru',
                            errors='surrogate_or_strict')

        def __iter__(self):
            return self.values.__iter__()

        def __setitem__(self, key, value):
            self.values[key] = value

        def __delitem__(self, key):
            del self.values[key]



# Generated at 2022-06-11 18:25:05.083689
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert 'foo' == environ['MOCK_ENV_VAR_FOO']
    assert 'bar' == environ['MOCK_ENV_VAR_BAR']
    assert 'baz' == environ['MOCK_ENV_VAR_BAZ']

# Unit tests for method __setitem__ of class _TextEnviron

# Generated at 2022-06-11 18:25:13.014566
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # A mapping corresponding to the current environment
    environ._raw_environ = {'foo': 'bar', 'baz': 'blah'}
    # Test that the values are returned in the encoding we expect
    # Also test that the cache is used properly
    assert environ['foo'] == u'bar'
    environ._raw_environ['foo'] = 'blah'
    assert environ['foo'] == u'bar'
    assert environ._value_cache['blah'] == u'bar'

# Generated at 2022-06-11 18:25:20.853627
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with str in sys.stdout.encoding
    with patch.object(sys, 'stdout', StringIO()) as stdout:
        sys.stdout.encoding = 'UTF-8'
        environ_test = _TextEnviron({b'key1': b'value1', b'key2': b'value2'})
        assert environ_test[b'key1'] == to_text(b'value1')
        assert environ_test[b'key2'] == to_text(b'value2')
        assert environ_test.encoding == 'UTF-8'

    # Test with str in sys.stdout.encoding
    with patch.object(sys, 'stdout', StringIO()) as stdout:
        sys.stdout.encoding = 'utf-8'

# Generated at 2022-06-11 18:25:31.819875
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    # On Python2, os.environ items are undecoded bytes.  On Python3, os.environ items are text
    if PY3:
        sample_env = {to_text(b'PATH', encoding='utf-8'): to_text(b'/bin:/usr/bin', encoding='utf-8'),
                      to_text(b'HOME', encoding='utf-8'): to_text(b'/home/a.badger', encoding='utf-8')}
    else:
        sample_env = {b'PATH': b'/bin:/usr/bin',
                      b'HOME': b'/home/a.badger'}
    environ = _TextEnviron(env=sample_env, encoding='utf-8')
    assert environ['PATH'] == '/bin:/usr/bin'
    assert environ

# Generated at 2022-06-11 18:25:39.653946
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class _TestEnviron(MutableMapping):
        def __init__(self, encoded_key, decoded_value):
            self.encoded_key = encoded_key
            self.decoded_value = decoded_value
        def __delitem__(self, key):
            raise NotImplementedError()
        def __getitem__(self, key):
            if key == self.encoded_key:
                return self.encoded_key
            else:
                raise KeyError
        def __setitem__(self, key, value):
            raise NotImplementedError()
        def __iter__(self):
            raise NotImplementedError()
        def __len__(self):
            raise NotImplementedError()

    environ = _TestEnviron(b'unit', u'unit')
    assert en

# Generated at 2022-06-11 18:25:40.784451
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ[u'TEST'] == u'test'

# Generated at 2022-06-11 18:25:51.134398
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    class MyFakeEnviron(object):
        def __init__(self):
            self._env = {}

        def __setitem__(self, key, value):
            self._env[key] = value

        def __getitem__(self, key):
            return self._env[key]

        def __iter__(self):
            return self._env.__iter__()

        def __delitem__(self, key):
            del self._env[key]

        def __len__(self):
            return len(self._env)

    print("\n### Testing method __getitem__ of class _TextEnviron")
    test_encoding = "utf-8"
    my_fake_environ = MyFakeEnviron()
    my_fake_environ["fake.var"] = "value"

# Generated at 2022-06-11 18:26:00.536202
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    d = {'byte_str': b'byte_str',
         'unicode_str': u'unicode_str',
         'non_ascii_str_utf8': u'\u043f\u0440\u0438\u0432\u0435\u0442'.encode('utf-8'),
         'non_ascii_str_cp1252': u'\u043f\u0440\u0438\u0432\u0435\u0442'.encode('cp1252')}

    for key, value in d.items():
        assert(environ[key] == value.decode('utf-8'))



# Generated at 2022-06-11 18:26:21.361361
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.common._collections_compat import UserDict
    from ansible.module_utils.six import PY3

    test_dict = UserDict(encoding='utf-8')
    test_dict['test_key'] = 'test_value'

    # Convert string to byte string
    key = 'test_key'.encode()
    value = 'test_value'.encode()

    # Test if the method __getitem__ returns string
    if PY3:
        assert test_dict[key] == value
    else:
        assert test_dict[key] == 'test_value'

# Generated at 2022-06-11 18:26:29.479528
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import types

    def test_env_var(env_var_name, env_var_value, expected_result, nonstring):
        if nonstring is None:
            environ = _TextEnviron(env={env_var_name: env_var_value})
        else:
            environ = _TextEnviron(env={env_var_name: env_var_value}, nonstring=nonstring)

        # print("%s: environ[%s] = %s" % (testname, env_var_name, environ[env_var_name]))

# Generated at 2022-06-11 18:26:39.685422
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # If a key exists in os.environ, return exactly the same value as os.environ
    environ_key = 'PATH'
    os_environ_value = os.environ[environ_key]
    if not PY3:
        os_environ_value = to_text(os_environ_value, encoding=environ.encoding,
                                   nonstring='passthru', errors='surrogate_or_strict')
    assert os_environ_value == environ[environ_key]

    # If a key does not exist in os.environ, raise a KeyError
    non_environ_key = 'THIS_KEY_DOES_NOT_EXIST_IN_OS_ENVIRON'

# Generated at 2022-06-11 18:26:45.121182
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that this returns the same values as os.environ on Python3 when using the default
    # encoding
    # Test that this returns the same values as os.environ on Python2 when the key exists
    # Test that this returns unicode when the key exists on Python2
    # Test that this raises a KeyError when the key does not exist
    pass


# Generated at 2022-06-11 18:26:47.960004
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = {b'test': b'value'}

    text_env = _TextEnviron(env=env)
    assert isinstance(text_env['test'], str)

# Generated at 2022-06-11 18:26:57.370005
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create mock environment
    _raw_environ = {'key': 'value', 'PATH': '/usr/bin:/bin:/usr/sbin:/sbin',
                    b'array_var': '/usr/bin:/bin:/usr/sbin:/sbin'}
    # Create instance of _TextEnviron
    env = _TextEnviron(env=_raw_environ)
    # Get value from environment
    env['key']
    # Check that the value is of type text
    assert isinstance(env['key'], str)
    # Get array of values from the environment
    env['array_var'].split(':')
    # Check that the environment value is of type text
    assert isinstance(env['key'], str)
    # Check that the environment value is a list

# Generated at 2022-06-11 18:27:06.181462
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Unit tests for method __getitem__ of class _TextEnviron

    # Test no encoding set
    environ_instance = _TextEnviron()

    # Test that we can get the same values out on PY3 that we put in.
    if PY3:
        # Test that we can get the same values out on PY3 that we put in.
        environ_instance = _TextEnviron()
        text_val = 'this is a text string'
        environ_instance['test'] = text_val
        assert environ_instance['test'] == text_val

    # Test setting values on one instance doesn't affect another instance
    environ_instance['test'] = text_val
    assert 'test' not in _TextEnviron()

    # Test non ASCII values
    utf8_val = '€'
    environ_

# Generated at 2022-06-11 18:27:08.634158
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    docstring for test__TextEnviron___getitem__
    '''
    pass

    # TODO: check return type

# Generated at 2022-06-11 18:27:15.636826
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a _TextEnviron object with a few entries in the environ
    # dictionary and a cache dictionary
    del environ['LC_ALL']
    del environ['LANG']
    environ['LC_ALL'] = 'C.UTF-8'
    environ['LANG'] = 'C.UTF-8'
    environ._value_cache['C.UTF-8'] = 'C'
    environ._value_cache['Foobar'] = 'Foobar'
    #
    # First test that the cache works
    assert environ._value_cache['C.UTF-8'] == 'C'
    #
    # Now test that the cache works when an environment variable is looked up
    assert environ['LC_ALL'] == 'C'
    #
    # Test that the cache is getting updated with new variables and that the

# Generated at 2022-06-11 18:27:23.209731
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.basic import AnsibleModule

    def test(environ_entry, expected, encoding='utf-8'):
        test_environ = _TextEnviron({'FOO': environ_entry}, encoding=encoding)
        assert test_environ['FOO'] == expected

    test('bar', 'bar', encoding='ascii')
    test('bar', 'bar', encoding='latin1')
    test('bar', 'bar', encoding='utf-8')

    if PY2:
        test(u'bar'.encode('utf-8'), u'bar')
        test(u'bar'.encode('latin1'), u'bar')
        test(u'bar'.encode('ascii'), u'bar')

# Generated at 2022-06-11 18:27:54.477916
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Check that _TextEnviron returns values as text instead of bytes
    """
    environ._value_cache.clear()
    env = _TextEnviron({'hello': 'world'})
    assert env['hello'] == u'world'
    assert env._value_cache['world'] == u'world'
    assert u'hello' in env
    assert u'world' in env._value_cache



# Generated at 2022-06-11 18:27:55.668196
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['TEST_VAR'] == u'foobar'


# Generated at 2022-06-11 18:28:00.323104
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    class Env(object):
        """
        An object that acts like a dictionary of byte strings.
        """
        def __init__(self, env=None):
            if env is None:
                env = {}
            self.env = env

        def __getitem__(self, key):
            return self.env[key]

    #
    # Test for valid input
    #
    # Pass a dictionary of strings keyed on strings
    #
    env = Env()
    env.env = {b'key1': b'The value of key1',
               b'key2': b'The value of key2'}
    text_env = _TextEnviron(env)
    assert('The value of key1' == text_env['key1'])

# Generated at 2022-06-11 18:28:09.522521
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({'name_1': 'value_1',
                        'name_2': 'value_2',
                        'name_3': 'value_3'})
    assert env['name_3'] == 'value_3'
    assert env['name_1'] == 'value_1'
    assert env['name_2'] == 'value_2'
    if not PY3:
        assert env._value_cache['value_2'] == 'value_2'
        assert env._value_cache['value_1'] == 'value_1'
        assert env._value_cache['value_3'] == 'value_3'



# Generated at 2022-06-11 18:28:19.931812
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_in = dict(
        ASCII_VALUE='value',
        ASCII_VALUE_WITH_NUMBERS='1234',
        ASCII_VALUE_WITH_NUMBERS_AND_LETTERS='123abc',
        UTF_VALUE=u'\u0020',
        UTF_VALUE_WITH_NUMBERS=u'H\u00ed1234',
        UTF_WITH_8_BIT_CHARS=b'\xc2\xa2',
        )
    text_environ = _TextEnviron(environ_in)
    # Test that it can read the ASCII values
    assert text_environ['ASCII_VALUE'] == environ_in['ASCII_VALUE']

# Generated at 2022-06-11 18:28:30.732816
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
    # instead of utf-8
    encoding = sys.getfilesystemencoding()
    # Test with a unicode value in the environment
    test_data = {
        b'test': '\xfe\xff\xfe'.encode(encoding),
    }
    # Create an instance of the class we want to test
    test_inst = _TextEnviron(test_data, encoding)
    # Test that the instance returns the value that we expect
    assert test_inst['test'] == u'\ufeff\ufeff'

    # Test with a byte value in the environment

# Generated at 2022-06-11 18:28:42.217527
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # verify that a simple string value is returned as text
    os.environ['FOO'] = 'bar'
    assert environ['FOO'] == 'bar'

    # verify that a unicode value is returned as text
    os.environ['FOO'] = '☃✔✘'
    assert environ['FOO'] == '☃✔✘'

    # verify that an encoded value is returned as text
    os.environ['FOO'] = '☃✔✘'.encode('utf-8')
    assert environ['FOO'] == '☃✔✘'

    # verify that a non-utf-8 encoded value is correctly handled
    os.environ['FOO'] = '☃✔✘'.encode('latin1')

# Generated at 2022-06-11 18:28:47.882167
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global environ
    os.environ['abc'] = 'abc'

    environ = _TextEnviron(encoding='utf-8')
    assert environ['abc'] == 'abc'

    os.environ['abc'] = b'\x80'
    assert environ['abc'] == u'\ufffd'



# Generated at 2022-06-11 18:28:55.746408
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:29:02.098838
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['TEST_TEXT'] = 'ascii'
    assert environ.get('TEST_TEXT') is not None
    assert isinstance(environ.get('TEST_TEXT'), str)

    os.environ['TEST_TEXT'] = b'\xe2\x98\x83'
    assert environ.get('TEST_TEXT') is not None
    assert isinstance(environ.get('TEST_TEXT'), str)

# Generated at 2022-06-11 18:30:01.859951
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(encoding='utf-8')
    assert 'PATH' in environ
    assert environ['PATH'] == 'c:\\windows\\system32'

# Generated at 2022-06-11 18:30:07.075873
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'key1': b'value1', b'key2': b'value2'}, encoding='latin-1')
    assert env['key1'] == u'value1'
    assert env['key2'] == u'value2'

# Generated at 2022-06-11 18:30:17.605466
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that bytes are returned as text
    environ = _TextEnviron({b'test': b'value'})
    assert environ[b'test'] == 'value'

    # Test that unicode is not supported if you provide unicde keys
    if PY3:
        import pytest
        pytest.skip("Unicode as keys is not supported on PY3")

    with pytest.raises(TypeError) as exc:
        environ[u'test']

    assert 'unicode object' in str(exc.value)

    del environ[b'test']
    try:
        environ[b'test']
        pytest.fail('Failed to raise KeyError when accessing a non-existent key')
    except KeyError:
        pass

    # Test that unicode is not supported if you provide unicde keys


# Generated at 2022-06-11 18:30:23.176906
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = _TextEnviron({'ANSIBLE_MODULE_ARGS': '{"key1": "value1", "key2":{"key2.1":"value2.1"}}'})
    assert test_environ['ANSIBLE_MODULE_ARGS'] == '{"key1": "value1", "key2":{"key2.1":"value2.1"}}'

# Generated at 2022-06-11 18:30:31.138401
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test case 1
    environ = _TextEnviron({
        'abc': 'abc123',
        b'def': 'def123',
        'ghi': 123,
        b'jkl': 456,
    })
    assert environ['abc'] == 'abc123'
    assert environ['def'] == 'def123'
    assert environ['ghi'] == '123'
    assert environ['jkl'] == '456'

    # Test case 2
    environ = _TextEnviron({
        'abc': 'abc123',
        b'def': 'def123',
        'ghi': 123,
        b'jkl': 456,
    }, encoding='ascii')
    assert environ['abc'] == 'abc123'
    assert environ['def'] == 'def123'
    assert en

# Generated at 2022-06-11 18:30:32.387137
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['1'] == u'2'



# Generated at 2022-06-11 18:30:37.462486
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(environ, MutableMapping)
    environ['a_key'] = 'a_value'
    assert environ['a_key'] == 'a_value'
    environ['a_key'] = u'a_value'
    assert environ['a_key'] == u'a_value'



# Generated at 2022-06-11 18:30:43.149187
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'KEY': b'value'}, encoding='utf-8')
    assert isinstance(env[b'KEY'], str), \
        "b'KEY' in env should return str, not {0}".format(type(env[b'KEY']))
    assert isinstance(env['KEY'], str), \
        "'KEY' in env should return str, not {0}".format(type(env['KEY']))
    assert isinstance(env[u'KEY'], str), \
        "u'KEY' in env should return str, not {0}".format(type(env[u'KEY']))


# Generated at 2022-06-11 18:30:52.538567
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # A mapping between input values, and their expected output values.
    test_inputs = {
        "simple_byte_string": b'test_simple_byte_string',
        "unicode_value": b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'.decode('utf-8'),
        "byte_string_without_encoding": 'test_simple_byte_string',
        "dict_input": {'key': 'value'},
        "num": 10,
        "None": None,
        "True": True,
        "False": False,
    }

    # A mapping between the expected output values and their expected types.

# Generated at 2022-06-11 18:30:55.083465
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''

    :return:
    '''
    a = _TextEnviron()
    b = a['PATH']
    print(b)