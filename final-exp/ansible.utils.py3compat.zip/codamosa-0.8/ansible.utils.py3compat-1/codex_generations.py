

# Generated at 2022-06-11 18:21:03.041411
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['LANG'] == 'en_US.UTF-8'
    assert isinstance(environ['LANG'], type(u''))
    assert type(environ['LANG']) == to_text(type(b''))
    if PY3:
        assert environ['LANG'] is os.environ['LANG']
    return True


# Generated at 2022-06-11 18:21:12.241283
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # set up
    env = {
        'bytekey': to_bytes('bytetext', encoding=environ.encoding),
        'textkey': to_text('texttext', encoding=environ.encoding),
        'unicodekey': to_text(u'unicodetext', encoding=environ.encoding)
    }
    testenv = _TextEnviron(env=env)
    # test
    try:
        assert testenv['bytekey'] == u'bytetext'
        assert testenv['textkey'] == u'texttext'
        assert testenv['unicodekey'] == u'unicodetext'
    except AssertionError:
        raise AssertionError('An AssertionError occurs by calling method test__TextEnviron___getitem__()')
    except Exception:
        raise Exception

# Generated at 2022-06-11 18:21:20.921974
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from types import EnvironmentError
    from ansible.module_utils.common._collections_compat import MutableMapping
    import os

    test_dict = {}
    test_dict['a'] = b'123'
    test_dict[b'b'] = b'456'
    test_dict['c'] = u'789\U0001f31f'

    test_dict_nonstr_key = {}
    test_dict_nonstr_key[u'a'] = b'123'
    test_dict_nonstr_key[1] = b'456'
    test_dict_nonstr_key[b'c'] = u'789\U0001f31f'

    test_dict_invalid_key = {}
    test_dict_invalid_key[u'a'] = b'123'
    test_dict

# Generated at 2022-06-11 18:21:32.251031
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import subprocess
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY2

    # If we're running on Python3, there's nothing to do
    if PY2:
        # Create a child shell that sets the environment variable to a non-ASCII value
        proc = subprocess.Popen(['bash', '-c', "export ANSIBLE_TEST='ñ'"], close_fds=True,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                stdin=subprocess.PIPE, env={'ANSIBLE_TEST': 'ascii'})
        # Wait for the subprocess to finish
        proc.wait()
        # Finally, check that the parent got the

# Generated at 2022-06-11 18:21:39.740036
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # pylint: disable=unused-variable
    def test_decode_surrogate_or_strict():
        os.environ['value'] = '\udcec\udceb'
        assert environ['value'] == '\udcec\udceb'
        os.environ['value'] = b'\xce\xeb\xce\xea'
        assert environ['value'] == '\udcec\udceb'

    def test_decode_surrogatereplace():
        os.environ['value'] = '\udcec\udceb'
        assert environ['value'] == '\udcec\udceb'
        os.environ['value'] = b'\xce\xeb\xce\xea'

# Generated at 2022-06-11 18:21:47.062984
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # The string to use in the test is the same one used by six
    test_string = b'\xff\xfeA\x00n\x00s\x00i\x00b\x00l\x00e\x00 \x00r\x00o\x00c\x00k\x00s\x00!'
    assert to_text(test_string, errors='strict', encoding='utf-16') == u'Ansible rocks!'

    # Test that a cached value is returned
    test_env = _TextEnviron()
    test_env[b'ANSIBLE_TEST'] = test_string
    # on Python3, the result is already a text object
    text_value = to_text(test_string, encoding='utf-16') if PY3 else u'Ansible rocks!'

# Generated at 2022-06-11 18:21:49.802305
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == '/usr/local/sbin:/usr/local/bin:/usr/bin:/usr/sbin:/sbin:/bin'

# Generated at 2022-06-11 18:21:58.084626
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # pylint: disable=protected-access
    # Prepare
    environ._raw_environ = {'one': 'one', 'two': 'two', 'three': 'three'}
    environ._value_cache = {}

    # Exercise
    value = environ['one']
    value1 = environ['one']
    value2 = environ['two']

    # Verify
    assert value == 'one'
    assert value1 == value
    assert value2 == 'two'
    assert len(environ._value_cache) == 2



# Generated at 2022-06-11 18:22:02.413661
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(env={b'ANSIBLE_TEST_VAR_ONE': b'ONE', b'ANSIBLE_TEST_VAR_TWO': b'TWO'})
    assert env['ANSIBLE_TEST_VAR_ONE'] == u'ONE'
    assert env['ANSIBLE_TEST_VAR_TWO'] == u'TWO'

# Generated at 2022-06-11 18:22:10.022472
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['TESTKEY'] = 'value1'
    environ['TEST_KEY_2'] = 'value2'
    assert environ['TESTKEY'] == 'value1'
    assert environ['TEST_KEY_2'] == 'value2'
    assert environ[b'TESTKEY'] == 'value1'
    assert environ[b'TEST_KEY_2'] == 'value2'


# Generated at 2022-06-11 18:22:15.752096
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # python2 set the encoding to utf-8 by default; this is not true for python3
    sys.getfilesystemencoding = lambda: 'utf-8'
    environ_tmp = {'foo': 'bar'}
    os.environ = environ_tmp
    assert _TextEnviron()['foo'] == 'bar'


# Generated at 2022-06-11 18:22:25.107056
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        return

    # Test TextEnviron with default encoding of utf-8
    os.environ["PYTHONIOENCODING"] = "ANSI_X3.4-1968"
    environ = _TextEnviron(env=None, encoding='utf-8')
    assert isinstance(environ["PYTHONIOENCODING"], str), "os.environ value should be str"

    # Test TextEnviron with encoding of ascii
    environ = _TextEnviron(env=None, encoding='ascii')
    assert isinstance(environ["PYTHONIOENCODING"], str), "os.environ value should be str"

# Generated at 2022-06-11 18:22:33.488961
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == '/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games'
    assert environ['PYTHONIOENCODING'] == 'UTF-8'

    if PY3:
        # os.environ already returns text strings so don't need to reencode
        assert environ['PYTHONIOENCODING'] == 'utf-8'
    else:
        os.environ['PYTHONIOENCODING'] = u'utf-8'
        assert environ['PYTHONIOENCODING'] == u'utf-8'

    assert environ[u'PYTHONIOENCODING'] == u'utf-8'



# Generated at 2022-06-11 18:22:40.798879
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(env={'a': 'A', 'b': b'B'}, encoding='utf-8')

    # Test decoding of environment variable
    assert isinstance(env['a'], str)
    assert env['a'] == 'A'

    # Test that byte strings that are already decoded are passed through
    assert isinstance(env['b'], str)
    assert env['b'] == 'B'

    # Test that missing keys raise KeyError
    try:
        env['c']
        assert False, 'Should have raised a KeyError'
    except KeyError:
        pass

    # Test that the cache works
    env._value_cache['B'] = 'C'
    assert env['b'] == 'C'



# Generated at 2022-06-11 18:22:50.655158
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    _os_environ = {b'KEY1': b'VAL1',
                   b'KEY2': b'VAL2',
                   'KEY3': b'VAL3',
                   'KEY4': 'VAL4'}
    environ = _TextEnviron(_os_environ)
    # KEY1 is a byte string.  It is added to the cache without decoding and returned from the cache
    # without decoding
    assert environ.get(b'KEY1') == environ.get('KEY1') == 'VAL1'
    # KEY2 is a unicode string.  It is added to the cache without decoding and returned from the
    # cache without decoding
    assert environ.get('KEY2') == 'VAL2'
    # KEY3 is a byte string.  It is added to the cache as a unicode string and returned from the
    # cache

# Generated at 2022-06-11 18:23:02.074753
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test when mimicking Python3
    os.environ['Text'] = 'text'
    test_text_environ = _TextEnviron(env=os.environ)
    assert test_text_environ['Text'] == 'text'
    del os.environ['Text']

    # Test when encoding
    os.environ['u'] = 'ü'
    os.environ['b'] = b'surrogate\\udc8e'
    os.environ['bad'] = b'surrogate\\udc8e'
    assert test_text_environ['u'] == 'ü'
    assert test_text_environ['b'] == 'surrogate�'
    assert test_text_environ['bad'] == b'surrogate\\udc8e'
    del os.environ['u']


# Generated at 2022-06-11 18:23:09.727838
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Instanciate a _TextEnviron Object with encoding utf-8
    text_environ = _TextEnviron(encoding='utf-8')

    os.environ['A'] = 'B'  # Create variable A in os.environ

    # Check if A variable is returned in bytes on Python 2
    assert type(os.environ['A']) == bytes

    # Check if A variable is returned in str on Python 3
    assert type(environ['A']) == str

# Generated at 2022-06-11 18:23:16.062532
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    t = _TextEnviron(env={}, encoding='utf-8')
    t['1'] = '1'
    assert t['1'] == '1'
    t['2'] = u'2'
    assert t['2'] == '2'
    t['3'] = b'3'
    assert t['3'] == '3'
    t['4'] = b'\xe2\x84\xa2'
    assert t['4'] == u'™'
    t['5'] = '\xe2\x84\xa2'
    assert t['5'] == u'™'


# Generated at 2022-06-11 18:23:18.767133
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_env = _TextEnviron(env={"a": "b"}, encoding='utf-8')
    assert test_env["a"] == u"b"

# Generated at 2022-06-11 18:23:20.810739
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == u'/Users/frantisek.kocun'

# Generated at 2022-06-11 18:23:27.446969
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_text
    
    with pytest.raises(KeyError) as e:
        # For example:
        # environ['VAR']
        environ['VAR']
    # Test __getitem__ of class _TextEnviron
    # KeyError: 'VAR'
    assert e.value.args == ('VAR',)

# Generated at 2022-06-11 18:23:36.357626
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import doctest
    import os
    import tempfile


# Generated at 2022-06-11 18:23:45.110187
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # We can still use the usual environ when creating the instance
    env = _TextEnviron()

    # Ensure that it returns text on Python3
    if PY3:
        assert isinstance(env[to_text('HOME')], text_type)

    text_key = to_text('LANG')
    text_value = to_text('C.UTF-8')
    # We know this is a string in Python3
    # pylint: disable=undefined-variable
    if PY3:
        env[text_key] = text_value
        # We can retrieve the value using a text type key
        assert env[text_key] == text_value
        # We can retrieve the value using a bytes type key
        assert env[to_bytes(text_key)] == text_value

        # In Python3, we can still

# Generated at 2022-06-11 18:23:50.720925
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that non-string type key fails on both Python2 and Python3
    try:
        environ.__getitem__(object())
    except TypeError:
        pass
    else:
        assert False, "Unexpectedly succeeded to get key of non-string type"

    # Test that utf-8 strings are returned as text on both Python2 and Python3
    value = u'\u2618'
    environ['test1'] = value
    assert environ.__getitem__('test1') == value

    # Test that non-utf-8 strings are also returned as text on both Python2 and Python3
    value = b'\xa5'
    environ['test2'] = value
    assert environ.__getitem__('test2') == value, "Unexpectedly failed to get key of non-utf-8 type"

# Generated at 2022-06-11 18:23:57.246533
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for __getitem__ under Python3
    env = _TextEnviron(env={'PYTHON_VERSION': '3.6.6'}, encoding='utf-8')
    assert env['PYTHON_VERSION'] == u'3.6.6'

    # Test for __getitem__ under Python2
    if not PY3:
        env = _TextEnviron(env={'PYTHON_VERSION': '2.7.13'}, encoding='utf-8')
        assert env['PYTHON_VERSION'] == u'2.7.13'

    # Test that an attempt to decode bytes which are not valid UTF-8 results in the undecoded
    # string being returned

# Generated at 2022-06-11 18:24:05.445734
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['LANG'] = u'ascii'
    assert environ['LANG'] == u'ascii'
    environ['LANG'] = u'utf-8'
    assert environ['LANG'] == u'utf-8'

    environ['LANG'] = b'ascii'
    assert environ['LANG'] == u'ascii'
    environ['LANG'] = b'utf-8'
    assert environ['LANG'] == u'utf-8'

    environ['LANG'] = 'ascii'
    assert environ['LANG'] == 'ascii'
    environ['LANG'] = 'utf-8'
    assert environ['LANG'] == 'utf-8'



# Generated at 2022-06-11 18:24:10.073886
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'NONASCII': b'\xc2\xae \xc2\xb5'}, encoding='utf-8')
    assert isinstance(environ['NONASCII'], str)
    assert environ['NONASCII'] == u'\u00ae \u00b5'


# Generated at 2022-06-11 18:24:11.693483
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['abc'] = 'abc'
    assert environ['abc'] == 'abc'

# Generated at 2022-06-11 18:24:22.410802
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # UnicodeEncodeError: 'ascii' codec can't encode character '\xc2' in position 13: ordinal not in range(128)
    # https://stackoverflow.com/questions/14693701/how-can-i-remove-the-ansi-escape-sequences-from-a-string-in-python

    import re
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')

    # should be a unicode
    # https://github.com/zgrab/ansible/blob/master/lib/ansible/module_utils/six.py#L28
    import sys

# Generated at 2022-06-11 18:24:31.488384
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create UTF-8 encoded byte string we'll use for testing
    utf8_byte_string = b"\xec\x8b\xac\xec\x9d\xbc\0\0"
    # Create the class to test, using the test variable for the OS environment
    test_environ = _TextEnviron(env={"test": utf8_byte_string}, encoding='utf-8')
    # With Python 2, the strings should be decoded to unicode and have a prefix of u
    assert u"심일\x00\x00" == test_environ['test']
    # The same with Python 3.  No prefix since it's now the default
    assert "심일\x00\x00" == test_environ['test']

# Generated at 2022-06-11 18:24:40.974966
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['K1'] = 'V1'
    environ['K2'] = u'K2-V2'

    assert environ['K1'] == u'V1'
    assert environ['K2'] == u'K2-V2'

# Generated at 2022-06-11 18:24:48.356404
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    bool(environ)  # Need this to be created in the global namespace
    environ.clear()
    environ['LANG'] = 'UTF-8'
    assert environ['LANG'] == 'UTF-8'
    environ['FOO'] = b'bar'
    assert environ['FOO'] == u'bar'
    environ['BAR'] = b'bar\xff'
    try:
        environ['BAR']
    except UnicodeDecodeError:
        pass
    else:
        assert False, "Should have raised UnicodeDecodeError"

# Generated at 2022-06-11 18:24:54.419542
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Arrange
    # Act
    new_environ = _TextEnviron(encoding='utf-8')
    new_environ["myvar"] = "myval"

    # Assert
    assert new_environ["myvar"] == "myval"

test__TextEnviron___getitem__()

# Generated at 2022-06-11 18:24:57.372916
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """
#    assert result == expected, 'Expected different value'
    assert True

# Generated at 2022-06-11 18:25:04.612200
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    def _test(text, encoding='utf-8'):
        import copy
        os_environ = copy.deepcopy(dict(os.environ))
        os_environ['TEST_KEY'] = text
        env = _TextEnviron(env=os_environ, encoding=encoding)
        return env['TEST_KEY']

    assert _test(text=u'abc') == u'abc'
    assert _test(text=b'abc') == u'abc'
    assert _test(text=u'\u1234') == u'\u1234'
    assert _test(text=b'\xe1\x88\xb4') == u'\u1234'

# Generated at 2022-06-11 18:25:14.243832
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    # Test UTF-8 encoding
    environ['LANG'] = 'fr_FR.UTF-8'
    assert environ['LANG'] == u'fr_FR.UTF-8'
    # Test when there's already a unicode
    environ['LANG'] = u'fr_FR.UTF-8'
    assert environ['LANG'] == u'fr_FR.UTF-8'
    # Test ISO-8859-1 encoding
    environ['LANG'] = u'es_MX.ISO-8859-1'
    assert environ['LANG'] == u'es_MX.ISO-8859-1'

# Generated at 2022-06-11 18:25:15.524078
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['test'] = 'test'
    assert environ['test'] == 'test'

# Generated at 2022-06-11 18:25:24.680386
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['ANSIBLE_TEST_KEY1'] = u'value1'
    os.environ['ANSIBLE_TEST_KEY2'] = b'value2'
    os.environ[b'ANSIBLE_TEST_KEY3'] = u'value3'
    os.environ[b'ANSIBLE_TEST_KEY4'] = b'value4'

    assert environ['ANSIBLE_TEST_KEY1'] == u'value1'
    assert environ['ANSIBLE_TEST_KEY2'] == u'value2'
    assert environ['ANSIBLE_TEST_KEY3'] == u'value3'
    assert environ['ANSIBLE_TEST_KEY4'] == u'value4'

    del os.environ['ANSIBLE_TEST_KEY1']
    del os.environ

# Generated at 2022-06-11 18:25:31.239498
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__(): # noqa: E302
    e = _TextEnviron()
    if os.name == 'posix':
        assert e['SHELL'] == '/bin/bash'
    elif os.name == 'nt':
        assert e['SystemRoot'] == r'C:\Windows'
    else:
        raise AssertionError(u'Unknown OS: {0}'.format(os.name))



# Generated at 2022-06-11 18:25:39.305758
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # GIVEN an environ dictionary with a combination of text and binary values
    os.environ['var1'] = 'value1'
    os.environ['var2'] = b'value2'
    os.environ['var3'] = b'value3\xe9'
    # WHEN getting a value
    result1 = environ['var1']
    result2 = environ['var2']
    result3 = environ['var3']
    # THEN the values retrieved are text values
    assert isinstance(result1, text_type)
    assert isinstance(result2, text_type)
    assert isinstance(result3, text_type)
    # AND the text values are the same as the input
    assert result1 == 'value1'
    assert result2 == u'value2'

# Generated at 2022-06-11 18:26:01.581240
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Tests decoding of surrogate escaped values
    environ[u'__TEST_UNICODE'] = u'abc\udcba\udcba'
    assert environ[u'__TEST_UNICODE'] == u'abc\U00010348'

    # Tests decoding of an undecoded unicode character
    environ[u'__TEST_UNICODE'] = u'abc\uabcd\uabcd'
    assert environ[u'__TEST_UNICODE'] == u'abc\ufffddcba'

    # Tests decoding of a binary value with an invalid utf-8 character
    environ[b'__TEST_UNICODE'] = b'abc\xff'
    assert environ[b'__TEST_UNICODE'] == u'abc\ufffd'

    # Tests decoding of

# Generated at 2022-06-11 18:26:07.353894
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:26:16.499980
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Save original environment variables for restoring
    tmp_env = os.environ.copy()
    # Create an instance of _TextEnviron
    textenv = _TextEnviron()
    # Test the original environment variables
    assert os.environ['PATH'] == textenv['PATH']
    # Add a new environment variable to original environment
    os.environ['TEST_UNICODE'] = u'über'
    # Test the new environment variable
    assert os.environ['TEST_UNICODE'] == textenv['TEST_UNICODE']
    # Test the other environment variable again
    assert os.environ['PATH'] == textenv['PATH']
    # Restore original environment variables
    os.environ = tmp_env


# Generated at 2022-06-11 18:26:19.059658
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'test': b'\x80test'})
    assert env['test'] == u'\uFFFDtest'

# Generated at 2022-06-11 18:26:28.254076
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['ANSIBLE_TEST_KEY'] = 'test'
    assert environ['ANSIBLE_TEST_KEY'] == 'test'
    assert environ['ANSIBLE_TEST_KEY'] == b'test'  # Make sure we're not doing a pass through
    environ['ANSIBLE_TEST_KEY'] = ''
    assert environ['ANSIBLE_TEST_KEY'] == ''
    environ['ANSIBLE_TEST_KEY'] = u"¿hərˈnarə"
    assert environ['ANSIBLE_TEST_KEY'] == u"¿hərˈnarə"
    assert environ['ANSIBLE_TEST_KEY'] == b'\xc2\xbfh\xc9\x99r\xc2\xb7nar\xc9\x99'
    #


# Generated at 2022-06-11 18:26:38.866735
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import pytest
    with open('/proc/sys/kernel/random/uuid', 'rb') as fd:
        uuid_bytes = fd.read()[:-1]
    mocked_environ = _TextEnviron({b'uuid': uuid_bytes})
    uuid_text = mocked_environ['uuid']
    assert isinstance(uuid_text, str)
    assert uuid_text == uuid_bytes.decode('utf-8')
    with open('/proc/sys/kernel/random/uuid', 'rb') as fd:
        uuid_bytes = fd.read()[:-1]
    mocked_environ = _TextEnviron({'uuid': uuid_bytes.decode('utf-8')})
    uuid_text = mocked_environ['uuid']


# Generated at 2022-06-11 18:26:42.234266
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['__ANSIBLE_TEST_ENCODING__'] == 'utf-8'
    assert type(environ['__ANSIBLE_TEST_ENCODING__']) == str

# Generated at 2022-06-11 18:26:53.274782
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    old_env = environ._raw_environ
    environ._raw_environ = {
        b'a': b'str',
        b'b': u'str',
        b'c': b'\xd0\xbc\xd0\xbe',
        b'd': u'\u043c\u043e',
        b'e': b'\xe2\x98\x83',
    }
    environ._value_cache = {}
    environ.encoding = 'utf-8'

    assert environ[b'a'] == u'str'
    assert environ[b'b'] == u'str'
    assert environ[b'c'] == u'\u043c\u043e'
    assert environ[b'd'] == u'\u043c\u043e'
   

# Generated at 2022-06-11 18:26:57.556208
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['ПРИВЕТ'] = 'Hello'  # cyrillic capital letter 'П'
    assert environ['ПРИВЕТ'] == 'Hello'
    del os.environ['ПРИВЕТ']

# Generated at 2022-06-11 18:27:00.477920
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({to_bytes('key', 'utf-8'): to_bytes('value', 'utf-8')}, 'utf-8')
    assert env['key'] == 'value'
    assert env[to_text('key', 'utf-8')] == 'value'

# Generated at 2022-06-11 18:27:31.720493
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # pylint: disable=trailing-whitespace
    # pylint: disable=line-too-long
    assert environ['test'] == os.environ['test']
    os.environ['test'] = to_bytes('test')
    assert environ['test'] == to_text('test')
    os.environ['test'] = to_bytes('tést')
    assert environ['test'] == to_text('tést')
    # pylint: enable=line-too-long
    # pylint: enable=trailing-whitespace

# Generated at 2022-06-11 18:27:35.038557
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(environ['HOME'], str)
    assert isinstance(environ['HOME'], str)
    assert environ['HOME'].encode('utf-8') == os.environ['HOME']

test__TextEnviron___getitem__()


# Generated at 2022-06-11 18:27:45.160796
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    import tempfile

    # a few tests to cover unicode
    test_unicode_envvars = {
        u'Юнікод_тест': u'Привіт світ'
    }

    for name, value in test_unicode_envvars.items():
        with tempfile.NamedTemporaryFile() as f:
            with open(f.name, 'wb') as out:
                # write the shell code to a file
                out.write(b'#!/usr/bin/env python\n')
                out.write(b'import os\n')
                out.write(b'from ansible.module_utils.six import PY3\n')

# Generated at 2022-06-11 18:27:48.120107
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
  key = 'TEST_KEY'
  value = 'TEST_VALUE'
  environ.clear()
  environ[key] = value
  assert(environ[key] == value)


# Generated at 2022-06-11 18:27:57.195509
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with good values
    os.environ['good_ascii'] = 'good_ascii'
    os.environ['good_utf8'] = 'ęąśżźćńół'
    os.environ['good_latin1'] = 'õüäöÜÕÄÖ'
    # Test with bad values
    os.environ['bad_utf8_as_latin1'] = 'ęąśżźćńół'.encode('latin1')
    os.environ['bad_latin1_as_utf8'] = 'õüäöÜÕÄÖ'.encode('utf8')

# Generated at 2022-06-11 18:28:08.413885
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(encoding='utf-8')
    # Test with utf-8 encoded values first round:
    env[b'key1'] = b'\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82'  # "Привет" in utf-8
    env[b'key2'] = b'\xf0\x90\x8c\x80'  # Unicode 4 byte code point in utf-8
    env[b'key3'] = b'\xf1\x80\x80\x80'  # Unicode 4 byte code point in utf-8
    env[b'key4'] = b'\xf4\x8f\xbf\xbf'  # Unicode 4

# Generated at 2022-06-11 18:28:19.511689
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Case-1: Python2/Linux
    if sys.version_info[0] < 3 and sys.platform.startswith('linux'):
        assert environ['LANG'] == u'en_US.UTF-8'
        assert environ['PATH'] == u'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games'

    # Case-2: Python3
    elif sys.version_info[0] == 3:
        assert environ['LANG'] == 'en_US.UTF-8'
        assert environ['PATH'] == '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games'

    # Case-3

# Generated at 2022-06-11 18:28:29.176236
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    inc_unicode = '\xe5\x85\xac\xe6\x96\xb9\xe5\xba\xa6'
    inc_utf8 = b'\xe5\x85\xac\xe6\x96\xb9\xe5\xba\xa6'

    os.environ.clear()

    os.environ[inc_utf8] = b'work'

    assert environ[inc_utf8] == 'work'
    assert environ[inc_unicode] == 'work'

    os.environ[inc_utf8] = b'\xe5\x8d\x81\xe4\xba\x8c'
    assert environ[inc_utf8] == '十二'

# Generated at 2022-06-11 18:28:40.475177
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

    module = AnsibleModule(
        argument_spec=dict(),
    )

    # Set the environment with a UTF-8 encoded string which utf-8 decodes to a multi-byte
    # UTF-8 character as well as a unicode character
    test_environ_string = u'{0}={1}'.format(to_text(b'testkey'), to_text(b'\xF1\xA0\xA0\xA0\u26AF',
                                                                        encoding=u'utf-8'))
    test_environ = os.environ.copy()

# Generated at 2022-06-11 18:28:47.827327
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env_cache = environ._value_cache
    try:
        assert env_cache == {}
        environ['a'] = 'b'
        assert environ['a'] == 'b'
        assert env_cache == {'b': u'b'}

        environ['a'] = 'c'
        assert env_cache == {'b': u'b', 'c': u'c'}
        assert environ['a'] == 'c'

        environ['a'] = 'b'
        assert env_cache == {'c': u'c'}
        assert environ['a'] == 'b'

        del environ['a']
        assert env_cache == {'c': u'c'}
        assert 'a' not in environ._raw_environ
    finally:
        environ.clear()

# Generated at 2022-06-11 18:29:51.814990
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # 1. Return text string from _value_cache
    # Arrange
    value = 'test'
    environ._value_cache[value] = 'text'

    # Act
    text = environ[value]

    # Assert
    assert text == 'text'
    assert text == environ._value_cache[value]

    # 2. Return text string from raw_environ
    # Arrange
    value = 'test'
    environ._value_cache.clear()
    environ._raw_environ[value] = 'text'

    # Act
    text = environ[value]

    # Assert
    assert text == 'text'
    assert text == environ._value_cache[value]

    # 3. Return str() on Py3
    # Arrange
    value = 'test'
    environ._

# Generated at 2022-06-11 18:29:56.513504
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # setup
    environ = _TextEnviron({b'raw_key': b'raw_value'}, encoding='utf-8')

    # expected
    expected = u'raw_value'

    # execute
    actual = environ['raw_key']

    # assert
    assert expected == actual

# Generated at 2022-06-11 18:30:04.791197
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test non-unicode strings
    os_environ = _TextEnviron(env={'foo': 'bar'})
    assert os_environ['foo'] == 'bar'

    # Test unicode strings
    # This will be a byte string on Python2 and a unicode string on Python3.
    # Both of these are valid inputs.
    if PY3:
        os_environ = _TextEnviron(env={'foo': '✓'})
        assert os_environ['foo'] == '✓'
    else:
        os_environ = _TextEnviron(env={'foo': b'\xe2\x9c\x93'})
        assert os_environ['foo'] == '✓'


# Generated at 2022-06-11 18:30:06.926195
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'a': b'a_value'})
    assert environ[b'a'] == u'a_value'



# Generated at 2022-06-11 18:30:11.126589
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(encoding='utf-8')
    test_environ = {'foo': 'bar'}
    assert env._raw_environ == os.environ
    assert env._value_cache == {}
    env._raw_environ = test_environ
    env._value_cache = {}
    assert env['foo'] == 'bar'
    assert env._raw_environ == test_environ
    assert env._value_cache == {'bar': 'bar'}


# Generated at 2022-06-11 18:30:19.973280
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env_dict = {}

    os.environ = env_dict

    env_dict[b'PYTHONIOENCODING'] = b'utf-8'

    env_dict[b'UTF'] = b'\xed\xa0\xbd\xed\xb0\x8d\xed\xa0\xbd\xed\xb0\x8d\xed\xa0\xbd\xed\xb0\x8d'

    env_dict[b'SURROGATE'] = b'surrogate_or_strict: \xed\xa0\x80'

    env_dict['ENCODING_ERROR'] = 'encoding_error: \xa2'

    environ = _TextEnviron(env=env_dict)

    # test: PYTHONIOENCODING env

# Generated at 2022-06-11 18:30:29.679977
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This test depends on the user's locale.  Run with C locale.
    os.environ['LANG'] = 'C'
    # Make sure that when we're running in Python2, we're still getting text strings out
    os.environ['ANSIBLE_TESTKEY'] = 'plain unicode string'
    assert isinstance(environ['ANSIBLE_TESTKEY'], str)
    del os.environ['ANSIBLE_TESTKEY']

    # Test that we get text when we pass in text to __setitem__
    os.environ['ANSIBLE_TESTKEY'] = u'plain unicode string'
    assert isinstance(environ['ANSIBLE_TESTKEY'], str)
    del os.environ['ANSIBLE_TESTKEY']

    # Test that we get text when we pass in bytes to __setitem__

# Generated at 2022-06-11 18:30:37.102774
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # create a dummy environment
    _os_environ = environ._raw_environ
    environ._raw_environ = {b'ANSIBLE_TEST1': b'foo', b'ANSIBLE_TEST2': b'bar'}
    # assert that keys are returned as strings (not bytes)
    assert isinstance(environ['ANSIBLE_TEST1'], str)
    assert isinstance(environ['ANSIBLE_TEST2'], str)
    # clean up the environment
    environ._raw_environ = _os_environ

# Generated at 2022-06-11 18:30:40.519246
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class DummyEnviron(dict):
        """
        A dummy class to store byte strings
        """
        def __getitem__(self, key):
            return b'\xc3\xa9'

    testing = _TextEnviron(env=DummyEnviron())
    assert testing['foo'] == u'é'

# Generated at 2022-06-11 18:30:50.915434
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from six import assertCountEqual
    from tempfile import TemporaryDirectory
    # set environment variable to a str
    with TemporaryDirectory() as tmpdir:
        environ['TEST_VAR'] = tmpdir
        encoded = tmpdir.encode('utf-8')
        if PY3:
            assert environ['TEST_VAR'] == tmpdir
        else:
            assert isinstance(environ['TEST_VAR'], str)
            assert environ['TEST_VAR'].encode('utf-8') == encoded
    # set environment variable to a bytes
    with TemporaryDirectory() as tmpdir:
        environ['TEST_VAR'] = to_bytes(tmpdir)
        encoded = tmpdir.encode('utf-8')