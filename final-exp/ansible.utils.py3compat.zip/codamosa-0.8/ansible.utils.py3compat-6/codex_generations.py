

# Generated at 2022-06-11 18:21:10.965688
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # should return correct text string value
    environ['ANSIBLE_TEST_UTF8'] = 'Hello World'
    assert environ['ANSIBLE_TEST_UTF8'] == u'Hello World'

    # should return correct binary value
    environ['ANSIBLE_TEST_BIN'] = to_bytes('Hello World')
    assert environ['ANSIBLE_TEST_BIN'] == u'Hello World'

    # should decode binary value
    environ['ANSIBLE_TEST_DECODE'] = 'Hello World'.encode('utf-8')
    assert environ['ANSIBLE_TEST_DECODE'] == u'Hello World'

    # should encode binary value
    environ['ANSIBLE_TEST_ENCODE'] = to_bytes('Hello World')
    assert environ['ANSIBLE_TEST_ENCODE'] == u

# Generated at 2022-06-11 18:21:16.961761
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    key = 'ANSIBLE_TEST_ENV'
    value = '1234567890'

    _TextEnviron.__setitem__(environ, key, value)

    assert _TextEnviron.__getitem__(environ, key) == value
    assert _TextEnviron.__getitem__(environ, key) != None
    assert _TextEnviron.__getitem__(environ, key) != False


# Generated at 2022-06-11 18:21:28.955226
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Create a test environment
    old_env = dict(os.environ)
    os.environ['encoding'] = 'utf-8'
    os.environ['invalid_utf_8'] = b'\x80'
    os.environ['unicode'] = '\u00e9'
    os.environ['chinese'] = '\u4e16\u754c'.encode('utf-8')
    environ = _TextEnviron()

    # Expected output
    assert environ == {'encoding': 'utf-8', 'invalid_utf_8': b'\x80', 'unicode': '\u00e9', 'chinese': '\u4e16\u754c'}
    assert environ['encoding'] == 'utf-8'

# Generated at 2022-06-11 18:21:34.093560
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    env = _TextEnviron()
    env._raw_environ = {'key1': b'value1', 'key2': b'value2'}
    # Expected result
    result = dict()
    result['key1'] = 'value1'
    result['key2'] = 'value2'

    # Actual result:
    actual = env['key1']
    actual = env['key2']

    # Assertion
    assert actual == result

# Generated at 2022-06-11 18:21:45.145178
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest
    from ansible.module_utils import _text_environ
    from ansible.module_utils._text import to_bytes, to_text

    class _TextEnvironGetItemTests(unittest.TestCase):
        """Test module class _TextEnviron"""

        def setUp(self):
            """Execute before each test method"""
            self.environ = _text_environ._TextEnviron()

        def test__TextEnviron___getitem__nonascii_py2(self):
            """Test _TextEnviron.__getitem__ non-ascii, python 2"""
            self.environ._raw_environ = {'TEST': to_bytes('δοκιμαστικό δοκιμαστικό')}
           

# Generated at 2022-06-11 18:21:53.604853
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    tmp = _TextEnviron()

    tmp._raw_environ['LANG'] = b'en_US.UTF-8'
    assert tmp['LANG'] == u'en_US.UTF-8'
    assert tmp._value_cache[b'en_US.UTF-8'] == u'en_US.UTF-8'

    tmp._raw_environ['BINARY'] = b'\x80'
    assert tmp['BINARY'] == u'\uFFFD'
    assert tmp._value_cache[b'\x80'] == u'\uFFFD'

    tmp._raw_environ['NONSTR'] = dict()
    try:
        tmp['NONSTR']
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-11 18:22:03.446784
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    real_env = os.environ
    real_getfilesystemencoding = sys.getfilesystemencoding

    os.environ.clear()
    os.environ['normal_key'] = u"normal_value"
    os.environ['utf_key'] = u"éxample"
    os.environ['latin_key'] = u"café"
    os.environ['mix_key'] = u"café éxample"
    os.environ['invalid_key'] = b"\xff\xff"

    os.environ = _TextEnviron(encoding='ascii')
    for key in os.environ:
        try:
            assert False
        except AssertionError:
            assert key == u'normal_key'


# Generated at 2022-06-11 18:22:11.146860
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    # get an existing value from the environment which is not utf-8
    assert env['CHARSET'] == 'ANSI_X3.4-1968'
    # get a non-existing value from the environment
    try:
        not_there = env['NOT_THERE']
        raise Exception('Should have raised a KeyError when accessing not_there')
    except KeyError:
        pass

# Generated at 2022-06-11 18:22:16.203694
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ._raw_environ = {b'key': 'value'}
    assert environ['key'] == 'value'

    environ._raw_environ = {'key': 'value'}
    assert environ['key'] == 'value'

    environ._raw_environ = {b'key': 'value'}
    assert environ._value_cache[b'value'] == 'value'

# Generated at 2022-06-11 18:22:23.521001
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Unit tests for _TextEnviron.__getitem__()

    # This module doesn't have many asserts because it's almost all tested in
    # module_utils.six. Our unit tests here are more like integration tests
    # that make sure that the module_utils.six tests are still passing on
    # python2

    import mock
    from ansible.module_utils.six._six import text_type

    # pylint: disable=unused-variable

    def _test_getitem_with_decoding(encoding, mock_sys_getfilesystemencoding=None,
                                    mock_to_text=None):

        environ = _TextEnviron(encoding=encoding)

        enc_sys_getfilesystemencoding = to_bytes('ascii')

# Generated at 2022-06-11 18:22:34.113686
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test if a byte string is returned when it is input
    environ = _TextEnviron()
    environ["test"] = b"hello"
    assert isinstance(environ["test"], to_text(b"hello", encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict'))
    # test if a text string is returned when it is input
    environ = _TextEnviron()
    environ["test"] = to_text(b"hello", encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict')
    assert isinstance(environ["test"], to_text(b"hello", encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict'))
    # test if an exception is raised when non-

# Generated at 2022-06-11 18:22:41.415566
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Create a fake environment to work in
    fake_environ = {b'key1': 'value1', b'key2': b'value2', b'key3': u'value3', b'key4': 'value4'}

    # Check that it works with a real dictionary
    real_environ = _TextEnviron(fake_environ, encoding='utf-8')
    assert real_environ[b'key1'] == 'value1'
    assert real_environ[b'key2'] == 'value2'
    assert real_environ[b'key3'] == u'value3'
    assert real_environ[b'key4'] == 'value4'

    # Check that it works with an environment variable that changes over time

# Generated at 2022-06-11 18:22:46.374363
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'a': b'b', u'\u043c\u0430': u'\u0440\u044b'})
    assert env[b'a'] == u'b'
    assert env[u'\u043c\u0430'] == u'\u0440\u044b'

# Generated at 2022-06-11 18:22:48.582711
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron()
    result = e['PATH']
    assert isinstance(result, str)



# Generated at 2022-06-11 18:23:00.337820
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    It should return values as text strings
    """
    environ._value_cache = {}
    assert isinstance(environ['python_version'], str)

    # It should not recode values when the value is already a text string
    py2_version = sys.version_info[0]
    py2_version = str(py2_version)
    environ._raw_environ['python_version'] = py2_version
    assert isinstance(environ['python_version'], str)

    # It should recode values if they are bytes
    environ._raw_environ['python_version'] = bytes(py2_version)
    assert isinstance(environ['python_version'], str)

    # It should recode values using sys.getfilesystemencoding()

# Generated at 2022-06-11 18:23:04.670972
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # arrange
    env = _TextEnviron()

    # act
    env['LANG'] = 'en'
    result_1 = env['LANG']
    result_2 = env['LANG']

    # assert
    assert result_1 == 'en'
    assert result_1 is result_2

# Generated at 2022-06-11 18:23:15.170193
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # pylint: disable=redefined-outer-name, missing-docstring
    def test_env_without_unicode_chars(encoding, environ):
        # pylint: disable=missing-docstring
        test_env = os.environ.copy()
        test_env['TEST_VAR'] = 'test var'
        te = _TextEnviron(test_env, encoding=encoding)
        assert te['TEST_VAR'] == 'test var'

    def test_env_with_unicode_chars(encoding, environ):
        # pylint: disable=missing-docstring
        unicode_char = u'\u06ae'
        test_env = os.environ.copy()

# Generated at 2022-06-11 18:23:26.026033
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Unit test for method __getitem__ of class _TextEnviron"""

    # test_e = _TextEnviron({b'foo': b'\x59\xdd\x53\xb9'})
    #assert test_e['foo'] == u'\u4e4b\u4eba'

    test_e = _TextEnviron({b'foo': b'\x00'})
    assert test_e['foo'] == u'\u0000'

    test_e = _TextEnviron({b'foo': b'\x61'})
    assert test_e['foo'] == u'a'

    #
    # The next two tests would fail on python3
    #

    test_e = _TextEnviron({b'foo': b'\xff'})

# Generated at 2022-06-11 18:23:35.128666
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print ('TEST METHOD __getitem__')
    import os
    import codecs
    os.environ["ANSIBLE_TEST_UTF8_VALUE"] = u"\u00e9"
    os.environ["ANSIBLE_TEST_LATIN1_VALUE"] = codecs.latin_1_encode(u"\u00e9")[0]
    print ("ANSIBLE_TEST_UTF8_VALUE returns: " + environ['ANSIBLE_TEST_UTF8_VALUE'])
    print ("ANSIBLE_TEST_LATIN1_VALUE returns: " + environ['ANSIBLE_TEST_LATIN1_VALUE'])

if __name__ == '__main__':
    test__TextEnviron___getitem__()

# Generated at 2022-06-11 18:23:40.554561
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup:
    os.environ = {'TEXT': 'a value', 'BYTE': b'a value'}
    te = _TextEnviron({'TEXT': 'a value', 'BYTE': b'a value'})

    # Verify:
    assert te['TEXT'] == 'a value'
    assert te['BYTE'] == u'a value'



# Generated at 2022-06-11 18:23:54.046646
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that the class returns the correct byte string for the environment for Python2
    environ['ANSIBLE_TEST_KEY'] = 'tests/setup/data/utf-8-sig.txt'
    if PY3:
        assert environ['ANSIBLE_TEST_KEY'] == 'tests/setup/data/utf-8-sig.txt'
    else:
        assert environ['ANSIBLE_TEST_KEY'] == 'tests/setup/data/utf-8-sig.txt'

    # Test that the class returns the correct unicode string for the environment for Python3
    # test that the class returns the correct unicode string for the environment for Python3
    environ['ANSIBLE_TEST_KEY'] = u'tests/setup/data/utf-8-sig.txt'

# Generated at 2022-06-11 18:23:56.371951
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ["A"] = "A"
    assert environ["A"] == "A"


# Generated at 2022-06-11 18:24:04.303377
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Requirement: keys in environ are bytes

    # Set an environment variable with a key that is bytes
    key = os.urandom(10)
    value = os.urandom(10)
    environ._raw_environ[key] = value

    # Get the value back and verify that the key and value match the original key and value
    assert environ[key] == value

    # Remove the key from the environment
    del environ._raw_environ[key]

    # Requirement: keys in environ are text

    # Set an environment variable with a key that is text
    key = u'Some kind of random text'
    value = u'Some kind of random text'
    environ._raw_environ[key] = value

    # Get the value back and verify that the key and value match the original key and value
    assert en

# Generated at 2022-06-11 18:24:11.087698
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        # Python 3's os.environ returns text.  So this is our expected result
        expected_result = {'LANG': 'C.UTF-8', 'USER': 'toshio'}
        result = {}
        for key, value in expected_result.items():
            os.environ[key] = value
            result[key] = environ.__getitem__(key)
        assert result == expected_result
    finally:
        for key in expected_result.keys():
            del os.environ[key]

# Generated at 2022-06-11 18:24:22.022704
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test non-unicode case
    environ['ANSIBLE_ASK_VAULT_PASS'] = 'ANSIBLE_ASK_VAULT_PASS'
    assert environ['ANSIBLE_ASK_VAULT_PASS'] == u'ANSIBLE_ASK_VAULT_PASS'

    # Test unicode case
    environ[u'ANSIBLE_ASK_VAULT_PASS'] = u'▶'
    assert environ[u'ANSIBLE_ASK_VAULT_PASS'] == u'▶'

    # Test bytes case
    environ[b'ANSIBLE_ASK_VAULT_PASS'] = b'ANSIBLE_ASK_VAULT_PASS'
    assert environ[b'ANSIBLE_ASK_VAULT_PASS'] == u'ANSIBLE_ASK_VAULT_PASS'


# Unit

# Generated at 2022-06-11 18:24:31.488660
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test on Python2
    if PY3:
        return

    # Test that the decoding of the environ works
    environ['test_key'] = b'\xc3\xb6\xc3\xa5\xc3\xb1\xc3\xa5'
    assert environ['test_key'] == '\xc3\xb6\xc3\xa5\xc3\xb1\xc3\xa5'

    # Test that the encoding of the environ works
    environ['test_key'] = '\xc3\xb6\xc3\xa5\xc3\xb1\xc3\xa5'
    assert environ['test_key'] == '\xc3\xb6\xc3\xa5\xc3\xb1\xc3\xa5'



# Generated at 2022-06-11 18:24:36.382213
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert(environ['SHELL'] == '/.ansible/venv/bin/bash')
    assert(environ['PATH'] == '/.ansible/venv/bin:/bin:/usr/bin')
    assert(environ['PYTHONPATH'] == '/.ansible/venv/lib/python3.6/site-packages')


# Generated at 2022-06-11 18:24:40.688519
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Given: An environment with an variable with a bytes value.
    env = _TextEnviron()
    env['foo'] = u'bar'

    # When: We get an item from the env
    # Then: The returned value is a byte string.
    assert isinstance(env['foo'], str)

# Generated at 2022-06-11 18:24:49.651691
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron()
    eu = _TextEnviron(encoding='utf-8')

    os.environ['test1'] = b'value1'
    os.environ['test2'] = b'value2'
    os.environ['test3'] = b'\xe2\x80\x94'  # emdash

    assert e['test1'] == u'value1'
    assert e['test2'] == u'value2'
    assert e['test3'] == u'\u2014'

    assert eu['test1'] == u'value1'
    assert eu['test2'] == u'value2'
    assert eu['test3'] == u'\u2014'



# Generated at 2022-06-11 18:25:00.815602
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test inside a function so we can more easily tearDown the patched values
    from ansible.module_utils.common._collections_compat import MutableMapping
    class _DictSubclass(MutableMapping):
        def __init__(self, d):
            self._d = d

        def __delitem__(self, key):
            del self._d[key]

        def __getitem__(self, key):
            return self._d[key]

        def __setitem__(self, key, value):
            self._d[key] = value

        def __iter__(self):
            return self._d.__iter__()

        def __len__(self):
            return len(self._d)

    # Test that the encoding variable overrides sys.getfilesystemencoding

# Generated at 2022-06-11 18:25:13.232014
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['HOME'] == environ._raw_environ['HOME']
    else:
        assert isinstance(environ['HOME'], unicode)
        assert environ['HOME'] == environ._raw_environ['HOME']
        assert environ['HOME'] == environ._raw_environ['HOME'].decode('utf-8')


# Generated at 2022-06-11 18:25:20.973186
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_env = {b'mykey1': b'value',
                b'mykey2': b'value1234'}
    text_environ = _TextEnviron(env=test_env)
    # By default the test will pass for any type of string
    assert text_environ[b'mykey1'] == u'value'
    assert isinstance(text_environ[b'mykey1'], str)
    assert text_environ[b'mykey2'] == u'value1234'

    test_env = {b'mykey1': u'value',
                b'mykey2': u'value1234'}
    text_environ = _TextEnviron(env=test_env)
    assert text_environ[b'mykey1'] == u'value'

# Generated at 2022-06-11 18:25:28.601043
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test to ensure that __getitem__ returns text or Unicode strings
    depending on the value of sys.getdefaultencoding.
    """
    setdefaultencoding = sys.getdefaultencoding
    sys.setdefaultencoding('utf-8')
    env = _TextEnviron(encoding='utf-8')
    assert isinstance(env['PATH'], str)
    sys.setdefaultencoding('ascii')
    env = _TextEnviron(encoding='utf-8')
    assert isinstance(env['PATH'], str)
    sys.setdefaultencoding(setdefaultencoding)

# Generated at 2022-06-11 18:25:32.785532
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ[b'ANSIBLE_TEST_BYTES'] = '言語'.encode('utf-8')
    assert environ[b'ANSIBLE_TEST_BYTES'] == '言語'

# Generated at 2022-06-11 18:25:40.189446
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.module_utils.six import PY3
    # Setting a unicode character in the environment is only possible in Python 2
    test_str = u'\u3042'

    tmpdir = to_text(mkdtemp())
    os.environ['_ansible_test_on_disk_file'] = tmpdir

    # Create a new environ object to test with
    import ansible.module_utils.basic.env_fallback
    environ = ansible.module_utils.basic.env_fallback.environ = ansible.module_utils.basic.env_fallback._TextEnviron()

    # Create a unicode-named file in a unicode-named dir in the tempdir

# Generated at 2022-06-11 18:25:50.586334
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test that the method is behaving as expected
    """
    class _MockEnviron(object):
        def __init__(self, environ):
            self._env = environ

        def __getitem__(self, key):
            return self._env[key]

    # PY3

    # If there is no encoding, use the system's encoding
    fake_env = _MockEnviron({'TEST_VAR_1': 'test_value_1'})
    mock_os_environ = _TextEnviron(env=fake_env, encoding=None)
    assert mock_os_environ['TEST_VAR_1'] == u'test_value_1'

    # If there is an encoding, use that

# Generated at 2022-06-11 18:26:01.233494
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import u

    # We want to test the case where the environment variables are unicode and are not
    # valid utf-8.  But os.environ does not allow us to do that.  So we need to somehow
    # get a mapping that is not os.environ for this test.

    # This is the unicode string we will be testing with.  It contains a non-valid utf-8
    # character
    test_unicode = u('\u2603')

    # We will just be feeding a dictionary to the constructor of our class.  So we
    # need to construct that dictionary in a way that makes the test unicode string
    # not valid utf-8.
    #
    # Note: The default encoding in Python is utf-8.
    # Note: encode takes a unicode string

# Generated at 2022-06-11 18:26:07.186980
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # initialization
    environ = _TextEnviron()
    # Test where test value is already unicode
    result = environ['ANSIBLE_CONFIG']
    assert result == to_text(os.environ['ANSIBLE_CONFIG'], encoding=sys.getfilesystemencoding())
    # Test where test value is bytes
    result = environ['PATH']
    assert result == to_text(os.environ['PATH'], encoding=sys.getfilesystemencoding())
    # Test of UnicodeEncodeError
    os.environ['ANSIBLE_SELECT_TEST_ENCODE'] = \
        to_bytes('\xed', encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict').decode('utf-8', 'surrogate_or_strict')

# Generated at 2022-06-11 18:26:14.533985
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({'var1': 'old value1'})
    assert env['var1'] == 'old value1'
    assert type(env['var1']) == str
    assert env['var1'] == env.get('var1')
    env['var1'] = 'new value1'
    assert env['var1'] == 'new value1'
    assert type(env['var1']) == str
    assert env['var1'] == env.get('var1')


# Generated at 2022-06-11 18:26:15.319131
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ.__init__()



# Generated at 2022-06-11 18:26:28.897405
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = {to_bytes(u'foo', 'utf-8'): to_bytes(u'bar', 'utf-8'),
           to_bytes(u'baz'): u'qux',
           to_bytes(u'quux', 'utf-8'): u'corge'}
    env = _TextEnviron(env, encoding='utf-8')
    assert env[u'foo'] == u'bar'
    assert env[u'baz'] == u'qux'
    assert env[u'quux'] == u'corge'

    assert env[b'foo'] == u'bar'
    assert env[b'baz'] == u'qux'
    assert env[b'quux'] == u'corge'


# Generated at 2022-06-11 18:26:39.099416
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a _TextEnviron with the encoding set to utf-8
    environ = _TextEnviron(encoding='utf-8')

    # Get a value from the environment which is encodable in utf-8
    utf8_value = environ.get('PATH')
    assert isinstance(utf8_value, str)
    assert utf8_value != ''

    # Get a value from the environment which is not encodable in utf-8
    environ['BOGUS'] = b'\x80'
    bogus_value = environ.get('BOGUS')
    assert isinstance(bogus_value, str)
    assert len(bogus_value) == 1
    assert bogus_value == u'\ufffd'



# Generated at 2022-06-11 18:26:45.658762
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    os.environ['TEST_KEY'] = b'\xe3\x81\x82'
    environ = _TextEnviron({b'TEST_KEY': b'\xe3\x81\x82'}, encoding='utf-8')
    assert environ['TEST_KEY'] == u'\u3042'


if __name__ == '__main__':
    test__TextEnviron___getitem__()

# Generated at 2022-06-11 18:26:56.245997
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # First ensure that the encoding is utf-8 (this is the default if not specified)
    assert environ.encoding == 'utf-8'

    # The first item we're going to test is a non-UTF8 encoding
    # We test this by using the file system encoding (which should be utf-8).  This will create
    # a string that's encoded in a different encoding.
    # On windows, this is 'mbcs' so use chr(200) which is not valid in that encoding.
    key = to_text(chr(200), encoding=sys.getfilesystemencoding())
    value = to_bytes(u'\xa4', encoding=sys.getfilesystemencoding())
    environ[key] = value

    # This should (in the end) decode to the euro symbol
    assert environ[key] == u

# Generated at 2022-06-11 18:26:58.817651
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['TEST_VAR'] = '仮\x80'
    assert environ['TEST_VAR'] == u'仮\uFFFD'
    del environ['TEST_VAR']


# Generated at 2022-06-11 18:27:08.550280
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest

    class _TextEnviron___getitem__TestCase(unittest.TestCase):
        """
        Unit tests for method .__getitem__ of class _TextEnviron
        """
        def test__getitem__with_ascii(self):  # pylint: disable=invalid-name
            """
            tests for .__getitem__
            """
            # Initialize _TextEnviron object at variable `env`
            env = _TextEnviron(env={'PATH': '/usr/bin:/usr/local/bin'})
            # Check that the value returned from env['PATH'] is the same as expected value
            self.assertEqual(env['PATH'], '/usr/bin:/usr/local/bin')
            # Check that the type of the value returned from env['PATH'] is unicode

# Generated at 2022-06-11 18:27:15.570203
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for ansible.module_utils.six._TextEnviron.__getitem__()
    """
    from ansible.module_utils.six import PY2

    # Note: If PY3 is True then all of the unittests are skipped because
    # they are testing that _TextEnvron.__getitem__() returns text strings
    if not PY2:
        return

    # The tests below assume the default encoding is unicode
    if not sys.getfilesystemencoding().startswith('utf'):
        return

    # First, set up some test data
    environ['ascii_var'] = b'test'

# Generated at 2022-06-11 18:27:19.842157
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # set up the test:
    # add some utf-8 characters to os.environ
    os.environ['badger'] = '井'

    # test the method:
    assert isinstance(environ['badger'], str)
    assert environ['badger'] == '井'


# Generated at 2022-06-11 18:27:30.134137
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    class FakeEnviron(MutableMapping):

        def __init__(self):
            self._values = {}

        def __delitem__(self, key):
            del self._values[key]

        def __getitem__(self, key):
            return self._values[key]

        def __setitem__(self, key, value):
            self._values[key] = value

        def __iter__(self):
            return self._values.__iter__()

        def __len__(self):
            return len(self._values)

    # Happy path
    env = _TextEnviron(env=FakeEnviron(), encoding='utf-8')
    env['latin1'] = b'\xe9'
    env['utf8'] = b'\xc3\xa9'

# Generated at 2022-06-11 18:27:33.501915
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['abcd'] = 'efgh'
    assert environ['abcd'] == 'efgh'
    environ['abcd'] = '$abcd'
    assert environ['abcd'] == '$abcd'

# Generated at 2022-06-11 18:27:48.905565
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # pylint: disable=redefined-outer-name
    # Nothing on Windows
    if os.name != 'nt':
        environ['CHROME_VERSION'] = 'A\\xE9\xC3\xA9'

        # If it is not bytes, it will raise a TypeError
        try:
            # pylint: disable=unused-variable
            value = environ['CHROME_VERSION']
            assert False, 'Should raise a TypeError'
        except TypeError:
            pass

        environ['CHROME_VERSION'] = 'A\xC3\xA9'

        # If it is not bytes, it will raise a TypeError

# Generated at 2022-06-11 18:27:52.422120
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    env['test'] = 'testval'
    assert env['test'] == 'testval'
    assert env['test'] == u'testval'
    assert env['test'].encode('utf-8') == b'testval'


# Generated at 2022-06-11 18:27:56.715345
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ.update({'foo': 'bar', 'некто': 'привет'})
    environ = _TextEnviron(os.environ)
    assert environ['foo'] == u'bar'
    assert environ['некто'] == u'привет'


# Generated at 2022-06-11 18:28:02.516315
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Given an environment variable that isn't already in environ
    if 'TEST_ENV' in environ:
        del environ['TEST_ENV']
    environ['TEST_ENV'] = u'проверка'

    # When I get the item from environ
    value = environ['TEST_ENV']

    # Then I get a text value back
    assert isinstance(value, str)
    assert value == u'проверка'

    # And it is utf-8 encoded

# Generated at 2022-06-11 18:28:11.942490
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that it handles an environment variable that is already in unicode format
    os.environ['ANSIBLE_TEST_UNICODE_ENCODING'] = u'Test раз'
    assert isinstance(environ['ANSIBLE_TEST_UNICODE_ENCODING'], type(u''))
    assert environ['ANSIBLE_TEST_UNICODE_ENCODING'] == u'Test раз'

    # Test that it handles an environment variable that is in utf-8 encoding
    os.environ['ANSIBLE_TEST_UTF8_ENCODING'] = u'Test раз'.encode(u'utf-8')
    assert isinstance(environ['ANSIBLE_TEST_UTF8_ENCODING'], type(u''))

# Generated at 2022-06-11 18:28:20.542115
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(env={b'key_bytes': b'./test_text_env.py',
                                b'bytes': b'bytes'},
                           encoding='latin-1')
    assert environ[b'key_bytes'] == u'./test_text_env.py'
    assert environ[u'key_bytes'] == u'./test_text_env.py'
    assert environ['key_bytes'] == u'./test_text_env.py'
    assert environ[b'bytes'] == u'bytes'
    assert environ[u'bytes'] == u'bytes'
    assert environ['bytes'] == u'bytes'


# Generated at 2022-06-11 18:28:31.508112
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test for byte string input
    byte_key = b"byte key"
    byte_value = b"byte value"

    # Create a new temporary environment
    env = {}
    # Add a byte string key and value to the new temporary environment
    env[byte_key] = byte_value

    # Create a new text environ using the new temporary environment
    text_env = _TextEnviron(env)

    # Ensure the value is the same as the input value
    assert text_env[byte_key] == byte_value
    assert isinstance(text_env[byte_key], str)

    # Test for text string input
    # Text string input should work even though it is not the value's encoding
    text_key = u"text key"
    text_value = u"text value"

    # Add a text string key and value to the

# Generated at 2022-06-11 18:28:42.728623
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test the __getitem__ method from the class _TextEnviron.
    """
    # Create a test class instance
    test_class = _TextEnviron()
    # Test the case where the key is a string
    assert test_class['PWD'] == os.environ['PWD']
    # Test the case where the key is a unicode code
    assert test_class[u'PWD'] == os.environ['PWD']
    # Test the case where the key is an integer
    assert test_class[0] == os.environ['0']
    # Test the case where the key is an invalid type
    with pytest.raises(TypeError):
        test_class[None]

# Following is a standalone test to be run via the Ansible test infrastructure
# Test python3 and python 2 separately so the test can

# Generated at 2022-06-11 18:28:50.312399
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.common._collections_compat import _SENTINEL
    en = _TextEnviron({b't': b'a', b's': 1})
    assert en[b't'] == u'a'
    assert en[b's'] == _SENTINEL

    en = _TextEnviron({'t': 'a', 's': 1})
    assert en['t'] == 'a'
    assert en['s'] == _SENTINEL


# Generated at 2022-06-11 18:28:53.589372
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    tmp_environ = {'ansible_is_a_string': 'yes'}
    ansible_env = _TextEnviron(env=tmp_environ)
    assert ansible_env['ansible_is_a_string'] == u'yes'

# Generated at 2022-06-11 18:29:28.160360
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Input arguments
    key = 'PATH'
    # Expected results
    result_decoded = to_text(os.environ[key], encoding='utf-8', nonstring='passthru',
                             errors='surrogate_or_strict')
    non_unicode_result_decoded = to_text(os.environ[key], encoding='utf-8', nonstring='strict',
                                         errors='surrogate_or_strict')

    # Actual output
    result = environ[key]

    # Assertions
    assert result == result_decoded
    assert environ[key] == non_unicode_result_decoded


# Generated at 2022-06-11 18:29:32.032446
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with Python2
    environ_var = u'TEST_VAR'
    environ_var_value = u'тест'
    environ[environ_var] = environ_var_value
    assert environ[environ_var] == environ_var_value

# Generated at 2022-06-11 18:29:34.751223
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['ANSIBLE_MODULE_ARGS']



# Generated at 2022-06-11 18:29:42.583931
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    _TextEnviron.__getitem__(key)

    returns a text string when your operating system supports it
    """
    import platform
    if platform.system() in ('Windows',):
        # Windows currently uses UTF-16LE in the CP637 codepage for the console
        environ = _TextEnviron(encoding=None)
        assert environ['SHELL'] == u'C:\\windows\\system32\\cmd.exe'
    elif platform.system() in ('Darwin', 'Linux'):
        # Darwin and Linux use utf-8
        environ = _TextEnviron(encoding=None)
        assert environ['SHELL'] == u'/bin/bash'

# Generated at 2022-06-11 18:29:50.870564
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six.moves.builtins import input
    # This test works via mocking out `os.environ` since `_TextEnviron` is designed to be an
    # interface over an existing dict.

    expected_value = u'अनुप्रयोग'
    actual_value = None

    # This is how python's `os.environ` is implemented in all the encodings I can test with.
    encoded_value = expected_value.encode('utf-8')

    # A dict to act as the environment
    mock_environ = {b'KEY': encoded_value}

    # Make sure that the encoded value actually encodes to the expected value
    assert encoded_value == expected_value.encode('utf-8')


# Generated at 2022-06-11 18:29:55.587331
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    t = _TextEnviron()
    t['FOO'] = 'BAR'
    if PY3:
        expected = 'BAR'
    else:
        expected = u'BAR'
    assert t['FOO'] == expected, 'Expected %s, got %s' % (expected, t['FOO'])



# Generated at 2022-06-11 18:30:04.824815
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import b
    from ansible.module_utils.six import u, text_type
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text

    # Test a non-unicode variable
    _environ = {'foo': b('hello')}
    t_env = _TextEnviron(env=_environ)

    # os.environ is a dict-like object.  Since dicts are ordered, we need to use the same key
    # order as os.environ
    test_key = u('foo')
    assert t_env[test_key] == u('hello')

    # Also confirm we cache the result
    assert to_text(b('hello'), 'utf-8') is t_env[test_key]



# Generated at 2022-06-11 18:30:11.685540
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Check that the method returns a unicode string on PY2
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils._text import to_bytes, to_text
    environ = _TextEnviron()
    assert isinstance(environ['PATH'], str) and isinstance(environ['PATH'], str)



# Generated at 2022-06-11 18:30:20.259804
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a dict with byte string keys and values and a dict with unicode keys and values
    # (in utf-8 encoding)
    raw_utf8 = {b'k1': b'v1', b'k2': b'value2'}
    utf8 = {u'k1': u'v1', u'k2': u'value2'}

    # Create an instance of _TextEnviron with the raw dict and get the items from it
    txt_utf8 = _TextEnviron(env=raw_utf8, encoding='utf-8')
    assert utf8.items() == sorted(txt_utf8.items())

    # Verify that it works if we try to get an item
    assert utf8['k1'] == txt_utf8['k1']

# Generated at 2022-06-11 18:30:27.747853
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['ANSIBLE_MODULE_ARGS'] = '{"_ansible_verbosity": 3, "_ansible_debug": true, "_ansible_socket": {"host": "192.168.1.110", "port": 22, "user": "ansible", "password": "ansible"}, "name": "demo", "view": "demo", "host": "demo"}'
    
    name = environ['ANSIBLE_MODULE_ARGS']
    
    print(name)

test__TextEnviron___getitem__()