

# Generated at 2022-06-11 18:21:05.825753
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Ensure that module_utils._text.environ returns the same type as
    # the original os.environ

    # This test assumes that if the original os.environ returns
    # a text type, the TextEnviron class should also return a text type
    # and likewise for bytes.

    if sys.version_info >= (3,):
        assert isinstance(environ['PATH'], str)
        # On Windows, the default is always cp65001 which is UTF-8
        assert environ['PATH'] == os.environ['PATH']

        os.environ['PATH'] = 'FOO'
        assert isinstance(environ['PATH'], str)
        assert environ['PATH'] == os.environ['PATH']
        del os.environ['PATH']

        os.environ['PATH'] = 'bar'

# Generated at 2022-06-11 18:21:17.127594
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Do not set a value for the LC_ALL environment variable in the test
    # environment so that we can be sure the tests will run correctly regardless of the user's
    # system settings.
    environ.update(os.environ)
    del environ['LC_ALL']

    # 1. Check if the method __getitem__ of the class _TextEnviron returns a unicode string
    assert isinstance(environ['HOME'], str)

    # 2. Check if the method __delitem__ of the class _TextEnviron is working properly
    environ['TEST'] = 'test'
    assert 'TEST' in environ
    del environ['TEST']
    assert 'TEST' not in environ

    # 3. Check if the method __contains__ of the class _TextEnviron is working properly

# Generated at 2022-06-11 18:21:29.039995
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron(encoding='utf-8')
    text_environ['text_key'] = 'text_value'
    assert text_environ['text_key'] == u'text_value'

    text_environ['binary_key'] = b'binary_value'
    assert text_environ['binary_key'] == u'binary_value'

    text_environ['binary_unicode_key'] = b'binary_\xF0\x9F\x92\xA9_unicode'
    assert text_environ['binary_unicode_key'] == u'binary_\U0001F4A9_unicode'

    text_environ['str_key'] = u'str_value'
    assert text_environ['str_key'] == u'str_value'

   

# Generated at 2022-06-11 18:21:33.976612
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['TEST_TEXTENVIRON'] = b'\xe2\x9c\x93'
    env = _TextEnviron(encoding='utf-8')

    env['TEST_TEXTENVIRON'] = "✓"
    assert env['TEST_TEXTENVIRON'] == u"✓"



# Generated at 2022-06-11 18:21:39.317213
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    envi = _TextEnviron()
    assert isinstance(envi.__getitem__('PATH'), str)
    envi.__setitem__('PATH', '/usr/bin:/bin')
    assert isinstance(envi.__getitem__('PATH'), str)


# Generated at 2022-06-11 18:21:42.142842
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(env={"TEST_ENV_VAR": "Hi there!"}, encoding="utf-8")
    assert env["TEST_ENV_VAR"] == u"Hi there!"

# Generated at 2022-06-11 18:21:46.351050
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an object of class _TextEnviron
    try:
        os.environb
    except AttributeError:
        os.environb = os.environ
    env = _TextEnviron(env=os.environb, encoding="ascii")
    env["foo"] = b"bar"
    assert env['föö'] == "bar"

# Generated at 2022-06-11 18:21:53.351616
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({}, encoding='utf-8')
    environ.__setitem__('test_s', '中文')
    environ.__setitem__('test_b', b'\xe4\xb8\xad\xe6\x96\x87')
    assert environ.__getitem__('test_s') == '中文'
    assert environ.__getitem__('test_b') == '中文'
    assert environ.__getitem__('test_b') == environ.__getitem__('test_s')

# Generated at 2022-06-11 18:22:03.416864
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(environ, MutableMapping)

# Generated at 2022-06-11 18:22:05.917711
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert b'PATH' in environ._raw_environ
    assert 'PATH' in environ


# Generated at 2022-06-11 18:22:18.477392
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    class _TextEnviron(MutableMapping):
        """
        Utility class to return text strings from the environment instead of byte strings

        Mimics the behaviour of os.environ on Python3
        """
        def __init__(self, env=None, encoding=None):
            if env is None:
                env = os.environ
            self._raw_environ = env
            # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
            # instead of utf-8

# Generated at 2022-06-11 18:22:21.022610
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        expected_result = '/home/user'
        assert environ['HOME'] == expected_result
    else:
        expected_result = u'/home/user'
        assert environ['HOME'] == expected_result

# Generated at 2022-06-11 18:22:31.710732
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test that __getitem__ does not return byte strings
    """
    # pylint: disable=too-many-branches,too-many-statements,too-many-locals,too-many-nested-blocks
    # pylint: disable=too-many-return-statements,too-many-boolean-expressions
    if not PY3:
        import os
        from ansible.module_utils._text import to_bytes, to_text
        # This is a helper function because the messages are very long

# Generated at 2022-06-11 18:22:40.501056
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    class EnvironDict(MutableMapping):
        def __delitem__(self, key):
            del os.environ[key]

        def __getitem__(self, key):
            return os.environ[key]

        def __setitem__(self, key, value):
            return os.environ.__setitem__(key, value)

        def __iter__(self):
            return os.environ.__iter__()

        def __len__(self):
            return len(os.environ)

    env = _TextEnviron(env=EnvironDict())
    assert 'non-utf8-value' not in env
    os.environ.__setitem__('non-utf8-value', b'\x80\x81\x82\x83\x84')

# Generated at 2022-06-11 18:22:48.374975
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.common._collections_compat import MutableMapping
    env = _TextEnviron(encoding='utf-8')
    assert isinstance(env, MutableMapping)

    assert isinstance(env['TEST1'], text_type)
    assert env['TEST1'] == ''

    os.environ['TEST2'] = 'test_value'
    assert isinstance(env['TEST2'], text_type)
    assert env['TEST2'] == 'test_value'

# Generated at 2022-06-11 18:22:53.004121
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    result = _TextEnviron().__getitem__('HOME')
    # if sys.platform == "win32":
        # assert result == "C:\\Users\\username"
    # else:
        # assert result == "/home/username"


# Generated at 2022-06-11 18:23:02.465572
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    env.encoding = 'utf-8'
    env._raw_environ['ascii'] = b'ascii'
    env._raw_environ['bytes_utf8'] = b'\xc2\xa2'.decode('utf-8')
    env._raw_environ['bytes_latin-1'] = b'\xa2'
    env._raw_environ['text_utf8'] = u'\xa2'.encode('utf-8')

    assert env['ascii'] == u'ascii'
    assert u'\xa2' == env['bytes_utf8']
    assert u'\xa2' == env['bytes_latin-1']
    assert u'\xa2' == env['text_utf8']

# Generated at 2022-06-11 18:23:13.910877
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import UserDict

    raw_environ = UserDict()
    raw_environ['unicode'] = u'\u30a2'
    raw_environ['bytes'] = u'\u30a2'.encode('cp437')
    raw_environ['nodecode'] = u'\u30a2'.encode('idna')
    raw_environ['errorreplace'] = u'\u30a2'.encode('ascii', errors='replace')
    raw_environ['errorstrict'] = u'\u30a2'.encode('ascii', errors='strict')
    raw_environ['byteunder'] = '\x80'.encode()
    raw_en

# Generated at 2022-06-11 18:23:24.479480
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # define some testcases (should add more)
    testcases = [
        {'key': 'FOO', 'value': 'bär'},
        {'key': 'BAR', 'value': u'bär'},
        {'key': 'BAZ', 'value': b'b\xc3\xa4r'},
    ]

    # call __getitem__ for all defined testcases
    for testcase in testcases:
      environ[testcase['key']] = testcase['value']
      assert(environ[testcase['key']] == testcase['value'])
      assert(len(environ[testcase['key']]) == len(testcase['value']))



# Generated at 2022-06-11 18:23:30.545546
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test with encoding set to utf-8
    test_environ = _TextEnviron(encoding='utf-8')

    # Test with non-ascii values:
    test_environ['spanish'] = b'alm\xc3\xadbar'
    test_environ['russian'] = b'\xd0\x92\xd0\xbe\xd0\xbb\xd1\x8c\xd0\xba\xd0\xb8\xd0\xbb\xd0\xbe\xd0\xb2\xd0\xb0'

# Generated at 2022-06-11 18:23:41.724469
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_test = _TextEnviron({'test1': 'value1', 'test2': 'value2'})
    assert environ_test['test1'] == u'value1'
    assert environ_test['test2'] == u'value2'
    environ_test['test2'] = u'value2_new'
    assert environ_test['test2'] == u'value2_new'
    assert environ_test.get('test2') == 'value2_new'
    assert environ_test.get('test3') is None
    assert environ_test.get('test3', 'default') == 'default'
    assert environ_test.get('test2', b'default') == 'value2_new'
    assert environ_test.get('test2', u'default') == u

# Generated at 2022-06-11 18:23:53.453660
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ1 = _TextEnviron(encoding='utf-8')
    environ1.clear()
    environ1.update({
        'NONEXISTENT': 'NONEXISTENT',
        'NONEXISTENT2': 'NONEXISTENT2',
        'NONEXISTENT3': 'NONEXISTENT3',
        'NONEXISTENT4': 'NONEXISTENT4',
    })
    assert environ1.keys() == ['NONEXISTENT', 'NONEXISTENT2', 'NONEXISTENT3', 'NONEXISTENT4']
    assert 'nonExistent' == environ1['NONEXISTENT']
    assert 'nonExistent2' == environ1['NONEXISTENT2']
    assert 'nonExistent3' == environ

# Generated at 2022-06-11 18:24:03.267531
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['ANSIBLE_TEST_VAR'] = b'ANSIBLE_TEST_VAR1,ANSIBLE_TEST_VAR2' if PY3 else 'ANSIBLE_TEST_VAR1,ANSIBLE_TEST_VAR2'
    # fetch ANSIBLE_TEST_VAR from environment
    assert environ['ANSIBLE_TEST_VAR'] == u'ANSIBLE_TEST_VAR1,ANSIBLE_TEST_VAR2'
    # fetch ANSIBLE_TEST_VAR from cache
    assert environ['ANSIBLE_TEST_VAR'] == u'ANSIBLE_TEST_VAR1,ANSIBLE_TEST_VAR2'
    # *not* fetch ANSIBLE_TEST_VAR2 from environment or cache

# Generated at 2022-06-11 18:24:14.050199
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    from ansible.module_utils._text import to_bytes, to_text

    # set up environment
    old_env = os.environ
    os.environ = {}
    os.environ['bytes_key'] = to_bytes("λ")
    os.environ['unicode_key'] = to_text("λ")
    os.environ['utf8_key'] = to_bytes("λ", encoding='utf-8')
    os.environ['utf8_key'] = to_text("λ", encoding='utf-8')

    # test when PY3 is true
    PY3_backup = PY3
    PY3 = True
    environ = _TextEnviron()
    assert environ['bytes_key'] == to_text("λ")

# Generated at 2022-06-11 18:24:22.446699
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Verify that variable can be read without an encoding argument on Python 3
    encoding = None
    if PY3:
        encoding = None
    else:
        encoding = 'utf-8'
    env = {b'BYTES': b'BYTES', u'UNICODE': u'UNICODE'}
    test_env = _TextEnviron(env=env, encoding=encoding)
    assert test_env[u'BYTES'] == u'BYTES'
    assert test_env[u'UNICODE'] == u'UNICODE'
    assert test_env[u'NON-EXISTENT'] == u''


# Generated at 2022-06-11 18:24:31.747352
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Verifies that __getitem__ handles an environment variable with a unicode value
    environ['foo'] = u'\xe3'
    assert isinstance(environ['foo'], text_type)
    assert environ['foo'] == u'\xe3'
    # Verifies that __getitem__ handles an environment variable with a byte value
    environ['foo'] = b'\xe3'
    assert isinstance(environ['foo'], text_type)
    assert environ['foo'] == u'\xe3'
    # Verifies that __getitem__ handles an environment variable with a byte value as a string
    environ['foo'] = '\xe3'
    assert isinstance(environ['foo'], text_type)
    assert environ['foo'] == u'\xe3'
    # Verifies that __get

# Generated at 2022-06-11 18:24:40.496294
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Tests method __getitem__ from class _TextEnviron

    Args:
        None

    Returns:
        None
    """
    env = _TextEnviron(encoding='ascii')
    assert isinstance(env['ascii'], str)
    assert env['ascii'] == 'ascii'
    assert isinstance(env['unicode'], str)
    assert env['unicode'] == 'unicode'

    env['set-ascii'] = 'ascii'
    assert isinstance(env['set-ascii'], str)
    assert env['set-ascii'] == 'ascii'
    env['set-unicode'] = 'unicode'
    assert isinstance(env['set-unicode'], str)

# Generated at 2022-06-11 18:24:50.162361
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # pylint: disable=protected-access
    # Setup
    env = {
            u'key1': u'value1',
            b'key2': b'value2',
            u'key3': {u'key4': u'value4'}
        }
    e = _TextEnviron(env, encoding='utf8')

    # Test that when a key points to an object that is not a string, the object is returned
    assert e['key3'] == {u'key4': u'value4'}

    # Test that when a key points to a unicode string, the unicode string is returned
    assert e['key1'] == u'value1'

    # Test that when a key points to a byte string, a unicode string is generated
    assert e['key2'] == u'value2'

# Generated at 2022-06-11 18:25:01.075277
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Case 1: The value of environment variable is unicode string
    txt_environ = _TextEnviron()
    txt_environ["PY_ENV_VAR_1"] = u'unicode val'
    assert txt_environ["PY_ENV_VAR_1"] == u'unicode val'

    # Case 2: The value of environment variable is encoded string.
    #         sys.getfilesystemencoding() is "utf-8".
    #         Encoding is "utf-8".
    #         There is no decoding errors.
    txt_environ = _TextEnviron(encoding='utf-8')
    txt_environ["PY_ENV_VAR_2"] = u'utf8 val'.encode('utf-8')

# Generated at 2022-06-11 18:25:12.440423
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a copy of os.environ in the variable raw_environ
    raw_environ = environ._raw_environ.copy()
    # Check that the variable "LANG" is present in the variable raw_environ
    assert 'LANG' in raw_environ

    # Check that the variable "LANG" is present in the variable environ
    assert environ.__contains__('LANG')
    assert 'LANG' in environ
    assert 'LANGUAGE' in environ
    # assert 'ANSIBLE_CONFIG' in environ
    # assert 'ANSIBLE_STDOUT_CALLBACK' in environ
    assert 'ANSIBLE_STDOUT_CALLBACK' not in environ
    # assert 'ANSIBLE_FORCE_COLOR' in environ
    assert 'ANSIBLE_FORCE_COLOR' not in en

# Generated at 2022-06-11 18:25:18.014573
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    env['TEST_ENV'] = 100
    assert env['TEST_ENV'] == '100'

# Generated at 2022-06-11 18:25:26.711762
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # If a key is in the environment, it should get returned
    os.environ['ANSIBLE_TEST_ENVIRON_1'] = u'▶'
    assert environ['ANSIBLE_TEST_ENVIRON_1'] == u'▶'
    assert u'ANSIBLE_TEST_ENVIRON_1' in environ

    # If a key is not in the environment, a KeyError should be raised
    try:
        os.environ['ANSIBLE_TEST_ENVIRON_2'] = u'▶'
    except KeyError:
        pass
    try:
        environ['ANSIBLE_TEST_ENVIRON_2'] = u'▶'
    except KeyError:
        pass


# Generated at 2022-06-11 18:25:29.835097
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['LANG'] = 'UTF-8'
    assert(environ.get('LANG') == 'UTF-8')



# Generated at 2022-06-11 18:25:35.570941
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ._raw_environ = {b'KEY': b'VALUE'}
    assert environ['KEY'] == 'VALUE'

    environ._raw_environ = {b'KEY': bytearray(b'VALUE')}
    assert environ['KEY'] == 'VALUE'

    environ._raw_environ = {b'KEY': memoryview(b'VALUE')}
    assert environ['KEY'] == 'VALUE'



# Generated at 2022-06-11 18:25:37.809914
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set up
    _environ = environ
    # Exercise
    result = _environ['TESTTEXTENVIRON']
    # Verify
    assert type(result) is str
    # Clean up
    del _environ


# Generated at 2022-06-11 18:25:47.483465
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that environment is returned as text if not on PY3, otherwise as bytes
    for env_key in os.environ:
        if PY3:
            assert isinstance(os.environ[env_key], bytes), \
                'environment should be bytes on PY3'
        else:
            assert isinstance(os.environ[env_key], text_type), \
                'environment should be text strings on Python2'
        if isinstance(os.environ[env_key], bytes):
            assert isinstance(environ[env_key], text_type), \
                'environ should return text strings on Python2'
        else:
            assert isinstance(environ[env_key], text_type), \
                'environ should return bytes on PY3'
    # Test that when set a value is set as

# Generated at 2022-06-11 18:25:55.376270
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import ansible_collections.testing.unit_tests.module_utils.common.text_environ

    # This is the test used in the six pull request
    os.environ[to_bytes('Basic_key')] = to_text('Basic_value')

    # Test the cache
    assert ansible_collections.testing.unit_tests.module_utils.common.text_environ.environ[to_bytes('Basic_key')] == \
        'Basic_value'
    assert ansible_collections.testing.unit_tests.module_utils.common.text_environ.environ[to_bytes('Basic_key')] == \
        'Basic_value'

    # Test changing a value in the environment
    os.environ[to_bytes('Basic_key')] = to_text('Basic_value2')


# Generated at 2022-06-11 18:26:03.979312
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    assert issubclass(_TextEnviron, MutableMapping)

    # Test subclasses of MutableMapping without overridden methods
    environ = _TextEnviron()
    assert isinstance(os.environ, MutableMapping)
    assert environ == os.environ

    # Verify that the intial state of the objects matches
    for key in os.environ:
        assert environ[key] == os.environ[key]

    # Verify that a missing key raises the same error
    try:
        os.environ["FOO"]
        assert False, "Failed to raise KeyError"
    except KeyError:
        pass

# Generated at 2022-06-11 18:26:14.385504
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test with a single variable value
    env = dict(VAR1=b'Hello', VAR2=b'World')
    temp_environ = _TextEnviron(env=env)
    assert temp_environ['VAR1'] == 'Hello'
    assert temp_environ['VAR2'] == 'World'

    # Test with a variable which changes between runs
    env = dict(VAR1=b'\xc3\xa9')
    temp_environ = _TextEnviron(env=env)
    assert temp_environ['VAR1'] == u'\xe9'
    env = dict(VAR1=b'\xc3\xa9\xc3\xa9')
    temp_environ = _TextEnviron(env=env)

# Generated at 2022-06-11 18:26:23.473045
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env_test = _TextEnviron()
    # intger
    env_test[b'int'] = 1
    assert isinstance(env_test[b'int'], int)

    # byte string
    byte_str = b'byte string'
    env_test[b'byte'] = byte_str
    assert isinstance(env_test[b'byte'], bytes)
    assert env_test[b'byte'] == byte_str

    # unicode string
    unicode_str = u'unicode string'
    env_test[b'unicode'] = unicode_str
    assert isinstance(env_test[b'unicode'], unicode)
    assert env_test[b'unicode'] == unicode_str



# Generated at 2022-06-11 18:26:39.825360
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # check that _TextEnviron.__getitem__() returns str in Python 3 and unicode in Python 2
    assert isinstance(environ['HOME'], str)
    assert isinstance(environ['HOME'], str)

    # check that _TextEnviron.__getitem__() returns empty string when the variable is not set
    os.environ.pop('TEST__TextEnviron___getitem__', None)
    assert environ['TEST__TextEnviron___getitem__'] == ''

    # check that _TextEnviron.__getitem__() returns the value of the variable
    test_var_value = 'test_value'
    os.environ['TEST__TextEnviron___getitem__'] = test_var_value
    assert environ['TEST__TextEnviron___getitem__'] == test_var_value

# Generated at 2022-06-11 18:26:46.798652
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Ensure that class _TextEnviron returns unicode strings on python2.
    The test case must run as python2 so that the behaviour for python2 is being tested.
    '''
    from ansible.module_utils.six.moves import builtins

    env = builtins.__dict__['environ']
    env["user"] = "johndoe"
    environ = _TextEnviron(env=env)

    assert environ["user"] == u"johndoe"

# Generated at 2022-06-11 18:26:52.859050
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if not PY3:
        environ = _TextEnviron(encoding='utf-8')
        assert environ['LANG'] == u'en_US.utf-8'

    environ = _TextEnviron(encoding='latin-1')
    assert environ['LANG'] == u'en_US.utf-8'



# Generated at 2022-06-11 18:26:59.522953
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        original_env = dict(environ._raw_environ)
    except:
        original_env = dict(environ)

    environ['test_utf'] = '\u00e9'
    assert environ['test_utf'] == u'\u00e9'

    # Try with different encoding
    environ.encoding = 'cp1252'
    environ['test_cp1252'] = '\u00e9'
    assert environ['test_cp1252'] == u'\u00e9'

    # Restore original environment
    environ._raw_environ = original_env

# Generated at 2022-06-11 18:27:09.189546
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test normal usage
    os.environ[u'test_key'] = u'test_value'
    assert environ[u'test_key'] == u'test_value'
    # Test that we won't receive an error if the environment variable contains a non latin
    # character
    os.environ[u'test_key'] = u'ñ'.encode('latin-1')
    assert environ[u'test_key'] == u'ñ'
    # Test that decoding if a variable changes during the run uses the new value and doesn't
    # cache the value (See github issue #26671)
    original_value = u'original_value'
    new_value = u'new_value'
    assert new_value != original_value
    os.environ[u'test_key'] = original_value

# Generated at 2022-06-11 18:27:15.782974
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Definition of test data
    os_environ_raw = {
        u'test1': u'this',
        u'test2': u'\u65e5\u672c\u8a9e',
        u'test3': u'1234',
        u'test4': u'\u03c0\u207f\u03c0',
        u'test5': u'\u00e9',
        u'test6': u'\u03b1',
        u'test7': u'abc\xffdef\x00ghi'
    }

# Generated at 2022-06-11 18:27:19.038472
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(encoding='ascii')
    super(MutableMapping, env).__setitem__('foo', 'foo')
    assert env['foo'] == u'foo'



# Generated at 2022-06-11 18:27:25.490537
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    # KeyError if key not in environ
    try:
        environ['NOTSET']
    except KeyError as e:
        assert str(e) == 'NOTSET'
    else:
        assert False

    # Returns unicode string for key in environ
    assert isinstance(environ['PATH'], text_type)

# Generated at 2022-06-11 18:27:30.228333
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    assert isinstance(env['PATH'], text_type)
    env.encoding = 'ascii'
    assert isinstance(env['PATH'], text_type)

if __name__ == "__main__":
    test__TextEnviron___getitem__()

# Generated at 2022-06-11 18:27:35.786045
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    __tracebackhide__ = True
    os.environ['TEST_TEXTENVIRON'] = b'bar'
    assert environ['TEST_TEXTENVIRON'] == 'bar'
    os.environ['TEST_TEXTENVIRON'] = 'baz'
    assert environ['TEST_TEXTENVIRON'] == 'baz'
    del os.environ['TEST_TEXTENVIRON']



# Generated at 2022-06-11 18:27:57.804002
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Unit test for method __getitem__ of class _TextEnviron

    :returns: A tuple of two elements: ``(True, 0)`` on success or ``(False, number_of_failed_tests)`` on failure.
    :rtype: tuple
    '''
    # pylint: disable=protected-access

    #
    # Method __getitem__ should return text strings for byte strings.
    #
    class _TestEnviron(object):
        def __init__(self):
            self.env_value = b'byte string'

        def __getitem__(self, key):
            return self.env_value

    env = _TestEnviron()
    environ = _TextEnviron(env=env)
    assert isinstance(environ['any_key'], str)

    #
    # Method __

# Generated at 2022-06-11 18:28:09.317744
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for Python3 behaviour
    if PY3:
        # Test that a unicode value is returned.  os.environ.__getitem__ will return unicode
        # values on Python3
        test_environ = _TextEnviron()
        test_environ['foo'] = 'bar'
        assert test_environ['foo'] == 'bar'
    else:
        # Test that a text value is returned.  os.environ.__getitem__ will return byte strings
        # on Python2
        test_environ = _TextEnviron()
        test_environ['foo'] = 'bar'
        assert test_environ['foo'] == u'bar'

    # Test that errors are handled correctly
    # Test that text is decoded under default conditions
    test_environ = _TextEnviron()
    test_en

# Generated at 2022-06-11 18:28:12.326546
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(environ['TEST'], str)
    assert isinstance(environ['PYTHONPATH'], str)
    assert isinstance(environ['TEST'], str)


# Generated at 2022-06-11 18:28:21.856250
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from mock import patch
    from ansible.module_utils.six import u
    from ansible.module_utils.six.moves.urllib.error import URLError

    # Patch _raw_environment
    environ_patch = patch.object(environ, '_raw_environ')
    environ_patch.start()

    # Test case 1
    environ_patch.get.return_value = b'\xc3\x84\xc3\x96\xc3\x9c'
    assert environ[b'\xc3\x84\xc3\x96\xc3\x9c'] == u('\u00c4\u00d6\u00dc')

    # Test case 2
    environ_patch.get.return_value = b'\xe2\x80\xa6'

# Generated at 2022-06-11 18:28:24.546824
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    tester = _TextEnviron()
    tester['test_variable'] = b'\xC2\xA2'
    assert tester['test_variable'] == '¢'

# Generated at 2022-06-11 18:28:27.203285
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:28:38.857266
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ.encoding = 'utf-8'
    environ['simplestr'] = 'one'
    assert environ.get('simplestr') == 'one'

    environ['simpleunicode'] = u'one'
    assert environ.get('simpleunicode') == u'one'

    environ['unicodestr'] = u'\u00fc'
    assert environ.get('unicodestr') == u'\u00fc'

    environ['unicodestr'] = '\xc3\xbc'
    assert environ.get('unicodestr') == u'\u00fc'

    environ['bytestr'] = b'\xc3\xbc'
    assert environ.get('bytestr') == u'\u00fc'


# Generated at 2022-06-11 18:28:46.996511
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Testing with various utf-8 encoded values
    environ[b'KEY'] = b'\xc2\xab'
    assert environ[b'KEY'] == u'\u00ab'
    assert environ['KEY'] == u'\u00ab'
    environ['KEY'] = u'\u00ab'
    assert environ['KEY'] == u'\u00ab'
    assert environ[b'KEY'] == u'\u00ab'

    environ[b'KEY'] = b'\xe2\x82\xac'
    assert environ[b'KEY'] == u'\u20ac'
    assert environ['KEY'] == u'\u20ac'
    environ['KEY'] = u'\u20ac'

# Generated at 2022-06-11 18:28:49.180870
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron({b'a': b'1'})
    assert text_environ[b'a'] == u'1'

# Generated at 2022-06-11 18:28:49.552586
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass

# Generated at 2022-06-11 18:29:30.216063
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class _RawEnviron(object):
        def __init__(self):
            self._vars = {}
        def __getitem__(self, key):
            return self._vars[key]

    raw_environ = _RawEnviron()

    # Define Key in the raw environment
    key = "MYKEY"
    value = "some text value"
    raw_environ._vars[key] = value

    # Test without encoding provided
    environ = _TextEnviron(raw_environ)
    assert value == environ[key]

    # Test with encoding provided
    environ = _TextEnviron(raw_environ, encoding="utf-8")
    assert value == environ[key]

    # Test with invalid key

# Generated at 2022-06-11 18:29:40.703023
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    raw_utf_variable_name = b'\xc3\xbc'
    raw_utf_variable_value = b'\xe2\x98\x83'
    raw_utf_variable = raw_utf_variable_name + b'=' + raw_utf_variable_value
    os.environ[raw_utf_variable_name] = raw_utf_variable_value
    env = _TextEnviron(encoding='utf-8')

    print(type(env.keys()))
    print(type(raw_utf_variable_name))
    print(type(env.keys()))
    import six
    print(type(six.u('abc')))
    print(six.u(env[raw_utf_variable_name]))
    print(type(six.u(env[raw_utf_variable_name])))

# Generated at 2022-06-11 18:29:42.488666
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PYTHON_ENV'] == 'utf-8'


# Generated at 2022-06-11 18:29:50.803842
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class ArgumentError(Exception):
        """
        Keeps track of whether we raised an exception

        The code being tested should raise an ArgumentError exception.  This exception class
        keeps track of whether that happened.
        """
        raised = False

        def __init__(self, msg):
            ArgumentError.raised = True
            super(ArgumentError, self).__init__(msg)

    def arg_error(msg):
        raise ArgumentError(msg)

    test_environ = _TextEnviron(env=dict())

    def _test(key, value, encoding, errors, expected_value):
        # Clear out the cache
        test_environ._value_cache.clear()
        # Update the env dict
        test_environ._raw_environ[key] = value
        # Update the encoding
        test_environ.encoding

# Generated at 2022-06-11 18:29:59.522294
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    sample_env = {b'ANSIBLE_TEST': b'bytes: \xe2\x99\xa5'}
    test_env = _TextEnviron(env=sample_env)

    # Python2 return value should be unicode
    assert type(test_env['ANSIBLE_TEST']) is unicode
    assert test_env['ANSIBLE_TEST'] == u'bytes: \xe2\x99\xa5'

    # MutableMapping interface doesn't define .keys()
    assert len(test_env.keys()) == 1
    assert next(iter(test_env.keys())) == u'ANSIBLE_TEST'

# Generated at 2022-06-11 18:30:07.034617
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['ansible_test'] = b'foobar'
    assert environ['ansible_test'] == u'foobar'

    environ['ansible_test'] = u'barfoo'
    assert environ['ansible_test'] == u'barfoo'

    environ['ansible_test'] = b'\uFEFF' # BOM
    assert environ['ansible_test'] == u'\uFEFF'

    # Invalid UTF-8
    environ['ansible_test'] = b'\xFF\xFF'
    assert environ['ansible_test'] == b'\xFF\xFF'

    # Invalid UTF-8
    environ['ansible_test'] = b'\xC3\xFF'

# Generated at 2022-06-11 18:30:17.571011
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """


# Generated at 2022-06-11 18:30:18.997184
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['test'] = 'test'
    assert environ['test'] == 'test'

# Generated at 2022-06-11 18:30:29.198577
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Variable used for assertions
    _success = True

    # Create a test environment

# Generated at 2022-06-11 18:30:32.668936
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test 1
    test_env = _TextEnviron(env={b'foo': b'spam'}, encoding='utf-8')
    assert test_env[b'foo'] == u'spam'

