

# Generated at 2022-06-11 18:21:04.317598
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # pylint: disable=protected-access
    environ = _TextEnviron()
    os.environ[b'ansible_utf8_test'] = b'\xc3\xa1'
    assert environ._raw_environ[b'ansible_utf8_test'] == b'\xc3\xa1'
    assert environ[b'ansible_utf8_test'] == u'\xe1'


# Generated at 2022-06-11 18:21:12.406025
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class _DummyEnviron(dict):
        def __getitem__(_, key):
            return key

    env = _TextEnviron(encoding='utf-8', env=_DummyEnviron())
    assert env['key'] == 'key'

    env = _TextEnviron(encoding='ascii', env=_DummyEnviron())
    assert env['key'] == 'key'

    env = _TextEnviron(encoding='ascii', env=_DummyEnviron())
    assert env['key'] == 'key'

    env = _TextEnviron(encoding='utf8', env=_DummyEnviron())
    assert env['key'] == 'key'

    env = _TextEnviron(encoding='utf8', env=_DummyEnviron())
    assert env['key'] == 'key'

# Generated at 2022-06-11 18:21:21.054345
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    def test_equal(actual, expected):
        assert actual == expected, "actual = {},\nexpected = {}".format(actual, expected)

    # Test that the raw value is returned
    test_equal(environ.__getitem__('AUTHOR_NAME'), os.environ['AUTHOR_NAME'])

    # os.environ returns values as bytes, so on Python3, this is the same as os.environ
    if PY3:
        test_equal(environ.__getitem__('AUTHOR_NAME'), os.environ['AUTHOR_NAME'])

    test_equal(environ.__getitem__('AUTHOR_NAME'), os.environ['AUTHOR_NAME'].decode('utf-8'))

    # Set the environment variable to utf-8 text
    os.environ

# Generated at 2022-06-11 18:21:32.251230
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test plain case
    os.environ[b'a'] = b'b'
    assert os.environ.get(b'a') == b'b'
    assert environ.get(b'a') == u'b'

    # Test case where the byte string has a different unicode decoded string
    os.environ[b'a'] = b'\xc3\xbf'
    assert os.environ.get(b'a') == b'\xc3\xbf'
    assert environ.get(b'a') == u'\ufffd'

    # Test case with a different encoding
    os.environ[b'a'] = b'b'
    environ = _TextEnviron(encoding='cp437')
    assert os.environ.get(b'a') == b'b'


# Generated at 2022-06-11 18:21:39.719232
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    with pytest.raises(KeyError):
        assert environ['__unknown_var__']

    # check that set item works with Unicode value
    environ['__test_var__'] = u'♞☭♘♜♝♛♚♝'
    assert environ['__test_var__'] == u'♞☭♘♜♝♛♚♝'

    # check that set item works with bytes value

# Generated at 2022-06-11 18:21:44.048342
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # unicode string to utf-8 bytes and then back to unicode
    assert environ['UNICODE_KEY'] == u'Здравствуйте'
    # encode to utf-8 using surrogateescape
    assert environ['NONASCII_KEY'] == u'\ud800 \uffff'

# Generated at 2022-06-11 18:21:47.905325
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Arrange
    environ['__test_key__'] = to_bytes('test_value', encoding='utf-8',
                                       nonstring='strict', errors='surrogate_or_strict')

    # Act
    value = environ['__test_key__']

    # Assert
    assert value == 'test_value'
    del environ['__test_key__']


# Generated at 2022-06-11 18:21:56.043058
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import iteritems

    utf8_values = {'python3_env': u'Германия'}
    cp1251_values = {'python2_env': u'Россия', 'broken_utf8': b'\xd0\x9f\xd0\xb5\xd1\x80\xd1\x84\xd0\xb5\xd0\xba\xd1\x82'}
    mixed_values = {'utf8_env': u'Россия', 'latin1_env': b'Brasil'}

    #
    # Check that all values are text
    #

# Generated at 2022-06-11 18:22:00.654253
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # set envrionment variable
    environ['test_env'] = 'test_value'

    # test that method __getitem__ of class _TextEnviron returns correct value
    assert(environ['test_env'] == 'test_value')

    # delete environement variable
    del environ['test_env']


# Generated at 2022-06-11 18:22:06.675632
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Tests whether __getitem__ works as expected.

    In particular, this tests that querying the same environment variable twice
    results in two valid strings, even if the value of the environment variable
    changes in the middle.
    """
    from ansible_collections.community.general.tests.unit.compat import unittest

    # Try changing a variable before and after the first getitem
    environ = _TextEnviron({b'TEST_VAR': 'initial value'}, encoding='utf-8')
    assert environ['TEST_VAR'] == u'initial value'
    environ['TEST_VAR'] = 'new value'
    assert environ['TEST_VAR'] == u'new value'

    # Try changing a variable in the middle of a getitem

# Generated at 2022-06-11 18:22:11.723584
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an instance of _TextEnviron
    environ = _TextEnviron()

    assert 'HOME' in environ
    assert '/home/toshio' == environ['HOME']

# Generated at 2022-06-11 18:22:20.526103
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_os_environ = {'latin1': '\xe0',           # Latin1 encoded (iso8859-1) byte string
                       'utf8': '\xe0'.encode('utf8'),  # UTF-8 encoded byte string
                       'utf8_with_surrogates': '\xff'.encode('utf8')}  # UTF-8 encoded byte string with surrogates
    test_encoding = 'iso8859-1'

    # Create an instance of _TextEnviron pointing to the test os.environ dictionary and using the
    # test encoding
    text_environ = _TextEnviron(test_os_environ, encoding=test_encoding)

    # Latin1 encoded (iso8859-1) byte string should be converted using _TextEnviron.encoding

# Generated at 2022-06-11 18:22:31.292593
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test data/values
    # This flag is used to switch between Py2 and Py3 tests
    flag_py3 = False

    # Test setup
    if flag_py3:
        PY3 = True
        str_encoding = 'utf-8'
        str_initial = 'str_value'
        str_encoded = b'str_value'
    else:
        PY3 = False
        str_encoding = 'utf-8'
        str_initial = b'str_value'
        str_encoded = b'str_value'

    # Test steps and verification assertions
    # Support for non ascii characters
    my_environ = _TextEnviron()
    my_environ['key'] = str_initial
    assert my_environ['key'] == 'str_value'



# Generated at 2022-06-11 18:22:40.180420
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # The environment needs to be reset before every test because the code under test will mutate
    # data
    env = {'strings': 'test', 'unicode': '⚡'}
    environ._raw_environ = env
    environ._value_cache = {}

    if PY3:
        # On Python3, the results should be the same as the input
        assert environ['strings'] is env['strings']
        assert environ['unicode'] is env['unicode']
    else:
        # On Python2, the byte strings should be decoded to text
        assert environ['strings'] == to_text(env['strings'])
        assert environ['unicode'] == to_text(env['unicode'])
        # And the byte strings should be cached based on the input
        assert env['strings'] in environ._

# Generated at 2022-06-11 18:22:43.180501
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    result_len = len(environ)
    value = environ.__getitem__('LANG')
    assert environ.__getitem__('LANG') == value
    assert len(environ) == result_len

# Generated at 2022-06-11 18:22:47.597765
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test that we can get unicode text back from environ for a unicode varname
    """
    env = _TextEnviron({to_bytes('δ'): to_bytes('∂')})
    assert env['δ'] == '∂'

# Generated at 2022-06-11 18:22:59.848774
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = {b'A': 1, b'B': 2}
    env = _TextEnviron(env=test_environ, encoding='utf-8')
    # test for key 'A'
    enc_key = to_bytes(u"A", 'utf-8')
    test_value = int(to_text(test_environ[enc_key], 'utf-8'))
    test_result = int(env[u"A"])
    assert test_result == test_value

    # test for key 'B'
    enc_key = to_bytes(u"B", 'utf-8')
    test_value = int(to_text(test_environ[enc_key], 'utf-8'))
    test_result = int(env[u"B"])
    assert test_result == test

# Generated at 2022-06-11 18:23:02.328261
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # given
    env = _TextEnviron()

    # when
    result = env['LC_ALL']

    # then
    assert result == os.environ['LC_ALL']

# Generated at 2022-06-11 18:23:04.469357
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Check if the environment variable is of text type
    assert isinstance(environ['PATH'], str)

# Generated at 2022-06-11 18:23:15.043457
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Some of the tests in this function are inspired by unittests on Python 3.5
    # Standard library. See https://github.com/python/cpython/blob/3.5/Lib/test/test_os.py

    # Test that passing a lambda through the environ is possible
    # from https://github.com/python/cpython/blob/3.5/Lib/test/test_os.py
    if PY3:
        # We can't test this on Py2 because the result is bytes
        assert environ[(lambda: b'TESTVAR')()] == ''
    # Test that exception is raised if the passed value is not a string
    with raises(TypeError):
        environ[123]

    # Test that surrogate pass in the environment are escaped
    # from https://github.com/python/cpython

# Generated at 2022-06-11 18:23:27.476459
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    org_environ = os.environ

# Generated at 2022-06-11 18:23:36.382890
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes
    os.environ['plain'] = 'Hello'
    os.environ['bytes'] = to_bytes(b'\xAC\xED\x00\x05')
    os.environ['unicode'] = to_bytes('\u0905')

# Generated at 2022-06-11 18:23:45.133059
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(env={}, encoding='utf-8')

# Generated at 2022-06-11 18:23:47.514911
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['foo'] = b'bar'
    assert environ['foo'] == 'bar'

    environ['bar'] = b'123'
    assert environ['bar'] == '123'

    environ['foo'] = b'bar'
    assert environ['foo'] == 'bar'

# Generated at 2022-06-11 18:23:54.585585
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import tests.unit.module_utils.test_common_collections as test_colect

    @test_colect.patch_ansible_module
    def test(ansible_module_mock):
        test_env = {'STRAIGHT_ASCII': 'value1', 'NON_ASCII': 'val\xc2\xa2ue2'.encode('utf-8')}
        environ = _TextEnviron(test_env)

        assert environ['STRAIGHT_ASCII'] == 'value1'
        assert environ['NON_ASCII'] == 'val\xc2\xa2ue2'

# Generated at 2022-06-11 18:23:56.247003
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PYTHONIOENCODING'] == u'UTF-8'

# Generated at 2022-06-11 18:24:04.232899
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    raw_environ = {u'unicode': u'unicode',
                   u'bytes': b'bytes',
                   u'bytes_decoded': b'bytes_decoded'.decode('utf-8'),
                   u'nonstring': 10,
                   u'ascii_bytes': b'ascii_bytes',
                   u'latin1_bytes': b'latin1_bytes',
                   b'bytes': b'bytes',
                   'bad_utf8_bytes': b'bad\xff_bytes',
                   'bad_utf8_bytes_decoded': b'bad\xff_bytes_decoded'.decode('utf-8'),
                   'ascii_bytes': b'ascii_bytes',
                   'latin1_bytes': b'latin1_bytes'}

# Generated at 2022-06-11 18:24:12.036879
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test a simple key, value pair
    assert environ['HOME'] == os.environ['HOME']
    # Test a key with a unicode codepoint with no encoding (checks surrogateescape error handling)
    assert environ['HOME'] == os.environ['HOME']
    # Test a unicode variable with an encoding
    os.environ['üñîçøðé_string'] = u'üñîçøðé_string'.encode('utf-8')
    assert environ['üñîçøðé_string'] == os.environ['üñîçøðé_string']



# Generated at 2022-06-11 18:24:22.627573
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import test.support

    # Test for Python2:
    if not PY3:
        # Test that we cannot set the environment to a text string
        test.support.unsetenv('PYTHON_TEST_ENV_VAR')
        try:
            os.environ['PYTHON_TEST_ENV_VAR'] = 'a test string'
        except UnicodeDecodeError:
            pass
        else:
            assert 0, "Failed to raise UnicodeDecodeError when assigning text string to os.environ"

        # Test that we can set the environment to a byte string
        os.environ['PYTHON_TEST_ENV_VAR'] = 'a test string'.encode('utf-8')

        # Test that we can fetch the value of an environment variable as a text string

# Generated at 2022-06-11 18:24:24.406412
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    assert env['PATH'] == os.environ['PATH']


# Generated at 2022-06-11 18:24:39.603994
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # _TextEnviron method __getitem__ (python2)
    if not PY3:
        os.environ = {'foo': u'bar'}
        # to_text called with encoding=utf-8
        assert to_text.called_once_with(
            u'bar', encoding=u'utf-8', nonstring='passthru', errors='surrogate_or_strict')
        # to_text called with encoding=utf-16
        os.environ = {'foo': u'bar'}
        environ = _TextEnviron(encoding='utf-16')
        to_text.reset_mock()
        environ['foo']

# Generated at 2022-06-11 18:24:49.826916
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test __getitem__ in class _TextEnviron
    """
    # Test for Python 2 without non-ascii characters
    if not PY3:
        fake_environ = {b'A': b'foo'}
        my_environ = _TextEnviron(env=fake_environ, encoding='utf-8')

        assert (u'foo' == my_environ[b'A'])
        assert (b'foo' == my_environ._raw_environ[b'A'])

    # Test for Python 2 with non-ascii characters
    if not PY3:
        fake_environ = {b'A': b'fo\xc3\xb3'}
        my_environ = _TextEnviron(env=fake_environ, encoding='utf-8')


# Generated at 2022-06-11 18:25:00.852433
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test the __getitem__ method of class _TextEnviron
    """
    environ._raw_environ = {}
    assert 'foo' not in environ
    assert environ._value_cache == {}
    environ._raw_environ = {b'foo': b'bar'}
    assert 'foo' in environ
    assert environ._value_cache == {b'bar': u'bar'}
    assert environ['foo'] == u'bar'
    environ._raw_environ = {b'foo': b'baz'}
    assert environ['foo'] == u'baz'
    environ._raw_environ = {b'foo': b'bar'}
    assert environ['foo'] == u'bar'
    environ._raw_environ = {}
    assert 'foo'

# Generated at 2022-06-11 18:25:11.998112
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Testing different types of keys
    expected = u'Key1 Foo'
    actual = environ[u'Key1']
    if actual != expected:
        raise AssertionError((expected, actual))
    actual = environ['Key1']
    if actual != expected:
        raise AssertionError((expected, actual))

    expected = u'Key2 Bar'
    actual = environ[u'Key2']
    if actual != expected:
        raise AssertionError((expected, actual))
    actual = environ['Key2']
    if actual != expected:
        raise AssertionError((expected, actual))

    # Testing existence of key in cache as well as get
    if 'Key2' in environ._value_cache:
        raise AssertionError('Cache contains key that we have not yet accessed in the usual way')

   

# Generated at 2022-06-11 18:25:19.469801
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    data = dict(KEY1='value1', KEY2='value2')
    environ = _TextEnviron(data)
    #
    # Test 1
    result = environ['KEY1']
    assert result == 'value1', 'Expected value1, got %s' % result
    #
    # Test 2
    result = environ['KEY2']
    assert result == 'value2', 'Expected value2, got %s' % result
    #
    # Test 3
    # Raise exception: key not found
    try:
        environ['KEY3']
    except KeyError:
        result = True
    assert result, 'Expected KeyError, no exception raised'


# Generated at 2022-06-11 18:25:29.880204
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This function is used for testing function __getitem__ of class _TextEnviron.
    try:
        from ansible.utils.unicode import to_unicode
    except ImportError:
        from ansible.module_utils.six import to_text as to_unicode

    assert isinstance(environ['Some_Random_Variable'], str)

    # Test values which are already unicode
    # The surrogate_or_strict error handler raises a UnicodeEncodeError for invalid unicode.
    # Since the value is already unicode, that error should be propagated

# Generated at 2022-06-11 18:25:35.285976
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = _TextEnviron({b'BASE': b'\xc3\xa9'}, 'utf-8')
    assert test_environ['BASE'] == 'é'
    assert test_environ[b'BASE'] == 'é'
    assert isinstance(test_environ['BASE'], str)
    assert isinstance(test_environ[b'BASE'], str)

# Generated at 2022-06-11 18:25:37.734779
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    _raw_environ = os.environ
    os.environ = {b'A': b'B'}
    assert env['A'] == 'B'
    os.environ = _raw_environ


# Generated at 2022-06-11 18:25:38.969124
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # TODO: Write mock tests for this method.
    pass


# Generated at 2022-06-11 18:25:49.350459
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest

    class _TextEnvironTestCase(unittest.TestCase):
        def setUp(self):
            self.env = _TextEnviron({b'foo': b'bar', 'baz': 'quux'})

        def test_py2_str(self):
            self.env['foo'] = 'baz'
            self.assertEqual(self.env['foo'], 'baz')

        def test_py2_bytes_ascii(self):
            self.env['foo'] = b'baz'
            self.assertEqual(self.env['foo'], 'baz')

        def test_py2_bytes_utf8(self):
            self.env['foo'] = b'\xc2\xa2'

# Generated at 2022-06-11 18:26:02.014967
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    d = {'key': 'value'}
    te = _TextEnviron(env=d, encoding='utf-8')
    assert te['key'] == u'value'
    assert isinstance(te['key'], str)


# Generated at 2022-06-11 18:26:05.425041
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Change the test environment for this test
    os.environ = {
        b'TEST_KEY': b'Test Value'
    }
    os.environ = _TextEnviron(env=os.environ)

    assert os.environ[b'TEST_KEY'] == u'Test Value'
    assert os.environ[u'TEST_KEY'] == u'Test Value'



# Generated at 2022-06-11 18:26:15.625242
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import io
    environ = _TextEnviron()
    environ._raw_environ = {
        'STR1': b'\xe4\xb8\xad\xe6\x96\x87',
        'STR2': b'\xff',
        'STR3': b'\xc3\xff',
        'STR4': b'\xff\xff',
        'STR5': b'\xc2\xff\xff',
    }
    # Check that we get encoded values for ASCII
    assert environ['STR1'] == '中文'
    # Check that we get surrogate_or_strict errors
    if PY3:
        surrogate_or_strict_error = UnicodeDecodeError
    else:
        surrogate_or_strict_error = UnicodeEncodeError

# Generated at 2022-06-11 18:26:25.725991
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    def fail(key):
        print('{} failed'.format(key))
        assert False

    environ[to_text(' asciikey ')] = to_bytes(' asciivalue ', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    assert environ[to_text(' asciikey ')] == to_text(' asciivalue ', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')

    environ[to_text(' utf8key ')] = to_bytes(' utf8value ', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')

# Generated at 2022-06-11 18:26:28.516204
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron({'foo': b'a'})
    assert isinstance(e['foo'], str)
    assert e['foo'] == 'a'



# Generated at 2022-06-11 18:26:39.066827
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ1 = _TextEnviron(env={'key': 'value'}, encoding='utf-8')
    assert environ1['key'] == environ['key']

    environ2 = _TextEnviron(env={'key': 'value'}, encoding='ascii')
    assert environ2['key'] == environ['key']

    environ3 = _TextEnviron(env={'key': 'value'}, encoding='cp037')
    assert environ3['key'] == environ['key']

    environ4 = _TextEnviron(env={'key': 'value'}, encoding='utf-8')
    assert environ4['key'] == environ['key']

    # because we use sys.getfilesystemencoding(), environ5 and environ6
    # should be different than environ4

# Generated at 2022-06-11 18:26:50.919384
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({'utf8': 'uñìcödé'}, encoding='utf-8')
    # Test a case where a value is not cached
    assert environ['utf8'] == 'uñìcödé'

    # Test a case where a value is cached
    assert environ['utf8'] == 'uñìcödé'

    # Test a case where an encoding error occurs
    if PY3:
        # Python3 doesn't use str.decode()
        assert environ['latin1'] == 'látín'
    else:
        assert environ['latin1'] == u'látín'

    # Test that the original value is returned if it is undecodable
    assert environ['undecodable'] == b'\xFF'



# Generated at 2022-06-11 18:27:00.424649
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # TODO: convert this to a unit test
    import os
    import sys
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    import io
    import io

    raw_environ = os.environ
    encoding = 'utf-8'
    value_cache = {}
    bytes_val = 'test'
    text_val = 'test'
    assert 'test' == to_text(bytes_val, encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict')
    if PY3:
        return value
    # Cache keys off of the undecoded values to handle any environment variables which change
   

# Generated at 2022-06-11 18:27:10.428239
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import sys
    from ansible.module_utils.six import PY2

    environ['test_getitem'] = 'žluťoučký kůň'

    if PY2:
        assert environ['test_getitem'] == u'\u017elu\u0165ou\u010dk\xfd k\u016f\u0148'
    else:
        # On Python3, the os module uses sys.getfilesystemencoding() to decode values it fetches
        # from the OS.  Mock that here
        assert environ['test_getitem'] == u'\u017elu\u0165ou\u010dk\xfd k\u016f\u0148'
        assert sys.getfilesystemencoding() == 'utf-8'

        #

# Generated at 2022-06-11 18:27:17.024462
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['foo'] = 'bar'
    assert environ['foo'] == 'bar'

    environ['foo'] = to_bytes('\xc3\xaf\xc2\xbb\xc2\xb7')  # UTF-8 encoding of 'ï»·'
    assert environ['foo'] == u'ï»·'

    del environ['foo']

# Generated at 2022-06-11 18:27:50.479023
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(encoding='utf-8')
    env['ascii'] = 'ascii'
    env['text_utf8'] = u'\u00e4\u00f6\u00fc\u00c4\u00d6\u00dc'
    env['text_unicode'] = u'\u00e4\u00f6\u00fc\u00c4\u00d6\u00dc'
    env['bytes_utf8'] = b'\xc3\xa4\xc3\xb6\xc3\xbc\xc3\x84\xc3\x96\xc3\x9c'

# Generated at 2022-06-11 18:27:54.390653
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['ANSIBLE_TEST_KEY'] = "Valeur à l'accent circonflexe"
    environ = _TextEnviron(encoding='utf-8')
    assert environ['ANSIBLE_TEST_KEY'] == "Valeur à l'accent circonflexe"

# Generated at 2022-06-11 18:27:55.913051
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['a'] = b'b'
    assert environ['a'] == 'b'

    environ['a'] = 'b'
    assert environ['a'] == 'b'

# Generated at 2022-06-11 18:27:57.858251
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    os.environ['HOME'] = 'foo'
    """
    test = _TextEnviron({'HOME': 'foo'})
    assert test['HOME'] == u'foo'
    assert test._value_cache[b'foo'] == 'foo'


# Generated at 2022-06-11 18:28:09.319317
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # set up
    from ansible.module_utils.six import PY3
    _environ = environ._raw_environ
    _environ['string'] = 'Hello world'
    _environ['bytes'] = b'Hello world'
    _environ['nonstring'] = {'hello': 'world'}
    # check str
    if PY3:
        assert _environ['string'] == 'Hello world'
    else:
        assert _environ['string'] == u'Hello world'
    # check bytes
    if not PY3:
        assert _environ['bytes'] == b'Hello world'
    else:
        assert _environ['bytes'] == 'Hello world'
    # check nonstring

# Generated at 2022-06-11 18:28:13.093868
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_env = _TextEnviron(encoding='utf-8')
    test_env['TEST'] = 'ünicode'
    assert to_text(test_env['TEST'], encoding='utf-8') == 'ünicode'


# Generated at 2022-06-11 18:28:16.547590
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = _TextEnviron({'foo': 'bar'})
    assert test_environ['foo'] == 'bar'
    assert type(test_environ['foo']) is str

# Generated at 2022-06-11 18:28:23.699125
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """ Make sure all the common scenarios work as expected """
    test_encoding = 'utf-8'

    # Test reading environment variables with common encodings

# Generated at 2022-06-11 18:28:34.860590
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text

    class _TextEnviron(MutableMapping):
        """
        Utility class to return text strings from the environment instead of byte strings

        Mimics the behaviour of os.environ on Python3
        """
        def __init__(self, env=None, encoding=None):
            if env is None:
                env = os.environ
            self._raw_environ = env
            self._value_cache = {}
            # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
            # instead of utf-8

# Generated at 2022-06-11 18:28:44.012321
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test handling of ASCII key and ASCII value with surrogate_or_strict errors
    # With surrogate_or_strict errors, surrogatehex string literal in python3
    # will be returned as the string literal itself.
    environ.__setitem__('python2_surrogatehex_entry', '\U0001F600')
    environ.__setitem__('python3_surrogatehex_entry', '\U0001F600')
    assert '\U0001F600' == environ.__getitem__('python2_surrogatehex_entry')
    assert '\U0001F600' == environ.__getitem__('python3_surrogatehex_entry')


# Generated at 2022-06-11 18:29:49.086714
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test setup
    import ansible.module_utils.common._collections_compat as collections_compat
    environ_bak = environ
    # Keep a mutable mapping installed as os.environ while we test
    environ = _TextEnviron(collections_compat.MutableMapping())

    # Test strings which are already in utf-8 (case insensitive ascii)
    environ['PATH'] = 'abc'
    assert environ['PATH'] == 'abc'

    # Test strings which are already in utf-8 (case sensitive ascii)
    environ['PATH'] = 'Abc'
    assert environ['PATH'] == 'Abc'

    # Test strings which are not in utf-8 (Latin-1)
    environ['PATH'] = '\xe1'

# Generated at 2022-06-11 18:29:59.697358
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    _TextEnviron.__getitem__(key=None)
    """
    # Get value by set in base
    default_os_environ = 'test'
    os.environ['default_os_environ'] = default_os_environ
    the_environ = _TextEnviron(env={})

    # The key is not in the dict
    key_not_in_dict = 'not_in_dict'
    value_not_in_dict = 'test_value'
    with pytest.raises(KeyError):
        the_environ[key_not_in_dict]
    the_environ[key_not_in_dict] = value_not_in_dict
    assert the_environ[key_not_in_dict] == value_not_in_dict

    # The key

# Generated at 2022-06-11 18:30:03.832460
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
  env = _TextEnviron()
  assert env['PATH'] == u'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
  assert env[b'PATH'] == u'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'


# Generated at 2022-06-11 18:30:09.458354
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Get a sample from utf-8 encoded
    test_dict = {'key1': 'value1', 'key2': '你好'.encode('utf-8'), 'key3': 'value3'}
    environ = _TextEnviron(test_dict)

    # Test if it works
    assert environ['key1'] == 'value1'
    assert environ['key2'] == '你好'
    assert environ['key3'] == 'value3'

    # Test if it works with non-unicode encoding as well
    environ = _TextEnviron(test_dict, 'gbk')
    assert environ['key1'] == 'value1'
    assert environ['key2'] == '你好'
    assert environ['key3'] == 'value3'

# Generated at 2022-06-11 18:30:16.964273
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
  # Verify correct conversion of value to text
  os.environ['TEST_BADGER']='Badger Badger Badger!'
  assert environ['TEST_BADGER']=='Badger Badger Badger!'

  # Verify that non-string keys generate KeyError exception
  try:
    environ[42]
  except KeyError:
    assert True
  else:
    assert False

  # Verify that non-existeant keys generate KeyError exception
  try:
    environ['Surrogate Badger']
  except KeyError:
    assert True
  else:
    assert False


# Generated at 2022-06-11 18:30:22.415021
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ["Z"] = "你好"
    assert environ["Z"] == u"你好"
    assert environ[b"Z"] == u"你好"
    assert environ[u"Z"] == u"你好"

if __name__ == '__main__':
    test__TextEnviron___getitem__()

# Generated at 2022-06-11 18:30:30.733878
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test normal getitem operation
    if 'ANSIBLE_TEST_ENV' in environ:
        del environ['ANSIBLE_TEST_ENV']

    if b'ANSIBLE_TEST_BYTES_ENV' in environ._raw_environ:
        del environ._raw_environ[b'ANSIBLE_TEST_BYTES_ENV']

    environ['ANSIBLE_TEST_ENV'] = 'foo'
    environ._raw_environ[b'ANSIBLE_TEST_BYTES_ENV'] = b'foo'

    assert environ['ANSIBLE_TEST_ENV'] == 'foo'
    assert environ['ANSIBLE_TEST_BYTES_ENV'] == 'foo'

    # Test error handling

# Generated at 2022-06-11 18:30:40.274753
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test the following cases:
    #   - Simple variable with no problems
    #   - Narrow python where variable has non-ascii value
    #   - Wide python where variable has non-ascii value
    #   - Value not in the cache since it was just added and also happens to be a unicode value
    #   - Empty variable
    #   - Python 2 where variable has surrogate encoding
    #   - Python 2 where variable has surrogate encoding and should be handled with surrogate_or_strict

    # Env variable with a "missing" surrogate unicode pair
    if PY3:
        os.environ['SURROGATE1'] = '\udc00\ud800'
    else:
        os.environ['SURROGATE1'] = '\ud800\udc00'

    # Env variable which contains a valid surrogate

# Generated at 2022-06-11 18:30:50.914621
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-11 18:31:01.529727
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import random
    import sys
    import string

    # FIXME: The cache is only populated when the items in this dict are gotten using __getitem__()
    # So if the dict ends up getting accessed through the dict interface instead of __getitem__()
    # the cache will have keys missing.
    # We should remove the cache and just use to_text() every time.  That should work well enough
    # The cache is only here because we're trying to mimic Python3 os.environ
    # But that wouldn't be an issue for this test
    env = _TextEnviron()
    # random.SystemRandom does not work on Windows
    if sys.platform == 'win32':
        generator = random.Random()
    else:
        generator = random.SystemRandom()
