

# Generated at 2022-06-21 08:56:01.220433
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({'KEY1': 'VALUE1', 'KEY2': 'VALUE2', 'KEY3': 'VALUE3'})
    del env['KEY2']
    assert 'KEY2' not in env

# Generated at 2022-06-21 08:56:05.265075
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    env["key"] = "value"
    assert to_text(os.environ["key"], encoding='utf-8', errors='surrogate_or_strict') == u"value"
    assert PY3 or env["key"] != os.environ["key"]


# Generated at 2022-06-21 08:56:08.228185
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron(env={'a': '1', 'b': '2', 'c': '3'})
    it = iter(env)
    assert next(it) == 'a'
    assert next(it) == 'b'
    assert next(it) == 'c'

# Generated at 2022-06-21 08:56:11.930788
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    text_environ = _TextEnviron(env={b"ANSIBLE_FOO": b"bar"})
    for k in text_environ:
        assert isinstance(k, text_type)

# Generated at 2022-06-21 08:56:21.454380
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from six.moves import cStringIO as StringIO
    from ansible.module_utils.common.collections import ImmutableDict
    # Create a test environ object
    environ = _TextEnviron(env=ImmutableDict({"key1": "value1", "key2": "value2", "key3": "value3"}))
    # Iterate over it and make sure that the iterator returns the keys
    # Use a StringIO object to capture the output
    output = StringIO()
    for item in environ:
        output.write(str(item))
    assert output.getvalue() == "key1key2key3"



# Generated at 2022-06-21 08:56:29.568225
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # environ is a global variable. We will keep its value and restore it in the end.
    old_environ = environ
    try:
        environ = _TextEnviron(env={'astring': '123', 'bytes': b'0123', 'text': u'0123', 'bad': b'\x80'})
        assert environ['astring'] == '123'
        assert environ['bytes'] == '0123'
        assert environ['text'] == '0123'
        raises(UnicodeDecodeError, lambda: environ['bad'])
    finally:
        environ = old_environ

# Generated at 2022-06-21 08:56:40.906594
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    class test_environ(MutableMapping):
        """
        Utility class to return text strings from the environment instead of byte strings

        Mimics the behaviour of os.environ on Python3
        """
        def __init__(self):
            self._raw_environ = {}
            self._value_cache = {}

        def __delitem__(self, key):
            del self._raw_environ[key]

        def __getitem__(self, key):
            value = self._raw_environ[key]
            if PY3:
                return value
            # Cache keys off of the undecoded values to handle any environment variables which change
            # during a run

# Generated at 2022-06-21 08:56:43.139157
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron()
    len_osenv = len(os.environ)
    len_environ = len(environ)
    assert len_environ == len_osenv


# Generated at 2022-06-21 08:56:49.991426
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron(encoding='utf-8')
    # Make sure we're getting bytes back from _raw_environ
    assert isinstance(env._raw_environ[b'PATH'], bytes)
    # Make sure we're getting unicode back from __getitem__
    assert isinstance(env['PATH'], str)

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-21 08:56:58.783686
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Note: No unit tests are needed for the other methods since they are trivial.  Python is also
    # happy to use unittests.TestCase so we'll just use that
    import unittest
    import unittest.mock


# Generated at 2022-06-21 08:57:03.765845
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Negative test: test for exception if _raw_environ passed to length function is not of type
    # dict
    e = _TextEnviron(env=1)
    try:
        len(e)
    except TypeError:
        pass
    else:
        raise Exception()



# Generated at 2022-06-21 08:57:04.393397
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    pass

# Generated at 2022-06-21 08:57:13.268979
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    try:
        # Test that we get a TypeError when we pass bad data to __setitem__
        environ['test'] = b'\x7f'
    except TypeError:
        print("test__TextEnviron___setitem__(): good, __setitem__() with non-text data raises "
              "TypeError")
    else:
        raise AssertionError("test__TextEnviron___setitem__(): bad, __setitem__() accepts non-text "
                             "data without raising TypeError")

    old_environ = os.environ
    try:
        os.environ = {'test': b'123'}
        environ['test'] = '456'
        assert os.environ['test'] == b'456'
    finally:
        os.environ = old_environ

# Generated at 2022-06-21 08:57:21.922455
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Test for _TextEnviron class
    """
    encoding = 'utf-8'
    text_environ = _TextEnviron(env={'PYTHONIOENCODING': 'utf-8'}, encoding=encoding)

    assert isinstance(text_environ._raw_environ, dict)
    assert encoding == text_environ.encoding
    assert to_text('utf-8', encoding=encoding, nonstring='passthru', errors='surrogate_or_strict') == text_environ['PYTHONIOENCODING']



# Generated at 2022-06-21 08:57:24.947323
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """
    raw_environ = dict()
    raw_environ['name'] = 'ALG\xc3\x89X'.encode('utf-8')
    text_env = _TextEnviron(env=raw_environ, encoding='utf-8')

    assert text_env['name'] == 'ALGÉX'


# Generated at 2022-06-21 08:57:35.044304
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test __getitem__ of _TextEnviron class.
    """
    env = _TextEnviron()
    env_dict = {to_bytes('key1', nonstring='strict'): to_bytes('value1', nonstring='strict'),
                to_bytes('key2', nonstring='strict'): to_bytes('value2', nonstring='strict'),
                }
    env._raw_environ = env_dict

    assert type(env['key1']) == type(u'')
    assert env['key1'] == to_text('value1', nonstring='passthru')
    assert type(env['key2']) == type(u'')
    assert env['key2'] == to_text('value2', nonstring='passthru')



# Generated at 2022-06-21 08:57:37.620521
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # setup
    env = _TextEnviron()

    # test
    assert type(env.__iter__()) is type(iter([]))



# Generated at 2022-06-21 08:57:39.088977
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ['TEST'] = 'Hello'
    assert len(environ) == len(os.environ) + 1


# Generated at 2022-06-21 08:57:41.030743
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    pass
    # assert len(environ) == 0


# Generated at 2022-06-21 08:57:45.994667
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    my_env = _TextEnviron(encoding='utf-8')
    my_env['one'] = '1'
    my_env['two'] = '2'
    assert my_env['one'] == '1'
    assert my_env['two'] == '2'
    assert len(my_env) == 2

# Generated at 2022-06-21 08:57:48.391897
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    pass

# Generated at 2022-06-21 08:57:52.093625
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Set up the input data
    os.environ['foo'] = 'bar'

    # Test the method under test
    del environ['foo']

    # Test the output data
    assert 'foo' not in environ


# Generated at 2022-06-21 08:58:00.168232
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from random import shuffle
    from string import ascii_lowercase
    from string import ascii_uppercase
    env = _TextEnviron()
    letters = list(ascii_lowercase)
    full_iter = True
    while letters:
        shuffle(letters)
        env.clear()
        env.update({k: k for k in letters})
        iter_letters = list(iter(env))
        iter_letters.sort()
        if iter_letters != letters:
            print('Wrong order in iteration of env: {0}'.format(iter_letters))
            full_iter = False
        letters.pop()
    # Now make sure that items are returned as unicode
    if PY3:
        letters = list(ascii_uppercase)

# Generated at 2022-06-21 08:58:11.970168
# Unit test for method __iter__ of class _TextEnviron

# Generated at 2022-06-21 08:58:21.236306
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # pylint: disable=invalid-name
    # pylint: disable=redefined-outer-name
    import pytest
    try:
        # This can only be fixed by
        # https://github.com/PyCQA/pylint/issues/2299
        environ[u'name']
    except TypeError:
        pytest.skip("This system doesn't support unicode keys in os.environ")

    environ[u'name'] = u'value'
    assert environ[u'name'] == u'value'

    environ[u'name'] = u'Значение'.encode('utf-8')
    assert environ[u'name'] == u'Значение'


# Generated at 2022-06-21 08:58:29.979523
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils.six import text_type

    c = _TextEnviron()
    # Test simple set
    c['foo'] = 'bar'
    assert c._raw_environ['foo'] == 'bar'
    # Test text type
    c['foo'] = text_type('bar')
    assert c._raw_environ['foo'] == 'bar'
    # Test non-ascii utf-8
    c['foo'] = u'\N{SNOWMAN}'
    assert c._raw_environ['foo'] == '\xe2\x98\x83'



# Generated at 2022-06-21 08:58:36.409900
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    CONST_KEY = 'KEY'
    CONST_VALUE = 'VALUE'
    CONST_VALUE_BYTES = b'VALUE'

    # ========================================================
    # PY3
    # ========================================================

    environ._raw_environ = {}
    environ.encoding = 'test_encoding'
    environ.__setitem__(CONST_KEY, CONST_VALUE)
    assert environ._raw_environ[CONST_KEY] == CONST_VALUE, "Failed _TextEnviron.__setitem__() in PY3, wrong type"
    assert environ._raw_environ[CONST_KEY] == CONST_VALUE_BYTES, "Failed _TextEnviron.__setitem__() in PY3, wrong content"

    # ========================================================
    #

# Generated at 2022-06-21 08:58:45.169448
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Return the number of items in the environment.
    """
    import os

    def clear_env():
        good_env = dict((k, v) for k, v in os.environ.items() if k not in ('LANG', 'LC_ALL', 'LC_CTYPE'))
        os.environ.clear()
        os.environ.update(good_env)
        # print("Env: %s" % os.environ)

    # Test empty environment
    clear_env()
    assert len(environ) == 0
    # print("Env: %s" % environ)

    # Test with a basic environment variable
    os.environ['test_var'] = 'test_var_value'
    assert len(environ) == 1
    # print("Env: %s" % en

# Generated at 2022-06-21 08:58:46.237172
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert environ



# Generated at 2022-06-21 08:58:54.286816
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    :rtype: str
    """
    r = 'test_data'
    e = _TextEnviron({b'test_key': b'test_data'}, encoding='utf-8')
    assert e['test_key'] == r, 'return value should be the plain text in environ'
    r = b'test_data'
    e = _TextEnviron({b'test_key': b'test_data'}, encoding='utf-8')
    assert e._raw_environ['test_key'] == r, 'return value should be the plain text in environ'

# Generated at 2022-06-21 08:59:09.507513
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os

    class _TestEnviron(MutableMapping):
        """
        Mock os.environ for testing
        """
        def __init__(self, test_values):
            self.test_values = test_values.copy()

        def __delitem__(self, key):
            del self.test_values[key]

        def __getitem__(self, key):
            return self.test_values[key]

        def __setitem__(self, key, value):
            self.test_values[key] = value

        def __iter__(self):
            return self.test_values.__iter__()

        def __len__(self):
            return len(self.test_values)

    # Test keys with null bytes

# Generated at 2022-06-21 08:59:11.577112
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    text_env = _TextEnviron(env={'test': 'value'})
    assert len(text_env) == 1


# Generated at 2022-06-21 08:59:21.511814
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test retrieving a byte string
    assert environ['PATH'] == to_text(os.environ['PATH'], encoding='utf-8', nonstring='passthru',
                                      errors='surrogate_or_strict')
    # Test retrieving a text string
    environ['ANSIBLE_TEST'] = b'Montr\xc3\xa9al'
    assert environ['ANSIBLE_TEST'] == to_text(b'Montr\xc3\xa9al', encoding='utf-8', nonstring='passthru',
                                              errors='surrogate_or_strict')
    del environ['ANSIBLE_TEST']


# Generated at 2022-06-21 08:59:30.769456
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # To test that our code works, we need to test against the actual environment.  But, our code
    # will change the environment by returning values in a different encoding.  To work around this,
    # we save the actual environment and write to a copy.
    import copy
    import os
    import tempfile

    old_environ = copy.deepcopy(os.environ)
    tmp_environ = copy.deepcopy(os.environ)

    # Test to see if we're handling non-strings/bytes as environment variables properly
    tmp_environ[b"ANSIBLE_TEST_INT_VAR"] = 1
    tmp_environ[b"ANSIBLE_TEST_UNICODE_VAR"] = '\u00a0'   # Unicode non-breaking space

# Generated at 2022-06-21 08:59:41.867399
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils._text import to_text
    x = _TextEnviron({b'foo': b'bar', u'baz': u'quux'})
    assert x[b'foo'] == 'bar'
    assert x[u'foo'] == 'bar'
    assert x[u'baz'] == 'quux'
    try:
        x[b'qux']
    except KeyError as exc:
        assert to_text(exc.args[0]) == 'qux'
    else:
        assert False, "Did not raise KeyError"

    try:
        x[u'qux']
    except KeyError as exc:
        assert to_text(exc.args[0]) == 'qux'
    else:
        assert False, "Did not raise KeyError"


# Generated at 2022-06-21 08:59:50.212461
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """
    Test that the __iter__ method of class TextEnviron returns an iterator
    equivalent to an iter() on os.environ
    """
    test_environ = _TextEnviron({b'somekey1': b'somevalue1', b'somekey2': b'somevalue2'})
    key_iter = test_environ.__iter__()
    assert type(key_iter) is type(iter(os.environ))
    assert list(key_iter) == ['somekey1', 'somekey2']



# Generated at 2022-06-21 08:59:58.293448
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This test is here instead of test/unit/module_utils/common/test_collections.py because
    # the collections compat code is only for Python2 and, even then, is only enabled if we
    # don't already have a collections.Mapping.  The test for collections.abc.Mapping is in
    # test/unit/module_utils/common/test_collections.py
    utf8_env = _TextEnviron(env={b'MESSAGE': b'\xef\xbb\xbfHello World'}, encoding='utf-8')
    assert utf8_env['MESSAGE'] == u'\ufeffHello World'


# Generated at 2022-06-21 09:00:04.441337
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    '''
    Ensure that the constructor for _TextEnviron returns the type we want.
    '''
    assert isinstance(environ, MutableMapping), 'Object from TextEnviron not a MutableMapping'
    assert isinstance(environ, _TextEnviron), 'Object from TextEnviron not a TextEnviron'


# Generated at 2022-06-21 09:00:13.927182
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    '''
    Object tests:
        Method __delitem__ of class _TextEnviron
    '''

    # Test environment variable
    variable = 'ANSIBLE_MODULE_TEST_VAR'

    # Test initial state - variable should not be defined
    try:
        _ = os.environ[variable]
    except KeyError:
        pass
    else:
        assert False

    # Test undefined variable
    try:
        del environ[variable]
    except KeyError:
        pass
    else:
        assert False

    # Test undefined variable in os.environ
    try:
        del os.environ[variable]
    except KeyError:
        pass
    else:
        assert False

    # Test defined variable
    environ[variable] = 'true'

# Generated at 2022-06-21 09:00:15.625313
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron(env={"test": "test"}, encoding='utf-8')
    assert list(environ) == ['test']

# Generated at 2022-06-21 09:00:25.227789
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Ensure that we can delete a key from the environment
    key = 'ANSIBLE_TEST_DELETE'
    old_value = None
    if key in environ:
        old_value = environ[key]
        del environ[key]
    try:
        assert key not in environ
    finally:
        if old_value:
            environ[key] = old_value


# Generated at 2022-06-21 09:00:33.678409
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ_mock = _TextEnviron()
    # Test pseudo-dictionary with 1 element
    environ_mock._raw_environ = {u'key1': u'value1'}
    assert 1 == len(environ_mock)
    # Test pseudo-dictionary with 3 elements
    environ_mock._raw_environ = {u'key1': u'value1', u'key2': u'value2', u'key3': u'value3'}
    assert 3 == len(environ_mock)
    # Test pseudo-dictionary with 0 elements
    environ_mock._raw_environ = {}
    assert 0 == len(environ_mock)



# Generated at 2022-06-21 09:00:38.940398
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpfile = os.path.join(tmpdir, 'tmpfile')
        orig_environ = os.environ.copy()
        os.environ['TEMPDIR'] = tmpdir
        os.environ['TMPFILE'] = tmpfile
        environ = _TextEnviron()
        assert os.environ['TEMPDIR'] == tmpdir
        assert os.environ['TMPFILE'] == tmpfile
        del environ['TEMPDIR']
        assert os.environ['TEMPDIR'] != tmpdir
        assert os.environ['TMPFILE'] == tmpfile
        os.environ = orig_environ



# Generated at 2022-06-21 09:00:42.007371
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    t = _TextEnviron({'a': 'b'})
    assert 'a' in t
    t.__delitem__('a')
    assert 'a' not in t


# Generated at 2022-06-21 09:00:45.095281
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ.clear()
    environ['abc'] = '123'
    assert environ['abc'] == '123'



# Generated at 2022-06-21 09:00:46.219741
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    _TextEnviron(encoding='utf-8')

# Generated at 2022-06-21 09:00:54.117744
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os.environ["AAA"] = "bbb"
    assert(len(environ) == 1)
    assert(set(environ) == {'AAA'})
    assert(list(environ) == ['AAA'])
    assert(set(environ.keys()) == {'AAA'})
    assert(list(environ.keys()) == ['AAA'])
    assert(set(environ.values()) == {'bbb'})
    assert(list(environ.values()) == ['bbb'])
    assert(set(environ.items()) == {('AAA', 'bbb')})
    assert(list(environ.items()) == [('AAA', 'bbb')])


# Generated at 2022-06-21 09:00:55.009734
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _TextEnviron.__delitem__()


# Generated at 2022-06-21 09:01:01.181739
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an instance of environ
    env = _TextEnviron()

    # Assign a text value to the key "test_key" in env
    env['test_key'] = 'test_value'

    # Test if key "test_key" exists in env
    assert 'test_key' in env

    # Test if the value assigned to "test_key" is the same as expected
    assert env['test_key'] == 'test_value'



# Generated at 2022-06-21 09:01:12.324703
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # string
    for s in ['abc', 'xyz']:
        environ['test'] = s
        assert environ['test'] == s
    # int
    for s in [10, 15]:
        environ['test'] = s
        assert environ['test'] == str(s)
    # float
    for s in [10.1, 15.1]:
        environ['test'] = s
        assert environ['test'] == str(s)
    # u''
    for s in [u'abc', u'xyz']:
        environ['test'] = s
        assert environ['test'] == s
    # 'u'a'
    for s in [u'a', u'b', u'c']:
        environ['test'] = 'u' + s
        assert environ['test']

# Generated at 2022-06-21 09:01:35.359114
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    _os_environ = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    _environ = _TextEnviron(env=_os_environ)
    assert len(_environ) == len(_os_environ)



# Generated at 2022-06-21 09:01:40.056879
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    old_environ = os.environ
    os.environ = {'LANG': 'en_US.utf8'}

    global environ
    environ = _TextEnviron(encoding='utf-8')

    t = environ['LANG']
    assert t == u'en_US.utf8'

    del environ['LANG']

    assert os.environ['LANG'] == u''

    os.environ = old_environ


# Generated at 2022-06-21 09:01:47.251938
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    my_environ = _TextEnviron()

    k = 'TestK'
    v = 'TestV'
    my_environ[k]=v
    my_environ['TestK']
    del my_environ[k]
    try:
        my_environ['TestK']
    except KeyError:
        # KeyError because key was deleted
        pass
    else:
        assert False, 'should have thrown KeyError because key was deleted'



# Generated at 2022-06-21 09:01:51.772255
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({'ascii': 'foo', 'unicode': u'bar'})
    assert 'foo' == env['ascii']
    assert u'bar' == env['unicode']
    del env['ascii']
    assert 'ascii' not in env
    del env['unicode']
    assert 'unicode' not in env


# Generated at 2022-06-21 09:02:01.953879
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import unittest

    class TestEnvironInitialization(unittest.TestCase):
        class TestNormalInit(unittest.TestCase):
            def test_no_args(self):
                '''Test default arguments'''
                env = _TextEnviron()
                self.assertIs(env._raw_environ, os.environ)
                self.assertEqual(env._value_cache, {})
                self.assertEqual(env.encoding, sys.getfilesystemencoding())

            def test_with_raw_environ(self):
                '''Test accepting raw_environ'''
                raw_environ = {}
                env = _TextEnviron(env=raw_environ)
                self.assertIs(env._raw_environ, raw_environ)

# Generated at 2022-06-21 09:02:11.383479
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    if PY3:
        env = {}
    else:
        env = {to_bytes('foo'): to_bytes('bar', encoding='ascii')}
        env[to_bytes('ƒØø', encoding='utf-8')] = to_bytes('bar', encoding='ascii')

    te = _TextEnviron(env)
    assert te['foo'] == u'bar'
    assert te[to_bytes('ƒØø', encoding='utf-8')] == u'bar'

    new_env = {'foo': 'baz'}
    te = _TextEnviron(new_env)
    assert te[u'foo'] == u'baz'
    te[u'ƒØø'] = 'baz'

# Generated at 2022-06-21 09:02:20.998224
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test that calling .__setitem__ with a unicode string will not raise a TypeError
    environ['test_key_1'] = u'This is a unicode string'

    # Test that calling .__setitem__ with a bytestring will not raise a TypeError
    environ['test_key_2'] = b'This is a bytestring'

    # Test that calling .__setitem__ with a non-string object will raise a TypeError
    try:
        environ['test_key_3'] = object()
    except TypeError:
        pass
    else:
        assert False, 'Calling environ.__setitem__ with a non-string object should have raised a TypeError.'

# Generated at 2022-06-21 09:02:29.533328
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ.clear()
    os.environ['text_key'] = 'foo'
    os.environ['byte_key'] = b'foo'
    os.environ['unicode_key'] = u'foo'
    os.environ['broken1_key'] = b'foo\xff'
    os.environ['broken2_key'] = u'foo\ufffd'
    assert environ['text_key'] == 'foo'
    assert environ['byte_key'] == u'foo'
    assert environ['unicode_key'] == u'foo'
    assert environ['broken1_key'] == u'foo\ufffd'
    assert environ['broken2_key'] == u'foo\ufffd'



# Generated at 2022-06-21 09:02:39.719760
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # create a temporary _TextEnviron instance to run tests
    _environ = _TextEnviron()

    # test passing a string
    _environ['a'] = 'b'
    assert _environ._raw_environ['a'] == b'b'
    assert _environ._value_cache == {}
    assert _environ['a'] == 'b'
    assert _environ._value_cache == {'b': 'b'}

    # test passing an invalid string
    _environ['a'] = '\x80'
    assert _environ._raw_environ['a'] == b'\xc3\x80'
    assert _environ._value_cache == {'b': 'b'}
    assert _environ['a'] == '\x80'

# Generated at 2022-06-21 09:02:42.310063
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ = _TextEnviron(env={"FOO": "foo"})
    del environ["FOO"]
    assert len(environ.keys()) == len(os.environ.keys())


# Generated at 2022-06-21 09:03:29.746876
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert sorted(os.environ.keys()) == sorted(environ.keys())



# Generated at 2022-06-21 09:03:35.754064
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()

    # Set item using a unicode string
    env['foo'] = '\x00\u00FF'
    assert len(env) == 1
    assert env['foo'] == '\x00\u00FF'

    # Set item using a byte string
    env['foo'] = b'\x00\xFF'
    assert len(env) == 1
    assert env['foo'] == '\x00\xFF'

    # Set item using a non-string value
    env['foo'] = 5
    assert len(env) == 1
    assert env['foo'] == '5'

# Generated at 2022-06-21 09:03:44.260229
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Reset environ as it is already populated with some data.
    environ = _TextEnviron()
    assert len(environ) == 0
    environ['http_proxy'] = 'http://proxy.example.com:3128'
    assert len(environ) == 1
    environ['pwd'] = '/home/ansible/wrk/ansible-test/targets'
    assert len(environ) == 2
    # Deleting an item
    del environ['http_proxy']
    assert len(environ) == 1
    del environ['pwd']
    assert len(environ) == 0


# Generated at 2022-06-21 09:03:48.852839
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _environ = _TextEnviron()
    os.environ[to_bytes('tést', encoding='utf-8')] = b'value'
    assert 'tést' in _environ
    del _environ['tést']
    assert 'tést' not in _environ


# Generated at 2022-06-21 09:03:52.401367
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ.clear()
    environ['test_key1'] = 'test_val1'
    del environ['test_key1']
    assert environ.get('test_key1') is None, "_TextEnviron.__delitem__ did not delete key from environment"


# Generated at 2022-06-21 09:03:53.874823
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    x = _TextEnviron()
    x.__delitem__(0)


# Generated at 2022-06-21 09:04:04.400544
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # pylint: disable=no-member
    # Constructor
    env = _TextEnviron()
    assert env._raw_environ is os.environ
    assert env._value_cache == {}
    assert sys.getfilesystemencoding() == env.encoding

    env = _TextEnviron(encoding='ascii')
    assert env._raw_environ is os.environ
    assert env._value_cache == {}
    assert 'ascii' == env.encoding

    fake_env = {'fake': 'spam'}
    env = _TextEnviron(env=fake_env, encoding='ascii')
    assert fake_env == env._raw_environ
    assert env._value_cache == {}
    assert 'ascii' == env.encoding
    # pylint: enable=

# Generated at 2022-06-21 09:04:07.105392
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron({b'str': 'str'}, encoding='ascii')
    assert env[b'str'] == u'str'


# Generated at 2022-06-21 09:04:16.400091
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Make a reference _TextEnviron object
    refenviron = _TextEnviron({b'VAR1': b'VALUE1', b'VAR2': b'VALUE2'}, encoding='utf-8')
    # Make a _TextEnviron object to be tested
    testenviron = _TextEnviron({b'VAR1': b'VALUE1', b'VAR2': b'VALUE2'}, encoding='utf-8')

    # Ensure the tested _TextEnviron object returns the expected values
    assert refenviron['VAR1'] == 'VALUE1'
    assert refenviron['VAR2'] == 'VALUE2'
    assert testenviron['VAR1'] == 'VALUE1'
    assert testenviron['VAR2'] == 'VALUE2'

    # Ensure the tested _TextEnviron object cached the expected values
   

# Generated at 2022-06-21 09:04:19.462367
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ["test_key"] = "test_value"
    assert environ["test_key"] == "test_value"
    del environ["test_key"]
    try:
        value_in_environ = environ["test_key"]
        assert False
    except KeyError:
        assert True

