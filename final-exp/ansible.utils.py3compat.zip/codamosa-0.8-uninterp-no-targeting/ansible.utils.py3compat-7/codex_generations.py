

# Generated at 2022-06-21 08:56:00.544578
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    iter_env=_TextEnviron()
    assert(iter_env.__iter__() == os.environ.__iter__())


# Generated at 2022-06-21 08:56:09.162485
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import pytest

    text = to_bytes('日本語', encoding='cp932')
    try:
        unicode('日本語')
    except NameError:
        expected = text
    else:
        expected = '日本語'

    # Test constructor with valid arguments
    encoding = 'cp932'
    if PY3:
        # In Python3, os.environ returns utf-8 by default.  It uses the locale to figure out
        # what encoding the environment variables are in.
        encoding = 'utf-8'
    os.environ[text] = text
    environ = _TextEnviron(env=os.environ, encoding=encoding)
    assert expected == environ[text]

    # Test constructor with invalid arguments

# Generated at 2022-06-21 08:56:11.760398
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
  # Test if the result of function __iter__ is a list
  assert isinstance(list(environ), list) == True


# Generated at 2022-06-21 08:56:15.693026
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    try:
        del environ['ANSIBLE_PYTHON_INTERPRETER']
    except KeyError:
        pass
    assert 'ANSIBLE_PYTHON_INTERPRETER' not in environ


# Generated at 2022-06-21 08:56:18.006063
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    try:
        len(environ)
    except NotImplementedError:
        return False
    else:
        return True


# Generated at 2022-06-21 08:56:19.178097
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    env = _TextEnviron()
    del env["test_str_key"]
    assert "test_str_key" not in env



# Generated at 2022-06-21 08:56:22.311162
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['PYTHONIOENCODING'] = 'utf-8'
    assert environ['PYTHONIOENCODING'] == 'utf-8'

# Generated at 2022-06-21 08:56:25.936434
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ.clear()
    environ["foo"]="bar"
    environ["baz"]="bam"
    l=list(environ)
    assert "foo" in l
    assert "baz" in l


# Generated at 2022-06-21 08:56:28.961400
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['tmp'] = 'tmp'
    assert 'tmp' in environ
    assert environ['tmp'] == 'tmp'
    del environ['tmp']
    assert 'tmp' not in environ


# Generated at 2022-06-21 08:56:40.013878
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils._text import to_bytes
    te = _TextEnviron(env={b'key': b'value'})
    assert to_bytes('key') in te
    assert 'key' in te
    assert te[b'key'] == 'value'
    assert te[to_bytes('key')] == 'value'
    assert to_bytes('key') in te._raw_environ
    assert te._raw_environ[b'key'] == b'value'
    assert te._raw_environ[to_bytes('key')] == b'value'
    te[b'key'] = 'value1'
    assert te[b'key'] == 'value1'
    assert te[to_bytes('key')] == 'value1'

# Generated at 2022-06-21 08:56:45.618371
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """Unit test the constructor of class _TextEnviron."""
    environ = _TextEnviron({'key': 'value'})
    assert environ['key'] == u'value'



# Generated at 2022-06-21 08:56:48.481360
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    var = "test_key"
    val = "test_value"
    environ[var] = val
    assert environ[var] == val



# Generated at 2022-06-21 08:56:57.790859
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = {b'key': b'value'}
    environ = _TextEnviron(env=env, encoding='utf-8')
    assert environ['key'] == u'value'

    environ = _TextEnviron(env=env, encoding='latin-1')
    assert environ['key'] == u'value'

    environ = _TextEnviron(env=env, encoding='utf-16')
    assert environ['key'] == u'value'

    # Test that the conversion works with an invalid value in the environment
    env = {b'key': b'\xff\xff'}
    environ = _TextEnviron(env=env, encoding='latin-1')
    assert environ['key'] == u'\ufffd\ufffd'

    # Non-compatible encoding

# Generated at 2022-06-21 08:57:07.808223
# Unit test for method __iter__ of class _TextEnviron

# Generated at 2022-06-21 08:57:10.470668
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    _TextEnviron.__len__ should always return the same value as os.environ.__len__
    """
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 08:57:14.032881
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['FOO'] = 'bar'
    assert 'FOO' in environ
    assert environ['FOO'] == u'bar'

    del environ['FOO']
    assert 'FOO' not in environ


# Generated at 2022-06-21 08:57:17.206936
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron(encoding='utf-8')
    assert list(iter(environ)) == list(iter(os.environ))

# Generated at 2022-06-21 08:57:28.648279
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Test for method __setitem__ of class _TextEnviron
    :return:
    """
    # Test example 1:
    x = _TextEnviron()
    x['test_int'] = 1
    assert(x['test_int'] == b'1')

    # Test example 2:
    x['test_str'] = '1'
    assert(x['test_str'] == b'1')

    # Test example 3:
    x['test_str_unicode'] = to_text('\u03b3', encoding='utf-8')
    assert(x['test_str_unicode'] == b'\xce\xb3')

    # Test example 4:
    x['test_int_unicode'] = to_text(u'\u03b3', encoding='utf-8')

# Generated at 2022-06-21 08:57:34.810198
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Test that the os.environ class is compatible with a _TextEnviron class
    env_copy = os.environ.copy()
    env_copy[b'ANSIBLE_TEST_ENV_VAR'] = b'foobar'

    text_env = _TextEnviron(env=env_copy)
    for key, value in text_env.items():
        assert isinstance(key, str)
        assert isinstance(value, str)
        assert key == to_text(key)
        assert value == to_text(value)

# Generated at 2022-06-21 08:57:39.025154
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test __getitem__ of class _TextEnviron
    env = _TextEnviron({b'foo': b'bar', b'ansible_python_interpreter': u'/usr/bin/python3.4'})
    assert env['foo'] == 'bar', env['foo']
    assert env['ansible_python_interpreter'] == u'/usr/bin/python3.4', env['ansible_python_interpreter']
    return True


# Generated at 2022-06-21 08:57:41.918173
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['SPAM'] == b'eggs'


# Generated at 2022-06-21 08:57:43.563191
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    result = environ['HOME']
    assert result == '/home/thebadger'

# Generated at 2022-06-21 08:57:51.692945
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['test__TextEnviron___delitem__'] = 'test__TextEnviron___delitem__'
    assert environ['test__TextEnviron___delitem__'] == 'test__TextEnviron___delitem__'
    del environ['test__TextEnviron___delitem__']
    try:
        value = os.environ['test__TextEnviron___delitem__']
        assert False, 'setting environ["test__TextEnviron___delitem__"] did not raise an exception'
    except KeyError:
        pass


# Generated at 2022-06-21 08:57:58.004668
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env1 = os.environ
    env2 = _TextEnviron(env1)
    pos = 0
    for k in env1:
        k1 = env1[k]
        k2 = env2[k]
        if PY3:
            assert(k1 == k2)
        else:
            assert(type(k1) == bytes)
            assert(isinstance(k2, text_type))
            assert(k1 == k2.encode('utf-8'))


# Generated at 2022-06-21 08:58:09.606436
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Unit test for class _TextEnviron.__delitem__
    """
    temp_environ = _TextEnviron()
    temp_environ['pk'] = 'pv'
    temp_environ['pk2'] = 'pv2'
    temp_environ['pk3'] = 'pv3'

    assert temp_environ['pk'] == 'pv'
    assert temp_environ['pk2'] == 'pv2'
    assert temp_environ['pk3'] == 'pv3'

    del temp_environ['pk2']

    assert temp_environ['pk'] == 'pv'
    assert 'pk2' not in temp_environ

    del temp_environ['pk3']


# Generated at 2022-06-21 08:58:14.567513
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ.clear()
    os.environ['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'
    assert 'ANSIBLE_TEST_KEY' in environ
    del environ['ANSIBLE_TEST_KEY']
    assert 'ANSIBLE_TEST_KEY' not in environ


# Generated at 2022-06-21 08:58:18.644213
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron(encoding='utf-8')
    env['baz'] = '{"bar": "\xe9", "foo": "123"}'
    assert to_bytes(env['baz'], encoding='utf-8') == b'{"bar": "\xc3\xa9", "foo": "123"}'

# Generated at 2022-06-21 08:58:30.436124
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class _TestEnviron:
        def __getitem__(self, key):
            return key

    environ = _TextEnviron(_TestEnviron(), encoding='us-ascii')
    assert environ["abc"] == u"abc"
    assert type(environ["abc"]) == str
    environ = _TextEnviron(_TestEnviron(), encoding='utf-8')
    assert environ[b"abc"] == u"abc"
    assert type(environ[b"abc"]) == str
    environ = _TextEnviron(_TestEnviron(), encoding='latin-1')
    assert environ[b"abc"] == u"abc"
    assert type(environ[b"abc"]) == str
    environ = _TextEnviron(_TestEnviron(), encoding='utf-16')

# Generated at 2022-06-21 08:58:36.706476
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """
    os.environ['test'] = b'bytes'
    environ['test'] = b'bytes'
    assert isinstance(environ['test'], str)
    assert environ['test'] == 'bytes'

    os.environ['test'] = b'\xE9'
    environ['test'] = b'\xE9'
    assert isinstance(environ['test'], str)
    assert environ['test'] == b'\xE9'.decode('utf-8')

    os.environ['test'] = b'\xE9\xE9'
    environ['test'] = b'\xE9\xE9'
    assert isinstance(environ['test'], str)

# Generated at 2022-06-21 08:58:45.325274
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    data = {'one': '1', 'two': '2', 'three': '3'}
    env = _TextEnviron(data)
    assert env['one'] == u'1'
    assert env['two'] == u'2'
    assert env['three'] == u'3'

    env = _TextEnviron()
    assert env['one'] == u'1'
    assert env['two'] == u'2'
    assert env['three'] == u'3'

    if not PY3:
        # test RAW environment variables
        data = {'one': u'1'.encode('utf-8'), 'two': u'2'.encode('utf-8'),
                'three': u'3'.encode('utf-8')}
        env = _TextEnviron(data, encoding='utf-8')
       

# Generated at 2022-06-21 08:58:54.623535
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # All variables set must be of type str
    test_environ = _TextEnviron()

    test_environ['key1'] = u'value1'
    if PY3:
        assert type(test_environ['key1']) is str
    else:
        assert type(test_environ['key1']) is unicode

    test_environ['key2'] = b'value2'
    assert type(test_environ['key2']) is str

    test_environ['key3'] = 0
    assert type(test_environ['key3']) is str

# Generated at 2022-06-21 08:59:00.379114
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ["test"] = "test"
    environ = _TextEnviron(env={"test": "test"}, encoding='utf-8')
    assert type(environ["test"]) == type(os.environ["test"])
    assert environ["test"] == os.environ["test"]

# Generated at 2022-06-21 08:59:05.931914
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['ansible_test'] = 'test'
    assert isinstance(environ._raw_environ['ansible_test'], bytes)
    assert isinstance(environ['ansible_test'], str)
    assert environ['ansible_test'] == 'test'
    assert environ._raw_environ['ansible_test'] == b'test'

# Generated at 2022-06-21 08:59:11.147856
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Use default constructor
    text_environ = _TextEnviron()
    assert environ._raw_environ is os.environ
    assert environ.encoding == sys.getfilesystemencoding()
    # Test when a different encoding is passed in
    text_environ = _TextEnviron(encoding='cp1252')
    assert environ._raw_environ is os.environ
    assert environ.encoding == 'cp1252'

# Generated at 2022-06-21 08:59:18.083485
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils.common._collections_compat import Iterable
    assert isinstance(environ, Iterable)
    assert isinstance(environ._raw_environ, Iterable)
    i = iter(environ)
    ri = iter(environ._raw_environ)
    try:
        while True:
            assert next(i) == next(ri)
    except StopIteration:
        pass

# Generated at 2022-06-21 08:59:23.936417
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    local_environ = environ
    local_environ.clear()
    local_environ['a'] = 'b'
    local_environ['c'] = 'd'
    local_environ['e'] = 'f'

    assert list(environ) == ['a', 'c', 'e']



# Generated at 2022-06-21 08:59:29.323250
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Test when deleting a key that exists and a key that doesn't exist

    key = "TEST_KEY"
    value = u"TEST_VALUE"

    # Test deleting a key that exists
    environ[key] = value
    del environ[key]
    assert key not in environ

    # Test deleting a key that doesn't exist
    with pytest.raises(KeyError):
        del environ[key]



# Generated at 2022-06-21 08:59:40.493506
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Prepare a test environment
    env = {b'ONE': b'ONE',
           b'TWO': b'\xc3\xa7',
           b'THREE': b'\xe2\x98\x83'}
    text_env = _TextEnviron(env=env, encoding='utf-8')

    # Make sure that the bytestrings in the environment are decoded
    assert text_env[b'ONE'] == u'ONE'
    assert text_env[b'TWO'] == u'\xe7'
    assert text_env[b'THREE'] == u'\u2603'

    # Make sure that an undecodable bytestring raises the correct error
    # This will raise a UnicodeDecodeError

# Generated at 2022-06-21 08:59:51.972624
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():

    def normalize(s):
        """
        Return a normalized string that is immune to platform differences in line endings.
        """
        return s.replace(os.linesep, '\n')

    def _run_test(env_str, args_str, expected_result, encoding='utf-8'):
        """
        Run a test to check the output of environ.__setitem__(key, value)
        """

        print('encoding: {}'.format(encoding))

        # Initialize the environ object for this test
        environ.clear()
        env_dict = dict(tuple(x.split('=', 1)) for x in env_str.split('\n') if x)
        print('env_dict: {}'.format(env_dict))
        environ.update(env_dict)

# Generated at 2022-06-21 08:59:53.977916
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    _TextEnviron()


# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-21 09:00:03.127367
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    if PY3:
        assert len(environ) == len(os.environ)
    else:
        num_items = 100
        for count in range(num_items):
            environ[str(count)] = str(count)
        assert len(environ) == num_items


# Generated at 2022-06-21 09:00:07.315109
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """Test the method __iter__ of class _TextEnviron."""
    # Mock the environment of the os module.
    os.environ = {'KEY1': 'VALUE1', 'KEY2': 'VALUE2'}
    result = [k for k in environ]
    assert os.environ.keys() == result

# Generated at 2022-06-21 09:00:11.172606
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # When called with no arguments, the return type of __len__ of class _TextEnviron is int
    assert isinstance(environ.__len__(), int)
    # When called with no arguments, the return value of __len__ of class _TextEnviron is greater than 0
    assert environ.__len__() > 0

# Generated at 2022-06-21 09:00:13.690628
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['test'] = to_bytes('test')
    environ = _TextEnviron()
    assert environ['test'] == 'test'


# Generated at 2022-06-21 09:00:21.407628
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2, PY3
    from io import BytesIO
    import os
    import sys

    filename = os.path.join(os.path.dirname(__file__), '..', 'test_data', '_text', 'utf8_bytes.json')
    with open(filename, 'rb') as f:
        utf8_bytes = f.read()
    mock_environ_dict = {}
    mock_environ = _TextEnviron(env=mock_environ_dict, encoding='utf-8')
    mock_environ['key'] = utf8_bytes


# Generated at 2022-06-21 09:00:27.664998
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import types
    # create a function to set item in `environ`
    def setitem(key, value):
        environ[key] = value
    # check it is working as expected
    setitem(u'foo', u'bar')
    assert types.FunctionType == type(setitem)
    assert {u'foo': u'bar'} == environ
    environ.clear()

if __name__ == "__main__":
    # execute only if run as a script
    test__TextEnviron___setitem__()

# Generated at 2022-06-21 09:00:31.068941
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ['ANSIBLE_TEST_VARIABLE'] = 'test'
    assert len(environ) == len(os.environ)
    del os.environ['ANSIBLE_TEST_VARIABLE']

# Generated at 2022-06-21 09:00:39.870447
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_copy = environ.copy()

    # Test that reading a text key/value works
    assert environ['LC_ALL'] == u'C'

    # Test that reading a byte key/value works
    assert environ['HOME'] == u'/root'

    # Test that reading a key/value pair with a surrogate escape works
    env_var_name = 'ANSIBLE_TEST_' + u'\udcc3'.encode('utf-8').decode('utf-8', 'surrogatepass')
    environ[env_var_name] = u'\udcc3'
    assert environ[env_var_name] == u'\udcc3'

    # Test that we get the expected error on an invalid key

# Generated at 2022-06-21 09:00:48.946048
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import unittest

    class _TextEnviron_TestCase(unittest.TestCase):
        def setUp(self):
            self.env = _TextEnviron()
            self.env['foo'] = 'bar'

        def tearDown(self):
            del self.env

        def test__TextEnviron___iter__(self):
            self.assertEqual(list(self.env), list(self.env._raw_environ))

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(_TextEnviron_TestCase))
    return suite


# Generated at 2022-06-21 09:00:52.294572
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Tests for method __delitem__ of class _TextEnviron
    """
    # Scenario: Delete an existing environment
    environ['FOO'] = 'BAR'
    del environ['FOO']
    assert 'FOO' not in environ

# Generated at 2022-06-21 09:01:06.440606
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    '''_TextEnviron should return utf-8 encoded unicode on Python2 and the original contents on
    Python3'''
    enc_val = 'ansible\xe2\x80\x99s'
    b_enc_val = enc_val.encode('utf-8')

    env_dict = {b'TEST_ENCODING': b_enc_val}
    mod_environ = _TextEnviron(env_dict, encoding='utf-8')
    assert mod_environ['TEST_ENCODING'] == enc_val

# Generated at 2022-06-21 09:01:08.452817
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron()
    assert iter(environ) == iter(environ._raw_environ)


# Generated at 2022-06-21 09:01:16.775259
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Set your python implementation (either Python 2 or Python 3)
    implementation = sys.version[0]
    # Create an instance of _TextEnviron class
    env = _TextEnviron()
    # List of keys and values to be set in environment variable
    keys = [
        u'key1',
        u'key2',
        u'key3',
        u'key4',
        u'key5',
        u'key6',
        u'key7',
        u'key8',
        u'key9'
    ]

# Generated at 2022-06-21 09:01:17.894807
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 09:01:20.624651
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from io import BytesIO
    from ansible.module_utils.six import next

    for value in environ.__iter__():
        assert isinstance(value, str)

# Generated at 2022-06-21 09:01:32.197731
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import pytest
    env = _TextEnviron({'unicode_key': 'unicode_value'}, encoding='utf-8')
    assert list(sorted(env.items())) == [('unicode_key', 'unicode_value')]

    # Test case where key is bytes and encoding is utf-8
    env = _TextEnviron({to_bytes('unicode_key', encoding='utf-8'): 'unicode_value'}, encoding='utf-8')
    assert list(sorted(env.items())) == [('unicode_key', 'unicode_value')]

    # Test case where key is bytes and encoding is latin-1
    env = _TextEnviron({to_bytes('unicode_key', encoding='latin-1'): 'unicode_value'}, encoding='latin-1')


# Generated at 2022-06-21 09:01:36.483012
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # A dummy environment
    environ = _TextEnviron({'foo': 'bar'})
    # We want to delete item 'foo', which is present in env
    del environ['foo']
    # Now item 'foo' must not be present in env
    assert 'foo' not in environ



# Generated at 2022-06-21 09:01:42.906081
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a good encoding set
    environ = _TextEnviron({'utf_8_good': '\xe2\x9a\x93'}, encoding='utf-8')
    # Check that we get good text
    assert b'\xe2\x9a\x93' == environ['utf_8_good']
    assert (b'\xe2\x9a\x93').decode('utf-8', 'surrogate_or_strict') == environ['utf_8_good']
    # Check that we get good text even if someone changes the value of the environment variable
    environ['utf_8_good'] = b'\xe2\x9a\x93\xe2\x9a\x93'

# Generated at 2022-06-21 09:01:44.676188
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)
