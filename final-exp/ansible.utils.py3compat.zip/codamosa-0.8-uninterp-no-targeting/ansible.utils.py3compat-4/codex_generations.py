

# Generated at 2022-06-21 08:56:02.745746
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    textenviron = _TextEnviron()
    assert 'foo' not in textenviron
    os.environ['foo'] = 'bar'
    assert 'foo' in os.environ
    assert 'foo' in textenviron
    del textenviron['foo']
    assert 'foo' not in textenviron
    assert 'foo' not in os.environ



# Generated at 2022-06-21 08:56:05.224982
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({b'A': b'1', b'B': b'2'})
    assert len(env) == 2



# Generated at 2022-06-21 08:56:08.717615
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils._text import to_text
    te = _TextEnviron()
    te['test_key'] = u'\u0a05\u0a05'
    assert isinstance(te['test_key'], to_text)
    assert u'\u0a05\u0a05' == te['test_key']

# Generated at 2022-06-21 08:56:20.468361
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_dict = {}
    x = _TextEnviron(test_dict, encoding='utf-8')
    if 'key' in x:
        raise Exception("__setitem__: 'key' should not have been in dict")
    x['key'] = 'a'
    if test_dict['key'] != b'a':
        raise Exception("__setitem__: Did not set 'key' to 'a' in dict")

    x['key1'] = u'b'
    if test_dict['key1'] != b'b':
        raise Exception("__setitem__: Did not set 'key1' to 'b' in dict")

    x['key2'] = b'c'

# Generated at 2022-06-21 08:56:23.672472
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    e = _TextEnviron({'a': 'a', 'b': 'b', 'c': 'c'})
    assert len(e) == 3


# Generated at 2022-06-21 08:56:28.816548
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    env['ascii'] = 'ascii'
    env['unicode'] = u'unicode'
    env['bytes'] = b'bytes'
    env['non-ascii'] = '\u9000'
    for k, v in env.items():
        assert isinstance(k, str)
        assert isinstance(v, str)

# Generated at 2022-06-21 08:56:36.234270
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    fake_environ = {b'a': b'1', b'b': b'2', b'c': b'3'}
    env = _TextEnviron(fake_environ, encoding='utf-8')
    for item in env:
        assert item in env
        assert env[item] in [u"1", u"2", u"3"]
    assert env[u'a'] == u'1'
    assert env[u'b'] == u'2'
    assert env[u'c'] == u'3'


# Generated at 2022-06-21 08:56:40.436519
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes, to_text
    text_environ = _TextEnviron({'foo': to_bytes('bar')})
    assert text_environ['foo'] == 'bar'


# Generated at 2022-06-21 08:56:42.574815
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-21 08:56:51.091544
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Create dummy object
    environ = _TextEnviron()
    # Check that object is _TextEnviron instance
    assert isinstance(environ, _TextEnviron)
    # Check that object is MutableMapping instance
    assert isinstance(environ, MutableMapping)
    # Check that object is environ
    assert environ == environ
    # Check that object is not empty
    assert bool(environ)



# Generated at 2022-06-21 08:57:03.136291
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import unittest
    import sys
    # Use encoding instead of encoding to mimic Python3's os.environ (see previous comment on env)
    def native_fs_encoding():
        if PY3:
            return sys.getfilesystemencoding()
        else:
            return 'utf-8'

    # Create a minimal object to test allowing the user to pass in an encoding
    class _Environ(MutableMapping):
        def __init__(self, encoding=None):
            self._raw_environ = {}
            if encoding is None:
                self.encoding = native_fs_encoding()
            else:
                self.encoding = encoding

        def __delitem__(self, key):
            del self._raw_environ[key]

        def __getitem__(self, key):
            return to_

# Generated at 2022-06-21 08:57:09.474828
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    env.__setitem__('KEY', 'value')
    assert env.__getitem__('KEY') == 'value'

    env.__setitem__('KEY', b'value')
    assert env.__getitem__('KEY') == 'value'

    env.__setitem__('KEY', u'value')
    assert env.__getitem__('KEY') == 'value'

    # Non-string values (e.g. integers) are tested in ansible.module_utils.common.collections_compat
    env.__setitem__('KEY', 1)
    assert env.__getitem__('KEY') == '1'

# Unit tests for methods __setitem__ and __getitem__ of class _TextEnviron when using surrogateescape error handler

# Generated at 2022-06-21 08:57:20.467247
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils.six.moves import cStringIO as StringIO

    def capture_stdout(func, *args, **kwargs):
        stdout = sys.stdout
        try:
            captured = StringIO()
            sys.stdout = captured
            ret = func(*args, **kwargs)
            sys.stdout = stdout
            captured.seek(0)
            return captured.read(), ret
        except:
            sys.stdout = stdout
            raise

    # Test that __iter__ returns an iterator of unicode strings on
    # Python2
    if not PY3:
        captured_output, ret = capture_stdout(list, environ)
        captured_output = captured_output.split()
        first_newline = captured_output.index('\n')

# Generated at 2022-06-21 08:57:30.147216
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ_test = _TextEnviron({'foo': b'bar'}, 'utf-8')
    list_env_test = list(environ_test)
    assert list_env_test == ['foo']

    environ_test = _TextEnviron({'foo': b'b\xc3\xa1r'}, 'utf-8')
    list_env_test = list(environ_test)
    assert list_env_test == ['foo']

    environ_test = _TextEnviron({'foo': b'b\xe1r'}, 'latin1')
    list_env_test = list(environ_test)
    assert list_env_test == ['foo']

# Generated at 2022-06-21 08:57:35.428765
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Create a dict-like object with a known length
    environ = _TextEnviron({'foo': 'bar'})
    # Exercise the method to run
    result = environ.__len__()
    # Verify the result and return the result
    assert result == 1
    return result



# Generated at 2022-06-21 08:57:42.340470
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    test_object = {'a': '1', 'e': '2', 'i': '3', 'o': '4', 'u': '5'}
    environ_test = _TextEnviron(test_object)

    assert 'a' in environ_test
    assert 'e' in environ_test
    assert 'i' in environ_test
    assert 'o' in environ_test
    assert 'u' in environ_test



# Generated at 2022-06-21 08:57:45.493443
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    env[u'foo'] = u'foo'
    assert env[u'foo'] == u'foo'


# Generated at 2022-06-21 08:57:47.329554
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 08:57:52.225642
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """
    Make sure that __iter__ works as expected
    """
    test_env = {'ANSIBLE_ANSIBLE': 'yes'}
    test_class = _TextEnviron(env=test_env)
    for i, key in enumerate(test_class):
        assert key == list(test_env)[i]



# Generated at 2022-06-21 08:57:57.086926
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Check that the constructor initializes all attributes correctly
    env = {to_bytes('test1'): to_bytes('test value 1'), to_bytes('test2'): to_bytes('test value 2')}
    test_env = _TextEnviron(env, encoding='utf-32')
    assert test_env._raw_environ == env
    assert test_env._value_cache == {}
    assert test_env.encoding == 'utf-32'


# Unit tests for __delitem__ of class _TextEnviron

# Generated at 2022-06-21 08:58:01.608820
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test startup of class
    assert environ == os.environ



# Generated at 2022-06-21 08:58:13.675190
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Unit test to make sure that _TextEnviron does what we want
    """
    # Test that the constructor takes a real dict and not a dict subclass
    if PY3:
        test_environ = _TextEnviron({'TEST1': 'あ', 'TEST2': '\udc80'})
        assert test_environ['TEST1'] == 'あ'
        assert test_environ['TEST2'] == '\udc80'
    else:
        test_environ = _TextEnviron({'TEST1': b'\xe3\x81\x82', 'TEST2': b'\xed\xb2\x80'})
        assert test_environ['TEST1'] == 'あ'
        assert test_environ['TEST2'] == '\udc80'

   

# Generated at 2022-06-21 08:58:18.894644
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test that the constructor works correctly
    # This is a test that the object can be constructed correctly
    environ = _TextEnviron({b'ANSIBLE_TEST_ENVVAR': b'ANSIBLE_TEST_VALUE'}, encoding='utf-8')
    assert environ['ANSIBLE_TEST_ENVVAR'] == u'ANSIBLE_TEST_VALUE'



# Generated at 2022-06-21 08:58:29.381836
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    from ansible.module_utils._text import b_to_text

    with environ.environ:
        os.environ['test__TextEnviron___delitem__'] = 'test__TextEnviron___delitem__'
        assert 'test__TextEnviron___delitem__' in environ
        assert 'test__TextEnviron___delitem__' in os.environ
        del environ['test__TextEnviron___delitem__']
        assert 'test__TextEnviron___delitem__' not in environ
        assert 'test__TextEnviron___delitem__' not in os.environ
    del os.environ['test__TextEnviron___delitem__']



# Generated at 2022-06-21 08:58:34.606375
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    if PY3:
        assert 'FOO' not in environ
    else:
        os.environ['FOO'] = 'BAR'

        assert 'FOO' in environ
        assert environ['FOO'] == 'BAR'

        del environ['FOO']

        assert 'FOO' not in environ


# Generated at 2022-06-21 08:58:43.347447
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = {b'a': b'1', b'b': b'2', b'c': 3}
    test_env1 = _TextEnviron(env=env, encoding='utf-8')
    test_env2 = _TextEnviron(env=env, encoding='iso-8859-1')
    assert test_env1['a'] == '1'
    assert test_env1['b'] == '2'
    assert test_env1['c'] == '3'
    assert test_env2['a'] == '1'
    assert test_env2['b'] == '2'
    assert test_env2['c'] == '3'


# Generated at 2022-06-21 08:58:54.329935
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    my_env = _TextEnviron()
    my_env['test1'] = 'this is a test'
    my_env['test2'] = '¿eres español?'

    try:
        # Attempt to add a non-string value to the environment
        my_env['test3'] = 1
    except TypeError:
        pass
    else:
        raise AssertionError("Did not raise TypeError when adding a non-string value to the environment")

    try:
        # Non-string values are converted to strings if possible
        my_env['test4'] = u'this is a test'
    except TypeError:
        raise AssertionError("Raised TypeError when adding a unicode value to the environment")


# Generated at 2022-06-21 08:59:06.799146
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Test the __len__ method of the class _TextEnviron

    Note:  In Python3, os.environ is a pure interface to the environment variables.  Because of
    this, we cannot modify the env in place.  Instead, we have to set a new env on the process.
    When we do this, the new environment is an empty dict.  We need to populate the dict with a
    key in order to test __len__.
    """
    # pylint: disable=missing-docstring
    import pytest
    if not PY3:
        pytest.skip('Python 2 has no _TextEnviron class')

    env = dict(os.environ)
    # This gives us an empty environment.  We need to add an entry to test the length
    os.environ = {}
    assert len(environ) == 0

# Generated at 2022-06-21 08:59:12.655710
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['TEST_KEY'] = 'STRING'
    assert isinstance(environ['TEST_KEY'], str)
    environ['TEST_KEY2'] = b'BYTES'
    assert isinstance(environ['TEST_KEY2'], str)
    os.environ['TEST_KEY'] = 'STRING'
    assert isinstance(os.environ['TEST_KEY'], str)
    os.environ['TEST_KEY2'] = b'BYTES'
    assert isinstance(os.environ['TEST_KEY2'], bytes)

# Generated at 2022-06-21 08:59:15.482868
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['test'] = 'test'

    del environ['test']
    assert 'test' not in environ


# Generated at 2022-06-21 08:59:23.698687
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    te = _TextEnviron()
    assert len(te) == len(environ) == len(os.environ)


# Generated at 2022-06-21 08:59:27.199570
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    global environ
    environ = _TextEnviron({'abc': 'abc'})
    assert list(environ.keys()) == ['abc']
    del environ['abc']
    assert list(environ.keys()) == []


# Generated at 2022-06-21 08:59:29.369991
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron(encoding='utf-8')
    env_list = list(environ)
    assert isinstance(env_list[0], str)



# Generated at 2022-06-21 08:59:35.054701
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Use an empty dict as the raw environment
    test_env = _TextEnviron({})
    # Test setting bytes to bytes
    test_env['bytes'] = b'bytes'
    assert test_env['bytes'] == b'bytes'
    # Test setting text to bytes
    test_env['bytes'] = u'bytes'
    assert test_env['bytes'] == b'bytes'
    # Test setting bytes to text
    test_env['text'] = b'text'
    assert test_env['text'] == u'text'
    # Test setting text to text
    test_env['text'] = u'text'
    assert test_env['text'] == u'text'
    # Test encoding is honoured
    test_env = _TextEnviron({}, encoding='ascii')

# Generated at 2022-06-21 08:59:46.366288
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Create a temporary environ for testing
    env = {}
    env['ANSIBLE_STRING'] = 'Foo'
    env['ANSIBLE_BYTES'] = 'Bär'
    env[b'ANSIBLE_BYTES2'] = b'B\xc3\xa4r'
    env['ANSIBLE_UNICODE'] = 'Bär'
    env[b'ANSIBLE_UNICODE2'] = b'B\xc3\xa4r'
    # Check that we get the right values when we decode as utf-8
    textenv = _TextEnviron(env=env, encoding=None)
    assert textenv['ANSIBLE_STRING'] == 'Foo'
    assert textenv['ANSIBLE_BYTES'] == 'Bär'

# Generated at 2022-06-21 08:59:48.266527
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-21 08:59:52.550280
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['test'] = u'foo'
    if PY3:
        assert environ['test'] == u'foo'
    else:
        assert environ['test'] == u'foo'
        assert b'foo' == os.environ[b'test']


# Generated at 2022-06-21 08:59:54.810528
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, MutableMapping)
    assert environ.encoding == 'utf-8'
    assert isinstance(environ._raw_environ, dict)

# Generated at 2022-06-21 09:00:00.302017
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """
    Unit test for method __iter__ of class _TextEnviron
    """
    env = _TextEnviron(env={'a': to_bytes('d', encoding='utf-8')})
    assert isinstance(iter(env).__next__(), str)



# Generated at 2022-06-21 09:00:00.817438
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, _TextEnviron)

# Generated at 2022-06-21 09:00:16.068764
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ = _TextEnviron(encoding='utf-8')
    assert 'PATH' in environ
    environ.__delitem__('PATH')
    assert 'PATH' not in environ


# Generated at 2022-06-21 09:00:25.938567
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    e = _TextEnviron()
    e['a'] = 'hello'
    assert e['a'] == 'hello'
    assert e._raw_environ['a'] == b'hello'
    e['b'] = 1
    assert e['b'] == '1'
    assert e._raw_environ['b'] == b'1'
    assert e._value_cache == {b'hello': 'hello', b'1': '1'}
    # Assert that mutating the environment dict doesn't change the value cache
    e._raw_environ['a'] = b'goodbye'
    assert e['a'] == 'hello'
    assert e._raw_environ['a'] == b'goodbye'
    assert e._value_cache == {b'hello': 'hello', b'1': '1'}
    pass

# Generated at 2022-06-21 09:00:28.972459
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    # Valid key
    assert to_text(os.environ['PATH']) == environ['PATH']
    # Invalid key
    try:
        assert to_text(environ['User'])
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-21 09:00:35.191256
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    e = _TextEnviron()
    assert isinstance(e, MutableMapping)
    assert isinstance(e, MutableMapping)

    assert isinstance(e.__iter__(), type(iter([])))

    assert isinstance(e._raw_environ['PATH'], type(u''))
    assert isinstance(e['PATH'], type(u''))
    assert e._raw_environ['PATH'] == e['PATH']

# Generated at 2022-06-21 09:00:41.720124
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():  # pylint: disable=invalid-name
    """
    This is a unit test for method __setitem__ of class _TextEnviron
    """
    # pylint: disable=no-member,line-too-long
    # pylint: disable=unused-variable,too-many-locals,too-many-branches,too-many-statements
    import unittest
    import ansible.module_utils._text  # pylint: disable=unused-import

    class Test___setitem__(unittest.TestCase):
        """
        Test for __setitem__ for _TextEnviron class
        """
        def setUp(self):
            environ['TEST_ENV_VAR'] = 'test_value'

# Generated at 2022-06-21 09:00:52.525538
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # The following case is problematic. The encoding is windows-1252 and the character cannot be
    # encoded with this encoding.
    environ = _TextEnviron(encoding='windows-1252')

    # Check the original value
    os.environ.__setitem__(b'set_test_key', b'Windows\xe9')
    assert os.environ.__getitem__(b'set_test_key') == b'Windows\xe9'

    # Test is set
    environ.__setitem__('set_test_key', 'Windows\xe9')
    assert environ.__getitem__('set_test_key') == u'Windows\xe9'

    # Check the result
    assert os.environ.__getitem__(b'set_test_key') == b'Windows\xe9'

# Generated at 2022-06-21 09:00:55.803707
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # environ will be used globally
    global environ
    # encoding='utf-8'
    # nonstring='strict'
    # errors='surrogate_or_strict'
    # bytes('ABC', 'utf-8'), bytes('DEF', 'utf-8')
    environ['k1'] = 'ABC'
    environ['k2'] = 'DEF'


# Generated at 2022-06-21 09:00:58.183234
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == 0
    environ['FOO'] = u'bar'
    assert len(environ) == 1


# Generated at 2022-06-21 09:01:02.368703
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({'one': 1, 'two': '2', 'three': 3.0, 'four': b'4'})
    len_env = len(env)
    assert len_env == 4
    env['five'] = b'5'
    assert len(env) == 5


# Generated at 2022-06-21 09:01:06.819771
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = {'a': '1', 'b': '2', 'c': '3'}
    env2 = _TextEnviron(env=env)
    assert len(env2) == 3



# Generated at 2022-06-21 09:01:34.690341
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test = _TextEnviron()
    try:
        test['test_key'] = 'test value'
        assert test['test_key'] == 'test value'

        del test['test_key']
        assert 'test_key' not in test
    finally:
        del test['test_key']



# Generated at 2022-06-21 09:01:41.932115
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Test with a single value
    env = {'ANSIBLE_PYTHON_INCLUDE_TESTS': '1'}
    environ = _TextEnviron(env=env, encoding='utf-8')
    assert list(environ) == ['ANSIBLE_PYTHON_INCLUDE_TESTS']

    # Test with a multi-value
    env = {'ANSIBLE_PYTHON_INCLUDE_TESTS': '1', 'ANSIBLE_PYTHON_TYPES': '2'}
    environ = _TextEnviron(env=env, encoding='utf-8')
    assert list(environ) == ['ANSIBLE_PYTHON_INCLUDE_TESTS', 'ANSIBLE_PYTHON_TYPES']



# Generated at 2022-06-21 09:01:48.395898
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ["test_key"] = "test_value"
    assert environ["test_key"] == "test_value"
    del environ["test_key"]
    try:
        value = environ["test_key"]
    except KeyError:
        raise AssertionError("Key does not exist")
    else:
        raise AssertionError("Key still exists with value %s" % value)


# Generated at 2022-06-21 09:01:55.814142
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Make sure that a unicode environment variable gets returned by __gettext__
    environ = _TextEnviron(encoding='utf-8')
    env = {'byte_str': b'with_bytes'}
    environ._raw_environ = env

    assert environ.__getitem__('byte_str') == 'with_bytes'

    env = {'native_str': 'native_str'}
    environ._raw_environ = env

    assert environ.__getitem__('native_str') == 'native_str'


# Generated at 2022-06-21 09:02:05.840640
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import os
    environ_utf8 = _TextEnviron(encoding='utf-8')
    assert isinstance(environ_utf8, MutableMapping)
    assert environ_utf8.encoding == 'utf-8'
    assert environ_utf8._value_cache == {}
    assert environ_utf8 is _TextEnviron()
    assert _TextEnviron(encoding='utf-8') is environ_utf8

    environ_latin1 = _TextEnviron(encoding='latin-1')
    assert environ_latin1.encoding == 'latin-1'
    assert environ_latin1._value_cache == {}

    environ_with_env = _TextEnviron(env=environ)
    assert isinstance(environ_with_env, MutableMapping)

# Generated at 2022-06-21 09:02:08.317522
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron(encoding='utf-8')
    for key in iter(environ):
        assert isinstance(key, to_text)


# Generated at 2022-06-21 09:02:08.863384
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    print(environ)

# Generated at 2022-06-21 09:02:15.566238
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    class MyEnv(object):
        def __init__(self):
            self.store = {}
        def __getitem__(self, key):
            return self.store[key]
        def __setitem__(self, key, value):
            self.store[key] = value
        def __delitem__(self, key):
            del self.store[key]
        def __iter__(self):
            return iter(self.store)
        def __len__(self):
            return len(self.store)

    testenv = MyEnv()
    env = _TextEnviron(env=testenv, encoding='ascii')
    env['foo'] = 'bar'
    env['fie'] = 'baz'
    del env['foo']
    assert len(env) == 1
    assert 'foo'

# Generated at 2022-06-21 09:02:19.125715
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ['test_key'] = 'test_value'
    del environ['test_key']
    assert b'test_key' not in os.environ


# Generated at 2022-06-21 09:02:24.912773
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import os
    import tempfile
    fd, filename = tempfile.mkstemp(suffix='.py')
    os.write(fd, b'#! /usr/bin/env python\n')
    os.close(fd)
    os.chmod(filename, 0o755)
    environ["PATH"] = os.pathsep.join((os.path.dirname(filename), environ["PATH"]))
    import test__TextEnviron
    assert test__TextEnviron.main() == 1


# Generated at 2022-06-21 09:03:21.050354
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils._text import to_bytes, to_text

    assert issubclass(_TextEnviron, MutableMapping)

    def test_getitem_non_ascii(environ, encoding):
        environ["\u2205"] = to_bytes("\u0132", "ascii")

        assert environ["\u2205"] == to_text("\u0132", encoding=encoding, nonstring='passthru', errors='surrogate_or_strict')

    for encoding in ['utf-8', 'ascii', 'latin_1', 'iso8859_1', 'iso8859_15']:
        environ = _TextEnviron(env={}, encoding=encoding)



# Generated at 2022-06-21 09:03:25.552843
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """Verify that _TextEnviron can delete items just like a dict"""
    environ = _TextEnviron(encoding='utf-8')
    environ['ANSIBLE_TEST_VAR'] = '1234'
    assert 'ANSIBLE_TEST_VAR' in environ.keys()
    environ.__delitem__('ANSIBLE_TEST_VAR')
    assert 'ANSIBLE_TEST_VAR' not in environ.keys()



# Generated at 2022-06-21 09:03:26.751590
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ) == list(os.environ)

# Generated at 2022-06-21 09:03:33.886775
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    key1 = 'ANSIBLE_DEV_STRING_KEY'
    value1 = 'ANSIBLE_DEV_STRING_VALUE'

    key2 = int(2)
    value2 = 'ANSIBLE_DEV_INTKEY_VALUE'

    key3 = 'ANSIBLE_DEV_UNICODE_KEY'
    value3 = u'ANSIBLE_DEV_UNICODE_VALUE'

    te = _TextEnviron()
    te[key1] = value1
    te[key2] = value2
    te[key3] = value3

    ret = []
    for k in te:
        ret.append(k)

    assert key1 in ret
    assert key2 in ret
    assert key3 in ret

# Generated at 2022-06-21 09:03:37.503373
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ = _TextEnviron({'mykey': 'myvalue'}, encoding='utf-8')
    assert 'mykey' in environ
    environ.__delitem__('mykey')
    assert 'mykey' not in environ


# Generated at 2022-06-21 09:03:39.749717
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    x = _TextEnviron()
    x.__setitem__('key', 'value')
    assert x._raw_environ['key'] == b'value'



# Generated at 2022-06-21 09:03:44.421118
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    util = _TextEnviron()
    assert len(util) == 1
    os.environ['_TextEnviron_key'] = '_TextEnviron_value'
    assert len(util) == 2
    del os.environ['_TextEnviron_key']


# Generated at 2022-06-21 09:03:53.464348
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Initialize the environment to empty
    environ.clear()
    # testcase 1: Set a 'unicode' string. The value of the variable is not modified
    # because it is already a 'unicode' string
    key1 = 'different_key'
    value1 = u'\u1234'
    environ[key1] = value1
    assert key1 in environ
    assert environ[key1] == value1

    # testcase 2: Set a 'str' string. The value of the variable is converted to 'unicode' string
    key2 = 'different_key'
    value2 = '\xc3\xbc'
    environ[key2] = value2
    assert key2 in environ
    assert environ[key2] == value2

    # testcase 3: Set a non-string value.

# Generated at 2022-06-21 09:03:54.908560
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    _TextEnviron().__iter__()


# Generated at 2022-06-21 09:03:59.261087
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():

    def __iter__(doc):
        """
        Return an iterator over the environment variables.

        Returns:
            iterator: iterator over the names of the environment variables
        """
        return iter(self._raw_environ)

    __iter__.__doc__ = _TextEnviron.__iter__.__doc__


# Generated at 2022-06-21 09:05:44.504008
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():

    # Without an explicit encoding, default to the filesystem encoding on Python2
    if PY3:
        filename = 'питон.txt'
        env = _TextEnviron({to_bytes(k): v for k, v in os.environ.items()})
    else:
        filename = '\xd0\xbf\xd0\xb8\xd1\x82\xd0\xbe\xd0\xbd.txt'
        env = _TextEnviron({to_bytes(k): v for k, v in os.environ.items()},
                           encoding=sys.getfilesystemencoding())

    assert env == os.environ
    assert env[filename] == os.environ[filename]
    assert isinstance(env[filename], type(os.environ[filename]))

# Generated at 2022-06-21 09:05:53.847502
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class EnvironMock(object):
        def __getitem__(self, key):
            return key

    environ = _TextEnviron(env=EnvironMock(), encoding='utf-8')
    assert environ['foo'] == 'foo'
    assert environ[u'bar'] == u'bar'
    assert environ[b'baz'] == u'baz'
    assert environ[1] == u'1'
    # __eq__ and __ne__
    assert environ[1] != '1'
    assert environ[1] == u'1'
    assert environ['foo'] != u'foo'
    assert environ['foo'] == 'foo'
    assert environ[u'bar'] != u'bar'
    assert environ[u'bar'] == 'bar'
    assert environ

# Generated at 2022-06-21 09:06:01.684645
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # get the environnement dictionary
    env = environ.__iter__()
    # create the expected result
    expected_result = {}
    for environnement_variable in env:
        expected_result[environnement_variable] = os.environ[environnement_variable]
    # execute the method
    result = {}
    for environnement_variable in environ.__iter__():
        result[environnement_variable] = environ[environnement_variable]
    # compare the result with what we expect
    assert result == expected_result
