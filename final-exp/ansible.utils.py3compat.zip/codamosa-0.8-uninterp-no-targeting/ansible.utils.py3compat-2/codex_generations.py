

# Generated at 2022-06-21 08:56:06.615301
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    assert to_text(u"¡¡¡¡\u2603") == u"¡¡¡¡\u2603"
    try:
        to_text(u"\u2603", u'ascii', 'surrogate_or_strict')
        assert False, "to_text should have thrown an exception with u'\u2603'"
    except UnicodeEncodeError:
        pass
    try:
        to_text(u"¡¡¡¡\u2603", u'ascii', 'strict')
        assert False, "to_text should have thrown an exception with u'¡¡¡¡\u2603'"
    except UnicodeEncodeError:
        pass

# Generated at 2022-06-21 08:56:13.010255
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    backup_environ = os.environ

    try:
        os.environ = {}
        os.environ['HOME'] = '/home/a.badger'

        del environ['HOME']
        assert 'HOME' not in os.environ
        assert not os.environ
    finally:
        os.environ = backup_environ



# Generated at 2022-06-21 08:56:21.452063
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Constructor requires a non-empty 'env' argument, we can use os.environ
    newenv = _TextEnviron(env=os.environ)

    # No key with name 'abc' in environment, we can safely use it
    newenv['abc'] = 'def'

    # Check if value of key 'abc' is correctly stored as bytes in environ
    assert b'def' == os.environ['abc']

    # Check if value of key 'abc' is correctly fetched as string in environ
    assert 'def' == newenv['abc']



# Generated at 2022-06-21 08:56:27.613389
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # verify that the test is valid by making sure that the default encoding for the environment is
    # different than utf-8
    assert sys.getfilesystemencoding() != 'utf-8'
    assert environ._raw_environ is os.environ
    assert isinstance(environ._raw_environ, MutableMapping)
    assert environ.encoding == 'utf-8'


# Unit tests for getitem method of class _TextEnviron

# Generated at 2022-06-21 08:56:32.064249
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({'EMAIL': 'foo@example.com', 'USER': 'foo', 'PASSWORD': 'bar'})
    env.__delitem__('EMAIL')
    assert env == {'USER': 'foo', 'PASSWORD': 'bar'}


# Generated at 2022-06-21 08:56:42.566861
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # <EDITED>
    _u = lambda t: t
    from ansible.module_utils.common._collections_compat import MutableMapping
    # </EDITED>

    class OSUpperEnviron(MutableMapping):
        def __init__(self, env=None, encoding=None):
            if env is None:
                env = os.environ
            self.env = env
            # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
            # instead of utf-8
            if encoding is None:
                # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
                # instead of utf-8
                self.encoding = sys.getfilesystemencoding()
            else:
                self.encoding

# Generated at 2022-06-21 08:56:48.091944
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    o = _TextEnviron(encoding='ascii')
    value = 'a' * 256
    o[value] = value
    assert value in o._value_cache
    assert value in o._raw_environ
    assert o._value_cache[value] == value
    assert o._raw_environ[value] == b'a' * 256

# Generated at 2022-06-21 08:56:54.844666
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # create instance of _TextEnviron
    env = _TextEnviron(env=None, encoding=None)

    # get the dict of the environment
    dict_env = dict(env)

    # get a random name of a variable
    key = dict_env.keys()[0]
    # check that the variable is defined
    assert key in dict_env.keys()
    # delete the variable
    del env[key]
    # check that the variable is not defined
    assert key not in env.keys()


# Generated at 2022-06-21 08:57:04.927338
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Generate a mutable mapping of arbitrary length
    arbitrary = MutableMapping()
    for i in range(0, 100):
        arbitrary[i] = i

    # If we don't have enough entries, add one more
    while len(arbitrary) < len(environ._raw_environ):
        arbitrary['arbitrary_addition'] = 'arbitrary_addition'

    # If we have too many entries, remove one
    while len(arbitrary) > len(environ._raw_environ):
        del arbitrary[list(arbitrary.keys())[-1]]

    # Copy the arbitrary environ dict for testing
    output = StringIO()
    custom

# Generated at 2022-06-21 08:57:08.764309
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ['a'] = '1'
    os.environ['b'] = '2'
    assert len(environ) == 2
    assert len(environ.keys()) == 2
    assert len(environ.items()) == 2


# Generated at 2022-06-21 08:57:13.480263
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    raw_env = {b'k1': b'v1', b'k2': b'v2', b'k3': b'v3'}
    txt_env = _TextEnviron(env=raw_env)
    assert len(raw_env) == len(txt_env)


# Generated at 2022-06-21 08:57:17.871304
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_environ = _TextEnviron()
    test_environ['ANSIBLE_TEST_KEY'] = '¡Děv'

    assert test_environ['ANSIBLE_TEST_KEY'] == '¡Děv'

# Generated at 2022-06-21 08:57:29.341762
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Set 'ENCODING' to the original UTF-8 encoded value.
    environ['ENCODING'] = 'm\xc3\xa3e\xc3\x85'
    # Check if 'ENCODING' was encoded to UTF-8 bytes and is equal to the original value.
    assert environ._raw_environ['ENCODING'] == b'm\xc3\xa3e\xc3\x85'
    assert environ['ENCODING'] == u'mãeÅ'

    # Set 'ENCODING' to a mixed string composed of a UTF-8 encoded value and an UTF-8 string.
    environ['ENCODING'] = b'm\xc3\xa3e\xc3\x85' + u' m\xc3\xa3e\xc3\x85'
    # Check if 'ENCODING

# Generated at 2022-06-21 08:57:31.893546
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ_test = _TextEnviron({'test_1': b'\xc3\xa1rv\xc3\xadzt\xc5\xb1r\xc5\x91 t\xc3\xbckfa'})

    list_of_keys = []
    for key in environ_test:
        list_of_keys.append(key)

    assert list_of_keys == ['test_1']


# Generated at 2022-06-21 08:57:39.693499
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    if not PY3:
        # Check that constructor doesn't set encoding if it didn't change
        sys.modules['__main__'].__dict__['environ'] = os.environ
        old_environ = dict(os.environ)
        environ = _TextEnviron(encoding=None)
        # The cache is already filled
        assert environ._value_cache
        assert old_environ == dict(environ._raw_environ)
        assert old_environ == dict(environ._raw_environ)
        new_environ = dict(environ)
        del sys.modules['__main__'].__dict__['environ']


# Generated at 2022-06-21 08:57:44.746433
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({})
    os.environ['Lorem'] = 'ipsum'
    env['Lorem'] = 'dolor'
    os.environ.pop('Lorem')
    assert 'Lorem' not in env
    del env['Lorem']
    assert 'Lorem' not in os.environ


# Generated at 2022-06-21 08:57:49.362275
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ = _TextEnviron()
    assert 'TEST' not in environ
    environ['TEST'] = 'test_value'
    assert 'TEST' in environ
    del environ['TEST']
    assert 'TEST' not in environ


# Generated at 2022-06-21 08:57:58.658904
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():

    t = _TextEnviron()

    # Unicode string should work in Python 2.6 and 3.x
    t['unicode_string'] = u'foo'
    assert 'foo' == t['unicode_string']
    assert b'foo' == t._raw_environ['unicode_string']

    # Byte strings should work in Python 2 with non-unicode chars
    # Python 2 should treat the bytes as a string of bytes
    t['byte_string'] = b'\xf0\x9f\x98\x8b'
    assert u'\U0001f60b' == t['byte_string']
    assert b'\xf0\x9f\x98\x8b' == t._raw_environ['byte_string']



# Generated at 2022-06-21 08:58:08.317722
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Given an instance of environ, an environment variable and a string value
    # When we set the value of the environment variable
    # Then all the values are now in unicode
    environ['FOO'] = 'Iñtërnâtiônàlizætiøn1'
    environ['BAR'] = 'Iñtërnâtiônàlizætiøn2'
    environ['BAZ'] = u'Iñtërnâtiônàlizætiøn3'
    for key in ('FOO', 'BAR', 'BAZ'):
        assert isinstance(environ[key], unicode)

# Generated at 2022-06-21 08:58:18.779404
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Set the encoding of the test environment to ASCII
    environ.encoding = 'ascii'
    key = 'ONE'
    value = b'ONE'
    environ[key] = value
    assert environ[key] == 'ONE'
    assert key in environ
    assert isinstance(environ[key], str)

    # Set the encoding of the test environment to UTF-8
    environ.encoding = 'utf-8'
    key = u'ONE'
    value = u'ONE'
    environ[key] = value
    assert environ[key] == u'ONE'
    assert key in environ
    assert isinstance(environ[key], str)

    # Set the encoding of the test environment to UTF-8
    environ.encoding = 'utf-8'

# Generated at 2022-06-21 08:58:26.896637
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Test the method __delitem__
    """
    """Unit test for method __delitem__ of class _TextEnviron"""

    # For some reason on py3 this is failing when run from the shell
    # but works when run from inside pycharm.  So for now, just skip
    # this test if we're on py3
    if PY3:
        pytest.skip()

    # Initialize some test variables
    varname = b'ANSIBLE_TEST'
    varvalue = b'testvar'
    encoding = u'utf-8'

    # First put in a value
    os.environ[varname] = varvalue

    # Get a _TextEnviron instance
    env = _TextEnviron(env=os.environ, encoding=encoding)

    # Delete the value

# Generated at 2022-06-21 08:58:34.233381
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    raw_env = {}
    env = _TextEnviron(env=raw_env)

    raw_env['bytes'] = b'bytes'
    raw_env['ascii'] = b'ascii'

    assert env['bytes'].encode('utf-8') == b'bytes'
    assert env['ascii'].encode('utf-8') == b'ascii'
    assert env.get('ascii').encode('utf-8') == b'ascii'


# Generated at 2022-06-21 08:58:44.193695
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test a normal item
    environ.__setitem__('FOO', u'BAR')
    assert os.environ['FOO'] == b'BAR'

    # Test an ascii str with ascii compatible encoding
    environ.__setitem__('FOO', 'BAR')
    assert os.environ['FOO'] == b'BAR'

    # Test an ascii str with utf-8 encoding
    environ.encoding = 'utf-8'
    environ.__setitem__('FOO', 'BAR')
    assert os.environ['FOO'] == b'BAR'

    # Test a non-ascii str with ascii compatible encoding
    environ.__setitem__('FOO', 'BÄR')
    assert os.environ['FOO']

# Generated at 2022-06-21 08:58:55.066413
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Expected to return a text string instead of a str on Python2
    """
    is_text = lambda x: type(x) == str

    env = {b'foo': 'bar'}
    text_env = _TextEnviron(env=env)
    assert is_text(text_env['foo']) is True

    env = {b'foo': u'bar'}
    text_env = _TextEnviron(env=env)
    assert is_text(text_env['foo']) is True

    env = {b'foo': b'\xc3\x88'}
    text_env = _TextEnviron(env=env)
    assert is_text(text_env['foo']) is True

    env = {b'foo': u'\xc3\x88'}
    text_env

# Generated at 2022-06-21 08:58:59.485532
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ['ANSIBLE_TEST_VAR'] = 'foo'
    assert len(environ) == len(os.environ)
    os.environ.pop('ANSIBLE_TEST_VAR')


# Generated at 2022-06-21 08:59:02.721252
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    try:
        env['test'] = 'test'
    except UnicodeEncodeError:
        return False
    return True


# Generated at 2022-06-21 08:59:12.025826
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test initializing from dictionary
    assert _TextEnviron({'foo': 'bar'}) == {'foo': 'bar'}
    assert _TextEnviron({'foo': 'bar'}) == {'foo': 'bar'}

    # Test initializing from environment
    raw_environ = os.environ
    os.environ = {'foo': 'bar'}
    assert _TextEnviron() == {'foo': 'bar'}
    assert _TextEnviron() == {'foo': 'bar'}
    os.environ = raw_environ

    # Test that the env is converted to bytes when setting
    assert _TextEnviron({'foo': 'bar'}) == {'foo': 'bar'}
    environ = _TextEnviron({'foo': 'bar'})

# Generated at 2022-06-21 08:59:13.942985
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, MutableMapping)


# Generated at 2022-06-21 08:59:17.252706
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({'key1':'value1', 'key2':'value2'})

    env.__delitem__('key1')

    assert 'key1' not in env


# Generated at 2022-06-21 08:59:23.935992
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ["TEST_VAR"] = u"Test text encoding with é and œ"
    assert isinstance(environ["TEST_VAR"], unicode)
    assert u"Test text encoding with é and œ" == environ["TEST_VAR"]
    # Clean up test variable
    del environ["TEST_VAR"]

# Generated at 2022-06-21 08:59:33.319418
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # pylint: disable=protected-access
    import os
    test_env = _TextEnviron({'PATH': 'my-path'}, encoding='utf-8')
    assert test_env['PATH'] == 'my-path'

    # This test only matters for Python2
    if not PY3:
        test_env = _TextEnviron({'Bytestring': b'bytestring'}, encoding='utf-8')
        assert test_env['Bytestring'] == u'bytestring'
    # pylint: enable=protected-access



# Generated at 2022-06-21 08:59:41.708636
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Arrange
    origin_key = 'ORIGIN_KEY'
    origin_value = 'ORIGIN_VALUE'
    environ[origin_key] = origin_value
    expected_result = origin_value
    expected_result_bytes = expected_result.encode('utf-8')

    # Act
    result = environ[origin_key]
    result_bytes = environ._raw_environ[origin_key.encode('utf-8')]

    # Assert
    assert result == expected_result
    assert result_bytes == expected_result_bytes


# Generated at 2022-06-21 08:59:42.716803
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    _TextEnviron.__iter__


# Generated at 2022-06-21 08:59:50.212608
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_env = _TextEnviron(encoding='utf-8')
    test_env['TEST_KEY'] = 'test_string'
    assert test_env['TEST_KEY'] == 'test_string'

    # Testing setting key in dict to unicode string
    test_env['TEST_KEY'] = u'test_unicode_string'
    assert test_env['TEST_KEY'] == u'test_unicode_string'


# Generated at 2022-06-21 08:59:53.897578
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    org_env = os.environ.copy()
    os.environ['key'] = 'value'
    assert len(environ) == len(org_env) + 1
    assert len(environ) == 1
    os.environ = org_env



# Generated at 2022-06-21 08:59:55.085740
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-21 08:59:56.692667
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron()
    assert isinstance(environ['PATH'], text_type)

# Generated at 2022-06-21 09:00:08.191987
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import os
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import PY3

    class _TextEnviron(MutableMapping):
        """
        Utility class to return text strings from the environment instead of byte strings

        Mimics the behaviour of os.environ on Python3
        """
        def __init__(self, env=None, encoding=None):
            if env is None:
                env = os.environ
            self._raw_environ = env
            self._value_cache = {}
            # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
            # instead of utf-8

# Generated at 2022-06-21 09:00:09.492462
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 09:00:12.176411
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    assert os.environ['PATH'] == 'test'
    environ['PATH'] = 'test'
    del environ['PATH']
    assert os.environ['PATH'] != 'test'
