

# Generated at 2022-06-21 08:56:03.575148
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # empty
    assert len(environ) == 0
    environ.clear()
    # not empty
    for item in {'abc': 'abc', '123': '123'}:
        environ[item] = item
    assert len(environ) == 2
    environ.clear()



# Generated at 2022-06-21 08:56:04.929560
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    text_environ = _TextEnviron({'a': 'b'})
    assert len(text_environ) == 1



# Generated at 2022-06-21 08:56:17.293446
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():

    # Tests that the function returns None when attempting to set a value
    def test_returns_none(monkeypatch):
        monkeypatch.setattr(environ, '_raw_environ', {})
        assert environ.__setitem__('TEST', 'TEST') is None

    test_returns_none()

    # Tests that the nonstring method encodes the string as utf-8 when given an unicode type
    def test_unicode_to_utf_8(monkeypatch):
        monkeypatch.setattr(environ, '_raw_environ', {})
        monkeypatch.setattr(environ, 'encoding', 'utf-8')
        environ.__setitem__('TEST', u'TEST')
        assert environ._raw_environ['TEST'] == 'TEST'

    test_unic

# Generated at 2022-06-21 08:56:24.851084
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import types
    environ_iter = environ.__iter__()
    assert isinstance(environ_iter, types.GeneratorType)
    environ_iter_list = list(environ_iter)
    assert len(environ_iter_list) == len(os.environ)
    assert all((key in os.environ) for key in environ_iter_list)
    assert all((key in environ_iter_list) for key in os.environ)


# Generated at 2022-06-21 08:56:31.829257
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # example of use of the method
    from six.moves import builtins
    from six import StringIO

    environ_saved = environ._raw_environ.copy()
    try:
        del environ['HOME']  # call of method __delitem__ of class _TextEnviron
        # check that the key is absent of os.environ
        assert 'HOME' not in environ._raw_environ
    finally:
        environ._raw_environ = environ_saved


# Generated at 2022-06-21 08:56:42.426638
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    class something(object):
        def __init__(self):
            self.__len = None

        def __len__(self):
            return self.__len

        def __iter__(self):
            raise Exception("Not implemented")

    # Test: failure
    something_instance = something()
    something_instance.__len = None
    text_environ_instance = _TextEnviron(env=something_instance)
    try:
        len(text_environ_instance)
    except Exception as e:
        assert type(e) == Exception
    else:
        assert False, "Expected Exception to be raised"
    # Test: failure
    something_instance = something()
    something_instance.__len = 1.0

# Generated at 2022-06-21 08:56:48.839344
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    sys_getfilesystemencoding = sys.getfilesystemencoding
    try:
        sys.getfilesystemencoding = lambda: 'utf-8'
        assert _TextEnviron().encoding == 'utf-8'
        assert _TextEnviron(encoding='ascii').encoding == 'ascii'
    finally:
        sys.getfilesystemencoding = sys_getfilesystemencoding

# Generated at 2022-06-21 08:56:50.765615
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert(len(list(environ.__iter__())) == len(environ))

# Generated at 2022-06-21 08:56:52.212406
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)

# Generated at 2022-06-21 08:57:01.025896
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test the conversion of bytes to text when PY3 is False
    environ_py2 = _TextEnviron({b'foo': b'bar'}, encoding='utf-8')
    assert environ_py2[b'foo'] == u'bar'
    assert isinstance(environ_py2[b'foo'], unicode)

    # Test against surrogateescape handling a surrogate character
    surrogate_env = {'foo': b"\xff"}
    environ_surrogate = _TextEnviron(surrogate_env, encoding='utf-8')
    assert environ_surrogate['foo'] == u'\udcff'
    assert isinstance(environ_surrogate['foo'], unicode)

    # Test against surrogateescape handling a non-surrogate character

# Generated at 2022-06-21 08:57:04.084834
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os.environ['HELLO'] = 'WORLD'
    assert list(environ) == [('HELLO', 'WORLD')]

# Generated at 2022-06-21 08:57:09.971338
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Create _TextEnviron instance and add items to it
    environ = _TextEnviron(env=None, encoding='utf-8')
    environ['TEST_KEY'] = 'TEST_VALUE'

    assert(len(environ) == len(os.environ) + 1)

    # Delete item from _TextEnviron instance and verify results
    del environ['TEST_KEY']

    assert(len(environ) == len(os.environ))


# Generated at 2022-06-21 08:57:11.771495
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['key1'] = 'value1'
    del environ['key1']
    assert 'key1' not in environ


# Generated at 2022-06-21 08:57:18.175224
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    validate that delete item works for _TextEnviron
    """
    env_var = 'Foo'
    env_val = 'bar'
    environ[env_var] = env_val
    assert (environ[env_var] == env_val)
    del environ[env_var]
    assert (environ[env_var] != env_val)


# Generated at 2022-06-21 08:57:19.798334
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert iter(environ) == iter(os.environ)


# Generated at 2022-06-21 08:57:30.987219
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import subprocess
    import unittest

    if PY3:
        class _TextEnvironGetItemTest(unittest.TestCase):
            def test__TextEnviron_getitem__p3(self):
                self.assertIsInstance(environ, MutableMapping)
                self.assertIs(environ._raw_environ, os.environ)

        if __name__ == '__main__':
            unittest.main()
        return

    class _TextEnvironGetItemTest(unittest.TestCase):
        def test__TextEnviron_getitem__p2(self):
            self.assertIsInstance(os.environ, MutableMapping)
            self.assertNotIsInstance(os.environ, _TextEnviron)


# Generated at 2022-06-21 08:57:38.674756
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test __getitem__ of class _TextEnviron
    """
    class TestEnviron(MutableMapping):
        def __delitem__(self, key):
            pass

        def __setitem__(self, key, value):
            pass

        def __iter__(self):
            return iter(['key_without_value', 'key_with_bytes_value', 'key_with_text_value'])

        def __len__(self):
            return 3

        def __getitem__(self, key):
            if key == 'key_without_value':
                return ''
            elif key == 'key_with_bytes_value':
                return 'value'.encode('utf-8')
            elif key == 'key_with_text_value':
                return 'value'
            else:
                raise

# Generated at 2022-06-21 08:57:41.867111
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron({b'foo': u'bar'}, encoding='utf-8')
    assert environ[b'foo'] == u'bar'

# Generated at 2022-06-21 08:57:46.947457
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Create a fresh os.environ and assert __len__ is zero
    environ = _TextEnviron()

    # Add a value to os.environ and assert __len__ is one
    environ['ANSIBLE_NET_USERNAME'] = 'test_user'
    assert len(environ) == 1



# Generated at 2022-06-21 08:57:50.114375
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = dict(environ)
    env["new_key"] = "new_value"
    assert len(environ) == len(env)


# Generated at 2022-06-21 08:57:57.302371
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    raw_environ = os.environ.copy()
    try:
        environ["ANSIBLE_TEST_ANSIBLE_OUTCOME"] = "1"
        del environ["ANSIBLE_TEST_ANSIBLE_OUTCOME"]
        assert environ.get('ANSIBLE_TEST_ANSIBLE_OUTCOME') is None
    finally:
        os.environ.clear()
        os.environ.update(raw_environ)



# Generated at 2022-06-21 08:58:08.716973
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import testinfra
    import os
    import ansible.module_utils.six
    import ansible.module_utils.basic
    import ansible.module_utils.common.collections
    import ansible.module_utils._text

    if not testinfra.utils.ansible_module_implementation.ANSIBLE_MODULE_CLASS:
        testinfra.utils.ansible_module_implementation.ANSIBLE_MODULE_CLASS = ansible.module_utils.basic.AnsibleModule
    mod = testinfra.utils.ansible_module_implementation.ANSIBLE_MODULE_CLASS


# Generated at 2022-06-21 08:58:19.012838
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Using values from documentation for PYTHONIOENCODING
    # For example: https://docs.python.org/3.7/using/cmdline.html#envvar-PYTHONIOENCODING
    os.environ['TEST_ENV_VAR'] = '\xd0\xbc\xd0\xbe\xd1\x80\xd0\xb5 \xe2\x80\x94 море'

    # Test codecs which don't handle surrogateescape properly
    os.environ['PYTHONIOENCODING'] = 'ascii'
    assert environ['TEST_ENV_VAR'] == '\xd0\xbc\xd0\xbe\xd1\x80\xd0\xb5 \xe2\x80\x94 море'

# Generated at 2022-06-21 08:58:30.620885
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    os.environ['PYTHONIOENCODING'] = 'ascii'
    from ansible.module_utils import six

    # Test the environment variable PYTHONIOENCODING.  This is a unicode string on Python2 and
    # latin1 on Python3
    try:
        t = six.text_type(os.environ['PYTHONIOENCODING'])
    except UnicodeDecodeError:
        old_python2 = True
    except UnicodeEncodeError:
        old_python2 = False

    # Test the environment variable PYTHONIOENCODING.  This is a unicode string on Python2 and
    # latin1 on Python3

# Generated at 2022-06-21 08:58:33.942329
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils.common._collections_compat import Sequence
    assert isinstance(environ.__iter__(), Sequence.__iter__(environ))

# Generated at 2022-06-21 08:58:39.565155
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert isinstance(environ, _TextEnviron)
    env = dict(environ)
    assert isinstance(env, dict)

    for key in environ:
        assert isinstance(key, str)
        assert isinstance(env[key], str)
        assert env[key] == environ[key]



# Generated at 2022-06-21 08:58:43.823007
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ[u"key"] = u"value"
    assert "value" == environ["key"]
    os.environ[u"key"] = u"valäue"
    assert u"valäue" == environ["key"]

# Generated at 2022-06-21 08:58:54.624407
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Given an existing os.environ variable
    os.environ['TEST_ENV_VAR'] = 'test'
    # And that variable is not deleted
    assert 'TEST_ENV_VAR' in os.environ
    # When I create an instance of _TextEnviron
    my_env = _TextEnviron()
    # Then the variable that I set up is in the instance of _TextEnviron
    assert 'TEST_ENV_VAR' in my_env
    # And the variable that I set up is in the instance's internal os.environ variable
    assert 'TEST_ENV_VAR' in my_env._raw_environ
    # And the variable that I set up is in the instance's iterator
    assert 'TEST_ENV_VAR' in list(my_env)


#

# Generated at 2022-06-21 08:59:00.885325
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # A single test for both failure and success.
    # We can't test success because we're using os.environ... depends on other
    # tests passing
    environ['TEST_TEXTENVIRON_ENVIRON'] = 'foo'
    del environ['TEST_TEXTENVIRON_ENVIRON']



# Generated at 2022-06-21 08:59:04.560199
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    from os import putenv, unsetenv
    putenv(b'a', b'b')
    del environ['a']
    assert(to_text(unsetenv(b'a')) == environ['a'])

# Generated at 2022-06-21 08:59:10.395200
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    key = 'test_key'
    value = 'test_value'
    te = _TextEnviron()
    te[key] = value
    assert te[key] == value
    del te[key]
    try:
        te[key]
    except KeyError as err:
        str_err = str(err)
    assert str_err == key


# Generated at 2022-06-21 08:59:18.083084
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = {b'PATH': b'/usr/sbin:/usr/bin',
           b'LOGNAME': b'root',
           b'USER': b'root',
           b'TERM': b'some_terminal'}

    expected = {'PATH': '/usr/sbin:/usr/bin',
                'LOGNAME': 'root',
                'USER': 'root',
                'TERM': 'some_terminal'}

    assert _TextEnviron(env)._raw_environ == env


# Generated at 2022-06-21 08:59:27.408894
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    raw_str = '\x9c\xee\xa7\xf0\x9a\x8f\xa5\xa6\xbf\x92\x8f\x9f\xa5\xe6\x8f\xbe'
    decoded_str = '\uff7c\u00ee\uff67\uff70\uff5a\uff8f\uff65\uff66\uff3f\uff52\uff8f\uff9f\uff65\u2336\uff8f\u25be'
    environ[u'foo'] = raw_str
    print(environ[u'foo'])
    assert environ[u'foo'] == decoded_str

# Generated at 2022-06-21 08:59:29.552294
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    sys.modules['os'] = __import__('__fake__.os')

    from ansible.module_utils import environment
    assert len(environment.environ) == 7


# Generated at 2022-06-21 08:59:31.883024
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({b'ansible_python_interpreter': b'/usr/bin/python'})
    assert list(env.__iter__()) == ['ansible_python_interpreter']


# Generated at 2022-06-21 08:59:41.480331
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    try:
        test_value = environ["test"]
    except KeyError:
        pass
    else:
        if PY3:
            raise Exception("Variable test must not exist before running tests")
        del environ["test"]
    environ["test"] = "testing"
    if PY3:
        assert environ["test"] == "testing"
    else:
        assert environ["test"] == unicode("testing")
    del environ["test"]
    try:
        test_value = environ["test"]
    except KeyError:
        pass
    else:
        raise Exception("Variable test should not exist after deleting it")



# Generated at 2022-06-21 08:59:49.239061
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron()
    len_before = len(env)
    env['ANSIBLE_TEST_ENV'] = 'This_is_a_test'
    len_after_set = len(env)
    del env['ANSIBLE_TEST_ENV']
    len_after_del = len(env)

    assert len_before != len_after_set
    assert len_after_set != len_after_del
    assert len_before == len_after_del



# Generated at 2022-06-21 08:59:50.761582
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)

# Generated at 2022-06-21 08:59:58.188576
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():

    _raw_environ = {'a': '1'}
    _value_cache = {}
    _encoding = 'utf-8'
    environ = _TextEnviron(_raw_environ, _encoding)
    assert 1 == len(_raw_environ)
    assert 1 == len(_value_cache)
    assert 'a' in _raw_environ
    assert 'a' in _value_cache
    environ['b'] = 2
    assert 2 == len(_raw_environ)
    assert 2 == len(_value_cache)
    assert 'a' in _raw_environ
    assert 'a' in _value_cache
    assert 'b' in _raw_environ
    assert 'b' in _value_cache

# Generated at 2022-06-21 09:00:05.019602
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['ANSIBLE_TEST'] = 'foo'
    assert environ['ANSIBLE_TEST'] == 'foo'

    environ['ANSIBLE_TEST'] = b'foo'
    assert environ['ANSIBLE_TEST'] == 'foo'

    environ['ANSIBLE_TEST'] = u'foo'
    assert environ['ANSIBLE_TEST'] == 'foo'



# Generated at 2022-06-21 09:00:15.279222
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Create a dict item to be used by the environment class
    dict_key = 'test_delitem_key'
    dict_value = 'test_delitem_value'
    dict_item_text = {dict_key: dict_value}
    dict_item_bytes = {to_bytes(dict_key, errors='strict'): to_bytes(dict_value, errors='strict')}

    # Create a test environment class
    test_environ = _TextEnviron(env=dict_item_text, encoding='utf-8')

    # Assert the dict item is in the environment
    assert dict_key in test_environ
    assert dict_item_text == test_environ._raw_environ

    # Delete the dict item from the environment class
    del test_environ[dict_key]

    # Assert the

# Generated at 2022-06-21 09:00:17.488917
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = environ
    test_environ['test'] = 'test'
    assert test_environ['test'] == 'test'