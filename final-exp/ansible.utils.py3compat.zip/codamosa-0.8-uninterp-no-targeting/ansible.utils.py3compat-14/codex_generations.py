

# Generated at 2022-06-21 08:56:07.984428
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # This test doesn't provide 100% coverage but it tests the main paths.
    import os

    # The constructor of this class should always return an object,
    environ = _TextEnviron()
    assert isinstance(environ, _TextEnviron)

    # The attrs of the object should be set properly
    assert isinstance(environ._raw_environ, dict)
    assert isinstance(environ._value_cache, dict)
    assert isinstance(environ.encoding, str)
    assert environ.encoding == os.environ.encoding

    # Test with different encoding
    environ = _TextEnviron(encoding='utf-8')
    assert environ.encoding == 'utf-8'

    # Test with different environment
    my_env = {'hello': 'world'}
    environ = _Text

# Generated at 2022-06-21 08:56:19.839391
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    env = {}

    def fake_to_bytes(text, encoding=None, nonstring='strict', errors='surrogate_or_strict'):
        return text.encode('utf-8')

    # Note that the original author of this, Toshio Kuratomi, is trying to submit this to six.  If
    # successful, the code in six will be available under six's more liberal license:
    # https://mail.python.org/pipermail/python-porting/2018-July/000539.html
    environ = _TextEnviron(env=env, encoding='utf-8')
    environ.__setitem__ = MutableMapping.__setitem__

# Generated at 2022-06-21 08:56:24.768452
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test with Python3
    if PY3:
        with environ.patch({"TEST": "value"}):
            assert isinstance(environ["TEST"], str)
    else:
        with environ.patch({"TEST": "value"}):
            assert isinstance(environ["TEST"], unicode)

# Generated at 2022-06-21 08:56:31.010911
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os.environ['ANSIBLE_TEXT_ITER_TEST_A'] = '1'
    os.environ['ANSIBLE_TEXT_ITER_TEST_B'] = '2'

    obj = _TextEnviron()
    assert set([x for x in obj]) == set(['ANSIBLE_TEXT_ITER_TEST_A', 'ANSIBLE_TEXT_ITER_TEST_B'])


# Generated at 2022-06-21 08:56:34.600261
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({b'one': b'1', b'two': b'2', b'three': b'3'})
    assert list(env.__iter__()) == ['one', 'two', 'three']



# Generated at 2022-06-21 08:56:44.004960
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    os_environ = os.environ.copy()
    test_environ = _TextEnviron({})
    test_environ['a'] = 'b'
    assert test_environ['a'] == 'b'
    del test_environ['a']

    os.environ.clear()
    test_environ = _TextEnviron(os.environ)
    test_environ['a'] = 'b'
    assert test_environ['a'] == 'b'
    del test_environ['a']

    os.environ.clear()
    os.environ.update(os_environ)

    # Unit test for method __setitem__ of class _TextEnviron
    test_environ = _TextEnviron({'a': 'b'})
    test_environ['a'] = 'c'


# Generated at 2022-06-21 08:56:53.221853
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # get length of environ
    len_environ = len(environ)
    # assert environ length is not empty
    assert len_environ > 0
    # add new environment variable
    environ["ADD_ENVIRONMENT_VARIABLE_KEY"] = "ADD_ENVIRONMENT_VARIABLE_VALUE"
    # get length of environ after adding a variable
    len_environ_new_variable = len(environ)
    # assert environ length is 1 more than before
    assert len_environ == len_environ_new_variable - 1



# Generated at 2022-06-21 08:56:56.146593
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    enc = sys.getfilesystemencoding()
    e = _TextEnviron()

    assert type(e['LC_ALL']) == str, "The LC_ALL environment variable should be returned as str"


# Generated at 2022-06-21 08:57:00.641371
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ["ANSIBLE_TEST_VAR"] = "a1"
    assert "ANSIBLE_TEST_VAR" in environ
    del environ["ANSIBLE_TEST_VAR"]
    assert "ANSIBLE_TEST_VAR" not in environ
    if hasattr(os, 'environb'):
        assert "ANSIBLE_TEST_VAR" not in os.environb


# Generated at 2022-06-21 08:57:10.057220
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for key that is a utf-8 encoded unicode character.
    environ.clear()
    environ['☺'] = 'happy'
    assert environ['☺'] == 'happy'

    # Test for key that is a string of ascii characters
    environ.clear()
    environ['ascii'] = 'ascii'
    assert environ['ascii'] == 'ascii'

    # Test for key that is not a unicode object, but byte string that can be decoded as utf-8
    environ.clear()
    environ[b'\xf0\x9f\x98\x80'] = 'smile'
    assert environ['\U000f09f988'] == 'smile'

    # Test for key that is a unicode object that can be decoded

# Generated at 2022-06-21 08:57:14.456725
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    for i in range(2):
        assert len(environ) == len(os.environ)



# Generated at 2022-06-21 08:57:20.128319
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # We do not have a testing framework for this kind of unit test, so we hack it in here.
    environ.encoding = 'ascii'
    assert environ['mystr'] == u'mystr'
    environ.encoding = 'utf-8'
    assert environ['mystr'] == u'mystr'

# Generated at 2022-06-21 08:57:23.454268
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = {'key': 'value'}
    text_environ = _TextEnviron(env, encoding='utf-8')
    assert text_environ['key'] == u'value'


# Generated at 2022-06-21 08:57:29.241762
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    cwd = environ.get('PWD')
    assert cwd is not None

    # Make sure 'PWD' is in the environment
    for key in environ:
        if key == 'PWD':
            break
    else:
        assert False, to_text(u'PWD not found in environ!', nonstring='strict')


# Generated at 2022-06-21 08:57:31.658469
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron()
    assert len(env.keys()) == len(set(env.keys()) | set(env.values()))



# Generated at 2022-06-21 08:57:33.253663
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    x = _TextEnviron({'a': 'b'})
    assert list(x) == ['a']

# Generated at 2022-06-21 08:57:35.721803
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    dummy_dict = {'DUMMY_KEY': 'DUMMY_VALUE'}
    dummy_environ = _TextEnviron(dummy_dict)

    assert len(dummy_environ) == 1

    del dummy_environ['DUMMY_KEY']

    assert len(dummy_environ) == 0


# Generated at 2022-06-21 08:57:39.594060
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    env['myvar'] = 'myvalue'
    assert b'myvar' in env._raw_environ
    assert env._raw_environ[b'myvar'] == b'myvalue'



# Generated at 2022-06-21 08:57:44.671516
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # https://github.com/ansible/ansible/issues/41688
    # this isn't really a test per se, but does verify that the class doesn't crash on python2.
    environ = _TextEnviron()
    print(environ['HOME'])


if __name__ == '__main__':
    test__TextEnviron()

# Generated at 2022-06-21 08:57:50.359673
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import types
    text_environ = _TextEnviron()
    test_func = text_environ.__len__
    assert(isinstance(test_func, types.MethodType))
    assert(test_func.__qualname__ == '_TextEnviron.__len__')
    assert(0 <= test_func())


# Generated at 2022-06-21 08:57:55.778611
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['foo'] = 'bar'
    environ['baz'] = 'quux'
    del environ['baz']
    assert len(environ) == 1
    assert environ['foo'] == 'bar'
    assert 'baz' not in environ


# Generated at 2022-06-21 08:57:56.937274
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _TextEnviron().__delitem__("C")


# Generated at 2022-06-21 08:57:58.692318
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    global environ
    environ['key'] = 'value'
    del environ['key']
    assert 'key' not in environ


# Generated at 2022-06-21 08:58:01.040907
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron()
    assert(len(environ) == len(os.environ))



# Generated at 2022-06-21 08:58:06.954280
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Check that the iterator does not alter the variable
    my_env = {'a': '1', 'b': '2'}
    env = _TextEnviron(env=my_env)
    it = iter(env)
    next(it)
    next(it)
    assert my_env == env._raw_environ


# Generated at 2022-06-21 08:58:17.552486
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env_default = os.environ.copy()
    env_utf8 = os.environ.copy()
    env_latin1 = os.environ.copy()
    env_utf8['LANG'] = 'en_US.UTF8'
    env_latin1['LANG'] = 'en_US.ISO88591'

    # Explicitly specify encoding=None
    env_none = _TextEnviron(encoding=None)
    assert env_none.encoding == sys.getfilesystemencoding()
    assert env_none['LANG'] == env_default['LANG']

    # Explicitly specify encoding='utf-8'
    env_utf8_explicit = _TextEnviron(env_utf8, encoding='utf-8')
    assert env_utf8_explicit.encoding == 'utf-8'

# Generated at 2022-06-21 08:58:28.336498
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Bytes in environ
    assert isinstance(environ['PATH'], str)
    assert environ['PATH'] == '/bin:/usr/bin'

    # Unicode in environ
    environ['FOO'] = 'this is unicode'
    assert isinstance(environ['FOO'], str)
    assert environ['FOO'] == 'this is unicode'
    del environ['FOO']

    # Unicode in environ
    environ['FOO'] = 'this is unicode'
    assert isinstance(environ['FOO'], str)
    assert environ['FOO'] == 'this is unicode'
    del environ['FOO']



# Generated at 2022-06-21 08:58:39.938934
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    This is a unit test for the __init__ method of class _TextEnviron
    """
    import os
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Make sure we can instantiate
    env = _TextEnviron()
    assert isinstance(env, MutableMapping)

    # Make sure that the raw environ is populated with the values from os.environ
    assert env._raw_environ == os.environ

    # If we try to instantiate with a non-mapping, we should get an error
    try:
        env = _TextEnviron(env='Not a dictionary')
    except TypeError:
        pass
    else:
        assert False, 'Should have gotten a TypeError'

    # If we instantiate with a non-unicode key or value, we

# Generated at 2022-06-21 08:58:42.823355
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os.environ['a'] = 'b'
    os.environ['c'] = 'd'
    test_obj = _TextEnviron()
    assert set(['a', 'c']) == set(test_obj.keys())


# Generated at 2022-06-21 08:58:55.067429
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    test_env = {}
    text_env = _TextEnviron(env=test_env, encoding='utf-8')
    assert isinstance(text_env, _TextEnviron)
    assert text_env._raw_environ == test_env
    assert text_env.encoding == 'utf-8'

    if PY3:
        test_env = {'FOO': 'foo', 'BAR': 'bar'}
    else:
        test_env = {'FOO': b'foo', 'BAR': b'bar'}
    text_env = _TextEnviron(env=test_env, encoding='utf-8')
    assert text_env == {'FOO': 'foo', 'BAR': 'bar'}

# Generated at 2022-06-21 08:58:58.380798
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():

    len_environ = len(environ)
    assert isinstance(len_environ, int)


# Generated at 2022-06-21 08:59:01.802388
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)

test__TextEnviron___len__()



# Generated at 2022-06-21 08:59:04.957882
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    dict = {'a': 'a', 'b': 'b'}
    textEnviron = _TextEnviron(dict)
    del textEnviron['a']
    assert 'a' not in dict


# Generated at 2022-06-21 08:59:09.993957
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    env[b'string'] = 'string'
    env[b'bytes'] = b'bytes'
    env[b'unicode'] = u'unicode'

    assert env[b'string'] == 'string'
    assert env[b'bytes'] == u'bytes'
    assert env[b'unicode'] == u'unicode'

# Generated at 2022-06-21 08:59:12.550748
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    expected = os.environ
    actual = _TextEnviron()
    assert list(expected) == list(actual)



# Generated at 2022-06-21 08:59:20.160500
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os.environ.update({'FOO': 'FOO', 'BAR': 'BAR'})
    env = _TextEnviron()
    env_iter = env.__iter__()
    assert 'FOO' == env_iter.__next__()
    assert 'BAR' == env_iter.__next__()
    # Raise StopIteration exception
    try:
        env_iter.__next__()
    except StopIteration:
        pass
    except Exception as e:
        # Raise error if any
        raise e


# Generated at 2022-06-21 08:59:29.705226
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    e = _TextEnviron()
    b1 = b'spam'
    b2 = b'eggs'
    t1 = 'spam'
    t2 = 'eggs'
    assert (b1, b2) == (e.setdefault('foo', b1), e.setdefault('bar', b2))
    assert (t1, t2) == (e['foo'], e['bar'])

    e['foo'] = b1
    e['bar'] = b2
    assert (t1, t2) == (e['foo'], e['bar'])

    e['foo'] = t1
    e['bar'] = t2
    assert (t1, t2) == (e['foo'], e['bar'])


# Generated at 2022-06-21 08:59:30.697175
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    pass


# Generated at 2022-06-21 08:59:39.207451
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ._raw_environ['TEST'] = b'foo'
    assert environ['TEST'] == u'foo'

    environ['TEST'] = b'bar'
    assert environ['TEST'] == u'bar'

    environ['TEST'] = u'baz'
    assert environ['TEST'] == u'baz'

    try:
        environ['TEST'] = object
        assert False
    except TypeError:
        pass

    try:
        environ['TEST'] = 1
        assert False
    except TypeError:
        pass


# Generated at 2022-06-21 08:59:43.262841
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Arrange
    env = _TextEnviron({'one': '1', 'two': '2', 'three': '3'}, encoding='utf-8')
    # Act
    del env['one']
    # Assert
    assert 'one' not in env


# Generated at 2022-06-21 08:59:50.042919
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_mock = {'key_one': 'value_one', 'key_two': 'value_two'}
    text_environ = _TextEnviron(env=environ_mock)
    assert text_environ['key_one'] == 'value_one'
    assert text_environ['key_two'] == 'value_two'

# Generated at 2022-06-21 08:59:52.737388
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron()
    env['KEY'] = 'VALUE'
    assert 'KEY' in env

    del env['KEY']
    assert 'KEY' not in env

# Generated at 2022-06-21 08:59:59.623685
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test using the constructor with no args
    os.environ['ANSIBLE_TEST_BYTES_KEY'] = b'test\xe4\xb8\xad\xe6\x96\x87'
    del os.environ['ANSIBLE_TEST_TEXT_KEY']
    te = _TextEnviron()
    assert te['ANSIBLE_TEST_BYTES_KEY'] == u'test\u4e2d\u6587'
    assert te['ANSIBLE_TEST_TEXT_KEY'] == u''
    assert u'ANSIBLE_TEST_BYTES_KEY' in te
    assert u'ANSIBLE_TEST_TEXT_KEY' in te
    assert 'ANSIBLE_TEST_BYTES_KEY' in te
    assert 'ANSIBLE_TEST_TEXT_KEY' not in te

# Generated at 2022-06-21 09:00:01.318841
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert (list(environ) == list(os.environ))


# Generated at 2022-06-21 09:00:04.100411
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    cache = _TextEnviron(env={'a': 1, 'b': 2})
    assert sorted(list(cache)) == ['a', 'b']


# Generated at 2022-06-21 09:00:05.839929
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ._raw_environ, MutableMapping)



# Generated at 2022-06-21 09:00:11.942047
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({b'TEST1': b'TESTSTRING', b'TEST2': b'H\xc3\xbcbi'}, encoding='utf-8')
    # Test keys
    env_keys = list(iter(env))
    assert len(env_keys) == 2, 'len(env_keys) is %s' % len(env_keys)
    assert 'TEST1' in env_keys
    assert 'TEST2' in env_keys


# Generated at 2022-06-21 09:00:16.661428
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['ANSIBLE_PROCESS_HOST'] = 'host'
    assert environ['ANSIBLE_PROCESS_HOST'] == environ._raw_environ['ANSIBLE_PROCESS_HOST']
    assert isinstance(environ['ANSIBLE_PROCESS_HOST'], str)
    assert isinstance(environ._raw_environ['ANSIBLE_PROCESS_HOST'], bytes)



# Generated at 2022-06-21 09:00:19.606785
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Create a TextEnviron with a known len of 1
    t_environ = _TextEnviron({'key': 'value'})
    assert len(t_environ) == 1


# Generated at 2022-06-21 09:00:21.409777
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['testing'] = 'testing'
    del environ['testing']
    assert environ.get('testing') is None



# Generated at 2022-06-21 09:00:25.732048
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    env["name"] = "中国"
    assert env["name"] == "中国"

# Generated at 2022-06-21 09:00:35.762493
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import io
    # define the text string for checking
    a_str_1 = "my name is %s\n" % "John"
    a_str_2 = "my name is %s\n" % "John"
    # ensure the string is of type byte
    if sys.version_info.major == 3 and isinstance(a_str_2, str):
        a_str_2 = bytes(a_str_2, 'utf-8')

    # define key to be set
    key = "test-key"
    # set bytes string in environ
    environ[key] = a_str_1
    # set utf-8 string in os.environ
    os.environ[key] = a_str_2
    # check the value stored in environ and os.environ
    assert a_str_

# Generated at 2022-06-21 09:00:40.345159
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from six import text_type
    from ansible.module_utils import common_errno

    environ['str_key'] = b'value'
    assert isinstance(environ['str_key'], text_type)
    assert environ['str_key'] == u'value'

    environ['unicode_key'] = u'value'
    assert isinstance(environ['unicode_key'], text_type)
    assert environ['unicode_key'] == u'value'

    environ['int_key'] = 42
    assert isinstance(environ['int_key'], text_type)
    assert environ['int_key'] == u'42'

    try:
        environ['error_int_key'] = common_errno.ETIMEDOUT
    except TypeError:
        pass

# Generated at 2022-06-21 09:00:46.903603
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    global _TextEnviron
    class _TextEnviron(MutableMapping):
        def __init__(self):
            self.key = 'value'
        def __delitem__(self, key):
            return '__delitem__'
    assert _TextEnviron().__delitem__('key') == '__delitem__'
test__TextEnviron___delitem__()



# Generated at 2022-06-21 09:00:52.332802
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ.clear()
    environ['type1'] = 'foo'
    environ['type1'] = 1
    environ['type2'] = ['a', 'b', 'c']
    environ['type3'] = {'a': 1, 'b': 2, 'c': 3}

    result = ""
    for key in environ:
        result = result + key

    assert "type1type2type3" == result

# Generated at 2022-06-21 09:00:55.310679
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils._text import to_text
    os.environ['test__setitem__'] = 'test__setitem__'
    assert(environ['test__setitem__'] == to_text('test__setitem__', encoding='utf-8'))
    del os.environ['test__setitem__']

# Generated at 2022-06-21 09:01:07.174765
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print("test__TextEnviron___getitem__")
    default_encoding = sys.getfilesystemencoding()
    print("default encoding:", default_encoding)
    # Cyrillic characters
    test_c = to_bytes('Привет мир', encoding=default_encoding)
    os.environ[b'c_var'] = test_c
    c = environ[b'c_var']
    print("c:", c)
    assert isinstance(c, str)
    assert b'c_var' in os.environ
    assert os.environ[b'c_var'] == test_c

    # Greek characters

# Generated at 2022-06-21 09:01:10.416416
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    os.environ.clear()
    os.environ['foo'] = 'bar'
    environ = _TextEnviron()
    assert 'foo' in environ
    assert environ['foo'] == u'bar'
    environ['foo'] = u'baz'
    assert 'foo' in environ
    assert environ['foo'] == u'baz'

# Generated at 2022-06-21 09:01:12.458315
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():

    def t_iter():
        for key, value in environ.items():
            yield key, value

    list(t_iter())

# Generated at 2022-06-21 09:01:15.233233
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ.clear()
    environ['FOO'] = 'BAR'
    assert environ['FOO'] == 'BAR'
    del environ['FOO']
    assert 'FOO' not in environ



# Generated at 2022-06-21 09:01:31.491837
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    assert environ['ANSIBLE_TEST'] == 'ANSIBLE_TEST'
    assert environ['ANSIBLE_TEST'] == 'ANSIBLE_TEST'
    assert environ['ANSIBLE_TEST'] == 'ANSIBLE_TEST'
    assert environ['ANSIBLE_TEST'] == 'ANSIBLE_TEST'
    assert environ['ANSIBLE_TEST'] == 'ANSIBLE_TEST'
    assert environ['ANSIBLE_TEST'] == 'ANSIBLE_TEST'
    assert environ['ANSIBLE_TEST'] == 'ANSIBLE_TEST'
    assert environ['ANSIBLE_TEST'] == 'ANSIBLE_TEST'
    assert environ['ANSIBLE_TEST'] == 'ANSIBLE_TEST'
    assert environ['ANSIBLE_TEST'] == 'ANSIBLE_TEST'

# Generated at 2022-06-21 09:01:37.958231
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    the results of the method ``__getitem__`` should be text
    """
    environ1 = _TextEnviron({b'foo': b'bar', b'baz': b'qux'}, encoding='utf-8')
    assert isinstance(environ1['foo'], text_type)
    assert isinstance(environ1['baz'], text_type)
    assert environ1['foo'] == 'bar'
    assert environ1['baz'] == 'qux'

# Generated at 2022-06-21 09:01:39.205639
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-21 09:01:45.817921
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Arrange
    import ansible.module_utils.common._collections_compat
    text_environ = _TextEnviron(env={'key1': 'value1', 'key2': 'value2'})

    # Act
    iterable = text_environ.__iter__()

    # Assert
    assert isinstance(iterable, ansible.module_utils.common._collections_compat.Iterator)


# Generated at 2022-06-21 09:01:49.584509
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils._text import to_bytes

    env = {to_bytes('foo'): to_bytes('bar')}
    environ = _TextEnviron(env=env, encoding='utf-8')
    assert len(environ) == 1



# Generated at 2022-06-21 09:01:59.791673
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ._raw_environ = {}
    environ._value_cache = {}
    environ.encoding = 'utf-8'

    # Encode text of type string and unicode
    environ['key1'] = 'string value'
    assert environ['key1'] == 'string value'
    assert environ._raw_environ['key1'] == b'string value'
    environ['key2'] = u'unicode value'
    assert environ['key2'] == u'unicode value'
    assert environ._raw_environ['key2'] == b'unicode value'

    # Do not encode non-string
    environ['key3'] = False
    assert environ['key3'] == False
    assert environ._raw_environ['key3'] == False

    # Check __setitem__

# Generated at 2022-06-21 09:02:05.983407
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_str = u'\xe7\x8c\xab\xe5\xad\x90'
    environ[test_str] = u'\xe7\x8c\xab\xe5\xad\x90'
    assert environ[test_str] == u'\xe7\x8c\xab\xe5\xad\x90'


# Generated at 2022-06-21 09:02:11.850081
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test that we can override the encoding used
    env = _TextEnviron(encoding='us-ascii')
    assert env.encoding == 'us-ascii'
    # Test that we can pass in an initial environment
    env = _TextEnviron({b'FOO': b'bar', b'BAR': b'baz'})
    assert env[b'FOO'] == 'bar'
    assert env[b'BAR'] == 'baz'


# Unit tests for the _TextEnviron class

# Generated at 2022-06-21 09:02:21.640068
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """_TextEnviron.__getitem__()
    gets the string value from the environment variable specified by key.
    """
    os.environ[to_bytes('string_value')] = to_bytes('value is a string')
    os.environ[to_bytes('bytes_value')] = b'value is bytes'
    # Instantiation of class _TextEnviron should return text string from the environment
    # variable
    te = _TextEnviron()
    assert te.encoding == sys.getfilesystemencoding()
    assert te['string_value'] == u'value is a string'
    assert te['bytes_value'] == u'value is bytes'

# Generated at 2022-06-21 09:02:29.992589
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Scenario 1: Assign some value in ASCII to the key.
    # Expected value: ASCII text.
    key = 'key1'
    value = 'value1'
    environ[key] = value
    assert environ[key] == u'value1'

    # Scenario 2: Assign some value in UTF-8 to the key.
    # Expected value: UTF-8 text.
    environ[key] = u'値'
    assert environ[key] == u'値'

    # Scenario 3: Assign some value to the key which has non-ASCII character.
    # Expected value: Text with the non-ASCII character converted to Unicode
    # UCS-4 escape.
    environ[key] = 'value\xc0'

# Generated at 2022-06-21 09:02:43.458871
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    item = environ["PATH"]
    assert item == "/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/home/oracle/.local/bin:/home/oracle/bin", \
        "environ[\"PATH\"] = %r" % item
    pass

# Generated at 2022-06-21 09:02:52.785292
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    v = to_bytes('a€', encoding='utf-8')
    os.environ[b'foo'] = v

    environ2 = _TextEnviron()

    assert type(environ2) == _TextEnviron
    assert environ2._raw_environ is os.environ
    assert environ2._value_cache == {}
    assert environ2.encoding == sys.getfilesystemencoding()
    assert environ2['foo'] == to_text(v, encoding='utf-8')

    environ2 = _TextEnviron({b'foo': v, b'bar': b'baz'})
    assert type(environ2) == _TextEnviron
    assert environ2._raw_environ == {b'foo': v, b'bar': b'baz'}
    assert environ2._

# Generated at 2022-06-21 09:02:55.062867
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    y = environ.__iter__()
    while True:
        try:
            x = next(y)
            print(x)
        except StopIteration:
            print("Collections finished")
            break

# Generated at 2022-06-21 09:02:59.717471
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron(encoding='utf-8')
    env['my_key'] = u'\xe4'
    env['other_key'] = b' \xe4'

    assert env['my_key'] == b'\xc3\xa4'
    assert env['other_key'] == b' \xc3\xa4'

# Generated at 2022-06-21 09:03:08.629586
# Unit test for method __setitem__ of class _TextEnviron

# Generated at 2022-06-21 09:03:19.415401
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test that it can handle ASCII
    assert(to_bytes('key1') in environ)
    environ['key1'] = 'value1'
    assert(environ['key1'] == 'value1')
    # Test that it can handle unicode with multibyte characters
    assert(to_bytes('key2') in environ)
    environ['key2'] = u'value2'
    assert(environ['key2'] == u'value2')
    # Test that it can handle non-unicode strings
    assert(to_bytes('key3') in environ)

# Generated at 2022-06-21 09:03:27.420709
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Test the case when item is in environ
    # Setup the environment
    test_env = {'key1': 'value1', 'key2': 'value2'}
    env1 = _TextEnviron(env=test_env)
    assert 'key1' in env1
    assert 'key2' in env1
    assert 'key1' in env1._raw_environ
    assert 'key2' in env1._raw_environ
    # Execute the code to be tested
    env1.__delitem__('key1')
    # Verify the results
    assert 'key1' not in env1
    assert 'key1' not in env1._raw_environ

    # Test the case when item is not in environ
    # Setup the environment

# Generated at 2022-06-21 09:03:29.001933
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert environ.__iter__() is environ._raw_environ.__iter__()


# Generated at 2022-06-21 09:03:30.701317
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """Unit test for method __len__ of class _TextEnviron."""
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 09:03:38.285828
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    global environ
    # Case 1: b is bytes; value is bytes
    b = b'foo'
    environ[b] = b'bar'
    assert b in environ
    assert environ[b] == b'bar'
    assert environ._raw_environ[b] == b'bar'
    # Case 2: b, value is bytes; b is unicode
    b = 'foo'
    environ[b] = b'bar'
    assert b in environ
    assert environ[b] == b'bar'
    assert environ._raw_environ[b] == b'bar'
    # Case 3: b, value is unicode; b is bytes
    b = b'foo'
    environ[b] = 'bar'
    assert b in environ

# Generated at 2022-06-21 09:04:04.296325
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Setup
    os.environ['LC_CTYPE'] = 'utf-8'
    ENC = 'utf-8'

    # Setup expected result
    expected_result = 0

    # Test case
    environ = _TextEnviron({'LC_CTYPE': 'utf-8'}, ENC)
    del environ['LC_CTYPE']
    result = len(environ)

    # Verify result
    assert expected_result == result


# Generated at 2022-06-21 09:04:08.221049
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({'k': 'v'})
    assert environ['k'] == 'v'
    if not PY3:
        environ['k'] = b'\xc3\x9f'
        assert environ['k'] == u'\u00df'
        environ['k'] = b'\xe2\x9d\xa4'
        assert environ['k'] == u'\u2764'
        environ['k'] = b'\xf0\x9f\x92\xa9'
        assert environ['k'] == u'\U0001f4a9'



# Generated at 2022-06-21 09:04:10.564499
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron(encoding='utf-8')
    assert environ.encoding == 'utf-8'

    environ = _TextEnviron()
    assert environ.encoding == 'mbcs'

# Generated at 2022-06-21 09:04:19.179184
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import doctest
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing import vault
    from ansible.parsing.vault import VaultLib
    results = doctest.testmod()
    assert not results.failed
    # Test that we can pass an env variable with a unicode value
    env = {to_bytes('string', errors='surrogate_or_strict'): to_bytes('⌘', errors='surrogate_or_strict')}
    assert isinstance(_TextEnviron(env), MutableMapping)
    text_env = _TextEnviron(env)
    assert to_text('string', errors='surrogate_or_strict') in text_env
    assert '⌘' == text_env['string']
    # Test that

# Generated at 2022-06-21 09:04:30.255490
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test the case when PY3 is True
    PY3_old = PY3
    PY3 = True
    assert environ._raw_environ['HOME'] == environ['HOME']
    PY3 = PY3_old

    # Test the case when PY3 is False
    PY3_old = PY3
    PY3 = False
    assert environ._raw_environ['HOME'] == environ['HOME']
    PY3 = PY3_old

    # Test the case when PY3 is False and key is not cached
    PY3_old = PY3
    PY3 = False
    assert environ._raw_environ['HOME'] == environ['HOME']
    PY3 = PY3_old

    # Test the case if key is not present in the dictionary


# Generated at 2022-06-21 09:04:31.098603
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) >= 1


# Generated at 2022-06-21 09:04:33.751087
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['test_key'] = 'test_value'
    del environ['test_key']
    assert 'test_key' not in environ


# Generated at 2022-06-21 09:04:41.218907
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    class TestEnviron(object):
        def __init__(self, items=None):
            if items is None:
                self.items = {}
            else:
                self.items = items

        def __getitem__(self, key):
            return self.items[key]

        def __setitem__(self, key, value):
            self.items[key] = value

        def __delitem__(self, key):
            del self.items[key]

        def __iter__(self):
            return iter(self.items)

        def __len__(self):
            return len(self.items)

    test_environ = {'foo': 'bar', 'baz': 'qux'}
    test_env = TestEnviron(items=test_environ)

# Generated at 2022-06-21 09:04:43.873916
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    _env = _TextEnviron()
    _env['A'] = 'b'
    assert isinstance(_env._raw_environ['A'], bytes)

# Generated at 2022-06-21 09:04:46.887358
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """_TextEnviron: Method __len__"""
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 09:05:33.397012
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test Class _TextEnviron's method __getitem__ to ensure the environment key is returned as a text
    string
    """

    class MockedOsEnviron:
        def __init__(self, env_dict):
            self._raw_environ = env_dict
        
        def __getitem__(self, key):
            return self._raw_environ[key]

    # Test Case 1: Key is not in os.environ
    env_dict = {"aaa": "aabbcc"}
    text_environ = _TextEnviron(MockedOsEnviron(env_dict))
    try:
        text_environ["bbb"]
        assert False
    except KeyError:
        assert True

    # Test Case 2: Key is in os.environ and a text string

# Generated at 2022-06-21 09:05:42.426804
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    class MockEnviron(object):
        """
        Mocks out os.environ and gets us a dict that's similar to os.environ
        """
        def __init__(self):
            self._dict = {}
            self._list = []
            self._len = 0

        def __setitem__(self, key, value):
            self._dict[key] = value
            self._list.append(key)
            self._len = len(self._list)

        def __getitem__(self, key):
            return self._dict.get(key, None)

        def __delitem__(self, key):
            del self._dict[key]
            self._list.remove(key)
            self._len = len(self._list)

        def __iter__(self):
            return self._list.__iter__

# Generated at 2022-06-21 09:05:51.962627
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    def _get_from_environ(key):
        return environ[key]

    # Unset variables should return as None
    assert environ['FOOBAR'] is None

    # Set the encoding to utf-8 explicitly
    environ = _TextEnviron(encoding='utf-8')
    # Test that there's no data in the cache
    assert environ._value_cache == {}

    # Test that an ascii string comes out as a text string
    os.environ['FOOBAR'] = b'I am plain text'
    assert environ['FOOBAR'] == u'I am plain text'

    # Test that a text string goes in as a byte string
    environ['FOOBAR'] = u'I am text'
    assert os.environ['FOOBAR'] == b'I am text'

    #

# Generated at 2022-06-21 09:06:03.120239
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    '''
    Unit test for method __setitem__ of class _TextEnviron
    '''
    env_copy = environ.copy()
    test_key = 'foo'
    test_value = 'bar'
    # Test case 1
    try:
        environ[test_key] = test_value
        assert test_key in environ
        assert environ[test_key] == test_value
    finally:
        # Restore original environment
        environ.clear()
        environ.update(env_copy)
    # Test case 2
    try:
        environ[test_key] = 1
        assert test_key in environ
        assert environ[test_key] == '1'
    finally:
        # Restore original environment
        environ.clear()
        environ.update(env_copy)
