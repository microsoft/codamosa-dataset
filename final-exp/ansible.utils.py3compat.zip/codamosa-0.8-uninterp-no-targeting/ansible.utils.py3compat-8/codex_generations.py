

# Generated at 2022-06-21 08:56:02.837587
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Setup
    environ = _TextEnviron()
    set_item_key = 'test_key'
    set_item_value = u'value'
    # Execute
    environ[set_item_key] = set_item_value
    # Verify
    assert environ
    assert set_item_key in environ
    assert environ[set_item_key] == set_item_value


# Generated at 2022-06-21 08:56:06.983760
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    global environ

    environ_dict = {'A': '1', 'B': '2', 'C': '3'}
    environ = _TextEnviron(env=environ_dict)

    environ_iter = environ.__iter__()

    for x in environ_iter:
        assert x in environ_dict, "Invalid iterator result"


# Generated at 2022-06-21 08:56:11.351875
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron()
    key = b'\xc3\xbc' if PY3 else u'ü'
    environ[key] = 'avocado'
    assert environ._raw_environ[key] == b'avocado'

# Generated at 2022-06-21 08:56:22.117923
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Ensure that _TextEnviron works
    """
    os.environ[b'ANSIBLE_TEST_ENCODING'] = b'value binary'
    te = _TextEnviron()
    assert 'ANSIBLE_TEST_ENCODING' in te
    assert te[b'ANSIBLE_TEST_ENCODING'] == 'value binary'
    assert te[u'ANSIBLE_TEST_ENCODING'] == 'value binary'
    assert te['ANSIBLE_TEST_ENCODING'] == 'value binary'
    assert 'ANSIBLE_TEST_ENCODING' in te
    assert 'ANSIBLE_TEST_ENCODING' in te
    assert 'ANSIBLE_TEST_ENCODING' in te



# Generated at 2022-06-21 08:56:29.430429
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        def test():
            assert environ["NONEXISTANT"] == "NONEXISTANT"
    else:
        def test():
            # UnicodeDecodeError is raised if the key is not in the environment
            try:
                environ["NONEXISTANT"]
            except UnicodeDecodeError:
                pass
    test()
    # to_text(...) should be memoized
    assert id(environ["NONEXISTANT"]) == id(environ["NONEXISTANT"])

# Generated at 2022-06-21 08:56:32.313980
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ['ANSIBLE_MODULE_TEST_VAR'] = 'value'
    assert len(environ) == len(os.environ) == 1


# Generated at 2022-06-21 08:56:34.748180
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    test_value = _TextEnviron()
    real_value = len(os.environ)
    assert test_value == real_value

# Generated at 2022-06-21 08:56:44.084741
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    The method _TextEnviron.__setitem__() should raise TypeError exception when
    the argument key is not of type string.
    """
    if not PY3:
        environ.clear()
        environ['key1'] = 'value1'
        assert(environ['key1'] == u'value1')
        environ['key1'] = b'value1'
        assert(environ['key1'] == u'value1')
        environ['key1'] = 1
        assert(environ['key1'] == u'1')
        environ['key1'] = True
        assert(environ['key1'] == u'True')
        environ['key1'] = bytearray('value1', 'utf-8')
        assert(environ['key1'] == u'value1')


# Generated at 2022-06-21 08:56:55.107615
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test for usual environ encoding
    test_env = _TextEnviron({'key_str': 'val_str',
                             'key_bytes': to_bytes('val_bytes', encoding='utf-8')},
                            encoding='utf-8')
    assert test_env['key_str'] == 'val_str'
    assert test_env['key_bytes'] == 'val_bytes'
    # test for environ encoding = 'ascii'
    test_env = _TextEnviron({'key_str': 'val_str',
                             'key_bytes': to_bytes('val_bytes', encoding='utf-8')},
                            encoding='ascii')
    assert test_env['key_str'] == 'val_str'

# Generated at 2022-06-21 08:57:03.303225
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # pylint: disable=invalid-name
    if '__TextEnviron_testing' in environ:
        del environ['__TextEnviron_testing']
    environ['__TextEnviron_testing'] = 'Unit test'
    assert environ['__TextEnviron_testing'] == 'Unit test'
    del environ['__TextEnviron_testing']
    assert '__TextEnviron_testing' not in environ
    del environ['__TextEnviron_testing']  # KeyError: '__TextEnviron_testing'
    # pylint: enable=invalid-name



# Generated at 2022-06-21 08:57:08.258574
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron(env={'first': '1', 'second': '2'})
    assert len(environ) == 2

# Generated at 2022-06-21 08:57:12.372940
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ.clear()
    os.environ[to_bytes('ANSIBLE_FOO', encoding='utf-8')] = to_bytes('BAR', encoding='utf-8')
    assert 'ANSIBLE_FOO' in environ
    del environ['ANSIBLE_FOO']
    assert 'ANSIBLE_FOO' not in environ



# Generated at 2022-06-21 08:57:14.901844
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ), 'length environ should be equal length of os.environ'


# Generated at 2022-06-21 08:57:26.179672
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import io
    import os
    import sys
    import unittest
    # Python2
    if not PY3:
        # Our constructor defaults to os.environ and uses the file system encoding
        env = _TextEnviron()
        assert env._raw_environ is os.environ
        assert env.encoding == sys.getfilesystemencoding()

        # If we're passed an encoding, it uses it
        env = _TextEnviron(encoding='ascii')
        assert env._raw_environ is os.environ
        assert env.encoding == 'ascii'

        # If passed a mapping, it uses that
        d = {'foo': 'bar'}
        env = _TextEnviron(d)
        assert env._raw_environ is d
        assert env.encoding == sys.getfiles

# Generated at 2022-06-21 08:57:35.926981
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Test for method __getitem__ of class _TextEnviron
    '''
    env = _TextEnviron(encoding='utf-8')
    # For PY3, check that you can get a unicode string out
    env['ANSIBLE_FORCE_COLOR'] = '1'
    assert env['ANSIBLE_FORCE_COLOR'] == u'1'
    # For Python2, check that you can get a unicode string out
    env['ANSIBLE_FORCE_COLOR'] = '1'
    assert env['ANSIBLE_FORCE_COLOR'] == u'1'
    # For Python2, check that you can get a unicode string out
    env['ANSIBLE_FORCE_COLOR'] = u'1'
    assert env['ANSIBLE_FORCE_COLOR'] == u'1'
    # For Python2

# Generated at 2022-06-21 08:57:43.472409
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    old_environ = {'PYTHONPATH': '//usr/local/bin/python3.6', 'LANG': 'en_US.UTF-8'}
    test_environ = _TextEnviron(encoding='utf-8')
    test_environ._raw_environ = old_environ
    assert test_environ['PYTHONPATH'] == '//usr/local/bin/python3.6'
    assert test_environ['LANG'] == 'en_US.UTF-8'

# Generated at 2022-06-21 08:57:49.675475
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    test = _TextEnviron({b'test\xc3\xb8': b'val\xc3\xb8ue'})
    assert len(test) == 1
    assert len(os.environ) == 2
    del test[u'testø']
    assert len(test) == 0
    assert len(os.environ) == 1


# Generated at 2022-06-21 08:57:58.799714
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = dict(
        simple='value of simple',
        non_ascii=u'\u6653\u6653',
        non_ascii_bytes=u'\u6653\u6653'.encode('utf-8'),
        non_ascii_pct_encoded='%e6%99%83%e6%99%83',
        non_unicode_bytes='\xe6\x99\x83\xe6\x99\x83',
    )
    env_text = _TextEnviron(env=env, encoding='utf-8')
    for key, value in env_text.items():
        assert not isinstance(key, bytes)
    assert set(env_text) == set(env)



# Generated at 2022-06-21 08:58:10.657473
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test which raw values will be managed by the caching mechanism
    values_to_cache = ('\xe2\x98\x83', '\xe2\x98')

    # Make sure that we get a text object back from __getitem__
    assert isinstance(environ['ANSIBLE_TESTVAR_U8'], unicode)
    # Make sure that we get the same value back every time
    assert environ['ANSIBLE_TESTVAR_U8'] == unicode('value_u8', 'utf8')
    assert environ['ANSIBLE_TESTVAR_U8'] == 'value_u8'
    assert environ['ANSIBLE_TESTVAR_U8'] == unicode('value_u8', 'utf8')

# Generated at 2022-06-21 08:58:13.200927
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ_ = _TextEnviron()
    assert len(environ_) == len(os.environ)


# Generated at 2022-06-21 08:58:30.030508
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils.common._collections_compat import MutableMapping
    import os
    # Unset PYTHONPATH so that we don't have a bunch of unneeded modules loading
    os.environ.pop('PYTHONPATH', None)
    import sys

    # Monkeypatch first since we're testing that we didn't do a destructive copy.
    # Then construct the _TextEnviron to test that we did things properly.
    raw_environ = os.environ
    try:
        utf8 = _TextEnviron(encoding='utf-8')
        ascii = _TextEnviron(encoding='ascii')
        latin1 = _TextEnviron(encoding='latin-1')
    finally:
        os.environ = raw_environ


# Generated at 2022-06-21 08:58:35.610811
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global environ
    environ = _TextEnviron({})

    environ['foo'] = u'bar'
    assert environ['foo'] == u'bar'
    environ['foo'] = b'bar'
    assert environ['foo'] == u'bar'
    environ['foo'] = 'bar'
    assert environ['foo'] == u'bar'
    environ['foo'] = 'b\xc3\xa4r'
    assert environ['foo'] == u'b\xe4r'
    environ['foo'] = b'b\xc3\xa4r'
    assert environ['foo'] == u'b\xe4r'

# Generated at 2022-06-21 08:58:44.977704
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test __setitem__() for a key/value pair with a '#' in the value.
    key = 'test_key'
    value = '#test_value#'
    environ_test = _TextEnviron({}, encoding='utf-8')
    environ_test[key] = value
    # Verify that the value in the cache is the same as the value being set.
    assert environ_test[key] == value
    # Verify that the key in the cache is the same as the key being set.
    assert value in environ_test._value_cache
    assert environ_test._value_cache[value] == value

    # Test __setitem__() for a key/value pair with values:
    #  - both empty strings
    #  - the key is an empty string
    #  - the value is an empty

# Generated at 2022-06-21 08:58:55.598389
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import collections
    import unittest

    class _TextEnviron__setitem__TestCase(unittest.TestCase):
        def test_nonstring_to_bytes(self):
            env = _TextEnviron()
            class Str(object):
                def __str__(self):
                    raise UnicodeEncodeError(b'UnicodeEncodeError', u'foo', 0, 1, b'bar')
            env['foo'] = Str()
            self.assertEqual(env['foo'], b'foo')

        def test_bytes_id_unchanged(self):
            env = _TextEnviron()
            # Make sure that the bytes do not change across conversion
            bytes_id = id(b'bytes')
            env['foo'] = b'bytes'
            new_bytes_id = id(env['foo'])


# Generated at 2022-06-21 08:59:00.665638
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    my_env = _TextEnviron({b'a': b'\xe2\x99\xa5', b'b': sys.getfilesystemencoding()})
    type(my_env['a']) == str
    my_env['b'] == sys.getfilesystemencoding()

# Generated at 2022-06-21 08:59:07.589568
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import six
    import pytest
    from ansible.module_utils._text import to_bytes, to_text

    env = _TextEnviron()
    assert len(env) == len(environ)
    for key, value in env._raw_environ.items():
        raw_value = env._raw_environ[key]
        assert isinstance(raw_value, six.binary_type)
        assert value == to_text(raw_value, env.encoding)

        # Make sure that a value is cached
        env[key]
        cached_value = env._value_cache[raw_value]
        assert isinstance(cached_value, six.text_type)
        assert value == cached_value
        assert value == env[key]

    # Make sure that a key which we haven't seen yet returns a unicode object

# Generated at 2022-06-21 08:59:08.374277
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    assert True


# Generated at 2022-06-21 08:59:17.201442
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    class _DummyEnviron(MutableMapping):
        def __init__(self, env=None):
            pass

        def __getitem__(self, k):
            return 'a'

        def __setitem__(self, k, v):
            pass

        def __delitem__(self, k):
            pass

        def __iter__(self):
            return iter('a')

        def __len__(self):
            return 1

    result = sorted(list(_TextEnviron(_DummyEnviron())))
    assert result == ['a']


# Generated at 2022-06-21 08:59:21.210861
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    assert 'SOME_VAR' in environ

    del environ['SOME_VAR']

    assert 'SOME_VAR' not in environ

    # Restore environment variable
    environ['SOME_VAR'] = '1'



# Generated at 2022-06-21 08:59:24.806783
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron(env={'ansible': 'awesome', 1: 'number'}, encoding='utf-8')
    assert [item for item in env] == list(env._raw_environ.keys())



# Generated at 2022-06-21 08:59:38.081729
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils.six import iterkeys
    from ansible.module_utils.common._collections_compat import OrderedDict
    env = OrderedDict()
    env['ANSIBLE_INTERNAL_TEST_ENV'] = 'internal'
    env['ANSIBLE_TEST_ENV'] = 'test'
    env['ANSIBLE_SERVER_ENV'] = 'server'
    text_env = _TextEnviron(env, encoding='utf-8')

    assert iterkeys(text_env) == iterkeys(env)

    return True


# Generated at 2022-06-21 08:59:43.328591
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron()
    env['SOME'] = "ENV"
    assert env['SOME'] == "ENV"
    del env['SOME']
    assert env['SOME'] == ''
    # check if the environment is not changed after deleting from the proxy
    assert os.environ['SOME'] == "ENV"


# Generated at 2022-06-21 08:59:47.957733
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({b'ANSIBLE_FOO': b'BAR', b'ANSIBLE_BAZ': b'BAH'})
    assert list(iter(env)) == ['ANSIBLE_FOO', 'ANSIBLE_BAZ']



# Generated at 2022-06-21 08:59:55.352932
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = dict(os.environ)
    env.update(test_var1='test_value1', test_var2='test_value2')
    text_env = _TextEnviron(env=env)

    assert 'test_var1' in text_env
    text_env.__delitem__('test_var1')
    assert 'test_var1' not in text_env

    assert 'test_var2' in text_env
    text_env.__delitem__('test_var2')
    assert 'test_var2' not in text_env


# Generated at 2022-06-21 09:00:02.438672
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Set up environment
    environ.clear()
    key1 = to_bytes('key1', encoding='utf-8')
    value1 = to_bytes('value1', encoding='utf-8')
    environ[key1] = value1
    # test
    for key in environ:
        assert key == key1
        assert environ[key] == value1


# Generated at 2022-06-21 09:00:06.268530
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['ANSIBLE_MODULE_ARGS'] = '{}'
    assert 'ANSIBLE_MODULE_ARGS' in environ
    del environ['ANSIBLE_MODULE_ARGS']
    assert 'ANSIBLE_MODULE_ARGS' not in environ


# Generated at 2022-06-21 09:00:09.816260
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    with environ.mapping() as temp_env:
        temp_env['FOO'] = 'bar'
        assert 'FOO' in temp_env
        del temp_env['FOO']
        assert 'FOO' not in temp_env


# Generated at 2022-06-21 09:00:18.706952
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # vars() returns a dict of the global env; we are mocking that.
    global environ
    environ = {'HOME': '/tmp/home'}
    assert isinstance(environ['HOME'], str)
    assert isinstance(environ, _TextEnviron)
    # os.environ.environ calls iter() on the dict.  So we will too.
    # We need to use next() to get the first value from the iter.
    assert getattr(next(iter(environ)), 0, None) == 'HOME'
    # Restore the real global env.
    global environ
    environ = _TextEnviron()