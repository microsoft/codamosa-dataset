

# Generated at 2022-06-21 08:56:01.047391
# Unit test for method __setitem__ of class _TextEnviron

# Generated at 2022-06-21 08:56:02.886915
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    len_env = len(environ)
    assert(len_env == len(os.environ))


# Generated at 2022-06-21 08:56:08.059878
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # (1) key is str, value is str
    assert environ['key'] == 'str'

    # (2) key is bytes, value is str
    assert environ[b'key'] == 'str'

    # (3) key is str, value is bytes
    assert environ['key2'] == 'byte'

    # (4) key is bytes, value is bytes
    assert environ[b'key2'] == 'byte'



# Generated at 2022-06-21 08:56:19.886220
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    def get_environ(env, encoding):
        return _TextEnviron(env, encoding)

    # This is here because the environ object already exists.  We're reusing it.  This isn't a
    # unit test thing ;-)
    old_environ = environ
    environ = {}

    # Empty environment
    assert dict(get_environ({}, 'utf-8')) == {}
    assert dict(get_environ({}, 'ascii')) == {}
    assert dict(get_environ({}, 'latin-1')) == {}

    # Empty string
    environ['ANSIBLE_EMPTY_STRING'] = b''
    assert get_environ({'ANSIBLE_EMPTY_STRING': b''}, 'utf-8')['ANSIBLE_EMPTY_STRING'] == u''

# Generated at 2022-06-21 08:56:24.126710
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # env_val = _TextEnviron()
    # delitem()
    assert False, "Test with mock"


# Generated at 2022-06-21 08:56:29.710182
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    class FakeEnviron(MutableMapping):
        def __len__(self):
            return 2
        def __iter__(self):
            return iter(['ANSIBLE_HASH_BEHAVIOUR', 'COLUMNS'])
        def __getitem__(self, key):
            if key == 'ANSIBLE_HASH_BEHAVIOUR':
                # This should be encoded by the _TextEnviron object
                return b'ASK'
            if key == 'COLUMNS':
                # This should be passed through as-is
                return 80
            raise KeyError('Invalid key: %s' % key)
        def __setitem__(self, key, value):
            pass
        def __delitem__(self, key):
            pass

    assert len(_TextEnviron(FakeEnviron())) == 2

# Unit

# Generated at 2022-06-21 08:56:40.948130
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import os
    import unittest

    class Test___setitem__(unittest.TestCase):
        def setUp(self):
            self.env_name = 'PY_TEST_ENV_' + to_text(os.getpid())
            self.env = _TextEnviron()

        def tearDown(self):
            del self.env[self.env_name]

        def test_bytes_value(self):
            expected_key = self.env_name
            expected_value = b'Bytes Value'
            self.env[expected_key] = expected_value
            self.assertEqual(to_bytes(expected_value), self.env._raw_environ[expected_key])
            self.assertEqual(expected_value, self.env[expected_key])


# Generated at 2022-06-21 08:56:46.295193
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron(encoding='utf-8')
    env[u'test__TextEnviron___len__'] = u'test__TextEnviron___len__'
    assert len(env) == len(env._raw_environ)


# Generated at 2022-06-21 08:56:56.210602
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # _TextEnviron.__setitem__() should accept unicode strings
    environ['TEST'] = u"This is a test"
    assert len(list(environ.keys())) == 1
    assert environ['TEST'] == u"This is a test"

    # _TextEnviron.__setitem__() should accept bytes
    environ['TEST'] = b'This is a test'
    assert len(list(environ.keys())) == 1
    assert environ['TEST'] == b'This is a test'

    # _TextEnviron.__setitem__() should raise TypeError if passed a value that isn't bytes or unicode
    try:
        environ['TEST'] = 1
    except TypeError:
        pass
    else:
        assert False, "Didn't raise TypeError"

# Generated at 2022-06-21 08:56:57.797010
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['FOO'] = 'BAR'
    assert environ['FOO'] == 'BAR'

# Generated at 2022-06-21 08:57:05.984546
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import mock

    env = {
        'BIG_ENDIAN_CHAR': '\xc2',
        'LITTLE_ENDIAN_CHAR': '\xd8\xbf',
        'MIXED_ENDIAN_CHAR': '\xc3\xdf',
        'BYTE_STRING': b'byte string',
        'TEXT_STRING': u'text string',
    }

    with mock.patch('os.environ', env):
        for key in _TextEnviron(env):
            assert isinstance(key, str)
            assert key in env

# Generated at 2022-06-21 08:57:10.470792
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ['test1'] = '1'
    assert os.environ.get('test1') == '1'
    assert environ.get('test1') == '1'
    del environ['test1']
    assert os.environ.get('test1') == None
    assert environ.get('test1') == None

# Generated at 2022-06-21 08:57:13.541257
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Success case
    environ['FOO'] = 'bar'
    assert(environ['FOO'] == 'bar')

    # Failure case
    try:
        environ['FOO'] = b'bar'
    except UnicodeEncodeError:
        assert(True)


# Generated at 2022-06-21 08:57:17.517206
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    value = 'this is a test'
    environ['test'] = value
    assert environ['test'] == value
    del environ['test']
    assert 'test' not in environ


# Generated at 2022-06-21 08:57:20.754717
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron({'1': 'a', '2': 'b', '3': 'c'}, encoding='utf-8')
    assert len(environ) == 3

# Generated at 2022-06-21 08:57:24.013607
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    new_env = _TextEnviron(env={'b': 'b', 'a': 'a', '1': '1'}, encoding=None)
    assert set(env.keys()) == set('ba1')

# Generated at 2022-06-21 08:57:31.658346
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    env['key1'] = 'value1'
    assert env['key1'] == 'value1'
    assert env._raw_environ[b'key1'] == b'value1'
    # Make sure we can handle Unicode characters
    env['key2'] = u'\u20ac'
    assert env['key2'] == u'\u20ac'
    assert env._raw_environ[b'key2'] == u'\u20ac'.encode('utf-8')


# Generated at 2022-06-21 08:57:34.276194
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['ansible_python_interpreter'] = 'py3'  # for Python2
    expected = 'py3'
    result = environ['ansible_python_interpreter']
    assert expected == result

# Generated at 2022-06-21 08:57:40.335770
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common._collections_compat import MutableMapping

    class _WrapEnviron(MutableMapping):
        def __init__(self, env):
            """
            Wrap the environ dict so that we can test the second level of __getitem__
            """
            self._raw_environ = env

        def __delitem__(self, key):
            del self._raw_environ[key]

        def __getitem__(self, key):
            return self._raw_environ[key]

        def __setitem__(self, key, value):
            self._raw_environ[key] = value

        def __iter__(self):
            return self._raw_environ.__iter__

# Generated at 2022-06-21 08:57:48.776998
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Create a dictionary with non-ascii unicode keys.
    environ = {u'key1': u'value1', u'rémy'.encode('utf-8'): u'rémy'}
    environ_text = _TextEnviron(env=environ, encoding='utf-8')
    # Observe that when converting to a list, we get the same result as when
    # doing the same operation with a non-unicode dict.
    expected_result = environ.keys()
    assert expected_result == list(environ_text.__iter__())

# Generated at 2022-06-21 08:57:56.317643
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    key, value = 'foo', 'bar'
    environ[key] = value
    assert environ[key] == value
    del environ[key]
    try:
        environ[key]
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 08:58:07.359804
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        return

    def _test_encoded_value(env, encoding, value):
        """
        Create a new _TextEnviron over the existing environment with the given encoding and try
        retrieving the value using it.  The retrieved value should match the given value.
        """
        environ = _TextEnviron(env=env, encoding=encoding)
        if value is None:
            # Can't compare to None as we encode None to bytes as b''
            assert to_text(b'', encoding) not in environ
        else:
            assert environ[value] == to_text(value, encoding)


# Generated at 2022-06-21 08:58:13.243540
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Test for method __len__ of class _TextEnviron
    """
    from ansible.module_utils.common._collections_compat import Mapping
    assert isinstance(environ, Mapping)
    assert len(environ) == len(dict(environ))
    assert len(environ) == len(environ._raw_environ)
    assert len(environ) >= 1


# Generated at 2022-06-21 08:58:23.536751
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron(encoding='utf-8')
    env.clear()
    env['key_a'] = 'a'
    env['key_b'] = 'b'
    env['key_c'] = 'c'
    env['key_d'] = 'd'
    env['key_e'] = 'e'
    ret = []
    for key in env:
        ret.append(key)
    assert ret[0] == ret[1] == 'key_a'
    assert ret[2] == ret[3] == 'key_b'
    assert ret[4] == ret[5] == 'key_c'
    assert ret[6] == ret[7] == 'key_d'
    assert ret[8] == ret[9] == 'key_e'

# Generated at 2022-06-21 08:58:27.342986
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Test to verify that we get the correct value from __len__()
    """
    environ['ANSIBLE_TEST'] = u'foo'
    assert len(environ) == len(os.environ) + 1

# Generated at 2022-06-21 08:58:30.300298
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ = _TextEnviron()
    os.environ['FOO'] = 'bar'
    del environ['FOO']
    assert 'FOO' not in os.environ


# Generated at 2022-06-21 08:58:33.249747
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    t = _TextEnviron()
    t['test'] = u'unicode'
    assert t['test'] == u'unicode'
    t['test'] = b'bytes'
    assert t['test'] == u'bytes'
    assert t._raw_environ['test'] == b'bytes'


# Generated at 2022-06-21 08:58:36.899161
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = {b'bytes': b'value', 'text': 'value'}
    tee = _TextEnviron(env)
    assert tee['bytes'] == 'value'
    assert tee['text'] == 'value'

# Generated at 2022-06-21 08:58:42.749051
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    test_input = {'a': '1', 'b': '2', 'c': '3'}
    # test_input.items() is a view object in python 3, let turn it into a list
    test_output = list(test_input.items())
    obj = _TextEnviron(env=test_input, encoding=None)
    assert set(obj.items()) == set(test_output)

# Unit tests for method __len__ of class _TextEnviron

# Generated at 2022-06-21 08:58:49.199353
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    my_env = _TextEnviron(env=dict(a=1, b=1, c=1))
    # The assertEqual method is doing an assertIn instead of an assertEqual because the classes are
    # different in Python2 and Python 3.  The environment is handled differently in the two
    # versions.  It is not possible to accurately test the value because the classes are different
    assert my_env[list(my_env)[0]] is not None

# Generated at 2022-06-21 08:58:59.182011
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # From Python 3.7
    from pprint import pprint
    from collections import OrderedDict
    import os

    # For the purposes of the test, use the environment variables of the current shell.
    object_to_test = _TextEnviron(env=os.environ)

    # This test is written generically to handle any version of Python.
    # pylint: disable=unidiomatic-typecheck
    if type(object_to_test) is not _TextEnviron:
        raise AssertionError('object_to_test is not of type _TextEnviron')
    # pylint: enable=unidiomatic-typecheck
    # Make a copy of the _raw_environ so __iter__() is not dependent on external data.

# Generated at 2022-06-21 08:59:10.142214
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test a happy path scenario
    environ['foo'] = u'ba\u4562\u4562r'
    assert environ._raw_environ['foo'] == b'ba\xe4\x95\x822\xe4\x95\x822r'

    # Test that we handle non-ascii characters well
    environ['foo'] = u'\u8239\u8328\u8328\u832a\u832a\u832b\u832b'

# Generated at 2022-06-21 08:59:18.181376
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'TEST_ENV_VAR1': '\x80'.encode('latin-1')})
    assert env['TEST_ENV_VAR1'] == '\udc80'
    #
    # Test that a key with a null in it gets returned
    #
    env = _TextEnviron({b'TEST_ENV_VAR1\x00': 'test'})
    assert env['TEST_ENV_VAR1\x00'] == 'test'


# Generated at 2022-06-21 08:59:20.429094
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron({'a': 1, 'b': 2, 'c': 3})
    assert len(environ) == 3



# Generated at 2022-06-21 08:59:26.221758
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Test __len__ for _TextEnviron.

    :return:
    """
    keys = ['ANSIBLE_TEST_VAR_ONE', 'ANSIBLE_TEST_VAR_ONE_2', 'ANSIBLE_TEST_VAR_TWO']
    assert len(keys) == len(_TextEnviron({key: 'foo' for key in keys}))



# Generated at 2022-06-21 08:59:27.903521
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Cannot use len(environ) since we monkeypatch environ
    assert len(_TextEnviron()) == len(os.environ)



# Generated at 2022-06-21 08:59:30.354237
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''Unit test for method __getitem__ of class _TextEnviron

    :CaseLevel: System
    '''
    # No test yet
    pass


# Generated at 2022-06-21 08:59:31.690946
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-21 08:59:37.272233
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    class TestEnv(object):
        index = 0

        def __iter__(self):
            return self

        def __next__(self):
            self.index += 1
            if self.index <= 3:
                return unicode(self.index)
            raise StopIteration

    environ = _TextEnviron(TestEnv())

    assert len(environ) == 3

# Generated at 2022-06-21 08:59:39.921169
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron()
    assert len(environ) == len(os.environ)

# Generated at 2022-06-21 08:59:53.856063
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Test the constructor of class _TextEnviron.
    """
    # Test that if the PY3 flag is set then the module actually imports `os.environ` and not a
    # proxy class
    import os
    assert os.environ is _TextEnviron(env={})

    from ansible.module_utils.six import PY2
    # Test that if PY2 is set that the module uses a proxy class.  Use a copy of os.environ so
    # that we don't mess with the real environment
    assert isinstance(os.environ, MutableMapping)
    assert isinstance(os.environ, _TextEnviron)

# Generated at 2022-06-21 09:00:00.182248
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import unittest
    import six

    class Test___setitem__(unittest.TestCase):
        def setUp(self):
            self.tmppaths = []

        def tearDown(self):
            for path in self.tmppaths:
                try:
                    os.unlink(path)
                except OSError:
                    pass

        def test_not_available(self):
            value = os.urandom(2)
            environ['FOOBAR'] = value

            with self.assertRaises(KeyError):
                res = os.environ['FOOBAR']

        def test_available(self):
            path = '/tmp/ansible-env-setitem.%d' % os.getpid()
            self.tmppaths.append(path)

            value = os.urandom(2)

# Generated at 2022-06-21 09:00:04.979153
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ = _TextEnviron({"var1": "val1", "var2": "val2"})
    environ.__delitem__("var1")
    assert len(environ) == 1
    with pytest.raises(KeyError):
        environ.__delitem__("var1")



# Generated at 2022-06-21 09:00:12.139380
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    unit test for method __getitem__ of class _TextEnviron
    """

    environ = _TextEnviron({b'key1': b'value1', b'key2': b'value2'})

    # testing whether this method returns unicode data when str data is encountered
    text = environ[b'key1']
    assert(isinstance(text, str))
    assert(text == 'value1')

    # testing whether this method returns unicode data when bytes data is encountered
    text = environ[b'key2']
    assert(isinstance(text, str))
    assert(text == 'value2')

# Generated at 2022-06-21 09:00:15.490857
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Ensure an item not in the environment is deleted safely
    env = _TextEnviron()
    del env['AAAAA']
    env['AAAAA'] = 'BBBBBB'
    del env['AAAAA']
    assert env['AAAAA'] not in env


# Generated at 2022-06-21 09:00:18.529835
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Create a new environ dictionary
    environ = _TextEnviron(env=dict())
    # Store a value for WHATEVER
    value = 'testing'
    environ['WHATEVER'] = value
    # The value should be available for retrieval
    assert value == environ['WHATEVER']


# Generated at 2022-06-21 09:00:27.741038
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import os
    import sys
    # Test on Python2 with a decoded value
    if not PY3:
        env = _TextEnviron()
        env['test_key'] = u'test_value'
        assert env['test_key'] == u'test_value'
    # Test on Python3 with a unicode value
    else:
        env = _TextEnviron()
        env['test_key'] = u'test_value'
        assert env['test_key'] == u'test_value'
    # Test on Python2 with encoded value
    if not PY3:
        env = _TextEnviron(encoding='ascii')
        env['test_key'] = u'test_value'
        assert env['test_key'] == u'test_value'
    # Test on Python3 with bytes value


# Generated at 2022-06-21 09:00:37.720027
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Create a new environ
    os_environ = environ._raw_environ
    environ._raw_environ = {}

    # Test string input
    environ['MY_TEST_1'] = 'Test string 1'
    assert isinstance(environ._raw_environ['MY_TEST_1'], bytes)
    assert environ._raw_environ['MY_TEST_1'] == b'Test string 1'
    assert environ['MY_TEST_1'] == 'Test string 1'

    # Test unicode input
    environ['MY_TEST_2'] = u'Test unicode 2'
    assert isinstance(environ._raw_environ['MY_TEST_2'], bytes)

# Generated at 2022-06-21 09:00:49.121182
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    this_module = sys.modules[__name__]
    setattr(this_module, '_ENV_IS_LOCAL', True)
    this_module._environ = _TextEnviron()
    # check if attribute _raw_environ has been removed
    assert hasattr(this_module._environ, '_raw_environ')
    delattr(this_module._environ, '_raw_environ')
    # check if attribute _value_cache has been removed
    assert hasattr(this_module._environ, '_value_cache')
    delattr(this_module._environ, '_value_cache')
    # check if attribute encoding has been removed
    assert hasattr(this_module._environ, 'encoding')
    delattr(this_module._environ, 'encoding')
    # check if

# Generated at 2022-06-21 09:00:51.846499
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():  # pylint: disable=missing-docstring
    if PY3:
        env = os.environ
    else:
        env = {b'foo': b'bar', u'baz': u'bop'}
    assert _TextEnviron(env=env, encoding='utf-8') == {u'foo': u'bar', u'baz': u'bop'}


# Generated at 2022-06-21 09:01:10.191942
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Unit test for method __setitem__ of class _TextEnviron

    :return:
    """
    new_environ = _TextEnviron(encoding='utf-8')
    new_environ['test'] = 'test'
    new_environ['test2'] = u'\u2122'
    new_environ['test3'] = b'test3'
    assert new_environ['test'] == 'test'
    assert new_environ['test2'] == u'\u2122'
    assert new_environ['test3'] == 'test3'

# Generated at 2022-06-21 09:01:18.047955
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    global environ
    # define dummy env
    env = dict()
    # instance of TextEnviron will not use original os.environ
    environ = _TextEnviron(env=env)

    test_values = {
        'string': u'teststring',
        'unicode': u'\u00f8', # LATIN SMALL LETTER O WITH STROKE
        'list': [u'test', u'string'],
        'dict': {'test': 'string'},
        'bstring': b'teststring',
        'bytearray': bytearray(b'teststring'),
    }

    # test nonstring='strict'
    for key, value in test_values.items():
        try:
            environ[key] = value
        except TypeError:
            pass

# Generated at 2022-06-21 09:01:23.228202
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Parametrized testcase for method __delitem__ of class _TextEnviron
    """
    environ_object = _TextEnviron()
    assert len(environ_object) > 0, "Testcase failed, class _TextEnviron does not exist."
    environ_object.__delitem__(environ_object.keys()[0])


# Generated at 2022-06-21 09:01:35.023673
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        return
    # utf-8
    os.environ['TEST_VARIABLE'] = b'ascii'
    assert environ['TEST_VARIABLE'] == 'ascii'
    os.environ['TEST_VARIABLE'] = b'\xc3\xa5'  # The LATIN SMALL LETTER A WITH RING ABOVE character
    assert environ['TEST_VARIABLE'] == 'å'
    os.environ['TEST_VARIABLE'] = b'\x69\xC3\xA6\xC3\xB8\x74'  # The LATIN SMALL LETTER I WITH DIAERESIS and LATIN SMALL LETTER O WITH STROKE

# Generated at 2022-06-21 09:01:42.136664
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    _environ = _TextEnviron()
    _environ['foo'] = u'bar'

    # we will set_environ the _environ to other environ
    import copy 
    __environ = copy.deepcopy(os.environ)
    for k, v in __environ.items():
        if not k in _environ.keys():
            os.environ[k] = v

    for k, v in _environ.items():
        os.environ[k] = v

    from ansible.module_utils.six import PY2
    if PY2:
        assert isinstance(_environ['foo'], unicode) == True
    else:
        assert isinstance(_environ['foo'], str) == True

    # we will set_environ os.environ to _environ back
