

# Generated at 2022-06-21 08:56:04.236365
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env_sample = {
        'a': '%',
        'b': u'\u0370',
        'c': b'\xfe'
    }
    env = _TextEnviron(encoding='ascii', env=env_sample)
    assert "key 'a' not found in environment" == env['a']
    assert u'\u0370' == env['b']
    assert "key 'c' not found in environment" == env['c']



# Generated at 2022-06-21 08:56:07.086657
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron(encoding='utf-8')
    text_environ['some_key'] = 'some_value'
    assert text_environ['some_key'] == 'some_value'


# Generated at 2022-06-21 08:56:19.159820
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    expected = '\u10d8\u10dc\u10d7\u10d8\u10e2\u10d4\u10e1 \u10d1\u10d0\u10d4\u10da\u10d0\u10e0\u10d8\u10ea'
    environ = _TextEnviron({'A_VAR': 'GEORGIAN_abc123'}, encoding='utf-8')
    environ[b'A_VAR'] = expected
    assert environ[b'A_VAR'] == expected
    assert environ[b'A_VAR'] == to_text(b'GEORGIAN_abc123', encoding=environ.encoding,
                                        errors='surrogate_or_strict')


# Generated at 2022-06-21 08:56:21.501522
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    def __len():
        a = _TextEnviron()
        len(a)
    __len()


# Generated at 2022-06-21 08:56:28.816140
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils.six.moves.builtins import range
    test_environ = _TextEnviron()
    for num in range(500):
        test_environ[str.format("test_vars.{}", num)] = str.format("{}", num)
    #pylint: disable=too-many-function-args
    assert sorted([i for i in test_environ]) == sorted([str.format("test_vars.{}", i) for i in range(500)])

# Generated at 2022-06-21 08:56:33.919386
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    '''Return the number of items in the environ.
    '''
    original_env = environ.copy()
    try:
        os.environ['HOME'] = '/home/foo/'
        assert len(environ) >= 1
    finally:
        environ.clear()
        environ.update(original_env)


# Generated at 2022-06-21 08:56:41.777380
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_environ = _TextEnviron()
    test_environ["new_variable"] = "This is a plain text string."
    assert isinstance(test_environ["new_variable"], str)
    assert test_environ["new_variable"] == "This is a plain text string."
    assert os.environ["new_variable"].decode('utf-8') == "This is a plain text string."
    assert test_environ._raw_environ["new_variable"].decode('utf-8') == "This is a plain text string."



# Generated at 2022-06-21 08:56:53.698264
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # set "à"
    environ["à"] = "à"
    assert b"\xc3\xa0" == environ._raw_environ[b"\xc3\xa0"]
    assert "à" == environ["à"]

    # set "a"
    environ["a"] = "a"
    assert b"a" == environ._raw_environ[b"a"]
    assert "a" == environ["a"]

    # set "a" again
    environ["a"] = "à"
    assert b"\xc3\xa0" == environ._raw_environ[b"a"]
    assert "à" == environ["a"]

    # set "b"
    environ["b"] = "b"

# Generated at 2022-06-21 08:57:00.613247
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Ensure that _TextEnviron.__getitem__ returns text (str on Python3 and unicode on Python2) and
    that the values are cached
    '''
    env = _TextEnviron()
    test_dict = {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}
    env._raw_environ = test_dict
    for key, expected_value in test_dict.items():
        value = env[key]
        assert isinstance(value, str)
        assert expected_value == value
        assert env._value_cache[value] == value



# Generated at 2022-06-21 08:57:10.013683
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    untested_msg = "They are not available on " + os.name
    if os.name != 'nt' and os.name != 'ce':
        try:
            os.unsetenv(to_bytes('TEST1', 'utf-8'))
        except: # noqa
            print(untested_msg)
            return
    else:
        print(untested_msg)
        return

    # Set some starting variables
    os.environ[to_bytes('TEST1', 'utf-8')] = to_bytes('Gobbledegook', 'utf-8')
    os.environ[to_bytes('TEST2', 'utf-8')] = to_bytes('Gibberish', 'utf-8')

    # Remove a variable from the test environ object

# Generated at 2022-06-21 08:57:12.988289
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    pass


# Generated at 2022-06-21 08:57:17.722216
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['TESTVAR'] = 'Test value'
    assert environ['TESTVAR'] == 'Test value'
    assert environ.encoding == 'utf-8'
    del os.environ['TESTVAR']



# Generated at 2022-06-21 08:57:19.750319
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(env={1: 1})
    assert env[1] == u'1'

# Generated at 2022-06-21 08:57:20.777446
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ["PYTHONIOENCODING"] == "UTF-8"

# Generated at 2022-06-21 08:57:25.209123
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    mocker.patch('os.environ', {'PYTHON_MODULE_UTILS_TEST': 'test value'})

    text_env = _TextEnviron()

    assert text_env['PYTHON_MODULE_UTILS_TEST'] == 'test value'


# Generated at 2022-06-21 08:57:30.057610
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import pytest
    utf8_ts_env = {b'ANSIBLE_TEST_ENCODING1': b'\xc3\x9f'}
    utf8_ts_text = u'ß'
    cp1252_ts_env = {b'ANSIBLE_TEST_ENCODING2': b'\xdf'}
    cp1252_ts_text = u'ß'
    ts_environ = _TextEnviron(env=utf8_ts_env, encoding='utf-8')
    assert ts_environ['ANSIBLE_TEST_ENCODING1'] == utf8_ts_text
    ts_environ = _TextEnviron(env=cp1252_ts_env, encoding='cp1252')
    assert ts_environ['ANSIBLE_TEST_ENCODING2']

# Generated at 2022-06-21 08:57:37.086151
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils._text import _EnvironStub
    # A new object should have the same length as os.environ
    obj = _TextEnviron(_EnvironStub())
    assert len(environ) == len(obj)
    # Add a key-value pair and ensure that the count goes up
    obj['ABC'] = '123'
    assert len(obj) == len(environ) + 1

# Generated at 2022-06-21 08:57:48.824839
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Save the current environment for later restore
    old_env = dict(os.environ)
    # Check deletion of an existing environment variable
    os.environ['TESTVARIABLE'] = 'Hello World'
    assert os.environ['TESTVARIABLE'] == 'Hello World'
    assert environ['TESTVARIABLE'] == 'Hello World'
    del environ['TESTVARIABLE']
    assert 'TESTVARIABLE' not in os.environ
    assert 'TESTVARIABLE' not in environ
    # Check deletion of a non-existing environment variable
    try:
        del environ['TESTVARIABLE']
    except KeyError:
        pass
    else:
        assert False, 'KeyError not raised when deleting a non-existing environment variable'
    # Restore

# Generated at 2022-06-21 08:57:52.136508
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    expected = 'UnitTest'
    environ['UnitTest'] = expected
    assert environ['UnitTest'] == expected

    del environ['UnitTest']
    assert 'UnitTest' not in environ


# Generated at 2022-06-21 08:57:53.324770
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, _TextEnviron)
    assert isinstance(environ, MutableMapping)

# Generated at 2022-06-21 08:58:01.088172
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    class FakeEnv(object):
        def __init__(self):
            self.count = 0
            return None

        def __len__(self):
            self.count += 1
            return self.count
    myenv = _TextEnviron(env=FakeEnv())
    assert len(myenv) == 2
    assert myenv._raw_environ.count == 2
    assert len(myenv) == 3
    assert myenv._raw_environ.count == 3
    return None



# Generated at 2022-06-21 08:58:03.954495
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['PATH'] = '3.7'
    del environ['PATH']
    assert 'PATH' not in environ


# Generated at 2022-06-21 08:58:15.447113
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    The test__TextEnviron___getitem__() function is used for unit testing.
    It will execute when user calls `python -m ansible.module_utils.environ`.
    """
    def _test_case(key, value, expect, comment):
        """
        The _test_case() function defines a test case.
        """
        if key not in environ:
            os.environ[key] = value
        #
        # case 0: key exists in environ
        #
        os.environ[key] = value

# Generated at 2022-06-21 08:58:24.541148
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # data
    data1 = 'str'
    data2 = u'unicode'
    data3 = 0
    data4 = False
    data5 = b'bytes'

    # test
    environ[__name__] = data1
    environ[__name__] = data2
    environ[__name__] = data3
    environ[__name__] = data4
    environ[__name__] = data5

    assert type(environ['ANSIBLE_TEST_ENVIRON']) is str
    assert type(environ['ANSIBLE_TEST_ENVIRON']) is bytes



# Generated at 2022-06-21 08:58:35.794232
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Verify it can be created with no args
    assert isinstance(environ, MutableMapping)

    # Verify it can be created with an alternate encoding
    mbcs_test_env = _TextEnviron(encoding='mbcs')
    assert isinstance(mbcs_test_env, MutableMapping)

    # Verify it can be created with a different environment
    from copy import copy
    test_environ = copy(os.environ)
    test_environ['FOO'] = u'bar'
    env2 = _TextEnviron(env=test_environ)
    assert isinstance(env2, MutableMapping)
    assert env2['FOO'] == u'bar'

    # Verify it can be created with a different environment and alternate encoding

# Generated at 2022-06-21 08:58:38.673149
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    e = _TextEnviron(encoding='utf-8')
    assert e.encoding == 'utf-8'


# Generated at 2022-06-21 08:58:46.399793
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = dict()
    env[b'ANSIBLE_MODULE_ARGS'] = '{"foo": "bar"}'
    env[b'ANSIBLE_SSH_DIR'] = '.'
    env[b'ANSIBLE_STDOUT_CALLBACK'] = 'blah'
    env[b'ANSIBLE_RETRY_FILES_ENABLED'] = 'False'
    os.environ = env

    text_env = _TextEnviron()
    assert text_env.get('ANSIBLE_MODULE_ARGS') == '{"foo": "bar"}'
    assert text_env.get('ANSIBLE_SSH_DIR') == '.'
    assert text_env.get('ANSIBLE_STDOUT_CALLBACK') == 'blah'

# Generated at 2022-06-21 08:58:51.885829
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    mock_environ = {}
    mock_environ['a'] = 1
    mock_environ['b'] = 2
    mock_environ['c'] = 3
    text_environ = _TextEnviron(mock_environ)
    assert text_environ.__iter__() == mock_environ.__iter__()


# Generated at 2022-06-21 08:58:59.204571
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import os
    import tempfile
    import sys
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text

    env = _TextEnviron(encoding='utf-8')

    assert sys.getfilesystemencoding() == "utf-8"

    assert isinstance(env, MutableMapping)
    assert isinstance(env, _TextEnviron)
    assert isinstance(env, dict)

    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8") as tf:
        print("key1=value1", file=tf)
        print("key2=value2", file=tf)

        tf.flush()
        os

# Generated at 2022-06-21 08:59:07.970705
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    assertenviron = os.environ
    assertenviron['TEST_UNICODE_VAR'] = '\u2640'
    assertenviron['TEST_BYTE_VAR'] = b'\xe2\x99\x80'
    assert environ['TEST_UNICODE_VAR'] == '\u2640'
    assert environ['TEST_BYTE_VAR'] == '\u2640'
    assert environ['TEST_UNICODE_VAR'] == '\u2640'


# Generated at 2022-06-21 08:59:20.871836
# Unit test for method __setitem__ of class _TextEnviron

# Generated at 2022-06-21 08:59:28.881140
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils._text import to_bytes

    assert isinstance(environ, MutableMapping)

    # Text environment
    text_env = _TextEnviron({to_bytes('SOMETHING'): to_bytes('SOMETHING-TEXT')})

    assert text_env['SOMETHING'] == 'SOMETHING-TEXT'

    # Byte environment
    byte_env = _TextEnviron({to_bytes('SOMETHING'): b'SOMETHING-BYTE'})

    assert byte_env['SOMETHING'] == 'SOMETHING-BYTE'


# Generated at 2022-06-21 08:59:37.050608
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env_dict = os.environ.copy()

    # PY3 -> env is equal to environ
    env = _TextEnviron()
    assert isinstance(env, MutableMapping)
    assert env.encoding == sys.getfilesystemencoding()
    assert env == env_dict
    assert env == environ

    # Not PY3 -> env is not equal to environ
    env = _TextEnviron(encoding='utf-8')
    assert isinstance(env, MutableMapping)
    assert env.encoding == 'utf-8'
    assert env != env_dict
    assert env == environ

# Generated at 2022-06-21 08:59:47.681917
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron({})
    # Dictionary is empty, so iter should be an empty iterator
    assert (list(environ) == [])
    environ = _TextEnviron({'a': 'b'})
    # Dictionary has one key, so iter should iterate over that key
    assert (list(environ) == ['a'])
    # Since iter() is a generator, we can't just test for equality
    # between the generator and a list, we have to iterate over the generator
    # and keep a list of the items it generates.
    environ = _TextEnviron({'a': 'b', 'c': 'd'})
    assert (list(environ) == ['a', 'c'])



# Generated at 2022-06-21 08:59:49.529768
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, dict)



# Generated at 2022-06-21 08:59:55.913740
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    e = _TextEnviron()
    e.__setitem__('TEST', 'TEST_VAL')
    assert e.__getitem__('TEST') == 'TEST_VAL'
    e.__setitem__('TEST', b'TEST_VAL')
    assert e.__getitem__('TEST') == 'TEST_VAL'
    e.__setitem__('TEST', u'TEST_VAL')
    assert e.__getitem__('TEST') == 'TEST_VAL'


# Generated at 2022-06-21 09:00:05.183818
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    txtenv = _TextEnviron({
        to_bytes('PYTHON_3'): to_bytes('2'),
        to_bytes('PYTHON_2'): to_bytes('3')
    })

    if PY3:
        assert sorted(txtenv) == sorted([to_bytes('PYTHON_2'), to_bytes('PYTHON_3')])
    else:
        assert sorted(txtenv) == [to_bytes('PYTHON_2'), to_bytes('PYTHON_3')]



# Generated at 2022-06-21 09:00:07.316008
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils.common._collections_compat import MutableMapping
    assert isinstance(environ, MutableMapping)

# Generated at 2022-06-21 09:00:10.823960
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    global environ
    # Unit test for method __iter__ of class _TextEnviron
    environ._raw_environ = {'PATH': '/bin:/usr/bin'}
    assert set(environ.__iter__()) == set(['PATH'])


# Generated at 2022-06-21 09:00:13.730854
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """Unit test for method __len__ of class _TextEnviron"""
    env = _TextEnviron(encoding='utf-8')
    assert len(env) == len(os.environ)



# Generated at 2022-06-21 09:00:25.774361
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    default_env = _TextEnviron()

    # Check that the default for text_env is os.environ
    assert default_env._raw_environ is os.environ
    # Check that text_env can be given a different dictionary
    my_env = {}
    text_env = _TextEnviron(env=my_env)
    assert text_env._raw_environ is my_env

    # Check that the default encoding is sys.getfilesystemencoding()
    assert default_env.encoding == sys.getfilesystemencoding()
    # Check that we can set the encoding
    text_env = _TextEnviron(encoding='utf-8')
    assert text_env.encoding == 'utf-8'



# Generated at 2022-06-21 09:00:32.036044
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    '''test method __delitem__ of class _TextEnviron'''
    # set test environment variable 
    os.environ["ANSIBLE_TEST_1"] = "p1"
    os.environ["ANSIBLE_TEST_2"] = "p2"
    os.environ["ANSIBLE_TEST_3"] = "p3"
    os.environ["ANSIBLE_TEST_4"] = "p4"
    # initialize object
    obj =  _TextEnviron(encoding='utf-8')
    # delete environment variable 'ANSIBLE_TEST_2'
    del obj['ANSIBLE_TEST_2']
    # check if variable 'ANSIBLE_TEST_2' was deleted
    assert os.environ["ANSIBLE_TEST_1"] == "p1"

# Generated at 2022-06-21 09:00:40.370577
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    class _EnvironSubstitutor(MutableMapping):
        def __init__(self, env_keys):
            self.env_keys = env_keys

        def __delitem__(self, key):
            del self.env_keys[key]

        def __getitem__(self, key):
            return self.env_keys[key]

        def __setitem__(self, key, value):
            self.env_keys[key] = value

        def __iter__(self):
            return self.env_keys.__iter__()

        def __len__(self):
            return len(self.env_keys)

    env_keys = {'a': 'b', 'c': 'd', 'e': 'f'}

# Generated at 2022-06-21 09:00:51.581919
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.common._collections_compat import ContextDecorator
    from ansible.module_utils.six import string_types

    with _DummyEnv(encoding='utf-8') as dummy:
        with _TestGetItem(dummy) as test:
            for key, value in test.items:
                if isinstance(value, bytes):
                    value = to_text(value, encoding=dummy.encoding, nonstring='passthru',
                                    errors='surrogate_or_strict')
                else:
                    assert isinstance(value, string_types)
                    value = to_text(value, encoding=dummy.encoding, nonstring='passthru',
                                    errors='surrogate_or_strict')
                assert dummy[key] == value
                assert not isinstance

# Generated at 2022-06-21 09:00:54.310364
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env1 = _TextEnviron({'key1': 'value1', 'key2': 'value2'}, encoding='utf-8')
    iter_env1 = iter(env1)
    for key in env1:
        assert next(iter_env1) == key


# Generated at 2022-06-21 09:00:57.160187
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env_dict = {
        b'K1': b'V1',
        'K2': b'V2',
        'K3': 'V3',
        b'K4': 'V4',
        'K5': u'V5',
    }

    # Test with a dict object, not os.environ
    _TextEnviron(encoding='utf-8')
    _TextEnviron(env=env_dict, encoding='utf-8')
    assert True

# Generated at 2022-06-21 09:01:01.584073
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test = _TextEnviron()
    test['test'] = 'foo'
    assert test['test'] == 'foo'
    del test['test']

    if PY3:
        import pytest
        pytest.xfail('not working yet on py3')
    assert 'test' not in test


# Generated at 2022-06-21 09:01:12.729500
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    os.environ[b'foo\xe4'] = b'bar\r\n'
    assert b'foo\xe4' in os.environ
    assert u'fooä' in environ
    with open(b'foo\xe4', 'w') as f:
        f.write(environ[u'fooä'])
    with open(b'foo\xe4') as f:
        assert f.read() == u'bar\r\n'
    os.remove(b'foo\xe4')

    environ[u'fooä'] = u'bar\r\n'
    assert b'foo\xe4' in os.environ
    assert u'fooä' in environ

# Generated at 2022-06-21 09:01:19.452532
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_env = _TextEnviron()
    test_env['foo'] = u'bar'
    assert test_env['foo'] == u'bar'
    assert test_env._raw_environ['foo'] == b'bar'
    assert test_env._value_cache[b'bar'] == u'bar'

    test_env['foo'] = b'baz'
    assert test_env['foo'] == u'baz'
    assert test_env._raw_environ['foo'] == b'baz'
    assert test_env._value_cache[b'baz'] == u'baz'

    test_env['foo'] = 'bar'
    assert test_env['foo'] == u'bar'
    assert test_env._raw_environ['foo'] == b'bar'
    assert test_env._

# Generated at 2022-06-21 09:01:30.965364
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    os.environ['b'] = u'\u20ac'
    os.environ['c'] = '\u20ac'
    test_environ = _TextEnviron(encoding='utf-8')
    assert test_environ.encoding == 'utf-8'
    assert test_environ['b'] == u'\u20ac'
    assert test_environ['c'] == u'\u20ac'
    # Set a unicode value into the environment
    test_environ[u'b'] = '\xc3\xa4'
    assert os.environ[b'b'] == b'\xc3\xa4'
    # Set a text value into the environment
    test_environ['c'] = '\xc3\xa4'

# Generated at 2022-06-21 09:01:38.805544
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ['foo'] = 'bar'
    assert len(environ) == 1

# Generated at 2022-06-21 09:01:49.669857
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Perform the test with the default os.environ, Python2's default text
    # strings, and UTF-8 strings
    environ1 = _TextEnviron(encoding='utf-8')

    # Check that the correct UTF-8 value is returned
    os.environ['ANSIBLE_TEST_VAR1'] = b'\xc3\xa9'
    result = environ1['ANSIBLE_TEST_VAR1']
    assert result == u'\xe9'

    # Check that passthru is working for non-strings
    os.environ['ANSIBLE_TEST_VAR2'] = b'10'
    result = environ1['ANSIBLE_TEST_VAR2']
    assert result == 10

    # Perform the test with the default os.environ, Python2's default text
    # strings,

# Generated at 2022-06-21 09:01:55.606053
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Environment variables are not expected to contain unicode
    # Private use areas are great
    value = u'\ud800\udc00'
    environ._raw_environ.clear()
    environ['test_key'] = value
    assert environ._raw_environ['test_key'] == to_bytes('\ud800\udc00', nonstring='strict',
                                                        errors='surrogate_or_strict')

# Generated at 2022-06-21 09:02:05.599892
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    string_env = {'string': 'value'}
    bytes_env = {b'bytes': b'value'}
    builtin_raw_env = {'__builtins__': 'module'}

    text_env1 = _TextEnviron(string_env)
    text_env2 = _TextEnviron(bytes_env)
    text_env3 = _TextEnviron(builtin_raw_env)

    assert text_env1.get(b'string') == 'value'
    assert text_env1.get(u'string') == 'value'
    assert text_env1.get('string') == 'value'

    assert text_env2.get(b'bytes') == 'value'
    assert text_env2.get(u'bytes') == 'value'
    assert text_env2.get

# Generated at 2022-06-21 09:02:07.350952
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Create a temporary environment to test with
    env = _TextEnviron(env={})
    pass

# Generated at 2022-06-21 09:02:09.966033
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ['ansible_test_var'] = 'foo'
    del environ['ansible_test_var']
    assert 'ansible_test_var' not in environ


# Generated at 2022-06-21 09:02:15.035356
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Function must work with an empty dictionary
    testing_dictionary = _TextEnviron()
    testing_dictionary['test'] = 'test'
    del testing_dictionary['test']
    assert 'test' not in testing_dictionary

    # Function must not raise error when passed an invalid key
    testing_dictionary = _TextEnviron(env={'test': 'test'})
    del testing_dictionary['not_a_key']

    # Function must raise a KeyError when passed a missing key
    try:
        del testing_dictionary['test']
        assert False
    except KeyError:
        pass



# Generated at 2022-06-21 09:02:19.010195
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    expected_keys = ['PATH', 'SHELL', 'LANG']

    environ_keys = [key for key in environ]
    assert environ_keys == expected_keys


# Generated at 2022-06-21 09:02:22.511102
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    try:
        key = 'someKey'
        environ[key] = 'someValue'
        assert key in environ.keys()
    except Exception:
        raise
    finally:
        del environ[key]
        assert key not in environ.keys()


# Generated at 2022-06-21 09:02:27.388749
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    raw_environ = {'A': 'a', 'B': 'b'}
    text_environ = _TextEnviron(raw_environ)
    assert len(text_environ) == len(raw_environ)

    iter_environ = iter(text_environ)
    assert next(iter_environ) == 'A'
    assert next(iter_environ) == 'B'


# Generated at 2022-06-21 09:02:46.894796
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ.update({'ANSIBLE_CACHE_PLUGIN': 'json', 'ANSIBLE_CACHE_PLUGIN_CONNECTION': 'ansible_cache'})
    environ.update({'ANSIBLE_CACHE_PLUGIN': 'json', 'ANSIBLE_CACHE_PLUGIN_CONNECTION': 'ansible_cache'})
    assert environ['ANSIBLE_CACHE_PLUGIN'] == 'json'
    assert 'ANSIBLE_CACHE_PLUGIN_CONNECTION' in environ
    del environ['ANSIBLE_CACHE_PLUGIN']
    assert 'ANSIBLE_CACHE_PLUGIN' not in environ


# Generated at 2022-06-21 09:02:51.048993
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils.common._collections_compat import UserDict
    assert len(_TextEnviron(env=UserDict())) == 0
    assert len(_TextEnviron(env=UserDict({b'foo': b'bar'}))) == 1
    assert len(_TextEnviron(env=UserDict({u'foo': u'bar'}))) == 1



# Generated at 2022-06-21 09:02:53.441765
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    test_environ = _TextEnviron({'a': '1', 'b': '2', 'c': '3'})
    assert len(test_environ) == 3

# Generated at 2022-06-21 09:03:02.588889
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import unittest

    import ansible.module_utils.six as six

    class Test_TextEnviron(unittest.TestCase):

        def setUp(self):
            self.env = {
                'PATH': '/usr/bin/',
                'HOME': '/home/profdwyer',
            }

            if six.PY3:
                self.encoding = None
            else:
                self.encoding = sys.getfilesystemencoding()

        def test__not_py3__len__(self):
            self.assertEqual(len(environ), len(self.env))


# Generated at 2022-06-21 09:03:05.663875
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    len_env_emulate_os = len(os.environ)
    len_env_actual = len(env)
    assert len_env_emulate_os == len_env_actual


# Generated at 2022-06-21 09:03:16.945655
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Case1: test if method __delitem__ works normally
    environ.clear()
    environ['key_1']='value_1'
    assert len(environ._value_cache) == 1
    assert len(environ._raw_environ) == 1

    del environ['key_1']

    assert len(environ._value_cache) == 0
    assert len(environ._raw_environ) == 0

    # Case2: test if method __delitem__ works normally when the key's type is text
    environ.clear()
    environ[u'key_1'] = 'value_1'
    assert len(environ._value_cache) == 1
    assert len(environ._raw_environ) == 1

    del environ[u'key_1']


# Generated at 2022-06-21 09:03:20.904425
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['ANSIBLE_TEST_VAR'] = 'normal_string'

    assert environ['ANSIBLE_TEST_VAR'] == 'normal_string'

    os.environ['ANSIBLE_TEST_VAR'] = b'bytes'
    assert environ['ANSIBLE_TEST_VAR'] == 'bytes'



# Generated at 2022-06-21 09:03:24.757933
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(encoding='utf-8')
    var = 'ANSIBLE_KEEP_REMOTE_FILES'
    val = 'true'
    os.environ[var] = val
    assert env[var] == val, '__getitem__ of class _TextEnviron returned {0}. Should have returned {1}'.format(env[var], val)
    del os.environ[var]

# Generated at 2022-06-21 09:03:32.888889
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    # Test with encoding='utf-8'
    environ = _TextEnviron(encoding='utf-8')
    # Create a new key with text value
    key = 'KEY_TO_BE_DELETED'
    value = 'KEY_TO_BE_DELETED_VALUE'
    environ._raw_environ[key] = to_bytes(value, encoding='utf-8', nonstring='strict',
                                         errors='surrogate_or_strict')
    # Check the key has been created with the expected value
    assert key in environ._raw_environ
    assert environ._raw_environ[key] == to_bytes(value, encoding='utf-8', nonstring='strict',
                                                  errors='surrogate_or_strict')
    # Delete the key

# Generated at 2022-06-21 09:03:42.654635
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron()
    environ['key1'] = 'value1'
    assert environ._raw_environ['key1'] == to_bytes('value1', encoding='utf-8', nonstring='strict',
                                                 errors='surrogate_or_strict')
    assert 'key1' in environ.keys()
    assert 'key1' in environ
    environ['key2'] = 'value2'
    assert environ._raw_environ['key2'] == to_bytes('value2', encoding='utf-8', nonstring='strict',
                                                 errors='surrogate_or_strict')
    assert 'key2' in environ.keys()
    assert 'key2' in environ


# Generated at 2022-06-21 09:04:08.894486
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Test length of _TextEnviron
    """
    test_env = _TextEnviron({'A': 'B'})
    assert len(test_env) == 1


# Generated at 2022-06-21 09:04:17.801148
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test with just getting the environ
    my_environ = _TextEnviron(encoding='base64')
    assert isinstance(my_environ, MutableMapping)
    assert b'TEST_VAR' in my_environ
    assert b'TEST_VAR' in my_environ._raw_environ
    assert 'TEST_VAR' not in my_environ
    assert 'TEST_VAR' not in my_environ._value_cache
    assert my_environ['TEST_VAR'] == 'test\nvalue\n'
    assert my_environ['TEST_VAR'] == b'test\nvalue\n'

    # Now add a bunch of test variables to the environ
    my_orig_env = my_environ._raw_environ.copy()
   

# Generated at 2022-06-21 09:04:22.840439
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = _TextEnviron({})
    # Test an empty environment
    assert len(test_environ) == 0
    assert test_environ['foo'] == 'bar'
    assert len(test_environ) == 1
    assert test_environ['foo'] == 'bar'
    assert len(test_environ) == 1

    # Test a pre-populated environment
    test_environ = _TextEnviron({b'\x80': b'\x80'})
    assert len(test_environ) == 1
    assert test_environ['\x80'] == '\x80'
    assert len(test_environ) == 1
    assert test_environ['\x80'] == '\x80'
    assert len(test_environ) == 1

    # Test a unicode string in

# Generated at 2022-06-21 09:04:31.544885
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    environ.__setitem__('FOO', os.path.join(tmpdir, 'foo'))
    environ['BAR'] = os.path.join(tmpdir, 'bar')
    environ['BAZ'] = os.path.join(tmpdir, 'baz')
    try:
        assert sorted(environ.keys()) == ['BAR', 'BAZ', 'FOO']
        assert sorted(environ) == ['BAR', 'BAZ', 'FOO']
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-21 09:04:38.385778
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Unit test for method __getitem__ of class _TextEnviron."""
    os.environ['foo'] = b'\xc3\xbc\x20\xe2\x98\x83'
    # Default encoding for _TextEnviron is sys.getfilesystemencoding()
    # which is 'utf-8'/'latin-1' on PY2/PY3
    _ = environ['foo']
    assert isinstance(environ['foo'], str)
    assert environ['foo'] == u'\xfc \u2603'


# Generated at 2022-06-21 09:04:49.558386
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():

    try:
        from unittest import mock
    except ImportError:
        from mock import mock

    with mock.patch('os.environ') as mock_environ:
        mock_environ.encode.return_value = 'ascii'
        fake_environ = {
            u'K1': u'V1',
            u'K2': u'V2',
            u'K3': u'V3',
        }
        fake_environ_bytes = {
            b'K1': b'V1',
            b'K2': b'V2',
            b'K3': b'V3',
        }
        mock_environ.items.return_value = fake_environ.items()
        environ = _TextEnviron(env=fake_environ)

# Generated at 2022-06-21 09:04:51.722692
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ['TEST_ENV'] = 'test value'
    assert len(environ) == (len(os.environ) + 1)


# Generated at 2022-06-21 09:04:58.352135
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import os
    os.environ['TEST_ITEM'] = "test item"
    environ['TEST_ITEM'] = "test item"
    assert os.environ['TEST_ITEM'] == environ['TEST_ITEM']
    del environ['TEST_ITEM']
    assert os.environ['TEST_ITEM'] == environ['TEST_ITEM']


# Generated at 2022-06-21 09:04:59.481471
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():

    assert list(environ) == list(os.environ)


# Generated at 2022-06-21 09:05:03.252337
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import doctest
    # Test with the default encoding
    environ = _TextEnviron()
    results = doctest.testmod(_TextEnviron)
    # Test with a specific encoding
    environ = _TextEnviron(encoding='latin-1')
    results = doctest.testmod(_TextEnviron)

    if results.failed:
        exit(1)



# Generated at 2022-06-21 09:05:53.398988
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({'msg1': 'hi', 'msg2': 'there'})
    assert ['msg1', 'msg2'] == sorted(list(env))


# Generated at 2022-06-21 09:05:57.909856
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    _environ = _TextEnviron({'A': b'a', 'B': b'b', 'C': b'c'})
    expected = ['A', 'B', 'C']
    assert list(_environ.__iter__()) == expected