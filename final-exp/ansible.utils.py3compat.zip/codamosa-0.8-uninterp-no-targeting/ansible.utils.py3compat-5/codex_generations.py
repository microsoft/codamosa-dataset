

# Generated at 2022-06-21 08:56:01.770759
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_dict = {"my_key": "my_value"}
    text_environ = _TextEnviron()
    text_environ.__setitem__("my_key", "my_value")
    assert test_dict == text_environ._raw_environ


# Generated at 2022-06-21 08:56:04.047201
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env1 = _TextEnviron()
    env2 = _TextEnviron()
    env1['a'] = 1
    env2['b'] = 2
    assert env1 == env2
    del env1['a']
    del env2['b']
    assert env1 == env2

# Generated at 2022-06-21 08:56:06.655203
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron(encoding='utf-8')
    len1 = len(os.environ)
    len2 = len(environ)
    assert len1 == len2


# Generated at 2022-06-21 08:56:08.536564
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 08:56:12.779444
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_env = _TextEnviron()
    try:
        test_env.__delitem__('TEST')
    except KeyError:
        assert 'TEST' not in test_env._raw_environ


# Generated at 2022-06-21 08:56:17.681620
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
	for x, y in zip(environ, environ._raw_environ):
		if PY3:
			assert(x == y)
		else:
			assert(x == to_text(y, encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict'))


# Generated at 2022-06-21 08:56:24.126500
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    _TextEnviron.__getitem__(self, key)

    Validate that a key can be used to retrieve a value
    """
    # Setup
    env = _TextEnviron()

    # Exercise
    value = env['PATH']

    # Verify
    # This should not raise a KeyError or any other exception
    assert isinstance(value, str), type(value)
    assert value



# Generated at 2022-06-21 08:56:29.710769
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # set up
    test_key = u'test_key'
    test_value = u'test_value'
    # test
    try:
        len(environ)
    except Exception:
        assert False, 'call to len(environ) raised exception.'
    try:
        len(environ._raw_environ)
    except Exception:
        assert False, 'call to len(environ._raw_environ) raised exception.'
    else:
        assert len(environ) == len(environ._raw_environ)
    if test_key not in os.environ:
        environ._raw_environ[test_key] = test_value

# Generated at 2022-06-21 08:56:32.910813
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron(env={'a': 1, 'b': 2, 'c': 3})
    assert tuple(environ) == ('a', 'b', 'c')



# Generated at 2022-06-21 08:56:43.187926
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():

    # Test with no kwargs passed.
    assert isinstance(environ, MutableMapping)
    # Smoke test that it looks like a dictionary
    assert isinstance(environ, dict)
    # Smoke test that it has the right to_text() values
    assert isinstance(environ['PATH'], str)

    # Test with a fake dictionary passed in.
    env = {'ANSIBLE_MODULE_UTILS_SIX_TEST_ENV': '\xe4\xbd\xa0\xe5\xa5\xbd'}
    test_environ = _TextEnviron(env)
    assert isinstance(test_environ, MutableMapping)
    # Smoke test that it looks like a dictionary
    assert isinstance(test_environ, dict)
    # Smoke test that it has the right to_text()

# Generated at 2022-06-21 08:56:55.179512
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set up the testing environment
    test_env = {b'A': b'val1',
                b'B': b'val2\xe7',
                b'C': b'val3\xff\xf7'}
    environ = _TextEnviron(env=test_env)

    # Test that non-bytes values are passed through
    assert environ[u'foo'] is environ._raw_environ[to_bytes(u'foo', 'utf-8')]

    # Test that we decode bytes values to text with the specified encoding
    assert environ[b'A'] == 'val1'
    assert environ[b'B'] == 'val2ç'
    assert environ[b'C'] == 'val3ÿ÷'

    # Test that we decode bytes values to text with the specified errors
    assert en

# Generated at 2022-06-21 08:57:05.495612
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    This test verifies the method __setitem__ of class _TextEnviron.
    """
    try:
        import builtins
    except ImportError:
        import __builtin__ as builtins

    def mock_to_bytes(value, encoding=None, nonstring='simplerepr', errors='strict'):
        """
        Mock method to_bytes to return value of type bytes
        """
        return bytes(value)

    # Save original value of function to_bytes
    orig_to_bytes = builtins.to_bytes

    # Replace to_bytes with mock_to_bytes
    builtins.to_bytes = mock_to_bytes

    v = _TextEnviron(encoding='utf-8')
    v['key1'] = 'value1'
    assert v['key1'] == 'value1'

    #

# Generated at 2022-06-21 08:57:11.312479
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Unit test for method __len__ of class _TextEnviron

    Confirm that len() on _TextEnviron returns the length of the raw environ
    """
    raw_environ = {'foo': 'bar', 'baz': 'qux'}
    environ = _TextEnviron(env=raw_environ)

    assert 2 == len(environ), "_TextEnviron's __len__() returns the length of the raw environ"



# Generated at 2022-06-21 08:57:23.039035
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test with no arguments
    textEnv_default = _TextEnviron()
    assert textEnv_default == os.environ

    # Test with dict object as the first argument
    textEnv2 = _TextEnviron(dict(THIS_IS_A_DICT={'is_dict': 'yes'}))
    assert len(textEnv2) == len(os.environ) + 1
    assert 'THIS_IS_A_DICT' in textEnv2
    assert textEnv2['THIS_IS_A_DICT'] == 'is_dict=yes'
    # Assumption from the below is that if we get the string representation
    # of the raw back it's the same as our original

# Generated at 2022-06-21 08:57:26.210996
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    orig = os.environ.copy()
    try:
        os.environ.clear()
        os.environ['ABC'] = 'abc'
        os.environ['DEF'] = 'def'
        for i in range(len(os.environ)):
            assert os.environ.popitem() in [('ABC', 'abc'), ('DEF', 'def')]
    finally:
        os.environ.update(orig)



# Generated at 2022-06-21 08:57:29.648002
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    myenviron = _TextEnviron(encoding='utf-8')
    assert len(myenviron) == len(myenviron._raw_environ)



# Generated at 2022-06-21 08:57:31.658091
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ_test = _TextEnviron(env={'a': 'b'})
    assert len(environ_test) == 1



# Generated at 2022-06-21 08:57:33.253721
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    o = _TextEnviron({'a': '123'})
    assert len(o) == 1



# Generated at 2022-06-21 08:57:37.301291
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environb['test_var'] = b'\xe2\x9c\x93'
    del os.environ['test_var']
    t = _TextEnviron(env=os.environb, encoding='utf-8')
    assert t['test_var'] == u'\u2713'
    del os.environb['test_var']


# Generated at 2022-06-21 08:57:49.314610
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():

    # Test encoding ascii
    ascii_encoding = "ascii"
    test_environ_ascii = _TextEnviron(encoding=ascii_encoding)
    test_environ_ascii['TEST_KEY'] = 'Derogatory term for a female'
    print("test_environ_ascii", test_environ_ascii)

    obtain_key = test_environ_ascii._raw_environ['TEST_KEY']
    expect_key = b'Derogatory term for a female'
    print("obtain_key", obtain_key)
    print("expect_key", expect_key)
    # assert obtain_key == expect_key

    # Test encoding utf-8
    utf_8_encoding = "utf-8"
   

# Generated at 2022-06-21 08:57:55.202401
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import pprint
    env = {'A': '1', 'B': '2'}
    result = set(str(c) for c in _TextEnviron(env))
    assert result == set(['A', 'B'])


# Generated at 2022-06-21 08:57:57.069493
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron({'PATH': '/bin:/usr/bin'})
    assert list(environ) == ['PATH']



# Generated at 2022-06-21 08:58:04.385980
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _os_environ = environ._raw_environ
    environ["test__TextEnviron___delitem__"] = "test__TextEnviron___delitem__"
    assert environ["test__TextEnviron___delitem__"] == "test__TextEnviron___delitem__"
    environ.__delitem__("test__TextEnviron___delitem__")
    assert "test__TextEnviron___delitem__" not in environ
    environ._raw_environ = _os_environ


# Generated at 2022-06-21 08:58:13.007485
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    uni_test_env = _TextEnviron(
        {b'NONASCII': b'\x93foo\x94', b'ASCII': b'bar'},
        encoding='utf-8')
    assert len(uni_test_env) == 2
    assert 'ASCII' in uni_test_env
    assert 'NONASCII' in uni_test_env
    assert uni_test_env['ASCII'] == 'bar'
    assert uni_test_env['NONASCII'] == '“foo”'



# Generated at 2022-06-21 08:58:21.795722
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    del os.environ['ANSIBLE_MODULE_UTILS_ENVIRON_TEST_VAR']
    new_obj = _TextEnviron()
    new_obj['ANSIBLE_MODULE_UTILS_ENVIRON_TEST_VAR'] = 'A'
    assert new_obj['ANSIBLE_MODULE_UTILS_ENVIRON_TEST_VAR'] == 'A'
    assert os.environ['ANSIBLE_MODULE_UTILS_ENVIRON_TEST_VAR'] == 'A'
    del new_obj['ANSIBLE_MODULE_UTILS_ENVIRON_TEST_VAR']
    with pytest.raises(KeyError):
        os.environ['ANSIBLE_MODULE_UTILS_ENVIRON_TEST_VAR']



# Generated at 2022-06-21 08:58:30.667907
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils.basic import AnsibleModule
    import os
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')

    try:
        test_env = os.environ.copy()
        test_env['ANSIBLE_CONFIG'] = test_file
        result = _TextEnviron(env=test_env)
        assert len(result) == len(test_env) + 1
    finally:
        shutil.rmtree(test_dir, ignore_errors=True)


# Generated at 2022-06-21 08:58:40.691135
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    class _Environ(object):
        def __init__(self):
            self._environ = {}

        def __setitem__(self, key, value):
            # For unit test purposes, we want to save both the key and the value so we can check
            # how _TextEnviron's __setitem__ handles it
            self._environ[key] = value

    env = _Environ()
    env_text = _TextEnviron(env=env)

    key = '1'
    value = '2'
    env_text[key] = value
    assert env_text[key] == value
    assert env_text.encoding == 'utf-8'

# Generated at 2022-06-21 08:58:44.727892
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({b'A': b'1', b'B': b'2', b'C': b'3'})
    assert 3 == len(env)
    assert 3 == len(env._raw_environ)


# Generated at 2022-06-21 08:58:47.581211
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron(encoding='utf-8')
    assert isinstance(environ, dict)
    assert isinstance(environ, _TextEnviron)

# Generated at 2022-06-21 08:58:52.087764
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ_test = _TextEnviron()
    e = u"\u4e2d\u6587"
    t = str(e)
    environ_test["key"] = e
    environ_test["key"] = t


# Generated at 2022-06-21 08:58:56.212132
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ._raw_environ) == len(environ)


# Generated at 2022-06-21 08:59:08.398344
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Tests using the Unicode REPLACEMENT CHARACTER which is a valid surrogate in the UTF-8 codec
    e = _TextEnviron()
    e['UTF8_SURROGATE'] = '\xef\xbf\xbd'
    assert e['UTF8_SURROGATE'] == u'\ufffd'

    # Tests using an invalid surrogate
    e = _TextEnviron()
    e['UTF8_SURROGATE'] = '\xF0\x9F\xBF\xBD'
    try:
        e['UTF8_SURROGATE']
    except UnicodeDecodeError:
        assert True
    else:
        assert False

    # Tests using the Unicode REPLACEMENT CHARACTER which is a valid surrogate in the cp1252 codec
    e = _TextEnviron()

# Generated at 2022-06-21 08:59:11.111434
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    test_env = _TextEnviron({'foo': 'bar', 'baz': 'qux'})
    for key in test_env:
        assert(test_env[key] == test_env._raw_environ[key])


# Generated at 2022-06-21 08:59:14.152440
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    for key in environ:
        assert isinstance(key, str)
        assert environ[key] == os.environ[key]


# Generated at 2022-06-21 08:59:25.055611
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    e = _TextEnviron()
    test_encoding = 'ascii'
    e.encoding = test_encoding

    # test for normal string input
    test_key = 'abcdefghijklmnopqrstuvwxyz'
    test_input = 'abcdefghijklmnopqrstuvwxyz'
    expected_output = 'abcdefghijklmnopqrstuvwxyz'
    e[test_key] = test_input
    assert e._raw_environ[test_key] == expected_output
    assert e[test_key] == expected_output

    # test for unicode string input

# Generated at 2022-06-21 08:59:32.759866
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Ensure that the environment variable encoding is set
    assert environ.encoding, "os.environ encoding not set"
    # PY2: When we set a variable as a string, it should be present in the raw os.environ as bytes
    if not PY3:
        environ['string_key'] = u'string_value'
        assert to_bytes(u'string_value', environ.encoding) == environ._raw_environ['string_key']
        assert u'string_value' == environ['string_key']

    # PY3: When we set a variable as a string, it should be present in the raw os.environ as a str
    # and returned as a str
    else:
        environ['string_key'] = 'string_value'

# Generated at 2022-06-21 08:59:44.320433
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import assertRaisesRegex
    from ansible.module_utils._text import to_bytes, to_native
    test_environ = _TextEnviron(encoding='utf-8')

    # Test we get the value in utf-8
    test_environ._raw_environ = {'test': to_bytes('ελληνικά', encoding='utf-8')}
    assert test_environ['test'] == 'ελληνικά'

    # Ensure we don't allow assigning non-string values
    class TestError(object):
        pass

    try:
        test_environ['test'] = TestError
    except TypeError:
        assert 'is not a valid string' in to_native(sys.exc_info()[1])


# Generated at 2022-06-21 08:59:49.289111
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    _test = _TextEnviron()
    _test['test'] = 'test'
    del _test['test']
    try:
        _test['test']
    except KeyError:
        pass
    else:
        raise AssertionError('_TextEnviron.__delitem__ does not work')


# Generated at 2022-06-21 08:59:51.016301
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    e = _TextEnviron(encoding='latin-1')
    import os
    assert e.encoding == 'latin-1'
    assert e._raw_environ == os.environ
    assert not e._value_cache


# Generated at 2022-06-21 08:59:58.681509
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set up the input data
    key = 'ANSIBLE_MODULE_ARGS'

# Generated at 2022-06-21 09:00:02.438907
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 09:00:05.886400
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    c = _TextEnviron()
    c['foo'] = 'bar'
    assert c['foo'] == 'bar'
    del c['foo']
    try:
        c['foo']
    except KeyError:
        pass
    else:
        assert False



# Generated at 2022-06-21 09:00:15.164234
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron(encoding='utf-8')

    # Test on Python2
    if not PY3:
        environ.clear()
        assert len(environ) == 0
        environ['TEST'] = '\x14\x03\x82\s\t\x82\x15\t\x82\x16'
        assert len(environ) == 1
        iterator = environ.__iter__()
        assert next(iterator) == u'TEST'
        with pytest.raises(StopIteration):
            next(iterator)

    # Test on Python3
    else:
        environ.clear()
        assert len(environ) == 0

# Generated at 2022-06-21 09:00:17.759616
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron()
    expected = set(env._raw_environ)
    actual = set(env.__iter__())
    assert actual == expected


# Generated at 2022-06-21 09:00:22.720110
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = {'ANSIBLE_PRIVATE_ITEM': b'ANSIBLE_PRIVATE_VALUE', b'ANSIBLE_PRIVATE_BYTE_ITEM': b'ANSIBLE_PRIVATE_BYTE_VALUE'}
    test_environ = _TextEnviron(env)
    assert test_environ['ANSIBLE_PRIVATE_ITEM'] == 'ANSIBLE_PRIVATE_VALUE'
    assert test_environ[b'ANSIBLE_PRIVATE_BYTE_ITEM'] == 'ANSIBLE_PRIVATE_BYTE_VALUE'

# Generated at 2022-06-21 09:00:29.351489
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Note that this function only tests the functionality of __getitem__.  It is not
    # designed to be a full test suite of _TextEnviron.
    environ['TEST_ENV_VAR'] = 'snowman: \xe2\x98\x83'
    try:
        assert environ['TEST_ENV_VAR'] == u'snowman: \u2603'
    except AssertionError:
        e = sys.exc_info()[1]
        raise AssertionError("Failed to convert environment variable to text: %s" % to_text(e))
    finally:
        del environ['TEST_ENV_VAR']

# Generated at 2022-06-21 09:00:34.497136
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_environ = _TextEnviron({'test': 'example'})
    assert len(test_environ) == len(os.environ) + 1
    del test_environ['test']
    assert len(test_environ) == len(os.environ)
    assert len(test_environ._raw_environ) == len(test_environ)


# Generated at 2022-06-21 09:00:35.812858
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({b'a':b'1', b'b':b'2'})
    assert sorted(env.__iter__()) == ['a', 'b']

# Generated at 2022-06-21 09:00:39.480272
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils._text import to_bytes
    env = _TextEnviron(env={'A': 'a', 'B': 'b'}, encoding='utf-8')
    assert len(env) == 2

    env['C'] = 'c'
    assert len(env) == 3

    del env['A']
    assert len(env) == 2


# Generated at 2022-06-21 09:00:43.417660
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():

    # Test that the length of the environment variable list is equal to the number of items
    # returned by calling list on environ
    assert(isinstance(environ, MutableMapping))
    assert(len(environ) == len(list(environ.items())))


# Generated at 2022-06-21 09:00:49.971734
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    e = _TextEnviron({'a': sys.getfilesystemencoding()})
    assert list(e.__iter__()) == ['a']


# Generated at 2022-06-21 09:00:55.162925
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({'a': 'b', 'c': 'd', 'e': 'f'})
    assert len(env) == 3
    del env['a']
    assert len(env) == 2
    assert env == {'c': 'd', 'e': 'f'}
    del env['c']
    assert len(env) == 1
    assert env == {'e': 'f'}
    del env['e']
    assert len(env) == 0
    assert env == {}



# Generated at 2022-06-21 09:01:06.160609
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    from ansible.module_utils._text import to_bytes, to_text

    # Create an in-memory environment so we don't affect the actual environment
    memory_env = _TextEnviron({'A': 'a', 'B': 'b', 'C': 'c'}, encoding='ascii')

    # Test that we can delete an item
    del memory_env['B']
    assert(memory_env == {'A': 'a', 'C': 'c'})

    # Test that we get an exception when trying to delete a variable that doesn't exist
    try:
        del memory_env['D']
    except KeyError:
        pass
    else:
        assert(0 and "Did not get a KeyError trying to delete a nonexistent key")


# Generated at 2022-06-21 09:01:08.185137
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    len_env = len(env)
    assert len_env == len(os.environ)


# Generated at 2022-06-21 09:01:10.755023
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    if PY3:
        assert _TextEnviron(encoding='utf-8') == os.environ
    else:
        assert _TextEnviron(encoding='utf-8') != os.environ

# Generated at 2022-06-21 09:01:18.376123
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # First set up the environment to use
    global environ
    _environ = {'test_bytes': b'7\xe8'.decode('utf-8'),
                'test_text': u'8\xe6',
                'test_mixed': b'9\xe7'.decode('utf-8')}
    environ = _TextEnviron(_environ, encoding='utf-8')

    # Verify that string that were in the dictionaries as bytes get decoded
    assert environ['test_bytes'] == u'7\u20ac'
    assert environ['test_text'] == u'8\xe6'

    # Verify that the cache works
    _environ['test_mixed'] = b'\xcc\xa8'.decode('utf-8')
    assert environ['test_mixed'] == u

# Generated at 2022-06-21 09:01:29.969989
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()

    # Test setter
    env['foo'] = u'bar'
    assert b'bar' == os.environ['foo']
    assert u'bar' == env['foo']

    # Test that the string is encoded
    env['foo'] = u'bär'
    assert b'b\xc3\xa4r' == os.environ['foo']
    assert u'bär' == env['foo']

    # Test that we throw an exception when the string cannot be encoded
    try:
        env['foo'] = u'bär\uFFFD'
    except UnicodeEncodeError:
        pass
    else:
        assert False

    # Test that we can set a byte string
    env['foo'] = b'bar'
    assert b'bar' == os.environ

# Generated at 2022-06-21 09:01:33.937747
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    assert issubclass(_TextEnviron, MutableMapping)
    obj = _TextEnviron()
    obj.__delitem__('HOME')


# Generated at 2022-06-21 09:01:41.488350
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Populate environ with a sample value, to emulate what may happen in a test
    environ['ANY_ENVIRONMENT_VARIABLE'] = to_text(b'\xed\x95\x9c\xea\xb5\xad\xec\x96\xb4',
                                                  encoding='utf-8')
    # Override the value with a unicode string which can't be encoded as utf-8
    environ[u'ANY_ENVIRONMENT_VARIABLE'] = u'\xa9'