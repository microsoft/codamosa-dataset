

# Generated at 2022-06-21 08:56:00.843602
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({'foo': 'bar'})
    del env['foo']
    assert 'foo' not in env



# Generated at 2022-06-21 08:56:03.033437
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron()

    del env['TEST_DEL']

    assert not 'TEST_DEL' in env



# Generated at 2022-06-21 08:56:04.740933
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    e = environ
    assert len(os.environ) == len(e)



# Generated at 2022-06-21 08:56:11.834282
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import ensure_native_str, ensure_text
    from unittest import TestCase

    # Test the raw case where we do not have unicode chars in the environment variable value
    # and the value does not have to be decoded from bytes to text.
    class TestTextEnvironGetitem(TestCase):
        def setUp(self):
            # Initialize the environment variable with native strings
            os.environ["MY_ENV_VAR"] = ensure_native_str("simple")

            self._text_environ = _TextEnviron()

        def test_basic(self):
            my_env_var_text = self._text_environ["MY_ENV_VAR"]
            self.assertIsInstance(my_env_var_text, ensure_text)

# Generated at 2022-06-21 08:56:19.694126
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """Unit test case for method _TextEnviron.__iter__

    """
    # Details of the test
    testcase = dict(
        method = '__iter__',
        instance = _TextEnviron({'foo': 'bar'}),
        )
    # Perform the unit test
    expected = ['foo']
    result = list(testcase['instance'])
    assert result == expected, "%s failed: expected: %s, received: %s" % (testcase['method'],
                                                                          expected, result)


# Generated at 2022-06-21 08:56:20.999125
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # put test here
    pass




# Generated at 2022-06-21 08:56:31.888898
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Create a fake os.environ in order to test easily
    my_environ = {}
    te = _TextEnviron(env=my_environ)

    # Test when value is not a str
    param = 1
    te['key'] = param
    assert str(param) == my_environ['key']

    # Test when encoding is None
    param = 'mytext'
    my_environ = {}
    te = _TextEnviron(env=my_environ)
    te['key'] = param
    assert param == my_environ['key']

    # Test when encoding is not None
    param = 'mytext'
    my_environ = {}
    te = _TextEnviron(env=my_environ, encoding='utf-8')
    te['key'] = param
    assert param == my_en

# Generated at 2022-06-21 08:56:33.315840
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ.items())


# Generated at 2022-06-21 08:56:41.108086
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron(env={'a': b'\xc2\xa9'})
    if PY3:
        assert environ['a'] == '©'
    else:
        assert environ['a'] == u'\xa9'
    environ['a'] = 'b'
    if PY3:
        assert environ['a'] == 'b'
    else:
        assert environ['a'] == u'b'
    del environ['a']
    assert 'a' not in environ

# Generated at 2022-06-21 08:56:46.574704
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    class MockDict(dict):
        def __setitem__(self, key, value):
            self.set_key = key
            self.set_value = value
            return super(MockDict, self).__setitem__(key, value)

    mock_environ = MockDict()
    mock_environ['PYTHONIOENCODING'] = 'ascii'
    encoded_env = _TextEnviron(env=mock_environ, encoding='utf-8')
    assert 'PYTHONIOENCODING' in encoded_env
    assert 'ascii' == encoded_env['PYTHONIOENCODING']
    assert mock_environ.set_key == 'PYTHONIOENCODING'
    assert mock_environ.set_value == b'ascii'



# Generated at 2022-06-21 08:56:50.296560
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    e = _TextEnviron()
    assert len(os.environ) == len(e)

# Generated at 2022-06-21 08:56:58.921675
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Tested inputs
    unicode_inputs = ['abc', u'abc']
    bytes_inputs = [b'abc', bytearray(b'abc'), memoryview(b'abc')]
    invalid_inputs = [object(), True, False, None]

    # Expected outputs (if input passes validation)
    unicode_outputs = [to_bytes(u'abc', encoding='utf-8', errors='surrogate_or_strict',
                                nonstring='strict')]
    bytes_outputs = [to_bytes(b'abc', encoding='utf-8', errors='surrogate_or_strict',
                              nonstring='strict')]

    # Test inputs
    # Testing valid inputs
    for i, item in enumerate(unicode_inputs + bytes_inputs):
        test

# Generated at 2022-06-21 08:57:04.331410
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron(encoding='utf-8')
    env.__setitem__('var_name', 'Hello World ø')
    if PY3:
        assert env.__getitem__('var_name') == 'Hello World ø'
    else:
        assert env.__getitem__('var_name') == u'Hello World ø'
    assert env.__getitem__('var_name') == 'Hello World ø'

# Generated at 2022-06-21 08:57:13.204210
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test constructor
    assert _TextEnviron().encoding == sys.getfilesystemencoding()

    assert not PY3
    env = _TextEnviron()
    utf8env = _TextEnviron(encoding='utf-8')
    latinenv = _TextEnviron(env=(os.environ.copy()))
    latinenv['PYMODULE_UT_ENCODING'] = b'latin1'
    latinenv['PYMODULE_UT_ENCODING_ASCII'] = b'ascii'
    latinenv['PYMODULE_UT_ENCODING_GERMAN'] = b'windows-1252'

# Generated at 2022-06-21 08:57:24.829652
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    te = _TextEnviron()

    te['unicode'] = u'🐧'
    assert isinstance(te['unicode'], str)
    assert isinstance(te._raw_environ['unicode'], bytes)

    te['bytes'] = b'\xF0\x9F\x90\xA7'
    assert isinstance(te['bytes'], str)
    assert isinstance(te._raw_environ['bytes'], bytes)

    # This demonstrates the change from Python2 behavior to Python3 behavior.
    # Python2 would return \xC7 when accessed via environ[key] but Python3 would
    # raise an UnicodeDecodeError.
    key = b'\xC7'
    te[key] = 'a'
    assert isinstance(te._raw_environ[key], bytes)


# Generated at 2022-06-21 08:57:34.966911
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    # Test non-string
    env[b'non-string'] = 3
    assert env._raw_environ[b'non-string'] == b'3'
    assert env[b'non-string'] == '3'

    # Test string from Python 2
    if not PY3:
        env[b'from-python'] = to_bytes(u'from-python-string', encoding='utf-8')
        assert env._raw_environ[b'from-python'] == b'from-python-string'
        assert env[b'from-python'] == u'from-python-string'
    else:
        env['from-python'] = u'from-python-string'
        assert env._raw_environ['from-python'] == b'from-python-string'
       

# Generated at 2022-06-21 08:57:41.235385
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    _test_dict = {'b': to_bytes('a', 'ascii'),
                  'c': to_bytes('a', 'utf-8')}
    _test_dict['b'].decode('ascii')
    _test_env = _TextEnviron(_test_dict, 'ascii')
    assert(_test_env['b'] == 'a')
    assert(_test_env['c'] == 'a')

# Generated at 2022-06-21 08:57:52.951356
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Unit test of class _TextEnviron, method __setitem__
    """

    # Set up test class
    environ = _TextEnviron()

    # Test with key of type str
    key_str = 'key_str'
    value_str = 'value_str'
    environ[key_str] = value_str
    assert(key_str in environ)
    assert(environ[key_str] == value_str)

    # Test with key of type bytes
    key_bytes = 'key_bytes'.encode('utf-8')
    value_bytes = 'value_bytes'.encode('utf-8')
    environ[key_bytes] = value_bytes
    assert(key_bytes in environ)

# Generated at 2022-06-21 08:58:00.997317
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from unittest import mock
    from datetime import datetime

    # In Python3, the environment will always be utf-8
    with mock.patch('ansible.module_utils.common._collections_compat.PY3', True):
        environ = _TextEnviron()
        assert environ.encoding == 'utf-8'

        environ = _TextEnviron(env={b'foo': b'bar'}, encoding='latin1')
        assert environ.encoding == 'latin1'
        assert environ._raw_environ == {b'foo': b'bar'}
        assert environ == {'foo': 'bar'}

        environ.encoding = 'ascii'
        assert environ._raw_environ == {'foo': 'bar'}

# Generated at 2022-06-21 08:58:05.305370
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Let's make sure we decode bytestrings to text on python2 and use text directly on python3
    environ = _TextEnviron(encoding='utf-8')
    assert environ['LANG'] == 'en_US.UTF-8'

# Generated at 2022-06-21 08:58:10.301874
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """Test __len__ method of class _TextEnviron."""
    # a new _TextEnviron should have as many elements as environ
    assert len(environ) == len(os.environ)



# Generated at 2022-06-21 08:58:14.412852
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    key = 'test_TextEnviron_key'
    value = 'test_TextEnviron_value'
    env = _TextEnviron(encoding='utf-8')
    env[key] = value
    assert env[key] == value
    return value


# Generated at 2022-06-21 08:58:19.128527
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # FIXME: We need to import this instead of the module directly.  Otherwise, we end up with a
    # circular import when running the unit tests for this module
    import ansible.module_utils.common._collections_compat
    env = ansible.module_utils.common._collections_compat._TextEnviron()
    assert len(env) == len(os.environ)

# Generated at 2022-06-21 08:58:23.536464
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron(env={'a': '1', 'b':'2', 'c':'3'})
    assert len(environ) == 3


# Generated at 2022-06-21 08:58:31.564951
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    if PY3:
        # Because we're trying to mimic Python3's os.environ, we should not be able to delete items
        try:
            del environ['PATH']
        except KeyError:
            pass
        else:
            assert False
    else:
        # os.environ should not be changed
        old_environ = dict(os.environ)
        try:
            del environ['PATH']
        except KeyError:
            pass
        else:
            assert False
        assert os.environ == old_environ



# Generated at 2022-06-21 08:58:33.752644
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron()

    for key in env:
        assert isinstance(key, str)



# Generated at 2022-06-21 08:58:39.565148
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # pylint: disable=protected-access
    env = _TextEnviron()
    assert env._raw_environ is os.environ
    assert env._value_cache == {}
    assert env.encoding == sys.getfilesystemencoding()


# Generated at 2022-06-21 08:58:43.745889
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Test _TextEnviron's __len__()
    """
    os.environ['__len__env_test_var'] = 'test_value'
    assert len(environ) == len(os.environ)
    del os.environ['__len__env_test_var']
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 08:58:50.600668
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    '''Test functionality of __len__ method of class _TextEnviron. '''
    my_env = _TextEnviron(encoding='utf-8')
    assert len(my_env) == 0, 'An _TextEnviron object should return 0 when it is empty.'
    my_env['a'] = 'b'
    assert len(my_env) == 1, 'An _TextEnviron object should have a length of 1 after adding a key-value pair.'


# Generated at 2022-06-21 08:58:55.067224
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'FOO': b'bar'}, encoding='utf-8')
    assert environ[b'FOO'] == u'bar'

# Generated at 2022-06-21 08:59:06.130068
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Remove a key from the environment
    key = "ANSIBLE_TEST_KEY"
    os.environ[key] = "ANSIBLE_TEST_VALUE"
    assert os.environ[key] == "ANSIBLE_TEST_VALUE"
    del environ[key]
    try:
        os.environ[key]
    except KeyError:
        assert True
    else:
        assert False, "Key was not deleted from the environment"



# Generated at 2022-06-21 08:59:12.719808
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # mock an environ dictionary
    environ2 = {b'key1': 'value1', b'key2': b'value2'}
    # test the constructor of _TextEnviron
    assert _TextEnviron(env=environ2) == environ2
    # Test that it will try to decode the value of env
    assert _TextEnviron(env=environ2, encoding='utf-8') == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-21 08:59:17.949468
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    e = _TextEnviron()
    try:
        del e['PATH']
    except KeyError:
        pass
    else:
        assert False, 'Expected KeyError to be raised'

    # TODO: This test will pass even if __delitem__ does not work correctly
    assert 'PATH' in os.environ


# Generated at 2022-06-21 08:59:19.341955
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 08:59:20.639729
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    #
    os.environ['a'] = '1'
    assert environ['a'] == '1'

    del environ['a']
    assert 'a' not in environ


# Generated at 2022-06-21 08:59:26.360326
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test #1
    origin = {'foo': 'bar'}
    environ = _TextEnviron(env=origin)

    assert origin['foo'] == b'bar'
    assert environ['foo'] == u'bar'

    environ['test'] = 'test_value'

    assert origin['test'] == b'test_value'
    assert environ['test'] == u'test_value'

# Generated at 2022-06-21 08:59:29.854245
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env_var_name = 'ANSIBLE_TEST_INPUT_ENCODING'
    env_var_value = 'éééééééé'
    environ[env_var_name] = env_var_value
    assert environ[env_var_name] == env_var_value

# Generated at 2022-06-21 08:59:40.970440
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import pytest
    from ansible.module_utils.six import b, u

    # We're using text strings in the tests but need to make sure that we don't confuse the mock
    # os.environ with bytes
    val_keys = ['foo', 'bar']
    val_bytes = [b'foo', b'bar']
    val_text = [u'foo', u'bar']
    unicode_env = {val_keys[0]: val_bytes[0], val_keys[1]: val_bytes[1]}

    # Test ASCII text
    env = _TextEnviron(env=unicode_env)
    assert isinstance(env.encoding, str)
    assert env.encoding == 'ascii'
    assert isinstance(env['foo'], str)
    assert isinstance(env['bar'], str)

# Generated at 2022-06-21 08:59:44.318246
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    test_dict = _TextEnviron()
    # __len__ should be the same as os.environ
    assert len(test_dict) == len(os.environ)



# Generated at 2022-06-21 08:59:51.922961
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    assert '__delitem__' not in environ, "environ should not contains '__delitem__'"
    environ['__delitem__'] = 'a'
    assert '__delitem__' in environ and '__delitem__' in os.environ, "environ should contains '__delitem__'"
    environ.__delitem__('__delitem__')
    assert '__delitem__' not in environ, "environ should not contains '__delitem__'"



# Generated at 2022-06-21 09:00:06.934367
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(iter(environ)) == list(iter(os.environ))

environ1 = _TextEnviron(encoding='utf-8')
environ2 = _TextEnviron({b'k1': b'v1', b'k2': b'v2'}, encoding='utf-8')
environ3 = _TextEnviron({b'k1': b'v1', b'k2': b'v2', 'k3': 'v3'.encode('utf-8')}, encoding='utf-8')
environ4 = _TextEnviron({'k1': 'v1', u'k2': u'v2'}, encoding='utf-8')
environ5 = _TextEnviron(encoding='utf-8')
environ5['k1'] = b'v1'

# Generated at 2022-06-21 09:00:08.212144
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ) == list(os.environ)


# Generated at 2022-06-21 09:00:18.581270
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    from ansible.module_utils.six import iteritems

    def get_set(mapping):
        return {k: mapping[k] for k in mapping}

    test_data = {'abcde': 'abcde', '12345': '12345'}
    test_data_encoded = {to_bytes(to_text(k, nonstring='passthru')): v
                         for k, v in iteritems(test_data)}

    # In python3, os.environ returns native strings.  For testing purposes, we're going to start
    # with a dict like what os.environ returns on python2 and build our _TextEnviron from that
    # instead of using the os.environ directly.
    environ.clear()
    environ.update(test_data_encoded)

    # Now that we've got our test