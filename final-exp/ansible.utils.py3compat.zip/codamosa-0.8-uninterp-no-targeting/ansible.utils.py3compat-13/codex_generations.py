

# Generated at 2022-06-21 08:56:08.264503
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Initialize the environment
    test_environ = {'a': 'A',
                    'b': 'B'}
    test_env = _TextEnviron(env=test_environ, encoding='ascii')

    # Make sure we return a text string
    assert test_env['a'] == 'A'
    assert test_env['b'] == 'B'

    # Make sure we can set the environment
    test_env['c'] = 'Ƥ'
    del test_env['a']
    assert 'c' in test_env
    with pytest.raises(KeyError):
        test_env['a']
    assert len(test_env) == 2

    # Make sure that we can set unicode values and get the encoded value back
    test_env.encoding = 'utf-8'
    test_env

# Generated at 2022-06-21 08:56:11.913478
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _TextEnviron.__delitem__(environ, 'ANSIBLE_STRICTHOST_KEY_CHECKING')
    assert 'ANSIBLE_STRICTHOST_KEY_CHECKING' not in environ



# Generated at 2022-06-21 08:56:16.295504
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    class _TestDict(dict):
        def __iter__(self):
            return self.__dict__.iteritems()

    env = _TextEnviron(_TestDict({'key': b'value'}))
    assert list(iter(env)) == ['key']

# Generated at 2022-06-21 08:56:19.558203
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['TEST'] = 'testvalue'
    assert len(environ) == len(os.environ) + 1
    del environ['TEST']
    assert len(environ) == 1



# Generated at 2022-06-21 08:56:25.787672
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ['FOO'] = 'bar'
    assert isinstance(environ['FOO'], str)
    assert 'FOO' in environ
    assert 'foo' not in environ
    assert 'FOO' in [key for key in environ]
    assert 'foo' not in [key for key in environ]
    assert ['FOO'] == [key for key in environ]



# Generated at 2022-06-21 08:56:30.725087
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ.clear()
    environ['test_var'] = 'test value'
    assert environ['test_var'] == 'test value'
    del environ['test_var']
    try:
        environ['test_var']
        raise AssertionError('delitem not working correctly')
    except KeyError:
        pass



# Generated at 2022-06-21 08:56:32.455440
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert isinstance(environ.__iter__(), type(iter(os.environ)))


# Generated at 2022-06-21 08:56:35.286660
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    new_environ = _TextEnviron(encoding='utf-8')
    assert len(environ) == len(new_environ)



# Generated at 2022-06-21 08:56:37.658164
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    for key in environ.__iter__():
        value = environ[key]
        assert key == value

# Generated at 2022-06-21 08:56:41.108041
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    raw_environ = {'not_unicode': 'ascii'}
    env = _TextEnviron(raw_environ, encoding='utf-8')
    assert len(env) == len(raw_environ)


# Generated at 2022-06-21 08:56:54.022173
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ._raw_environ = {}
    environ.__setitem__('test_variable_1', u'test_value_1')
    assert environ._raw_environ[b'test_variable_1'] == b'test_value_1'

    environ._raw_environ = {}
    environ.__setitem__(u'test_variable_2', b'test_value_2')
    assert environ._raw_environ[b'test_variable_2'] == b'test_value_2'

    environ._raw_environ = {}
    environ.__setitem__(b'test_variable_3', u'test_value_3')
    assert environ._raw_environ[b'test_variable_3'] == b'test_value_3'

    environ._raw_

# Generated at 2022-06-21 08:56:55.290521
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['name'] = 'foo'
    assert isinstance(environ['name'], str)
    assert environ['name'] == 'foo'

# Generated at 2022-06-21 08:56:59.539422
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['test_delitem'] = 'bar'
    assert ('test_delitem' in environ)
    del environ['test_delitem']
    assert ('test_delitem' not in environ)



# Generated at 2022-06-21 08:57:09.072210
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Make sure that __setitem__ successfully encodes the values
    environ['str'] = 'foo'
    assert isinstance(environ._raw_environ['str'], bytes)
    assert environ._raw_environ['str'] == b'foo'

    environ['bytes'] = b'foo'
    assert isinstance(environ._raw_environ['bytes'], bytes)
    assert environ._raw_environ['bytes'] == b'foo'

    environ['unicode'] = u'fóo'
    assert isinstance(environ._raw_environ['unicode'], bytes)
    assert environ._raw_environ['unicode'] == b'f\xc3\xb3o'

    # Make sure that __setitem__ handles errors correctly

# Generated at 2022-06-21 08:57:11.274327
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['foo'] = 'bar'
    assert 'foo' in environ
    del environ['foo']
    assert 'foo' not in environ


# Generated at 2022-06-21 08:57:17.313202
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    keys = ['k1', 'k2', 'k3']

    env = _TextEnviron()
    env._raw_environ = {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}

    group = env.__iter__()
    for key in group:
        assert key in keys


# Generated at 2022-06-21 08:57:22.201271
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert {'TEXTENV_TEST_ONE': '1', 'TEXTENV_TEST_TWO': '2'}.__iter__() == \
        {'TEXTENV_TEST_ONE': u'1', 'TEXTENV_TEST_TWO': u'2'}.__iter__()


# Generated at 2022-06-21 08:57:27.812591
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
  environ['testvar'] = 'testval'
  if environ['testvar'] != 'testval':
      raise ValueError('testvar: wrong value of environ["testvar"]')
  del environ['testvar']
  if 'testvar' in environ:
      raise ValueError('testvar: environ["testvar"] should be removed')


# Generated at 2022-06-21 08:57:36.792902
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from __builtin__ import next
    test_env = {'key1': 'value1', 'key2': 'value2'}
    result_env = _TextEnviron(test_env)
    assert isinstance(result_env, _TextEnviron)
    assert result_env._raw_environ == test_env
    assert len(result_env) == 2
    assert isinstance(result_env, MutableMapping)
    assert isinstance(result_env, dict)
    if PY3:
        assert result_env['key1'] == 'value1'
        assert result_env['key2'] == 'value2'
    else:
        assert result_env['key1'] == u'value1'
        assert result_env['key2'] == u'value2'
    assert 'key1' in result_env

# Generated at 2022-06-21 08:57:37.768979
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) >= 0


# Generated at 2022-06-21 08:57:51.307671
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron()
    assert len(env) == len(os.environ)
    # Save the original value of the environment variable
    if 'ANSIBLE_PYTHON_INTERPRETER' in env:
        py_interpreter = env['ANSIBLE_PYTHON_INTERPRETER']
    else:
        py_interpreter = None

    # Store a value into the environment variable

# Generated at 2022-06-21 08:57:56.113329
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
  from ansible.module_utils.common._collections_compat import MutableMapping

  # Create test object
  environ_test = _TextEnviron(encoding='utf-8')

  # Test method __iter__ of class _TextEnviron
  assert isinstance(environ_test.__iter__(), MutableMapping)


# Generated at 2022-06-21 08:58:07.056431
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Test with byte string keys
    byte_env = {b'foo': b'bar'}
    byte_environ = _TextEnviron(byte_env)
    assert list(byte_environ.__iter__()) == [b'foo']

    # Test with unicode keys
    unicode_env = {u'foo': u'bar'}
    unicode_environ = _TextEnviron(unicode_env)
    assert list(byte_environ.__iter__()) == [b'foo']

    # Test a mix of bytes, unicode, and str keys
    mixed_env = {b'foo': b'bar', u'baz': u'BAM', u'X': 'Y'}
    mixed_environ = _TextEnviron(mixed_env)

# Generated at 2022-06-21 08:58:17.644480
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Python 2

    # Check that the length of an empty _TextEnviron is zero
    os.environ.clear()
    environ = _TextEnviron()
    assert len(environ) == 0

    # Check that the length of a populated _TextEnviron is the same as the length of the same keys
    # in os.environ
    os.environ['empty'] = ''
    environ = _TextEnviron()
    assert len(environ) == len(os.environ)
    del os.environ['empty']
    environ = _TextEnviron()
    assert len(environ) == len(os.environ)
    os.environ['spam'] = 'eggs'
    environ = _TextEnviron()
    assert len(environ) == len(os.environ)

    # Python

# Generated at 2022-06-21 08:58:20.891242
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert type(environ['PATH']) == str
    assert environ['PYTHONIOENCODING'] == 'utf-8'

# Generated at 2022-06-21 08:58:32.442452
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'ANSIBLE_TEST_STR': b'\xce\xb1\xce\xb2\xce\xb3'})
    assert env['ANSIBLE_TEST_STR'] == u'\u03b1\u03b2\u03b3'
    assert env[b'ANSIBLE_TEST_STR'] == u'\u03b1\u03b2\u03b3'
    env = _TextEnviron({b'ANSIBLE_TEST_STR': u'\u03b1\u03b2\u03b3'})
    assert env['ANSIBLE_TEST_STR'] == u'\u03b1\u03b2\u03b3'

# Generated at 2022-06-21 08:58:43.054944
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # First, test using environ as the original environment
    new_env = _TextEnviron()
    assert repr(new_env) == repr(environ)
    assert new_env._value_cache == {}
    assert new_env.encoding == sys.getfilesystemencoding()
    # Then test using {} as the original environment
    new_env = _TextEnviron(env={})
    assert repr(new_env) != repr(environ)
    assert new_env._value_cache == {}
    assert new_env.encoding == sys.getfilesystemencoding()
    # Then test using a non-UTF8 encoding
    new_env = _TextEnviron(env={}, encoding='latin-1')
    assert repr(new_env) != repr(environ)
    assert new_env._value_cache == {}


# Generated at 2022-06-21 08:58:54.329800
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    t = _TextEnviron()
    import os
    # Test raw bytes from the environment
    # sys.getfilesystemencoding() returns utf-8 on my systems
    if sys.getfilesystemencoding() == 'utf-8':
        assert t['HOME'] == os.environ['HOME']
    else:
        # But if the system is not utf-8, we'll just check that it's doable
        t['HOME'] == os.environ['HOME'].decode(sys.getfilesystemencoding())

    # Test bytes which convert to unicode
    if os.name == 'nt':
        # sys.getfilesystemencoding() on windows returns 'mbcs'
        assert t[u'PATH'] == os.environ[u'PATH']

# Generated at 2022-06-21 08:58:57.051553
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron({'a': '1', 'b': '2'})

    assert len(environ) is 2

# Generated at 2022-06-21 08:59:01.444753
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron()
    env['foo'] = 'bar'
    assert env['foo'] == 'bar'
    del env['foo']
    assert env['foo'] == None


# Generated at 2022-06-21 08:59:10.533493
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    known_good_utf8 = u'\u201cHello, World!\u201d'
    known_good_utf8_bytes = b'\xe2\x80\x9cHello, World!\xe2\x80\x9d'

    known_bad_utf8 = u'\u201cHello, World!\xa2\xe2\x80\x9d'
    known_bad_utf8_bytes = b'\xe2\x80\x9cHello, World!\xa2\xe2\x80\x9d'

    # Start with an empty environment
    os.environ.clear()

    # Use the known good utf8 bytes
    os.environ[b'foo'] = known_good_utf8_bytes

# Generated at 2022-06-21 08:59:15.828691
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    _TextEnviron()["key"] = "value"

    t_env = _TextEnviron()
    t_env["key"] = b"value"
    t_env["key"] = "value"
    t_env["key"] = 1

    t_env = _TextEnviron(encoding=None)

# Generated at 2022-06-21 08:59:21.001524
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils.common._collections_compat import MutableMapping
    assert isinstance(environ, MutableMapping)
    assert hasattr(environ, '_raw_environ')
    assert environ._raw_environ == os.environ
    assert hasattr(environ, 'encoding')
    assert environ.encoding == 'utf-8'

# Generated at 2022-06-21 08:59:23.937076
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    u = _TextEnviron(env={})
    res = [x for x in u.__iter__()]
    assert res == [], 'Should be empty'
    u = _TextEnviron(env={'foo': 'bar'})
    res = [x for x in u.__iter__()]
    assert res == ['foo'], 'Should contain one key: foo'


# Generated at 2022-06-21 08:59:32.254275
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    _TextEnviron is a subclass of MutableMapping:
      http://docs.python.org/2/library/collections.html#collections.MutableMapping
    as such, it is a wrapper around a dict.  The dict that it wraps can be passed in from the
    caller, but if not specified then it will wrap os.environ.  The class __init__() is responsible
    for setting up the wrapped dict.
    """
    text_environ = _TextEnviron()
    assert isinstance(text_environ, _TextEnviron)
    assert text_environ._raw_environ is os.environ

    # For the test environment, ensure that we can work with the variables we expect
    for key in text_environ:
        assert text_environ[key] == os.environ[key]

   

# Generated at 2022-06-21 08:59:43.512345
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # set value
    environ['Test1'] = 'test value'
    assert isinstance(environ._raw_environ['Test1'], bytes)
    assert environ['Test1'] == 'test value'
    assert environ._raw_environ['Test1'] == 'test value'.encode('utf-8')
    # set value for unicode
    environ['Test2'] = 'тестовое значение'
    assert isinstance(environ._raw_environ['Test2'], bytes)
    assert environ['Test2'] == 'тестовое значение'

# Generated at 2022-06-21 08:59:44.781557
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert not len(environ)



# Generated at 2022-06-21 08:59:47.852902
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['abc'] = '123'
    assert 'abc' in environ
    del environ['abc']
    assert 'abc' not in environ


# Generated at 2022-06-21 08:59:51.769470
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    assert 'ANSIBLE_INVENTORY_V2' in environ

    del environ['ANSIBLE_INVENTORY_V2']

    assert 'ANSIBLE_INVENTORY_V2' not in environ



# Generated at 2022-06-21 08:59:52.737821
# Unit test for method __iter__ of class _TextEnviron

# Generated at 2022-06-21 09:00:00.415867
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import os

    # os.environ is used as the initial value here to provide a real environment variable
    # to test against.
    env = _TextEnviron(os.environ)
    assert isinstance(env, _TextEnviron)
    for value in env:
        assert isinstance(value, str) or (PY3 and isinstance(value, bytes))


# Generated at 2022-06-21 09:00:01.079509
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Call function under test, check result
    assert len(environ) >= 1

# Generated at 2022-06-21 09:00:02.370123
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """Unit test for method __delitem__ of class _TextEnviron"""
    os.environ['a'] = 'foo'
    foo = environ.pop('a')
    assert foo == 'foo'



# Generated at 2022-06-21 09:00:05.056216
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    s = u'spam'
    environ[s] = s
    result = len(environ)
    assert result > 0
    assert type(result) == int
    assert result == 1


# Generated at 2022-06-21 09:00:14.474196
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import unittest

    raw_environ = {'foo': 'bar', 'spam': 'eggs'}

    class _TextEnvironTest(unittest.TestCase):
        def setUp(self):
            self._raw_environ = raw_environ

        def test_iter(self):
            iter_list = list(_TextEnviron(self._raw_environ).__iter__())
            self.assertEqual(iter_list, list(self._raw_environ.keys()))
            self.assertEqual(type(iter_list[0]), str)

    suite = unittest.TestSuite()
    suite.addTest(_TextEnvironTest('test_iter'))

    runner = unittest.TextTestRunner()
    runner.run(suite)


# Generated at 2022-06-21 09:00:17.977611
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['ANSIBLE_TEST'] = u'a-test'
    assert 'ANSIBLE_TEST' in environ
    del environ['ANSIBLE_TEST']
    assert 'ANSIBLE_TEST' not in environ



# Generated at 2022-06-21 09:00:21.317143
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():   # pylint: disable=invalid-name
    """Test __getitem__ against the os environ object"""
    # Test against the 'normal' environment
    e = _TextEnviron(encoding='utf-8')
    for (key, value) in e.items():
        assert type(e[key]) == text_type

# Generated at 2022-06-21 09:00:25.138497
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():

    env = _TextEnviron()
    assert len(env) == len(env._raw_environ)

    env = _TextEnviron({'KEY1': 'VALUE'})
    assert len(env) == len(env._raw_environ)


# Generated at 2022-06-21 09:00:31.661860
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Set up test environment
    os.environ.clear()
    os.environ['LANG'] = 'en_US.UTF-8'
    os.environ['ASCII_VAR'] = 'ASCII'
    os.environ['UTF8_VAR'] = b'\xc3\xa9'.decode('utf-8')

    # Test with None as encoding
    environ1 = _TextEnviron(os.environ, 'utf-8')
    environ1['LANG'] = 'en_US.UTF-8'
    assert environ1['LANG'] == u'en_US.UTF-8'

    environ1['ASCII_VAR'] = 'ASCII'
    assert environ1['ASCII_VAR'] == u'ASCII'

    # Test with ASCII as encoding
    en

# Generated at 2022-06-21 09:00:36.163629
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils._text import to_bytes, to_text

    mock_environ = {}
    environ['a'] = 'b'

    assert mock_environ['a'] == to_bytes('b', encoding='utf-8')
    assert environ['a'] == 'b'



# Generated at 2022-06-21 09:00:41.062810
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({'a': 'a_val'})
    assert isinstance(iter(env), type(iter(env._raw_environ)))
    assert list(env) == list(env._raw_environ)


# Generated at 2022-06-21 09:00:51.937594
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_env = _TextEnviron()
    # Test the case when passing in a non-string value
    test_env["key"] = 1
    assert b"1" == test_env._raw_environ["key"]

    # Test the case when passing in a unicode value with non-ascii character
    test_env["key"] = u'Iñtërnâtiônàlizætiøn'
    assert b"I\xc3\xb1t\xc3\xbbrn\xc3\xa2ti\xc3\xb4n\xc3\xa0liz\xc3\xa6ti\xc3\xb8n" == test_env._raw_environ["key"]

    # Test the case when passing in a byte string with non-ascii character
    test_env["key"] = b

# Generated at 2022-06-21 09:00:53.047721
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-21 09:00:55.207999
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ["a"] = "b"
    assert len(environ) == 2
    del os.environ["a"]


if __name__ == '__main__':
    test__TextEnviron___len__()

# Generated at 2022-06-21 09:01:00.224988
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Test if the deletion of the item with
    key 'TESTKEY' works.
    """
    test = _TextEnviron()
    test['TESTKEY'] = 'TESTVALUE'
    assert test['TESTKEY'] == 'TESTVALUE'
    del test['TESTKEY']
    assert 'TESTKEY' not in test


# Generated at 2022-06-21 09:01:04.577535
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = {'one': '1', 'two': '2', 'three': '3'}
    e = _TextEnviron(env, encoding='utf-8')
    assert len(e) == len(env)


# Generated at 2022-06-21 09:01:14.261096
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron()
    assert isinstance(env, MutableMapping)
    # NOTE: On Python2, os.environ is not a MutableMapping but on Python3 it is.
    # In order to support python2's environ, we transform the environ into a
    # MutableMapping.  The easiest way to do this is to put it into a
    # _TextEnviron.  Since we're writing tests, we need to add an additional
    # layer of _TextEnviron so that we can use the MutableMapping methods on
    # python2.
    env2 = _TextEnviron(env=env)
    assert isinstance(env2, MutableMapping)
    env2['key1'] = 'value1'
    assert 'key1' in env2

# Generated at 2022-06-21 09:01:15.721049
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(environ._raw_environ)


# Generated at 2022-06-21 09:01:23.783827
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    ident = 'TEST_MOD_UTILS_ENVIRON_environment'
    environ[ident] = b"\xe2\x82\xac"
    assert environ[ident] == u"\u20ac"  # Euro symbol
    # Test the cache
    del environ[ident]
    environ[ident] = b"\xe2\x82\xac"
    assert environ[ident] == u"\u20ac"  # Euro symbol
    del environ[ident]
    environ[ident] = u"\u20ac"
    assert environ[ident] == u"\u20ac"  # Euro symbol


# Generated at 2022-06-21 09:01:26.380901
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    _environ = _TextEnviron()
    assert isinstance(_environ[u'LANG'], str)



# Generated at 2022-06-21 09:01:29.852337
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 09:01:32.643486
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron()
    # Not testing much here.  Just that __iter__ itself works
    assert len(list(env)) == len(env)



# Generated at 2022-06-21 09:01:40.941952
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import os

    class MockEnvironment(MutableMapping):
        def __init__(self, env=None):
            self._raw_environ = env

        def __delitem__(self, key):
            del self._raw_environ[key]

        def __getitem__(self, key):
            return self._raw_environ[key]

        def __setitem__(self, key, value):
            self._raw_environ[key] = value

        def __iter__(self):
            return self._raw_environ.__iter__()

        def __len__(self):
            return len(self._raw_environ)

    class AnsibleException(Exception):
        pass

    class MockTextConversionError(AnsibleException):
        pass

    # pylint: disable=unused-variable,

# Generated at 2022-06-21 09:01:51.775989
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Test method __delitem__ of class _TextEnviron
    """
    import tempfile
    tmpdir = tempfile.mkdtemp()

    # delete a non-existing key
    environ = _TextEnviron({'__test_key1':'test_value1', '__test_key2':'test_value2'})
    del environ['__test_key3']
    if sys.version_info[0] == 2:
        assert environ._raw_environ == {'__test_key1':'test_value1', '__test_key2':'test_value2'}
    else:
        assert environ._raw_environ == {'__test_key1':'test_value1', '__test_key2':'test_value2'}

# Generated at 2022-06-21 09:01:57.332829
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Unit test for constructor of class _TextEnviron
    """
    my_environ = _TextEnviron({'a': 'b', 'c': 'd'})
    assert 'a' in my_environ
    assert 'b' == my_environ['a']
    assert 'c' in my_environ
    assert 'd' == my_environ['c']



# Generated at 2022-06-21 09:01:59.352600
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ["LEN"] = "foo"
    assert len(environ)
    assert len(environ) == 1

# Generated at 2022-06-21 09:02:02.254372
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ = _TextEnviron({'a': 'b'})
    assert len(environ) == 1
    del environ['a']
    assert len(environ) == 0


# Generated at 2022-06-21 09:02:05.280409
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    test_env = {'ANSIBLE_MODULE_ARGS': '{"a": "b", "c": "d"}'}
    assert _TextEnviron(test_env, 'utf-8') is not None

# Generated at 2022-06-21 09:02:08.276828
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Create an instance of a class _TextEnviron
    text_env = _TextEnviron()

    assert isinstance(text_env.__iter__(), type(environ.__iter__()))



# Generated at 2022-06-21 09:02:12.173837
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Mimic what we do in the code.  We expect the output to be identical to Python3's os.environ"""
    environment = dict(os.environ)
    environ = _TextEnviron(env=environment, encoding='utf-8')
    for key in environ:
        assert environ[key] == os.environ[key]


# Generated at 2022-06-21 09:02:20.918023
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron(env={b'k1': b'v1', b'k2': b'v2', b'k3': b'v3'})
    it = env.__iter__()
    assert next(it) == u'k1'
    assert next(it) == u'k2'
    assert next(it) == u'k3'
    try:
        next(it)
    except StopIteration:
        pass
    else:
        assert False


# Generated at 2022-06-21 09:02:24.135604
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    assert environ['LANG'] == 'en_US.UTF-8'
    environ['LANG'] = 'zh_CN.UTF-8'
    assert environ['LANG'] == 'zh_CN.UTF-8'


if __name__ == '__main__':
    test__TextEnviron___getitem__()

# Generated at 2022-06-21 09:02:31.784368
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # This tests the basic functionality of _TextEnviron.
    # We don't care about testing Python2 vs Python3 here as we're trying to mimic Python3's
    # os.environ on Py2 and Py3.
    if not PY3:
        # By default, an empty environ will use the default sys.getfilesystemencoding()
        assert isinstance(environ, _TextEnviron)

    # Test constructor with a non-unicode encoding
    env = _TextEnviron(encoding='latin-1')
    assert isinstance(env, _TextEnviron)

    # Test constructor with an encoding class
    env = _TextEnviron(encoding=sys.getfilesystemencoding)
    assert isinstance(env, _TextEnviron)

    # Test constructor with a passed in environment

# Generated at 2022-06-21 09:02:36.113395
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class TestEnv(object):
        def __init__(self):
            self.dict = {'test': 'foo'}
        def __getitem__(self, key):
            return self.dict[key]
    env = TestEnv()
    assert _TextEnviron(env).__getitem__('test') == 'foo'



# Generated at 2022-06-21 09:02:45.657658
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Simulate the environment
    environ = _TextEnviron()

    # Check that an encoding error is raised
    test_bytes = b'\xFF\xFE'
    environ[b"TEST_KEY"] = test_bytes
    assert environ[b"TEST_KEY"] == test_bytes

    # Check that a value error is raised
    test_bytes = b'\xFE'
    try:
        environ[b"TEST_KEY"] = test_bytes
    except ValueError as e:
        assert to_bytes(str(e), encoding='utf-8') == b'\x00\x02\x00\x00'
    else:
        assert False, "Expected ValueError to be raised"

    # Check that a value error is NOT raised

# Generated at 2022-06-21 09:02:54.047637
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    class TestEnviron(MutableMapping):
        def __init__(self, env=None):
            self._raw_environ = env
        def __delitem__(self, key):
            del self._raw_environ[key]
        def __getitem__(self, key):
            return self._raw_environ[key]
        def __setitem__(self, key, value):
            self._raw_environ[key] = value
        def __iter__(self):
            raise RuntimeError('This is a unit test.')
        def __len__(self):
            return len(self._raw_environ)

    env2 = _TextEnviron(env=TestEnviron({1:2}))
    assert 1 in env2

# Generated at 2022-06-21 09:02:58.905734
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils._text import to_bytes
    env = {}
    test_environ = _TextEnviron(env=env)
    test_environ['testkey'] = 'testvalue'
    # The value must be encoded in the destination encoding
    assert to_bytes('testvalue') == env['testkey']
    return True


# Generated at 2022-06-21 09:03:03.685390
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert(environ['TEST_TEXT_ENV'] == 'RTEST_TEXT_ENV')
    environ['TEST_TEXT_ENV'] = 'TEST_TEXT_ENV'
    assert(environ['TEST_TEXT_ENV'] == 'TEST_TEXT_ENV')
    assert(environ['TEST_TEXT_ENV2'] == 'RTEST_TEXT_ENV2')

# Generated at 2022-06-21 09:03:07.977834
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    os.environ['utf8_var'] = 'møøse'
    text_environ = _TextEnviron(encoding='utf-8')
    assert text_environ['utf8_var'] == u'm\xf8\xf8se'

    text_environ = _TextEnviron()
    assert text_environ['utf8_var'] == u'møøse'

# Generated at 2022-06-21 09:03:19.068246
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils.basic import AnsibleModule

    def test_run(os_environ):
        global environ
        module = AnsibleModule({})

        environ = _TextEnviron(env=os_environ)
        module.exit_json(msg="PASS", changed=False)

    def test_fail(os_environ):
        global environ
        module = AnsibleModule({})

        environ = _TextEnviron(env=os_environ)
        module.fail_json(msg="FAIL")

    fixture = ['PATH=/bin:/usr/bin', 'HOME=/home/test']

    assert len(dict(fixture)) == 2

    # Test edge case
    assert len(_TextEnviron()) == len(dict(os.environ))

    # Test successful execution

# Generated at 2022-06-21 09:03:23.974229
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == to_text(os.environ['PATH'], nonstring='passthru', errors='surrogate_or_strict', encoding='utf-8')
    assert environ['PATH'] == environ['PATH']

# Generated at 2022-06-21 09:03:26.012901
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    os.environ['ANSIBLE_TESTING'] = '123'
    assert environ['ANSIBLE_TESTING'] == u'123'



# Generated at 2022-06-21 09:03:27.669324
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron()
    assert isinstance(env.__iter__(), type(os.environ.__iter__()))



# Generated at 2022-06-21 09:03:35.719839
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import builtins

    if PY3:
        builtins.__dict__['__env__'] = os.environ
        environ['ASCIIVALUE'] = 'npqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpq'
        assert len(environ['ASCIIVALUE']) == 56
        del environ['ASCIIVALUE']
    else:
        builtins.__dict__['__env__'] = os.environ
        environ['ASCIIVALUE'] = 'npqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpqnpq'

# Generated at 2022-06-21 09:03:41.586310
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert 'abc' == environ['TEST_CASE_1']
    if PY3:
        assert '日本語' == environ['TEST_CASE_3']
    else:
        assert u'日本語' == environ['TEST_CASE_3']
    assert 'zyx' == environ['TEST_CASE_7']

if __name__ == '__main__':
    import os
    os.environ['TEST_CASE_1'] = 'abc'
    os.environ['TEST_CASE_2'] = b'bcd'
    os.environ['TEST_CASE_3'] = b'\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e'


# Generated at 2022-06-21 09:03:42.779081
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 09:03:50.145286
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    old_env = os.environ.copy()
    try:
        # Test that __delitem__ deletes an item
        # Make sure we have a variable that we can delete
        os.environ['TESTVAR'] = 'foo'
        assert 'TESTVAR' in os.environ

        del environ['TESTVAR']
        assert 'TESTVAR' not in os.environ
    finally:
        os.environ.clear()
        os.environ.update(old_env)



# Generated at 2022-06-21 09:03:53.465156
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """Test the __len__ method of the _TextEnviron class.

    The __len__ method should return the length of the environment from the underlying OS module.
    We expect that the OS module will always have a value for 'PATH' in the environment.
    """
    assert len(environ) > 0
    assert 'PATH' in environ



# Generated at 2022-06-21 09:04:03.970514
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    oldenviron = os.environ
    testenviron = {'ANSIBLE_TEST_KEY_1': 'ANSIBLE_TEST_VALUE_1',
                   'ANSIBLE_TEST_KEY_2': 'ANSIBLE_TEST_VALUE_2',
                   'ANSIBLE_TEST_KEY_3': 'ANSIBLE_TEST_VALUE_3',
                  }

# Generated at 2022-06-21 09:04:07.375545
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils import basic
    print(type(environ))
    for key in environ:
        print(type(key))
        print(key)
    print(type(environ))


# Generated at 2022-06-21 09:04:15.984104
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Check that the method can encode unicode strings to byte strings
    assert isinstance(environ.__setitem__('foo', 'foo'), None)

    # Check that the method can encode byte strings to byte strings
    assert isinstance(environ.__setitem__('foo', b'foo'), None)

# Generated at 2022-06-21 09:04:19.980153
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    r'''Unit test for method __delitem__ of class _TextEnviron'''
    environ_der = _TextEnviron()
    environ_der['MYENV'] = r'MYVAL'
    assert environ_der['MYENV'] == r'MYVAL'
    assert 'MYENV' in environ_der
    del environ_der['MYENV']
    assert 'MYENV' not in environ_der


# Generated at 2022-06-21 09:04:21.161614
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 09:04:32.236023
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron({b'ANSIBLE_MODULE_ARGS': b'{something: "nice"}'},
                           b'utf-8')
    assert(environ[b'ANSIBLE_MODULE_ARGS'] == u'{something: "nice"}')
    assert(environ[u'ANSIBLE_MODULE_ARGS'] == environ[b'ANSIBLE_MODULE_ARGS'])

    # Test equalities
    assert(environ[u'ANSIBLE_MODULE_ARGS'] == u'{something: "nice"}')

    # Test __getitem__
    assert(environ.__getitem__(b'ANSIBLE_MODULE_ARGS') ==
           environ[b'ANSIBLE_MODULE_ARGS'])

# Generated at 2022-06-21 09:04:40.430545
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Initialize io.StringIO()
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO
    stdout = StringIO()
    stderr = StringIO()

    # Redirect standard output and standard error.
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    sys.stdout = stdout
    sys.stderr = stderr

    # --stderr-on-error
    # If set, the test runner will write the standard error of the
    # unit test to the standard output only if the test failed.
    #
    # -v
    # Increase the verbosity of the output. There are three levels
    # of verbosity:
    #     1. (Default) - Only a summary of the unit test execution is displayed.

# Generated at 2022-06-21 09:04:47.218342
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # __iter__ iterate over the keys

    # Set up some environment to iterate over
    os.environ['KEY_1'] = 'value1'
    os.environ['KEY_2'] = 'value2'

    # Iterate over the keys
    result = []
    for key in environ:
        result.append(key)

    assert result == ['KEY_1', 'KEY_2']



# Generated at 2022-06-21 09:04:49.639373
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron(encoding='utf-8')
    environ['abc'] = 'def'
    assert environ['abc'] == 'def'


# Generated at 2022-06-21 09:04:53.168987
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    t = _TextEnviron()
    assert isinstance(t.encoding, str)
    assert t.encoding == sys.getfilesystemencoding()
    t = _TextEnviron(encoding='latin-1')
    assert isinstance(t.encoding, str)
    assert t.encoding == 'latin-1'



# Generated at 2022-06-21 09:04:56.465695
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Setup
    from six import PY2
    env = _TextEnviron()

    # Test
    assert len(env) == len(os.environ)

    # Tear Down



# Generated at 2022-06-21 09:05:04.415566
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    encoding = 'utf-8'
    e = {to_bytes('key1', encoding=encoding): to_bytes('value1', encoding=encoding),
         to_bytes('key2', encoding=encoding): to_bytes('value2', encoding=encoding)}

    env = _TextEnviron(env=e, encoding=encoding)
    assert len(env) == 2
    assert env['key1'] == 'value1'
    assert env['key2'] == 'value2'
    assert env.get('key2') == 'value2'
    assert env.get('key2', 'VVV') == 'value2'
    assert env.get('key3', 'VVV') == 'VVV'
    assert env.get('key3') is None

# Generated at 2022-06-21 09:05:24.023102
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest2 as unittest

    class TestEnvironGetItem(unittest.TestCase):
        def test_passthrough(self):
            testenv = {'FOO': 'bar'}
            env = _TextEnviron(env=testenv)
            self.assertEqual(env['FOO'], 'bar')

        def test_decode(self):
            testenv = {'FOO': b'bar'}
            env = _TextEnviron(env=testenv)
            self.assertEqual(env['FOO'], 'bar')

        def test_errors_raise(self):
            testenv = {'FOO': b'\xff'}
            env = _TextEnviron(env=testenv)

# Generated at 2022-06-21 09:05:31.767876
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Tests that environ was initialized with the default argument (environ).
    assert environ == os.environ
    # Tests that non-strings are converted to strings.
    environ['TEST_INTEGER'] = 1
    assert environ['TEST_INTEGER'] == '1'
    # Tests that the value is stored in the encoding specified.
    test_value = u'\u03B1\u03B2\u03B3'
    environ['TEST_UNICODE'] = test_value
    assert environ['TEST_UNICODE'].encode('utf-8') == b'\xce\xb1\xce\xb2\xce\xb3'

# Generated at 2022-06-21 09:05:34.781112
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    my_environ = _TextEnviron()
    my_environ['my_key'] = 'my_value'
    del my_environ['my_key']
    assert len(my_environ) == len(environ) - 1



# Generated at 2022-06-21 09:05:37.067095
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import os
    e = os.environ.copy()
    del e[b'PATH']
    del environ['PATH']
    assert e == dict(environ)



# Generated at 2022-06-21 09:05:38.950297
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-21 09:05:42.736365
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    # Test for function __delitem__ of _TextEnviron class
    environ._raw_environ['_text_environ_test'] = 'Hello'
    del(environ['_text_environ_test'])
    assert '_text_environ_test' not in environ._raw_environ


# Generated at 2022-06-21 09:05:48.070243
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import os
    import sys

    # Test normal behaviour
    os.environ.clear()
    os.environ['a'] = 'b'
    assert len(environ) == 1
    os.environ['b'] = 'c'
    assert len(environ) == 2

    # Test after deleting an item
    del os.environ['a']
    assert len(environ) == 1



# Generated at 2022-06-21 09:05:55.565077
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from six import StringIO
    from ansible.module_utils.six import PY2

    old_environ = os.environ
    old_stdout = sys.stdout


# Generated at 2022-06-21 09:06:00.483367
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # original environment
    assert os.environ == environ._raw_environ
    # None for '_TextEnviron' value
    assert environ._value_cache == {}
    # encoding should be the same as sys.getfilesystemencoding()
    assert environ.encoding == sys.getfilesystemencoding()

