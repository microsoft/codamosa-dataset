

# Generated at 2022-06-21 08:56:01.663603
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    bypass_weird_python2_type_checking = environ  # NOQA pylint: disable=unused-variable
    environ['goodval'] = 'goodval'
    environ['surrogate'] = u'\udcff'



# Generated at 2022-06-21 08:56:06.897395
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import random
    import string
    random.seed()
    n = random.randint(0, 10)
    test_env = _TextEnviron()
    test_env._raw_environ = {}
    for i in range(n):
        test_env._raw_environ[random.choice(string.ascii_letters)] = random.choice(string.ascii_letters)
    assert len(test_env) == n


# Generated at 2022-06-21 08:56:10.879806
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, _TextEnviron)
    assert environ._raw_environ == os.environ
    assert environ.encoding == 'utf-8'


# Generated at 2022-06-21 08:56:13.008508
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    e = _TextEnviron()
    assert len(e) == len(os.environ)


# Generated at 2022-06-21 08:56:15.399292
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert (isinstance(environ.__iter__(), type(environ._raw_environ.__iter__())))



# Generated at 2022-06-21 08:56:16.539010
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 08:56:19.017075
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron()
    assert hasattr(env, '__iter__')
    assert callable(env.__iter__)


# Generated at 2022-06-21 08:56:23.143781
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = {b'key1': b'value',
           b'key2': b'value2'}
    environ = _TextEnviron(env=env)
    
    # Test
    assert len(environ) == 2


# Generated at 2022-06-21 08:56:24.481933
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-21 08:56:25.986302
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    for key in environ:
        assert isinstance(key, str)



# Generated at 2022-06-21 08:56:37.131032
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import types
    import unittest

    class _TextEnvironTestCase(unittest.TestCase):
        def test__iter__(self):
            self.assertTrue(isinstance(environ.__iter__(), types.GeneratorType),
                        '__iter__ is not a generator')
            self.assertEqual(next(environ.__iter__()), next(iter(environ)),
                        '__iter__ is not a generator')

    suite = unittest.TestLoader().loadTestsFromTestCase(_TextEnvironTestCase)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 08:56:40.569022
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    mocks = _TextEnviron({'ANSIBLE_VAULT_PASSWORD_FILES': '/tmp/home/vault.txt'})
    assert len(mocks) == 1



# Generated at 2022-06-21 08:56:42.876139
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    test_input = dict(a='b')
    test_obj = _TextEnviron(test_input)
    test_result = list(test_obj)
    assert test_result == ['a']


# Generated at 2022-06-21 08:56:48.038771
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    s = _TextEnviron(encoding='utf-8')
    s['str'] = 'value'
    assert isinstance(s._raw_environ['str'], bytes)
    assert isinstance(s['str'], str)
    assert s['str'] == 'value'



# Generated at 2022-06-21 08:56:54.183750
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    class os_environ_mock(dict):
        def __setitem__(self, key, value):
            dict.__setitem__(self, key, value)
    os_environ = os_environ_mock()
    text_environ = _TextEnviron(os_environ, 'ascii')
    text_environ['foo'] = 'bar'
    assert os_environ['foo'] == b'bar'

# Generated at 2022-06-21 08:57:02.204442
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test that all the methods of MutableMapping are present
    assert hasattr(_TextEnviron, '__delitem__')
    assert hasattr(_TextEnviron, '__getitem__')
    assert hasattr(_TextEnviron, '__setitem__')
    assert hasattr(_TextEnviron, '__iter__')
    assert hasattr(_TextEnviron, '__len__')

    # Test that the encoding can be set
    env = _TextEnviron(encoding='utf-8')
    assert env.encoding == 'utf-8'
    env = _TextEnviron(encoding='ascii')
    assert env.encoding == 'ascii'

    # Test that the initial value is os.environ
    env = _TextEnviron()
    assert env._raw_environ is os.environ

    #

# Generated at 2022-06-21 08:57:09.086896
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['ANSIBLE_TEST_VAR'] = 'first test string'

    expected_result = 'first test string'
    actual_result = environ['ANSIBLE_TEST_VAR']
    assert expected_result == actual_result

    expected_result = u'first test string'
    actual_result = environ['ANSIBLE_TEST_VAR']
    assert expected_result == actual_result

    os.environ['ANSIBLE_TEST_VAR'] = b'second test string'

    expected_result = u'second test string'
    actual_result = environ['ANSIBLE_TEST_VAR']
    assert expected_result == actual_result

    # Clean up for subsequent tests
    del os.environ['ANSIBLE_TEST_VAR']
    del environ._value_cache

# Generated at 2022-06-21 08:57:10.788408
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron()
    environ['A'] = 'Æ'
    assert b'\xc3\x86' == environ._raw_environ['A']

# Generated at 2022-06-21 08:57:16.825094
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import PY3 as _PY3
    from ansible.module_utils._text import to_bytes as _to_bytes, to_text as _to_text

    _environ_arg = dict(
        foo=_to_bytes('foo'),
        bar=_to_bytes('bar'),
    )
    _encoding_arg = 'utf-8'
    _encoding_result = _encoding_arg

    _raw_environ_result = dict(
        foo=_to_bytes('foo'),
        bar=_to_bytes('bar'),
    )

    _value_cache_result = {}

    _return_value = _TextEnviron(_environ_arg, _encoding_arg)
    assert _return_value._raw_environ == _raw_environ_result

# Generated at 2022-06-21 08:57:20.127754
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({'1': '1', '2': '2'})
    assert len(env) == 2  # i.e. len equal to environ length



# Generated at 2022-06-21 08:57:28.146744
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils._text import to_bytes

    class A(object):
        def __init__(self):
            self._d = {}

        def __len__(self):
            return len(self._d)

        def __getitem__(self, key):
            return self._d[key]

        def __setitem__(self, key, value):
            self._d[key] = value

        def __delitem__(self, key):
            del self._d[key]

        def __iter__(self):
            return iter(self._d)

    a = A()
    a[to_bytes('a', encoding='utf-8')] = to_bytes('asdf', encoding='utf-8')
    b = _TextEnviron(env=a, encoding='utf-8')
    assert 1

# Generated at 2022-06-21 08:57:36.935281
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # pylint: disable=too-many-branches
    import unittest

    class TestEnviron:
        def __init__(self, keys):
            self.keys = keys

        def __iter__(self):
            for key in self.keys:
                yield key

    class TestCases(unittest.TestCase):
        def test_empty(self):
            class TestEnv(_TextEnviron):
                def __init__(self):
                    self._raw_environ = TestEnviron({})

            env = TestEnv()
            self.assertEqual([], list(env))

        def test_one_key(self):
            class TestEnv(_TextEnviron):
                def __init__(self):
                    self._raw_environ = TestEnviron({'a': 'b'})

            env

# Generated at 2022-06-21 08:57:46.536420
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    u'''
    Test method __getitem__ of class _TextEnviron
    '''

    # Test case to check that method __getitem__ of class _TextEnviron
    # returns text string for given byte string
    key = b'PATH'
    actual_return_type = type(environ.__getitem__(key))
    expected_return_type = type(u'')
    assert actual_return_type == expected_return_type, \
        'Expected return type is {0} and actual return type is {1}'.format(expected_return_type,
                                                                           actual_return_type)



# Generated at 2022-06-21 08:57:50.535172
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({b'key1': b'value1', b'key2': b'value2', b'key3': b'value3'})
    len_result = len(env)
    assert len_result == 3


# Generated at 2022-06-21 08:57:53.132448
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    t = _TextEnviron()
    assert t.encoding == sys.getfilesystemencoding()
    assert PY3 == (t.encoding == 'utf-8')

# Generated at 2022-06-21 08:57:59.973540
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import os
    import sys

    try:
        # Get the first two env variables
        raw_keys = os.environ.keys()
        keys = environ.keys()
        assert raw_keys[0] == keys[0]
        assert raw_keys[1] == keys[1]
        # Get the env variables using the iter method of _TextEnviron
        keys = list()
        for key in environ:
            keys.append(key)
        assert len(keys) == len(os.environ)
        assert keys[0] == raw_keys[0]
        assert keys[1] == raw_keys[1]
    except:
        pass

# Generated at 2022-06-21 08:58:11.518080
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils._text import to_bytes, to_text
    environ = _TextEnviron(encoding='utf-8')
    #
    # Test that we're setting keys into the environment via their byte value
    #
    environ[u'TESTING'] = u'Testing'
    assert b'TESTING' in environ._raw_environ
    assert u'TESTING' not in environ._raw_environ
    assert to_bytes(u'TESTING', encoding='utf-8') in environ._raw_environ
    assert b'Testing' in environ._raw_environ[b'TESTING']
    assert u'Testing' not in environ._raw_environ[b'TESTING']
    #
    # Test that we're returning Unicode values from the environment
    #

# Generated at 2022-06-21 08:58:16.157567
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    env['test_key'] = 'test_value'
    assert 'test_key' in env
    assert env['test_key'] == 'test_value'
    assert env._raw_environ['test_key'] == b'test_value'



# Generated at 2022-06-21 08:58:20.090700
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six.moves import UserDict
    assert isinstance(environ, UserDict)
    assert issubclass(UserDict, MutableMapping)
    assert isinstance(environ, MutableMapping)

# Generated at 2022-06-21 08:58:26.261827
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Create new instance of _TextEnviron
    environ = _TextEnviron()

    # Set item should take 'value' as unicode, encode it into bytes, and set the key 'key' to it.
    key = 'key'
    value = u'value'

    environ[key] = value

    assert environ._raw_environ['key'] == b'value'

# Generated at 2022-06-21 08:58:30.250195
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron()
    assert isinstance(env, MutableMapping)



# Generated at 2022-06-21 08:58:34.135541
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # 'env' used only to pass the test.
    env = {'a': '1', 'b': '2', 'c': '3'}
    env_valid = {'a': '1', 'c': '3'}
    environ_test = _TextEnviron(env=env)
    del environ_test['b']
    assert (environ_test._raw_environ == env_valid)


# Generated at 2022-06-21 08:58:37.954002
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    new_env = _TextEnviron({u'foo': u'bar'})
    del new_env['foo']
    assert u'foo' not in new_env._raw_environ


# Generated at 2022-06-21 08:58:42.151547
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ["ANSIBLE_TEST_DELITEM__TEXTENVIRON"] = ""
    del environ["ANSIBLE_TEST_DELITEM__TEXTENVIRON"]
    assert not "ANSIBLE_TEST_DELITEM__TEXTENVIRON" in environ._raw_environ


# Generated at 2022-06-21 08:58:45.542522
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert 12 == len(environ)
    environ['__test__'] = 'set'
    assert 13 == len(environ)
    del environ['__test__']


# Generated at 2022-06-21 08:58:54.799501
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # preqreuisites:
    # - no environment variable with key 'ANSTEST' is set
    # - class _TextEnviron is defined
    environ = _TextEnviron({})
    assert 'ANSTEST' not in environ
    # testcase 1:
    # - environ['ANSTEST'] = 'OK'
    # - del environ['ANSTEST']
    # - 'ANSTEST' is not in environ
    environ['ANSTEST'] = 'OK'
    assert environ['ANSTEST'] == 'OK'
    del environ['ANSTEST']
    assert 'ANSTEST' not in environ
    return True


# Generated at 2022-06-21 08:59:03.622018
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_dict = {'ANSIBLE_COW_SELECTION': u'random',
                 'ANSIBLE_FORCE_COLOR': u'false'}
    test_environ = _TextEnviron(test_dict, encoding='utf-8')
    test_environ.__delitem__(u'ANSIBLE_FORCE_COLOR')
    assert u'ANSIBLE_FORCE_COLOR' not in test_environ.keys()
    assert u'ANSIBLE_FORCE_COLOR' not in test_environ._raw_environ.keys()


# Generated at 2022-06-21 08:59:07.524749
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, _TextEnviron)
    assert isinstance(environ, MutableMapping)
    assert len(environ) > 1
    for key, value in environ.items():
        assert isinstance(key, str)
        assert isinstance(value, str)

# Generated at 2022-06-21 08:59:13.976650
# Unit test for method __iter__ of class _TextEnviron

# Generated at 2022-06-21 08:59:16.909658
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ["foo"] = "bar"
    assert environ["foo"] == "bar"
    del environ["foo"]
    assert "foo" not in environ


# Generated at 2022-06-21 08:59:23.137769
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    test_data = {'a': 'b', 'b': 'c', 'c': 'd'}
    test_object = _TextEnviron(test_data)
    assert list(iter(test_object)) == list(iter(test_data))



# Generated at 2022-06-21 08:59:31.795409
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    value_cache = environ._value_cache.copy()
    environ._value_cache.clear()

    # If the value is cached, it should be returned
    assert environ['PATH'] == '/bin:/usr/bin'
    assert environ._value_cache[environ._raw_environ['PATH']] == environ['PATH']

    # If the value is not cached and is already text, it should be returned
    if sys.version_info < (2, 7):
        assert environ['TEST_GETITEM_STR'] == to_text(environ._raw_environ['TEST_GETITEM_STR'],
                                                      encoding=environ.encoding, nonstring='passthru',
                                                      errors='surrogate_or_strict')

# Generated at 2022-06-21 08:59:41.754038
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Create test environment which is empty
    env = _TextEnviron({})
    # Set some ASCII values
    env['key_ascii'] = 'value_ascii'
    # Set some non-ASCII values
    env['key_chinese_utf8'] = u'你好'.encode('utf-8')
    env['key_chinese_big5'] = u'你好'.encode('big5')

    # Test values
    assert env['key_ascii'] == u'value_ascii'
    assert env['key_chinese_utf8'] == u'你好'
    assert env['key_chinese_big5'] == u'你好'

# Generated at 2022-06-21 08:59:45.150167
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    expected = [b'foo', b'bar']
    actual = []
    for elem in environ:
        actual.append(elem)
    assert ordered(actual) == ordered(expected)



# Generated at 2022-06-21 08:59:51.461543
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_environ = _TextEnviron()
    test_environ['FOO'] = 'foo'

    assert 'FOO' in test_environ
    assert test_environ['FOO'] == 'foo'

    del test_environ['FOO']

    assert 'FOO' not in test_environ
    assert test_environ['FOO'] != 'foo'


# Generated at 2022-06-21 08:59:53.640360
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test for method __getitem__ of class _TextEnviron

    :return:
    """
    text_environ_ = _TextEnviron()
    print(text_environ_)


if __name__ == '__main__':
    test__TextEnviron___getitem__()

# Generated at 2022-06-21 08:59:56.057510
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    a = _TextEnviron()
    a['a'] = 'a'
    assert a['a'] == 'a'
    assert a._raw_environ['a'] == b'a'


# Generated at 2022-06-21 09:00:07.669504
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from io import StringIO
    from unittest import TestCase
    import sys

    class Test_TextEnviron_Setitem(TestCase):
        def setUp(self):
            # Set sys.stdout to StringIO so we can test that we set the right value
            self.stdout = StringIO()
            self.real_stdout = sys.stdout
            sys.stdout = self.stdout

        def tearDown(self):
            # Reset sys.stdout
            self.stdout.close()
            sys.stdout = self.real_stdout

        def test_py2_to_bytes(self):
            if PY3:
                # Not testing this case on Python3 so just return
                return

            env_text = _TextEnviron()
            env_text['key'] = 'value'

# Generated at 2022-06-21 09:00:10.088099
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    t = _TextEnviron()

    t['foo'] = 'bar'
    del t['foo']

    assert 'foo' not in t


# Generated at 2022-06-21 09:00:18.394020
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Start by setting a key to a value that is encoded as utf-8
    environ['TEST_KEY'] = u'\xe9'
    assert b'\xc3\xa9' == os.environ[b'TEST_KEY']

    # Now set a key to a value that is encoded as latin-1.  What happens depends on what encoding
    # the terminal is in (so this test can't be run from a CI system)
    environ['TEST_KEY'] = u'\xe9'.encode('latin-1')
    # If the terminal is set to latin-1, we get a latin-1 value back
    if sys.stdout.encoding == 'ISO-8859-1':
        assert b'\xe9' == os.environ[b'TEST_KEY']
    # If

# Generated at 2022-06-21 09:00:29.986342
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron(env={'TEST': 'TEST'}, encoding='utf-8')
    env['TEST'] = 'test'.encode('utf-8')
    assert env['TEST'] == 'test'

    env['TEST'] = 'test'.encode('utf-16')
    assert env['TEST'] == u'test'

    env['TEST'] = b'\xd0\x9f\xd1\x8c\xd1\x8e\xd1\x80\xd1\x83\xd1\x81\xd1\x81\xd0\xba\xd0\xb8\xd0\xb9'
    # utf-16

# Generated at 2022-06-21 09:00:32.061103
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = _TextEnviron()
    assert test_environ['PATH'] == environ['PATH']

# Generated at 2022-06-21 09:00:39.305937
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import unittest

    class Test__TextEnviron___iter__(unittest.TestCase):
        def test_with_no_args(self):
            test_obj = _TextEnviron()
            self.assertEqual(len(test_obj), len(os.environ))
            for key in os.environ:
                self.assertEqual(test_obj[key], os.environ[key])

            for key in test_obj:
                self.assertTrue(key in os.environ)
                self.assertEqual(test_obj[key], os.environ[key])

    unittest.main()


# Generated at 2022-06-21 09:00:50.178156
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['a'] = u'\N{CYRILLIC CAPITAL LETTER BE}'
    assert isinstance(environ['a'], type(u'')), 'Key [a] is not unicode'
    assert environ['a'] == u'\N{CYRILLIC CAPITAL LETTER BE}', 'Key [a] not equal to value'

    # Verify caching of values
    environ._value_cache = {}
    environ._raw_environ['a'] = b'\xd0\x91'
    assert environ['a'] == u'\N{CYRILLIC CAPITAL LETTER BE}', 'Key [a] not equal to value'
    # Make sure we cache the value
    assert len(environ._value_cache) == 1



# Generated at 2022-06-21 09:00:51.541568
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ) == list(os.environ)

# Generated at 2022-06-21 09:00:56.379611
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that retieving the variable works
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that bytes passed in are converted to text
    environ['test'] = b'test'
    assert environ['test'] == 'test'
    del environ['test']

    # Test that a variable that changes is updated
    environ['test'] = 'test1'
    assert environ['test'] == 'test1'
    environ['test'] = 'test2'
    assert environ['test'] == 'test2'
    del environ['test']

    # Test that a variable that changes is changed if we've retieved it as text already
    environ['test'] = 'test1'
    assert environ['test'] == 'test1'
    val = environ['test']

# Generated at 2022-06-21 09:00:59.536172
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    with pytest.raises(AttributeError) as excinfo:
        len()
    assert excinfo.value.args[0].startswith("'module' object has no attribute 'environ'")



# Generated at 2022-06-21 09:01:10.424531
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    global environ
    environ["ansible_python_interpreter"] = "Ñôṕyṭħõñ"

    try:
        os.environ["ansible_python_interpreter"]
    except KeyError:
        raise AssertionError("Environment variable ansible_python_interpreter not created")

    if os.environ["ansible_python_interpreter"] != b'\xc3\x91\xc3\xb4\xe1\xb8\xbf\xe1\xb9\xad\xc5\x8d\xcc\xb0\xc4\x91\xc3\xb4\xc3\xb1':
        raise AssertionError("ansible_python_interpreter value different from expected.")


# Generated at 2022-06-21 09:01:12.769075
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    e = _TextEnviron({u'test1': u'test2'})
    len_e = len(e)
    assert len_e == 1



# Generated at 2022-06-21 09:01:14.576143
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({'abc': 'one', 'def': 'two'})

    assert len(env) == 2



# Generated at 2022-06-21 09:01:35.064966
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import os, sys
    # Since the class is designed to work on Python 2 and Python 3, check whether it behaves
    # like os.environ on each.  There are differences in the default behavior between Python 2 and
    # Python 3
    # Python 2: Assumes non-unicode things can be converted to ASCII
    # Python 3: Assumes non-unicode things are binary
    if PY3:
        encoding = 'utf-8'
        strict = 'strict'
        surrogate = 'surrogate_or_strict'
        nonstring = 'passthru'
        totext_expected_encoding = 'utf-8'
    else:
        encoding = 'ascii'
        strict = 'ignore'
        surrogate = 'surrogate_then_replace'
        nonstring = 'strict'
        totext_expected_

# Generated at 2022-06-21 09:01:38.265202
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['abc'] = b'\xc3\xb6\xc3\xa4\xc3\xbc'
    assert environ['abc'] == 'öäü'
if __name__ == '__main__':
    test__TextEnviron___getitem__()

# Generated at 2022-06-21 09:01:49.091227
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import pytest
    from ansible.module_utils.common.text_unicode import to_unicode
    from ansible.module_utils.common.text_unicode import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.text_unicode import to_text

    class _TextEnviron(MutableMapping):

        def __init__(self, env=None, encoding=None):
            if env is None:
                env = os.environ
            self._raw_environ = env
            self._value_cache = {}
            # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
            # instead of utf-8

# Generated at 2022-06-21 09:01:52.694801
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = os.environ
    os.environ = {'x': 'abc'}
    value = _TextEnviron()
    assert value['x'] == 'abc'
    # Set os.environ back to where it was
    os.environ = env

# Generated at 2022-06-21 09:02:02.643707
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron()
    # Test that we can pass in an environment to mimic
    env_vars = {'str_key': 'str_val', u'unicode_key': u'unicode_val'}
    env = _TextEnviron(env=env_vars)

    # Test that we get the right values back
    if PY3:
        assert env['str_key'] == 'str_val'
        assert env['unicode_key'] == 'unicode_val'
        if env._raw_environ['str_key'] is not env_vars['str_key']:
            raise AssertionError('Environment with passed in environment should have used the '
                                 'passed in environment')

# Generated at 2022-06-21 09:02:03.835678
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 09:02:09.776021
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
  import unittest
  import six
  class __TextEnviron___iter__TestCase(unittest.TestCase):
    """Test the method __iter__ of class _TextEnviron"""
    def test__TextEnviron___iter__(self):
      result = next(iter(environ))
      self.assert_(isinstance(result, six.string_types))
  return __TextEnviron___iter__TestCase


# Generated at 2022-06-21 09:02:14.435572
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    # No environment tests
    class EmptyEnviron(dict):
        def __contains__(self, key):
            return False
    empty_env = EmptyEnviron()
    assert len(env) == len(os.environ)
    assert len(_TextEnviron(env=empty_env)) == 0
    assert len(empty_env) == 0



# Generated at 2022-06-21 09:02:19.124812
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """Check iterating over environment"""
    env = {to_bytes("FOO"): to_bytes("BAR")}
    environ = _TextEnviron(env)
    for k in environ:
        assert isinstance(k, str)

# Generated at 2022-06-21 09:02:24.912819
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test without without non-ASCII text
    environ.clear()
    environ['FOO'] = 'bar'
    assert isinstance(environ['FOO'], str)
    assert environ['FOO'] == 'bar'
    # Test with non-ASCII text
    environ.clear()
    environ['FOO'] = u'bar\x00'
    assert isinstance(environ['FOO'], str)
    assert environ['FOO'] == u'bar\x00'

# Generated at 2022-06-21 09:02:34.890529
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) >= 3

# Generated at 2022-06-21 09:02:44.510252
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ2 = _TextEnviron({b'one': b'foo', 'two': 'bar'})
    assert environ2['one'] == 'foo'
    assert environ2['two'] == 'bar'
    assert isinstance(environ2['one'], str)
    assert isinstance(environ2['two'], str)
    assert isinstance(environ2._raw_environ['one'], bytes)
    assert isinstance(environ2._raw_environ['two'], str)

    environ2 = _TextEnviron(encoding='ascii')
    environ2['foo'] = 'bar'
    assert environ2['foo'] == 'bar'
    assert isinstance(environ2['foo'], str)
    assert isinstance(environ2._raw_environ['foo'], bytes)

# Generated at 2022-06-21 09:02:53.661446
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Set up the test
    environ_test = _TextEnviron(env={'foo': 'bar'}, encoding='ascii')

    # Check that all the dictionary operations work
    assert len(environ_test) == 1
    assert 'foo' in environ_test
    assert environ_test['foo'] == 'bar'
    del environ_test['foo']
    assert len(environ_test) == 0
    environ_test['foo'] = 'bar'
    assert len(environ_test) == 1
    assert 'foo' in environ_test
    assert environ_test['foo'] == 'bar'
    assert list(environ_test) == ['foo']
    environ_test.clear()
    assert len(environ_test) == 0

    # Check that we don't decode the non-

# Generated at 2022-06-21 09:03:00.961878
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import locale

    environ = _TextEnviron(encoding=locale.getpreferredencoding(False))
    # os.environ.__getitem__(key) returns bytes on Python2 except KEY is unicode
    assert not isinstance(environ.__getitem__('PATH'), six.text_type)
    assert isinstance(environ.__getitem__('PATH'), six.binary_type)
    # environ.__getitem__(key) always returns unicode
    assert isinstance(environ.__getitem__('PATH'), six.text_type)
    del environ


# Generated at 2022-06-21 09:03:07.210687
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({'TEST_DELETE': 'TEST_DELETE_VALUE'})

    try:
        env['TEST_DELETE']
    except KeyError:
        raise AssertionError("Key wasn't found")

    try:
        del env['TEST_DELETE']
    except KeyError:
        raise AssertionError("Key wasn't deleted")

    try:
        env['TEST_DELETE']
    except KeyError:
        return

    raise AssertionError("Key was found")



# Generated at 2022-06-21 09:03:13.873685
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test that __getitem__ maps correctly using the python interpreter major version.

    This test is executed only if the underlying interpreter is Python 2.X.

    :return: No return value
    :rtype: None
    """
    if sys.version_info[0] != 2:
        return
    test_environ = _TextEnviron()
    assert test_environ['PATH'] == u'/bin'

# Generated at 2022-06-21 09:03:17.075209
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron(encoding='utf-8')
    result = text_environ['PYTHONPATH']
    assert isinstance(result, str)



# Generated at 2022-06-21 09:03:24.616943
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import sys
    from ansible.module_utils.six import PY3

    test_environ = {"key1": "value1",
                    u"key2": u"value2",
                    "key3": "\u1234",
                    "key4": "\U0001F40D",
                    "key5": "a\x00bad\xff\u1234\U0001F40D",
                    }
    # Need the side_effects to support Python3.5 and earlier where mock doesn't support
    # multiple calls to the same mocked method in the same test case.
    if PY3:
        environ._raw_environ.__getitem__.side_effect = test_environ.__getitem__
    else:
        environ._raw_environ.__getitem__.side_effect = lambda k: test_environ

# Generated at 2022-06-21 09:03:28.257446
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ._raw_environ = {b'key1': b'value1',
                            b'key2': b'value2',
                            b'key3': b'value3'}
    expected = ['key1', 'key2', 'key3']
    assert list(environ.__iter__()) == expected


# Generated at 2022-06-21 09:03:30.701749
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    del environ['PATH']
    len_environ = len(environ)
    environ['PATH'] = '/usr/bin:/usr/sbin'
    assert len_environ + 1 == len(environ)

# Generated at 2022-06-21 09:03:52.979858
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['ANSIBLE_MODULE_TEST_VAR'] = 'ANSIBLE_MODULE_TEST_VALUE'
    assert environ['ANSIBLE_MODULE_TEST_VAR'] == 'ANSIBLE_MODULE_TEST_VALUE'
    del environ['ANSIBLE_MODULE_TEST_VAR']
    try:
        assert environ['ANSIBLE_MODULE_TEST_VAR']
        assert False
    except KeyError:
        pass


# Generated at 2022-06-21 09:03:56.124634
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    my_env = _TextEnviron({'ANSIBLE_MODULE_ANSIBLE_GIT_COMMIT': 'cc9961caf'})
    assert len(my_env) == 1
    assert 1 == len(my_env)



# Generated at 2022-06-21 09:03:59.162075
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron(env={"A": "a", "B": "b"})
    del env["A"]
    assert "A" not in env
    assert "B" in env


# Generated at 2022-06-21 09:04:03.537621
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _environ = _TextEnviron()
    key = '_test__TextEnviron__delitem__'
    value = 'Testing __delitem__'
    _environ[key] = value
    del _environ[key]
    assert key not in _environ


# Generated at 2022-06-21 09:04:08.157554
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['A'] = 'A'
    assert(environ['A'] == 'A')
    environ['A'] = u'Å'
    assert(environ['A'] == u'Å')
    if not PY3:
        assert(environ._raw_environ['A'] == 'Å'.encode('utf-8'))

# Generated at 2022-06-21 09:04:13.881440
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():

    mock_raw_environ = {b'ANSIBLE_STRING_CONVERSION': b'b',
                        b'ANSIBLE_RETRY_FILES_ENABLED': b'False'}

    mock_environ = _TextEnviron(env=mock_raw_environ)

    assert list(mock_environ) == [b'ANSIBLE_STRING_CONVERSION', b'ANSIBLE_RETRY_FILES_ENABLED']



# Generated at 2022-06-21 09:04:20.771990
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    The method __delitem__ of class _TextEnviron should remove an environment variable from the
    dictionary.

    The removal of an environment variable should also prevent the variable from being returned
    in the environment if the variable is listed in os.environ.
    """
    env_key = 'A_TEXT_ENVIRON_TEST_KEY'
    env_value = 'A_TEXT_ENVIRON_TEST_VALUE'
    environ[env_key] = env_value
    assert env_key in environ
    assert environ[env_key] == env_value
    assert env_key in os.environ
    assert os.environ[env_key] == env_value
    del environ[env_key]
    assert env_key not in environ
    assert env_key not in os.environ

# Generated at 2022-06-21 09:04:24.499938
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    testenv = _TextEnviron(env={'a': 'b'})
    assert list(testenv.keys()) == ['a']
    testenv.pop('a')
    assert list(testenv.keys()) == []


# Generated at 2022-06-21 09:04:27.547096
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_env = _TextEnviron()
    assert isinstance(test_env['PATH'], str)
    assert isinstance(test_env['PATH'], unicode)


# Generated at 2022-06-21 09:04:29.471400
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    assert len(env) == len(os.environ)


# Generated at 2022-06-21 09:05:08.474604
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['TEST'] = 'test'
    del(environ['TEST'])
    try:
        os.environ['TEST']
        pytest.fail("del(environ['TEST']) didn't delete the value from os.environ")
    except KeyError:
        pass


# Generated at 2022-06-21 09:05:13.950231
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = {
        b'ANSIBLE_TEST_KEY_1': b'Bogus Value 1',
        b'ANSIBLE_TEST_KEY_2': b'Bogus Value 2',
        b'ANSIBLE_TEST_KEY_3': b'Bogus Value 3',
    }
    env_text = _TextEnviron(env=env)
    assert sorted(env_text.__iter__()) == sorted(env.keys())
    assert sorted(env_text) == sorted(env.keys())


# Generated at 2022-06-21 09:05:15.664980
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    test_env = _TextEnviron({'hello': 'world'})
    assert len(test_env) == 1


# Generated at 2022-06-21 09:05:19.330968
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Method _TextEnviron.__setitem__ should return a string in the given encoding
    """
    environ['abc'] = 'abc'
    assert isinstance(environ['abc'], str)



# Generated at 2022-06-21 09:05:21.636284
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Accessing elements in _TextEnviron instance.
    _TextEnviron.__init__(os.environ)
    _TextEnviron.__getitem__(os.environ)


# Generated at 2022-06-21 09:05:25.881359
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron(encoding='utf-8')

    if PY3:
        assert isinstance(environ['LANG'], str)
    else:
        assert isinstance(environ['LANG'], unicode)

# Generated at 2022-06-21 09:05:33.470432
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ["TEST1"] = "\u4f0a\u85e4\u5b89\u5bae"  # Japanese Kanji
    # Change the code to the Unicode Kanji name
    assert environ["TEST1"] == u"\u4f0a\u85e4\u5b89\u5bae"

    environ["TEST2"] = "\u4f0a\u85e4\u5b89\u5bae"  # Japanese Kanji in UTF-8
    # Change the code to the Unicode Kanji name
    assert environ["TEST2"] == "\u4f0a\u85e4\u5b89\u5bae"


# Generated at 2022-06-21 09:05:34.483771
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == '/bin:/usr/bin'


# Generated at 2022-06-21 09:05:43.513860
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # These tests check the encoding of the input to os.environ.  The encoding and decoding of the
    # returned data is tested in test__TextEnviron__getitem__
    e = _TextEnviron(encoding='utf-8')
    # str on py2 with utf-8 should get encoded properly
    e['a'] = u'\u1234'
    assert b'\xe1\x88\xb4' == os.environ[b'a']

    # str on py3 with utf-8 should get encoded properly.  Note that this is the one case that
    # doesn't need a decode since Python 3 doesn't have str
    e['b'] = '\u1234'
    assert b'\xe1\x88\xb4' == os.environ[b'b']

    # bytes on py2 or 3

# Generated at 2022-06-21 09:05:46.569101
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    '''Checking whether __len__() function is working fine or not
    '''
    obj = _TextEnviron()
    assert len(obj) == len(os.environ)
