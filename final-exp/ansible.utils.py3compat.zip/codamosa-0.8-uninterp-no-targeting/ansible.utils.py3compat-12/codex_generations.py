

# Generated at 2022-06-21 08:56:05.555077
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # pylint: disable=protected-access
    # Check that the environ is loaded from os.environ on python2 by default
    from os import environ as _os_environ
    assert environ._raw_environ is _os_environ
    # Check that the environ can be loaded from somewhere else
    custom_environ = {b'test_bytes_key1': b'test_bytes_value1',
                      b'test_bytes_key2': b'test_bytes_value2'}
    new_environ = _TextEnviron(env=custom_environ, encoding='latin-1')
    assert new_environ._raw_environ is custom_environ
    # pylint: enable=protected-access

# Generated at 2022-06-21 08:56:18.102965
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = os.environ.copy()
    env.update({'ANSIBLE_TEST_KEY1': b'\xe2\x98\xa2'})
    env.update({'ANSIBLE_TEST_KEY2': b'\xc3\x85'})
    env.update({'ANSIBLE_TEST_KEY3': b'\xe2\x98\xa2\xc3\x85\xe2\x98\xa2'})
    textenv = _TextEnviron(env, 'utf-8')
    assert textenv['ANSIBLE_TEST_KEY1'] == u'\u2622'
    assert textenv['ANSIBLE_TEST_KEY2'] == u'\xc5'

# Generated at 2022-06-21 08:56:29.430465
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # _TextEnviron should be able to construct an object from None and from an actual dict
    assert isinstance(_TextEnviron(), _TextEnviron)
    assert isinstance(_TextEnviron({}), _TextEnviron)

    # Construct an object and make sure it mimics os.environ
    orig_env_copy = os.environ.copy()
    env = _TextEnviron()

    # Make sure we can lookup all the keys and find the same values
    assert len(env.keys()) == len(os.environ.keys())
    for key in env.keys():
        assert key in os.environ
        assert env[key] == os.environ[key]

    # Make sure it handles encoding of non-ascii characters right
    os.environ['FOÖ'] = 'BÅR'

# Generated at 2022-06-21 08:56:34.112120
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    # Test for deleting an key
    environ['foo'] = 'bar'
    del environ['foo']
    assert 'foo' not in environ

    # Test for deleting a non-existent key
    os.environ['doesnotexist'] = 'bar'
    del environ['doesnotexist']



# Generated at 2022-06-21 08:56:43.780682
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # test with str
    environ['test_str'] = u'str'
    assert(environ['test_str'] == u'str')
    del environ['test_str']

    # test with bytes
    environ['test_bytes'] = b'bytes'
    assert(environ['test_bytes'] == u'bytes')
    del environ['test_bytes']

    # test with bytes for str on Python 2
    environ['test_bytes_py2'] = u'bytes'.encode('utf-8')
    assert(environ['test_bytes_py2'] == u'bytes')
    del environ['test_bytes_py2']

    # test with text when encoding is None
    environ['test_unicode'] = u'str'

# Generated at 2022-06-21 08:56:52.848554
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # We need to test that the system's filesystem encoding, which is what we're
    # using, is utf-8 because we're using utf-8 in the 'error' call in the
    # implementation of _TextEnviron.__getitem__.
    assert sys.getfilesystemencoding() == 'utf-8'

    # Test that we're getting byte strings back from os.environ
    assert isinstance(os.environ['PATH'], str)

    # Test that we're getting text back from environ
    assert isinstance(environ['PATH'], str)

# Generated at 2022-06-21 08:56:55.032854
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ['foo'] = 'bar'
    assert len(environ) == 1



# Generated at 2022-06-21 08:56:56.235006
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron()
    assert list(environ) == list(environ._raw_environ)

# Generated at 2022-06-21 08:57:00.497575
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron(encoding="utf-8")
    env['foo'] = 'bar'
    assert env._raw_environ['foo'] == 'bar'.encode("utf-8")
    assert env.get('foo') == 'bar'
    del env['foo']
    assert 'foo' not in env._raw_environ
    assert 'foo' not in env

# Generated at 2022-06-21 08:57:04.882720
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Arrange
    encoding = "utf-8"
    key = "some_random_key"
    value = "some_value"
    os.environ[key] = value

    # Act
    environ = _TextEnviron(encoding=encoding)
    result = environ[key]

    # Assert
    assert result == value


# Generated at 2022-06-21 08:57:14.739240
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Verify that both bytes and text strings can be set in the environment
    """
    # Python2's C locale will use ascii which is a strict subset of utf-8
    # If a surrogate error happens here, then the locale wasn't set to a unicode locale
    # See: https://github.com/ansible/ansible/pull/50697#issuecomment-396957430
    #      https://github.com/todylu/haskell-py-c/blob/d1063a926c98297654baa0a7a5296069d70fb7b2/src/TestUtils.hs#L1777
    #      https://github.com/pytest-dev/pytest/issues/1239
    assert os.environ[b'LANG'] == b'C.UTF-8'


# Generated at 2022-06-21 08:57:19.408374
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = {u'bytes': u'bytes', u'Unicode': u'ünîcöde'}
    text_env = _TextEnviron(env, encoding='utf-8')
    assert len([k for k in text_env]) == len(env)



# Generated at 2022-06-21 08:57:30.643707
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    from ansible.module_utils._text import to_bytes, to_text

    obj = _TextEnviron()

    # 
    obj.encoding = 'utf-8'

    # obj.environ = {'ansible_facts': {'environ': {'LANG': 'en_GB.UTF-8'}}}
    obj._raw_environ = {b'LANG': b'en_GB.UTF-8'}
    assert 'en_GB.UTF-8' == obj['LANG']

    # obj.environ = {'ansible_facts': {'environ': {'VAR': 'text'}}}
    obj._raw_environ = {b'VAR': b'text'}
    assert 'text' == obj['VAR']

    # Test if the object caches the undecoded value and returns the

# Generated at 2022-06-21 08:57:32.728461
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    e = _TextEnviron()
    e['ANSIBLE_CONFIG'] = b'/etc/ansible/ansible.cfg'
    assert e['ANSIBLE_CONFIG'] == '/etc/ansible/ansible.cfg'
    assert e._raw_environ[b'ANSIBLE_CONFIG'] == b'/etc/ansible/ansible.cfg'

# Generated at 2022-06-21 08:57:34.188919
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test that the constructor works and doesn't spin into an infinite recursion loop
    assert _TextEnviron()



# Generated at 2022-06-21 08:57:45.191744
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Unset a Python3 environment variable
    key = 'ANSIBLE_TEST_VARIABLE_FOR_UNSETTING_FROM_ENVIRON'
    if key in os.environ:
        del os.environ[key]
    assert key not in os.environ
    assert key not in _TextEnviron()

    # Set a Python3 environment variable
    key = 'ANSIBLE_TEST_VARIABLE_FOR_SETTING_FROM_ENVIRON'
    os.environ[key] = 'somevalue'
    assert os.environ[key] == 'somevalue'
    # Expect the TextEnviron class to be able to return text
    assert _TextEnviron()[key] == u'somevalue'

    # Unset a Python2 environment variable

# Generated at 2022-06-21 08:57:56.358304
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Unit test for method __delitem__ of class _TextEnviron
    """
    from ansible.module_utils.six import PY3
    import os

    env_dict = {'key1': 'value1', 'key2': 'value2'}
    env = _TextEnviron(env_dict)
    assert len(env) == 2
    assert env['key1'] == 'value1'
    assert env['key2'] == 'value2'
    del env['key1']
    try:
        env['key1']
        raise AssertionError("Expected KeyError not raised")
    except KeyError:
        pass  # Expected
    assert len(env) == 1
    assert env['key2'] == 'value2'
    env['key1'] = 'value1'

# Generated at 2022-06-21 08:58:01.276068
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    from ansible.module_utils.common._text_environ import environ
    enviro = _TextEnviron()
    enviro["TestValueKey"] = "TestValue"
    del enviro["TestValueKey"]
    try:
        value = enviro["TestValueKey"]
    except KeyError:
        pass
    else:
        raise AssertionError("KeyError should be raised")



# Generated at 2022-06-21 08:58:12.956865
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    raw_environ = {
        b'key1': b'value1',  # tests utf-8 handling
        b'key2': b'value2',  # tests surrogate_or_strict handling
        b'key3': to_bytes('value3', encoding='utf-16'),   # tests nonstring handling
    }
    text_environ = _TextEnviron(env=raw_environ)

    # Exercise
    value1 = text_environ[b'key1']
    value2 = text_environ['key2']
    value3 = text_environ['key3']

    # Verify
    assert value1 == 'value1'
    assert value2 == 'value2'
    assert value3 == 'value3'


# Generated at 2022-06-21 08:58:21.758748
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    expected_data = {
        'unicode_key': u'𝖕𝖊𝖔𝖓𝖘',
        'utf8_key': b'\xf0\x9d\x96\x95\x0a',
        'ascii_key': b'ansible\n',
    }

    # create a _TextEnviron instance
    text_environ = _TextEnviron()

    # set the items in the _TextEnviron instance
    for key, value in expected_data.items():
        text_environ[key] = value

    # check that __getitem__ returns a text string when the key is 'unicode_key'
    unicode_key = expected_data['unicode_key']

# Generated at 2022-06-21 08:58:35.526982
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    global environ

    from copy import deepcopy


# Generated at 2022-06-21 08:58:41.703843
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # PY2
    if not PY3:
        environ_bytes = b'FOO=BAR'
        os.environ = {environ_bytes: environ_bytes}
    # PY3
    else:
        os.environ = {'FOO': 'BAR'}
    new_environ = _TextEnviron()
    assert len(new_environ) == len(os.environ)

# Generated at 2022-06-21 08:58:45.498300
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # We are using a copy of os.environ so that this test won't change the test
    # suite environment.
    env = _TextEnviron(env=os.environ.copy())
    assert list(env) == list(env._raw_environ)

# Generated at 2022-06-21 08:58:51.497386
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_os_environ = {'key1': 'value1', 'key2': 'value2'}
    test_TextEnviron = _TextEnviron(test_os_environ, encoding='utf-8')
    del test_TextEnviron['key1']
    assert test_os_environ == {'key2': 'value2'}


# Generated at 2022-06-21 08:58:53.241429
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron()
    assert isinstance(env['SHELL'], (str, unicode))

# Generated at 2022-06-21 08:58:59.841440
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    os.environ['ANSIBLE_TEST_STR'] = 'some text'
    os.environ['ANSIBLE_TEST_BYTES'] = b'\xcf\x80'
    os.environ['ANSIBLE_TEST_BAD_BYTES'] = b'\xff\xaa'

    # Check we have the right type of object
    assert isinstance(os.environ['ANSIBLE_TEST_STR'], str)
    assert isinstance(os.environ['ANSIBLE_TEST_BYTES'], bytes)
    assert isinstance(os.environ['ANSIBLE_TEST_BAD_BYTES'], bytes)

    environ['ANSIBLE_TEST_STR'] = 'some text'

# Generated at 2022-06-21 08:59:04.607913
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """
    Test for when _TextEnviron.__iter__ is called
    """
    os.environ['TEST'] = 'testing'
    assert hasattr(environ, '__iter__')
    assert 'TEST' in environ
    os.environ.pop('TEST')



# Generated at 2022-06-21 08:59:08.353470
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    text_environment = _TextEnviron({'boo': 'bar'})
    text_environ_iter = iter(text_environment)
    assert text_environ_iter.next() == 'boo'



# Generated at 2022-06-21 08:59:14.167239
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test nonstring values
    environ['nonstring_int'] = 123
    assert environ['nonstring_int'] == 123
    environ.__setitem__('nonstring_int', 123)
    assert environ['nonstring_int'] == 123

    # Test string value that can be encoded/decoded exactly in utf-8
    environ['test_string'] = 'test'
    assert environ['test_string'] == 'test'
    environ.__setitem__('test_string', 'test')
    assert environ['test_string'] == 'test'

    # Test string that can be encoded/decoded exactly in raw_utf-8
    environ['raw_utf8_string'] = 'お\u00b7･'

# Generated at 2022-06-21 08:59:18.222774
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Initialize the environ variable
    environ['foo'] = 'bar'
    # Check the result of __setitem__
    assert environ['foo'] == 'bar'

if __name__ == '__main__':
    test__TextEnviron___setitem__()

# Generated at 2022-06-21 08:59:30.362448
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    '''
    Ensure that __delitem__ of class _TextEnviron behaves as expected
    '''
    if PY3:
        return
    with environ_vars({'ANSIBLE_ANSIBLE_TEST_KEY': 'x'}):
        del environ['ANSIBLE_ANSIBLE_TEST_KEY']
        assert 'ANSIBLE_ANSIBLE_TEST_KEY' not in environ
    with environ_vars({'ANSIBLE_ANSIBLE_TEST_KEY': 'y'}):
        environ.pop('ANSIBLE_ANSIBLE_TEST_KEY')
        assert 'ANSIBLE_ANSIBLE_TEST_KEY' not in environ
    with environ_vars({'ANSIBLE_ANSIBLE_TEST_KEY': 'z'}):
        environ.clear()

# Generated at 2022-06-21 08:59:38.456328
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Test SimpleIter
    if sys.version_info[:2] > (2, 7):
        import unittest.mock as mock
        env = _TextEnviron()
        with mock.patch('ansible.module_utils.common._collections_compat.SimpleIterator') as mock_SI:
            env.__iter__()
            mock_SI.assert_called_once_with(env._raw_environ)
    else:
        # SimpleIter is not implemented in py27, just make sure this doesn't crash
        env = _TextEnviron()
        env.__iter__()

# Generated at 2022-06-21 08:59:42.045180
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({'FOO': 'bar'})
    for var in env:
        assert var == 'FOO'
        break
    else:
        assert False, 'iteration did not return'


# Generated at 2022-06-21 08:59:50.364069
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    global environ
    environ['test_string'] = 'the quick brown fox'
    assert environ['test_string'] == 'the quick brown fox'
    environ['test_bytes'] = b'spam'
    assert environ['test_bytes'] == b'spam'
    environ['test_int'] = 123
    assert environ['test_int'] == b'123'
    environ['test_unicode'] = u'spam'
    assert environ['test_unicode'] == u'spam'


# Generated at 2022-06-21 08:59:56.198014
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    ansible_os_environ_changed = 'ANSIBLE_OS_ENVIRON_CHANGED'
    assert ansible_os_environ_changed not in environ
    environ[ansible_os_environ_changed] = 'True'
    assert environ[ansible_os_environ_changed] == 'True'
    del environ[ansible_os_environ_changed]
    print("Tests for method __setitem__ of class _TextEnviron passed.")



# Generated at 2022-06-21 08:59:59.022502
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron(encoding='utf-8')
    assert isinstance(env, dict)



# Generated at 2022-06-21 09:00:08.873204
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import os
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Test initializing with a non-utf-8 environment
    env = {b'utf8': b'\xc3\xa9', 'latin1': b'\xe9', 'native_str': '\xe9'}
    text_env = _TextEnviron(env)
    assert text_env.encoding == 'utf-8'
    assert isinstance(text_env, MutableMapping)
    assert set(text_env) == {'utf8', 'latin1', 'native_str'}
    assert set(text_env.values()) == {'é', 'é', 'é'}

# Generated at 2022-06-21 09:00:17.458408
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Initialize a dict with some values with bytes and text.
    # Then pass that dict to _TextEnviron
    test_dict = {
        'TEXT1': u'\u00FCnicode text',
        'BYTES1': b'\xC3\xBCnicode text',
        'TEXT2': u'Plain Ascii',
        to_bytes('BYTES2', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict'): b'Plain Ascii',
    }
    # By default, _TextEnviron uses sys.getfilesystemencoding() which is utf-8 in
    # Travis CI.  But ensure our test works in other environments as well
    utf8 = test_dict
    # Update the test dict to have utf-16 encoded keys
   

# Generated at 2022-06-21 09:00:23.798806
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import os
    from ansible.module_utils.six import PY2, PY3
    import ansible.module_utils.basic
    environ = _TextEnviron()

    def _compare_type(obj, typ):
        if not isinstance(obj, typ):
            print("unexpected type on attributes")
            print(obj)
            print(obj.__class__)
            print(type(obj))
            return False
        return True

    keys = set(environ.keys())
    assert not keys - set(os.environ.keys())
    assert not set(os.environ.keys()) - keys
    for key in keys:
        if PY2:
            if isinstance(os.environ[key], str):
                continue


# Generated at 2022-06-21 09:00:26.019977
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ["env_key"] = "env_value"
    environ.pop("env_key")
    assert "env_key" not in environ


# Generated at 2022-06-21 09:00:37.852346
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    try:
        # test deleting a key that exists
        # setup
        from ansible.module_utils.common._collections_compat import MutableMapping
        environ = _TextEnviron()
        key = "LANG"
        # test
        del environ[key]
        # verify
        assert key not in environ

    except Exception as e:
        raise AssertionError("method __delitem__ of class _TextEnviron threw exception " + str(e) + " with args: "  )


# Generated at 2022-06-21 09:00:49.207005
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Invalid encoding, surrogate_or_strict -> get surrogate values
    environ = _TextEnviron({b'BAD_VALUE': b'\xf0', b'GOOD_VALUE': b'b'}, encoding='macroman')
    assert environ.get(b'BAD_VALUE', 'default') == u'\udc00'
    assert environ.get(b'GOOD_VALUE', 'default') == 'b'

    # Invalid encoding, surrogateescape -> get surrogate values
    environ = _TextEnviron({b'BAD_VALUE': b'\xf0', b'GOOD_VALUE': b'b'}, encoding='macroman', errors='surrogateescape')
    assert environ.get(b'BAD_VALUE', 'default') == u'\udc00'

# Generated at 2022-06-21 09:00:51.300955
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_dict = _TextEnviron(dict(foo='bar', baz='quux'))
    del test_dict['foo']
    assert len(test_dict) == 1
    assert 'foo' not in test_dict
    assert 'bar' not in test_dict
    assert test_dict['baz'] == 'quux'


# Generated at 2022-06-21 09:00:55.457991
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Setup
    test_environ = _TextEnviron()
    original_value = test_environ['PATH']

    # Execute
    test_environ['PATH'] = 'new'
    test_environ['PATH'] = original_value

    # Verify
    assert test_environ['PATH'] == original_value

    # Execute
    del test_environ['PATH']

    # Verify
    assert 'PATH' not in test_environ


# Generated at 2022-06-21 09:00:58.785589
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron(env={b'foo': b'bar', b'baz': b'quux'}, encoding='ascii')

    assert len(env) == 2



# Generated at 2022-06-21 09:01:02.940939
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    test_dict = {'key1': 'value1', 'key2': 'value2'}
    test_environ = _TextEnviron(env=test_dict, encoding='utf-8')
    assert len(test_dict) == len(test_environ)


# Generated at 2022-06-21 09:01:09.873257
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Register the dummy environment before environ is created
    # and make sure the registered environment remains the same
    before = {b'abc': b'123', b'xyz': b'987'}
    os.environ = before
    environ
    assert os.environ == before

    # Test that we get the same values back
    assert environ[b'abc'] == b'123'
    assert environ[b'xyz'] == b'987'


# Generated at 2022-06-21 09:01:16.586821
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    raw = {"ANSIBLE_FOO": u"bər".encode('utf-8'), "ANSIBLE_BAR": 12345}
    ansible_environ = _TextEnviron(env=raw)
    assert ansible_environ == {'ANSIBLE_FOO': u'bər', 'ANSIBLE_BAR': u'12345'}
    ansible_environ = _TextEnviron(env=raw, encoding='latin-1')
    assert ansible_environ == {'ANSIBLE_FOO': u'b\xe6r', 'ANSIBLE_BAR': u'12345'}


# Generated at 2022-06-21 09:01:17.382948
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
   assert len(environ) >= 1


# Generated at 2022-06-21 09:01:26.697450
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test to make sure that we get back what we put in
    environ_test = _TextEnviron(env={})
    environ_test['foo'] = 'bar'
    assert environ_test['foo'] == 'bar'
    del environ_test['foo']
    try:
        environ_test['foo']
    except KeyError:
        assert True
    else:
        assert False, "KeyError not raised when expected"
        # Make sure that environ is an instance of MutableMapping
        assert isinstance(environ_test, MutableMapping)


if __name__ == '__main__':
    # Run the unit test for class _TextEnviron
    test__TextEnviron()

# Generated at 2022-06-21 09:01:33.548368
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-21 09:01:41.312939
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common.text.text_compat import to_bytes

    #
    # test one:
    #
    os.environ['TEST_ONE_KEY'] = 'key_one'
    os.environ['TEST_TWO_KEY'] = 'key_two'

    new_environ = _TextEnviron(env=os.environ)

    stderr = sys.stderr
    sys.stderr = StringIO()
    # loop through all the environment variables and check the content
    for k in new_environ:
        if k == 'TEST_ONE_KEY':
            assert os.environ[k] == to_bytes(new_environ[k])

# Generated at 2022-06-21 09:01:48.275147
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _raw_environ = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
        }
    env = _TextEnviron(env=_raw_environ)
    del env['key2']
    assert dict(env) == {
        'key1': 'value1',
        'key3': 'value3',
        }


# Generated at 2022-06-21 09:01:51.013400
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['test_key'] = 'hi'
    assert environ['test_key'] == 'hi'
    del environ['test_key']
    assert 'test_key' not in environ


# Generated at 2022-06-21 09:01:56.128004
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    my_env = _TextEnviron()
    my_env[u'привет'] = u'привет мир'
    assert my_env[u'привет'] == u'привет мир'

# Generated at 2022-06-21 09:02:06.175617
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Just checking the behavior of the environment when we're on Python 2.  We'll rely on the
    # unittests in six and the stdlib to verify that we're behaving as expected when on Python3
    _environ = _TextEnviron({b'KEY': b'value'}, encoding='ascii')
    assert _environ['KEY'] == u'value'
    _environ = _TextEnviron({b'KEY': u'value'}, encoding='ascii')
    assert _environ['KEY'] == u'value'
    _environ = _TextEnviron({b'KEY': b'value'}, encoding='utf-8')
    assert _environ['KEY'] == u'value'
    _environ = _TextEnviron({b'KEY': u'value'}, encoding='utf-8')

# Generated at 2022-06-21 09:02:13.958879
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import pytest
    # String should be returned as-is
    env = _TextEnviron()
    env['foo'] = 'bar'
    assert isinstance(env['foo'], str) and env['foo'] == 'bar'
    # Unicode string should be returned decoded as bytes
    env['baz'] = u'qux'
    assert isinstance(env['baz'], bytes) and env['baz'] == b'qux'
    # non-string should raise appropriate exception
    with pytest.raises(TypeError):
        env['baz'] = 1
    # If encoding is None, it should be set to sys.getfilesystemencoding()
    env = _TextEnviron(encoding=None)
    assert env.encoding == sys.getfilesystemencoding()
    # If encoding is a string, it should

# Generated at 2022-06-21 09:02:15.407189
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 09:02:17.711288
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    _TextEnviron()


# Generated at 2022-06-21 09:02:26.926596
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = {b'foo': b'bar'}

    # Test __init__ with no encoding
    t_env = _TextEnviron(env=env)
    assert t_env.encoding == sys.getfilesystemencoding()
    assert t_env[b'foo'] == u'bar'

    # Test __init__ with encoding of utf-8
    t_env = _TextEnviron(env=env, encoding='utf-8')
    assert t_env.encoding == 'utf-8'
    assert t_env[b'foo'] == u'bar'

    # Test __init__ with passed-in default from os.environ
    t_env = _TextEnviron()
    assert t_env.encoding == sys.getfilesystemencoding()

    # Test __init__ with passed-in default from os.

# Generated at 2022-06-21 09:02:46.035897
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import tempfile
    import unittest

    class Test__TextEnviron(unittest.TestCase):
        def setUp(self):
            environ.clear()

        def tearDown(self):
            environ.clear()

        def test_text_environ_constructor(self):
            self.assertEqual({}, environ)

        def test_text_environ_constructor_with_env(self):
            temp_environ = {'ANSIBLE_TEST': 'working-environ'}
            environ = _TextEnviron(env=temp_environ)
            self.assertEqual(temp_environ, environ)


# Generated at 2022-06-21 09:02:48.151977
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ) == list(environ._raw_environ.items())


# Generated at 2022-06-21 09:02:54.586894
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_text

    # Set up
    env = _TextEnviron()
    env["text"] = "text_value"
    env["bytes"] = b"bytes_value"
    env["unicode"] = u"unicode_value"

    assert env["text"] == to_text(b"text_value", encoding='utf-8', nonstring='passthru')
    assert env["bytes"] == to_text(b"bytes_value", encoding='utf-8', nonstring='passthru')
    assert env["unicode"] == to_text(b"unicode_value", encoding='utf-8', nonstring='passthru')

    env["bytes"] = b"\xf1\xf2\xf3\xf4"

# Generated at 2022-06-21 09:03:03.951282
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # No value passed in, should mimic os.environ on Python3
    env = _TextEnviron()
    print(to_text(type(env._raw_environ)), to_text(type(env._value_cache)), to_text(type(env)))

    # Pass in an empty dict, should mimic os.environ on Python3
    env = _TextEnviron({})
    print(to_text(type(env._raw_environ)), to_text(type(env._value_cache)), to_text(type(env)))

    # Pass in an empty dict with encoding, should mimic os.environ on Python3
    env = _TextEnviron({}, 'utf-8')
    print(to_text(type(env._raw_environ)), to_text(type(env._value_cache)), to_text(type(env)))

# Generated at 2022-06-21 09:03:08.873776
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    try:
        from test_runner import get_runner
    except ImportError as e:
        sys.exit("ERROR: The test_runner is required to run unit tests")
    TestRunner = get_runner('_TextEnviron')

    if not TestRunner:
        sys.exit("ERROR: Unable to load test runner")

    runner = TestRunner()
    runner.run(['_TextEnviron'])

# Generated at 2022-06-21 09:03:12.710342
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    try:
        os.environ['TEST'] = "test"

        environ['TEST'] = "test"

        assert 'TEST' in environ
    finally:
        del os.environ['TEST']



# Generated at 2022-06-21 09:03:21.804129
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # pylint: disable=attribute-defined-outside-init

    import mock
    import unittest

    class _TextEnvironTestCase(unittest.TestCase):
        def setUp(self):
            self.environ = _TextEnviron()

        def test_no_cache_passthru(self):
            self.environ._raw_environ = {'TEST': 'TEST'}
            self.assertEqual(b'TEST', self.environ['TEST'])

        def test_cache_on_unicode(self):
            self.environ._raw_environ = {'TEST': 'TEST'}
            self.assertEqual(u'TEST', self.environ['TEST'])

        def test_cache_on_encoded(self):
            self.environ

# Generated at 2022-06-21 09:03:29.601321
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Make sure the instance environ doesn't share a cache with os.environ
    try:
        assert environ._raw_environ is not os.environ
        assert environ._value_cache is not os.environ
    # On python3, os.environ is a mapping proxy so we can't directly compare them
    # Only run this test if we have access to the underlying dictionary
    except (AttributeError, TypeError):
        pass

    key = u'\u043e\u0434\u0438\u043d\u043d\u043e\u043a\u043b\u0430\u0441\u0441\u043d\u044b\u0439'
    environ[key] = u'English'
    if PY3:
        assert key in environ

# Generated at 2022-06-21 09:03:31.048766
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(_TextEnviron(encoding='utf-8')) == len(os.environ)


# Generated at 2022-06-21 09:03:36.319360
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Unit test for constructor of class _TextEnviron
    try:
        # We can't test the os.environ hook here because that's what Ansible is built against.
        # So we have to mock it
        os.environ = {b'TEST_BYTES': b'foo'}

        assert 'TEST_BYTES' in environ
        assert environ['TEST_BYTES'] == u'foo'
    finally:
        # Get rid of the hook
        del os.environ

# Generated at 2022-06-21 09:04:04.861212
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    environ.update({
        'TF_VAR_TEST_VARIABLE': 'test1',
        'TF_VAR_TEST_INVALID_VARIABLE': '\xed\xac\x83\xed\xb2\x80',
    })

    # Execute
    test1 = environ['TF_VAR_TEST_VARIABLE']
    test2 = environ['TF_VAR_TEST_INVALID_VARIABLE']

    # Verify
    assert type(test1) is str
    assert test1 == 'test1'
    assert type(test2) is str
    assert test2 == '\udcc3\udcb0'


# Generated at 2022-06-21 09:04:12.046859
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    test_env = {}
    test_env['TEST_ONE'] = 'ONE'
    test_env['TEST_TWO'] = 'TWO'
    test_env['TEST_TWO_B'] = 'TWO_B'
    test_env['TEST_THREE'] = 'THREE'

    text_environ = _TextEnviron(test_env)

    assert list(text_environ.__iter__()) == ['TEST_ONE', 'TEST_TWO', 'TEST_TWO_B', 'TEST_THREE']

# Generated at 2022-06-21 09:04:13.803569
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    obj = _TextEnviron()
    len_obj = len(obj)
    return len_obj


# Generated at 2022-06-21 09:04:15.490985
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Test __len__ method of _TextEnviron class

    Unit test for method __len__ of class _TextEnviron
    """
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 09:04:21.552308
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Test for method __delitem__(self, key, value)
    # of class _TextEnviron.
    from ansible.module_utils.six import b
    from ansible.module_utils.six.moves import UserDict

    dict = UserDict.UserDict()
    dict['foo'] = 'bar'

    env = _TextEnviron({'abc': '123', 'spam': 'eggs'}, None)
    env['foo'] = 'bar'
    del env['spam']
    env.copy()
    # Check that we're using the right environment to retrieve values
    assert env['abc'] == dict['abc'] == '123'
    assert env['spam'] == dict['spam'] == 'eggs'
    assert env['foo'] == dict['foo'] == 'bar'

# Generated at 2022-06-21 09:04:23.183127
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 09:04:34.024306
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = {'foo': b'this is foo', 'bar': b'this is bar'}
    te = _TextEnviron(env)
    assert te['foo'] == 'this is foo'
    assert te['bar'] == 'this is bar'

    sys.getfilesystemencoding = lambda: 'ascii'
    te = _TextEnviron(env)
    assert te['foo'] == 'this is foo'
    assert te['bar'] == 'this is bar'

    sys.getfilesystemencoding = lambda: 'utf-8'
    te = _TextEnviron(env, encoding='utf-8')
    assert te['foo'] == 'this is foo'
    assert te['bar'] == 'this is bar'


# Generated at 2022-06-21 09:04:37.156527
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # load data, i.e. the environment
    environ.update(os.environ)

    # test if __getitem__ works as expected
    for key, value in environ.items():
        assert environ[key] == value

# Generated at 2022-06-21 09:04:39.205518
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    '''
        Verify _TextEnviron class instance method __delitem__ for the following conditions:
            normal
            error no key
    '''
    pass


# Generated at 2022-06-21 09:04:42.738454
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['delete_me_test_value'] = 'delete_me_test_value'
    del environ['delete_me_test_value']
    assert 'delete_me_test_value' not in environ


# Generated at 2022-06-21 09:05:31.926272
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import copy
    import os
    def py_tests():
        if not PY3:
            return
        os_environ_backup = copy.deepcopy(os.environ)
        try:
            environ_backup = copy.deepcopy(environ)
            del environ['HOME']
            del os.environ['HOME']
            assert environ == os.environ
        finally:
            os.environ = os_environ_backup
            environ.clear()
            environ.update(environ_backup)

    def py2_tests():
        if PY3:
            return
        os_environ_backup = copy.deepcopy(os.environ)

# Generated at 2022-06-21 09:05:36.094223
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    value = '{"value": [{"id": "one"}]}'
    key = 'ANSIBLE_INVALID_INPUT'
    environ[key] = value
    assert isinstance(environ[key], str), \
        "_TextEnviron.__setitem__(): failed type check!"
    assert environ[key] == value, \
        "_TextEnviron.__setitem__(): failed str check!"

# Generated at 2022-06-21 09:05:40.746486
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    # create OS environment
    os.environ['TEST_KEY'] = 'TEST_VALUE'

    # test case
    del environ['TEST_KEY']
    assert 'TEST_KEY' not in environ
    assert os.environ['TEST_KEY'] != 'TEST_VALUE'


# Generated at 2022-06-21 09:05:49.738405
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test default behavior
    environ_kv_pair = environ.__getitem__('PWD')
    assert environ_kv_pair == '/home/vagrant', \
        'test__TextEnviron___getitem__(): FAILED to get environ value with default encoding!'

    # Test special behavior when key value is not a text string
    # __NonExistentEnvKey__ should not exist in os.environ
    try:
        environ_kv_pair = environ.__getitem__('__NonExistentEnvKey__')
    except KeyError:
        print(sys.exc_info())
        assert KeyError, \
            'test__TextEnviron___getitem__(): FAILED to handle missing environment variable!'


# Generated at 2022-06-21 09:05:56.234175
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    str_env = dict(FOO='bar', BAZ='quux')
    b_env = dict(FOO=b'bar', BAZ=b'quux')

    assert len(environ) == 0
    environ.pop('FOO', None)
    environ.pop('BAZ', None)
    assert len(environ) == 0

    environ.update(str_env)
    assert len(environ) == 2
    assert len(environ._raw_environ) == 2
    assert environ.pop('FOO') == 'bar'
    assert len(environ) == 1
    assert len(environ._raw_environ) == 1
    assert environ.pop('BAZ') == 'quux'
    assert len(environ) == 0