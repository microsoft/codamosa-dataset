

# Generated at 2022-06-21 08:56:00.943569
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Initialize a _TextEnviron object and ensure it has a length
    my_env = _TextEnviron()
    assert(len(my_env) > 0)


# Generated at 2022-06-21 08:56:09.923296
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Test _TextEnviron.__setitem__()
    """
    # Test that it can store bytes
    environ['somebytes'] = b'foo'
    assert os.environ['somebytes'] == b'foo'
    assert environ['somebytes'] == u'foo'
    del os.environ['somebytes']

    # Test that it can store bytes that are not decodable
    environ['somedecodeerror'] = b'\xb3'
    assert os.environ['somedecodeerror'] == b'\xb3'
    assert environ['somedecodeerror'] == u'\xb3'
    del os.environ['somedecodeerror']

    # Test that it can store text
    environ['sometext'] = u'foo'

# Generated at 2022-06-21 08:56:11.555430
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ.__iter__()) == list(environ.keys())

# Generated at 2022-06-21 08:56:24.126716
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # This uses the environment variables set by the test so that we don't pollute the environment
    # with test values

    # The orig value is a unicode string that is not valid utf-8
    os.environ['ANSIBLE_TEST_ORIG_VAL'] = u'Orig\uffff Value'

    # The new value is a utf-8 byte string
    os.environ['ANSIBLE_TEST_NEW_VAL'] = 'New Value'

    # Make sure that the bytes in the raw environ are what we expect
    orig_val = os.environ['ANSIBLE_TEST_ORIG_VAL']
    if PY3:
        assert to_bytes(os.environ['ANSIBLE_TEST_ORIG_VAL'], errors='surrogate_or_strict') == \
            orig_val.encode

# Generated at 2022-06-21 08:56:26.612361
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron()
    environ[b'foo'] = b'bar'

    if PY3:
        assert environ[b'foo'] == b'bar'
    else:
        assert environ[b'foo'] == u'bar'


# Generated at 2022-06-21 08:56:33.003060
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text

    t = _TextEnviron()
    t["TEST"] = to_text("TEST", encoding='utf-8', errors='surrogate_or_strict')
    assert os.environ["TEST"] == to_bytes("TEST", encoding='utf-8', errors='surrogate_or_strict')


# Generated at 2022-06-21 08:56:35.042431
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ) == list(environ._raw_environ)


# Generated at 2022-06-21 08:56:40.013429
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    t = environ
    assert 'TEST_VAR' not in t
    t['TEST_VAR'] = 'testing'
    assert 'TEST_VAR' in t
    del t['TEST_VAR']
    assert 'TEST_VAR' not in t



# Generated at 2022-06-21 08:56:44.156203
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    raw_environ = {to_bytes('foo'): to_bytes('bar'), to_bytes('世界'): to_bytes('wård')}
    environ = _TextEnviron(env=raw_environ)
    assert environ['foo'] == u'bar'
    assert environ['世界'] == u'wård'


if __name__ == '__main__':
    test__TextEnviron()

# Generated at 2022-06-21 08:56:53.699209
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    class _FakeEnviron(dict):
        pass
    env = _FakeEnviron({'A': 'a', 'C': 'c', 'B': 'b'})
    testenv = _TextEnviron(env)

    # test simple key
    del(testenv['A'])
    assert testenv == _TextEnviron({'B': 'b', 'C': 'c'})

    del(testenv['B'])
    assert testenv == _TextEnviron({'C': 'c'})

    del(testenv['C'])
    assert testenv == _TextEnviron({})


# Generated at 2022-06-21 08:56:58.520674
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['test_key'] = 'test_value'
    del environ['test_key']
    assert 'test_key' not in environ.keys()


# Generated at 2022-06-21 08:57:05.448889
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Method __setitem__ must convert value to byte-string
    """
    obj = _TextEnviron()
    obj['JENKINS_URL'] = 'https://ci.example.org/'
    assert 'https://ci.example.org/' == os.environ['JENKINS_URL'], "test__TextEnviron___setitem__"
    assert 'https://ci.example.org/' == obj['JENKINS_URL'], "test__TextEnviron___setitem__"
    del obj['JENKINS_URL']

# Generated at 2022-06-21 08:57:12.730047
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = ['TEST_ONE=foo', 'TEST_TWO=bar']
    test_env = _TextEnviron(env)
    assert test_env['TEST_ONE'] == b'foo'
    test_env['TEST_ONE'] = u'test one'
    assert test_env['TEST_ONE'] == u'test one'
    assert test_env._raw_environ['TEST_ONE'] == u'test one'
    del test_env['TEST_ONE']
    assert 'TEST_ONE' not in test_env
    assert 'TEST_ONE' not in test_env._raw_environ


# Generated at 2022-06-21 08:57:13.686496
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) > 0


# Generated at 2022-06-21 08:57:20.325262
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    encoding = sys.getfilesystemencoding()
    if PY3:
        assert environ['PATH'] == os.environ['PATH'], '__getitem__ fails test when encoding is {}'.format(encoding)
    else:
        assert environ['PATH'] == os.environ['PATH'].decode(encoding), '__getitem__ fails test when encoding is {}'.format(encoding)

# Generated at 2022-06-21 08:57:30.375308
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    env['test1'] = 'hello world'
    env['test2'] = '你好，世界'
    env['test3'] = u'hello world'
    env['test4'] = u'你好，世界'
    assert env['test1'] == u'hello world'
    assert env['test2'] == u'你好，世界'
    assert env['test3'] == u'hello world'
    assert env['test4'] == u'你好，世界'

if __name__ == '__main__':
    test__TextEnviron___setitem__()

# Generated at 2022-06-21 08:57:33.010873
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron(env={'foo': b'bar'}, encoding='utf-8')
    env.__iter__() is not env._raw_environ.__iter__()


# Generated at 2022-06-21 08:57:37.770137
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environment_var = 'SOME_TEST_ENVIRONMENT_VARIABLE'
    try:
        del environ[environment_var]
    except KeyError:
        pass
    environ[environment_var] = 'some test value'
    assert environment_var in environ
    del environ[environment_var]
    assert environment_var not in environ


# Generated at 2022-06-21 08:57:46.644404
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Verify that we're setting things correctly
    """

    # Test 1: Normal ascii string
    environ['test'] = u'abcd'
    assert(u'abcd' == environ['test'])
    assert(u'abcd' == os.environ['test'])

    # Test 2: Unicode string with a non-ascii character
    environ['test'] = u'déf'
    assert(u'déf' == environ['test'])
    assert(u'déf' == os.environ['test'])

# Generated at 2022-06-21 08:57:51.023809
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    dict = {'key': 'value'}
    t = _TextEnviron({'key': 'value'}, encoding='utf-8')
    t.__delitem__('key')

    assert t.__getitem__('key') == dict['key']


# Generated at 2022-06-21 08:58:00.863536
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_text, to_bytes
    import sys

    test_environ = {}
    test_environ_key_value = [
        (to_bytes('abc', encoding='utf-8'), to_bytes('만능', encoding='utf-8')),
        (to_bytes('안수찬', encoding='utf-8'), to_bytes('장준수', encoding='utf-8')),
        (to_bytes('TB_Token_1234', encoding='utf-8'), to_bytes('1234-4321', encoding='utf-8')),
        (to_bytes('', encoding='utf-8'), to_bytes('abc', encoding='utf-8')),
    ]

    # Put test data into environment variable

# Generated at 2022-06-21 08:58:07.606142
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    old_env = environ.copy()
    key = 'KEY'
    try:
        del environ[key]
        assert key not in environ
    except:
        # Clean up in case of an exception
        environ.clear()
        environ.update(old_env)
        raise
    environ.clear()
    environ.update(old_env)


# Generated at 2022-06-21 08:58:11.143356
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Method '__iter__' of class '_TextEnviron' should return an iterator over the keys in the
    # environment
    assert list(environ.__iter__()) == list(os.environ.__iter__())


# Generated at 2022-06-21 08:58:20.795993
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils._text import to_bytes, to_native

    # Test non-string types
    for nonstring in (1, 2.3, {'a': 'b'}):
        environ.__setitem__('base_key', nonstring)
        assert 'base_key' in environ
        assert environ['base_key'] == to_bytes(nonstring)

    # Test bytes are not decoded
    try:
        environ.__setitem__('base_key', b'bytes')
    except TypeError:
        pass
    else:
        raise AssertionError(to_native('Setting an value of type `bytes` should throw a TypeError '
                                       'exception'))
    assert environ['base_key'] == b'bytes'

    # Test to_bytes raises an exception with non

# Generated at 2022-06-21 08:58:32.395687
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test basic creation with default constructor
    assert isinstance(environ, MutableMapping)
    assert 'LC_ALL' in environ
    assert environ['LC_ALL'] == 'C'

    # Test setting an environment value
    environ['FOO'] = 'bar'
    assert 'FOO' in environ
    assert environ['FOO'] == 'bar'

    # Make sure keys are cached with the original byte strings
    byte_value = to_bytes(environ['FOO'], encoding='utf-8')
    environ['FOO'] = 'baz'
    assert environ['FOO'] == 'baz'
    assert 'bar' in environ.keys()
    assert 'bar' in environ.values()
    assert 'bar' in environ.items()

    # Make sure setting a value to None

# Generated at 2022-06-21 08:58:39.592860
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import os

    test_env = {'test1': 'test data', 'test2': 'test data'}
    assert len(os.environ) == len(_TextEnviron(test_env))

    test_env = {'test1': 'test data'}
    assert len(os.environ) == len(_TextEnviron(test_env))

    test_env = {}
    assert len(os.environ) == len(_TextEnviron(test_env))



# Generated at 2022-06-21 08:58:46.716365
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    class MockEnviron(dict):
        def __setitem__(self, key, value):
            return super(MockEnviron, self).__setitem__(key, value)

    mock_environ = MockEnviron()
    text_environ = _TextEnviron(env=mock_environ)
    text_environ['ansible_test'] = 'bob'
    assert mock_environ['ansible_test'] == b'bob'


# Generated at 2022-06-21 08:58:56.729882
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import unittest
    from unittest import TestCase, mock
    from io import StringIO

    class TextEnvironTestCase(TestCase):
        def setUp(self):
            self._environ = _TextEnviron()

        def tearDown(self):
            pass

        @mock.patch('sys.stdout', new_callable=StringIO)
        @mock.patch('traceback.print_exception')
        def test__TextEnviron___setitem__(self, mock_traceback, mock_stdout):
            # Test with an invalid encoding
            self._environ.encoding = to_bytes('invalid encoding')
            self._environ['a'] = u'sécurité'
            self.assertIn(u'sécurité', self._environ.items())

# Generated at 2022-06-21 08:59:02.452391
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron()
    if not isinstance(env.__iter__(), types.GeneratorType):
        raise Exception("Unexpected return type of object '{}' returned by method {} of class _TextEnviron".format(type(env.__iter__()), '__iter__'))



# Generated at 2022-06-21 08:59:11.148425
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    env['key1'] = 'jose'
    env['key2'] = 'maria'
    env['key3'] = 'carlos'
    del env['key1']
    assert len(env) == 2
    assert env['key2'] == 'maria'
    assert env['key3'] == 'carlos'
    del env['key2']
    assert len(env) == 1
    assert env['key3'] == 'carlos'
    del env['key3']
    assert len(env) == 0


# Generated at 2022-06-21 08:59:23.797956
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils._text import to_text
    unicode_env = {u'incoming': b'\xe4\xe4'}
    environ_1 = _TextEnviron(env=unicode_env)
    assert environ_1[u'incoming'] == to_text(b'\xe4\xe4', encoding='utf-8', nonstring='passthru',
                                             errors='surrogate_or_strict')
    assert repr(unicode_env) == repr(environ_1._raw_environ)
    environ_2 = _TextEnviron(env={u'incoming': b'\xe4\xe4'})

# Generated at 2022-06-21 08:59:27.900089
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron(encoding='utf-8')

    try:
        env['FOO'] = 'bar'
    except TypeError:
        assert False

    try:
        env[b'FOO'] = b'bar'
    except TypeError:
        assert False



# Generated at 2022-06-21 08:59:29.703461
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron(encoding='utf-8')
    assert len(environ) > 0


# Generated at 2022-06-21 08:59:31.070863
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 08:59:34.586522
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ.clear()
    environ.update({'STRING': 'hello world'})

    assert environ['STRING'] == 'hello world'
    del environ['STRING']
    assert 'STRING' not in environ


# Generated at 2022-06-21 08:59:45.971677
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    # Test with non-string values
    env['key1'] = 1
    assert env['key1'] == '1'
    env['key2'] = None
    assert env['key2'] == ''
    env['key3'] = True
    assert env['key3'] == 'True'
    # Test with ascii-only bytes
    env['key4'] = 'abc'
    assert env['key4'] == 'abc'
    env['key5'] = bytes(b'abc')
    assert env['key5'] == 'abc'
    # Test with unicode
    env['key6'] = u'abc'
    assert env['key6'] == 'abc'
    env['key7'] = u'\u0080'
    assert env['key7'] == '\x80'


# Generated at 2022-06-21 08:59:49.289804
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Unit test for method __getitem__ of class _TextEnviron"""

    environ["FOO"] = "bar"
    assert environ["FOO"] == u"bar"

# Generated at 2022-06-21 08:59:53.977757
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    global environ
    environ = _TextEnviron(env={"foo": "bar"}, encoding='utf-8')
    del environ["foo"]
    assert len(environ) == 0


# Generated at 2022-06-21 08:59:58.244289
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():

    # Create the test object
    _test_obj = _TextEnviron({'test1': 'value1', 'test2': 'value2'}, encoding='utf-8')

    # Test case - iterate object
    for key in _test_obj:
        assert key in ['test1','test2']


# Generated at 2022-06-21 09:00:08.796321
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'ASDF': b'FA'})
    if PY3:
        assert env[b'ASDF'] == b'FA'
    else:
        assert env[b'ASDF'] == u'FA'
        # Cache keys off of the undecoded values to handle any environment variables which change
        # during a run
        assert env[b'ASDF'] == u'FA'
        env[b'ASDF'] = b'FE'
        assert env[b'ASDF'] == u'FE'
        env[b'ASDF'] = 'FÉ'
        assert env[b'ASDF'] == u'FÉ'
        env[b'ASDF'] = 'FĔ'
        assert env[b'ASDF'] == u'FĔ'
        env[b'ASDF']

# Generated at 2022-06-21 09:00:18.629000
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Make sure that the default encoding is set from the system
    assert environ.encoding == sys.getfilesystemencoding()

    env = _TextEnviron(encoding='ascii')
    assert env.encoding == 'ascii'

    # Should be able to initialise with a dict
    raw_environ = {'a': 'b', 'c': 'd'}
    env = _TextEnviron(env=raw_environ)
    assert env._raw_environ == raw_environ
    assert env._value_cache == {}
    assert env.encoding == sys.getfilesystemencoding()

    # Should be able to initialise with the static environ
    env = _TextEnviron()
    assert env._raw_environ is os.environ
    assert env._value_cache == {}
    assert env

# Generated at 2022-06-21 09:00:21.866771
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron()
    env['TEST'] = 'test'
    assert 'TEST' in env
    del env['TEST']
    assert 'TEST' not in env
    return True


# Generated at 2022-06-21 09:00:29.181193
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import unittest
    from unittest.mock import patch

    class TestEnviron(unittest.TestCase):
        @patch.dict(os.environ, {'ANSIBLE_TEST_VAL': 'test'})
        def test__iter__test_env(self):
            text_env = _TextEnviron()
            self.assertEqual(text_env['ANSIBLE_TEST_VAL'], 'test')
            self.assertIn('ANSIBLE_TEST_VAL', list(text_env.keys()))

    suite = unittest.TestLoader().loadTestsFromTestCase(TestEnviron)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 09:00:31.913123
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    text_environ = _TextEnviron({'a': 1, 'b': 2})
    assert ['a', 'b'] == list(text_environ.__iter__())

# Generated at 2022-06-21 09:00:36.040742
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Test _TextEnviron.__delitem__
    """
    # Test deletion
    environ['test'] = 'test'
    assert 'test' in environ
    del environ['test']
    assert 'test' not in environ



# Generated at 2022-06-21 09:00:39.467212
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ_tmp = environ._TextEnviron()
    environ_tmp['ANSIBLE_CALLBACKS'] = 'c1,c2'
    environ_tmp['ANSIBLE_CALLBACK_PLUGINS'] = '/tmp'
    assert environ_tmp['ANSIBLE_CALLBACKS'] == 'c1,c2'
    assert environ_tmp['ANSIBLE_CALLBACK_PLUGINS'] == '/tmp'
    del environ_tmp['ANSIBLE_CALLBACKS']
    assert len(environ_tmp) == 1


# Generated at 2022-06-21 09:00:42.144863
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['test'] = 'test'
    assert 'test' in environ
    del environ['test']
    assert 'test' not in environ


# Generated at 2022-06-21 09:00:46.997151
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import pytest
    import os
    os.environ["TEST1"] = "value1"
    os.environ["TEST2"] = "value2"
    assert len(environ) == 2
    os.environ.clear()


# Generated at 2022-06-21 09:00:55.235318
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = dict(an_ascii_only_string='foobar',
               a_unicode_string=u'foo\u00e9')
    e = _TextEnviron(env)

    assert len(e) == len(env)
    assert 'an_ascii_only_string' in e
    assert 'a_unicode_string' in e
    assert 'baz' not in e

    assert u'foobar' == e['an_ascii_only_string']
    assert u'foo\u00e9' == e['a_unicode_string']

    assert e == env
    assert e != {}
    assert e != {'an_ascii_only_string': 'foobar'}
    assert e != {'an_ascii_only_string': u'foobar'}


# Generated at 2022-06-21 09:01:01.757994
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test with non string values
    textenviron = _TextEnviron(encoding='utf-8')
    textenviron['key'] = 10
    assert textenviron['key'] == '10'
    # Test with regular string
    textenviron['key'] = 'hello'
    assert textenviron['key'] == 'hello'
    # Test with unicode string
    textenviron['key'] = u'Hello'
    assert textenviron['key'] == u'Hello'


# Generated at 2022-06-21 09:01:13.653224
# Unit test for constructor of class _TextEnviron

# Generated at 2022-06-21 09:01:19.820933
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Get the class which we are testing
    from ansible.module_utils.common._collections_compat import _TextEnviron
    # The class should be tested with the context of a class.  This allows us
    # to test local members
    class __test__TextEnviron__:
        def __init__(self):
            self.encoding = 'utf-8'
            self._raw_environ = {}
            self._value_cache = {}
            self.environ = _TextEnviron(env=self._raw_environ, encoding=self.encoding)

        def test_passthru(self):
            self.environ['value'] = 6
            assert type(self.environ.__getitem__('value')) is int

        def test_strict(self):
            import six


# Generated at 2022-06-21 09:01:24.111473
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron(encoding='utf-8')
    assert isinstance(environ._raw_environ, dict)
    assert isinstance(environ._value_cache, dict)
    assert len(environ) == len(environ._raw_environ)


# Generated at 2022-06-21 09:01:35.692326
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test to ensure that we don't modify the behavior of os.environ when using the default
    # path to os.environ
    assert environ._raw_environ == os.environ
    # Test that we get a text value and that it is decoded
    assert isinstance(environ['PATH'], str)
    assert environ['PATH'] != os.environ['PATH']

    test_values = {to_bytes('test_val', errors='surrogate_or_strict'): 'ümlaut',
                   to_bytes('another_key', errors='surrogate_or_strict'): '🤠'}

    # Test that all of the test values in test_values are of type str
    env = environ.__class__(test_values, encoding='utf-8')

# Generated at 2022-06-21 09:01:38.228469
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    test_env = _TextEnviron({'a':'1', 'b':'2', 'c':'3'}, encoding=None)
    assert len(test_env) == 3

