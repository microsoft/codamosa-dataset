

# Generated at 2022-06-21 08:56:01.310526
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    for key in environ:
        # Any key will do for this test
        assert isinstance(key, str)
        break


# Generated at 2022-06-21 08:56:10.775558
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils.six import PY3
    # Create a normal dict with some encoded strings
    raw_environ = {"key1": b"value1",
                   "key2": b"value2",
                   "key3": b"value3"}
    test_environ = _TextEnviron(env=raw_environ, encoding='utf-8')
    try:
        test_environ['key4'] = raw_environ['key1']
    except TypeError:
        assert PY3
    else:
        assert not PY3
    try:
        test_environ['key5'] = raw_environ['key2']
    except TypeError:
        assert PY3
    else:
        assert not PY3

# Generated at 2022-06-21 08:56:20.929854
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron()
    assert env.encoding == 'utf-8'
    assert env._raw_environ is os.environ
    assert env._value_cache == {}
    #
    # Test for unicode by setting env variable, then getting it and comparing the type of the
    # result to what we'd get from os.environ
    #
    key = 'myunicode'
    value = 'あいうえお'
    os.environ[key] = value
    try:
        env = _TextEnviron()
        assert type(os.environ[key]) != type(env[key])
    finally:
        del os.environ[key]



# Generated at 2022-06-21 08:56:24.291590
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        environ['PYTHONPATH'] = 'test'
        assert environ['PYTHONPATH'] == 'test'
    finally:
        del environ['PYTHONPATH']

# Generated at 2022-06-21 08:56:30.964526
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, MutableMapping), 'environ is not a Mapping'
    assert environ._value_cache == {}, "environ._value_cache is not empty"
    assert environ._raw_environ == os.environ, "environ._raw_environ is not the system's os.environ"
    assert environ.encoding == 'utf-8', "environ.encoding is not utf-8"



# Generated at 2022-06-21 08:56:41.741293
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-21 08:56:45.366895
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron()
    for env_rec in environ:
        assert isinstance(env_rec, str), "`environ` must return strings"


# Generated at 2022-06-21 08:56:55.359084
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    class MockEnvironment(object):
        def __init__(self):
            self.env = {}

        def __len__(self):
            return len(self.env)

        def __delitem__(self, key):
            del self.env[key]

        def __getitem__(self, key):
            return self.env[key]

        def __setitem__(self, key, value):
            self.env[key] = value

        def __iter__(self):
            return self.env.__iter__()

    global environ
    environ = _TextEnviron(env=MockEnvironment())
    assert environ.__len__() == 0
    environ['TEST'] = 'a'
    assert environ.__len__() == 1


# Generated at 2022-06-21 08:57:02.315144
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # This is a fake test.  We need to have at least one test in order for the tests to run and
    # for coverage to be generated.  This test actually is run and it tests the environment
    # variable LC_ALL.  If this test fails, then something is wrong with the system.
    # In the future, this test will be moved to a system_test and will be replaced with a real
    # test.
    assert 'en_US.UTF-8' in environ

# Generated at 2022-06-21 08:57:09.155864
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    envvar = dict(LANG='C', ANSIBLE_FORCE_COLOR='true')
    env = _TextEnviron(envvar)
    assert env['LANG'] == 'C'
    assert isinstance(env['ANSIBLE_FORCE_COLOR'], str)
    # Make sure we don't create a class with a really wide API

# Generated at 2022-06-21 08:57:22.203044
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class FakeEnviron(object):
        def __getitem__(self, key):
            return value
        def __setitem__(self, key, value):
            pass
        def __delitem__(self, key):
            pass
        def __iter__(self):
            return self
        def next(self):
            return None
        def __len__(self):
            return 1

    env = FakeEnviron()
    # non-string key should raise TypeError
    try:
        env[0]
    except TypeError:
        pass
    else:
        assert False, 'non-string key should raise TypeError.'

    # non-bytes value should be converted to utf-8
    env['key'] = 'value'
    assert env['key'] == 'value'

    # bytes value should be converted to unicode
   

# Generated at 2022-06-21 08:57:23.823875
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 08:57:28.162894
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ._raw_environ['test'] = 'test'
    assert environ['test'] == 'test'

    environ._raw_environ['test'] = b'foobar'
    assert environ['test'] == 'foobar'



# Generated at 2022-06-21 08:57:31.284386
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import os
    os.environ['TEST_KEY'] = 'a test value'
    assert 'TEST_KEY' in environ
    os.environ.pop('TEST_KEY')

# Generated at 2022-06-21 08:57:32.552489
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-21 08:57:34.648909
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron(env=dict(a=1, b=2, c=3))
    assert set(env) == set(('a', 'b', 'c'))

# Generated at 2022-06-21 08:57:41.613366
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Unit test for method __delitem__ of class _TextEnviron
    """
    if hasattr(os, 'environb'):
        # Python2
        raw_environ = os.environb
    else:
        # Python3 - os.environ is type bytes
        raw_environ = os.environ
    te = _TextEnviron(raw_environ)
    te.__delitem__('LANG')
    assert 'LANG' not in os.environ


# Generated at 2022-06-21 08:57:43.663208
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert environ.__len__() == os.environ.__len__()



# Generated at 2022-06-21 08:57:54.385195
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # we must use a fake environment for tests
    fake_env = {}
    environ_test = _TextEnviron(env=fake_env)

    # ascii characters should be unencoded
    environ_test['test'] = 'test'
    assert fake_env['test'] == b'test'

    # non ascii characters should be encoded
    environ_test['test'] = 'tést'
    assert fake_env['test'] == b't\xc3\xa9st'

    # invalid characters should cause a ValueError
    try:
        environ_test['test'] = 'tést\xff'
        assert False, 'invalid characters should raise ValueError'
    except ValueError:
        pass



# Generated at 2022-06-21 08:58:00.447024
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test for passing non-string value
    environ.clear()
    try:
        environ['ANSIBLE_TEST_FOR_NON_STRING'] = 123
    except TypeError:
        pass
    else:
        assert False, "non-string value passed"

    # Test for passing non-unicode string
    environ.clear()
    try:
        environ['ANSIBLE_TEST_FOR_NON_STRING'] = b'abc'
    except UnicodeError:
        pass
    else:
        assert False, "non-unicode string passed"


# Generated at 2022-06-21 08:58:08.170436
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # initialize
    d = os.environ.copy()
    del d["PATH"]
    d_key = d.keys()
    k = _TextEnviron(d)

    # call method
    del k["PATH"]

    # assert result
    assert d_key == k.keys()


# Generated at 2022-06-21 08:58:18.644494
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test on python3
    # Test that the decoding of str/unicode on python3 works properly
    environ_py3_str = _TextEnviron({'var1': b'\x80\x81\x82', 'var2': 'ascii'}, encoding='utf-8')
    # Test that surrogate_or_strict replaces bad characters properly
    assert environ_py3_str['var1'] is u'\ufffd\ufffd\ufffd'
    # Test that str coming in to the environment is not modified
    assert environ_py3_str['var2'] == 'ascii'

    # Test on python2
    # Test that the decoding of bytes/str on python2 works properly

# Generated at 2022-06-21 08:58:23.536521
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    te = _TextEnviron()
    te['foo'] = 'bar'
    assert 'foo' in te
    assert 'foo' in iter(te)

# Generated at 2022-06-21 08:58:25.540352
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ = _TextEnviron({'unicode': '\u0430\u0446\u0430'})
    del environ['unicode']
    assert 'unicode' not in environ


# Generated at 2022-06-21 08:58:35.523498
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron()
    assert(isinstance(environ, MutableMapping))
    assert(isinstance(environ.get(b'PATH', b'path'), six.text_type))
    assert(isinstance(environ.get('PATH', 'path'), six.text_type))
    assert(isinstance(environ.items(), list))
    assert(isinstance(environ.keys(), list))
    assert(isinstance(environ.values(), list))
    assert(environ.get(b'PATH', b'path') == environ.get('PATH', 'path'))
    assert(environ[b"PATH"] == environ["PATH"])


# Generated at 2022-06-21 08:58:40.692222
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Make sure that the class works if no parameters are passed.
    # There was a bug where the initializer was confused between the parameters to init and the
    # parameters to mutable mapping.
    a = _TextEnviron()
    a['foo'] = 'bar'
    assert a['foo'] == 'bar'
    del a['foo']

# Generated at 2022-06-21 08:58:42.340678
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 08:58:47.582123
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_env = _TextEnviron()
    test_env['ANSIBLE_MODULE_UNIT_TEST'] = 'REMOVE_ME'
    del test_env['ANSIBLE_MODULE_UNIT_TEST']
    assert 'ANSIBLE_MODULE_UNIT_TEST' not in test_env


# Generated at 2022-06-21 08:58:57.235599
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Function to test method __delitem__ of class _TextEnviron
    """
    try:
        environ__getitem__ = os.environ['PATH']
    except KeyError:
        environ__getitem__ = None
    environ__delitem__ = environ.__delitem__('PATH')
    print(environ__getitem__)
    print(environ__delitem__)
    
    if 'PATH' in os.environ:
        assert os.environ['PATH'] == environ__getitem__
    else:
        assert os.environ != environ__getitem__
    
    if environ.__delitem__ is None:
        assert os.environ['PATH'] != environ__delitem__
    else:
        assert os.environ['PATH'] == environ__delitem

# Generated at 2022-06-21 08:59:00.264248
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    assert isinstance(environ, _TextEnviron)
    assert isinstance(environ._raw_environ, dict)

# Generated at 2022-06-21 08:59:05.980480
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Test the length of the environment
    assert len(_TextEnviron()) == len(os.environ)
    assert len(_TextEnviron({'A': '1', 'B': '2'})) == 2



# Generated at 2022-06-21 08:59:09.697932
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global environ
    environ = _TextEnviron(encoding='ascii')
    env = {b'foo': b'bar'}
    environ._raw_environ = env
    assert environ['foo'] == 'bar'



# Generated at 2022-06-21 08:59:11.061098
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 08:59:18.723428
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():

    test_environ = {}
    _test_environ = _TextEnviron(test_environ)

    assert len(test_environ) == 0

    _test_environ["foo"] = "bar"
    assert len(test_environ) == 1
    assert test_environ["foo"] == b"bar"

    _test_environ["bar"] = "foo"
    assert len(test_environ) == 2
    assert test_environ["bar"] == b"foo"



# Generated at 2022-06-21 08:59:23.936675
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ_ = _TextEnviron({'C': 'C', 'B': 'B', 'A': 'A'})
    result = environ_.__iter__()

    keys = iter(result)
    assert keys.next() == 'C'
    assert keys.next() == 'B'
    assert keys.next() == 'A'


# Generated at 2022-06-21 08:59:29.305679
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''Test _TextEnviron.__getitem__()'''
    # Check that an existing and valid key returns the expected text
    assert 'test_value' == environ['test_key']

    # Check that an existing and invalidly encoded key returns the expected text
    assert 'test_value' == environ['test_invalid_key']

    import pytest
    with pytest.raises(KeyError):
        # Check that a missing key raises KeyError
        environ['not_a_key']

if __name__ == '__main__':
    test__TextEnviron___getitem__()

# Generated at 2022-06-21 08:59:31.456714
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({'QUX': 'baz', 'ZOO': 'moo'})
    del env['ZOO']
    del env['QUX']
    assert 0 == len(env)

# Generated at 2022-06-21 08:59:34.585548
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['test'] = 'test1'
    assert environ['test'] == 'test1'
    del environ['test']
    assert 'test' not in environ


# Generated at 2022-06-21 08:59:41.620589
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # check a unicode string
    environ["test_key"] = u"İstanbul"
    assert environ["test_key"] == u"İstanbul"

    # check a byte string
    environ["test_key"] = b"\xc4\xb0stanbul"
    assert environ["test_key"] == u"İstanbul"

    # check a nonstring item
    environ["test_key"] = 1
    assert environ["test_key"] == u"1"

# Generated at 2022-06-21 08:59:46.268505
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import copy
    original_env = copy.deepcopy(os.environ)
    del os.environ['LANG']
    assert 'LANG' not in os.environ
    assert 'LANG' not in _TextEnviron()
    os.environ = original_env


# Generated at 2022-06-21 08:59:57.890020
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = {'key1': u'test', 'key2': 'test1', b'key3': b'test2'}
    from copy import deepcopy
    envcopy = deepcopy(env)
    # Test __init__
    sample_environ = _TextEnviron(env=env)
    assert sample_environ.encoding == 'utf-8'
    assert env == envcopy
    # Test __iter__
    assert list(sample_environ) == ['key1', 'key2', b'key3']
    # Test __getitem__
    assert sample_environ['key1'] == 'test'
    assert sample_environ['key2'] == 'test1'
    # Test __setitem__
    sample_environ['key1'] = 'test3'

# Generated at 2022-06-21 09:00:00.637887
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    assert len(env) > 0


# Generated at 2022-06-21 09:00:07.043492
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    _TextEnviron.encoding = 'utf-8'
    os.environ['CHARSET'] = '\xc3\x9c'.encode('utf-8')
    env = _TextEnviron()
    assert env['CHARSET'] == u'\xdc'.encode('utf-8').decode('utf-8')
    assert env['CHARSET'] == u'ü'.encode('utf-8').decode('utf-8')
    del os.environ['CHARSET']



# Generated at 2022-06-21 09:00:10.545507
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():

    t = _TextEnviron()

    def _get_iterable(obj):
        try:
            iter(obj)
            return True
        except TypeError:
            return False

    assert _get_iterable(t), 'Iterable is not _TextEnviron'


# Generated at 2022-06-21 09:00:20.022108
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # pylint: disable=protected-access
    new_environ = os.environ.copy()
    new_environ['HELLO'] = 'DOG'
    environ._raw_environ = new_environ
    environ['HELLO'] = 'WORLD'
    assert environ._raw_environ['HELLO'] == b'WORLD'
    environ['HELLO'] = b'WORLD'
    assert environ._raw_environ['HELLO'] == b'WORLD'
    environ['HELLO'] = u'WORLD'
    assert environ._raw_environ['HELLO'] == b'WORLD'


# Generated at 2022-06-21 09:00:28.823226
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test with text-like environment
    # Note that this also tests __getitem__ and __setitem__ since we're setting the env and
    # retrieving it
    env = _TextEnviron(env={'TEST_VAR': 'test_value'})
    assert env['TEST_VAR'] == u'test_value'
    assert type(env['TEST_VAR']) is unicode

    # Test with binary-like environment
    env = _TextEnviron(env={'TEST_VAR': b'test_value'})
    assert env['TEST_VAR'] == u'test_value'
    assert type(env['TEST_VAR']) is unicode

    # Test with mixed environment

# Generated at 2022-06-21 09:00:38.537477
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    if PY3:
        return None

    os.environ['test_TextEnviron_1'] = 'test_TextEnviron_value_1'
    os.environ['test_TextEnviron_2'] = 'test_TextEnviron_value_2'

# Generated at 2022-06-21 09:00:42.365274
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({'TEST_KEY1': 'VAL1', 'TEST_KEY2': 'VAL2'})
    assert len(env) == len({'TEST_KEY1': 'VAL1', 'TEST_KEY2': 'VAL2'})


# Generated at 2022-06-21 09:00:43.660281
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    pass


# Generated at 2022-06-21 09:00:46.616790
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _TextEnviron.__delitem__(environ, 'PWD')
    assert 'PWD' not in environ


# Generated at 2022-06-21 09:00:54.867735
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    '''
    Should return len of the underlying os.environ
    '''
    import os
    e = _TextEnviron()
    assert len(e) == len(os.environ)



# Generated at 2022-06-21 09:00:56.169474
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-21 09:01:07.274087
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    e = _TextEnviron(encoding='utf-8')
    e['foo'] = 'bar'
    assert e._raw_environ['foo'] == b'bar'
    e['foo'] = u'bar'
    assert e._raw_environ['foo'] == b'bar'
    try:
        e['foo'] = 42
        assert False
    except TypeError as e:
        pass
    # The following throws a UnicodeEncodeError when not in a PY3 branch but we catch this in the
    # __setitem__ method so we shouldn't see the exception here
    try:
        e['foo'] = u'\u2318'
    except UnicodeEncodeError as e:
        assert False



# Generated at 2022-06-21 09:01:09.700108
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    obj = _TextEnviron({'ZIG': 'ZAG', 'ONE': 'TWO'})
    results = set()
    for i in obj:
        results.add(i)
    assert results == set(['ONE', 'ZIG'])

# Generated at 2022-06-21 09:01:10.946529
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-21 09:01:17.550342
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    class Environ(object):
        values = {}

        def __getitem__(self, key):
            return self.values[key]

        def __setitem__(self, key, value):
            self.values[key] = value

        def __delitem__(self, key):
            del self.values[key]

    env = Environ()
    env.values = {'a': '1', 'b': '3'}

    te = _TextEnviron(env)
    del(te['b'])
    assert 'b' not in te
    te['a'] = '5'
    assert env.values['a'] == b'5'


# Generated at 2022-06-21 09:01:20.624829
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron(encoding='utf-8')
    assert isinstance(env, _TextEnviron)
    assert env._raw_environ is not None
    assert env.encoding == 'utf-8'

# Generated at 2022-06-21 09:01:32.187719
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    import sys
    if sys.version_info[0] > 2:
        # Python 3 has byte strings in environment variables (and so mutable byte strings)
        # because it uses surrogateescape
        # python3 -c "import os; print(os.environ.get('TEST_ENVVAR_1_BYTES', b'not found'))"
        # b'TEST_ENVVAR_1_BYTES=\xcc\x81\xcc\x80\xcc\x81\xcc\x80'
        import unittest.mock as mock
        from ansible.module_utils.six import text_type
        from ansible.module_utils._text import to_bytes, to_text
        from ansible.module_utils.common._collections_compat import MutableMapping


# Generated at 2022-06-21 09:01:37.096395
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import mock

    environ = _TextEnviron()
    with mock.patch.object(environ, '_raw_environ') as mock_raw_environ:
        environ.__delitem__('MOCK_ITEM')
        mock_raw_environ.__delitem__.assert_called_once_with('MOCK_ITEM')



# Generated at 2022-06-21 09:01:48.436088
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import PY2
    if PY2:
        from ansible.module_utils.six import b, u
    else:
        from ansible.module_utils.six import u
        b = u

    test_environ = _TextEnviron()
    test_environ._raw_environ = {u('NORMAL'): u('normal_value')}
    # Test with a simple key
    assert test_environ.__getitem__('NORMAL') == u('normal_value')
    # Test with an existing non-ascii key

# Generated at 2022-06-21 09:02:06.865638
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    x = {'name-with-utf8': u'Bödvar Bjarki',
         'name-with-latin1': u'\xe1'}
    environ = _TextEnviron(env=x, encoding='utf-8')
    assert len(environ) == len(x)
    for key in x:
        assert key in environ
        assert environ[key] == x[key]

# Generated at 2022-06-21 09:02:11.089741
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    def delitem(self, key):
        del environ[key]

    # Test case for subclass of class _TextEnviron
    # initialize an object of the subclass
    environ = _TextEnviron()
    # invoke method __delitem__ of its superclass _TextEnviron with arguments
    environ['key'] = 'value'
    delitem(environ, 'key')
    assert 'key' not in environ


# Generated at 2022-06-21 09:02:14.129039
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron(env={'Foo': 'bar'}, encoding='ascii')
    assert env._value_cache == {}
    assert env._raw_environ == {'Foo': b'bar'}
    assert env.encoding == 'ascii'
    assert env == {'Foo': 'bar'}


# Generated at 2022-06-21 09:02:23.134197
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """
    assert environ['PATH'] == u'/bin:/usr/bin'

    # Some encodings are not lossless.  We can only test the encoded output if we know the encoding
    environ = _TextEnviron(env={"BLAH": "bl\xfah"}, encoding='latin-1')
    assert environ['BLAH'] == u'blãh'

    # Non-string values should pass through
    environ = _TextEnviron(encoding='blah')
    assert environ['shell'] == '/bin/sh'



# Generated at 2022-06-21 09:02:31.127702
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # pylint: disable=unused-argument
    def _test_fn(test_environ=None, encoding=None):
        # pylint: disable=protected-access
        environ = _TextEnviron(test_environ, encoding)
        assert isinstance(environ, _TextEnviron)
        assert environ._raw_environ is test_environ
        assert SORTED(environ._value_cache) == SORTED(test_environ)
        assert environ.encoding == encoding

    _test_fn()
    _test_fn(encoding='ascii')
    _test_fn({u'foo': 'bar'})
    _test_fn({u'foo': u'bar'})
    _test_fn({u'foo': 'bar'}, encoding='ascii')
    _

# Generated at 2022-06-21 09:02:35.171205
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # setup
    env = _TextEnviron(encoding='utf-8')
    env['FOO'] = 'BAR'
    # test
    del env['FOO']
    # assert
    assert 'FOO' not in env
    assert 'FOO' not in os.environ


# Generated at 2022-06-21 09:02:38.477863
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    os.environ['TEST_KEY'] = b'abc'
    te = _TextEnviron(encoding='utf-8')
    assert te['TEST_KEY'] == u'abc'

# Generated at 2022-06-21 09:02:46.519487
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    global __builtins__
    if '__builtins__' in globals():
        old_builtins = globals()['__builtins__']
        globals()['__builtins__'] = {'_': str}
    if PY3:
        old_env = os.environ.copy()

    env = _TextEnviron()

    # Delete from os.environ
    env['TEST_KEY'] = 'foo'
    del env['TEST_KEY']
    assert env.get('TEST_KEY') is None

    if PY3:
        os.environ = old_env

    if '__builtins__' in globals():
        globals()['__builtins__'] = old_builtins



# Generated at 2022-06-21 09:02:51.771695
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """os.environ['blah'] = to_bytes('blah', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    try:
        os.environ['blah']
    except KeyError as e:
        if os.environ.get('blah') == None:
            pass
        else:
            raise e
    try:
        os.environ['blah']
        raise Exception
    except KeyError as e:
        pass
    """


# Generated at 2022-06-21 09:02:57.028383
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    #  Test deleting a key in the environment
    test_key = 'ANSIBLE_TEST_KEY'
    environ[test_key] = 'initial value'
    assert environ[test_key] == 'initial value'
    del environ[test_key]
    try:
        assert environ[test_key] == 'initial value'
        assert False
    except KeyError:
        # Key should be gone from the environment
        pass

    # Test deleting a key that is not in the environment
    try:
        del environ['ANSIBLE_DOES_NOT_EXIST']
        assert False
    except KeyError:
        # Key should not be in the environment
        pass


# Generated at 2022-06-21 09:03:30.551342
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    ret = _TextEnviron()

    ret['toto'] = u''
    assert 'toto' in ret
    assert ret['toto'] == u''

    ret['toto'] = u'ééé'
    assert 'toto' in ret
    assert ret['toto'] == u'ééé'
    assert ret._raw_environ['toto'] == b'\xc3\xa9\xc3\xa9\xc3\xa9'

    ret['toto'] = 'aaa'
    assert 'toto' in ret
    assert ret['toto'] == u'aaa'
    assert ret._raw_environ['toto'] == b'aaa'

    # The code below shows that if we do a ret['toto'] = 'bbb' we will never see it
    # as the environment has been altered


# Generated at 2022-06-21 09:03:38.204855
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['USER'] == os.environ['USER']
    # Create a case where the key is different to the value that it returns
    test_environ = {}
    test_environ[b'USER'] = b'bytesuser'
    test_environ[u'USER'] = u'unicodeuser'
    certain_environ = _TextEnviron(env=test_environ)
    assert certain_environ['USER'] == u'unicodeuser'
    # Create a case where the key is different to the value that it returns
    test_environ[u'NOCASE'] = u'uppercase'
    test_environ[u'nocase'] = u'lowercase'
    lower_environ = _TextEnviron(env=test_environ)

# Generated at 2022-06-21 09:03:43.517384
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ['ANSIBLE_TEST_KEY'] = 'ansible'
    environ = _TextEnviron(encoding='utf-8')
    del environ['ANSIBLE_TEST_KEY']
    assert True if not os.environ.__contains__('ANSIBLE_TEST_KEY') else False


# Generated at 2022-06-21 09:03:52.919622
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create test data
    os.environ[to_bytes('unicode_value_key')] = to_text('\u00001')
    os.environ[to_bytes('ascii_value_key')] = to_text('1')
    os.environ[to_bytes('binary_value_key')] = b'\x00\x01'

    # Test for non-existing key
    try:
        environ[to_bytes('non_existing_key')]
    except KeyError:
        pass

    # Test for binary key
    try:
        environ[b'binary_value_key']
    except TypeError:
        pass

    # Test for key in raw_environ
    assert environ['unicode_value_key'] == '\u00001'

# Generated at 2022-06-21 09:03:55.391080
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    test_case = _TextEnviron({'a': '1', 'b': '2'})
    assert len(test_case) == 2


# Generated at 2022-06-21 09:04:04.703602
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron(encoding='utf-8')
    key = 'TEST'
    value = u'fööbär'

    environ[key] = value
    assert environ[key] == value

    environ[key] = 'bär'
    assert environ[key] == u'bär'

    # The following test is best done in the debugger - it makes sure that a change to the
    # underlying data structure doesn't change the data we return.
    # We do this by directly changing the underlying data structure.
    # environ._raw_environ[key] = b'baz'
    # assert environ[key] == u'bär'



# Generated at 2022-06-21 09:04:11.267314
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import pytest

    cases = (
        (
            {'a': 'alpha', 'b': 'beta'},
            [u'a', u'b'],
        ),
        (
            {'a': 'α', 'b': 'β'},
            [u'a', u'b'],
        ),
    )

    for env, expected in cases:
        e = _TextEnviron(env)
        assert set(e.__iter__()) == set(e.keys()) == set(e) == set(expected)



# Generated at 2022-06-21 09:04:14.531321
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    raw_environ = {'ANSIBLE_UNIT_TEST': 'foo'}
    text_environ = _TextEnviron(env=raw_environ)
    assert 'foo' == text_environ['ANSIBLE_UNIT_TEST']

# Generated at 2022-06-21 09:04:19.351673
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    test_env = {'TEST_VAR': 'strýçk'}
    env = _TextEnviron(env=test_env)
    assert env['TEST_VAR'] == u'strýçk'
    env = _TextEnviron(env=test_env, encoding='latin-1')
    assert env['TEST_VAR'] == u'strýçk'.encode('latin-1').decode('latin-1')



# Generated at 2022-06-21 09:04:30.333708
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Test creating a _TextEnviron class and using it to store and retrieve values
    """
    my_environ = _TextEnviron()

    # Test using unicode key and value
    my_environ['⌘'] = '⌘'
    assert my_environ['⌘'] == '⌘'

    # Test using bytes key and value
    my_environ[b'\xe2\x8c\x98'] = b'\xe2\x8c\x98'
    assert my_environ['⌘'] == '⌘'

    # Test using unicode key with bytes values
    my_environ['⌘'] = b'\xe2\x8c\x98'
    assert my_environ['⌘'] == '⌘'
    my_

# Generated at 2022-06-21 09:05:32.852417
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for the method get of class _TextEnviron
    """
    env_data = [
        (u'a', b'a'),
        (u'b', u'b'),
        (u'c', b'\x80'),
        (u'd', u'\u0fff'),
        (u'e', u'\U00010000'),
    ]

    # Create a test environment
    raw_environ = os.environment()

    # Set some expected values
    for key, val in env_data:
        raw_environ[key] = val

    # Test how we parse the data back to text
    env = _TextEnviron(env=raw_environ, encoding='utf-8')

    for key, val in env_data:
        assert env[key] == val

    # Test replacing the value

# Generated at 2022-06-21 09:05:40.046707
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron({b'ansible_foo': b'bar'})
    assert env == {'ansible_foo': 'bar'}
    assert env.__getitem__(b'ansible_foo') == 'bar'
    env[b'kb'] = 'values'
    assert env[b'kb'] == 'values'
    assert env.__getitem__(b'kb') == 'values'
    assert env == {'ansible_foo': 'bar', 'kb': 'values'}
    del env[b'kb']
    assert env == {'ansible_foo': 'bar'}

# Generated at 2022-06-21 09:05:43.212823
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ["ANSIBLE_UNIT_TEST"] = "Yes"
    for x in environ:
        if x == "ANSIBLE_UNIT_TEST":
            return True
    raise AssertionError("Expected key 'ANSIBLE_UNIT_TEST'")


# Generated at 2022-06-21 09:05:44.648218
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-21 09:05:53.907324
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method ``__getitem__`` of class ``_TextEnviron``
    """
    import random
    import string
    import sys

    # Set up fake environment with many keys and values containing utf-8 and other byte sequences
    # which are valid in utf-8
    env = sys.modules[__name__].environ._raw_environ
    for _ in range(random.randint(10, 100)):
        key = ''.join(random.choice(string.ascii_letters) for _ in range(random.randint(4, 10)))
        value = ''.join([chr(random.choice(range(0, 255))) for _ in range(random.randint(2, 20))])
        env[key] = value

    # Run the test with a non-utf-8 encoding
   