

# Generated at 2022-06-17 15:24:59.013402
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a normal value
    environ['ANSIBLE_TEST_KEY'] = 'normal'
    assert environ['ANSIBLE_TEST_KEY'] == 'normal'
    # Test with a value that is already unicode
    environ['ANSIBLE_TEST_KEY'] = u'unicode'
    assert environ['ANSIBLE_TEST_KEY'] == u'unicode'
    # Test with a value that is already bytes
    environ['ANSIBLE_TEST_KEY'] = b'bytes'
    assert environ['ANSIBLE_TEST_KEY'] == u'bytes'
    # Test with a value that is already bytes and is unicode
    environ['ANSIBLE_TEST_KEY'] = b'\xe2\x98\x83'

# Generated at 2022-06-17 15:25:10.879466
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that the method returns the correct value when the value is already text
    environ['test_key'] = 'test_value'
    assert environ['test_key'] == 'test_value'

    # Test that the method returns the correct value when the value is bytes
    environ['test_key'] = b'test_value'
    assert environ['test_key'] == 'test_value'

    # Test that the method returns the correct value when the value is bytes with a non-utf-8
    # encoding
    environ['test_key'] = b'test_value'.decode('latin-1')
    assert environ['test_key'] == 'test_value'

    # Test that the method returns the correct value when the value is bytes with a non-utf-8
    # encoding and the encoding is set to latin-1

# Generated at 2022-06-17 15:25:21.443171
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that it returns the correct value for a key
    environ['TEST_KEY'] = 'test_value'
    assert environ['TEST_KEY'] == 'test_value'

    # Test that it returns the correct value for a key with a unicode character
    environ['TEST_KEY'] = 'test_value_with_unicode_character_\u263a'
    assert environ['TEST_KEY'] == 'test_value_with_unicode_character_\u263a'

    # Test that it returns the correct value for a key with a unicode character
    # that is not valid in the filesystem encoding
    environ['TEST_KEY'] = 'test_value_with_unicode_character_\u263a'

# Generated at 2022-06-17 15:25:28.818662
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a non-unicode value
    environ['foo'] = 'bar'
    assert environ['foo'] == 'bar'

    # Test with a unicode value
    environ['foo'] = u'bár'
    assert environ['foo'] == u'bár'

    # Test with a non-unicode value that's not utf-8
    environ['foo'] = b'\x80'
    assert environ['foo'] == u'\uFFFD'

    # Test with a unicode value that's not utf-8
    environ['foo'] = u'\x80'
    assert environ['foo'] == u'\uFFFD'

    # Test with a non-unicode value that's not utf-8 and can't be decoded

# Generated at 2022-06-17 15:25:40.177077
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a key that does not exist
    try:
        environ['does_not_exist']
    except KeyError:
        pass
    else:
        raise AssertionError('KeyError not raised')

    # Test with a key that exists
    environ['does_exist'] = 'value'
    assert environ['does_exist'] == 'value'

    # Test with a key that exists but is not a string
    environ['does_exist'] = b'value'
    assert environ['does_exist'] == 'value'

    # Test with a key that exists but is not a string
    environ['does_exist'] = u'value'
    assert environ['does_exist'] == 'value'

    # Test with a key that exists but is not a string
    environ['does_exist'] = 1

# Generated at 2022-06-17 15:25:44.669517
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we can get a value from the environment
    assert environ['PATH'] == os.environ['PATH']

    # Test that we can get a value from the environment when the value is unicode
    environ['TEST_UNICODE'] = u'\u00e9'
    assert environ['TEST_UNICODE'] == u'\u00e9'

    # Test that we can get a value from the environment when the value is bytes
    environ['TEST_BYTES'] = b'\xc3\xa9'
    assert environ['TEST_BYTES'] == u'\u00e9'

    # Test that we can get a value from the environment when the value is bytes and the encoding
    # is ascii

# Generated at 2022-06-17 15:25:56.598824
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we get the same value back that we put in
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back that we put in
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back that we put in
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back that we put in
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back that we put in
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value

# Generated at 2022-06-17 15:26:05.896243
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we can get a value from the environment
    assert environ['PATH'] == os.environ['PATH']

    # Test that we can get a value from the environment that is not in the cache
    assert environ['PATH'] == os.environ['PATH']

    # Test that we can get a value from the environment that is in the cache
    assert environ['PATH'] == os.environ['PATH']

    # Test that we can get a value from the environment that is not in the cache and is not
    # utf-8
    assert environ['PATH'] == os.environ['PATH']

    # Test that we can get a value from the environment that is in the cache and is not utf-8
    assert environ['PATH'] == os.environ['PATH']

    # Test that we can get a value from the environment that is not

# Generated at 2022-06-17 15:26:10.897710
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for method __getitem__ of class _TextEnviron
    #
    # Test that we get a text string back from the environment
    environ['ANSIBLE_TEST_VAR'] = 'test'
    assert isinstance(environ['ANSIBLE_TEST_VAR'], str)
    del environ['ANSIBLE_TEST_VAR']

    # Test that we get a text string back from the environment
    environ['ANSIBLE_TEST_VAR'] = b'test'
    assert isinstance(environ['ANSIBLE_TEST_VAR'], str)
    del environ['ANSIBLE_TEST_VAR']

    # Test that we get a text string back from the environment
    environ['ANSIBLE_TEST_VAR'] = u'test'

# Generated at 2022-06-17 15:26:14.275190
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(encoding='utf-8')
    environ['test_key'] = 'test_value'
    assert environ['test_key'] == 'test_value'

# Generated at 2022-06-17 15:26:26.648025
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a value that is already text
    environ['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'
    assert environ['ANSIBLE_TEST_KEY'] == 'ANSIBLE_TEST_VALUE'
    # Test with a value that is bytes
    environ['ANSIBLE_TEST_KEY'] = b'ANSIBLE_TEST_VALUE'
    assert environ['ANSIBLE_TEST_KEY'] == 'ANSIBLE_TEST_VALUE'
    # Test with a value that is bytes and has non-ascii characters
    environ['ANSIBLE_TEST_KEY'] = b'\xc3\xa9'
    assert environ['ANSIBLE_TEST_KEY'] == u'\xe9'
    # Test with a value that is bytes and has non-ascii characters and is not valid

# Generated at 2022-06-17 15:26:37.028427
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we can get the value of an environment variable
    assert environ['PATH'] == os.environ['PATH']

    # Test that we can get the value of an environment variable with non-ascii characters
    if 'TEST_NON_ASCII_ENV_VAR' in os.environ:
        assert environ['TEST_NON_ASCII_ENV_VAR'] == os.environ['TEST_NON_ASCII_ENV_VAR']

    # Test that we can get the value of an environment variable with non-ascii characters
    # and that the value is decoded properly
    if 'TEST_NON_ASCII_ENV_VAR' in os.environ:
        assert environ['TEST_NON_ASCII_ENV_VAR'] == os.en

# Generated at 2022-06-17 15:26:48.802202
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a non-unicode value
    environ['foo'] = 'bar'
    assert environ['foo'] == 'bar'

    # Test with a unicode value
    environ['foo'] = u'baz'
    assert environ['foo'] == u'baz'

    # Test with a unicode value that can't be decoded
    environ['foo'] = u'\u1234'
    assert environ['foo'] == u'\u1234'

    # Test with a unicode value that can't be decoded
    environ['foo'] = u'\u1234'
    assert environ['foo'] == u'\u1234'

    # Test with a unicode value that can't be decoded
    environ['foo'] = u'\u1234'
    assert environ['foo']

# Generated at 2022-06-17 15:26:54.855737
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({'foo': 'bar'})
    assert env['foo'] == 'bar'
    assert env['foo'] == u'bar'
    assert env['foo'] == b'bar'
    assert env['foo'] == u'bar'
    assert env['foo'] == b'bar'



# Generated at 2022-06-17 15:27:03.493285
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we can get a value from the environment
    assert environ['PATH'] == os.environ['PATH']

    # Test that we can get a value from the environment that is not in the cache
    assert environ['HOME'] == os.environ['HOME']

    # Test that we can get a value from the environment that is in the cache
    assert environ['PATH'] == os.environ['PATH']

    # Test that we can get a value from the environment that is not in the cache
    assert environ['HOME'] == os.environ['HOME']

    # Test that we can get a value from the environment that is in the cache
    assert environ['PATH'] == os.environ['PATH']

    # Test that we can get a value from the environment that is not in the cache

# Generated at 2022-06-17 15:27:13.911091
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a key that is not in the environment
    assert environ['THIS_KEY_IS_NOT_IN_THE_ENVIRONMENT'] == ''

    # Test with a key that is in the environment
    assert environ['PATH'] == os.environ['PATH']

    # Test with a key that is in the environment but the value is not in the cache
    environ['PATH'] = 'foo'
    assert environ['PATH'] == 'foo'

    # Test with a key that is in the environment and the value is in the cache
    assert environ['PATH'] == 'foo'

    # Test with a key that is in the environment and the value is in the cache but the value has
    # changed
    environ['PATH'] = 'bar'
    assert environ['PATH'] == 'bar'

    # Test with a key that is

# Generated at 2022-06-17 15:27:23.537709
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we get the same value back that we put in
    environ['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'
    assert environ['ANSIBLE_TEST_KEY'] == 'ANSIBLE_TEST_VALUE'

    # Test that we get the same value back that we put in when we use a unicode value
    environ['ANSIBLE_TEST_KEY'] = u'ANSIBLE_TEST_VALUE'
    assert environ['ANSIBLE_TEST_KEY'] == u'ANSIBLE_TEST_VALUE'

    # Test that we get the same value back that we put in when we use a byte string
    environ['ANSIBLE_TEST_KEY'] = b'ANSIBLE_TEST_VALUE'

# Generated at 2022-06-17 15:27:34.725452
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for non-ascii characters
    environ['ANSIBLE_TEST_KEY'] = u'\u2603'
    assert environ['ANSIBLE_TEST_KEY'] == u'\u2603'

    # Test for non-ascii characters in a byte string
    environ['ANSIBLE_TEST_KEY'] = b'\xe2\x98\x83'
    assert environ['ANSIBLE_TEST_KEY'] == u'\u2603'

    # Test for non-ascii characters in a byte string with a different encoding
    environ['ANSIBLE_TEST_KEY'] = b'\xc3\xa9'
    assert environ['ANSIBLE_TEST_KEY'] == u'\xe9'

    # Test for non-ascii characters in a byte string with a different encoding


# Generated at 2022-06-17 15:27:47.200769
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a non-unicode value
    environ['test_key'] = 'test_value'
    assert environ['test_key'] == 'test_value'

    # Test with a unicode value
    environ['test_key'] = u'test_value'
    assert environ['test_key'] == u'test_value'

    # Test with a non-unicode value that contains a unicode character
    environ['test_key'] = 'test_value\u1234'
    assert environ['test_key'] == 'test_value\u1234'

    # Test with a unicode value that contains a unicode character
    environ['test_key'] = u'test_value\u1234'
    assert environ['test_key'] == u'test_value\u1234'

    # Test

# Generated at 2022-06-17 15:27:55.635779
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a key that doesn't exist
    assert environ['DOES_NOT_EXIST'] == ''

    # Test with a key that exists
    assert environ['PATH'] == os.environ['PATH']

    # Test with a key that exists and has a unicode character in it
    if 'ANSIBLE_TEST_UNICODE_ENV_VAR' in os.environ:
        assert environ['ANSIBLE_TEST_UNICODE_ENV_VAR'] == os.environ['ANSIBLE_TEST_UNICODE_ENV_VAR']



# Generated at 2022-06-17 15:28:06.774920
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for non-unicode values
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test for unicode values
    environ['test'] = u'test'
    assert environ['test'] == u'test'

    # Test for unicode values with non-ascii characters
    environ['test'] = u'\u00E9'
    assert environ['test'] == u'\u00E9'

    # Test for unicode values with non-ascii characters
    environ['test'] = u'\u00E9'
    assert environ['test'] == u'\u00E9'

    # Test for unicode values with non-ascii characters
    environ['test'] = u'\u00E9'

# Generated at 2022-06-17 15:28:15.755348
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we get the same value back when we set a value
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back when we set a value with a unicode character
    environ['test'] = u'test\u20ac'
    assert environ['test'] == u'test\u20ac'

    # Test that we get the same value back when we set a value with a unicode character
    environ['test'] = u'test\u20ac'
    assert environ['test'] == u'test\u20ac'

    # Test that we get the same value back when we set a value with a unicode character
    environ['test'] = u'test\u20ac'

# Generated at 2022-06-17 15:28:21.207801
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a unicode string
    environ['test_key'] = u'\u00e9'
    assert environ['test_key'] == u'\u00e9'

    # Test with a byte string
    environ['test_key'] = b'\xc3\xa9'
    assert environ['test_key'] == u'\u00e9'

    # Test with a non-string
    environ['test_key'] = 123
    assert environ['test_key'] == u'123'



# Generated at 2022-06-17 15:28:28.853882
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a key that doesn't exist
    assert environ['DOES_NOT_EXIST'] == ''

    # Test with a key that exists
    assert environ['PATH'] == os.environ['PATH']

    # Test with a key that exists but has a non-ascii value
    os.environ['ANSIBLE_TEST_NON_ASCII'] = '\xe2\x98\x83'
    assert environ['ANSIBLE_TEST_NON_ASCII'] == '\xe2\x98\x83'
    del os.environ['ANSIBLE_TEST_NON_ASCII']

    # Test with a key that exists but has a non-ascii value and we're on Python2

# Generated at 2022-06-17 15:28:37.887608
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a key that is not in the environment
    assert environ['NOT_IN_ENV'] == ''

    # Test with a key that is in the environment
    assert environ['PATH'] == os.environ['PATH']

    # Test with a key that is in the environment but has a non-ascii value
    if 'NON_ASCII_ENV' in os.environ:
        assert environ['NON_ASCII_ENV'] == os.environ['NON_ASCII_ENV']



# Generated at 2022-06-17 15:28:47.510253
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we get the same value back as we put in
    environ['foo'] = 'bar'
    assert environ['foo'] == 'bar'

    # Test that we get the same value back as we put in
    environ['foo'] = 'baz'
    assert environ['foo'] == 'baz'

    # Test that we get the same value back as we put in
    environ['foo'] = 'baz'
    assert environ['foo'] == 'baz'

    # Test that we get the same value back as we put in
    environ['foo'] = 'baz'
    assert environ['foo'] == 'baz'

    # Test that we get the same value back as we put in
    environ['foo'] = 'baz'
    assert environ['foo'] == 'baz'

   

# Generated at 2022-06-17 15:28:56.127671
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a non-unicode value
    environ['TEST_VAR'] = 'test'
    assert environ['TEST_VAR'] == u'test'

    # Test with a unicode value
    environ['TEST_VAR'] = u'test'
    assert environ['TEST_VAR'] == u'test'

    # Test with a unicode value that has a non-ascii character
    environ['TEST_VAR'] = u'\u00e9'
    assert environ['TEST_VAR'] == u'\u00e9'

    # Test with a unicode value that has a non-ascii character and is encoded in utf-8
    environ['TEST_VAR'] = u'\u00e9'.encode('utf-8')

# Generated at 2022-06-17 15:29:06.152552
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a non-unicode value
    environ['test_key'] = 'test_value'
    assert environ['test_key'] == 'test_value'

    # Test with a unicode value
    environ['test_key'] = u'test_value'
    assert environ['test_key'] == u'test_value'

    # Test with a unicode value that has a non-ascii character
    environ['test_key'] = u'test_value_\u00e9'
    assert environ['test_key'] == u'test_value_\u00e9'

    # Test with a unicode value that has a non-ascii character
    environ['test_key'] = u'test_value_\u00e9'

# Generated at 2022-06-17 15:29:14.980110
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we get the same thing back that we put in
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same thing back that we put in
    environ['test'] = b'test'
    assert environ['test'] == 'test'

    # Test that we get the same thing back that we put in
    environ['test'] = u'test'
    assert environ['test'] == 'test'

    # Test that we get the same thing back that we put in
    environ['test'] = b'\xc3\xbc'
    assert environ['test'] == u'\xfc'

    # Test that we get the same thing back that we put in
    environ['test'] = u'\xfc'
    assert environ['test']

# Generated at 2022-06-17 15:29:25.126032
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a non-unicode value
    environ._raw_environ = {'foo': 'bar'}
    assert environ['foo'] == 'bar'
    # Test with a unicode value
    environ._raw_environ = {'foo': '\u2603'}
    assert environ['foo'] == '\u2603'
    # Test with a unicode value that can't be decoded
    environ._raw_environ = {'foo': '\u2603'.encode('utf-16')}
    assert environ['foo'] == '\u2603'
    # Test with a unicode value that can't be decoded
    environ._raw_environ = {'foo': '\u2603'.encode('utf-16')}

# Generated at 2022-06-17 15:29:35.446955
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a value that is already text
    environ['foo'] = 'bar'
    assert environ['foo'] == 'bar'

    # Test with a value that is bytes
    environ['foo'] = b'bar'
    assert environ['foo'] == 'bar'

    # Test with a value that is bytes and needs to be decoded
    environ['foo'] = b'\xc3\xa9'
    assert environ['foo'] == u'\xe9'

    # Test with a value that is bytes and needs to be decoded with errors
    environ['foo'] = b'\xc3\x28'
    assert environ['foo'] == u'\ufffd('

    # Test with a value that is bytes and needs to be decoded with errors

# Generated at 2022-06-17 15:29:46.796091
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that the method returns the value of the environment variable
    # when the value is a string
    environ['ANSIBLE_TEST_VAR'] = 'test'
    assert environ['ANSIBLE_TEST_VAR'] == 'test'

    # Test that the method returns the value of the environment variable
    # when the value is a unicode string
    environ['ANSIBLE_TEST_VAR'] = u'test'
    assert environ['ANSIBLE_TEST_VAR'] == u'test'

    # Test that the method returns the value of the environment variable
    # when the value is a byte string
    environ['ANSIBLE_TEST_VAR'] = b'test'
    assert environ['ANSIBLE_TEST_VAR'] == b'test'

    # Test that the method returns the value of the environment

# Generated at 2022-06-17 15:29:56.651694
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a non-unicode value
    environ._raw_environ['test'] = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f'
    environ._value_cache = {}
    assert environ['test'] == u'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f'

# Generated at 2022-06-17 15:30:07.538252
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a non-unicode value
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test with a unicode value
    environ['test'] = u'test'
    assert environ['test'] == u'test'

    # Test with a unicode value that can't be decoded
    environ['test'] = u'\u1234'
    assert environ['test'] == u'\u1234'

    # Test with a unicode value that can't be decoded
    environ['test'] = u'\u1234'
    assert environ['test'] == u'\u1234'

    # Test with a unicode value that can't be decoded
    environ['test'] = u'\u1234'
    assert environ['test'] == u

# Generated at 2022-06-17 15:30:18.587232
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we get the same value back when the value is already text
    assert environ['PATH'] == os.environ['PATH']

    # Test that we get the same value back when the value is already bytes
    assert environ[b'PATH'] == os.environ['PATH']

    # Test that we get the same value back when the value is already bytes
    assert environ[b'PATH'] == os.environ['PATH']

    # Test that we get the same value back when the value is already bytes
    assert environ[b'PATH'] == os.environ['PATH']

    # Test that we get the same value back when the value is already bytes
    assert environ[b'PATH'] == os.environ['PATH']

    # Test that we get the same value back when the value is already bytes
    assert environ[b'PATH']

# Generated at 2022-06-17 15:30:27.710779
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we get a text string back
    assert isinstance(environ['PATH'], str)
    # Test that we get the same value back as os.environ
    assert environ['PATH'] == os.environ['PATH']
    # Test that we get the same value back as os.environ for a unicode value
    os.environ['UNICODE_TEST'] = u'\u00e9'
    assert environ['UNICODE_TEST'] == os.environ['UNICODE_TEST']
    del os.environ['UNICODE_TEST']


# Generated at 2022-06-17 15:30:38.392812
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a unicode string
    environ['TEST_VAR'] = u'\u00e9'
    assert environ['TEST_VAR'] == u'\u00e9'
    # Test with a byte string
    environ['TEST_VAR'] = b'\xc3\xa9'
    assert environ['TEST_VAR'] == u'\u00e9'
    # Test with a byte string that is not valid utf-8
    environ['TEST_VAR'] = b'\xff'
    assert environ['TEST_VAR'] == u'\ufffd'
    # Test with a byte string that is not valid utf-8
    environ['TEST_VAR'] = b'\xff\xff'

# Generated at 2022-06-17 15:30:51.132447
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a non-unicode value
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test with a unicode value
    environ['test'] = u'test'
    assert environ['test'] == u'test'

    # Test with a unicode value that can't be encoded
    environ['test'] = u'\u1234'
    assert environ['test'] == u'\u1234'

    # Test with a unicode value that can't be encoded
    environ['test'] = u'\u1234'
    assert environ['test'] == u'\u1234'

    # Test with a unicode value that can't be encoded
    environ['test'] = u'\u1234'

# Generated at 2022-06-17 15:31:03.449869
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that the class returns the same value as os.environ when the value is already text
    environ['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'
    assert environ['ANSIBLE_TEST_KEY'] == os.environ['ANSIBLE_TEST_KEY']

    # Test that the class returns the same value as os.environ when the value is already bytes
    environ['ANSIBLE_TEST_KEY'] = b'ANSIBLE_TEST_VALUE'
    assert environ['ANSIBLE_TEST_KEY'] == os.environ['ANSIBLE_TEST_KEY']

    # Test that the class returns the same value as os.environ when the value is already bytes
    environ['ANSIBLE_TEST_KEY'] = b'\xc3\xbc'

# Generated at 2022-06-17 15:31:11.890375
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that the environment variable is returned as text
    environ['ANSIBLE_TEST_VAR'] = 'test'
    assert isinstance(environ['ANSIBLE_TEST_VAR'], str)

    # Test that the environment variable is returned as text even if it was set as bytes
    environ['ANSIBLE_TEST_VAR'] = b'test'
    assert isinstance(environ['ANSIBLE_TEST_VAR'], str)

    # Test that the environment variable is returned as text even if it was set as text
    environ['ANSIBLE_TEST_VAR'] = u'test'
    assert isinstance(environ['ANSIBLE_TEST_VAR'], str)

    # Test that the environment variable is returned as text even if it was set as text

# Generated at 2022-06-17 15:31:24.682961
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a key that is not in the environment
    assert environ['NOT_A_REAL_KEY'] == ''

    # Test with a key that is in the environment
    assert environ['PATH'] == os.environ['PATH']

    # Test with a key that is in the environment but has a non-ascii value
    # This is a bit of a hack to get a non-ascii value into the environment
    # that is not a unicode string.  The environment is always byte strings
    # and we're trying to test that we can decode them.
    os.environ['NON_ASCII_KEY'] = b'\x80'
    assert environ['NON_ASCII_KEY'] == u'\u0080'

    # Test with a key that is in the environment but has a non-ascii value


# Generated at 2022-06-17 15:31:34.365700
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that the method returns the same value as os.environ when the value is a byte string
    assert environ['PATH'] == os.environ['PATH']
    # Test that the method returns a text string when the value is a byte string
    assert isinstance(environ['PATH'], str)
    # Test that the method returns the same value as os.environ when the value is a text string
    os.environ['TEST_VAR'] = 'test value'
    assert environ['TEST_VAR'] == os.environ['TEST_VAR']
    # Test that the method returns a text string when the value is a text string
    assert isinstance(environ['TEST_VAR'], str)
    # Test that the method returns the same value as os.environ when the value is a byte string
    # with non

# Generated at 2022-06-17 15:31:44.476178
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that the method returns the same value as os.environ
    assert environ['PATH'] == os.environ['PATH']

    # Test that the method returns a text string
    assert isinstance(environ['PATH'], str)

    # Test that the method returns the same value as os.environ when the value is a text string
    os.environ['PATH'] = 'foo'
    assert environ['PATH'] == os.environ['PATH']

    # Test that the method returns a text string when the value is a text string
    assert isinstance(environ['PATH'], str)

    # Test that the method returns the same value as os.environ when the value is a byte string
    os.environ['PATH'] = b'foo'
    assert environ['PATH'] == os.environ['PATH']

    # Test that the

# Generated at 2022-06-17 15:31:52.354361
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we get the same value back that we put in
    environ['test_key'] = 'test_value'
    assert environ['test_key'] == 'test_value'

    # Test that we get the same value back that we put in
    environ['test_key'] = b'test_value'
    assert environ['test_key'] == 'test_value'

    # Test that we get the same value back that we put in
    environ['test_key'] = u'test_value'
    assert environ['test_key'] == 'test_value'

    # Test that we get the same value back that we put in
    environ['test_key'] = u'test_value'
    assert environ['test_key'] == 'test_value'

    # Test that we get the same value back that we

# Generated at 2022-06-17 15:32:02.720820
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'foo': b'bar'}, encoding='utf-8')
    assert environ[b'foo'] == u'bar'
    assert environ['foo'] == u'bar'
    assert environ[u'foo'] == u'bar'
    assert environ[b'foo'] == u'bar'
    assert environ[b'foo'] == u'bar'
    assert environ[b'foo'] == u'bar'
    assert environ[b'foo'] == u'bar'
    assert environ[b'foo'] == u'bar'
    assert environ[b'foo'] == u'bar'
    assert environ[b'foo'] == u'bar'
    assert environ[b'foo'] == u'bar'
    assert environ[b'foo'] == u

# Generated at 2022-06-17 15:32:12.570603
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we get the same value back when we set it
    environ['test_key'] = 'test_value'
    assert environ['test_key'] == 'test_value'

    # Test that we get the same value back when we set it with a unicode string
    environ['test_key'] = u'test_value'
    assert environ['test_key'] == 'test_value'

    # Test that we get the same value back when we set it with a unicode string
    environ['test_key'] = u'test_value'
    assert environ['test_key'] == 'test_value'

    # Test that we get the same value back when we set it with a unicode string
    environ['test_key'] = u'test_value'

# Generated at 2022-06-17 15:32:24.526417
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we get the same value back that we put in
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back that we put in
    environ['test'] = b'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back that we put in
    environ['test'] = u'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back that we put in
    environ['test'] = u'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back that we put in
    environ['test'] = u'\u00e9'

# Generated at 2022-06-17 15:32:31.146254
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we get the same value back when we ask for a key that's already in the environment
    assert environ['PATH'] == os.environ['PATH']
    # Test that we get the same value back when we ask for a key that's not in the environment
    assert environ['PATH'] == os.environ['PATH']
    # Test that we get the same value back when we ask for a key that's not in the environment
    # and then add it
    environ['TEST_KEY'] = 'test_value'
    assert environ['TEST_KEY'] == 'test_value'
    assert environ['TEST_KEY'] == os.environ['TEST_KEY']
    # Test that we get the same value back when we ask for a key that's not in the environment
    # and then add it and then change it
    en

# Generated at 2022-06-17 15:32:38.109234
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a key that is not in the environment
    assert environ['NOT_A_REAL_KEY'] == u''

    # Test with a key that is in the environment
    assert environ['PATH'] == os.environ['PATH']

    # Test with a key that is in the environment and has a value that is not utf-8
    os.environ['NOT_UTF8'] = b'\x80'
    assert environ['NOT_UTF8'] == u'\ufffd'



# Generated at 2022-06-17 15:32:49.358148
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a key that is not in the environment
    assert 'not_in_environ' not in environ
    try:
        environ['not_in_environ']
    except KeyError:
        pass
    else:
        assert False, 'KeyError not raised'

    # Test with a key that is in the environment
    assert 'HOME' in environ
    assert environ['HOME'] == os.environ['HOME']

    # Test with a key that is in the environment but the value is not in the cache
    assert 'PATH' in environ
    assert environ['PATH'] == os.environ['PATH']

    # Test with a key that is in the environment and the value is in the cache
    assert 'PATH' in environ
    assert environ['PATH'] == os.environ['PATH']



# Generated at 2022-06-17 15:33:13.619587
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a non-unicode value
    environ['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'
    assert environ['ANSIBLE_TEST_KEY'] == u'ANSIBLE_TEST_VALUE'

    # Test with a unicode value
    environ['ANSIBLE_TEST_KEY'] = u'ANSIBLE_TEST_VALUE'
    assert environ['ANSIBLE_TEST_KEY'] == u'ANSIBLE_TEST_VALUE'

    # Test with a unicode value that has non-ascii characters
    environ['ANSIBLE_TEST_KEY'] = u'ANSIBLE_TEST_VALUE\u00a9'
    assert environ['ANSIBLE_TEST_KEY'] == u'ANSIBLE_TEST_VALUE\u00a9'

    # Test with a unic

# Generated at 2022-06-17 15:33:24.005925
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we get the same value back as we put in
    environ['test'] = 'value'
    assert environ['test'] == 'value'

    # Test that we get a text value back on Python2
    if not PY3:
        assert isinstance(environ['test'], text_type)

    # Test that we get a text value back on Python3
    if PY3:
        assert isinstance(environ['test'], str)

    # Test that we get a surrogate escaped value back on Python2
    if not PY3:
        environ['test'] = u'\U0001f4a9'
        assert environ['test'] == u'\udc4a9'

    # Test that we get a surrogate escaped value back on Python3

# Generated at 2022-06-17 15:33:34.273168
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a value that is already text
    environ = _TextEnviron({'ANSIBLE_TEST_KEY': 'ANSIBLE_TEST_VALUE'})
    assert environ['ANSIBLE_TEST_KEY'] == 'ANSIBLE_TEST_VALUE'

    # Test with a value that is bytes
    environ = _TextEnviron({'ANSIBLE_TEST_KEY': b'ANSIBLE_TEST_VALUE'})
    assert environ['ANSIBLE_TEST_KEY'] == 'ANSIBLE_TEST_VALUE'

    # Test with a value that is bytes and the encoding is set to utf-8
    environ = _TextEnviron({'ANSIBLE_TEST_KEY': b'ANSIBLE_TEST_VALUE'}, encoding='utf-8')

# Generated at 2022-06-17 15:33:47.428699
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we get the same value back when we set it
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back when we set it
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back when we set it
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back when we set it
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back when we set it
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value

# Generated at 2022-06-17 15:33:59.718863
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we can get a value from the environment
    assert environ['PATH'] == os.environ['PATH']

    # Test that we can get a value from the environment that is not in the cache
    assert environ['PATH'] == os.environ['PATH']

    # Test that we can get a value from the environment that is in the cache
    assert environ['PATH'] == os.environ['PATH']

    # Test that we can get a value from the environment that is not in the cache
    # but is in the cache for a different key
    assert environ['PATH'] == os.environ['PATH']

    # Test that we can get a value from the environment that is not in the cache
    # but is in the cache for a different key
    assert environ['PATH'] == os.environ['PATH']

    # Test that we can get

# Generated at 2022-06-17 15:34:06.835498
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for non-unicode environment variables
    environ['ANSIBLE_TEST_VAR'] = 'test_value'
    assert environ['ANSIBLE_TEST_VAR'] == 'test_value'

    # Test for unicode environment variables
    environ['ANSIBLE_TEST_VAR'] = u'\u00e9'
    assert environ['ANSIBLE_TEST_VAR'] == u'\u00e9'

    # Test for unicode environment variables with surrogate pairs
    environ['ANSIBLE_TEST_VAR'] = u'\ud83d\ude00'
    assert environ['ANSIBLE_TEST_VAR'] == u'\ud83d\ude00'

    # Test for unicode environment variables with surrogate pairs

# Generated at 2022-06-17 15:34:14.330421
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'foo': b'bar'}, encoding='utf-8')
    assert environ[b'foo'] == u'bar'
    assert environ['foo'] == u'bar'
    assert environ[u'foo'] == u'bar'
    assert environ[b'foo'] == u'bar'
    assert environ[u'foo'] == u'bar'
    assert environ[b'foo'] == u'bar'
    assert environ[u'foo'] == u'bar'
    assert environ[b'foo'] == u'bar'
    assert environ[u'foo'] == u'bar'
    assert environ[b'foo'] == u'bar'
    assert environ[u'foo'] == u'bar'
    assert environ[b'foo'] == u

# Generated at 2022-06-17 15:34:24.457337
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a key that has a value that is a byte string
    environ['foo'] = b'bar'
    assert environ['foo'] == u'bar'

    # Test with a key that has a value that is a text string
    environ['foo'] = u'bar'
    assert environ['foo'] == u'bar'

    # Test with a key that has a value that is a byte string that is not utf-8
    environ['foo'] = b'\x80'
    assert environ['foo'] == u'\udc80'

    # Test with a key that has a value that is a text string that is not utf-8
    environ['foo'] = u'\x80'
    assert environ['foo'] == u'\x80'

    # Test with a key that has a value that is

# Generated at 2022-06-17 15:34:35.227747
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we get the same value back that we put in
    environ['ANSIBLE_TEST_VAR'] = u'\u2603'
    assert environ['ANSIBLE_TEST_VAR'] == u'\u2603'
    del environ['ANSIBLE_TEST_VAR']

    # Test that we get the same value back that we put in
    environ['ANSIBLE_TEST_VAR'] = u'\u2603'
    assert environ['ANSIBLE_TEST_VAR'] == u'\u2603'
    del environ['ANSIBLE_TEST_VAR']

    # Test that we get the same value back that we put in
    environ['ANSIBLE_TEST_VAR'] = u'\u2603'

# Generated at 2022-06-17 15:34:42.953654
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we get the same value back as we put in
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back as we put in
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back as we put in
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back as we put in
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value back as we put in
    environ['test'] = 'test'
    assert environ['test'] == 'test'

    # Test that we get the same value