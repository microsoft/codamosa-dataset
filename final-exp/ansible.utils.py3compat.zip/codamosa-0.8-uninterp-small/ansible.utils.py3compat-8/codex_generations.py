

# Generated at 2022-06-25 13:34:26.232144
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        text_environ = _TextEnviron()
        # UnicodeEncodeError(u'ascii', u'abc\u2713', 0, 1, 'ordinal not in range(128)')
        # text_environ['abc\u2713']
        # text_environ['abc\u2713']
    except Exception as e:
        if e.message == 'abc\xe2\x9c\x93' and str(e.message) == 'abc\xe2\x9c\x93':
            print('assertion failed')
            assert False
        else:
            print('assertion passed')
            assert True


# Generated at 2022-06-25 13:34:31.496285
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        return
    text_environ_0 = _TextEnviron(encoding='ascii')
    text_environ_0['test_key'] = 'test_value'
    assert text_environ_0['test_key'] == 'test_value', 'AssertionError: %s != %s' % (text_environ_0['test_key'], 'test_value')

# Generated at 2022-06-25 13:34:34.370209
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__(0)
    assert result == text_environ_0._raw_environ[0]


# Generated at 2022-06-25 13:34:38.950647
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Initialize
    text_environ_0 = _TextEnviron()
    # Perform operation
    var_return = text_environ_0.__getitem__('a')
    # Verify
    assert var_return == 'b'


# Generated at 2022-06-25 13:34:49.320584
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for proper handling of non-unicode values in the environment
    if PY3:
        # Python3 has implicit decoding of unicode so this will work.  The only thing we need to
        # test is that non-unicode values do not raise TypeError
        assert environ[b'PYTHONPATH'] == os.environ['PYTHONPATH']
    else:
        # Non-unicode values raise TypeError in Python2.  Test that they raise TypeError when
        # passed as bytes and that they raise TypeError when passed as unicode
        try:
            environ[b'PYTHONPATH']
        except TypeError:
            pass
        else:
            # TypeError not raised
            assert False
        try:
            environ['PYTHONPATH']
        except TypeError:
            pass

# Generated at 2022-06-25 13:34:50.506724
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    value_0 = environ.__getitem__(None)



# Generated at 2022-06-25 13:34:53.331559
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['SHELL'] == '/bin/bash'
    assert environ.get('SHELL') == '/bin/bash'


# Generated at 2022-06-25 13:34:57.667750
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # __getitem__: (1 of 2) ValueError when trying to decode a string that isn't actually a string
    # __getitem__: (1 of 2) ValueError when trying to decode a string that isn't actually a string
    assert_exception(ValueError, text_environ_0.__getitem__, None)


# Generated at 2022-06-25 13:35:01.686731
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # The next line tests that we get a unicode string.  The call to to_text is just to ensure we
    # get the same type back in all cases.  We could otherwise simply inspect the type of value
    assert isinstance(to_text(text_environ_0['LOCALDOMAIN']), str)



# Generated at 2022-06-25 13:35:10.925055
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # We are not running on Python3. The value we set will be a byte string,
    # and the value we get back will be a text string.
    if not PY3:
        text_environ_1 = _TextEnviron()
        text_environ_1['foo'] = b'bar'
        assert text_environ_1['foo'] == u'bar'

        # Test that we see the right encoding errors
        text_environ_1['nonascii'] = b'\xff'
        raises(UnicodeDecodeError, text_environ_1.__getitem__, 'nonascii')

    # We're on Python3. The value we set is a text string, and the value we get back is that same
    # text string.
    else:
        text_environ_2 = _TextEn

# Generated at 2022-06-25 13:35:20.042828
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    # In Python3, we want to return the text that was set in __setitem__
    if PY3:
        text_environ_0['bvalue'] = 'This is a bytestring'
        assert text_environ_0['bvalue'] == to_text('This is a bytestring', encoding='utf-8')

    # Otherwise, we'll decode from the raw value stored in os.environ
    else:
        text_environ_0._raw_environ['bvalue'] = to_bytes('This is a bytestring', encoding='utf-8')
        assert text_environ_0['bvalue'] == to_text('This is a bytestring', encoding='utf-8')

    # Unicode values are not changed at all
    text_environ_0

# Generated at 2022-06-25 13:35:21.743512
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0['HOME'] == '/root'


# Generated at 2022-06-25 13:35:24.811528
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Initialize the test environment.
    text_environ_1 = _TextEnviron()

    # Call method __getitem__ of class _TextEnviron with argument 'HOME'.
    text_environ_1.__getitem__('HOME')


# Generated at 2022-06-25 13:35:30.522574
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # If the passed key doesn't exist in environ, raise KeyError
    try:
        print('No such key')
        print(text_environ_0['No such key'])
    except KeyError as err:
        print(err)

    # If the passed key exists in environ, and the value is in ASCII characters, return str object
    print(text_environ_0['PATH'])
    print(type(text_environ_0['PATH']))

    # If the stored value is in non-ASCII characters, raise UnicodeDecodeError
    try:
        print(text_environ_0['LANG'])
    except UnicodeDecodeError as err:
        print(err)


# Generated at 2022-06-25 13:35:35.227463
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # set up the test environment
    text_environ_0 = _TextEnviron()
    try:
        # initiate test
        text_environ_0['foo'] = "bar"
        # assert expected result values
        assert text_environ_0['foo'] == "bar"
    finally:
        # clean up the test environment
        del text_environ_0['foo']

# Generated at 2022-06-25 13:35:37.403736
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert text_environ_1['PATH'] == environ['PATH']


# Generated at 2022-06-25 13:35:38.243683
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # FIXME
    pass


# Generated at 2022-06-25 13:35:40.598776
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Instantiate
    text_environ_0 = _TextEnviron()

    # KeyError
    try:
        result = text_environ_0['hello']
    except KeyError:
        pass


# Generated at 2022-06-25 13:35:44.406013
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError):
        text_environ_0[b'JOB_NAME']
    assert text_environ_0.get(b'JOB_NAME', 'default') == 'default'


# Generated at 2022-06-25 13:35:53.019928
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Test __getitem__ method of class _TextEnviron"""

    # Create a test string in UTF-8 with a non-ASCII character
    test_utf8_string = u'$!@#$%^&*()-=_+[]{}\\|<>,./?~`;\u263a'.encode('utf-8')

    # Create an instance of TextEnviron
    text_environ_1 = _TextEnviron()

    # Load the test string into the instance of TextEnviron
    text_environ_1['test_key'] = test_utf8_string

    # Call __setitem__ and verify that the returned value is a text string
    assert isinstance(text_environ_1['test_key'], text)

    # Verify that the returned value is the original string converted to text
    assert text_environ

# Generated at 2022-06-25 13:36:03.848280
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    ascii_value = 'this is ascii'
    utf8_value = u'\u3053\u308c\u306fUTF8'
    latin1_value = u'\u00e0'
    iso8859_value = u'\u20ac'
    fake_utf8_value = u'\u00e0'

    text_environ_0 = _TextEnviron()
    if PY3:
        # Python 3 -- these should all be native strings in environ
        assert ascii_value == text_environ_0['doesntexist']
        assert utf8_value == text_environ_0['doesntexist']
        assert latin1_value == text_environ_0['doesntexist']

# Generated at 2022-06-25 13:36:10.331578
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Case 0
    # Method __getitem__ runs with the following arguments:
    # key: 'PATH'

    # Expected results:
    # value: '/bin:/usr/bin'

    # Case 0 - run the method with the arguments provided
    result = environ.__getitem__('PATH')

    # Case 0 - check if the actual result is the same as the expected result
    assert result == '/bin:/usr/bin'


# Generated at 2022-06-25 13:36:18.207610
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    unit test for __getitem__ of class _TextEnviron
    """
    # Create test _TextEnviron instance to test __getitem__
    test_TextEnviron = _TextEnviron()

    # check __getitem__ of _TextEnviron
    try:
        assert(test_TextEnviron['existing_item'] == os.environ['existing_item'])
        assert(test_TextEnviron['non_existing_item'] == os.environ['non_existing_item'])
    finally:
        del test_TextEnviron


# Generated at 2022-06-25 13:36:23.812237
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test case for valid key
    assert _TextEnviron()['PATH'] == environ['PATH']
    assert _TextEnviron({'PATH':'/bin:/usr/bin'})['PATH'] == '/bin:/usr/bin'
    # Test case for invalid key
    try:
        _TextEnviron()['DEF_NOT_DEFINED']
    except KeyError as e:
        assert 'DEF_NOT_DEFINED' in str(e)



# Generated at 2022-06-25 13:36:28.495655
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This will be a skitish test.  Since we're overriding the global environ variable, we need to
    # split it up into two tests.  The first one will be run on Python 3 and the second on Python 2
    # On Python 2 we need to ensure that anything set in the environment for the process will not
    # interfere with the test
    environ_orig = dict(environ)

    if PY3:
        test_getitem_python3()
        test_getitem_python2()
    else:
        test_getitem_python2()
        test_getitem_python3()

    environ.clear()
    environ.update(environ_orig)



# Generated at 2022-06-25 13:36:35.115774
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Case 0
    # Unit tests.text_environ_test.test_case_0()
    text_environ_0 = test_case_0()
    # Test of the tuple_to_dict of the _TextEnviron class in the cases:
    # item is not in _raw_environ. Test of the PY3 condition block.
    # Here we expect the value to be returned unchanged.
    __item = '__item'
    # This should be true for this test case
    assert __item not in os.environ
    assert __item not in text_environ_0._raw_environ
    assert __item not in text_environ_0._value_cache
    # If text_environ_0._value_cache[__item] does not exist, the else condition will be executed.
    assert text_environ_0

# Generated at 2022-06-25 13:36:45.042585
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # keys are binary, values are text
    os.environ[b'key1'] = 'value1'
    os.environ[b'key2'] = 'value2'
    te = _TextEnviron()

    assert te['key1'] == 'value1'
    assert te['key2'] == 'value2'

    # keys are binary, values are binary
    os.environ[b'key1'] = b'value1'
    os.environ[b'key2'] = b'value2'
    te = _TextEnviron()

    assert te['key1'] == 'value1'
    assert te['key2'] == 'value2'

    # keys are text, values are binary
    os.environ['key1'] = b'value1'

# Generated at 2022-06-25 13:36:52.311750
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        text_environ_0 = _TextEnviron()
        text_environ_0._raw_environ = {'PATH': 'C:\\My\\Path'}
        assert text_environ_0['PATH'] == 'C:\\My\\Path'
    else:
        text_environ_0 = _TextEnviron()
        text_environ_0._raw_environ = {b'PATH': b'C:\\My\\Path'}
        text_environ_0._value_cache = {}
        assert text_environ_0['PATH'] == 'C:\\My\\Path'


# Generated at 2022-06-25 13:36:58.824024
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Initialize TextEnviron with a fake environment
    text_environ = _TextEnviron(env={b'1': b'value1', b'2': b'value2'})
    # Check that the correct values were returned
    assert text_environ['1'] == u'value1'
    assert text_environ['2'] == u'value2'
    # Check that the text_environ[unicode-key] returned the correct value
    assert text_environ[u'1'] == u'value1'


# Generated at 2022-06-25 13:36:59.810937
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass



# Generated at 2022-06-25 13:37:07.106913
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        text_environ_0.__getitem__('abcdefg')
        # Check whether there are exceptions.
        assert False
    except KeyError as err:
        # Check whether there are exceptions.
        assert type(err) == KeyError



# Generated at 2022-06-25 13:37:08.862072
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # TODO: test should not return None
    assert test_case_0().__getitem__() is None


# Generated at 2022-06-25 13:37:14.316508
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This testcase assumes that the system encoding is not UTF-8
    import sys

    if sys.getfilesystemencoding() == 'UTF-8':
        raise unittest.SkipTest('Test cannot be run when the filesystem encoding is UTF-8')

    with mock.patch.dict(os.environ, {'SOME_VAR': 'hello'}):
        # Use the system encoding for this test
        text_environ = _TextEnviron(encoding=sys.getfilesystemencoding())

        assert text_environ['SOME_VAR'] == u'hello'



# Generated at 2022-06-25 13:37:17.538944
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0._TextEnviron__getitem__('XDG_RUNTIME_DIR')


# Generated at 2022-06-25 13:37:21.409234
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_1 = text_environ_0['PATH']
    # TODO test this
    assert var_1 == None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:37:24.429557
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Test 1
    key = 'key_value_1'
    result = text_environ_0.__getitem__(key)
    assert result == 'value_1'


# Generated at 2022-06-25 13:37:26.192672
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_ = _TextEnviron()
    text_environ_.__getitem__('foo')


# Generated at 2022-06-25 13:37:29.574281
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(None, 'utf-8')
    assert text_environ_0['TERM'] == 'xterm', "__getitem__(self, key): key = 'TERM', expected value = 'xterm', actual value = '%s'" % text_environ_0['TERM']



# Generated at 2022-06-25 13:37:36.060171
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set up test values
    os.environ['TEST_ENV'] = b"This\xc2\xa2is a test."
    test_environ = _TextEnviron(encoding='utf-8')
    assert to_text(os.environ['TEST_ENV']) == test_environ['TEST_ENV']
    # Check that there's no caching for things that aren't in cache
    os.environ['TEST_ENV'] = b'"This was a test.  This is a TROLL"'
    assert to_text(os.environ['TEST_ENV']) == test_environ['TEST_ENV']


# Generated at 2022-06-25 13:37:43.144891
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Check getitem when text is available
    text_environ_0.__setitem__('test_key', 'test_text')
    assert text_environ_0.__getitem__('test_key') == 'test_text'
    # Check getitem when bytes are avaiable
    text_environ_0.__setitem__('test_key', b'test_bytes')
    assert text_environ_0.__getitem__('test_key') == 'test_bytes'


# Generated at 2022-06-25 13:37:53.661478
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Initialize an instance of _TextEnviron class
    text_environ_0 = _TextEnviron()
    # Assert that the value of the key "PATH" of the environ is same as that
    # obtained from the os module's environ attribute when converting to text
    if sys.version_info[0] == 3:
        # On Python3, the value of os.environ is already text
        assert os.environ["PATH"] == text_environ_0["PATH"]
    else:
        # On Python2, the value of os.environ is byte string
        import six
        assert six.text_type(os.environ["PATH"]) == text_environ_0["PATH"]
    # Assert that the value of the key doesn't exist by trying to get the
    # value of the key and checking if the exception raised

# Generated at 2022-06-25 13:37:59.817056
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test for 0 inputs
    environ = _TextEnviron()
    assert(environ['PATH'] == '/usr/bin')
    assert(environ['HOME'] == '/home/user')
    assert(environ['SHELL'] == '/bin/bash')

    # Test for 1 inputs
    environ = _TextEnviron(env={'PATH': '/usr/bin', 'HOME': '/home/user', 'SHELL': '/bin/bash'})
    assert(environ['PATH'] == '/usr/bin')
    assert(environ['HOME'] == '/home/user')
    assert(environ['SHELL'] == '/bin/bash')

    # Test for 2 inputs

# Generated at 2022-06-25 13:38:01.650564
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['foo'] = 'bar'
    assert environ['foo'] == u'bar'

# Generated at 2022-06-25 13:38:04.652576
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0['PATH'] == to_text(text_environ_0._raw_environ['PATH'])

# Generated at 2022-06-25 13:38:08.456562
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Unit test for method __getitem__ of class
    '''
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('TEST_TEXTENVIRON__GETITEM__') == 'textenviron__getitem__'


# Generated at 2022-06-25 13:38:11.802681
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Constructor test
    assert text_environ_0._raw_environ.__class__.__name__ == 'os.environb'
    assert text_environ_0.encoding == 'utf-8'

    # Function test: getitem
    assert to_text(text_environ_0['PWD'], encoding=sys.getfilesystemencoding(),
                   nonstring='passthru', errors='surrogate_or_strict') == os.getcwd()

# Generated at 2022-06-25 13:38:13.432002
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env =  _TextEnviron()
    env["key1"] = "val1"
    assert env["key1"] == "val1"


# Generated at 2022-06-25 13:38:15.904104
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    value_0 = text_environ_0.__getitem__('COLUMNS')
    assert isinstance(value_0, str)
    assert isinstance(value_0, str)


# Generated at 2022-06-25 13:38:17.718693
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    key = (text_environ_0.__getitem__('USERNAME'))
    assert os.environ['USERNAME'] == key


# Generated at 2022-06-25 13:38:22.126047
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()

    if PY3:
        var = 'ANSIBLE_CONFIG'
    else:
        var = b'ANSIBLE_CONFIG'

    # Test no arguments and expected results
    assert text_environ_1.__getitem__(var) == environ[var]

    # Test that all type of arguments values are accepted and that the result is the same as
    # the one obtained with os.environ
    var_list = [var]

    for var in var_list:
        assert text_environ_1.__getitem__(var) == environ[var]


# Generated at 2022-06-25 13:38:29.879816
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    variable_1 = text_environ_1["TEST_VARIABLE_1"]
    variable_2 = text_environ_1["TEST_VARIABLE_2"]


# Generated at 2022-06-25 13:38:33.663417
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        environ['testkey'] = 'testvalue'
        assert environ['testkey'] == 'testvalue'
    else:
        environ['testkey'] = u'testvalue'
        assert environ['testkey'] == u'testvalue'


# Generated at 2022-06-25 13:38:41.489415
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert len(environ._value_cache) == 0
    assert environ['PATH'] == u'/usr/bin:/bin:/usr/sbin:/sbin'
    assert len(environ._value_cache) == 1
    assert environ['HOME'] == u'/home/badger'
    assert len(environ._value_cache) == 2
    assert environ['HOME'] == u'/home/badger'
    assert len(environ._value_cache) == 2
    assert environ['PATH'] == u'/usr/bin:/bin:/usr/sbin:/sbin'
    assert len(environ._value_cache) == 3
    assert environ['falsepositivename'] == u''
    assert len(environ._value_cache) == 4


# Generated at 2022-06-25 13:38:44.495270
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = sys.stdout
    assert text_environ_0 is not None


# Generated at 2022-06-25 13:38:54.202513
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron({'a': 'b'}, 'utf-8')
    assert text_environ_1.encoding == 'utf-8'
    assert text_environ_1['a'] == 'b'
    # Test that we do the correct mapping when we have a unicode value
    text_environ_2 = _TextEnviron({'a': to_text('\u00e9', encoding='utf-8')}, 'utf-8')
    assert text_environ_2['a'] == to_text('\u00e9', encoding='utf-8')
    # Test that we do the correct mapping when we have a byte string value
    text_environ_3 = _TextEnviron({'a': b'\xc3\xa9'}, 'utf-8')
    assert text_en

# Generated at 2022-06-25 13:38:56.115380
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    for key, value in environ.items():
        assert value == text_environ_1[key]


# Generated at 2022-06-25 13:39:01.114407
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    check_function = to_text

# Generated at 2022-06-25 13:39:02.380565
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(environ['PATH'], str)


# Generated at 2022-06-25 13:39:05.889152
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_5 = 'COMSPEC'
    comspec = text_environ_0.__getitem__(var_5)
    # normal exit
    return 0


# Generated at 2022-06-25 13:39:10.601240
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a new environment with a single key
    test_env = {'ANSIBLE_TEST_VAR': 'ANSIBLE_TEST_VAR'}
    text_environ_1 = _TextEnviron(env=test_env)

    # Check that the returned value is correct
    assert text_environ_1['ANSIBLE_TEST_VAR'] == 'ANSIBLE_TEST_VAR'


# Generated at 2022-06-25 13:39:27.746313
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # first test on an ascii environment variable
    text_environ_0.__setitem__(u"PATH", u"/bin:/usr/bin")
    assert text_environ_0.__getitem__(u"PATH") == "/bin:/usr/bin"
    # test on an utf-8 environment variable
    text_environ_0.__setitem__(u"LANG", u"en_US.UTF-8")
    assert text_environ_0.__getitem__(u"LANG") == u"en_US.UTF-8"


# Generated at 2022-06-25 13:39:32.208569
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    a = "a"
    env = dict(a5=5, b=b'b')
    b = "b"
    text_environ_0 = _TextEnviron(env=env)
    text_environ_0[a] = b
    text_environ_0[a]
    assert text_environ_0[a] == b

# Generated at 2022-06-25 13:39:33.753296
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    a = environ['PATH']
    assert type(a) is str

# Generated at 2022-06-25 13:39:34.703708
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()


# Generated at 2022-06-25 13:39:38.460916
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a new instance of the _TextEnviron class
    text_environ_0 = _TextEnviron()
    # Call the __getitem__ method with the appropriate key
    value_0 = text_environ_0.__getitem__('SHELL')
    assert(value_0 == '/bin/bash')


# Generated at 2022-06-25 13:39:40.155667
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    key = 'PATH'
    return_value = text_environ[key]



# Generated at 2022-06-25 13:39:44.580776
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test 1 :
    # Check that os.environ and environ have the same key,value pairs

    # single-byte key
    assert os.environ['PATH'] == environ['PATH']
    # single-byte value
    assert os.environ['PATH'] == environ['PATH']

    # multi-byte key
    assert os.environ['LANG'] == environ['LANG']
    # multi-byte value
    assert os.environ['LANG'] == environ['LANG']


# Generated at 2022-06-25 13:39:52.538526
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert '1' == text_environ_0[to_bytes('0', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')]
    assert '1' == text_environ_0[to_bytes('1', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')]
    assert '1' == text_environ_0[to_bytes('2', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')]
    assert '1' == text_environ_0[to_bytes('3', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')]
    assert '1' == text_en

# Generated at 2022-06-25 13:39:56.687131
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Initializing the object
    text_environ_1 = _TextEnviron()
    # Calling __getitem__ method
    index_value_1 = text_environ_1["ANSIBLE_ROLES_PATH"]

# Instantiate test class
test_case_0()
test__TextEnviron___getitem__()
# Done testing

# Generated at 2022-06-25 13:39:58.176825
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()


test_case_0()

# Generated at 2022-06-25 13:40:22.978647
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0._raw_environ = {'a': 'b'}
    retval1 = text_environ_0.__getitem__('a')
    assert (retval1 == 'b')


# Generated at 2022-06-25 13:40:32.267663
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Imports:
    from os import environ
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    if PY2:
        # Imports:
        from os import environb
    # Code:
    text_environ_0 = _TextEnviron(encoding='utf-8')
    # Test _TextEnviron.__getitem__()
    # Test getting a value that is not in the cache:

# Generated at 2022-06-25 13:40:36.080678
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global environ
    assert isinstance(environ, _TextEnviron)
    assert environ == os.environ
    assert environ['PATH'] == os.environ['PATH']
    assert environ.__class__.__name__ == '_TextEnviron'
    assert environ['PATH'].__class__.__name__ == 'str'


# Generated at 2022-06-25 13:40:39.823461
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = {'PY_TEST_ENV': 'PY_TEST_HELLO_WORLD_ENV'}
    text_environ = _TextEnviron(env=env)
    assert text_environ['PY_TEST_ENV'] == 'PY_TEST_HELLO_WORLD_ENV'


# Generated at 2022-06-25 13:40:44.194191
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Tests that we get the correct text back from a value when we're on PY3
    text_environ_0 = _TextEnviron()
    key = 'HOME'
    value = text_environ_0[key]
    if value != environ[key]:
        raise AssertionError("expected '%s', received '%s'" % (environ[key], value))


# Generated at 2022-06-25 13:40:45.314498
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()


# Generated at 2022-06-25 13:40:50.447453
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Init the class
    environ = _TextEnviron()

    # Test the return type of the method
    assert isinstance(environ.__getitem__("HOME"), unicode)

    # Test the return type of the method
    assert isinstance(environ.__getitem__("PATH"), unicode)

    # Test the return type of the method
    assert isinstance(environ.__getitem__("PWD"), unicode)



# Generated at 2022-06-25 13:40:57.094733
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Ensure that we can get an item from our Environ instance
    """
    env = _TextEnviron()
    assert 'PYTHONIOENCODING' in env
    # Default should use utf8
    assert to_text(os.environ['PYTHONIOENCODING'], encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict') == env['PYTHONIOENCODING']
    # Should be able to specify a different encoding
    latin1_env = _TextEnviron(encoding='latin-1')

# Generated at 2022-06-25 13:41:07.574749
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_1 = text_environ_0.__getitem__('HOME')
    assert '/Users/toshio', var_1

    text_environ_1 = _TextEnviron()
    var_2 = text_environ_1.__getitem__('PYTHONIOENCODING')
    assert 'utf-8', var_2

    text_environ_2 = _TextEnviron()
    var_3 = text_environ_2.__getitem__('PYTHONPATH')
    assert '', var_3

    text_environ_3 = _TextEnviron()
    var_4 = text_environ_3.__getitem__('VERSIONER_PYTHON_PREFER_32_BIT')
    assert 'no', var_

# Generated at 2022-06-25 13:41:11.691121
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert False, 'Test not valid on py3'

    text_environ_0 = _TextEnviron({b'key_0': b'val_0'})
    assert text_environ_0['key_0'] == u'val_0'


# Generated at 2022-06-25 13:41:56.041615
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Call _TextEnviron.__getitem__ with argument '__name__'
    # Call _TextEnviron.__getitem__ with argument '__file__'
    # Call _TextEnviron.__getitem__ with argument '__doc__'
    pass # TODO



# Generated at 2022-06-25 13:41:59.071497
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert ('LC_COLLATE' in _TextEnviron()), 'If key is in the environment, __getitem__ should return true'
    assert ('foo' not in _TextEnviron()), 'If key is not in the environment, __getitem__ should return false'


# Generated at 2022-06-25 13:42:06.505725
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import PY3
    text_environ_0 = _TextEnviron()
    # test __getitem__, PY3 environment, UTF-8 text
    var_name = 'RÉALIZATION_ENCODÉ'
    var_value = 'ÉLÉMENTS IMPORTANTS'
    os.environ[var_name] = var_value
    assert text_environ_0[var_name] == var_value, "Failed to decode text in a Py3 environment"
    del os.environ[var_name]

    # test __getitem__, PY2 environment, UTF-8 text
    if not PY3:
        var_name = 'RÉALIZATION_ENCODÉ'
        var_value = 'ÉLÉMENTS IMPORTANTS'
        os

# Generated at 2022-06-25 13:42:11.099523
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = os.environ
    te = _TextEnviron(env)
    report = ''
    for key, value in env.items():
        if isinstance(value, bytes):
            expected = value.decode('utf-8')
        else:
            expected = value
        result = te.__getitem__(key)
        if result != expected:
            report += "%s: expected %s, got %s\n" % (key, expected, result)
    assert not report, report
        


# Generated at 2022-06-25 13:42:15.998174
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Check that the value is properly decoded
    # NOTE: This check will only be done on Python 2
    if not PY3:
        encoding = 'utf-8'
        test_key = u'TEST_KEY'
        test_value = u'TEST_VALUE'
        raw_environ = {test_key: to_bytes(test_value, encoding=encoding)}
        text_environ = _TextEnviron(raw_environ, encoding=encoding)
        assert test_value == text_environ[test_key]


# Generated at 2022-06-25 13:42:17.455037
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
        text_environ = _TextEnviron()
        assert text_environ.__getitem__('user') == 'root'


# Generated at 2022-06-25 13:42:19.258433
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        path = text_environ_0['PATH']
    except:
        path= None
    assert path is not None



# Generated at 2022-06-25 13:42:21.413832
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    text_environ = _TextEnviron()
    for key, value in environ._raw_environ.items():
        assert text_environ[key] == value.decode('utf-8', 'surrogate_or_strict')


# Generated at 2022-06-25 13:42:22.314188
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()


# Generated at 2022-06-25 13:42:25.806957
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['LC_ALL'] = "C"
    assert type(text_environ_0['LC_ALL']) is str
    if __name__ == '__main__':
        text_environ_0['LC_ALL'] = "C"
        assert type(text_environ_0['LC_ALL']) is str

# Generated at 2022-06-25 13:44:08.808181
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('NULL') == 'None'

# Generated at 2022-06-25 13:44:16.411443
# Unit test for method __getitem__ of class _TextEnviron