

# Generated at 2022-06-25 13:34:25.963489
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0['SHELL'] == '/bin/bash'

# Generated at 2022-06-25 13:34:31.235710
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup: Testing getting an item from the environment which is unicode in Python 2
    text_environ_0 = _TextEnviron()
    keys_0 = ('SHELL',)
    unicode_text_0 = text_environ_0.__getitem__(keys_0)
    # Test: `unicode_text_0` is expected to be a unicode string
    assert(isinstance(unicode_text_0, unicode))


# Generated at 2022-06-25 13:34:32.368805
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['PATH']
    environ['LANG']


# Generated at 2022-06-25 13:34:34.281087
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    result = text_environ.__getitem__('')



# Generated at 2022-06-25 13:34:45.855433
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test case 0
    text_environ_0 = _TextEnviron()
    k = "key"
    assert text_environ_0.__getitem__(k) is None, "did not handle default value correctly"
    # Test case 1
    text_environ_1 = _TextEnviron({'yes': 'yes', 'no': 'no'})
    k = "yes"
    assert text_environ_1.__getitem__(k) == 'yes', "did not handle dictionary values correctly"
    # Test case 2
    text_environ_2 = _TextEnviron({'yes': 'yes', 'no': 'no'})
    k = "no"
    assert text_environ_2.__getitem__(k) == 'no', "did not handle dictionary values correctly"
    # Test case 3


# Generated at 2022-06-25 13:34:51.152707
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Augment text_environ_0 with the key 'foo' and the corresponding value 'bar'
    text_environ_0 = _TextEnviron()
    text_environ_0['foo'] = 'bar'
    # Validate that the entry added to text_environ_0 has the text type
    assert(type(text_environ_0['foo']) == str)


# Generated at 2022-06-25 13:34:55.726046
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        text_environ_0.__getitem__(str())
        assert False
    except KeyError:
        pass
    try:
        text_environ_0.__getitem__(str())
        assert False
    except KeyError:
        pass


# Generated at 2022-06-25 13:35:00.085028
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print("Testing method __getitem__ of _TextEnviron")
    text_environ_0 = _TextEnviron()
    try:
        if (type(text_environ_0) == type(dict())):
            # TypeError raised
            print("\tException raised - ", "TypeError")
        else:
            pass

    except TypeError as exception:
        print("\tException raised - ", type(exception).__name__)


# Generated at 2022-06-25 13:35:03.129382
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_1 = text_environ_0['PATH']
    assert str_1 == os.environ['PATH']


# Generated at 2022-06-25 13:35:12.173696
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # array of values for testing.
    # The default value of the variable 'key' is set to 'NOCODE' that is a string.
    values = [u'NOCODE',
              u'UTF-8',
              u'ISO-8859-1',
              u'ASCII'
              ]
    # initialize key variable
    key = 'LANG'
    # initialize environ variable
    environ = _TextEnviron(env=None)
    # initialize lang variable
    lang = []
    # set the default lang to utf-8
    lang = u'UTF-8'
    # set the environment variable LANG to utf-8
    environ.__setitem__(key, lang)
    # fetch the value of LANG from environment
    lang = environ.__getitem__(key)
    # check the

# Generated at 2022-06-25 13:35:21.155721
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['foo'] = to_bytes('bar', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    assert isinstance(text_environ_0['foo'], str)
    text_environ_1 = _TextEnviron(env={'spam': to_bytes('eggs', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')})
    assert isinstance(text_environ_1['spam'], str)
    text_environ_2 = _TextEnviron(env={'spam': 'eggs'})
    assert isinstance(text_environ_2['spam'], str)



# Generated at 2022-06-25 13:35:22.920631
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__('TEST')
    assert result == None


# Generated at 2022-06-25 13:35:30.385551
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an instance of a private class
    text_environ_0 = _TextEnviron()
    # Set an attribute value
    text_environ_0.encoding = 'utf-8'
    # Create an instance of a private class
    text_environ_1 = _TextEnviron()
    # Set an attribute value
    text_environ_1.encoding = 'utf-8'
    # Create an instance of a private class
    text_environ_2 = _TextEnviron()
    # Set an attribute value
    text_environ_2.encoding = 'utf-8'
    # Create an instance of a private class
    text_environ_3 = _TextEnviron()
    # Set an attribute value
    text_environ_3.encoding = 'utf-8'
    # Create an instance of a

# Generated at 2022-06-25 13:35:32.784108
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that we can get a text string from the environment
    assert isinstance(environ['PATH'], str), "Failed to get a text string for an environment variable"


# Generated at 2022-06-25 13:35:41.852707
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    text_environ_0 = _TextEnviron()
    text_environ_1 = _TextEnviron()
    text_environ_2 = _TextEnviron()

    # Call method __getitem__ and verify the outcome.
    # Note: This assumes that the system has a locale known by Python's locale module and that the
    # system has a set of environment variables which it can decode using this locale.  One way to
    # test this condition is to set up the system to have a single environment variable with
    # randomly generated values.  This is a pretty weak test for an API operating on the environment
    # but it's the best we can do at the moment.
    the_key = text_environ_0.__iter__().__next__()
    assert text_environ_0.__getitem__(the_key) == os.environ

# Generated at 2022-06-25 13:35:50.882868
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Environ strings when they're stored without an encoding
    assert text_environ_0.__getitem__("SSH_AUTH_SOCK").__str__() == '/run/user/1000/keyring/ssh'
    assert text_environ_0.__getitem__("SESSION_MANAGER").__str__() == 'local/unix:@/tmp/.ICE-unix/1352,unix/unix:/tmp/.ICE-unix/1352'
    assert text_environ_0.__getitem__("SHELL").__str__() == '/bin/bash'

# Generated at 2022-06-25 13:35:53.237087
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result_bool_1 = text_environ_0.__getitem__('USER')
    assert result_bool_1 == "root"


# Generated at 2022-06-25 13:35:56.633259
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(encoding='utf-8')
    # This test would be more useful if we could change the environment variables.
    # Trying to figure that out.
    if 'LANG' in os.environ:
        assert 'UTF-8' == text_environ_0.__getitem__('LANG')[-5:]
        

# Generated at 2022-06-25 13:36:02.250867
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    expected = 'not-yet-set'
    assert text_environ_0['ANSIBLE_TEST_KEY'] == expected

    os.environ['ANSIBLE_TEST_KEY'] = 'baz'
    expected = 'baz'
    assert text_environ_0['ANSIBLE_TEST_KEY'] == expected


# Generated at 2022-06-25 13:36:04.833591
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    if PY3:
        assert text_environ is not None
    else:
        assert text_environ is not None



# Generated at 2022-06-25 13:36:13.099060
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    text_environ_0 = _TextEnviron()
    key = 'RVGYxS1nH7lMA8dfP'

    # Testing
    # Test 1 - start
    text_environ_0[key] = 'oQPzsW'
    # Test 1 - end
    # Test 2 - start
    text_environ_0.pop(key)
    # Test 2 - end


# Generated at 2022-06-25 13:36:16.997255
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1.__getitem__('set_from_env')
    text_environ_1.__getitem__('get_from_env')


# Generated at 2022-06-25 13:36:19.406681
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['LANG'] = 'en_US.UTF-8'
    assert environ['LANG'] == 'en_US.UTF-8'


# Generated at 2022-06-25 13:36:22.458714
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert text_environ_0.__getitem__('PYTHONPATH') == ':'
    assert text_environ_0.__getitem__('VIRTUAL_ENV').find('find-me') > -1


# Generated at 2022-06-25 13:36:24.513313
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    # Test for a key that does not exist
    text_environ_0['ANSIBLE_MUTANT_HUGS']

    # Test for a key that does exist
    text_environ_0['ANSIBLE_CALLBACK_PLUGINS']



# Generated at 2022-06-25 13:36:28.501066
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create object
    text_environ_0 = _TextEnviron()
    # Call method __getitem__
    text_environ_0__getitem___return_value = text_environ_0.__getitem__('LC_MONETARY')
    print('Return value:', text_environ_0__getitem___return_value)


# Generated at 2022-06-25 13:36:30.181456
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__('HOME')
    return result


# Generated at 2022-06-25 13:36:31.832850
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert (environ['USER'] == 'Autotest')
    assert (environ['LANG'] == 'en_US.utf8')


# Generated at 2022-06-25 13:36:34.413834
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert to_text(environ['PATH'], encoding='utf-8', nonstring='passthru',
                       errors='surrogate_or_strict') == environ['PATH']


# Generated at 2022-06-25 13:36:44.102930
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test Python3 and default b'' bytes
    environ = _TextEnviron()
    os.environ['ANSIBLE_TEST_BYTES_0'] = b'\xc3\xbcnic\xc3\xb4de'
    assert environ['ANSIBLE_TEST_BYTES_0'] == u'\u00fcnic\u00f4de'

    # Test Python2 and default b''
    environ = _TextEnviron()
    os.environ['ANSIBLE_TEST_BYTES_1'] = b'\xc3\xbcnic\xc3\xb4de'
    assert environ['ANSIBLE_TEST_BYTES_1'] == u'\u00fcnic\u00f4de'

    # Test Python2 and default b'' with surrogate
    environ = _Text

# Generated at 2022-06-25 13:36:48.173510
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert True  # TODO: implement your test here


# Generated at 2022-06-25 13:36:49.816721
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['PATH']


# Generated at 2022-06-25 13:36:50.695106
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()


# Generated at 2022-06-25 13:36:52.512059
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0['PATH'] == environ['PATH']


# Generated at 2022-06-25 13:36:55.478537
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        assert 'pwd' in text_environ_0
    except AssertionError:
        print("Wrong __getitem__() method")

test_case_0()
test__TextEnviron___getitem__()

# Generated at 2022-06-25 13:37:02.797433
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print("Testing __getitem__ of _TextEnviron")
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__("") == ""
    assert text_environ_0.__getitem__("") == ""
    assert text_environ_0.__getitem__("") == ""
    assert text_environ_0.__getitem__("") == ""
    assert text_environ_0.__getitem__("") == ""


# Generated at 2022-06-25 13:37:08.905688
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Return value from the environment as a text string

    As much as possible, return from the cache.
    """
    text_environ_0 = _TextEnviron()
    var_key = 'ttt'
    var_value = '$'
    text_environ_0[var_key] = var_value

    val = text_environ_0[var_key]
    assert val == b'$', "Expected '$' got '{}'".format(val)

# Generated at 2022-06-25 13:37:11.104782
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert ('ANSIBLE_ANSIBLE_MODULE_UTILS' == _TextEnviron()['ANSIBLE_ANSIBLE_MODULE_UTILS']), 'getitem method returns wrong value'


# Generated at 2022-06-25 13:37:14.569194
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test 1
    raw_environ = {}
    text_environ = _TextEnviron(env=raw_environ)

    # Test 2
    raw_environ = None
    text_environ = _TextEnviron(env=raw_environ)


# Generated at 2022-06-25 13:37:20.069154
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__setitem__("PYTHONPATH", "/usr/local/lib64/python2.7/site-packages")
    assert text_environ_0.__getitem__("PYTHONPATH") == "/usr/local/lib64/python2.7/site-packages"


# Generated at 2022-06-25 13:37:27.520685
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    result = text_environ_1.__getitem__("SHELL")
    assert result == "/bin/sh"


# Generated at 2022-06-25 13:37:35.008925
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['test_0'] = u'\u3d9b\u1eff\u7f54\u6052\u7a79\u039d\u2cf3\u598f\u2c46\ud8e8\u0d7b\u07f6\uee8f\u00c9\u30b9\u5d43\u1eb1\u5929\u6e5d\ua66e\u9f20\u4a4d\u2cd3\u5eaf\u1c02'

# Generated at 2022-06-25 13:37:44.538191
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # TODO: It might be a good idea to randomize the tests or perform them in a different order
    # in each run.  For instance right now 'PATH' is always the first test

    # Testing when key is 'PATH'
    # NOTE: For this test, make sure that os.environ['PATH'] has a unicode character
    os_environ_0 = os.environ
    assert isinstance(os_environ_0, MutableMapping)
    assert 'PATH' in os_environ_0
    os_environ_1 = 'PATH'
    # Call function __getitem__ of class _TextEnviron with args (os_environ_0, os_environ_1)
    # NOTE: os_environ_0['PATH'] is always a string in Python3, so we get the string from os.environ
   

# Generated at 2022-06-25 13:37:48.323177
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['LC_ALL'] = 'foobar'
    assert text_environ_0['LC_ALL'] == u'foobar'
    del(text_environ_0['LC_ALL'])


# Generated at 2022-06-25 13:37:53.302663
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an instance of _TextEnviron
    text_environ_0 = _TextEnviron()

    # Assigning a to text_environ_0['A']
    text_environ_0['A'] = 'a'

    # Call method __getitem__ of text_environ_0
    # Example: text_environ_0.__getitem__('A')
    text_environ_0.__getitem__('A')


# Generated at 2022-06-25 13:37:54.310889
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-25 13:37:56.674326
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    if PY3:
        assert isinstance(environ['PATH'], str)
    else:
        assert isinstance(environ['PATH'], unicode)


# Generated at 2022-06-25 13:37:58.483123
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    result = environ['HOME']
    int_result = isinstance(result, six.text_type)
    assert int_result is True


# Generated at 2022-06-25 13:38:00.779099
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    _text_environ_0 = _TextEnviron()
    _text_environ_0.__getitem__(None)



# Generated at 2022-06-25 13:38:10.221195
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:38:28.912667
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # value is not a str, None or an instance of unicode
    with pytest.raises(Exception):
        text_environ_0.__getitem__(0)
    # value is a str
    with pytest.raises(Exception):
        text_environ_0.__getitem__('1')
    # value is None
    with pytest.raises(Exception):
        text_environ_0.__getitem__(None)
    # value is an instance of unicode
    with pytest.raises(Exception):
        text_environ_0.__getitem__(u'2')


# Generated at 2022-06-25 13:38:37.639554
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    __setitem__0 = 'PYTHONPATH'
    text_environ_0.__setitem__(__setitem__0, '/usr/share/ansible:/usr/lib/python3.6/site-packages')
    __setitem__1 = 'ANSIBLE_MODULE_UTILS'
    text_environ_0.__setitem__(__setitem__1, '/usr/share/ansible/plugins/module_utils')
    __setitem__2 = 'LANG'
    text_environ_0.__setitem__(__setitem__2, 'en_US.UTF-8')
    __setitem__3 = 'PYTHONIOENCODING'

# Generated at 2022-06-25 13:38:40.411218
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Behavior tests for __getitem__
    """
    environ['PYTHONIOENCODING'] = 'utf-8'

    assert environ['PYTHONIOENCODING'] == 'utf-8'

# Generated at 2022-06-25 13:38:48.225976
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert(text_environ_1.__getitem__('PATH') == 'c:\\users\\name\\appdata\\local\\programs\\python\\python36-32\\python.exe')
    assert(text_environ_1.__getitem__('LANG') == 'en_US.UTF-8')
    assert(text_environ_1.__getitem__('PROXY') == 'http_proxy=http://user:pass@proxy.com:3128')


# Generated at 2022-06-25 13:38:49.507590
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()

test__TextEnviron___getitem__()

# Generated at 2022-06-25 13:38:57.569964
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test when key is non-existent
    text_environ_1 = _TextEnviron()
    assert not text_environ_1.__getitem__(__random_key__)

    # Test when key has a value that is valid on Python2
    # noinspection SpellCheckingInspection
    os.environ[__random_key__] = 'föó'
    text_environ_2 = _TextEnviron()
    assert text_environ_2.__getitem__(__random_key__) == 'föó'

    # Test when key has a value that is invalid on Python2
    os.environ[__random_key__] = b'\xff'
    text_environ_3 = _TextEnviron()

# Generated at 2022-06-25 13:39:07.945409
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # posix locale and utf-8 encoding
    environ['LANG'] = 'en_US.UTF-8'
    assert environ['LANG'] == 'en_US.UTF-8'

    # non-utf-8 encoding
    environ['LANG'] = 'en_US.ISO8859-1'
    assert environ['LANG'] == 'en_US.ISO8859-1'

    # non-ascii utf-8 encoding
    environ['LANG'] = 'en_US.UTF-8'
    environ['TEST_UTF8'] = u'\u00C6'
    assert environ['TEST_UTF8'] == u'\u00C6'

    # non-ascii non-utf-8 encoding

# Generated at 2022-06-25 13:39:13.741572
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Verify that we get a string back when the environment variable's value cannot be
    # decoded
    os.environ[to_bytes('decode_fail', encoding='ascii')] = to_bytes('\xff', encoding='ascii')
    text_environ = _TextEnviron()
    assert to_text(text_environ.__getitem__(to_text('decode_fail', encoding='ascii')),
                   encoding='ascii') == '\xff'


# Generated at 2022-06-25 13:39:15.235351
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global environ
    text_environ = _TextEnviron()
    x =  text_environ['PATH']

# Generated at 2022-06-25 13:39:22.056721
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    testenv = _TextEnviron({b'foo': b'bar', u'foou': u'b\xe9ar', 'foob': None})
    assert isinstance(testenv[b'foo'], six.text_type)
    assert isinstance(testenv['foo'], six.text_type)
    assert testenv[b'foo'] == u'bar'
    assert testenv['foo'] == u'bar'
    assert testenv[u'foou'] == u'b\xe9ar'
    #assert testenv['foob'] is None
    assert testenv['foob'] == u''
    assert testenv[u'ss1s'] == u''
    assert testenv['ss1s'] == u''
    assert testenv[u'fo'] == u''
    assert testenv['fo'] == u''


# Generated at 2022-06-25 13:39:52.639078
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()

    if PY3:
        text_environ_2 = _TextEnviron()
        with pytest.raises(KeyError):
            text_environ_2.__getitem__('ANSIBLE_PLUGINS_GATEWAY_SOCKET')

        ansible_plugins_gateway_socket = text_environ_1.__getitem__('ANSIBL_PLUGINS_GATEWAY_SOCKET')
        assert isinstance(ansible_plugins_gateway_socket, str)
    else:
        ansible_plugins_gateway_socket = text_environ_1.__getitem__('ANSIBL_PLUGINS_GATEWAY_SOCKET')
        assert isinstance(ansible_plugins_gateway_socket, unicode)


#

# Generated at 2022-06-25 13:39:55.482313
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup requirements
    text_environ_0 = _TextEnviron()

    for key, value in environ.items():
        assert(text_environ_0[key] == value)


# Generated at 2022-06-25 13:40:04.345619
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print("test__TextEnviron___getitem__(): START")

    # import needed classes from python modules
    from ansible.module_utils.common._collections_compat import MutableMapping

    # initialize vars
    text_environ_0 = None
    int_0 = None
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    str_5 = None
    str_6 = None
    str_7 = None
    str_8 = None
    str_9 = None
    str_10 = None
    str_11 = None
    str_12 = None
    str_13 = None
    str_14 = None
    str_15 = None
    str_16 = None
    str_17 = None
    str_

# Generated at 2022-06-25 13:40:06.234911
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == u'/root' or environ['HOME'] == u'C:\\Users\\Administrator'


# Generated at 2022-06-25 13:40:11.465136
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Testing with a valid input
    os.environ['test'] = 'test_value'
    text_environ_1 = _TextEnviron()
    assert text_environ_1.__getitem__('test') == 'test_value'
    # Testing with a non-existent input
    try:
        text_environ_1.__getitem__('non_existent')
        assert False
    except KeyError:
        # KeyError: Should be raised in case the input dictionary doesn't have the key
        assert True


# Generated at 2022-06-25 13:40:13.836613
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''Tests _TextEnviron.__getitem__'''
    # Test that the environ module gets the environment variable as bytes
    assert isinstance(environ['LANG'], str)
    assert os.environ['LANG'] == environ['LANG']


# Generated at 2022-06-25 13:40:16.695604
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError):
        text_environ_0.__getitem__('RAW_ENVIRON')


# Generated at 2022-06-25 13:40:23.464107
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['LANG'] = 'en_US.utf8'
    text_environ_0['TREE'] = ['pine', 'oak']
    
    result = text_environ_0['LANG']
    assert result == 'en_US.utf8', "'LANG' is not equal to 'en_US.utf8'"
    
    result = text_environ_0['TREE']
    assert result == ['pine', 'oak'], "'TREE' is not equal to ['pine', 'oak']"
    


# Generated at 2022-06-25 13:40:32.673932
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Initialize environment variables (in a thread safe manner)
    os.environ['LANG'] = 'en_US.utf8'
    os.environ['greeting'] = 'Hi'

    # Iterate through all the environment variables and then check if their values are
    # unicode strings in PY3
    for key in os.environ:
        value = os.environ[key]
        if PY3:
            try:
                _ = value.encode('utf-8')
            except UnicodeError:
                assert False, 'Environment variable value should be unicode string'
        else:
            assert isinstance(value, str)
            try:
                _ = value.encode('utf-8')
            except UnicodeError:
                assert False, 'Environment variable value should be UTF-8 encoded byte string'

# Unit

# Generated at 2022-06-25 13:40:35.371778
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0['HOME'] == os.environ['HOME']
    assert text_environ_0['HOME'] == environ['HOME']


# Generated at 2022-06-25 13:41:26.014481
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PYTHONPATH'] == '/Users/toshio/Projects/ansible-tox-support'


# Generated at 2022-06-25 13:41:34.390658
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0['HOME']
    text_environ_0['HOME'] = str_0
    str_0 = text_environ_0['SHELL']
    text_environ_0['SHELL'] = str_0
    str_0 = text_environ_0['USER']
    text_environ_0['USER'] = str_0
    str_0 = text_environ_0['SHELL']
    text_environ_0['SHELL'] = str_0
    str_0 = text_environ_0['LANG']
    text_environ_0['LANG'] = str_0
    str_0 = text_environ_0['SHELL']
    text_environ_0['SHELL'] = str

# Generated at 2022-06-25 13:41:35.563129
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    key = "PATH"
    value = text_environ[key]
    assert value is not None


# Generated at 2022-06-25 13:41:36.653481
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert text_environ_1['SHELL'] == environ['SHELL']

# Generated at 2022-06-25 13:41:46.712566
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Note: this should be a docstring, not a comment
    # _TextEnviron.__getitem__(key) -> Text

    # The conversion to text strings was already tested by test_case_0,
    # now we test that the caching of decoded values works
    text_environ_0 = _TextEnviron({b'ANSIBLE_PYTHON_INTERPRETER': '/usr/bin/python'})
    text_environ_0[b'ANSIBLE_PYTHON_INTERPRETER'] = u'/usr/bin/python3'
    assert text_environ_0['ANSIBLE_PYTHON_INTERPRETER'] == u'/usr/bin/python'
    assert text_environ_0[b'ANSIBLE_PYTHON_INTERPRETER'] == u'/usr/bin/python3'




# Generated at 2022-06-25 13:41:48.641559
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    assert text_environ['__getitem__'] == 'test_case_0()'


# Generated at 2022-06-25 13:41:56.758653
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an instance of _TextEnviron
    # Use "test_case_0" instance of _TextEnviron
    # Create a test value of "key"
    test_key_0 = "test_value_0"
    # Store a copy of the existing value of "key" in the environment variable
    existing_key_0 = os.environ["HOME"]
    # Set the environment variable "key" to "test_value_0"
    os.environ["HOME"] = test_key_0

# Generated at 2022-06-25 13:41:59.014970
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create instance of class
    text_environ_0 = _TextEnviron()
    # Get data from instance
    assert text_environ_0.__getitem__(None) == None


# Generated at 2022-06-25 13:42:03.163144
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    arg_0 = 'test'  # type: str
    # begin(ansible.module_utils.six._TextEnviron)
    if PY3:
        return os.environ[arg_0]  # type: str
    return to_text(os.environ[arg_0])  # type: str


# Generated at 2022-06-25 13:42:10.342579
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    new_environ = {'LANG': 'en_US.UTF-8',
                   'PATH': '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
                   'GPG_KEY': b'\xc3\xbc'}
    text_environ_0 = _TextEnviron(new_environ)
    assert text_environ_0['LANG'] == 'en_US.UTF-8'
    assert text_environ_0['PATH'] == '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    assert text_environ_0['GPG_KEY'] == '\xfc'

#Unit test for method __setitem__ of class _TextEnviron

# Generated at 2022-06-25 13:44:18.019800
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a simple key, value pair and no py3compat
    os.environ['test_foo'] = 'bar'
    text_environ_0 = _TextEnviron()
    assert text_environ_0['test_foo'] == 'bar'

    # Test with unicode
    os.environ['test_foo'] = u'\u1234'
    assert text_environ_0['test_foo'] == u'\u1234'
    assert u'\u1234' == text_environ_0['test_foo']

    # Test with unicode and nonutf-8 encoding
    text_environ_1 = _TextEnviron(encoding='utf-32')
    assert text_environ_1['test_foo'] == u'\u1234'

    # Test with a changing value
   