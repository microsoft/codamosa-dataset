

# Generated at 2022-06-25 13:34:18.624866
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    #
    # Test getitem method of class _TextEnviron
    #
    # Test with no arguments
    #
    try:
        text_environ_0.__getitem__()
    except TypeError:
        print("Expected failure setting no args")


# Generated at 2022-06-25 13:34:20.662862
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert isinstance(text_environ_0.__getitem__('_'), str)

# Generated at 2022-06-25 13:34:24.595070
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(env={'1': '1', '2': '2'})
    if text_environ_0['1'] != '1':
        raise Exception("return value is not string")



# Generated at 2022-06-25 13:34:29.352968
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with bytes as input
    os.environ[b'TEST_KEY'] = 'test value'
    environ_0 = _TextEnviron()
    result = environ_0.__getitem__('TEST_KEY')
    assert type(result) == type(b'a')
    assert result == b'test value'
    del os.environ[b'TEST_KEY']


# Generated at 2022-06-25 13:34:31.539381
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron()
    key = 'PATH'
    assert(type(e[key]) == str)


# Generated at 2022-06-25 13:34:41.238213
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # setup
    text_environ_0 = _TextEnviron()

    # execution
    try:
        if PY3:
            text_environ_0[to_bytes('', 'ascii')]
        else:
            text_environ_0[to_bytes('', 'ascii')]
    except UnicodeDecodeError as exception:
        if (str(exception)) != '\'utf-8\' codec can\'t decode byte 0x00 in position 0: invalid start byte':
            raise AssertionError(str(exception))

    # verification
    assert text_environ_0[to_bytes('', 'ascii')] == ''


# Generated at 2022-06-25 13:34:50.139217
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print('Testing __getitem__ of _TextEnviron\n')
    # Test 1
    try:
        os.putenv('foo', 'bar')
    except:
        print('FAILED TO ADD ENVIRONMENT VARIABLE')
    if environ['foo'] == 'bar':
        print('Test Passed')
    else:
        print('Test Failed')
    # Test 2
    try:
        os.putenv('foo_2', 'bar_2')
    except:
        print('FAILED TO ADD ENVIRONMENT VARIABLE')
    if environ['foo_2'] == 'bar_2':
        print('Test Passed')
    else:
        print('Test Failed')



# Generated at 2022-06-25 13:34:59.130125
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Verify __getitem__ returns the string
    assert text_environ_0['PWD'] == os.environ['PWD']
    text_environ_1 = _TextEnviron(encoding='iso-8859-15')
    # Verify __getitem__ returns the string
    assert text_environ_1['PWD'] == os.environ['PWD']
    # Verify __getitem__ with non-ascii returns the string
    assert text_environ_1['ANSIBLE_TEST_ENV'] == os.environ['ANSIBLE_TEST_ENV']
    text_environ_2 = _TextEnviron()
    # Verify __getitem__ returns the string

# Generated at 2022-06-25 13:35:05.336612
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Init a _TextEnviron object
    text_environ_1 = _TextEnviron()
    res = text_environ_1["PATH"]
    assert res == u"/home/user/centos7/lib/python2.7/site-packages/ansible/modules:/home/user/anaconda3/bin:/home/user/anaconda3/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin"

# Generated at 2022-06-25 13:35:12.698441
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Arrange
    non_utf8_string = u'\xa3'.encode('iso-8859-1')

    # Act
    try:
        # Should raise UnicodeDecodeError on PY2
        if not PY3:
            raise AssertionError(non_utf8_string.decode('utf-8'))
        text_environ_0 = _TextEnviron({'some_key': non_utf8_string})
        result = text_environ_0['some_key']
    except UnicodeDecodeError:
        result = None

    # Assert
    assert result is not None


# Generated at 2022-06-25 13:35:19.999939
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    # Unit test for method __getitem__ (1 of 2) of class _TextEnviron
    # 'key' is undefined/doesn't exist
    text_environ_getitem__value_7 = text_environ.__getitem__('key')
    assert text_environ_getitem__value_7 is not None
    # Unit test for method __getitem__ (2 of 2) of class _TextEnviron
    text_environ_getitem__value_8 = text_environ.__getitem__('PATH')
    assert text_environ_getitem__value_8 is not None


# Generated at 2022-06-25 13:35:26.766442
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Each call to __getitem__ returns the same object which can be changed by calling __setitem__
    assert text_environ_0.__getitem__('HOME') == os.environ['HOME']
    assert text_environ_0.__getitem__('HOME') == text_environ_0.__getitem__('HOME')
    text_environ_0.__setitem__('HOME', "/root")
    text_environ_0.__setitem__('HOME', "/root")
    assert text_environ_0.__getitem__('HOME') == "/root"
    assert text_environ_0.__getitem__('HOME') == os.environ['HOME']

# Generated at 2022-06-25 13:35:31.089999
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_1 = to_text(text_environ_0.__getitem__("ANSIBLE_REMOTE_TEMP"))
    assert var_1 == os.environ[to_bytes("ANSIBLE_REMOTE_TEMP", encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')]


# Generated at 2022-06-25 13:35:32.718740
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # AssertionError: 'SHELL'
    assert text_environ_0['SHELL'] != 'SHELL'



# Generated at 2022-06-25 13:35:37.557879
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.get('__name__', None) is None
    assert text_environ_0['__name__'] == 'ansible.module_utils.six'
    assert text_environ_0['__name__'] == 'ansible.module_utils.six'


# Generated at 2022-06-25 13:35:38.703533
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == os.environ['PATH']


# Generated at 2022-06-25 13:35:47.797837
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    # Testing key 0
    key_0_0 = b'GIT_ASKPASS'
    value_0_0 = text_environ_1.__getitem__(key_0_0)
    if PY3:
        expected_value_0_0 = os.environ[key_0_0]
        assert(value_0_0 == expected_value_0_0)
    else:
        expected_value_0_0 = u'git-gui--askpass'
        assert(value_0_0 == expected_value_0_0)
    # Testing key 1
    key_1_0 = b'LANG'
    value_1_0 = text_environ_1.__getitem__(key_1_0)

# Generated at 2022-06-25 13:35:53.619232
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a mock _raw_environ
    text_environ_1 = _TextEnviron()
    text_environ_1._raw_environ = {}
    text_environ_1._value_cache = {}
    text_environ_1._encoding = 'utf-8'
    # Populate the mock _raw_environ
    text_environ_1._raw_environ['valid_key'] = 'valid_value'
    # Verify
    assert text_environ_1['valid_key'] == 'valid_value'


# Generated at 2022-06-25 13:35:57.773795
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()

    text_environ_1['this_value'] = b'This is a test'

    text_environ_2 = _TextEnviron()

    assert text_environ_1[b'this_value'] == b'This is a test'
    assert text_environ_2['this_value'] == u'This is a test'


# Generated at 2022-06-25 13:36:00.328988
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__('ansible')


# Generated at 2022-06-25 13:36:05.010845
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Test __getitem__ method of class _TextEnviron
    '''
    environ_var_0 = 'HOME'
    try:
        test__TextEnviron___getitem___1(environ_var_0)
    except:
        assert False



# Generated at 2022-06-25 13:36:08.056148
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('USER') == os.environ['USER']


# Generated at 2022-06-25 13:36:18.340455
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    pytest.raises(KeyError, text_environ_0.__getitem__, "A6UWE9ZU")
    pytest.raises(KeyError, text_environ_0.__getitem__, "TLTJTZ9O")
    pytest.raises(KeyError, text_environ_0.__getitem__, "VA1B6MLN")
    pytest.raises(KeyError, text_environ_0.__getitem__, "ITJTZ9O1")
    pytest.raises(KeyError, text_environ_0.__getitem__, "ITJTZ9O2")

# Generated at 2022-06-25 13:36:22.117940
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    # Call method __getitem__ of class _TextEnviron and assert
    # Call method __getitem__ of class _TextEnviron and assert
    assert text_environ_0.__getitem__("HOME") == u"/root"



# Generated at 2022-06-25 13:36:24.898920
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    if PY3:
        assert text_environ_0['PYTHONPATH'] == ':'.join(sys.path)
    else:
        assert text_environ_0['PYTHONPATH'] == ':'.join([to_text(path, errors='surrogate_or_strict') for path in sys.path])


# Generated at 2022-06-25 13:36:27.612879
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron({'HOME': '/home/mihai'})
    assert text_environ_0['HOME'] == '/home/mihai'
    text_environ_1 = _TextEnviron({'TERM': 'VT100'}, encoding='utf-8')
    assert text_environ_1['TERM'] == 'VT100'


# Generated at 2022-06-25 13:36:28.518818
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    pass


# Generated at 2022-06-25 13:36:35.140064
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    if not PY3:
        # Test to ensure that py2 behavior is preserved
        text_environ_0._raw_environ.update({"PYTHONIOENCODING": "utf8"})
        text_environ_0._raw_environ.update({"PYTHONUTF8": "utf8"})
        assert text_environ_0["PYTHONIOENCODING"] == u'utf8'
        text_environ_0._raw_environ["PYTHONUTF8"] = u'utf8'.encode('utf-8')
        assert text_environ_0["PYTHONUTF8"] == u'utf8'

# Generated at 2022-06-25 13:36:38.278030
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Here we bind the value of the argument key to 'C' for testing
    text_environ_0.__getitem__('C')

# Generated at 2022-06-25 13:36:40.958521
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # initialize the test environment
    text_environ_0 = _TextEnviron()

    # perform the test
    result = text_environ_0['TEST_ENV_VAR']


# Generated at 2022-06-25 13:36:51.396787
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron(encoding='ascii')
    text_environ_2 = _TextEnviron()

    if sys.platform == 'darwin':
        assert (text_environ_1['PATH'] == text_environ_2['PATH']) == True
        assert (text_environ_1['PATH'] == b'/Users/toshio/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin') == True
    elif sys.platform == 'linux2':
        assert (text_environ_1['PATH'] == text_environ_2['PATH']) == True

# Generated at 2022-06-25 13:36:52.232540
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-25 13:36:58.135931
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for the _TextEnviron class with text keys and byte strings
    environ_0 = _TextEnviron()
    # Test the byte string (default) case
    assert environ_0[b'PATH'] == os.environ['PATH']
    # Test a key not present in os.environ
    assert environ_0['NONEXISTENT'] == os.environ['NONEXISTENT']
    # Test with text keys
    assert environ_0['PATH'] == os.environ['PATH']
    # Test a key not present in os.environ
    assert environ_0['NONEXISTENT'] == os.environ['NONEXISTENT']

    # Test for the _TextEnviron class with text keys and text strings

# Generated at 2022-06-25 13:37:00.591964
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    ret = text_environ_0['PATH']
    assert ret == os.environ['PATH']

# Generated at 2022-06-25 13:37:09.360462
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_value_1 = environ['HOME']
    environ_value_2 = environ['PATH']
    environ_value_3 = environ['CDPATH']
    environ_value_4 = environ['PWD']
    home = os.environ['HOME']
    _path = os.environ['PATH']
    cd_path = os.environ['CDPATH']
    pwd = os.environ['PWD']
    assert environ_value_1 == home
    assert environ_value_2 == _path
    assert environ_value_3 == cd_path
    assert environ_value_4 == pwd


# Generated at 2022-06-25 13:37:10.544454
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] is not None


# Generated at 2022-06-25 13:37:13.027180
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    my_environ_key = "PATH"
    with pytest.raises(RuntimeError):
        text_environ_0[my_environ_key]


# Generated at 2022-06-25 13:37:15.428541
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(encoding='ascii')
    expected = "Hello, World!"
    assert(text_environ_0['HELLO'] == expected)


# Generated at 2022-06-25 13:37:25.544003
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_1 = text_environ_0.__getitem__('HOME')
    str_2 = text_environ_0.__getitem__('HOME')
    str_3 = text_environ_0.__getitem__('HOME')
    str_4 = text_environ_0.__getitem__('HOME')
    text_environ_0.__setitem__('test_getitem__0', 'test_getitem__0')
    text_environ_0.__setitem__('test_getitem__1', 'test_getitem__1')
    text_environ_0.__setitem__('test_getitem__2', 'test_getitem__2')

# Generated at 2022-06-25 13:37:32.821288
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    temp_var_0 = text_environ_0['']
    # Ensure that we're converting the return value to text
    if not hasattr(temp_var_0, '__le__'):
        raise AssertionError("_TextEnviron.__getitem__ should turn a value obtained from os.environ into text")
    # If we're on Python3, we must have text as a type
    if PY3 and not isinstance(temp_var_0, str):
        raise AssertionError("_TextEnviron.__getitem__ should turn a value obtained from os.environ into text")
    # If we're on Python2 and the original string was bytes, we should have converted to unicode

# Generated at 2022-06-25 13:37:44.225583
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()

    # Check that it fetches a value properly
    text_environ['LANG'] = 'en_US.UTF-8'
    assert text_environ['LANG'] == u'en_US.UTF-8'

    # Check that it errors on non-existent values
    try:
        text_environ['NOTAVAR']
    except KeyError:
        pass
    else:
        assert False, 'Expected KeyError when trying to fetch a non-existant value'

    # Check that it returns the same value for a string as os.environ does
    assert os.environ['LANG'] == text_environ['LANG']

    # Check that it converts a byte string to text
    text_environ['LANG'] = b'en_US.UTF-8'
   

# Generated at 2022-06-25 13:37:45.209450
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert True


# Generated at 2022-06-25 13:37:46.155466
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    test_case_0()


# Generated at 2022-06-25 13:37:52.035862
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    if PY3:
        assert text_environ_0["PATH"] == os.environ["PATH"]
        return

    text_environ_0 = _TextEnviron()
    to_text_0 = text_environ_0["PATH"]
    assert sys.getfilesystemencoding() == "utf-8"
    assert to_text_0 == to_text(os.environ["PATH"], encoding=sys.getfilesystemencoding(), nonstring='passthru', errors='surrogate_or_strict')


# Generated at 2022-06-25 13:37:53.954779
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    print(text_environ_0.__getitem__("TEST_VAR"))


# Generated at 2022-06-25 13:37:56.360723
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    key_0 = 'C2_0:E2_0'
    var_0 = text_environ_0[key_0]


# Generated at 2022-06-25 13:37:58.086453
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    assert text_environ.__getitem__("PATH") == os.environ["PATH"]


# Generated at 2022-06-25 13:38:07.929605
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Tests for _TextEnviron's __getitem__ method
    """
    # Test that we get items from os.environ
    os.environ['ANSIBLE_TEST_GETITEM'] = 'TestValue'
    assert text_environ_0['ANSIBLE_TEST_GETITEM'] == 'TestValue'
    del os.environ['ANSIBLE_TEST_GETITEM']
    os.environ['ANSIBLE_TEST_GETITEM'] = b'TestValue'
    assert text_environ_0['ANSIBLE_TEST_GETITEM'] == 'TestValue'

    # Test that we get unicode values
    os.environ['ANSIBLE_TEST_GETITEM_2'] = b'ByteString'

# Generated at 2022-06-25 13:38:11.628447
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    result = environ.__getitem__('INVOCATION_ID')
    # AssertionError: '0cf7b0fb-8a93-447a-be1d-ff9c77c81076' != '0cf7b0fb-8a93-447a-be1d-ff9c77c81076'
    assert result == '0cf7b0fb-8a93-447a-be1d-ff9c77c81076'

# Unit tests for methods __delitem__, __iter__ and __contains__ of class _TextEnviron

# Generated at 2022-06-25 13:38:18.072595
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:38:23.258845
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert True


# Generated at 2022-06-25 13:38:25.364651
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_1 = text_environ_0.__getitem__('SHELL')


# Generated at 2022-06-25 13:38:31.916610
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # From now on, we will enter text strings in environment variables
    environ['LANG'] = 'en_US.UTF-8'

    # Create an object of the class under test
    text_environ_1 = _TextEnviron()

    # Retrieve a text string from the environment variable
    lang_1 = text_environ_1['LANG']

    # Check that we have a text string
    assert isinstance(lang_1, type(''))

    # Check that the string we have matches the string we put in
    assert lang_1 == 'en_US.UTF-8'



# Generated at 2022-06-25 13:38:35.908359
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    with pytest.raises(TypeError):
        text_environ_0 = _TextEnviron()
        text_environ_0.__getitem__()

    with pytest.raises(TypeError):
        text_environ_0 = _TextEnviron()
        text_environ_0.__getitem__()


# Generated at 2022-06-25 13:38:39.896674
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    assert text_environ['TEST_TEXTENVIRON_KEY'] == 'TEST_TEXTENVIRON_VALUE'
    # Check that the cache can be used
    assert text_environ['TEST_TEXTENVIRON_KEY'] == 'TEST_TEXTENVIRON_VALUE'



# Generated at 2022-06-25 13:38:48.672411
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    key, value = 'ANSIBLE_LIBRARY', 'foo,bar'
    text_environ[key] = value
    assert text_environ[key] == value, \
        "The value returned is not what is set in the env: %s != %s" % \
        (text_environ[key], value)
    assert text_environ._raw_environ[key] == to_bytes(value, encoding='utf-8', nonstring='strict',
                                                      errors='surrogate_or_strict'), \
        "_raw_environ doesn't match what was set"



# Generated at 2022-06-25 13:38:52.264711
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    value = text_environ_0['HOME']
    assert True
    value = text_environ_0['PATH']
    assert True
    value = text_environ_0['LOGNAME']
    assert True


# Generated at 2022-06-25 13:38:54.904761
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    test = text_environ_0.__getitem__('HOME')
    assert test == os.path.expanduser('~'), 'function call failed'


# Generated at 2022-06-25 13:38:56.037593
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()

if __name__ == "__main__":
    test__TextEnviron___getitem__()

# Generated at 2022-06-25 13:38:57.804451
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Current os.environ has values as bytes.
    text_environ_0.__getitem__('HOME')

# Generated at 2022-06-25 13:39:12.082507
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This will fail on both python 2 and 3 if LANG is not set.  Assume it is set.
    print('Hello', environ['LANG'])
    print('Hello', environ['PATH'])
    os.environ['LANG'] = 'en_US.UTF-8'
    print('Hello', environ['LANG'])
    assert isinstance(environ['LANG'], str)
    assert environ['LANG'] == 'en_US.UTF-8'
    assert isinstance(environ['LANG'], str)
    assert environ['LANG'] == 'en_US.UTF-8'



# Generated at 2022-06-25 13:39:14.105060
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()

if __name__ == "__main__":
    test__TextEnviron___getitem__()

# Generated at 2022-06-25 13:39:16.752838
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Test method __getitem__ of class _TextEnviron"""
    # Test with no environment variable
    assert(text_environ_0.__getitem__("this_environ_key_should_not_exist") is not None)


# Generated at 2022-06-25 13:39:20.798351
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for no caching (no second lookups)
    text_environ_0 = _TextEnviron({'test': 'test'})
    if PY3:
        assert text_environ_0['test'] == 'test'
    else:
        # Check that the item is decoded from bytes to text
        import six
        assert text_environ_0['test'] == six.text_type('test')


# Generated at 2022-06-25 13:39:24.440866
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = {"HOME": b"/home/bruce"}
    t = _TextEnviron(env=e)
    assert t["HOME"] == u"/home/bruce"


# Generated at 2022-06-25 13:39:32.802924
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    text_environ_0 = _TextEnviron()

    # Test making sure that the value of x matches the equal value of y
    x = text_environ_0['PATH']
    y = os.environ['PATH']
    assert x == y

    # Test making sure that the value of x matches the equal value of y
    x = text_environ_0['PYTHONPATH']
    y = os.environ['PYTHONPATH']
    assert x == y

    # Test making sure that the value of x matches the equal value of y
    x = text_environ_0['PWD']
    y = os.environ['PWD']
    assert x == y


# Generated at 2022-06-25 13:39:35.525818
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    empl_var = _TextEnviron()
    assert empl_var.__getitem__('ANSIBLE_TEST_FOO') == os.environ['ANSIBLE_TEST_FOO']


# Generated at 2022-06-25 13:39:36.923209
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert 'TEST' in text_environ_1.keys()
    'TEST' in text_environ_1


# Generated at 2022-06-25 13:39:39.406035
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    test_0 = text_environ_1.__getitem__('0')
    if isinstance(test_0, type(str())):
        test__TextEnviron___getitem___0 = True
    else:
        test__TextEnviron___getitem___0 = False
    assert test__TextEnviron___getitem___0


# Generated at 2022-06-25 13:39:40.824459
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert(_TextEnviron.__getitem__(item=b'HOME') == to_text(os.environ[b'HOME']))


# Generated at 2022-06-25 13:40:00.198797
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Unit test execution
    assert text_environ_0.__getitem__('PATH') == '/bin:/usr/bin'


# Generated at 2022-06-25 13:40:02.936703
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    text_environ = _TextEnviron()
    # Test
    text_environ['QUERY_STRING']
    # Test
    assert text_environ['QUERY_STRING']


# Generated at 2022-06-25 13:40:04.637955
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    assert text_environ['PATH']



# Generated at 2022-06-25 13:40:12.242311
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # The default encoding should be utf-8 on python3
    if PY3:
        assert environ._TextEnviron__encoding == 'utf-8'
        assert environ['HOME'] == os.environ['HOME']
    else:
        assert environ['HOME'] == os.environ['HOME'].decode('utf-8')
        assert environ['HOME'] == os.environ['HOME'].decode(sys.getfilesystemencoding())
    assert environ['HOME'] != os.environ['HOME']
    environ['TEST_ENVVAR'] = 'Täst Väluä'
    assert environ['TEST_ENVVAR'] == 'Täst Väluä'

# Generated at 2022-06-25 13:40:17.583797
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Check that we always get text back
    assert isinstance(environ.get('PATH', None),
                      type(u''))
    assert isinstance(environ.get('PATH', None),
                      type(''))
    # Check that we get the right text back
    if PY3:
        assert environ['PATH'] == os.environ['PATH']
    else:
        assert environ['PATH'] == os.environ['PATH'].decode(sys.getfilesystemencoding())


# Generated at 2022-06-25 13:40:20.654290
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # If on Python3, returns text directly
    if PY3:
        assert isinstance(environ['HOME'], text)
    # Otherwise, always returns text
    else:
        assert isinstance(environ['HOME'], text)


# Generated at 2022-06-25 13:40:29.763513
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        # Given the following environment variable
        envvar_0 = 'HOME'
        # When I retrieve the values of that environment variable from the environment
        env_0_os = os.environ[envvar_0]
        env_0_ansible = environ[envvar_0]
        # Then the values I get should be identical
        assert env_0_os == env_0_ansible
    else:
        # Given the following environment variable
        envvar_0 = 'HOME'
        # When I retrieve the values of that environment variable from the environment
        env_0_os = os.environ[envvar_0]
        env_0_ansible = environ[envvar_0]
        # Then the values I get should be identical
        assert env_0_os == env_0_ansible



# Generated at 2022-06-25 13:40:32.509939
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert isinstance(text_environ_1._TextEnviron__getitem__(text_environ_1,'HOME'),str)


# Generated at 2022-06-25 13:40:35.503288
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        text_environ_1 = _TextEnviron(env=None, encoding=None)
        print(text_environ_1['TEST_VAR'])
    except IndexError:
        print('Index does not exists')


# Generated at 2022-06-25 13:40:39.459439
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_env = dict(foo='bar', baz='qux', bip='bop')
    _environ = _TextEnviron(test_env)
    assert _environ.get('foo') == 'bar'
    if PY3:
        assert _environ.get('baz') == 'qux'
    else:
        assert _environ.get('baz') == u'qux'

# Generated at 2022-06-25 13:41:15.325425
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    actual_result_1 = text_environ_1['SHELL']
    expected_result_1 = text_environ_1['SHELL']
    assert actual_result_1 == expected_result_1


if __name__ == '__main__':
    import pytest
    pytest.main(['-x', __file__])

# Generated at 2022-06-25 13:41:17.285285
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_name_0 = text_environ_0['SHELL']


# Generated at 2022-06-25 13:41:20.142421
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

# Generated at 2022-06-25 13:41:25.527826
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This is a hash table with arbitrary keys, so just pick something that's likely to always be
    # in os.environ
    for key in ('PATH', 'SHELL', 'PWD',):
        result = text_environ_0.__getitem__(key)
        assert result == os.environ[key]
    assert result is not None


# Generated at 2022-06-25 13:41:28.740014
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    key = 'TEST_KEY'
    val = 'TEST_VALUE'

    __tracebackhide__ = True
    text_environ_0 = _TextEnviron({key: val})
    assert text_environ_0[key] == val



# Generated at 2022-06-25 13:41:32.300891
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    res_1 = text_environ_0['SHELL']
    res_2 = os.environ['SHELL']
    try:
        assert res_1 == res_2
    except AssertionError as ae:
        raise ae


# Generated at 2022-06-25 13:41:34.050590
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # __getitem__ has no assert statements. No test to run

# Generated at 2022-06-25 13:41:40.669374
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert b'TEST_VAR' in environ
        assert u'TEST_VAR' in environ
        assert 'TEST_VAR' in environ
        with os.environb.context:
            os.environb[b'TEST_VAR'] = b'foo'
            assert environ[u'TEST_VAR'] == 'foo'
            assert environ[b'TEST_VAR'] == 'foo'
            assert environ['TEST_VAR'] == 'foo'
    else:
        assert environ[u'TEST_VAR'] == u'foo'
        assert environ[b'TEST_VAR'] == u'foo'
        assert environ['TEST_VAR'] == u'foo'


# Generated at 2022-06-25 13:41:43.398033
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Initializing TextEnviron object
    text_environ_0 = _TextEnviron()

    # Accessing environment variable via getitem method of TextEnviron object.
    assert 'SHELL' in text_environ_0

# Generated at 2022-06-25 13:41:50.097023
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Tests to see if value is stored in _value_cache properly
    try:
        test_case_0()
    except Exception:
        assert False
    result = to_text(b'ANSIBLE_CONFIG', encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict')
    result = text_environ_0[result]
    # Tests to see if value is stored in _value_cache properly
    if not (result == ''):
        test_case_0()
        assert False

if __name__ == '__main__':
   test__TextEnviron___getitem__()

# Generated at 2022-06-25 13:43:12.514835
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with no arguments
    text_environ_0 = _TextEnviron()
    key = 'None'
    result = text_environ_0.__getitem__(key)
    assert result is None
    # Test with one argument
    text_environ_1 = _TextEnviron(env={'name': 'value'})
    result = text_environ_1.__getitem__('name')
    # Check that the result is correct
    assert result == 'value'



# Generated at 2022-06-25 13:43:17.023710
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    print(text_environ["PATH"])
    print(type(text_environ["PATH"]))
    text_environ = _TextEnviron(env={"str_only_unicode": "str/bytes"}, encoding='utf-8')
    print(text_environ["str_only_unicode"])
    print(type(text_environ["str_only_unicode"]))


# Generated at 2022-06-25 13:43:22.171306
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # ``__getitem__`` is tested by test_case_1()

    text_environ_0 = _TextEnviron()
    # Test ``__getitem__`` with a missing argument.
    text_environ_0.__getitem__(a=1)
    text_environ_0.__getitem__('b', 1)
    # ``__getitem__`` is tested by ``test_case_1()``.


# Generated at 2022-06-25 13:43:24.309863
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    with pytest.raises(KeyError):
        text_environ['']


# Generated at 2022-06-25 13:43:32.984214
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    text_environ_0 = _TextEnviron()
    # print('text_environ_0: ', text_environ_0)
    # print('text_environ_0._raw_environ: ', text_environ_0._raw_environ)
    # print('environ: ', environ)
    # print('environ._raw_environ: ', environ._raw_environ)
    # print('text_environ_0._value_cache: ', text_environ_0._value_cache)
    # print('text_environ_0.encoding: ', text_environ_0.encoding)
    # print('environ.encoding: ', environ.encoding)
    # print('text_environ_0._raw_environ[\'PATH\']: ', text_environ

# Generated at 2022-06-25 13:43:35.703280
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    text_environ_0 = _TextEnviron()
    key = 'TEST_VAR_NAME'

    # Exercise
    result = text_environ_0.__getitem__(key)

    # Verify
    assert result is not None



# Generated at 2022-06-25 13:43:36.726016
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    p1 = _TextEnviron().__getitem__('a')


# Generated at 2022-06-25 13:43:42.898689
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(os.environ, 'utf-8')
    # These two tests get to the same code path
    #assert(to_text('abc', encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict') ==
    #       text_environ_0['LC_MESSAGES'])
    assert(text_environ_0['LC_MESSAGES'] == text_environ_0['LC_MESSAGES'])
    # Python2 only test
    # assert(text_environ_0['SHELL'] == to_text(os.environ['SHELL'], encoding='utf-8',
    #                                           nonstring='passthru', errors='surrogate_or_strict'))



# Generated at 2022-06-25 13:43:47.877522
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Using setUp() because we need to be able to reset the environment before each test
    # The environment is global and changes during the tests
    # This is tested in utils\test_unicode.py (test_unicode_type_error_repeatedly)
    pass


_TEXT_ENVIRON_TEST_VALUE = u"I didn't ask for this"
_TEXT_ENVIRON_TEST_KEY = u'ARROW_ALAN_TEST_TEXT_ENVIRON'



# Generated at 2022-06-25 13:43:50.585363
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_1 = _TextEnviron()
    text_environ_2 = _TextEnviron()
    # test getitem
    assert text_environ_2['PATH'] == text_environ_1['PATH'] == text_environ_0['PATH']
