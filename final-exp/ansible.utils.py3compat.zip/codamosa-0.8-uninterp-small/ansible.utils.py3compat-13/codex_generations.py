

# Generated at 2022-06-25 13:34:25.459350
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        return
    # Unit test: __getitem__ / missing item
    env_item = text_environ_0['does_not_exist']
# TODO: How to check that we raise some sort of error when an item is missing?
#    assert env_item == '', f'Incorrect type returned: `{type(env_item)}`'
    # Unit test: __getitem__ / item with utf-8 text
    env_item = text_environ_0['__a_utf8_env_var_name__']
    assert env_item == 'a utf-8 value\xa1\xa2', f'Incorrect type returned: `{type(env_item)}`'
    # Unit test: __getitem__ / item with latin_1 text
    env_item = text_environ

# Generated at 2022-06-25 13:34:27.467611
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ[to_text('PATH', encoding='utf-8')] == os.environ['PATH']


# Generated at 2022-06-25 13:34:29.687367
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print('Method __getitem__ of class _TextEnviron')
    # TODO: implement unit test for this
    raise NotImplementedError()


# Generated at 2022-06-25 13:34:32.756952
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_0 = _TextEnviron()
    expected = 'env_value'
    os.environ['envvar'] = 'env_value'
    res = environ_0['envvar']
    assert res == expected


# Generated at 2022-06-25 13:34:35.472631
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result_0 = text_environ_0.__getitem__(var_name='PATH')
    assert result_0 == os.environ.get('PATH')


# Generated at 2022-06-25 13:34:42.262846
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    # we need to check that the right value is returned since Python3's os.environ will be
    # returning a string (on Python3) and we're trying to emulate that.
    retval__object__1 = text_environ_1['PATH']
    assert retval__object__1 is not None, 'cannot find path in test'

# Generated at 2022-06-25 13:34:49.036437
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__setitem__(u'TEST_ENV_VAR', u'test_env_val')
    assert text_environ_0.__getitem__(u'TEST_ENV_VAR') == u'test_env_val', 'Expected "test_env_val", but got "{}"'.format(text_environ_0.__getitem__(u'TEST_ENV_VAR'))


# Generated at 2022-06-25 13:34:54.458725
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert 'HOME' in text_environ_0, "Failed to set up test"
    assert isinstance(text_environ_0['HOME'], str), "Failed to set up test"
    # __getitem__
    assert isinstance(text_environ_0['HOME'], str), "Failed to set up test"


# Generated at 2022-06-25 13:34:56.304211
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    result = text_environ_1.__getitem__('')


# Generated at 2022-06-25 13:34:59.350969
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    attrvalue_0 = text_environ_0.__getitem__('0')
    assert attrvalue_0 is not None, "Failed to get attribute '__getitem__' of <class '_TextEnviron'>"



# Generated at 2022-06-25 13:35:04.999180
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['PWD'] == os.environ['PWD']
    else:
        assert environ['PWD'] != os.environ['PWD']  # type: ignore
        assert environ['PWD'] == u'%s' % os.environ['PWD']  # type: ignore


# Generated at 2022-06-25 13:35:14.233343
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Check that bytes are handled correctly on python2
    if not PY3:
        text_environ_1 = _TextEnviron(encoding='utf-8')
        # Create an environment variable that contains bytes
        bytes_env_var = b'bytes_env_var'
        bytes_env_var_value = b'\xc2\xa2'
        os.environ[bytes_env_var] = bytes_env_var_value

        # Verify that the value of the bytes environment variable gets decoded as utf-8
        assert text_environ_1[bytes_env_var] == b'\xc2\xa2'.decode('utf-8')

        # Verify that a second use of the same variable gets the same results

# Generated at 2022-06-25 13:35:21.392983
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_0 = _TextEnviron(encoding='utf-8')
    # Testing when key is defined and value is of type string

# Generated at 2022-06-25 13:35:26.502506
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.encoding = 'utf-8'
    text_environ_0._value_cache = {}
    text_environ_0._raw_environ = {}
    assert text_environ_0['path'] == '%SystemRoot%\\system32;%SystemRoot%;%SystemRoot%\\System32\\Wbem;C:\\Users\\alex\\AppData\\Local\\Microsoft\\WindowsApps'  # noqa


# Generated at 2022-06-25 13:35:31.007805
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert len(environ) == len(os.environ)
    assert len(environ) >= 2
    assert 'HOME' in environ
    assert 'PATH' in environ
    if 'NON_EXISTANT_VARIABLE' in os.environ:
        del os.environ['NON_EXISTANT_VARIABLE']
    assert 'NON_EXISTANT_VARIABLE' not in environ



# Generated at 2022-06-25 13:35:40.175545
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # If we never set the encoding, then we should end up returning the value unchanged
    text_environ_0 = _TextEnviron()
    text_environ_0['PATH'] = '/bin:/usr/bin'
    assert text_environ_0['PATH'] == '/bin:/usr/bin'
    text_environ_0['HOME'] = '/home/jdoe'
    assert text_environ_0['HOME'] == '/home/jdoe'

    # If we set the encoding to bytes, then we should end up returning the value unchanged
    text_environ_1 = _TextEnviron(encoding='bytes')
    text_environ_1['PATH'] = '/bin:/usr/bin'
    assert text_environ_1['PATH'] == '/bin:/usr/bin'
    text_environ_1['HOME']

# Generated at 2022-06-25 13:35:41.291703
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()


# Generated at 2022-06-25 13:35:45.051517
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

# Generated at 2022-06-25 13:35:53.379718
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an instance of the class to test
    text_environ = _TextEnviron()

    # Test with a simple key
    text_environ['test_case_0'] = 'test_case_0'
    assert text_environ['test_case_0'] == 'test_case_0'

    # Test with a unicode key
    text_environ[u'test_case_0'] = 'test_case_0'
    assert text_environ[u'test_case_0'] == 'test_case_0'

    # Test with a unicode key and a bytes value
    text_environ[u'test_case_0'] = b'test_case_0'
    assert text_environ[u'test_case_0'] == 'test_case_0'

    # Test with a key of bytes

# Generated at 2022-06-25 13:36:02.293241
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ.__getitem__('PWD') == os.environ['PWD']
    if PY3:
        assert environ.__getitem__('PWD') == os.environ['PWD']
    else:
        assert isinstance(environ.__getitem__('PWD'), unicode)
    del os.environ['PYTHONPATH']
    assert 'PYTHONPATH' not in environ
    assert 'PYTHONPATH' not in os.environ
    os.environ['PYTHONPATH'] = ''
    assert environ['PYTHONPATH'] == ''
    assert isinstance(environ['PYTHONPATH'], unicode)
    assert os.environ['PYTHONPATH'] == ''

# Generated at 2022-06-25 13:36:09.639185
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    #
    # First test that we translate non-unicode bytestrings to unicode
    #
    assert text_environ_0['OUTPUT_ENCODING'] == u'UTF-8'
    #
    # Now test that we don't have to re-translate bytestrings that have
    # already been translated
    #
    assert text_environ_0['ANSIBLE_CONFIG'] == u''
    #
    # Make sure we don't fail on regular unicode strings
    #
    assert text_environ_0['PYTHONIOENCODING'] == u'UTF-8'


# Generated at 2022-06-25 13:36:12.077446
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    global text_environ_0

    expected = None
    actual = text_environ_0.__getitem__('TEST_1')
    assert expected == actual



# Generated at 2022-06-25 13:36:16.951983
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an object of class _TextEnviron
    text_environ_0 = _TextEnviron()
    # Check if the method __getitem__ of class _TextEnviron is working as expected
    assert text_environ_0.__getitem__('USER') == os.environ['USER']


# Generated at 2022-06-25 13:36:25.883319
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

# Generated at 2022-06-25 13:36:28.578085
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Here are some test cases for the _TextEnviron.__getitem__ method
    text_environ_0 = _TextEnviron()
    assert text_environ_0['PATH'] == os.environ['PATH']



# Generated at 2022-06-25 13:36:29.743844
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()



# Generated at 2022-06-25 13:36:31.625613
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        # This will fail because there is no key, 'foo'
        environ['foo']
        assert False
    except KeyError:
        assert True



# Generated at 2022-06-25 13:36:40.919772
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test getitem with a valid key
    assert environ['PATH'] == '/usr/bin:/usr/sbin:/bin:/sbin'

    # Test getitem with an invalid key
    try:
        environ['BOGUS']
    except KeyError as e:
        assert str(e) == 'BOGUS'
    else:
        raise AssertionError('Expected KeyError')

    # Test getitem with a value that needs decoding
    environ['BYTES_KEY'] = b'\xc3\x84\xc3\xa0\xc3\xa8\xc3\xb9'
    assert environ['BYTES_KEY'] == 'Äàèù'

    # Test getitem with a value that isn't valid utf-8

# Generated at 2022-06-25 13:36:45.125723
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        os.environ['TextEnviron_test_str'] = 'some text'
    else:
        os.environ['TextEnviron_test_str'] = b'some text'

    assert environ['TextEnviron_test_str'] == u'some text'


# Generated at 2022-06-25 13:36:46.773237
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    print(text_environ["PATH"])


# Generated at 2022-06-25 13:36:51.430250
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert type(text_environ_0['LANG']) == str


# Generated at 2022-06-25 13:36:56.144855
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    val_0 = text_environ_0["XDG_VTNR"]
    print(val_0)

    with mock.patch.object(builtins, "print") as mock_print:
        text_environ_0 = _TextEnviron()
        val_0 = text_environ_0["XDG_VTNR"]
        print(val_0)
        mock_print.assert_called_once_with("7")

# Generated at 2022-06-25 13:37:07.178396
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test that __getitem__ returns text on Python 2 and returns the original string on Python 3
    """
    # Create a TextEnviron instance for testing with
    text_environ_0 = _TextEnviron(encoding='ascii')

    # Test with a non-unicode value
    assert text_environ_0.__getitem__('HOME') == os.environ['HOME']

    # Test with a unicode value
    # NOTE: The u'' to represent unicode strings here is part of Python2's syntax, not Python3's.
    # The reason for this is that the u'' represents a unicode object on Python2 and becomes a
    # string on Python3.
    text_environ_0['FOO'] = u'bar'

# Generated at 2022-06-25 13:37:09.630962
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert isinstance(text_environ_0.__getitem__("SHELL"), (str,))


# Generated at 2022-06-25 13:37:15.734951
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = None
    # Save the current environment so we can restore it if it's modified
    env_save = dict(os.environ)


# Generated at 2022-06-25 13:37:17.079591
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert True


# Generated at 2022-06-25 13:37:19.983399
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    value = text_environ_1.__getitem__(key='PATH')
    assert ':' in value


# Generated at 2022-06-25 13:37:21.608391
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert repr(environ['SHELL']) == repr(os.environ['SHELL'])


# Generated at 2022-06-25 13:37:29.693958
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron(os.environ)
    assert "SHELL" == text_environ_1.__getitem__("SHELL")
    assert "PATH" == text_environ_1.__getitem__("PATH")
    assert "LANG" == text_environ_1.__getitem__("LANG")
    assert "HOME" == text_environ_1.__getitem__("HOME")
    assert "USER" == text_environ_1.__getitem__("USER")
    assert "LOGNAME" == text_environ_1.__getitem__("LOGNAME")
    assert "PWD" == text_environ_1.__getitem__("PWD")

# Generated at 2022-06-25 13:37:32.377108
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    print(text_environ_1["PATH"])
    print(text_environ_1["LANG"])
    print(text_environ_1["BLANK"])

# Generated at 2022-06-25 13:37:37.191896
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_1 = text_environ_0.__getitem__('key')


# Generated at 2022-06-25 13:37:39.321843
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_1 = _TextEnviron(encoding='utf-8')


# Generated at 2022-06-25 13:37:47.763020
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__(to_text('2E#wcBh<2',
                                       errors='surrogate_or_strict'))
    text_environ_0.__getitem__(to_text('3[Z*\x05',
                                       errors='surrogate_or_strict'))
    text_environ_0.__getitem__(to_text('l<', errors='surrogate_or_strict'))
    text_environ_0.__getitem__(to_text('', errors='surrogate_or_strict'))


# Generated at 2022-06-25 13:37:55.020456
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a _TextEnviron object with a known starting state
    dt_obj = _TextEnviron({b'key_0': b'value_0', b'key_1': b'value_1', b'key_2': b'value_2', b'key_3': b'value_3', b'key_4': b'value_4', b'key_5': b'value_5', b'key_6': b'value_6', b'key_7': b'value_7', b'key_8': b'value_8', b'key_9': b'value_9'})
    results = dt_obj.__getitem__("key_6")
    assert results == "value_6"


# Generated at 2022-06-25 13:37:58.420568
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Method __getitem__ for class _TextEnviron
    text_environ_1 = _TextEnviron()
    ansible = u"ansible"
    key = u"HOME"
    if key in text_environ_1:
        assert text_environ_1[key] == ansible, "Error in __getitem__ of class _TextEnviron"


# Generated at 2022-06-25 13:38:04.324208
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test case 0
    if PY3:
        text_environ_0 = _TextEnviron()
        # We're on Python3, so os.environ returns text
        assert isinstance(text_environ_0['PATH'], text)
    else:
        # We're on Python2, so os.environ returns bytes
        assert isinstance(text_environ_0['PATH'], bytes)


# Generated at 2022-06-25 13:38:09.530601
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        for x_0 in range(6):
            try:
                assert text_environ_0.__getitem__(chr(x_0) * (x_0 + 1) + 'w') not in text_environ_0._raw_environ
            except:
                return False
        return True
    except:
        return False


# Generated at 2022-06-25 13:38:12.360836
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_arg_0 = text_environ_0.__getitem__('USER')
    str_arg_1 = text_environ_0.__getitem__('USER')
    assert str_arg_0 is not None
    assert str_arg_1 is not None


# Generated at 2022-06-25 13:38:15.204694
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Constructor test case 1
    text_environ_0 = _TextEnviron()
    assert 'PWD' in text_environ_0
    assert text_environ_0['PWD'] == os.environ['PWD']
    assert isinstance(text_environ_0['PWD'], str)


# Generated at 2022-06-25 13:38:17.240711
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError):
        # KeyError raised by __getitem__
        text_environ_0['PATH']

# Generated at 2022-06-25 13:38:26.821450
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        text_environ_0.__getitem__('HOME')
    except KeyError as exception_0:
        pass
    else:
        assert False, 'Expected KeyError "' + 'HOME' + '" not thrown'


# Generated at 2022-06-25 13:38:28.839985
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test case 0

    # Test case 1
    result = environ.__getitem__('HOME')
    assert result == '/home/akshat'


# Generated at 2022-06-25 13:38:33.585673
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Test with a known non-existent key
    result = text_environ_0['wmwmwmwmwmwmwmwmwmwmwmwmwmwmwmwmwmwmw']
    assert result == ""
    # Test with a known existing key
    result = text_environ_0['USER']
    assert result == "root"


# Generated at 2022-06-25 13:38:35.078250
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(_TextEnviron.__getitem__, type(object.__get__))



# Generated at 2022-06-25 13:38:44.352401
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_arg_0 = text_environ_0.get('PATH')
    # Make sure we get a text string back
    assert isinstance(str_arg_0, str)
    # Verify that we got the same value back as os.environ
    assert str_arg_0 == os.environ['PATH']
    # Verify that we can retrieve nonascii text strings
    environ.clear()
    str_arg_0 = to_text('тест', errors='surrogate_or_strict')
    environ['TEST_NONASCII'] = str_arg_0
    # Unset TEST_NONASCII in os.environ so we're not relying on a system value
    os.environ['TEST_NONASCII'] = to

# Generated at 2022-06-25 13:38:45.588531
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-25 13:38:49.837071
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        text_environ_0.__getitem__('LANG')
    except KeyError:
        print('KeyError raised, expected')
    else:
        print('No KeyError raised, not expected')


# Generated at 2022-06-25 13:38:52.646204
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_arg_0 = text_environ_0.__getitem__('')
    assert str_arg_0 == ""


# Generated at 2022-06-25 13:38:59.381074
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:39:08.870902
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # initialization
    test_case_0()

    # testing os.environ on Python 2
    sys.stdout.write("Testing on Python 2:\n")
    # testing UnicodeDecodeError
    sys.stdout.write("Testing UnicodeDecodeError:\n")
    bad_item = 'BAD_ITEM'
    # build-up the bad_item
    for i in range(1, 128):
        if sys.version_info[0] == 2 and sys.version_info[1] < 6:
            environ[bad_item] = chr(i)
        else:
            environ[bad_item] = to_bytes(chr(i), encoding='utf-8')

# Generated at 2022-06-25 13:39:16.603205
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    if isinstance(text_environ_1.__getitem__('HOME'), bytes):
        raise ValueError('__getitem__: ' + 'Home should be unicode')


# Generated at 2022-06-25 13:39:18.222183
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with key 'LANG' (default value='C')
    assert environ['LANG'] == 'C'


# Generated at 2022-06-25 13:39:19.395778
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test case 0 of 1
    environ['CFLAGS']
    assert True


# Generated at 2022-06-25 13:39:23.946874
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    text_environ_1 = _TextEnviron()
    text_environ_1['test_key'] = 'test_value'

    # Retrieve
    retrieved_value = text_environ_1['test_key']

    # Check
    assert retrieved_value == 'test_value'


# Generated at 2022-06-25 13:39:33.299086
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    #
    #
    # String format: CI
    str_format_0 = text_environ_0['CI'] if 'CI' in text_environ_0 else ""
    # Verify the type of variable str_format_0.
    assert isinstance(str_format_0, str)
    #
    #
    # String format: CONTINUOUS_INTEGRATION
    str_format_0 = text_environ_0['CONTINUOUS_INTEGRATION'] if 'CONTINUOUS_INTEGRATION' in text_environ_0 else ""
    # Verify the type of variable str_format_0.
    assert isinstance(str_format_0, str)
    #
    #
    # String format: GIT_BRANCH
    str

# Generated at 2022-06-25 13:39:41.436649
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    # This is a method of a TextEnviron instance
    expected = to_text(os.environ.__getitem__('PATH'), encoding="utf-8",
                       nonstring="passthru", errors="surrogate_or_strict")
    actual = text_environ_0.__getitem__('PATH')
    assert expected == actual

    text_environ_0 = _TextEnviron()

    # This is a method of a TextEnviron instance
    expected = to_text(os.environ.__getitem__('PATH'), encoding="utf-8",
                       nonstring="passthru", errors="surrogate_or_strict")
    actual = text_environ_0['PATH']
    assert expected == actual

    text_environ_0 = _Text

# Generated at 2022-06-25 13:39:45.795000
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for the case when the key is absent
    text_environ_0 = _TextEnviron()
    try:
        assert text_environ_0[0] is None  # We expect this line throws KeyError exception
    except KeyError:
        assert True

    # Test for the case when the key is present
    text_environ_1 = _TextEnviron()
    text_environ_1['USER'] = 'root'
    assert text_environ_1['USER'] == 'root'


# Generated at 2022-06-25 13:39:53.452732
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Initialization
    text_environ_0 = _TextEnviron()

    # Call method to test
    method_to_test = text_environ_0.__getitem__

    # Pass in some arguments
    method_to_test('')

    ##################################################################
    ############### Testing the method arguments ####################
    ##################################################################
    args_expected = {
        "0": {
            "method_arg_name": "key",
            "method_arg_value": "",
            "types": str,
            "exception": None,
            "desc": "Empty string",
            "test_passed": True
        },
    }

    # Iterate through parameter tests to find any errors

# Generated at 2022-06-25 13:39:54.638042
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(environ, _TextEnviron)


# Generated at 2022-06-25 13:40:03.579288
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test Python2 case
    if not PY3:
        test_environ = _TextEnviron({b'ansible_python_interpreter': '/usr/bin/python'}, encoding='utf-8')
        assert test_environ[u'ansible_python_interpreter'] == u'/usr/bin/python'
        # Test that we have a cache
        assert test_environ.encoding == 'utf-8'
        assert test_environ._value_cache[b'ansible_python_interpreter'] == u'/usr/bin/python'

        # Test with unicode key
        test_environ = _TextEnviron({u'ansible_python_interpreter': u'/usr/bin/python'}, encoding='utf-8')

# Generated at 2022-06-25 13:40:19.203350
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__("is_executing")
    var_0 = text_environ_0.__getitem__("SHELL")
    # This is only a test, not that useful
    assert "BASH" in var_0


# Generated at 2022-06-25 13:40:25.018455
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # text_environ_4 = _TextEnviron()
    try:
        text_environ_4 = _TextEnviron()
    except IOError as e:
        return False
    try:
        text_environ_4___getitem___var_13 = text_environ_4.__getitem__(str(u'$HOME'))
    except IOError as e:
        return False
    return text_environ_4___getitem___var_13


# Generated at 2022-06-25 13:40:28.037766
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = test_case_0()
    text_environ_0.__setitem__(str("A"), str("b"))
    assert text_environ_0.__getitem__("A") == "b"


# Generated at 2022-06-25 13:40:29.762859
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
  text_environ_0 = _TextEnviron()
  assert(True)


# Generated at 2022-06-25 13:40:37.562150
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # assert text_environ_0.__getitem__('SHELL') == '/bin/bash', 'Failed to get expected value of "SHELL" key. Expected "/bin/bash", Got: %s' % text_environ_0.__getitem__('SHELL')
    assert 'bin' in text_environ_0.__getitem__('SHELL'), 'Failed to get expected value of "SHELL" key. Expected "bin" to be in the value string, Got: "%s"' % text_environ_0.__getitem__('SHELL')
    assert 'SHELL' in text_environ_0, 'Failed to get expected value of "SHELL" key. Expected "SHELL" to be in the key list.'


# Generated at 2022-06-25 13:40:41.312316
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['-\u0083\xab'.upper()] = '\U000ea9d9'
    text_environ_0['`.`'] = "d"
    #test case
    text_environ_0['`.`']


# Generated at 2022-06-25 13:40:44.925417
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result_should_be = text_environ_0._raw_environ["PYTHONPATH"]
    result_seen = text_environ_0["PYTHONPATH"]

    assert result_should_be == result_seen


# Generated at 2022-06-25 13:40:53.561157
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import environ, getcwd
    from os.path import join
    from ansible.module_utils.six import PY2, PY3

    # Create a directory with encoded characters
    directory = mkdtemp()
    filename = to_text(directory + '/unic\xe8de.txt')
    with open(filename, 'a'):
        pass

    # Set the directory where we can find the encoded characters
    os.chdir(directory)

    # Create an environment variable that contains encoded characters
    environ['ANSIBLE_UNIC\xe8DE'] = directory

    # Verify that the directory path is decoded to text
    assert isinstance(environ['ANSIBLE_UNIC\xe8DE'], str)

# Generated at 2022-06-25 13:40:58.578300
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:41:03.396597
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    setattr(test_case_0, "_TextEnviron__getitem__", None)
    text_environ_0 = _TextEnviron()
    try:
        text_environ_0.__getitem__("abc")
    except Exception:
        pass
    else:
        raise AssertionError("No exception raised!")


# Generated at 2022-06-25 13:41:30.468274
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_1 = _TextEnviron()
    text_environ_1.__getitem__()


# Generated at 2022-06-25 13:41:34.089020
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    key = 'COPR_API_URL'
    try:
        text_environ_0.__getitem__(key)
    except Exception as exception:
        pytest.fail("The test case failed because the raised exception is not expected: " + str(exception))


# Generated at 2022-06-25 13:41:35.169232
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test case 0
    _TextEnviron()['KEY_0']


# Generated at 2022-06-25 13:41:43.817307
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        if PY3:
            assert environ['HOME'] == os.environ['HOME']
        else:
            assert environ['HOME'] == to_text(os.environ['HOME'], encoding=sys.getfilesystemencoding(),
                                              nonstring='passthru', errors='surrogate_or_strict')

    except (AssertionError, KeyError):
        raise AssertionError('Failed to get HOME.')

# Generated at 2022-06-25 13:41:47.188788
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__setitem__('key_0', 'value_0')
    assert text_environ_0.__getitem__('key_0') == 'value_0'


# Generated at 2022-06-25 13:41:55.185992
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test 0:
    # Check that we get back a text string when we use an encoded value for the key
    os.environ[to_bytes('test-value', encoding='utf-8')] = 'value'
    text_environ_0 = _TextEnviron()
    assert text_environ_0['test-value'] == 'value'
    assert isinstance(text_environ_0['test-value'], text)
    assert 'test-value' in text_environ_0._value_cache
    assert text_environ_0._value_cache['value'] == 'value'
    # Test 1:
    # Check that we get back a text string when we use an unencoded value for the key

# Generated at 2022-06-25 13:42:03.096248
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Pass a ascii-encoded bytes string
    key = to_bytes('ascii string')
    value = to_bytes('ascii string')
    environ._raw_environ[key] = value
    result = environ[key]
    assert isinstance(result, to_bytes('unicode'))
    assert result == value

    # Pass a ascii-encoded text string
    key = to_text('ascii string')
    value = to_text('ascii string')
    environ._raw_environ[key] = value
    result = environ[key]
    assert isinstance(result, to_text('unicode'))
    assert result == value

    # Pass a utf-8-encoded bytes string

# Generated at 2022-06-25 13:42:10.006499
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create new instance
    text_environ_0 = _TextEnviron()
    # Assign values as follows:
    # text_environ_0._value_cache = {'a': 'b'}
    # text_environ_0.encoding = 'utf-8'
    # text_environ_0._raw_environ = {'c': 'd'}
    text_environ_0._value_cache = {'a': 'b'}
    text_environ_0.encoding = 'utf-8'
    text_environ_0._raw_environ = {'c': 'd'}
    # Call method __getitem__ of text_environ_0
    text_environ_0.__getitem__('c')


# Generated at 2022-06-25 13:42:11.194293
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1["HOME"]


# Generated at 2022-06-25 13:42:12.078275
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()



# Generated at 2022-06-25 13:43:14.072649
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_0 = _TextEnviron()
    environ_0
    # assertEqual(actual, expected)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 13:43:17.360932
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an instance of _TextEnviron
    text_environ = _TextEnviron()

    # Test when Python 2:
    if not PY3:
        # Check that the function throws expected exceptions
        assert text_environ[1] is None
        assert text_environ['key'] is None


# Generated at 2022-06-25 13:43:20.677207
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1['text_environ_1'] = "abcd"
    assert text_environ_1['text_environ_1'] == 'abcd'


# Generated at 2022-06-25 13:43:25.933374
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:43:34.244214
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Encode the expected values in utf-8 for PY3 and in the environment's encoding for PY2
    # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding() instead of utf-8
    if PY3:
        expected_decoded = u'Ñtñ'
        expected_encoded = expected_decoded.encode('utf-8')
    else:
        expected_decoded = u'Ñtñ'
        expected_encoded = expected_decoded.encode(sys.getfilesystemencoding())
    # Make sure that the expected_decoded and expected_encoded text string actually match
    assert expected_decoded.encode(sys.getfilesystemencoding()) == expected_encoded

    # Make a new environment object with the utf-8 encoded string

# Generated at 2022-06-25 13:43:35.151625
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    assert isinstance(text_environ['PATH'], basestring)

# Generated at 2022-06-25 13:43:36.923566
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Check that all items in the cache are returned
    for key, value in environ.items():
        environ[key]
        assert value == environ[key]


# Generated at 2022-06-25 13:43:39.852809
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError):
        # AssertionError: '_TextEnviron.__getitem__() returned None'
        #      [None]
        assert text_environ_0.__getitem__("CDUYFYAYU") is None

# Generated at 2022-06-25 13:43:42.668236
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert 'PATH' in text_environ_0, "Failed to get item from hash"
    assert 'text_environ_0.__getitem__(\'PATH\')' in text_environ_0, "Failed to get item from hash"
    return


# Generated at 2022-06-25 13:43:46.950395
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    es = _TextEnviron()
    expected = os.environ.get('PATH', None)
    actual = es.__getitem__('PATH')
    # TODO: this should be the str type for python3
    assert type(actual) == type(expected), 'Return value does not match expected value'
    assert actual == expected, 'Value of es.__getitem__(\'PATH\') does not match expected value'
