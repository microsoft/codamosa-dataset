

# Generated at 2022-06-25 13:34:26.625810
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        actual_0 = text_environ_0['ALIEN_BACKUP_TEST']
        assert actual_0 == text_environ_0['ALIEN_BACKUP_TEST']
    except KeyError as e1:
        assert False
    try:
        actual_1 = text_environ_0['ALIEN_BACKUP_TEST']
        assert actual_1 != text_environ_0['ALIEN_BACKUP_TEST']
    except KeyError as e1:
        assert False
    

# Generated at 2022-06-25 13:34:33.206555
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # String Varables
    text_environ_1 = _TextEnviron()
    test_var_1 = 'Test String'
    # Setting value in the environment
    os.environ['test_var_1'] = test_var_1
    # Getting value from the environment
    result_var_1 = text_environ_1['test_var_1']
    # Checking if the value retrieved is same as value set
    assert result_var_1 == test_var_1
    del os.environ['test_var_1']  # Deleting the value set in environment


# Generated at 2022-06-25 13:34:43.823668
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_arg_0 = text_environ_0.__getitem__('PYTHONPATH')
    str_arg_0 = text_environ_0.__getitem__('NAME')
    str_arg_0 = text_environ_0.__getitem__('SHELL')
    str_arg_0 = text_environ_0.__getitem__('PYTHONUNBUFFERED')
    str_arg_0 = text_environ_0.__getitem__('PYTHONIOENCODING')
    str_arg_0 = text_environ_0.__getitem__('KILLALL')


# Generated at 2022-06-25 13:34:48.346059
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0['USERNAME'] is not None
    assert text_environ_0['USERNAME'] == os.environ['USERNAME']
    assert text_environ_0['USERNAME'] is not os.environ['USERNAME']


# Generated at 2022-06-25 13:34:51.765381
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        text_environ_0 = _TextEnviron()
        try:
            text_environ_0.__getitem__('y')
        except IndexError:
            pass
    except:
        pass


# Generated at 2022-06-25 13:34:54.497639
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()

    # Excepted to return a string at some point
    assert isinstance(text_environ_1['HOME'], str)


# Generated at 2022-06-25 13:34:56.947596
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    assert(type(text_environ["HOME"])==text_environ.__class__.__bases__[0])


# Generated at 2022-06-25 13:35:01.863948
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PYTHONPATH'] == '/home/vagrant/.ansible/plugins/modules:/usr/share/ansible/plugins/modules'
    assert environ['VIRTUAL_ENV'] == '/home/vagrant/.ansible-venv'
    assert environ['SHELL'] == '/bin/bash'
    assert environ['USER'] == 'vagrant'
    assert environ['SUDO_USER'] == 'vagrant'
    assert environ['LOGNAME'] == 'vagrant'
    assert environ['USERNAME'] == 'vagrant'
    assert environ['HOME'] == '/home/vagrant'



# Generated at 2022-06-25 13:35:07.062113
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an instance of _TextEnviron
    text_environ_0 = _TextEnviron()

    # Call method __getitem__ with argument "b'test_var'"
    # No exception should be raised
    try:
        text_environ_0.__getitem__("b'test_var'")
    except Exception:
        fail("Unexpected Exception when calling __getitem__ with argument \"b'test_var'\"")

# Generated at 2022-06-25 13:35:16.019551
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        # Test with a string that succeeds
        text_environ_1 = _TextEnviron({b'PYTHONPATH': b'/usr/lib/python2.6:/usr/lib/python3.3'})
        assert text_environ_1[b'PYTHONPATH'] == b'/usr/lib/python2.6:/usr/lib/python3.3'
        # Test with a string that has a non-decodeable character
        text_environ_2 = _TextEnviron({b'USERNAME': b'\xFF\xFF'})
        # We'll need to decode using surrogateescape or we're going to get a UnicodeDecodeError
        assert text_environ_2.encoding == 'UTF-8'
        assert text_environ_2[b'USERNAME'] == b

# Generated at 2022-06-25 13:35:24.401411
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env_key = 'USER'
    env_value = 'todd'
    os.environ[env_key] = env_value
    text_environ_0 = _TextEnviron()
    # test with bytestring
    assert text_environ_0[env_key] == env_value
    # test with textstring
    assert text_environ_0[to_text(env_key, encoding='utf-8')] == env_value

    env_key = 'ANSIBLE_TEST_UTF8'
    env_value = 'Todd\xc3\xa2\xc2\x80\xc2\x99s \xc3\xa2\xc2\x80\xc2\x9cfriend\xc3\xa2\xc2\x80\xc2\x9d from Belgium'
    os.en

# Generated at 2022-06-25 13:35:31.289952
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    expected = ['ABC', 'DEF', 'GHI']
    os.environ['ABC'] = 'ABC'
    os.environ['DEF'] = 'DEF'
    os.environ['GHI'] = 'GHI'
    if text_environ_0.__getitem__('ABC') != expected[0]:
        raise Exception('Test 0 Failed')
    if text_environ_0.__getitem__('DEF') != expected[1]:
        raise Exception('Test 1 Failed')
    if text_environ_0.__getitem__('GHI') != expected[2]:
        raise Exception('Test 2 Failed')
    os.environ.pop('ABC')
    os.environ.pop('DEF')
    os.environ.pop('GHI')



# Generated at 2022-06-25 13:35:40.444868
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0['SSH_AGENT_PID']
    assert str_0 == '2378'
    str_1 = text_environ_0['SSH_AUTH_SOCK']
    assert str_1 == '/run/user/1000/keyring/ssh'
    str_2 = text_environ_0['TMUX']
    assert str_2 == '/tmp/ansible-test-null4597-0/ansible-test-null4597-0/tmux-1000'
    str_3 = text_environ_0['_']
    assert str_3 == '/snap/bin/ansible'
    str_4 = text_environ_0['XDG_SESSION_ID']

# Generated at 2022-06-25 13:35:45.848586
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
        # Test '__getitem__' with a string argument
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('test_case_0') == 'test_case_0'
        # Test '__getitem__' with an int argument
    text_environ_1 = _TextEnviron()
    assert text_environ_1.__getitem__(0) == 0


# Generated at 2022-06-25 13:35:52.605194
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_cases = [
        {'name': 'test_case_0', 'expected': True, 'args': [{}, 'a']},
    ]

    for test_case in test_cases:
        try:
            result = test_case['function'](*test_case['args'])
        except Exception as e:
            result = e

        if test_case['expected'] == 'exception':
            assert isinstance(result, Exception)
        else:
            assert result == test_case['expected'], 'failed test: %s, result: %s' % (test_case['name'], result)


# Generated at 2022-06-25 13:35:58.764116
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text

    if PY3:
        unicode_envvar = to_bytes('☃'.encode('utf-8'))
    else:
        unicode_envvar = to_bytes(u'☃'.encode('utf-8'))
    test_environ = {b'A': b'a'.encode('utf-8'),
                    b'B': b'b'.encode('utf-8'),
                    b'C': unicode_envvar}
    text_environ = _TextEnviron(test_environ, 'utf-8')
    assert text_environ['A'] == 'a'
    assert text_environ['B'] == 'b'
    assert text_

# Generated at 2022-06-25 13:36:02.334476
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    for test_key in text_environ_0._raw_environ.keys():
        text_environ_0[test_key]


# Generated at 2022-06-25 13:36:06.418518
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ__getitem__0 = _TextEnviron()
    try:
        text_environ__getitem__0.__getitem__("key")
    except KeyError:
        pass
    try:
        text_environ__getitem__0.__getitem__("key")
    except KeyError:
        pass


# Generated at 2022-06-25 13:36:11.378189
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os

    try:
        os.environ['ansible_test_encoding'] = "ascii"
        test_environ = _TextEnviron()
        assert test_environ['ansible_test_encoding'] == 'ascii'
    finally:
        del os.environ['ansible_test_encoding']


# Generated at 2022-06-25 13:36:15.295298
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert(text_environ_0['PATH'] == '/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games')


# Generated at 2022-06-25 13:36:20.516569
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    pass

# Generated at 2022-06-25 13:36:28.951997
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        text_environ_0 = _TextEnviron()
        str_0 = text_environ_0.__getitem__('PWD')
        if str_0[-1:] == '\n':
            str_0 = str_0[:-1]
        assert str_0 == os.getcwd()
    except Exception:
        assert False

    try:
        text_environ_1 = _TextEnviron()
        str_0 = text_environ_1.__getitem__('SHELL')
        if str_0[-1:] == '\n':
            str_0 = str_0[:-1]
        assert str_0 == os.getenv('SHELL')
    except Exception:
        assert False


# Generated at 2022-06-25 13:36:37.906753
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    with pytest.raises(AnsibleFallbackToText):
        text_environ_0.__getitem__(key=bytearray(b''.join(int(c).to_bytes(1, byteorder='little') for c in '73'.split(' '))))
    with pytest.raises(AnsibleFallbackToText):
        text_environ_0.__getitem__(key=bytearray(b''.join(int(c).to_bytes(1, byteorder='little') for c in '88'.split(' '))))

# Generated at 2022-06-25 13:36:41.322691
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test for method __getitem__ of class _TextEnviron
    """
    # call __getitem__
    args = []
    with pytest.raises(TypeError) as excinfo:
        text_environ_0.__getitem__(*args)


# Generated at 2022-06-25 13:36:45.424248
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert_equals(text_environ_1['PATH'], os.environ['PATH'])
    assert_equals(text_environ_1['PATH'], text_environ_1._raw_environ['PATH'])


# Generated at 2022-06-25 13:36:51.068911
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Test the method _TextEnviron.__getitem__ of class _TextEnviron
    '''
    test_cases = ['test_case_0']
    for test_case in test_cases:
        print('in test case: {}'.format(test_case))
        test_case = _TextEnviron
        assert test_case.__getitem__() == 'test_case_0', 'The test case failed, expected: test_case_0'


# Generated at 2022-06-25 13:36:52.596299
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert text_environ_0.__getitem__('USER') == 'osmc'


# Generated at 2022-06-25 13:36:56.088848
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Put the target method on the stack
    globals()['test_case_0'].__globals__['_TextEnviron'].__getitem__(globals()['test_case_0'].__globals__['text_environ_0'],'TESTVAR')


# Generated at 2022-06-25 13:36:59.769042
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    actual = text_environ_0.__getitem__('PYTHONPATH')
    expected = os.environ['PYTHONPATH']
    assert actual == expected


# Generated at 2022-06-25 13:37:03.685302
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['PATH'] == os.environ['PATH']
    else:
        assert environ['PATH'] == os.environ['PATH'].decode('utf-8')


# Generated at 2022-06-25 13:37:22.177321
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    expected = 'hello'
    if PY3:
        # Make sure that the bare bytes and the text are the same
        assert expected == expected.encode()
    else:
        # Make sure that the bare bytes and the text are not the same
        assert expected != expected.encode()

    text_environ_expected_0 = _TextEnviron()
    text_environ_expected_0[b'ANSIBLE_MODULE_TEST_KEY'] = expected
    text_environ_0 = _TextEnviron()
    text_environ_0[b'ANSIBLE_MODULE_TEST_KEY'] = expected.encode()
    result = text_environ_0.__getitem__(b'ANSIBLE_MODULE_TEST_KEY')
    assert result == expected
    assert result == text_environ_expected_

# Generated at 2022-06-25 13:37:30.204907
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0.__getitem__("AS")
    str_1 = text_environ_0.__getitem__("XDG_VTNR")
    str_2 = text_environ_0.__getitem__("LC_MESSAGES")
    str_3 = text_environ_0.__getitem__("LANG")
    str_4 = text_environ_0.__getitem__("XDG_SESSION_ID")
    str_5 = text_environ_0.__getitem__("XDG_GREETER_DATA_DIR")
    str_6 = text_environ_0.__getitem__("XDG_MENU_PREFIX")
    str_7 = text_en

# Generated at 2022-06-25 13:37:33.979744
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Implicitly using system encoding but forcing ascii since that's what os.environ on Python2
    # does
    # This test assumes a dummy environment variable is set
    assert text_environ_0['ANSIBLE_TEST_ENV_VAR'] == 'abcd123\xe9'


# Generated at 2022-06-25 13:37:35.865993
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # __getitem__(self, key, silencing_exceptions=None)


# Generated at 2022-06-25 13:37:40.020291
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['TESTKEY'] = 'TESTVALUE'
    text_environ_0 = _TextEnviron()
    assert text_environ_0['TESTKEY'] == 'TESTVALUE'
    assert 'TESTKEY' in text_environ_0
    assert 'TESTKEY' in text_environ_0._raw_environ


# Generated at 2022-06-25 13:37:44.269039
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError) as excinfo:
        print(text_environ_0['PATH'])
    assert excinfo.value.args[0] == 'PATH'


# Generated at 2022-06-25 13:37:52.903084
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        text_environ = _TextEnviron(encoding='utf-8')
    else:
        text_environ = _TextEnviron(encoding='cp1252')

    assert text_environ['TEST_ENV_0'] == u'sin \u00f1\u0303'

    # Test handling of a unicode-capable encoding
    assert text_environ['TEST_ENV_1'] == u'Hello \u263a'

    # Test handling of a unicode-incapable encoding
    assert text_environ['TEST_ENV_2'] == u'Hello \ufffd'

    # Test handling of a unicode-incapable encoding with a non-unicode string we can't decode

# Generated at 2022-06-25 13:37:55.071613
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__('string')



# Generated at 2022-06-25 13:37:56.747343
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__('abc')
    assert result is None



# Generated at 2022-06-25 13:38:06.406180
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test case for key that is a string for a value encoded in utf-8
    # Create a _TextEnviron object to test the __getitem__() method
    text_environ_1 = _TextEnviron()
    # Create a pair key: value that is utf-8 encoded
    test_key_1 = "test_key"
    test_value_1 = "test_value\u2122"
    # Insert the test key and value into the raw environment
    text_environ_1._raw_environ[test_key_1] = test_value_1.encode(encoding='utf-8')
    # Get the value from the _TextEnviron object
    result_value = text_environ_1[test_key_1]

# Generated at 2022-06-25 13:38:30.885498
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = {'TEST0': u'case ümlaut',
               'TEST1': 'case ümlaut'.encode('utf-8'),
               'TEST2': 'case ümlaut',
               }
    text_environ = _TextEnviron(environ)
# Testing with a unicode environment variable
    assert text_environ['TEST0'] == u'case ümlaut'
# Testing with a utf-8 encoded bytes environment variable
    assert text_environ['TEST1'] == u'case ümlaut'
# Testing with an ascii encoded bytes environment variable
    assert text_environ['TEST2'] == u'case ümlaut'


# Generated at 2022-06-25 13:38:38.349178
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Note: mutable mapping can rename key, so we could have to_string failed case
    assert isinstance(environ['LC_ALL'], str)
    assert isinstance(environ['LANG'], str)
    assert isinstance(environ['PATH'], str)
    return True

if __name__ == '__main__':
    testcase_list = [test_case_0, test__TextEnviron___getitem__]
    for tc in testcase_list:
        try:
            ret = tc()
            print ("{} passed".format(tc.__name__))
        except Exception as e:
            print("{} failed: {}".format(tc.__name__, e))

# Generated at 2022-06-25 13:38:40.845284
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['AS_ROOT_CMD'] == 'sudo -H'
    assert environ['HOME'] == '/home/toshio'
    assert environ['USER'] == 'toshio'



# Generated at 2022-06-25 13:38:42.893115
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert type(environ.__getitem__('PWD')) is str



# Generated at 2022-06-25 13:38:45.149558
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    value = text_environ_0.__getitem__(key)


# Generated at 2022-06-25 13:38:51.282247
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import PY2

    text_environ_0 = _TextEnviron()
    if PY3:
        # Python3: String -> String
        assert text_environ_0['PATH'] == os.getenv('PATH')
    else:
        # Python2: String -> Unicode
        assert text_environ_0['PATH'] == os.getenv('PATH').decode(text_environ_0.encoding)


# Generated at 2022-06-25 13:38:57.270948
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0._raw_environ['PYTHONPATH'] == sys.path[0]
    assert text_environ_0['PYTHONPATH'] == sys.path[0]
    assert text_environ_0['PYTHONPATH'] is text_environ_0['PYTHONPATH']
    assert isinstance(text_environ_0['PYTHONPATH'], str)
    assert isinstance(text_environ_0['PYTHONPATH'], str)


# Generated at 2022-06-25 13:39:02.469986
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Raw value of $HOME is b'\x7f\xff\xff\xff'
    # Value should be decoded to u'\u007f\uffff\uffff\uffff'
    assert text_environ_0['HOME'] == u'\u007f\uffff\uffff\uffff'


# Generated at 2022-06-25 13:39:06.338999
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    with pytest.raises(NameError):
        text_environ_0.__getitem__('ENV_a')
    with pytest.raises(KeyError):
        text_environ_0.__getitem__('ABCD')


# Generated at 2022-06-25 13:39:15.236661
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # test1
    try:
        _msg = "Failed when getting a key from the environment returned by _TextEnviron.__getitem__: "
        assert text_environ_0['PATH'] == os.environ['PATH'], _msg + "path does not match"
    except KeyError:
        _msg = "Failed when getting a key from the environment returned by _TextEnviron.__getitem__: "
        assert os.environ['PATH'] is not None, _msg + "path not defined in environment"
    # test2

# Generated at 2022-06-25 13:39:58.222404
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Reading a text key that is encoded in ASCII
    # os.environ is modified by this test!
    try:
        os.environ['ANSIBLE_TEST_TEXT_ENVIRON'] = 'abcd'
        assert environ['ANSIBLE_TEST_TEXT_ENVIRON'] == u'abcd'
    finally:
        del os.environ['ANSIBLE_TEST_TEXT_ENVIRON']

    # Reading a text key that is encoded in ASCII
    # os.environ is modified by this test!

# Generated at 2022-06-25 13:40:07.148876
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a dictionary containing the pairs (key, value) to add to the environment
    test_values = {'unicode': u'\u00E6', 'ascii': 'ascii', 'bytes': b'bytes'}

    for key, value in test_values.items():
        # Make sure the value wasn't cached from a previous test
        if key in text_environ_0._value_cache:
            del text_environ_0._value_cache[key]

        from ansible.module_utils.six import PY3
        if PY3:
            # Python 3: the environment contains only unicode values
            assert not isinstance(value, bytes)

            # Python 3: the environment is set up such that each value is returned as unicode on
            # each call
            text_environ_0._raw_environ

# Generated at 2022-06-25 13:40:09.369274
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Testing that this returns a String
    assert isinstance(text_environ_0['__name__'], str)


# Generated at 2022-06-25 13:40:15.341038
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set up an os.environ which has a mixture of native unicode and bytes
    # First, we use a bytes version of the same dictionary that we've been using
    # throughout ansible.report.mock
    environ_bytes = os.environ.copy()
    # Now add some unicode key-value pairs to that dictionary
    environ_bytes[u'ANSIBLE_CALLBACK_WHITELIST'] = u'yaml'
    environ_bytes[u'ANSIBLE_CALLBACK_PLUGINS'] = u'./plugins/callbacks/'
    # Now convert the whole dictionary to bytes
    environ_bytes = {to_bytes(k, encoding='utf-8'): to_bytes(v, encoding='utf-8')
                     for k, v in environ_bytes.items()}

    # At the same

# Generated at 2022-06-25 13:40:17.966048
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0['SHELL']
    assert str_0 is not None


# Generated at 2022-06-25 13:40:24.279699
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Test direct hit on a key
    text_environ_0[u'SPAM'] = u'eggs'
    assert text_environ_0[u'SPAM'] == u'eggs'
    # Test miss on a key
    try:
        text_environ_0[u'SPAM'] = u'eggs'
        assert False, u"__getitem__ did not raise KeyError"
    except KeyError:
        pass
    return



# Generated at 2022-06-25 13:40:26.710594
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    returned_value = text_environ['HOME']
    assert returned_value == '/home/toshio'



# Generated at 2022-06-25 13:40:28.516292
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert text_environ_1['x'] == 'y'


# Generated at 2022-06-25 13:40:34.414504
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    if PY3:
        import os

    paths = ['/usr/bin', '/bin', '/usr/sbin', '/sbin', '/usr/local/bin', '/usr/X11/bin']
    env = _TextEnviron()
    assert isinstance(env['PATH'], str)
    assert ':' in env['PATH']
    assert all(p in env['PATH'] for p in paths)
    if PY3:
        assert env['PATH'] == os.environ['PATH']


# Generated at 2022-06-25 13:40:38.825801
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # We're setting PY3 to False here so we can test this branch of the code even though we're running
    # on Python3.
    text_environ_0.__getitem__('foo')
    text_environ_0._value_cache['foo'] = 'text'
    text_environ_0.__getitem__('foo')
    text_environ_0.__getitem__('bar')

# Generated at 2022-06-25 13:42:01.225993
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.encoding = 'utf-8'
    text_environ_0._value_cache = {}
    text_environ_0._value_cache['asdf'] = 'asdf'
    text_environ_0._raw_environ = {'asdf': 'asdf'}
    #exception = None
    try:
        # call the method given
        result = text_environ_0.__getitem__('asdf')
    except Exception as exception:
        pass
    # assert that there is no exception
    assert exception is None
    # assert that the output is equal to the value given
    assert result == 'asdf'


# Generated at 2022-06-25 13:42:03.618963
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__('ANSIBLE_CALLBACK_WHITELIST')
    assert isinstance(result, str)

# Generated at 2022-06-25 13:42:06.838563
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    str_2 = text_environ_1['ENVIRON_FOO']
    assert isinstance(str_2, str)
    str_3 = text_environ_1['ENVIRON_FOO']
    assert str_2 is str_3
    

# Generated at 2022-06-25 13:42:09.639916
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    ex_value = 'blah'
    ex_key = 'TEST'
    text_environ_0 = _TextEnviron()
    text_environ_0[ex_key] = ex_value
    text_environ_0[ex_key]


# Generated at 2022-06-25 13:42:15.772529
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    utf_8_env = os.environ
    utf_8_env.update({'HOME': '_TextEnviron.py'})
    __str___0 = str(utf_8_env)
    # Verify __str___0 with value '_TextEnviron.py'
    assert __str___0 == '_TextEnviron.py'
    text_environ_0 = _TextEnviron(utf_8_env)
    # Verify text_environ_0.__getitem__('HOME') with value '_TextEnviron.py'
    assert text_environ_0.__getitem__('HOME') == '_TextEnviron.py'

# Generated at 2022-06-25 13:42:17.685643
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__(text_environ_0.__setitem__(None, None))


# Generated at 2022-06-25 13:42:20.145634
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        print('\n== Testing _TextEnviron.__getitem__ ==')
        text_environ_0 = _TextEnviron()
        print(text_environ_0['HOME'])
    except Exception as reason:
        print('Exception: {}'.format(reason))


# Generated at 2022-06-25 13:42:25.313933
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from importlib import import_module
    import os
    import os.path
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible import module_utils
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils._text import to_bytes, to_text

    # Import module
    module_path = os.path.join(os.path.dirname(__file__), '../module_utils/text_environ.py')
    builtins = import_module('__builtin__')
    if PY3:
        builtins = import_module('builtins')
    sys.path.insert(0, module_path)

# Generated at 2022-06-25 13:42:34.298734
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.six import StringIO
    old_stderr = sys.stderr

    # Capture stderr
    sys.stderr = StringIO()

    # Simple getitem with non-unicode
    try:
        os.environ['Key1'] = 'value1'
        os.environ['Key2'] = 'value2'
        os.environ['Key3'] = 'value3'
        assert (text_environ_0['Key1'] == 'value1')
    except UnicodeDecodeError as e:
        raise

    # Simple getitem with unicode

# Generated at 2022-06-25 13:42:36.699575
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if not PY3:
        if not os.environ['PATH'].startswith(b'C:\\ansible'):
            # Skip the test
            return

    assert environ['PATH'].startswith('C:\\ansible')