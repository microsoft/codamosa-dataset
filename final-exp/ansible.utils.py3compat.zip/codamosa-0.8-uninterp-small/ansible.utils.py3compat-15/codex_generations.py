

# Generated at 2022-06-25 13:34:23.201738
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    if hasattr(os, "getuid"):
        str_0 = None
        try:
            str_0 = text_environ_0.__getitem__("USER")
            assert str_0 is not None
        except:
            var1 = sys.exc_info()[0]
            assert not True
    else:
        var2 = sys.exc_info()[0]
        assert not True


# Generated at 2022-06-25 13:34:26.451919
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    key_2 = str()
    value_3 = text_environ_1.__getitem__(key_2)
    assert value_3 == None


# Generated at 2022-06-25 13:34:28.059407
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    assert isinstance(env['PATH'], str)


# Generated at 2022-06-25 13:34:34.648694
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
#
# Setup
#
    utc_0 = _TextEnviron()
    key = environ.__getitem__()

    return_value_0 = utc_0.__getitem__(key)

#
# Postcondition 1
#
    try:
        assert return_value_0 == 'passthru'
    except AssertionError:
        raise AssertionError('Unable to check postcondition 1 for "test__TextEnviron___getitem__"')
#
# Postcondition 2
#
    try:
        assert return_value_0 == 'surrogate_or_strict'
    except AssertionError:
        raise AssertionError('Unable to check postcondition 2 for "test__TextEnviron___getitem__"')
#
# Postcondition 3
#

# Generated at 2022-06-25 13:34:39.649231
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test 1
    assert 'c' == environ['A']
    assert 'c' == environ['A']
    assert 'bbb' == environ['BB']
    assert 'bbb' == environ['BB']
    assert 'dd' == environ['CC']

# Generated at 2022-06-25 13:34:47.219482
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_1 = _TextEnviron()
    del text_environ_1
    text_environ_1 = _TextEnviron()
    text_environ_2 = _TextEnviron()
    text_environ_3 = _TextEnviron()
    text_environ_3.__getitem__(text_environ_2.__getitem__(text_environ_1.__getitem__(text_environ_0)))


# Generated at 2022-06-25 13:34:50.421299
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()

    text_environ_1['HOME'] = '1234'
    text_environ_1['LC_ALL'] = '1234'
    text_environ_1.__getitem__('HOME')



# Generated at 2022-06-25 13:34:58.561423
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # _TextEnviron.__getitem__(key)
    # test case 1
    #self.assertRaises(TypeError, _TextEnviron().__getitem__)

    # _TextEnviron.__getitem__(key)
    # test case 2
    text_environ_2 = _TextEnviron()
    os.environ['key_text_environ_1'] = 'value_text_environ_1'
    text_environ_2._raw_environ['key_text_environ_1'] = 'value_text_environ_1'
    assert text_environ_2.__getitem__('key_text_environ_1') == 'value_text_environ_1'

# Generated at 2022-06-25 13:35:07.434512
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:35:11.348083
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron({'TEST': 'TEST'})

    if PY3:
        assert text_environ_1['TEST'] == 'TEST'
    else:
      assert text_environ_1['TEST'] == u'TEST'


# Generated at 2022-06-25 13:35:15.643635
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_arg_0 = environ['HOME']
    str_arg_1 = str(str_arg_0)
    return str_arg_1

# Generated at 2022-06-25 13:35:17.654729
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Create a default instance
    # Create an instance
    environ.__getitem__("DEFAULT_BASE")
    # Normal return
    return


# Generated at 2022-06-25 13:35:21.247988
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test __getitem__ of _TextEnviron
    # Case 1 :
    text_environ_0 = _TextEnviron()
    if PY3:
        assert text_environ_0['LANG'] == 'C.UTF-8'
    else:
        assert 'C.UTF-8' == text_environ_0['LANG']


# Generated at 2022-06-25 13:35:22.103467
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert text_environ_0.__getitem__
    pass


# Generated at 2022-06-25 13:35:27.683326
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    test_cases = [
        # [test_case_id, input, expected]
        [0, 'HOME', 'home'],
        [1, 'PWD', 'pwd'],
        [2, 'PATH', 'path'],
        [3, 'MANPATH', 'manpath']
    ]

    for case_id, key, expected in test_cases:
        result = text_environ_0[key]
        assert result == expected


# Generated at 2022-06-25 13:35:36.469145
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0['LANGUAGE'] == u'en_US.UTF-8'
    #assert text_environ_0['LANGUAGE'] == 'en_US.UTF-8'
    assert to_text(text_environ_0['LANGUAGE']) == 'en_US.UTF-8', 'LANGUAGE=%s' % to_text(text_environ_0['LANGUAGE'])
    assert to_text(text_environ_0['LC_CTYPE']) == 'en_US.UTF-8', 'LC_CTYPE=%s' % to_text(text_environ_0['LC_CTYPE'])

# Generated at 2022-06-25 13:35:40.521822
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    r = text_environ_0.__getitem__("USER")
    assert type(r) == type("")
    if (sys.platform != "win32"):
        r = text_environ_0.__getitem__("HOME")
        assert type(r) == type("")


# Generated at 2022-06-25 13:35:44.323126
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['SHELL'] = to_bytes('/bin/sh', errors='surrogate_or_strict')
    result = text_environ_0['SHELL']
    assert result == '/bin/sh'


# Generated at 2022-06-25 13:35:47.263806
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert_equals(text_environ_0. __getitem__('PWD'), os.environ['PWD'])


# Generated at 2022-06-25 13:35:48.164292
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert 0


# Generated at 2022-06-25 13:35:53.345460
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Unit test for method __getitem__ of class _TextEnviron
    text_environ_1 = _TextEnviron()
    if PY3:
        text_environ_1['USER']
    else:
        # FIXME: should raise UnicodeDecodeError
        text_environ_1['USER']


# Generated at 2022-06-25 13:35:56.652610
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class mock_os(object):
        def __init__(self):
            self.environ = {}

    class mock_sys(object):
        def __init__(self):
            self.getfilesystemencoding = lambda : None

    # TODO: state machine test
    # TODO: check return
    # TODO: check exception

    return


# Generated at 2022-06-25 13:36:06.454411
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Make a dictionary to use as an environment
    in_env = {}

    # Make a TextEnviron instance with our own environment
    test_env = _TextEnviron(env=in_env)

    # Mimic Python3's os.environ behaviour which uses utf-8 for text
    assert 'utf-8' == test_env.encoding

    # Start with an empty environment
    assert 0 == len(test_env)

    #
    # Case 0: Set a key/value pair and get it back
    #
    in_env[b'first'] = b'value'
    assert 'value' == test_env['first']
    assert 'first' in test_env

    #
    # Case 1: Set a key/value pair and get it back
    #

# Generated at 2022-06-25 13:36:15.435343
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test path equal to a value in os.environ
    text_environ_0 = _TextEnviron()
    path_0 = 'PATH'
    result_0 = text_environ_0[path_0]
    assert type(result_0) is str, 'result_0 is not str'

    # Test path not in os.environ
    # The exception here is mainly for coverage testing since this is a dictionary error
    text_environ_1 = _TextEnviron()
    path_1 = 'ZHQTQZ'
    try:
        text_environ_1[path_1]
    except KeyError:
        pass


# Generated at 2022-06-25 13:36:16.548593
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()



# Generated at 2022-06-25 13:36:20.734026
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    raw_env = {b'a': b'A', b'b': b'B'}
    text_environ = _TextEnviron(env=raw_env)
    assert text_environ[b'a'] == u'A'
    assert text_environ[b'b'] == u'B'



# Generated at 2022-06-25 13:36:26.640854
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Test case: text keys
    text_environ_0['text_key'] = 'text_value'
    assert text_environ_0['text_key'] == 'text_value'
    # Test case: bytes keys
    text_environ_0[b'bytes_key'] = b'bytes_value'
    try:
        assert text_environ_0[b'bytes_key'] == 'bytes_value'
        assert False
    except KeyError:
        assert True

# Generated at 2022-06-25 13:36:28.728114
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    item_name = ""
    text_environ_0.__getitem__(item_name)


# Generated at 2022-06-25 13:36:33.696112
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(encoding='ascii')
    text_environ_0.__getitem__('LOGNAME')
    text_environ_1 = _TextEnviron(encoding='ascii')
    text_environ_1.__getitem__('LOGNAME')
    text_environ_2 = _TextEnviron()
    text_environ_2.__getitem__('LOGNAME')
    text_environ_3 = _TextEnviron()
    text_environ_3.__getitem__('LOGNAME')


# Generated at 2022-06-25 13:36:38.114918
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    value = text_environ_0['SCREENDIR']
    assert value is not None
    assert value == 'c:\\cygwin64\\var\\run\\screen', 'Expected c:\\cygwin64\\var\\run\\screen, but got ' + repr(value)


# Generated at 2022-06-25 13:36:44.379705
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test that the __getitem__ method of _TextEnviron returns text when called with a
    string key.
    """
    assert isinstance(text_environ_0.__getitem__('HOME'), str)



# Generated at 2022-06-25 13:36:48.090234
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_arg_0 = os.environ
    del str_arg_0[u'HOME']
    os.environ[u'HOME'] = u'.'
    text_environ_0['HOME']

# Generated at 2022-06-25 13:36:50.402010
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    val = text_environ.__getitem__('PATH')
    assert val is not None


# Generated at 2022-06-25 13:36:54.049730
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for bytes as value of os.environ
    with open('/dev/null', 'w') as null_file:
        text_environ_1 = _TextEnviron(env={'foobar': null_file.name})
        assert text_environ_1['foobar'] == null_file.name


# Generated at 2022-06-25 13:37:05.010725
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('USER')
    assert text_environ_0.__getitem__('TERM')
    assert text_environ_0.__getitem__('SUDO_USER')
    assert text_environ_0.__getitem__('SUDO_UID')
    assert text_environ_0.__getitem__('SUDO_GID')
    assert text_environ_0.__getitem__('USERNAME')
    assert text_environ_0.__getitem__('MAIL')
    assert text_environ_0.__getitem__('PATH')
    assert text_environ_0.__getitem__('PWD')

# Generated at 2022-06-25 13:37:08.035515
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    # Simple test for __getitem__
    assert text_environ_1.__getitem__('PATH') == os.environ['PATH']


# Generated at 2022-06-25 13:37:09.718321
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__('key')

# Generated at 2022-06-25 13:37:11.512362
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert test_case_0() is None
    assert environ['PWD'] == u'/home/toshio/source/ansible'


# Generated at 2022-06-25 13:37:13.919387
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    key = None
    value = text_environ_1[key]


# Generated at 2022-06-25 13:37:16.351157
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # ----------------------------------------------------------------------
    # Initialize test run
    text_environ_1 = _TextEnviron()
    # ----------------------------------------------------------------------
    # Run test
    # ----------------------------------------------------------------------
    # Cleanup
    


# Generated at 2022-06-25 13:37:22.203974
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_value = 'foo'
    text_environ_0 = _TextEnviron()
    environ[test_value] = test_value
    assert(text_environ_0[test_value] == test_value)



# Generated at 2022-06-25 13:37:26.457817
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    # Test case __getitem__ of class _TextEnviron with arguments: {'foo': 'bar'}
    environ['foo'] = 'bar'
    if text_environ_0['foo'] != 'bar':
        raise AssertionError('_TextEnviron.__getitem__ failed')


# Generated at 2022-06-25 13:37:31.379280
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    assert isinstance(text_environ.__getitem__(suite.name()), text_type)
    assert text_environ.__getitem__(suite.name()).encode('utf-8') == suite.name().encode('utf-8')
    assert isinstance(environ[suite.name()], text_type)
    assert environ.__getitem__(suite.name()).encode('utf-8') == suite.name().encode('utf-8')

# Generated at 2022-06-25 13:37:35.780902
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        # The standard Python3 behaviour is to return a text string
        assert type(text_environ_0['PATH']) == str
    else:
        # The standard Python2 behaviour is to return a byte string with an ASCII compatible encoding
        assert type(text_environ_0['PATH']) == unicode
    assert text_environ_0['PATH'].split(':')[0] == '/bin'


# Generated at 2022-06-25 13:37:37.739475
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    x = _TextEnviron()
    # element should be text
    return type(x['PWD']) == str


# Generated at 2022-06-25 13:37:39.506784
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    # Test non-existent key
    text_environ_0.__getitem__('key')

# Generated at 2022-06-25 13:37:45.893002
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    key_0 = 'Æ'
    item_0 = text_environ_0.__getitem__(key_0)
    assert item_0 == 'Æ'
    text_environ_1 = _TextEnviron()
    key_1 = 'Æ'
    item_1 = text_environ_1.__getitem__(key_1)
    assert item_1 == 'Æ'


# Generated at 2022-06-25 13:37:50.193381
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_key = 'PYTHON_PATH'
    assert test_key in environ
    test_value0 = os.environ[test_key]
    test_value1 = environ[test_key]
    assert test_value0 == test_value1.encode('utf-8')
    assert isinstance(test_value1, str)


# Generated at 2022-06-25 13:37:52.903254
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    item = 'ANSIBLE_TEST_VARIABLE'
    assert isinstance(text_environ[item], str), 'Failed to decode the value'


# Generated at 2022-06-25 13:37:54.433427
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()


# Generated at 2022-06-25 13:38:02.196576
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # assert text_environ_0.__getitem__('') == 0
    assert True # TODO: implement your test here


# Generated at 2022-06-25 13:38:03.269633
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-25 13:38:04.651264
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == os.environ['HOME']


# Generated at 2022-06-25 13:38:08.105311
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError) as excinfo:
        text_environ_0.__getitem__('HOME')
    assert excinfo.value.args[0] == 'HOME'


# Generated at 2022-06-25 13:38:10.363756
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Test __getitem__()
    '''
    # Test passing in a string key
    expected_value = 'Test'
    key = 'TEST'
    text_environ_0 = _TextEnviron()
    actual_value = text_environ_0[key]
    assert(actual_value==expected_value)


# Generated at 2022-06-25 13:38:13.433610
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global text_environ_0
    try:
        text_environ_0['LANG']
    except:
        raise AssertionError()
    try:
        text_environ_0['NONEXISTENT']
    except KeyError:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-25 13:38:21.004686
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import sys
    # TODO: Implement to test case of a non-string value
    # TODO: Implement to test case of a non-ascii string value where encoding is utf-8
    # TODO: Implement to test case of a non-ascii string value where encoding is cp1252
    # TODO: Implement to test case of a non-ascii string value where encoding is cp1256
    # TODO: Implement to test case of a non-ascii string value where nonstring is strict
    # TODO: Implement to test case of a non-ascii string value where nonstring is passthru
    # TODO: Implement to test case of a non-ascii string value where nonstring is empty
    # TODO: Implement to test case of a non-ascii string value where nonstring is none
   

# Generated at 2022-06-25 13:38:29.237210
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    __getitem___0 = text_environ_0.__getitem__
    __getitem___1 = text_environ_0.__getitem__
    __getitem___1('jPAbwJp')
    str_0 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    int_0 = -53
    float_0 = -9.9
    float_1 = -4.4
    float_2 = -4.4
    float_3 = 39.9
    float_4 = -52.8
    str_1 = 'zalgaQu'
    str_2 = 'VKsXFPn'
    list_0 = ['fTvLl']

# Generated at 2022-06-25 13:38:35.395884
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # We can't test for the exact output since the environment variables in our test system aren't
    # always going to be the same as the user's system
    text_environ_0 = _TextEnviron()

    # Store the value of the key so we can check it later.
    var_0 = list(text_environ_0.keys())[0]

    try:
        assert text_environ_0[var_0] == os.environ[var_0]
    except AssertionError:
        pass


# Generated at 2022-06-25 13:38:37.280681
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__('HOME')


# Generated at 2022-06-25 13:38:45.391412
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    assert(isinstance(text_environ.__getitem__('LANG'), str))


# Generated at 2022-06-25 13:38:47.893903
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.get('HOME') == '/home/toshio'


# Generated at 2022-06-25 13:38:52.453962
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    key = to_bytes('ANSIBLE_LOCALE', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    assert text_environ[key] == to_text(key, encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    

# Generated at 2022-06-25 13:38:55.369897
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == to_text(os.environ['HOME'], encoding='utf-8')

if __name__ == '__main__':
    test_case_0()
    test__TextEnviron___getitem__()

    print('Completed the test')

# Generated at 2022-06-25 13:38:57.945158
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    u'hello' in text_environ_0 # __contains__
    text_environ_0['hello'] # __getitem__
    # AssertionError: 'hello' in text_environ_0


# Generated at 2022-06-25 13:39:00.591796
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0['PATH']


# Generated at 2022-06-25 13:39:02.605696
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1.__getitem__(3)


# Generated at 2022-06-25 13:39:04.347503
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH']
    assert environ['PATH'] == os.environ['PATH']



# Generated at 2022-06-25 13:39:07.084785
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert text_environ_1['PWD'] == os.environ['PWD']


# Generated at 2022-06-25 13:39:10.994614
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with open('/etc/hosts', 'rb') as fobj_0:
        text_environ_0.__setitem__('Name_1', fobj_0.read())
    text_environ_0.__getitem__('Name_1')


# Generated at 2022-06-25 13:39:25.246655
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Unit test for method __getitem__ of class _TextEnviron"""
    text_environ_1 = _TextEnviron()
    test_value = text_environ_1
    assert isinstance(test_value, _TextEnviron)

    text_environ_1 = _TextEnviron({'HOME': '/home/jdoe'})
    test_value = text_environ_1['HOME']
    assert test_value == '/home/jdoe'
    test_value = text_environ_1['LC_ALL']
    assert test_value == 'C'

    # Test with a non-ascii character in the value
    text_environ_2 = _TextEnviron({'HOME': '/home/jdoe/cédille'})
    test_value = text_environ_2['HOME']


# Generated at 2022-06-25 13:39:34.704034
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0['HOME'] == None
    assert text_environ_0['DNSDOMAIN'] == None
    assert text_environ_0['XDG_VTNR'] == None
    assert text_environ_0['t'] == None
    assert text_environ_0['XDG_RUNTIME_DIR'] == None
    assert text_environ_0['SSH_AGENT_PID'] == None
    assert text_environ_0['LANG'] == None
    assert text_environ_0['GPG_AGENT_INFO'] == None
    assert text_environ_0['TERM'] == None
    assert text_environ_0['XDG_DATA_DIRS'] == None
    assert text_environ_

# Generated at 2022-06-25 13:39:36.921672
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['PATH'] is os.environ['PATH']

        # Test caching the value too.
        assert environ['PATH'] is os.environ['PATH']
    else:
        assert environ['PATH'] == os.environ['PATH']

        # Test caching the value too.
        assert environ['PATH'] == os.environ['PATH']



# Generated at 2022-06-25 13:39:40.449856
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    origin = os.environ
    os.environ = {b'testcase': b'abc'}
    text_environ_0 = _TextEnviron()
    value_0 = text_environ_0['testcase']
    os.environ = origin
    assert value_0 == u'abc'


# Generated at 2022-06-25 13:39:45.230063
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__('_TextEnviron.test_case_0.text_environ_0')
    assert (result == 'test_case_0._test__TextEnviron___getitem__:test_case_0.text_environ_0'
            or result == 'test_case_0._test__TextEnviron___getitem__:test_case_0.text_environ_0:')

# Generated at 2022-06-25 13:39:50.583315
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # __getitem__: unicode key, unicode value and non-unicode value
    environ_0 = _TextEnviron()
    assert isinstance(environ_0['LANG'], str)
    assert environ_0['LANG'] == 'en_US.UTF-8'
    assert isinstance(environ_0['PATH'], str)
    assert environ_0['PATH'] == '/usr/local/bin:/usr/bin:/bin:/usr/games'


# Generated at 2022-06-25 13:39:54.070233
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.update({u'TZ': u'LANGUAGE=C:PYTHONIOENCODING=UTF-8:PYTHONPATH=.'})
    for key in text_environ_0:
        text_environ_0[key]



# Generated at 2022-06-25 13:39:56.685938
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['key'] = 'value'
    assert text_environ_0['key'] == 'value'


# Generated at 2022-06-25 13:39:59.383417
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test to get valid string value
    text_environ_0 = _TextEnviron()
    result = text_environ_0['PATH']


# Generated at 2022-06-25 13:40:02.901314
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Verify that retrieving an existing key returns the expected value
    assert environ['PATH'] == os.environ['PATH']
    # Verify that retrieving a non-existant key raises the expected exception
    with pytest.raises(KeyError):
        environ['NONEXISTANT_KEY']


# Generated at 2022-06-25 13:40:18.083414
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__('TEST')



# Generated at 2022-06-25 13:40:24.774719
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    text_environ_1 = _TextEnviron()
    if PY3:
        assert text_environ_1['PATH'] == os.environ['PATH']
    else:
        assert text_environ_1['PATH'] == os.environ['PATH'].decode('utf-8')

    assert text_environ_1['PATH'] == text_environ_1['PATH']

    text_environ_2 = _TextEnviron(encoding='utf-8')
    assert text_environ_2['PATH'] == text_environ_1['PATH']


# Generated at 2022-06-25 13:40:27.798350
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['PATH'] == os.environ['PATH']
    else:
        assert environ['PATH'] == os.environ['PATH'].decode('utf-8')


# Generated at 2022-06-25 13:40:30.504307
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['foo'] = u'bar'
    assert text_environ_0['foo'] == 'bar'


# Generated at 2022-06-25 13:40:35.924829
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    text_environ_0.__setitem__('lang', b'en_US.UTF-8')
    exp = u'en_US.UTF-8'
    act = text_environ_0.__getitem__('lang')
    assert exp == act

    exp = u'en_US.UTF-8'
    act = text_environ_0.__getitem__('LANG')
    assert exp == act


# Generated at 2022-06-25 13:40:37.953567
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_0 = _TextEnviron()
    str_arg_0 = '1.0'
    assert(environ_0.__getitem__  (str_arg_0) == None)


# Generated at 2022-06-25 13:40:41.844654
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0['MAIL']
    expected = to_text(os.environ['MAIL'], encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict')
    assert result == expected


# Generated at 2022-06-25 13:40:44.194277
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert to_text(environ['PATH']) == environ['PATH']
    assert to_text(environ['PWD']) == environ['PWD']


# Generated at 2022-06-25 13:40:52.913925
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    r'''Test the method __getitem__ of class _TextEnviron.
    '''
    from datetime import datetime
    from unittest import TestCase, TestLoader, TextTestRunner

    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import MutableMapping

    class Test__TextEnviron___getitem__(TestCase):
        '''
        Test the method __getitem__ of class _TextEnviron.
        '''
        def setUp(self):
            self.random_items = {}
            self.random_keys = []
            for i in range(10):
                key = 'random_key_%s' % i
                value = 'random_value_%s' % i
                self.random_items[key] = value


# Generated at 2022-06-25 13:40:56.181065
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test case: Returns a unicode object representing the value of the environment
    # variable.
    # The environment variable in question is unicode on Python3, so just return it
    # unmodified.
    environ['a'] = 'b'
    a = environ['a']
    assert isinstance(a, str)
    a_b = environ['a'] == 'b'
    assert a_b


# Generated at 2022-06-25 13:41:25.903557
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron({u'ANSIBLE_LOCALHOST_WARNING': u'false', u'ANSIBLE_FORCE_COLOR': u'1'})
    assert text_environ_1[u'ANSIBLE_LOCALHOST_WARNING'] == u'false'


# Generated at 2022-06-25 13:41:26.808687
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Nothing here yet
    pass


# Generated at 2022-06-25 13:41:28.402247
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    key = 'PATH'
    value = environ[key]
    assert isinstance(value, str)


# Generated at 2022-06-25 13:41:32.574913
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Creation of instances for testing
    text_environ_0 = _TextEnviron()

    # Testing method __getitem__ of class _TextEnviron with arguments
    # This method can be called with an integer
    # The arguments have already been converted to a list: [item]
    assert text_environ_0.__getitem__(0) is None


# Generated at 2022-06-25 13:41:38.172444
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()

    # TODO: Implement this unit test
    text_environ[b'byte_key'] = b'byte_value'
    text_environ[b'unicode_key'] = u'unicode_value'
    assert text_environ[b'byte_key'] == 'byte_value'
    assert text_environ[b'unicode_key'] == u'unicode_value'

    # TODO: Unit test for accessing an environment variable that's not present
    # TODO: Unit test for accessing an environment variable that changes


# Generated at 2022-06-25 13:41:43.281189
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set up test case
    text_environ_0 = _TextEnviron()
    item_key = 'Z'
    # Execute code being tested
    result = text_environ_0.__getitem__(item_key)
    # Verify expected results
    assert result == os.environ['Z']
    # Clean up - none necessary


# Generated at 2022-06-25 13:41:44.177265
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-25 13:41:45.628098
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    pass


# Generated at 2022-06-25 13:41:48.063155
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['foo'] = 'bar'
    print(type(environ['foo']))
    assert isinstance(environ['foo'], str)
    assert environ['foo'] == 'bar'

# Generated at 2022-06-25 13:41:53.407863
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global text_environ_0
    print("Test that environment variables are decoded.")
    type(text_environ_0)
    unicode = to_text("UTF-8")
    type(unicode)
    unicode = to_text("Not UTF-8")
    to_text("Not UTF-8")
    to_text("Not UTF-8")
    type(unicode)
    unicode = to_text("Not UTF-8")
    type(unicode)


# Generated at 2022-06-25 13:42:59.808003
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0._raw_environ
    assert text_environ_0.encoding == 'utf-8'
    assert text_environ_0._value_cache == {}
    assert text_environ_0
    assert text_environ_0.__len__() == 0


# Generated at 2022-06-25 13:43:03.662462
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Testing os.environ on Python2
    if not PY3:
        if 'PATH' in text_environ_0:
            assert not isinstance(text_environ_0['PATH'], str)
    # Testing os.environ on Python3
    if PY3:
        if 'PATH' in text_environ_0:
            assert isinstance(text_environ_0['PATH'], str)


# Generated at 2022-06-25 13:43:05.864018
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # initialization of object
    text_environ_obj = _TextEnviron()

    # Negative testcase no:1
    with pytest.raises(KeyError) as excinfo:
        print(text_environ_obj['asd'])
    assert excinfo.value.args[0] == 'asd'


# Generated at 2022-06-25 13:43:09.584907
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    new_environ = {'ANSIBLE_MODULE_ARGS': '{"debug": false, "inject_facts": "true"}'}
    environ = _TextEnviron(new_environ)
    value = environ['ANSIBLE_MODULE_ARGS']
    assert(value == new_environ['ANSIBLE_MODULE_ARGS'])
    return value


# Generated at 2022-06-25 13:43:11.013682
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert text_environ_0.__getitem__('SHELL') == '/bin/bash'


# Generated at 2022-06-25 13:43:14.162043
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__setitem__('foo', 'bar')
    assert text_environ_0.__getitem__('foo') == 'bar'


# Generated at 2022-06-25 13:43:17.717744
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """ """
    # Python3 case
    if sys.version_info >= (3, 0):
        assert environ.__getitem__('PATH') == os.environ['PATH']
    # Python2 case
    else:
        assert environ.__getitem__('PATH') == to_text(os.environ['PATH'])


# Generated at 2022-06-25 13:43:22.889790
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Case 1: PY3 returns value
    text_environ_1 = _TextEnviron()
    value = text_environ_1['USER']
    assert(value == 'user1')

    # Case 2: !PY3 returns text value
    text_environ_2 = _TextEnviron()
    value = text_environ_2['USER']
    assert(value == 'user1')


# Generated at 2022-06-25 13:43:25.428633
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    out = environ.__getitem__('SHELL')
    assert out == "/bin/sh"


# Generated at 2022-06-25 13:43:33.998607
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = os.environ.keys()
    var_0_0 = text_environ_0['USER']
    var_0_1 = var_0
    var_1 = os.environ.items()
    var_1_0 = text_environ_0['USER']
    var_1_1 = var_1
    var_2 = os.environ.values()
    var_2_0 = text_environ_0['USER']
    var_2_1 = var_2
    var_3 = os.environ.get('USER')
    var_3_0 = text_environ_0['USER']
    var_3_1 = var_3
    var_4 = os.environ.pop('USER')
    var_4