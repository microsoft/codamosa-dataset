

# Generated at 2022-06-25 13:34:17.417262
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    for key in ('TEXT', 'INT', 'LIST'):
        try:
            if '0' != text_environ_0[key]:
                assert False
        except KeyError:
            assert False
        except AssertionError:
            raise AssertionError()


# Generated at 2022-06-25 13:34:27.760027
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # new instance of class _TextEnviron with no env
    text_environ_0 = _TextEnviron()
    # the value of key 'PATH' should be '/Users/ozgur/anaconda/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'
    assert text_environ_0['PATH'] == '/Users/ozgur/anaconda/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin'
    # the value of key 'HOME' should be '/Users/ozgur'
    assert text_environ_0['HOME'] == '/Users/ozgur'
    # check if the value of key 'ANSIBLE' is not None
    assert text_environ_0['ANSIBLE'] is not None
    # check if the value of key 'ANSIBLE' is

# Generated at 2022-06-25 13:34:30.543523
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
# Test case 0
    text_environ_0 = _TextEnviron()
    text_environ_1 = _TextEnviron()
    assert 'HOME' in text_environ_0
    assert 'HOME' in text_environ_0
    assert text_environ_1['HOME'] == text_environ_0['HOME']

# Generated at 2022-06-25 13:34:38.195146
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        text_environ_0 = _TextEnviron()

        # Normal operation
        assert sys.version_info[0] == text_environ_0['PYTHON_MAJOR_VERSION']

        # Throw exception when byte-string is not decodable
        os.environ.__setitem__('PYTHON_MAJOR_VERSION', b'\x7f')
        try:
            text_environ_0['PYTHON_MAJOR_VERSION']
            assert False
        except UnicodeDecodeError:
            assert True
    else:
        text_environ_0 = _TextEnviron()

        # Normal operation
        assert sys.version_info[0] == int(text_environ_0['PYTHON_MAJOR_VERSION'])

        # Throw

# Generated at 2022-06-25 13:34:45.268979
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    print('Testing __getitem__ ...')
    if PY3:
        # On Python3, non-unicode values are returned as is
        assert text_environ_0['PATH'] == os.environ['PATH']
    else:
        # On Python2, non-unicode values are converted to unicode
        assert text_environ_0['PATH'] == os.environ['PATH'].decode(sys.getfilesystemencoding())


# Generated at 2022-06-25 13:34:48.388114
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global environ
    assert environ['PATH'] == u'/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin'


# Generated at 2022-06-25 13:34:51.112626
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert to_text(text_environ_0['PATH']) == to_text(os.environ['PATH'])



# Generated at 2022-06-25 13:34:55.723920
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print('Start test__TextEnviron___getitem__')
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__('testVarName')
    text_environ_0.__getitem__('testVarName')
    print('End test__TextEnviron___getitem__')


# Generated at 2022-06-25 13:34:57.416321
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    data = 'dummydata'
    text_environ = _TextEnviron()
    text_environ[data] = data
    assert(text_environ[data] == data)


# Generated at 2022-06-25 13:34:59.374175
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['n'] = 'foo'
    text_environ_0['n']


# Generated at 2022-06-25 13:35:01.804041
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-25 13:35:03.853018
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    res = text_environ_0.__getitem__('')



# Generated at 2022-06-25 13:35:04.715152
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()

# Generated at 2022-06-25 13:35:13.767129
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_str_0 = text_environ_0.__getitem__('M')
    text_str_1 = text_environ_0.__getitem__('B')
    text_str_2 = text_environ_0.__getitem__('I')
    text_str_3 = text_environ_0.__getitem__('L')
    text_str_4 = text_environ_0.__getitem__('L')
    text_str_5 = text_environ_0.__getitem__('I')
    text_str_6 = text_environ_0.__getitem__('A')
    text_str_7 = text_environ_0.__getitem__('R')
    text_str_8 = text_

# Generated at 2022-06-25 13:35:16.438293
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert os.environ['PATH'] == environ['PATH']
    else:
        assert environ['PATH'] == to_text(os.environ['PATH'], encoding='utf-8',
                                          nonstring='passthru', errors='surrogate_or_strict')

# Generated at 2022-06-25 13:35:17.650818
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    # Load the environment
    text_environ_0.__getitem__('SHELL')

# Generated at 2022-06-25 13:35:19.775059
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # TODO: Something to compare against
    # Implicit return value
    try:
        text_environ_0.__getitem__('LC_ALL')
    except AttributeError:
        pass


# Generated at 2022-06-25 13:35:21.499154
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert(text_environ_0['HOME'] == text_environ_0._raw_environ['HOME'])


# Generated at 2022-06-25 13:35:24.173535
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ[u'test'] == os.getenv(u'test')
    else:
        assert environ[u'test'] == os.getenv(u'test').decode('utf-8')


# Generated at 2022-06-25 13:35:27.429781
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    key = "HTTP_USER_AGENT"
    text_environ_0 = _TextEnviron()
    # assert text_environ_0.__getitem__(key) is not None
    # Key error
    # assert text_environ_0.__getitem__("PATH") is not None


# Generated at 2022-06-25 13:35:32.339743
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Input parameters
    key = 'HOME'

    # Expected return value
    expected = environ[key]

    # Actual return value
    actual = _TextEnviron()[key]

    # Unit test
    assert expected == actual


# Generated at 2022-06-25 13:35:35.227406
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.get_item('HOME')
    text_environ_0.get_item('LOGNAME')


# Generated at 2022-06-25 13:35:37.711560
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    assert text_environ.__getitem__('PATH') == os.environ['PATH']


# Generated at 2022-06-25 13:35:39.785297
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global text_environ_0
    assert text_environ_0.__getitem__('PYTHONHTTPSVERIFY') == '0'


# Generated at 2022-06-25 13:35:47.264355
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        os.environ['FOO_BAR'] = 'foobar'
        assert os.environ['FOO_BAR'] == 'foobar'
        os.environ['BAZ'] = b'baz'
        assert os.environ['BAZ'] == 'baz'
    else:
        os.environ['FOO_BAR'] = b'foobar'
        assert os.environ['FOO_BAR'] == u'foobar'
        os.environ['BAZ'] = 'baz'
        assert os.environ['BAZ'] == u'baz'


# Generated at 2022-06-25 13:35:48.806497
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    func_call_0 = text_environ_0.__getitem__(__name__)
    text_type_0 = type(func_call_0)
    assert text_type_0 == str



# Generated at 2022-06-25 13:35:52.178937
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Should return value
    assert text_environ_0.__getitem__('SHELL') == '/bin/bash'
    # Should raise KeyError
    try:
        assert text_environ_0.__getitem__('blah') == 'blah'
    except KeyError:
        pass


# Generated at 2022-06-25 13:35:55.151696
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create test object
    text_environ_0 = _TextEnviron()
    assert isinstance(text_environ_0, _TextEnviron)
    # Call method
    result = text_environ_0['COLUMNS']
    # Check result
    assert result == '80'


# Generated at 2022-06-25 13:36:05.748724
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a new instance of _TextEnviron
    text_environ_1 = _TextEnviron()
    # Assert that the key 'HOME' is in the text_environ_1._raw_environ
    assert 'HOME' in text_environ_1._raw_environ
    # Assert that the value of the key 'HOME' in the text_environ_1._raw_environ is the same as the
    # value returned by the call to __getitem__
    assert text_environ_1._raw_environ['HOME'] == text_environ_1['HOME']
    # If this is not Python 3, confirm that converting the value from the
    # text_environ_1._raw_environ back to text matches the value returned by the call to
    # __getitem__

# Generated at 2022-06-25 13:36:06.732433
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    raise NotImplementedError()


# Generated at 2022-06-25 13:36:13.600572
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    key_0 = 'LANG'
    var_0 = text_environ_0[key_0]
    print(var_0)


# Generated at 2022-06-25 13:36:19.587765
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        # Set expected values
        expected_value = 'dummy'

        # Invoke method
        text_environ_0 = _TextEnviron()
        actual_value = text_environ_0.__getitem__(expected_value)

    except Exception as e:
        # Asserting the error throw message
        assert False

    # Asserting the results
    assert actual_value is expected_value


# Generated at 2022-06-25 13:36:21.019560
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0._TextEnviron__getitem__('')


# Generated at 2022-06-25 13:36:23.728370
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0.__getitem__('HOME')
    assert str_0 is not None


# Generated at 2022-06-25 13:36:26.142778
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_1 = text_environ_0.__getitem__('SHELL')
    assert var_1 == abs_path_0



# Generated at 2022-06-25 13:36:30.561165
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with unicode string as key
    assert environ['ANSIBLE_CALLBACK_PLUGINS_STR'] == os.environ['ANSIBLE_CALLBACK_PLUGINS_STR']
    # Test with bytes string as key
    assert environ[b'ANSIBLE_CALLBACK_PLUGINS_BS'] == os.environ[b'ANSIBLE_CALLBACK_PLUGINS_BS']


# Generated at 2022-06-25 13:36:32.738786
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    value = text_environ.__getitem__('PATH')
    assert isinstance(value, str)


# Generated at 2022-06-25 13:36:35.273057
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert type(text_environ_0.__getitem__("owWmiUyD6hY9K2")) is unicode


# Generated at 2022-06-25 13:36:36.459328
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == os.environ['PATH']


# Generated at 2022-06-25 13:36:41.482282
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__delitem__('USER')
    text_environ_0.__setitem__('USER', 'foo')
    text_environ_0.__getitem__('USER')
    assert text_environ_0.__getitem__('USER') == 'foo'



# Generated at 2022-06-25 13:36:49.525592
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test that the _TextEnviron class returns unicode strings rather than byte strings
    """
    text_environ_1 = _TextEnviron()

    os.environ[u'my_key'] = u'my_value'
    assert text_environ_1[u'my_key'] == u'my_value'


# Generated at 2022-06-25 13:36:56.773885
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Sanity check; this should never be true because _TextEnviron is instantiated before __main__
    # is run
    if PY3:
        return

    # Create the test cases.

# Generated at 2022-06-25 13:37:00.544524
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    if PY3:
        assert isinstance(text_environ_0['LC_ALL'], str)
    else:
        assert isinstance(text_environ_0['LC_ALL'], unicode)


# Generated at 2022-06-25 13:37:04.196856
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # __getitem__(self, key)
    res = text_environ_0.__getitem__('TEST_VAR_TEST_VALUE')


# Generated at 2022-06-25 13:37:07.722336
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import ansible.module_utils.six as six
    if six.PY2:
        pass
    elif six.PY3:
        pass
    else:
        raise TypeError("Unknown python version")


# Generated at 2022-06-25 13:37:08.669386
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    _TextEnviron.__getitem__()


# Generated at 2022-06-25 13:37:12.002744
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1['PYTHONPATH'] = 'swim'
    text_environ_1['_'] = 'dive'

    assert(text_environ_1['PYTHONPATH'] == 'swim')
    assert(text_environ_1['_'] == 'dive')


# Generated at 2022-06-25 13:37:15.105819
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError):
        text_environ_0.__getitem__('T_')


# Generated at 2022-06-25 13:37:25.151096
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = test_case_0()
    # AssertionError: TextEnviron['ANSIBLE_ANSIBLE_CONFIG_DIR'] != os.environ['ANSIBLE_ANSIBLE_CONFIG_DIR']
    assert text_environ_0['ANSIBLE_ANSIBLE_CONFIG_DIR'] == os.environ['ANSIBLE_ANSIBLE_CONFIG_DIR']
    # AssertionError: TextEnviron['ANSIBLE_CONFIG'] != os.environ['ANSIBLE_CONFIG']
    assert text_environ_0['ANSIBLE_CONFIG'] == os.environ['ANSIBLE_CONFIG']
    # AssertionError: TextEnviron['ANSIBLE_CONFIG_DIR'] != os.environ['ANSIBLE_CONFIG_DIR']

# Generated at 2022-06-25 13:37:29.799497
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({b'k01': b'v01', 'k02': b'v02', u'k03': u'v03', 'k04': u'v04'}, 'utf-8')
    assert environ['k01'] == u'v01'
    assert environ['k02'] == u'v02'
    assert environ['k03'] == u'v03'
    assert environ['k04'] == u'v04'


# Generated at 2022-06-25 13:37:40.719333
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    try:
        if PY3:
            assert text_environ_1['PATH'] == 'whatever'
        else:
            assert text_environ_1[b'PATH'] == 'whatever'
    except KeyError:
        pass


# Generated at 2022-06-25 13:37:45.122271
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test when the environment has text values
    for key in environ.keys():
        assert isinstance(environ[key], text_type)
    # Test when the environment has non-text values, including None
    # TODO: add and test non-text encoded values


# Generated at 2022-06-25 13:37:51.451179
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    text_environ_0 = _TextEnviron()
    assert isinstance(text_environ_0['PATH'], str), \
        'Return of Environ.__getitem__() is not of type str'
    assert isinstance(text_environ_0['LC_ALL'], str), \
        'Return of Environ.__getitem__() is not of type str'
    assert isinstance(text_environ_0['LANG'], str), \
        'Return of Environ.__getitem__() is not of type str'


# Generated at 2022-06-25 13:37:55.809002
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Only test Python 2 because the cache is only needed for Python 2
    if PY3:
        return

    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0.__getitem__('USER')
    str_0 = text_environ_0.__getitem__('USER')
    str_0 = text_environ_0.__getitem__('USER')
    assert str_0 == os.environ['USER']


# Generated at 2022-06-25 13:37:57.886812
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    u'This is the text environ' in text_environ_0.__getitem__('ANSIBLE_CONFIG')


# Generated at 2022-06-25 13:38:07.705663
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Ensure that an environment variable that always exists can be parsed into text
    text_environ_0 = _TextEnviron()
    if PY3:
        text_environ_0[b'PATH'] == os.environ['PATH']
    else:
        text_environ_0[b'PATH'] == os.environ[b'PATH']

    # Test that an environment variable that is mutated also has it's text representation being
    # mutated

# Generated at 2022-06-25 13:38:11.228631
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        text_environ_0 = _TextEnviron()
        text_environ_0.__getitem__('0U6XVS')
    except KeyError as exc:
        assert str(exc) == "Environment variable '0U6XVS' not found"


# Generated at 2022-06-25 13:38:13.339556
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Verify that this method returns the correct type
    assert isinstance(environ['TEST_ENV_TEST_FOO'], str), "Method __getitem__ returns incorrect type"


# Generated at 2022-06-25 13:38:14.979946
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('TEXT_ENVIRONMENT_0') is not None



# Generated at 2022-06-25 13:38:22.399506
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a _TextEnviron object
    text_environ_0 = _TextEnviron()
    # Call method __getitem__ of class _TextEnviron with argument 'PWD'
    result = text_environ_0.__getitem__('PWD')
    # Assert that method __getitem__ of class _TextEnviron returned the correct value
    assert result == os.getcwd()
    # Call method __getitem__ of class _TextEnviron with argument 'ANSIBLE_LIBRARY'
    result = text_environ_0.__getitem__('ANSIBLE_LIBRARY')
    # Assert that method __getitem__ of class _TextEnviron returned the correct value
    assert result == '/home/vcap/app/ansible/library'

# Generated at 2022-06-25 13:38:43.254505
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['TEST'] = 'foo'
    value = text_environ_0._raw_environ['TEST']
    assert value == 'foo'
    # Calling the base method with a valid key should return the associated value
    value = text_environ_0.__getitem__('TEST')
    assert value == 'foo'



# Generated at 2022-06-25 13:38:47.847238
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        # Python 3
        assert u'foobar' == environ['FOOBAR']
    else:
        # Python 2
        # TODO: figure out why the utf-8 encoded environment variables work on python2-remote
        # but not python2-local
        pass



# Generated at 2022-06-25 13:38:49.134131
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    #TODO Add test
    pass


# Generated at 2022-06-25 13:38:53.231064
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(env={"hello": "world"})
    assert env["hello"] == "world"
    assert env.get("hello") == "world"
    assert env.get("not_there") is None
    env["hello"] = "foobar"
    assert env["hello"] == "foobar"


# Generated at 2022-06-25 13:38:55.793649
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0[u'HOME'] == u'/home/user' and type(text_environ_0[u'HOME']) == unicode


# Generated at 2022-06-25 13:38:58.881956
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    test_key = 'test_key'
    test_value = 'test_value'
    if test_key in text_environ:
        text_environ.pop(test_key)
    text_environ[test_key] = test_value
    assert text_environ[test_key] == test_value


# Generated at 2022-06-25 13:39:01.664560
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    # set up parameters
    key = 'PATH'
    # execute method
    result = text_environ_1.__getitem__(key)


# Generated at 2022-06-25 13:39:11.032848
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # from ansible.module_utils.six import PY3
        
    # Establish that __getitem__ returns None, None for any unknown key
    # (taken from https://github.com/ansible/ansible/blob/devel/test/units/module_utils/six_test.py)
    # _text_environ_0 = _TextEnviron()
    # _result = _text_environ_0.__getitem__(key)
    # assert isinstance(_result, None)
    
    # Establish that __getitem__ returns None, None for key 'foobar'
    _text_environ_0 = _TextEnviron()
    _result = _text_environ_0.__getitem__('foobar')
    assert isinstance(_result, None)
    
    # Establish that __

# Generated at 2022-06-25 13:39:12.708642
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0['str']

# Generated at 2022-06-25 13:39:20.460093
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    new_environ = {
        u'unicode_key': u'unicode_value',
        b'byte_key': b'byte_value',
        u'unicode_bytes_key': to_bytes(u'\u03B1'),
        b'bytes_bytes_key': b'\xce\xb1',
        u'bytes_unicode_key': to_text(b'\xce\xb1'),
    }
    # If we have Python3, this will be byte strings
    if PY3:
        new_environ[u'unicode_byte_key'] = to_bytes('\u03B1')
        new_environ[u'byte_byte_key'] = b'\xce\xb1'
    else:
        new_environ[u'unicode_byte_key']

# Generated at 2022-06-25 13:40:03.308163
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0[text('DBUS_SESSION_BUS_ADDRESS')] == text('unix:abstract=/tmp/dbus-YwWfV8pvCz,guid=3f3a35df159d95d80975caa982408bbe')
    assert text_environ_0[text('DEFAULTS_PATH')] == text('/usr/share/gconf/gnome.default.path')
    assert text_environ_0[text('MPLBACKEND')] == text('module://ipykernel.pylab.backend_inline')
    assert text_environ_0[text('LOGNAME')] == text('qasdfgh')

# Generated at 2022-06-25 13:40:11.336423
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    arg_str_0 = ''
    try:
        text_environ_0.__getitem__(arg_str_0)
    except KeyError:
        pass
    else:
        raise AssertionError('KeyError not raised')
    text_environ_1 = _TextEnviron()
    arg_str_1 = '\x00'
    try:
        text_environ_1.__getitem__(arg_str_1)
    except KeyError:
        pass
    else:
        raise AssertionError('KeyError not raised')
    text_environ_2 = _TextEnviron()
    arg_str_2 = 'TEST_VAR_TO_SET'
    arg_str_3 = '\x00'

# Generated at 2022-06-25 13:40:13.421020
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert text_environ_1.keys() is not None
    assert text_environ_1.values() is not None
    assert text_environ_1.items() is not None

# Generated at 2022-06-25 13:40:14.386094
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert (environ['PATH'] == os.environ['PATH'])


# Generated at 2022-06-25 13:40:17.849689
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1.__getitem__("HOME")
    with pytest.raises(KeyError):
        text_environ_1.__getitem__("$FOO")


# Generated at 2022-06-25 13:40:19.278951
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test 1: should get some value of os.environ.
    assert environ['PATH'] != ''


# Generated at 2022-06-25 13:40:25.110097
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Case 0: key not in environ
    try:
        text_environ_0 = _TextEnviron(encoding='utf-8')
        text_environ_0__getitem___0 = text_environ_0.__getitem__('non_existent_key')
        assert(text_environ_0__getitem___0 is not None)
    except KeyError:
        return

    raise Exception('Test Case 0 failed')


# Generated at 2022-06-25 13:40:34.139171
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # This is a noop test in Python 3
    if not PY3:
        str_0 = os.environ.get('HOME', None)
        str_1 = text_environ_0.get('HOME', None)
        assert str_1 == str_0, 'Expected "%(str_0)s", but got "%(str_1)s"' % {'str_1': str_1, 'str_0': str_0}
        str_3 = os.environ.get('SHELL', None)
        str_4 = text_environ_0.get('SHELL', None)

# Generated at 2022-06-25 13:40:36.315484
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0['LANG'] == 'en_US.utf-8'


# Generated at 2022-06-25 13:40:44.565955
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0['PATH'] == text_environ_0['PATH']
    assert text_environ_0['PATH'] == text_environ_0['PATH']
    assert text_environ_0['PATH'] == text_environ_0['PATH']
    assert text_environ_0['PATH'] == text_environ_0['PATH']
    assert text_environ_0['PATH'] == text_environ_0['PATH']
    assert text_environ_0['PATH'] == text_environ_0['PATH']
    assert text_environ_0['PATH'] == text_environ_0['PATH']
    assert text_environ_0['PATH'] == text_environ_0['PATH']

# Generated at 2022-06-25 13:42:01.119180
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_2 = _TextEnviron()
    key_value = u"text_environ_1"
    with pytest.raises(KeyError) as ex:
        text_environ_2.__getitem__(key_value)
    assert 'text_environ_1' in str(ex)
    assert 'is not defined' in str(ex)


# Generated at 2022-06-25 13:42:08.634353
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a string that needs to be decoded
    os.environ['__ansible_test_env_encoding__'] = to_bytes('this is a test', encoding='utf-8')
    assert environ['__ansible_test_env_encoding__'] == 'this is a test'

    # Test with a string that is ascii encoded
    os.environ['__ansible_test_env_ascii__'] = 'ascii'
    assert environ['__ansible_test_env_ascii__'] == 'ascii'

    # Test with a string that is unicode
    os.environ['__ansible_test_env_unicode__'] = 'unicode'
    assert environ['__ansible_test_env_unicode__'] == 'unicode'

    # Test with

# Generated at 2022-06-25 13:42:11.618383
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    key_1 = 'SSH_CLIENT'
    result_1 = text_environ_1.__getitem__(key_1)
    assert result_1 is not None
    assert isinstance(result_1, str)
    assert len(result_1) > 0


# Generated at 2022-06-25 13:42:15.239055
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    if PY3:
        assert environ['SHELL'] == environ._raw_environ['SHELL']
    else:
        assert environ['SHELL'] == to_text(environ._raw_environ['SHELL'], encoding=sys.getfilesystemencoding(),
                                           nonstring='passthru', errors='surrogate_or_strict')


# Generated at 2022-06-25 13:42:16.485791
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert text_environ_0.__getitem__('HOME') == os.environ['HOME']


# Generated at 2022-06-25 13:42:22.152518
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron()
    os.environ["foo"] = "bar"
    assert e["foo"] == "bar"
    e["unicode"] = u"\u20AC\u20AChé"
    assert e["unicode"] == u"\u20AC\u20AChé"
    if not PY3:
        del os.environ["unicode"]
        e["latin1"] = b"\xc2\xa3\xc2\xa3h\xc3\xa9"
        assert e["latin1"] == u"\u20AC\u20AChé"
        del os.environ["latin1"]
        e["latin1"] = b"\xc2\xa3\xc2\xa3h\xc3\xa9"

# Generated at 2022-06-25 13:42:23.715837
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    for env_key in os.environ:
        assert text_environ_0.__getitem__(env_key) == os.environ[env_key]



# Generated at 2022-06-25 13:42:24.262415
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-25 13:42:26.588226
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    _TextEnviron()
    # 1)
    foo = 'foo'
    os.environ[foo] = 'bar'
    assert environ[foo] == 'bar'


# Generated at 2022-06-25 13:42:35.524133
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # set up environment variables 
    os.environ['a'] = 'A'
    os.environ['b'] = 'B'
    os.environ['c'] = 'C'
    os.environ['d'] = 'D'
    os.environ['e'] = 'E'
    os.environ['f'] = 'F'
    os.environ['g'] = 'G'
    os.environ['h'] = 'H'

    text_environ_0 = _TextEnviron()

    # Test the positive flow
    # Assert against the expected values
    assert text_environ_0['a'] == 'A'
    assert text_environ_0['b'] == 'B'
    assert text_environ_0['c'] == 'C'