

# Generated at 2022-06-25 13:34:15.632139
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__('HOME')


# Generated at 2022-06-25 13:34:17.534897
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__(0)


# Generated at 2022-06-25 13:34:20.526853
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0._TextEnviron__getitem__('TEST_ENVIRONMENT_VARIABLE')


# Generated at 2022-06-25 13:34:24.446351
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__('HOME')
    assert var_0 is not None
    assert var_0 == os.environ['HOME']


# Generated at 2022-06-25 13:34:26.538284
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0.__getitem__('HOME')


# Generated at 2022-06-25 13:34:35.280857
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Test case for method __getitem__ of class _TextEnviron."""
    text_environ_1 = _TextEnviron()
    text_environ_2 = _TextEnviron(env=text_environ_1,
                                  encoding=sys.getfilesystemencoding())

    # noinspection PyUnusedLocal
    # FIXME(toabctl): Unused variable: 'i'
    for i in text_environ_1:
        # We should never get here since we're mocking the environment
        # This just serves as a template for when the mock is removed
        # var_1 = i
        # var_2 = text_environ_0[i]
        # var_3 = text_environ_1[i]
        # var_4 = text_environ_2[i]
        pass


# Unit

# Generated at 2022-06-25 13:34:38.266238
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__()


# Generated at 2022-06-25 13:34:45.648193
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    expected_0 = to_bytes(text_environ_0.encoding, encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    actual_0 = text_environ_0.__getitem__(to_bytes(text_environ_0.encoding, encoding='utf-8', nonstring='strict', errors='surrogate_or_strict'))
    assert actual_0 == expected_0


# Generated at 2022-06-25 13:34:48.753629
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Testing default use case
    text_environ_1 = _TextEnviron()
    var_1 = text_environ_1.__getitem__('PATH')
    print(var_1)

# Generated at 2022-06-25 13:34:52.037433
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError):
        var_0 = text_environ_0.__getitem__('foo')



# Generated at 2022-06-25 13:34:56.076140
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Assert that when os module is passed to __init__ function of _TextEnviron
    # class it returns the environment variable in a text string
    assert isinstance(environ['SHELL'], str)

# Generated at 2022-06-25 13:35:02.228882
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:35:04.914675
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert isinstance(u'KEY' in environ, bool)
    else:
        assert isinstance(u'KEY' in environ, bool)


# Generated at 2022-06-25 13:35:07.608050
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    if PY3:
        assert test_case_0().environ['PATH'] == '1'
    else:
        assert test_case_0().environ['PATH'] == u'1'

# Generated at 2022-06-25 13:35:11.917326
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Case 0:
    # A simple lookup, byte strings in the environment should be returned as unicode.
    # If we're on python3, this test should be a no-op.
    if not PY3:
        os.environ['TEST_VAR'] = b'Hello world'
        assert environ['TEST_VAR'] == u'Hello world'
        del os.environ['TEST_VAR']

    # Case 1:
    # Unicode strings in the environment should be returned as unicode.
    # If we're on python3, this test should be a no-op.
    if not PY3:
        os.environ['TEST_VAR'] = u'Hello world'
        assert environ['TEST_VAR'] == u'Hello world'

# Generated at 2022-06-25 13:35:19.873060
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    ansible_hostname = text_environ_0['ansible_hostname']
    if PY3:
        import re
        p = re.compile('\\b[A-Za-z0-9]+\\b')
        assert p.match(ansible_hostname)
    else:
        import re
        p = re.compile('\\b[A-Za-z0-9]+\\b')
        assert p.match(ansible_hostname)
    ansible_fqdn = text_environ_0['ansible_fqdn']
    if PY3:
        import re
        p = re.compile('\\b[A-Za-z0-9]+\\b')

# Generated at 2022-06-25 13:35:21.582106
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('USER') != None


# Generated at 2022-06-25 13:35:28.760497
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Case 0: Unicode environment variable
    os.environ['UNICODE_ENV_VAR'] = '\u03b1\u03b2\u03b4\u03b5'
    assert environ['UNICODE_ENV_VAR'] == u'\u03b1\u03b2\u03b4\u03b5'
    del os.environ['UNICODE_ENV_VAR']

    # Case 1: ASCII environment variable
    os.environ['ASCII_ENV_VAR'] = 'abcdef'
    assert environ['ASCII_ENV_VAR'] == u'abcdef'
    del os.environ['ASCII_ENV_VAR']



# Generated at 2022-06-25 13:35:32.293046
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    text_environ_0 = _TextEnviron()
    key_0 = 'Ọ̀ṣùńgàlá'

    # Exercise
    actual_return_value_0 = text_environ_0[key_0]

    # Verify
    pass


# Generated at 2022-06-25 13:35:41.254793
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        # Unit test for method __getitem__ of class _TextEnviron
        # The value is already a string, use it as is and don't convert it
        text_environ_0 = _TextEnviron()

# Generated at 2022-06-25 13:35:51.633004
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    set_locale()
    test_environ = _TextEnviron()
    # Where the test is running:
    if 'AMBARI_SERVER_HOST' in test_environ.keys():
        del test_environ['AMBARI_SERVER_HOST']
    if 'AMBARI_SERVER_HOST' in test_environ.keys():
        raise Exception("Test failed: test_environ['AMBARI_SERVER_HOST'] exists")
    # Where the test is running:
    if 'AMBARI_SERVER_HOST' in test_environ.keys():
        raise Exception("Test failed: test_environ['AMBARI_SERVER_HOST'] exists")

# Generated at 2022-06-25 13:35:56.255323
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test the function without any input arguments
    # Test with an invalid argument
    environ = _TextEnviron()
    with pytest.raises(KeyError):
        environ['unknown key']
    # Test with a valid argument
    assert environ['SHELL'] == '/bin/bash'
    # Test with an invalid argument but with a default value
    assert environ.get('unknown key') is None
    assert environ.get('unknown key', 'default value') == 'default value'



# Generated at 2022-06-25 13:36:00.975377
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # __getitem__(self, key)
    # Return the encoding of text objects returned by the environment
    
    # Create a _TextEnviron object for testing
    text_environ_0 = _TextEnviron()
    
    # Call method __getitem__ of text_environ_0 with argument 'key'
    
    
    
    
    
    
    
    
    ##############################################################################
    # TODO: 3 tests need to be completed.                                        #
    ##############################################################################
    
    # Assert the return type of method __getitem__ is str
    assert isinstance(text_environ_0.__getitem__('key'), str)
    
    # Assert the return value of method __getitem__ is 'value'
    
    
    
    
    
    
    
    

# Generated at 2022-06-25 13:36:02.505717
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert(environ['LAB_TEST2'] == "Hello!")

# Generated at 2022-06-25 13:36:09.754991
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Make sure that it works on string keys
    assert True, (text_environ_0['PATH'])
    # Make sure that it works on unicode keys on Py2
    if PY2:
        assert True, (text_environ_0[to_text('PATH', encoding='utf-8')])
    # Make sure that it works on bytes keys on Py2
    if PY2:
        assert True, (text_environ_0[to_bytes('PATH', encoding='utf-8')])
    # Make sure that it works with non-ascii characters on Py3

# Generated at 2022-06-25 13:36:13.952857
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Ensure that when Py3 is True, __getitem__ delegates to _raw_environ
    text_environ_0 = _TextEnviron()
    if PY3:
        text_environ_0.__getitem__ = text_environ_0._raw_environ.__getitem__


# Generated at 2022-06-25 13:36:18.076507
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    assert environ.__getitem__(environ.__iter__().__iter__().__next__()) == environ.__getitem__(environ.__iter__().__iter__().__next__())


# Generated at 2022-06-25 13:36:26.799770
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test example:
    #   assert func(value) == expected, 'Failed to assert that {} yields {}
    #   (instead of {})'.format(value, expected, func(value))
    # where
    #   func is the function to test (ex, environ.__getitem__(key)),
    #   value is the value to pass in (ex, key for environ.__getitem__()),
    #   expected is the expected output (ex, 'value' for environ.__getitem__('key')).
    environ['key_0'] = 'value_0'
    assert environ.__getitem__('key_0') == 'value_0', 'Failed to assert that key_0 yields value_0 (instead of ' + environ.__getitem__('key_0') + ')'

# Generated at 2022-06-25 13:36:28.578175
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    a = _TextEnviron()
    b = a['PATH']
    assert isinstance(b, str)


# Generated at 2022-06-25 13:36:29.775759
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(environ[b'PATH'], str)


# Generated at 2022-06-25 13:36:40.531708
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with PY3 (which is natively text)
    if PY3:
        text_environ_1 = _TextEnviron(encoding=None)
        s = text_environ_1['PATH']

    # Test with PY2 (which needs to be decoded to text)
    if not PY3:
        text_environ_2 = _TextEnviron(encoding=None)
        s = text_environ_2['PATH']

    # Test with a bad key
    if not PY3:
        # with self.assertRaises(KeyError):
        text_environ_3 = _TextEnviron(encoding=None)
        s = text_environ_3['PATH']

    # Test with a bad key

# Generated at 2022-06-25 13:36:43.101133
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_1 = text_environ_0[os.getcwd()]
    return str_1


# Generated at 2022-06-25 13:36:49.687302
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert isinstance(text_environ_0['PATH'], to_text(to_bytes('', sys.getfilesystemencoding()), sys.getfilesystemencoding(), 'strict'))
    try:
        print('python3')
        assert isinstance(text_environ_0['PATH'], to_text(to_bytes('', sys.getfilesystemencoding()), sys.getfilesystemencoding(), 'strict'))
    except AttributeError:
        pass


# Generated at 2022-06-25 13:36:52.507494
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        text_environ_0.__getitem__(u'PWD')
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-25 13:36:56.233442
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # No assertion. Just tests that it can get a value for a key without error
    if PY3:
        text_environ_getitem_0 = environ['PATH']
    else:
        text_environ_getitem_0 = environ[to_bytes('PATH', encoding='utf-8', nonstring='strict',
                                                  errors='surrogate_or_strict')]


# Generated at 2022-06-25 13:36:59.140176
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    assert text_environ_0.__getitem__('LANG') == 'en_US.UTF-8'



# Generated at 2022-06-25 13:37:02.702138
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    str_0 = ''
    try:
        text_environ_1[str_0]
    except KeyError:
        pass


# Generated at 2022-06-25 13:37:05.923111
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test simple case
    environ_1 = _TextEnviron()
    assert environ_1['PATH'] == '/usr/bin:/usr/sbin:/sbin:/bin'

    # Test unicode cases

    # Test error case: KeyError
    pass

# Generated at 2022-06-25 13:37:14.101520
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    # Test cases to check that the method accepts non-ascii values
    assert text_environ_1['ANSIBLE_MODULE_ARGS'] == u'{"ANSIBLE_MODULE_ARGS": "✓"}'
    assert text_environ_1['PWD'] == u'/home/toshio/python/ansible/lib/ansible/module_utils'
    # Test cases to check that it returns non-ascii values as text strings
    assert isinstance(text_environ_1['ANSIBLE_MODULE_ARGS'], str)
    assert isinstance(text_environ_1['PWD'], str)
    # Test cases to check that the method returns byte strings when byte strings are passed

# Generated at 2022-06-25 13:37:19.896033
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set up test objects
    text_environ_0 = _TextEnviron()
    # Call the __getitem__ method for text_environ_0
    if PY3:
        assert isinstance(text_environ_0.__getitem__('HOME'), str)
    else:
        assert isinstance(text_environ_0.__getitem__('HOME'), unicode)


# Generated at 2022-06-25 13:37:25.307554
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Sets the environment variable to a value
    os.environ["foo"] = "This is a test"
    # Creates a _TextEnviron object
    text_environ_0 = _TextEnviron()

    assert text_environ_0["foo"] == "This is a test", "Should return the value defined for the environment variable"



# Generated at 2022-06-25 13:37:32.450715
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:37:40.494455
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test when we have an ascii value
    # Assert that value of text_environ_0['HOME'] is 'C:\\Users\\toshio'
    assert to_text(os.environ['HOME'], encoding='utf-8') == 'C:\\Users\\toshio'
    # Test when we have a non-ascii value
    # Assert that value of text_environ_0['HOME'] is 'C:\\Users\\toshio'
    assert to_text(os.environ['HOME'], encoding='utf-8') == 'C:\\Users\\toshio'
    # Test when we have a non-utf8-encodable value
    # Assert that value of text_environ_0['HOME'] is 'C:\\Users\\toshio'

# Generated at 2022-06-25 13:37:43.776404
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron(env={},
                                  encoding='UTF-8')
    assert text_environ_1['foo'] == ''


# Generated at 2022-06-25 13:37:52.490311
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:37:56.428580
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test when no encoding is passed in
    text_environ_1 = _TextEnviron()
    # Test when bytes are already text on PY3
    # Test when bytes are already bytes on PY2
    # Test cache hit
    # Test when bytes are already bytes on PY3
    # Test when bytes are already text on PY2


# Generated at 2022-06-25 13:37:57.885433
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['FOO'] = 'A'
    test_case_0()
    assert environ['FOO'] == 'A'


# Generated at 2022-06-25 13:38:01.651844
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    if (PY3):
        result = text_environ_0.__getitem__("LC_ALL")
    else:
        result = text_environ_0.__getitem__("USER")


# Generated at 2022-06-25 13:38:10.881185
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:38:13.092560
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    x_0 = text_environ_0.get('DOESNTEXIST')
    assert x_0 is None


# Generated at 2022-06-25 13:38:24.345476
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This is a very rough test.  We're only testing that things are working as expected
    # with the way that Python 3 handles Unicode.  Other things will be tested in
    # integration tests
    text_environ_0 = _TextEnviron(encoding='utf-8')
    key = 'LANG'
    expected = u'en_US.UTF-8'
    actual = text_environ_0.__getitem__(key)
    assert expected == actual
    key = 'SHELL'
    expected = u'/bin/bash'
    actual = text_environ_0.__getitem__(key)
    assert expected == actual
    text_environ_1 = _TextEnviron(encoding='utf-8')
    key = 'LC_ALL'
    expected = u'en_US.UTF-8'
   

# Generated at 2022-06-25 13:38:32.922647
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test case for PY2, where there is no encoding set.
    os.environ.update({'ACCEPTED_ENCODING': b'utf-8', 'ACCEPTED': 'utf-8'})
    text_environ_0 = _TextEnviron()
    assert text_environ_0['ACCEPTED_ENCODING'] == b'utf-8'
    os.environ.update({'ACCEPTED_ENCODING': 'utf-8'})
    assert text_environ_0['ACCEPTED_ENCODING'] == 'utf-8'
    assert text_environ_0['ACCEPTED'] == 'utf-8'
    # Test case for PY2, where there is an encoding set.
    text_environ_1 = _TextEnviron(encoding='latin-1')
   

# Generated at 2022-06-25 13:38:38.221485
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    key = 'TEST_ENVIRON_KEY_' + str(0)
    b_value = to_bytes(key, encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    os.environ[key] = b_value
    value = text_environ_1[key]
    if PY3:
        assert value == b_value
    else:
        assert value == key


# Generated at 2022-06-25 13:38:41.024533
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Initialize the test object
    text_environ_1 = _TextEnviron()

    # Execute the method under test
    result = text_environ_1.__getitem__("HOME")
    assert result == "/home/user"

# Generated at 2022-06-25 13:38:45.248588
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['PATH'] == os.environ['PATH']
    else:
        assert environ['PATH'] == os.environ['PATH'].decode(sys.getfilesystemencoding())


# Generated at 2022-06-25 13:38:47.799462
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert isinstance(text_environ_0["SHELL"], str)


# Generated at 2022-06-25 13:38:56.258049
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    # test__getitem__.py:18
    for k in text_environ_0:
        pass
    # test__getitem__.py:19
    if PY3:
        # test__getitem__.py:23
        try:
            text_environ_0['fooooo']
            assert False
        except KeyError:
            pass
        else:
            assert False
        # test__getitem__.py:25
        try:
            text_environ_0['fooooo']
            assert False
        except KeyError:
            pass
        else:
            assert False

# Generated at 2022-06-25 13:39:00.953513
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron({'b': '\x80'})

    # Test with bytes passed in
    assert text_environ_1['b'] == u'\udc80'

    # Test with text passed in
    assert text_environ_1[u'b'] == u'\udc80'


# Generated at 2022-06-25 13:39:07.983283
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test for method __getitem__ of class _TextEnviron for valid input data
    The method tests if the __getitem__ method of _TextEnviron class works as expected.
    """
    os.environ['ANSIBLE_TEST_VAR'] = 'ANSIBLE_TEST_VAR'
    assert os.environ['ANSIBLE_TEST_VAR'] == 'ANSIBLE_TEST_VAR'
    assert text_environ_0['ANSIBLE_TEST_VAR'] == u'ANSIBLE_TEST_VAR'


# Generated at 2022-06-25 13:39:10.917501
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # gets the item with key=`arg1` from self._raw_environ
    # if there is no value with the key=`arg1` then it throws keyerror
    assert environ['HOME'] == '/home/we45'


# Generated at 2022-06-25 13:39:18.904381
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    x = text_environ_0['PWD']
    assert x
    x = text_environ_0['LANG']
    assert x

# Generated at 2022-06-25 13:39:21.986807
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # KeyError raised when __getitem__ is passed a non-existent key
    with pytest.raises(KeyError):
        text_environ_0['non-existent key']


# Generated at 2022-06-25 13:39:24.796564
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Tests for when the environment variable is not in the cache
    text_environ_0 = _TextEnviron()
    assert text_environ_0['PATH'] == 'foo'


# Generated at 2022-06-25 13:39:27.255097
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__("USER")


# Generated at 2022-06-25 13:39:33.051426
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Make sure that a key which is found in the environment is returned properly
    # TODO: Need to handle the case of getting the value from the cache
    assert environ['PATH'] == os.environ['PATH']
    # Make sure that a key which isn't in the environment raises the expected exception
    try:
        environ['VARIABLE_WHICH_DOES_NOT_EXIST']
        assert False, 'Variable which does not exist did not raise KeyError'
    except KeyError:
        pass


# Generated at 2022-06-25 13:39:35.453464
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import sys
    import collections
    import six
    from io import StringIO
    from six import StringIO
    from io import BytesIO


# Generated at 2022-06-25 13:39:37.571576
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('PATH') == environ['PATH']


# Generated at 2022-06-25 13:39:39.431405
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set up the object
    text_environ_1 = _TextEnviron()
    # Try it out
    result = text_environ_1.__getitem__('HOME')
    # Check the results
    pass


# Generated at 2022-06-25 13:39:41.730782
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0_1 = text_environ_0['PATH']
    print(text_environ_0_1)
    assert text_environ_0_1


# Generated at 2022-06-25 13:39:47.675961
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        environ_0 = os.environ
    else:
        environ_0 = dict(((k, v.encode('utf-8')) for k, v in os.environ.items()))

    text_environ_0 = _TextEnviron(environ_0)
    os.environ['ANSIBLE_TEST'] = 'žlutý kůň příliš žluťoučký'
    if PY3:
        # getitem
        assert text_environ_0['ANSIBLE_TEST'] == 'žlutý kůň příliš žluťoučký'

# Generated at 2022-06-25 13:39:56.722072
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert True == (text_environ_0.__getitem__("PYCHARM_HOSTED") is not None)



# Generated at 2022-06-25 13:40:05.801987
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    t = environ
    if PY3:
        # On Python3, just compare t to os.environ
        e = os.environ
        for key in os.environ.keys():
            assert t[key] == e[key]
        return
    # Test to make sure _TextEnviron returns text values
    assert t['PWD'] == to_text(os.getcwd(), encoding='utf-8')
    # Test with a non-text value
    temp_var = os.environ['VAR'] = b'foo'
    assert t['VAR'] == 'foo'
    # Test with a value that is already unicode
    temp_var = os.environ['VAR'] = u'foo'
    assert t['VAR'] == u'foo'


# Generated at 2022-06-25 13:40:11.366590
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron(encoding='utf-8')
    # Formatted to avoid needless line wrapping
    assert text_environ['ansible_check_mode'] == os.environ['ansible_check_mode']
    assert text_environ['HOME'] == os.environ['HOME']
    assert text_environ['PATH'] == os.environ['PATH']
    # Any encoded characters in the env vars
    assert text_environ['ANSIBLE_INVENTORY'] == os.environ['ANSIBLE_INVENTORY']


# Generated at 2022-06-25 13:40:19.129921
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import sys
    import unittest
    import ansible.module_utils.common._collections_compat as collections_compat

# Generated at 2022-06-25 13:40:22.978985
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_key = 'TEST_KEY'
    test_value = 'TEST_VALUE'
    test_environ = _TextEnviron()
    test_environ[test_key] = test_value

    key_value = test_environ[test_key]
    assert key_value == test_value

# Generated at 2022-06-25 13:40:32.267466
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set up appropriate values for the environment
    os.environ['HOME'] = u'/home/username'
    # Set up the class
    text_environ_0 = _TextEnviron()
    # Run the test
    test_arg_0 = 'HOME'
    # This returns a text string on Python3 and a bytes string on Python 2
    test_return_0 = text_environ_0.__getitem__(test_arg_0)
    if PY3:
        assert test_return_0 == u'/home/username'
    else:
        # On python2 the bytes string will be the actual bytes
        assert test_return_0 == b'/home/username'
        # But the bytes should match the decoded unicode

# Generated at 2022-06-25 13:40:34.097650
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    test_case_0(text_environ_0)


# Generated at 2022-06-25 13:40:42.186409
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test that getting unicode vars work as expected

    unicode_var = '⌘'
    unicode_key = u'UNICODE_TEST_KEY'
    bytes_key = unicode_key.encode('utf-8')

    os.environ[unicode_key] = unicode_var
    # Test that we get what we put in when we use a unicode key:
    assert unicode_var == _TextEnviron(encoding='utf-8')[unicode_key]
    # Test that we get what we put in when we use a bytes key:
    assert unicode_var == _TextEnviron(encoding='utf-8')[bytes_key]
    # Test that we can tell the encoding of a bytes key that we put in
    # We expect this to fail if we use the default of utf

# Generated at 2022-06-25 13:40:49.399669
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # 1. Generate a text_environ object that uses utf-8 as the encoding
    text_environ_0 = _TextEnviron(encoding='utf-8')
    # 2. Read, decode, and re-encode LANG to utf-8 from it
    utf8_lang = to_bytes(to_text(text_environ_0['LANG']))
    # 3. Read LANG directly from the environment
    raw_lang = to_bytes(os.environ['LANG'])
    # 4. Assert that the two are equivalent
    assert utf8_lang.lower() == raw_lang.lower()



# Generated at 2022-06-25 13:40:53.179823
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Input parameters
    #   self
    #   key
    # Expected return values
    #   text_environ_0.__getitem__('key')

    text_environ_0 = _TextEnviron()
    assert isinstance(text_environ_0.__getitem__('key'), text_type)


# Generated at 2022-06-25 13:41:10.381661
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    unicode_0 = text_environ_0['PATH']
    assert unicode_0 == os.environ['PATH']


# Generated at 2022-06-25 13:41:16.951322
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Initialize a _TextEnviron object.
    text_environ_0 = _TextEnviron()
    # Put some values in the raw environment.
    os.environ[b'a'] = to_bytes(u'\u041c\u0430\u0440\u0442\u0438\u043d \u0427\u0435\u0440\u043d\u044b\u0439')
    os.environ[b'b'] = to_bytes(u'\u041c\u0438\u043d\u0438\u043d-\u0424\u0443\u0440\u043d\u0430\u0443')

# Generated at 2022-06-25 13:41:26.329808
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    temp_environ = os.environ.copy()

# Generated at 2022-06-25 13:41:29.416138
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_1 = 'HOME'
    var_0 = text_environ_0.__getitem__(var_1)
    assert var_0 == 'C:\\Users\\willa'


# Generated at 2022-06-25 13:41:32.071151
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    # TextEnviron.__getitem__
    value = text_environ_1['LANG']
    assert isinstance(value, str)


# Generated at 2022-06-25 13:41:37.756596
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Testing for case: not PY3
    # Should return text strings
    test_env = {b'key': b'value'}
    text_environ_1 = _TextEnviron(env=test_env)
    assert text_environ_1[b'key'] == u'value'
    # Testing for case: PY3
    # Should return byte strings
    if PY3:
        test_env = {'key': 'value'}
        text_environ_2 = _TextEnviron(env=test_env)
        assert text_environ_2['key'] == b'value'


# Generated at 2022-06-25 13:41:42.310709
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ.clear()
    environ.update({"ANSIBLE_NET_USERNAME": "admin", "ANSIBLE_NET_PASSWORD": "admin"})
    for key in environ:
        assert(environ.get(key).__contains__('admin'))



# Generated at 2022-06-25 13:41:44.702164
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert text_environ_1["PATH"] == '/bin:/usr/bin:/usr/local/bin'


# Generated at 2022-06-25 13:41:52.674577
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0._raw_environ = {'Foo': b'Bar'}
    # text_environ_0._raw_environ = {'Foo': 'Bar'} #  For Python3
    # After being inside the class, the type of sys.getfilesystemencoding should be 'str'
    assert(type(sys.getfilesystemencoding()) is str)
    text_environ_0.encoding = 'utf-8'
    # This should pass
    text_environ_0.__getitem__('Foo')
    # This should fail
    # text_environ_0.__getitem__('baz')


# Generated at 2022-06-25 13:42:00.433905
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Populating the environment with key-value pairs
    os.environ['a'] = 'a'
    os.environ['b'] = 'b'
    os.environ['c'] = 'c'
    os.environ['d'] = 'd'
    os.environ['e'] = 'e'
    os.environ['f'] = 'f'
    # Printing the populated environment
    print("\nThe current environment is : ", end="")
    print(os.environ)
    # Creating an object of _TextEnviron class
    obj = _TextEnviron()
    # Checking for correct output for b
    assert obj['b'] == 'b'
    # Checking for correct output for e
    assert obj['e'] == 'e'
    # Checking for correct output for d

# Generated at 2022-06-25 13:42:15.546436
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test Result:
    """
    test_case_0()

# Generated at 2022-06-25 13:42:18.632065
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test_case_0
    text_environ_0 = _TextEnviron()
    # expected result
    expected_result_0 = os.environ
    # actual result
    actual_result_0 = text_environ_0.__getitem__("HOME")
    # test
    assert actual_result_0 == expected_result_0


# Generated at 2022-06-25 13:42:22.088062
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert len(text_environ_0) == len(os.environ)
    key = 'PATH'
    if key not in text_environ_0:
        raise KeyError('Path')
    try:
        item = text_environ_0[key]
    except KeyError:
        pass
    else:
        assert item
        assert item == os.environ[key]


# Generated at 2022-06-25 13:42:26.951397
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    value = text_environ['ANSIBLE_HOOKS_DIR']
    if value != '/home/ansibler/.ansible/plugins/modules/action_plugins':
        raise AssertionError(
            "Unexpected value of type {} received instead of a string.".format(type(value)))
    value = text_environ['TRAVIS']
    if value != 'true':
        raise AssertionError(
            "Unexpected value of type {} received instead of a string.".format(type(value)))
    if not PY3:
        value = text_environ['LC_ALL']
        if value != 'C.UTF-8':
            raise AssertionError(
                "Unexpected value of type {} received instead of a string.".format(type(value)))

#

# Generated at 2022-06-25 13:42:28.396863
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ[b'PATH'] == environ[u'PATH']


# Generated at 2022-06-25 13:42:36.172881
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # initialize
    text_environ_0 = _TextEnviron()

    # verify return value
    # _TextEnviron.__getitem__ is getting the value of 'PYTHONPATH' environment variable.
    # The value of 'PYTHONPATH' is different for different systems.
    # The value of 'PYTHONPATH' is being checked for 'None' or ''.
    # The value of 'PYTHONPATH' is being checked for 'None' or ''.
    # The value of 'PYTHONPATH' is being checked for 'None' or ''.
    assert text_environ_0.__getitem__('PYTHONPATH') is not None or ''


# Generated at 2022-06-25 13:42:40.564322
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.encoding = 'utf-8'
    # Test for __getitem__
    assert text_environ_0.__getitem__('SHELL') == 'csh'
    assert text_environ_0.__getitem__('IAMHERE') == u'íamhere'
    assert text_environ_0.__getitem__('i_am_not') is None


# Generated at 2022-06-25 13:42:47.412427
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    if PY3:
        assert text_environ_0.__getitem__('PATH') == os.environ['PATH']
    else:
        assert text_environ_0.__getitem__('PATH') == os.environ['PATH'].decode('utf-8', 'surrogate_or_strict')
    
    text_environ_0._raw_environ['PATH'] = b'\xe5\x90\x89\xe4\xba\x9a'
    if PY3:
        assert text_environ_0.__getitem__('PATH') == b'\xe5\x90\x89\xe4\xba\x9a'.decode('utf-8', 'surrogate_or_strict')
   

# Generated at 2022-06-25 13:42:53.334606
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from sys import getfilesystemencoding
    from collections import OrderedDict

    # Determine the expected encoding when not hardcoded
    encoding = getfilesystemencoding()

    # Bunch of tests for non-ascii characters
    sample_text = OrderedDict()
    # Japanese sample text.  Taken from https://en.wikipedia.org/wiki/Yamato_period
    sample_text[b'\xe6\xad\xa6\xe8\x89\xb2\xe6\x99\x82\xe4\xbb\xa3'] = u'\u6b66\u5175\u6642\u4ee3'
    # Russian sample text.  Taken from https://en.wikipedia.org/wiki/Chukotka_Autonomous_Okrug

# Generated at 2022-06-25 13:42:57.206106
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Testing with unicode values
    text_environ_1 = _TextEnviron()
    result = text_environ_1.__getitem__('HOME')
    assert(result)


# Generated at 2022-06-25 13:43:27.993263
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    temp_path_2 = environ.get('PATH')
    temp_path_3 = text_environ_1.__getitem__('PATH')
    assert temp_path_2 == temp_path_3


# Generated at 2022-06-25 13:43:31.319411
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    def tc0():
        text_environ_0 = _TextEnviron()
        text_environ_0['text_environ_0'] = 'text_environ_0'
        text_environ_0['text_environ_0']


# Generated at 2022-06-25 13:43:33.434177
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # os.environ['PATH']
    __getitem__ = text_environ_0['PATH']

# Generated at 2022-06-25 13:43:38.913024
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['HOME'] == os.environ['HOME']
        assert environ['PATH'] == os.environ['PATH']
        assert environ['LC_COLLATE'] == os.environ['LC_COLLATE']
    else:
        assert environ['HOME'] == os.environ['HOME'].decode(sys.getfilesystemencoding())
        assert environ['PATH'] == os.environ['PATH'].decode(sys.getfilesystemencoding())
        assert environ['LC_COLLATE'] == os.environ['LC_COLLATE'].decode(sys.getfilesystemencoding())

# Generated at 2022-06-25 13:43:42.075696
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0['HOME']
    str_1 = os.environ['HOME']
    bool_0 = text_environ_0['HOME'] == str_1
    bool_1 = text_environ_0['HOME'] == os.environ['HOME']


# Generated at 2022-06-25 13:43:47.804807
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Ensure __getitem__ returns bytes if on py2"""
    # Setup test environment
    text_environ_0 = _TextEnviron()
    target_0 = 'TERM'
    target_0_value = text_environ_0[target_0]
    if not PY3:
        assert isinstance(target_0_value, str)
    assert 'TERM' in text_environ_0
    assert 'TERM' in text_environ_0
    assert 'TERM' in text_environ_0
    # Teardown test environment
    del text_environ_0


# Generated at 2022-06-25 13:43:54.141234
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        try:
            # pylint: disable=anomalous-backslash-in-string
            environ[u'HTTP_PROXY']
        except KeyError:
            # KeyError will be raised if the key doesn't exist
            environ[u'HTTP_PROXY'] = u'http://proxy.example.com:3128'
            pass
        else:
            # Key exists, nothing to do
            pass
        # pylint: enable=anomalous-backslash-in-string
    else:
        try:
            # pylint: disable=anomalous-backslash-in-string
            environ[u'HTTP_PROXY']
        except KeyError:
            # KeyError will be raised if the key doesn't exist
            environ[u'HTTP_PROXY']

# Generated at 2022-06-25 13:43:56.890073
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__('LC_ALL')
    text_environ_0.__getitem__('SHELL')
    text_environ_0.__getitem__('PATH')
    text_environ_0.__getitem__('HOME')
    text_environ_0.__getitem__('PWD')


# Generated at 2022-06-25 13:44:00.337137
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a utf8-encoded environment variable
    os.environ[b'TEST_ENV'] = b'\xe3\x81\x82'
    # If we're on Python3, just return the string that was there
    if PY3:
        assert environ[b'TEST_ENV'] == b'\xe3\x81\x82'
    else:
        assert environ[b'TEST_ENV'] == u'\u3042'



# Generated at 2022-06-25 13:44:01.696562
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('PATH') == os.getenv('PATH')
