

# Generated at 2022-06-25 13:34:19.850362
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1['foo'] = to_text(b'bar')
    res = text_environ_1['foo']
    assert res == to_text('bar')
    res = text_environ_1[to_bytes('foo')]
    assert res == 'bar'
    res = text_environ_1[to_bytes('foo', encoding='utf-8')]
    assert res == 'bar'


# Generated at 2022-06-25 13:34:30.019747
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a standard environ dict
    enc = sys.getfilesystemencoding()
    text_environ_0 = _TextEnviron({'a' : b'b', 'c' : 'd'}, enc)
    assert text_environ_0['a'] == 'b'
    assert text_environ_0['c'] == 'd'
    assert text_environ_0['a'] != b'b'
    assert text_environ_0['c'] != b'd'
    if PY3:
        assert text_environ_0['a'] == 'b'
    else:  # PY3
        assert text_environ_0['a'] == b'b'.decode(enc)
    # Test with a set of keys where a different encoding is used
    text_environ_1 = _TextEn

# Generated at 2022-06-25 13:34:37.873241
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if not (text_environ_0._raw_environ == os.environ):
        raise AssertionError("""text_environ_0._raw_environ is {}, expected {}""".format(
                text_environ_0._raw_environ, os.environ))
    if not (text_environ_0.encoding == sys.getfilesystemencoding()):
        raise AssertionError("""text_environ_0.encoding is {}, expected {}""".format(
                text_environ_0.encoding, sys.getfilesystemencoding()))

# Generated at 2022-06-25 13:34:47.925341
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Example 1: Return value for valid data
    text_environ_0 = _TextEnviron(encoding='utf-8')
    text_environ_0['NEW_ENV_VARIABLE'] = "new_env_value"
    text_environ_0['NEW_ENV_VARIABLE'] == "new_env_value"

    # Example 2: Return value for valid data
    text_environ_1 = _TextEnviron(encoding='utf-8')
    text_environ_1['NEW_ENV_VARIABLE'] = "new_env_value"
    text_environ_1['NEW_ENV_VARIABLE'] == "new_env_value"


# Generated at 2022-06-25 13:34:52.221646
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    key = 'TEST_KEY'
    value = 'Some Value'
    os.environ[key] = value
    text_environ_0 = _TextEnviron()
    returned_value = text_environ_0.__getitem__(key)
    assert returned_value == value


# Generated at 2022-06-25 13:34:55.569303
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    if PY3:
        assert isinstance(text_environ['some_key'], str)
    else:
        assert isinstance(text_environ['some_key'], unicode)


# Generated at 2022-06-25 13:34:57.551023
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__(text_environ_0)
    text_environ_0.__getitem__(text_environ_0)



# Generated at 2022-06-25 13:34:59.141247
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0['PATH'] == '/usr/local/bin'


# Generated at 2022-06-25 13:35:04.074367
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        str_0 = text_environ_0.__getitem__('HOME')
    except KeyError as exc_0:
        print('Could not find network interface: [')
        print(exc_0)
        print(']')
    except Exception as exc_0:
        print(exc_0)


# Generated at 2022-06-25 13:35:06.308935
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    assert isinstance(env['USER'], str)
    assert env['USER'] == 'mimic'


# Generated at 2022-06-25 13:35:08.127273
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-25 13:35:12.004891
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    with pytest.raises(KeyError):
        text_environ_1.__getitem__('HOME')
    with pytest.raises(KeyError):
        text_environ_1.__getitem__('this_is_not_a_key')


# Generated at 2022-06-25 13:35:16.545264
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Print the values in the environ object
    for k, v in environ.items():
        print(k, v)

    # Print the values in the environ object
    for k, v in environ.items():
        print(k, v)

    # Print the values in the environ object
    for k, v in environ.items():
        print(k, v)



# Generated at 2022-06-25 13:35:19.839530
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_2 = _TextEnviron({'PATH': '/usr/bin:/usr/local/bin', 'HOME': '/home/testuser'})

    assert text_environ_2['PATH'] == '/usr/bin:/usr/local/bin'
    assert text_environ_2['HOME'] == '/home/testuser'


# Generated at 2022-06-25 13:35:24.230903
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # TODO: There needs to be a test for non-unicode values in environment variables; this isn't
    # good enough as-is
    text_environ_0 = _TextEnviron()

    # Verify that the environment is set up to allow for these tests to work
    assert os.environ['SHELL'] == to_text('/bin/sh')
    assert os.environ['SHELL'] == text_environ_0['SHELL']
    assert os.environ['SHELL'] == text_environ_0['SHELL']


# Generated at 2022-06-25 13:35:26.307079
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_3 = text_environ_0.__getitem__('SHELL')


# Generated at 2022-06-25 13:35:27.099455
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-25 13:35:28.944716
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    text_environ = _TextEnviron()

    # Assume
    # Assert
    assert isinstance(text_environ['PATH'], str)


# Generated at 2022-06-25 13:35:36.158146
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()

    # Test with byte strings in the environment
    result = text_environ_1.__getitem__(b'HOME')
    assert isinstance(result, text_type)
    assert result == to_text(environ[b'HOME'], encoding='utf-8')

    # Test with unicode strings in the environment
    result = text_environ_1.__getitem__('HOME')
    assert isinstance(result, text_type)
    assert result == to_text(environ['HOME'], encoding='utf-8')



# Generated at 2022-06-25 13:35:38.061062
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert isinstance(text_environ_0['PATH'], str) == True


# Generated at 2022-06-25 13:35:48.438889
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Create instance of object to test
    text_environ_0 = _TextEnviron()

    # Check initial state of object
    assert isinstance(text_environ_0, _TextEnviron)
    assert text_environ_0._raw_environ == os.environ
    assert text_environ_0.encoding == sys.getfilesystemencoding()
    assert isinstance(text_environ_0._value_cache, dict)
    assert text_environ_0._value_cache == {}

    # Get 'PATH' from object
    assert text_environ_0['PATH'] == os.environ['PATH']
    assert len(text_environ_0._value_cache) == 1
    assert text_environ_0._value_cache[os.environ['PATH']] == os.environ['PATH']

# Generated at 2022-06-25 13:35:51.150929
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron(env={'key': 'value'})
    assert text_environ['key'] == 'value'
    assert text_environ.get('missing', 'something') == 'something'


# Generated at 2022-06-25 13:35:51.985634
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert False #FIXME



# Generated at 2022-06-25 13:35:54.459852
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1['PATH'] = '/home/ubuntu/path'
    assert text_environ_1['PATH'] == '/home/ubuntu/path'


# Generated at 2022-06-25 13:35:56.848325
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Python3 uses unicode strings for environment variables by default.
    assert isinstance(text_environ_0[u'LANG'], str)


# Generated at 2022-06-25 13:36:02.118228
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    if PY3:
        assert text_environ_1[u'PATH'] == environ[u'PATH']
    else:
        assert text_environ_1[u'PATH'] == to_text(environ[u'PATH'], errors='surrogate_or_strict')


# Generated at 2022-06-25 13:36:09.541794
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with PY3 environment
    # initialize variable with target class
    test_instance_0 = _TextEnviron()
    with pytest.raises(KeyError):
        test_instance_0.__getitem__('PYTHON_S')
    with pytest.raises(KeyError):
        test_instance_0.__getitem__('PYTHON_S')

    # Test with PY2 environment
    # initialize variable with target class
    test_instance_0 = _TextEnviron()
    with pytest.raises(KeyError):
        assert test_instance_0.__getitem__('PYTHON_S') == '1'
    with pytest.raises(KeyError):
        assert test_instance_0.__getitem__('PYTHON_S') == '1'

   

# Generated at 2022-06-25 13:36:15.293837
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0[to_text("USERNAME", encoding='utf-8')] = to_text("TOSHIO", encoding='utf-8')
    assert text_environ_0[to_text("USERNAME", encoding='utf-8')] == to_text("TOSHIO", encoding='utf-8')


# Generated at 2022-06-25 13:36:20.776815
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    TEST_KEY = u'TEST\u03b1\u03b2\u03b3'
    TESTRESULT = u'TESTRESULT\u03b1\u03b2\u03b3'
    environ.clear()
    environ.update({TEST_KEY: TESTRESULT})
    TEST_VALUE = environ[TEST_KEY]
    assert TEST_VALUE == TESTRESULT


# Generated at 2022-06-25 13:36:23.854109
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # TypeError: an integer is required (got type str)
    #self.assertRaises(TypeError, lambda: text_environ_0.__getitem__(str))



# Generated at 2022-06-25 13:36:30.393048
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0._value_cache == {}
    text_environ_0.__getitem__('key1')
    assert text_environ_0._value_cache == {}
    text_environ_0.__getitem__('key2')
    assert text_environ_0._value_cache == {}


# Generated at 2022-06-25 13:36:33.182750
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        os.environ['ANSIBLE_TEXT_ENVIRON'] = u'ONE'
    except KeyError:
        pass
    value = text_environ_0.__getitem__('ANSIBLE_TEXT_ENVIRON')
    assert value == 'ONE'


# Generated at 2022-06-25 13:36:35.600678
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    expected = os.environ['PATH']
    actual = text_environ_0['PATH']
    assert actual == expected


# Generated at 2022-06-25 13:36:38.402491
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert text_environ_1[b'LANG'] == text_environ_1[b'LANG']


# Generated at 2022-06-25 13:36:40.411841
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Try to get a single environment variable that exists
    assert environ['HOME'] == os.environ['HOME']



# Generated at 2022-06-25 13:36:49.037605
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from types import GeneratorType
    from _collections_abc import Mapping
    from ansible.module_utils.six import text_type
    text_environ_0 = _TextEnviron()
    text_environ_0.__setitem__('TEXT_ENVIRON_0', 'TEXT_ENVIRON_0')
    text_environ_1 = text_environ_0.__getitem__('TEXT_ENVIRON_0')
    if isinstance(text_environ_1, GeneratorType):
        raise AssertionError('Invalid return value: ' + repr(text_environ_1))
    assert isinstance(text_environ_1, text_type)


# Generated at 2022-06-25 13:36:54.296537
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('USER') == os.environ.get('USER')
    assert text_environ_0.__getitem__('USER') == os.environ.get('USER')
    assert text_environ_0.__getitem__('USER') == os.environ.get('USER')
    assert text_environ_0.__getitem__('USER') == os.environ.get('USER')


# Generated at 2022-06-25 13:37:02.914032
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'
    assert environ['ANSIBLE_TEST_KEY'] == u'ANSIBLE_TEST_VALUE'

    environ['ANSIBLE_TEST_KEY'] = b'ANSIBLE_TEST_VALUE'
    assert environ['ANSIBLE_TEST_KEY'] == u'ANSIBLE_TEST_VALUE'

    environ['ANSIBLE_TEST_KEY'] = u'ANSIBLE_TEST_VALUE'
    assert environ['ANSIBLE_TEST_KEY'] == u'ANSIBLE_TEST_VALUE'



# Generated at 2022-06-25 13:37:07.812993
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0['PATH'] == '/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin'
    assert text_environ_0['HOME'] == '/root'
    assert text_environ_0['PYTHONPATH'] == '/usr/local/bin'


# Generated at 2022-06-25 13:37:09.892412
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError) as excinfo:
        text_environ_0.__getitem__('key')
        excinfo.match(r'\'key\'')

# Generated at 2022-06-25 13:37:21.572003
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        os.environ[b'foo']
    except KeyError:
        os.environ[b'foo'] = b'bar'
    try:
        os.environ[u'foo']
    except KeyError:
        os.environ[u'foo'] = u'bar'
    environ = _TextEnviron(env={b'foo': b'bar'})
    assert environ[b'foo'] == u'bar'
    assert environ[u'foo'] == u'bar'

# Generated at 2022-06-25 13:37:29.658859
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1['TEST'] = 'test'
    text_environ_2 = _TextEnviron()
    text_environ_3 = _TextEnviron()
    # Test case for string
    text_environ_3['TEST'] = 'test'
    # Test case for bytes
    text_environ_2['TEST'] = b'test'
    # Test case for unicode
    text_environ_1['TEST'] = u'test'

    try:
        raise TypeError
    except TypeError:

        # Test case for list 
        text_environ_3['TEST'] = ['test']
        raise
    except:
        pass

# Generated at 2022-06-25 13:37:31.653220
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('HOME') == os.environ['HOME']


# Generated at 2022-06-25 13:37:35.075045
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    key = "HOME"
    actual = text_environ_0.__getitem__(key)
    # assert actual == '/home/jason', "Expected: %s, Actual: %s" % ("/home/jason", actual)
    return actual


# Generated at 2022-06-25 13:37:35.902991
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert True


# Generated at 2022-06-25 13:37:44.445445
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test that environment variable values are returned as text strings.
    """
    assert environ['PATH'] == '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    assert environ['HOME'] == '/home/badger'
    assert environ['PATH'] != '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    assert environ['HOME'] != '/home/badger'

    # Double check that it's actually returning text strings.  This will fail on Python2
    assert isinstance(environ['PATH'], str)
    assert isinstance(environ['HOME'], str)



# Generated at 2022-06-25 13:37:45.430532
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()



# Generated at 2022-06-25 13:37:47.396428
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
   text_environ_0 = _TextEnviron()
   key = "TEST_KEY"
   value = "TEST_VALUE"

   text_environ_0[key] = value
   if text_environ_0[key] != value:
       print("Failed getitem() with key: " + key)
       return False


# Generated at 2022-06-25 13:37:49.941976
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['key_0'] = 'value_0'
    assert text_environ_0['key_0'] == 'value_0'
    assert text_environ_0['key_0'] == b'value_0'


# Generated at 2022-06-25 13:37:50.627658
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()


# Generated at 2022-06-25 13:38:04.096163
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    from ansible.module_utils._text import to_text
    text_0 = text_environ_0.__getitem__('SHELL')
    assert(isinstance(text_0, to_text))


# Generated at 2022-06-25 13:38:07.207594
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    byte_dict = {}
    byte_dict[b'foo'] = b'bar'
    text_environ = _TextEnviron(env=byte_dict)
    assert text_environ[b'foo'] == u'bar'



# Generated at 2022-06-25 13:38:15.017677
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Testing with a non-string key
    try:
        text_environ = _TextEnviron()
        text_environ[1]
    except TypeError as e:
        print(e)
    # Testing with a missing key
    try:
        text_environ = _TextEnviron()
        text_environ['a_key_that_is_not_in_os_environ']
    except KeyError as e:
        print(e)
    # Testing with a key that is present in os.environ
    text_environ = _TextEnviron()
    value = text_environ['PATH']
    print(value)
    # Testing with a key that is present in os.environ and the non-default encoding
    text_environ = _TextEnviron(encoding=sys.getdefaultencoding())
   

# Generated at 2022-06-25 13:38:23.062467
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:38:25.865890
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    key = 'KEY_NOT_IN_OS_ENV'
    with pytest.raises(KeyError):
        text_environ_0.__getitem__(key)


# Generated at 2022-06-25 13:38:28.106382
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_obj = _TextEnviron()
    test_obj['Test'] = 'Value'
    return test_obj['Test'] == 'Value'


# Generated at 2022-06-25 13:38:31.993386
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        text_environ_0.__getitem__('ascii')
        text_environ_0.__getitem__(None)
        assert True
    except TypeError:
        # If a var is not defined it will raise on TypeError
        assert True


# Generated at 2022-06-25 13:38:37.845513
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_1 = _TextEnviron({'PYTHONPATH': u'foo', 'test1': u'a\xac\u1234\u20ac\U00008000'})
    text_environ_2 = _TextEnviron({'PYTHONPATH': 'foo', 'test1': b'a\xac\xe1\x88\xb4\xe2\x82\xac\xed\xa0\x80'})


# Generated at 2022-06-25 13:38:40.331672
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    a = {u"ABC": '123'}
    text_environ_0 = _TextEnviron(a)
    return text_environ_0["ABC"] == '123'


# Generated at 2022-06-25 13:38:41.378481
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test case #0 - normal behavior
    test_case_0()


# Generated at 2022-06-25 13:39:02.647667
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('DISPLAY') == os.environ['DISPLAY']


# Generated at 2022-06-25 13:39:03.685858
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-25 13:39:09.074480
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert (text_environ_0.__getitem__('TEXTTEST_CHECK_PY3') is None)
    text_environ_0.__setitem__('TEXTTEST_CHECK_PY3', 'Y')
    assert (text_environ_0.__getitem__('TEXTTEST_CHECK_PY3') == 'Y')


# Generated at 2022-06-25 13:39:12.201750
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Case: Key exists in os.environ and returns a string
    text_environ_0 = _TextEnviron()
    assert text_environ_0['LANG'] == 'en_US.UTF-8'


# Generated at 2022-06-25 13:39:17.265091
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Simple case: fetch a key
    text_environ_1 = _TextEnviron()
    assert text_environ_1['PATH']
    # Test that a missing key raises an error
    text_environ_2 = _TextEnviron()
    text_environ_2.pop('PATH')
    try:
        text_environ_2['PATH']
    except KeyError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-25 13:39:19.497706
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron()
    assert e['HOME'] == os.environ['HOME']
    assert e['HOME'] != os.environ[b'HOME']



# Generated at 2022-06-25 13:39:22.854634
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    t_0 = ''

    # Set up the return value
    t_0 = _TextEnviron()

    # Call the function (unit test)
    t_0_return_value = t_0.__getitem__('key')



# Generated at 2022-06-25 13:39:27.216620
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a new object of class _TextEnviron
    text_environ_1 = _TextEnviron()
    # Assert that the type of text_environ_1 is that of the _TextEnviron
    assert isinstance(text_environ_1, _TextEnviron)


# Generated at 2022-06-25 13:39:30.566287
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_1 = _TextEnviron(env={'a': 'b'})
    text_environ_2 = _TextEnviron(env={'a': 'b'}, encoding='ascii')


# Generated at 2022-06-25 13:39:39.160709
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(env={u'mt': u'wt'})
    f = sys._getframe()
    # get the 'self' object from the calling method
    self = f.f_locals['self']
    # Because of the way the cache is implemented, we cannot make assertions about the contents of
    # the cache.  We must make assertions about the method output itself.
    assert self._raw_environ[u'mt'] == u'wt'
    if PY3:
        assert self[u'mt'] == u'wt'
    else:
        assert self[u'mt'] == u'mt=wt'
    # getitem should not change the contents of the cache.
    result_0 = self[u'mt']

# Generated at 2022-06-25 13:40:32.349780
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env_key0 = 'TEST_TEXT_ENV_KEY_0'
    env_value0 = 'TEST_TEXT_ENV_VALUE_0'
    env_key1 = 'TEST_TEXT_ENV_KEY_1'
    env_value1 = 'TEST_TEXT_ENV_VALUE_1'
    os.environ[env_key0] = env_value0
    os.environ[env_key1] = env_value1
    text_environ_0 = _TextEnviron()
    text_environ_0.encoding = "utf-8"
    assert text_environ_0[env_key0] == env_value0
    assert text_environ_0[env_key1] == env_value1
    del os.environ[env_key0]
   

# Generated at 2022-06-25 13:40:35.370595
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron({'a': 'foo', 'b': 'bar'})
    assert text_environ_1['a'] == 'foo'
    assert text_environ_1['b'] == 'bar'


# Generated at 2022-06-25 13:40:36.050861
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()



# Generated at 2022-06-25 13:40:40.663507
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # set sys.version to something that should be unicode
    sys.version = '3.6.5 (v3.6.5:f59c0932b4, Mar 28 2018, 17:00:18) \n[GCC 4.2.1 (Apple Inc. build 5666) (dot 3)]'
    _TextEnviron.__getitem__(text_environ_0, None)

# Generated at 2022-06-25 13:40:49.573474
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Note:
    First char of key of environ should be an alpha (A-Z, a-z) or an underscore (_)
    See: https://docs.python.org/3/library/functions.html#environ
    """
    text_environ = _TextEnviron()
    
    for k, v in environ.items():
        if k[0] in ('0','1','2','3','4','5','6','7','8','9'):
            continue

# Generated at 2022-06-25 13:40:53.836157
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # create an instance of _TextEnviron
    text_environ_0 = _TextEnviron()
    assert isinstance(text_environ_0['LD_LIBRARY_PATH'], str)
    # test that __getitem__ works for a specific ASCII environment variable
    assert text_environ_0['SHELL'] in ['/bin/bash', '/bin/sh', '/usr/bin/bash']



# Generated at 2022-06-25 13:40:58.814731
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Testing good case with unicode string
    # Create valid unicode string
    good_unicode_string = 'unit_test_string'
    good_unicode_string = to_text(good_unicode_string, encoding='utf-8', nonstring='passthru',
                                  errors='surrogate_or_strict')
    # Create new os.environ object
    os.environ = _TextEnviron(env={})
    # Setup test case
    os.environ['unit_test'] = good_unicode_string
    # Call method to test
    test__TextEnviron___getitem___result = os.environ['unit_test']
    # Verify result

# Generated at 2022-06-25 13:41:09.173677
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # GIVEN the module
    from ansible.module_utils._text import environ
    # AND an environment variable for PYTHONIOENCODING
    os.environ['PYTHONIOENCODING'] = 'utf-8'
    # AND a variable for the environment variable name
    name = 'PYTHONIOENCODING'
    expected_result_type = str
    expected_result = 'utf-8'
    # WHEN getting a variable from the environ
    actual_result = environ[name]
    # THEN the result should be the value of the variable
    assert expected_result == actual_result
    # AND the result should be a string
    assert isinstance(actual_result, expected_result_type)


if __name__ == '__main__':
    test_case_0()
    test__

# Generated at 2022-06-25 13:41:16.369692
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # No test possible for this method since we are monkeypatching the builtin os.environ

    # Test for non-string keys
    #   assertRaises called with function-object as arg 1, exception-type as arg 2
    try:
        text_environ_1 = _TextEnviron()
    except TypeError:
        pass
    else:
        # raise AssertionError(
        #     "Failed to raise TypeError when setitem called with a non-string key type"
        # )
        pass

    # Test for environment variable that is not in the environment or the value cache
    #   assertIs called on 'value' (line 75), with arg value 'None'
    #   assertEqual called on 'self._raw_environ' (line 74)
    #   assertEqual called on 'self._value_cache' (line

# Generated at 2022-06-25 13:41:24.740384
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    #
    # Setup
    #
    os.environ["ANSIBLE_FOO_BAR"] = b"unicode text"
    if b"ANSIBLE_FOO_BAR" not in os.environ:
        os.environ[b"ANSIBLE_FOO_BAR"] = b"unicode text"

    #
    # Test
    #
    if PY3:
        assert(environ["ANSIBLE_FOO_BAR"] == u"unicode text")
    else:
        assert(type(environ["ANSIBLE_FOO_BAR"]) is unicode)
        assert(environ["ANSIBLE_FOO_BAR"] == u"unicode text")


# Generated at 2022-06-25 13:43:14.562305
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Test with values that can be decoded from bytes to unicode safely
    assert to_text(b'foo', 'utf-8') == text_environ_0[b'foo']
    assert to_text(1, errors='surrogate_or_strict') == text_environ_0[1]
    assert to_text(None, errors='surrogate_or_strict') == text_environ_0[None]

    # Test with values that cannot be decoded to unicode
    try:
        text_environ_0[b'\xFF\xFF']
    except UnicodeDecodeError:
        pass
    else:
        assert False



# Generated at 2022-06-25 13:43:15.258418
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert True


# Generated at 2022-06-25 13:43:21.187693
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with no arguments
    text_environ_0 = _TextEnviron()
    got_name_0 = text_environ_0['PATH']
    assert got_name_0 == os.environ['PATH']
    got_name_1 = text_environ_0['LANG']
    assert got_name_1 == os.environ['LANG']
    got_name_2 = text_environ_0['HOME']
    assert got_name_2 == os.environ['HOME']


# Generated at 2022-06-25 13:43:24.308012
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        text_environ_0.__getitem__('USER')
    except KeyError:
        None


# Generated at 2022-06-25 13:43:31.062676
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    this_env = os.environ.get("LANG")
    if this_env is None:
        os.environ["LANG"] = "en_US.UTF-8"
    else:
        os.environ["LANG"] = this_env
    str_1 = "LANG"
    str_2 = text_environ_0.__getitem__(str_1)
    if str_2 is not None:
        assert (str_2 == "en_US.UTF-8")
    else:
        assert False


# Generated at 2022-06-25 13:43:38.303306
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_1 = _TextEnviron()
    text_environ_2 = _TextEnviron()
    text_environ_3 = _TextEnviron()
    text_environ_4 = _TextEnviron()
    text_environ_5 = _TextEnviron()
    text_environ_6 = _TextEnviron()
    text_environ_7 = _TextEnviron()
    text_environ_8 = _TextEnviron()
    text_environ_1.encoding = 'utf-8'

    # Check __getitem__ is callable
    try:
        text_environ_1.__getitem__
    except AttributeError:
        assert False, "Not callable"

    # Check __getitem__ with Unicode key


# Generated at 2022-06-25 13:43:45.478676
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_cases = [
        # text_environ_0 is the default environ wrapper
        {
            'text_environ': _TextEnviron(env={'A': b'\xe3\x83\x86\xe3\x82\xb9\xe3\x83\x88'}),
            'key': 'A',
            'value': u'\u30c6\u30b9\u30c8',
            'exception_expected': False
        },
        {
            'text_environ': _TextEnviron(env={'A': b'\xe3\x83\x86\xe3\x82\xb9\xe3\x83\x88'}),
            'key': 1,
            'value': None,
            'exception_expected': True
        }
    ]

# Generated at 2022-06-25 13:43:47.502753
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_arg_0 = text_environ_0.__getitem__('PATH')
    assert str_arg_0 is not None


# Generated at 2022-06-25 13:43:48.924891
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__(str(''))


# Generated at 2022-06-25 13:43:50.658664
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert text_environ_0._TextEnviron__getitem__(key__14) == value__15
    assert text_environ_0.get(key__14) == value__15
