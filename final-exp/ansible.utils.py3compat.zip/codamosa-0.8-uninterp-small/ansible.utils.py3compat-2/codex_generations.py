

# Generated at 2022-06-25 13:34:17.336112
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__('USER')
    var_1 = text_environ_0.__getitem__('HOME')
    var_2 = text_environ_0.__getitem__('PATH')


# Generated at 2022-06-25 13:34:19.637780
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__("")


# Generated at 2022-06-25 13:34:22.654759
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    w_0 = _TextEnviron()
    res_0 = w_0[w_0]
    assert(res_0 == None)


# Generated at 2022-06-25 13:34:24.832364
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__('PATH')


# Generated at 2022-06-25 13:34:27.930836
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_2 = _TextEnviron()
    key_2 = 'HOME'
    value_1 = text_environ_2.__getitem__(key_2)
    assert value_1 == os.path.expanduser('~')

# Generated at 2022-06-25 13:34:31.453174
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    # Test the return of the method
    var_return_0 = text_environ_0.__getitem__('SHELL')
    assert var_return_0 == '/bin/sh'


# Generated at 2022-06-25 13:34:33.328067
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__("PWD")


# Generated at 2022-06-25 13:34:38.051407
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__('LANG')
    var_1 = to_text(var_0)
    # var_1 = 'en_US.UTF-8'


# Generated at 2022-06-25 13:34:45.522968
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup test environment
    text_environ_1 = _TextEnviron()
    # Test __getitem__ method
    # Case 1
    var_1 = text_environ_1.__getitem__('C')
    assert var_1 == '\\Users\\THD\\Documents\\Code\\Ansible'
    # Case 2
    var_2 = text_environ_1.__getitem__('TEMPd')
    assert var_2 == 'C:\\Users\\THD\\AppData\\Local\\Temp'


# Generated at 2022-06-25 13:34:55.530720
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    _input_0 = dict(compat_env_1='foo')
    _input_1 = dict(compat_env_2='bar')
    _input_2 = dict(compat_env_3='baz')
    _input_3 = dict()
    _input_4 = dict(compat_env_4='foo')
    _input_5 = dict(compat_env_5='bar')
    _input_6 = dict(compat_env_6='baz')
    _input_7 = dict()
    _input_8 = dict(compat_env_7='foo')
    _input_9 = dict(compat_env_8='bar')
    _input_10 = dict(compat_env_9='baz')
    _input_11 = dict()
    _input_12 = dict

# Generated at 2022-06-25 13:34:57.572804
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-25 13:35:02.663248
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['SOME_VAR'] = 'some_value'
    assert environ['SOME_VAR'] == 'some_value'
    os.environ['SOME_VAR'] = b'some_value'
    assert environ['SOME_VAR'] == 'some_value'
    os.environ['SOME_VAR'] = u'some_value'
    assert environ['SOME_VAR'] == 'some_value'


# Generated at 2022-06-25 13:35:08.510800
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Init
    text_environ_0 = _TextEnviron()

    # Test for unicode encoding
    if PY3:
        # Check expected result
        assert(text_environ_0['PYTHONIOENCODING'] == 'UTF-8')
    # Test for bytes encoding
    else:
        # Check expected result
        assert(text_environ_0['PYTHONIOENCODING'] == u'UTF-8')


# Generated at 2022-06-25 13:35:10.139604
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_1 = text_environ_0['TEXTHOME']
    assert str_1 == os.environ['TEXTHOME']


# Generated at 2022-06-25 13:35:18.487394
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # value in cache
    # Note: This only tests the case where the value is in the cache.  It doesn't test that
    # getitem correctly handles things that aren't in the cache
    #
    # Setup:
    #   Create an environ object
    #   Add a value to the raw_environ dict
    #   Add the value's encoded version to the value cache
    #
    # Test:
    #   Call getitem on the key and see that we get the value from the cache
    text_environ_1 = _TextEnviron()

    k = "key"
    v = u"䷄"
    text_environ_1._raw_environ[k] = v.encode("utf-8")
    text_environ_1._value_cache[v.encode("utf-8")] = v



# Generated at 2022-06-25 13:35:20.460987
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('INPUTRC') == u'/etc/inputrc'


# Generated at 2022-06-25 13:35:22.848688
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1['a'] = 'b'
    value = text_environ_1['a']
    assert(value == 'b')


# Generated at 2022-06-25 13:35:27.926101
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Note: Tests for _TextEnviron directly are only useful for Python2.  Since it relies on the
    # utf-8 decode of bytes, it does not need to be run for python3 because that is the standard
    # behaviour of the interpreter.  Instead, we're testing that it is used in the correct places
    # and that it works correctly when Python2 is run.
    environ['TEST_VAR'] = b'Test Value'
    assert b'Test Value' == environ['TEST_VAR']


# Generated at 2022-06-25 13:35:29.603838
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0['HOME']
    assert str_0 == os.path.expanduser('~')

# Generated at 2022-06-25 13:35:33.132790
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.encoding = 'utf-8'
    try:
        text_environ_0['test_case_0']
        assert False
    except KeyError:
        pass


# Generated at 2022-06-25 13:35:35.647736
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == '/Users/toshio'



# Generated at 2022-06-25 13:35:38.935625
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_arg_0 = "PAGER"
    str_return_0 = text_environ_0.__getitem__(str_arg_0)
    assert str_return_0 == "less"


# Generated at 2022-06-25 13:35:48.043155
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Test that we can look up items in our _TextEnviron object
    '''
    text_environ = _TextEnviron()
    # Simple lookup
    if 'HOME' not in text_environ:
        raise AssertionError("Could not find 'HOME' in text_environ")
    if 'HOME' not in text_environ._raw_environ:
        raise AssertionError("Could not find 'HOME' in text_environ._raw_environ")
    if text_environ['HOME'] != text_environ._raw_environ['HOME']:
        raise AssertionError("raw_environ['HOME'] != text_environ['HOME']")
    # Unicode lookup from the environment
    text_environ['ANSIBLE_SOMETHING'] = u''

# Generated at 2022-06-25 13:35:49.468664
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # If encoding is None, fall back to sys.getfilesystemencoding()
    assert isinstance(environ, _TextEnviron)
    assert environ['PATH'] == os.environ['PATH']


# Generated at 2022-06-25 13:35:52.831721
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['HOME'] == os.environ['HOME']
    else:
        assert isinstance(environ['HOME'], str)
        assert environ['HOME'] == os.environ['HOME'].decode(sys.getfilesystemencoding())



# Generated at 2022-06-25 13:35:57.529782
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1[u'user'] = u'test_user'
    if sys.version_info[1] >= 6:
        assert text_environ_1[u'user'] == 'test_user', \
            u'Method __getitem__ of class _TextEnviron not working'
    else:
        assert text_environ_1[u'user'] == u'test_user', \
            u'Method __getitem__ of class _TextEnviron not working'


# Generated at 2022-06-25 13:36:07.119009
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    # If a dict is passed in, __getitem__ should return the same values
    assert(text_environ['USER'] == os.environ['USER'])

    # If a unicode str is passed in, it should return that item converted to text if it's in the native
    # strings but otherwise as bytes
    if sys.version_info[0] == 2:
        # If running on Python 2, unicode is the native string type
        assert(text_environ[u'HOME'] == os.environ[u'HOME'])
    else:
        # If running on Python 3, unicode is not the native string type
        assert(type(text_environ[u'HOME']) is not type(os.environ[u'HOME']))

    # If a byte str is passed in

# Generated at 2022-06-25 13:36:10.544622
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    x = _TextEnviron()
    x['a'] = '3'
    x['b'] = '4'
    assert x['a'] == '3'
    assert x['b'] == '4'


# Generated at 2022-06-25 13:36:15.293903
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    key_0 = 'ANTENNA_AZIMUTH'
    try:
        result_0 = text_environ_0.__getitem__(key_0)
    except KeyError:
        result_0 = None
    assert result_0 is None

# Generated at 2022-06-25 13:36:24.570510
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # __getitem__(self, key)
    #
    # Returns a text string from the environment instead of a byte string.
    #
    #  :arg str key: The key to look up from the environment
    #
    #  :returns: The value from the environment
    #  :rtype: text str (unicode on py2, str on py3)
    #
    #  :raises KeyError: Key doesn't exist in the environment
    #

    # Assign parameters
    text_environ_0.__setitem__(u'ANSIBLE_TEST_ENV_VAR', u'\ufffd')

    # Call method

# Generated at 2022-06-25 13:36:29.132290
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert (environ['PATH'] == '/usr/bin:/usr/local/bin:/usr/bin')
    assert (environ['THIS_KEY_SHOULD_NOT_EXIST'] == '')
    assert (environ['HOME'] == '/home/toshio')


# Generated at 2022-06-25 13:36:30.087101
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()

# Generated at 2022-06-25 13:36:35.765320
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    try:
        text_environ['ANSIBLE_TESTS_GET_ENV'] = 'ANSIBLE_TESTS_GET_ENV'
        value = text_environ['ANSIBLE_TESTS_GET_ENV']
        assert value == 'ANSIBLE_TESTS_GET_ENV'
    finally:
        try:
            del os.environ['ANSIBLE_TESTS_GET_ENV']
        except KeyError:
            pass



# Generated at 2022-06-25 13:36:36.624957
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-25 13:36:39.808269
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    expected = u'bar'
    result = text_environ_1.__getitem__(u'foo')
    assert result == expected


# Generated at 2022-06-25 13:36:44.946553
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # In Python 2, we decode and cache the first run of each variable's value
    if not PY3:
        assert environ['PATH'] == u'/bin'
        assert environ._value_cache[u'/bin'] == u'/bin'
    # Python3 has no such cache
    else:
        assert environ['PATH'] == '/bin'
        assert 'caching' not in environ.__dict__

# Generated at 2022-06-25 13:36:46.932725
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # assert test_case_1() == (e_in, expected_out)
    pass  # TODO


# Generated at 2022-06-25 13:36:51.750790
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from distutils.version import LooseVersion
    assert LooseVersion(sys.version) < LooseVersion('3.0'), "'__getitem__' of class '_TextEnviron' is not tested for Python 3.0 and higher"
    text_environ_0 = _TextEnviron()
    for key in text_environ_0:
        text_environ_0.__getitem__(key)


# Generated at 2022-06-25 13:36:52.633657
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()  # Use of _TextEnviron class to set environment variable

# Generated at 2022-06-25 13:37:03.288657
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Tests that a simple string in the environment is passed through properly
    assert(environ['PATH'] == os.environ['PATH'])

    # Tests that a unicode string in the environment is passed through properly
    assert(environ['LANG'] == os.environ['LANG'])

    # Tests that non-unicode data in the environment is passed through properly
    # Coded both using raw bytes below 128 and using a surrogate escape character
    os.environ['ANSI_STR'] = b'\x41\x64\x20\x6d\x6f\x64\x75\x6c\x75\x73\x20\x61\x20\x66\x65\x75\x67\x69\x61\x74'

# Generated at 2022-06-25 13:37:13.060540
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Test that zero length key raises KeyError
    try:
        text_environ_0.__getitem__("")
    except KeyError:
        pass
    else:
        raise AssertionError("Expected exception")
    # Test that invalid key raises KeyError
    try:
        text_environ_0.__getitem__("bc")
    except KeyError:
        pass
    else:
        raise AssertionError("Expected exception")

# Generated at 2022-06-25 13:37:15.717930
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    my_var = 'MY_VAR'
    environ[my_var] = '23'
    assert environ[my_var] == '23'

test_case_0()
test__TextEnviron___getitem__()

# Generated at 2022-06-25 13:37:19.852262
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global environ
    text_environ_0 = _TextEnviron()
    for key, value in environ.items():
         assert isinstance(text_environ_0[key], (str, unicode))


# Generated at 2022-06-25 13:37:22.125259
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    print('Passed!')


if __name__ == '__main__':
    test__TextEnviron___getitem__()

# Generated at 2022-06-25 13:37:24.509164
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    pass
    #assertEqual(expected, text_environ_1.__getitem__(key))


# Generated at 2022-06-25 13:37:27.445338
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var0 = 'SNAP_NAME'
    var1 = 'SHLVL'

    def __getitem__0():
        value0 = text_environ_0[var0]
        return



# Generated at 2022-06-25 13:37:29.936123
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if not PY3:
        text_environ = _TextEnviron()
        assert text_environ['PATH'] == text_environ._raw_environ['PATH'].decode('utf-8')


# Generated at 2022-06-25 13:37:33.207656
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__setitem__('foo', 'bar')
    text_environ_0.__setitem__('foo', 'baz')
    text_environ_0.__setitem__('foo', 'baz')


# Generated at 2022-06-25 13:37:35.217303
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    key = 'LANG'
    value = text_environ_0[key]


# Generated at 2022-06-25 13:37:39.096245
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    item_value_0 = 'value'
    text_environ_0['item'] = item_value_0
    result__TextEnviron___getitem__ = text_environ_0['item']
    assert result__TextEnviron___getitem__ == item_value_0



# Generated at 2022-06-25 13:37:50.845745
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    key = ''
    value = text_environ_0.__getitem__(key)
    assert value == text_environ_0[key]


# Generated at 2022-06-25 13:37:52.458725
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0['PATH'] == os.environ['PATH']


# Generated at 2022-06-25 13:37:56.669356
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    key = 'ANSIBLE_VERSION_CHECK_INTERVAL'
    text_environ_0 = _TextEnviron()
    val = text_environ_0[key]
    # TODO: this case can caused by system install.
    if val is not None and 'strict' in val:
        val = None
    assert val == '0'


# Generated at 2022-06-25 13:38:02.151759
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        text_environ_0.__getitem__(str())
    except KeyError as exception_instance_0:
        pass
    #
    text_environ_1 = _TextEnviron()
    try:
        text_environ_1.__getitem__(str())
    except KeyError as exception_instance_0:
        pass
    #


# Generated at 2022-06-25 13:38:04.786645
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    assert issubclass(_TextEnviron, MutableMapping)


# Generated at 2022-06-25 13:38:13.255055
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import pytest
    from ansible.module_utils.six import PY3
    if not PY3:
        # Only run this test on python2
        #
        # Create a directory with a non-ascii name and cd into it so
        # we can check to see if the environment is set up correctly
        # for handling non-ascii directory names
        test_dir = 'ಠ_ಠ'
        pytest.fileutil.mkdir(test_dir)
        os.chdir(test_dir)

        text_environ = _TextEnviron()

        # We have to check the prefix because, on some systems, the current
        # directory is set up to be the full path from the root dir.  On
        # others, the current directory is set to just the relative path
        # from the root.  Also

# Generated at 2022-06-25 13:38:17.751551
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if not PY3:
        for key, value in os.environ.items():
            # The value of the key needs to be decoded.  The test might pass but if the current
            # encoding can't decode the value, it will fail later.  Therefore, pick an encoding
            # that is guaranteed to support the US-ASCII subset (latin-1)
            assert text_environ_0.get(key) == to_text(value, encoding='latin-1',
                                                      errors='surrogate_or_strict')



# Generated at 2022-06-25 13:38:21.845648
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        text_environ_0.__getitem__('HOME')
    except TypeError as e:
        if "unsubscriptable object" in str(e):
            print(str(e))
            return
    assert False, 'Should have failed.'


# Generated at 2022-06-25 13:38:24.727976
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['PATH'] == os.environ['PATH']
    else:
        assert environ['PATH'] == os.environ['PATH'].decode('utf-8')


# Generated at 2022-06-25 13:38:33.334987
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__("elb-name")
    text_environ_0.__getitem__("HTTP_PROXY")
    text_environ_0.__getitem__("AWS_ACCESS_KEY_ID")
    text_environ_0.__getitem__("AWS_SECRET_ACCESS_KEY")
    text_environ_0.__getitem__("AWS_SESSION_TOKEN")
    text_environ_0.__getitem__("AWS_CREDENTIAL_EXPIRATION")
    text_environ_0.__getitem__("AWS_ROLE_ARN")

# Generated at 2022-06-25 13:38:54.951978
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for type _TextEnviron
    text_environ_0 = _TextEnviron()
    # Test for type _TextEnviron and key str
    text_environ_0.__getitem__('SHLVL')


# Generated at 2022-06-25 13:38:57.689205
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    expected_encoding = sys.getfilesystemencoding()
    expected_text = u'bar'

    # Get the value of the 'foo' environment variable
    value = environ[u'foo']

    assert value == expected_text
    assert type(value) == type(expected_text)


# Generated at 2022-06-25 13:39:01.217414
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1['USER'] = u'mt'
    assert text_environ_1['USER'] == u'mt'



# Generated at 2022-06-25 13:39:10.641281
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0[u'_ANSIBLE_VERSION'] = u'0.0.0'
    text_environ_0[u'_ANSIBLE_VERSIONS'] = u'0.0.0'
    testval = u"value"
    text_environ_0[u'key'] = testval
    text_environ_0[u'key2'] = u'2'
    text_environ_0[u'key3'] = u'3'
    text_environ_0[u'key4'] = u'4'
    text_environ_0[u'key5'] = u'5'
    # Testing the == comparison operator
    assert(text_environ_0[u'key'] == testval)
    # Testing the

# Generated at 2022-06-25 13:39:18.879889
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Tests that __getitem__ works properly on a _TextEnviron
    """
    # Make sure that we don't get a conversion problem with the default encoding
    text_environ_0 = _TextEnviron(encoding=sys.getfilesystemencoding())
    assert text_environ_0['PATH'] == environ['PATH']
    # Make sure that we get a conversion problem with an incompatible encoding
    text_environ_1 = _TextEnviron(encoding='latin-1')
    with pytest.raises(UnicodeError):
        assert text_environ_1['PATH'] == environ['PATH']
    # Make sure that the surrogate_or_strict decoding works
    bad_unicode_cached = u'\udce8'  # Surrogate character
    text_environ_2 = _Text

# Generated at 2022-06-25 13:39:20.729373
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # check if the key exists in the environ
    assert 'PATH' in environ
    # check that the key is decoded properly.
    assert isinstance(environ['PATH'], str)


# Generated at 2022-06-25 13:39:25.406292
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        text_environ_0 = _TextEnviron()
        text_environ_0.__getitem__("ISL-VEB")
        text_environ_0.__getitem__("SHLVL")
    except Exception as e:
        print(e)


# Generated at 2022-06-25 13:39:28.843466
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(env={b'value0': to_bytes('value0')})
    assert text_environ_0[b'value0'] == to_text('value0')


# Generated at 2022-06-25 13:39:33.341181
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an instance of _TextEnviron
    text_environ = _TextEnviron()
    # If PY3, getitem from _TextEnviron should return a string
    if PY3:
        assert(isinstance(text_environ['STATUS'], str))
    else:
        assert(isinstance(text_environ['STATUS'], unicode))



# Generated at 2022-06-25 13:39:41.468447
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    if PY3:
        os.environ['text_environ_key_0'] = 'unicodé'
    else:
        os.environ['text_environ_key_0'] = b'unicod\xc3\xa9'

    text_environ_0 = _TextEnviron()
    # Returns <class '_ansible_test._TextEnviron'>
    assert(isinstance(text_environ_0, _TextEnviron))

    text_environ_0.encoding = 'utf-8'

    try:
        # Returns 'unicodé'
        assert(text_environ_0['text_environ_key_0'] == u'unicodé')
    finally:
        del os.environ['text_environ_key_0']

    text_environ_0 = _Text

# Generated at 2022-06-25 13:40:04.758794
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    value = text_environ_0._TextEnviron__getitem__('LANG')
    assert value.endswith('UTF-8')



# Generated at 2022-06-25 13:40:09.125341
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global environ
    try:
        for k in environ:
            assert isinstance(environ[k], str), 'Expected type str, got %s instead' % type(environ[k])
    except BaseException as e:
        print('An error occurred while testing function _TextEnviron.__getitem__:')
        print(str(e))
        return False
    else:
        return True


# Generated at 2022-06-25 13:40:12.273038
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    text_environ = _TextEnviron()

    # Exercise

    # Exercise
    # Verify
    assert isinstance(text_environ["PATH"], text)
    assert isinstance(text_environ[u"PATH"], text)
    assert isinstance(text_environ[b"PATH"], text)



# Generated at 2022-06-25 13:40:20.825242
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Python2
    if not PY3:
        # Values come in as bytes
        assert isinstance(text_environ_0['ASCII'], text_type)
        assert text_environ_0['ASCII'] == b'ascii'

        # Non-ASCII values get encoded
        assert isinstance(text_environ_0['NON_ASCII'], text_type)
        assert text_environ_0['NON_ASCII'] == b'\xef\xbf\xbd'

        # Keys come in as bytes
        assert isinstance(list(text_environ_0.keys())[0], text_type)

    # Python3
    else:
        assert isinstance(text_environ_0['ASCII'], text_type)
        assert text_environ_0['ASCII']

# Generated at 2022-06-25 13:40:23.843404
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({'foo': 'foo'})
    if PY3:
        assert environ['foo'] == 'foo'
    else:
        assert environ['foo'] == u'foo'




# Generated at 2022-06-25 13:40:24.812728
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()


# Generated at 2022-06-25 13:40:27.196067
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError):
        text_environ_0.__getitem__(str())


# Generated at 2022-06-25 13:40:34.978876
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from nose.tools import assert_equals, assert_true
    text_environ_0 = _TextEnviron()
    if hasattr(text_environ_0, '__getitem__'):
        # Call the method __getitem__
        ret = text_environ_0.__getitem__('USER')
        assert_equals(ret, to_text(to_bytes('USER', encoding='utf-8', nonstring='strict',
                                            errors='surrogate_or_strict')))
        # Return value assertion
        # The value
        assert_true(ret)
    else:
        raise Exception('Method __getitem__ in class _TextEnviron not implemented')


# Generated at 2022-06-25 13:40:42.987304
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    keys = ('PATH', 'LANG', 'HOME', 'PATH_INFO')

    # Ensure the environment has at least one key which is not a byte string
    if PY3:
        keys = (k for k in keys if not isinstance(k, bytes))

    for key in keys:
        # Run in a subprocess so we can modify the environment without worrying about cleanup
        # after the test
        codec = 'utf-8' if PY3 else sys.getfilesystemencoding()
        os.environ[key] = u'ü{0}'.format(key).encode(codec, 'surrogateescape')

# Generated at 2022-06-25 13:40:51.655926
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:41:40.389498
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:41:42.270889
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert text_environ_0.__getitem__(u'COMPANY_ID') == u'0'


# Generated at 2022-06-25 13:41:51.280416
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import pytest
    from ansible.module_utils._six import PY3

    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError):
        text_environ_0.__getitem__('PqCjYV')
    with pytest.raises(KeyError):
        text_environ_0.__getitem__('gPMtwT')
    with pytest.raises(KeyError):
        text_environ_0.__getitem__('JNOkZI')
    with pytest.raises(KeyError):
        text_environ_0.__getitem__('GJaW')
    with pytest.raises(KeyError):
        text_environ_0.__getitem__('mKMi')

# Generated at 2022-06-25 13:41:53.755126
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.get('HOME')
    text_environ_0.get('LANG')
    text_environ_0.get('PATH')


# Generated at 2022-06-25 13:41:55.818835
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    value = text_environ_1['SHELL']
    assert value == os.environ['SHELL']


# Generated at 2022-06-25 13:42:01.672038
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test 1:
    # Testing __getitem__() when the key name is present in the environment
    key_name = 'LANG'
    assert key_name in _TextEnviron()

    # Test 2:
    # Testing __getitem__() when the key name is not present in the environment
    # Since the Python2 environment is bytestrings, we need to encode the key name to bytes
    key_name = 'TEST_UNIQUE_KEY_NAME'
    if PY3:
        key_name = to_bytes(key_name)
    assert key_name not in _TextEnviron()


# Generated at 2022-06-25 13:42:04.308526
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Tests that _TextEnviron.__getitem__ returns text on Py2
    if not PY3:
        assert isinstance(text_environ_0.__getitem__('PATH'), text_type)


# Generated at 2022-06-25 13:42:07.424550
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # This is the python2 handling, shouldn't be true
    assert isinstance(text_environ_0['PATH'], unicode)
    assert text_environ_0['PATH'] == os.getenv('PATH')


# Generated at 2022-06-25 13:42:09.514928
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_0 = _TextEnviron()
    assert environ_0.__getitem__("MACOSX_DEPLOYMENT_TARGET") == "10.13"


# Generated at 2022-06-25 13:42:16.454688
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test 'ANSIBLE_SYSTEMD_UNIT_PATH' when not set
    assert('ANSIBLE_SYSTEMD_UNIT_PATH' not in os.environ)
    assert('ANSIBLE_SYSTEMD_UNIT_PATH' not in text_environ_0)
    assert('ANSIBLE_SYSTEMD_UNIT_PATH' not in environ)

    # Test 'ANSIBLE_SYSTEMD_UNIT_PATH' when set
    os.environ['ANSIBLE_SYSTEMD_UNIT_PATH'] = '/this/is/a/test'
    assert('ANSIBLE_SYSTEMD_UNIT_PATH' in os.environ)
    assert('ANSIBLE_SYSTEMD_UNIT_PATH' in text_environ_0)

# Generated at 2022-06-25 13:44:03.688513
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['test_key'] = 'test_value'


# Generated at 2022-06-25 13:44:04.751122
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test cases
    test_case_0()


# Generated at 2022-06-25 13:44:06.978367
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1[u'TEST_0'] = u'test value 0'
    assert text_environ_1[u'TEST_0'] == u'test value 0'


# Generated at 2022-06-25 13:44:09.414987
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    d = {}
    d['foo'] = 'bar'
    d['baz'] = 'qux'
    text_environ__getitem__0 = _TextEnviron(d)
    assert text_environ__getitem__0['foo'] == 'bar'
    assert text_environ__getitem__0['baz'] == 'qux'


# Generated at 2022-06-25 13:44:10.296076
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

