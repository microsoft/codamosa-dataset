

# Generated at 2022-06-25 13:34:20.931172
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__('{?d8<%W&_oLlw')


# Generated at 2022-06-25 13:34:24.446982
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test case 0
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__('_TextEnviron')


# Generated at 2022-06-25 13:34:26.638269
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # The following line is for mock of os.environ.
    os.environ = {'HOME': '/home/developer', 'SHELL': 'bash'}

    text_environ_0 = _TextEnviron()

    # Assigning to a "dict" with more than one item.
    var_0 = text_environ_0.__getitem__(('SHELL', 'HOME'))


# Generated at 2022-06-25 13:34:28.675950
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__("\n")


# Generated at 2022-06-25 13:34:31.884261
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_1 = text_environ_0.__getitem__('TOP_LEVEL_CACHE')
    assert var_1 == 'false'


# Generated at 2022-06-25 13:34:35.903057
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Instantiate _TextEnviron
    text_environ_0 = _TextEnviron()
    # Call method
    var_0 = text_environ_0.__getitem__('PYTHONPATH')
    # Return type assertion
    assert isinstance(var_0, str)


# Generated at 2022-06-25 13:34:39.946630
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    text_environ_1 = _TextEnviron()
    var_1 = text_environ_1.__getitem__(key)
    """
    pass


# Generated at 2022-06-25 13:34:43.157634
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__("JL")


# Generated at 2022-06-25 13:34:45.143781
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_1 = _TextEnviron()
    var_1 = environ_1.__getitem__('')


# Generated at 2022-06-25 13:34:47.921761
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_1 = text_environ_0.__getitem__("TERM")


# Generated at 2022-06-25 13:34:54.222551
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    key = 'PATH'
    if PY3:
        text_environ_0 = _TextEnviron()
        assert isinstance(text_environ_0[key], str)
    else:
        text_environ_0 = _TextEnviron()
        assert isinstance(text_environ_0[key], unicode)


# Generated at 2022-06-25 13:34:56.984454
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    key_0 = 'BASH'
    result_0 = text_environ_0.__getitem__(key_0)
    assert result_0 == ''



# Generated at 2022-06-25 13:35:02.633833
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test that __getitem__ handles bytes to text conversion correctly.
    """
    # Test on Windows
    sys.platform = "win32"
    sys.getfilesystemencoding = lambda: "cp932"

    text_environ = _TextEnviron()
    text_environ[b'PYTHONIOENCODING'] = u'utf-8'
    assert text_environ[b'PYTHONIOENCODING'] == u'utf-8'
    text_environ[b'ANSI_X3.4-1968'] = b'ANSI_X3.4-1968'
    assert text_environ[b'ANSI_X3.4-1968'] == b'ANSI_X3.4-1968'

# Generated at 2022-06-25 13:35:04.955086
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    key_0 = None
    text_environ_0 = _TextEnviron()
    text = text_environ_0.__getitem__(key_0)


# Generated at 2022-06-25 13:35:08.324490
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1[u'LANG']
    text_environ_1[u'TERM']
    text_environ_1[u'PATH']


# Generated at 2022-06-25 13:35:16.850137
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test #0 for method __getitem__
    # of class _TextEnviron
    # Test with a PY3 machine
    # Test with PY2
    # Test that encoding is correct: utf-8
    text_environ_0 = _TextEnviron(encoding='utf-8')
    text_environ_0['LANG'] = 'en_US.UTF-8'
    text_environ_0.__getitem__(key='LANG')
    text_environ_0.__getitem__(key=to_bytes('LANG'))
    text_environ_0.__getitem__(key='LANG2')
    text_environ_0.__getitem__(key=None)

# Generated at 2022-06-25 13:35:18.648875
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    # __getitem__ should return a string for os.environ['PATH']
    text_environ_1['PATH']


# Generated at 2022-06-25 13:35:22.114816
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__setitem__(to_bytes('key_0'), to_bytes('value_0'))
    assert text_environ_0.__getitem__(to_bytes('key_0')) == 'value_0'


# Generated at 2022-06-25 13:35:24.023484
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert('SHELL' in text_environ_0)


# Generated at 2022-06-25 13:35:29.725083
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0['EDITOR'] == 'vim'
    assert text_environ_0[to_text('EDITOR', encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict')] == 'vim'
    assert text_environ_0[to_bytes('EDITOR', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')] == 'vim'
    assert text_environ_0['EDITOR'] == 'vim'



# Generated at 2022-06-25 13:35:40.329587
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:35:43.698065
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Verify the exception handling of the __getitem__ method of class _TextEnviron
    try:
        text_environ_3 = _TextEnviron()
        text_environ_3.__getitem__('test_value_3')
    except:
        pass


# Generated at 2022-06-25 13:35:51.233508
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 =  _TextEnviron()
    # Fake a UTF-8 encoded environment variable
    value = '\N{SNOWMAN}'
    value_bytes = value.encode('utf8')
    os.environ['FAKE_ENV_VAR'] = value_bytes
    # Fetch the environment variable
    returned_value = text_environ_0['FAKE_ENV_VAR']
    # Assert that we got back a text string and not a byte string
    assert isinstance(returned_value, unicode)
    # Assert that the value we got back is the same as input
    assert returned_value == value


# Generated at 2022-06-25 13:35:53.242671
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    test_key_0 = ''
    try:
        test_result = text_environ.__getitem__(test_key_0)

    except Exception as e:
        test_error_0 = str(e)
        assert(test_error_0 == 'KeyError: \'' + str(test_key_0) + '\'')



# Generated at 2022-06-25 13:35:53.988779
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()



# Generated at 2022-06-25 13:35:59.614156
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.encoding = 'utf-16'
    val_0 = text_environ_0.__getitem__('tmpld2o.ext')
    text_environ_0.encoding = 'cp850'
    text_environ_0.encoding = 'utf-8'
    text_environ_0.encoding = sys.getfilesystemencoding()
    text_environ_0.encoding = 'utf-8'
    text_environ_0.encoding = sys.getfilesystemencoding()
    text_environ_0.encoding = 'utf-8'
    text_environ_0.encoding = 'utf-16'

# Generated at 2022-06-25 13:36:02.470906
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert isinstance(text_environ_1.__getitem__('PWD'), unicode)


# Generated at 2022-06-25 13:36:09.733438
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError) as getitem_exception:
        text_environ_0.__getitem__('X0U9')
    with pytest.raises(TypeError) as getitem_exception:
        text_environ_0.__getitem__(5)
    with pytest.raises(TypeError) as getitem_exception:
        text_environ_0.__getitem__(0.8)
    with pytest.raises(TypeError) as getitem_exception:
        text_environ_0.__getitem__(True)
    with pytest.raises(TypeError) as getitem_exception:
        text_environ_0.__getitem__(False)

# Generated at 2022-06-25 13:36:15.144251
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    try:
        text_environ['test_case_1']
        assert False
    except KeyError:
        pass
    text_environ['test_case_1'] = 'test_case_1'
    assert text_environ['test_case_1'] == 'test_case_1'


# Generated at 2022-06-25 13:36:16.640467
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()


# Generated at 2022-06-25 13:36:21.502388
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """_TextEnviron.__getitem__() returns text strings"""
    text_environ_0 = _TextEnviron()
    text_environ_0.__setitem__('HOME', '/home/joe')
    assert text_environ_0.__getitem__('HOME') == '/home/joe'
    assert type(text_environ_0.__getitem__('HOME')) is str
    assert type(os.environ.__getitem__('HOME')) is str


# Generated at 2022-06-25 13:36:25.449073
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that when os.environ has a byte string it returns a text string
    text_environ = _TextEnviron({b'BYTE_STR' : b'data'})
    assert isinstance(text_environ['BYTE_STR'], str)
    assert text_environ['BYTE_STR'] == 'data'


# Generated at 2022-06-25 13:36:26.831951
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('PATH') == os.environ['PATH']



# Generated at 2022-06-25 13:36:28.614726
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1['PATH'] == os.environ['PATH']



# Generated at 2022-06-25 13:36:37.325233
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    # Test test_case_0
    text_environ_0.__getitem__('USER')
    # Test test_case_1
    text_environ_0.__getitem__('HOME')
    # Test test_case_2
    text_environ_0.__getitem__('USERNAME')

    # Test test_case_3
    text_environ_1 = _TextEnviron(encoding='gbk')
    text_environ_1.__getitem__('USER')
    # Test test_case_4
    text_environ_1.__getitem__('HOME')
    # Test test_case_5
    text_environ_1.__getitem__('USERNAME')

    # Test test_case_6
    text_en

# Generated at 2022-06-25 13:36:44.560642
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0[to_bytes('HOME', errors='surrogate_or_strict')] == None
    assert text_environ_0[to_bytes('PATH', errors='surrogate_or_strict')] == None
    assert text_environ_0[to_bytes('windowssubsystemforlinux', errors='surrogate_or_strict')] is None
    assert text_environ_0[to_bytes('NOCOMPILEFLAGS', errors='surrogate_or_strict')] is None

# Generated at 2022-06-25 13:36:45.601989
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-25 13:36:47.441092
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert_equal(environ['HOME'], os.environ['HOME'])


# Generated at 2022-06-25 13:36:52.967176
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:36:55.479394
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__('_')
    assert result is not None


# Generated at 2022-06-25 13:37:07.332738
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_value_0 = text_environ_0.__getitem__('LC_ALL')
    str_value_1 = text_environ_0.__getitem__('LC_TIME')
    str_value_2 = text_environ_0.__getitem__('LC_PAPER')
    str_value_3 = text_environ_0.__getitem__('LC_COLLATE')
    str_value_4 = text_environ_0.__getitem__('LC_MONETARY')
    str_value_5 = text_environ_0.__getitem__('LC_MEASUREMENT')
    str_value_6 = text_environ_0.__getitem__('LC_NUMERIC')
    str_value_7

# Generated at 2022-06-25 13:37:10.782873
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        # Test failure due to wrong type of argument
        environ.__getitem__('foo')

        # Test failure due to wrong type of argument
        environ.__getitem__(1)
    except TypeError:  # expected failure
        pass


# Generated at 2022-06-25 13:37:20.813350
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    with patch.object(os, 'environ',
                      new_callable=mock.PropertyMock) as mock_environ:

        # Set up env. variables (mock)
        def side_effect():
            return {
                b'ANSIBLE_ABORT_EXCEPTIONS': b'False',
                b'ANSIBLE_CALLABLE_WHITELIST': b'',
                b'ANSIBLE_COLLECTIONS_PATH': b'',
                b'ANSIBLE_HOST_KEY_CHECKING': b'False',
                b'ANSIBLE_INVENTORY': b'',
                b'ANSIBLE_MATCH_HOSTNAME': b'no'
            }
        mock_environ.__get__ = Mock(side_effect=side_effect)

        # Instantiate class _TextEnviron
        text_en

# Generated at 2022-06-25 13:37:21.652365
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-25 13:37:24.991002
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('HOME') == 'C:\\Users\\toshio' or '/home/toshio' or 'C:\\Users\\toshio'


# Generated at 2022-06-25 13:37:27.889985
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.keys()
    text_environ_0.values()
    text_environ_0.__iter__()
    text_environ_0.__len__()


# Generated at 2022-06-25 13:37:31.582042
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    test_0 = text_environ_1[to_bytes('SHELL', encoding='ascii')]
    assert isinstance(test_0, str)
    test_1 = text_environ_1[to_bytes('THIS_OVALUE', encoding='ascii')]
    assert test_1 is None


# Generated at 2022-06-25 13:37:38.706547
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    test_values = {"b1": b"1",
                   "b2": b"2",
                   "b3": b"3",
                   "b4": b"\xe2",
                   "b5": b"\xe2\x2e"}

    for key, value in test_values.items():
        text_environ[key] = value

    for key, value in test_values.items():
        if PY3:
            assert text_environ[key] == value
        else:
            # By default, we assume that the value is already encoded properly
            assert text_environ[key] == to_text(value)



# Generated at 2022-06-25 13:37:40.761039
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__('ANSIBLE_VERBOSITY')


# Generated at 2022-06-25 13:37:50.645937
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ0 = _TextEnviron()

    # Negative test
    # Test case: key = '', value = ''
    try:
        result = text_environ0['']
    except KeyError:
        pass

    # Test case: key = '', value = 'e2e86f7d-f1c6-4c55-a3e3-2e8b9d10304f'
    text_environ0[''] = 'e2e86f7d-f1c6-4c55-a3e3-2e8b9d10304f'
    result = text_environ0['']

    # Negative test
    # Test case: key = '', value = ''
    try:
        result = text_environ0['']
    except KeyError:
        pass

# Generated at 2022-06-25 13:37:56.838261
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """
    if PY3:
        return
    test_case_0()
    # Insert method testing here
    raise NotImplementedError


if __name__ == '__main__':
    test__TextEnviron___getitem__()

# Generated at 2022-06-25 13:38:06.548420
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Test for method ``_TextEnviron.__getitem__``"""
    if PY3:
        # Make sure that the encoding we got from the system is the same as Python3's default
        # for os.environ
        assert sys.getfilesystemencoding() == sys.stdout.encoding
    # By default we get strings out of environ
    assert isinstance(environ['PATH'], str)
    # Python3 should give us back bytes
    text_environ_3 = _TextEnviron(encoding=None)
    assert isinstance(text_environ_3['PATH'], bytes)

    # Test with an encoding that is explicitly specified
    text_environ_explicit = _TextEnviron(encoding='iso8859-1')
    assert isinstance(text_environ_explicit['PATH'], str)

# Generated at 2022-06-25 13:38:08.881756
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__('/usr/bin/which')


# Generated at 2022-06-25 13:38:12.548617
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        text_environ_0.__getitem__("3<]@k4")
    except KeyError as exc:
        assert exc.args[0] == "3<]@k4"
    else:
        raise AssertionError("No exception was raised")

# Generated at 2022-06-25 13:38:19.842432
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_arg_0 =  text_environ_0[ord(')')]
    str_arg_0 =  text_environ_0[ord('K')]
    str_arg_0 =  text_environ_0[ord('e')]
    str_arg_0 =  text_environ_0[ord('x')]
    text_environ_0.__getitem__(ord('k'))
    str_arg_0 =  text_environ_0[ord('!')]
    text_environ_0.__getitem__(ord('|'))
    str_arg_0 =  text_environ_0[ord('\r')]
    text_environ_0.__getitem__(ord('('))
    str

# Generated at 2022-06-25 13:38:28.183134
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create the text_environ from the bytes_environ
    text_environ_0 = _TextEnviron(os.environ.copy())

    # Test decoding from text
    assert text_environ_0['LANG'] == os.environ['LANG']
    assert text_environ_0['LANG'] == u'en_US.UTF-8'

    # Test decoding from bytes
    assert text_environ_0['PATH'] == os.environ['PATH']

# Generated at 2022-06-25 13:38:36.866508
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with string value
    os.environ['ANSIBLE_TEST_VAR_GETITEM'] = 'ansible'
    assert 'ansible' == text_environ_0['ANSIBLE_TEST_VAR_GETITEM']
    assert 'ansible' == os.environ['ANSIBLE_TEST_VAR_GETITEM']
    del os.environ['ANSIBLE_TEST_VAR_GETITEM']
    os.environ['ANSIBLE_TEST_VAR_GETITEM'] = 'b'
    assert 'b' == text_environ_0['ANSIBLE_TEST_VAR_GETITEM']
    assert 'b' == os.environ['ANSIBLE_TEST_VAR_GETITEM']

# Generated at 2022-06-25 13:38:40.520270
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Since we have no idea what the value of os.environ will be when this test
    # is run, we'll just verify that __getitem__ returns a text type.
    text_environ = _TextEnviron()
    for key in text_environ:
        assert isinstance(text_environ[key], text_type)



# Generated at 2022-06-25 13:38:50.577226
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an instance of _TextEnviron
    text_environ_1 = _TextEnviron()

    # Call __getitem__ on the instance
    if PY3:
        # On Python 3, os.environ returns unicode strings.  Just pass the string through.
        result = text_environ_1.__getitem__('HOME')
        assert result == os.environ['HOME']
    else:
        # On Python 2, os.environ returns byte strings.  Decode them.
        result = text_environ_1.__getitem__('HOME')
        assert result == os.environ['HOME'].decode(sys.getfilesystemencoding(), errors='surrogate_or_strict')


# Generated at 2022-06-25 13:38:54.086906
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1.__setitem__(to_text(u'SHELL'), to_text(u'/bin/bash'))
    text_environ_1.__getitem__(to_text(u'SHELL'))


# Generated at 2022-06-25 13:39:01.485934
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    _environ = _TextEnviron()
    assert _environ.__getitem__('PATH') == os.environ['PATH']


# Generated at 2022-06-25 13:39:03.942158
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_0 = _TextEnviron()
    if not (environ_0['PATH'] == to_text(environ_0['PATH'])): raise AssertionError()

# Generated at 2022-06-25 13:39:07.375538
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_1 = text_environ_0.__getitem__('')
    assert(str_1 == text_environ_0[' '])


# Generated at 2022-06-25 13:39:09.512395
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['ANSIBLE_ACTION_PLUGINS'] == ""
    else:
        assert environ['ANSIBLE_ACTION_PLUGINS'] == u""

# Generated at 2022-06-25 13:39:12.941443
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    # Ensure that we return a text value when getting an environment key
    text_environ['LC_ALL'] = 'en_US.UTF-8'
    assert isinstance(text_environ['LC_ALL'], str)


# Generated at 2022-06-25 13:39:15.274547
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] != os.environ['PATH']
    assert environ['PATH'] == os.environ['PATH'].decode('UTF-8')


# Generated at 2022-06-25 13:39:16.676103
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert text_environ_0.__getitem__('LOGNAME') == os.environ['LOGNAME']



# Generated at 2022-06-25 13:39:19.120763
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    var_1_0 = text_environ_1['SHELL']
    assert var_1_0 is not None, "call to read False failed"


# Generated at 2022-06-25 13:39:28.761588
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test a native str key
    os.environ['STR_K'] = 'str_v'
    assert os.environ['STR_K'] == 'str_v'
    assert environ['STR_K'] == 'str_v'

    # Test a non-native str key
    os.environ[u'UNICODE_K'] = u'unicode_v'
    assert os.environ['UNICODE_K'] == u'unicode_v'
    assert environ['UNICODE_K'] == u'unicode_v'

    # Test a b'' key
    os.environ[u'UNICODE_K'.encode('utf-8')] = u'unicode_v'

# Generated at 2022-06-25 13:39:37.693815
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # 1. Case
    # Create an object for testing
    text_environ_0 = _TextEnviron()
    # Set variable for testing
    text_environ_0._raw_environ = {"LOGNAME": "sysadmin", "LANG": "C.UTF-8", "TERM": "dumb", "HOME": "/home/sysadmin", "HOSTNAME": "storm"}
    # Testing...
    assert len(text_environ_0) == 5
    assert text_environ_0['LOGNAME'] == "sysadmin"
    assert text_environ_0['LANG'] == "C.UTF-8"
    assert text_environ_0['TERM'] == "dumb"
    assert text_environ_0['HOME'] == "/home/sysadmin"

# Generated at 2022-06-25 13:39:46.976414
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Given a key
    text_environ = _TextEnviron(env={'key': 'value'})

    # When we try to access the value by the key
    result = text_environ['key']

    # Then we should get the value
    assert result == 'value'



# Generated at 2022-06-25 13:39:54.344529
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    # Before
    text_environ_1["LANG"] = "en_US.UTF-8"
    text_environ_1["LANGUAGE"] = "en_US:en"
    assert text_environ_1["LANG"] == "en_US.UTF-8"
    assert text_environ_1["LANGUAGE"] == "en_US:en"
    assert text_environ_1.get("LANG") == "en_US.UTF-8"
    assert text_environ_1.get("LANGUAGE") == "en_US:en"

    text_environ_2 = _TextEnviron()
    # After
    os.environ["LANG"] = "en_US.UTF-8"

# Generated at 2022-06-25 13:39:55.208498
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert 1 == 1


# Generated at 2022-06-25 13:39:56.431357
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == u'/home/a.badger'


# Generated at 2022-06-25 13:39:59.840878
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup test
    text_environ_0 = _TextEnviron()

    # Invoke method
    result = text_environ_0.__getitem__("PACKAGE_VERSION")
    assert result == '50'



# Generated at 2022-06-25 13:40:01.991764
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    v = text_environ['PATH']
    assert v == os.environ['PATH']


# Generated at 2022-06-25 13:40:09.370668
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        text_environ_0 = _TextEnviron({u'abc': u'1'})
        text_environ_0_getitem_0 = text_environ_0[u'abc']
        if not type(text_environ_0_getitem_0) is str:
            raise AssertionError
    else:
        text_environ_0 = _TextEnviron({u'abc': u'1'})
        text_environ_0_getitem_0 = text_environ_0.__getitem__(u'abc')
        if not type(text_environ_0_getitem_0) is unicode:
            raise AssertionError


# Generated at 2022-06-25 13:40:14.649289
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Testing if __getitem__ works correctly when python major version is 3
    if sys.version_info >= (3,):
        assert (text_environ_0.__getitem__('PW_AGE') == '90')
        assert (text_environ_0.__getitem__('USER') == 'root')
    # Testing if __getitem__ works correctly when python major version is 2
    if sys.version_info < (3,):
        assert (text_environ_0.__getitem__('PW_AGE') == u'90')
        assert (text_environ_0.__getitem__('USER') == u'root')

# Generated at 2022-06-25 13:40:23.843367
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    enc = sys.getfilesystemencoding()
    os.environ['text'] = 'Test'
    os.environ['bytes'] = b'Test'
    os.environ['unicode'] = u'Test'
    os.environ['mixed_unicode'] = u'aöeünö'
    os.environ['mixed_bytes'] = u'aöeünö'.encode('utf-8')
    os.environ['mixed_ascii'] = u'\u0394\u03a0\u03b7\u03a3\u03b5\u03af\u03a3\u03bf\u03c2'

    text_environ = _TextEnviron()

    assert text_environ['text'] == 'Test'

# Generated at 2022-06-25 13:40:27.318034
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_arg_0 = text_environ_0['HOME']
    assert(str_arg_0 is not None)
    assert(isinstance(str_arg_0, str))


# Generated at 2022-06-25 13:40:39.374156
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()

# Generated at 2022-06-25 13:40:46.529711
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.pycompat24 import get_python_lib, is_py2

    if is_py2:
        return

    text_environ_0 = _TextEnviron()
    KEY = 'PATH'
    VALUE = text_environ_0._raw_environ[KEY]
    assert to_text(VALUE) == text_environ_0[KEY]
    assert to_text(VALUE) == text_environ_0._value_cache[VALUE]



# Generated at 2022-06-25 13:40:49.793143
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert(environ['TEST_VAR'] == 'TEST_VALUE')
    else:
        assert(environ['TEST_VAR'] == u'TEST_VALUE')

# Generated at 2022-06-25 13:40:52.427175
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['ANSIBLE_TEST_KEY'] = 'Ansible Test Value'
    assert environ['ANSIBLE_TEST_KEY'] == 'Ansible Test Value'



# Generated at 2022-06-25 13:40:55.649497
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1.__getitem__('DEMO_WORKDIR')
    text_environ_1.__getitem__('HOME')
    text_environ_1.__getitem__('LANG')
    text_environ_1.__getitem__('PWD')


# Generated at 2022-06-25 13:41:05.831715
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    This test is just here to make sure we're passing in unicode to the module so the unicode
    version of unittest can run this.
    """
    for vartype in [str, bytes, to_text('utf-8'), to_text('latin-1')]:
        new_environ = _TextEnviron()
        new_environ['text'] = vartype('unicode_value')
        assert new_environ['text'] == u'unicode_value'
        new_environ['text'] = vartype('ascii_value')
        assert new_environ['text'] == u'ascii_value'
        new_environ['bytes'] = vartype(b'bytes_value')
        assert new_environ['bytes'] == u'bytes_value'
        new_en

# Generated at 2022-06-25 13:41:10.685400
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Assert that 'PATH' is of the expected value.
    assert text_environ_0['PATH'] == os.environ['PATH']
    try:
        text_environ_0.__getitem__('PATH')
    except Exception as e:
        assert False

# Generated at 2022-06-25 13:41:13.619829
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    key = 'foo'
    value = 'bar'
    text_environ_1 = _TextEnviron()
    text_environ_1._raw_environ[key] = value
    assert text_environ_1[key] == value



# Generated at 2022-06-25 13:41:23.204764
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        key_0 = 'GEM_PATH'
        text_environ_0 = _TextEnviron({key_0: ':/path/to/gem'})
        text_environ_0.__getitem__(key_0)
        assert text_environ_0[key_0] == ':/path/to/gem'
        #
        key_1 = 'GEM_PATH'
        text_environ_1 = _TextEnviron(encoding='utf-8')
        text_environ_1.__getitem__(key_1)
        assert text_environ_1[key_1] == ':/path/to/gem'
        #

# Generated at 2022-06-25 13:41:26.514530
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron({'key0': 'value0'})
    print(text_environ_1['key0'])
    text_environ_2 = _TextEnviron({b'key0': b'value0'})
    print(text_environ_2['key0'])

# Generated at 2022-06-25 13:41:42.872267
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # 'LANG=en_US.UTF-8'
    default_lang = 'LANG=en_US.UTF-8'
    assert text_environ_0[default_lang] == 'en_US.UTF-8'


# Generated at 2022-06-25 13:41:45.630370
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = environ['HOME']
    str_1 = environ['HOME']
    assert str_0 is str_1


# Generated at 2022-06-25 13:41:48.848493
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1["PATH"] = "/usr/bin:/bin:/usr/sbin:/sbin"
    text_environ_1["LANG"] = "en_US.UTF-8"


# Generated at 2022-06-25 13:41:51.682842
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['PATH'] == os.environ['PATH']
    else:
        assert environ['PATH'] == os.environ['PATH'].decode('utf-8')


# Generated at 2022-06-25 13:41:54.478967
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ.pop('FOO') is None
    environ['FOO'] = 'bar'
    if PY3:
        assert environ['FOO'] == 'bar'
    else:
        assert environ['FOO'] == u'bar'


# Generated at 2022-06-25 13:41:57.647877
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Method __getitem__ of _TextEnviron
    """
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('HOME') == os.environ.get('HOME')


# Generated at 2022-06-25 13:41:59.861693
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron({'text_environ': 'case'})
    if to_text(text_environ['text_environ']) == 'case':
        return True


# Generated at 2022-06-25 13:42:07.433883
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Test the following cases for __getitem__:
    # 1. with a key that has a utf-8 encoded value
    # 2. with a key that has a binary value
    # 3. with a key that doesn't exist in os.environ
    # 4. with a key that has a surrogate_or_strict encoded value
    # 5. with a key that has a surrogate_then_replace encoded value
    # 6. with a key that has an ignore encoded value
    # 7. with a key that has a strict encoded value
    if PY3:
        assert os.environ['hello'] == text_environ_0['hello']
    else:
        os.environ['hello'] = 'world'
        assert os.environ['hello'] == text_environ_0

# Generated at 2022-06-25 13:42:14.378160
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Test case for text_environ_0
    text_environ_0_getitem_0 = to_text(os.environ.get('GIT_AUTHOR_NAME'), encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    text_environ_0.__getitem__('GIT_AUTHOR_NAME') == text_environ_0_getitem_0
    # Test case for text_environ_0
    text_environ_0_getitem_1 = to_text(os.environ.get('GIT_MERGE_AUTOEDIT'), encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    text_environ_0.__getitem

# Generated at 2022-06-25 13:42:20.589877
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with unset variable
    text_environ_1 = _TextEnviron()
    # Test with non-ascii variable
    text_environ_1['東京都'] = '東京1'
    # Test with set variable
    text_environ_1['住所'] = '東京'
    # Test with set variable
    text_environ_1['東京都'] = '東京2'
    # Test with set variable
    text_environ_1['池袋'] = '東京3'
    # Verify that the output is to_text
    assert isinstance(next(iter(text_environ_1.keys())), str)
    # Verify that the output is to_text

# Generated at 2022-06-25 13:43:01.149758
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test case with text as input
    text_environ_0 = _TextEnviron()
    text_environ_0.__setitem__('foo', 'bar')
    result = text_environ_0.__getitem__('foo')
    assert result == 'bar', 'foo: bar was not returned'

    # Test case with byte string as input
    text_environ_1 = _TextEnviron()
    text_environ_1.__setitem__('foo', b'bar')
    result = text_environ_1.__getitem__('foo')
    assert result == 'bar', 'foo: bar was not returned'

    # Test case with byte string as input
    text_environ_2 = _TextEnviron()
    text_environ_2.__setitem__('foo', 'bar')
    result

# Generated at 2022-06-25 13:43:04.607869
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['PATH']
    text_environ_0['HOME']
    # TODO: Test other environment variables.
    # TODO: Test environment variables which don't exist.
    # TODO: Test a UTF-8 environment variable.
    # TODO: Test a non-utf-8 environment variable in various encodings.



# Generated at 2022-06-25 13:43:08.236957
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Test __getitem__ of class _TextEnviron"""
    text_environ_0 = _TextEnviron(encoding='utf-8')
    text_environ_0.__getitem__("b'c'")
    text_environ_0.__getitem__(text_environ_0)
    # Case 1
    text_environ_0 = _TextEnviron(encoding='utf-8')
    text_environ_0.__getitem__("b'c'")
    text_environ_0.__getitem__(text_environ_0)


# Generated at 2022-06-25 13:43:10.671606
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    value = text_environ["PATH"]
    assert value == "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"


# Generated at 2022-06-25 13:43:14.401422
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set up test data
    text_environ = _TextEnviron()
    text_environ.__setitem__('A','B')

    # Execute task
    output = text_environ.__getitem__('A')

    # Verify results
    assert output == 'B'


# Generated at 2022-06-25 13:43:15.350827
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ["HOME"] == "/root"


# Generated at 2022-06-25 13:43:17.604678
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    key = 'dummy'
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__(key)



# Generated at 2022-06-25 13:43:19.032499
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    value = text_environ_0['PATH']

# Generated at 2022-06-25 13:43:22.271612
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('HOME') is not None
    assert len(text_environ_0.__getitem__('HOME')) > 0


# Generated at 2022-06-25 13:43:25.309447
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    ansible_runner_0 = text_environ_0.get(__file__)
    print(str(ansible_runner_0))
