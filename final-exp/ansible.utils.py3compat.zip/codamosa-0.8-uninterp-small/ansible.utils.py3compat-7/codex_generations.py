

# Generated at 2022-06-25 13:34:22.148372
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError):
        text_environ_0.__getitem__('nonexisting')


# Generated at 2022-06-25 13:34:29.079545
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Testing for a string in the environment
    text_environ_0[u'__TEST_KEY__'] = u'__TEST_VALUE__'
    str_0 = text_environ_0[u'__TEST_KEY__']
    # Verify that the str_0 is of type str
    assert isinstance(str_0, str)
    assert str_0 == u'__TEST_VALUE__'
    del text_environ_0[u'__TEST_KEY__']



# Generated at 2022-06-25 13:34:37.332813
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # py2 fails on a unicode env var
    # os.environ[u'a_unicode_env_var'] = b'a unicode string'.decode('utf-8')
    os.environ['a_unicode_env_var'] = 'a unicode string'

    # py2 fails on a unicode key
    # text_environ_0[u'a_unicode_env_var'] = 'a unicode string'
    text_environ_0['a_unicode_env_var'] = 'a unicode string'

    # py2 fails on an ascii env var
    #os.environ[u'a_ascii_env_var'] = b'a string'

# Generated at 2022-06-25 13:34:47.359098
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    from sys import getfilesystemencoding
    assert isinstance(text_environ_1, _TextEnviron)
    encoded = to_bytes("encoded", encoding=getfilesystemencoding(), nonstring='strict', errors='surrogate_or_strict')
    assert text_environ_1.__getitem__("encoded") == to_text(encoded, encoding=getfilesystemencoding(), nonstring='passthru', errors='surrogate_or_strict')


# Generated at 2022-06-25 13:34:55.486291
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import sys
    from ansible.module_utils.six import PY3

    text_environ_0 = _TextEnviron(encoding='utf-8')
    # Test if the returned value is of type text
    assert isinstance(text_environ_0['NOEXISTENTKEY'], str)
    assert isinstance(text_environ_0['NOEXISTENTKEY'], str)
    # Test if the returned value is correct
    assert text_environ_0['NOEXISTENTKEY'] == os.environ['NOEXISTENTKEY']
    assert text_environ_0['NOEXISTENTKEY'] == os.environ['NOEXISTENTKEY']


# Generated at 2022-06-25 13:34:58.663908
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        text_environ_0 = _TextEnviron()
        str_1 = text_environ_0['HOME']
    except KeyError:
        pass
    try:
        str_1 = text_environ_0['USER']
    except KeyError:
        pass


# Generated at 2022-06-25 13:35:00.267526
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0.__getitem__("HOME")


# Generated at 2022-06-25 13:35:05.999093
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    if PY3:
        assert text_environ_0.__getitem__('PATH') == os.environ.get('PATH')
    else:
        assert text_environ_0.__getitem__('PATH') == to_text(
            os.environ.get('PATH'), encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict')


# Generated at 2022-06-25 13:35:08.371681
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    value_0 = text_environ_0.__getitem__('user')


# Generated at 2022-06-25 13:35:09.092037
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()

# Generated at 2022-06-25 13:35:18.060268
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class Mock_TextEnviron:
        def __init__(self,  *args, **kwargs):
            self._raw_environ = {
                u'LANG': b'en_US.UTF-8',
                u'LC_ALL': b'en_US.UTF-8',
            }
            self._value_cache = {}
            self.encoding = 'utf-8'
    mock_obj = Mock_TextEnviron()
    assert mock_obj._raw_environ[u'LANG'] == b'en_US.UTF-8'
    # missing "assert VerifyResult" line after this


# Generated at 2022-06-25 13:35:22.496948
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Variable "text_environ_0" initializer
    text_environ_0 = _TextEnviron()

    # Assertion: "text_environ_0" should not be empty
    assert len(text_environ_0) > 0

    # Test: __getitem__ should not throw exception
    for key in text_environ_0:
        try:
            text_environ_0.__getitem__(key)
        except Exception:
            raise


# Generated at 2022-06-25 13:35:24.411841
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0.__getitem__('HOME')


# Generated at 2022-06-25 13:35:30.785843
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Input parameters
    #   _TextEnviron instance to call method on
    #   key: key to get value for
    # Return value
    #   Return value of method

    print("\n\nCalled test__TextEnviron___getitem__")
    print("Input parameters:")
    print("\t  _TextEnviron instance to call method on")
    print("\t  key: key to get value for")
    print("Return value:")
    print("\t  Return value of method\n")

    # Set up test data
    text_environ_0 = _TextEnviron()
    key = None

    print("\n---------------------------------")
    print("Test Case 0: key = None")
    print("Expected result:")
    print("\t  KeyError exception raised")

# Generated at 2022-06-25 13:35:37.481543
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Tests for the case that key exists in os.environ
    text_environ_0 = _TextEnviron()
    # TODO: Implement this test
    #print(text_environ_0.__getitem__(key=None))
    text_environ_0.__setitem__(key='', value='value')
    # Tests for the case that key does not exist in os.environ
    # TODO: Implement this test
    #print(text_environ_0.__getitem__(key=None))


# Generated at 2022-06-25 13:35:46.344898
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_arg_0 = text_environ_0.__getitem__('XDG_VTNR')
    text_environ_0.__getitem__('SHELL')
    text_environ_0.__getitem__('GROUP')
    text_environ_0.__getitem__('TERM')
    str_arg_4 = text_environ_0.__getitem__('VIRTUAL_ENV')
    text_environ_0.__getitem__('SELINUX_LEVEL_REQUESTED')
    text_environ_0.__getitem__('LIBGL_ALWAYS_INDIRECT')
    text_environ_0.__getitem__('HOME')

# Generated at 2022-06-25 13:35:50.918715
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    key_0 = 'LOGNAME'
    value_0 = text_environ_0.__getitem__(key_0)
    print(value_0)
    text_environ_1 = _TextEnviron()
    key_1 = 'TMP'
    value_1 = text_environ_1.__getitem__(key_1)
    print(value_1)
    key_2 = 'CVS_RSH'
    value_2 = text_environ_1.__getitem__(key_2)
    print(value_2)
    key_3 = 'USER'
    value_3 = text_environ_0.__getitem__(key_3)
    print(value_3)

# Generated at 2022-06-25 13:35:53.805987
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Basic test of getitem functionality
    environ['abc'] = '123'
    assert '123' == environ['abc']

    # Test unicode when on py2
    if not PY3:
        # Originally from http://stackoverflow.com/a/2962165
        test_unicode = u'\u00C0nimal'
        environ['abc'] = test_unicode
        assert test_unicode == environ['abc']
        del environ['abc']



# Generated at 2022-06-25 13:35:56.592411
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
  environ_0 = _TextEnviron()
  num_0 = 0
  for i in environ_0.__getitem__('USERNAME'):
    num_0 += 1
  assert (num_0 == len(os.environ.__getitem__('USERNAME')))


# Generated at 2022-06-25 13:36:00.199425
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test when key not in os.environ
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__('abc')
    text_environ_0.__getitem__('abc')


# Generated at 2022-06-25 13:36:15.680263
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Declare objects and variables
    text_environ_0 = _TextEnviron()
    text_environ_0.__setitem__('1', '1')
    text_environ_0.__setitem__('2', '2')
    text_environ_0.__setitem__('3', '3')
    text_environ_0.__setitem__('4', '4')
    text_environ_0.__setitem__('5', '5')

    if PY3:
        assert text_environ_0.__getitem__('1') == '1'
        assert text_environ_0.__getitem__('2') == '2'
        assert text_environ_0.__getitem__('3') == '3'
        assert text_environ_0.__getitem

# Generated at 2022-06-25 13:36:17.900868
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__("VARIABLE")


# Generated at 2022-06-25 13:36:22.748950
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Python3 behaviour
    if PY3:
        text_environ_0 = _TextEnviron()
        assert text_environ_0['PATH'] == os.environ['PATH']

    # Python2 behaviour
    else:
        text_environ_0 = _TextEnviron(env={'ANSIBLE': 'Value'})
        assert text_environ_0['ANSIBLE'] == 'Value'


# Generated at 2022-06-25 13:36:24.609465
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0.__getitem__('HOME')


# Generated at 2022-06-25 13:36:26.760490
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_1 = environ
    # No exception is expected
    text_environ_1["LANG"]
    # No exception is expected
    text_environ_0["LANG"]


# Generated at 2022-06-25 13:36:29.134800
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('ANSIBLE_TEST_VAR') == 'changeme'


# Generated at 2022-06-25 13:36:30.996636
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    item = 'HOME'
    # Assert condition
    assert item in text_environ


# Generated at 2022-06-25 13:36:36.418745
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Description:
        Unit test for method __getitem__ of class _TextEnviron

    Parameters:
        None

    Returns:
        None

    Raises:
        None
    """
    # Arrange
    test_class = _TextEnviron()

    # Act
    set_value = 'C:\\Users\\admin'
    test_class['aa'] = set_value
    get_value = test_class['aa']

    # Assert
    assert set_value == get_value


# Generated at 2022-06-25 13:36:41.444393
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Testing to check the code with no errors
    try:
        text_environ_0 = _TextEnviron()
        assert text_environ_0.__getitem__('') == ''
    except AssertionError:
        raise AssertionError('Unexpected assertion error occurred')
    except Exception:
        raise AssertionError('Unexpected error occurred')


# Generated at 2022-06-25 13:36:42.517335
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()

# Generated at 2022-06-25 13:36:48.875340
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test os.environ[key]
    value = environ['__FOO__']
    assert isinstance(value, basestring)


# Generated at 2022-06-25 13:36:53.568791
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['A'] = to_bytes('B', 'utf-8', 'strict', 'surrogate_or_strict')
    text_environ_0['A']
    assert to_text(text_environ_0['A'], 'utf-8', 'passthru', 'surrogate_or_strict') == 'B'


# Generated at 2022-06-25 13:36:54.592548
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()

# Generated at 2022-06-25 13:37:01.031435
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for when encoding is None
    text_environ_0 = _TextEnviron()
    # Test for when encoding is not None and value has no special characters
    text_environ_1 = _TextEnviron(encoding=u'cp1272')
    # Test for when encoding is not None and value is not ASCII
    text_environ_2 = _TextEnviron(encoding=u'cp1252')


# Generated at 2022-06-25 13:37:04.235455
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(text_environ_0['PYTHONPATH'], str)
    assert len(text_environ_0) == os.environ.__len__()



# Generated at 2022-06-25 13:37:08.128244
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env_var_key = 'BLAH_BLAH'
    env_var_value = 'blah_blah'
    text_environ = _TextEnviron()
    assert text_environ[env_var_key] == env_var_value



# Generated at 2022-06-25 13:37:10.461590
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert _TextEnviron.__getitem__({to_bytes('a'): to_bytes('b')}, to_bytes('a')) == to_text('b')


# Generated at 2022-06-25 13:37:16.132133
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # _TextEnviron captures the text representation when byte environ is accessed

    # Force encoding to ascii to make sure the test isn't generating a false pass
    text_environ = _TextEnviron(encoding='ascii')
    # Update the os.environ variable with a non-ascii value.
    os.environ.update({'TEST_KEY_WITH_NON_ASCII_VALUE': b'\xc3\xa9'})
    # This should trigger decoding the byte string
    text_environ.__getitem__('TEST_KEY_WITH_NON_ASCII_VALUE')
    # Check the decoded value is cached
    assert text_environ._value_cache[b'\xc3\xa9'] == u'\xe9'
    # Return the os.environ to its original state

# Generated at 2022-06-25 13:37:19.252332
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test 0 (Case 0)
    if os.environ['ANSIBLE_TEST_DEST'] is not None:
        test_case_0()

# Generated at 2022-06-25 13:37:27.779905
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    #
    # TESTCASE 0
    test_case_0()
    #
    # TESTCASE 1
    test_case_1()
    #
    # TESTCASE 2
    test_case_2()
    #
    # TESTCASE 3
    test_case_3()
    #
    # TESTCASE 4
    test_case_4()
    #
    # TESTCASE 5
    test_case_5()
    #
    # TESTCASE 6
    test_case_6()
    #
    # TESTCASE 7
    test_case_7()
    #
    # TESTCASE 8
    test_case_8()
    #
    # TESTCASE 9
    test_case_9()
    #
    # TESTCASE

# Generated at 2022-06-25 13:37:35.590938
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Test case for _TextEnviron.__getitem__

    Unit test for method __getitem__ of class _TextEnviron
    """
    # Test var initialization
    key = 'SHELL'

    # Execute the tested call
    result = text_environ_0.__getitem__(key)

    # Check return value
    assert type(result) == str



# Generated at 2022-06-25 13:37:45.252464
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    new_env = {to_bytes('a'): to_bytes('b'), to_bytes('c'): to_bytes('d')}
    text_environ_1 = _TextEnviron(env=new_env)
    assert text_environ_1[to_bytes('a')] == to_text('b', encoding=text_environ_1.encoding,
                                                    nonstring='passthru', errors='surrogate_or_strict'), 'Failed to get proper value for key a of new_env'
    assert text_environ_1[to_bytes('c')] == to_text('d', encoding=text_environ_1.encoding,
                                                    nonstring='passthru', errors='surrogate_or_strict'), 'Failed to get proper value for key c of new_env'

# Generated at 2022-06-25 13:37:51.250549
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Tests that the internal cache is used to limit the number of conversions of a variable
    text_environ_0 = _TextEnviron({'foo': 'bar'})

    # The variable is converted and the key cached
    to_text_0 = text_environ_0.__getitem__('foo')
    assert to_text_0 == 'bar'

    # Cache is used instead of doing another conversion
    to_text_1 = text_environ_0.__getitem__('foo')
    assert to_text_1 == 'bar'


# Generated at 2022-06-25 13:37:55.411702
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Make sure that getting a string value returns text
    if not PY3:
        if not isinstance(text_environ_0['HOME'], str):
            return 1
        if not isinstance(text_environ_0['PYTHONPATH'], str):
            return 1


# Generated at 2022-06-25 13:37:59.331176
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Note: This test will fail if PY3 is False and sys.getfilesystemencoding() is not 'utf-8'
    test_bytes = to_bytes(u"Test string", encoding='utf-8', nonstring='strict',
                          errors='surrogate_or_strict')
    os.environ['ANSIBLE_TEST_KEY'] = test_bytes
    assert text_environ_0.__getitem__('ANSIBLE_TEST_KEY') == u"Test string"


# Generated at 2022-06-25 13:38:05.916683
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test normal operation of _TextEnviron.__getitem__
    """
    # Test __getitem__ returns byte strings on Python2 and text strings on Python3
    if PY3:
        assert isinstance(environ['PWD'], str)
    else:
        assert isinstance(environ['PWD'], bytes)
    # Test that we return our special TextEnviron object on subsequent calls
    assert environ == environ.__getitem__('PWD')


# Generated at 2022-06-25 13:38:09.315122
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Unit test for raising KeyError
    def test_case_1():
        try:
            text_environ_0['xxx']
        except KeyError:
            pass
        else:
            assert False, "KeyError not raised"

    test_case_1()
    return

# Generated at 2022-06-25 13:38:10.435568
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()

    assert text_environ_1["HOME"] == environ["HOME"]


# Generated at 2022-06-25 13:38:11.869092
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """test for method __getitem__ of class _TextEnviron"""
    test_case_0()

# Generated at 2022-06-25 13:38:17.663085
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    text_environ_1 = _TextEnviron()

    # Impossible since we don't set values in the environment in the tests
    #assert text_environ_1.__getitem__('badkey') == 'badvalue'
    #assert text_environ_1.__getitem__('') == 'badvalue'
    assert text_environ_1.__getitem__('PATH') == u'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    assert text_environ_1.__getitem__('PWD') == u'/home/toshio/fedora/ansible/test/units/module_utils/text'


# Generated at 2022-06-25 13:38:23.465944
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == os.environ['PATH']


# Generated at 2022-06-25 13:38:30.798692
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test 0
    print('Test 0')
    text_environ_0 = _TextEnviron()
    assert(text_environ_0.__getitem__('TEXT_ENVIRON_0') == 'TextEnviron0')
    # Test 1
    print('Test 1')
    text_environ_0 = _TextEnviron()
    assert(text_environ_0.__getitem__('TEXT_ENVIRON_1') == 'TextEnviron1')
    # Test 2
    print('Test 2')
    text_environ_0 = _TextEnviron()
    assert(text_environ_0.__getitem__('TEXT_ENVIRON_2') == 'TextEnviron2')

# Generated at 2022-06-25 13:38:38.014287
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test case 0
    #
    # Create a _TextEnviron object.  Need to override os.environ because os.environ has a
    # cache that is thrown away during unit testing
    text_environ_0 = _TextEnviron(env={b'PATH': b'/bin:/usr/bin:/usr/local/bin', b'LANG': b'en_US.UTF-8'})
    #
    # Invoke method from the object with the argument LANG
    result = text_environ_0.__getitem__('LANG')
    #
    # Assert the result is the expected value
    assert result == 'en_US.UTF-8'


# Generated at 2022-06-25 13:38:41.096753
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global text_environ_0

    with pytest.raises(KeyError):
        text_environ_0['__item_0']
    with pytest.raises(KeyError):
        text_environ_0['__item_1']



# Generated at 2022-06-25 13:38:52.075450
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    # AssertionError: 'Unable to decode value: bytearray(b'This is a byte string.') Could not decode
    # byte value 0x74. Try specifying a non-default encoding.' == 'This is a byte string.'
    # assert to_text(text_environ_0[b'\x0c\x8a\xcd\xdd\x0ft\xd7\x00\x1a\xe0\x84\xe2\x90\x83\xd3\x00\x07\x00\x07\x00\xdd\x00\x01\x00\x01\x00\x01\x00\x01\x00\x01\x00\x01\x00\x01\x00\x01

# Generated at 2022-06-25 13:38:56.153197
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = 'PATH'
    res_0 = text_environ_0[var_0]
    var_1 = 'PWD'
    res_1 = text_environ_0[var_1]
    var_2 = 'PWD'
    res_2 = text_environ_0[var_2]


# Generated at 2022-06-25 13:39:04.883446
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    x = lambda: None
    x.__class__ = _TextEnviron
    if PY3:
        x.__dict__['_raw_environ'] = {'_':'_'}
    else:
        x.__dict__['_raw_environ'] = {b'_':b'_'}
        x.__dict__['_value_cache'] = {}
        x.__dict__['encoding'] = 'utf-8'
    # Call method __getitem__

# Generated at 2022-06-25 13:39:07.168608
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with raises(KeyError):
        os.environ['0']


# Generated at 2022-06-25 13:39:15.926843
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_arg_0 = '_LANG'
    str_arg_1 = 'LANGUAGE'
    str_arg_2 = 'LANG'
    str_arg_3 = 'LANG_ALL'
    str_arg_4 = 'LANGUAGE'
    str_arg_5 = '_LANG'
    str_arg_6 = 'LC_CTYPE'
    str_arg_7 = 'LC_ALL'
    str_arg_8 = 'LCL_ALL'
    str_arg_9 = '_LCL_ALL'
    str_arg_10 = 'LCL_ALL'
    str_arg_11 = 'LANG_ALL'
    str_arg_12 = 'LANGUAGE'
    str_arg_13

# Generated at 2022-06-25 13:39:19.663975
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert text_environ_1["PATH"] == os.environ["PATH"]
    assert text_environ_1["PATH"] == os.environ["PATH"]
    assert text_environ_1["PATH"] == os.environ["PATH"]
    assert text_environ_1["PATH"] == os.environ["PATH"]
    assert text_environ_1["PATH"] == os.environ["PATH"]


# Generated at 2022-06-25 13:39:25.973640
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global text_environ_0
    assert text_environ_0.__getitem__('SHLVL') == '1'


# Generated at 2022-06-25 13:39:35.567205
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Construct a _TextEnviron object
    text_environ = _TextEnviron()

    # Try to access an environment variable which isn't set
    try:
        text_environ["ANSIBLE_UTIL_TEST_ENVIROINMENT_VARIABLE_NAME_0"]
        raise AssertionError("Expected KeyError from accessing an unset environment variable")
    except KeyError:
        pass

    # Try to access an environment variable which is set to a string
    os.environ["ANSIBLE_UTIL_TEST_ENVIROINMENT_VARIABLE_NAME_0"] = "This is a test"
    assert text_environ["ANSIBLE_UTIL_TEST_ENVIROINMENT_VARIABLE_NAME_0"] == "This is a test"

    # Try to access an environment variable

# Generated at 2022-06-25 13:39:41.500903
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for python2.7
    if sys.version_info[0] < 3:
        os.environ['_TextEnviron_test_setitem_0_key'] = '\xC3\x9F'
    else:
        # No op for python3
        os.environ['_TextEnviron_test_setitem_0_key'] = '\xc3\x9f'
    assert environ['_TextEnviron_test_setitem_0_key'] == 'ß'
    os.environ.pop('_TextEnviron_test_setitem_0_key')



# Generated at 2022-06-25 13:39:48.947925
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # When we use the _TextEnviron to get an item, we expect that the value is returned as a text
    # object in all cases.
    if sys.version_info[0:2] == (2, 6):
        # Python2.6's os module has a b prefix on the environment keys and so we need to skip this
        # test on this version.
        return

    raw_environ = os.environ
    # On Python3, the returned value is already a unicode object and so we can just return here.
    if PY3:
        assert raw_environ.__getitem__('PATH') is raw_environ['PATH']
        return

    # Check that text and bytestrings agree

# Generated at 2022-06-25 13:39:56.254432
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:40:00.314565
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    # Simple test that method __getitem__ exists
    try:
        text_environ.__getitem__
    except AttributeError:
        raise AssertionError('Class _TextEnviron has no attribute __getitem__')


# Generated at 2022-06-25 13:40:03.746979
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
   text_environ_0 = _TextEnviron()
   _in_0 = 'PWD'
   _expected_0 = '.'
   _out_0 = text_environ_0.__getitem__(_in_0)
   assert _out_0 == _expected_0

# Generated at 2022-06-25 13:40:07.766924
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    test_key = 'UNITTEST'
    test_value = 817
    text_environ = _TextEnviron()
    os.environ[test_key] = test_value

    # Test
    data = text_environ[test_key]

    # Verify
    assert data == test_value 


# Generated at 2022-06-25 13:40:13.900122
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = '배치'
    str_1 = '막우기'
    str_2 = '모드'
    str_3 = '자유'
    str_4 = '상태'

    text_environ_0[str_0] = str_1


    if PY3:
        text_environ_0[str_2] = str_3
    else:
        text_environ_0[str_2] = str_4

    assert text_environ_0[str_0] == '배치'


# Generated at 2022-06-25 13:40:18.664395
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_ = _TextEnviron()
    text_environ_1 = text_environ_.__getitem__('SHELL')
    assert isinstance(text_environ_1, text)
    value_ = 'SHELL'
    text_environ_2 = text_environ_[value_]
    assert isinstance(text_environ_2, text)


# Generated at 2022-06-25 13:40:29.804673
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    temp_var_2 = text_environ_0.__getitem__('HOME')
    pass


# Generated at 2022-06-25 13:40:37.589961
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test case for unicode chars in env variable name
    # os.environ.get(u'\u0430\u0440\u0433') is always None.
    # on ubuntu, it won't save the value if assign it to environ var
    item_key = u'\u0430\u0440\u0434'
    item_value = u'\u0430\u0440\u0435'
    os.environ[item_key] = item_value
    assert os.environ[item_key] == item_value
    text_environ = _TextEnviron()
    assert text_environ[item_key] == item_value
    # On python3, the returned value is already unicode
    if PY3:
        assert type(text_environ[item_key]) == type

# Generated at 2022-06-25 13:40:40.038091
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert 'Hello there' == text_environ_0['Hello'] + ' ' + text_environ_0['there']


# Generated at 2022-06-25 13:40:44.673144
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__('PATH')
    text_environ_0.__getitem__('HOME')
    text_environ_0.__getitem__('SHELL')
    text_environ_0.__getitem__('DISPLAY')
    text_environ_0.__getitem__('PROMPT')


# Generated at 2022-06-25 13:40:50.659743
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a test environment
    test_environ = {b'PATH': b'/usr/bin:/bin'}
    # Create a _TextEnviron class using this environment
    text_environ = _TextEnviron(env=test_environ)
    # Assert that the class contains the key PATH
    assert b'PATH' in text_environ
    # Assert that the class has the same value for PATH as the initial environment
    assert text_environ[b'PATH'] == test_environ[b'PATH']


# Generated at 2022-06-25 13:40:53.776023
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    key = 'foo'
    value = 'bar'
    os.environ[key] = value
    actual = text_environ_1.__getitem__(key)
    assert actual == value


# Generated at 2022-06-25 13:40:55.413585
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1.__getitem__()
    pytest.fail()


# Generated at 2022-06-25 13:40:59.691993
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_arg_0 = ''
    try:
        val = text_environ_0[str_arg_0]
        assert False
    except KeyError:
        pass
    except Exception:
        assert False


# Generated at 2022-06-25 13:41:02.540984
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    #test TextEnviron.__getitem__ returns ascii text on Python2
    assert to_bytes(environ['TERM'], encoding='utf-8') == b'xterm-256color'


# Generated at 2022-06-25 13:41:12.457843
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test with a string
    os.environ['ANSIBLE_UNIT_TEST_KEY_TEXT'] = 'String'
    text_environ_1 = _TextEnviron()
    result_1 = text_environ_1['ANSIBLE_UNIT_TEST_KEY_TEXT']
    assert result_1 == 'String'

    # Test with ASCII bytes
    try:
        os.environ['ANSIBLE_UNIT_TEST_KEY_TEXT'] = '\xc3\xa9'.encode('utf-8')
    except Exception as e:
        os.environ['ANSIBLE_UNIT_TEST_KEY_TEXT'] = b'\xc3\xa9'
    text_environ_2 = _TextEnviron()

# Generated at 2022-06-25 13:41:34.684112
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    key_1 = "PATH"
    value_1 = text_environ_1.__getitem__(key_1)
    assert value_1 is not None
    assert isinstance(value_1, str)
    assert len(value_1) >= 1


# Generated at 2022-06-25 13:41:39.569957
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    test_dict = {
        1: to_bytes('a', encoding='utf-8'),
        2: to_bytes('b', encoding='utf-8'),
        3: to_bytes('c', encoding='utf-8'),
    }
    text_environ = _TextEnviron(env=test_dict, encoding='utf-8')
    assert type(text_environ[1]) == text
    assert type(text_environ[2]) == text
    assert type(text_environ[3]) == text


# Generated at 2022-06-25 13:41:41.871501
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__(())


# Generated at 2022-06-25 13:41:50.711162
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(encoding='utf-8')
    str_0 = os.environ.__getitem__('USER')
    str_1 = text_environ_0.__getitem__('USER')
    str_2 = text_environ_0.__getitem__(os.environ.__getitem__('USER'))
    str_3 = text_environ_0.__getitem__(str_2)
    str_4 = text_environ_0.__getitem__(str_3)
    str_5 = text_environ_0.__getitem__(text_environ_0.__getitem__('USER'))
    str_6 = os.environ.__getitem__(text_environ_0.__getitem__('USER'))
   

# Generated at 2022-06-25 13:41:53.333503
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['PATH'] == os.environ['PATH']
    else:
        assert environ['PATH'] == os.environ['PATH'].decode('utf-8')



# Generated at 2022-06-25 13:41:55.279081
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    _TextEnviron_0 = text_environ_0[to_bytes('string')]


# Generated at 2022-06-25 13:41:58.128837
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_1 = _TextEnviron()
    a = text_environ_0.__getitem__(text_environ_1)


# Generated at 2022-06-25 13:41:58.900015
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()

# Generated at 2022-06-25 13:42:01.672788
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global cmp_text_environ_0_key_0__getitem__
    text_environ_0 = _TextEnviron()
    cmp_text_environ_0_key_0__getitem__ = text_environ_0.__getitem__('shell')


# Generated at 2022-06-25 13:42:04.022788
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('LANG') == u'en_US.UTF-8'


# Generated at 2022-06-25 13:42:50.930073
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    for key in environ:
        assert key.__class__ == unicode
    assert len(environ) == len(os.environ)



# Generated at 2022-06-25 13:42:54.052428
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Default values test
    text_environ_0 = _TextEnviron()
    arg0 = 'TEST_0'
    try:
        value_0 = text_environ_0[arg0]
    except RuntimeError as arg1:
        value_0 = arg1
    # AssertionError: 'TEST_0'

    assert value_0 == 'TEST_0'


# Generated at 2022-06-25 13:42:57.958928
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        # Python 3 should have all strings in the environment
        text_environ_0 = _TextEnviron()
        for key in text_environ_0:
            assert isinstance(text_environ_0[key], str)
    else:
        # Python 2 should convert bytes to text strings
        text_environ_1 = _TextEnviron()
        encoding = sys.getfilesystemencoding()
        for key in text_environ_1:
            assert isinstance(text_environ_1[key], str)
            assert isinstance(text_environ_1[key], str)



# Generated at 2022-06-25 13:43:00.201903
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        text_environ = _TextEnviron(encoding='utf-8')
        assert isinstance(text_environ['PYTHONPATH'], str)
    except KeyError:
        pass

# Generated at 2022-06-25 13:43:06.447056
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # In python3, os.environ already returns unicode strings, so we don't have to test cases
    # that are already handled by Python.
    # os.environ returns a dict-proxy on Python2 but dict-proxy types can't be copied so we have to
    # convert it to a dict.  This may make the tests less accurate because we're not testing the
    # dict-proxy object itself, but we can't do anything about that without changing the
    # input/output types for this module.
    text_environ_0 = _TextEnviron(env=dict(os.environ))  # __init__

    # Test case 0
    expected_0 = to_bytes('/usr/bin:/bin')
    actual_0 = text_environ_0['PATH']
    assert expected_0 == actual_0

    # Test case 1


# Generated at 2022-06-25 13:43:10.248770
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for presence of value for known key in text environment dictionary
    # It is important to know if a value has changed and a key has not.
    environ = _TextEnviron()
    assert environ['PATH'] == "/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin", "The value for `PATH` should not have changed"


# Generated at 2022-06-25 13:43:12.074307
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('USER') == 'atif'


# Generated at 2022-06-25 13:43:15.038059
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    key = 'HOME'
    value = '/home/ansible'

    os.environ[key] = value
    assert environ[key] == value

    os.environ[key] = b'/home/ansible'
    assert environ[key] == '/home/ansible'

    del os.environ[key]


# Generated at 2022-06-25 13:43:24.486622
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(NotImplementedError):
        text_environ_0.__getitem__('l')
    text_environ_1 = _TextEnviron()
    with pytest.raises(KeyError):
        text_environ_1.__getitem__('\x0f')
    text_environ_2 = _TextEnviron()
    with pytest.raises(KeyError):
        text_environ_2.__getitem__('idt')
    text_environ_3 = _TextEnviron()
    with pytest.raises(KeyError):
        text_environ_3.__getitem__('d\xdf\xf4\xa6')


# Generated at 2022-06-25 13:43:28.725008
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        text_environ_0.__getitem__('HOME')
    except KeyError:
        print('KeyError raised')
    print(text_environ_0.__getitem__('HOME'))
    print('PASSED at line {}'.format(sys._getframe().f_lineno))
