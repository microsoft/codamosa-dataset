

# Generated at 2022-06-25 13:34:13.255165
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert not text_environ_0.__getitem__('B')


# Generated at 2022-06-25 13:34:15.665019
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__(to_text('HOSTNAME'))



# Generated at 2022-06-25 13:34:19.309241
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    tmp1 = _TextEnviron()
    try:
        tmp2 = tmp1.__getitem__('i')
    except KeyError:
        pass
    tmp2 = tmp1.__getitem__('TMP')
    assert isinstance(tmp2, str)



# Generated at 2022-06-25 13:34:22.703517
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    pytest_0 = text_environ_0.__getitem__('1x4')
    print(pytest_0)


# Generated at 2022-06-25 13:34:27.066170
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['ANSIBLE_NET_SSH_KEYFILE'] = "~/.ssh/id_rsa"
    text_environ_0['ANSIBLE_NET_SSH_KEYFILE'] = "~/.ssh/id_rsa"


# Generated at 2022-06-25 13:34:30.582778
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_3 = _TextEnviron()
    text_environ_3.__setitem__('test_key', 'test_value')
    assert text_environ_3.__getitem__('test_key') == 'test_value'



# Generated at 2022-06-25 13:34:34.634911
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = str(text_environ_0.__getitem__('PYTEST_CURRENT_TEST'))
    text_environ_0.__setitem__('TEST_VAR', 'tést')
    var_1 = text_environ_0.__getitem__('TEST_VAR')


# Generated at 2022-06-25 13:34:46.171059
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__('USER')
    var_0 = text_environ_0.__getitem__('XDG_VTNR')
    var_0 = text_environ_0.__getitem__('XDG_SESSION_ID')
    var_0 = text_environ_0.__getitem__('USERNAME')
    var_0 = text_environ_0.__getitem__('TERM')
    var_0 = text_environ_0.__getitem__('SHELL')
    var_0 = text_environ_0.__getitem__('SHLVL')
    var_0 = text_environ_0.__getitem__('HOME')
    var_0 = text_en

# Generated at 2022-06-25 13:34:56.076779
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # PY3 check
    if PY3:
        pass
    # PY2 check
    if not PY3:
        # UnicodeEncodeError check
        with pytest.raises(Exception) as excinfo:
            text_environ_0 = _TextEnviron()
            str_0 = text_environ_0.__getitem__(u'Unit test string')
        assert excinfo.value.__class__.__name__ == 'UnicodeEncodeError'
        # Non-string check
        with pytest.raises(Exception) as excinfo:
            text_environ_0 = _TextEnviron()
            str_0 = text_environ_0.__getitem__(None)
        assert excinfo.value.__class__.__name__ == 'TypeError'


# Generated at 2022-06-25 13:35:03.771879
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__
    var_1 = text_environ_0.__getitem__("SHELL")
    var_2 = text_environ_0.__getitem__("LANG")
    var_3 = text_environ_0.__getitem__("PWD")
    var_4 = text_environ_0.__getitem__("XDG_SESSION_ID")
    var_5 = text_environ_0.__getitem__("SELINUX_INIT")
    var_6 = text_environ_0.__getitem__("SESSION")
    var_7 = text_environ_0.__getitem__("TERM")
    var_8 = text_environ_

# Generated at 2022-06-25 13:35:14.270417
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from os import environ

    # Test against utf-8 encoded variable
    os.environ['ANSIBLE_TEST_UTF8'] = '\u2603'
    assert environ['ANSIBLE_TEST_UTF8'] == u'\u2603'

    # Test against shift-jis encoded variable
    os.environ['ANSIBLE_TEST_SHIFTJIS'] = '\u2603\u2603'.encode('shift-jis')
    assert environ['ANSIBLE_TEST_SHIFTJIS'] == u'\u2603\u2603'

    # Test against unchanged bytes
    environ['ANSIBLE_TEST_BYTES'] = b'bytes'
    assert environ['ANSIBLE_TEST_BYTES'] == u'bytes'

    # Test against bad bytes

# Generated at 2022-06-25 13:35:19.238868
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Unit test for method __getitem__ of class _TextEnviron"""
    #assert that __getitem__ retrieves the value corresponding to the given key
    dict_test = {'C1': to_bytes('d', encoding='utf-8'), 'C2': to_bytes('e', encoding='utf-8')}
    te = _TextEnviron(env=dict_test)
    assert te['C1'] == to_text('d')
    assert te['C2'] == to_text('e')


# Generated at 2022-06-25 13:35:26.498531
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # First a basic test.  We expect this to return the same value that we get by calling os.environ
    # directly.
    assert environ['LANG'] == os.environ['LANG']
    if not PY3:
        # Now test that we get the same value out of the cache when we call it again
        assert environ['LANG'] == environ['LANG']

    # Test that we can retrieve keys even when the environment is modified
    os.environ['LANG'] = 'en_US.UTF-8'
    assert environ['LANG'] == 'en_US.UTF-8'

    # Test that we get the cached values if we change the environment variable
    os.environ['LANG'] = 'en_US.UTF-8'

# Generated at 2022-06-25 13:35:29.034519
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Arrange
    text_environ_1 = _TextEnviron()
    key = 'PATH'

    # Act
    actual = text_environ_1[key]

    # Assert
    assert isinstance(actual, str)


# Generated at 2022-06-25 13:35:30.520335
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    textenviron_0 = _TextEnviron()
    str_0 = environ['HOME']


# Generated at 2022-06-25 13:35:38.163497
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # try something simple: a unicode string
    assert(u'A' == environ[u'A'])  # equal
    assert(u'A' != environ[u'A'])  # not equal
    # try something a little more fun:  Non-ascii unicode characters
    assert(u'中' == environ[u'中'])  # equal
    assert(u'中' != environ[u'中'])  # not equal
    assert(u'中' == environ[u'中'])  # equal
    assert(u'中' != environ[u'中'])  # not equal



# Generated at 2022-06-25 13:35:47.173355
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import sys
    import os
    import unittest
    import mock
    import six

    class Test__TextEnviron___getitem__(unittest.TestCase):

        if six.PY2:

            @mock.patch('os.environ', {b'/': b'/'})
            def test_1(self):
                text_environ_0 = _TextEnviron()
                assert text_environ_0[b'/'] == u'/'

            @mock.patch('os.environ', {'\u01d0\u01c8': '\u01d0\u01c8'})
            def test_2(self):
                text_environ_1 = _TextEnviron()

# Generated at 2022-06-25 13:35:53.096387
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_1 = _TextEnviron()
    str_0 = str(text_environ_1.__getitem__("PATH"))
    str_1 = str(text_environ_0.__getitem__("PATH"))
    text_environ_1.__setitem__("PATH", ";")
    str_2 = str(text_environ_1.__getitem__("PATH"))
    assert str_0 == str_1
    assert str_2 == ";"


# Generated at 2022-06-25 13:35:54.941433
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for non-unicode string as input
    text_environ_1 = _TextEnviron()
    text_environ_1["sample_key"] = b"sample_val"
    assert text_environ_1["sample_key"] == "sample_val"


# Generated at 2022-06-25 13:35:56.961701
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__(): 
    assert list(environ.keys()) == os.environ.keys()
    

# Generated at 2022-06-25 13:36:02.335082
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_10 = _TextEnviron()
    assert text_environ_10['HOME'] == os.environ['HOME']
    # Test that we can use the cache
    assert text_environ_10['HOME'] == os.environ['HOME']


# Generated at 2022-06-25 13:36:09.264254
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_1 = _TextEnviron()
    # Test that the default environment is the same as the one returned by os.environ
    assert text_environ_0 == os.environ

    # Test that it works if we create _TextEnviron passing in environment variables
    new_env = {}
    new_env['HELLO'] = 'hello'
    new_env['B_KEY'] = 'bye'
    text_environ_2 = _TextEnviron(env=new_env)
    assert text_environ_2['HELLO'] == 'hello'
    assert text_environ_2['B_KEY'] == 'bye'


# Generated at 2022-06-25 13:36:11.640497
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    val = text_environ_0[u'HOME']
    assert val == os.environ[u'HOME']

# Generated at 2022-06-25 13:36:21.194310
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test when key not in environ
    text_environ_1 = _TextEnviron({})
    try:
        text_environ_1['notset']
    except KeyError:
        pass
    else:
        # Keys that are not set should raise KeyError
        raise AssertionError("'notset' key should not work but did")

    # Test when key does exist
    text_environ_2 = _TextEnviron({'key': 'value'})
    assert text_environ_2['key'] == 'value', 'Key should be there with value'

    # Test if cache works
    assert text_environ_2['key'] == 'value', 'Key should continue to be there with value'


# Generated at 2022-06-25 13:36:26.187974
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.get(None)
    text_environ_0.get('PYTHONIOENCODING')
    text_environ_0.get('1')
    text_environ_0.get('5')
    text_environ_0.get('11')
    text_environ_0.get('15')
    text_environ_0.get('21')
    text_environ_0.get('25')
    text_environ_0.get('31')
    text_environ_0.get('35')
    text_environ_0.get('41')
    text_environ_0.get('45')
    text_environ_0.get('51')
    text_environ_0.get

# Generated at 2022-06-25 13:36:30.081293
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print("To test method __getitem__ of class _TextEnviron")
    env = {
        'key1': 'value1',
        'key2': 'value2',
        }
    text_environ = _TextEnviron(env)
    value = text_environ.__getitem__('key1')
    print(value)


# Generated at 2022-06-25 13:36:31.727802
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    x = _TextEnviron()
    assert isinstance(x['PATH'], str) and x['PATH'] == 'thing'


# Generated at 2022-06-25 13:36:33.464453
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    assert text_environ["HOME"] == os.environ["HOME"]

# Generated at 2022-06-25 13:36:35.887891
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError):
        text_environ_0.__getitem__('ZQQV7U')


# Generated at 2022-06-25 13:36:38.881560
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    assert env[ 'PATH' ] == os.environ[ 'PATH' ]
    assert isinstance(env['PATH'], str)



# Generated at 2022-06-25 13:36:46.380802
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Testing with default arguments.
    result = _TextEnviron._TextEnviron__getitem__()

    # Testing with positional arguments
    result = _TextEnviron._TextEnviron__getitem__(self=_TextEnviron(), key='HOME')

    # Testing with positional and keyword arguments
    result = _TextEnviron._TextEnviron__getitem__(self=_TextEnviron(), key='HOME')


# Generated at 2022-06-25 13:36:51.874617
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Test the retrieval of environment variables

    The value of the environment variables should come back as unicode.
    """
    # Python 2
    text_environ_1 = _TextEnviron()
    assert isinstance(text_environ_1['PATH'], unicode)
    # Python 3
    text_environ_2 = _TextEnviron(encoding='utf-8')
    assert isinstance(text_environ_2['PATH'], unicode)


# Generated at 2022-06-25 13:36:57.977468
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test cases
    string_1 = 'abc'
    string_2 = 'nbsp'
    string_3 = 'latin-1'
    string_4 = 'utf-8'
    string_5 = 'junk'
    text_environ_1 = _TextEnviron({'abc': 'abc'.encode('utf8'),
                                   'nbsp': '\xA0'.encode('utf8'),
                                   'latin-1': '\xA0'.encode('latin-1'),
                                   'utf-8': '\xA0'.encode('utf-8'),
                                   'junk': b'\xA0'})
    assert text_environ_1[string_1] == string_1

# Generated at 2022-06-25 13:36:59.764179
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron()
    assert e['SHELL'] == os.environ['SHELL']



# Generated at 2022-06-25 13:37:10.142588
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test None
    text_environ_0 = _TextEnviron()
    # assertRaises -> None
    # self, expected_exception
    # assertRaises context manager raises AssertionError if unexpected_exception is raised
    with pytest.raises(AssertionError) as cm_0:
        # _TextEnviron().__getitem__ -> None
        text_environ_0.__getitem__()
    assert str(cm_0.exception) == 'Expected an exception from None.'
    # Test dummy arg
    text_environ_1 = _TextEnviron()
    with pytest.raises(TypeError) as cm_1:
        text_environ_1.__getitem__('dummy')

# Generated at 2022-06-25 13:37:14.278533
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    key = '__TextEnviron___getitem__'
    text_environ = _TextEnviron()
    del text_environ[key]
    try:
        text_environ[key]
    except KeyError as e:
        assert str(e) == "'{0}'".format(key)
    else:
        assert False


# Generated at 2022-06-25 13:37:24.350801
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['HOME'] == os.environ['HOME']
        return
    assert environ['HOME'] == to_text(os.environ['HOME'], encoding=environ.encoding,
                                      nonstring='passthru', errors='surrogate_or_strict')
    environ.encoding = 'ascii'
    assert environ['HOME'] == to_text(os.environ['HOME'], encoding=environ.encoding,
                                      nonstring='passthru', errors='surrogate_or_strict')
    environ.encoding = 'utf-8'

# Generated at 2022-06-25 13:37:27.004581
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    assert(environ.__getitem__('PATH') is not None)
    assert(environ.__getitem__('PATH') == os.environ['PATH'])


# Generated at 2022-06-25 13:37:30.336551
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test empty string
    assert environ.__getitem__('') == ''

    # Test non-empty string
    assert environ.__getitem__('PATH') == os.getenv('PATH')

    # Test empty string
    assert environ.__getitem__('NONEXISTENTENV') == ''


# Generated at 2022-06-25 13:37:32.999928
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__setitem__('ansible_env_python_version', '2.7.5')
    assert text_environ_0.__getitem__('ansible_env_python_version') == '2.7.5'


# Generated at 2022-06-25 13:37:46.428314
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(env={b'TESTENV': b'Testing'})
    assert text_environ_0[b'TESTENV'] == 'Testing'

    testenv_value = os.environ[b'TESTENV']
    text_environ_1 = _TextEnviron()
    assert text_environ_1[b'TESTENV'] == testenv_value

    text_environ_2 = _TextEnviron(env={b'TESTENV': b'Testing'})
    assert text_environ_2[b'TESTENV'] == 'Testing'
    assert len(text_environ_2) == 1


# Generated at 2022-06-25 13:37:48.143030
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    t_environ_0 = _TextEnviron()
    t_environ_0.__getitem__('')
    t_environ_0.__getitem__('HOME')


# Generated at 2022-06-25 13:37:55.303535
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Init class
    text_environ = _TextEnviron()
    # Tests
    if sys.platform == 'win32':
        text_environ['TestKey'] = 'TestValue'
        assert text_environ['TestKey'] == 'TestValue'
    else:
        # This test doesn't work on win32 because os.environ on win32 is always byte strings.
        # So when we update the value, we always keep the byte string version.
        text_environ['TestKey'] = 'TestValue'
        assert text_environ['TestKey'] == 'TestValue'
        os.environ['TestKey'] = 'TestValue2'
        assert text_environ['TestKey'] == 'TestValue2'



# Generated at 2022-06-25 13:37:57.398526
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    temp_1 = text_environ_0['']
    temp_2 = text_environ_0['']


# Generated at 2022-06-25 13:38:00.229372
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set up
    # Unit under test
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__(u'HOME')


# Generated at 2022-06-25 13:38:03.315368
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__('LC_IDENTIFICATION')
    text_environ_0.__getitem__('PATH')


# Generated at 2022-06-25 13:38:07.572690
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert (to_bytes(text_environ_0['PATH']) == os.environ['PATH'])
    text_environ_0['PATH'] = u'PATHVAL'
    assert (to_bytes(text_environ_0['PATH']) == u'PATHVAL')



# Generated at 2022-06-25 13:38:10.492089
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['key'] = 'value'
    result = text_environ_0.__getitem__('key')
    assert result == 'value'


# Generated at 2022-06-25 13:38:12.841652
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # TODO - Add more tests
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__("TEST_KEY")
    text_environ_0.__getitem__("PATH")


# Generated at 2022-06-25 13:38:14.898569
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create environ_0
    environ_0 = _TextEnviron(env = {'variable_0': 'value_0'})
    environ_0.__getitem__('variable_0')


# Generated at 2022-06-25 13:38:28.515388
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        # We have to test this by assertion since it's impossible to truly set a byte key in the
        # environment so the variables should agree.
        assert environ['PWD'] == os.getcwd()
    else:
        environ['PWD'] = os.getcwd()
        assert environ['PWD'] == os.getcwd()
        # Set a key to a latin-1 value and then make sure that we get the latin-1 value back out
        # despite being in utf-8 mode.
        environ['PWD_LATIN1'] = to_bytes('PWD_LATIN1='.encode('latin-1') + os.getcwd().encode('latin-1'),
                                         errors='surrogate_or_strict')

# Generated at 2022-06-25 13:38:30.314774
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__('')


# Generated at 2022-06-25 13:38:38.185482
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    with pytest.raises(KeyError):
        text_environ_0 = _TextEnviron()
        text_environ_0.__getitem__(b'A_KEY')
    with pytest.raises(KeyError):
        text_environ_0 = _TextEnviron()
        text_environ_0.__getitem__('A_KEY')
    with pytest.raises(KeyError):
        text_environ_0 = _TextEnviron()
        text_environ_0.__getitem__(6)
    with pytest.raises(KeyError):
        text_environ_0 = _TextEnviron()
        text_environ_0.__getitem__('A_KEY')



# Generated at 2022-06-25 13:38:40.071248
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(env=None)
    text_environ_0.__getitem__('SHLVL')


# Generated at 2022-06-25 13:38:43.167080
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    temp = os.getenv("TMP")
    ans = text_environ_0.__getitem__("TMP")
    assert temp == ans


# Generated at 2022-06-25 13:38:45.808000
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    value = text_environ_0['SHELL']
    assert 'bash' in value


# Generated at 2022-06-25 13:38:55.085808
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        prev_env = os.environ['HOME']
    except KeyError:
        prev_env = None

    # 1. Missing key
    try:
        # os-environment doesn't allow missing keys
        os.environ.__getitem__('MISSING')
    except KeyError:
        pass
    with pytest.raises(KeyError):
        text_environ_0.__getitem__('MISSING')

    def _set_env(key, value):
        os.environ[key] = value

    # 2. Missing value
    try:
        prev_env = os.environ['HOME']
        del os.environ['HOME']
    except KeyError:
        prev_env = None
        pass


# Generated at 2022-06-25 13:38:56.701311
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert len(environ) > 0
    for key, value in environ.items():
        assert(key == environ[key])


# Generated at 2022-06-25 13:39:06.862019
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Case-0: set item with key and value, get item with key
    text_environ_0 = _TextEnviron()
    # Check if the result of __getitem__ of text_environ_0 is the same as the expected value
    # expected_value = b'value 00'
    # result = text_environ_0.__getitem__(b'key_00')
    # assert result == expected_value
    # Case-1: get item with unknown key
    text_environ_0 = _TextEnviron()
    # expected_value = b'value 00'
    # result = text_environ_0.__getitem__(b'key_01')
    # assert result == expected_value
    # Case-2: set item with key and value, get item with key
    text_environ_0 = _

# Generated at 2022-06-25 13:39:15.660714
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create test object
    obj = _TextEnviron()
    assert obj._raw_environ == os.environ
    assert obj._value_cache == {}
    assert obj.encoding == sys.getfilesystemencoding()

    # Test with environment variables like Python 3's os.environ would return
    bytes_env_key = os.environ.keys()[0]
    obj = _TextEnviron(env={bytes_env_key: os.environ[bytes_env_key]})
    obj_string_key = obj.keys()[0]
    assert obj.get(obj_string_key, False) == os.environ.get(bytes_env_key, False)

    # Test with environment variables with binary data in them
    bytes_env_key = os.environ.keys()[0]
    obj = _

# Generated at 2022-06-25 13:39:29.808412
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    # Get a value that's set in the raw environment
    assert(text_environ['PATH'] == os.environ['PATH'])
    # Get a value that isn't set in the raw environment
    assert(text_environ['PATH2'] == os.environ['PATH2'])


# Generated at 2022-06-25 13:39:38.684090
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    for key in text_environ:
        value = text_environ[key]
        assert(isinstance(value, six.text_type))

        # Test the cache by changing the environment variable from under us
        orig_value = os.environ[key]
        os.environ[key] = b'spam'
        assert(value == text_environ[key])
        os.environ[key] = to_bytes(value, encoding='utf-8', nonstring='strict',
                                   errors='surrogate_or_strict')
        assert(value == text_environ[key])
        os.environ[key] = orig_value


# Generated at 2022-06-25 13:39:45.473818
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test case 0
    # We have a value that is already unicode
    text_environ_0 = _TextEnviron()
    expected_result_0 = u'ThisIsNotAValue'
    result_0 = text_environ_0[u'ThisIsNotAValue']
    assert result_0 == expected_result_0
    # Test case 1
    # We have a value that is a byte string in the system encoding
    expected_result_1 = u'ThisIsNotAValue'
    result_1 = text_environ_0[b'ThisIsNotAValue']
    assert result_1 == expected_result_1
    # Test case 2
    # We have a value that is a byte string not in the system encoding
    expected_result_2 = u'ThisIsNotAValue'
    result_2 = text_en

# Generated at 2022-06-25 13:39:46.821030
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test case 0 with no arguments
    test_case_0()


# Generated at 2022-06-25 13:39:50.133813
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Assert that the first assertion failure is the key error
    os.environ = {'SCRIPT': 'fail', 'PATH': 'fail'}
    print(os.environ)
    print(environ)
    print(environ['PATH'])
    assert environ['PATH'] == 'fail'


# Generated at 2022-06-25 13:39:51.803486
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Case 0: Not implemented yet
    text_environ_0 = _TextEnviron()
    # TODO: Implement your test here
    assert True # TODO: implement your test here


# Generated at 2022-06-25 13:39:53.879489
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Perhaps we should mock the type returned by __getitem__?
    pass


# Generated at 2022-06-25 13:39:54.830221
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass



# Generated at 2022-06-25 13:39:58.263574
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0._raw_environ["LANG"] == "en_US.UTF-8"
    assert text_environ_0["LANG"] == "en_US.UTF-8"


# Generated at 2022-06-25 13:40:01.764238
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if 'PYTHONPATH' in environ:
        assert 'PYTHONPATH' in environ
        assert isinstance(environ['PYTHONPATH'], str)
    assert environ['HOME'] == os.getcwd()


# Generated at 2022-06-25 13:40:25.342511
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set up test environment
    # Case 0
    # Run test
    test_case_0()


# Generated at 2022-06-25 13:40:27.074433
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for __getitem__ with correct input and correct output
    test_case_0()



# Generated at 2022-06-25 13:40:32.308548
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Tests that values in environ are returned as text
    # Example dict with bytes key, text value
    raw_environ = {to_bytes("KEY"): to_text("VALUE")}
    # Create the _TextEnviron instance
    text_environ = _TextEnviron(env=raw_environ)
    # Make sure that the value comes back out as text
    assert isinstance(text_environ['KEY'], text)



# Generated at 2022-06-25 13:40:38.732324
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Test for method __getitem__ of class _TextEnviron
    '''

    if PY3:
        env_val = os.environ['ANSIBLE_TEST_DATA']
    text_environ_0 = _TextEnviron()
    if PY3:
        assert text_environ_0.__getitem__('ANSIBLE_TEST_DATA') == env_val
    elif sys.platform == 'win32':
        assert text_environ_0.__getitem__('ANSIBLE_TEST_DATA') == u'\\u00C1'
    else:
        assert text_environ_0.__getitem__('ANSIBLE_TEST_DATA') == u'\u00c1'


# Generated at 2022-06-25 13:40:41.004792
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # assert(obj == expected, "Expected: " + expected + " Actual: " + obj)
    assert not True, "___getitem___ not implemented"


# Generated at 2022-06-25 13:40:41.936372
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()


# Generated at 2022-06-25 13:40:45.134791
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__setitem__("PYTHONIOENCODING", "ascii")
    text_environ_0.__getitem__("PYTHONIOENCODING")


# Generated at 2022-06-25 13:40:48.174028
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['key'] = 'value'
    value_0 = text_environ_0['key']


# Generated at 2022-06-25 13:40:49.539986
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert text_environ_0.__getitem__(text_environ_0) == None


# Generated at 2022-06-25 13:40:53.044167
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Calls str.__getitem__; fails with TypeError if 'PATH' is not a string in os.environ
    str_0 = text_environ_0.__getitem__('PATH')
    assert str_0 is not None


# Generated at 2022-06-25 13:41:43.558184
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Test normal case with existing key
    try:
        text_environ_0.__getitem__('PATH')
    except KeyError:
        pass
    # Test with non-existent key
    with pytest.raises(KeyError):
        text_environ_0.__getitem__('non_existent')


# Generated at 2022-06-25 13:41:45.667260
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for default value of argument key
    assert text_environ_0.__getitem__() == "LANG"


# Generated at 2022-06-25 13:41:48.877053
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Initialize _TextEnviron object
    text_environ_0 = _TextEnviron()

    # Call method __getitem__ with argument 'PATH'
    result = text_environ_0.__getitem__('PATH')

    assert result is not None



# Generated at 2022-06-25 13:41:52.334676
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Initialize test object
    text_environ_0 = _TextEnviron()
    # Call method
    key = "LANG"
    result = text_environ_0.__getitem__(key)
    # Check result
    assert result == u"en_US.UTF-8"

# Generated at 2022-06-25 13:41:54.215451
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__('P%N~|T2T')


# Generated at 2022-06-25 13:41:56.754276
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__('SHELL')
    assert result == '/bin/bash'


# Generated at 2022-06-25 13:41:59.003796
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """
    e = _TextEnviron()
    assert e['LANG'] == u'en_US.utf8'



# Generated at 2022-06-25 13:42:00.912131
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Default value for argument 1 is five
    text_environ_0.__getitem__('five')


# Generated at 2022-06-25 13:42:04.150947
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    t = text_environ_0['PATH']
    assert isinstance(t, basestring)
    if not PY3:
        # We should be decoding the value
        assert not isinstance(t, bytes)


# Generated at 2022-06-25 13:42:06.009614
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert 'HOME' in environ
    assert 'HOME' in os.environ
    assert environ['HOME'] == os.environ['HOME']


# Generated at 2022-06-25 13:43:06.767426
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0[''] == os.environ['']
    assert text_environ_0['x'] == os.environ['x']
    assert text_environ_0['x#'] == os.environ['x#']
    assert text_environ_0['_'] == os.environ['_']
    assert text_environ_0['_#'] == os.environ['_#']
    assert text_environ_0['_x'] == os.environ['_x']
    assert text_environ_0['_x#'] == os.environ['_x#']


# Generated at 2022-06-25 13:43:09.369449
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import sys

    for env in (os.environ, {b'foo': b'bar'}):
        with _TextEnviron(env) as text_environ_0:
            # __getitem__ should return text when python3
            text_environ_0.__getitem__('foo')
            # __getitem__ should return text when python2
            text_environ_0.__getitem__('foo')



# Generated at 2022-06-25 13:43:12.005932
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert text_environ_0[GET] == GETVALUE
    assert text_environ_0['get'] == GETVALUE
    assert text_environ_0['GET'] == GETVALUE
    assert text_environ_0['gEt'] == GETVALUE


# Generated at 2022-06-25 13:43:15.225755
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_arg_0 = get_random_string(random.randint(1, 100), string.printable)
    str_arg_1 = text_environ_0[str_arg_0]
    assert cmp(str_arg_1, os.environ[str_arg_0]) == 0


# Generated at 2022-06-25 13:43:24.761165
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Test 1: Key does not exist
    environ = _TextEnviron({})
    try:
        environ.__getitem__('ANSIBLE_NOTREAL')
    except KeyError as e:
        assert str(e) == "'ANSIBLE_NOTREAL'"
    else:
        pytest.fail("__getitem__ did not raise KeyError")

    # Test 2: Key exists, but has no value
    environ = _TextEnviron({'ANSIBLE_NOTREAL': ''})
    assert environ.__getitem__('ANSIBLE_NOTREAL') == ''

    # Test

# Generated at 2022-06-25 13:43:28.031439
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(encoding='utf-8')
    text_environ_0.__setitem__('HOME', 'home/user')
    assert text_environ_0.__getitem__('HOME') == 'home/user'


# Generated at 2022-06-25 13:43:29.574786
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert text_environ_0.__getitem__('__name__') == '__main__'

# Generated at 2022-06-25 13:43:37.246655
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-25 13:43:38.345878
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ["LANG"] == "en_US.UTF-8"


# Generated at 2022-06-25 13:43:42.320003
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    val = text_environ_1.__getitem__("PYTHONPATH")
    assert val == __file__.split(os.path.sep)[:-1]

    text_environ_2 = _TextEnviron()
    val = text_environ_2.__getitem__("PATH")
    assert val != __file__.split(os.path.sep)[:-1]
