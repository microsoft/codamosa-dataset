

# Generated at 2022-06-25 13:34:20.976620
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__setitem__('HOME', '/home/foo')
    var_0 = text_environ_0.__getitem__('HOME')
    assert var_0 == '/home/foo'


# Generated at 2022-06-25 13:34:29.103023
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # str input
    text_environ_0 = _TextEnviron()

    assert text_environ_0.__getitem__('') == ''

    # unicode input
    text_environ_1 = _TextEnviron()

    assert text_environ_1.__getitem__(u'\u0061') == u'\u0061'

    # non-string input
    text_environ_2 = _TextEnviron()

    assert text_environ_2.__getitem__(1) == 1
    assert text_environ_2.__getitem__(0.0) == 0.0



# Generated at 2022-06-25 13:34:30.582450
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 13:34:38.052502
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = "DxmJSj+wV7R^F]8JvEb,PF;?/YK[+#N%c,B+*H>2Q+`OHUnB:Z8E#,b1!l(X9ml"
    try:
        text_environ_0.__setitem__(str_0, str_0)
    except UnicodeDecodeError:
        pass
    except UnicodeEncodeError:
        pass
    text_environ_0.__getitem__(str_0)


# Generated at 2022-06-25 13:34:43.428348
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_1 = _TextEnviron()
    text_environ_2 = _TextEnviron(encoding='utf-8')
    # Exception handling
    try:
        text_environ_0.__getitem__('a')
    except:
        pass


# Generated at 2022-06-25 13:34:45.731717
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__('ALU_TOOLS_HOME')


# Generated at 2022-06-25 13:34:48.187241
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    var_1 = text_environ_1['__getitem__']



# Generated at 2022-06-25 13:34:57.434355
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0.__getitem__('a')
    str_1 = text_environ_0.get('a')
    str_0 = text_environ_0['a']
    str_1 = text_environ_0.__getitem__('a')
    str_0 = text_environ_0.get('a')
    str_0 = text_environ_0['a']
    # str_1 = text_environ_0['a']
    str_1 = text_environ_0.get('a')
    str_0 = text_environ_0['a']
    try:
        str_1 = text_environ_0['b']
    except KeyError:
        str_0 = str_1

# Generated at 2022-06-25 13:35:01.571391
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Testing with non-existent key
    text_environ_3 = _TextEnviron()
    var_3 = text_environ_3.__getitem__('non-existent')
    # Testing with existing key
    text_environ_4 = _TextEnviron()
    var_4 = text_environ_4.__getitem__('PATH')

# Generated at 2022-06-25 13:35:03.990910
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__('LC_ALL')


# Generated at 2022-06-25 13:35:14.512276
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    text_environ_0 = _TextEnviron()
    # AssertionError (repr(var) == other)
    with pytest.raises(AssertionError):
        text_environ_0.__getitem__((1.0))
    # AssertionError (repr(var) == other)
    with pytest.raises(AssertionError):
        text_environ_0.__getitem__((1.0))
    # AssertionError (repr(var) == other)
    with pytest.raises(AssertionError):
        text_environ_0.__getitem__(('A'))
    # AssertionError (repr(var) == other)
    with pytest.raises(AssertionError):
        text_environ_0

# Generated at 2022-06-25 13:35:16.884960
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0[b'key'] = b'value'
    assert_equal(text_environ_0[b'key'], u'value')


# Generated at 2022-06-25 13:35:23.557610
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test 1: Python2 with environment variable that is not in the cache
    #         Should put it in the cache
    import os
    environ_0 = os.environ.copy()
    os.environ['python_version'] = '2'
    text_environ_0 = _TextEnviron()
    assert text_environ_0['python_version'] == '2'
    assert len(text_environ_0._value_cache) == 1
    assert 'python_version' in text_environ_0._value_cache
    assert text_environ_0._value_cache['python_version'] == '2'
    # Restore state
    os.environ = environ_0
    del text_environ_0

    # Test 2: Python2 with environment variable that is in the cache
    #         Should use the cached

# Generated at 2022-06-25 13:35:25.611417
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    value_0 = text_environ_0.__getitem__('')
    assert value_0 is None


# Generated at 2022-06-25 13:35:27.320765
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'

# Generated at 2022-06-25 13:35:35.647779
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        # Test for a key that's been set (and thus we need to encode)
        environ['test_key__TextEnviron___getitem__'] = 'test_value__TextEnviron___getitem__'
        assert environ['test_key__TextEnviron___getitem__'] == 'test_value__TextEnviron___getitem__'

        # Test for a key that's already got a text value
        environ['test_key__TextEnviron___getitem__'] = 'test_value__TextEnviron___getitem__'.encode('utf-8')
        assert environ['test_key__TextEnviron___getitem__'] == 'test_value__TextEnviron___getitem__'

        # Test for a key that's already got a bytes value

# Generated at 2022-06-25 13:35:37.364570
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert _TextEnviron(env={'a': 'b'})['a'] == 'b'


# Generated at 2022-06-25 13:35:46.222317
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1['key1'] = 'text1'
    assert text_environ_1['key1'] == 'text1'
    assert type(text_environ_1['key1']) == str
    # Test error handling
    try:
        text_environ_1['key2']
    except KeyError as e:
        if str(e) != 'key2':
            raise AssertionError()
        pass
    else:
        raise AssertionError()
    # Test non-string values
    text_environ_1['key3'] = b'bytes3'
    assert text_environ_1['key3'] == b'bytes3'
    assert type(text_environ_1['key3']) == bytes

# Unit test

# Generated at 2022-06-25 13:35:48.241376
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_2 = _TextEnviron()
    # No assertion.


# Generated at 2022-06-25 13:35:51.907002
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['_TextEnviron'] = '_TextEnviron'
    text_environ_0.__getitem__('_TextEnviron')
    text = '_TextEnviron'
    text_environ_0.__getitem__(text)


# Generated at 2022-06-25 13:35:54.384616
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__('ASDF')

    assert(result == "" )



# Generated at 2022-06-25 13:35:56.419629
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0['SSSSSSSSSSS']


# Generated at 2022-06-25 13:36:00.717519
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # check if returns the correct type when text is input.
    assert isinstance(text_environ_0.__getitem__('HOME'), str)
    # check if returns the correct type when bytes is input.
    assert isinstance(text_environ_0.__getitem__(b'HOME'), str)


# Generated at 2022-06-25 13:36:08.675481
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # test normal case
    try:
        assert 'HOSTNAME' in os.environ
    except (AssertionError, TypeError):
        raise AssertionError
    # env_7 = text_environ_0.__getitem__('HOSTNAME')
    # test with blank values
    # sandbox = _copy()
    text_environ_1 = _TextEnviron()
    # test with blank values
    # sandbox = _copy()
    os.environ['HOSTNAME'] = ''
    # text_environ_1.__setitem__('HOSTNAME', '')
    # env_8 = text_environ_1.__getitem__('HOSTNAME')
    pass



# Generated at 2022-06-25 13:36:11.770910
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    #line 56
    str_0 = text_environ_0.__getitem__('HOME')
    assert str_0 == os.environ['HOME']


# Generated at 2022-06-25 13:36:22.043025
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test 1:
    # Test params: environ_0 = _TextEnviron( encoding='utf-8')
    # Test expected: 5
    # Test assertion: environ_0.__getitem__('LANG') == 'en_US.UTF-8'
    # Test cleanup:
    text_environ_0 = _TextEnviron(encoding='utf-8')
    assert text_environ_0.__getitem__('LANG') == 'en_US.UTF-8', "Expected 5, but got %s" % text_environ_0.__getitem__('LANG')
    # Test 2:
    # Test params: environ_0 = _TextEnviron( encoding='utf-8')
    # Test expected: 3
    # Test assertion: environ_0.__getitem__('PATH') == '/

# Generated at 2022-06-25 13:36:29.939482
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['TEST_KEY'] = 'abc'

    # Test with an ASCII key (expected result is unicode)
    assert environ['TEST_KEY'] == u'abc'

    # Test with a unicode key (expected result is unicode)
    assert environ[u'TEST_KEY'] == u'abc'

    # Test with a non-ASCII key (expected result is unicode)
    if not PY3:
        assert environ[u'☃'.encode('utf-8')] == u'abc'

    # Test with a key that doesn't exist (expected result is KeyError)
    try:
        environ['NON_EXISTENT_KEY']
        raise Exception('Caught KeyError as expected')
    except KeyError:
        pass



# Generated at 2022-06-25 13:36:39.004279
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test default init
    text_environ_0 = _TextEnviron()
    try:
        text_environ_0['']
    except KeyError:
        pass
    else:
        raise AssertionError('Assertion error from test "test__TextEnviron___getitem__".')

    # Test if we get the same result as os.environ.get()
    text_environ_0 = _TextEnviron()
    get_result = os.environ.get('LD_LIBRARY_PATH')
    if not get_result is None and not get_result == text_environ_0['LD_LIBRARY_PATH']:
        raise AssertionError('Assertion error from test "test__TextEnviron___getitem__".')

    # Test if we can retrieve environment variables with unicode characters in them

# Generated at 2022-06-25 13:36:44.651345
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # If a byte string is in the environment, it should be converted to a
    # text string automatically
    assert 'foo' in environ
    assert u'foo' in environ
    if PY3:
        # On Python3, we're converting but there's no need to cache anything
        assert environ['foo'] == os.environ['foo']
    else:
        # Caching the translated value
        assert environ['foo'] == u'foo'


# Generated at 2022-06-25 13:36:49.123930
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Tests with keys that only exist in the environment
    assert text_environ_0.__getitem__('PATH') == environ['PATH']

    # Tests with keys that do not exist in the environment
    assert text_environ_0.__getitem__('GIT_FORCE_INTERACTIVE_PASS') is None


# Generated at 2022-06-25 13:36:54.157994
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    key = 'PWD'
    value = text_environ_0.__getitem__(key)
    assert value is not None
    assert value is not ''

# Generated at 2022-06-25 13:37:05.141023
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    case_0 = _TextEnviron({'PYTHONPATH': '$ANSIBLEDIR:$ANSIBLE_TEST_DATA_ROOT:$ANSIBLE_TEST_DATA_ROOT/integration:$ANSIBLE_REPO_ROOT/lib:$ANSIBLE_TEST_DATA_ROOT/units'})
    result = case_0.__getitem__('PYTHONPATH')
    assert result == '$ANSIBLEDIR:$ANSIBLE_TEST_DATA_ROOT:$ANSIBLE_TEST_DATA_ROOT/integration:$ANSIBLE_REPO_ROOT/lib:$ANSIBLE_TEST_DATA_ROOT/units'
    case_1 = _TextEnviron()
    result = case_1.__getitem__('TEST_VALUE')

# Generated at 2022-06-25 13:37:08.544652
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    key_arg_0 = 'XDG_SESSION_ID'
    return_text_0 = text_environ_0.__getitem__(key_arg_0)


# Generated at 2022-06-25 13:37:17.265613
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        # On Python 3 no decoding is necessary
        assert environ['HOME'] == os.environ['HOME']

    else:
        # Utf-8 encoded environment variables succeed
        os.environ[b'ANSIBLE_TEST_UTF8_ENV_VAR'] = b'/\xc3\xbc\xc3\xa4\xc3\xb6/'
        assert environ[b'ANSIBLE_TEST_UTF8_ENV_VAR'] == u'/\xfc\xe4\xf6/'

        # Invalid utf-8 characters are not decoded
        os.environ[b'ANSIBLE_TEST_INVALID_UTF8_ENV_VAR'] = b'\xc3\x28\xa3\x29'

# Generated at 2022-06-25 13:37:20.108312
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_keys = list(environ.keys())
    for key in environ_keys:
        print(key + " = " + environ[key])


# Generated at 2022-06-25 13:37:23.258423
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Make sure that we can use the mapping
    text_environ_0 = _TextEnviron(encoding=None)
    assert len(text_environ_0) > 0
    assert isinstance(text_environ_0['HOME'], str)


# Generated at 2022-06-25 13:37:26.193063
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('LANG') == os.getenv('LANG'), 'Failed to get item from _TextEnviron'



# Generated at 2022-06-25 13:37:27.891706
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__('HOME')


# Generated at 2022-06-25 13:37:30.604121
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    test_1 = text_environ_0.__getitem__(
        'CHECK_WINDOWS_DEFENDER_ANTIVIRUS')
    assert  test_1 == 'true'


# Generated at 2022-06-25 13:37:32.017059
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
# ###############################

# Generated at 2022-06-25 13:37:37.664096
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['PYCHARM_DEBUG'] = '1'
    assert text_environ_0['PYCHARM_DEBUG'] == '1'



# Generated at 2022-06-25 13:37:41.727634
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    tmp_environ = {}
    expected_result = {"A": "B"}
    #
    os.environ = tmp_environ
    text_environ_0 = _TextEnviron(os.environ)
    actual_result = text_environ_0.__getitem__("A")
    assert expected_result == actual_result


# Generated at 2022-06-25 13:37:45.430182
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__(u'USER') == os.environ[u'USER']


# Generated at 2022-06-25 13:37:48.415562
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an instance of _TextEnviron
    text_environ_0 = _TextEnviron()
    # Assigning a Str to a Subscript is not supported
    # assert (text_environ_0[''] == _____)


# Generated at 2022-06-25 13:37:52.394545
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_2 = _TextEnviron()
    key = text_environ_1.__getitem__('PATH')
    assert isinstance(key, str)
    key = text_environ_2.__getitem__('PATH')
    assert isinstance(key, str)
    assert key == text_environ_1.__getitem__('PATH')


# Generated at 2022-06-25 13:37:54.755258
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError):
        text_environ_0['asdf']


# Generated at 2022-06-25 13:37:56.771574
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['PWD']
    text_environ_0['PWD']



# Generated at 2022-06-25 13:38:06.451239
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Method __getitem__ should return a text value that's decoded from the environment.
    """
    text_environ_2 = _TextEnviron({b'ASCII_ONLY': b'ASCII VALUE'})
    text_environ_5 = _TextEnviron({b'UTF8_ONLY': b'\xe7\xb5\xb5\xe8\xaf\x9d'.decode('UTF-8')})
    # Both of these environmen variables are cached
    assert text_environ_2[b'ASCII_ONLY'] == u'ASCII VALUE'
    assert text_environ_2[b'ASCII_ONLY'] == u'ASCII VALUE'
    assert text_environ_5[b'UTF8_ONLY'] == u'絵詞'

# Generated at 2022-06-25 13:38:12.866574
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert to_text(text_environ_1["SHELL"]) == "/bin/bash"
    text_environ_2 = _TextEnviron()
    assert to_text(text_environ_2["PYTHONIOENCODING"]) == "UTF-8"
    assert text_environ_1["SHELL"] == text_environ_2["SHELL"]
    assert text_environ_1["PYTHONIOENCODING"] == text_environ_2["PYTHONIOENCODING"]



# Generated at 2022-06-25 13:38:14.064430
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    res = text_environ['test']
    assert res == 'test'

# Generated at 2022-06-25 13:38:27.081932
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    old_sys_getfilesystemencoding = sys.getfilesystemencoding
    sys.getfilesystemencoding = lambda: "ascii"
    text_environ_0 = _TextEnviron()
    assert len(text_environ_0) == len(os.environ)
    for key, value in os.environ.items():
        assert text_environ_0[key] == os.environ[key]
    assert text_environ_0['PATH'] == os.environ['PATH']
    with pytest.raises(KeyError):
        text_environ_0['PATHs']
    sys.getfilesystemencoding = old_sys_getfilesystemencoding


# Generated at 2022-06-25 13:38:28.220509
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test 1
    test_case_0()



# Generated at 2022-06-25 13:38:30.277482
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # NOTE: dict comparison tests if the two dicts are equal or not and returns a boolean
    assert environ['LANG'] == 'en_US.utf8'


# Generated at 2022-06-25 13:38:38.958271
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # check behaviour when key is missing
    try:
        text_environ_0 = _TextEnviron()
        get_1 = text_environ_0['TEST_ENV_VAR_2']
    except:
        pass
    else:
        raise Exception("Failed to raise exception when key is missing")

    # check behaviour when key is present but not decoded
    text_environ_1 = _TextEnviron({'TEST_ENV_VAR_1': 'test_value'})
    test_value = text_environ_1['TEST_ENV_VAR_1']
    if test_value != 'test_value':
        raise Exception("Unexpected value returned when key is present but not decoded")

    # check behaviour when key is present and is decoded
    text_environ_2 = _Text

# Generated at 2022-06-25 13:38:49.344968
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # iterate over a text string as UTF-8 encoded bytes
    text_environ_0 = _TextEnviron()
    text_environ_0.encoding = to_text('utf-8')
    expected_0 = to_text('')
    test_case_0()
    for key in text_environ_0._value_cache:
        actual_0 = text_environ_0._value_cache[key]
        assert actual_0 == expected_0
    # iterate over a text string as UTF-16 encoded bytes
    text_environ_1 = _TextEnviron()
    text_environ_1.encoding = to_text('utf-16')
    expected_1 = to_text('')
    for key in text_environ_1._value_cache:
        actual_1 = text_en

# Generated at 2022-06-25 13:38:52.491795
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    te0 = _TextEnviron()
    assert ('HOME' in te0.keys())
    assert ('HOME' in te0)
    assert (te0[u'HOME'] == os.environ[u'HOME'])


# Generated at 2022-06-25 13:38:59.085154
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    # Non-String Key case
    try:
        text_environ_0.__getitem__(1)
    except Exception as e:
        assert type(e) == TypeError

    # Key not in environment case
    try:
        text_environ_0.__getitem__('TEST_NOT_IN_ENV')
    except Exception as e:
        assert type(e) == KeyError

    # Positive case: Add value to environment and attempt to retrieve
    test_value = 'Test'
    os.environ['TEST_CASE_0'] = to_bytes(test_value)
    assert test_value == text_environ_0.__getitem__('TEST_CASE_0')


# Generated at 2022-06-25 13:39:01.543936
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__('HOME') == environ['HOME']



# Generated at 2022-06-25 13:39:03.641348
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test the __getitem__() method of the _TextEnviron class
    """

    text_environ_0 = None


# Generated at 2022-06-25 13:39:09.353786
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if sys.version_info.major < 3:
        text_environ_0 = _TextEnviron()
        byte_key = 'some_text_string'.encode('utf-8')
        byte_value = 'some other text string'.encode('utf-8')
        os.environ[byte_key] = byte_value
        text_value = text_environ_0[byte_key]
        assert text_value == u'some other text string'

# Generated at 2022-06-25 13:39:25.122985
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # This is where we'd like to get the current value of the environment variable.  But doing so
    # requires changing the environment variable to something else and then back from the test
    # process itself.  That's out of scope for this unit test.  Instead, let's just verify that we
    # can get the same value back that we set
    # assert 0
    return text_environ_0.__getitem__('abcde')


# Generated at 2022-06-25 13:39:28.560412
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    _text_environ = _TextEnviron()
    value=_text_environ.__getitem__('hello')
    if value:
        print('Key found')
    else:
        print('Key not found')


# Generated at 2022-06-25 13:39:37.492454
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print('Testing method ' + test__TextEnviron___getitem__.__name__)
    text_environ_0 = _TextEnviron()
    text_environ_0['HOME'] = '.'
    assert text_environ_0['HOME'] == '.'
    text_environ_0['HOME'] = '.'
    text_environ_0['HOME'] = '.'
    text_environ_0['HOME'] = '.'
    text_environ_0['HOME'] = '.'
    text_environ_0['HOME'] = '.'
    text_environ_0['HOME'] = '.'
    text_environ_0['HOME'] = '.'
    text_environ_0['HOME'] = '.'
    text_environ_0['HOME'] = '.'

# Generated at 2022-06-25 13:39:40.956849
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if not PY3:
        # os.environ returns byte strings on Python2
        assert isinstance(text_environ_0['__class__'], str)  # type: ignore
    text_environ_0['TEST'] = 'foo'
    assert text_environ_0['TEST'] == 'foo'


# Generated at 2022-06-25 13:39:46.239351
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        assert text_environ_0['DOTNETCORE_REPO_PAT'] == 'TEST_VALUE'
    except KeyError:
        if PY3:
            raise
        # Python2 requires the env var to be set
        os.environ['DOTNETCORE_REPO_PAT'] = u'TEST_VALUE'
        assert text_environ_0['DOTNETCORE_REPO_PAT'] == 'TEST_VALUE'
        del os.environ['DOTNETCORE_REPO_PAT']



# Generated at 2022-06-25 13:39:47.052552
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_case_0()

# Generated at 2022-06-25 13:39:53.483535
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    r"""
    _TextEnviron.__getitem__(key) -> value

    Mimics the behaviour of os.environ on Python 3 about returning text strings from the environment
    instead of byte strings
    """
    # Save current environment variables for later restoration
    original_environ = dict(os.environ)

    # A basic get without modification
    try:
        text_environ_1 = _TextEnviron()
        # A basic get without modification
        assert text_environ_1['PATH'] == os.environ['PATH']
    finally:
        # Restore original environment variables
        os.environ.clear()
        os.environ.update(original_environ)


# Generated at 2022-06-25 13:39:54.681325
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert _TextEnviron.__getitem__ == 'TODO'


# Generated at 2022-06-25 13:39:59.765362
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    path = text_environ_0['PATH']
    assert path == '/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games:/usr/local/bin:/usr/bin:/bin:/usr/local/games:/usr/games', 'Failed to get the path from the text_environ_0 object: '+path


# Generated at 2022-06-25 13:40:08.242255
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()

    assert text_environ_1[u'PYTHONPATH'] == u'/usr/lib/python/site-packages'
    assert text_environ_1[u'SHELL'] == u'/bin/bash'
    assert text_environ_1[u'USER'] == u'vagrant'
    assert text_environ_1[u'SUDO_COMMAND'] == u'/usr/bin/ansible-connection-test'
    assert text_environ_1[u'SUDO_USER'] == u'vagrant'
    assert text_environ_1[u'SUDO_UID'] == u'1000'
    assert text_environ_1[u'USERNAME'] == u'vagrant'

# Generated at 2022-06-25 13:40:21.206235
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['USER'] == os.environ['USER']


# Generated at 2022-06-25 13:40:24.632686
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__setitem__('key', 'value')
    str_0 = text_environ_0.__getitem__('key')
    assert str_0 == 'value'


# Generated at 2022-06-25 13:40:25.829160
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Parameters
    test_case_0()


# Generated at 2022-06-25 13:40:27.516621
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    assert environ['HOME'] == '/home/toshio'


# Generated at 2022-06-25 13:40:31.540866
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print('starting test_case_1')
    text_environ_0 = _TextEnviron()
    #set_trace()
    result = text_environ_0.__getitem__('USER')
    assert 'toshio' in result
    print('test_case_1 complete')
    print('\n')


# Generated at 2022-06-25 13:40:34.566880
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1['TEST_VAR'] = 'TEST_VAL'
    assert text_environ_1['TEST_VAR'] == 'TEST_VAL'


# Generated at 2022-06-25 13:40:36.931964
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0['A'] == 'B'
    assert text_environ_1['A'] == 'B', 'Assertion error at line : 9'


# Generated at 2022-06-25 13:40:38.469941
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 13:40:41.448313
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        assert text_environ_0.__getitem__('HOME')
    except KeyError:
        return
    else:
        raise AssertionError()


# Generated at 2022-06-25 13:40:50.235180
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Retrieve the value of an environment variable.
    
    If the value is not in the cache, it will be decoded using ``self.encoding``.
    Return the value as text after decoding.
    
    :arg str key: Name of the environment variable to retrieve.
    :returns: The text value of the environment variable.
    """
    text_environ_0 = _TextEnviron(encoding='utf-8')
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # set up the attributes
    text_environ_0.encoding = 'utf-8'
    
    # set up the method attributes
    text_environ_0._raw_environ = {}
    text_environ_0._value_cache = {}

# Generated at 2022-06-25 13:41:15.126557
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # initialize a global variable environ
    global environ
    text_environ_1 = _TextEnviron()
    global result_test_case_1
    result_test_case_1 = text_environ_1.__getitem__('HOSTNAME')
    assert True, result_test_case_1


# Generated at 2022-06-25 13:41:19.474685
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test case 1:
    # Test that a text value is returned when given a text key

    # Arrange
    text_environ_0 = _TextEnviron({'abc': 'abc'})

    # Act
    text_environ_0_ret = text_environ_0.__getitem__('abc')

    # Assert
    assert text_environ_0_ret == 'abc'



# Generated at 2022-06-25 13:41:29.109284
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test in PY3 to ensure we haven't broken existing functionality
    if PY3:
        # Test that we get a normal value from this
        text_environ = _TextEnviron()
        value = text_environ['PATH']
        assert value == os.environ['PATH']
        assert isinstance(value, str)
    else:
        # Test that we get a text value from this
        text_environ = _TextEnviron()
        value = text_environ['PATH']
        assert value == os.environ['PATH'].decode('utf-8')
        assert isinstance(value, str)
        # Test that a unicode value is returned as text

# Generated at 2022-06-25 13:41:37.108760
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # check for pythons prior to 3.x
    if sys.version_info.major < 3:
        # check for keys that must exist
        assert 'PATH' in text_environ_0
        assert 'USER' in text_environ_0
        # check for keys that must not exist
        assert 'LANGUAGE' not in text_environ_0
        assert 'LC_CTYPE' not in text_environ_0
        # check for keys that should be able to be retrieved
        assert text_environ_0['PATH']
        assert text_environ_0['USER']
        # check for UTF-8 path
        assert text_environ_0['PATH'].startswith('/usr/bin:/bin:/usr/sbin:/sbin')
   

# Generated at 2022-06-25 13:41:41.212247
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    expected_result = os.environ['PATH']
    actual_result = text_environ_0['PATH']
    assert actual_result == expected_result

# Generated at 2022-06-25 13:41:50.105755
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # If PY3, make sure that we return the text value.
    # This test will fail on PY2, but if it does, then it means that the
    # os.environ on PY2 is always returning text, which is what we want.
    if PY3:
        assert isinstance(environ['LANG'], str)

    # Make sure that we return the correct text values
    assert environ['LANG'] == 'en_US.UTF-8'
    assert environ['LC_ALL'] == 'en_US.UTF-8'

    # Make sure that we handle non-string values properly
    environ['ANSIBLE_TEST_BOOL_VAR'] = False
    assert environ['ANSIBLE_TEST_BOOL_VAR'] == 'False'

# Generated at 2022-06-25 13:41:52.757169
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    assert text_environ_0._raw_environ == os.environ
    assert text_environ_0._value_cache == {}
    assert text_environ_0.encoding == sys.getfilesystemencoding()
    assert text_environ_0['PWD'] == os.getcwd()

# Generated at 2022-06-25 13:42:00.466973
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test cases for method __getitem__ of class _TextEnviron
    """
    # Unit test for __getitem__ of class _TextEnviron
    # Case 1: Get from os.environ
    text_environ_0 = _TextEnviron()
    regexp = None
    regexp = r'^\w+$'
    key = 'LANG'
    value = 'zh_CN.UTF-8'
    # Put the key and value into os.environ
    text_environ_0._raw_environ[key] = value
    # Get the value from the dict
    value_0 = text_environ_0[key]
    # Assert on the values
    assert value == value_0, 'Expected {}, got {}'.format(value, value_0)


# Generated at 2022-06-25 13:42:03.162786
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    sys.stderr.write("testing _TextEnviron.__getitem__\n")
    assert sys.getfilesystemencoding() == 'utf-8'
    assert _TextEnviron().encoding == 'utf-8'

# Generated at 2022-06-25 13:42:10.343818
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()

    # Test function __getitem__ of class _TextEnviron against list: [
    #     'REMOTE_PORT',
    #     'HTTP_COOKIE',
    #     'LOCAL_PORT',
    #     'MANPATH',
    #     'USERNAME',
    #     'PATH',
    #     'REMOTE_ADDR',
    #     'TERM',
    #     'AP_PARENT_PID',
    #     '_',
    #     'RUN_FROM_CLI',
    #     'HTTP_REFERER',
    #     'LD_LIBRARY_PATH',
    #     'HTTP_HOST',
    #     'SERVER_PORT',
    #     'HTTP_USER_AGENT',
    #    

# Generated at 2022-06-25 13:42:41.349836
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Test passing a key which doesn't exist
    assert text_environ_0["hello"] != None

    # Test passing a valid key
    text_environ_1 = _TextEnviron()
    assert text_environ_1["PWD"] != None


# Generated at 2022-06-25 13:42:43.430976
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError):
        text_environ_0["bar"]


# Generated at 2022-06-25 13:42:45.355929
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        assert text_environ_0.__getitem__(None) == None
    except:
        assert False, "Unable to get item None"



# Generated at 2022-06-25 13:42:46.918096
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    result = text_environ_0.__getitem__('HOME')
    # Verify the expected
    assert result == '/home/osboxes'


# Generated at 2022-06-25 13:42:49.760443
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Init class _TextEnviron
    text_environ_0 = _TextEnviron()
    # Set key to item of text_environ_0
    key = 'SSH_CONNECTION'
    # Get item of text_environ_0 in key
    item = text_environ_0[key]


# Generated at 2022-06-25 13:42:52.086146
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set up test data for testing

    # Run test method
    text_environ_0 = _TextEnviron()
    result = text_environ_0.__getitem__("LINES")

    # Check that the result is as expected
    assert result == "25"



# Generated at 2022-06-25 13:42:53.540948
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert type(text_environ_0.__getitem__('$')) == str


# Generated at 2022-06-25 13:42:59.773563
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(env={b'LANG': b'en_US.UTF-8'}, encoding='utf-8')
    text_environ_1 = _TextEnviron(env={b'LANG': b'en_US.UTF-8'}, encoding='utf-8')
    assert text_environ_0['LANG'] == 'en_US.UTF-8'
    assert text_environ_1['LANG'] == 'en_US.UTF-8'



# Generated at 2022-06-25 13:43:04.576299
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # os.environ contains bytes so the key is bytes and the values are bytes
    if PY3:
        assert(to_text(ENV['test_case_0'], errors='surrogate_or_strict') ==
               to_text('_TextEnviron', errors='surrogate_or_strict'))
    else:
        assert(to_text(ENV['test_case_0'], errors='surrogate_or_strict') ==
               to_text('_TextEnviron', encoding='utf-8', errors='surrogate_or_strict'))

# Generated at 2022-06-25 13:43:05.913281
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__('LANG')


# Generated at 2022-06-25 13:43:31.540380
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PWD'] == '.'


# Generated at 2022-06-25 13:43:33.662578
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    arg0 = environ
    arg1 = 'PATH'
    out0 = arg0.__getitem__(arg1)
    return out0


# Generated at 2022-06-25 13:43:35.228445
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_1 = _TextEnviron()



# Generated at 2022-06-25 13:43:36.499516
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    te = _TextEnviron()
    assert te['KEY'] == os.environ['KEY']


# Generated at 2022-06-25 13:43:38.487390
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['test'] = 'test'
    test_1 = text_environ_0['test']


# Generated at 2022-06-25 13:43:40.114301
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()

    with pytest.raises(KeyError):
        text_environ['no_key_here']


# Generated at 2022-06-25 13:43:41.696563
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert (text_environ_0['HOME'] == os.environ['HOME'])


# Generated at 2022-06-25 13:43:43.126740
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    temp_var_1 = text_environ_0['HOME']
    # the test should pass
    assert True


# Generated at 2022-06-25 13:43:45.529306
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test function without any argument
    test_case_0()
    # Test function with argument value
    test_case_1()
    # Test function with argument value
    test_case_2()
    # Test function with argument value
    test_case_3()
    # Test function with argument value
    test_case_4()


# Generated at 2022-06-25 13:43:51.540725
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        # Python3:  environ object is already unicode
        assert isinstance(environ, MutableMapping)

        def test__TextEnviron___getitem__0():
            text_environ_0 = _TextEnviron()
            text_environ_0._raw_environ = {'ansible_python_version': '3.6'}
            text_environ_0.encoding = 'utf-8'
            assert text_environ_0['ansible_python_version'] == '3.6'

        def test__TextEnviron___getitem__1():
            text_environ_0 = _TextEnviron()
            text_environ_0._raw_environ = {'home': u'/Users/badger'}