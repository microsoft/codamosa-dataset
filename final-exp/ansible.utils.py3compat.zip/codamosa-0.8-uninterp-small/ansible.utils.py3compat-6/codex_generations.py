

# Generated at 2022-06-25 13:34:18.805825
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__('__test_0')


# Generated at 2022-06-25 13:34:28.815931
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_1 = text_environ_0.__getitem__('USER')
    text_environ_0.encoding = 'iso-8859-1'
    var_2 = text_environ_0.__getitem__('PATH')
    text_environ_0.encoding = 'iso-8859-15'
    var_3 = text_environ_0.__getitem__('PWD')
    text_environ_0.encoding = 'utf-8'
    var_4 = text_environ_0.__getitem__('SHELL')
    text_environ_0.encoding = 'koi8-r'
    var_5 = text_environ_0.__getitem__('LANG')
    text_environ_

# Generated at 2022-06-25 13:34:30.975778
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    var_1 = text_environ_1.__getitem__('PATH')


# Generated at 2022-06-25 13:34:35.652275
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Test __getitem__ function of _TextEnviron
    var_0 = text_environ_0.__getitem__('LANG')
    var_1 = text_environ_0.__getitem__('LANGUAGE')
    var_2 = text_environ_0.__getitem__('ANSIBLE_TEST_FOO')


# Generated at 2022-06-25 13:34:38.724601
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__getitem__('0')


# Generated at 2022-06-25 13:34:43.514965
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    obj_0 = _TextEnviron()
    val_0 = obj_0.__getitem__('LANG')
    val_1 = obj_0['LANG']

    text_environ_1 = _TextEnviron()
    var_0 = text_environ_1['LANG']


# Generated at 2022-06-25 13:34:45.144102
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    var_0 = _TextEnviron().__getitem__('$D')



# Generated at 2022-06-25 13:34:49.565428
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0.__getitem__(text_environ_0.__iter__()[0])
    var_0 = text_environ_0.__delitem__(text_environ_0.__iter__()[0])


# Generated at 2022-06-25 13:34:53.068530
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(encoding='')
    var_0 = text_environ_0.__iter__()
    assert var_0 is not None



# Generated at 2022-06-25 13:34:54.894991
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0.__len__()


# Generated at 2022-06-25 13:34:58.335114
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print("Method: __getitem__")
    text_environ_0 = _TextEnviron(0,0)
    assert text_environ_0.__getitem__(0) == 0


# Generated at 2022-06-25 13:35:07.183861
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test a standard environment variable
    assert environ['PATH'] == os.environ['PATH']
    # Test a unicode variable set to non-unicode text
    assert environ['ANSIBLE_TEST_UNICODE_ENVIRONMENT'] == u'Non-unicode test'
    # Test a unicode variable set to unicode
    assert environ['ANSIBLE_TEST_UNICODE_ENVIRONMENT_2'] == u'Кириллица по-русски'
    # Test a unicode variable set to a unicode string with a surrogate
    assert environ['ANSIBLE_TEST_UNICODE_ENVIRONMENT_3'] == u'PIPE \U0001f3fe'
    # Test a unicode variable set to a unicode string with

# Generated at 2022-06-25 13:35:12.735693
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an instance of _TextEnviron
    text_environ_0 = _TextEnviron()
    # Try getting an item that's in both the local environment and the provided environment
    try:
        assert text_environ_0['PATH'] == os.environ['PATH']
    # In case the key doesn't exist, raise a KeyError
    except KeyError:
        raise KeyError('key does not exist')

test__TextEnviron___getitem__()


# Generated at 2022-06-25 13:35:17.215956
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Create an instance
    text_environ_0 = _TextEnviron()

    # Assign value to the instance's attributes
    text_environ_0._raw_environ = {'name': 'ansible'}
    text_environ_0._value_cache = {}

    # Call method on class
    assert 'ansible' == text_environ_0.__getitem__('name')



# Generated at 2022-06-25 13:35:20.344658
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(env=None)
    text_environ_0.__setitem__('temp', 'bogus')
    var_1 = text_environ_0.__getitem__('temp')
    assert var_1 == 'bogus'
    del text_environ_0


# Generated at 2022-06-25 13:35:22.249461
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    obj_0 = os.system
    result = obj_0
    assert result == os.system


# Generated at 2022-06-25 13:35:24.448313
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert text_environ_0.__getitem__('LANG')
    assert text_environ_0.__getitem__('PATH')


# Generated at 2022-06-25 13:35:31.576052
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    #
    text_environ_0.update({'BADGER_TEST': 'foo'})
    #
    assert text_environ_0['BADGER_TEST'] == 'foo'
    #
    del text_environ_0['BADGER_TEST']
    #
    text_environ_0.update({'BADGER_TEST': 'f00'})
    #
    text_environ_0.update({'BADGER_TEST': 'foo'})
    #
    assert text_environ_0['BADGER_TEST'] == 'foo'

#
# (c) 2018, Toshio Kuratomi <a.badger@gmail.com>
# GNU General Public License v3.0+ (see COP

# Generated at 2022-06-25 13:35:40.638235
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from os import environ
    from sys import getfilesystemencoding
    from ansible.module_utils.six import PY3
    text_environ_0 = _TextEnviron(environ)
    str_0 = 'LC_COLLATE'
    if (str_0 in text_environ_0):
        str_1 = text_environ_0[str_0]
        text_1 = to_text(str_1, errors='surrogate_or_strict', nonstring='strict', encoding='utf-8')
        print(text_1)
    if (PY3):
        str_1 = text_environ_0[str_0]

# Generated at 2022-06-25 13:35:42.767315
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert text_environ_1['ANSIBLE_CONFIG'] is not None


# Generated at 2022-06-25 13:35:52.983122
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test with byte string
    byte_environ = {b"ANSIBLE_MODULE_ARGS": b'{"test": "value"}',
                    b"OTHER_ARGS": b'{"test": "value"}',
                    b"EMPTY_ARGS": b'{}',
                    b"NULL_ARGS": b'null'}
    test_environ = _TextEnviron(byte_environ)
    assert test_environ[b"ANSIBLE_MODULE_ARGS"] == '{"test": "value"}'
    assert test_environ[b"OTHER_ARGS"] == '{"test": "value"}'
    assert test_environ[b"EMPTY_ARGS"] == '{}'
    assert test_environ[b"NULL_ARGS"] == 'null'

    # Test with text string
   

# Generated at 2022-06-25 13:35:56.349779
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    expected0 = 'bar'
    actual_value0 = text_environ_0.get('FOO')
    assert actual_value0 == expected0, "%s != %s" % (actual_value0, expected0)
    #    assert text_environ_0['FOO'] == 'bar'


# Generated at 2022-06-25 13:35:58.629286
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_0 = text_environ_0['SHELL']
    assert var_0 is not None


# Generated at 2022-06-25 13:36:07.953007
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__(u'ENV') == u'Value'
    assert text_environ_0.__getitem__(u'ENV') == u'Value'
    assert text_environ_0.__getitem__(u'ENV') == u'Value'
    assert text_environ_0.__getitem__(u'ENV') == u'Value'
    assert text_environ_0.__getitem__(u'ENV') == u'Value'
    assert text_environ_0.__getitem__(u'\u1234') == u''
    assert text_environ_0.__getitem__(u'\u1234') == u''
    assert text_environ_0.__

# Generated at 2022-06-25 13:36:12.564455
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['PATH'] == os.environ['PATH']
    else:
        # In Python 2, os.environ returns bytestrings
        assert environ['PATH'] == os.environ['PATH'].decode(sys.getfilesystemencoding(),
                                                            'surrogate_or_strict')


# Generated at 2022-06-25 13:36:17.263440
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Check if the environment variables 'PATH' and 'SHELL' are text on Python3
    assert isinstance(environ['PATH'], text_type)
    assert isinstance(environ['SHELL'], text_type)

test_case_0()
test__TextEnviron___getitem__()

# Generated at 2022-06-25 13:36:26.143457
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Creating a new environment to test with
    raw_environ = dict(os.environ)
    new_value = "testing"
    # make sure that the key we're going to test with isn't already in our environment
    if 'ANSIBLE_TEST_ENV_KEY' in raw_environ:
        del raw_environ['ANSIBLE_TEST_ENV_KEY']
    text_environ_0._raw_environ.update(raw_environ)
    # Now that the base environment is set, start the test
    # Test for the case where a new key gets set
    text_environ_0.__setitem__('ANSIBLE_TEST_ENV_KEY', new_value)

# Generated at 2022-06-25 13:36:27.956647
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == os.environ['PATH']
    assert environ['PATH'] == os.getenv('PATH')


# Generated at 2022-06-25 13:36:34.726597
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Verify the proper cache keys are being used
    text_environ_0._raw_environ = {b'TEST1': b'\x00\x01\x02', b'TEST2': b'\xF0\xF1\xF2'}
    text_environ_0._value_cache = {to_text(b'TEST1'): 'test1', to_text(b'TEST2'): 'test2'}
    # We want to assert that the text_environ_0._value_cache is being used
    assert text_environ_0['TEST1'] == 'test1'
    assert text_environ_0['TEST2'] == 'test2'

    # We'll test the cache resetting path later in test_

# Generated at 2022-06-25 13:36:44.428886
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class TestClass:
        text_environ_0 = None
        result = None

        def __init__(self):
            self.test_case_0()
            self.test__TextEnviron___getitem__()

        def test_case_0(self):
            # TestCase 0
            self.text_environ_0 = _TextEnviron()

        def test__TextEnviron___getitem__(self):
            # TestCase __getitem__
            if sys.version_info < (3, 0):
                self.result = self.text_environ_0.__getitem__(b'PATH')
            else:
                self.result = self.text_environ_0.__getitem__('PATH')
            text_environ_0 = self.text_environ_0
            results = self.result


# Generated at 2022-06-25 13:36:50.485737
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a _TextEnviron instance
    text_environ_0 = _TextEnviron()
    # Verify that we can get a value from the instance
    result_0 = text_environ_0['PATH']


# Generated at 2022-06-25 13:36:57.283001
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    
    # 1
    try:
        text_environ_0["1"]
    except KeyError as error0:
        pass
    else:
        raise Exception("Unreachable")
    
    # 2
    try:
        text_environ_0[""]
    except KeyError as error1:
        pass
    else:
        raise Exception("Unreachable")
    
    # 3
    result_2 = text_environ_0["PATH"]
    
    assert result_2 == os.environ["PATH"]
    
    # 4
    common_1_3 = os.getcwd()

# Generated at 2022-06-25 13:37:01.153443
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert text_environ_1['PATH'] is not None
    text_environ_1['foo'] = 'bar'
    assert text_environ_1['foo'] == 'bar'


# Generated at 2022-06-25 13:37:04.890322
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    str_0 = text_environ_0.__getitem__('SSSSSSSSSSSSSS')
    assert str_0 == 'SSSSSSSSSSSSSS'


# Generated at 2022-06-25 13:37:08.325138
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    text_environ_1['key_0'] = 'value_0'
    assert text_environ_1.__getitem__('key_0') == 'value_0'


# Generated at 2022-06-25 13:37:13.636078
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    def __getitem__(self, key):
        value = self._raw_environ[key]
        if PY3:
            return value
        # Cache keys off of the undecoded values to handle any environment variables which change
        # during a run
        if value not in self._value_cache:
            self._value_cache[value] = to_text(value, encoding=self.encoding,
                                               nonstring='passthru', errors='surrogate_or_strict')
        return self._value_cache[value]


# Generated at 2022-06-25 13:37:14.716385
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == '/root'


# Generated at 2022-06-25 13:37:21.380699
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # set up initial environment
    os.environ[to_bytes('ENVIRON_TEST_KEY', 'utf-8')] = to_bytes('test_env', 'utf-8')
    text_environ_0 = _TextEnviron()
    assert text_environ_0.__getitem__(to_text('ENVIRON_TEST_KEY', 'utf-8')) == to_text('test_env', 'utf-8')



# Generated at 2022-06-25 13:37:23.742304
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_1 = _TextEnviron()
    assert text_environ_1[u'LANG'] == u'en_US.UTF-8'



# Generated at 2022-06-25 13:37:27.926006
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(encoding='utf-8')
    assert text_environ_0['PWD'] == '/home/toshio/bin/ansible-scripts'
    assert text_environ_0._value_cache['/home/toshio/bin/ansible-scripts'] == '/home/toshio/bin/ansible-scripts'


# Generated at 2022-06-25 13:37:35.555060
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert 'HOME' in environ
    assert environ['HOME']



# Generated at 2022-06-25 13:37:36.451566
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass



# Generated at 2022-06-25 13:37:46.243550
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # No error when retrieving environment variables that
    # are set to text
    text_environ = _TextEnviron()

    # Done in __init__ too
    text_environ['PY3'] = str(PY3)
    assert text_environ['PY3'] == str(PY3)

    # Ensure that retrieving a value that is in the cache works
    text_environ._raw_environ['ANSI_BOLD'] = b'\x1b[7m'
    text_environ['ANSI_BOLD'] == '\x1b[7m'

    # Test that retrieving a value that is not in the cache works
    text_environ._raw_environ['ANSI_OFF'] = b'\x1b[27m'

# Generated at 2022-06-25 13:37:50.477157
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    
    text_environ = _TextEnviron()
    
    new_key = 'new_key'
    if new_key in text_environ:
        text_environ.__delitem__(new_key)
    
    new_value = 'new_value'
    text_environ[new_key]= new_value
    
    result = text_environ[new_key]
    assert result == new_value
    
    result_type = type(result)
    expected_type = type(new_value)
    assert result_type == expected_type

# Generated at 2022-06-25 13:37:53.941065
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Test with str(.. -> 'test')
    text_environ_0['ANSIBLE_HOST_KEY_CHECKING'] = 'test'
    assert(text_environ_0['ANSIBLE_HOST_KEY_CHECKING'] == 'test')

# Generated at 2022-06-25 13:38:01.038513
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Try get item for an existing key
    environ['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'
    assert environ['ANSIBLE_TEST_KEY'] == 'ANSIBLE_TEST_VALUE'
    assert isinstance(environ['ANSIBLE_TEST_KEY'], str)

    # Try to get item by a non-existing key
    try:
        test_value = environ['ANSIBLE_NON_EXISTING_KEY']
    except KeyError as exc:
        assert "ANSIBLE_NON_EXISTING_KEY" in str(exc)
    else:
        raise AssertionError("KeyError was not raised. ", test_value)


# Generated at 2022-06-25 13:38:05.554556
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron(env={b'a': b'1'})
    text_environ_0[b'b'] = b'2'
    assert text_environ_0[b'a'] == '1'
    assert text_environ_0[b'b'] == '2'


# Generated at 2022-06-25 13:38:07.574175
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    my_environ = _TextEnviron()
    assert my_environ["HOME"]=="/root"



# Generated at 2022-06-25 13:38:08.014808
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert 0, "Not implemented yet"


# Generated at 2022-06-25 13:38:11.793207
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
#    assert text_environ_0.__getitem__(key = 'HOME')
#    assert text_environ_0.__getitem__(key = 'SHELL')
    assert text_environ_0['HOME']
    assert text_environ_0['SHELL']


# Generated at 2022-06-25 13:38:31.039037
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Test _TextEnviron.__getitem__()"""

    text_environ_0 = _TextEnviron()
    list_0 = list()
    # pass
    for text_environ_0_item_0 in text_environ_0:
        list_0.append(text_environ_0[text_environ_0_item_0])
    # pass
    for list_0_item_0 in list_0:
        print(list_0_item_0)



# Generated at 2022-06-25 13:38:34.054485
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Test with PY2, check if text is returned
    if not PY3:
        assert isinstance(text_environ_0[''], six.text_type)


# Generated at 2022-06-25 13:38:35.995449
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    x = text_environ_0.__getitem__('')

# Generated at 2022-06-25 13:38:37.741092
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    environ['a'] = '1'
    assert environ['a'] == '1'


# Generated at 2022-06-25 13:38:39.317307
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert text_environ_0.__getitem__(os.environ) == 'PATH'


# Generated at 2022-06-25 13:38:49.756212
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test python3
    if PY3:
        os.environ['FOO'] = b'foo'
        assert(environ['FOO'] == 'foo')
    else:
        # Test python2.7
        os.environ['FOO'] = b'\xC3\xA1'
        assert(environ['FOO'] == u'\u00e1')
        # Test python2.7+nonascii
        os.environ['FOO'] = b'\xC3\xA1'
        assert(environ['FOO'] == u'\u00e1')
        # Test python2.7+nonascii+nonutf8 (utf-8 encoded string with non-utf8 data)
        os.environ['FOO'] = u'\u00e1'.encode

# Generated at 2022-06-25 13:38:54.424825
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['lang'] = b'C.UTF-8'
    assert text_environ_0['lang'] == u'C.UTF-8'
    assert hasattr(text_environ_0['lang'], 'encode')
    assert isinstance(text_environ_0['lang'], unicode)


# Generated at 2022-06-25 13:38:56.828347
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test 0
    try:
        text_environ_0 = _TextEnviron()
        key = 'COMPUTERNAME'
        text_environ_0.__getitem__(key)
    except:
        print('Exception caught')


# Generated at 2022-06-25 13:39:03.370906
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Python 2.7
    if sys.version_info[0] < 3:
        assert text_environ_0.__getitem__(
            'LC_MESSAGES'
        ) == 'en_US.UTF-8'

    # Python 3.4+
    if sys.version_info[0] >= 3:
        assert text_environ_0.__getitem__(
            'LC_MESSAGES'
        ) == 'en_US.UTF-8'



# Generated at 2022-06-25 13:39:07.822979
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Assert that __getitem__ raises KeyError on missing key
    try:
        with pytest.raises(KeyError):
            text_environ_0[u'not_a_key']
    except Exception as e:
        print(type(e))
        print(e.message)
        print(e)


# Generated at 2022-06-25 13:39:42.260924
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    __var_0__ = text_environ_0['TEXT']
    __var_0__ = text_environ_0['TEXT']
    __var_0__ = text_environ_0['TEXT']
    __var_0__ = text_environ_0['TEXT']
    __var_0__ = text_environ_0['TEXT']
    __var_0__ = text_environ_0['TEXT']
    __var_0__ = text_environ_0['TEXT']
    __var_0__ = text_environ_0['TEXT']
    __var_0__ = text_environ_0['TEXT']
    __var_0__ = text_environ_0['TEXT']

# Generated at 2022-06-25 13:39:47.218553
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Class instantiation
    text_environ_0 = _TextEnviron()
    # Method call
    res = text_environ_0.__getitem__('PATH')
    if not isinstance(res, str):
        raise AssertionError(res)
    # Check that __getitem__ returned unicode on python2
    if not PY3:
        if not isinstance(res, unicode):
            raise AssertionError(res)
    # Check that __getitem__ returned a str on python3
    if PY3:
        if not isinstance(res, str):
            raise AssertionError(res)

if __name__ == '__main__':
    sys.exit(1)

# Generated at 2022-06-25 13:39:49.332775
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert len(text_environ_0) == os.environ.__len__()


# Generated at 2022-06-25 13:39:52.772382
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    argument_0 = 'DW_JAVA_HOME'
    return_value_0 = text_environ_0.__getitem__(argument_0)
    assert return_value_0 == os.getenv('DW_JAVA_HOME')


# Generated at 2022-06-25 13:39:57.050424
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron()
    os.environ['testing_1'] = '\xff'
    assert type(e['testing_1']) == text
    assert e['testing_1'] == u'\ufffd'
    del os.environ['testing_1']
    assert e['testing_1'] == u'\ufffd'



# Generated at 2022-06-25 13:40:00.238500
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0['LANG']
    text_environ_0['SHELL']
    text_environ_0['HOME']


# Generated at 2022-06-25 13:40:03.665621
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    try:
        text_environ_0.__getitem__('RANDOM')
    except KeyError as exc:
        assert isinstance(exc, KeyError)
    else:
        raise AssertionError('KeyError not raised')


# Generated at 2022-06-25 13:40:06.678420
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['PATH'] == os.environ['PATH']
    else:
        assert environ['PATH'] == os.environ['PATH'].decode(environ.encoding)


# Generated at 2022-06-25 13:40:09.809949
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    text_environ_0 = _TextEnviron()

    # Test
    result = text_environ_0.__getitem__(u'TEST_UNICODE_VARIABLE')

    # Assertion
    assert type(result) == unicode


# Generated at 2022-06-25 13:40:14.372676
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['ANSIBLE_TEST_KEY'].startswith('b\'\xe6\x96\x87\xe5\xad\x97\xef\xbc\x88\xe6\x96\x87\xe5\xad\x97\xef\xbc\x89\'')
    else:
        assert environ['ANSIBLE_TEST_KEY'].startswith(u'b\'\u6587\u5b57\uff08\u6587\u5b57\uff09\'')

# Generated at 2022-06-25 13:41:14.023852
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test method _TextEnviron.__getitem__()
    """
    text_environ_0 = _TextEnviron()
    pytest.xfail("Could not test method _TextEnviron.__getitem__()")



# Generated at 2022-06-25 13:41:15.643073
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert text_environ_0.__getitem__("PATH") == environ["PATH"]


# Generated at 2022-06-25 13:41:17.953682
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError):
        text_environ_0.__getitem__('s')


# Generated at 2022-06-25 13:41:27.282174
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['ADAPTER']
    environ['ALLUSERSPROFILE']
    environ['APPDATA']
    environ['CommonProgramFiles']
    environ['COMPUTERNAME']
    environ['ComSpec']
    environ['GLADE_PIXMAP_PATH']
    environ['GNOME_KEYRING_CONTROL']
    environ['GNOME_KEYRING_PID']
    environ['GTK_IM_MODULE']
    environ['LOCALAPPDATA']
    environ['LOGONSERVER']
    environ['Microsoft.NET']
    environ['MOZ_PLUGIN_PATH']
    environ['NUMBER_OF_PROCESSORS']
    environ['OS']
    environ['Path']
    environ['PATHEXT']

# Generated at 2022-06-25 13:41:34.465006
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Initializing with a Python 2 None
    if PY3:
        text_environ_1 = _TextEnviron(env=None)
    else:
        text_environ_1 = _TextEnviron(env=None)
    assert text_environ_1.encoding == sys.getfilesystemencoding()

    # Initializing with a non-None value
    if PY3:
        text_environ_2 = _TextEnviron(env=environ)
    else:
        text_environ_2 = _TextEnviron(env=environ)
    assert text_environ_2.encoding == sys.getfilesystemencoding()


# Generated at 2022-06-25 13:41:35.859878
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    with pytest.raises(KeyError):
        text_environ_0 = _TextEnviron()
        text_environ_0.__getitem__('PWD')


# Generated at 2022-06-25 13:41:37.120808
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    with pytest.raises(KeyError):
        text_environ_0.__getitem__('HOME')


# Generated at 2022-06-25 13:41:47.588145
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        text_environ_0 = _TextEnviron()
        result_0 = text_environ_0[text_environ_0.encoding]
        text_environ_1 = _TextEnviron()
        result_1 = text_environ_1[text_environ_1.encoding]
        text_environ_2 = _TextEnviron()
        result_2 = text_environ_2['abc']
        assert len(result_0) > 0
        assert ':' in result_0
        assert len(result_1) > 0
        assert ':' in result_1
        assert len(result_2) > 0
        assert ':' in result_2
    else:
        text_environ_3 = _TextEnviron()
        result_3 = text_environ_3

# Generated at 2022-06-25 13:41:55.722478
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    # Assert __getitem__ is able to handle all the following by returning a
    # unicode object
    #
    # 1. Simple ASCII-8BIT encoded string
    # 2. UTF-8 encoded string
    # 3. UTF-16 encoded string
    # 4. UTF-32 encoded string
    # 5. Unicode string
    # 6. Boolean
    # 7. None
    # 8. Float
    # 9. Same as above, but with encoding=None
    # 10. Same as above, but with errors=ignore

    # 1. Simple ASCII-8BIT encoded string
    # https://en.wikipedia.org/wiki/Octet_(computing)#Character_encodings_using_8_bits
    # The ASCII-8BIT encoding is also known as ISO-8859-1 encoding

# Generated at 2022-06-25 13:41:57.913393
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    text_environ_0.__getitem__('CI_COV')
    return


# Generated at 2022-06-25 13:43:06.926877
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    var_1 = None
    var_1 = text_environ_0.__getitem__('SHELL')
    assert var_1.startswith('/bin')


# Generated at 2022-06-25 13:43:13.932692
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Check that a text environ is returned for a unicode key
    assert isinstance(environ[u'HOME'], text_type)
    # Check that a text environ is returned for a byte key
    assert isinstance(environ[b'HOME'], text_type)
    # Check that a text environ is returned for a byte key
    assert isinstance(environ[b'HOME'], text_type)
    # Check that a text environ is returned for a pre-encoded byte key
    # (this is what is passed to the module if a variable evaluates to the str type)
    assert isinstance(environ[to_bytes('HOME')], text_type)



# Generated at 2022-06-25 13:43:22.623373
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with Python 2
    if not PY3:
        # Test with bytes in the environment
        text_environ_0 = _TextEnviron({b'key': b'value'})
        assert text_environ_0[b'key'] == 'value'
        # Test with text in the environment
        text_environ_1 = _TextEnviron({'key': 'value'})
        assert text_environ_1['key'] == 'value'
        # Test that we can handle non-utf8 unicode in the environment
        text_environ_2 = _TextEnviron({b'key': to_bytes('\xe9', encoding='iso8859-1')})
        assert text_environ_2[b'key'] == '\xe9'
        # Test that we can change the encoding
        text_environ_

# Generated at 2022-06-25 13:43:31.688238
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    if PY3:
        print("Python 3")
        os.environ["TEST_VAR_1"] = "value_1"
        assert "value_1" == text_environ_0["TEST_VAR_1"]
        assert os.environ["TEST_VAR_1"] == text_environ_0["TEST_VAR_1"]

        os.environ["TEST_VAR_2"] = "\u043f\u0440\u0438\u0432\u0435\u0442 \"\u043a\u043e\u0440\u0438\u0441\u0442\u0430\u043d\u0430\u043b\u0430\""

# Generated at 2022-06-25 13:43:33.812374
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert(text_environ_0.__getitem__('PATH') == os.environ['PATH'])


# Generated at 2022-06-25 13:43:35.151442
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    value = text_environ_0[os.environ.keys()[0]]


# Generated at 2022-06-25 13:43:41.231407
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert to_text(os.environ.get('PYTHONIOENCODING')) == environ.get('PYTHONIOENCODING')
        assert to_text(os.environ.get('abc')) == environ.get('abc')
        assert to_text('abc') == environ.get('abc')
    else:
        # Make sure Python3-style environment settings are passed through to _TextEnviron class
        assert to_text(os.environ.get('PYTHONIOENCODING')) == environ.get('PYTHONIOENCODING')
        assert to_text(os.environ.get('abc')) == environ.get('abc')
        assert to_text('abc') == environ.get('abc')
        # Make sure non-

# Generated at 2022-06-25 13:43:48.643470
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a key that is already in the environment
    assert environ['HOME'] == os.environ['HOME']
    # Test that casting from bytes to text works
    if not PY3:
        environ['ANSIBLE_TEST_STRING_FROM_BYTES'] = 'b"Hi!  We\'re bytes!"'
        text = environ['ANSIBLE_TEST_STRING_FROM_BYTES']
        assert text == "Hi!  We're bytes!"
        # Test that casting from str to text works
        environ['ANSIBLE_TEST_STRING_FROM_STR'] = 'u"Hello!  We\'re unicode"'
        text = environ['ANSIBLE_TEST_STRING_FROM_STR']
        assert text == "Hello!  We're unicode"

# Unit

# Generated at 2022-06-25 13:43:54.969016
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        text_environ_1 = _TextEnviron()['TEST_TEXT_ENVIRON_1']
    except KeyError:
        text_environ_1 = 'TEST_TEXT_ENVIRON_1'
    text_environ_1 = to_text(text_environ_1, encoding='utf-8', nonstring='passthru',
                             errors='surrogate_or_strict')
    assert text_environ_1 == to_text(os.environ['TEST_TEXT_ENVIRON_1'])
    text_environ_1 = to_text(os.environ['TEST_TEXT_ENVIRON_1'], encoding='utf-8', nonstring='passthru',
                             errors='surrogate_or_strict')
    assert text

# Generated at 2022-06-25 13:43:56.296525
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ_0 = _TextEnviron()
    assert text_environ_0[('cat', 'dog', 'goat')] is None
