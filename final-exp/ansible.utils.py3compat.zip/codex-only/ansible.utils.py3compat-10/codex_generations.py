

# Generated at 2022-06-23 14:27:52.855489
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron({b'a': b'b',to_bytes('c'): to_bytes('d')}, encoding=to_bytes('utf-8'))
    assert environ == {'a': 'b', 'c': 'd'}
    environ = _TextEnviron(env={'a': 'b', to_bytes('c'): 'd'}, encoding='utf-8')
    assert environ == {'a': 'b', 'c': 'd'}
    environ = _TextEnviron(env=None, encoding='utf-8')
    assert environ == os.environ
    environ = _TextEnviron(env=None, encoding=to_bytes('utf-8'))
    assert environ == os.environ


# Generated at 2022-06-23 14:27:59.093963
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Configures _raw_environ with bytes keys and values
    environ._raw_environ[b'name'] = b'Bob'
    environ._raw_environ[b'age'] = b'30'

    # Retrieve a key from _raw_environ with __getitem__ and test for equality with a
    # unicode string
    assert environ['name'] == u'Bob'
    assert environ['age'] == u'30'



# Generated at 2022-06-23 14:28:04.800780
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # _TextEnviron() should work
    environ = _TextEnviron()

    assert isinstance(environ, _TextEnviron)

    # The first key should be unicode
    for key in environ:
        assert isinstance(key, str)
        break

    # The first value should be unicode
    for value in environ.values():
        assert isinstance(value, str)
        break

# Generated at 2022-06-23 14:28:10.471600
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(env={b'test': b'valu\xc3'}, encoding='utf-8')
    environ.__getitem__('test')
    assert environ._raw_environ[b'test'] == b'valu\xc3'
    assert environ._value_cache[b'valu\xc3'] == u'valu\ufffd'


# Generated at 2022-06-23 14:28:17.123714
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    print("Test to ensure that __delitem__ works properly")
    _environ = _TextEnviron(env={'test': 'test'}, encoding='utf-8')
    print("Checking to see if key is as expected")
    assert 'test' in _environ
    print("Checking to ensure we can delete the key")
    del _environ['test']
    assert 'test' not in _environ


# Generated at 2022-06-23 14:28:21.836503
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    utf_environ = _TextEnviron({'FOO': 'bar', 'BAR': 'foo'}, encoding='utf-8')
    del utf_environ['FOO']
    del utf_environ['BAR']
    assert len(utf_environ) == 0


# Generated at 2022-06-23 14:28:32.150502
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # pylint: disable=unused-variable
    def _test__TextEnviron___setitem__(value, expected):
        # Use a new environment object for each test case
        env = _TextEnviron()
        env['key'] = value
        assert env._raw_environ['key'] == expected

    def test_bytes():
        _test__TextEnviron___setitem__(b'\xff', b'\xff')
        _test__TextEnviron___setitem__(b'\x00\xff', b'\x00\xff')


# Generated at 2022-06-23 14:28:43.267967
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Provided that:
    #    a. class _TextEnviron is instantiated with an environment variable,
    #       which contains only unique values, where:
    #        - each value is a string, which represents a number,
    #        - each value is an unique number
    #
    # When:
    #    a. the method __iter__ is invoked,
    #    b. each iteration value is converted to int,
    #    c. the iteration values are added together
    #
    # Then:
    #    a. the total sum of iteration values will equal the total sum of numbers from 1 to N,
    #       where N is equal to the number of environment variables

    # Given: class _TextEnviron instantiated with environment variable,
    #        which contains only unique values
    s = 1
    for i in range(12):
        en

# Generated at 2022-06-23 14:28:44.662609
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:28:47.887302
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Call the _TextEnviron object created in the top level of this file
    assert len(environ) == len(os.environ)

# Generated at 2022-06-23 14:28:54.604212
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    class _DummyOs(object):
        def __init__(self):
            self.dummy_environ = dict(A=1, B=2, C=3)
        def __getitem__(self, key):
            return self.dummy_environ[key]
        def __setitem__(self, key, value):
            self.dummy_environ[key] = value
        def __iter__(self):
            return iter(self.dummy_environ)
        def __len__(self):
            return len(self.dummy_environ)
    os = _DummyOs()
    test_object = _TextEnviron(os)
    assert len(test_object) == 3


# Generated at 2022-06-23 14:28:58.143053
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ = _TextEnviron()
    environ['key1'] = 'value1'
    del environ['key1']
    assert 'key1' not in environ


# Generated at 2022-06-23 14:29:03.841809
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    test_dict = {
        u'undecodable': b'\xe9',
        u'encodable': u'\xe9',
        u'encodable2': u'\xe9',
        u'nonstring': 123,
    }
    test_env = _TextEnviron(test_dict, encoding='utf-8')
    assert len(test_env) == len(test_dict)


# Generated at 2022-06-23 14:29:04.994279
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:29:10.259305
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-23 14:29:13.845392
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['test_a_key'] = 'test_a_value'
    assert 'test_a_value' == environ['test_a_key']
    del environ['test_a_key']

# Generated at 2022-06-23 14:29:19.264788
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
  # __iter__ of class _TextEnviron may make use of the private member
  # _raw_environ, which is now visible in the global scope of the unit test
  # module. So we make it available as global variable.
  global _raw_environ
  _raw_environ = {"a": "b"}
  assert next(environ.__iter__()) == "a"


# Generated at 2022-06-23 14:29:30.242162
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron({b'key1': b'val1', 'key2': 'val2'}, encoding='utf-8')
    assert environ.encoding == 'utf-8'
    assert environ._raw_environ == {'key1': 'val1', 'key2': 'val2'}
    assert environ._value_cache == {}
    assert environ == {'key1': 'val1', 'key2': 'val2'}
    assert dict(environ) == {'key1': 'val1', 'key2': 'val2'}
    assert len(environ) == 2
    assert environ['key1'] == 'val1'
    assert environ['key2'] == 'val2'


# Unit tests for class _TextEnviron

# Generated at 2022-06-23 14:29:37.439713
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    #
    # os.environ is str on Python3 and bytes on Python2
    #
    if PY3:
        raw_environ = {'foo': 'bar'}
        encoding = 'utf-8'
        test_str = 'bar'
    else:
        raw_environ = {'foo': b'bar'}
        encoding = 'utf-8'
        test_str = u'bar'

    test_environ = _TextEnviron(env=raw_environ, encoding=encoding)
    assert(test_str == test_environ['foo'])

# Generated at 2022-06-23 14:29:45.186770
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({'key1': 'value1', 'key2': 'value2', 'key3': u'value3'})
    assert env['key1'] == 'value1'
    assert env['key2'] == 'value2'
    assert env['key3'] == u'value3'
    assert env[b'key1'] == 'value1', 'key must be text (unicode) type'
    assert env[u'key1'] == 'value1', 'key must be text (unicode) type'


# Generated at 2022-06-23 14:29:55.077529
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    _TextEnviron() -- return text strings instead of byte strings

    We have to pass sys.modules as the 2nd parameter to simulate the way Python will
    do an import of a module.
    """
    test_str = u"à bête bête, quelle étrange sangsue!"
    env = dict(os.environ, UNICODE_STRING=test_str)
    # sys.modules is needed for to_text to find the TextType class
    env_obj = _TextEnviron(env, sys.modules)

    assert env_obj['UNICODE_STRING'] is test_str
    # And from now on, it stays in the cache
    assert env_obj['UNICODE_STRING'] is env_obj['UNICODE_STRING']

# Generated at 2022-06-23 14:30:00.506275
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest
    import os

    with unittest.mock.patch('ansible.module_utils.common.environment.os.environ', {'test': 'value'}):
        test_environ = _TextEnviron()
        assert test_environ['test'] == 'value'

    test_environ = _TextEnviron({'test': b'value'}, encoding='utf-8')
    assert test_environ['test'] == 'value'
    test_environ = _TextEnviron({'test': 'value'}, encoding='utf-8')
    assert test_environ['test'] == 'value'


# Generated at 2022-06-23 14:30:01.906510
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == 0
    assert not len({})



# Generated at 2022-06-23 14:30:05.247094
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    # Create a temporary environment variable and delete it
    name = 'TESTVAR'
    value = 'TESTVALUE'
    environ[name] = value
    del environ[name]

    # Assert that the environment variable has indeed been deleted
    assert name not in environ



# Generated at 2022-06-23 14:30:08.270661
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    env = _TextEnviron()

    assert('PATH' in env)

    del env['PATH']

    assert('PATH' not in env)



# Generated at 2022-06-23 14:30:11.008072
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['SHELL'] = u'bash'
    assert to_text(environ['SHELL']) == u'bash'

# Generated at 2022-06-23 14:30:18.216505
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():

    TEST_VARS = {
        u'VAR1': 'Value1',
        u'VAR2': 'Value2',
        u'VAR3': u'Value3',
    }
    TEST_VARS_ITER = (u'VAR1', u'VAR2', u'VAR3')

    __call__ = environ.__iter__()

    for key in TEST_VARS_ITER:
        found_key = next(__call__)
        assert key == found_key, "%s != %s" % (key, found_key)


# Generated at 2022-06-23 14:30:26.333513
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_environ = _TextEnviron(encoding='utf-8')

    test_value = 'blah'
    test_environ['test'] = test_value
    assert test_environ['test'] == test_value
    assert test_environ._raw_environ['test'] == test_value if PY3 else to_bytes(test_value, encoding='utf-8')

    test_environ['test'] = u'blah'
    assert test_environ['test'] == test_value
    assert test_environ._raw_environ['test'] == test_value if PY3 else to_bytes(test_value, encoding='utf-8')

    test_value2 = u'\u2603'
    test_environ['test'] = test_value2

# Generated at 2022-06-23 14:30:30.908530
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = os.environ
    if PY3:
        assert set(environ) == set(_TextEnviron(env)._raw_environ)
    else:
        assert set(environ) == set(_TextEnviron(env)._raw_environ.keys())


# Generated at 2022-06-23 14:30:34.840704
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ.clear()
    environ['TEST_ENV_DELITEM'] = 'fubar'
    assert len(environ) == 1
    del environ['TEST_ENV_DELITEM']
    assert len(environ) == 0


# Generated at 2022-06-23 14:30:38.120000
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test __getitem__ method of _TextEnviron class
    """
    my_env = _TextEnviron({b'foo': 'bar'})
    assert my_env.encoding == 'utf-8'
    assert my_env[b'foo'] == u'bar'
    assert my_env[u'foo'] == u'bar'



# Generated at 2022-06-23 14:30:46.251879
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import unittest
    import pdb

    class __TextEnviron___iter__TestCase(unittest.TestCase):
        def test__init__(self):
            # pdb.set_trace()
            env = _TextEnviron(env={'a': 'b'})
            self.assertEqual(len(env), 1)

    suite = unittest.TestSuite()
    suite.addTest(__TextEnviron___iter__TestCase('test__init__'))
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    # if result.failures or result.errors:
    #     import pdb
    #     pdb.set_trace()

# Generated at 2022-06-23 14:30:49.747405
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import os

    assert len(environ) == len(os.environ)
    environ.clear()
    assert len(environ) == 0
    environ['test'] = 'test'
    assert len(environ) == 1


# Generated at 2022-06-23 14:31:00.170626
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['test_var'] = u'TEST_VAR=TEST_VALUE'
    os.environ['test_var_bytes'] = 'TEST_VAR_BYTES=TEST_VALUE_BYTES'
    os.environ['test_var_bytes_gb2312'] = u'TEST_VAR_BYTES_GB2312=\u6d4b\u8bd5'
    os.environ['test_var_bytes_broken'] = u'TEST_VAR_BYTES_BROKEN=\u6d4b'
    assert environ['test_var'] == u'TEST_VALUE'
    assert environ['test_var_bytes'] == u'TEST_VALUE_BYTES'

# Generated at 2022-06-23 14:31:01.776826
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert(len(environ)) == len(os.environ)

# Generated at 2022-06-23 14:31:09.632639
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # noinspection PyUnusedLocal
    def _gettext_mock(input, encoding='utf-8', nonstring=None, errors='surrogate_or_strict'):
        return input

    # noinspection PyUnusedLocal
    def _bytestext_mock(input, encoding='utf-8', nonstring=None, errors='surrogate_or_strict'):
        return input

    # noinspection PyUnusedLocal
    def _len_mock(input):
        return len(input)

    # noinspection PyUnusedLocal
    def _iter_mock(input):
        return input.__iter__()

    # noinspection PyUnusedLocal
    def _iteritems_mock(input):
        return input.items()


# Generated at 2022-06-23 14:31:15.063307
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_var = '_ansible_test_variable'
    if test_var in environ:
        del environ[test_var]
    environ[test_var] = 'this is a test'
    assert test_var in environ
    del environ[test_var]
    assert test_var not in environ


# Generated at 2022-06-23 14:31:16.665049
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:31:24.815519
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Populate os.environ with a mixture of utf-8 and latin-1 byte strings
    os.environ[u'mixed ascii'.encode('ascii')] = u'mixed €'.encode('utf-8')
    os.environ[u'all ascii'.encode('ascii')] = u'all ascii'.encode('ascii')
    os.environ[u'all utf-8'.encode('ascii')] = u'all €'.encode('utf-8')

# Generated at 2022-06-23 14:31:35.853023
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test valid string
    test_dict = {}
    my_env = _TextEnviron(env=test_dict)
    my_env['key'] = 'value'
    assert test_dict == {'key': b'value'}
    # Test dict
    test_dict = {}
    my_env = _TextEnviron(env=test_dict)
    my_env['key'] = {}
    assert test_dict == {'key': b'{}'}
    # Test list
    test_dict = {}
    my_env = _TextEnviron(env=test_dict)
    my_env['key'] = []
    assert test_dict == {'key': b'[]'}
    # Test tuple
    test_dict = {}
    my_env = _TextEnviron(env=test_dict)
   

# Generated at 2022-06-23 14:31:41.151856
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Test if input values are properly encoded
    """
    text = u'Some çharaçters'
    encoded = text.encode('utf-8')
    assert environ['key'] == u''
    environ['key'] = text
    assert environ._raw_environ['key'] == encoded


# Generated at 2022-06-23 14:31:47.784283
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ_test = _TextEnviron()
    assert b'key' not in environ_test._raw_environ
    environ_test['key'] = u'value'
    assert b'key' in environ_test._raw_environ
    assert environ_test._raw_environ[b'key'] == b'value'
    value = environ_test._raw_environ[b'key']
    assert isinstance(value, bytes)


# Generated at 2022-06-23 14:31:54.524593
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    from tempfile import mkdtemp
    import shutil

    test_env = os.environ.copy()
    del test_env['PYTHONHASHSEED']

    tmp = mkdtemp()
    try:
        test_environ = _TextEnviron(test_env.keys(), encoding=test_env.values())
        del test_environ['TMPDIR']
        assert 'TMPDIR' not in test_environ
    finally:
        shutil.rmtree(tmp)



# Generated at 2022-06-23 14:31:56.336720
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Test for len in _TextEnviron of Class _TextEnviron
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:32:05.447284
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['ansible_python_interpreter'] = '/opt/ansible/bin/python'
    # Since ansible_python_interpreter should be set in the test environment, we know the
    # encoding is utf-8 for this directory
    assert environ['ansible_python_interpreter'] == '/opt/ansible/bin/python'
    # This one is unset so we'll get native type
    assert isinstance(environ['no_such_key'], str)
    # Disable caching
    environ._value_cache = None
    assert isinstance(environ['ansible_python_interpreter'], str)

# Generated at 2022-06-23 14:32:07.464068
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert to_bytes(u'1') == environ.__getitem__('LANG')
    assert to_bytes(u'1') == environ.__getitem__('LANG')

# Generated at 2022-06-23 14:32:17.607044
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test round trip with new object and object returned by init
    raw_environ = {to_bytes('one'): to_bytes('1'), to_bytes('two'): to_bytes('2')}
    te = _TextEnviron(raw_environ, encoding='utf-8')
    assert te._raw_environ == raw_environ
    assert te._value_cache == {}
    assert te.encoding == 'utf-8'
    # Test round trip with unicode values on Python2 - no caching
    if not PY3:
        for key in te:
            assert to_text(key) == te[key]
    # Test round trip with unicode values on Python3
    if PY3:
        for key in te:
            assert key == te[key]
    # Test round trip with surrogate escapes on Python2


# Generated at 2022-06-23 14:32:26.299037
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import pytest
    env = {'key1': 'value1'}
    # Test get a text without encoding
    text_environ = _TextEnviron(env=env)
    text1 = text_environ['key1']
    assert(isinstance(text1, str))
    assert(text1 == 'value1')
    # Test get a text with encoding
    text_environ = _TextEnviron(env=env, encoding='ascii')
    with pytest.raises(UnicodeDecodeError):
        text2 = text_environ['key1']

# Unit test of method __setitem__ of class _TextEnviron

# Generated at 2022-06-23 14:32:37.697154
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test for properly handling nonstring types
    environ_ = _TextEnviron({None: 'null'}, encoding='utf-8')
    assert list(environ_.keys()) == ['None']
    assert list(environ_.values()) == ['null']
    assert list(environ_.items()) == [(u'None', u'null')]

    # Test for properly decoding the values of env
    if PY3:
        environ_ = _TextEnviron({to_bytes('uni', encoding='utf-16'):
                                 to_bytes('ding', encoding='utf-16')}, encoding='utf-16')
    else:
        environ_ = _TextEnviron({to_bytes('uni', encoding='utf-16'):
                                 to_bytes('ding', encoding='utf-16')})

    assert list(environ_.keys())

# Generated at 2022-06-23 14:32:38.664805
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert 'HOME' in environ

# Generated at 2022-06-23 14:32:40.897302
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ_obj = _TextEnviron()
    assert len(environ_obj) == len(environ)



# Generated at 2022-06-23 14:32:43.506400
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    textEnviron = _TextEnviron()
    len_textEnviron = len(textEnviron)
    assert len_textEnviron is not None


# Generated at 2022-06-23 14:32:45.712889
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ['FOO'] = 'bar'
    assert len(environ) == 1
    del os.environ['FOO']


# Generated at 2022-06-23 14:32:48.333632
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({b'TEST': b'test'})
    # Delete key from object
    del env['TEST']
    # Ensure key has been deleted
    assert 'TEST' not in env

# Generated at 2022-06-23 14:32:56.169483
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """
    Test to assure that the method '__iter__' of class '_TextEnviron' is returning module 'six'
    object 'text_type' in case of Python 2 and 'str' in case of Python 3.
    """
    # Ansible has requirements.txt to install everything under Python 2 and Python 3,
    # but 'six' is already installed as a package in Python 2 and as a part of Python 3.
    # It does not support 'from __future__ import print_function'.
    # I am skipping this test for now.
    pass


# Generated at 2022-06-23 14:33:06.246748
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import copy
    import random

    assert isinstance(environ, MutableMapping)
    assert hasattr(environ, '__iter__')
    assert hasattr(environ, '__next__')

    # Start with an empty environment
    environ.clear()
    # Inject random number of random keys.
    for k in range(random.randint(1, 100)):
        environ[str(k)] = str(k)
        assert k in environ

    assert len(environ) == len([k for k in environ])

    # Create a copy of the dict and check it matches
    dict_copy = copy.copy(environ)
    assert environ == dict_copy


# Generated at 2022-06-23 14:33:11.482793
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ.clear()
    environ['foo'] = 'bar'
    assert environ['foo'] == 'bar'

    environ['baz'] = u'ö'
    assert environ['baz'] == u'ö'

    environ['baz'] = u'香港'
    assert environ['baz'] == u'香港'

    environ['baz'] = u'\xe4'
    assert environ['baz'] == u'ä'


# Generated at 2022-06-23 14:33:20.130674
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    os.environ['ANSIBLE_TEXT_ENVIRON_TEST'] = '123'
    test_environ = _TextEnviron(encoding='utf-8')
    assert test_environ['ANSIBLE_TEXT_ENVIRON_TEST'] == '123'

    # Test caching of values
    if PY3:
        test_environ._raw_environ[b'ANSIBLE_TEXT_ENVIRON_TEST'] = 'abc'
        assert test_environ['ANSIBLE_TEXT_ENVIRON_TEST'] == 'abc'
    else:
        test_environ._raw_environ[b'ANSIBLE_TEXT_ENVIRON_TEST'] = 'abc'
        assert test_environ['ANSIBLE_TEXT_ENVIRON_TEST'] == '123'

   

# Generated at 2022-06-23 14:33:22.442618
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # _TextEnviron object
    env = _TextEnviron(encoding='utf-8')
    assert 'PATH' in env


# Generated at 2022-06-23 14:33:32.348275
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    A mocked environment is created containing a unicode character in the enviroment variable
    TEST_GET_ITEM_UNICODE_CHAR
    """
    # Mock the environment
    environ._raw_environ = {
        'TEST_GET_ITEM_UNICODE_CHAR': u'\u2714'
    }
    assert environ._raw_environ.get('TEST_GET_ITEM_UNICODE_CHAR'), u'\u2714'

    # This is the expected result
    expected_result = '\u2714'

    assert environ.__getitem__('TEST_GET_ITEM_UNICODE_CHAR') == expected_result


# Generated at 2022-06-23 14:33:39.856806
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():

    # Test __setitem__()
    os.environ.clear()
    # Non-ascii character
    os.environ['NON_ASCII_CHARACTER'] = '№'
    # Integer
    os.environ['INTEGER'] = 100
    # Non-ascii string and integer
    os.environ['NON_ASCII_STRING_AND_INTEGER'] = '№100'
    # Failing UTF8 string
    os.environ['FAILING_UTF8_STRING'] = b'\xf0\xf1\xf2\xf3\xf4\xf5'
    # Empty string
    os.environ['EMPTY_STRING'] = ''
    # Empty byte string
    os.environ['EMPTY_BYTE_STRING'] = b''


# Generated at 2022-06-23 14:33:42.498608
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron({'a': 'b'})
    assert len(environ) == 1


# Generated at 2022-06-23 14:33:54.128006
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from tempfile import TemporaryFile
    from os import fdopen, close

    for item in ['foo', u'東京', '東京']:
        # The standard os.environ object cannot be modified as it is read-only
        # so we have to create a synthetic one
        actual_output = TemporaryFile('w+b')
        os.environ = environ
        os.environ['foo'] = item
        print(os.environ['foo'], file=fdopen(actual_output.fileno(), 'w'))
        close(actual_output.fileno())

        expected_output = TemporaryFile('w+b')
        print(item, file=fdopen(expected_output.fileno(), 'wb'))
        close(expected_output.fileno())

        assert actual_output.read() == expected_

# Generated at 2022-06-23 14:33:58.724154
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    e = _TextEnviron()
    e['foo'] = 'bar'
    assert e._raw_environ['foo'] == b'bar'
    try:
        e['foo'] = u'baz'
    except UnicodeEncodeError:
        pass
    else:
        assert False, '_TextEnviron failed to properly handle setting a unicode value'

# Generated at 2022-06-23 14:34:10.399356
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['foo'] = u"\u0F00"
    assert to_text(environ._raw_environ['foo'], encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict') == u"\u0F00"
    environ['foo'] = 'ascii str'
    assert to_text(environ._raw_environ['foo'], encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict') == 'ascii str'
    environ['foo'] = u'unicode u'
    assert to_text(environ._raw_environ['foo'], encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict') == 'unicode u'

# Generated at 2022-06-23 14:34:19.887514
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron({b'TEST_VAR1': b'ascii: \xe2\x80\xa2',
                                 b'TEST_VAR2': b'\xed\x9a\xa8\xed\xa0\xb8',
                                 b'TEST_VAR3': b'bytes: \xe2\x80\xa2'})

    assert text_environ[b'TEST_VAR1'] == u'ascii: •'
    assert text_environ[b'TEST_VAR2'] == u'합함'
    assert text_environ[b'TEST_VAR3'] == u'bytes: •'


# Generated at 2022-06-23 14:34:30.774347
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    if PY3:
        return
    # Constructor called without arguments
    test_env_object = _TextEnviron()
    # Accessing a key/value pair through `environ`
    assert test_env_object[to_bytes('HOME')].endswith(u'/.ansible')
    # Accessing a key/value pair directly through `os.environ`
    assert os.environ[to_bytes('HOME')].endswith(b'/.ansible')
    # Constructor called with argument `env`
    test_env_object = _TextEnviron(env={'test1': u'dummy'})
    # Accessing a key/value pair through `test_env_object`
    assert test_env_object[u'test1'] == u'dummy'
    # Constructor called with argument `env` and `

# Generated at 2022-06-23 14:34:31.932671
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:34:43.050274
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    def get_str_type():
        if PY3:
            return str
        else:
            return unicode

    # Make sure the class doesn't break when env=None and encoding=None
    str_type = get_str_type()
    for key in ['HOME', 'ANSIBLE_TEST_ENCODING']:
        assert isinstance(environ[key], str_type), 'env[%s] did not decode properly' % key

    test_env = _TextEnviron(encoding='utf-8')
    str_type = get_str_type()
    for key in ['HOME', 'ANSIBLE_TEST_ENCODING']:
        assert isinstance(test_env[key], str_type), 'test_env[%s] did not decode properly' % key

# Generated at 2022-06-23 14:34:51.644334
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    test_ps1 = '$ '
    environ[b'PS1'] = test_ps1
    # We should be able to read the original value
    assert environ['PS1'] == test_ps1
    # We should be able to read the value as text
    assert environ[b'PS1'] == test_ps1
    # We should be able to set the value as text
    test_ps1 = test_ps1 + ' '
    environ['PS1'] = test_ps1
    assert environ[b'PS1'] == test_ps1
    # We should be able to set the value as text
    test_ps1 = test_ps1 + ' '
    environ['PS1'] = test_ps1
    assert environ[b'PS1'] == test_ps1
    # We should be able to

# Generated at 2022-06-23 14:34:56.164328
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    class TestTextEnviron(_TextEnviron):
        def __init__(self, env=None):
            if env is None:
                env = {'str': 'str',
                       'bytes': b'bytes',
                       'non-ascii': b'\x80\xff',
                       'unicode': u'unicode',
                       'non-ascii-unicode': u'\U0001F4A9',
                       }
            super(TestTextEnviron, self).__init__(env)

    test_env = TestTextEnviron()
    assert test_env['str'] == 'str'
    assert test_env['bytes'] == 'bytes'
    assert test_env['non-ascii'] == '\x80\xff'
    assert test_env['unicode'] == 'unicode'
    assert test_

# Generated at 2022-06-23 14:35:01.715422
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Create a _TextEnviron object.
    te = _TextEnviron()

    # Get the length of the underlying dict-like object.
    dict_len = len(te._raw_environ)

    # Get the length of the _TextEnviron object.
    te_len = len(te)

    assert te_len == dict_len

# Generated at 2022-06-23 14:35:04.100534
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron()

    assert isinstance(env.__iter__(), type(iter([])))

    for key in env:
        assert key in env



# Generated at 2022-06-23 14:35:08.852713
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Set a value with a unicode key
    environ[u'unicodē'] = u'valuē'
    assert u'unicodē' in environ

    # Check that we get the value back
    assert environ[u'unicodē'] == u'valuē'

    # Delete the key
    del environ[u'unicodē']

    # Make sure the key is no longer in the environment
    assert u'unicodē' not in environ


# Generated at 2022-06-23 14:35:18.766871
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from six.moves import builtins
    from functools import partial

    test_dict = {b'test_key1': b'value1', b'test_key2': b'value2', b'test_key3': b'value3'}
    mock_environ = _TextEnviron(env=test_dict)

    # Check that __iter__ of _TextEnviron when called iterates over converted values of
    # raw_environ
    dict_iter = dict.__iter__
    dict_iter_partial = partial(dict_iter, test_dict)
    with builtins.mock.patch.object(test_dict, '__iter__', return_value=dict_iter_partial()) as mock_dict_iter:
        for key in mock_environ:
            mock_dict_iter.assert_called_once_

# Generated at 2022-06-23 14:35:20.543229
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    if len(environ) != len(os.environ):
        raise AssertionError()


# Generated at 2022-06-23 14:35:22.388675
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    for key in environ:
        assert (type(key) is str)



# Generated at 2022-06-23 14:35:28.509748
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    try:
        from unittest import mock
    except ImportError:
        mock = None

    if mock is None:
        # TODO: Skip this test
        return

    test_env = {
        'no_value_change': 'no_value_change',
        'changes_to_value': 'unicode_string',
        'value_with_non_ascii': b'\xe2\x98\x84'.decode('utf-8'),  # snowman
        'byte_string': b'\xe2\x98\x84',  # snowman
        'unicode_string': '\u2603',  # snowman
        'byte_string_with_non_ascii': b'\xe2\x98\x84with_non_ascii'  # snowman
    }
   

# Generated at 2022-06-23 14:35:38.832709
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Need to mark this as a unit test so that assertRaises is available
    # pylint: disable=too-few-public-methods
    class UnitTest_TextEnviron___getitem__:
        def test_getitem_with_string_value(self):
            # pylint: disable=no-member
            environ['TEST'] = 'test'
            assert environ['TEST'] == 'test'

        def test_getitem_with_unicode_value(self):
            # pylint: disable=no-member
            environ['TEST'] = u'test'
            assert environ['TEST'] == u'test'

        def test_getitem_with_bytes_value(self):
            # pylint: disable=no-member
            environ['TEST'] = b'test'


# Generated at 2022-06-23 14:35:44.221242
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ["test"] = "foo"
    assert environ["test"] == "foo"
    del environ["test"]
    assert environ["test"] != "foo"


# Generated at 2022-06-23 14:35:48.427373
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # empty constructor
    assert isinstance(_TextEnviron(), _TextEnviron)

    # constructor with dictionary
    assert isinstance(_TextEnviron({u'key1': u'value1', u'key2': u'value2'}), _TextEnviron)

    # constructor with an encoding argument
    assert isinstance(_TextEnviron(encoding='utf-8'), _TextEnviron)


# pytest test setup

# Generated at 2022-06-23 14:35:57.301237
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    class test_os_environ(MutableMapping):
        def __init__(self):
            self._values = {}
            self._raw_environ = {}

        def __delitem__(self, key):
            del self._values[key]
            del self._raw_environ[key]

        def __getitem__(self, key):
            return self._values[key]

        def __setitem__(self, key, value):
            self._values[key] = value
            self._raw_environ[key] = to_bytes(value, encoding='utf-8', nonstring='strict',
                                              errors='surrogate_or_strict')

        def __iter__(self):
            return self._values.__iter__()


# Generated at 2022-06-23 14:36:03.430059
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    with _TextEnviron(encoding=None) as environ:
        environ['TEXT'] = 'tést'
        environ['TEXT2'] = b't\xc3\xa9st'
        environ['TEXT3'] = u'tést'
        assert 'TEXT' in environ
        assert 'TEXT2' in environ
        assert 'TEXT3' in environ
        assert 'tést' in environ
        if not PY3:
            assert 't\xc3\xa9st' in environ
            assert 't\xc3\xa9st' in environ.values()
        assert u'tést' in environ.values()
        assert 'tést' in environ.values()
        assert 'TEXT' in environ.keys()
        assert 'TEXT2' in environ.keys()


# Generated at 2022-06-23 14:36:12.094875
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    if not PY3:
        # PY2 version is supposed to convert env strings to text and to decode them
        os.environ['TEST1'] = b'bytes'
        os.environ['TEST2'] = u'Unicode'
        os.environ['TEST3'] = to_bytes(u'Unicode', encoding='utf-8')
        os.environ['TEST4'] = b'bytes \x80'
        text_env = _TextEnviron(os.environ, 'utf-8')
        assert isinstance(text_env['TEST1'], text)
        assert isinstance(text_env['TEST2'], text)
        assert isinstance(text_env['TEST3'], text)
        assert isinstance(text_env['TEST4'], text)

# Generated at 2022-06-23 14:36:14.232178
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env_with_bytes = {b'byte1': b'cannot decode', b'byte2': 'decode OK'}
    text_environ = _TextEnviron(env_with_bytes, encoding='utf-8')
    assert list(text_environ) == ['byte2', 'byte1']


# Generated at 2022-06-23 14:36:17.630717
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    if PY3:
        assert environ['PATH'] == os.environ['PATH']
        return

    os.environ['PATH'] = b'/usr/bin'
    environ.clear()
    assert environ['PATH'] == '/usr/bin'

# Generated at 2022-06-23 14:36:20.247960
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    del environ['ANSIBLE_TRANSFORM_INVALID_GROUP_CHARS']
    assert 'ANSIBLE_TRANSFORM_INVALID_GROUP_CHARS' not in environ


# Generated at 2022-06-23 14:36:21.872904
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    e = _TextEnviron({"TEST": "TEST"})
    assert len(e) == 1



# Generated at 2022-06-23 14:36:27.089837
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    e = _TextEnviron(encoding='ascii')
    assert e.encoding == 'ascii'
    assert e._raw_environ is os.environ
    assert e._value_cache == {}

    e = _TextEnviron(encoding='ascii', env={'ascii': b'hello', b'bad_key_type': 'world'})
    assert e.encoding == 'ascii'
    assert e._raw_environ == {'ascii': b'hello', b'bad_key_type': 'world'}
    assert e._value_cache == {}



# Generated at 2022-06-23 14:36:31.167577
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    original_environ = environ
    environ = _TextEnviron()
    try:
        assert len(environ) == len(os.environ)
    finally:
        environ = original_environ


# Generated at 2022-06-23 14:36:38.720028
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test constructor with just encoding
    assert sys.getfilesystemencoding() == _TextEnviron().encoding

    # Test constructor with env that is all byte strings
    test_environ = os.environ.copy()
    assert id(os.environ) != id(test_environ)
    assert isinstance(os.environ, MutableMapping)
    assert isinstance(test_environ, MutableMapping)
    environ = _TextEnviron(env=test_environ)
    text_environ = {}

# Generated at 2022-06-23 14:36:47.628236
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import os
    import tempfile
    from ansible.module_utils.six import PY3

    #ensure the key is not in the environment before trying to delete it
    key = "test__TextEnviron___delitem__"
    assert key not in os.environ

    #define a function which will test __delitem__ of class _TextEnviron() on the given environment
    def test_delitem(env, key):
        orig_len = len(env)
        assert key not in env
        try:
            del env[key]
        except KeyError as e:
            # The key was not in the environment to begin with
            assert orig_len == len(env)
        else:
            # The key was deleted correctly
            assert key not in env
            assert orig_len == len(env) + 1

    #define a function

# Generated at 2022-06-23 14:36:52.737095
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ._raw_environ = {}
    assert len(environ) == 0
    environ[u'ANSIBLE_TEST'] = u'foo'
    assert len(environ) == 1
    assert environ[u'ANSIBLE_TEST'] == u'foo'
    del environ[u'ANSIBLE_TEST']
    assert len(environ) == 0


# Generated at 2022-06-23 14:37:01.771341
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Try with no arguments
    result = _TextEnviron()
    assert result._raw_environ is os.environ
    assert result.encoding == sys.getfilesystemencoding()

    # Try with a dict
    result = _TextEnviron({b'key': b'value'})
    assert result._raw_environ == {b'key': b'value'}
    assert result.encoding == sys.getfilesystemencoding()

    # Try with a dict and an encoding
    result = _TextEnviron({b'key': b'value'}, encoding='utf-8')
    assert result._raw_environ == {b'key': b'value'}
    assert result.encoding == 'utf-8'

    # Try with an encoding
    result = _TextEnviron(encoding='utf-8')

# Generated at 2022-06-23 14:37:05.874833
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():  # noqa: D103
    environ['key_to_be_deleted'] = 'value'
    assert 'key_to_be_deleted' in environ
    del environ['key_to_be_deleted']
    assert 'key_to_be_deleted' not in environ



# Generated at 2022-06-23 14:37:12.973626
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """
    Unit test for method __iter__ of class _TextEnviron

    This is variously documented (depending on your version of the Python3 docs) as returning a
    list of keys or returning a view of the keys.  We check that we're returning an iterable
    """
    env = _TextEnviron()
    keys = []
    for key in env:
        keys.append(key)
    assert isinstance(keys, list)
    assert 6 == len(keys)



# Generated at 2022-06-23 14:37:22.019509
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Text in local encoding
    assert environ['NAME'] == u'val'

    environ['NAME'] = u'newval'
    assert environ['NAME'] == u'newval'

    # Bytes in latin1
    environ['NAME'] = b'\xc3\xa9'
    assert environ['NAME'] == u'\xe9'

    # Text in unicode
    environ['NAME'] = u'\u0421'
    assert environ['NAME'] == u'\u0421'

    # Bytes in utf-8
    environ['NAME'] = b'\xd0\xa1'
    assert environ['NAME'] == u'\u0421'



# Generated at 2022-06-23 14:37:25.308683
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({b'foo': b'bar', b'baz': b'qux'})
    del env['baz']
    assert len(env) == 1
    del env['baz']



# Generated at 2022-06-23 14:37:33.844694
# Unit test for method __setitem__ of class _TextEnviron

# Generated at 2022-06-23 14:37:36.261363
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import iteritems

    env = {"key":"value", "key1":"value1"}
    env_text = _TextEnviron(env)
    assert len(env) == len(env_text)


# Generated at 2022-06-23 14:37:41.875204
# Unit test for constructor of class _TextEnviron

# Generated at 2022-06-23 14:37:42.981289
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print('test__TextEnviron___getitem__')
    text_environ = environ
    print(text_environ)


# Generated at 2022-06-23 14:37:46.000615
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    assert environ["PATH"]
    assert not type(environ["PATH"]) == bytes
    assert environ["PATH"] == to_text(environ["PATH"])
    assert environ["PATH"] != to_bytes(environ["PATH"])