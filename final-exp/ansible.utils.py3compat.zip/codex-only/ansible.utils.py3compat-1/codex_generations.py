

# Generated at 2022-06-23 14:27:45.601946
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """Create a text environ object and put a value into it"""
    environ = _TextEnviron(encoding='utf-8')
    assert isinstance(environ, MutableMapping)
    environ['test'] = 'test'
    assert environ['test'] == 'test'



# Generated at 2022-06-23 14:27:56.784532
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    class RawEnviron(dict):

        def __getitem__(self, key):
            value = dict.__getitem__(self, key)
            return to_bytes(value, errors='strict')

    # When the value for a key is not in the cache, we need to add it
    # and decode it from bytes
    raw_environ = RawEnviron()
    raw_environ['ansible_test'] = 'testing 123'
    environ = _TextEnviron(raw_environ)
    assert isinstance(environ['ansible_test'], text_type)
    assert environ['ansible_test'] == u'testing 123'
    assert 'ansible_test' in environ._value_cache
    assert environ._value_cache[b'testing 123'] == u'testing 123'

    # When the value

# Generated at 2022-06-23 14:27:58.047123
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
  assert len(environ) == len(os.environ.copy())


# Generated at 2022-06-23 14:28:09.104704
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()

    # Test ascii string
    env['a'] = 'a'
    assert env['a'] == 'a'
    assert env._raw_environ['a'] == b'a'
    assert env._value_cache[b'a'] == 'a'

    # Test unicode string
    env['b'] = '\u1234'
    assert env['b'] == '\u1234'
    assert env._raw_environ['b'] == b'\xe1\x88\xb4'
    assert env._value_cache[b'\xe1\x88\xb4'] == '\u1234'

    # Test non-string
    env['c'] = u'c'
    assert env['c'] == 'c'
    assert env._raw_environ['c']

# Generated at 2022-06-23 14:28:11.640318
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(env={b'test': b'value'})
    assert env['test'] == to_text(b'value')



# Generated at 2022-06-23 14:28:15.600633
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron(encoding='utf-8')
    assert 'LANG' not in environ
    environ['LANG'] = 'C'
    assert environ['LANG'] == 'C'



# Generated at 2022-06-23 14:28:23.036852
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    if PY3:
        os.environ['TEST_DELITEM_KEY'] = 'TEST_DELITEM_VALUE'
    else:
        os.environ['TEST_DELITEM_KEY'] = u'TEST_DELITEM_VALUE'
    try:
        environ['TEST_DELITEM_KEY']  # To cache the key
        del environ['TEST_DELITEM_KEY']
        assert 'TEST_DELITEM_KEY' not in environ
        assert 'TEST_DELITEM_KEY' not in environ._value_cache
    finally:
        if 'TEST_DELITEM_KEY' in os.environ:
            del os.environ['TEST_DELITEM_KEY']



# Generated at 2022-06-23 14:28:32.837232
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Mixed values for the environment
    environ = _TextEnviron(env={b'a_key': b'a_value',
                                b'unicode_key': b'\xe4\xbd\xa0\xe5\xa5\xbd',
                                b'windows_key': b'c:\\path\\to\\directory',
                                u'unicode_key': u'\u4f60\u597d'})
    assert environ[u'a_key'].strip('\n') == 'a_value'
    assert environ[u'unicode_key'].strip('\n') == u'你好'
    # leading whitespace characters are stripped
    assert environ[u'windows_key'].strip(' \t\n\r') == 'c:\\path\\to\\directory'


# Generated at 2022-06-23 14:28:39.703112
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env1 = _TextEnviron({'key': 'value', 'key2': 'value2'})
    assert list(env1.__iter__()) == ['key', 'key2']

    env2 = _TextEnviron()
    env2['key'] = 'value'
    env2['key2'] = 'value2'
    assert list(env2.__iter__()) == ['key', 'key2']



# Generated at 2022-06-23 14:28:45.738903
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    import os

    # set an environment variable for testing
    os.environ['A_KEY'] = 'A_VALUE'

    # create a _TextEnviron object that returns text strings from the environment
    environ = _TextEnviron(encoding='utf-8')

    assert isinstance(environ, MutableMapping)
    assert isinstance(environ['A_KEY'], str)

# Generated at 2022-06-23 14:28:56.668683
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Give an arbitrary character that requires multiple bytes
    encoding = 'shift-jis'
    # Only works on Python3
    if PY3:
        raw_env = {to_bytes(u'キラキラ', encoding=encoding): to_bytes(u'キラキラ', encoding=encoding)}
    else:
        # yey, bugs!
        raw_env = {u'キラキラ'.encode('shift_jis'): u'キラキラ'.encode('shift_jis')}

    # Test Unicode to bytes
    test_env = _TextEnviron(env=raw_env)
    assert to_bytes(u'キラキラ', encoding=encoding) == test_env[to_bytes(u'キラキラ', encoding=encoding)]

    # Test bytes to Unicode

# Generated at 2022-06-23 14:29:00.562780
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    _testEnviron = _TextEnviron(encoding='utf-8')
    testString = u"Test"
    _testEnviron['test_key'] = testString
    assert (_testEnviron['test_key'] == testString)
    return


# Generated at 2022-06-23 14:29:05.503125
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Set a value for a normal text key
    environ['testKey1'] = 'testValue1'
    # Set a value for a unicode key
    environ[u'testKey2'] = 'testValue2'
    # Overwrite an existing key with a unicode value
    environ['testKey1'] = u'testValue3'
    assert(environ['testKey1'] == 'testValue3')

# Generated at 2022-06-23 14:29:16.721342
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils.six.moves import unittest
    class Test__TextEnvironInit(unittest.TestCase):
        def test_good(self):
            environ = _TextEnviron()
            self.assertTrue(hasattr(environ, '_raw_environ'))
            self.assertTrue(hasattr(environ, '_value_cache'))
            self.assertEqual(environ.encoding, sys.getfilesystemencoding())

        def test_override_codec(self):
            environ = _TextEnviron(encoding='ascii')
            self.assertEqual(environ.encoding, 'ascii')

    unittest.main()



# Generated at 2022-06-23 14:29:19.684220
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron()
    env["foo"] = "bar"
    del env["foo"]
    assert "foo" not in env
    assert "foo" not in os.environ


# Generated at 2022-06-23 14:29:20.856752
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:29:24.254852
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ_test = _TextEnviron()
    environ_test['test_env_key'] = 'test_env_value'
    assert environ_test['test_env_key'] == 'test_env_value'
    del environ_test['test_env_key']
    assert 'test_env_key' not in environ_test


# Generated at 2022-06-23 14:29:31.704251
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Put some bytes in the environment for testing
    os.environb[b'ANSIBLE_TEST_ENCODING_1'.encode('utf-8')] = b'\xc3\xb6'.encode('utf-8')

    iter_result = list(environ.__iter__())
    assert iter_result == [b'ANSIBLE_TEST_ENCODING_1'.decode('utf-8')]



# Generated at 2022-06-23 14:29:40.488264
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    def assert_getitem(key, expected_value, env=None, encoding=None):
        if env is None:
            env = {}
        env = _TextEnviron(env, encoding=encoding)
        assert env[key] == expected_value

    assert_getitem('foo', 'bar')

    # Key does not exist in the environment
    #   Non UTF-8 byte string
    assert_getitem('foo', None, env={})

    assert_getitem('foo', None, env={}, encoding=None)
    assert_getitem('foo', None, env={}, encoding='ascii')
    assert_getitem('foo', None, env={}, encoding='utf-8')

    #   UTF-8 byte string
    assert_getitem('foo', None, env={}, encoding=None)

# Generated at 2022-06-23 14:29:42.122666
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    for key in environ:
        value = environ[key]

# Generated at 2022-06-23 14:29:52.749370
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import random

    # Generate a random string with random string length
    rand_str = ''.join(chr(random.randint(0, 255)) for _ in range(random.randint(0, 255)))

    # Set and get the item with the given key
    key = 'PYTHON_RANDOM_STR'
    environ[key] = rand_str
    str_get = environ[key]

    # Test the result
    # Check if the length of the original string is equal to the one from environ
    assert len(rand_str) == len(str_get)

    # Check for each char if the char from the environ string is equal to the char from the original
    # string
    for i, char in enumerate(rand_str):
        assert char == str_get[i]

    # Delete the

# Generated at 2022-06-23 14:30:00.066352
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.pycompat24 import get_exception
    environ = _TextEnviron({b'ANSIBLE_KEEP_REMOTE_FILES': u'1'.encode('utf-8')}, encoding='utf-8')
    assert isinstance(environ[b'ANSIBLE_KEEP_REMOTE_FILES'], unicode) and \
            environ[b'ANSIBLE_KEEP_REMOTE_FILES'] == u'1'
    try:
        environ[b'ANSIBLE_KEEP_REMOTE_FILES'] = u'2'
    except:
        exc = get_exception()
        assert isinstance(exc, UnicodeEncodeError)
    else:
        assert False
    environ.encoding = 'ascii'

# Generated at 2022-06-23 14:30:01.746002
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:30:03.019278
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:30:07.997391
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    e = _TextEnviron(encoding='utf-8')
    assert isinstance(e, _TextEnviron)
    assert e.encoding == 'utf-8'
    assert isinstance(e._raw_environ, dict)
    assert isinstance(e._value_cache, dict)
    assert not e._value_cache


# Generated at 2022-06-23 14:30:18.464650
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Setup the test environment
    environ['TEST_ENV'] = 'ansible-python'
    assert(environ['TEST_ENV'] == 'ansible-python')

    # Test the method __getitem__

    # Case 1
    # Check the return value of method __getitem__ with the key 'TEST_ENV'
    assert(environ['TEST_ENV'] == 'ansible-python')

    # Case 2
    # Check the return value of method __getitem__ with the key 'TEST_ENV'
    # when PY3 is True
    environ._value_cache['ansible-python'] = 'ansible-python'
    assert(environ['TEST_ENV'] == environ._value_cache['ansible-python'])

    # Case 3
    # Check the return value

# Generated at 2022-06-23 14:30:26.591381
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Test case 1
    # Create an empty environment
    environ = _TextEnviron({})
    assert len(environ) == 0

    i = iter(environ)
    assert next(i) is None

    # Test case 2
    # Create a one item environment
    environ = _TextEnviron({'ANSIBLE_LIBRARY': '/usr/share/ansible/'})
    assert len(environ) == 1

    i = iter(environ)
    assert next(i) == 'ANSIBLE_LIBRARY'
    assert next(i) is None

    # Test case 3
    # Create a two item environment
    environ = _TextEnviron({'ANSIBLE_LIBRARY': '/usr/share/ansible/',
                            'ANSIBLE_DEBUG': 'False'})
    assert len(environ)

# Generated at 2022-06-23 14:30:34.553896
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Create a new test environment
    test_env = _TextEnviron({})
    # Len of test_env = 0
    assert (len(test_env) == 0)

    # Len of test_env is still 0 because os.environ is a different object
    assert (len(test_env) == 0)

    # Assign test_env to a new value with one element
    test_env = _TextEnviron({'path': '/tmp/'})
    # Len of test_env = 1
    assert (len(test_env) == 1)



# Generated at 2022-06-23 14:30:38.405497
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    environ['test__TextEnviron___delitem__'] = 'test__TextEnviron___delitem__'
    assert 'test__TextEnviron___delitem__' in environ
    del environ['test__TextEnviron___delitem__']
    assert 'test__TextEnviron___delitem__' not in environ

    return True



# Generated at 2022-06-23 14:30:44.560568
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    f'''
    Testcase for method __delitem__ of class _TextEnviron
    
    Method __delitem__ in class _TextEnviron deletes the `key` from the mapping object.
    '''
    environ['TEST_KEY'] = 'TEST_VALUE'
    assert 'TEST_KEY' in environ
    del environ['TEST_KEY']
    assert 'TEST_KEY' not in environ


# Generated at 2022-06-23 14:30:55.968620
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """
    # Test entry 1
    # Add a value into the cache and then see that it returns the same value
    # when asked for it

    test_entry_1_test_key = to_bytes('test_key', encoding='utf-8', nonstring='strict',
                                     errors='surrogate_or_strict')

    test_entry_1_test_value = to_text('test_value', encoding='utf-8', nonstring='passthru',
                                      errors='surrogate_or_strict')

    environ._value_cache.update({test_entry_1_test_key: test_entry_1_test_value})

    test_entry_1_dummy_value_for_mock_raw_environ_

# Generated at 2022-06-23 14:30:57.855391
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron()
    assert len(environ) >= 0


# Generated at 2022-06-23 14:31:06.950289
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Some good test cases for this are os.uname and os.environ

    import os

    # First test os.uname.  This is on a Linux system and thus should always be bytes.
    #
    # getattr(os.uname(), 0) is the first name from os.uname
    # os.uname returns a list of tuples so we need to get the first value from the first tuple
    encode_test_in = getattr(os.uname(), 0)
    if not isinstance(encode_test_in, bytes):
        # If encode_test_in is not bytes then we have some symlink or something
        # Return an error message and the type of input value
        return "Wrong type returned from os.uname(); expected bytes but got %s" % type(encode_test_in)

# Generated at 2022-06-23 14:31:14.759698
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ_bytes = b'red'
    environ_text = u'red'
    utf8_encoded_environ = environ_text.encode('utf-8')
    assert list(environ) == list(os.environ)
    os.environ[environ_bytes] = utf8_encoded_environ
    # __iter__ should return text values in Ansible 2.6 and higher
    if PY3:
        assert [utf8_encoded_environ] == list(os.environ)
    else:
        assert [environ_bytes] == list(os.environ)
    assert [environ_text] == list(environ)
    os.environ.pop(environ_bytes)



# Generated at 2022-06-23 14:31:17.796005
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron(env={b'USER': b'feodoran', b'LANG': b'en_CA.utf8'})

    assert env[b'USER'] == u'feodoran'
    assert env[b'LANG'] == u'en_CA.utf8'

    assert env['USER'] == u'feodoran'
    assert env['LANG'] == u'en_CA.utf8'


# Generated at 2022-06-23 14:31:23.599630
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils._text import to_bytes

    environ = _TextEnviron({to_bytes('ANSIBLE_TEST_VAR', 'utf-8'): to_bytes('ANSIBLE_TEST_VAR', 'utf-8')})
    assert isinstance(environ, _TextEnviron) == True
    env_var = next(iter(environ))
    assert env_var == 'ANSIBLE_TEST_VAR'
    assert environ[env_var] == 'ANSIBLE_TEST_VAR'


# Generated at 2022-06-23 14:31:26.507005
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    _env = {'foo': b'bar'}
    env = _TextEnviron(_env, encoding='ascii')
    assert env == {'foo': 'bar'}

# Generated at 2022-06-23 14:31:30.001946
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Testing __len__ and __iter__ of class _TextEnviron
    """
    assert len(environ) == len(os.environ)
    assert len(environ) == len(dict(environ))



# Generated at 2022-06-23 14:31:34.944353
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    os_environ = os.environ

# Generated at 2022-06-23 14:31:45.672934
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import io

    # Ensure that the constructor sets up the defaults correctly
    assert environ._raw_environ is os.environ
    assert environ._value_cache == {}
    assert environ.encoding == sys.getfilesystemencoding()

    # Ensure that os.environ does work
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()
    old_loglevel = os.environ.get('ANSIBLE_LOG_PATH')

# Generated at 2022-06-23 14:31:50.554322
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Unit test for method __delitem__ of class _TextEnviron in module utils.environ
    """
    env = _TextEnviron({"NAME": "TEST"})
    assert "NAME" in env
    del env["NAME"]
    assert "NAME" not in env


# Generated at 2022-06-23 14:31:53.573083
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    for key in environ:
        assert isinstance(key, str), 'Error: keys of environ are not text: %s' % key

# Note: not unit-test
test__TextEnviron___iter__()

# Generated at 2022-06-23 14:31:56.063128
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Verifies the __len__ method of class _TextEnviron
    Returns:

    """
    obj = _TextEnviron()
    len = obj.__len__()
    assert len == 2

# Generated at 2022-06-23 14:32:03.492252
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Use the class directly.  If this is done in the global namespace,
    # importing this module will fail with a NameError in python2.
    class_under_test = _TextEnviron()

    # Test basic iteration
    env_keys = os.environ.keys()
    for key in env_keys:
        found = False
        for item in class_under_test:
            if item == key:
                found = True
        assert found


# Generated at 2022-06-23 14:32:07.160371
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ["TEST1"] = "TEST1"
    del environ["TEST1"]
    assert "TEST1" not in environ


# Generated at 2022-06-23 14:32:10.593289
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """Test _TextEnviron.__iter__"""
    from collections import OrderedDict
    raw_env = OrderedDict({
        b'var1': b'hello',
        b'var2': b'goodbye',
        b'var3': b'hello again'
    })
    environ = _TextEnviron(raw_env, encoding='utf-8')
    assert list(environ) == ['var1', 'var2', 'var3']



# Generated at 2022-06-23 14:32:14.287309
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    class_name = '_TextEnviron'

    # This is to ensure we can load this function even when the tests are not run
    if class_name not in globals():
        return

    # Happy path
    test_class = _TextEnviron(encoding='ascii')
    assert isinstance(test_class, MutableMapping)

    # The class triggers a type error on creating a bad instance
    try:
        test_class = _TextEnviron(encoding='not a real encoding')
        assert False
    except TypeError:
        pass

    # Check that defaults work
    test_class = _TextEnviron()
    assert isinstance(test_class, MutableMapping)

# Generated at 2022-06-23 14:32:16.773292
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({'ANSIBLE_TEST_KEY': 'TEST VALUE'}, encoding='utf-8')
    assert list(env) == ['ANSIBLE_TEST_KEY']



# Generated at 2022-06-23 14:32:27.591378
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test cases are listed in a dict
    cases = dict()

    # Setup cases
    # Case 1: Unicode string should be encoded
    cases[1] = {'key': 'spam', 'value': u'\u8d85\u5feb\uff01'}
    # Case 2: Byte string will be passed through
    cases[2] = {'key': 'egg', 'value': b'\xe4\xb8\xad\xe6\x96\x87'}
    # Case 3: Non-byte string non-unicode objects should be converted with str()
    cases[3] = {'key': 'sausage', 'value': 3}

    # Execute the test
    environ.clear()
    for case, values in cases.items():
        environ[values['key']] = values['value']

# Generated at 2022-06-23 14:32:32.710396
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ['TEST_ENV_VAR_1'] = 'value 1'
    assert 'TEST_ENV_VAR_1' in environ
    del(environ['TEST_ENV_VAR_1'])
    assert 'TEST_ENV_VAR_1' not in environ


# Generated at 2022-06-23 14:32:35.185094
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    To test method of class _TextEnviron
    """
    x = _TextEnviron()

    x["test"] = "test"
    assert x["test"] == "test"

# Generated at 2022-06-23 14:32:38.486511
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This test should pass in python2 and python3
    assert environ['PWD'] == u"Python2Passed"
    assert environ['PWD'] == u"Python3Passed"

# Generated at 2022-06-23 14:32:41.788930
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Arrange
    environ.clear()
    environ['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'

    # Act & Assert
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:32:42.888918
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    pass  # Nothing to test


# Generated at 2022-06-23 14:32:50.521819
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os.environ['ANSIBLE_FORCE_COLOR'] = '1'
    os.environ['ANSIBLE_NOCOLOR'] = '0'
    os.environ['ANSIBLE_NOCOWS'] = '1'
    # We need to convert the iterator to a list to make sure __iter__ is called in Python2
    assert list(environ.__iter__()) == list(environ)
    assert set(environ) == {'ANSIBLE_FORCE_COLOR', 'ANSIBLE_NOCOLOR', 'ANSIBLE_NOCOWS'}
    del environ['ANSIBLE_FORCE_COLOR']
    assert set(environ) == {'ANSIBLE_NOCOLOR', 'ANSIBLE_NOCOWS'}
    del environ['ANSIBLE_NOCOLOR']

# Generated at 2022-06-23 14:32:59.945051
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class _FakeOsEnviron:
        _fake_environ = {'a_b': 'c_d', 'e_f': 'g_h', 'i_j': 'k_l'}

        def __getitem__(self, key):
            return self._fake_environ[key]

    class _FakeSys:
        @staticmethod
        def getfilesystemencoding():
            return 'utf-8'

    class _FakeOs:
        environ = _FakeOsEnviron()

    os = _FakeOs()
    sys = _FakeSys()
    environ = _TextEnviron(encoding=sys.getfilesystemencoding())

    assert environ.__getitem__('a_b') == 'c_d'
    assert environ.__getitem__('e_f') == 'g_h'


# Generated at 2022-06-23 14:33:03.594517
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = os.environ.copy()
    env['key'] = b'\xe2\x80\x93'
    test_env = _TextEnviron(env)
    assert test_env['key'] == u'\u2013'

# Generated at 2022-06-23 14:33:12.569944
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from os import environ as O_environ

    # Test key value not in os.environ. Do not set/change environment variable
    try:
        O_environ['$ANSIBLE_TEST_GET_ENVIRON_KEY_1']
    except KeyError:
        assert '$ANSIBLE_TEST_GET_ENVIRON_KEY_1' not in environ
    else:
        # Now key is in os.environ. Delete it and test again
        del O_environ['$ANSIBLE_TEST_GET_ENVIRON_KEY_1']
        assert '$ANSIBLE_TEST_GET_ENVIRON_KEY_1' not in environ

    # Test key value in os.environ. Do not set/change environment variable

# Generated at 2022-06-23 14:33:14.576141
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    assert len(env) == len(os.environ)

# Generated at 2022-06-23 14:33:22.208203
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ._raw_environ['str_ans'] = 'str'
    assert environ['str_ans'] == 'str'

    environ._raw_environ['unicode_ans'] = u'unicode'
    assert environ['unicode_ans'] == u'unicode'

    environ._raw_environ['bytes_ans'] = b'bytes'
    if PY3:
        assert environ['bytes_ans'] == b'bytes'
    else:
        assert environ['bytes_ans'] == u'bytes'

    # Test str in a cp437 encoding
    str_cp437 = ''
    for i in range(128):
        str_cp437 += chr(i)
    environ._raw_environ['str_cp437'] = str_cp437.encode('cp437')
    assert en

# Generated at 2022-06-23 14:33:25.507435
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron(env={'a': 'foo', 'b': 'bar'})
    del env['b']
    assert env == {'a': 'foo'}


# Generated at 2022-06-23 14:33:29.414064
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    '''
    Test for method __setitem__ of class _TextEnviron
    '''
    # If the return value of this function is True, then it indicates that the
    # unit test was successful.
    return True


# Generated at 2022-06-23 14:33:38.453348
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # use a copy of environ as it is a cached global object
    env = dict(environ)
    # set and get byte strings from dict
    env['byte_string'] = b'value'
    if PY3:
        assert env['byte_string'] == 'value'
    else:
        assert env['byte_string'] == u'value'
    # set and get unicode strings from dict
    env[u'unicode_string'] = u'value'
    if PY3:
        assert env[u'unicode_string'] == 'value'
    else:
        assert env[u'unicode_string'] == u'value'
    # set and get non-unicode text using surrogateescape
    env[u'non_unicode_string'] = u'\U0001f604'

# Generated at 2022-06-23 14:33:42.642417
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    environ[key] = value
    """
    a = _TextEnviron()
    a['foo'] = 'bar'
    assert a == {'foo': 'bar'}

# Generated at 2022-06-23 14:33:54.269988
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """ Tests get item method of _TextEnviron.
    """
    environ_test = _TextEnviron(encoding='utf-8')

    # Test for non-existing key
    try:
        environ_test.__getitem__('non-existing-key')
    except KeyError:
        print('Test passed')
    else:
        raise AssertionError

    os.environ['TEST_ENV_VAR'] = 'testvalue'

    if PY3:
        assert environ_test.__getitem__('TEST_ENV_VAR') == 'testvalue'
    else:
        assert environ_test.__getitem__('TEST_ENV_VAR') == u'testvalue'
    
    # Test with multibyte characters

# Generated at 2022-06-23 14:34:01.432170
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    ''' Test __delitem__ methed of class _TextEnviron '''
    _test_env = {'A': 'A', 'B': 'B', 'C': 'C'}
    _test_environ = _TextEnviron(env=_test_env)
    assert _test_env == _test_environ._raw_environ
    del _test_environ['C']
    assert 'C' not in _test_environ.keys()
    assert 'C' not in _test_environ._raw_environ.keys()
    assert _test_env != _test_environ._raw_environ



# Generated at 2022-06-23 14:34:12.858849
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    os.environ['ANSIBLE_TEST_VAR'] = 'xyzzy'
    os.environ['ANSIBLE_BYTES_VAR'] = b'\x01\x02\x03\x04\x05\x04\x03\x02\x01'

    text_environ = _TextEnviron()

    # Test that we've initialized our objects properly
    assert(text_environ._raw_environ is os.environ)
    assert(text_environ._value_cache == {})

    # Test that the getitem method works
    assert(text_environ['ANSIBLE_TEST_VAR'] == 'xyzzy')
    # Test that the getitem method found a unicode string

# Generated at 2022-06-23 14:34:18.234723
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _TextEnviron.__delitem__('non_existing_key')
    os.environ['existing_key'] = 'existing_value'
    # pylint: disable=E1128
    try:
        _TextEnviron.__delitem__('existing_key')
        assert not os.environ.get('existing_key')
    finally:
        del os.environ['existing_key']

# Generated at 2022-06-23 14:34:24.532488
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Check the behavior of delitem, when the environment variable is not defined before.
    # The variable is defined before the test and removed after the test.
    env_key = "TEST_VARIABLE_DELITEM"
    env_value = "VALUE_TEST_VARIABLE_DELITEM"
    os.environ[env_key] = env_value

    result = environ.pop(env_key, None)
    assert result == env_value
    assert env_key not in environ

    # Check the behavior of delitem, when the environment variable is defined before.
    # The variable is defined before the test and removed after the test.
    env_key = "TEST_VARIABLE_DELITEM"

# Generated at 2022-06-23 14:34:34.669058
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    e = _TextEnviron({'byteskey': b'one', 'unicodekey': 'two'})
    assert e.encoding == 'utf-8'
    assert e['byteskey'] == 'one'
    assert e['unicodekey'] == 'two'
    e['byteskey'] = b'three'
    assert e['byteskey'] == 'three'
    assert e._raw_environ == {'byteskey': b'three', 'unicodekey': 'two'}

    # Test auto-converting to unicode
    e = _TextEnviron({'byteskey': b'one', 'unicodekey': 'two'}, encoding='iso-8859-1')
    assert e.encoding == 'iso-8859-1'
    assert e['byteskey'] == u'one'

# Generated at 2022-06-23 14:34:40.553586
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    _TextEnviron.__setitem__ should raise TypeError if text is not in the encoding

    This tests that _TextEnviron will raise TypeError if you set a text string into it that
    cannot be converted to the desired encoding.
    """
    def environment_setter():
        environ['utf-8'] = '\xff'

    assert_raises(environment_setter, TypeError)



# Generated at 2022-06-23 14:34:43.883148
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = {b'a': b'b', b'1': b'2'}
    x = _TextEnviron(env)
    assert not any([isinstance(i, bytes) for i in x.__iter__()])



# Generated at 2022-06-23 14:34:46.404571
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    backup_env = dict(environ)
    try:
        del environ['SHELL']
        assert environ._raw_environ['SHELL'] is None
    finally:
        environ.clear()
        environ.update(backup_env)


# Generated at 2022-06-23 14:34:53.109889
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Unit test for the constructor of class _TextEnviron
    """
    env = {'normal': 'text', 'unicode': u'é', 'latin1': '\xe9', 'binary': b'binary'}
    # test default constructor
    environ = _TextEnviron(env)
    assert environ._raw_environ == env
    assert environ._value_cache == {}
    assert environ.encoding == sys.getfilesystemencoding()
    # test constructor with encoding
    encoding = 'latin1'
    environ = _TextEnviron(env, encoding=encoding)
    assert environ._raw_environ == env
    assert environ._value_cache == {}
    assert environ.encoding == encoding
    # test invalid encoding
    encoding = 'ascii'

# Generated at 2022-06-23 14:34:55.296308
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['foo'] = 'bar'
    assert environ['foo'] == 'bar'
    del environ['foo']
    assert 'foo' not in environ


# Generated at 2022-06-23 14:35:06.075122
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    class MockEnv(MutableMapping):
        def __init__(self, data):
            self.data = data
        def __getitem__(self, key):
            return self.data[key]
        def __setitem__(self, key, value):
            self.data[key] = value
        def __delitem__(self, key):
            del self.data[key]
        def __iter__(self):
            return iter(self.data)
        def __len__(self):
            return len(self.data)

    encoding = sys.getfilesystemencoding()
    data = {'str': 'str', 'bytes': b'bytes', 'unicode': '\u1f63', 'unknown': '\u0001'}

# Generated at 2022-06-23 14:35:11.447518
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    d = dict(a='1', b='2', c='3')
    e = _TextEnviron(d)
    e['a']
    e['b']
    e['c']
    del e['b']
    assert 'a' in e
    assert 'b' not in e
    assert 'c' in e
    d = dict(a='1', b='2', c='3')
    e = _TextEnviron(d)
    e['a']
    e['b']
    e['c']
    del e['b']
    assert 'a' in e
    assert 'b' not in e
    assert 'c' in e


# Generated at 2022-06-23 14:35:15.378834
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({'var1': 'val1', 'var2': 'val2'})
    assert len(env) == 2
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:35:26.056311
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron(encoding='utf-8')
    for k, v in environ.items():
        if isinstance(v, bytes):
            raise Exception("FAIL: _TextEnviron[%s] is bytes" % k)
        if v != os.environ[k]:
            raise Exception("FAIL: _TextEnviron[%s] is not the same as os.environ[%s]" % (k, k))

    # Test method __iter__ of class _TextEnviron
    test__TextEnviron___iter__()
    # Test method __len__ of class _TextEnviron
    test__TextEnviron___len__()
    # Test method __getitem__ of class _TextEnviron
    test__TextEnviron___getitem__()
    # Test method __setitem__ of class _TextEnviron

# Generated at 2022-06-23 14:35:28.387945
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    e = _TextEnviron()
    assert len(e) == len(os.environ)


# Generated at 2022-06-23 14:35:32.700402
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['LC_ALL'] = u'en_US.UTF-8'
    assert isinstance(environ['LC_ALL'], str)
    assert environ['LC_ALL'] == 'en_US.UTF-8'

# Generated at 2022-06-23 14:35:40.176567
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = _TextEnviron({
        'SOMETHING': 'body',
        'SOMETHING_ELSE': 'body',
    })
    if PY3:
        assert test_environ['SOMETHING'] == 'body'
        assert test_environ['SOMETHING_ELSE'] == 'body'
    else:
        assert test_environ['SOMETHING'] == u'body'
        assert test_environ['SOMETHING_ELSE'] == u'body'



# Generated at 2022-06-23 14:35:46.031009
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = os.environ.copy()
    orig_environ_keys = set(env.keys())
    modified_environ = _TextEnviron(env=env)
    modified_environ['foo'] = u'bar'
    modified_environ_keys = set(modified_environ.keys())
    assert orig_environ_keys == modified_environ_keys

# Generated at 2022-06-23 14:35:52.570272
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron()
    env['TEST_KEY'] = 'value'
    assert env['TEST_KEY'] == 'value'
    del env['TEST_KEY']
    if os.path.expanduser('~') == '/root':
        assert 'TEST_KEY' not in env


# Generated at 2022-06-23 14:35:55.879537
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    assert 'MORECOWBELL' not in environ
    environ['MORECOWBELL'] = 'SLIM'
    assert 'MORECOWBELL' in environ
    del environ['MORECOWBELL']
    assert 'MORECOWBELL' not in environ


# Generated at 2022-06-23 14:36:00.181555
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _environ = _TextEnviron({b'a': b'1', b'b': b'2', b'c': b'3'})
    del _environ['a']
    assert _environ == {b'b': b'2', b'c': b'3'}
    _environ = _TextEnviron({b'a': b'1', b'b': b'2', b'c': b'3'})
    del _environ[b'a']
    assert _environ == {b'b': b'2', b'c': b'3'}


# Generated at 2022-06-23 14:36:10.317896
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """
    Test: Iterate over environ keys
    Expected: Retrun iter on keys of environ
    """
    if 'ANSIBLE_UNIT_TESTING' in environ:
        del environ['ANSIBLE_UNIT_TESTING']

    # Setup the environment
    environ['ANSIBLE_UNIT_TESTING'] = 'yes'
    environ['ANSIBLE_BOGUS'] = 'bogus'
    environ['ANSIBLE_TEST_ENCODING'] = 'UTF-8'

    # Verify keys are iterated properly
    assert 'ANSIBLE_UNIT_TESTING' in environ
    assert 'ANSIBLE_BOGUS' in environ
    assert 'ANSIBLE_TEST_ENCODING' in environ



# Generated at 2022-06-23 14:36:11.600764
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    pass



# Generated at 2022-06-23 14:36:21.460300
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # check if we get back original value when PY3
    if PY3:
        test_value = "abcdééé"
        assert environ.__getitem__('test') == test_value, \
            '{0} != {1}'.format(environ.__getitem__('test'), test_value)

    # check if we get back original value when not PY3 and latin1
    test_value = "abcdééé".encode('latin1')
    environ = _TextEnviron({'test': test_value}, encoding=None)

# Generated at 2022-06-23 14:36:32.641813
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    should_print = False
    if 'TEST_ENV' in environ:
        del environ['TEST_ENV']
    else:
        os.environ['TEST_ENV'] = 'foo'
        should_print = True

    try:
        del environ['TEST_ENV']
    except KeyError:
        assert False, 'KeyError should be raised when key does not exist'

    try:
        del os.environ['TEST_ENV']
    except KeyError:
        assert False, 'KeyError should be raised when key does not exist'

    environ['TEST_ENV'] = 'foo'

    del environ['TEST_ENV']


# Generated at 2022-06-23 14:36:37.445874
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import os
    environ['ANSIBLE_TEST_ENV_VAR'] = 'some value'
    assert os.environ['ANSIBLE_TEST_ENV_VAR']
    # A byte string should be removed
    del environ['ANSIBLE_TEST_ENV_VAR']
    assert not os.environ['ANSIBLE_TEST_ENV_VAR']
    # A text string should be removed
    environ['ANSIBLE_TEST_ENV_VAR'] = to_text('some value')
    assert os.environ['ANSIBLE_TEST_ENV_VAR']
    del environ['ANSIBLE_TEST_ENV_VAR']
    assert not os.environ['ANSIBLE_TEST_ENV_VAR']


# Generated at 2022-06-23 14:36:42.068912
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Verifies that new items can be properly added to the env.

    # Arrange
    key = 'ANSIBLE_TEST'
    value = u'café'

    # Act
    environ[key] = value

    # Assert
    assert key in environ
    assert environ[key] == value

# Generated at 2022-06-23 14:36:50.717967
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Test for method __delitem__ of class _TextEnviron
    """
    environ = _TextEnviron()
    var_name = "TEST_ENVIRON_VARIABLE"
    if var_name in environ:
        del environ[var_name]
    assert var_name not in environ
    environ[var_name] = "TEST_ENVIRON_VALUE"
    assert var_name in environ
    del environ[var_name]
    # On windows, deleting a variable only unsets it in the current process.  In order to test
    # the delete we have to force the C runtime to use our dict to get back 'None' instead of
    # the value of the variable in another process.
    if os.name == "nt":
        os.environ = environ._

# Generated at 2022-06-23 14:36:54.227786
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    key = 'PYTHONUTF8'
    value = '\u00e1'
    environ[key] = value
    assert len(environ) > 0


# Generated at 2022-06-23 14:37:02.194551
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    class MyEnviron(object):
        def __init__(self):
            self.map = {}
        def __getitem__(self, key):
            return self.map[key]
        def __setitem__(self, key, value):
            self.map[key] = value

    # test handling of bytes data in environment
    myenv = MyEnviron()
    myenv['text'] = b'abc'
    myenv['bytes'] = b'\x01\x02\x03'
    myt = _TextEnviron(myenv, encoding='ascii')
    assert myt['text'] == 'abc'
    # test bytes data which cannot be decoded
    myenv['undecodable'] = b'\xFF'

# Generated at 2022-06-23 14:37:04.204469
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    a_dict = _TextEnviron()
    assert len(a_dict) == len(environ)


# Generated at 2022-06-23 14:37:13.226066
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    try:
        del environ['ANSIBLE_TEST']
        raise AssertionError('Del should have thrown a KeyError')
    except KeyError:
        pass
    environ['ANSIBLE_TEST'] = 'test__TextEnviron___delitem__'
    assert environ['ANSIBLE_TEST'] == 'test__TextEnviron___delitem__'
    del environ['ANSIBLE_TEST']
    try:
        environ['ANSIBLE_TEST'] == 'test__TextEnviron___delitem__'
        raise AssertionError('Getting a key that was just deleted should have thrown a KeyError')
    except KeyError:
        pass


# Generated at 2022-06-23 14:37:14.431592
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:37:24.839173
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    new_environ = dict(os.environ)
    new_environ[to_bytes('TEST', encoding='utf-8')] = to_bytes('This is a test.', encoding='utf-8')

    # Create a text environ object and verify that it can return the value of TEST
    test_environ = _TextEnviron(env=new_environ)
    if PY3:
        assert test_environ[to_bytes('TEST', encoding='utf-8')] == 'This is a test.'
    else:
        assert test_environ[to_bytes('TEST', encoding='utf-8')] == 'This is a test.'

    # Try to decode using utf-8
    test_environ = _TextEnviron(env=new_environ, encoding='utf-8')

# Generated at 2022-06-23 14:37:28.254005
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from os import environ
    test_environ = _TextEnviron()
    for key, value in environ.items():
        assert (key in test_environ) == True


# Generated at 2022-06-23 14:37:31.789601
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    class _TextEnviron(MutableMapping):
        pass

    obj = _TextEnviron()
    assert iter(obj) is not None



# Generated at 2022-06-23 14:37:41.027774
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set the environment
    test_env = {
        'UNDECODED': b'ab\xc3\xa2cd',
        'DECODED': 'ab\xa2cd',
        'NON_UNICODE': 'ab\xcd\x9fcd',
        }
    for key, value in test_env.items():
        environ[key] = value

    # Verify that __getitem__ returns the decoded value
    assert environ['UNDECODED'] == 'abâcd'
    assert environ['DECODED'] == 'ab\xa2cd'
    assert environ['NON_UNICODE'] == 'ab\xcd\x9fcd'

    return True



# Generated at 2022-06-23 14:37:45.655221
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    new_environ = _TextEnviron()
    new_environ['TEST_ENV_VAR'] = 'Значение'
    assert new_environ['TEST_ENV_VAR'] == 'Значение'
    assert isinstance(new_environ['TEST_ENV_VAR'], str)