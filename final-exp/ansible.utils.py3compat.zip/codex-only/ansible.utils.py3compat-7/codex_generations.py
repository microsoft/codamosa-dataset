

# Generated at 2022-06-23 14:27:49.063680
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ_copy = environ.copy()
    try:
        del environ['PATH']
        assert environ._raw_environ['PATH'] == b'path'
        assert 'PATH' not in environ._raw_environ
    finally:
        environ._raw_environ = environ_copy._raw_environ
        environ._value_cache = environ_copy._value_cache


# Generated at 2022-06-23 14:27:55.085185
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-23 14:27:59.981266
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print('Testing __getitem__() of class _TextEnviron')
    environ = _TextEnviron(encoding='ascii')
    # "ȝ" is a character that is ch03, so it should become an x-surrogate when we attempt to
    # encode it to 'ascii'.
    os.environ['z'] = '\u02dc'
    if environ['z'] != '\udcf3':
        raise AssertionError(environ['z'])
    del os.environ['z']
    # "😘" is a character that is ch03, so it should become an x-surrogate when we attempt to
    # encode it to 'ascii'.
    os.environ['z'] = '\U0001f618'

# Generated at 2022-06-23 14:28:01.775461
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ.__iter__()) == list(os.environ.__iter__())


# Generated at 2022-06-23 14:28:05.542057
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils.six.moves import UserString
    env = _TextEnviron()
    for key in env:
        assert isinstance(env[key], (str, UserString))


# Generated at 2022-06-23 14:28:06.547360
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) > 0

# Generated at 2022-06-23 14:28:11.369807
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ.clear()
    environ['ansible_test'] = u'我喜欢做甜点'
    assert os.environ['ansible_test'] == u'我喜欢做甜点'.encode('utf-8')
    del environ['ansible_test']


# Generated at 2022-06-23 14:28:21.090001
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ2 = _TextEnviron(encoding='utf-8')

    environ2['test_string'] = 'value'
    assert environ2['test_string'] == 'value'
    assert environ2._raw_environ['test_string'] == b'value'

    environ2['test_bytes'] = b'value'
    assert environ2['test_bytes'] == 'value'
    assert environ2._raw_environ['test_bytes'] == b'value'

    if PY3:
        environ2['test_unicode'] = 'value'
        assert environ2['test_unicode'] == 'value'
        assert environ2._raw_environ['test_unicode'] == b'value'

    # Test converting non-text

# Generated at 2022-06-23 14:28:22.279219
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) > 0


# Generated at 2022-06-23 14:28:29.865077
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    class mock_environ:
        def __delitem__(self, key):
            self._key = key

        def __getitem__(self, key):
            self._key = key

        def __setitem__(self, key, value):
            self._key = key

        def get(self, key, default=None):
            return default

    # test
    with mock_environ() as env:
        env['test'] = 'test'
        del env['test']
        assert env._key == 'test'



# Generated at 2022-06-23 14:28:31.201854
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert sorted(list(environ)) == sorted(list(os.environ))

# Generated at 2022-06-23 14:28:34.077144
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    _raw_environ = {'ANSIBLE_TEST_KEY_ONE': 'First Value', 'ANSIBLE_TEST_KEY_TWO': 'Second Value'}
    te = _TextEnviron(_raw_environ)
    assert set(te) == set(_raw_environ)



# Generated at 2022-06-23 14:28:37.648886
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['test'] = 'value'
    assert 'test' in environ
    del environ['test']
    assert 'test' not in environ


# Generated at 2022-06-23 14:28:44.525376
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({'a': b'test'})
    assert environ['a'] == u'test'
    environ = _TextEnviron({'a': to_bytes('test')})
    assert environ['a'] == u'test'
    environ = _TextEnviron({'a': to_text('test')})
    assert environ['a'] == u'test'
    environ = _TextEnviron({'a': 'test'})
    assert environ['a'] == u'test'

# Generated at 2022-06-23 14:28:53.309953
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Scenario 1: Get the value of an environment variable, 'ANSIBLE_COW_SELECTION'
    # Given: The environment variable, 'ANSIBLE_COW_SELECTION', is set
    os.environ['ANSIBLE_COW_SELECTION'] = 'dragon-and-cow'

    # When: I get the value of 'ANSIBLE_COW_SELECTION'
    env_var_value = environ['ANSIBLE_COW_SELECTION']

    # Then: The value of 'ANSIBLE_COW_SELECTION' is returned
    assert env_var_value == 'dragon-and-cow'

# Generated at 2022-06-23 14:29:03.485136
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    old_environ = dict(os.environ)
    environ.clear()
    os.environ.clear()
    assert not os.environ
    assert not environ
    os.environ['a'] = 'byte'
    assert os.environ['a'] == 'byte'
    assert environ['a'] == u'byte'
    for key in environ:
        assert isinstance(key, unicode)
    os.environ.update(old_environ)
    environ.update(old_environ)

# Local variables:
# tab-width: 4
# c-basic-offset: 4
# indent-tabs-mode: nil
# End:
# vim: ft=python noet sw=4 ts=4 fdm=manual

# Generated at 2022-06-23 14:29:04.723525
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ.__getitem__('LANG') == 'en_US.UTF-8'
    assert environ.__getitem__('LANG') != b'en_US.UTF-8'


# Generated at 2022-06-23 14:29:06.082398
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PYTHONIOENCODING'] == 'utf-8'


# Generated at 2022-06-23 14:29:12.792658
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Set environment variable ANSIBLE_TEST_VAR to an arbitrary value
    environ['ANSIBLE_TEST_VAR'] = '123'
    # Check that we return the same value after casting it to text
    assert environ['ANSIBLE_TEST_VAR'] == to_text('123')
    # Delete the environment variable
    del environ['ANSIBLE_TEST_VAR']

# Generated at 2022-06-23 14:29:22.238494
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_env = {'foo':'foo', 'bar':'bar', 'baz':'baz'}
    test_obj = _TextEnviron(env=test_env)
    assert('foo' in test_obj)
    assert('bar' in test_obj)
    assert('baz' in test_obj)
    del test_obj['foo']
    assert('foo' not in test_obj)
    assert('bar' in test_obj)
    assert('baz' in test_obj)
    del test_obj['bar']
    assert('foo' not in test_obj)
    assert('bar' not in test_obj)
    assert('baz' in test_obj)
    del test_obj['baz']
    assert('foo' not in test_obj)

# Generated at 2022-06-23 14:29:26.941290
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import doctest
    import sys
    import textwrap

    results = doctest.testmod(
        m=sys.modules[__name__],
        optionflags=doctest.NORMALIZE_WHITESPACE,
        globs={}
    )
    if results.failed:
        sys.exit(1)

# Generated at 2022-06-23 14:29:37.942025
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Set an environment variable
    # encode as latin-1
    environ['ANSIBLE_TEST_VAR_LATIN1'] = '\xe9\u20ac'
    # encode as utf-8
    environ['ANSIBLE_TEST_VAR_UTF8'] = '\xe9\u20ac'

    # Reading the values back
    # ANSIBLE_TEST_VAR_LATIN1 should come back as latin-1
    assert environ['ANSIBLE_TEST_VAR_LATIN1'] == '\xe9\u20ac'
    # ANSIBLE_TEST_VAR_UTF8 should come back as utf-8
    assert environ['ANSIBLE_TEST_VAR_UTF8'] == '\xe9\u20ac'

    # Cleanup


# Generated at 2022-06-23 14:29:44.606147
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron()
    env_keys = len(env.keys())
    env_copy = env.copy()
    assert len(env) == len(env_copy)
    assert env == env_copy
    key = env_copy.keys()[0]
    del env_copy[key]
    assert len(env_copy) == env_keys - 1
    assert len(env_copy) != len(env)
    assert env != env_copy
    


# Generated at 2022-06-23 14:29:46.657707
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    e = _TextEnviron()
    assert len(e) == len(os.environ)



# Generated at 2022-06-23 14:29:52.761571
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Testing method __delitem__ of class _TextEnviron
    """
    test_pass_key = 'test_pass'
    test_fail_key = 'test_fail'
    env = _TextEnviron()
    env[test_pass_key] = 'test'
    try:
        del env[test_fail_key]
    except KeyError:
        pass
    else:
        raise AssertionError("KeyError Exception Not Raised")
    del env[test_pass_key]
    try:
        env[test_pass_key]
    except KeyError:
        pass
    else:
        raise AssertionError("KeyError Exception Not Raised")



# Generated at 2022-06-23 14:29:55.703254
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    container = dict()
    container['test'] = 'test__TextEnviron___delitem__'
    environ = _TextEnviron(env=container)
    del environ['test']
    assert not container



# Generated at 2022-06-23 14:30:01.932667
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import os
    import copy
    import os.path
    import tempfile

    file_to_create = os.path.join(tempfile.gettempdir(), 'test__TextEnviron___len__')
    # Unset the variable so it's not present in the environment
    os.environ.pop('ANSIBLE_TEST_FILE', None)

    # Make sure we can't find the file
    assert not os.path.exists(file_to_create)

    # Make sure we can open the file
    with open(file_to_create, 'wb') as fp:
        fp.write(b'foo')

    # Make sure we can make the file vanish
    os.unlink(file_to_create)

    # Make sure the file is gone

# Generated at 2022-06-23 14:30:04.462565
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({'ANSIBLE_TEST_KEY': 'ANSIBLE_TEST_VALUE'}, encoding='utf-8')
    assert 1 == len(env)


# Generated at 2022-06-23 14:30:06.039735
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    assert len(env) == len(os.environ)



# Generated at 2022-06-23 14:30:09.656526
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron()
    for key, value in os.environ.items():
        assert environ[key] == value

# Generated at 2022-06-23 14:30:19.157174
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    te = _TextEnviron(encoding='utf-8')

    te['w'] = 'value'
    assert te['w'] == 'value'
    assert te._raw_environ['w'] == b'value'

    te['s'] = u'strùng'
    assert te['s'] == u'strùng'
    assert te._raw_environ['s'] == b'str\xc3\xb9ng'

    var = u'unic∞de'
    te['unicode'] = var
    assert te['unicode'] == var
    assert te._raw_environ['unicode'] == b'unic\xe2\x88\x9ede'

    te['binary'] = b'binary\xe2\x88\x9ede'

# Generated at 2022-06-23 14:30:24.769832
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['test___delitem__'] = 'test_value'
    assert environ['test___delitem__'] == 'test_value'
    del environ['test___delitem__']
    try:
        assert environ['test___delitem__']
    except KeyError as e:
        print(e)
        assert True
    else:
        assert False
test__TextEnviron___delitem__()


# Generated at 2022-06-23 14:30:26.549891
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:30:34.843376
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Create a test object using the os.environ which is always a byte string
    test_env = _TextEnviron(env={b'foo': b'bar'})
    # Check that the same value comes back on Python3
    if PY3:
        assert test_env['foo'] == 'bar'
        assert list(test_env.keys()) == ['foo']
    else:
        # Check that the value is converted to text using the encoding we specified in the
        # constructor
        assert test_env['foo'] == 'bar'
        assert list(test_env.keys()) == [u'foo']

# Generated at 2022-06-23 14:30:44.626408
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-23 14:30:52.474682
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Test for deletion of existing key
    env = _TextEnviron(env={'MY_TEST': 'test_value'})

    del env['MY_TEST']

    assert 'MY_TEST' not in env
    assert env._raw_environ.get('MY_TEST') is None

    # Test for deletion of non-existing key
    env = _TextEnviron()

    del env['MY_TEST']

    assert 'MY_TEST' not in env
    assert env._raw_environ.get('MY_TEST') is None


# Generated at 2022-06-23 14:30:59.929720
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Unit test for method __delitem__ of class _TextEnviron.
    """

    # Try to remove a key which exists
    environ['key1'] = 'value1'
    del environ['key1']
    assert 'key1' not in environ

    # Try to remove a key which doesn't exist.  Will throw a key error.
    try:
        del environ['key1']
        assert 1 == 0
    except KeyError:
        assert 1 == 1



# Generated at 2022-06-23 14:31:06.601671
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that the caching works.  Change an environment variable in the middle of a run.  Ansible 2.7
    # will use this cached value in its templating engine instead of the environment variable.
    test_environ = _TextEnviron(encoding='utf-8')
    test_environ['FOO'] = 'bar'
    result = test_environ['FOO']
    assert result == "bar"
    test_environ['FOO'] = 'baz'
    result = test_environ['FOO']
    assert result == "baz"

# Generated at 2022-06-23 14:31:15.112689
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    from ansible.module_utils.six import PY3
    if PY3:
        test_env = environ
    else:
        test_env = _TextEnviron(encoding='utf-8')
    # Test deleting a key that already exists on the environment
    key = 'ANSIBLE_TEST_ENV1'
    if key in test_env:
        del environ[key]
    # Test deleting a key that doesn't exist on the environment
    key = 'ANSIBLE_TEST_ENV2'
    if key in test_env:
        del environ[key]
    if PY3:
        del environ.encoding


# Generated at 2022-06-23 14:31:19.952244
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # the method should act like the _raw_environ.__delitem__()
    environ_ = _TextEnviron(env={'a':'123', 'b':'456'})
    environ_.__delitem__('a')
    assert environ_._raw_environ == {'b':'456'}


# Generated at 2022-06-23 14:31:22.491180
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['TestKey'] = b'TestValue'
    del environ['TestKey']
    assert 'TestKey' not in environ


# Generated at 2022-06-23 14:31:24.688353
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    class_obj = _TextEnviron(encoding='utf-8')
    assert isinstance(class_obj, _TextEnviron)

# Generated at 2022-06-23 14:31:28.930072
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron(encoding='utf-8')
    environ[u'ANSIBLE_TEST_ENV_VAR'] = u'a'
    assert environ[u'ANSIBLE_TEST_ENV_VAR'] == u'a'

# Generated at 2022-06-23 14:31:32.342961
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils import six

    # TODO: figure out how to get at the .environ object when this is installed in six
    #if six.PY3:
    #    assert environ is environ._raw_environ

    expected_encoding = sys.getfilesystemencoding()
    assert expected_encoding == environ.encoding



# Generated at 2022-06-23 14:31:37.648214
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    e = _TextEnviron({"name": "foo", "user": "bar"})
    assert sorted(e.keys()) == ["name", "user"]
    del e["name"]
    assert sorted(e.keys()) == ["user"]
    try:
        del e["name"]
    except KeyError:
        pass
    else:
        assert False, "Must raise KeyError"



# Generated at 2022-06-23 14:31:43.716477
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """_TextEnviron.__setitem__"""
    env = _TextEnviron()
    env['test'] = 'ほげ'
    assert env['test'] == 'ほげ'
    assert to_text(env._raw_environ[b'test'], encoding='utf-8') == 'ほげ'

# Generated at 2022-06-23 14:31:46.183338
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, MutableMapping)
    assert environ.encoding == 'utf-8'
    assert 'PYTHONIOENCODING' in environ
    assert isinstance(environ['PYTHONIOENCODING'], str)
    assert environ['PYTHONIOENCODING'] == 'utf-8'



# Generated at 2022-06-23 14:31:56.376270
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron()

    try:
        # Test non-str/non-bytes input
        environ['an_int'] = 42
        # Test 'strict' settings for non-str/non-bytes input
        environ['an_int'] = 42
    except TypeError:
        pass
    else:
        raise RuntimeError('_TextEnviron._setitem_() does not handle non-str/non-bytes in strict mode')

    # Test 'surrogate_then_replace' settings for non-str/non-bytes input
    environ['an_int'] = 42
    del environ['an_int']

    environ['a_none'] = None
    del environ['a_none']

    # Test that it accepts unicode

# Generated at 2022-06-23 14:32:06.996416
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'non_unicode_key1': b'non_unicode_value'})
    non_unicode_key1 = env['non_unicode_key1']
    assert non_unicode_key1 == 'non_unicode_value', non_unicode_key1
    env['non_unicode_key2'] = u'non_unicode_value'
    non_unicode_key2 = env['non_unicode_key2']
    assert non_unicode_key2 == 'non_unicode_value', non_unicode_key2
    # We mimic the behaviour of os.environ so we can't raise errors on unicode

# Generated at 2022-06-23 14:32:15.123571
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Prepare test data
    key = 'key'
    value = 'значение'

    # Run method under test
    environ[key] = value

    # Verify results
    key_bytes = to_bytes(key, encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    assert environ._raw_environ[key_bytes] == to_bytes(value, encoding='utf-8',
                                                       nonstring='strict', errors='surrogate_or_strict')



# Generated at 2022-06-23 14:32:19.990639
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():

    env = dict(key1='value1', key2='value2')

    textenviron = _TextEnviron(env=env)

    actual = list(iter(textenviron))

    expected = ['key1', 'key2']

    assert actual == expected



# Generated at 2022-06-23 14:32:24.606203
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # We can't test that this class will always return a text object.  Sometimes 'surrogate_or_strict'
    # will return a text object, but if the input is a surrogate bytes object, it will return a
    # bytes object instead.  We accept this behaviour.
    pass


# Generated at 2022-06-23 14:32:30.746928
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, MutableMapping)
    assert len(environ) == len(os.environ)
    for key in os.environ:
        assert environ[key] == os.environ[key]
        assert isinstance(environ[key], text_type)
        assert os.environ[key] == environ[key]
        assert isinstance(os.environ[key], text_type)

# Generated at 2022-06-23 14:32:34.821781
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    test_environ = {'a': '1', 'b': '2', 'c': '3'}
    environ = _TextEnviron(test_environ)
    assert all(x in ['a', 'b', 'c'] for x in environ)


# Generated at 2022-06-23 14:32:38.849659
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    test_env = {'LANG': 'ja_JP.UTF-8'}
    environ._raw_environ = test_env
    assert environ['LANG'] == 'ja_JP.UTF-8'



# Generated at 2022-06-23 14:32:40.711622
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    assert isinstance(environ['PATH'], str)

# Generated at 2022-06-23 14:32:45.675066
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test environment
    os.environ['ANSIBLE_TEST_ENVVAR'] = 'abc\xe9'

    # Test assertions
    assert isinstance(environ, MutableMapping)
    assert isinstance(environ['ANSIBLE_TEST_ENVVAR'], str)
    assert environ['ANSIBLE_TEST_ENVVAR'] == 'abc\xe9'



# Generated at 2022-06-23 14:32:47.414722
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ._raw_environ['FOO'] = b'bar'
    assert environ['FOO'] == 'bar'



# Generated at 2022-06-23 14:32:51.618569
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['abc'] = 'abc'
    assert environ['abc'] == 'abc'
    environ['abc'] = u'abc'
    assert environ['abc'] == 'abc'
    environ['abc'] = b'abc'
    assert environ['abc'] == 'abc'

# Generated at 2022-06-23 14:32:54.469705
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test the constructor
    env = _TextEnviron()

    # Test that we have the same number of items returned
    assert len(os.environ) == len(env)



# Generated at 2022-06-23 14:32:55.341138
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    assert type(env['PATH']) is type(u'')

# Generated at 2022-06-23 14:32:58.457474
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os.environ['FOO'] = 'bar'
    del os.environ['PATH']

    list_of_keys = []

    for key in environ:
        list_of_keys.append(key)

    assert list_of_keys == ['FOO']


# Generated at 2022-06-23 14:33:05.391159
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import os
    e = _TextEnviron()
    os.environ['ANSIBLE_TEST_ENV_VAR'] = 'Íťöngęr техτ'
    if PY3:
        assert e['ANSIBLE_TEST_ENV_VAR'] == 'Íťöngęr техт'
    else:
        assert e['ANSIBLE_TEST_ENV_VAR'] == u'Íťöngęr техт'

# Generated at 2022-06-23 14:33:07.257655
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os.environ['FOO'] = 'bar'
    assert dict(environ).keys() == dict(os.environ).keys()

# Generated at 2022-06-23 14:33:13.448434
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # pylint: disable=protected-access
    # Test normal constructor
    assert environ._raw_environ is os.environ
    assert environ.encoding == environ._TextEnviron.encoding

    # Test constructor with param
    raw_environ = {'a': 'c'}
    environ = _TextEnviron(raw_environ, 'utf-8')
    assert environ._raw_environ is raw_environ
    assert environ.encoding == 'utf-8'



# Generated at 2022-06-23 14:33:14.847949
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ) == list(environ.keys())


# Generated at 2022-06-23 14:33:20.216504
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = environ.copy()
    test_environ['ANSIBLE_TEST_VAR'] = 'ünicode valüe'
    environ_with_cached_keys = _TextEnviron(env=test_environ, encoding='utf-8')
    environ_with_cached_keys.__getitem__('ANSIBLE_TEST_VAR')
    assert environ_with_cached_keys._value_cache['ünicode valüe'] == 'ünicode valüe'


# Generated at 2022-06-23 14:33:24.514498
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Test the constructor of _TextEnviron

    Test that we can construct the object with different input and that it gets
    converted to the right output
    """
    # Use _TextEnviron with default data
    text_environ = _TextEnviron(encoding='utf-8')
    assert text_environ._raw_environ is os.environ
    assert text_environ.encoding == 'utf-8'
    # Create input data with bytes and unicode strings
    input_environ = {'a': 'b', 'c': u'd', 'e': b'f'}
    text_environ = _TextEnviron(env=input_environ, encoding='utf-8')

# Generated at 2022-06-23 14:33:35.296844
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ._raw_environ = {}
    environ._value_cache = {}

    # Test: basic test
    environ.__setitem__('key1', 'value1')
    assert b'key1' in environ._raw_environ
    assert environ._raw_environ[b'key1'] == b'value1'
    assert b'value1' in environ._value_cache
    assert environ._value_cache[b'value1'] == 'value1'

    # Test: strict non-string test
    environ.__setitem__('key2', 2)
    assert b'key2' in environ._raw_environ
    assert environ._raw_environ[b'key2'] == b'2'
    assert b'2' in environ._value_cache
    assert environ._

# Generated at 2022-06-23 14:33:41.259236
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['OTHER_VAR'] = 'Other value'
    assert 'Other value' == environ['OTHER_VAR']
    environ['OTHER_VAR'] = b'Other value'
    assert 'Other value' == environ['OTHER_VAR']
    environ['OTHER_VAR'] = b'Other \xe9 value'
    assert u'Other \ufffd value' == environ['OTHER_VAR']
    environ['OTHER_VAR'] = 'Other \xe9 value'
    assert u'Other \ufffd value' == environ['OTHER_VAR']


# Generated at 2022-06-23 14:33:52.225319
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, MutableMapping)
    assert not isinstance(environ, dict)

    raw_environ = os.environ
    assert raw_environ is not environ
    if PY3:
        assert raw_environ == environ
    else:
        assert raw_environ != environ

    if PY3:
        # Verify that we can set and get a unicode value with no transformation on PY3
        environ['UNICODE_KEY'] = b'unicode value'
        assert environ['UNICODE_KEY'] == u'unicode value'
    else:
        environ['UNICODE_KEY'] = b'unicode value'
        assert environ['UNICODE_KEY'] == u'unicode value'

# Generated at 2022-06-23 14:33:58.355665
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ[u'FOO'] == u'bar'
    environ[u'TEST_1'] = u'\u00fch\u00e4\u00fc\u00ef\u00eb'
    assert environ[u'TEST_1'] == u'\u00fch\u00e4\u00fc\u00ef\u00eb'



# Generated at 2022-06-23 14:34:02.871238
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    method __len__() should return the amount of items in the environment
    """
    # Test: create a new _TextEnviron, check len
    test = _TextEnviron()
    assert len(test) == len(os.environ)


# Generated at 2022-06-23 14:34:06.659329
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ = _TextEnviron({'foo': 'bar'})
    del environ['foo']
    assert 'foo' not in environ
    # TODO : Need to handle exceptions


# Generated at 2022-06-23 14:34:08.769893
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os_environ_keys = set(os.environ.keys())
    environ_keys = set(environ.keys())
    assert os_environ_keys == environ_keys


# Generated at 2022-06-23 14:34:12.663664
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron(encoding='utf-8')
    for key in environ:
        assert key in os.environ
    for key in os.environ:
        assert key in environ


# Generated at 2022-06-23 14:34:18.301942
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test bytes
    environ = _TextEnviron(env={'a': b'\xe2\x98\x95'})
    assert environ['a'] == to_text('\xe2\x98\x95', 'utf-8')

    # Test text
    environ = _TextEnviron(env={'a': '\u2605'})
    assert environ['a'] == '\u2605'



# Generated at 2022-06-23 14:34:24.591115
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-23 14:34:27.560300
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ._raw_environ = {'AN': '2'}
    del environ['AN']
    assert 'AN' not in environ


# Generated at 2022-06-23 14:34:38.032954
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # pylint: disable=redefined-outer-name,unused-variable
    # pytest defined fixture
    import pytest

    # _TextEnviron should be a MutableMapping
    assert issubclass(_TextEnviron, MutableMapping)

    # Check that initializing _TextEnviron with a dict returns a _TextEnviron object
    env_dict = dict(one="1", two="2", three="3")
    assert not isinstance(env_dict, _TextEnviron)
    te = _TextEnviron(env_dict)
    assert isinstance(te, _TextEnviron)

    # Check that the environment that we get back is the same as the environment we provided
    assert te['one'] == env_dict['one']
    assert te['two'] == env_dict['two']

    # Check that the environment can

# Generated at 2022-06-23 14:34:47.646087
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes
    if PY3:
        import unittest.mock as mock
        mock.patch.dict(os.environ, {'SOMETHING_UNICODE': 'é'})
        assert environ['SOMETHING_UNICODE'] == 'é'
        mock.patch.dict(os.environ, {'SOMETHING_BYTES': to_bytes('é')})
        assert environ['SOMETHING_BYTES'] == to_bytes('é')
    else:
        import mock
        with mock.patch.dict(os.environ, {'SOMETHING_UNICODE': 'é'}):
            assert environ['SOMETHING_UNICODE'] == 'é'

# Generated at 2022-06-23 14:34:54.589322
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    #
    # Test that del env['key'] works.
    #

    # Set up a test key first
    key = 'ANSIBLE_TEST_ENV_' + os.urandom(8).encode('hex')

    # Just a simple case that the key gets deleted
    environ[key] = 'test'
    assert environ[key] == 'test'
    del environ[key]
    assert key not in environ

    # Test that deleting a key that doesn't exist does the right thing
    try:
        del environ[key]
    except KeyError:
        pass
    else:
        assert False, 'KeyError should be raised if key does not exist'



# Generated at 2022-06-23 14:35:04.923985
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == os.path.expanduser('~'), "Default encoding of module_utils.six.environ not working"

    env_clone = _TextEnviron(env=environ, encoding='ascii')

    if PY3:
        # On Python3, the result should always be the same since we're always decoding utf-8
        assert environ['HOME'] == env_clone['HOME'], "Default encoding of module_utils.six.environ not working"
    else:
        # On Python2, the result should be different since we're not using utf-8 to decode the
        # values in the first environment
        assert environ['HOME'] != env_clone['HOME'], "Default encoding of module_utils.six.environ not working"

# Generated at 2022-06-23 14:35:11.926569
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    def _setup():
        environ['__TEST__'] = 'TEST'

    def _run(expected_result):
        assert len(environ) == expected_result

    def _teardown():
        del environ['__TEST__']

    _setup()
    _run(expected_result=1)
    _teardown()

    _setup()
    _run(expected_result=1)
    _teardown()


# Generated at 2022-06-23 14:35:19.849066
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    local_environ = {}
    env = _TextEnviron(env=local_environ)
    env['MY_VAR'] = '123'
    assert local_environ['MY_VAR'] == b'123'

    env['MY_VAR'] = '我是中国人'.encode('utf-8')
    assert local_environ['MY_VAR'] == b'\xe6\x88\x91\xe6\x98\xaf\xe4\xb8\xad\xe5\x9b\xbd\xe4\xba\xba'

    # Non-string types
    env['MY_VAR'] = 5
    assert local_environ['MY_VAR'] == b'5'
    env.encoding = 'ascii'

# Generated at 2022-06-23 14:35:22.889139
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Ensure that on Python 2, constructing the class has not changed the
    # type of os.environ
    orig_environ = os.environ
    _TextEnviron()
    assert orig_environ == os.environ

# Generated at 2022-06-23 14:35:27.700135
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['a'] = 'a'
    assert type(environ['a']) == str
    assert environ['a'] == 'a'
    environ['b'] = 'á'
    assert type(environ['b']) == str
    assert environ['b'] == 'á'
    environ['c'] = b'c'
    assert type(environ['c']) == str
    assert environ['c'] == 'c'

# Generated at 2022-06-23 14:35:37.294338
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
  # Three tests:
  #   Unset a string key
  #   Unset a unicode key
  #   Unset a key that is not set

  # Unset a string key
  environ['testkey'] = 'value'
  assert 'testkey' in environ
  del environ['testkey']
  assert 'testkey' not in environ

  # Unset a unicode key
  environ[u'testkey'] = u'value'
  assert u'testkey' in environ
  del environ[u'testkey']
  assert u'testkey' not in environ

  # Unset an key that is not set
  del environ['testkey']



# Generated at 2022-06-23 14:35:41.881964
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['_TextEnviron_test_key'] = '_TextEnviron_test_value'
    assert environ['_TextEnviron_test_key'] == '_TextEnviron_test_value'
    del environ['_TextEnviron_test_key']
    assert '_TextEnviron_test_key' not in environ


# Generated at 2022-06-23 14:35:44.877714
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    my_dict = _TextEnviron()
    my_dict['key'] = 'value'
    assert 'key' in my_dict
    del my_dict['key']
    assert 'key' not in my_dict


# Generated at 2022-06-23 14:35:47.553171
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ._raw_environ.clear()
    environ._raw_environ['key'] = 'value'
    assert environ['key'] == 'value'
    del environ['key']
    assert 'key' not in environ



# Generated at 2022-06-23 14:35:57.176872
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # It appears that os.environ is implemented differently on Windows than on POSIX systems.
    # We're going to test with different environment variables on each system.
    #
    # Note: This should pass on all systems.  If it fails everywhere, we probably have an issue
    # with the test itself.
    if sys.platform == 'win32':
        # Windows: Make sure that the drive letter is encoded with the filesystem encoding
        #
        # On Windows, the environment variables are actually bytes.
        # Make sure that our code can handle this

        # Get the environment variable encoding
        encoding = sys.getfilesystemencoding()
        # We have to have an explicit variable because PY3 is False on Windows
        is_py3 = sys.version_info[0] == 3

# Generated at 2022-06-23 14:35:59.305973
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['test_var'] = 'test_value'
    assert environ['test_var'] == 'test_value'


# Generated at 2022-06-23 14:36:00.713828
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert 3 == len(environ)


# Generated at 2022-06-23 14:36:08.281414
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os.environ['THIS_IS_A_TEST'] = 'value'
    os.environ['THIS_IS_A_TEST2'] = 'value2'
    things = list(environ)
    assert len(things) == 2
    assert 'THIS_IS_A_TEST' in things
    assert 'THIS_IS_A_TEST2' in things
    del os.environ['THIS_IS_A_TEST2']
    del os.environ['THIS_IS_A_TEST']


# Generated at 2022-06-23 14:36:13.569763
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    _test_env_var = u'test_env'
    _test_value = u'test_value'
    test_env = _TextEnviron(encoding='utf-8')
    test_env[_test_env_var] = _test_value
    test_value = environ[_test_env_var]
    assert _test_value == test_value



# Generated at 2022-06-23 14:36:18.127967
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    raw_env = {to_bytes('foo'): to_bytes('bar'), to_bytes('föó'): to_bytes('bär')}
    env = _TextEnviron(env=raw_env, encoding='utf-8')
    for key in env:
        assert key in raw_env.keys()



# Generated at 2022-06-23 14:36:25.760875
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = {
        ('key1', 'utf8'): '\xc3\xa9',
        ('key2', 'latin1'): '\xe9',
        ('key3', 'ascii'): '\xc3\xa9',  # This is an invalid encoding, but tests our error handling
        ('key4', 'utf8'): '\xc3\xa9',
        ('key5', 'utf8'): '\xef\xbf\xbc',
    }

    for (key, encoding), value in env.items():
        if PY3:
            assert value == to_text(value, encoding=encoding, errors='surrogate_or_strict')
        else:
            assert value == to_text(value, encoding=encoding, errors='surrogate_or_strict')

# Generated at 2022-06-23 14:36:27.851501
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['foo'] = u'bar'
    assert environ['foo'] == u'bar'

# Generated at 2022-06-23 14:36:37.291750
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ.clear()
    assert {} == environ
    # Set an ASCII-only environment variable
    environ['hello'] = 'world'
    assert 1 == len(environ)
    assert 'world' == environ['hello']
    # Set another ASCII-only environment variable
    environ['foo'] = 'bar'
    assert 2 == len(environ)
    assert 'bar' == environ['foo']
    # Set an non-ASCII environment variable
    environ['baz'] = 'ñ'
    assert 3 == len(environ)
    assert 'ñ' == environ['baz']
    # Set an environment variable with a Unicode replacement character
    environ['baz'] = u'\ufffd'
    assert 3 == len(environ)
    assert u'\ufffd' == environ['baz']


# Generated at 2022-06-23 14:36:39.305303
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # len(environ)
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:36:43.973482
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # os.environ may have bytes or text depending on the Python version
    if PY3:
        env_keys = os.environ.keys()
    else:
        env_keys = sorted(os.environ.keys(), key=lambda k: k.lower())

    assert sorted(environ.keys()) == env_keys

# Generated at 2022-06-23 14:36:50.139691
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Test the case of method __delitem__ of class _TextEnviron
    """
    # Case 1: Delete the item in self._raw_environ
    test = _TextEnviron()
    test['TESTVAR'] = 'test'
    assert test['TESTVAR'] == 'test'
    del test['TESTVAR']
    assert 'TESTVAR' not in test


# Generated at 2022-06-23 14:36:56.628740
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    from ansible.module_utils._text import to_bytes, to_native

    if PY3:
        encoding = 'utf-8'
    else:
        encoding = 'ascii'
    # Test with a change in environment
    e = _TextEnviron(encoding=encoding)
    k = to_bytes('THIS IS A TEST', encoding=encoding)
    v = to_bytes('Hello World', encoding=encoding)
    os.environ[k] = v
    value = e[k]
    assert value == v.decode(encoding)

    # Test with caching off
    v = to_bytes('Goodbye World', encoding=encoding)
    os.environ[k] = v
    value = e[k]
    assert value == v.decode(encoding)
   

# Generated at 2022-06-23 14:37:06.880967
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['BYTESUNICODE'] = b'\xc3\xb1'
    os.environ['BYTESUTF8'] = b'\xc3\xb1'.decode('utf-8')
    os.environ['BYTESUTF8'] = b'\xc3\xb1'.decode('utf-8')
    os.environ['UNICODE'] = b'\xc3\xb1'.decode('utf-8')
    assert environ['BYTESUNICODE'] == b'\xc3\xb1'.decode('utf-8')
    assert environ['BYTESUTF8'] == b'\xc3\xb1'.decode('utf-8')
    assert environ['UNICODE'] == b'\xc3\xb1'.decode('utf-8')



# Generated at 2022-06-23 14:37:08.472543
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert isinstance(environ, MutableMapping)



# Generated at 2022-06-23 14:37:13.439712
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_test = _TextEnviron()
    environ_test._raw_environ['test'] = "test1"
    environ_test._raw_environ['test_multi'] = "test2"
    assert environ_test._raw_environ['test'] == "test1"
    assert environ_test._raw_environ['test_multi'] == "test2"

# Generated at 2022-06-23 14:37:22.900948
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert len(_TextEnviron()) == len(environ)
    assert isinstance(_TextEnviron(), MutableMapping)
    assert _TextEnviron().__getitem__('PYTHONHASHSEED') == environ['PYTHONHASHSEED']
    # Create a clone and make sure it shares the same state we do
    cloned_env = _TextEnviron(env=environ)
    assert cloned_env == environ
    environ['TESTMOCKENV'] = 'test'
    assert 'TESTMOCKENV' in environ
    assert environ['TESTMOCKENV'] == 'test'
    assert cloned_env['TESTMOCKENV'] == 'test'


# Generated at 2022-06-23 14:37:28.253186
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({'one':1, 'two':2, 'three':3})
    env_iter = env.__iter__()
    assert next(env_iter) == 'one'
    assert next(env_iter) == 'two'
    assert next(env_iter) == 'three'
    assert next(env_iter, None) is None



# Generated at 2022-06-23 14:37:39.534663
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(encoding='utf-8')
    env['TEST_KEY'] = 'TestValue'
    assert env['TEST_KEY'] == 'TestValue'
    assert isinstance(env['TEST_KEY'], str)
    env['TEST_KEY'] = 'TestValue_unicode_ä'
    assert env['TEST_KEY'] == 'TestValue_unicode_ä'
    assert isinstance(env['TEST_KEY'], str)

    env = _TextEnviron(encoding='ascii')
    env['TEST_KEY'] = 'TestValue'
    assert env['TEST_KEY'] == 'TestValue'
    assert isinstance(env['TEST_KEY'], str)
    env['TEST_KEY'] = 'TestValue_unicode_ä'
    assert env

# Generated at 2022-06-23 14:37:50.020511
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Verify approach 1: check decoding is happening as expected
    assert 'SIMPLE_TEST_VAR' not in environ
    os.environ['SIMPLE_TEST_VAR'] = 'SUCCESS'
    assert environ['SIMPLE_TEST_VAR'] == 'SUCCESS'
    # Verify approach 2: check encoding is happening as expected
    os.environ['SIMPLE_TEST_VAR'] = b'\xC3\xA9'
    assert environ['SIMPLE_TEST_VAR'] == u'\xe9'
    # Check that pass-thru happens with non-strings
    os.environ['SIMPLE_TEST_VAR'] = 0xdeadbeef