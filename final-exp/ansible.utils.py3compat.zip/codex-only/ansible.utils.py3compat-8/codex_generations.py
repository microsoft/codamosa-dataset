

# Generated at 2022-06-23 14:27:46.227442
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron(env={}, encoding='utf-8')
    env['test_key'] = 'test_val'
    del env['test_key']
    try:
        env['test_key']
    except KeyError:
        pass
    else:
        raise

# Generated at 2022-06-23 14:27:53.172643
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # The environment should be in ascii bytes.  This means that internally, things are
    # stored in bytes not unicode strings.
    # If we set the environment to an ascii value, it should come out as ascii
    environ['TEST_VAR'] = 'ascii_value'
    assert to_bytes('ascii_value') == environ._raw_environ['TEST_VAR']
    # And if we retrieve the value, we should get a python 2 unicode string
    assert 'ascii_value' == environ['TEST_VAR']
    # If we try to set a unicode string, we should get a bytes string
    environ['TEST_VAR'] = 'fööbär'

# Generated at 2022-06-23 14:27:58.119217
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    >>> environ = _TextEnviron(encoding='utf-8')
    >>> environ['TEST_INPUT_VARIABLE'] = 'test input'
    >>> b'TEST_INPUT_VARIABLE' in os.environ and 'test input' in os.environ.values()
    True
    """

# Generated at 2022-06-23 14:28:00.570075
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    result = 'PYTHON3' in environ
    assert result, 'Failed to find PYTHON3 in environment!'



# Generated at 2022-06-23 14:28:11.431456
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """Test unicode data entered into environ using Text_environ[key] = value

    This function test whether unicode data is correctly entered into the environ
    when we use environ[key] = value.  The data will be entered in to the dict and
    the bytes representation will be in the raw environ and the text version in the
    value cache.
    """
    from ansible.module_utils._text import to_bytes, to_text
    environ = _TextEnviron()

    # Test unicode data entered into environ using Text_environ[key] = value
    environ['key1'] = u'value1\u2603'
    fsencoding = sys.getfilesystemencoding()
    assert environ['key1'] == u'value1\u2603'

# Generated at 2022-06-23 14:28:16.874464
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ_temp = _TextEnviron(encoding='utf-8')
    environ_temp['test_key'] = 'test_value'
    assert environ_temp['test_key'] == 'test_value'
    del environ_temp['test_key']
    with pytest.raises(KeyError):
        environ_temp['test_key']


# Generated at 2022-06-23 14:28:28.455960
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert dict(environ) == dict(os.environ)
    # Sanity check for our caching
    environ.update({to_bytes(u'ANSIBLE_TEST_KEY_1', encoding=environ.encoding):
                    to_bytes(u'ANSIBLE_TEST_VALUE_1', encoding=environ.encoding)})
    environ.update({to_bytes(u'ANSIBLE_TEST_KEY_2', encoding=environ.encoding):
                    to_bytes(u'ANSIBLE_TEST_VALUE_2', encoding=environ.encoding)})
    environ.update({to_bytes(u'ANSIBLE_TEST_KEY_3', encoding=environ.encoding):
                    to_bytes(u'ANSIBLE_TEST_VALUE_3', encoding=environ.encoding)})


# Generated at 2022-06-23 14:28:35.508402
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import os
    if not PY3 and '_' in os.environ:
        del os.environ['_']

    my_env = _TextEnviron({'hello': 'world'})
    assert len(list(my_env)) == 1
    assert len(list(my_env.keys())) == 1
    assert len(my_env.values()) == 1

    for key in my_env:
        assert key == 'hello'

    for key in my_env.keys():
        assert key == 'hello'

    for value in my_env.values():
        assert value == 'world'

    values = []
    for key, value in my_env.items():
        values.append((key, value))
    assert len(values) == 1
    assert values[0] == ('hello', 'world')


#

# Generated at 2022-06-23 14:28:36.608914
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # _TextEnviron input checking
    with pytest.raises(TypeError):
        _TextEnviron(env = 12345)


# Generated at 2022-06-23 14:28:42.859869
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that method __getitem__ of class _TextEnviron returns unicode in Python2.
    old_val = None
    try:
        old_val = environ['LANG']
        environ['LANG'] = 'en_US.UTF-8'
        assert isinstance(environ['LANG'], text_type)
    finally:
        if old_val is not None:
            environ['LANG'] = old_val
        else:
            del environ['LANG']

# Generated at 2022-06-23 14:28:44.193911
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron()
    print(environ.__len__())

# Generated at 2022-06-23 14:28:47.684393
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    try:
        del environ["PYTHONPATH"]
    except KeyError:
        pass
    else:
        assert False, "Failed to raise KeyError"


# Generated at 2022-06-23 14:28:49.977777
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, MutableMapping)
    assert not isinstance(environ, dict)


# Unit tests for __setitem__ of class _TextEnviron

# Generated at 2022-06-23 14:28:52.946042
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """
    Validate the __iter__ method of class _TextEnviron
    """
    for i, k in enumerate(environ):
        assert k == 'ANSIBLE_%d' % i


# Generated at 2022-06-23 14:29:03.484885
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    class FakeEnv():
        def __init__(self):
            self.storage = {}

        def __setitem__(self, key, value):
            self.storage[key] = value

        def __delitem__(self, key):
            del self.storage[key]

        def __getitem__(self, key):
            return self.storage[key]

        def __iter__(self):
            return iter(self.storage)

        def __len__(self):
            return len(self.storage)

    # Test class constructor
    # 1. First, test if the class can create _TextEnviron with default parameters
    # 2. Second, test if the class can create _TextEnviron with custom encoding
    # 3. Third, test if the class can create _TextEnviron with env is set
    # 4. Fourth, test

# Generated at 2022-06-23 14:29:06.432308
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test with default values (None for env and encoding)
    text_environ = _TextEnviron()
    assert text_environ.encoding == sys.getfilesystemencoding()
    assert text_environ._raw_environ is os.environ
    assert text_environ._value_cache == {}
    # Test with an env passed in
    env = {}
    text_environ = _TextEnviron(env)
    assert text_environ.encoding == sys.getfilesystemencoding()
    assert text_environ._raw_environ is env
    assert text_environ._value_cache == {}


# Generated at 2022-06-23 14:29:17.707721
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # the 'encoding' parameter to the _TextEnviron constructor is used to decode the values of the
    # environment variables.  This makes it difficult to test when the default value for that
    # parameter is used.

    # Set encoding to non-default value
    environ = _TextEnviron(encoding='utf-8')

    # TODO: It'd be nice to know how to insert non-ascii characters into the environment on all
    # platforms
    # environ['nonascii'] = b'\xc2\xa9'  # b'\xc2\xa9' is unicode copyright symbol

    # Test the __getitem__ method
    assert environ['HOME'] == u'/home/toshio'
    # assert environ['nonascii'] == u'\xa9'

# Generated at 2022-06-23 14:29:20.306450
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron(env={b'key': b'value'}, encoding='utf-8')
    assert len(env) == len({b'key': b'value'})



# Generated at 2022-06-23 14:29:24.701984
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a TextEnviron instance
    #__getitem__ will be called
    text_environ = _TextEnviron()
    # Mock the __getitem__ of os.environ
    os.environ.__getitem__ = Mock(return_value="🐦")
    # Call the __getitem__ of _TextEnviron instance
    result = text_environ.__getitem__("key")
    # The result should be unicode
    assert type(result) == unicode


# Generated at 2022-06-23 14:29:26.941860
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['foo'] = u'bar'
    assert environ['foo'] == u'bar'



# Generated at 2022-06-23 14:29:31.511943
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    iter_environ = list(environ)
    assert isinstance(iter_environ, list)
    assert len(iter_environ) > 0
    assert set(iter_environ) == set(environ)



# Generated at 2022-06-23 14:29:38.749273
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # pylint: disable=invalid-name
    # pylint: disable=protected-access

    environ = _TextEnviron(env={'foo': 'bar'}, encoding='utf-8')
    # The following is an implementation detail, don't test

    # _raw_environ might be normalised on native Python3, so need to test for that
    if environ._raw_environ['foo'] == b'bar':
        assert environ['foo'] == 'bar'

    environ = _TextEnviron(env=None, encoding='utf-8')
    assert environ['HOME'] == 'bar'

# Generated at 2022-06-23 14:29:41.702189
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron(env={'a': 1, 'b': 2})
    assert set(env) == {'a', 'b'}



# Generated at 2022-06-23 14:29:45.969110
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['ANSIBLE_TEST_DELETE'] = 'Test Delete Value'
    assert 'ANSIBLE_TEST_DELETE' in environ
    del environ['ANSIBLE_TEST_DELETE']
    assert 'ANSIBLE_TEST_DELETE' not in environ



# Generated at 2022-06-23 14:29:55.886774
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from unittest import TestCase, main
    from ansible.module_utils._text import to_text

    class Tests(TestCase):
        def test_environment_variable_set_to_unicode(self):
            if 'ANSIBLE_TEST_UNICODE_ENVIRONMENT_VARIABLE' in os.environ:
                del os.environ['ANSIBLE_TEST_UNICODE_ENVIRONMENT_VARIABLE']
            os.environ['ANSIBLE_TEST_UNICODE_ENVIRONMENT_VARIABLE'] = u'\ue000'
            self.assertEqual(to_text(u'\ue000'), environ['ANSIBLE_TEST_UNICODE_ENVIRONMENT_VARIABLE'])

# Generated at 2022-06-23 14:30:05.824376
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    unit-test for method __getitem__ of class _TextEnviron
    """
    class _DummyOsModule:
        """
        Class to replace "os" module for testing purposes.
        """
        # pylint: disable=too-few-public-methods
        # pylint: disable=missing-docstring
        def __init__(self, environ):
            self.environ = environ

        def __getattr__(self, name):
            return getattr(os, name)

    class _DummyEncoding:
        """
        Class to replace "sys" module for testing purposes.
        """
        # pylint: disable=too-few-public-methods
        # pylint: disable=missing-docstring
        def __init__(self, value):
            self.value = value

# Generated at 2022-06-23 14:30:10.130317
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # arrange
    environ["TEST_VAR"] = u"ä"
    expected = u"ä"

    # act
    actual = environ["TEST_VAR"]

    # assert
    assert actual == expected

# Generated at 2022-06-23 14:30:19.978573
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for a simple variable that is a string
    import os
    environ = _TextEnviron({'TESTVAR': 'TESTSTRING'})
    assert environ['TESTVAR'] == 'TESTSTRING'
    del os.environ['TESTVAR']

    # Test for a variable that is not a text string
    environ = _TextEnviron({'TESTVAR': b'TESTSTRING'})
    assert environ['TESTVAR'] == 'TESTSTRING'
    del os.environ['TESTVAR']

    # Test for a variable in a text string
    environ = _TextEnviron({'TESTVAR': b'TESTSTRING\xff'})
    # We expect this to raise a UnicodeDecodeError

# Generated at 2022-06-23 14:30:21.885301
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    '''
    Test for method __delitem__ of class _TextEnviron
    '''
    assert True is not False


# Generated at 2022-06-23 14:30:24.276302
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ_copy = environ.copy()

    test_object = _TextEnviron(env=environ_copy)
    assert len(environ_copy) == len(test_object)


# Generated at 2022-06-23 14:30:28.379526
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import copy

    # Make a copy of the environment so we can restore it later
    env = copy.deepcopy(os.environ)

    del environ['VIRTUAL_ENV']
    assert 'VIRTUAL_ENV' not in environ

    # Restore the environment
    os.environ = env



# Generated at 2022-06-23 14:30:35.160754
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import pytest

    environ = _TextEnviron(encoding='utf-8')
    environ['foo'] = '\u1234'
    environ['foo2'] = b'\u1234'

    assert environ._raw_environ['foo'] == b'\xe1\x88\xb4'
    assert environ._raw_environ['foo2'] == b'\u1234'



# Generated at 2022-06-23 14:30:43.507949
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # This can happen if ansible runs on a system with utf8 locale but an environment variable
    # which contains a latin-1 encoded character.  This is annoying because it's not something that
    # you can fix in your environment; you either have to change your locale or have the program
    # that sets the environment variable encode it differently.
    env = dict(blarg='bl\xe1rg')
    environ = _TextEnviron(env)
    # So to make this easy, we force a caching error
    environ._value_cache = {}
    assert environ.get('blarg', None) == u'bl\xe1rg'



# Generated at 2022-06-23 14:30:50.788120
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Check, if method __len__ returns correct value, when method __init__ uses default value for
    # argument 'env'
    assert 1 == len(environ)

    # Check, if method __len__ returns correct value, when method __init__ is called with argument
    # 'env'
    len_env = os.environ
    len_environ = _TextEnviron(env = len_env)
    assert 1 == len(len_environ)


# Generated at 2022-06-23 14:31:01.214830
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test1: set value and then check if the same value
    environ_test = _TextEnviron(encoding='utf-8')
    environ_test['ANSIBLE_TEST_VALUE'] = ' Test 1 Value'
    assert environ_test['ANSIBLE_TEST_VALUE'] == ' Test 1 Value'
    # Test2: check if the value is unicode
    # from __future__ import unicode_literals
    # environ_test = _TextEnviron(encoding='utf-8')
    # environ_test['ANSIBLE_TEST_VALUE'] = ' Test 2 Value'
    # assert environ_test['ANSIBLE_TEST_VALUE'] == u' Test 2 Value'
    assert isinstance(environ_test['ANSIBLE_TEST_VALUE'], unicode)

# Generated at 2022-06-23 14:31:08.819736
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # _raw_environ is set to environ
    # _value_cache is set to empty dict
    # encoding is set to 'utf-8'
    # os.environ is set to empty dict
    #
    # __delitem__(self, key)
    # 1. self._raw_environ[key] is deleted
    assert "HOME" not in environ
    assert "HOME" not in environ._raw_environ
    environ["HOME"] = "/home"
    assert "HOME" in environ
    assert "HOME" in environ._raw_environ
    del environ["HOME"]
    assert "HOME" not in environ
    assert "HOME" not in environ._raw_environ


# Generated at 2022-06-23 14:31:15.424201
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():

    # PY3 - raw is text
    assert environ['HOME'] == u'/home/badgert'
    assert isinstance(environ['HOME'], str)

    # Not PY3 - raw is bytes
    # (in our case, this is utf-8 encoded str for non-PY3)
    assert environ._raw_environ['HOME'] == '/home/badgert'
    assert isinstance(environ._raw_environ['HOME'], bytes)

    # Make sure that invalid bytes are handled in the same way as Python3
    dirty_env = {b'foo': b'\xff'}
    text_env = _TextEnviron(dirty_env)
    if PY3:
        assert text_env['foo'] == u'\udcff'

# Generated at 2022-06-23 14:31:17.126480
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    test case for method __len__ of class _TextEnviron
    """

    assert len(environ) == len(os.environ)

# Generated at 2022-06-23 14:31:21.756344
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ = _TextEnviron()
    environ['foo'] = 'bar'
    assert 'foo' in environ._raw_environ
    assert 'foo' in environ
    del environ['foo']
    assert 'foo' not in environ._raw_environ
    assert 'foo' not in environ


test__TextEnviron___delitem__()



# Generated at 2022-06-23 14:31:27.652166
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Verify _TextEnviron.__setitem__ converts its value to bytes.

    :return: ``None``
    """
    test_env = _TextEnviron()
    test_env['ANSIBLE_MODULE_STDERR'] = u'drôles de poissons'
    assert isinstance(test_env._raw_environ[u'ANSIBLE_MODULE_STDERR'], bytes)

# Generated at 2022-06-23 14:31:37.395254
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    my_env = _TextEnviron({'test': 'original'})
    # ensure that using setitem sets the contents of the underlying dict
    my_env['test'] = 'test'
    assert 'test' in my_env
    assert my_env['test'] == 'test'
    # ensure that using bytes works as well
    my_env[b'test2'] = b'test2'
    assert 'test2' in my_env
    assert my_env['test2'] == 'test2'
    # ensure that passing in text that cannot be decoded raises an error
    try:
        my_env['test3'] = 'invalid\x80'
    except UnicodeEncodeError:
        pass
    else:
        raise AssertionError('Expected unicode decode error')

# Generated at 2022-06-23 14:31:40.354092
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    t = _TextEnviron()
    assert t._raw_environ == os.environ


# Generated at 2022-06-23 14:31:43.401271
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Returns the text type for environment variables on python2/3

    getitem() must return the native text type for the environment variables
    """
    if PY3:
        assert environ['PATH'] == os.environ['PATH']
    else:
        # On Python2, the fallback encoding is utf-8, not sys.getfilesystemencoding()
        assert environ['PATH'] == os.environ['PATH'].decode('utf-8')

# Generated at 2022-06-23 14:31:45.895485
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['test_key'] = 'test_value'
    del environ['test_key']
    assert 'test_key' not in environ


# Generated at 2022-06-23 14:31:55.219269
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # create a dict before initializing environ
    assert not isinstance(os.environ, _TextEnviron)
    temp_environ = {'TEST_STRING_1': 1, 'TEST_STRING_2': 2}
    # initialize environ
    environ_1 = _TextEnviron(env=temp_environ)
    # add one more element
    environ_1['TEST_STRING_3'] = 3
    len_before_del = len(environ_1)
    assert len_before_del == 3
    del environ_1['TEST_STRING_1']
    assert len(environ_1) == len_before_del - 1


# Generated at 2022-06-23 14:31:59.906524
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_environ = _TextEnviron(encoding='utf-8')
    test_environ['test_key'] = 'test_value'
    assert test_environ._raw_environ['test_key'] == b'test_value'


# Generated at 2022-06-23 14:32:06.737197
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Verify __len__ returns the same value as len() on the underlying os.environ
    """
    textenviron = _TextEnviron()
    assert len(textenviron) == len(os.environ)



# Generated at 2022-06-23 14:32:12.064314
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron(encoding='ascii')
    assert b'ASCII' == env['PYTHONIOENCODING']
    env['PYTHONIOENCODING'] = 'utf-8'
    assert b'utf-8' == env['PYTHONIOENCODING']

# Generated at 2022-06-23 14:32:19.690572
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import sys
    import unittest

    # Create a fake os that returns bad bytes in an environment variable
    class _BadEnviron(object):
        def __init__(self, encoding):
            self.encoding = encoding

        def get(self, key, default=None):
            if key == 'TEST_ENV_VAR':
                return '\xe9'.encode(self.encoding)
            if key == 'NONEXISTENT_ENV_VAR':
                return None
            return default

        def __getitem__(self, key):
            if key == 'TEST_ENV_VAR':
                return '\xe9'.encode(self.encoding)
            raise KeyError(key)

        def __setitem__(self, key, item):
            raise NotImplementedError


# Generated at 2022-06-23 14:32:28.689269
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Expected behaviour is for instance methods to return strings and for class methods to return a
    string or a bytes object.
    """
    my_env = _TextEnviron(env=dict(VAL='Spam'))

    assert isinstance(my_env['VAL'], str), '__getitem__ should return a str'
    assert my_env['VAL'] == 'Spam', '__getitem__ should return the correct value'

    my_env['VAL'] = 'Spam'
    assert isinstance(list(my_env.values())[0], str), 'values() should return str'
    assert list(my_env.values())[0] == 'Spam', 'values() should return the correct value'

    assert list(my_env.keys())[0] == 'VAL', 'keys() should return the correct key'

   

# Generated at 2022-06-23 14:32:32.188661
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron()
    env['XYZ'] = b'1234'
    del env['XYZ']
    assert b'XYZ' not in env._raw_environ


# Generated at 2022-06-23 14:32:34.684360
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert PY3
    e = _TextEnviron({'a': 'b', 'c': 'd'})
    assert set(['a', 'c']) == set(e)

# Generated at 2022-06-23 14:32:45.149236
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = {b'PATH': b'/bin:/usr/bin',
           b'SOME_NONSTRING': 42,
           b'SOME_UNICODE': '\xe1\x88\xb4\xea\xb0\x80\xe1\x88\x9b\xe1\x8c\x81',
           b'SOME_BYTES': b'\xe1\x88\xb4\xea\xb0\x80\xe1\x88\x9b\xe1\x8c\x81'}
    env = _TextEnviron(env, encoding='utf-8')

    # test getitem on path
    assert env[b'PATH'] == '/bin:/usr/bin'
    assert isinstance(env[b'PATH'], str)

    # test getitem on a

# Generated at 2022-06-23 14:32:49.448152
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env_len = len(os.environ)
    for i in range(5):
        environ['test_len_%d' % i] = 'test_len_%d' % i
    assert len(environ) == env_len + 5
    for i in range(5):
        del environ['test_len_%d' % i]
    assert len(environ) == env_len


# Generated at 2022-06-23 14:32:55.431401
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        fd, os.environ['A_FILE'] = tempfile.mkstemp(dir=tmpdir)
        os.close(fd)

        env = _TextEnviron()
        assert 'A_FILE' in env
        assert isinstance(env.__iter__(), type(iter(())))

# Generated at 2022-06-23 14:32:59.698896
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron()
    assert isinstance(environ, _TextEnviron)
    assert isinstance(environ, MutableMapping)
    # In the following two blocks, we test the two implementations of the
    # environment dict.
    #
    # The first way is to simply use os.environ as the internal dict.
    # The second way is to create a new dict and use it as the basis for
    # the internal dict.
    #
    # In both cases, we're trying to make sure that the original dict
    # isn't mutated.
    for orig_env in (os.environ, dict(os.environ)):
        # Verify that the class contains the same keys as the original dict
        for key in orig_env:
            assert key in environ
        # Verify that the values in the class equal the values

# Generated at 2022-06-23 14:33:01.071200
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:33:03.856964
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(encoding='ascii')
    environ['test'] = 1
    assert environ['test'] == u'1'


# Generated at 2022-06-23 14:33:05.997277
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_value = 'string with Unicode: \u20ac'
    environ['TEST'] = test_value
    assert test_value == environ['TEST']

# Generated at 2022-06-23 14:33:09.128240
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Verify _TextEnviron.__len__ returns correct number of items
    """
    te = _TextEnviron(encoding='utf-8')
    test_size = len(te)
    assert test_size == len(os.environ)


# Generated at 2022-06-23 14:33:16.609782
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    if not PY3:
        test_env = dict(environ)
        test_env[to_bytes('TEST_DELETE_ENV_KEY', encoding=environ.encoding)] = to_bytes('test_del', encoding=environ.encoding)
        test_env = _TextEnviron(env=test_env)
        assert 'TEST_DELETE_ENV_KEY' not in environ
        del test_env['TEST_DELETE_ENV_KEY']
        assert 'TEST_DELETE_ENV_KEY' not in test_env


# Generated at 2022-06-23 14:33:24.874822
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ['MYENVIRONMENT'] = 'myvalue'

    assert os.environ['MYENVIRONMENT'] == 'myvalue'
    assert environ['MYENVIRONMENT'] == u'myvalue'

    del environ['MYENVIRONMENT']

    assert 'MYENVIRONMENT' not in os.environ
    assert 'MYENVIRONMENT' not in environ
    assert 'MYENVIRONMENT' not in os.environ.keys()
    assert 'MYENVIRONMENT' not in environ.keys()


# Generated at 2022-06-23 14:33:35.621730
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['A'] = 'A'
    environ['B'] = b'B'
    environ['C'] = b'\xe2\x80\x99'
    environ['D'] = b'\xe2\x80\x99'.decode('utf-8')
    environ['E'] = u'E'
    environ['F'] = u'\u2019'
    environ['G'] = u'G'.encode('utf-8')
    environ['H'] = b'H'.decode('utf-8')
    environ['I'] = u'\u2019'.encode('utf-8')
    environ['J'] = u'J'
    environ['K'] = 'K'.encode('utf-8')
    environ['L'] = u'\u2019'.en

# Generated at 2022-06-23 14:33:38.380734
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron()
    assert isinstance(env, MutableMapping)
    assert env.encoding == 'utf-8'
    assert isinstance(env, MutableMapping)
    assert len(env) == len(os.environ)

# Generated at 2022-06-23 14:33:44.495530
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        cwd = os.getcwd()
        os.chdir(tmpdir)
        with open('my_encoding', 'w') as f:
            f.write('utf-8')
        os.putenv('PYTHONIOENCODING', 'utf-8')

        environ = _TextEnviron(encoding='utf-8')
        assert environ.encoding == 'utf-8'
        assert environ.get('PYTHONIOENCODING') == 'utf-8'

        environ = _TextEnviron(encoding=None)
        assert environ.encoding != 'utf-8'
        assert environ.get('PYTHONIOENCODING') == 'utf-8'

        environ = _Text

# Generated at 2022-06-23 14:33:46.086547
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Unit tests for class _TextEnviron
    """
    pass

# Generated at 2022-06-23 14:33:51.540331
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # PY2: call to_bytes(encoding='utf-8') with unicode string
    # PY2: call to_bytes(encoding='utf-8') with non-string
    # PY3: call to_bytes(encoding='utf-8') with non-string
    # PY3: call to_bytes(encoding='utf-8') with unicode string
    pass

# Generated at 2022-06-23 14:33:55.268021
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Given
    env = _TextEnviron()
    key = 'key'
    value = 'value'
    # When
    env[key] = value
    # Then
    assert env[key] == value

# Generated at 2022-06-23 14:34:03.446919
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Test the method __setitem__ of class _TextEnviron.
    """
    additional_parameters = {"encoding": 'utf-8'}
    environ = _TextEnviron(encoding='utf-8')

    test_keys = ['foo', 'bar', 'baz']
    for key in test_keys:
        environ.__setitem__(key, key)
        assert key == environ[key]

    test_values = ['foo', 'bar', 'baz']
    for idx, val in enumerate(test_values):
        environ[test_keys[idx]] = val
        assert val == environ[test_keys[idx]]

    # Exceptions
    try:
        environ['fail'] = None
    except TypeError:
        pass

# Generated at 2022-06-23 14:34:11.793438
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({
        b'foo': b'bar',
        b'baz': u'blammo',
        b'quux': 5,
        b'quuuux': object(),
    })
    assert u'bar' == env['foo']
    assert u'blammo' == env['baz']
    assert u'5' == env['quux']
    assert '5' == env['quux']
    assert u'<object object at 0x12345>' == env['quuuux']


# Generated at 2022-06-23 14:34:13.550880
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    assert len(env) == len(os.environ)



# Generated at 2022-06-23 14:34:22.252676
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Note: Due to the difficulty in mocking os.environ, this test only covers a small portion of
    # the __getitem__ method's logic.

    # Create __environ object
    encoding = 'utf-8'
    env = {
        'key1': 'value1',
        'key2': 'value2',
    }
    environ = _TextEnviron(env, encoding)

    # Test PY3
    if PY3:
        for key, value in env.items():
            assert value == environ[key]
        return

    # Test PY2
    for key, value in env.items():
        assert to_text(value, encoding=encoding, nonstring='passthru', errors='surrogate_or_strict') == environ[key]



# Generated at 2022-06-23 14:34:23.961091
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) > 10


# Generated at 2022-06-23 14:34:27.309828
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    e = _TextEnviron(env={'a': 'a', 'b': 'b'})
    assert set(e.__iter__()) == set(('a', 'b'))


# Generated at 2022-06-23 14:34:31.428765
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Unit test for method __len__ of class _TextEnviron
    os.environ = {'ANSIBLE_TEST_KEY': 'ANSIBLE_TEST_VALUE', 'ANSIBLE_TEST_KEY2': 'ANSIBLE_TEST_VALUE2'}
    env = _TextEnviron()
    assert len(env) == 2



# Generated at 2022-06-23 14:34:35.428150
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    e = _TextEnviron()
    assert len(e) == len(os.environ)
    e.append('TEST_KEY', 'TEST_VALUE')
    assert len(e) == len(os.environ) + 1


# Generated at 2022-06-23 14:34:45.648201
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Cover the main constructor
    def test_constructor():
        # We're mimicking Python3 so the default env should be unicode strings
        if PY3:
            assert isinstance(os.environ[b'test'], str)
        else:
            assert isinstance(os.environ[b'test'], bytes)
        assert isinstance(environ[b'test'], str)

    # We shouldn't choke on non-ascii keys
    def test_constructor_nonascii():
        environ[u'Tést'] = u'Test'
        assert environ[u'Tést'] == u'Test'
        assert isinstance(environ[b'T\xc3\xa9st'], str)  # bytes key returns unicode value

# Generated at 2022-06-23 14:34:47.722321
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Arrange
    os.environ['foo'] = 'bar'

    # Act
    actual = len(environ)

    # Assert
    assert actual == 1



# Generated at 2022-06-23 14:34:51.602460
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Create a new instance of _TextEnviron class and set a variable
    textenviron = _TextEnviron()
    textenviron['PATH'] = 'some_path'
    # Check that variable was set to os.environ
    if os.environ['PATH'] != 'some_path':
        raise Exception('os.environ')

# Generated at 2022-06-23 14:34:58.639312
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from unittest import TestCase, skipIf, skipUnless
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six import PY3

    class _TextEnviron_setitem_Test(TestCase):
        def __init__(self, *args, **kwargs):
            self.environ_bak = environ
            self.environ = _TextEnviron(env={b'foo': b'bar'})

            super(_TextEnviron_setitem_Test, self).__init__(*args, **kwargs)

        def tearDown(self):
            environ = self.environ_bak


# Generated at 2022-06-23 14:35:00.591029
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ._TextEnviron().__iter__()) == os.environ.keys()


# Generated at 2022-06-23 14:35:02.131744
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == 0

# Generated at 2022-06-23 14:35:09.976505
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # check that __setitem__ adds the key/value to os.environ and converts the value to utf-8
    test_key = 'ANSIBILE_ABC_TEST'
    test_value = u'\u041e'
    environ[test_key] = test_value
    assert os.environ[test_key] == test_value.encode('utf-8')
    assert environ[test_key] == test_value
    del environ[test_key]

    # check that __setitem__ adds the key/value to os.environ and does not convert the value if it
    # is already bytes
    test_key = 'ANSIBILE_ABC_TEST'
    test_value = u'\u041e'

# Generated at 2022-06-23 14:35:19.192717
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Tests the constructor of class _TextEnviron
    """

    assert environ.__doc__ == '''
    Utility class to return text strings from the environment instead of byte strings

    Mimics the behaviour of os.environ on Python3
    '''

    assert environ['PATH'] == os.environ['PATH']
    assert environ['PATH'] == os.environ['PATH']
    assert environ['PATH'] == os.environ['PATH']
    assert environ['LANG'] == os.environ['LANG']
    assert environ['LANG'] == os.environ['LANG']
    assert environ['LANG'] == os.environ['LANG']

    assert environ['TEST_VAR'] == 'TEST_VAR'

# Generated at 2022-06-23 14:35:30.133131
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test that we can set and get utf-8 characters
    env = _TextEnviron(encoding='utf-8')
    # Try setting a valid UTF-8 character
    env['test'] = '\u00e9'
    assert isinstance(env['test'], str)
    assert env['test'] == '\u00e9'

    # Try setting an invalid UTF-8 character
    env['test'] = b'\xe9A'
    assert isinstance(env['test'], str)
    assert env['test'] == b'\xe9A'

    # Test that we can set and get latin-1 characters
    env = _TextEnviron(encoding='latin-1')
    # Try setting a valid latin-1 character
    env['test'] = '\xe9'

# Generated at 2022-06-23 14:35:38.677584
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """Test _TextEnviron.__len__()
    """
    import sys
    from ansible.module_utils.six import iterkeys, itervalues

    test_dict = {b'text': b'yay', b'unicode': b'\xe4\xbd\xa0\xe5\xa5\xbd'}
    test_dict.update({x: y for x, y in zip(itervalues(test_dict), iterkeys(test_dict))})

    sys.modules['os'].environ = test_dict
    te = _TextEnviron()
    assert len(te) == len(test_dict)
    del sys.modules['os'].environ



# Generated at 2022-06-23 14:35:49.603483
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest
    from ansible.module_utils.common._collections_compat import MutableMapping, Sequence

    class MockDict(MutableMapping):

        def __init__(self):
            self._data = {}

        def __getitem__(self, key):
            return self._data[key]

        def __setitem__(self, key, value):
            self._data[key] = value

        def __delitem__(self, key):
            del self._data[key]

        def __iter__(self):
            return iter(self._data)

        def __len__(self):
            return len(self._data)


# Generated at 2022-06-23 14:35:57.454295
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    '''
    Unit test for method __delitem__ of class _TextEnviron
    :return:
    '''
    try:
        # Test for valid/invalid key
        environ['test'] = 'test'
        # If this key has been set and has value 'test', it means the test pass
        assert environ['test'] == 'test'
        del environ['test']
        try:
            # If the value is None, the key has been deleted
            assert environ['test'] is None
        except KeyError:
            # If the exception KeyError occurred, it means the test pass
            assert True
    except KeyError:
        # If the exception KeyError occurred, it means the test pass
        assert True

test__TextEnviron___delitem__()



# Generated at 2022-06-23 14:36:03.771207
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    test_env = _TextEnviron()
    # Check that it functions like the builtin os.environ
    assert test_env == os.environ
    assert test_env.get('PATH') == os.environ.get('PATH')
    assert test_env['PATH'] == os.environ['PATH']
    assert sorted(iter(test_env)) == sorted(iter(os.environ))

# Generated at 2022-06-23 14:36:10.313298
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron()
    assert isinstance(env.encoding, str)
    env = _TextEnviron(encoding=u'abc')
    assert isinstance(env.encoding, str)
    assert env.encoding == 'abc'
    env = _TextEnviron(env={u'abc': u'Γ', u'ć': u'Ł'})
    assert env[u'abc'] == u'Γ'
    assert env[u'ć'] == u'Ł'

# Generated at 2022-06-23 14:36:15.486884
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_obj = _TextEnviron()
    test_key = 'test_key'
    test_value = 'val_\N{LATIN SMALL LETTER E WITH ACUTE}'
    test_obj[test_key] = test_value
    assert test_obj[test_key] == test_value


# Generated at 2022-06-23 14:36:18.484232
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['USER'] == os.environ['USER']
    assert environ['HOME'] == os.environ['HOME']
    assert environ['PATH'] == os.environ['PATH']


# Generated at 2022-06-23 14:36:21.966357
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Given
    exemple_env = {'1': 'a', '2': 'b', '3': 'c'}
    # When
    myenv = _TextEnviron(exemple_env)
    # Then
    assert len(myenv) == len(exemple_env)
    

# Generated at 2022-06-23 14:36:29.683738
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_unicode = _TextEnviron(env={'A': 'youȧre'}, encoding='utf-8')
    environ_byte = _TextEnviron(env={to_bytes('A', encoding='utf-8'): to_bytes('youȧre', encoding='utf-8')}, encoding='utf-8')
    # Test unicode encoded key
    assert environ_unicode['A'] == environ_byte['A']
    # Test undecoded bytes-keys
    assert environ_unicode['A'] == environ_byte['A']

# Generated at 2022-06-23 14:36:33.652115
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron({'ANSIBLE_MODULE_ARGS': '{"a": "A"}'})
    assert text_environ['ANSIBLE_MODULE_ARGS'] == '{"a": "A"}'


# Generated at 2022-06-23 14:36:38.354182
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # For the sake of demonstrating that __iter__() works, we'll make a copy of
    # _TextEnviron
    class _TestEnviron(_TextEnviron):
        # We're going to be in Python2, so we need to explicitly override the __iter__() method
        def __iter__(self):
            return self._raw_environ.keys()
    # Make an instance of the class
    test_environ = _TestEnviron()
    # Iterate over the environment, verifying the contents
    for key in test_environ:
        assert key in environ

# Generated at 2022-06-23 14:36:44.832860
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_obj = _TextEnviron({'KEY1':'foo','KEY2':'bar'})
    test_obj['KEY1'] = 'baz'
    assert test_obj['KEY1'] == 'baz'
    test_obj['KEY2'] = 'quxx'
    assert test_obj['KEY2'] == 'quxx'
    test_obj['KEY3'] = 'quxx'
    assert test_obj['KEY3'] == 'quxx'


# Generated at 2022-06-23 14:36:46.403318
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for well-formed strings
    assert environ['some_key'] == 'some_value'

# Generated at 2022-06-23 14:36:52.208699
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    
    # Test byte input
    byte_input = b"/tmp/foo"
    environ[u"USER"] = byte_input

    # Test unicode input
    unicode_input = u"/tmp/foo"
    environ[u"USER"] = unicode_input

# Generated at 2022-06-23 14:36:57.360350
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    global environ
    key = 'ANSIBLE_TEST_ENV'
    environ[key] = 'Test'
    del environ[key]
    assert not environ.has_key(key), 'Exception: deitem key:ANSIBLE_TEST_ENV failed.'


# Generated at 2022-06-23 14:37:06.749424
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Given a _TextEnviron Object
    test_environ = _TextEnviron()
    # When I set a local variable
    test_environ['test_key'] = 'test_value'
    # Then it is accessible in the environment
    assert os.environ['test_key'] == 'test_value'
    assert test_environ['test_key'] == 'test_value'
    # Then get a KeyError
    test_environ.__delitem__('test_key')
    assert not os.environ.get('test_key', False)
    assert not test_environ.get('test_key', False)
    assert test_environ.get('test_key', True) == True


# Generated at 2022-06-23 14:37:12.545708
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Test standard TextEnviron
    a = _TextEnviron()
    b = os.environ
    assert set(a) == set(b)
    assert set(a) == set(a._raw_environ)

    # Test that other functions work after init
    a['foo'] = u'Hello'
    del a['foo']

    assert b['foo'] == os.environ['foo']


# Generated at 2022-06-23 14:37:22.674696
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Test that _TextEnviron subclass works as expected
    """

    assert os.environ == environ
    for key in os.environ:
        assert os.environ[key] == environ[key]
        assert type(environ[key]) == str
    assert str(environ) == str(os.environ)

    for key, value in os.environ.items():
        assert os.environ[key] == environ[key]
        assert type(environ[key]) == str

    assert len(environ) == len(os.environ)
    assert environ is not os.environ

    keys = []
    values = []
    for key, value in environ.items():
        assert key in environ
        assert key in os.environ
        assert type(value) == str
       

# Generated at 2022-06-23 14:37:30.394758
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ.clear()
    assert len(environ) == 0
    environ['ANSIBLE_MODULE_UTILS_ENV'] = 'ANSIBLE_MODULE_UTILS_ENV'
    assert len(environ) == 1
    environ['ANSIBLE_MODULE_UTILS_ENV2'] = 'ANSIBLE_MODULE_UTILS_ENV2'
    assert len(environ) == 2
    del environ['ANSIBLE_MODULE_UTILS_ENV']
    assert len(environ) == 1
    environ.clear()
    assert len(environ) == 0


# Generated at 2022-06-23 14:37:33.770605
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({'A': '1', 'B': '2', 'C': '3', 'D': '4'})
    assert len(env) == 4, env


# Generated at 2022-06-23 14:37:43.943013
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # _raw_environ contains a bytes value
    environ_test01 = _TextEnviron()
    environ_test01._raw_environ = {b'VALUE01': b'bar'}
    # Test 01 - expected result: returned value is a text string
    assert isinstance(environ_test01.__getitem__(b'VALUE01'), text_type) == True
    # Test 02 - expected result: returned value is equal to the value in os.environ
    assert environ_test01.__getitem__(b'VALUE01') == os.environ[b'VALUE01']
    # _raw_environ doesn't contain any value
    environ_test02 = _TextEnviron()
    environ_test02._raw_environ = {}
    # Test 03 - expected result: raises a KeyError(u'key