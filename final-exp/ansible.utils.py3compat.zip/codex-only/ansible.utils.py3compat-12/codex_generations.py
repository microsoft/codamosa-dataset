

# Generated at 2022-06-23 14:27:44.091497
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Verify that __len__ works properly
    """
    x = _TextEnviron({'a': '', 'b': '', 'c': ''})
    assert len(x) == 3



# Generated at 2022-06-23 14:27:50.226817
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Make sure that unlike os.environ, this object's __delitem__ works on the wrapped object
    key = 'ANSIBLE_TEST_KEY_FOR_DEL_TEST'
    if key in environ:
        del environ[key]

    assert key not in environ, '__delitem__ should remove a key which is not in the environment'
    environ[key] = 'test_value'
    assert key in environ, '__setitem__ not working'
    del environ[key]
    assert key not in environ, '__delitem__ not working'

    if key in environ:
        del environ[key]



# Generated at 2022-06-23 14:27:58.399869
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
  # Case 1: Delete a key which exists in the environment
  environ['ANSIBLE_TEST_DELITEM'] = 'foobar'
  del environ['ANSIBLE_TEST_DELITEM']
  # Note: os.environ.__contains__ is not present in Python2 and this test cannot be run
  #assert 'ANSIBLE_TEST_DELITEM' not in os.environ

  # Case 2: Delete a key which does not exist in the environment
  del environ['ANSIBLE_TEST_DELITEM_NOT_EXIST']


# Generated at 2022-06-23 14:28:09.223333
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import tempfile
    import os
    from ansible.module_utils._text import to_bytes, to_text

    # Make sure that the return of _TextEnviron()[key] is the same on Python2 and 3
    env = os.environ.copy()
    env['ANSIBLE_MODULE_TESTS'] = 'PASS'
    test_env = _TextEnviron(env)
    assert test_env['ANSIBLE_MODULE_TESTS'] == 'PASS'

    # Make sure that the environ object created has the appropriate type of string
    assert isinstance(env['ANSIBLE_MODULE_TESTS'], bytes)
    assert isinstance(test_env['ANSIBLE_MODULE_TESTS'], to_text(str))

    # Make sure that we can assign to the environment and that it's the right type

# Generated at 2022-06-23 14:28:19.594178
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Constructor must not fail without any arguments
    environ = _TextEnviron()
    assert len(environ) > 0
    assert 'HOME' in environ
    assert isinstance(environ['HOME'], str)

    # Constructor must accommodate a given encoding
    environ = _TextEnviron(environ, encoding='iso-8859-1')
    assert len(environ) > 0
    assert 'HOME' in environ
    assert isinstance(environ['HOME'], str)

    # __init__: Keyword arguments are parsed correctly
    environ = _TextEnviron(env={'ANSIBLE_TEST': 'foo'}, encoding='iso-8859-1')
    assert isinstance(environ, _TextEnviron)
    assert len(environ) == 1
    assert 'ANSIBLE_TEST' in en

# Generated at 2022-06-23 14:28:30.317724
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Given an environment which uses utf-8 values,
    utf8_value = b'\xe2\x9c\x93'
    utf8_env = {b'utf8': utf8_value}

    # When we create an object _TextEnviron with the utf8 environment,
    env = _TextEnviron(env=utf8_env)

    # Then it has the byte value of the utf8 key,
    assert(b'utf8' in env)
    # And the byte value of the utf8 key,
    assert(env.get(b'utf8') == utf8_value)
    # And the text value of the utf8 key,
    assert(env.get(u'utf8') == utf8_value.decode('utf-8'))
    # And the byte

# Generated at 2022-06-23 14:28:36.710281
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ = _TextEnviron()
    environ['aa'] = 'bb'
    # Make sure delitem works
    del environ['aa']
    try:
        environ['aa']
    except KeyError:
        pass
    else:
        raise AssertionError('__delitem__ of _TextEnviron does not work')


# Generated at 2022-06-23 14:28:39.171878
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, MutableMapping)
    assert isinstance(environ._raw_environ, MutableMapping)
    assert isinstance(environ.encoding, str)

# Generated at 2022-06-23 14:28:46.164699
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    dict_environ = dict()
    dict_environ[b'a'] = b'1'
    dict_environ[b'b'] = b'2'
    dict_environ[b'c'] = b'3'
    text_environ = _TextEnviron(env=dict_environ, encoding='utf-8')
    assert set(dict_environ.keys()) == set(text_environ)
    assert set(dict_environ.keys()) == set([text_environ.__getitem__(x) for x in text_environ])


# Generated at 2022-06-23 14:28:53.689970
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """ Check the method __delitem__ of the class _TextEnviron """
    environ = _TextEnviron(encoding='utf-8')
    key = '_ANSIBLE_TEST_DELITEM'
    environ[key] = 'foo'
    assert key in environ
    del environ[key]
    assert key not in environ
    environ[key] = u'ééé'
    assert key in environ
    del environ[key]
    assert key not in environ


# Generated at 2022-06-23 14:28:57.405547
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # __iter__ should return the iterator of the underlying os.environ
    # class.
    assert environ._raw_environ == os.environ
    assert environ.__iter__() == os.environ.__iter__()



# Generated at 2022-06-23 14:29:06.624621
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import os
    import sys
    import unittest

    if sys.version_info.major == 2:
        @unittest.skip("Skipping __len__ since it does not apply to Python2")
        class Test__TextEnviron___len__(unittest.TestCase):
            pass
    else:
        class Test__TextEnviron___len__(unittest.TestCase):
            def test__TextEnviron___len__(self):
                d = _TextEnviron()
                self.assertEqual(len(d), len(os.environ))

                d['foo'] = 'bar'
                self.assertEqual(len(d), len(os.environ) + 1)

                del d['foo']
                self.assertEqual(len(d), len(os.environ))

    unitt

# Generated at 2022-06-23 14:29:07.999616
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert(len(environ) == len(os.environ))


# Generated at 2022-06-23 14:29:15.884600
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    d = {'a': 'b'}
    os.environ = d
    environ = _TextEnviron(env=d)
    assert os.environ['a'] == 'b'
    assert environ['a'] == u'b'
    del environ['a']
    with pytest.raises(KeyError):
        assert os.environ['a'] != 'b'
    with pytest.raises(KeyError):
        assert environ['a'] != u'b'


# Generated at 2022-06-23 14:29:18.664507
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    class _TestEnv(MutableMapping):
        def __len__(self):
            return 1

    assert len(_TextEnviron(_TestEnv())) == 1



# Generated at 2022-06-23 14:29:19.696525
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)

# Generated at 2022-06-23 14:29:21.983604
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    e = _TextEnviron()
    assert set(iter(e)) == set(iter(os.environ))



# Generated at 2022-06-23 14:29:28.502964
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['SOMEKEY'] = 'SOMEVALUE'
    # Expect the key to be set
    assert environ['SOMEKEY'] == 'SOMEVALUE'
    # Make sure the key is in the environment
    assert 'SOMEKEY' in environ
    del environ['SOMEKEY']
    # the key should be removed from the environment
    assert 'SOMEKEY' not in environ


# Generated at 2022-06-23 14:29:37.309920
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():

    e = _TextEnviron({'a': 'b'})
    e['a'] = u'é'
    e['a'] = 'é'

    e = _TextEnviron({'a': 'b'}, encoding='latin-1')
    e['a'] = u'é'
    e['a'] = 'é'

    with pytest.raises(TypeError):
        e['a'] = 1

    with pytest.raises(UnicodeDecodeError):
        e['a'] = chr(255) + chr(255)

    with pytest.raises(UnicodeEncodeError):
        e['a'] = chr(255)



# Generated at 2022-06-23 14:29:40.042498
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    global environ
    environ['a'] = 'a'
    del environ['a']
    assert not environ


# Generated at 2022-06-23 14:29:42.554601
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['LC_ALL'] = 'UTF-8'
    assert environ['LC_ALL'] == u'UTF-8'


# Generated at 2022-06-23 14:29:44.652058
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = environ.copy()
    del env['LANG']
    assert set(env) == set(os.environ)

# Generated at 2022-06-23 14:29:47.049603
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    instance = _TextEnviron({'Foo': 'Café'})
    assert sorted(instance) == ['Foo']


# Generated at 2022-06-23 14:29:52.789705
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['TEST_VAR'] = '\x80'

    assert 'TEST_VAR' in environ
    if PY3:
        assert environ['TEST_VAR'] == '\x80'
    else:
        assert environ['TEST_VAR'] == u'\uFFFD'

    del os.environ['TEST_VAR']



# Generated at 2022-06-23 14:30:00.093001
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron

    Method under test:
        _TextEnviron.__getitem__
        _TextEnviron.__setitem__

    Parameters:
        None.  Note that this will change os.environ

    Returns:
        None.  Raises an exception if there is a test failure
    """
    environ['test'] = b'0123\x01\xe9\x9a'
    assert environ['test'] == u'0123\u0001\u00e9\u009a'

    os.environ['test'] = b'0123\x01\xe9\x9a'
    # Py2 is broken because it uses undecoded bytes in the cache key

# Generated at 2022-06-23 14:30:05.015086
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import unittest

    class os_environ_mock():
        def __init__(self):
            self.environ = {}

        def __getitem__(self, item):
            return self.environ[item]

        def __setitem__(self, key, value):
            self.environ[key] = value

    class Test_TextEnviron(unittest.TestCase):
        def setUp(self):
            self.encoding = 'utf-8'
            self.mock_env = os_environ_mock()
            self.mock_env.environ['spam'] = b'eggs'
            self.mock_env.environ['wheels'] = b'\x80\x81\x82\x83'.decode(self.encoding, errors='strict')


# Generated at 2022-06-23 14:30:08.181655
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    try:
        iter(environ)
    except Exception:
        raise AssertionError('Exception raised while iterating over the _TextEnviron object')


# Generated at 2022-06-23 14:30:12.336844
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = {b'Foo': b'bar', b'Blah': b'blah'}
    assert len(_TextEnviron(env, 'ascii')) == 2
    assert len(_TextEnviron(env, 'utf-8')) == 2


# Generated at 2022-06-23 14:30:19.189952
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():

    class DummyEnviron(object):
        def __init__(self, environment):
            self._environment = environment

        def __iter__(self):
            return iter(self._environment)

    def test(env, expected_result):
        environ = _TextEnviron(DummyEnviron(env))
        result = list(iter(environ))
        assert result == expected_result

    test({}, [])
    test({'A': 'B'}, ['A'])
    test({'A': 'B', 'C': 'D'}, ['A', 'C'])



# Generated at 2022-06-23 14:30:26.365395
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():

    # Arrange
    env = _TextEnviron(env={u'a': u'b', u'c': u'd'}, encoding='utf-8')

    # Act
    l = list()
    for k in env:
        l.append(k)

    # Assert
    assert l == [u'a', u'c'], \
        "_TextEnviron class method __iter__ does not return the expected values, expected %s, actual %s." % ([u'a', u'c'], l)



# Generated at 2022-06-23 14:30:35.598967
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    .. code-block:: python

        class TestEnvironment(object):

            def __init__(self, env):
                self._env = env

            def __len__(self):
                return len(self._env)

            def __contains__(self, key):
                return key in self._env

            def __iter__(self):
                return iter(self._env)

            def __getitem__(self, key):
                return self._env[key]

        env = TestEnvironment({'foo': 'bar'})
    """
    env = _TextEnviron({'foo': 'bar'})
    assert len(env) == len({'foo': 'bar'})



# Generated at 2022-06-23 14:30:41.508947
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import unittest

    class Test__TextEnviron(unittest.TestCase):
        def test_basic(self):
            test_env = _TextEnviron({b'key1': b'value1', b'key2': b'value2'})
            assert test_env[b'key1'] == 'value1'
            assert test_env[b'key2'] == 'value2'
            test_env[b'key3'] = 'value3'
            assert test_env[b'key3'] == 'value3'
            del test_env[b'key3']
            with self.assertRaises(KeyError):
                test_env[b'key3']


# Generated at 2022-06-23 14:30:51.149912
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    test_env = {to_bytes('foo', encoding='utf-8'): to_bytes('bar', encoding='utf-8')}
    te = _TextEnviron(env=test_env)

    assert isinstance(te, _TextEnviron)
    assert len(te) == 1

    # __getitem__ works
    assert te['foo'] == u'bar'

    # __setitem__ works
    te['foo'] = 'baz'
    assert te['foo'] == u'baz'

    # __iter__ works
    for key in te:
        assert key == to_bytes('foo', encoding='utf-8')

    # __contains__ works
    assert 'foo' in te

# Generated at 2022-06-23 14:31:01.572117
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron({'a': 'b', 'c': 'd'})
    assert len(environ) == 2
    assert list(iter(environ)) == ['a', 'c']
    assert list(environ.keys()) == ['a', 'c']
    assert list(environ.values()) == ['b', 'd']
    assert list(environ.items()) == [('a', 'b'), ('c', 'd')]
    assert environ['a'] == 'b'
    assert environ['c'] == 'd'
    assert environ['a'] == 'b'
    assert environ['c'] == 'd'
    environ['a'] = u'foo'
    assert len(environ) == 2
    assert list(iter(environ)) == ['a', 'c']
    assert list

# Generated at 2022-06-23 14:31:09.792095
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """
    def get_value(environ, key):
        """
        Workaround for environ.__getitem__().__get__(environ, None) returning None
        """
        return environ.__getitem__(key)

    env_from_to = {
        'Test': 'Nice',
        u'Test': u'Nice',
        'Test': b'Nice',
        u'Test': b'Nice',
        b'Test': u'Nice',
        b'Test': b'Nice',
    }


# Generated at 2022-06-23 14:31:20.816592
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():

    # try to set key-value pair: key=b'ABC'
    try:
        environ[b'ABC'] = "DEF"
    except TypeError as e:
        if e.args[0] == "str() argument 2 must be str, not bytes":
            print("[PASS]")
        else:
            raise
    else:
        print("[FAIL]")

    # try to set key-value pair: key=b'ABC', value=True
    try:
        environ[b'ABC'] = True
    except TypeError as e:
        if e.args[0] == "str() argument 2 must be str, not bool":
            print("[PASS]")
        else:
            raise
    else:
        print("[FAIL]")

    # try to set key-value pair: key=b'

# Generated at 2022-06-23 14:31:23.141146
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({'a': '1'})
    del env['a']
    assert env == {}


# Generated at 2022-06-23 14:31:34.171379
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.six import PY2, PY3
    test_env = _TextEnviron(encoding='utf-8')
    assert 'utf-8' == test_env.encoding


# Generated at 2022-06-23 14:31:40.318541
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    if PY3:
        orig_value = u'a_value'
    else:
        # The value may not be unicode on Python2 so we need to handle that
        orig_value = u'a_value'.encode('utf-8')
    env['a_key'] = u'a_value'
    assert orig_value == env['a_key']
    env['a_key'] = u'a_value'.encode('utf-8')
    assert orig_value == env['a_key']



# Generated at 2022-06-23 14:31:44.691750
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Set up
    environ.clear()
    environ.update({'first_key': 'first_value', 'second_key': 'second_value', 'third_key': 'third_value'})

    # Tests
    del environ['second_key']
    assert len(environ) == 2



# Generated at 2022-06-23 14:31:48.027761
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    assert isinstance(environ, _TextEnviron)
    environ['PATH'] = 'some-path'
    assert isinstance(environ['PATH'], str)
    assert environ['PATH'] == 'some-path'

# Generated at 2022-06-23 14:31:51.883078
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ['Test_Key'] = 'Test_Value'
    assert 'Test_Key' in environ
    environ.pop('Test_Key')
    assert 'Test_Key' not in environ


# Generated at 2022-06-23 14:31:53.649366
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ['ANSIBLE_TEST'] = u'ünîcôde'
    for key in environ:
        if to_bytes(u'ANSIBLE_TEST', encoding='utf-8') == key:
            assert True
            return
    assert False, "environ did not contain the key we set"

# Generated at 2022-06-23 14:31:58.933415
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Create a _TextEnviron object with a sample data
    testenv = _TextEnviron(env={b'key1': b'spam', b'key2': b'bar', b'key3': b'snafu'})
    # Verify that __iter__ method returns a list iterator which contains only text values
    data = list(testenv)
    testenv_iter = iter(data)
    # Verify that all the values are the text values
    for item in testenv_iter:
        assert isinstance(item, str)


# Generated at 2022-06-23 14:32:08.632827
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # .__init__()
    #   .uses raw os.environ if not passed anything
    #       /usr/bin/env python3
    environ = _TextEnviron()
    assert environ._raw_environ is os.environ
    assert environ.encoding == sys.getfilesystemencoding()
    #   .encoding is used if passed to .__init__()
    #       /usr/bin/env python3
    environ = _TextEnviron(encoding='latin-1')
    assert environ.encoding == 'latin-1'
    #   .encoding defaults to utf-8 if no encoding specified
    #       /usr/bin/env python3
    environ = _TextEnviron(encoding=None)
    assert environ.encoding == sys.getfilesystemencoding()

# Generated at 2022-06-23 14:32:11.118751
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ.update({'foo': 'bar'})

    assert environ['foo'] == 'bar'


# Generated at 2022-06-23 14:32:19.207819
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # pylint: disable=duplicate-code
    e1 = _TextEnviron()
    assert isinstance(e1, MutableMapping)

    # Constructor with a dictionary should set the dictionary
    #
    # Also test that the encoded value is stored in the environment
    e2 = _TextEnviron({'foo': 'bar'})
    assert isinstance(e2, MutableMapping)
    assert e2['foo'] == 'bar'
    assert e2._raw_environ[b'foo'] == to_bytes('bar', encoding='utf-8', nonstring='strict',
                                               errors='surrogate_or_strict')

    # Constructor with an encoding should change the encoding
    e3 = _TextEnviron(encoding='utf-16')

# Generated at 2022-06-23 14:32:22.219169
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    test_environ = _TextEnviron({})
    assert len(test_environ) == 0
    test_environ['foo'] = 'bar'
    assert len(test_environ) == 1



# Generated at 2022-06-23 14:32:28.044600
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ.clear()
    os.environ.setdefault('TestTextEnviron1', 'TestTextEnviron1')
    os.environ.setdefault('TestTextEnviron2', 'TestTextEnviron2')
    print('Length before deleting: ', len(environ._raw_environ))
    del environ['TestTextEnviron1']
    print('Length after deleting: ', len(environ._raw_environ))
    print(environ._raw_environ)


# Generated at 2022-06-23 14:32:39.163408
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron({'bytes-key': b'bytes-value', 'text-key': 'text-value'})
    # Check that keys and values are returned as text
    for key, value in env.items():
        assert not isinstance(key, bytes)
        assert not isinstance(value, bytes)

    # Check that modifying results in bytes values in the underlying dictionary
    env['key'] = 'value'
    assert env['key'] == 'value'
    assert isinstance(env._raw_environ['key'], bytes)
    assert env._raw_environ['key'] == b'value'

    # Check that if we delete the key, it is removed from the underlying dictionary
    del env['key']
    assert 'key' not in env
    assert 'key' not in env._raw_environ

    # Check that if

# Generated at 2022-06-23 14:32:48.156023
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test construction with no options
    environ0 = _TextEnviron()
    assert environ0._raw_environ is os.environ
    assert environ0._value_cache == {}
    assert environ0.encoding == sys.getfilesystemencoding()
    # Test construction with a dict
    environ1 = _TextEnviron(env={u'key1': 'value1',
                                 u'key2': u'value2',
                                 u'key3': u'value3',
                                 })
    assert environ1._raw_environ is not os.environ
    assert environ1._raw_environ == {u'key1': 'value1',
                                     u'key2': u'value2',
                                     u'key3': u'value3',
                                     }
    assert environ1

# Generated at 2022-06-23 14:32:58.493694
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    def test_1():
        obj = _TextEnviron()
        obj['test'] = 'test'
        if obj._raw_environ['test'] != 'test':
            raise AssertionError('Expected raw value test but got %s' % obj._raw_environ['test'])
    test_1()
    def test_2():
        obj = _TextEnviron()
        test_value = u'\U0001f300'
        obj['test'] = test_value
        if obj._raw_environ['test'] != '\xf0\x9f\x8c\x80':
            raise AssertionError('Expected raw value fef0:9f:8c:80 but got %s' % obj._raw_environ['test'])
    test_2()

# Generated at 2022-06-23 14:33:08.162066
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()

    # Test case 1: value is a str
    # Expectation: value is set to a byte string
    # Bug: https://github.com/ansible/ansible/issues/38558
    env['key1'] = 'value'
    assert env._raw_environ['key1'] == b'value'

    # Test case 2: value is an int
    # Expectation: value is set to a byte string
    # Bug: https://github.com/ansible/ansible/issues/38558
    env['key2'] = 123
    assert env._raw_environ['key2'] == b'123'

    # Test case 3: value is a float
    # Expectation: value is set to a byte string
    # Bug: https://github.com/ansible/ansible/issues/38558

# Generated at 2022-06-23 14:33:09.695679
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    assert len(env) == len(env._raw_environ)



# Generated at 2022-06-23 14:33:17.475541
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    '''
    Unit test for method __iter__ of class _TextEnviron.
    '''

    # Test with a single item and with a dictionary with multiple items.
    for test_dictionary in ({'key1': 'value1'}, os.environ):
        temp_env = _TextEnviron(env=test_dictionary)
        test_object = temp_env.__iter__()

        # Ensure that the method call returned the expected object type.
        assert isinstance(test_object, dict_view)

        # Ensure that the method call returned the expected dictionary items.
        assert sorted(test_object) == sorted(test_dictionary.keys())


# Generated at 2022-06-23 14:33:25.750175
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Test deleting a key when the underlying string is in the cache
    environ['test-key'] = 'test value'
    assert(environ['test-key'] == 'test value')
    del environ['test-key']
    assert('test-key' not in environ)

    # Test deleting a key when the underlying string is not in the cache
    environ['test-key'] = 'test value'
    assert(environ['test-key'] == 'test value')
    del environ['test-key']
    assert('test-key' not in environ)



# Generated at 2022-06-23 14:33:34.330476
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ['FOO'] = 'Bar'
    environ['TEST1'] = 'Foo'
    environ['TEST2'] = 'Bar'
    environ['TEST3'] = 'Baz'
    environ['TEST4'] = 'Bar'
    del environ['TEST3']
    del environ['TEST4']
    assert 'TEST1' in environ
    assert 'TEST2' in environ
    assert 'TEST3' not in environ
    assert 'TEST4' not in environ
    assert 'FOO' in environ


# Generated at 2022-06-23 14:33:36.640688
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    testenv = _TextEnviron({'a': '1', 'b': '2'})
    assert testenv.__iter__() == ['a', 'b']

# Generated at 2022-06-23 14:33:37.901318
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
  assert (len(environ) == len(os.environ))


# Generated at 2022-06-23 14:33:50.246403
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # pylint: disable=redefined-outer-name,missing-docstring
    from ansible.module_utils._text import to_bytes, to_text

    # Test that we get the same thing back for values already stored in UTF-8
    utf8_value = u'\u3053\u3093\u306b\u3061\u306f'
    assert utf8_value == environ[utf8_value.encode('utf-8')]

    # Mock up a non-utf8 environment
    os.environ = {'WAT': u'\u3053\u3093\u306b\u3061\u306f'.encode('shift-jis')}
    old_environ = os.environ

    # Make sure we get the value decoded as utf-8
    environ

# Generated at 2022-06-23 14:33:58.189471
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = {to_bytes(k): to_bytes(v) for k, v in os.environ.items()}
    env[b'ANSIBLE_MODULE_TESTING_TEXTENVIRON_ONE'] = b'value 2'
    env[b'ANSIBLE_MODULE_TESTING_TEXTENVIRON_TWO'] = b'value 2'
    te = _TextEnviron(env)

    # Check the iterator returns keys in the correct order
    assert list(iter(te)) == list(iter(env))

# Generated at 2022-06-23 14:34:01.343965
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron(env=dict(a=1, b='foo'))
    assert len(env) == 2


# Generated at 2022-06-23 14:34:10.995327
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron({b'unicode_key': b'unicode_value'})
    assert 'unicode_key' in e
    assert 'unicode_value' == e['unicode_key']
    assert b'unicode_value' == e._raw_environ[b'unicode_key']
    # Test cached values
    assert 'unicode_value' == e['unicode_key']
    # Test missing element
    try:
        e['missing_key']
    except KeyError as exc:
        assert exc.args[0] == b'missing_key'
    else:
        assert False, 'Missing exception raising'


# Generated at 2022-06-23 14:34:13.642074
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test to ensure that the 'getitem' returns a value that is a unicode type on python 2.
    assert isinstance(environ.__getitem__('PATH'), unicode)

# Generated at 2022-06-23 14:34:20.424867
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron(encoding='ascii')
    # Verify that the value gets coerced to bytes
    env[b'test'] = 'a'
    assert b'a' == env._raw_environ[b'test']
    # Verify that a TypeError is raised for non-string values
    try:
        env[b'test2'] = 5
    except TypeError:
        assert os.environ != env._raw_environ
    else:
        raise AssertionError('A type error should be raised when setting a non-string value')



# Generated at 2022-06-23 14:34:30.984292
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    env_var = 'HOME'
    # Cache keys off of the undecoded values to handle any environment variables which change
    # during a run
    if PY3:
        expected = os.environ[env_var]
        result = environ[env_var]
        assert isinstance(result, str)
        assert result == expected
    else:
        expected = to_text(os.environ[env_var], encoding=environ.encoding,
                           nonstring='passthru', errors='surrogate_or_strict')
        result = environ[env_var]
        assert isinstance(result, unicode)
        assert result == expected
        # Re-read the env_var after mocking the object
        # Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-23 14:34:35.104554
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron()
    em = os.environ
    assert len(list(env)) == len(em)
    for var in env:
        print(var)
        assert var == to_text(var)
        assert env[var] == to_text(em[var])

# Generated at 2022-06-23 14:34:35.870995
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron()
    for i in env:
        assert i in environ

# Generated at 2022-06-23 14:34:37.438504
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == os.environ['PATH']

# Generated at 2022-06-23 14:34:47.146531
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if not PY3:
        environ_ = _TextEnviron({'some_variable': 'value'})
        assert isinstance(environ_['some_variable'], str)
        assert environ_['some_variable'] == 'value'

        # The same value has to be decoded only once
        environ_ = _TextEnviron({'some_variable': 'value'})
        assert isinstance(environ_['some_variable'], str)
        assert environ_['some_variable'] == 'value'
        assert environ_.get('some_variable') == 'value'

        # Ensure that it is case-sensitive
        environ_ = _TextEnviron({'SOME_VARIABLE': 'value'})
        assert isinstance(environ_['SOME_VARIABLE'], str)
        assert en

# Generated at 2022-06-23 14:34:53.372500
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os.environ.clear()
    if PY3:
        os.environ['TEST_TEXT'] = 'test string'
        os.environ['TEST_BINARY'] = b'test string'
    else:
        os.environ['TEST_TEXT'] = u'test string'
        os.environ['TEST_BINARY'] = b'test string'

    env = _TextEnviron()

    for key, value in env.items():
        if key == 'TEST_TEXT':
            assert value == u'test string'
        elif key == 'TEST_BINARY':
            assert value == u'test string'
        else:
            assert False, "Got an unexpected key from the environment: %s" % key



# Generated at 2022-06-23 14:34:58.122274
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    os.environ['ANSIBLE_PYTHON_VERSION'] = '2.7'
    text_env = _TextEnviron()
    assert text_env._raw_environ == os.environ
    # Should return unicode
    assert isinstance(text_env['ANSIBLE_PYTHON_VERSION'], str)


# Generated at 2022-06-23 14:35:05.683412
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    t = _TextEnviron()
    k = '\u2603'  # snowman in utf-8, but not ascii
    v = '\u2603'  # snowman in utf-8, but not ascii
    t[k] = v
    assert os.environ[to_bytes(k, encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')] == to_bytes(v, encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')


# Generated at 2022-06-23 14:35:16.668015
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    def _get_list(env):
        keys = []
        for key in env:
            keys.append(key)
        return keys

    test_env = {
        'ANSIBLE_LINT_TEST_VARIABLE': 'A' * 10,
        b'ANSIBLE_LINT_TEST_VARIABLE2': b'B' * 10
    }

    # Check that we get only unicode objects back from environment variable keys
    te = _TextEnviron(test_env)
    keys = _get_list(te)
    for key in keys:
        assert isinstance(key, str)

    # Check that we get only unicode objects back from environment variable keys
    te = _TextEnviron(test_env, encoding='ascii')
    keys = _get_list(te)

# Generated at 2022-06-23 14:35:21.043134
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ['ASDF'] = 'ASDF'
    assert 1 == len(environ)
    os.environ['ASDF'] = 'ASDF'
    assert 1 == len(environ)
    del os.environ['ASDF']
    assert 0 == len(environ)



# Generated at 2022-06-23 14:35:25.698172
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ.clear()
    environ['teststr'] = u'你好，世界'
    assert b'\xe4\xbd\xa0\xe5\xa5\xbd\xef\xbc\x8c\xe4\xb8\x96\xe7\x95\x8c' == environ._raw_environ['teststr']

# Generated at 2022-06-23 14:35:37.075451
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import unittest
    import os

    class Test__TextEnviron___iter__(unittest.TestCase):
        def test_iter(self):
            with self.assertRaises(OSError):
                os.environ['_INVALID_VARIABLE_NAME']
            self.assertEqual(os.environ['_INVALID_VARIABLE_NAME'], '_INVALID_VARIABLE_NAME')
            del environ['_INVALID_VARIABLE_NAME']
            self.assertEqual(os.environ['_INVALID_VARIABLE_NAME'], '_INVALID_VARIABLE_NAME')

    # unittest.main()
    suite = unittest.TestSuite()

# Generated at 2022-06-23 14:35:45.423175
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils.six import PY2, PY3

    test_environ = {to_bytes('test1'): to_bytes('test1'), to_bytes('test2'): to_bytes('test2')}
    if PY2:
        # Python2: keys() returns a list of byte-strings while iterkeys() returns an iterable of
        # byte strings
        expected = set([to_bytes('test1'), to_bytes('test2')])
        got = set(environ.__iter__())
        assert got == expected
    elif PY3:
        # Python3: keys() returns an iterable of text strings while iterkeys() returns a TypeError
        expected = set([to_bytes('test1').decode('utf-8'), to_bytes('test2').decode('utf-8')])

# Generated at 2022-06-23 14:35:55.759800
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    e = _TextEnviron({
        u'ascii_value': 'ascii',
        'bytes_value': b'bytes',
        u'unicode_value': u'unicode'
        })
    assert e['ascii_value'] == u'ascii'
    assert e[b'bytes_value'] == u'bytes'
    assert e[u'unicode_value'] == u'unicode'
    assert len(e) == 3
    assert e.encoding == 'utf-8'

    e = _TextEnviron({
        u'ascii_value': 'ascii',
        'bytes_value': b'bytes',
        u'unicode_value': u'unicode'
        }, encoding='ascii')

# Generated at 2022-06-23 14:36:02.868166
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ_test = _TextEnviron()
    # Test unicode
    environ_test["key1"] = u"string_u"
    assert isinstance(environ_test["key1"], str)
    assert environ_test._raw_environ["key1"] == b"string_u"

    # Test bytes
    environ_test["key1"] = b"string_b"
    assert isinstance(environ_test["key1"], str)
    assert environ_test._raw_environ["key1"] == b"string_b"

    # Test integer
    try:
        environ_test["key1"] = 1
    except TypeError:
        pass
    else:
        assert False, "Should raise TypeError"


# Generated at 2022-06-23 14:36:04.390494
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import doctest
    doctest.testmod()



# Generated at 2022-06-23 14:36:11.739004
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Create an environ without passing an environment to the constructor
    e = _TextEnviron()
    # Test that we can delete a key
    e['FOO'] = 'bar'
    assert e['FOO'] == 'bar'
    del e['FOO']
    assert 'FOO' not in e
    # Test that we can delete a key previously deleted from os.environ
    os.environ['BAR'] = 'baz'
    e['BAR'] = 'baz'
    assert e['BAR'] == 'baz'
    del e['BAR']
    assert 'BAR' in os.environ
    assert 'BAR' not in e


# Generated at 2022-06-23 14:36:14.676160
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Testing for correct length of _TextEnviron class
    assert len(environ) == len(_TextEnviron(encoding='utf-8'))



# Generated at 2022-06-23 14:36:20.802561
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ_bak = dict(os.environ)

    try:
        del environ['PATH']
        assert 'PATH' not in os.environ

        os.environ['PATH'] = '/usr/bin:/bin'
        environ['PATH'] = '/usr/bin:/bin'
        del environ['PATH']
        assert 'PATH' not in os.environ
    finally:
        os.environ.clear()
        os.environ.update(environ_bak)



# Generated at 2022-06-23 14:36:23.418325
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron(env={'test': 'value'}, encoding='utf-8')
    assert isinstance(env.__iter__(), list)
    assert env.__iter__() == ['test']


# Generated at 2022-06-23 14:36:24.201499
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
  assert len(environ) == 1


# Generated at 2022-06-23 14:36:34.186505
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Verify that the method works when the os.environ is a string
    environ = _TextEnviron({'a': 'b'})
    del environ['a']
    assert 'a' not in environ

    # Verify that the method works when the os.environ is a byte string
    environ = _TextEnviron({to_bytes('a'): to_bytes('b')})
    del environ['a']
    assert 'a' not in environ

    # Verify that the method works when the os.environ is a unicode
    environ = _TextEnviron({'a': u'b'})
    del environ['a']
    assert 'a' not in environ


# Generated at 2022-06-23 14:36:45.382080
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    '''
    _TextEnviron.__iter__()
    '''
    env1 = {'A':'1', 'B': '2', 'C': '3'}
    env2 = {'D': '4'}
    env3 = {'E': '5'}
    env4 = {'F': '6'}
    env5 = {'G': '7'}
    env6 = {'H': '8'}

    test_obj = None

    ###########################################################################
    # Test 1: Test basic functionality of __iter__()
    #         1. Create an instance of _TextEnviron
    #         2. Check that __iter__() returns a valid iterator.
    ###########################################################################
    test_obj = _TextEnviron(env1)
    it = test_obj.__iter__

# Generated at 2022-06-23 14:36:50.140193
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['ANSIBLE_MODULE_ARGS'] == sys.argv[1:]
    assert environ['PYTHONPATH'] == ':'.join(sys.path)
    assert environ['HOME'] == '/home/a_badger'



# Generated at 2022-06-23 14:36:54.294664
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(environ['HOME'], str)
    # Check that we get an exception when the value cannot be decoded.
    # We cannot check for UnicodeError here because in Python3, UnicodeError is always thrown
    # from __getitem__
    try:
        environ['bad_value']
    except Exception as e:
        assert '' in str(e)
    else:
        assert False



# Generated at 2022-06-23 14:37:00.120216
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ.clear()
    os.environ['a'] = 'A'
    os.environ['b'] = 'B'

    if 'a' in os.environ:
        assert 'a' in environ
        assert environ['a'] == 'A'

    del environ['a']
    assert 'a' not in environ
    assert 'a' not in os.environ
    del environ['b']
    assert 'b' not in environ
    assert 'b' not in os.environ



# Generated at 2022-06-23 14:37:04.547874
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Removing an existing environment variable by its key will delete the key.
    """
    env = {}
    env['key'] = 'existing value'
    environ = _TextEnviron(env)
    del environ['key']
    assert 'key' not in environ



# Generated at 2022-06-23 14:37:05.093653
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isins

# Generated at 2022-06-23 14:37:15.513834
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # default encoding: utf-8
    env = _TextEnviron(encoding='utf-8')
    env['key'] = 'value'
    assert env._raw_environ['key'] == b'value'
    assert env['key'] == 'value'
    
    # encoding: ascii
    env = _TextEnviron(encoding='ascii')
    env['key'] = 'value'
    assert env._raw_environ['key'] == b'value'
    assert env['key'] == 'value'

    # encoding: us-ascii
    env = _TextEnviron(encoding='us-ascii')
    env['key'] = 'value'
    assert env._raw_environ['key'] == b'value'
    assert env['key'] == 'value'

    # encoding: ut

# Generated at 2022-06-23 14:37:26.246041
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = {"a": "value"}
    # Test that environment vars get converted
    e = _TextEnviron(env=env)
    assert len(e) == 1
    assert e["a"] == "value"
    assert not e._raw_environ
    # Test that the raw environment gets saved
    e = _TextEnviron(encoding="ascii", env=env)
    assert len(e._raw_environ) == 1
    # Test that the environment gets copied
    env["b"] = "value"
    assert len(e._raw_environ) == 1
    # Test that __setitem__ works
    e["a"] = "value2"
    assert len(e._raw_environ) == 2
    assert isinstance(e._raw_environ["a"], bytes)
    # Test that __getitem

# Generated at 2022-06-23 14:37:29.779162
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    _environ = {'a': 'b', 'c': 'd', 'e': 'f'}
    _te = _TextEnviron(_environ)
    assert len(_te) == len(_environ)


# Generated at 2022-06-23 14:37:34.453717
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Presume os.environ non-empty
    len_environ = len(environ)
    for key in environ.keys():
        del environ[key]
        assert(len_environ - 1 == len(environ))
        len_environ -= 1


# Generated at 2022-06-23 14:37:35.317368
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ) == list(os.environ)


# Generated at 2022-06-23 14:37:45.184726
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Check that encoding defaults to the fs encoding
    os.environ['LANG'] = b'en_US.utf-8'
    te = _TextEnviron()
    assert te.encoding == sys.getfilesystemencoding(), 'Failed to set encoding to the fs encoding'

    # Check that the environment variable is returned as text
    os.environ['LANG'] = b'en_US.utf-8'
    te = _TextEnviron()
    assert te['LANG'] == u'en_US.utf-8', 'Failed to return text strings'
    assert isinstance(te['LANG'], type(u'')), 'Failed to return text strings'

    # Check that __setitem__ recodes
    os.environ['LANG'] = b'en_US.utf-8'
    te = _Text