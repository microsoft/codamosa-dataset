

# Generated at 2022-06-23 14:27:45.010111
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['TEST'] = 'Hello World!'
    assert environ['TEST'] == 'Hello World!'
    del environ['TEST']


# Generated at 2022-06-23 14:27:48.468486
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'FOO': b'bar', b'BAZ': b'quux'}, encoding='utf-8')
    assert env['FOO'] == 'bar'
    assert env['BAZ'] == 'quux'



# Generated at 2022-06-23 14:27:50.908790
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils.six import iterkeys
    assert iterkeys(environ) == iterkeys(os.environ)


# Generated at 2022-06-23 14:27:54.480497
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _TextEnviron.__delitem__(environ,'test_env')
    if 'test_env' in environ._raw_environ:
        raise AssertionError


# Generated at 2022-06-23 14:28:00.342448
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """
    Check that `__iter__` method of _TextEnviron returns text in python3 and bytes in python2.
    """
    class _BadIter():
        def __iter__(self):
            return self
        def __next__(self):
            pass

    if PY3:
        assert not isinstance(environ.__iter__(), bytes)
        assert isinstance(environ.__iter__(), str)
    else:
        assert isinstance(environ.__iter__(), _BadIter)

# Generated at 2022-06-23 14:28:04.327978
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    _env = _TextEnviron({'one': '1', 'two': '2', 'three': 3})
    assert set(_env.__iter__()) == set(['one', 'two', 'three'])



# Generated at 2022-06-23 14:28:06.001716
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert len(list(environ.keys())) > 0


# Generated at 2022-06-23 14:28:14.178026
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import os
    import sys
    import unittest

    PY2 = sys.version_info[0] == 2
    PY3 = sys.version_info[0] == 3

    class _TextEnvironTestCase(unittest.TestCase):
        def setUp(self):
            # reset the values in the environment
            if PY2:
                env = os.environ
            else:
                env = environ._raw_environ
            env.pop('ANSIBLE_TEST_PY3_ENV_1', None)
            env.pop('ANSIBLE_TEST_PY3_ENV_2', None)

        def test_init_defaults(self):
            if PY2:
                self.assertEqual(os.environ, environ._raw_environ)

# Generated at 2022-06-23 14:28:22.455280
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test UTF-8
    environ._raw_environ['ANSIBLE_TEST_ENCODING'] = u'\u2500'.encode('utf-8')
    assert environ['ANSIBLE_TEST_ENCODING'] == u'\u2500'

    # Test binary
    environ._raw_environ['ANSIBLE_TEST_BINARY'] = b'\x0a\x1f\xff'
    assert environ['ANSIBLE_TEST_BINARY'] == b'\x0a\x1f\xff'

    # Test ASCII
    environ._raw_environ['ANSIBLE_TEST_ASCII'] = b'This is ASCII text'
    assert environ['ANSIBLE_TEST_ASCII'] == 'This is ASCII text'

    # Test latin1
    environ._raw

# Generated at 2022-06-23 14:28:32.556455
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import unittest
    import sys

    class TestTextEnviron(unittest.TestCase):
        def setUp(self):
            self.old_env = os.environ
            os.environ = {to_bytes('k1', encoding=sys.getfilesystemencoding()): to_bytes('v1', encoding=sys.getfilesystemencoding()),
                          to_bytes('k2', encoding=sys.getfilesystemencoding()): to_bytes('v2', encoding=sys.getfilesystemencoding())}
            self.textenv = environ

        def tearDown(self):
            os.environ = self.old_env


# Generated at 2022-06-23 14:28:41.660953
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Type of the _raw_environ should be bytes
    environ[to_bytes('TEST_VAR_1')] = to_bytes('TEST_VALUE_1')
    assert type(environ._raw_environ[to_bytes('TEST_VAR_1')]) == bytes
    environ[to_bytes('TEST_VAR_2')] = to_text('TEST_VALUE_2', encoding='utf-8')
    assert type(environ._raw_environ[to_bytes('TEST_VAR_2')]) == bytes


# Generated at 2022-06-23 14:28:52.882551
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Passing encoding=None results in using sys.getfilesystemencoding()
    env = _TextEnviron(encoding=None)
    assert env.encoding == sys.getfilesystemencoding()
    # Pick an encoding that is not the default to ensure that we're using our encoding
    encoding = os.environ.get('PYTHONIOENCODING', 'utf-8')
    if encoding == sys.getfilesystemencoding():
        encoding = 'utf-8'
    env = _TextEnviron(encoding=encoding)
    assert env.encoding == encoding
    # When we pass in an _environment_, it might have bytes or text values in it already.
    assert isinstance(env['PYTHONIOENCODING'], str)
    # Values are cached as text values.  If the byte string value changes, we

# Generated at 2022-06-23 14:28:55.275091
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['ansible_test_key'] = 'test'
    assert environ['ansible_test_key'] == 'test'


# Generated at 2022-06-23 14:28:57.197199
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ) == list(os.environ)



# Generated at 2022-06-23 14:29:06.523416
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # pylint: disable=protected-access

    # Test that unicode text values get converted to bytes
    environ['foo'] = u'bar'
    assert isinstance(environ._raw_environ['foo'], bytes)
    assert environ._raw_environ['foo'] == b'bar'

    # Test that strings which are already bytes get passed through unchanged
    environ['foo'] = b'baz'
    assert isinstance(environ._raw_environ['foo'], bytes)
    assert environ._raw_environ['foo'] == b'baz'

    # Test that undefined keys raise KeyErrors
    with pytest.raises(KeyError):
        environ['missing']
    with pytest.raises(KeyError):
        del environ['missing']

    # Test that we can del keys
   

# Generated at 2022-06-23 14:29:18.182711
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    try:
        os.environ[to_bytes('bytes_key')] = b'bytes_value'
        os.environ[u'unicode_key'] = u'unicode_value'
        txt_env = _TextEnviron(encoding='utf-8')
        assert txt_env[u'bytes_key'] == u'bytes_value'
        assert txt_env[u'unicode_key'] == u'unicode_value'
        assert txt_env[b'bytes_key'] == u'bytes_value'
        assert txt_env[b'unicode_key'] == u'unicode_value'
        del os.environ[to_bytes('bytes_key')]
        del os.environ[u'unicode_key']
    except:
        raise

# Generated at 2022-06-23 14:29:22.987028
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ['test_value'] = 'test_value'
    assert len(environ) > 0
    assert 'test_value' in environ
    assert environ.get('test_value') == 'test_value'
    del os.environ['test_value']
    assert len(environ) > 0
    assert 'test_value' not in environ
    assert environ.get('test_value') is None


# Generated at 2022-06-23 14:29:34.729033
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class _Environ(object):
        def __init__(self):
            self.env = {'key1': 'value1', 'key2': 'value2'}

        def __getitem__(self, key):
            if key not in self.env:
                raise IndexError
            return self.env[key]

    dummy_environ = _Environ()
    dummy_environ.env['key3'] = 'value3'

    text_environ = _TextEnviron(env=dummy_environ)

    # Key is present
    assert 'value1' == text_environ[u'key1']
    assert 'value2' == text_environ[u'key2']

    # Key is not present

# Generated at 2022-06-23 14:29:36.069463
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:29:37.395377
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)

# Generated at 2022-06-23 14:29:41.242723
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({'key1': 'value1', 'key2': 'value2', 'key3': 'value3'})
    assert len(env) == 3


# Generated at 2022-06-23 14:29:45.043958
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    existing_key = None
    for key in environ:
        existing_key = key
        break
    else:
        # No existing keys, can't test
        return

    del environ[existing_key]
    assert not environ.get(existing_key)



# Generated at 2022-06-23 14:29:46.648830
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert set(environ) == set(os.environ)


# Generated at 2022-06-23 14:29:56.361385
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = dict()
    env['ANSIBLE_TEST_ENCODING_1'] = b'\xe4\xb8\x80'
    env['ANSIBLE_TEST_ENCODING_2'] = b'\xe4\xb8\x80'
    env['ANSIBLE_TEST_ENCODING_3'] = b'\xe4\xb8\x80'
    env['ANSIBLE_TEST_ENCODING_4'] = b'\xe4\xb8\x80'
    env['ANSIBLE_TEST_ENCODING_5'] = b'\xe4\xb8\x80'
    env['ANSIBLE_TEST_ENCODING_6'] = b'\xe4\xb8\x80'

# Generated at 2022-06-23 14:30:03.421333
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():

    from collections import Counter

    _TextEnviron_dict = dict(var1='foo1', var2='foo2', var3='foo3', var4='foo4')

    t_environ_test_dict = _TextEnviron(_TextEnviron_dict)

    result = [key for key in t_environ_test_dict]
    expected = [key for key in _TextEnviron_dict]

    assert Counter(result) == Counter(expected)



# Generated at 2022-06-23 14:30:09.987033
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    data = [
        'a',
        'long',
        'list',
        'of',
        'words',
    ]
    result = [
        'a',
        'long',
        'list',
        'of',
        'words',
    ]

    # Create _TextEnviron object
    obj = _TextEnviron(data)

    # Run unit test
    assert(len(obj) == len(result))


# Generated at 2022-06-23 14:30:16.514128
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import os

    # make sure the env is empty
    os.environ.clear()
    assert len(environ) == 0

    # import os as our dict
    os.environ = {'ANSIBLE_TEST_KEY': 'ANSIBLE_TEST_VAL'}
    environ = _TextEnviron(encoding='utf-8')

    # assert that we have 1 key
    assert len(environ) == 1

    # assert that accessing len does not trigger encoding the values
    assert len(environ) == len(os.environ)

# Generated at 2022-06-23 14:30:22.340143
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    tmp_env = _TextEnviron()
    tmp_env['foo'] = 'a'
    tmp_env['bar'] = 'b'
    assert len(tmp_env) == 2
    del tmp_env['foo']
    assert tmp_env['bar'] == 'b'
    assert len(tmp_env) == 1
    return True


# Generated at 2022-06-23 14:30:24.064450
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert isinstance(len(environ), int)

if __name__ == '__main__':
    test__TextEnviron___len__()

# Generated at 2022-06-23 14:30:31.342709
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils import six
    from ansible.module_utils.six.moves import cPickle as pickle

    assert isinstance(environ, _TextEnviron)
    assert isinstance(environ, dict)
    assert isinstance(environ, six.Iterator)

    # Pickling should just be a copy of the raw environ
    assert pickle.loads(pickle.dumps(environ)) == environ._raw_environ

    # Test pickling while using the text based accessors of the class
    environ['test-1'] = 'test-1'

    assert pickle.loads(pickle.dumps(environ)) == environ._raw_environ
    assert pickle.loads(pickle.dumps(environ))['test-1'] == 'test-1'

# Generated at 2022-06-23 14:30:33.959906
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # TypeError would be raised if input is invalid.
    a = _TextEnviron('{}')
    assert len(a) == 0
    a['A'] = 'B'
    assert len(a) == 1



# Generated at 2022-06-23 14:30:42.421664
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test that we have a class
    assert hasattr(_TextEnviron, '__init__')

    # Test that we have class methods
    assert hasattr(_TextEnviron, '__delitem__')
    assert hasattr(_TextEnviron, '__getitem__')
    assert hasattr(_TextEnviron, '__setitem__')
    assert hasattr(_TextEnviron, '__iter__')
    assert hasattr(_TextEnviron, '__len__')

    # Test when not given an environment
    text_environ = _TextEnviron(env=None)
    assert isinstance(text_environ, _TextEnviron)

# Generated at 2022-06-23 14:30:43.250171
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert 0 == len(environ)


# Generated at 2022-06-23 14:30:51.675835
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    from ansible.module_utils._text import to_bytes, to_text
    _raw_environ = {'a': '1', 'b': '2', 'c': '3'}
    _value_cache = _raw_environ.copy()
    te = _TextEnviron(_raw_environ)
    te.__delitem__('b')
    assert 'b' not in te
    assert 'b' not in _raw_environ
    assert 'b' in _value_cache
    assert 'b' not in te._value_cache


# Generated at 2022-06-23 14:30:52.515881
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) >= 1


# Generated at 2022-06-23 14:31:02.851637
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from os import environ
    # Need to import here because _TextEnviron imports this module.
    from ansible.module_utils.common._collections_compat import Sequence

    env = _TextEnviron(env=environ, encoding='utf-8')
    assert isinstance(env, MutableMapping)
    assert isinstance(env, Sequence)
    assert not isinstance(env, type)



# Generated at 2022-06-23 14:31:07.057205
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = type('test_environment', (object,), {})()
    env.data = {}
    env.keyError = False
    def __getitem__(self, key):
        return self.data[key]
    def __setitem__(self, key, value):
        self.data[key] = value
    def __delitem__(self, key):
        del self.data[key]
    def __len__(self):
        return len(self.data)
    def __iter__(self):
        return self.data.__iter__()
    def __contains__(self, key):
        return key in self.data
    env.__getitem__ = __getitem__
    env.__setitem__ = __setitem__
    env.__delitem__ = __delitem__
    env.__

# Generated at 2022-06-23 14:31:13.453920
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _test_environ = _TextEnviron()

    if 'TEST_ENV_DEL' in _test_environ:
        del _test_environ['TEST_ENV_DEL']
    _test_environ['TEST_ENV_DEL'] = 'Test'
    del _test_environ['TEST_ENV_DEL']
    # check if the environment variable is not set,
    # only then test will pass.
    assert 'TEST_ENV_DEL' not in _test_environ


# Generated at 2022-06-23 14:31:21.796287
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ[to_bytes('LANG', 'ascii', 'strict')] = to_bytes('en_US', 'ascii', 'strict')
    os.environ[to_bytes('ANSIBLE_TEST_KEY', 'ascii', 'strict')] = to_bytes('VALUE', 'ascii', 'strict')

    assert 'LANG' in environ
    assert 'ANSIBLE_TEST_KEY' in environ

    del environ['LANG']

    assert 'LANG' not in environ
    assert 'ANSIBLE_TEST_KEY' in environ



# Generated at 2022-06-23 14:31:24.101457
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['test_del_key'] = 'test_del_value'
    assert 'test_del_key' in environ
    del environ['test_del_key']
    assert 'test_del_key' not in environ


# Generated at 2022-06-23 14:31:35.213883
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """Verify Variable __setitem__"""
    env1 = _TextEnviron({'a': b'foo'}, encoding='utf-8')
    assert env1['a'] == u'foo'
    env1['a'] = u'foo'
    assert env1['a'] == u'foo'
    env1['a'] = u'\x80'
    assert env1['a'] == u'\uFFFD'
    env1['a'] = u'\uD83D\uDC4A'
    assert env1['a'] == u'\U0001F44A'
    env1['a'] = u'\uD800\uDC00'
    assert env1['a'] == u'\U00010000'
    env1['a'] = b'foo'

# Generated at 2022-06-23 14:31:37.701721
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron({'a': 1, 'b': 2, 'c': 3})
    assert list(environ) == ['a', 'b', 'c']


# Generated at 2022-06-23 14:31:46.031332
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Unit test for method __getitem__ of class _TextEnviron."""
    import unittest

    class MyTestCase(unittest.TestCase):
        def test__TextEnviron___getitem__(self):
            environ = _TextEnviron({b'KEY': b'VAL'}, encoding='utf-8')
            self.assertEqual(environ['KEY'], u'VAL')

    my_test_case = MyTestCase()
    my_test_case.test__TextEnviron___getitem__()
    del my_test_case

# Generated at 2022-06-23 14:31:55.661425
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Since this is a unit test, it's ok to mutate the global state
    env = _TextEnviron()
    try:
        del env['ANSIBLE_NOSHELL']
    except KeyError:
        pass
    else:
        raise AssertionError("KeyError not raised on deletion of a non-existent key")
    env['ANSIBLE_NOSHELL'] = 'True'
    val = env['ANSIBLE_NOSHELL']
    del env['ANSIBLE_NOSHELL']
    try:
        backup_value = env['ANSIBLE_NOSHELL']
    except KeyError:
        pass
    else:
        raise AssertionError("KeyError not raised on deletion of a non-existent key")


# Generated at 2022-06-23 14:31:59.045012
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ.clear()
    assert len(environ) == 0
    environ['key'] = 'value'
    assert len(environ) == 1
    assert environ['key'] == 'value'


# Generated at 2022-06-23 14:32:05.024390
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Verifies that _TextEnviron.__setitem__ sets up the value as expected.
    """
    # Create a test instance
    test = _TextEnviron(encoding='utf-8')
    # Set an environment variable
    test['foo'] = 'bar'
    # Verify that the value is what we expect
    assert test['foo'] == 'bar'



# Generated at 2022-06-23 14:32:07.604604
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_environ = _TextEnviron(env={'foo': 'bar'})
    assert test_environ['foo'] == 'bar'
    del test_environ['foo']
    assert 'foo' not in test_environ


# Generated at 2022-06-23 14:32:11.596835
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    os.environ['TEST_TEXTENVIRON_VAR'] = 'foo'
    te = _TextEnviron()
    assert te['TEST_TEXTENVIRON_VAR'] == 'foo'

# Generated at 2022-06-23 14:32:19.426240
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    # create test file as a unicode file
    with open(os.path.join(tmpdir, "%s_1" % to_text(u'file\u0406')), 'wb') as f:
        f.write(b'file\xc6')
    unicode_utf8_list = []
    for filename in os.listdir(tmpdir):
        unicode_utf8_list.append(os.path.join(tmpdir, filename))

    unicode_utf8_list.sort()
    tmpdir_utf8_unicode_list = [to_text(f, encoding='utf-8', nonstring='strict', errors='strict') for f in os.listdir(to_bytes(tmpdir))]
    tmp

# Generated at 2022-06-23 14:32:27.156512
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    '''
    Unit test for constructor of class _TextEnviron.
    '''
    #
    # constructor with no arguments
    #
    environ1 = _TextEnviron()

    #
    # constructor with just a dictionary argument
    #
    env2 = {'key1': 'abc', 'key2': 'def'}
    environ2 = _TextEnviron(env2)

    #
    # constructor with dictionary and encoding
    #
    env3 = {'key1': 'abc', 'key2': 'def'}
    environ3 = _TextEnviron(env3, 'iso-8859-1')

# Generated at 2022-06-23 14:32:31.519688
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron(encoding='utf-8')
    assert isinstance(text_environ['LANG'], type(u''))
    assert text_environ['LANG'] == u'en_US.utf8'


# Generated at 2022-06-23 14:32:33.708304
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ["key"] = 'foo,bar\x00'
    assert environ["key"] == 'foo,bar\x00'

# Generated at 2022-06-23 14:32:44.287817
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from io import StringIO
    import sys
    import unittest
    from ansible.module_utils.six import PY3

    class Test_TextEnviron__setitem__(unittest.TestCase):
        """Test the __setitem__ method of the _TextEnviron class
        """

        def setUp(self):
            self.env = _TextEnviron()

        def _set_and_check(self, key, value, expected_value):
            self.env[key] = value
            observed = self.env[key]
            self.assertEqual(observed, expected_value)


# Generated at 2022-06-23 14:32:47.336045
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    _environ = _TextEnviron({"FOO": u"BAR", "PAUL": "Émile"})
    assert _environ['FOO'] == u'BAR'
    assert _environ['PAUL'] == u'Émile'


# Generated at 2022-06-23 14:32:50.212109
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    test_environ = _TextEnviron(env=dict(key1=b'value1', key2=b'value2'), encoding='utf-8')
    for key, value in test_environ.items():
        print(key, value)

# Generated at 2022-06-23 14:32:54.768953
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    e = _TextEnviron({b'ANSIBLE_TEST': b'value'}, 'utf-8')
    assert e[b'ANSIBLE_TEST'] == 'value'
    assert e['ANSIBLE_TEST'] == 'value'

# Generated at 2022-06-23 14:33:02.050594
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test basic functionality of _TextEnviron

    # pylint: disable=too-few-public-methods
    class _MockEnviron(MutableMapping):
        def __init__(self, env):
            self.env = env
            self.set = set()

        def __getitem__(self, key):
            return self.env[key]

        def __setitem__(self, key, value):
            self.set.add(key)
            self.env[key] = value

        def __delitem__(self, key):
            del self.env[key]

        def __iter__(self):
            return self.env.__iter__()

        def __len__(self):
            return len(self.env)


# Generated at 2022-06-23 14:33:03.616440
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, MutableMapping)



# Generated at 2022-06-23 14:33:07.493702
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    print('Testing __setitem__')
    environ['ANSIBLE_EASY'] = u'\u263a'
    # This will throw an exception if the wrong type was in environ.
    assert isinstance(environ['ANSIBLE_EASY'], text_type)
    print('passed')


# Generated at 2022-06-23 14:33:17.052048
# Unit test for method __iter__ of class _TextEnviron

# Generated at 2022-06-23 14:33:28.009135
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_dict = {
        'empty': '',
        'ascii': 'ascii',
        'utf8': u'\u2018',
        'binary': b'binary',
        'binary_utf8': b'\xe2\x80\x98',
    }

    assert environ['empty'] == ''
    assert environ['ascii'] == 'ascii'
    assert environ['utf8'] == u'\u2018'
    assert environ['binary'] == 'binary'
    assert environ['binary_utf8'] == u'\u2018'

    # Check that memoization works.
    environ.clear()
    environ._value_cache.clear()

    # Check cache keys off of the undecoded values
    environ['empty'] = test_dict['empty']
    assert en

# Generated at 2022-06-23 14:33:35.578992
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env_var1 = 'normal_text_var1'
    env_val1 = 'a'
    env_var2 = 'normal_text_var2'
    env_val2 = 'å'
    env_var3 = 'normal_text_var3'
    env_val3 = '久'
    env_var4 = 'normal_text_var4'
    env_val4 = 'இங்கே'
    env_var5 = 'normal_text_var5'
    env_val5 = 'కొనరాసం'

    ####################################################################################################
    # Single value tests
    ####################################################################################################
    # Test 1: Set environment variable with ASCII value
    # Result 1: Test to

# Generated at 2022-06-23 14:33:42.763384
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron()
    assert isinstance(env, MutableMapping)
    assert env._raw_environ is os.environ
    assert isinstance(env.encoding, str)
    assert env.encoding == 'utf-8'

    # Test the interface
    assert len(env) == len(os.environ)
    for key, value in iter(os.environ.items()):
        assert env[key] == value
        assert key in env
    assert list(env.keys()) == list(os.environ.keys())
    assert list(env.values()) == list(os.environ.values())
    assert list(env) == list(os.environ)
    key = 'ANSI_MODULE_UTILS_TEST_KEY'

# Generated at 2022-06-23 14:33:54.399909
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ.clear()
    original_environ_get = os.environ.get

    # Test the default case where the value is not set in the original environment
    assert environ['MY_VAR'] is None
    assert os.environ.get('MY_VAR') is None

    # Test the case where the value is a string
    environ['MY_VAR'] = u'foo'
    assert environ['MY_VAR'] == u'foo'
    assert os.environ.get('MY_VAR') == 'foo'

    # Test that the underlying os.environ was changed, too
    os.environ.clear()
    os.environ.get = original_environ_get
    assert environ['MY_VAR'] == u'foo'

    # Test the case where the value is a unicode


# Generated at 2022-06-23 14:34:02.675507
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    print('\n********** test__TextEnviron___setitem__()')
    print('# This test is good at checking that the class handles unicode characters.  On Python2,'
          ' it is also good at checking that the class is returning the same value for a key even'
          ' if the value was changed in the raw os.environ.  This is because the underlying values'
          ' from os.environ (in Python2) are bytes and the cached value is always checked against'
          ' the underlying os.environ value')
    print('# On Python3, it is still useful at handling unicode but is not as good at testing the'
          ' caching.  This is because the underlying values from os.environ (in Python3) are'
          ' already text strings')
    import os

# Generated at 2022-06-23 14:34:12.615842
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    class TestEnviron():
        def __getitem__(self, key):
            return to_bytes('value', encoding='utf-8')
        def __setitem__(self, key, value):
            pass
        def __delitem__(self, key):
            pass
        def __len__(self):
            return 1
        def __iter__(self):
            return [k for k in ['key']].__iter__()

    test_environ = _TextEnviron(env=TestEnviron())
    iter_environ = test_environ.__iter__()

    assert isinstance(iter_environ, iter)
    assert iter_environ.next() == 'key'

# Generated at 2022-06-23 14:34:21.661582
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    errmsg = "unable to decode '\\xff'"
    assert environ['LANG'] == environ._raw_environ['LANG']
    assert environ['LANG'].startswith('en')
    environ['FAIL_DECODE_TEST'] = to_bytes(u'\uFFFD\uFFFD', encoding='utf-8', errors='strict')
    try:
        environ['FAIL_DECODE_TEST']
    except UnicodeDecodeError as e:
        assert str(e) == errmsg
    environ['FAIL_DECODE_TEST'] = to_bytes(u'\uFFFD\uFFFD', encoding='utf-8', errors='ignore')
    assert environ['FAIL_DECODE_TEST'] == u''

# Generated at 2022-06-23 14:34:23.899333
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ_test = _TextEnviron()
    assert len(environ_test)



# Generated at 2022-06-23 14:34:27.601073
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Next line fails when running a module.  works in unit test
    # assert environ['PATH'] != b'/u/bin:/usr/bin'
    assert environ['PATH'] == u'/u/bin:/usr/bin'


# Generated at 2022-06-23 14:34:37.345848
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    class FakeOsEnviron(MutableMapping):
        def __init__(self, *args):
            pass

        def __getitem__(self, key):
            return b'1'

        def __setitem__(self, key, value):
            raise AssertionError('__setitem__ called')

        def __delitem__(self, key):
            raise AssertionError('__delitem__ called')

        def __iter__(self):
            return iter(('one', 'two'))

        def __len__(self):
            return 2

    test_environ = _TextEnviron(encoding='utf-8', env=FakeOsEnviron())
    assert len(test_environ) == 2



# Generated at 2022-06-23 14:34:39.772300
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert isinstance(list(environ), list)
    assert all(isinstance(item, str) for item in environ)



# Generated at 2022-06-23 14:34:43.095245
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron(encoding='utf-8')
    assert env.encoding == 'utf-8'
    env = _TextEnviron(encoding='utf-16')
    assert env.encoding == 'utf-16'


# Generated at 2022-06-23 14:34:43.700120
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    return

# Generated at 2022-06-23 14:34:45.082008
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    assert len(env) >= 1


# Generated at 2022-06-23 14:34:46.260489
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert(isinstance(environ.__iter__(), type(iter([]))))



# Generated at 2022-06-23 14:34:48.901549
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ.clear()
    value = u'💣'
    environ[u'bomb'] = value
    assert value.encode(environ.encoding) in environ, 'Should be able to assign text to environ'



# Generated at 2022-06-23 14:34:50.860115
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron(env={'A': '1', 'B': '2', 'C': '3'})
    assert len(env) == 3



# Generated at 2022-06-23 14:34:52.760370
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    _TextEnviron(env={'one': 1, 'two': 2, 'three': 3}).__iter__()


# Generated at 2022-06-23 14:34:56.183850
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = {'A': 1, 'B': 2, 'C': 3}
    env_iter = _TextEnviron(env).__iter__()
    assert set(env_iter) == set(env.keys())



# Generated at 2022-06-23 14:35:06.533617
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # test that invalid unicode characters get replaced
    os.environ[b'\xe5'] = b'\xe5'
    assert b'\ufffd' == environ[b'\xe5']

    # test that non-string variables get returned as is
    os.environ[b'1'] = 1
    assert 1 == environ[b'1']

    # test that valid unicode characters get returned as unicode
    os.environ[b'\xe5'] = b'\xc3\xa5'
    assert u'å' == environ[b'\xe5']

    # test that keys in different cases are returned the same
    os.environ[b'test'] = b'test'
    assert u'test' == environ[b'test']

# Generated at 2022-06-23 14:35:09.020544
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron()
    if PY3:
        assert environ['PATH'] == os.environ['PATH']
    else:
        assert environ['PATH'] == to_text(os.environ['PATH'])



# Generated at 2022-06-23 14:35:16.415276
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Unit test for method __len__ of class _TextEnviron

    Notes
    -----
    We currently can't test this in the integration tests because we can't create a new
    _TextEnviron object there.
    """
    os.environ = _TextEnviron({'a': 'b', 'c': 'd'})
    import ansible.module_utils.environ
    assert 2 == len(ansible.module_utils.environ.environ)

# Generated at 2022-06-23 14:35:26.880397
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron(env={b'ANSIBLE_FOO': b'Test Value'}, encoding='utf-8')
    assert env[b'ANSIBLE_FOO'] == u'Test Value'
    assert env[u'ANSIBLE_FOO'] == u'Test Value'
    assert env['ANSIBLE_FOO'] == u'Test Value'
    env['ANSIBLE_BAR'] = 'Another Value'
    assert env['ANSIBLE_BAR'] == u'Another Value'
    assert env.get('ANSIBLE_BAR') == u'Another Value'
    assert env.get('ANSIBLE_BAR', 'Default Value') == u'Another Value'
    assert env.get('ANSIBLE_BAZ', 'Default Value') == u'Default Value'

# Generated at 2022-06-23 14:35:37.648362
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # pylint: disable=missing-docstring
    # Constructor with defaults
    env = _TextEnviron()
    assert isinstance(env, MutableMapping)
    assert env._raw_environ is os.environ
    assert env._value_cache == {}
    assert env.encoding == sys.getfilesystemencoding()

    # Constructor with alternate list

# Generated at 2022-06-23 14:35:45.656384
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test for the case when unicode is in the env var
    try:
        os.environ[u'test_var'] = u'日本語'
        assert environ['test_var'] == u'日本語'
    finally:
        del os.environ['test_var']

    # Test for the case when byte string is in the env var
    try:
        os.environ['test_var'] = u'日本語'.encode('utf-8')
        assert environ['test_var'] == u'日本語'
    finally:
        del os.environ['test_var']

    # Test for the case when byte string is in the env var but it is not utf-8 encoded

# Generated at 2022-06-23 14:35:48.558523
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os.environ['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'
    for k in environ:
        assert k == 'ANSIBLE_TEST_KEY'
        return
    assert False, 'iteration should have happened'


# Generated at 2022-06-23 14:35:57.301465
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    t = _TextEnviron()
    assert t == environ
    assert t['PATH'] == environ['PATH']
    assert t['PATH'] == os.environ['PATH']
    assert t.encoding == 'utf-8'

    t = _TextEnviron(encoding='ascii')
    assert t == environ
    assert t['PATH'] == environ['PATH']
    assert t['PATH'] == os.environ['PATH']
    assert t.encoding == 'ascii'

    t = _TextEnviron(env={b'PATH': b'/bin:/usr/bin', b'LANG': b'en_US.UTF-8'})
    assert t.encoding == 'utf-8'
    assert t['PATH'] == '/bin:/usr/bin'

# Generated at 2022-06-23 14:36:08.602989
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    class TestEnviron(MutableMapping):
        def __getitem__(self, key):
            dict = {'ANSIBLE_PYTHON_INTERPRETER': '/bin/python',
                    'ANSIBLE_TRANSPORT': 'ssh'}
            return dict[key]

        def __setitem__(self, key, value):
            dict = {'ANSIBLE_PYTHON_INTERPRETER': '/bin/python',
                    'ANSIBLE_TRANSPORT': 'ssh'}
            dict[key] = value

        def __delitem__(self, key):
            dict = {'ANSIBLE_PYTHON_INTERPRETER': '/bin/python',
                    'ANSIBLE_TRANSPORT': 'ssh'}
            del dict[key]


# Generated at 2022-06-23 14:36:12.413193
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ["TEST"] = "TEST"
    assert len(environ) == len(os.environ) + 1
    del environ["TEST"]
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:36:17.397576
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ['A'] = 'a'
    environ['B'] = 'b'
    assert 'A' in environ
    assert 'B' in environ
    assert 'foo' not in environ
    assert list(environ) == [b'A', b'B']
    assert [key for key in environ] == list(environ)


# Generated at 2022-06-23 14:36:19.094436
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ.clear()
    environ["myvar"] = "myvalue"
    print(environ)
    assert environ["myvar"].encode("utf-8") == os.environ["myvar"]

# Generated at 2022-06-23 14:36:20.945076
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ._raw_environ["test_key"] = "test_val"
    assert len(_TextEnviron(environ)) == 1



# Generated at 2022-06-23 14:36:27.486580
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    uenviron = _TextEnviron({b'foo': b'bar'})
    assert uenviron._raw_environ == {b'foo': b'bar'}
    assert uenviron.encoding == 'utf-8'
    assert uenviron == {b'foo': u'bar'}
    assert uenviron[b'foo'] == u'bar'
    assert list(uenviron.keys()) == [b'foo']
    assert list(uenviron.values()) == [u'bar']

    uenviron = _TextEnviron(encoding='ascii')
    assert uenviron._raw_environ == {b'foo': b'bar'}
    assert uenviron.encoding == 'ascii'
    assert uenviron == {b'foo': u'bar'}
    assert u

# Generated at 2022-06-23 14:36:33.473275
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import os
    import os.path

    _environ = os.environ
    os.environ = _TextEnviron(encoding='utf-8')
    os.environ['TEST_KEY'] = 'TEST_VALUE'
    del os.environ['TEST_KEY']
    assert not os.path.exists('TEST_KEY')
    os.environ = _environ


# Generated at 2022-06-23 14:36:34.798464
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    value = len(_TextEnviron())
    assert value > 1


# Generated at 2022-06-23 14:36:38.608280
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    #Create an instance of TextEnviron
    env = _TextEnviron(env={'a': 'b'}, encoding='utf-8')
    env__delitem('a')
    assert env == {}

# Generated at 2022-06-23 14:36:44.352271
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({'name': 'value', 'key': 'abc123', 'counter': '0'})
    # Try to get an existing key
    assert env['name'] == 'value'
    # Try to get a key that doesn't exist
    try:
        env['missing']
    except KeyError:
        pass
    else:
        assert False, 'should have raised KeyError'


# Generated at 2022-06-23 14:36:52.686013
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_key="test"
    test_value="test_value"

    try:
        #Test with non-ascii strings
        test_value = unicode(test_value.decode('utf8'))
        environ[test_key] = test_value
        assert(environ[test_key] == test_value)
    except Exception as e:
        raise Exception('Exception in test method test__TextEnviron___getitem__ of class module.utils.common.os_path: ' + str(e)+ ". test value is " + str(test_value))

# Generated at 2022-06-23 14:36:56.258082
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron()
    env['a'] = 'bc'
    del env['a']
    assert 'a' not in env
    

# Generated at 2022-06-23 14:37:06.750059
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import copy
    # can only test if we have write access
    if not os.access(os.environ['HOME'], os.W_OK | os.X_OK):
        return

    tempfile = os.path.join(os.environ['HOME'], '__ansibletest_' + __file__)
    if os.path.exists(tempfile):
        os.remove(tempfile)

    # test with key that exists
    open(tempfile, 'w').close()
    environ['HOME'] = os.environ['HOME']
    environ['ANSIBLE_TEST_FILE'] = tempfile
    del environ['ANSIBLE_TEST_FILE']
    assert tempfile not in environ
    assert os.path.exists(tempfile)
    os.remove(tempfile)

    # with

# Generated at 2022-06-23 14:37:11.456264
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({b'a': b'1', b'b': b'2', b'c': b'3'}, encoding='utf-8')

    keys = set()
    for key in env:
        keys.add(key)
    assert keys == set(['a', 'b', 'c'])

# Generated at 2022-06-23 14:37:16.375061
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Test the size of environ when no environment variables are set
    assert len(environ) == 0

    # Test the size of environ when one environment variable is set
    os.environ["TA2"] = "55"
    assert len(environ) == 1

    # Test the size of environ when multiple environment variables are set
    os.environ["TA3"] = "7.5"
    assert len(environ) == 2



# Generated at 2022-06-23 14:37:27.638266
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    class _RawEnviron:
        def __init__(self, valuemap):
            self.valuemap = valuemap

        def __getitem__(self, key):
            return self.valuemap[key]

        def __setitem__(self, key, value):
            self.valuemap[key] = value

        def __delitem__(self, key):
            del self.valuemap[key]

        def __contains__(self, key):
            return key in self.valuemap

        def __iter__(self):
            return iter(self.valuemap)

        def __len__(self):
            return len(self.valuemap)

    # Verify the _RawEnviron class is a valid dict

# Generated at 2022-06-23 14:37:33.550377
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test that __setitem__ works in the normal case
    test_env = _TextEnviron()
    test_env['test'] = 'test'
    assert isinstance(test_env['test'], str)
    # Make sure that non-strings are converted properly
    test_env['test2'] = 123
    assert isinstance(test_env['test2'], str)
    assert test_env['test2'] == '123'



# Generated at 2022-06-23 14:37:40.698998
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Unit test for method __delitem__ of class ansible.module_utils._text.environ._TextEnviron.

    This method deletes the given key from the environment.

    :return: ``True``
    """
    d = {'test': 'value'}
    e = _TextEnviron(env=d)
    assert len(e) == 1
    assert e['test'] == 'value'
    del e['test']
    assert len(e) == 0
    assert 'test' not in e
    return True


# Generated at 2022-06-23 14:37:51.424300
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """
    Test the iterator for _TextEnviron

    When iterating over _TextEnviron, we need to get a byte string from os.environ and then
    convert to text using the encoding we've been given.
    """
    # We can't start with an empty environment because we'll lose all of the built-in environment
    # variables.  However, we can delete them one-at-a-time
    env = _TextEnviron(encoding='utf-8')
    env.clear()
    assert env._raw_environ == os.environ
    assert env._value_cache == {}
    for key in environ:
        del env[key]
    assert env._raw_environ == {}
    assert env._value_cache == {}

    # Add the variables back again so we can test that __iter__() returns the environment variables
   