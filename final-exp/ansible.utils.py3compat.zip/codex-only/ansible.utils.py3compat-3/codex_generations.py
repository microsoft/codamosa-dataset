

# Generated at 2022-06-23 14:27:52.609805
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Given
    os.environ["TEST_KEY_1"] = "TEST_VALUE_1"
    os.environ["TEST_KEY_2"] = "TEST_VALUE_2"
    os.environ["TEST_KEY_3"] = "TEST_VALUE_3"

    # When
    expected_env_keys = ["TEST_KEY_1", "TEST_KEY_2", "TEST_KEY_3"]
    actual_env_keys = [key for key in environ]

    # Then
    assert expected_env_keys == actual_env_keys



# Generated at 2022-06-23 14:28:01.282544
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes, to_text

    env = _TextEnviron(encoding='utf-8')
    env['test'] = '\u05d0'
    assert env['test'] == u'\u05d0'

    env = _TextEnviron(encoding='ascii')
    env['test'] = '\u05d0'
    assert env['test'] == u'?\u05d0'

    env = _TextEnviron(encoding='utf-8')
    env['test'] = '\u05d0'
    assert env['test'] == u'\u05d0'
    env['test'] = '\u05d0\ufffd'
    assert env['test'] == u'\u05d0\ufffd'

    env = _TextEn

# Generated at 2022-06-23 14:28:11.060368
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Random test data to test the string conversion code
    environ['ascii'] = 'a string'
    environ['utf8'] = u'\u03b1\u03b2\u03b3'
    environ['latin1'] = u'\xfc'
    environ['badutf8'] = '\xc3\x28'

    assert environ['ascii'] == u'a string'
    assert environ['utf8'] == u'\u03b1\u03b2\u03b3'
    assert environ['latin1'] == u'\xfc'
    assert environ['badutf8'] == u'\ufffd('


# Generated at 2022-06-23 14:28:18.314085
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Mock the environment
    _orig_os_environ = os.environ
    os.environ = {}
    e = _TextEnviron(env=os.environ)

    # Set the key and value
    key = u'ansible_test_key'
    value = u'ansible_test_value'
    e[key] = value

    # Verify that the key and value are returned
    assert key in e
    assert e[key] == value

    # Restore the saved environment
    os.environ = _orig_os_environ

# Generated at 2022-06-23 14:28:29.418361
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six.moves import UserDict

    # Test _TextEnviron._raw_environ is an iterable
    assert hasattr(environ._raw_environ, '__iter__')

    # Test _TextEnviron._raw_environ.__iter__() returns an iterable
    assert hasattr(environ._raw_environ.__iter__(), "__iter__")
    assert hasattr(environ._raw_environ.__iter__(), "__next__")

    # Test _TextEnviron.__iter__() method returns an iterable
    assert hasattr(environ.__iter__(), "__iter__")
    assert hasattr(environ.__iter__(), "__next__")

    # Test _TextEnviron._

# Generated at 2022-06-23 14:28:40.208407
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ["simple_key_1"] = "simple_value_1"
    os.environ["simple_key_2"] = "simple_value_2"

    os.environ["unicode_escape_key_1"] = "\\u0411\\u0435\\u0441\\u0442\\u0430\\u043d\\u043d\\u0430\\u044f"
    os.environ["unicode_escape_key_2"] = "\\u0411\\u0435\\u0441\\u0442\\u0430\\u043d\\u043d\\u0430\\u044f"

    os.environ["unicode_raw_key_1"] = u"Бестанная"
    os.environ["unicode_raw_key_2"] = u

# Generated at 2022-06-23 14:28:43.640394
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PATH'] == to_text(os.environ['PATH'], encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict')


# Generated at 2022-06-23 14:28:46.252395
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['foo'] = 'bar'
    assert isinstance(environ._raw_environ['foo'], bytes)


# Generated at 2022-06-23 14:28:57.129935
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    string_a = 'A'
    string_b = 'B'
    string_c = 'C'
    environ[string_a] = string_a
    environ[string_b] = string_b
    environ[string_c] = string_c
    del environ[string_a]
    del environ[string_b]
    del environ[string_c]
    for key in ['A', 'B', 'C']:
        if key in os.environ:
            raise Exception("method __delitem__ of class _TextEnviron is NOT working as intended")
    if string_a in environ:
        raise Exception("method __delitem__ of class _TextEnviron is NOT working as intended")

# Generated at 2022-06-23 14:29:01.753732
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(os.environ, encoding='utf-8')
    assert environ['PYTHONPATH'] == to_text(os.environ['PYTHONPATH'], encoding='utf-8',
                                            nonstring='passthru', errors='surrogate_or_strict')


# Generated at 2022-06-23 14:29:07.189428
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['key1'] = 'value1'
    assert(environ['key1'] == 'value1')
    # Verify that setting an item will change the key to bytes
    assert(type(environ._raw_environ['key1']) == bytes)
    # Verify that setting an item will change the key to unicode
    if PY3:
        assert(type(environ['key1']) == str)
    else:
        assert(type(environ['key1']) == unicode)

# Generated at 2022-06-23 14:29:10.564796
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Run unit test for class _TextEnviron
    """
    # Make sure that the constructor of _TextEnviron works
    # without crashing.
    _TextEnviron()

# Generated at 2022-06-23 14:29:18.277777
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Delete a key that exists in the current environment
    env = environ

    try:
        del env['PATH']
    except KeyError:
        pass
    else:
        assert False, 'deleting a key that exists should raise a KeyError'

    # Delete a key that doesn't exist in the current environment
    try:
        del env['CLOUDSDK_CORE_PROJECT']
    except KeyError:
        assert False, 'deleting a key that doesn\'t exist should raise a KeyError'



# Generated at 2022-06-23 14:29:20.511801
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({b'a': 1, 'b': 2})
    for key in env:
        assert 'a' == key or 'b' == key

# Generated at 2022-06-23 14:29:23.541252
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    my_env = {'one': '1', 'two': '2'}
    text_env = _TextEnviron(env=my_env)
    del text_env['two']
    assert text_env['one'] == '1'
    assert len(text_env) == 1


# Generated at 2022-06-23 14:29:34.487466
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Define an environment variable with a b'bytes' value
    os.environ[b'ANSIBLE_TEST'] = b'\xc3\xbc'
    # Retrieve the environment variable
    value = environ[b'ANSIBLE_TEST']
    # Check that a text value is what we got back
    assert(value == u'\xfc')
    # Check that the unicode character is u'\xfc' and not u'\ufffd'
    assert(value == u'\xfc')
    # Delete the environment variable
    del os.environ[b'ANSIBLE_TEST']
    # Check that the environment variable no longer exists
    assert(b'ANSIBLE_TEST' not in environ)


# Generated at 2022-06-23 14:29:36.597934
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron(env=dict(D1='T1'), encoding='utf-8')
    assert env['D1'] == 'T1'

# Generated at 2022-06-23 14:29:39.120655
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    _environ_ = _TextEnviron()
    for key in _environ_:
        assert type(key) == str
        assert type(_environ_[key]) == str


# Generated at 2022-06-23 14:29:42.458061
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ.clear()
    environ['foo'] = 'bar'
    assert 'foo' in environ
    del environ['foo']
    assert 'foo' not in environ


# Generated at 2022-06-23 14:29:52.984050
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.common.dicts
    import base64
    import json
    import sys

    if sys.version_info >= (3, 0):
        ansible.module_utils.common.dicts.environ = dict()
    else:
        ansible.module_utils.common.dicts.environ = _TextEnviron()

    VALUE_UNICODE = u"¡Hola, amigo!"
    VALUE_BYTES = value_unicode.encode('utf-8')

    MODULE_ARGS_DICT = dict(
        name='my_unicode_var',
        value=VALUE_UNICODE
    )


# Generated at 2022-06-23 14:30:00.260558
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Construct a TextEnviron with a unicode string
    raw_env = {b'foo': b'\xE2\x98\x83'}
    env = _TextEnviron(raw_env, encoding='utf-8')
    assert env[b'foo'] == u'\u2603'
    assert env['foo'] == u'\u2603'
    with pytest.raises(TypeError):
        # Can't use the older-style non-bytes string
        env['foo'] == u'☃'

    # Construct a TextEnviron with an ascii string
    raw_env = {'foo': 'bar'}
    env = _TextEnviron(raw_env, encoding='ascii')
    assert env[b'foo'] == u'bar'
    assert env['foo'] == 'bar'



# Generated at 2022-06-23 14:30:05.597261
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    env['unicode_key'] = u'unicode_value'
    env['bytestr_key'] = 'bytestr_value'
    env['bytes_key'] = b'bytes_key'
    assert env['unicode_key'] == u'unicode_value'
    assert env['bytestr_key'] == u'bytestr_value'
    assert env['bytes_key'] == u'bytes_key'



# Generated at 2022-06-23 14:30:16.474769
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test when we don't pass in an env
    assert isinstance(environ, MutableMapping)
    # Make sure that we can interact with environ
    assert 'SHELL' in environ
    assert environ['SHELL'] != 'foo'
    environ['SHELL'] = 'foo'
    assert environ['SHELL'] == 'foo'

    # Test when we pass in an env
    env = os.environ.copy()
    my_environ = _TextEnviron(env=env)
    assert isinstance(my_environ, MutableMapping)
    # Make sure that we can interact with my_environ
    assert 'SHELL' in my_environ
    assert my_environ['SHELL'] == 'foo'
    my_environ['SHELL'] = 'bar'
    assert my_en

# Generated at 2022-06-23 14:30:26.588180
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    global environ
    import io
    import sys
    import unittest

    class Test__TextEnviron___getitem__(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            global environ
            cls._stdout = sys.stdout
            cls._stderr = sys.stderr
            sys.stdout = io.StringIO()
            sys.stderr = io.StringIO()

        @classmethod
        def tearDownClass(cls):
            global environ
            sys.stdout = cls._stdout
            sys.stderr = cls._stderr

        def test__ascii(self):
            """
            Test __getitem__ with ASCII bytes and text in the environment
            """
            # Use the special ANSIBALLZ_

# Generated at 2022-06-23 14:30:36.856380
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ._raw_environ = {
        'str': b'hello world',
        'unicode': 'hi \u00FC world'.encode('utf8')
    }

    assert b'hello world' == environ['str']
    assert 'hello world' == environ['str']

    assert b'hi \xc3\xbc world' == environ['unicode']
    assert 'hi \u00fc world' == environ['unicode']

    # Test caching
    environ._value_cache[b'hello world'] = 'changed'
    assert 'changed' == environ['str']

    del environ._value_cache[b'hello world']
    environ._value_cache[b'hi \xc3\xbc world'] = '\u00dc'

# Generated at 2022-06-23 14:30:40.621194
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    raw_environ = {b'foo': b'bar', b'baz': b'qux'}
    text_environ = _TextEnviron(env=raw_environ)



# Generated at 2022-06-23 14:30:47.736586
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Sequence
    environ_backup = environ._raw_environ.copy()
    raw_environ = {to_bytes('HELLO'): to_bytes('WORLD'),
                   to_bytes('ANSIBLE_MODULE_ARGS'): {to_bytes('ANSIBLE_MODULE_ARGS'): to_bytes('ANSIBLE_MODULE_ARGS')}}
    environ._raw_environ = raw_environ

    assert isinstance(environ._raw_environ, dict)
    assert isinstance(environ, MutableMapping)
    assert isinstance(environ, Sequence)
    assert isinstance(environ.__iter__(), Sequence)

# Generated at 2022-06-23 14:30:48.541378
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)

# Generated at 2022-06-23 14:30:51.304758
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron(env={'US-ASCII': b'ascii', 'UTF-8': b'\xc3\xbc'})
    assert environ['US-ASCII'] == 'ascii'
    assert environ['UTF-8'] == u'\xfc'


# Generated at 2022-06-23 14:30:57.776818
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # type: () -> None
    import os
    import mock

    # set up our class
    raw_environ = os.environ.copy()
    test_environ = _TextEnviron(env=raw_environ)

    # Unit test for method __getitem__ of class _TextEnviron
    # Test that __getitem__ returns the value of 'key'
    @mock.patch.object(_TextEnviron, '_raw_environ', raw_environ)
    def test_returns_value(key):
        # type: (str) -> None
        assert test_environ[key] == os.environ[key]
    # test different keys
    test_returns_value('PATH')
    test_returns_value('PWD')
    test_returns_value('SHLVL')
    test

# Generated at 2022-06-23 14:31:06.880636
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import os

    class TestEnviron(object):
        def __init__(self, value_cache):
            self._value_cache = value_cache

        def __getitem__(self, key):
            try:
                return self._value_cache[key]
            except KeyError:
                raise KeyError('The environment variable {} is not set'.format(key))

        def __setitem__(self, key, value):
            self._value_cache[key] = value

        def __delitem__(self, key):
            self._value_cache[key] = None

    # Test that the encoding gets passed down to the to_text call
    te = _TextEnviron(env=TestEnviron({}), encoding='latin-1')
    te['test1'] = '\U0001F631'

# Generated at 2022-06-23 14:31:12.066918
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    test__TextEnviron___delitem__(value)

    Test that deleting environment variables works
    """
    # Arrange
    # Act
    environ['foo'] = 'bar'
    assert environ['foo'] == 'bar'
    # Assert
    del environ['foo']
    assert 'foo' not in environ

test__TextEnviron___delitem__()


# Generated at 2022-06-23 14:31:13.994469
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    e = _TextEnviron()
    assert len(e) == len(os.environ)


# Generated at 2022-06-23 14:31:16.279711
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert isinstance(environ.__iter__(), type(iter([])))



# Generated at 2022-06-23 14:31:17.289979
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    del environ['path']


# Generated at 2022-06-23 14:31:20.568481
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert isinstance(environ.__iter__(), type(environ._raw_environ.__iter__()))
    assert list(environ.__iter__()) == list(environ._raw_environ.__iter__())


# Generated at 2022-06-23 14:31:31.284745
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """__getitem__() should return text strings from the environment instead of byte strings."""

    print("Running test__TextEnviron___getitem__ ...")

    if PY3:
        # Ensure that the test runs under Python3 is has the same behaviour as the actual
        # os.environ
        if environ['LANG'] != 'en_US.UTF-8':
            raise AssertionError('Failed test__TextEnviron___getitem__: expected default value of $LANG to be "en_US.UTF-8"; got {0}'.format(environ['LANG']))

# Generated at 2022-06-23 14:31:40.233724
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import os
    import sys
    import unittest

    class __TextEnviron_TestCase(unittest.TestCase):

        def setUp(self):
            self.environ = _TextEnviron(encoding='utf-8')

        def test___delitem__(self):
            self.environ['SHOULD_NOT_BE_SET'] = 'test'
            del self.environ['SHOULD_NOT_BE_SET']
            with self.assertRaises(KeyError) as cm:
                _ = self.environ['SHOULD_NOT_BE_SET']
            self.assertEqual(cm.exception.args[0], 'SHOULD_NOT_BE_SET')

    unittest.main()


# Generated at 2022-06-23 14:31:45.406078
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # input_output = (input, output)
    test_cases = [
        ('TEST', None),
        ('TEST', None),
    ]
    for in_out in test_cases:
        environ.__delitem__(in_out[0])
        assert in_out[1] == environ.__getitem__(in_out[0])



# Generated at 2022-06-23 14:31:51.553270
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Add a variable
    os.environ["TEST_VARIABLE_1"] = "TEST_VALUE_1"
    # Check that the variable can be retrieved
    assert environ["TEST_VARIABLE_1"] == "TEST_VALUE_1"
    # Remove the variable
    del os.environ["TEST_VARIABLE_1"]


# Generated at 2022-06-23 14:31:52.973729
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert(len(_TextEnviron()) >= 5)



# Generated at 2022-06-23 14:31:55.179433
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ['ANSIBLE_TEST_LENGTH'] = '1'
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:32:01.508644
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Test that _TextEnviron.__setitem__() works as expected
    """
    old_env_value = environ.pop('SHELL', None)


# Generated at 2022-06-23 14:32:12.393822
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # First, make sure we're testing with bytes input
    if PY3:
        old_env = environ._raw_environ
        environ._raw_environ = {to_bytes('UNITTEST_KEY', encoding='utf-8'): to_bytes('UNITTEST_VALUE', encoding='utf-8')}

    # Test simple del
    del environ['UNITTEST_KEY']
    assert 'UNITTEST_KEY' not in environ

    if PY3:
        environ._raw_environ = old_env


# Generated at 2022-06-23 14:32:16.558532
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Unit test for method __setitem__ of class _TextEnviron
    """
    if not PY3:
        obj = _TextEnviron()
        obj['foo'] = 'bar'
        assert obj._raw_environ['foo'] == b'bar'
        assert obj['foo'] == u'bar'



# Generated at 2022-06-23 14:32:27.556951
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import os
    import sys
    import six
    import stat
    import tempfile
    import unittest

    if six.PY2:
        from ansible.module_utils.six.moves.urllib.parse import unquote  # noqa: F811

    TEST_PATH = u' /tmp/Test \u2713'
    TEST_PATH_BYTES = b'/tmp/Test \xe2\x9c\x93'

    class TestPath(unittest.TestCase):
        # This class is simply to provide a unittest with a nice failure message
        def test_path(self):
            self.assertEqual(TEST_PATH, environ[to_text(TEST_PATH_BYTES)])


# Generated at 2022-06-23 14:32:29.870819
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert 2 == len(environ['PATH'])
    assert 1 == len(environ['LANG'])


# Generated at 2022-06-23 14:32:35.138681
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Unit test for method __delitem__ of class _TextEnviron

    environ._raw_environ.clear()
    environ.setdefault('test_key', 'test_value')
    assert environ.get('test_key') == 'test_value'
    del environ['test_key']
    assert not environ.get('test_key')



# Generated at 2022-06-23 14:32:45.552665
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    del environ['LANG']

    # Check that it encodes non-ASCII values correctly (as non-ASCII)
    environ['LANG'] = 'en_US.utf8'
    assert environ['LANG'] == u'en_US.utf8'
    if PY3:
        # py2 encodes byte string values to unicode
        to_bytes = lambda a: a.encode('utf-8')
    else:
        # py3 does not encode byte string values
        to_bytes = lambda a: a

    # Ensure caching works for a key-value pair that is not encoded
    os.environ[to_bytes('LANG')] = to_bytes('en_US.utf8')
    assert environ['LANG'] is environ['LANG']

    # Ensure that changing the value in the environment causes

# Generated at 2022-06-23 14:32:51.852937
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    test_env = {
        'key1': b'\xc3\xb6',  # \xc3\xb6 is 'ö' in utf-8
    }

    expected_result = {
        'key1': u'\xf6',  # \xf6 is 'ö' in Latin-1
    }

    te = _TextEnviron(test_env, encoding='Latin-1')

    assert expected_result == dict(te.items())

# Generated at 2022-06-23 14:33:00.324650
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron(encoding='utf-8')
    # Test setting a normal text value
    env['TEST1'] = 'フォーク'
    assert env._raw_environ['TEST1'] == to_bytes('フォーク', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    # Test setting a text with an invalid character in it
    env['TEST2'] = '\x93'
    assert env._raw_environ['TEST2'] == to_bytes('\x93', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    # Test setting a non-string value
    env['TEST3'] = 123

# Generated at 2022-06-23 14:33:08.121318
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Test that when deleting a text item, it is removed from the os.environ
    environ["mytest"] = "test"
    del environ["mytest"]
    assert not os.environ.get("mytest")
    assert environ == {}
    # Test that when deleting a binary string, the text equivalent is removed from os.environ
    environ["mytest"] = "test"
    del environ[to_bytes("mytest", encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')]
    assert not os.environ.get("mytest")
    assert environ == {}


# Generated at 2022-06-23 14:33:11.180406
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    foo_value = 'bar'
    os.environ['FOO'] = foo_value
    assert environ['FOO'] == foo_value

    del environ['FOO']
    assert 'FOO' not in os.environ


# Generated at 2022-06-23 14:33:12.436718
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:33:14.848138
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    env['breakfast'] = '🍩'
    assert env['breakfast'] == '🍩'

# Generated at 2022-06-23 14:33:22.873582
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    try:
        import unittest
    except ImportError:
        # Python 2.6 doesn't have unittest, so use the bundled backport
        # Note: don't move this to the top of the file: it pulls in too many
        # Python 3 dependencies
        from ansible.module_utils.six.moves import unittest

    class _TextEnviron___iter__TestCase(unittest.TestCase):
        def test___iter__(self):
            results = set()
            for k in environ:
                results.add(k)
            self.assertEqual(results, set(environ.keys()))

    tests = unittest.TestLoader().loadTestsFromTestCase(_TextEnviron___iter__TestCase)

    unittest.TextTestRunner(verbosity=2).run(tests)


#

# Generated at 2022-06-23 14:33:34.120576
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron(encoding='utf-8')

    # This is a valid utf-8 string
    environ['VALUE'] = u'1234567890\u20ac'

    assert os.environ['VALUE'] == '1234567890\xe2\x82\xac'

    # Can't set a unicode string with invalid utf-8 in it
    try:
        environ['VALUE'] = u'1234567890\xc3\u20ac'
    except UnicodeEncodeError:
        assert True
    else:
        assert False

    # Can set a byte string with invalid utf-8 in it
    environ['VALUE'] = '1234567890\xc3\u20ac'


# Generated at 2022-06-23 14:33:40.948888
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test non-string type
    try:
        _TextEnviron({'foo': b'12345'})['foo']
        assert False, "Did not raise error on non-string value"
    except TypeError:
        pass

    # Test non-utf8 encoding
    try:
        render_data = {'encoding': 'big5'}
        raw_data = {'foo': b'\xa4@'}
        _TextEnviron(raw_data, **render_data)['foo']
        assert False, "Did not raise error on non-utf8 value"
    except UnicodeDecodeError:
        pass

    # Test invalid utf-8

# Generated at 2022-06-23 14:33:46.088802
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os.environ = {"HELLO": "WORLD", "FOO": "BAR"}
    assert set(environ.__iter__()) == {"HELLO", "FOO"}
    assert isinstance(environ.__iter__(),type(os.environ.__iter__()))

test__TextEnviron___iter__()


# Generated at 2022-06-23 14:33:50.583905
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['foo'] = 'bar'
    assert environ['foo'] == 'bar'
    del environ['foo']
    try:
        environ['foo']
    except Exception as err:
        assert err.args == ('foo',)
# test__TextEnviron___delitem__()


# Generated at 2022-06-23 14:34:00.893288
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import os
    from ansible.module_utils._text import to_bytes

    def check_delete_no_value_cache():
        LABEL = 'DEL_NO_VALUE_CACHE: '
        os.environ[LABEL] = LABEL
        assert env[LABEL] == LABEL
        del env[LABEL]
        assert LABEL not in env

    def check_delete_with_value_cache():
        LABEL = 'DEL_WITH_VALUE_CACHE: '
        os.environ[LABEL] = LABEL
        assert env[LABEL] == LABEL
        assert LABEL in env._value_cache
        del env[LABEL]
        assert LABEL not in env
        assert LABEL not in env._value_cache

    # os.

# Generated at 2022-06-23 14:34:03.837593
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ['TEST_ONE'] = 'ONE'
    os.environ['TEST_TWO'] = 'TWO'
    assert len(environ) == 2



# Generated at 2022-06-23 14:34:14.557868
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    test_environ = _TextEnviron({'a': 'b'})
    assert len(test_environ) == 1
    os.environ['a'] = 'b'
    test_environ = _TextEnviron()
    assert len(test_environ) == 1
    del os.environ['a']
    # Test some bad inputs
    try:
        test = _TextEnviron(123)
        assert False
    except TypeError:
        assert True
    try:
        test = _TextEnviron(['a'])
        assert False
    except TypeError:
        assert True
    try:
        test = _TextEnviron('abc')
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-23 14:34:15.547828
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, MutableMapping)

# Generated at 2022-06-23 14:34:23.229614
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print("Testing _TextEnviron.__getitem__:")
    print("  Sanity check: ")
    if 'PATH' in environ:
        print("    environ[PATH] should be in environ")
    else:
        print("    ERROR: environ[PATH] should be in environ")
        sys.exit(1)
    if 'ANSIBLE_MODULE_UTILS' in environ:
        print("    environ[ANSIBLE_MODULE_UTILS] should be in environ")
    else:
        print("    ERROR: environ[ANSIBLE_MODULE_UTILS] should be in environ")
        sys.exit(1)

    print("Testing __getitem__:")

# Generated at 2022-06-23 14:34:29.359936
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import unittest
    import unittest.mock
    env_test = _TextEnviron()

    class TestEnviron(dict):
        def __iter__(self):
            return iter(('foo', 'bar', 'baz'))

    with unittest.mock.patch.dict(env_test._raw_environ, {}, clear=True):
        env_test._raw_environ = {'foo': 'Foo', 'bar': 'Bar', 'baz': 'Baz'}
        assert env_test.__iter__() == env_test._raw_environ.__iter__()

    with unittest.mock.patch.dict(env_test._raw_environ, {}, clear=True):
        env_test._raw_environ = TestEnviron()
        assert env_test.__

# Generated at 2022-06-23 14:34:36.989052
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Mock os.environ dict
    os.environ = {
        b'a': b'1',
        b'b': b'2',
        b'c': b'3'
    }
    # Generate the object
    env = _TextEnviron(os.environ)
    # Test if the method returns a generator object
    assert env.__iter__() == iter(os.environ.keys())
    # Test if the generator returns bytes
    for item in env.__iter__():
        # On Python 3, the items should still be bytes
        if PY3:
            assert type(item) is bytes
        # On Python 2, the items should be unicode if the environment dict holds bytes
        if not PY3:
            assert type(item) is unicode



# Generated at 2022-06-23 14:34:45.163257
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # retrieve current environment setting for environment variable LANG
    lang_value = environ['LANG']

    # change the environment variable LANG to a different value than the one in the environment
    environ['LANG'] = 'fr'

    # lookup the environment variable LANG again and verify that it has been updated to what we set
    if environ['LANG'] == 'fr':
        print("PASS: test__TextEnviron___setitem__")
    else:
        print("FAIL: test__TextEnviron___setitem__")

    # reset the environment variable LANG to the prior setting
    environ['LANG'] = lang_value


# Generated at 2022-06-23 14:34:51.081413
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """Unit test for method __delitem__ of class _TextEnviron"""
    foo = {}
    foo['bar'] = 'bar'
    bar = to_bytes(foo['bar'])
    mode_utils = _TextEnviron(foo, 'utf-8')
    assert isinstance(mode_utils['bar'], unicode) == True
    # Now test that deleting and item works
    del mode_utils['bar']
    try:
        mode_utils['bar']
    except KeyError:
        pass
    else:
        assert False, "Key 'bar' of mode_utils['env'] wasn't deleted"



# Generated at 2022-06-23 14:34:56.247989
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    __environ = _TextEnviron({'a': 'value-a', 'b': 'value-b'})
    assert len(environ) == 2
    del __environ['a']
    assert len(environ) == 1
    assert 'a' not in environ
    assert 'b' in environ
    del __environ['b']
    assert len(environ) == 0
    assert 'a' not in environ
    assert 'b' not in environ

test__TextEnviron___delitem__()


# Generated at 2022-06-23 14:35:06.571000
# Unit test for constructor of class _TextEnviron

# Generated at 2022-06-23 14:35:16.110848
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # clear previously set environment variable
    if 'ANSIBLE_TEST_VAR' in environ:
        del environ['ANSIBLE_TEST_VAR']
    # set new environment variable
    environ['ANSIBLE_TEST_VAR'] = 'Some value'
    # check environment variable is set
    if 'ANSIBLE_TEST_VAR' in environ:
        # delete environment variable
        del environ['ANSIBLE_TEST_VAR']
        # check environment variable is not set
        if 'ANSIBLE_TEST_VAR' not in environ:
            # test passed
            return True
    # test failed
    return False


# Generated at 2022-06-23 14:35:19.275977
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({'FOO': 'BAR'})
    del env['FOO']
    assert 'FOO' not in env


# Generated at 2022-06-23 14:35:23.393004
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_object = _TextEnviron(encoding='UTF-8')
    test_object[u'test'] = u'fooã'
    assert test_object[u'test'] == u'fooã'
    assert test_object._raw_environ[b'test'] == b'foo\xc3\xa3'

# Generated at 2022-06-23 14:35:25.300845
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({'a': 'test', 'b': 'test2'})
    assert list(env.__iter__()) == ['a', 'b']

# Generated at 2022-06-23 14:35:29.747747
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['foo'] = 'bar'
    assert(environ['foo'] == 'bar')
    del environ['foo']
    with pytest.raises(KeyError):
        environ['foo']


# Generated at 2022-06-23 14:35:33.309378
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ_iter = environ.__iter__()
    count = 0
    while True:
        try:
            environ_iter.__next__()
            count+=1
        except StopIteration:
            break
    
    assert count > 0

# Generated at 2022-06-23 14:35:37.367184
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    raw_env = {b'PATH': b'/usr/local/bin:/usr/bin:/bin:'}
    env = _TextEnviron(env=raw_env)
    assert len(env) == 1
    assert env[b'PATH'] == u'/usr/local/bin:/usr/bin:/bin:'

# Generated at 2022-06-23 14:35:41.884710
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'FOO': b'bar', u'A': u'b'})
    assert isinstance(env[b'FOO'], str)
    assert env[b'FOO'] == u'bar'
    assert isinstance(env[u'A'], str)
    assert env[u'A'] == u'b'


# Generated at 2022-06-23 14:35:49.930030
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    if PY3:
        env[to_text('foo')] = to_text('bar')
        assert env['foo'] == 'bar'
        env[to_bytes('foo', errors='surrogate_or_strict')] = to_bytes('bar', errors='surrogate_or_strict')
        assert env['foo'] == 'bar'
        env[to_text('foo')] = 'bar'
        assert env['foo'] == 'bar'
        env[to_bytes('foo', errors='surrogate_or_strict')] = 'bar'
        assert env['foo'] == 'bar'
    else:
        env[to_text('foo')] = to_text('bar')
        assert env['foo'] == 'bar'

# Generated at 2022-06-23 14:35:53.876428
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ['TEST_ENVIRON_KEY'] = 'TEST_ENVIRON_VALUE'
    text_environ = _TextEnviron()
    assert len(text_environ) == len(os.environ)
    del os.environ['TEST_ENVIRON_KEY']


# Generated at 2022-06-23 14:35:59.087288
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron()
    assert 'PATH' in env
    env['TEST'] = 'Some value'
    assert env['TEST'] == 'Some value'
    assert len(env) == len(os.environ) + 1
    del env['TEST']
    assert len(env) == len(os.environ)
    for k in env:
        assert k in os.environ

# Generated at 2022-06-23 14:36:04.439697
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron(env={b'/bin': b'/bin', b'/usr/bin': b'/usr/bin'})
    expected = u'/bin'
    result = env[u'/bin']
    assert result == expected
    expected = u'/usr/bin'
    result = env[b'/usr/bin']
    assert result == expected

# Generated at 2022-06-23 14:36:12.478013
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import StringIO, StringIO
    from ansible.module_utils.common.compat.ipaddress import ip_address
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_datetime import datetime_ex
    from ansible.module_utils.parsing.convert_json import jsonify
    from ansible.module_utils.parsing.convert_yaml import yamlify
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import iteritems

# Generated at 2022-06-23 14:36:16.077892
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Test for method __delitem__ of class _TextEnviron.
    """
    # _TextEnviron object
    obj = _TextEnviron()

    environ["TEST_DEL_ENV_VAR"] = "some_value"
    assert obj["TEST_DEL_ENV_VAR"] == "some_value"

    del obj["TEST_DEL_ENV_VAR"]
    assert environ.get("TEST_DEL_ENV_VAR") is None


# Generated at 2022-06-23 14:36:22.194850
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    utf8_env = {}
    environ.__setitem__('utf8_test', 'こにちわ')
    utf8_env['utf8_test'] = 'こにちわ'.encode('utf-8')
    assert environ._raw_environ['utf8_test'] == utf8_env['utf8_test']
    assert environ._value_cache['こにちわ'.encode('utf-8')] == 'こにちわ'



# Generated at 2022-06-23 14:36:28.246976
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    __tracebackhide__ = True
    import os
    foo_env_var = 'foo'
    foo_value = '\u00e1\u00e9\u00ed\u00f3\u00fa'
    foo_utf8_value = foo_value.encode('utf-8')
    foo_latin1_value = foo_value.encode('latin-1')
    foo_iso88591_value = foo_latin1_value

    # Test default constructor
    os.environ[foo_env_var] = foo_utf8_value
    environ = _TextEnviron()
    assert foo_value == environ[foo_env_var]
    # Verify that it is really a cached value
    del os.environ[foo_env_var]
    assert foo_value == environ

# Generated at 2022-06-23 14:36:29.680645
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:36:35.044665
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # setup input and expected output
    env = {b'abc': b'foo', b'def': u'ほげ'}
    text_env = _TextEnviron(env, encoding='utf-8')
    # verify output
    assert text_env['abc'] == 'foo'
    assert text_env[u'def'] == u'ほげ'


# Generated at 2022-06-23 14:36:45.769843
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    '''
    Test various values for key/value parameters:
    - key, value = str
    - key = str, value = unicode
    - key, value = unicode
    - key, value = int
    - key, value = None
    - key = unicode, value = str
    - key, value = str, encoding = None

    Test for calling with key = None (should raise TypeError)

    '''
    # Initialize
    os.environ.clear()
    environ._raw_environ = os.environ
    environ._value_cache.clear()

    # Test key, value = str
    os.environ['str'] = 'str'
    environ['str'] = 'str'
    assert environ['str'] == os.environ['str']

    # Test key = str, value = unic

# Generated at 2022-06-23 14:36:55.143800
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from tempfile import mkdtemp
    from shutil import rmtree
    import os

    test_path = mkdtemp()
    bytes_test_path = to_bytes(test_path, encoding='utf-8')
    for filename in ['a' + chr(0) + 'b', 'c' + chr(100) + 'd', 'e' + chr(0xff) + 'f', 'g' + chr(0x100) + 'h',
                     'i' + chr(0xffff) + 'j', 'k' + chr(0x10000) + 'l', 'm' + chr(0x10ffff) + 'n']:
        open(os.path.join(bytes_test_path, filename), 'w').close()
    # Walk through the directory and make sure that the bytest

# Generated at 2022-06-23 14:37:02.036218
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """
    environ_mock = dict(ANSIBLE_ANSIBLE_MODULE_ARGS='null',
                        PYTHONPATH='/opt/ansible/lib',
                        PATH='/bin:/usr/bin',
                        )

    text_environ = _TextEnviron(env=environ_mock)

    assert text_environ[u'ANSIBLE_ANSIBLE_MODULE_ARGS'] == u'null'
    assert text_environ[u'PYTHONPATH'] == u'/opt/ansible/lib'
    assert text_environ[u'PATH'] == u'/bin:/usr/bin'



# Generated at 2022-06-23 14:37:04.877182
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    e = _TextEnviron(env={'MY_VAR': '1', 'OTHER_VAR': '2'})
    assert len(e) == 2


# Generated at 2022-06-23 14:37:12.590713
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Create an instance of a class _TextEnviron
    environ = _TextEnviron(encoding='utf-8')
    # Use __iter__ of a class _TextEnviron
    # Create list of the key strings in the dictionary of the instance of the class _TextEnviron
    key_list = list(environ)
    # Check the type of the list
    assert isinstance(key_list, list)
    # Check the type of element in the list
    for key in key_list:
        assert isinstance(key, str)


# Generated at 2022-06-23 14:37:15.786037
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    e = _TextEnviron(env={'foo': 'bar', 'baz': 'biscuit'})
    del e['foo']
    assert e == {'baz': 'biscuit'}
    assert 'foo' not in e


# Generated at 2022-06-23 14:37:18.130897
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    original_environ = dict(os.environ)
    del os.environ['PATH']
    assert environ != original_environ
    environ.__delitem__('PATH')
    assert environ == original_environ
    os.environ = original_environ


# Generated at 2022-06-23 14:37:24.101904
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Setup
    environ_bak = environ.copy()
    key = 'delete_me'
    value = 'delete this value'
    environ[key] = value

    # Exercise
    del environ[key]

    # Verify
    assert key not in environ
    # Reset for other unit tests
    environ.update(environ_bak)



# Generated at 2022-06-23 14:37:30.560278
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class TestEnviron(object):
        def __init__(self):
            self.some_env_var = to_bytes("some value")

        def __getitem__(self, key):
            if key == 'some_env_var':
                return self.some_env_var
            else:
                raise KeyError

    te = _TextEnviron(env=TestEnviron(), encoding='utf-8')
    assert te['some_env_var'] == "some value"


# Generated at 2022-06-23 14:37:41.108192
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # If the key is in the environ it should return a str (unicode on python2)
    # If the key is not in the environ it should raise a KeyError
    # If the key is not a string it should raise a TypeError
    env = _TextEnviron({'a': '1', 'b': '2'})

    # If the key is in the environ it should return a str (unicode on python2)
    assert isinstance(env['a'], str)
    assert isinstance(env['b'], str)

    # If the key is not in the environ it should raise a KeyError
    try:
        env['c']
    except KeyError:
        pass
    else:
        assert False, "Did not raise KeyError for missing key"

    # If the key is not a string it should raise a TypeError

# Generated at 2022-06-23 14:37:48.161752
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    class MockEnviron(MutableMapping):
        def __delitem__(self, key):
            assert False

        def __getitem__(self, key):
            assert False

        def __iter__(self):
            assert False

        def __len__(self):
            assert False

        def __setitem__(self, key, value):
            assert key == 'foo'
            assert value == b'\xc3\xa9'

    env = _TextEnviron(env=MockEnviron(), encoding='utf-8')
    env['foo'] = u'é'