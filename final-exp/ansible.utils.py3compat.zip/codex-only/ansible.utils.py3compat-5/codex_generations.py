

# Generated at 2022-06-23 14:27:48.799388
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ.clear()
    environ['foo'] = 'bar'
    assert 'foo' in environ
    del environ['foo']
    assert 'foo' not in environ



# Generated at 2022-06-23 14:27:53.748312
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ.clear()
    environ['TEST_ENV'] = 'TEST_VALUE'
    assert environ['TEST_ENV'] == 'TEST_VALUE'
    del environ['TEST_ENV']
    assert not environ.has_key('TEST_ENV')


# Generated at 2022-06-23 14:28:01.805512
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Create a copy of the current environment
    # pylint: disable=unpacking-non-sequence
    environ, os.environ = os.environ, dict(os.environ)

# Generated at 2022-06-23 14:28:04.904899
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    dict_environ = _TextEnviron()
    dict_environ['MY_VAR'] = 'value 1'
    assert dict_environ['MY_VAR'] == 'value 1'

# Generated at 2022-06-23 14:28:06.147992
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) >= 1



# Generated at 2022-06-23 14:28:11.321102
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ = _TextEnviron(env={"ZERO": "ZERO", "ONE": "ONE", "TWO": "TWO"})
    assert len(environ) == 3

    del environ["ONE"]
    assert len(environ) == 2

    # delitem does NOT throw an exception if the key is missing
    del environ["ONE"]
    assert len(environ) == 2



# Generated at 2022-06-23 14:28:21.059490
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils.common._collections_compat import MutableMapping

    env = _TextEnviron()
    assert isinstance(env, MutableMapping)

    environ_keys = sorted(list(env.keys()))
    orig_env_keys = sorted(list(os.environ.keys()))
    assert environ_keys == orig_env_keys

    for key in environ_keys:
        assert env[key] == os.environ[key]

    # Non-existent key
    try:
        env['TEST_NOT_THERE']
    except KeyError:
        pass
    else:
        raise Exception('we should have thrown a KeyError')

    # Unicode key
    key = 'TEST_KEY'
    env[u'\u1234'] = 'unicode key'


# Generated at 2022-06-23 14:28:23.553557
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    tdict = _TextEnviron()
    for key, value in tdict.items():
        assert(tdict[key] == value)

# Generated at 2022-06-23 14:28:26.736101
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ.clear()
    environ.update({'a': 'b', 'c': 'd'})
    assert set(environ) == set(os.environ)



# Generated at 2022-06-23 14:28:29.483564
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron(encoding='utf-8')
    if sys.version_info[0] < 3:
        assert len(env) == len(os.environ)
    else:
        assert len(env) == len(os.environ)


# Generated at 2022-06-23 14:28:31.243545
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    env['TEST_VAR'] = 'test'
    assert env['TEST_VAR'] == 'test'

# Generated at 2022-06-23 14:28:32.388127
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:28:39.544384
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron({b'test': b'\xc3\xa9'})
    assert env.encoding == 'utf-8'
    assert env[b'test'] == u'\xe9'
    env = _TextEnviron({'test': u'\xe9'})
    assert env.encoding == 'utf-8'
    assert env[b'test'] == u'\xe9'


# Generated at 2022-06-23 14:28:42.413554
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    e = _TextEnviron()
    e['foo'] = 'bar'
    del e['foo']
    assert 'foo' not in e


# Generated at 2022-06-23 14:28:47.116537
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    try:
        _TextEnviron.__getitem__({u'a': u'b'}, 'a')
    except:
        assert False
    assert _TextEnviron.__getitem__({u'a': u'b'}, 'a') == u'b'



# Generated at 2022-06-23 14:28:54.455670
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    env['key'] = 'text'
    assert to_bytes('text', encoding='utf-8') == env._raw_environ['key']
    env['key'] = 123
    assert to_bytes('123', encoding='utf-8') == env._raw_environ['key']

    env = _TextEnviron(encoding='ascii')
    env['key'] = to_text('\u1ea9', encoding='utf-8')
    assert to_bytes('\u1ea9', encoding='ascii') == env._raw_environ['key']
    with pytest.raises(UnicodeEncodeError):
        env['key'] = to_text('\u1e9a', encoding='utf-8')

# Generated at 2022-06-23 14:29:04.646627
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import os


# Generated at 2022-06-23 14:29:07.415161
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({b'MY_VAR': b'foob\xc3\xa4r'} if PY3 else {'MY_VAR': 'foob\xc3\xa4r'})
    assert next(iter(env)) == 'MY_VAR'


# Generated at 2022-06-23 14:29:15.353032
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = {'name': 'Fred'}
    textenv = _TextEnviron(env)
    assert textenv.encoding == 'utf-8'
    assert textenv['name'] == 'Fred'
    env['name'] = b'Jane'
    assert textenv['name'] == 'Jane'
    assert env['name'] == b'Jane'
    textenv['name'] = 'Bill'
    assert env['name'] == b'Bill'
    assert textenv['name'] == 'Bill'

# Generated at 2022-06-23 14:29:23.895024
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import contextlib
    import io
    from unittest import TestCase

    os_environ_backup = os.environ

# Generated at 2022-06-23 14:29:27.066679
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ_ = _TextEnviron(env={'foo': 'bar'})
    del environ_['foo']
    assert environ_._raw_environ == {}



# Generated at 2022-06-23 14:29:36.981039
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron(encoding='utf-8')
    k1 = 'a'
    v1 = u'b'
    environ[k1] = v1
    assert k1 in environ
    assert environ[k1] == v1
    environ[k1] = str(v1)
    assert k1 in environ
    assert environ[k1] == v1
    environ[k1] = bytes(v1)
    assert k1 in environ
    assert environ[k1] == v1
    environ[k1] = bytes(str(v1), 'utf-8')
    assert k1 in environ
    assert environ[k1] == v1

# Generated at 2022-06-23 14:29:47.821669
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['TEST_VAR_PY_2'] = b'\xc3\xa9coute'
    assert environ['TEST_VAR_PY_2'] == u'\xe9coute'
    assert b'TEST_VAR_PY_2' in environ
    del environ['TEST_VAR_PY_2']
    assert b'TEST_VAR_PY_2' not in environ

    if PY3:
        environ['TEST_VAR_PY_3'] = '\xe9coute'
        assert environ['TEST_VAR_PY_3'] == u'\xe9coute'
        del environ['TEST_VAR_PY_3']

# Generated at 2022-06-23 14:29:50.783678
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    env['key'] = 'value'
    assert 'value' == env['key']


# Generated at 2022-06-23 14:29:56.825328
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    from ansible.module_utils._text import to_bytes, to_text

    environ = _TextEnviron()
    assert not environ
    environ["foo"] = "bar"
    assert environ["foo"] == "bar"

    del environ["foo"]
    assert not environ["foo"]

    if PY3:
        environ["foo"] = b"bar"
    else:
        environ["foo"] = "bar"

    assert environ["foo"] == "bar"
    del environ["foo"]
    assert not environ["foo"]


# Generated at 2022-06-23 14:29:58.538809
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ) == list(os.environ)



# Generated at 2022-06-23 14:30:07.261218
# Unit test for method __iter__ of class _TextEnviron

# Generated at 2022-06-23 14:30:17.251039
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_environ = _TextEnviron(encoding='utf-8')
    if not PY3:
        # make sure a bytestring does get converted to unicode
        test_environ['test_key1'] = b'\xe4\xbd\xa0\xe5\xa5\xbd'
        assert(isinstance(test_environ['test_key1'], str))
        assert(test_environ['test_key1'] == '你好')
    else:
        # make sure a unicode string does not get converted to bytes
        test_environ['test_key2'] = u'你好'
        assert(isinstance(test_environ['test_key2'], str))
        assert(test_environ['test_key2'] == '你好')


# Generated at 2022-06-23 14:30:24.927721
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # pylint: disable=protected-access
    # pylint: disable=no-member
    # pylint: disable=protected-access
    environ['INITIAL'] = u'this is a test'
    assert environ['INITIAL'] == u'this is a test'
    del environ['INITIAL']
    assert 'INITIAL' not in environ
    try:
        del environ['INITIAL']  # noqa: F841
        assert False
    except KeyError:
        pass
    assert 'INITIAL' not in environ



# Generated at 2022-06-23 14:30:32.969974
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_env = _TextEnviron()

    # This test is to ensure that non-string values are correctly coerced to bytes.
    values = (
        (1234, b'1234'),
        (12.34, b'12.34'),
        (b'abcd', b'abcd'),
        (u'abcd', b'abcd'),
    )
    for value, expected_value in values:
        test_env['test'] = value
        assert(test_env['test'] == expected_value)



# Generated at 2022-06-23 14:30:37.241020
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    It should set native environment value
    """
    # Initialization
    txt_environ = _TextEnviron()
    key = 'key'
    value = 'value'

    # Test
    txt_environ[key] = value
    result = txt_environ[key]

    # Assertion
    assert result == value


# Generated at 2022-06-23 14:30:46.138009
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes, to_text

    # Test encoding attribute
    env = _TextEnviron(encoding='ascii')
    assert env.encoding == 'ascii'

    # Test raw bytes
    raw_bytes = b'bytes'
    raw_bytes_utf8 = to_text(raw_bytes, encoding='ascii', nonstring='passthru', errors='surrogate_or_strict')
    assert raw_bytes_utf8 == 'bytes'
    env[b'bytes'] = raw_bytes
    assert env[b'bytes'] == 'bytes'
    assert env['bytes'] == 'bytes'

    # Test raw text
    raw_text = 'text'
    assert raw_text == 'text'
    env['text'] = raw_text

# Generated at 2022-06-23 14:30:56.497588
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    encodings = 'utf-16', 'iso-8859-1'
    for encoding in encodings:
        text_environ = _TextEnviron(encoding=encoding)
        for key, value in os.environ.items():
            assert text_environ[key] == to_text(value, encoding=encoding, nonstring='passthru',
                                                errors='surrogate_or_strict')
        key = 'unicode_key'
        value = 'unicode_\u1234'
        os.environ[key] = to_bytes(value, encoding=encoding, errors='surrogate_or_strict')

# Generated at 2022-06-23 14:31:05.806017
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ["test_get_item"] = "abc123"

    # Test valid return
    assert os.environ["test_get_item"] == "abc123"
    assert environ["test_get_item"] == "abc123"
    del os.environ["test_get_item"]
    assert not os.environ.get("test_get_item", None)

    # Test unicode return
    os.environ["test_get_item"] = "\u263A"
    assert environ["test_get_item"] == "\u263A"
    del os.environ["test_get_item"]
    assert not os.environ.get("test_get_item", None)

    # Test encoding error
    os.environ["test_get_item"] = "b'\\x01'"

# Generated at 2022-06-23 14:31:08.966706
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    def get_keys(env):
        keys = []
        for key in env:
            keys.append(key)
        return keys

    assert get_keys(os.environ) == get_keys(environ)


if __name__ == '__main__':
    test__TextEnviron___iter__()

# Generated at 2022-06-23 14:31:11.118196
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env1 = _TextEnviron()
    env2 = _TextEnviron(env=os.environ)
    assert len(env1) == len(env2)



# Generated at 2022-06-23 14:31:13.655616
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()

    assert len(env) == len(os.environ)


# Generated at 2022-06-23 14:31:17.542107
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = dict(A='A', B='B', C='C')
    my_environ = _TextEnviron(env)
    assert set(my_environ.__iter__()) == set(env)


# Generated at 2022-06-23 14:31:22.956268
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron()
    assert 'PYTHONPATH' in environ
    assert isinstance(environ['PYTHONPATH'], str)

    os_environ = os.environ
    os.environ = {}
    environ = _TextEnviron(os_environ, encoding='utf-8')
    assert 'PYTHONPATH' in environ
    assert isinstance(environ['PYTHONPATH'], str)


# Generated at 2022-06-23 14:31:26.313867
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron()
    environ['test'] = 'test'
    assert isinstance(environ['test'], str) and environ['test'] == 'test'


# Generated at 2022-06-23 14:31:27.856694
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == '/home/toshio'

# Generated at 2022-06-23 14:31:32.941242
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Importing the module and testing from here so the code will be run on both Python2 and Python3
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Initialize to the system environment
    env = _TextEnviron()
    assert (isinstance(env, MutableMapping))

    # Initialize to something else
    env2 = _TextEnviron({'a': to_bytes('\N{SNOWMAN}'.encode('utf-8'))})
    assert (isinstance(env2, MutableMapping))


# Generated at 2022-06-23 14:31:35.257041
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    assert len(env) == len(os.environ)



# Generated at 2022-06-23 14:31:39.308388
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """Constructor of class _TextEnviron.
    """
    env = _TextEnviron(env=dict(A='B', C='D'))
    assert env['A'] == 'B'
    assert env['C'] == 'D'



# Generated at 2022-06-23 14:31:42.848927
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['PATH']
    environ['PATH']
    # Add a new value to see if it uses the cache
    environ['ANSIBLE_NEW'] = 'NEW'
    environ['ANSIBLE_NEW']

# Generated at 2022-06-23 14:31:53.578516
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    # __delitem__() function delete keys and values
    # create an object to Test Module
    class _TextEnviron(MutableMapping):

        def __init__(self, env=None, encoding=None):
            self.env = os.environ
            if env is None:
                env = os.environ
            self._raw_environ = env
            self._value_cache = {}
            if encoding is None:
                self.encoding = sys.getfilesystemencoding()
            else:
                self.encoding = encoding

        def __delitem__(self, key):
            del self._raw_environ[key]

        # __get

# Generated at 2022-06-23 14:31:56.615347
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_env = {'FACTS': u'\xf5'}
    text_env = _TextEnviron(env=test_env, encoding='utf-8')
    assert text_env[u'FACTS'] == u'\xf5'



# Generated at 2022-06-23 14:32:04.130975
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Non-unicode env value, no unicode characters in env value
    b'hello world' in environ

    # Unicode env value, no unicode characters in env value
    u'hello world' in environ

    # Non-unicode value, unicode characters in env value
    u'\u2020 hello world' in environ

    # Non-unicode value, unicode characters in env value
    u'hello world \u2020' in environ



# Generated at 2022-06-23 14:32:05.588322
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    _e = _TextEnviron()
    assert set(_e) == set(os.environ)


# Generated at 2022-06-23 14:32:11.504211
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    global environ
    environ = _TextEnviron({}, encoding='utf-8')
    environ["TEST"] = "â€™"
    assert len(environ['TEST']) == 3

if __name__ == '__main__':
    test__TextEnviron___setitem__()

# Generated at 2022-06-23 14:32:12.862703
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:32:18.007519
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['HOME'] == u'~'

    # Test that a cached value returns the correct text
    os.environ['HOME'] = b'/usr/share/httpd'
    assert environ['HOME'] == u'/usr/share/httpd'

    # Test that a cached value returns the correct text
    os.environ['HOME'] = b'/usr/share/httpd'
    assert environ['HOME'] == u'/usr/share/httpd'



# Generated at 2022-06-23 14:32:26.036664
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from cStringIO import StringIO

    # Test with a dummy environment
    os.environ = {'one': 'a', 'two': 'b'}
    environment = _TextEnviron(encoding='utf-8')
    assert len(environment) == 2

    # Test with a real environment
    os.environ = {'PATH': os.getenv('PATH')}
    environment = _TextEnviron(encoding='utf-8')
    assert len(environment) == 1

    # Test that the environment is correct
    assert environment['PATH'] == os.getenv('PATH')


# Generated at 2022-06-23 14:32:33.615761
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    _environ = {u'foo': u'bar',
                u'baz': u'qux',
                u'camelCase': u'camelCaseValue',
                u'_underScore': u'underscoreValue'}
    _expected_keys = [u'foo',
                      u'baz',
                      u'camelCase',
                      u'_underScore']
    assert sorted(list(_TextEnviron(_environ))) == _expected_keys
    assert sorted(list(environ)) == _expected_keys



# Generated at 2022-06-23 14:32:44.205202
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    class MockOsEnviron(MutableMapping):
        def __init__(self, data):
            self.data = data

        def __getitem__(self, item):
            return self.data[item]

        def __setitem__(self, key, value):
            self.data[key] = value

        def __delitem__(self, key):
            del self.data[key]

        def __iter__(self):
            return iter(list(self.data.keys()))

        def __len__(self):
            return len(self.data)

    mock_os_environ = MockOsEnviron({1: b'x', 2: b'y', 3: b'z'})
    mock_raw_environ = _TextEnviron(env=mock_os_environ, encoding='bytes')


# Generated at 2022-06-23 14:32:49.216229
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # The environ object has a value for 'PATH' when we start
    assert 'PATH' in environ

    # The environ object has this value for 'PATH' when we start
    result = environ['PATH']
    assert isinstance(result, str)

    # The environ object continues to have the same value for 'PATH' even after
    # we set and retrieve
    path = result
    environ['PATH'] = path
    result = environ['PATH']
    assert isinstance(result, str)


# Generated at 2022-06-23 14:32:51.852809
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron()
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:32:58.635330
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    raw_environ = {'foo': 'a', 'bar': 'b'}
    text_environ = _TextEnviron(raw_environ)
    if PY3:
        assert text_environ['foo'] == raw_environ['foo']
        assert text_environ['bar'] == raw_environ['bar']
    else:
        assert text_environ['foo'] == raw_environ['foo'].decode('utf-8')
        assert text_environ['bar'] == raw_environ['bar'].decode('utf-8')

# Generated at 2022-06-23 14:33:01.826596
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ["ABC"] = "123"
    _TextEnviron.__delitem__(environ, 'ABC')
    assert 'ABC' not in os.environ


# Generated at 2022-06-23 14:33:10.966737
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test with an empty dict
    test_dict = {}
    environ = _TextEnviron(test_dict)
    environ.__setitem__("test", "utf8")
    assert type(test_dict.get("test")) == bytes
    assert test_dict.get("test") == b"utf8"

    # Test with a dict already containing the item
    test_dict = {"test": b"other_value"}
    environ = _TextEnviron(test_dict)
    environ.__setitem__("test", "utf8")
    assert type(test_dict.get("test")) == bytes
    assert test_dict.get("test") == b"utf8"

    # Test with a dict already containing the item which is a unicode type.  This is not really valid
    # but it can happen with environment variables.

# Generated at 2022-06-23 14:33:19.272922
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import os
    import unittest

    class Test_TextEnviron__iter__(unittest.TestCase):
        def setUp(self):
            os.environ.clear()
            os.environ['one'] = '1'

        def tearDown(self):
            os.environ.clear()

        def test__TextEnviron___iter__(self):
            list_environ = list(environ)
            self.assertEqual(len(os.environ), len(list_environ))
            for key in os.environ:
                self.assertTrue(key in list_environ)

    unittest.main()

if __name__ == '__main__':
    test__TextEnviron___iter__()

# Generated at 2022-06-23 14:33:20.496615
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    for k, v in environ.items():
        yield lambda: environ[k] == v

# Generated at 2022-06-23 14:33:28.681218
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Note that this does not test the caching of the decoded values as it would require a
    # monkey patch of os.environ which would be more trouble than it's worth.
    original_environ = environ._raw_environ
    new_environ = {}
    try:
        environ._raw_environ = new_environ
        environ['HOME'] = u'/home/a.badger'
        assert new_environ[b'HOME'] == b'/home/a.badger'
    finally:
        environ._raw_environ = original_environ



# Generated at 2022-06-23 14:33:38.055366
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-23 14:33:39.738653
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    expected_result = len(os.environ)

    result = len(environ)

    assert result == expected_result


# Generated at 2022-06-23 14:33:45.885878
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Returns text on a py2 machine"""
    # Arrange
    test_environ = _TextEnviron({'test_var': 'test_val'}, encoding='utf-8')

    # Act
    result = test_environ['test_var']
    # Assert
    assert result, 'test_val'
    assert type(result).__name__ == 'text', 'Should be text'

# Generated at 2022-06-23 14:33:47.709855
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PYTHONPATH'] == os.getenv('PYTHONPATH')

# Generated at 2022-06-23 14:33:58.927624
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Test that the __setitem__ method of _TextEnviron correctly encodes the value of the new
    environment variable.
    """
    # Test that __setitem__ encodes non-unicode strings as bytes
    # Test behaviour with a string
    key = 'foo'
    value = 'bar'
    environ[key] = value
    assert environ[key] == value
    assert isinstance(environ._raw_environ[key], bytes)

    # Test behaviour with a byte string
    key = 'foo'
    value = b'bar'
    environ[key] = value
    assert environ[key] == 'bar'
    assert isinstance(environ._raw_environ[key], bytes)

    # Test behaviour with a text string (should be rejected)
    key = 'foo'
    value = u

# Generated at 2022-06-23 14:34:04.298515
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Arrange
    import subprocess

    # Act
    value = subprocess.check_output(['echo', to_bytes('ABC世 i ́ÝÕ', encoding='utf-8')])

    # Assert
    assert to_text(value, encoding='utf-8') == 'ABC世 i ́ÝÕ'

# Generated at 2022-06-23 14:34:07.313016
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    c = _TextEnviron({'a': 'b'})
    assert list(iter(c)) == ['a']



# Generated at 2022-06-23 14:34:17.903215
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    data_set = [
        # input data, expected output
        ({}, {}),
        ({b'x': b'1'}, {'x': '1'}),
        ({b'x': u'1'}, {'x': '1'}),
        ({b'x': b'\x00'}, {'x': u'\x00'}),  # Null bytes are illegal in env vars on Windows
        ({b'x': b'\x00'.decode('utf-8', 'surrogate_or_strict')}, {'x': u'\uDC00'}),
    ]

    for input_data, expected_output in data_set:
        obj = _TextEnviron(env=input_data)
        assert isinstance(obj, _TextEnviron)

# Generated at 2022-06-23 14:34:19.445157
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    assert len(env) == len(os.environ)



# Generated at 2022-06-23 14:34:21.421685
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({b'TEST_ENV': b'test_value'})
    assert sorted(env) == ['TEST_ENV']



# Generated at 2022-06-23 14:34:22.538476
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert hasattr(environ, '__iter__')


# Generated at 2022-06-23 14:34:32.582695
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import tempfile
    import os
    import os.path
    import unittest
    import ansible.module_utils._text as _text

    class Test_TextEnviron_GetItem(unittest.TestCase):
        @classmethod
        def setUpClass(self):
            # create temporary UTF-8 locale for testing
            locale = None

# Generated at 2022-06-23 14:34:43.796778
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    '''
    Test __getitem__ method of class _TextEnviron
    '''
    class EnvironMock(object):
        '''
        Class with the same interface of os.environ
        '''
        def __init__(self, values=None):
            '''
            Constructor
            '''
            if values is None:
                values = dict()
            self.values = values

        def __delitem__(self, key):
            del self.values[key]

        def __getitem__(self, key):
            return self.values[key]

        def __setitem__(self, key, value):
            self.values[key] = value

        def __iter__(self):
            return self.values.__iter__()


# Generated at 2022-06-23 14:34:49.700505
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Check the initial environment
    assert environ[b'PWD'] == u'/'
    assert environ[u'PWD'] == u'/'

    environ[u'PWD'] = u'/mnt/new/root'
    assert environ[b'PWD'] == u'/mnt/new/root'
    assert environ[u'PWD'] == u'/mnt/new/root'

    del environ[u'PWD']
    assert environ[b'PWD'] == u'/'
    assert environ[u'PWD'] == u'/'

# Generated at 2022-06-23 14:34:57.326905
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from tempfile import mkdtemp
    from shutil import rmtree

    class TestEnv:
        def __init__(self, keys={}):
            self.keys = keys

        def __getitem__(self, key):
            return self.keys[key]

        def __setitem__(self, key, value):
            self.keys[key] = value

        def __iter__(self):
            return self.keys.__iter__()

        def __len__(self):
            return len(self.keys)

    # Test both Py2 and Py3 cases
    env = _TextEnviron(env=TestEnv(keys=dict(text='text')))

    if PY3:
        assert 'text' == env['text']
    else:
        from ansible.module_utils.six import text_type

# Generated at 2022-06-23 14:35:07.057316
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """Test the constructor of class _TextEnviron."""
    test_env = {u'foo': b'bar', u'bar': b'baz'}
    te = _TextEnviron(env=test_env)
    assert len(te) == 2
    for key in te:
        assert isinstance(key, str)
        assert isinstance(te[key], str)
        assert te[key].encode('utf-8') == test_env[key]
    assert te[u'foo'] == 'bar'
    assert te['bar'] == 'baz'
    test_env['bar'] = b'qaz'
    assert te[u'bar'] == 'qaz'
    assert u'foo' in te
    assert 'bar' in te
    assert 'foo' not in te

# Generated at 2022-06-23 14:35:13.088874
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    try:
        del environ['ANSIBLE_PYTHON_INTERPRETER']
    except KeyError as e:
        msg = 'no such environment variable'
        assert msg in to_text(e), \
            "Message should contain '{0}' got '{1}' instead".format(msg, to_text(e))

# Generated at 2022-06-23 14:35:14.589342
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:35:21.675123
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test 1: handle bytes
    tester = _TextEnviron()
    tester['foo'] = 'bar'
    assert tester['foo'] == 'bar'
    # Test 2: handle text
    if not PY3:
        tester = _TextEnviron()
        tester['foo'] = u'bar'
        assert tester['foo'] == u'bar'


# Making sure that we don't return an encodable string for bad variables

# Generated at 2022-06-23 14:35:24.352703
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import itertools

    text_environ = _TextEnviron(env={'foo': 'bar'})
    assert isinstance(iter(text_environ), type(itertools.chain()))



# Generated at 2022-06-23 14:35:26.465579
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['TESTENV'] = "success"
    assert(environ['TESTENV'] == "success")


# Generated at 2022-06-23 14:35:32.747217
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_environ = _TextEnviron({'test': '\u0411\u0435\u043b\u0430\u0440\u0443\u0441\u044c'})
    assert test_environ['test'] == '\u0411\u0435\u043b\u0430\u0440\u0443\u0441\u044c'

# Generated at 2022-06-23 14:35:43.075436
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # env kwarg
    env = {b'foo': b'bar'}
    text_env = _TextEnviron(env)
    assert text_env.encoding == sys.getfilesystemencoding()
    assert len(text_env) == 1
    assert text_env['foo'] == to_text(env['foo'], encoding=sys.getfilesystemencoding(), errors='replace')
    text_env['bar'] = 'baz'
    assert text_env['bar'] == to_text('baz', encoding=sys.getfilesystemencoding(), errors='replace')
    del text_env['bar']
    assert text_env['foo'] == to_text(env['foo'], encoding=sys.getfilesystemencoding(), errors='replace')
    assert len(text_env) == 1

    # encoding kwarg

# Generated at 2022-06-23 14:35:48.208845
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['test'] = 'test_str'
    assert environ._raw_environ['test'] == to_bytes('test_str', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    environ['test'] = u'test_ustr'
    assert environ._raw_environ['test'] == to_bytes(u'test_ustr', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')


# Generated at 2022-06-23 14:35:51.283144
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['ANSIBLE_TEST'] = '1'
    del environ['ANSIBLE_TEST']
    assert 'ANSIBLE_TEST' not in environ


# Generated at 2022-06-23 14:35:54.489513
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env_save = environ._raw_environ.copy()
    environ['FOO'] = 'BAR'
    del environ['FOO']
    assert 'FOO' not in environ
    environ._raw_environ = env_save



# Generated at 2022-06-23 14:35:55.015368
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    pass

# Generated at 2022-06-23 14:36:02.645570
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import unittest
    import unittest.mock as mock
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves.builtins import dict

    class Test__TextEnviron___setitem__(unittest.TestCase):
        @mock.patch('ansible.module_utils._text.to_bytes')
        def test___setitem__(self, mock_to_bytes):
            mock_to_bytes.return_value = 'b'

            env = _TextEnviron('utf-8')

            env['a'] = 'a'

            self.assertEqual({'a': 'b'}, dict(env._raw_environ))

# Generated at 2022-06-23 14:36:03.500668
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert set(environ.__iter__()) == set(os.environ.keys())


# Generated at 2022-06-23 14:36:12.118045
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_utf8_body = 'Работайте с кодировкой utf-8'
    try:
        environ_utf8_body.encode('ascii')
    except UnicodeEncodeError:
        pass
    else:
        raise AssertionError(
            "%s is expected to raise UnicodeEncodeError" % environ_utf8_body)

    assert environ_utf8_body == to_text(environ_utf8_body.encode('utf-8'), 'utf-8')

    # os.environ is a dict of bytes
    os.environ['u'] = environ_utf8_body.encode('utf-8')
    # _TextEnviron is a dict of unicode

# Generated at 2022-06-23 14:36:15.165188
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    original_env = os.environ
    os.environ = {'1': 'a', '2': 'b', '3': 'c'}
    try:
        text_env = _TextEnviron()
        for key, value in zip(text_env.__iter__(), os.environ.__iter__()):
            assert key == value
    finally:
        os.environ = original_env


# Generated at 2022-06-23 14:36:18.558497
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils.six import PY2
    # PY2: b'value'
    # PY3: 'value'
    assert b'value' == environ.__setitem__('key', 'value')



# Generated at 2022-06-23 14:36:26.039838
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    current_env = os.environ.copy()
    os.environ['ANSIBLE_ENV_TEST_KEY_1'] = 'value 1'
    os.environ['ANSIBLE_ENV_TEST_KEY_2'] = 'value 2'


# Generated at 2022-06-23 14:36:29.682372
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    _TextEnviron(env={}, encoding='utf-8')
    _TextEnviron(env=dict(a=b'a', b=b'b'), encoding='utf-8')
    _TextEnviron(encoding='utf-8')

# Generated at 2022-06-23 14:36:32.047168
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environment = os.environ
    assert len(_TextEnviron(environment)) == len(environment)


# Generated at 2022-06-23 14:36:33.412062
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ.clear()
    del environ['PATH']


# Generated at 2022-06-23 14:36:38.080276
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
  from ansible.module_utils.common._collections_compat import MutableMapping
  from ansible.module_utils._text import to_text
  from ansible.module_utils._text import to_bytes
  from ansible.module_utils.six import PY3

  class _TextEnviron(MutableMapping):
      """
      Utility class to return text strings from the environment instead of byte strings

      Mimics the behaviour of os.environ on Python3
      """
      def __init__(self, env=None, encoding=None):
          if env is None:
              env = os.environ
          self._raw_environ = env
          self._value_cache = {}
          # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
          # instead of utf-

# Generated at 2022-06-23 14:36:41.806106
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    raw_environ = {'a': 1, 'b': 2}
    text_environ = _TextEnviron(raw_environ)
    assert len(text_environ) == len(raw_environ)


# Generated at 2022-06-23 14:36:44.146891
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert isinstance(environ, MutableMapping)
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:36:50.322506
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    e = _TextEnviron(encoding='utf-8')
    e['test_key'] = u'test_value'
    e['another_key'] = u'another_value'
    del e['test_key']
    if __name__ == '__main__':
        print(dict(e))
    assert dict(e) == {'another_key': u'another_value'}


# Generated at 2022-06-23 14:36:53.642978
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ.clear()
    assert len(environ) == 0
    environ['testkey'] = "testvalue"
    assert len(environ) == 1
    assert environ['testkey'] == "testvalue"
    del environ['testkey']
    assert len(environ) == 0


# Generated at 2022-06-23 14:37:00.329362
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # os.environ.__getitem__ method works on unicode as well as str (for Python 2 or 3)
    # so reset it to only have a str key
    os.environ.clear()
    os.environ.update({'FOO': 'FOOvalue'})

    # text environ does not work on bytes (for Python 2 or 3)
    # for now, just test if it works on unicode for the key
    environ.clear()
    environ.update({u'FOO': 'FOOvalue'})
    assert environ[u'FOO'] == 'FOOvalue'

# Generated at 2022-06-23 14:37:05.024116
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ.clear()
    environ['test1'] = 'value1'
    environ['test2'] = 'value2'
    environ['test3'] = 'value3'

    result = list(environ)

    assert 'test1' in result
    assert 'test2' in result
    assert 'test3' in result



# Generated at 2022-06-23 14:37:10.584144
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = {'1': '1', '2': '2'}
    environ = _TextEnviron(env)
    assert len(environ) == 2
    del env['2']
    assert len(environ) == 1
    env['2'] = '2'
    assert len(environ) == 2



# Generated at 2022-06-23 14:37:19.947178
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import copy
    import builtins

    # Use a copy of the real os.environ so that we aren't changing the real environment
    test_env = copy.deepcopy(environ._raw_environ)
    assert isinstance(test_env, MutableMapping)

    # Default to utf-8 if provided environment is not None
    if PY3:
        test_te = _TextEnviron(env=test_env)
    else:
        test_te = _TextEnviron(env=test_env, encoding=None)
    assert isinstance(test_te, MutableMapping)
    assert isinstance(test_te._raw_environ, MutableMapping)
    assert test_te._raw_environ == test_env
    assert test_te._value_cache == {}

# Generated at 2022-06-23 14:37:29.704087
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Check with a known good value
    e = _TextEnviron(encoding='utf-8')
    e['mykey'] = u'中文'
    assert e['mykey'] == u'中文'
    assert isinstance(e['mykey'], str)
    assert isinstance(e._raw_environ[b'mykey'], bytes)

    # Check with a bad value
    e['mykey'] = u'\udcff'
    assert e['mykey'] == u'\udcff'
    assert isinstance(e['mykey'], str)
    assert isinstance(e._raw_environ[b'mykey'], bytes)



# Generated at 2022-06-23 14:37:34.749044
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils._text import to_text

    expected_results = {}
    for expected_key in environ:
        expected_results[expected_key] = to_text(environ[expected_key])

    assert len(expected_results) == environ.__len__()



# Generated at 2022-06-23 14:37:37.610512
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _env = _TextEnviron({'a':'1'})
    assert('a' in _env)
    del _env['a']
    assert('a' not in _env)
    _env['a']='1'
    assert('a' in _env)
    del _env['a']
    assert('a' not in _env)


# Generated at 2022-06-23 14:37:47.223633
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Test creation of a _TextEnviron object
    """

    # Test inheriting from os.environ
    assert isinstance(environ, _TextEnviron)
    assert environ is not os.environ

    # Test inheriting from a plain dict
    t_environ = _TextEnviron({b'FOO': b'bar'}, encoding='utf-8')
    assert t_environ['FOO'] == u'bar'
    t_environ['BAZ'] = u'buzz'
    assert t_environ['BAZ'] == u'buzz'
    assert t_environ._raw_environ[b'BAZ'] == b'buzz'

# Test __getitem() of class _TextEnviron