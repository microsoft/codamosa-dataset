

# Generated at 2022-06-23 14:27:51.095500
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    if PY3:
        assert environ['PATH'] == os.environ['PATH']
        return

    # Since we're going to change things, don't mess with real environ, make a copy.
    test_environ = os.environ.copy()
    # For the first test, we'll assume environ is always using bytes
    test_environ['PATH'] = b'/a/b/c'

    # Mimic the behaviour of a real-world environment:
    #   - Cache the decoded string based on the byte string (in this case, the byte string is not
    #     valid utf-8 so we'll get a surrogate escape encoded string back)
    #   - Return the cached value
    assert environ['PATH'] == u'\udccb\udccc'
    assert 'PATH' in environ._value_cache


# Generated at 2022-06-23 14:27:53.851174
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['USER'] = 'user_name'
    assert isinstance(environ['USER'], str)
    assert isinstance(environ._raw_environ['USER'], bytes)

# Generated at 2022-06-23 14:27:58.865875
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Check the iterator when there is no environment
    if 'PATH' in environ:
        del environ['PATH']

    assert isinstance(environ, _TextEnviron), 'an instance of _TextEnviron is not created'

    iterator = iter(environ)

    assert isinstance(iterator, iter), 'iterator is not an instance of builtin class iter'



# Generated at 2022-06-23 14:28:00.689103
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) > 0
    env = _TextEnviron({})
    assert len(env) == 0



# Generated at 2022-06-23 14:28:03.058093
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron(env={'1': '2'}, encoding='utf-8')
    assert list(env.__iter__()) == ['1']

# Generated at 2022-06-23 14:28:11.060123
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron({b'key1': b'value1', b'key2': b'value2'})
    assert sorted(environ) == sorted(environ._raw_environ)
    assert sorted(environ) == sorted({'key1', 'key2'})
    environ = _TextEnviron({'key1': 'value1', 'key2': 'value2'})
    assert sorted(environ) == sorted(environ._raw_environ)
    assert sorted(environ) == ['key1', 'key2']



# Generated at 2022-06-23 14:28:16.704758
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron()
    env['TEST'] = 'tacos'
    assert env['TEST'] == 'tacos'
    del env['TEST']
    try:
        env['TEST']
    except KeyError:
        pass
    else:
        raise AssertionError('del env[key] did not remove the key from the environment')


# Generated at 2022-06-23 14:28:23.162035
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    global environ
    environ_copy = environ.copy()
    environ['ANSIBLE_PYTHON_MODULE_RUNNING_UNITTEST'] = '42'
    del environ['ANSIBLE_PYTHON_MODULE_RUNNING_UNITTEST']
    assert 'ANSIBLE_PYTHON_MODULE_RUNNING_UNITTEST' not in environ
    environ = environ_copy



# Generated at 2022-06-23 14:28:32.909802
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # empty constructor
    environ = _TextEnviron()
    assert isinstance(environ, MutableMapping)
    # populate constructor with a pre-existing environ
    environ_copy = os.environ.copy()
    # Make sure the values are bytes objects
    for key, value in environ_copy.items():
        if not isinstance(key, bytes):
            environ_copy[key.encode('utf-8')] = environ_copy.pop(key)
        if not isinstance(value, bytes):
            environ_copy[key] = value.encode('utf-8')
    test_environ = _TextEnviron(environ_copy)
    assert environ_copy == test_environ._raw_environ
    # Test decoding the values

# Generated at 2022-06-23 14:28:35.166055
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) >= 0, "__len__ of class _TextEnviron failed"

# Generated at 2022-06-23 14:28:41.584871
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    data = [
        ('a'),
        ('b'),
        ('c')
    ]
    os.environ['a'] = 'a'
    os.environ['b'] = 'aa'
    os.environ['c'] = 'aaa'
    assert len(environ) == len(data)
    os.environ.pop('a')
    os.environ.pop('b')
    os.environ.pop('c')

# Generated at 2022-06-23 14:28:48.358240
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import sys
    # The following is a string containing a non-ascii character
    nonascii = '\u2026'
    try:
        nonascii = nonascii.encode(sys.getfilesystemencoding())
    except UnicodeEncodeError:
        # Filesystem encoding couldn't handle it, so skip this test
        return
    os.environ[b'TEST'] = nonascii
    assert environ[b'TEST'] == nonascii.decode(sys.getfilesystemencoding())
    del os.environ[b'TEST']

# Generated at 2022-06-23 14:28:55.262669
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test on unicode str, is expected to be encoded to utf-8 and then decoded to unicose again
    # Test on bytes, is expected to be decoded to unicode
    # Test on non-string, is expected to be returned directly

    # Test on unicode str, is expected to be encoded to utf-8 and then decoded to unicose again
    # Setup
    data = {u'1': u'2', b'1': u'2'}
    environ = _TextEnviron(data)
    # Test
    for k in data:
        assert isinstance(environ[k], unicode), 'Returned type is wrong'
        assert data[k] == environ[k], 'Returned value is wrong'
    # Teardown

    # Test on bytes, is expected to be decoded to unicode
    #

# Generated at 2022-06-23 14:28:58.238708
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Make sure that we've overriden the os.environ with our _TextEnviron class
    assert all(map(lambda key: isinstance(os.environ[key], str), os.environ))


# Generated at 2022-06-23 14:29:02.444155
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ = _TextEnviron({'unicode': '\u00e9', 'bytes_to_text': b'\xe9'})
    assert environ['unicode'] == '\u00e9'
    assert environ['bytes_to_text'] == '\u00e9'

# Generated at 2022-06-23 14:29:06.869684
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = {}
    envTxt = _TextEnviron(env, encoding='utf-8')
    assert len(env) == len(envTxt)

    env['i'] = to_bytes('i', encoding='utf-8')
    envTxt['i'] = 'i'
    assert len(env) == len(envTxt)
    assert len(env) == 1


# Generated at 2022-06-23 14:29:09.564283
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron(os.environ)
    assert set(env) == set(os.environ)


# Generated at 2022-06-23 14:29:13.860131
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['test_key'] = 'test_value'
    assert environ['test_key'] == 'test_value'
    del environ['test_key']
    assert 'test_key' not in environ


# Generated at 2022-06-23 14:29:16.485411
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test simple __setitem__ and __getitem__
    environ['aaa'] = 'bbb'
    assert environ['aaa'] == 'bbb'



# Generated at 2022-06-23 14:29:24.483563
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """ Test _TextEnviron.__setitem__()
    """

    # Test with default encoding
    environ__setitem__ = _TextEnviron(encoding='utf-8')
    environ__setitem__['ansible_become_password'] = u'é'
    assert isinstance(environ__setitem__['ansible_become_password'], str) is True
    assert isinstance(environ__setitem__['ansible_become_password'], bytes) is False

    # Test with ascii encoding
    environ__setitem__ = _TextEnviron(encoding='ascii')
    environ__setitem__['ansible_become_password'] = u'é'
    assert isinstance(environ__setitem__['ansible_become_password'], str) is True

# Generated at 2022-06-23 14:29:33.421579
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils.six.moves.builtins import range

    def __iter__():
        for index in range(4):
            yield 'myvar' + str(index)

    environ = _TextEnviron()
    environ._raw_environ = {
        'myvar0': b'a',
        'myvar1': b'b',
        'myvar2': b'c',
        'myvar3': b'd',
    }
    assert [key for key in environ] == list(__iter__())


# Generated at 2022-06-23 14:29:38.429665
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ['TEST_1'] = 'value'
    assert len(environ) == 1
    os.environ['TEST_2'] = 'value'
    assert len(environ) == 2
    del os.environ['TEST_1']
    assert len(environ) == 1
    del os.environ['TEST_2']
    assert len(environ) == 0


# Generated at 2022-06-23 14:29:41.289750
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron({'foo': 'bar', 'baz': 'bam'})
    assert len(environ) == 2



# Generated at 2022-06-23 14:29:52.142119
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = {'key1': 'value1', 'key2': 'value2'}
    textenviron = _TextEnviron(env=env)
    assert len(textenviron) == 2
    assert textenviron['key1'] == 'value1'
    assert textenviron['key2'] == 'value2'
    textenviron['key3'] = 'value3'
    assert textenviron['key3'] == 'value3'
    del textenviron['key3']
    assert len(textenviron) == 2
    assert 'key3' not in textenviron
    textenviron.encoding = 'ascii'
    textenviron['key1'] = b'value1'
    assert textenviron['key1'] == 'value1'

# Generated at 2022-06-23 14:29:53.202586
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:30:00.399332
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron(encoding=None)
    env._raw_environ = {
        'foo': 'bar'
    }
    result = env['foo']
    assert result == u'bar', 'Test type of the result should be unicode'

    env._raw_environ = {
        'foo': u'bar'
    }
    result = env['foo']
    assert result == u'bar', 'Test type of the result should be unicode'

    env._raw_environ = {
        'foo': u'\x00'
    }
    result = env['foo']
    assert result == u'\x00', 'Test type of the result should be unicode'

    env._raw_environ = {
        'foo': u'hh\x00'
    }
    result = env['foo']

# Generated at 2022-06-23 14:30:07.736515
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import ansible_collections.toshio.kuramoto._text_environ

    # test basic function
    os.environ['TEST_KEY'] = 'TEST_VAL'
    assert ansible_collections.toshio.kuramoto._text_environ.environ['TEST_KEY'] == 'TEST_VAL'
    assert isinstance(ansible_collections.toshio.kuramoto._text_environ.environ['TEST_KEY'], str)

    # test memory caching
    os.environ['TEST_KEY'] = b'test_val'
    assert ansible_collections.toshio.kuramoto._text_environ.environ['TEST_KEY'] == 'test_val'
    os.environ['TEST_KEY'] = 'test_val'
   

# Generated at 2022-06-23 14:30:13.831196
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Initialization of environ object
    environ = _TextEnviron(env={'A': b'Val1', 'B': b'Val2', 'C': b'Val3'}, encoding='utf-8')
    # Creation of a list to compare with the result
    l = ['A', 'B', 'C']
    for k in l:
        l.remove(k)
        l.append(k)
    # Test
    assert (list(environ) == l)

# Generated at 2022-06-23 14:30:21.309733
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Unit test for method __delitem__
    of class _TextEnviron
    """
    env = _TextEnviron()
    try:
        test_key = os.getenv('PATH')
        test_value = 'test_value'
        del env[test_key]
        env[test_key] = test_value
        assert test_key in env
        environment = dict(env)
        # test if value stored in class is same as os.environ
        assert environment[test_key] == os.environ[test_key]
    finally:
        # restore os.environ
        os.environ.clear()
        os.environ.update(environment)


# Generated at 2022-06-23 14:30:24.395182
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    obj = _TextEnviron(encoding='utf-8')
    obj['test_item'] = 'hello'
    # Added for python 2.6
    assert obj['test_item'] == u'hello'
    del obj['test_item']



# Generated at 2022-06-23 14:30:31.587237
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Make sure the conversion works on the items in environ
    for key, value in environ.items():
        assert key == to_bytes(key, encoding='utf-8', nonstring='strict',
                               errors='surrogate_or_strict')
        assert value == to_text(value, encoding='utf-8', nonstring='passthru',
                                errors='surrogate_or_strict')
    # Make sure it works on a new environ that doesn't exist in the parent
    environ['TEST_ITEM'] = 'TEST_VALUE'
    assert environ['TEST_ITEM'] == 'TEST_VALUE'
    # Make sure the new item is converted to bytes properly
    raw_environ = os.environ

# Generated at 2022-06-23 14:30:32.505493
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    return True

# Generated at 2022-06-23 14:30:39.732437
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    '''
    This test verifies that the setitem method of the class _TextEnviron
    properly encodes unicode string values.
    '''
    class MockEnv(MutableMapping):
        '''
        An object that can be used as an environment object to
        test the _TextEnviron class
        '''
        def __init__(self):
            self._env_dict = dict()

        def __delitem__(self, key):
            del self._env_dict[key]

        def __getitem__(self, key):
            return self._env_dict[key]

        def __setitem__(self, key, value):
            self._env_dict[key] = value

        def __iter__(self):
            return self._env_dict.__iter__()


# Generated at 2022-06-23 14:30:47.409887
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import json
    import os
    import tempfile

    # Note: This test works on Python3 since it will fail in the json.dump call if the environment
    # is not utf-8.
    #
    # Need to create a file with a unicode character in the filename
    tf = tempfile.mkstemp(u'\u2603-utf8.conf', 'ansible-')
    oname = tf[1]


# Generated at 2022-06-23 14:30:56.912720
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron(encoding='utf-8')
    value = to_bytes('value', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    environ['key'] = value
    assert 'key' in environ
    assert to_text(value, encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict') == \
        environ['key']
    assert len(environ) == 1
    assert 'key' in environ.keys()
    assert 'value' in environ.values()
    assert ('key', 'value') in environ.items()
    del environ['key']
    assert len(environ) == 0

# Generated at 2022-06-23 14:31:02.667173
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ__Test = _TextEnviron()
    text = to_text('\u043f\u0440\u0438\u0432\u0435\u0442')
    environ__Test['HELLO'] = text
    byte_text = to_bytes('\u043f\u0440\u0438\u0432\u0435\u0442')
    assert environ__Test['HELLO'] == byte_text


# Generated at 2022-06-23 14:31:05.166441
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['TEST'] = '\u4e2d\u56fd'
    assert environ['TEST'] == u'\u4e2d\u56fd'

# Generated at 2022-06-23 14:31:07.649353
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ.clear()
    environ['PATH'] = '/foo'
    assert 'PATH' in environ
    del environ['PATH']
    assert 'PATH' not in environ


# Generated at 2022-06-23 14:31:16.281111
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Verify len(environ) is the same between the wrapped environ and the unwrapped environ.
    assert len(environ) == len(os.environ)

    # Verify that adding one to the wrapped class is reflected in the unwrapped one.
    length = len(environ)
    environ['NEW'] = 'foo'
    assert len(environ) == length + 1
    assert len(os.environ) == length + 1
    assert os.environ['NEW'] == 'foo'
    del environ['NEW']
    assert len(environ) == length
    assert len(os.environ) == length


# Generated at 2022-06-23 14:31:24.593305
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():

    class TestEnviron(object):
        def __init__(self):
            self._cache = {}

        def __getitem__(self, key):
            return self._cache[key]

        def __setitem__(self, key, value):
            self._cache[key] = value

        def __iter__(self):
            return self._cache.__iter__()

        def __len__(self):
            return len(self._cache)

        def __delitem__(self, key):
            del self._cache[key]

    test_env_as_bytes = TestEnviron()
    test_env_as_bytes['firstkey'] = 'value'.encode('utf-8')

    test_env_as_unicode = TestEnviron()

# Generated at 2022-06-23 14:31:35.688844
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Wrap os.environ with environ object
    os.environ = _TextEnviron()

    # Test set/get StringString
    os.environ['name'] = 'Toshio'
    assert os.environ['name'] == 'Toshio'

    # Test set/get StringUtf8
    os.environ['language'] = '日本語'
    assert os.environ['language'] == '日本語'

    # Test set/get Utf8Utf8
    os.environ[u'language'] = u'日本語'
    assert os.environ[u'language'] == u'日本語'

    # Test set/get Utf8String
    os.environ[u'language'] = '日本語'


# Generated at 2022-06-23 14:31:39.358045
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env_name = 'ANSIBLE_TEST_ENV'
    environ[env_name] = 'test'
    assert env_name in environ

    del environ[env_name]
    assert env_name not in environ


# Generated at 2022-06-23 14:31:50.647954
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Initializing an empty environ
    environ_ = _TextEnviron(env={})
    # set a value with a str value
    environ_['string'] = 'foo'
    # set a value with bytes, should raise TypeError
    try:
        environ_['bytes'] = b'bar'
    except TypeError:
        pass
    assert environ_['string'] == 'foo'
    assert 'bytes' not in environ_
    # set a value with a non string value, should raise TypeError
    try:
        environ_['list'] = list()
    except TypeError:
        pass
    assert environ_['string'] == 'foo'
    assert 'bytes' not in environ_
    assert 'list' not in environ_
    # set a value with a non string value, should raise TypeError


# Generated at 2022-06-23 14:31:58.965983
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import copy
    import os
    import unittest

    class test_TextEnvironClass(unittest.TestCase):
        """
        Tests for _TextEnviron's __iter__ method
        """
        def setUp(self):
            self.environ_data = copy.deepcopy(environ)


# Generated at 2022-06-23 14:32:08.661338
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # First, for a utf-8 capable system
    env = _TextEnviron(env=dict(LANG='en_US.UTF-8'), encoding='utf-8')
    assert env.get('LANG') == u'en_US.UTF-8'
    env.clear()
    env['LANG'] = 'en_US.UTF-8'
    assert env.get('LANG') == u'en_US.UTF-8'
    # Now, for a non-utf-8 capable system
    env = _TextEnviron(env=dict(LANG='C'), encoding='ascii')
    assert env.get('LANG') == u'C'
    env.clear()
    env['LANG'] = 'C'
    assert env.get('LANG') == u'C'
    # Now, for a

# Generated at 2022-06-23 14:32:15.307288
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-23 14:32:19.047915
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron({'A': 'B', 'C': 'D'})
    assert len(environ) == 2, "unexpected len of environ"



# Generated at 2022-06-23 14:32:20.888194
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    for key in environ:
        assert(isinstance(key, str))


# Generated at 2022-06-23 14:32:23.871221
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import os

    n = len(os.environ)
    print('_TextEnviron\nlen: ' + str(n))
    assert n == len(environ)


# Generated at 2022-06-23 14:32:26.552551
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_environ = _TextEnviron(env={'name': 'image'})
    del test_environ['name']
    assert(len(test_environ) == 0)


# Generated at 2022-06-23 14:32:37.977424
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    env['foo'] = 'bar'
    assert env['foo'] == 'bar'
    assert b'bar' == env._raw_environ[b'foo']

    env['baz'] = b'qux'
    assert env['baz'] == 'qux'
    assert b'qux' == env._raw_environ[b'baz']

    env['baz'] = u'quux'
    assert env['baz'] == 'quux'
    assert b'quux' == env._raw_environ[b'baz']

    # We want to throw on non-string values since this is an environment variable
    try:
        env['baz'] = {'quux': 3}
    except TypeError:
        pass

# Generated at 2022-06-23 14:32:43.670531
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert '__iter__' in dir(_TextEnviron)

    if PY3:
        newenv = _TextEnviron()
        assert newenv.__iter__() == os.environ.__iter__()

    else:
        newenv = _TextEnviron(dict(a='1', b='2'))
        assert newenv.__iter__() == dict(a='1', b='2').__iter__()



# Generated at 2022-06-23 14:32:50.941381
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import six
    if six.PY3:
        assert isinstance(environ, os._Environ)
        assert environ._raw_environ is os.environ
    else:
        assert isinstance(environ, dict)
        assert environ._raw_environ is os.environ

    # Test setting and getting keys
    environ['ANSIBLE_TEST'] = '1'
    assert environ['ANSIBLE_TEST'] == '1'
    del environ['ANSIBLE_TEST']
    if 'ANSIBLE_TEST' in environ:
        # Different tests may have set this value
        if six.PY3:
            assert environ['ANSIBLE_TEST'].startswith('b')
        else:
            assert environ['ANSIBLE_TEST'].startswith('u')

   

# Generated at 2022-06-23 14:32:59.968592
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Testing _TextEnviron.__getitem__
    #
    # 1. Populate a test environ with known values
    env = _TextEnviron()
    env['value_1'] = 'value 1'
    env['value_2'] = 'value 2'

    # 2. Assert that the environment variables are in the expected format
    #    (i.e. text)
    assert env['value_1'] == "value 1"
    assert env['value_2'] == "value 2"

    # 3. Change the encoding and assert that the environment
    #    variables are still in the expected format
    env = _TextEnviron(encoding='mbcs')
    assert env['value_1'] == "value 1"
    assert env['value_2'] == "value 2"

    # 4. Assert that when the environment is changed

# Generated at 2022-06-23 14:33:04.760339
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    if not PY3:
        environ = _TextEnviron()
        assert isinstance(environ, _TextEnviron)
        assert sys.getfilesystemencoding() == environ.encoding
    else:
        assert isinstance(environ, os._Environ)
        assert sys.getfilesystemencoding() == environ.encoding

# Generated at 2022-06-23 14:33:10.405639
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # pylint: disable=protected-access
    assert not sys.version_info.major == 3

    # Test that string values are coerced to native strings
    environ_value = environ._TextEnviron({'TEST': 'foo'})
    assert isinstance(environ_value['TEST'], str)

    # Test that bytes values are coerced to native
    environ_value = environ._TextEnviron({'TEST': b'foo'})
    assert isinstance(environ_value['TEST'], str)

# Generated at 2022-06-23 14:33:12.137240
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron(encoding="utf-8")
    assert isinstance(environ, _TextEnviron)

# Generated at 2022-06-23 14:33:20.536422
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test str for Python3
    if PY3:
        environ._raw_environ.clear()

        environ['KEY'] = 'value'
        assert environ._raw_environ['KEY'] == b'value'

        del environ['KEY']
        assert len(environ._raw_environ) == 0

    # Test bytes for Python2
    if not PY3:
        environ._raw_environ.clear()

        environ['KEY'] = b'value'
        assert environ._raw_environ['KEY'] == b'value'

        del environ['KEY']
        assert len(environ._raw_environ) == 0

    # Test non-ascii unicode string for Python3
    if PY3:
        environ._raw_environ.clear()


# Generated at 2022-06-23 14:33:22.873399
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({'abc': 'abc', 'def': 'def'})
    assert len(env) == 2
    env['ghi'] = 'ghi'
    assert len(env) == 3


# Generated at 2022-06-23 14:33:25.322057
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    try:
        len(environ)
    except:  # noqa
        assert 0, 'len(environ) raised an exception'



# Generated at 2022-06-23 14:33:26.870626
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:33:29.466810
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that the __getitem__ method returns a text string
    assert isinstance(environ[b'PATH'], text_type)



# Generated at 2022-06-23 14:33:38.480226
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    cls = _TextEnviron
    # test
    #   __init__
    #       default
    #           environ
    #   __getitem__
    #       byte string
    #       byte array
    #       unicode string
    #       unicode array
    #   __setitem__
    #       byte string
    #       byte array
    #       unicode string
    #       unicode array
    #       non-string

    # Test init
    #    default
    #        environ
    t = cls()

    # Test getitem
    #    byte string
    #    byte array
    #    unicode string
    #    unicode array
    #    bytes that can't be decoded
    #    byte string in array
    #    byte array in array
    #    unicode string in array
    #

# Generated at 2022-06-23 14:33:47.761254
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a key that has non-ascii characters in its value
    key = 'TEST'
    value = u'\u0394\u0399\u03A2\u03A9'
    environ[key] = value
    assert environ[key] == value

    # Test with a key that has non-utf-8 characters in its value
    key = 'TEST2'
    value = u'\U0001F639'
    environ[key] = value.encode('utf-16')
    assert environ[key] == value

# Generated at 2022-06-23 14:33:49.265989
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)

# Generated at 2022-06-23 14:33:52.176826
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    _TextEnviron.__setitem__(environ, 'mykey', 'myvalue')
    assert list(environ.__iter__()) == ['mykey']



# Generated at 2022-06-23 14:33:56.611988
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env_var = 'ANSIBLE_TEST_ENV_VAR'
    test_env = 'this is a test environment variable'
    env = _TextEnviron({env_var: test_env})

    assert env[env_var] == test_env


# Generated at 2022-06-23 14:34:03.836101
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test the case where all the keys are the same
    _TextEnviron.__getitem__.test_id = 'all keys are the same'
    env = _TextEnviron({'key': 'value', 'key2': 'value'})
    assert env['key'] == 'value'
    assert env['key2'] == 'value'
    assert env._value_cache['value'] == 'value'
    # Test case where the cached value is different from the underlying value
    _TextEnviron.__getitem__.test_id = 'cached value is different from underlying value'
    env = _TextEnviron({'key': 'value2', 'key2': 'value'})
    assert env['key'] == 'value2'
    assert env['key2'] == 'value'

# Generated at 2022-06-23 14:34:09.358856
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['test'] = 'こんにちは'
    assert b'\xe3\x81\x93\xe3\x82\x93\xe3\x81\xab\xe3\x81\xa1\xe3\x81\xaf' == environ._raw_environ['test']



# Generated at 2022-06-23 14:34:19.620170
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with key not existing in environment
    text_environ = _TextEnviron()
    assert text_environ['nonexisting'] == u''

    text_environ = _TextEnviron({'PY_TEXTENV_VALUE1': 'ABC'})
    # Test with key existing in environment
    assert text_environ['PY_TEXTENV_VALUE1'] == u'ABC'

    # Test with key existing in environment but as non-ASCII bytes
    text_environ = _TextEnviron({'PY_TEXTENV_VALUE2': b'\xeb'})
    assert text_environ['PY_TEXTENV_VALUE2'] == u'\xeb'

    # Test with key existing in environment but as non-ASCII str

# Generated at 2022-06-23 14:34:27.613003
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test unicode values are not changed
    os.environ['unicode'] = 'hø'
    assert environ['unicode'] == 'hø'

    # Test non-utf8 strings with surrogate-or-strict error handling
    os.environ['bad'] = '\x80'.encode('utf8')
    assert environ['bad'] == '\uFFFD'

    # Test non-string values are returned without change
    os.environ['nonstring'] = 42
    assert environ['nonstring'] == 42


# Generated at 2022-06-23 14:34:31.218014
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    global environ

    environ = _TextEnviron()
    environ['TEST_KEY'] = 'A'
    assert 'TEST_KEY' in environ
    del environ['TEST_KEY']
    assert 'TEST_KEY' not in environ


# Generated at 2022-06-23 14:34:42.219849
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Tests the __len__ method of the _TextEnviron class

    Description:
        The _TextEnviron class should behave very similarly to os.environ in Python3.  That
        includes returning the same number of values for len(os.environ) == len(environ).
        This test does that assertion.
    """
    from ansible.module_utils.six import PY3

    # The os.environ.__len__ method on Python2 is weird and returns a
    # PyLong on some systems.  So explicitly create it to be sure we
    # have that value.
    if not PY3:
        length = len(os.environ)
    else:
        length = len(environ)


# Generated at 2022-06-23 14:34:50.418122
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron(encoding='utf-8')
    # surrogate_or_strict -> fail
    with pytest.raises(UnicodeEncodeError):
        environ['key'] = '\udcff'
    # surrogateescape -> surrogate escaped
    environ['key'] = '\udcff'
    assert environ['key'] == '\udcff'
    environ['key'] = '\udcff\ud800'
    assert environ['key'] == '\udcff\ud800'
    environ['key'] = '\udcff\ud800\udc00'
    assert environ['key'] == '\udcff\ud800\udc00'
    # surrogateescape + backslashreplace -> surrogate escaped and backslash replacement
    environ = _TextEnviron

# Generated at 2022-06-23 14:34:54.160666
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    class _RawEnviron(object):
        def __init__(self, value):
            self.value = value
        def __iter__(self):
            return iter(self.value)
    assert sorted(['MY_KEY', 'MY_VALUE']) == sorted(list(_TextEnviron(_RawEnviron(['MY_KEY', 'MY_VALUE']))))

# Generated at 2022-06-23 14:34:55.463668
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Current environment should have at least one item 'PATH'
    assert len(environ) >= 1



# Generated at 2022-06-23 14:35:01.755455
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron(os.environ, encoding='utf-8')

    # This is the same as when we do this on Python 2
    assert isinstance(env.get(b'HOME'), str)

    # When we pass in a unicode string, we should get a unicode string back
    assert isinstance(env.get(u'HOME'), unicode)

# Generated at 2022-06-23 14:35:03.468638
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) >= 0
    assert len(_TextEnviron()) >= 0


# Generated at 2022-06-23 14:35:05.325034
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PYTHONUTF8'] == u'1'
    assert environ['PATH'] == u'...'


# Generated at 2022-06-23 14:35:14.992522
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['TEST_VALUE'] = '\xE9'
    assert environ['TEST_VALUE'] == '\u00e9'
    environ['FOO_BAR'] = 'FOO'
    assert environ['FOO_BAR'] == 'FOO'
    # The below case is worked around in the code.  If a user has an environment variable
    # which contains the same value as an already decoded environment variable, then the cached
    # value will be returned even if the environment variable changes.
    environ['TEST_VALUE'] = 'BAZ'
    assert environ['TEST_VALUE'] == '\u00e9'

# Generated at 2022-06-23 14:35:22.101877
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Tests for the _TextEnviron.__delitem__() method.
    """

    # Note: We can't use the normal mock.patch framework since that modifies the os.environ module
    # global.  We really want to modify .environ itself.
    env = _TextEnviron()
    env._raw_environ = {'a': 'b'}

    del env['a']
    assert env._raw_environ == {}



# Generated at 2022-06-23 14:35:24.269487
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['TEST'] = '1'
    assert 'TEST' in environ
    del environ['TEST']
    assert 'TEST' not in environ


# Generated at 2022-06-23 14:35:34.634007
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils.six import assertCountEqual

    source_env = os.environ.copy()
    try:
        # Set up some basic environment variables
        os.environ = {}
        os.environ['FOO'] = 'one'
        os.environ['BAR'] = 'two'
        os.environ['baz'] = 'three'

        assert len(os.environ) == 3
        assert len(_TextEnviron(env=os.environ)) == 3
        # Make sure we can mix keys with case
        assertCountEqual(_TextEnviron(env=os.environ), ['FOO', 'BAR', 'baz'])
    finally:
        os.environ = source_env



# Generated at 2022-06-23 14:35:38.639778
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    key = '_TextEnviron___delitem__'
    value = '_TextEnviron___delitem__'
    environ[key] = value
    assert key in environ
    del environ[key]
    assert key not in environ
    return


# Generated at 2022-06-23 14:35:40.552826
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['foo'] = b'\xef\xbb\xbf'
    assert environ['foo'] == u'\ufeff'

# Generated at 2022-06-23 14:35:45.384788
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import copy

    test_env = copy.copy(os.environ)
    assert not os.environ.pop('ANSIBLE_TEST_DELETED_ENV_VARIABLE')
    environ.__delitem__('ANSIBLE_TEST_DELETED_ENV_VARIABLE')
    assert not os.environ.pop('ANSIBLE_TEST_DELETED_ENV_VARIABLE')

    os.environ = test_env


# Generated at 2022-06-23 14:35:51.801494
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print(__name__)

    # None value
    print('\nNone value')
    print(environ['PATH'])

    # With native byte string
    print('\nWith native byte string')
    os.environ['PATH'] = b'/bin'
    print(environ['PATH'])
    print(type(environ['PATH']))

    # With unicode string
    print('\nWith unicode string')
    os.environ['PATH'] = u'/bin'
    print(environ['PATH'])
    print(type(environ['PATH']))

    # With unicode string in wrong local encoding
    print('\nWith unicode string in wrong local encoding')
    os.environ['PATH'] = u'/bin'.encode('gb2312')
    print(environ['PATH'])
    print

# Generated at 2022-06-23 14:35:56.396864
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ.clear()
    os.environ['CONFIG_FILE'] = './ansible.cfg'
    assert isinstance(environ, _TextEnviron)
    assert isinstance(environ['CONFIG_FILE'], str)
    assert isinstance(os.environ['CONFIG_FILE'], str)
    assert environ['CONFIG_FILE'] == os.environ['CONFIG_FILE']


# Generated at 2022-06-23 14:36:01.363897
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    test__TextEnviron___setitem__() -> None

    Unit test for _TextEnviron.__setitem__()
    """
    key = '    '
    key_chk = key or ' '
    value = 'testing'
    # Check initial status
    if key in environ:
        del environ[key]
    if key not in environ:
        environ[key] = value
    assert key_chk in environ._raw_environ
    # Check that environ stores the bytes
    assert environ[key_chk] == value
    del environ[key_chk]
    assert key_chk not in environ._raw_environ
    # Check that leading/trailing whitespace is stripped
    environ[key] = value
    assert key_chk in environ._raw_

# Generated at 2022-06-23 14:36:11.027971
# Unit test for method __setitem__ of class _TextEnviron

# Generated at 2022-06-23 14:36:21.144788
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import unittest
    from ansible.module_utils.six.moves.builtins import dict
    import tempfile

    class TestTextEnviron(unittest.TestCase):
        def setUp(self):
            self.env = to_bytes(dict(os.environ))
            self.encoding = 'utf-8'
            self.text_env = _TextEnviron(env=self.env, encoding=self.encoding)
            self.utf8_env = _TextEnviron(encoding=self.encoding)

        def tearDown(self):
            del self.text_env
            del self.utf8_env


# Generated at 2022-06-23 14:36:22.271992
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert _TextEnviron().__len__() > 5


# Generated at 2022-06-23 14:36:33.413508
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test basic construction
    env = _TextEnviron()
    for key, value in env.items():
        assert isinstance(key, six.text_type)
        assert isinstance(value, six.text_type)
    # Test the non-standard encoding
    env = _TextEnviron(encoding='latin-1')
    for key, value in env.items():
        assert isinstance(key, six.text_type)
        assert isinstance(value, six.text_type)

    # Test passing in an ordinary dictionary
    env = _TextEnviron({b'key1': b'value1', b'key2': b'value2'})
    if PY3:
        assert env[b'key1'] == b'value1'
        assert env[b'key2'] == b'value2'

# Generated at 2022-06-23 14:36:37.485119
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test the __getitem__ method of the _TextEnviron class.

    :returns: ``True`` on success, ``False`` otherwise
    :rtype: Bool
    """
    test_dict = {
        b'TestKey1': b'TestValue1',
        b'TestKey2': b'TestValue2',
    }
    environ_test = _TextEnviron(env=test_dict)

    if environ_test[b'TestKey1'] != u'TestValue1':
        return False
    if environ_test[b'TestKey2'] != u'TestValue2':
        return False

    return True


# Generated at 2022-06-23 14:36:38.663098
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert isinstance(environ['PATH'], str)

# Generated at 2022-06-23 14:36:41.080194
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron()
    return environ

if __name__ == '__main__':
    test__TextEnviron()

# Generated at 2022-06-23 14:36:47.083872
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    original_environ = environ._raw_environ.copy()
    environ.clear()
    # test when environ is empty
    environ_iter_result = list(environ.__iter__())
    assert environ_iter_result == []
    # test when environ is not empty
    environ['foo'] = 'bar'
    environ_iter_result = list(environ.__iter__())
    assert environ_iter_result == ['foo']
    # restore original environ
    environ._raw_environ = original_environ

# Generated at 2022-06-23 14:36:48.984412
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) > 0


# Generated at 2022-06-23 14:36:52.884075
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron()
    del env
    env = _TextEnviron({'hi': 'yes'})
    del env
    env = _TextEnviron(env={'hi': 'yes'})
    del env
    env = _TextEnviron(env={'hi': 'yes'}, encoding='latin1')
    del env

# Generated at 2022-06-23 14:36:57.626628
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    _environ = _TextEnviron({'PWD': '/home/user/', 'HOME': '/home/user/',
                              'SHELL': '/bin/bash'})
    assert set(_environ.__iter__()) == set(['PWD', 'HOME', 'SHELL'])



# Generated at 2022-06-23 14:37:03.840258
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ.clear()

    with pytest.raises(TypeError):
        # key should be text and not bytes
        environ[b'foo'] = to_bytes(u'bär')


# Generated at 2022-06-23 14:37:06.577984
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({"PYTHON": "2.7.5", "ANSIBLE": "2.6.1"})
    assert set(["PYTHON", "ANSIBLE"]) == set(env)


# Generated at 2022-06-23 14:37:16.419488
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    A _TextEnviron has a __getitem__ method which returns text strings instead of byte strings.
    """
    # Generate a dict using bytes to store the key and string.  We want to make sure that we can
    # get the dict by using a unicode string as a key or a byte string as a key.
    # Since environ is a global, we have to make sure we aren't overwriting the real environ.
    # We'll use a copy of it.
    environ = _TextEnviron({b'foo': u'bar'})
    # Use a unicode string as a key.  This should get back a text string
    assert environ[u'foo'] == 'bar'
    # Use a byte string as a key.  This should get back a text string
    assert environ['foo'] == 'bar'

# Generated at 2022-06-23 14:37:22.820292
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Test that the __delitem__ method of the _TextEnviron class deletes
    the specified key from the environment.
    """


# Generated at 2022-06-23 14:37:25.354683
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ_mock = _TextEnviron({'a': 'b'})
    assert len(list(environ_mock)) == 1


# Generated at 2022-06-23 14:37:31.182065
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a shallow copy of the original environment
    os_environ = os.environ.copy()

    # Create a new instance of the test class
    mock_environ = _TextEnviron(env=os_environ)

    # Check that the returned value is a text-type string
    assert isinstance(mock_environ['HOME'], str)
    # Check that the returned value is correct
    assert mock_environ['HOME'] == os_environ['HOME']



# Generated at 2022-06-23 14:37:33.035538
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron(encoding='us-ascii')
    for key, value in os.environ.items():
        assert environ[key] == value

# Generated at 2022-06-23 14:37:34.896957
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Make sure we can get a length of the environment
    assert isinstance(len(environ), int)


# Generated at 2022-06-23 14:37:38.165409
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Invalid encoding for _TextEnviron
    try:
        _TextEnviron(encoding=None)
        assert False
    except RuntimeError:
        pass

    # Test with a valid encoding
    t = _TextEnviron(encoding='utf-8')
    assert len(t) == len(os.environ)
    assert os.environ[b'PATH'] in t
    assert os.environ['PATH'] not in t



# Generated at 2022-06-23 14:37:42.241494
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    from ansible.module_utils._text import to_bytes, to_text

    environ_tmp = _TextEnviron(encoding='utf-8')
    key = "ANSIBLE_MODULE_UTILS_TEST"
    value = u"a test"
    environ_tmp[key] = value
    assert len(environ_tmp) == len(environ) + 1
    assert environ_tmp[key] == value
    del environ_tmp[key]
    assert len(environ_tmp) == len(environ)


# Generated at 2022-06-23 14:37:43.795316
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['delitem_key'] = 'delitem_value'
    del environ['delitem_key']
    assert 'delitem_key' not in environ
