

# Generated at 2022-06-23 14:27:51.493498
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Use case 1:
    # Verify that the methods raises a KeyError when the name of an environment variable is not
    # defined
    try:
        os.environ['FOOBAR_TEST']
    except KeyError:
        pass
    else:
        raise AssertionError('os.environ does not raise KeyError for undefined variable')

    try:
        environ['FOOBAR_TEST']
    except KeyError:
        pass
    else:
        raise AssertionError('environ does not raise KeyError for undefined variable')

    # Use case 2:
    # Verify that the methods raises a KeyError when the name of an environment variable is a None
    try:
        os.environ[None]
    except KeyError:
        pass

# Generated at 2022-06-23 14:28:00.089977
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # __init__ should not accept invalid encoding
    invalid_encoding = 'ascii'
    try:
        _TextEnviron(encoding=invalid_encoding)
        assert(False)
    except LookupError:
        assert(True)

    # __init__ should accept valid encoding
    valid_encoding = 'utf-8'
    try:
        _TextEnviron(encoding=valid_encoding)
        assert(True)
    except LookupError:
        assert(False)

    # __init__ should set encoding to utf-8 if no value is provided
    environ = _TextEnviron()
    assert(environ.encoding == 'utf-8')



# Generated at 2022-06-23 14:28:04.854624
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    _TextEnviron.__len__() returns the number of env vars set
    """
    env_len = len(environ)
    # We know that these env vars should be set so assert that the length is
    # more than these
    assert env_len > 2



# Generated at 2022-06-23 14:28:08.342543
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ['TEST_UNSET'] = 'a'
    test_env = _TextEnviron()
    del test_env['TEST_UNSET']
    assert 'TEST_UNSET' not in test_env



# Generated at 2022-06-23 14:28:15.225356
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import unittest
    import warnings
    class __TextEnviron___iter__(unittest.TestCase):
        # Test the iterator when the object is used as iterable
        def test_iterable(self):
            if not PY3:
                # On python 2, the iteration returns keys
                # whereas it returns items on python 3
                self.assertEqual(lambda: [k for k in environ],
                                 lambda: [k for k in environ._raw_environ])
            else:
                # On python 3, the iteration returns items
                # whereas it returns keys on python 2
                self.assertEqual(lambda: [(k, environ[k]) for k in environ],
                                 lambda: [(k, environ._raw_environ[k]) for k in environ._raw_environ])
    impl_details

# Generated at 2022-06-23 14:28:21.090486
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    assert 'ansible_utf8_test' not in os.environ

    # Create a test environment variable
    os.environ['ansible_utf8_test'] = 'Testenviron'
    assert 'ansible_utf8_test' in os.environ
    assert 'ansible_utf8_test' in environ
    del environ['ansible_utf8_test']

    assert 'ansible_utf8_test' not in os.environ
    assert 'ansible_utf8_test' not in environ


# Generated at 2022-06-23 14:28:24.263011
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    x = _TextEnviron()
    assert len(x)
    x = _TextEnviron({'X': 'Y'})
    assert len(x) == 1



# Generated at 2022-06-23 14:28:26.960841
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert (list(environ) == []) or (list(environ) == ['PATH', 'PYTHONPATH', 'PYTHONIOENCODING'])


# Generated at 2022-06-23 14:28:29.406833
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ_ = _TextEnviron(dict(A='B'))
    assert len(environ_) == 1



# Generated at 2022-06-23 14:28:33.756075
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    class _OSEnviron():
        def __init__(self):
            self._raw_environ = {}

        def __setitem__(self, key, value):
            self._raw_environ[key] = value

    osenviron = _OSEnviron()

    test_environ = _TextEnviron(env=osenviron, encoding='utf-8')
    test_environ.__setitem__('name', 'Тошио')
    assert osenviron._raw_environ['name'] == b'\xd0\xa2\xd0\xbe\xd1\x88\xd0\xb8\xd0\xbe'

    test_environ = _TextEnviron(env=osenviron, encoding='utf-8')

# Generated at 2022-06-23 14:28:40.284496
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils.common._collections_compat import MutableMapping
    assert(isinstance(environ, MutableMapping))
    assert(hasattr(environ, '__delitem__'))
    assert(hasattr(environ, '__getitem__'))
    assert(hasattr(environ, '__setitem__'))
    assert(hasattr(environ, '__iter__'))

# Generated at 2022-06-23 14:28:43.680740
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _TextEnviron.__delitem__(env={"a":1}, key = 1)
    _TextEnviron.__delitem__(env={"a":1}, key = 2)



# Generated at 2022-06-23 14:28:47.486622
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_env = {b'FOO': b'bar'}
    te = _TextEnviron(env=test_env)
    del te['FOO']
    assert 'FOO' not in te



# Generated at 2022-06-23 14:28:49.516850
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['key'] = 'value'
    assert(environ['key'] == 'value')

# Generated at 2022-06-23 14:28:52.482353
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    e = _TextEnviron()
    e['test_foo'] = u'foo'
    assert 'test_foo' in e
    assert e['test_foo'] == u'foo'



# Generated at 2022-06-23 14:28:54.597669
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import os
    del environ["MYTEST"]
    assert os.environ.get("MYTEST") == None


# Generated at 2022-06-23 14:28:59.161313
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Create a new environ object with value {'test':1}
    environ_ = _TextEnviron({'test': '1'})

    # Delete the key 'test'
    del environ_['test']

    # Assert the key 'test' is deleted
    assert 'test' not in environ_


# Generated at 2022-06-23 14:29:02.189889
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    d = {b'FOO': b'bar'}
    d1 = _TextEnviron(d)
    assert isinstance(iter(d1), type(iter(d)))



# Generated at 2022-06-23 14:29:04.225018
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    text_environ = _TextEnviron()
    assert text_environ['LANG'] == os.environ['LANG']

# Generated at 2022-06-23 14:29:09.846148
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # pylint: disable=wildcard-import,unused-wildcard-import
    from ansible.module_utils.common._text_environ import *
    # pylint: enable=wildcard-import,unused-wildcard-import
    from ansible.module_utils.six import PY2

    raw_environ = {
        'ukey': u'utf-8 value',
        # Note that the bkey value is a byte string.  This is what os.environ returns on Python2
        'bkey': b'utf-8 value',
    }
    # Handle the case where we're on Python3
    if PY3:
        raw_environ['utf8key'] = 'utf-8 value'
    # Handle the case where we're on Python2

# Generated at 2022-06-23 14:29:15.984435
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron(env={"test1": "testx", "test2": "testy"})
    for x in env:
        assert x in ["test1", "test2"]
    env = _TextEnviron()
    from ansible.module_utils.six.moves import builtins
    for x in env:
        assert x in builtins.__dict__



# Generated at 2022-06-23 14:29:19.393650
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({'ANSIBLE_INTERNAL_DATA': 'value'})
    del env['ANSIBLE_INTERNAL_DATA']
    assert 'ANSIBLE_INTERNAL_DATA' not in env


# Generated at 2022-06-23 14:29:20.893783
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['test'] = u'æ'
    assert environ['test'] == u'æ'


# Generated at 2022-06-23 14:29:23.346052
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    result = _TextEnviron()
    assert result._raw_environ is os.environ
    assert result.encoding == sys.getfilesystemencoding()

# vim: set expandtab ts=4 sw=4 fileencoding=utf-8:

# Generated at 2022-06-23 14:29:35.087272
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    '''
    Test method __setitem__ of class _TextEnviron
    '''
    class A():
        pass

    class B(A):
        pass

    class C(A):
        def __str__(self):
            return '3'

    class D(C):
        def __bytes__(self):
            return b'4'

    b_str = b'1'
    u_str = '2'
    b_str_obj = B()
    b_str_obj.__bytes__ = lambda self: b'1'
    u_str_obj = D()
    env = _TextEnviron(env={}, encoding='utf-8')
    env['k1'] = b_str
    assert env['k1'] == '1'
    env['k2'] = u_str

# Generated at 2022-06-23 14:29:39.977192
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    klass = _TextEnviron({}, 'utf-8')
    assert len(klass) == 0
    for key, value in (('foo', 'bar'), ('baz', 'qux'), ('quux', 'quuux')):
        klass[key] = value
        assert len(klass) == 3
        assert key in klass
        assert klass.__getitem__(key) == value


# Generated at 2022-06-23 14:29:51.235859
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron()
    original_value = os.environ.get('PATH', b'asdf')

    # Test that items can be set and retrieved
    environ['asdf'] = original_value
    assert environ['asdf'] == to_text(original_value)

    # Test that items can be deleted
    del environ['asdf']
    assert 'asdf' not in environ

    # Test that unicode objects are converted properly
    environ['asdf'] = to_text(original_value)
    assert environ['asdf'] == to_text(original_value)

    # Test that non-unicode objects can be set
    environ['asdf'] = original_value
    assert environ['asdf'] == to_text(original_value)

    # Test that non-unicode objects are

# Generated at 2022-06-23 14:29:52.428668
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)

# Generated at 2022-06-23 14:29:59.847499
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Basic function (already done in the base class)
    def test_TextEnviron_base_pass():
        # This test should pass but is not a good test because we don't do anything special
        # in the method being tested.
        environ_class = _TextEnviron()
        for key, value in os.environ.items():
            assert environ_class[key] == value

    # Failsafe in case someone changes the order of the assignments
    def test_TextEnviron_key_order_fail():
        # This test should fail, because we've assigned to self._raw_environ *after* we assign to
        # self._value_cache
        environ_class = _TextEnviron()
        environ_class._raw_environ = {'hi': 'hola'}
        environ_class._value_cache

# Generated at 2022-06-23 14:30:04.858692
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import os
    import sys

    # Test encode
    # We don't have to test unicode on PY3 because the code will
    # return the raw value from os.environ
    if not PY3:
        unicode_string = b'\xe1\x8a\xa0\xe1\x88\x9d'.decode('utf-8')

    # Test bytes on PY2
    if not PY3:
        os.environ['my_key'] = unicode_string
        assert os.environ['my_key'] == unicode_string

    # Test bytes on PY3
    if PY3:
        os.environb[b'my_key'] = b'my_value'
        assert os.environb[b'my_key'] == b'my_value'

   

# Generated at 2022-06-23 14:30:09.394948
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    '''_TextEnviron.__len__() returns the number of items in the dict'''
    # len()
    environ2 = _TextEnviron()
    assert len(environ2) == len(os.environ)


# Generated at 2022-06-23 14:30:18.980759
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    class TestEnv(object):
        def __init__(self):
            self.env_vars = {'PATH': 'foo'}
        def __iter__(self):
            return iter(['PATH'])
        def __getitem__(self, key):
            return self.env_vars.__getitem__(key)
        def __setitem__(self, key, value):
            self.env_vars.__setitem__(key, value)
        def __delitem__(self, key):
            self.env_vars.__delitem__(key)
        def __len__(self):
            return len(self.env_vars)

    assert list(environ) == list(environ._raw_environ)
    env = TestEnv()

# Generated at 2022-06-23 14:30:28.727997
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    test_env = {
        b'utf8_key': u'utf8_value'.encode('utf8'),
        'latin1_key': u'latin1_value'.encode('latin1'),
        # surrogateescape 0xdc00 is a surrogate so Windows will not produce a character
        u'unicode_key': u'unicode_value\udc00',
        'utf8_mix': u'utf8_value\udc00'.encode('utf8'),
    }
    # Test that we can initialize the class
    _TextEnviron(test_env)
    # Test that we can access the items in the class
    text_environ = _TextEnviron(test_env, encoding='latin1')
    assert text_environ['utf8_key'] == 'utf8_value'
    assert text

# Generated at 2022-06-23 14:30:40.164629
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # We aren't testing all the code paths here as that's done in other tests.
    # We will only test the codepaths which are different for Python < 3.
    if PY3:
        return
    # Check that the value is utf-8 encoded properly
    text_environ = _TextEnviron(encoding='utf-8')
    text_environ["abc"] = u"가이아자차카타파하"

    byte_environ = _TextEnviron(encoding='ascii')
    byte_environ["abc"] = u"가이아자차카타파하"

    # This value should fail when it's passed through to_bytes

# Generated at 2022-06-23 14:30:41.873962
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)

# Generated at 2022-06-23 14:30:50.787609
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    new_env = _TextEnviron(encoding='utf-8')
    assert __len__(new_env) == 0

    new_env = _TextEnviron(encoding='utf-8')
    __setitem__(new_env, 'firstkey', 'firstvalue')
    assert __len__(new_env) == 1

    new_env = _TextEnviron(encoding='utf-8')
    __setitem__(new_env, 'firstkey', 'firstvalue')
    __setitem__(new_env, 'secondkey', 'secondvalue')
    assert __len__(new_env) == 2


# Generated at 2022-06-23 14:30:52.396117
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({'FOO': 'bar'})
    assert len(env) == 1



# Generated at 2022-06-23 14:31:02.741611
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron({b'Foo': u'bar\ufffd'}, encoding='utf-8')
    assert environ[b'Foo'] == u'bar\ufffd'
    assert environ[u'Foo'] == u'bar\ufffd'
    assert environ[u'Foo'.encode('utf-8')] == u'bar\ufffd'

    environ = _TextEnviron({u'Foo': u'bar\ufffd'}, encoding='utf-8')
    assert environ[b'Foo'] == u'bar\ufffd'
    assert environ[u'Foo'] == u'bar\ufffd'
    assert environ[u'Foo'.encode('utf-8')] == u'bar\ufffd'


# Generated at 2022-06-23 14:31:08.054964
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping

    original_value = u'Foo'
    environ_mock = MutableMapping()
    environ_mock[b'ANSIBLE_CONFIG'] = original_value.encode('utf-8')

    te = _TextEnviron(environ_mock)
    value = te[b'ANSIBLE_CONFIG']
    assert(value == original_value)



# Generated at 2022-06-23 14:31:09.488123
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ) == ['PATH', 'PWD', 'TMP']


# Generated at 2022-06-23 14:31:12.835067
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron({b'foo': b'bar'})
    assert env[b'foo'] == u'bar'
    assert b'ascii' in env['LC_ALL']
    assert b'ascii' in env['LANG']
    assert b'ascii' in env['LANGUAGE']



# Generated at 2022-06-23 14:31:16.180281
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron()
    assert isinstance(environ['PATH'], str)

if __name__ == '__main__':
    test__TextEnviron()

# Generated at 2022-06-23 14:31:22.223140
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """Unit test for method __iter__ of class _TextEnviron"""
    # Arrange
    env = _TextEnviron(encoding='utf-8')
    env['My.Key'] = 'My Value'
    env['My.OtherKey'] = 'My Other Value'
    # Act
    result = list(env.__iter__())
    # Assert
    assert len(result) == len(env)
    assert 'My.Key' in result
    assert 'My.OtherKey' in result


# Generated at 2022-06-23 14:31:24.501398
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron()
    assert env.__iter__() == os.environ.__iter__()


# Generated at 2022-06-23 14:31:27.955558
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    expected_keys = ['PATH', 'HOME', 'RUN_COMPAT_DEBUG', 'ANSIBLE_CONFIG']

    assert set(environ.__iter__()) == set(expected_keys)

# Generated at 2022-06-23 14:31:36.096122
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ_test = _TextEnviron(dict(VAR_1=1, VAR_2=2, VAR_3=3))
    environ_test.__setitem__('VAR_4', 4)

    environment_test_iter = environ_test.__iter__()

    assert 'VAR_1' == next(environment_test_iter)
    assert 'VAR_2' == next(environment_test_iter)
    assert 'VAR_3' == next(environment_test_iter)
    assert 'VAR_4' == next(environment_test_iter)


# Generated at 2022-06-23 14:31:43.338688
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_environ = _TextEnviron(encoding='utf-8')
    test_key = "TEST_KEY"
    test_value = "TEST_VALUE"
    test_environ[test_key] = test_value

    assert test_environ[test_key] == test_value
    assert test_key in test_environ
    del test_environ[test_key]
    assert test_key not in test_environ


# Generated at 2022-06-23 14:31:50.506962
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ.clear()
    # Set env variable to be deleted
    environ['test__TextEnviron___delitem__'] = 'test_value'
    assert 'test__TextEnviron___delitem__' in environ
    assert environ['test__TextEnviron___delitem__'] == 'test_value'
    # Delete Set env variable
    del environ['test__TextEnviron___delitem__']
    assert 'test__TextEnviron___delitem__' not in environ


# Generated at 2022-06-23 14:31:58.898906
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    _environ = _TextEnviron()

    # test 1, that we can set a key to the value
    assert None == _environ.get('test_key')
    _environ['test_key'] = 'test_value'
    assert 'test_value' == _environ.get('test_key')
    del(_environ['test_key'])

    # test 2, that we can't set a text object to the key
    assert None == _environ.get('test_key')
    _environ['test_key'] = u'test_value'
    assert 'test_value' == _environ.get('test_key')
    del(_environ['test_key'])

    # test 3, that we can't set a text object to the value
    assert None == _environ.get('test_key')

# Generated at 2022-06-23 14:32:08.633678
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    old_environ = environ._raw_environ.copy()

# Generated at 2022-06-23 14:32:18.190593
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    e = _TextEnviron()
    e['b'] = 1
    assert(e['b'] == '1')
    e['b'] = b'1'
    assert(e['b'] == '1')
    e['b'] = '1'
    assert(e['b'] == '1')
    e['b'] = 1.0
    assert(e['b'] == '1.0')
    e['b'] = True
    assert(e['b'] == '1')
    e['b'] = None
    assert(e['b'] == 'None')
    e['b'] = ['1']
    assert(e['b'] == '1')
    e['b'] = ['1', '2']
    assert(e['b'] == "'1', '2'")
    # Test that we can't use an invalid

# Generated at 2022-06-23 14:32:24.513171
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ_backup = dict(environ)
    try:
        environ['TEST__TextEnviron___delitem__'] = 'test'
        del environ['TEST__TextEnviron___delitem__']
        assert 'TEST__TextEnviron___delitem__' not in environ
    finally:
        environ.clear()
        environ.update(environ_backup)


# Generated at 2022-06-23 14:32:35.230857
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # os.environ needs to get some data in it for the tests
    os.environ['TEST_GETITEM_1'] = 'abc'

    test_env = _TextEnviron(env={'TEST_GETITEM_2': 'def'})
    assert sys.getfilesystemencoding() == test_env.encoding

    if PY3:
        # We should be able to get the byte string out of the mapped value
        byte_str = b'TEST_GETITEM_1'
        assert byte_str == test_env[byte_str]
        assert byte_str == environ[byte_str]

    # We should be able to get the unicode string out of the mapped value
    unicode_str = u'TEST_GETITEM_1'

# Generated at 2022-06-23 14:32:42.482743
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import os

    os.environ["ANSIBLE_TEST_KEY"] = "Test Value"
    textenv = _TextEnviron()
    assert to_text(textenv["ANSIBLE_TEST_KEY"], errors='surrogate_or_strict') == "Test Value"


# Unit tests for the special methods of _TextEnviron
# We can get away with only testing for one of the following because we know the parent class does
# most of the work.  __getitem__ is tested in the constructor test above.

# Generated at 2022-06-23 14:32:49.992930
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import os
    import os.path
    import traceback

    # Set up vars
    var_name = 'ANSIBLE_TEST_VAR'
    var_value = 'this value is for testing'
    var_value_encoded = var_value.encode('utf-8')
    # Get current environment
    curr_environ = os.environ.copy()

# Generated at 2022-06-23 14:32:52.692838
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ._raw_environ) == len(environ)


# Generated at 2022-06-23 14:33:00.737108
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron({'text': 'foo'})
    assert len(env) == 1
    assert env['text'] == 'foo'
    env['text'] = 'bar'
    assert env['text'] == 'bar'
    del env['text']
    assert len(env) == 0

    env = _TextEnviron({b'text': b'foo'})
    assert len(env) == 1
    assert env['text'] == 'foo'
    env['text'] = 'bar'
    assert env['text'] == 'bar'
    del env['text']
    assert len(env) == 0

    env = _TextEnviron({b'text': 'foo'})
    assert len(env) == 1
    assert env['text'] == 'foo'
    env['text'] = 'bar'

# Generated at 2022-06-23 14:33:04.718374
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ.clear()
    environ['Abc'] = '1234'
    assert environ['Abc'] == '1234'
    environ['Abc'] = u'858g'
    assert environ['Abc'] == u'858g'



# Generated at 2022-06-23 14:33:12.122603
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    te = _TextEnviron(encoding='ascii')
    te['unicode_key'] = u'\u03b1'
    assert isinstance(te['unicode_key'], unicode if PY3 else str)
    assert b'unicode_key' in te._raw_environ
    assert u'unicode_key' in te
    assert te['unicode_key'] == u'\u03b1'
    assert te._raw_environ[b'unicode_key'] == b'\xce\xb1'  # '\u03b1' in latin1
    assert te._raw_environ[u'unicode_key'] == b'\xce\xb1'  # '\u03b1' in latin1


# Generated at 2022-06-23 14:33:20.538200
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test encoding initialization
    if not PY3:
        assert environ.encoding == 'utf-8'
    else:
        assert environ.encoding is None

    # Test environment initialization

# Generated at 2022-06-23 14:33:30.835241
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test that the module's "environ" instance is properly initialized to the right
    # default environment (e.g. not an empty dict)
    assert os.environ == environ._raw_environ

    # Test that we can set a new environment variable
    environ["FOO"] = "hello world"
    assert os.environ["FOO"] == "hello world"

    # Test that setting a unicode value works
    environ["FOO"] = u"\u1234"
    assert os.environ["FOO"] == b"\xe1\x88\xb4"

    del environ["FOO"]
    try:
        del os.environ["FOO"]
    except KeyError:
        pass


# Generated at 2022-06-23 14:33:38.055167
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # PY3
    assert isinstance(environ, _TextEnviron)
    assert isinstance(environ, MutableMapping)
    assert not isinstance(environ, MutableMapping)
    assert isinstance(environ._raw_environ, MutableMapping)
    if os.name == 'nt':
        assert isinstance(environ._raw_environ, MutableMapping)
    else:
        assert not isinstance(environ._raw_environ, MutableMapping)
    assert environ.encoding == sys.getfilesystemencoding()
    assert environ.encoding == sys.getfilesystemencoding()

# Generated at 2022-06-23 14:33:40.740025
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:33:43.400171
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    o = _TextEnviron({b'test': 'value'})
    for i in o:
        assert i == 'test'


# Generated at 2022-06-23 14:33:46.963742
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ_data = {'a': 'b', 'c': 'd'}
    text_environ = _TextEnviron(env=environ_data)
    assert len(text_environ) == 2


# Generated at 2022-06-23 14:33:58.314157
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """Test that __iter__ returns a unicode string"""

    import os
    from ansible.module_utils._text import to_text

    # Set default file system encoding to utf8
    os.environb['LANG'] = to_bytes('en_US.utf8')
    del os.environb['LANG']
    environ = _TextEnviron(encoding='utf-8')

    # Add text data to environ
    key = u'TEST_KEY'
    value = u'test\u03F7'
    environ[key] = value

    # Get text data from environ
    i = None
    for i in environ:
        break
    assert isinstance(i, text_type), "__iter__ did not return unicode string: %s" % to_native(type(i))



# Generated at 2022-06-23 14:34:04.601668
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    class TestEncoding(object):
        def __init__(self):
            self.called = []
        def __call__(self, *args, **kwargs):
            self.called.append((args, kwargs))
            return args[0]
    test_encoding = TestEncoding()
    orig_to_bytes = to_bytes

# Generated at 2022-06-23 14:34:08.072302
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    envar = _TextEnviron(None, 'utf-8')
    len = envar.__len__()
    assert len == len(envar._raw_environ)

# Generated at 2022-06-23 14:34:10.843084
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron(encoding='utf-8')
    env['TESTING'] = 'testing'
    del env['TESTING']
    env = _TextEnviron({'TESTING': 'testing'}, encoding='utf-8')
    assert len(env) == 1
    assert env['TESTING'] == u'testing'



# Generated at 2022-06-23 14:34:17.945692
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    my_env = _TextEnviron({'USER': 'foo', 'HOME': 'bar'})
    assert 'USER' in my_env and 'HOME' in my_env
    assert 'USER' not in my_env and 'HOME' not in my_env
    my_env[u'USER'] = u'foo'
    my_env[u'HOME'] = u'bar'
    assert 'USER' in my_env and 'HOME' in my_env
    assert 'USER' not in my_env and 'HOME' not in my_env


# Generated at 2022-06-23 14:34:19.143717
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = environ
    len = 0
    for key in env:
        len = len + 1
    assert(len == env.__len__())

# Generated at 2022-06-23 14:34:21.724602
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron(encoding='utf-8')
    assert type(env._raw_environ) is dict
    assert env._value_cache == {}
    assert env.encoding == 'utf-8'



# Generated at 2022-06-23 14:34:27.794607
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    e = _TextEnviron()
    e['key1'] = 1
    e['key2'] = '2'
    e['key3'] = u'3'
    assert e._raw_environ['key1'] == '1'
    assert e._raw_environ['key2'] == '2'
    assert e._raw_environ['key3'] == '3'


# Generated at 2022-06-23 14:34:37.267513
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test where raw value is of type bytes
    # test the case where the value is not utf-8 encoded
    if PY3:
        d = {b'foo': b'bar'}
    else:
        d = {u'foo': u'bar'}
    text_env = _TextEnviron(env=d)
    assert text_env['foo'] == u'bar'

    # Test where raw value is of type unicode
    d = {u'foo': u'bar'}
    text_env = _TextEnviron(env=d)
    assert text_env['foo'] == u'bar'

if __name__ == '__main__':
    test__TextEnviron___getitem__()

# Generated at 2022-06-23 14:34:43.188914
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Remove a non-unicode key
    TE = _TextEnviron()
    key = 'test'
    TE[key] = 'test'
    del TE[key]
    assert len(TE) == 0

    # Remove a unicode key
    key = '\u1234'
    TE[key] = '\u1234'
    del TE[key]
    assert len(TE) == 0


# Generated at 2022-06-23 14:34:51.644232
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import six
    import os
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping

    text = u"foo"
    byte = b"bar"

    # Test env building with ASCII strings
    expected_byte_str = text.encode('ascii')
    environ[text] = text
    assert isinstance(environ[text], six.text_type)
    assert environ[text] == text
    assert isinstance(environ._raw_environ[text], six.binary_type)
    assert environ._raw_environ[text] == expected_byte_str

    # Test env building with text strings that can't be encoded as utf-8
    expected_byte_str = byte
    environ

# Generated at 2022-06-23 14:34:56.149738
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env_list = os.listdir(os.environ['CWD'])
    env_list.sort()
    environ_list = [item for item in environ]
    environ_list.sort()
    assert env_list == environ_list


# Generated at 2022-06-23 14:34:58.683554
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    assert environ.get('PATH')
    environ.__delitem__('PATH')
    assert not environ.get('PATH')


# Generated at 2022-06-23 14:35:05.084291
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ_orig = environ

    # Test for empty environment
    environ = _TextEnviron({})
    assert len(environ) == 0

    # Test for not empty environment
    environ = _TextEnviron({b'ANSIBLE_FORCE_COLOR': b'1', b'ANSIBLE_PYTHON_INTERPRETER': b'/usr/bin/python3'})
    assert len(environ) == 2

    environ = environ_orig



# Generated at 2022-06-23 14:35:06.570374
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    assert len(env) == len(os.environ)



# Generated at 2022-06-23 14:35:09.382599
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({'b': 'a', 'a': 'c', 'c': 'b'})
    assert list(env) == ['b', 'a', 'c']



# Generated at 2022-06-23 14:35:16.263997
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    if PY3:
        assert 'ANSIBLE_FOO' not in environ
        environ['ANSIBLE_FOO'] = 'bar'
        assert 'ANSIBLE_FOO' in environ
        del environ['ANSIBLE_FOO']
        assert 'ANSIBLE_FOO' not in environ
    else:
        # Can't del on py2 environ because it's the system environ
        del environ


# Generated at 2022-06-23 14:35:18.564207
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    t_environ = _TextEnviron({'KEY': 'VALUE'}, encoding='utf-8')
    assert len(t_environ) == 1
    assert len(t_environ._raw_environ) == 1


# Generated at 2022-06-23 14:35:21.231071
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['test_var'] = 'test_value'
    assert b'test_value' == os.environ[b'test_var']



# Generated at 2022-06-23 14:35:25.493830
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create a new environment object with a simple unicode character in it
    test_env = _TextEnviron({b'test_var': b'test_\xc3\xa9'})
    # Test loading a variable which was put in with a unicode character in it
    assert test_env['test_var'] == 'test_é'


# Generated at 2022-06-23 14:35:29.998427
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import unittest

    test = _TextEnviron(encoding='utf-8')
    test.setdefault('TESTVAR', 'TESTVAL')
    assert len(test) == len(os.environ) + 1



# Generated at 2022-06-23 14:35:32.522459
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['Hello'] = 'World'
    del environ['Hello']
    assert 'Hello' not in environ


# Generated at 2022-06-23 14:35:40.863235
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import unittest
    from ansible.module_utils.six.moves import StringIO

    class _TextEnvironTestCase(unittest.TestCase):
        def _run_test(self, environ=None, expect_len=0):
            if environ is None:
                environ = _TextEnviron()
            self.assertEqual(expect_len, len(environ))

    suite = unittest.TestSuite()
    suite.addTest(unittest.FunctionTestCase(_TextEnvironTestCase()._run_test, buffer=True))
    suite.addTest(unittest.FunctionTestCase(_TextEnvironTestCase()._run_test,
                                            args=(dict(ANSIBLE_MODULE_DEBUG=True, OTHER_KEY=False), 2),
                                            buffer=True))


# Generated at 2022-06-23 14:35:49.848325
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    from ansible.module_utils.common._collections_compat import UserDict
    import os

    def call(env, encoding=None):
        text_environ = _TextEnviron(env=env, encoding=encoding)
        return text_environ

    # Test against empty dict
    tf = call({})
    assert isinstance(tf, _TextEnviron)
    assert isinstance(tf, MutableMapping)
    assert len(tf) == 0

    # Test against ordinary dict
    tf = call({'foo': 'bar', 'baz': 'qux'})
    assert isinstance(tf, _TextEnviron)
    assert isinstance(tf, MutableMapping)
    assert tf['foo'] == 'bar'
    assert tf['baz'] == 'qux'
    assert len(tf) == 2

# Generated at 2022-06-23 14:35:52.171905
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron()
    x = list(iter(env))
    assert isinstance(x, list)
    assert len(x) > 0


# Generated at 2022-06-23 14:35:57.001610
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron()

    # Added to ensure that the implementation is based on os.environ
    os.environ["ANSIBLE_TEST_KEY_1"] = "ANSIBLE_TEST_VALUE_1"
    os.environ["ANSIBLE_TEST_KEY_2"] = "ANSIBLE_TEST_VALUE_2"

    for key, value in env.items():
        assert type(key) is str
        assert type(value) is str

# Generated at 2022-06-23 14:36:03.312332
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Set a key-value pair in environ
    environ['key1'] = 'value1'
    # Retrieve the value of the key to check that the correct value is returned
    assert environ['key1'] == 'value1'

    # This test should not fail on Python3 as the values are kept in the same format as was
    # inserted into the dictionary
    if not PY3:
        # Set a key-value pair in environ
        environ['key2'] = b'value2'
        # Retrieve the value of the key to check that the correct value is returned
        assert environ['key2'] == 'value2'

        # Set a key-value pair in environ
        environ['key3'] = to_text('value3', encoding='utf-8')
        # Retrieve the value of the key to check that the

# Generated at 2022-06-23 14:36:08.689454
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    '''
    Unit test for method __iter__ of class _TextEnviron
    :return:
    '''
    environ_ = _TextEnviron(encoding='utf-8')

# Generated at 2022-06-23 14:36:14.585991
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Test for the number of keys in the environment
    """
    test_keys = ['one', 'two', 'three', 'four', 'five']
    test_data = dict(zip(test_keys, test_keys))
    new_environ = _TextEnviron(test_data, encoding='utf-8')
    assert len(test_keys) == len(new_environ)


# Generated at 2022-06-23 14:36:19.416024
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert True == isinstance(environ, _TextEnviron)
    os.environ['one'] = 'un'
    os.environ['two'] = 'duex'
    os.environ['three'] = 'trois'

    assert 3 == len(environ)

    del environ['two']
    assert 2 == len(environ)


# Generated at 2022-06-23 14:36:29.233977
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # This is nearly the same set of tests as the os.environ tests in the python stdlib,
    # with the change that strings in the value fields are unicode strings instead of
    # byte strings.

    env = _TextEnviron({'foo': 'bar'})
    assert len(env) == 1
    assert env['foo'] == 'bar'

    env['foo'] = 'gumby'
    assert len(env) == 1
    assert env['foo'] == 'gumby'

    var = 'foo' * 100  # a string longer than 256 bytes
    env[var] = 'gumby'
    assert len(env) == 2
    assert env[var] == 'gumby'

    del env['foo']
    assert len(env) == 1
    assert var in env

    del env[var]
   

# Generated at 2022-06-23 14:36:35.900084
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    from ansible.module_utils._text import to_bytes
    environ['TEST_VAR'] = u"Test value"
    assert environ['TEST_VAR'] == u"Test value"
    assert 'TEST_VAR' in environ
    assert b'Test value' == to_bytes(environ['TEST_VAR'], encoding='utf-8')
    del environ['TEST_VAR']
    assert 'TEST_VAR' not in environ


# Generated at 2022-06-23 14:36:40.786345
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['TESTENV'] == to_text('foobar', encoding='utf-8')
    # TESTENV exists as a byte string in this environment as well as an unicode string
    assert environ['TESTENV'] == to_text(u'foobar', encoding='utf-8')

# Generated at 2022-06-23 14:36:49.609530
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    class RawEnviron(dict):
        pass

    class _CachedEnviron(RawEnviron):
        def __getitem__(self, key):
            if key == "BADKEY":
                raise KeyError("BADKEY")
            return super(_CachedEnviron, self).__getitem__(key)
    _raw_environ = _CachedEnviron({"ABC": "some text", "BYTES": b"\xf4\x8f\xbf\xbf","BADKEY": "BADVALUE"})
    assert _raw_environ["ABC"] == "some text"
    assert _raw_environ["BADKEY"] == "BADVALUE"

    environ = _TextEnviron(env=_raw_environ, encoding='utf-8')

# Generated at 2022-06-23 14:36:55.756598
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    env = {b"FOO": u"bar", b"HELLO": "world"}
    test_environ = _TextEnviron(env=env)

    assert u"bar" == test_environ["FOO"]
    assert u"world" == test_environ["HELLO"]

    # Test the cache return
    env[b"HELLO"] = b"toto"
    assert u"toto" == test_environ["HELLO"]

    # Test that the cache picks up changes to the environment
    env[b"FOO"] = u"baz"
    assert u"baz" == test_environ["FOO"]



# Generated at 2022-06-23 14:37:06.324352
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Setup
    env_str = dict()

    # Test cases
    env_str['key_str'] = 'value_str'
    env_str['key_int'] = 1
    env_str['key_float'] = 1.0
    env_str['key_bool'] = True
    env_str['key_byt'] = b'value_byt'
    env_str['key_byt_nonascii'] = b'\xc3\xb1'
    env_str['key_byt_unicode'] = u'\xf1'.encode('utf-8')
    env_str['key_unicode_0'] = u'value_unicode_0'
    env_str['key_unicode_1'] = u'value_unicode_1'

# Generated at 2022-06-23 14:37:08.762945
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    assert len(env) == len(os.environ)


# Generated at 2022-06-23 14:37:12.674236
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import os
    # Cast to list is a workaround for a bug in Python 2.7.9, should be fixed in later versions
    assert list(environ) == list(os.environ)
    assert list(environ.keys()) == list(os.environ.keys())


# Generated at 2022-06-23 14:37:19.524574
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = {b'a': b'b', b'c': b'd'}
    myenv = _TextEnviron(env)
    assert len(env) == 2
    del myenv['a']
    assert len(env) == 1
    assert 'a' not in myenv
    assert 'a' not in env
    del myenv['c']
    assert len(env) == 0
    assert 'a' not in myenv
    assert 'c' not in myenv
    assert 'a' not in env
    assert 'c' not in env


# Generated at 2022-06-23 14:37:29.928486
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['TEST'] = 'Test string'
    assert type(environ['TEST']) is str
    assert environ['TEST'] == 'Test string'

    environ['TEST'] = 12345
    assert type(environ['TEST']) is str
    assert environ['TEST'] == '12345'

    if not PY3:
        environ['TEST'] = b'Test bytes'
        assert type(environ['TEST']) is str
        assert environ['TEST'] == 'Test bytes'

        environ['TEST'] = bytearray(b'Test bytearray')
        assert type(environ['TEST']) is str
        assert environ['TEST'] == 'Test bytearray'



# Generated at 2022-06-23 14:37:40.981508
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    class MyEnviron(object):
        def __init__(self):
            self.env = {}

        def __setitem__(self, key, value):
            self.env[key] = value

    myenv = MyEnviron()

    # Non-string types should be coerced to strings
    environ = _TextEnviron(env=myenv)
    environ['key'] = 10
    assert myenv.env['key'] == b"10"

    # Strings should get encoded without error
    environ['key'] = "unicode"
    assert myenv.env['key'] == b"unicode"

    # Invalid strings should raise a UnicodeEncodeError
    # TODO: unicode_faked_environ.__setitem__ should be a little smarter about figuring out the
    # encoding of non-ascii characters and not

# Generated at 2022-06-23 14:37:45.225052
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron(env={'foo': 'BAR'}, encoding='utf-8')
    env['foo']
    assert 'foo' in env, "Environment variable foo is not in the environment"
    env.__delitem__('foo')
    assert 'foo' not in env, "Environment variable foo still present in environment after deletion"

