

# Generated at 2022-06-23 14:27:43.888690
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    test_env = _TextEnviron({u'a': u'b'})
    assert len(test_env._raw_environ) == 1


# Generated at 2022-06-23 14:27:48.092953
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    item = 'TEST_ENV_VAR'
    lost_value = 'Hello I am being deleted'
    if item in environ:
        del environ[item]
    environ[item] = lost_value
    assert environ[item] == lost_value
    del environ[item]
    try:
        environ[item]
        assert False
    except KeyError:
        pass


# Generated at 2022-06-23 14:27:55.340699
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron()
    assert isinstance(env['PATH'], text_type)
    assert env['PATH'] == os.pathsep.join([
        os.path.join(os.getcwd(), 'functional', 'inventory'),
        os.path.join(os.getcwd(), 'functional', 'support', 'lib')
    ])
    assert isinstance(env, MutableMapping)
    assert len(env) == len(os.environ)

# Generated at 2022-06-23 14:27:59.921661
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    try:
        del environ['TEST__TEXTENVIRON__ITER']
    except KeyError:
        pass

    ensure_variable = False
    for key in environ:
        if key == 'TEST__TEXTENVIRON__ITER':
            ensure_variable = True
            break
    assert ensure_variable
    del environ['TEST__TEXTENVIRON__ITER']


# Generated at 2022-06-23 14:28:10.830339
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Make the sure the the environ is set to the correct value.
    """

    test_environment = {
        b'ANSIBLE_TEST': b'ANSIBLE_TEST_VALUE',
        u'ANSIBLE_TEST_UNICODE': u'ANSIBLE_TEST_UNICODE_VALUE',
        u'ANSIBLE_TEST_NON_ASCII': u'ANSIBLE_TEST_NON_ASCII_VALUE\u03a0',
    }

    # Update the os.environ with a dummy ANSIBLE_TEST variable,
    # and then delete the variable from os.environ at the end of the test
    os.environ.update(test_environment)


# Generated at 2022-06-23 14:28:15.179460
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    test_environ = _TextEnviron(env=dict(os.environ, TEST_ENVIRON_VAR='foo'))

    assert len(test_environ) == len(os.environ) + 1


# Generated at 2022-06-23 14:28:18.973875
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Basic test for class _TextEnviron, do not use it in code, just here
    to make sure coverage is 100%

    :return: None
    """
    environ = _TextEnviron()
    assert environ['HOME'] == '/var/tmp/ansible'

# Generated at 2022-06-23 14:28:20.919327
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['KEY_1'] = 'VALUE_1'
    del environ['KEY_1']


# Generated at 2022-06-23 14:28:31.445935
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """https://github.com/ansible/ansible/pull/51335#issuecomment-408604721"""
    class MockEnviron(MutableMapping):
        def __init__(self):
            self._raw_environ = {'ascii': 'value', 'unicode': u'\u20ac'}
        def __delitem__(self, key):
            del self._raw_environ[key]
        def __getitem__(self, key):
            return self._raw_environ[key]
        def __setitem__(self, key, value):
            self._raw_environ[key] = value
        def __iter__(self):
            return self._raw_environ.__iter__()
        def __len__(self):
            return len(self._raw_environ)

   

# Generated at 2022-06-23 14:28:36.193623
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    env.__setitem__('one', 'hello')
    env.__setitem__('b', 'world')
    assert len(env) == 2



# Generated at 2022-06-23 14:28:42.860205
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    os.environ.clear()
    os.environ['foo'] = b'test'
    os.environ['binary'] = b'\xff'
    os.environ['binary-utf8'] = b'\xc3\xb1'
    my_environ = _TextEnviron()
    assert 'foo' == my_environ['foo']
    assert u'\ufffd' == my_environ['binary']
    assert u'\u00f1' == my_environ['binary-utf8']



# Generated at 2022-06-23 14:28:53.878064
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import ansible.module_utils.six as six
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    # Note: Using os.environ directly would be a bad idea (if it was even possible) as it would
    # cause failures if someone had set the environment to something other than ascii.
    environ = _TextEnviron({'ascii': to_bytes('ascii_value', encoding='ascii'),
                            'utf8': to_bytes('utf8_value\u2713', encoding='utf-8')})
    assert b'ascii_value' == environ._raw_environ['ascii']
    assert 'ascii_value' == environ['ascii']


# Generated at 2022-06-23 14:28:57.129659
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    t = _TextEnviron()
    assert len(t) == len(environ)
    t['a'] = 'b'
    assert len(t) == (len(environ) + 1)

# Generated at 2022-06-23 14:29:06.488679
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # This function is a unit test that runs the constructor of class _TextEnviron.  We have to put
    # it in the global namespace because we need it to be imported across the tests.
    #
    # pylint: disable=pointless-string-statement
    u'This string will be encoded later'
    # pylint: enable=pointless-string-statement
    raw_env = {b'one': b'1',
               b'two': b'2',
               b'three': b'3',
               b'four': b'\xd7\x90',
               b'five': u'\u1234'}

    text_env = _TextEnviron(env=raw_env)
    assert raw_env == text_env._raw_environ
    assert text_env['one'] == u'1'


# Generated at 2022-06-23 14:29:10.616227
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ.clear()
    environ.update({'key1': 'value1', 'key2': 'value2'})
    assert frozenset(environ) == frozenset({'key1', 'key2'})


# Generated at 2022-06-23 14:29:14.168709
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    class DummyEnviron:
        def __iter__(self):
            return self

    assert "a" in _TextEnviron(DummyEnviron())
    assert "a" in _TextEnviron()

# Generated at 2022-06-23 14:29:23.150513
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    class TestEnviron(MutableMapping):
        def __init__(self, encoding='utf-8'):
            self.encoding = encoding
            self._environ = {'undecodable': b'\xAA\xAA\xAA'
                             }

        def __delitem__(self, key):
            del self._environ[key]

        def __getitem__(self, key):
            return self._environ[key]

        def __setitem__(self, key, value):
            self._environ[key] = value

        def __iter__(self):
            return self._environ.__iter__()

        def __len__(self):
            return len(self._environ)

    env = TestEnviron(encoding='utf-8')
    te_env = _TextEnviron

# Generated at 2022-06-23 14:29:30.972795
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    utf8_text = to_text(b'a\xcc\x8a', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    key = b'a\xcc\x8a'
    environ[key] = utf8_text
    assert environ.encoding == 'utf-8'
    assert environ._raw_environ[key] == b'a\xcc\x8a'

# Generated at 2022-06-23 14:29:32.360944
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert len(list(environ)) == len(environ)

# Generated at 2022-06-23 14:29:38.866479
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import os
    env_key = "ANSIBLETEST"
    env_value = "ANSIBLETEST"
    os.environ[env_key] = env_value

    env = _TextEnviron(encoding='utf-8')
    assert env_key in env
    del env[env_key]
    assert env_key not in env

    # KeyError
    try:
        del env[env_key]
    except KeyError:
        pass
    else:
        assert False, "Should raise KeyError."



# Generated at 2022-06-23 14:29:44.509175
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Test a plain environment
    environ["TEST_DELETE_1"] = "DELETE_ME"
    assert len(environ) == 1
    assert "TEST_DELETE_1" in environ
    del environ["TEST_DELETE_1"]
    assert "TEST_DELETE_1" not in environ
    assert len(environ) == 0


# Generated at 2022-06-23 14:29:54.860495
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Create a _TextEnviron with the default constructor
    text_environ = _TextEnviron(encoding='utf-8')
    # Create a _TextEnviron passing in an empty dict as the environment to test
    empty_environ = _TextEnviron({}, encoding='utf-8')

    # Test that the __getitem__ method can retrieve items as text when the key is passed in as
    # text
    assert text_environ[to_text('PATH')] == os.environ[to_text('PATH')]

    # Test that the __getitem__ method can retrieve items as text when the key is passed in as
    # bytes
    if not PY3:
        assert text_environ[to_bytes('PATH')] == os.environ[to_bytes('PATH')]

    # Test that the __getitem__ method returns

# Generated at 2022-06-23 14:30:00.964651
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    raw_environ = {}
    raw_environ['key1'] = 'value1'
    raw_environ['key2'] = 'value2'
    text_environ = _TextEnviron(env=raw_environ)
    assert len(raw_environ) == len(text_environ)
    assert set(raw_environ) == set(text_environ)



# Generated at 2022-06-23 14:30:07.965466
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Test the constructor.  Also test the __delitem__ and __setitem__ methods

    The dict values set in one of these ways:
        self._raw_environ[key] = value
    or
        del self._raw_environ[key]
    are not stored as text.  The only time the value is converted to text is when it's accessed
    via the __getitem__ method.  So we test here by setting a value with __setitem__, deleting
    that value with __delitem__, and then verifying that we get None from the __getitem__ method.
    The tests for __setitem__ and __getitem__ are duplicated above in the test of the module's
    environ variable.
    """

# Generated at 2022-06-23 14:30:10.419523
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    _TextEnviron._TextEnviron__getitem__(environ,'ansible_winrm_transport')

# Generated at 2022-06-23 14:30:15.749065
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    if not PY3:
        return

    foo = 'bar'
    expected_bytes = b'bar'
    env = _TextEnviron({'FOO': expected_bytes})
    assert 'FOO' in env
    assert env['FOO'] == foo
    assert env._raw_environ['FOO'] == expected_bytes



# Generated at 2022-06-23 14:30:22.703055
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Test that the constructor of _TextEnviron gets the environment from os.environ and
    gets the encoding from the sys module
    """
    mock_environ = {}
    mock_sys = {'getfilesystemencoding': 'foo'}
    env = _TextEnviron(env=mock_environ, sys=mock_sys)
    assert env._raw_environ == mock_environ
    assert env.encoding == 'foo'



# Generated at 2022-06-23 14:30:24.469954
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ_copy = environ.copy()
    for key in environ_copy:
        assert isinstance(key, str)


# Generated at 2022-06-23 14:30:35.242961
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-23 14:30:36.419477
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ['foo'] = 'bar'

    assert environ['foo'] == 'bar'

# Generated at 2022-06-23 14:30:44.056406
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _test_env = _TextEnviron()
    _test_env['test_constant'] = 'TEST_CONSTANT_VALUE'
    assert len(_test_env) == len(os.environ) + 1
    assert _test_env['test_constant'] == 'TEST_CONSTANT_VALUE'

    del _test_env['test_constant']

    assert len(_test_env) == len(os.environ)
    with pytest.raises(KeyError):
        _test_env['test_constant']


# Generated at 2022-06-23 14:30:49.446813
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    my_env = _TextEnviron({'TEST_VAR': 'test val', 'VAR_TO_DELETE': 'val'})
    assert len(my_env) == 2
    del my_env['VAR_TO_DELETE']
    assert len(my_env) == 1


# Generated at 2022-06-23 14:30:51.318079
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    length = len(os.environ)
    assert len(os.environ) == len(environ)



# Generated at 2022-06-23 14:30:54.016203
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    a = _TextEnviron()
    if PY3:
        assert isinstance(a['HOME'], str)
    else:
        assert isinstance(a['HOME'], unicode)


# Generated at 2022-06-23 14:30:57.469641
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Given
    keys = list(environ.keys())
    key = keys[0]
    # When
    del environ[key]
    # Then
    assert key not in environ



# Generated at 2022-06-23 14:31:02.072393
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Constructor
    env = _TextEnviron()
    # surrogate_or_strict should raise an error
    try:
        env['x'] = b'\xed\xa0\x80'
    except UnicodeDecodeError:
        pass
    else:
        raise AssertionError('UnicodeDecodeError expected when encoding non-unicode characters')


# Generated at 2022-06-23 14:31:08.222075
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Setup
    testenv = _TextEnviron({})
    set_item = 'a_key'
    set_value = 'a_value'
    testenv[set_item] = set_value
    del_item = 'a_second_key'
    del_value = 'a_second_value'
    testenv[del_item] = del_value

    # Test
    del testenv[del_item]

    # Verify
    assert del_item not in testenv
    assert testenv[set_item] == set_value


# Generated at 2022-06-23 14:31:11.476488
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """Remove an item from the environment"""
    environ['FOO'] = 'foo'
    assert 'FOO' in environ
    del environ['FOO']
    assert 'FOO' not in environ


# Generated at 2022-06-23 14:31:15.834864
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os.environ['test_var'] = 'test_var'
    assert isinstance(environ.__iter__(), type(os.environ.__iter__()))
    assert 'test_var' in environ



# Generated at 2022-06-23 14:31:18.882604
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron()
    environ['ANSIBLE_TEST'] = 'foo'
    assert isinstance(environ['ANSIBLE_TEST'], str)



# Generated at 2022-06-23 14:31:28.399915
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    with _TextEnviron() as text_environ:
        text_environ['a'] = 'a'
        assert isinstance(text_environ['a'], str)
        assert 'a' == text_environ['a']
        text_environ['b'] = b'b'
        assert isinstance(text_environ['b'], str)
        assert 'b' == text_environ['b']
        text_environ['c'] = u'c'
        assert isinstance(text_environ['c'], str)
        assert 'c' == text_environ['c']

# Generated at 2022-06-23 14:31:38.159839
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class _TestEnviron(MutableMapping):
        def __init__(self):
            self.environ = {'标准': "鸡蛋"}

        def __delitem__(self, key):
            del self.environ[key]

        def __getitem__(self, key):
            return self.environ[key]

        def __setitem__(self, key, value):
            self.environ[key] = value

        def __iter__(self):
            return self.environ.__iter__()

        def __len__(self):
            return len(self.environ)
    environ = _TextEnviron(_TestEnviron())
    assert environ['标准'] == u'鸡蛋'


# Generated at 2022-06-23 14:31:41.204184
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron({'key': 'value'})
    assert 1 == len(environ)



# Generated at 2022-06-23 14:31:52.270521
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_environ = _TextEnviron()
    # Accept str
    test_environ['str'] = 'str'
    assert isinstance(test_environ['str'], to_text(u'str'))
    # Accept bytes
    test_environ['bytes'] = b'bytes'
    assert isinstance(test_environ['bytes'], to_text(u'bytes'))
    # Accept unicode
    test_environ['unicode'] = u'unicode'
    assert isinstance(test_environ['unicode'], to_text(u'unicode'))
    # Skip None
    test_environ['none'] = None
    assert isinstance(test_environ['none'], to_text(u'None'))
    # Skip other types
    test_environ['int'] = 1
   

# Generated at 2022-06-23 14:31:59.882889
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import inspect


    test_environ = {}
    test_environ['FOO'] = b'BAR'
    test_environ['BS'] = b'\x00'
    test_environ['UNICODE'] = b'\xe4\xbd\xa0\xe5\xa5\xbd'
    # Test that passing in a dict for the environment works
    compl_run_env = _TextEnviron(env=test_environ)
    assert compl_run_env['FOO'] == 'BAR'
    assert compl_run_env['BS'] == '\x00'
    assert compl_run_env['UNICODE'] == u'你好'

    # Test that setting the encoding on the environment works

# Generated at 2022-06-23 14:32:11.268468
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    '''
    Test to verify when the method __iter__ of class _TextEnviron is called then the method
    __iter__ of class _TextEnviron is called.
    '''
    raw_environ = os.environ
    encoding = sys.getfilesystemencoding()
    environ2 = _TextEnviron(raw_environ, encoding)
    # Testing method __iter__ of class _TextEnviron
    environ2.__iter__()

# Generated at 2022-06-23 14:32:15.639389
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Test: regular os.environ
    original_environ = dict(os.environ)
    environ = _TextEnviron()
    assert isinstance(environ.__iter__(), type(os.environ.__iter__()))

    # Clean up: restore original os.environ
    os.environ = original_environ


# Generated at 2022-06-23 14:32:20.087246
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron(encoding='UTF-8')
    env["TEXT"] = "中文"
    # Regression test for bug #40323.
    # Should not raise an UnicodeEncodeError.
    env["TEXT"] = "foo"

# Generated at 2022-06-23 14:32:26.266869
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron({'foo': 'bar'}, encoding='latin-1')
    assert 'foo' in env
    assert env['foo'] == 'bar'
    assert env.encoding == 'latin-1'
    env['foo'] = 'baz'
    assert env['foo'] == 'baz'
    assert env._raw_environ['foo'] == 'baz'
    del env['foo']
    assert 'foo' not in env


# Generated at 2022-06-23 14:32:29.445313
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os.environ["TEST_KEY"] = "test_value"
    te = _TextEnviron()
    assert "TEST_KEY" in te
    assert te["TEST_KEY"] == "test_value"

# Generated at 2022-06-23 14:32:32.573197
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    my_environ = _TextEnviron({'1': '2', '3': '4'})
    assert len(my_environ) == 2



# Generated at 2022-06-23 14:32:35.881790
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    with environ.as_dict():
        environ['TextEnviron'] = 'should be removed'
        assert 'TextEnviron' in environ
        del environ['TextEnviron']
        assert 'TextEnviron' not in environ


# Generated at 2022-06-23 14:32:42.205656
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_environ = _TextEnviron()
    os.environ['ANSIBLE_TEST_FOO'] = to_bytes('Bar')
    assert 'ANSIBLE_TEST_FOO' in test_environ
    del test_environ['ANSIBLE_TEST_FOO']
    assert 'ANSIBLE_TEST_FOO' not in test_environ
    del os.environ['ANSIBLE_TEST_FOO']



# Generated at 2022-06-23 14:32:50.135839
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test the base functionality of the class.
    #   Equality should work on the dict storing the environment
    text_environ = _TextEnviron()
    assert text_environ.keys() == os.environ.keys()
    assert text_environ.values() == os.environ.values()
    assert text_environ.items() == os.environ.items()

    #   Equality should work on the dict storing the environment.  This time, we'll make
    #   our own dict.
    text_environ = _TextEnviron({b'foo': 'bar', b'baz': 'qux'})
    assert text_environ.keys() == {'foo', 'baz'}
    assert text_environ.values() == {'bar', 'qux'}

# Generated at 2022-06-23 14:32:59.453300
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a simple env variable with normal coding
    environ['PYTHON_VERSION'] = '3.6'
    assert environ['PYTHON_VERSION'] == u'3.6'
    # Test with a complex env variable with UTF coding
    environ['JEEVES'] = 'Jeeves È deretano'
    assert environ['JEEVES'] == u'Jeeves È deretano'
    # Test with a complex env variable with a non UTF codec
    environ['FANCY_ENCODING'] = b'\xe0\x20\xe8'
    assert environ['FANCY_ENCODING'] == u'\xe0\x20\xe8'



# Generated at 2022-06-23 14:33:09.072409
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """Test __setitem__ of class _TextEnviron"""
    # Test that it works with an empty dictionary
    env = _TextEnviron({}, encoding='utf-8')
    env['mykey'] = 'myvalue'
    assert env == {'mykey': 'myvalue'}

    # Test that it works with a non-empty dictionary
    env = _TextEnviron({'mykey': 'myvalue'}, encoding='utf-8')
    env['mykey'] = 'myvalue2'
    assert env == {'mykey': 'myvalue2'}

    # Test encoding unicode strings
    env = _TextEnviron({}, encoding='utf-8')
    env['mykey'] = u'non-ascii: \u20ac'

# Generated at 2022-06-23 14:33:18.407103
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Test the __len__ method.

    This test exists to validate that the environ mapping object correctly
    tracks the lenght of the underlying raw_environ object.  We cannot test
    that __len__ is accurate in general because:

    - We can't guarantee that all the environment variables will be present
      at the time we run the test
    - We can't reliably change the length of the environment variables because
      we cannot guarantee that the test runner will not set variables during
      the test run.
    - We can't reliably remove environment variables, for the same reason as
      above

    Instead, we'll test that the length is correct with one variable and then
    change the variable and check the length again to validate that it
    correctly tracks the length of the underlying dictionary.

    :returns: None
    :rtype: None
    """

# Generated at 2022-06-23 14:33:21.551833
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()

    value = env['PWD']
    assert isinstance(value, type(u''))
    assert type(env['PWD']) == unicode

# Generated at 2022-06-23 14:33:32.573358
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    raw_environ = {
        b'var_bytes': b'bytes',
        'var_unicode': u'unicode'
    }
    # Test passing a raw environment and encoding
    te = _TextEnviron(env=raw_environ, encoding='utf-8')
    assert isinstance(te['var_bytes'], str)
    assert te['var_bytes'] == u'bytes'
    assert isinstance(te['var_unicode'], str)
    assert te['var_unicode'] == u'unicode'

    # Test passing a raw environment and no encoding
    te = _TextEnviron(env=raw_environ)
    assert isinstance(te['var_bytes'], str)
    assert te['var_bytes'] == u'bytes'

# Generated at 2022-06-23 14:33:41.076918
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from os import environ
    from os import setenv
    from os import unsetenv
    # Test for standard method __iter__
    assert isinstance(_TextEnviron().__iter__(), type(environ.__iter__()))
    # Test for case when the environment is empty - no arguments
    assert isinstance(_TextEnviron(environ).__iter__(), type(environ.__iter__()))
    # Saving previous value of environment variable EXISTING_VAR
    try:
        saved_existing_var = environ["EXISTING_VAR"]
    except KeyError:
        saved_existing_var = ""
    # Defining new value of environment variable EXISTING_VAR
    if not "EXISTING_VAR" in environ:
        setenv("EXISTING_VAR", "1")
    # Test

# Generated at 2022-06-23 14:33:52.080619
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    test_dict = {'int': 1, 'float': 1.1, 'str': 'test str',
                 'bytes': b'test bytes', b'bytes key': 'str value',
                 'unicode': u'test unicode'}
    env = _TextEnviron(test_dict)

    assert len(env) == 6
    for key in test_dict:
        assert env[key] == to_text(test_dict[key], errors='surrogate_or_strict')

    # Bytes key is not handled specially.  It's converted with the same rules as other keys.
    assert env['bytes key'] == to_text(b'test bytes', errors='surrogate_or_strict')
    assert to_bytes(env['bytes key']) == b'test bytes'

    # Check the cache works
    assert env

# Generated at 2022-06-23 14:33:57.613663
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_env = os.environ.copy()
    test_env['TEST_VAR'] = 'A test variable'
    env = _TextEnviron(test_env)

    assert 'TEST_VAR' in env
    del env['TEST_VAR']
    assert 'TEST_VAR' not in env


# Generated at 2022-06-23 14:33:59.164641
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron()
    assert len(environ) == len(os.environ)

# Generated at 2022-06-23 14:34:10.116873
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import os
    environ = _TextEnviron()
    assert len(environ) == len(os.environ)
    # Adding a variable shouldn't change the length
    environ['test_variable_1'] = 'test_variable_1'
    assert len(environ) == len(os.environ)
    # Deleting a variable shouldn't change the length
    del environ['test_variable_1']
    assert len(environ) == len(os.environ)
    # Deleting a variable that was never set should fail
    try:
        del environ['test_variable_1']
    except KeyError:
        pass
    else:
        raise AssertionError('Did not throw KeyError on nonexistent variable delete')


# Generated at 2022-06-23 14:34:20.274800
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ.clear()
    environ['LANG'] = 'C'
    environ['HOME'] = '/home/kabadger'
    assert environ['LANG'] == 'C'
    assert environ['HOME'] == '/home/kabadger'
    environ['LANG'] = 'en_US.UTF-8'
    assert environ['LANG'] == 'en_US.UTF-8'
    assert environ['HOME'] == '/home/kabadger'
    del environ['LANG']
    assert environ['HOME'] == '/home/kabadger'
    try:
        environ['LANG']
    except KeyError as e:
        assert e.args[0] == 'LANG'
    else:
        raise AssertionError('env[LANG] should have raised a KeyError')



# Generated at 2022-06-23 14:34:24.610364
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Test that __delitem__ works properly.
    """
    original_environ = environ._raw_environ
    del environ['PWD']
    assert 'PWD' not in environ._raw_environ
    environ._raw_environ = original_environ



# Generated at 2022-06-23 14:34:26.897025
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    result = environ.__iter__()
    assert (result is not None)


# Generated at 2022-06-23 14:34:30.662868
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['TEST_ENV_VAR'] = "42"
    assert 'TEST_ENV_VAR' in environ
    del environ['TEST_ENV_VAR']
    assert 'TEST_ENV_VAR' not in environ


# Generated at 2022-06-23 14:34:32.813816
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    textenviron = _TextEnviron(encoding='utf-8')
    assert len(textenviron) == len(os.environ)


# Generated at 2022-06-23 14:34:36.824685
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    text_environ = _TextEnviron(encoding='utf-8')
    length = len(text_environ)
    assert isinstance(length, int)
    pass


# Generated at 2022-06-23 14:34:42.359016
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Test base case
    te = _TextEnviron()
    assert len(te._raw_environ) == len(te)

    # Test adding a new key
    te['foo'] = 'bar'
    assert len(te._raw_environ) == len(te)

    # Test deleting a key
    del te['foo']
    assert len(te._raw_environ) == len(te)



# Generated at 2022-06-23 14:34:50.924373
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    def check_equal(val1, val2):
        assert val1 == val2

    environ = _TextEnviron({b'KEY1': b'value1'}, b'utf-8')
    check_equal(b'value1', environ[b'KEY1'])
    check_equal(u'value1', environ[u'KEY1'])
    check_equal(b'value1', environ.get(u'KEY1'))
    check_equal(u'value1', environ.get(b'KEY1'))
    check_equal(u'value1', environ.get(u'KEY1'))
    check_equal(b'value1', environ.get(b'KEY1'))


# Generated at 2022-06-23 14:34:55.808224
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    class fakeEnv:
        def __init__(self):
            self.dict = {'bytes': b'value', 'text': u'value'}

        def __getitem__(self, key):
            return self.dict[key]

        def __setitem__(self, key, value):
            self.dict[key] = value

        def __delitem__(self, key):
            del self.dict[key]

        def clear(self):
            self.dict.clear()

        def __contains__(self, item):
            return item in self.dict

        def __iter__(self):
            return iter(self.dict)

        def __len__(self):
            return len(self.dict)

        def copy(self):
            return self.dict.copy()

    raw_env = fakeEnv

# Generated at 2022-06-23 14:34:59.465554
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['TEST_VAR'] = 'test value'
    if PY3:
        assert environ['TEST_VAR'] == 'test value'
    else:
        assert environ['TEST_VAR'] == u'test value'

# Generated at 2022-06-23 14:35:08.785054
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Configure python2 to return a unicode object
    environ.encoding = 'utf-8'
    instr = {b'key1': u'value1'.encode('utf-8'), b'key2': b'value2'}
    outstr = {'key1': b'value1'.decode('utf-8'), 'key2': b'value2'}
    new_env = _TextEnviron(env=instr)
    for (key, value) in outstr.items():
        assert new_env[key] == value
    # Configure python2 to return a byte string
    environ.encoding = 'latin-1'
    instr = {b'key1': u'value1'.encode('utf-8'), b'key2': b'value2'}

# Generated at 2022-06-23 14:35:18.766290
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import unittest
    import subprocess

    class TestEnviron(unittest.TestCase):
        def setUp(self):
            self.env = _TextEnviron()
            self.orig_env = dict(self.env)
            self.env['foo'] = 'bar'
            self.env['baz'] = to_bytes('qux', encoding='utf-16-le')

        def tearDown(self):
            self.env.clear()
            self.env.update(self.orig_env)

        def test_getitem(self):
            self.assertEqual(self.env['foo'], 'bar')
            self.assertEqual(self.env['baz'], u'qux')


# Generated at 2022-06-23 14:35:20.168489
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:35:23.858261
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import os
    os.environ.update({'FOO': 'BAR', 'ZED': 'ZEE'})
    env = _TextEnviron()
    assert set(env.__iter__()) == set(['FOO', 'ZED'])


# Generated at 2022-06-23 14:35:30.919363
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ['ANSIBLE_TEST'] = '1'
    assert len(environ) == len(os.environ)
    environ['ANSIBLE_TEST'] = '2'
    assert len(environ) == len(os.environ)
    del environ['ANSIBLE_TEST']
    assert len(environ) == len(os.environ)
    del os.environ['ANSIBLE_TEST']


# Generated at 2022-06-23 14:35:35.666217
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Add a couple of non-ascii values to os.environ
    environ['日本語'] = '平仮名'
    environ['myè'] = 'à'
    assert environ['日本語'] == '平仮名'
    assert environ['myè'] == 'à'

# Generated at 2022-06-23 14:35:44.376342
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Unit test for method __setitem__ of class _TextEnviron
    """
    import os

    # Create a TestEnviron object instance with empty raw_environ
    T_raw_environ = {}
    T_encoding = 'utf-8'

    TestEnviron = _TextEnviron(T_raw_environ, T_encoding)

    # Test with empty "value"
    key = 'testing_key'
    value = ''
    TestEnviron[key] = value
    assert T_raw_environ[key] == b''

    # Test with simple string "value"
    key = 'testing_key'
    value = 'testing_value'
    TestEnviron[key] = value

# Generated at 2022-06-23 14:35:47.967041
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = {}
    environ["A"] = "A"
    environ["B"] = "B"
    environ["C"] = "C"
    text_environ = _TextEnviron(environ, encoding='utf-8')
    assert len(environ) == 3
    for key in text_environ:
        assert key in environ

# Generated at 2022-06-23 14:35:55.164992
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils.six import assertCountEqual
    from ansible.module_utils.six import string_types

    env = _TextEnviron({b'foo': b'bar', b'baz': b'qux'})

    # Query __len__ for its return value
    ret = len(env)

    assert isinstance(ret, int), "Expected {0} to be an instance of {1}".format(ret, int)
    assert ret == 2, 'Expected "{0}" to be "{1}"'.format(ret, '2')



# Generated at 2022-06-23 14:35:57.792690
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ = {'A': 'B'}
    e = _TextEnviron()
    assert len(e) == 1



# Generated at 2022-06-23 14:35:59.202434
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ) == list(os.environ)


# Generated at 2022-06-23 14:36:10.057712
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    '''
    Test the _TextEnviron class constructor
    '''
    # Test by providing the class the current environment which is the default
    env = _TextEnviron()
    assert len(env) == len(os.environ)
    for key in env:
        assert key in os.environ
        assert env[key] == os.environ[key]

    # Test by providing a dictionary that's a copy of the current environment
    new_env = os.environ.copy()
    env = _TextEnviron(env=new_env)
    assert len(env) == len(os.environ)
    for key in env:
        assert key in os.environ
        assert env[key] == os.environ[key]

    # Test by providing a dictionary with an additional key
    new_env = os.environ

# Generated at 2022-06-23 14:36:20.534446
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that on Python3, the environment variable is just returned
    environ_getitem_py3 = environ.__getitem__
    assert 'some value' == environ_getitem_py3('PY3_TEST_VAR')
    # Test that the converted values are cached
    environ['PY2_TEST_VAR'] = b'\xED\x95\x98'
    assert '長' == environ_getitem_py3('PY2_TEST_VAR')
    # Change the value of the environment variable
    os.environ['PY2_TEST_VAR'] = b'\xE7\xBB\xAD'
    # Test that the cached value is returned rather than the new value of the environment variable
    assert '長' == environ_getitem

# Generated at 2022-06-23 14:36:24.928734
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = {}
    env['key1'] = 'value1'
    env['key2'] = 'value2'
    env['key3'] = 'value3'

    text_env = _TextEnviron(env)
    assert sorted(list(text_env.__iter__())) == sorted(list(env.__iter__()))



# Generated at 2022-06-23 14:36:28.235552
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    len_env = len(env)
    len_os_env = len(os.environ)
    assert len_env == len_os_env



# Generated at 2022-06-23 14:36:37.507040
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Check that it returns the unicode decoded value when running on Python2
    environ['ANSIBLE_TEST_KEY'] = u'\u3042\u3044\u3046'
    if PY3:
        assert environ[b'ANSIBLE_TEST_KEY'] == u'\u3042\u3044\u3046'
    else:
        assert environ['ANSIBLE_TEST_KEY'] == u'\u3042\u3044\u3046'

    # Check that it returns the unicode decoded value when running on Python2
    environ[b'ANSIBLE_TEST_KEY'] = '\xe3\x81\x82\xe3\x81\x84\xe3\x81\x86'

# Generated at 2022-06-23 14:36:44.596672
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """
    Unit test for method __iter__ of class _TextEnviron
    """
    os_environ = _TestEnviron(env={"test1" : b"1", "test2" : "2", "test3" : "3"})
    test_environ = _TextEnviron(env=os_environ, encoding='utf-8')

    assert set(["test1", "test2", "test3"]) == set([x for x in test_environ])


# Generated at 2022-06-23 14:36:50.056869
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    real_environ = os.environ
    os.environ = {'foo': to_bytes('bar', encoding=sys.getfilesystemencoding())}

    t_environ = _TextEnviron()

    assert list(t_environ) == ['foo']

    os.environ = real_environ


# Generated at 2022-06-23 14:36:56.601742
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    '''
    Basic test for the constructor of class _TextEnviron

    The __setitem__ test is at the bottom of the file.
    '''
    # We don't need to test when PY3 is True since the main point of this class is to mimic Python3
    # behaviour on Python2.
    if PY3:
        return
    env = os.environ
    t = _TextEnviron(env)
    encoding = sys.getfilesystemencoding()
    assert t._raw_environ is env
    assert t._value_cache == {}
    assert t.encoding == encoding
    t = _TextEnviron(env, encoding='ascii')
    assert t._raw_environ is env
    assert t._value_cache == {}
    assert t.encoding == 'ascii'
    t = _Text

# Generated at 2022-06-23 14:37:02.948861
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    with environ.patch(ANSIBLE_TEST=b'\xe2\x9c\x94'):
        # We're expecting bytes from environ but as unicode from our class
        # So we define ANSIBLE_TEST as a unicode string here
        assert ('ANSIBLE_TEST' in environ) and (environ['ANSIBLE_TEST'] == u'\u2714')

# Generated at 2022-06-23 14:37:13.606986
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    '''
    Test that _TextEnviron.__setitem__ converts strings correctly to bytes

    Validate that:
        * bytes in are bytes out
        * unicode in are bytes out
        * nonstring types in raise TypeError
    '''
    import io
    from ansible.module_utils.six import BytesIO

    env = _TextEnviron(encoding='utf-8')
    env['bytes_value'] = b'foo'
    assert env['bytes_value'] == b'foo'

    env['unicode_value'] = u'bar\u00e9'
    assert env['unicode_value'] == b'bar\xc3\xa9'

    fd_output = BytesIO()
    env['file_value'] = io.open(__file__, 'rb')

# Generated at 2022-06-23 14:37:14.874774
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # An empty environment should return no keys
    assert len(environ) == 0



# Generated at 2022-06-23 14:37:16.499004
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """Test if length of _TextEnviron object is same as os.environ."""
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:37:20.684672
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)  # pylint: disable=len-as-condition
    environ.clear()
    assert len(environ) == 0
    os.environ['ANSIBLE_FOOBAR'] = ''
    assert len(environ) == 1
    del environ['ANSIBLE_FOOBAR']
    assert len(environ) == 0


# Generated at 2022-06-23 14:37:25.687637
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Assert that setting to a text value works
    environ['key'] = u'value'
    assert environ['key'] == u'value'

    # Assert that setting to bytes works as expected
    environ['key'] = b'value'
    assert environ['key'] == u'value'

test__TextEnviron___setitem__()

# Generated at 2022-06-23 14:37:27.587699
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:37:30.793054
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Test counting length of _TextEnviron initialized with empty dictionary
    assert len(_TextEnviron(env={})) == 0
    # Test counting length of _TextEnviron initialized with environ dictionary
    assert len(_TextEnviron(env=environ)) > 0


# Generated at 2022-06-23 14:37:41.228526
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['_ANSIBLE_TEST_BYTES_ENCODING_1'] = '1\xc2\xb2\xc2\xb3'
    os.environ['_ANSIBLE_TEST_BYTES_ENCODING_2'] = '2\xc3\x82\xc3\x83'
    os.environ['_ANSIBLE_TEST_BYTES_ENCODING_3'] = '3\xe2\x82\xac'
    os.environ['_ANSIBLE_TEST_BYTES_ENCODING_4'] = '4\xe4\xbd\xa0\xe5\xa5\xbd'

    global environ
    environ = _TextEnviron(encoding='utf-8')


# Generated at 2022-06-23 14:37:45.061689
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils._text import to_bytes, to_text

    # unit test for _TextEnviron.__len__()
    environ_len = len(environ)
    if environ_len == 0:
        raise Exception("Testcase failed, environ is empty!")
