

# Generated at 2022-06-23 14:27:45.525885
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:27:50.080749
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    dict_ = _TextEnviron()
    env_var = 'test__TextEnviron___delitem__'
    dict_[env_var] = 'foo'
    assert len(dict_.keys()) == 1
    dict_.__delitem__(env_var)
    assert len(dict_.keys()) == 0



# Generated at 2022-06-23 14:27:54.613093
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    text = u'\u4ffe'
    #environ[u'LANG'] = text
    #print(text, ": LANG = ", environ[u'LANG'])

if __name__ == '__main__':
    test__TextEnviron___setitem__()

# Generated at 2022-06-23 14:28:00.183012
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Ensures that _TextEnviron acts as expected
    """
    env = _TextEnviron(encoding='utf-8')
    assert env['PYTHONPATH'] == os.environ['PYTHONPATH']
    if not PY3:
        # Python2 puts an extra colon on the end of the path
        assert env['PYTHONPATH'] == os.environ['PYTHONPATH'] + ':'
    assert env.encoding == 'utf-8'

# Generated at 2022-06-23 14:28:02.863489
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron(encoding='utf-8', env={'a': '1'})
    assert len(environ) == 1



# Generated at 2022-06-23 14:28:07.395368
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_dict = {
        'foo': 'bar',
    }
    te = _TextEnviron(env=environ_dict)
    assert isinstance(te['foo'], text_type)
    assert te['foo'] == u'bar'


# Generated at 2022-06-23 14:28:09.053910
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron()
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:28:11.876210
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert hasattr(environ, '__iter__')
    assert callable(environ.__iter__)
    for key in os.environ:
        assert key in environ


# Generated at 2022-06-23 14:28:21.286436
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test encoding related things.
    # PY2 will never have bytes in os.environ so we don't test those
    if PY3:
        # os.environ keys and values are always str objects
        # This will create an environ object which has str keys and values
        environ = _TextEnviron(env={'a': 'b'})
        assert isinstance(environ['a'], str)

        # Let's make a dict which has bytes keys and values
        # We'll use a dict which is only allowed to contain bytes
        # This is an equivalent of str(b'a') for bytes
        key_bytes = b'a'
        assert isinstance(key_bytes, bytes)
        value_bytes = b'b'
        env_bytes_keys_bytes_values = {key_bytes: value_bytes}

# Generated at 2022-06-23 14:28:31.772685
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():

    import os
    import random
    import string

    module = sys.modules[__name__]

    # Test with populated environment
    env_len = len(os.environ)
    module_len = len(module.environ)
    assert env_len == module_len

    # Test with empty environment
    env_len = 0
    for key in os.environ.keys():
        del os.environ[key]
    assert len(os.environ) == env_len
    assert len(module.environ) == env_len

    # Test with one item in environment
    key = ''.join(random.choice(string.ascii_lowercase) for _ in range(8))
    os.environ[key] = key
    assert len(os.environ) == env_len + 1

# Generated at 2022-06-23 14:28:33.838872
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:28:37.533460
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from os import environ
    text_environ = _TextEnviron(environ, 'utf-8')
    assert len(environ) == len(text_environ)

# Generated at 2022-06-23 14:28:42.923980
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    e = _TextEnviron()
    e['Key1'] = 'Value1'
    assert e['Key1'] == 'Value1'
    e['Key2'] = u'\u1234'
    assert e['Key2'] == u'\u1234'
    e['Key2'] = b'\xe1\x88\xb4'
    assert e['Key2'] == u'\u1234'


# Generated at 2022-06-23 14:28:46.260488
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    global environ
    environ['key'] = 'value'
    assert environ['key'] == 'value'
    del environ['key']
    assert environ.get('key', None) == None


# Generated at 2022-06-23 14:28:55.612567
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env_copy = os.environ.copy()
    test_environ = _TextEnviron(env=env_copy)
    try:
        test_environ["testing"] = "testing_value"
        assert "testing" in test_environ
        assert test_environ["testing"] == to_text("testing_value", encoding=test_environ.encoding,
                                                  nonstring='passthru', errors='surrogate_or_strict')
    finally:
        # For coverage we need to trigger the finally block
        # pylint: disable=redefined-variable-type
        test_environ = environ
        # pylint: enable=redefined-variable-type

# Generated at 2022-06-23 14:28:57.254834
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():

    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:29:06.557234
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import tempfile
    with tempfile.TemporaryDirectory() as tempdir:
        yp_file = os.path.join(tempdir, 'yp.txt')
        with open(yp_file, 'wb') as fo:
            fo.write(b'\x00\x01\x02\x03\x04')
        environ_copy = dict(os.environ)
        environ_copy.update({'ANSIBLE_TEST_A': 'ANSIBLE_TEST_B', 'ANSIBLE_TEST_C': yp_file})
        _TextEnviron(environ_copy).get('ANSIBLE_TEST_A') == 'ANSIBLE_TEST_B'
        _TextEnviron(environ_copy).get('ANSIBLE_TEST_C') == yp_file



# Generated at 2022-06-23 14:29:11.434186
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = os.environ.copy()
    env[b"FOO"] = b"BAR"
    env[b'baz'] = b"fop"
    te = _TextEnviron(env)
    assert len(te) == 2



# Generated at 2022-06-23 14:29:21.343251
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import pytest
    test_data = {
        'a': 'a',
        'b': u'b',
        'c': 'a\xe9',
        'd': u'a\xe9',
        'e': 'a\xc3\xa9',
        'f': u'a\xc3\xa9',
        # g is a byte string that is not valid utf-8.  Handled by surrogateescape
        'g': 'a\xe9'.encode('latin-1'),
        # h is an invalid surrogate
        'h': '\ud800'
    }
    # Test that environ is correctly loading both the keys and the values
    for key, value in test_data.items():
        environ[key] = value
        assert environ[key] == key

    # Test that getting or setting

# Generated at 2022-06-23 14:29:23.276861
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == 0

test__TextEnviron___len__()


# Generated at 2022-06-23 14:29:34.211706
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    in_environ = {'a': '1', 'b': '2', 'c': '3'}
    # if we try to get values from a TextEnviron with no encoding set they should be bytes
    x = _TextEnviron(env=in_environ)
    assert x['a'] == b'1'
    assert x['b'] == b'2'
    assert x['c'] == b'3'
    # if we try to get values from a TextEnviron with an encoding set they should be text
    x = _TextEnviron(env=in_environ, encoding='utf-8')
    assert x['a'] == '1'
    assert x['b'] == '2'
    assert x['c'] == '3'



# Generated at 2022-06-23 14:29:36.742732
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()
    env['test'] = 'foo'
    assert env['test'] == 'foo'
    assert env._raw_environ['test'] == b'foo'

# Generated at 2022-06-23 14:29:43.409763
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Checks to make sure __delitem__ removes the key from os.environ and has no residual effects
    """
    environ['MY_NEW_ENV_VAR'] = 'env_var_value'
    assert 'MY_NEW_ENV_VAR' in environ
    del environ['MY_NEW_ENV_VAR']
    assert 'MY_NEW_ENV_VAR' not in environ
    assert 'MY_NEW_ENV_VAR' not in os.environ
    for envvar in environ:
        assert isinstance(environ[envvar], str)



# Generated at 2022-06-23 14:29:44.407738
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) >= 0


# Generated at 2022-06-23 14:29:50.285160
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils.six import PY2
    if PY2:
        return  # Noop on Python2 where this is already the case

    e = _TextEnviron()
    e['foo'] = 'bar'
    assert e['foo'] == 'bar'
    assert e._raw_environ['foo'] == b'bar'


# Generated at 2022-06-23 14:29:54.064611
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ_orig = environ._raw_environ
    environ._raw_environ = {'a': '1', 'b': '2', 'c': '3'}
    assert len(environ) == 3
    environ._raw_environ = environ_orig



# Generated at 2022-06-23 14:30:04.275393
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Values that already are bytes should be passed through unchanged
    testenv = _TextEnviron()
    rawkey = b'RAWKEY'
    rawvalue = b'RAWVALUE'
    testenv[rawkey] = rawvalue
    assert type(testenv._raw_environ[rawkey]) is bytes
    assert rawvalue == testenv._raw_environ[rawkey]

    # Values that are unicode should be converted to bytes before saving
    testenv = _TextEnviron()
    textkey = u'TEXTKEY'
    textvalue = u'TEXTVALUE'
    testenv[textkey] = textvalue
    assert type(testenv._raw_environ[textkey]) is bytes
    assert b'TEXTVALUE' == testenv._raw_environ[textkey]

    # Values that are strings should be encoded before saving

# Generated at 2022-06-23 14:30:12.659618
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    a_dict = _TextEnviron()
    keys = [key for key in a_dict]
    assert keys == [], 'all keys: %s in dict %s' % (keys, a_dict)
    os.environ['ANSIBLE_TEST_VAR'] = 'ANSIBLE_TEST_VALUE'
    keys = [key for key in a_dict]
    assert keys == ['ANSIBLE_TEST_VAR'], 'all keys: %s in dict %s' % (keys, a_dict)
    del os.environ['ANSIBLE_TEST_VAR']



# Generated at 2022-06-23 14:30:18.955340
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    _test_env = environ
    _test_env['test'] = 'test_value'
    _test_env['test2'] = 'test_value2'
    assert _test_env['test'] == 'test_value'
    assert _test_env['test2'] == 'test_value2'
    assert len(_test_env) == 2
    del _test_env['test']
    assert len(_test_env) == 1
    assert _test_env['test2'] == 'test_value2'
    assert 'test' not in _test_env



# Generated at 2022-06-23 14:30:23.037029
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_cases = [('create_parser', 'ansible.module_utils.basic.create_parser')]

    for parameter, expected in test_cases:
        result = environ.__getitem__(parameter)
        assert result == expected, 'getitem failed for {0}, expected: {1}, got: {2}'.format(parameter, expected, result)



# Generated at 2022-06-23 14:30:27.812335
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Create new mapping
    mapping = _TextEnviron()
    # Populate with test data
    mapping['foo'] = u'bar'
    mapping['baz'] = b'quux'
    # Check results
    assert isinstance(mapping['foo'], str)
    assert isinstance(mapping['baz'], str)
    assert mapping['foo'] == u'bar'
    assert mapping['baz'] == u'quux'


# Generated at 2022-06-23 14:30:35.353826
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Test the following:
    1. __setitem__ accepts unicode keys
    2. __setitem__ accepts unicode values
    3. __setitem__ accepts byte strings as keys
    4. __setitem__ accepts byte strings as values
    5. __setitem__ accepts other non-string objects as values
    6. __setitem__ encodes non-ascii unicode values into bytes using the set encoding
    """

# Generated at 2022-06-23 14:30:36.064052
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == 0


# Generated at 2022-06-23 14:30:45.518445
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test not covered by _test_six_py3_environ_mapping
    import tempfile
    import subprocess
    import shlex
    import os

    test_environ = _TextEnviron()
    test_environ['test'] = 'test_value'
    test_environ['from_subprocess'] = 'subprocess_value'

    with tempfile.NamedTemporaryFile(suffix='.py') as py3_script:
        py3_script.write(b"""
#!/usr/bin/python3
import os

print('test: ' + os.environ['test'])
print('subprocess_value: ' + os.environ['from_subprocess'])
print('subprocess_value: ' + os.environ['subprocess_value'])
""")

# Generated at 2022-06-23 14:30:49.317541
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({'a': 'b'})
    assert list(env) == list(env.keys())
    assert set(env) == set(env.keys())
    assert list(env.__iter__()) == list(env.keys())

# Generated at 2022-06-23 14:30:51.365193
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = {to_text('a'): to_text('b')}
    text_env = _TextEnviron(env)
    assert {'a': 'b'} == text_env

# Generated at 2022-06-23 14:30:54.302477
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['TEST_VAR'] = 'test'
    assert 'TEST_VAR' in environ
    del environ['TEST_VAR']
    assert 'TEST_VAR' not in environ


# Generated at 2022-06-23 14:31:03.862180
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # The standard encoding for unit tests on Python 2.7 (and presumably for other Python versions)
    # is ASCII.
    if PY3:
        environ = _TextEnviron(encoding='utf-8')
        # PY3
        # os.environ returns text
        environ['test1'] = 'UTF-8-TEST'
        assert isinstance(environ['test1'], str)
        environ['test2'] = '\xe3\x81\x82ABC'
        assert isinstance(environ['test2'], str)
        assert environ['test2'] == 'あABC'
    else:
        environ = _TextEnviron(encoding='ascii')
        # os.environ returns bytes
        environ['test1'] = 'ASCII-TEST'
        assert isinstance

# Generated at 2022-06-23 14:31:05.529434
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert tuple(environ) == tuple(os.environ)

# Generated at 2022-06-23 14:31:09.632421
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test for setitem.
    environ['foo'] = 1
    assert environ['foo'] == '1'

    # Test for setitem with utf-8 encoding.
    environ['foo'] = '1€'
    assert environ['foo'] == '1€'

    # Test for setitem with surrogate_or_strict errors handler.
    environ['foo'] = 'â'
    assert environ['foo'] == 'â'

# Generated at 2022-06-23 14:31:10.431049
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    pass


# Generated at 2022-06-23 14:31:21.596554
# Unit test for constructor of class _TextEnviron

# Generated at 2022-06-23 14:31:24.252102
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    keys = environ.keys()
    assert len(environ) == len(keys), "IMHO 'len(environ)' should equal 'len(environ.keys())'"


# Generated at 2022-06-23 14:31:35.388564
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class TestEnv(MutableMapping):
        def __init__(self, env=None):
            if env is None:
                env = {}
            self._raw_environ = env

        def __delitem__(self, key):
            del self._raw_environ[key]

        def __getitem__(self, key):
            return self._raw_environ[key]

        def __setitem__(self, key, value):
            self._raw_environ[key] = value

        def __iter__(self):
            return self._raw_environ.__iter__()

        def __len__(self):
            return len(self._raw_environ)

    # Test with a native string from the default utf-8 encoding

# Generated at 2022-06-23 14:31:46.114959
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, _TextEnviron)
    assert 'HOME' in environ
    assert 'HOME' in environ._raw_environ
    # Make sure that the environment variable's value is cached
    binary_value = os.environ['HOME']
    cached_value = environ.__getitem__('HOME')
    assert cached_value == os.environ['HOME']
    assert cached_value == environ['HOME']
    assert environ['HOME'] == cached_value
    assert cached_value == binary_value.decode('utf-8')
    assert cached_value in environ._value_cache
    assert binary_value in environ._value_cache
    assert environ._value_cache[cached_value] == cached_value
    assert environ._value_cache[binary_value] == cached_value




# Generated at 2022-06-23 14:31:51.502457
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    test_dict = {'first': 'first_value', 'second': 'second_value'}
    test_obj = _TextEnviron(test_dict)

    method_output = test_obj.__iter__()
    expected_output = dict.__iter__(test_dict)
    assert((method_output) == expected_output)



# Generated at 2022-06-23 14:31:57.395110
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['first'] = u'foo'
    environ['second'] = u'bar'
    assert environ['first'] == u'foo'
    assert environ['second'] == u'bar'
    del environ['first']
    del environ['second']
    try:
        assert environ['first'] == u'foo'
        assert False
    except KeyError:
        pass

    try:
        assert environ['second'] == u'bar'
        assert False
    except KeyError:
        pass


# Generated at 2022-06-23 14:32:07.464343
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Unit test for method __setitem__ of class _TextEnviron
    """
    class TestCase:
        def __init__(self, name, key, value, expect=None, exception=None):
            self.name = name
            self.key = key
            self.value = value
            self.expect = expect
            self.exception = exception

    testcases = [
        TestCase('valid key and value 1 byte', 'foo', 'bar', expect='bar'),
        TestCase('valid key and value 2 byte', 'foo', u'☃', expect=u'☃'),
        TestCase('valid key and invalid value type', 'foo', 4, exception=TypeError),
        TestCase('invalid key type', 4, 'bar', exception=TypeError),
    ]

    for tc in testcases:
        environ

# Generated at 2022-06-23 14:32:17.607154
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = dict(os.environ)
    env['BYTES_KEY'] = b'bytes value'
    env['UNICODE_KEY'] = u'unicode value'

    # Test is_unicode is True and is_bytes is False
    environ_test = _TextEnviron(env=env, encoding='utf-8')
    key_list = list(environ_test.__iter__())
    assert u'BYTES_KEY' in key_list
    assert u'UNICODE_KEY' in key_list
    assert u'bytes value' in key_list
    assert u'unicode value' in key_list

    # Test is_unicode is True and is_bytes is True
    environ_test = _TextEnviron(env=env, encoding='utf-16')

# Generated at 2022-06-23 14:32:27.806833
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    ascii_value = u'abcde'
    utf8_value = u'\u20ac'

    # By default, creation of a _TextEnviron object uses the same encoding as os.environ (Python2)
    # or sys.getfilesystemencoding() (Python3)
    if PY3:
        # On Python3, environ is created with text values so just test that we get the same data out
        # as was put in
        environ_py3 = _TextEnviron({'ascii': ascii_value, 'utf8': utf8_value})
        assert environ_py3['ascii'] == ascii_value
        assert environ_py3['utf8'] == utf8_value

# Generated at 2022-06-23 14:32:38.988355
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Test bytes input to __setitem__

    According to PEP-383, bytes strings that are not valid UTF-8 should be passed through
    unmodified.
    """

    # PEP-383 source: https://www.python.org/dev/peps/pep-0383/#surrogates
    # Note: This is Python3 source.  Since we're testing against a Python2 environment, turn the
    # bytes into ascii bytes

# Generated at 2022-06-23 14:32:42.798429
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    _TEST_ENV = _TextEnviron({'TEST_1': 'VALUE_1', 'TEST_2': 'VALUE_2'})
    assert set(_TEST_ENV.__iter__()) == {'TEST_1', 'TEST_2'}

# Generated at 2022-06-23 14:32:44.158666
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(iter(environ)) == list(iter(os.environ))


# Generated at 2022-06-23 14:32:45.986247
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['name'] = 'value'
    assert isinstance(environ._raw_environ['name'], bytes)



# Generated at 2022-06-23 14:32:47.912181
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PWD'].__class__.__name__ == 'unicode'



# Generated at 2022-06-23 14:32:55.648607
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test with str and unicode input
    bytes_arg = b"foo"
    str_arg = u"foo"
    text_environ = _TextEnviron()
    text_environ[str_arg] = str_arg
    text_environ[bytes_arg] = bytes_arg
    assert text_environ["foo"] == "foo"
    text_environ[str_arg] = bytes_arg
    text_environ[bytes_arg] = str_arg
    assert text_environ[b"foo"] == "foo"

# Generated at 2022-06-23 14:33:01.102643
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({u'foo': u'bar'})
    assert len(env) == len({u'foo': u'bar'})
    env = _TextEnviron({b'foo': b'bar'})
    assert len(env) == len({b'foo': b'bar'})
    env = _TextEnviron({b'foo': u'bar'})
    assert len(env) == len({b'foo': u'bar'})
    env = _TextEnviron({u'foo': b'bar'})
    assert len(env) == len({u'foo': b'bar'})


# Generated at 2022-06-23 14:33:05.390766
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ[str('test__TextEnviron___delitem__')] = 'test__TextEnviron___delitem__'
    del environ[str('test__TextEnviron___delitem__')]
    assert not 'test__TextEnviron___delitem__' in environ


# Generated at 2022-06-23 14:33:07.700809
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({'a': 'b', 'c': 'd'})
    assert len(env) == 2



# Generated at 2022-06-23 14:33:17.207478
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    r"""
    Unit test for method _TextEnviron.__delitem__
    """
    #
    # Tests for method __delitem__ of class _TextEnviron.
    #
    # This test uses the following data:
    #
    # Data frame with the following columns:
    #   key   -    str -> Key name
    #   value -    str -> Value to set in the environment
    #   want  -  bytes -> Expected value of the environment variable
    #   error - boolean -> True if we expect an error to be raised by setting the environment
    #                      variable
    #

# Generated at 2022-06-23 14:33:25.747713
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    def _test(env, result):
        te = _TextEnviron(env)
        assert set(te) == result
        assert set(iter(te)) == result
        assert set(list(te)) == result
    _test(['var1=value1'], set(['var1']))
    _test(['var1=value1', 'var2=value2'], set(['var1', 'var2']))
    _test(['var1=value1', 'var3=value3', 'var2=value2'], set(['var2', 'var3', 'var1']))

# Generated at 2022-06-23 14:33:36.340887
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    for test_name, raw_environ, key, expected_del_result, expected_len, expected_get_error in (
            ('str', {'simple': 'value'}, 'simple', None, 0, KeyError),
            ('bytes', {b'simple': b'value'}, b'simple', None, 0, KeyError),
            ('unicode', {u'simple': u'value'}, u'simple', None, 0, KeyError)):
        environ_ = _TextEnviron(env=raw_environ)
        del environ_[key]
        assert len(environ_) == expected_len, \
            '{}: Length should be {} != {}'.format(test_name, len(environ_), expected_len)

# Generated at 2022-06-23 14:33:39.354531
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({b'k1': b'v1', to_bytes('k2'): to_bytes('v2')})

    d = dict(env)

    assert d == {'k1': 'v1', 'k2': 'v2'}

# Generated at 2022-06-23 14:33:50.951598
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron({u'HELLO': u'Hello world!', u'BYTES': b'This is bytes'}, encoding='utf-8')
    assert env[u'HELLO'] == u'Hello world!'
    assert isinstance(env[u'HELLO'], text_type)
    assert env[u'BYTES'] == u'This is bytes'
    assert isinstance(env[u'BYTES'], text_type)
    env[u'HELLO'] = b'\xd0\x9f\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82!'
    assert env[u'HELLO'] == u'Привет!'

    env = _TextEnviron()

# Generated at 2022-06-23 14:33:54.079089
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)

if __name__ == '__main__':
    test__TextEnviron___len__()

# Generated at 2022-06-23 14:33:59.007716
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    class env:
        def __iter__(self):
            return iter(['key1', 'key2', 'key3'])
    env = _TextEnviron(env=env())
    result = set(iter(env))
    expected_result = set(['key1', 'key2', 'key3'])
    assert result == expected_result


# Generated at 2022-06-23 14:34:06.882438
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Unit test for method __iter__ of class _TextEnviron
    # Simple test to verify the iterator is working
    os.environ['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'
    for key in environ:
        assert key == 'ANSIBLE_TEST_KEY'
        assert environ[key] == 'ANSIBLE_TEST_VALUE'
    else:
        # Shouldn't get here since the loop should be broken out of
        assert False

# Generated at 2022-06-23 14:34:17.265079
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_data = [
        ('key_bytes', b'this is a byte string'),
        ('key_text', 'this is a unicode string'),
        ('key_bytes_nonascii', b'this is a byte string with a non-ascii char: \xc3\xb1'),
        ('key_text_nonascii', 'this is a unicode string with a non-ascii char: \xc3\xb1'),
    ]

# Generated at 2022-06-23 14:34:18.510039
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
  environ = _TextEnviron(encoding='utf-8')
  assert len(environ) >= 1


# Generated at 2022-06-23 14:34:20.312453
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # test for type error: 'str' object does not support item assignment
    assert environ['TEST_VAR'] == ''



# Generated at 2022-06-23 14:34:24.965935
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    before = os.environ
    if b'FOO' in before:
        del before[b'FOO']
    after = before.copy()
    environ[u'FOO'] = u'bar'
    del environ[u'FOO']
    assert after == os.environ
    assert before == os.environ


# Generated at 2022-06-23 14:34:28.508846
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    if PY3:
        # Already used in Python3
        assert environ.__iter__ == environ._raw_environ.__iter__
    else:
        assert iter(environ) == environ._raw_environ

# Generated at 2022-06-23 14:34:35.300230
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils._text import to_text
    environ = _TextEnviron()
    text_obj = to_text(u'\u5f20', encoding=environ.encoding, nonstring='strict', errors='surrogate_or_strict')
    environ['A'] = text_obj
    environ._raw_environ['B'] = text_obj

    assert text_obj is environ._raw_environ['A']
    assert text_obj is environ._raw_environ['B']


# Generated at 2022-06-23 14:34:42.587242
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)
    assert len(environ) > 0
    import random
    random_value = str(random.randint(-2**32, 2**32))
    os.environ[random_value] = random_value
    temp_environ = _TextEnviron(env={random_value: random_value})
    assert len(temp_environ) == 1
    assert len(temp_environ) == len(os.environ)
    del os.environ[random_value]


# Generated at 2022-06-23 14:34:45.726329
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron(encoding='utf-8')
    env['foo'] = u'bar'
    assert env['foo'] == u'bar'
    env['foo'] = b'bar'
    assert env['foo'] == u'bar'

# Generated at 2022-06-23 14:34:50.323863
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    old_environ = os.environ
    os.environ = {b'ANSIBLE_MODULE_ARGS': "--tags=test",
                  b'ANSIBLE_FOO': 'foo',
                  b'ANSIBLE_BAR': 'bar',
                  }
    assert set(environ) == {'ANSIBLE_MODULE_ARGS', 'ANSIBLE_FOO', 'ANSIBLE_BAR'}
    os.environ = old_environ


# Generated at 2022-06-23 14:34:51.645963
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ) == list(os.environ)



# Generated at 2022-06-23 14:34:52.695093
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ.__iter__()) == list(os.environ.__iter__())



# Generated at 2022-06-23 14:34:57.347358
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils.six import PY3
    text_environ = _TextEnviron(encoding='utf-8')

    if PY3:
        text_environ['key'] = 'value'
        assert text_environ._raw_environ['key'] == 'value'

    text_environ['key1'] = 'value1'
    assert text_environ._raw_environ['key1'] == b'value1'
    assert text_environ['key1'] == 'value1'

# Generated at 2022-06-23 14:35:07.093950
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test cases:

    1) When the environment variable is defined in os.environ with type text
    2) When the environment variable is defined in os.environ with type bytes
    3) When the environment variable is not defined in os.environ
    """
    t = _TextEnviron(encoding='utf-8')
    if PY3:
        e = os.environ
    else:
        e = {'no_exist': 'no_exist'}

    assert e['no_exist'] == to_text(t['no_exist'], 'utf-8', 'strict')
    e['exist'] = 'exist'
    assert to_text(e['exist'], 'utf-8', 'strict') == t['exist']
    e['exist'] = b'exist'

# Generated at 2022-06-23 14:35:14.348905
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Test a case of deleting an item.
    """
    # This is a temporary envrionment variable setup for this unit test
    environ["test__TextEnviron___delitem__"] = "test"
    assert environ["test__TextEnviron___delitem__"] == "test"
    del environ["test__TextEnviron___delitem__"]
    assert "test__TextEnviron___delitem__" not in environ


# Generated at 2022-06-23 14:35:20.641194
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():

    os.environ[b'ANSIBLE_TEST_KEY'] = b'ansible'
    assert b'ANSIBLE_TEST_KEY' in os.environ
    assert os.environ[b'ANSIBLE_TEST_KEY'] == b'ansible'
    del os.environ[b'ANSIBLE_TEST_KEY']

    os.environ['ANSIBLE_TEST_KEY'] = 'ansible'
    assert 'ANSIBLE_TEST_KEY' in os.environ
    assert os.environ['ANSIBLE_TEST_KEY'] == 'ansible'
    del os.environ['ANSIBLE_TEST_KEY']

    os.environ['ANSIBLE_TEST_KEY'] = u'ansible'
    assert 'ANSIBLE_TEST_KEY' in os.environ

# Generated at 2022-06-23 14:35:31.058219
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    class _DummyEnviron(dict):
        def __setitem__(self, key, value):
            self.__dict__[key] = value

    os.environ = _DummyEnviron()

    environ['ascii'] = 'foo'
    assert os.environ.__dict__ == {'ascii': b'foo'}
    assert environ['ascii'] == 'foo'

    environ['unicode'] = u'föö'
    assert os.environ.__dict__ == {'ascii': b'foo', 'unicode': u'föö'.encode('utf-8')}
    assert environ['unicode'] == u'föö'


# Generated at 2022-06-23 14:35:40.142134
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    os.environ['ANSIBLE_TEST_1'] = 'This string contains utf8: 是否'
    os.environ['ANSIBLE_TEST_2'] = b'This string contains utf8: \xd6\x96\xd6\x95'

    # Test when the constructor is called with an encoding
    test_environ = _TextEnviron(encoding='utf-8')
    assert test_environ['ANSIBLE_TEST_1'] == u'This string contains utf8: 是否'
    assert test_environ['ANSIBLE_TEST_2'] == u'This string contains utf8: \xd6\x96\xd6\x95'

    # Test when the constructor is called with no encoding
    test_environ = _TextEnviron()
    assert test_en

# Generated at 2022-06-23 14:35:47.015925
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test non-py3
    # No test needed.  The function is just a wrapper around os.environ's getitem
    # Test py3
    import six
    # Test using internal cache
    v1 = b'foo'
    v2 = 'bar'
    v3 = u'baz'
    env = _TextEnviron({'v1': v1})
    env.encoding = 'utf-8'
    assert env['v1'] == 'foo'
    assert env['v1'] == 'foo'
    env['v2'] = v2
    assert env['v2'] == 'bar'
    # Test clearing cache
    env.clear()
    assert env['v2'] == 'bar'
    assert env['v2'] == 'bar'
    del env['v2']
    assert env['v1']

# Generated at 2022-06-23 14:35:57.144416
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron()
    # Test that we return text when PY3 is set.  Don't set PY3 here, the actual class
    # uses the interpreter version
    if PY3:
        assert isinstance(env['HOME'], str)
    else:
        assert isinstance(env['HOME'], unicode)

    # Test that we accept a custom encoding
    env = _TextEnviron(encoding='utf-16')
    if PY3:
        assert isinstance(env['HOME'], str)
    else:
        assert isinstance(env['HOME'], unicode)

    # Test that the constructor will accept a custom environment
    my_env = {}
    env = _TextEnviron(env=my_env)
    assert env._raw_environ == my_env

# Generated at 2022-06-23 14:36:08.268922
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import io
    import os
    import six
    import tempfile

    # Create a locale in which the filesystem encoding is unknown
    with tempfile.NamedTemporaryFile('w') as locale_desc:
        locale_desc.write('LC_ALL=C.UTF-8\n')
        locale_desc.flush()
        os.environ['LC_ALL'] = 'C'
        os.putenv('LANG', 'C.UTF-8')
        os.system('localedef --quiet -fUTF-8 -i {} -c {}'.format(locale_desc.name, locale_desc.name))
        os.unsetenv('LANG')

    # Test that a str value is converted to text
    os.environ['test_var'] = 'test_value'

# Generated at 2022-06-23 14:36:11.551268
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_key = "abcdefghijk"
    test_value = "1234567890"
    environ[test_key] = test_value
    del environ[test_key]
    assert test_key not in environ


# Generated at 2022-06-23 14:36:16.916851
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import unittest

    class Test_TextEnviron___len__(unittest.TestCase):
        def test__TextEnviron___len__(self):
            """Test for method __len__ in class _TextEnviron"""
            self.assertEqual(len(environ), len(os.environ))

    return Test_TextEnviron___len__



# Generated at 2022-06-23 14:36:19.872861
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils.six import PY2, PY3
    environ_iter = environ.__iter__()
    if PY2:
        assert next(environ_iter)[1] == environ['LANG']
    else:
        assert next(environ_iter)[1] == str(environ['LANG'])


# Generated at 2022-06-23 14:36:24.621325
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # test for Python2
    if not PY3:
        # set up
        env = _TextEnviron()

        # test
        env_list = list(env.__iter__())

        # verify:
        #   The result is not empty list.
        assert len(env_list) > 0
        #   All items of the result is unicode type.
        for env_kv in env_list:
            assert isinstance(env_kv, unicode)


# Generated at 2022-06-23 14:36:33.605266
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Test for object _TextEnviron.__iter__
    #
    # Setup:
    # 1. Create a _TextEnviron object 'test_obj'
    #
    # Test:
    # 1. Create a list 'expected_output' of values which are in os.environ
    # 2. Create an iterable iterator 'output' by iterating over the object
    # 3. Test that list(output) == expected_output

    # Setup
    test_obj = environ

    # Test
    expected_output = list(environ._raw_environ)
    output = iter(test_obj)
    assert list(output) == expected_output



# Generated at 2022-06-23 14:36:36.851852
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    txt_environ = _TextEnviron()
    txt_environ['name'] = 'value'
    del txt_environ['name']
    assert 'name' not in txt_environ
    assert 'name' not in txt_environ._raw_environ


# Generated at 2022-06-23 14:36:46.913756
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():

    # Using PY3, all functions of class _TextEnviron will return text,
    # so we can get away with testing only a few of them here.
    assert isinstance(environ['LANG'], str)
    assert isinstance(environ.__contains__('LANG'), bool)

    # On PY2, only __getitem__ and __setitem__ are used to convert between text and byte strings,
    # which we will test separately.
    #
    # We also need to verify that the values returned by the other functions are converted back
    # to text.
    if not PY3:
        assert isinstance(environ.__contains__('LANG'), str)
        assert isinstance(environ.get('LANG'), str)
        assert isinstance(environ.keys(), list)

# Generated at 2022-06-23 14:36:55.704400
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test the __getitem__ method of the _TextEnviron class.
    """
    if not PY3:
        # __getitem__ returns text on all Python versions
        environ = _TextEnviron()
        environ['FOO'] = to_bytes('bar', encoding='utf-8')
        assert environ['FOO'] == to_text('bar')
        assert environ['FOO'] is not to_bytes('bar', encoding='utf-8')
        environ['FOO'] = u'bäz'
        assert environ['FOO'] == to_text(u'bäz', encoding='utf-8')
        assert environ['FOO'] is not to_bytes(u'bäz', encoding='utf-8')
        # Test that we can decode bytes in the environment

# Generated at 2022-06-23 14:37:01.799866
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    input_value = b'\xed\xc8\x80\xed\xb2\xa1'
    output_value = u'\u0ce0\u0cb1'
    _env = _TextEnviron()
    _env._raw_environ = {'test_g': input_value}
    # Test
    assert _env['test_g'] == output_value

# Generated at 2022-06-23 14:37:10.440781
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, MutableMapping)
    env = {'a': 'b', b'c': b'd'}
    te = _TextEnviron(env)
    assert te == {'a': 'b', 'c': 'd'}
    assert te['a'] == 'b'
    te = _TextEnviron(env, 'ascii')
    assert te == {'a': 'b', 'c': 'd'}
    assert te['a'] == 'b'

    assert te.encoding == 'ascii'

    env[b'a'] = b'a'
    assert te['a'] == 'a'
    env['a'] = 'A'
    assert te['a'] == 'A'

    assert 'a' in te
    assert 'b' not in te

# Generated at 2022-06-23 14:37:14.184532
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    def test_env_del(env, var_name):
        env[var_name] = "bar"
        assert var_name in env
        del env[var_name]
        assert var_name not in env

    test_env_del(environ, "TEST_FOO")


# Generated at 2022-06-23 14:37:24.542218
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = {
        'ascii': 'ascii value',
        u'unicode': u'unicode value',
        b'binary': b'binary value',
        b'binary-unicode': u'binary-unicode value'.encode('utf-8'),
    }
    text_env = _TextEnviron(env)

    assert text_env[u'ascii'] == u'ascii value'
    assert text_env[b'ascii'] == u'ascii value'

    assert text_env[u'unicode'] == u'unicode value'
    assert text_env[b'unicode'] == u'unicode value'

    assert text_env[b'binary'] == u'binary value'

    # The binary value is utf-8 encoded.  It's not Python3's job

# Generated at 2022-06-23 14:37:33.342734
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import tempfile
    temp = tempfile.mkdtemp()

    def check(environ):
        if PY3:
            assert environ['BASETEMP'] == '\u1234'
        else:
            assert environ['BASETEMP'] == u'\u1234'
        assert '\u1234'.encode('utf-8') == os.environ['BASETEMP']
        # The mutable mapping should have bytes stored in it
        assert b'\u1234'.decode('utf-8') == environ._raw_environ['BASETEMP']
        assert os.path.exists(os.path.join(u'\u1234'.encode('utf-8'), b'linux.iso'))

    environ['BASETEMP'] = u'\u1234'
   

# Generated at 2022-06-23 14:37:40.503194
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    # Create a simple MutableMapping object to mimic the behaviour of os.environ
    my_environ = MutableMapping({'x': 'y'})
    text_environ = _TextEnviron(env=my_environ)
    # Try to delete a key
    del text_environ['x']
    # Check that the key doesn't exist anymore
    assert text_environ.get('x') is None



# Generated at 2022-06-23 14:37:43.066468
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron()
    environ['a'] = 'b'
    assert environ._raw_environ['a'] == b'b'



# Generated at 2022-06-23 14:37:52.648138
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test for Unicode values
    for val in [u'test', u'€1', u'\u6587', u'привет']:
        environ[u'test_key'] = val
        assert val == environ[u'test_key']

    # Test for non-Unicode values
    for val in [b'bytes', 1, 10.0, {1: 1}, [1], None]:
        environ[u'test_key'] = val
        assert to_text(val) == environ[u'test_key']

    # Test for invalid surrogateescape
    environ[u'test_key'] = to_text(b'surrogate escape \xf4\x8f\xbf\xbe', errors='surrogateescape')