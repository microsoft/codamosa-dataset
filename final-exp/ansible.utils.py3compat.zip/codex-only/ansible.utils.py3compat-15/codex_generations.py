

# Generated at 2022-06-23 14:27:46.056639
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, _TextEnviron)
    assert isinstance(environ, MutableMapping)

# Generated at 2022-06-23 14:27:48.971343
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({b'A': b'1', b'B': b'2'})
    assert len(env) == 2
    del env['A']
    assert len(env) == 1
    assert env['B'] == '2'



# Generated at 2022-06-23 14:27:55.037259
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, MutableMapping)
    environ.clear()
    assert len(environ) == 0
    assert list(environ) == []

    # Test encoded values
    environ.clear()
    environ[b'\xe9\x9c\x9c\xe6\xb0\x8f'] = b'\xe6\x9c\xb1\xe6\x9d\x91\xe7\x8b\x97\xe6\x96\x87'
    assert len(environ) == 1
    assert list(environ) == [b'\xe9\x9c\x9c\xe6\xb0\x8f']
    assert environ[b'\xe9\x9c\x9c\xe6\xb0\x8f']

# Generated at 2022-06-23 14:27:58.037157
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(_TextEnviron()) == list(os.environ)
    assert list(_TextEnviron(os.environ, encoding='utf-8')) == list(os.environ)



# Generated at 2022-06-23 14:28:09.101955
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Mimic PY3
    setattr(sys, 'getfilesystemencoding', lambda: 'utf-8')
    # Test default behaviour: environment variable is ascii and PY3 False
    environ_ascii = _TextEnviron()
    environ_ascii['ansible_devel_remote_lib'] = 'lib'
    assert isinstance(environ_ascii['ansible_devel_remote_lib'], str)
    assert environ_ascii['ansible_devel_remote_lib'] == 'lib'
    # Test default behaviour: environment variable is utf-8 and PY3 False
    environ_utf8 = _TextEnviron()
    environ_utf8['ansible_devel_remote_lib'] = 'δέφτ'

# Generated at 2022-06-23 14:28:11.640770
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    del os.environ['CFLAGS']

    environ['CFLAGS'] = '-Wall'

    assert(list(environ) == ['CFLAGS'])


# Generated at 2022-06-23 14:28:17.324740
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    text_environ = _TextEnviron(encoding='utf-8')
    assert isinstance(text_environ, _TextEnviron)
    assert isinstance(text_environ._raw_environ, MutableMapping)
    assert isinstance(text_environ._value_cache, MutableMapping)
    assert isinstance(text_environ.encoding, str)



# Generated at 2022-06-23 14:28:25.198671
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    os.environ['PYTHON_TEST_TEXTENVIRON_KEY'] = 'Some Value'
    assert os.environ['PYTHON_TEST_TEXTENVIRON_KEY'] == 'Some Value'

    environ['PYTHON_TEST_TEXTENVIRON_KEY'] = 'Some Text'
    assert environ['PYTHON_TEST_TEXTENVIRON_KEY'] == 'Some Text'

    del os.environ['PYTHON_TEST_TEXTENVIRON_KEY']

# Generated at 2022-06-23 14:28:26.615080
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:28:30.196492
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """
    Test that __iter__ returns iterable on environment variables
    """

    import pytest

    with pytest.raises(StopIteration):
        next(iter(_TextEnviron(encoding='utf-8')))



# Generated at 2022-06-23 14:28:31.558067
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)

# Generated at 2022-06-23 14:28:43.015463
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert to_text(u'\xe1', encoding='utf-8') == u'\xe1'
    if PY3:
        # In Python3, os.environ returns text already
        assert to_text(u'\xe1', errors='surrogate_or_strict', nonstring='passthru', encoding='utf-8') == u'\xe1'
    else:
        # In Python2, os.environ returns bytes
        assert to_text(b'\xc3\xa1', errors='surrogate_or_strict', nonstring='passthru', encoding='utf-8') == u'\xe1'

    # Test that the lower level class handles values that are already text

# Generated at 2022-06-23 14:28:51.052875
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ.clear()
    environ.update(dict(Foo='bar', Foo2='bar2'))
    assert len(environ) == 2
    environ.update(dict(Foo3='bar3'))
    assert len(environ) == 3
    environ.pop('Foo')
    assert len(environ) == 2
    del environ['Foo2']
    assert len(environ) == 1
    environ.popitem()
    assert len(environ) == 0


# Generated at 2022-06-23 14:28:57.423067
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils.six import iteritems

    env = _TextEnviron({b'foo': b'bar', 'unicode': u'bar'}, encoding='utf-8')
    for k, v in iteritems(env):
        assert isinstance(k, str)
        assert isinstance(v, str)
    assert len(env) == 2
    assert isinstance(env['foo'], str)
    assert isinstance(env['unicode'], str)


# Generated at 2022-06-23 14:28:59.193754
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    raw_environ = _TextEnviron()
    assert len(raw_environ) == len(os.environ)

# Generated at 2022-06-23 14:29:04.839542
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    # Arrange:
    os.environ['DATA'] = 'ABC'  # pylint: disable=no-member
    tEnviron = _TextEnviron()

    # Act:
    del tEnviron['DATA']

    # Assert:
    if 'DATA' in tEnviron:
        raise AssertionError('FAILED test__TextEnviron___delitem__: key still in delitem')


# Generated at 2022-06-23 14:29:06.487060
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    os.environ['Key'] = 'Value'
    assert 'Key' in environ
    assert 'Value' == environ['Key']

# Generated at 2022-06-23 14:29:13.985483
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    class Dict(object):
        def __iter__(self):
            for i in range(10):
                yield 'var' + str(i)

    d = _TextEnviron(env=Dict())
    assert isinstance(d, _TextEnviron)
    assert list(iter(d)) == ['var0', 'var1', 'var2', 'var3', 'var4', 'var5', 'var6', 'var7', 'var8', 'var9']



# Generated at 2022-06-23 14:29:18.364415
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    try:
        del environ['PATH']
        assert False, "Must have thrown a KeyError"
    except KeyError:
        pass

    os.environ['PATH'] = '/bin:/usr/bin'
    del environ['PATH']
    assert not os.environ.get('PATH')



# Generated at 2022-06-23 14:29:21.775857
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    class TestEnviron(MutableMapping):
        def __len__(self):
            return 3

    test_raw_environ = TestEnviron()
    text_environ = _TextEnviron(test_raw_environ)
    assert 3 == len(text_environ)


# Generated at 2022-06-23 14:29:33.465810
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    print("\n-- Executing test__TextEnviron___getitem__ --\n")

    # Get the current value of PATH
    path_key = "PATH"
    path = environ._raw_environ[path_key]
    print("Initial value of '%s' is '%s', type is '%s'" % (path_key, path, type(path)))

    # Change PATH to include all subdirectories of /usr/bin
    environ["PATH"] = "/usr/bin:%s" % path
    print("Changed value of '%s' is '%s', type is '%s'" % (path_key, environ["PATH"], type(environ["PATH"])))

    # Get the value of PATH back, it should be in the cache

# Generated at 2022-06-23 14:29:35.975256
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ["MYVAR"] = "foo"
    assert environ["MYVAR"] == "foo"
    del os.environ["MYVAR"]



# Generated at 2022-06-23 14:29:38.940662
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_environ = _TextEnviron()
    key = "testkey"
    value = "testvalue"
    test_environ.__setitem__(key, value)
    assert test_environ[key] == value

# Generated at 2022-06-23 14:29:45.330249
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """
    Test _TextEnviron.__iter__()
    """
    temp_env = dict(foo=b'bar', baz=b'qux')
    environ = _TextEnviron(env=temp_env)
    for key in environ:
        assert isinstance(key, str)

    for key, value in temp_env.items():
        assert isinstance(key, str)
        assert isinstance(value, str)



# Generated at 2022-06-23 14:29:55.402188
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    x = _TextEnviron()
    x._raw_environ = {b'a': b'', 'b': b'\xe9', 'c': b'\xee', b'd': u'\u092f\u094b', b'e': u'\u092f\u094b'}
    x.encoding = 'utf-8'
    assert x[b'a'] == ''
    assert x[b'b'] == u'\xe9'
    assert x[b'c'] == u'\xee'
    assert x[b'd'] == u'\u092f\u094b'
    assert x[b'e'] == u'\u092f\u094b'

    os.environ['b'] = '\xe9'
    os

# Generated at 2022-06-23 14:29:58.428003
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    os.environ[b'hello'] = u'world'
    assert 'world' in os.environ
    try:
        os.environ[b'hello'] = u'french'
        assert 'french' in os.environ
    finally:
        del os.environ[b'hello']

# Generated at 2022-06-23 14:30:07.213294
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # build, test, assert
    # all capital
    env = _TextEnviron({'a': 'A', 'b': 'B', 'c': 'C', 'd': 'D', 'e': 'E'})
    assert set(list(env.__iter__())) == set(['a', 'b', 'c', 'd', 'e'])
    # all lower
    env = _TextEnviron({'a': 'a', 'b': 'b', 'c': 'c', 'd': 'd', 'e': 'e'})
    assert set(list(env.__iter__())) == set(['a', 'b', 'c', 'd', 'e'])
    # mixed

# Generated at 2022-06-23 14:30:10.375439
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ['toto'] = "titi"
    environ.__delitem__('toto')
    assert 'toto' not in environ



# Generated at 2022-06-23 14:30:15.749673
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ.clear()
    environ['setitem_test'] = 'test_value'
    assert list(environ.keys()) == ['setitem_test']
    assert environ['setitem_test'] == 'test_value'
    assert list(environ._value_cache.keys()) == [b'test_value']



# Generated at 2022-06-23 14:30:23.114836
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # The function os.environ is completely immutable on Windows when inside a virtualenv
    if os.name != 'nt':
        mock_env = {}
        env = _TextEnviron(env=mock_env)
        env['foo'] = b'bar'
        assert mock_env['foo'] == b'bar'
        mock_env = {}
        env = _TextEnviron(env=mock_env)
        env['foo'] = u'bar'
        assert mock_env['foo'] == b'bar'
        mock_env = {}
        env = _TextEnviron(env=mock_env)
        env['foo'] = 42
        assert mock_env['foo'] == b'42'

# Generated at 2022-06-23 14:30:26.116316
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['TEST_VAR'] = 'TEST_VAR_VALUE'
    assert('TEST_VAR' in environ)
    del environ['TEST_VAR']
    assert('TEST_VAR' not in environ)


# Generated at 2022-06-23 14:30:33.059982
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Test mimics the behavior of os.environ on Python3
    env = {b'a': b'1',
           b'b': b'2',
           b'c': b'3'}
    txt_env = _TextEnviron(env=env, encoding='utf-8')

    env_iter = txt_env.__iter__()
    result = []
    while True:
        try:
            result.append(next(env_iter))
        except StopIteration:
            break
    expected = ['a', 'b', 'c']
    assert result == expected, 'Result {0} expected {1}'.format(result, expected)
    assert result == list(txt_env.keys()), 'Result {0} expected {1}'.format(result, list(txt_env.keys()))


# Unit

# Generated at 2022-06-23 14:30:35.055447
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    assert len(env) == len(os.environ)

# Generated at 2022-06-23 14:30:44.803103
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    # Test valid unicode.
    key = u'key'
    value = u'value'
    environ[key] = value
    assert key in module.params
    assert environ[key] == value
    # Test invalid unicode.
    key = to_bytes('key', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')
    value = to_bytes('value', encoding='utf-8', nonstring='strict', errors='surrogate_or_strict')

# Generated at 2022-06-23 14:30:49.228531
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    os.environ['UTF-8'] = b'\xc5\x9f\xc3\xb6\xc3\xae\xc3\xaa'
    assert environ['UTF-8'] == u'şöîê'


# Generated at 2022-06-23 14:30:53.291324
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    oldenviron = os.environ
    os.environ = {}
    environ = _TextEnviron()
    environ['a'] = 'alpha'
    assert 'a' in os.environ
    del environ['a']
    assert 'a' not in os.environ
    os.environ = oldenviron


# Generated at 2022-06-23 14:31:00.214303
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test for method __getitem__ of class _TextEnviron
    """
    import os
    import sys

    environ = _TextEnviron()
    env_var = os.getenv('SHELL')

    if sys.version_info[0] == 2:
        # Unicode strings should be returned on Python2
        assert isinstance(env_var, unicode)
    else:
        # Strings should be returned on Python3
        assert isinstance(env_var, str)

# Generated at 2022-06-23 14:31:08.896174
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
	import os, subprocess

# Generated at 2022-06-23 14:31:12.424168
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # constructor
    text_environ = _TextEnviron(encoding='utf-8')
    assert text_environ.encoding == 'utf-8'
    text_environ = _TextEnviron()
    assert text_environ.encoding == sys.getfilesystemencoding()

# Unit tests for method of class _TextEnviron

# Generated at 2022-06-23 14:31:22.579636
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Check that the constructor fails if it is passed something other than a dict
    try:
        _TextEnviron(env=23)
        assert False
    except TypeError:
        pass

    # Check that the class preserves the original dict if it is passed one and that we can
    # access its keys and values
    test_dict = {'key1': 'value1', 'key2': 'value2'}
    text_environ = _TextEnviron(env=test_dict)
    assert text_environ is not test_dict
    assert text_environ.get('key1') == 'value1'

    # Check that the class uses os.environ if it is passed no argument
    text_environ = _TextEnviron()
    # Can use .get() here because we're checking a known key
    assert text_environ.get

# Generated at 2022-06-23 14:31:28.400256
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup
    expected_result = u'foo\u00bf'
    test_default_encoding = sys.getfilesystemencoding()
    if not test_default_encoding:
        test_default_encoding = 'utf-8'
    # Execute
    result = _TextEnviron(encoding=test_default_encoding)['FOO']
    # Verify
    assert result == expected_result

# Generated at 2022-06-23 14:31:29.883068
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) >= 1


# Generated at 2022-06-23 14:31:36.377690
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron({'a': 'b', 'c': 'd'})
    assert env['a'] == 'b'
    assert env['c'] == 'd'

    env['a'] = 'q'
    assert 'a' in env
    assert env['a'] == 'q'

    del env['a']
    assert 'a' not in env

    assert len(env) == 1
    assert sum(1 for _ in env) == 1



# Generated at 2022-06-23 14:31:42.895347
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['I_AM_AN_ENVIRON_VAR'] == 'I_AM_A_VALUE'
    assert environ[u'I_AM_AN_ENVIRON_VAR'] == 'I_AM_A_VALUE'
    assert environ[b'I_AM_AN_ENVIRON_VAR'] == 'I_AM_A_VALUE'


# Generated at 2022-06-23 14:31:44.443569
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({'A': '1', 'B': '2', 'C': '3'})
    assert sorted(env.__iter__()) == ['A', 'B', 'C']



# Generated at 2022-06-23 14:31:53.614169
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    from itertools import chain

    temp_env = {to_text('a'): to_text('1'), to_text('b'): to_text('2')}
    utf8_environ = _TextEnviron(env=temp_env, encoding='utf-8')
    assert isinstance(utf8_environ, MutableMapping)
    assert list(utf8_environ.__iter__()) == list(chain(temp_env.__iter__(), temp_env.keys()))



# Generated at 2022-06-23 14:31:54.483176
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    set_item = environ.__setitem__

# Generated at 2022-06-23 14:31:55.661396
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    '''
    assert environ['cwd'] == '/tmp'
    '''

# Generated at 2022-06-23 14:31:59.198870
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import os
    environ = _TextEnviron(encoding='utf-8')
    os.environ["test"] = "foo"
    print(environ["test"])
    environ.__delitem__("test")
    if "test" in environ:
        print("key 'test' is not deleted from environ")
        assert False


# Generated at 2022-06-23 14:32:15.439511
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron()
    environ['not-utf-8'] = b'\xA4\xA2'
    environ['utf-8'] = b'\xe4\xb8\xad\xe6\x96\x87'
    environ['unicode'] = u'\u4e2d\u6587'

    if PY3:
        # On Python3, environ should return unicode strings
        assert isinstance(environ['not-utf-8'], str)
        assert isinstance(environ['utf-8'], str)
        assert isinstance(environ['unicode'], str)
        # Use the surrogate escape error handler to handle non-utf8 characters
        assert environ['not-utf-8'].encode('utf-8', 'surrogateescape') == b

# Generated at 2022-06-23 14:32:26.480620
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test the success scenario: __setitem__ should set value to environment variable
    key_name = 'DUMMY'
    dummy_var_value = to_text('dummy_value')
    if key_name in environ:
        del environ[key_name]
    environ[key_name] = dummy_var_value
    assert environ[key_name] == dummy_var_value
    del environ[key_name]

    # Test the failure scenario 1: __setitem__ should raise TypeError when value is not of type text or bytes
    test_var_value = None
    try:
        environ[key_name] = test_var_value
    except TypeError:
        pass
    else:
        raise AssertionError('test failed')

    # Test the failure scenario 2: __setitem__ should raise

# Generated at 2022-06-23 14:32:37.882123
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import unittest

    class Test_TextEnviron___iter__(unittest.TestCase):
        def test__TextEnviron___iter__(self):
            env = {'foo': 'bar'}
            self.assertEqual(list(env), list(_TextEnviron(env=env)))

    # Run unit tests
    suite = unittest.TestLoader().loadTestsFromModule(sys.modules[__name__])
    return unittest.TextTestRunner(verbosity=2).run(suite)

if __name__ == '__main__':
    # Run unit test for method __iter__ of class _TextEnviron
    result = test__TextEnviron___iter__()
    if result.errors or result.failures:
        sys.exit(1)
    sys.exit(0)

# Generated at 2022-06-23 14:32:45.593532
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_test = _TextEnviron()

    # Test decoding ascii
    environ_test._raw_environ = {u'key': b'value'}
    assert environ_test[u'key'] == u'value'

    # Test decoding unicode
    environ_test._raw_environ = {u'key': '\u041f\u0443\u0442\u0438\u043d'.encode('utf-8')}
    assert environ_test[u'key'] == u'\u041f\u0443\u0442\u0438\u043d'



# Generated at 2022-06-23 14:32:50.047336
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    __env__ = _TextEnviron(env=os.environ)
    assert len(__env__) == len(os.environ)
    __env__['foo'] = 'bar'
    assert len(__env__) == len(os.environ) + 1
    assert os.environ['foo'] == 'bar'
    del __env__['foo']
    assert 'foo' not in __env__
    assert 'foo' not in os.environ


# Generated at 2022-06-23 14:32:51.623349
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    pass

# Generated at 2022-06-23 14:33:00.219451
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    test_env = {'text_key': 'text_value', b'binary_key': b'binary_value',
                'non_utf8_text': 'r\xe9p\xe9tition', b'non_utf8_binary': b'r\xe9p\xe9tition'}
    assert environ == os.environ
    os.environ = test_env
    assert environ != os.environ
    assert 'text_key' in environ and 'binary_key' in environ
    assert environ['text_key'] == 'text_value'
    assert environ['binary_key'] == 'binary_value'
    assert environ['non_utf8_text'] == 'r\xe9p\xe9tition'

# Generated at 2022-06-23 14:33:04.676221
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import os

    environ = _TextEnviron(encoding='utf-8')
    os.environ['FOO'] = 'asdf'
    environ['FOO'] = 'asdf'
    assert environ['FOO'] == 'asdf'

test__TextEnviron___setitem__()

# Generated at 2022-06-23 14:33:11.340165
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    THIS_IS_A_TEST_FOR_THEM = "THIS_IS_A_TEST_FOR_THEM"

    environ = _TextEnviron(encoding='utf-8')
    # Here we mark the mock environment as empty
    environ._raw_environ = {}

    for i in range(0, 10):
        environ._raw_environ[to_bytes('%s_%d' % (THIS_IS_A_TEST_FOR_THEM, i))] = to_bytes('%d' % i)

    iterable = []
    for k in environ.__iter__():
        iterable.append(k)


# Generated at 2022-06-23 14:33:16.312498
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == 0
    environ['FAKE_ENVIRON'] = 'fake_value'
    assert len(environ) == 1
    environ['FAKE_ENVIRON'] = ''
    assert len(environ) == 1
    del environ['FAKE_ENVIRON']
    assert len(environ) == 0


# Generated at 2022-06-23 14:33:26.919590
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.compat import unittest
    import mock

    class A(unittest.TestCase):
        @mock.patch('os.environ', {'a': b'b\x81'})
        def test__TextEnviron___getitem__(self):
            _raw_environ = {'a': b'b\x81'}
            _value_cache = {}
            encoding = 'utf-8'
            text_environ = _TextEnviron(_raw_environ, encoding)

            self.assertEqual(text_environ['a'], u'b\ufffd')
            self.assertEqual(_raw_environ['a'], b'b\x81')

# Generated at 2022-06-23 14:33:37.119885
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    class MyEnv(object):
        def __getitem__(self, key):
            return to_text(key + '=' + key, encoding='utf-8')

    myenv = MyEnv()

    environ = _TextEnviron(env=myenv, encoding='utf-8')
    assert environ['FOO'] == 'FOO=FOO'

    environ = _TextEnviron(env=myenv, encoding='ascii')
    assert environ['FOO'] == u'FOO=FOO'

    if PY3:
        assert environ['FOO'] == 'FOO=FOO'
    else:
        assert environ['FOO'] == u'FOO=FOO'

    environ = _TextEnviron(env=myenv, encoding='latin-1')
    assert environ

# Generated at 2022-06-23 14:33:42.301825
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    old_os_environ = os.environ

    try:
        os.environ = {}
        assert _TextEnviron().__getitem__('foo') == u''
    finally:
        os.environ = old_os_environ


# Generated at 2022-06-23 14:33:53.936956
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Unit test for method __getitem__ of class _TextEnviron"""
    if not PY3:
        encoding = sys.getfilesystemencoding()
        environ[b'TEST_BYTE'] = b'pass'
        assert type(environ[b'TEST_BYTE']) == str
        assert environ[b'TEST_BYTE'] == 'pass'

        environ[b'TEST_UNICODE']= u'pass'
        assert environ[b'TEST_UNICODE'] == 'pass'

        # We need to convert the the unicode character to bytes ourselves here because the module
        # doesn't have access to the unicode character
        environ[b'TEST_UNICODE']= u'pass\u263a'.encode(encoding)

# Generated at 2022-06-23 14:33:55.738441
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    e = _TextEnviron()
    assert len(e) == len(os.environ)
    assert True is True

# Generated at 2022-06-23 14:34:01.131698
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # since we are operating on a non-mutable copy of os.environ this will
    # not affect the process environment for the ansible process
    e = _TextEnviron(env=dict(os.environ))
    assert 'HTTP_PROXY' in e, "HTTP_PROXY is required for test__TextEnviron___delitem__"
    del e['HTTP_PROXY']
    assert 'HTTP_PROXY' not in e, "__delitem__ has failed"


# Generated at 2022-06-23 14:34:12.565203
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import unittest
    import ansible.module_utils.six as six
    from ansible.module_utils.six._collections_compat import MutableMapping

    class _TextEnvironTest(unittest.TestCase):
        _DUMMY_VALUE = 'dummy_value'

        def setUp(self):
            # Create a class instance
            self.environ_instance = _TextEnviron()
            # Save original environ value
            self._original_environ_value = self.environ_instance._raw_environ[self._DUMMY_KEY]

        def tearDown(self):
            # Reset original environ value
            self.environ_instance._raw_environ[self._DUMMY_KEY] = self._original_environ_value


# Generated at 2022-06-23 14:34:19.847444
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():

    # test for python3
    if PY3:
        environ['TEST'] = u'TEST'
        assert environ['TEST'] == u'TEST'

    environ.encoding = 'utf-8'
    environ['TEST'] = 'TEST'

    assert environ['TEST'] == 'TEST'

    environ.encoding = 'utf-16'
    environ['TEST'] = 'TEST'

    assert environ['TEST'] == u'TEST'


if __name__ == '__main__':
    test__TextEnviron___setitem__()

# Generated at 2022-06-23 14:34:30.774665
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest
    import random

    # Test getting raw items from the environment
    for key, value in environ.items():
        assert key in environ._raw_environ, ('Key %s not in environment' % key)
        assert value == os.environ[key], ('Raw byte value from os.environ differs from that '
                                          'returned by environ. Expected: %s, got: %s') % (
                                              os.environ[key], value)

    # Test getting unicode items from the environment
    for key, value in environ.items():
        assert key in environ._raw_environ, ('Key %s not in environment' % key)
        # FIXME: Use a more restrictive unicode test than this.

# Generated at 2022-06-23 14:34:35.387213
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Verify the length of environ is returned
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    text_environ = _TextEnviron(env=test_dict)
    assert len(text_environ) == len(test_dict)



# Generated at 2022-06-23 14:34:39.957415
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test
    dict = {'key1': 'value1', 'key2': 'value2'}

    textEnviron = _TextEnviron(dict)

    assert textEnviron['key1'] == 'value1'
    assert textEnviron['key2'] == 'value2'


# Generated at 2022-06-23 14:34:42.172497
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    text_environ = _TextEnviron(encoding='utf-8')
    assert len(text_environ) > 0


# Generated at 2022-06-23 14:34:43.141958
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    pass



# Generated at 2022-06-23 14:34:45.249274
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['__class__'] == '_TextEnviron'
    assert isinstance(environ['__class__'], str)


# Generated at 2022-06-23 14:34:52.452843
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Create an example environment with both utf-8 and ascii strings as keys/values
    # as well as a unicode surrogate escape as part of the value
    os.environ = {
        b'ASCII_KEY': b'ASCII_VAL',
        b'UNICODE_KEY': b'\xc3\xbf',
        b'UNICODE_KEY_UNICODE_VAL': b'\xc3\xbf',
        b'BAD_KEY': b'\xff\xff',
    }

    # Assert that the os.environ returns bytestrings
    assert isinstance(os.environ[b'ASCII_KEY'], bytes)
    assert isinstance(os.environ[b'UNICODE_KEY'], bytes)

# Generated at 2022-06-23 14:35:00.550394
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron(os.environ)

    if not isinstance(env, _TextEnviron):
        raise TypeError('Wrong object instanciated it\'s type is "{0}" expected "{1}"'.format(
            type(env),
            _TextEnviron
        ))

    if not isinstance(env.__iter__(), iter):
        raise TypeError('Wrong object returned by method __iter__() it\'s type is "{0}" expected "{1}"'.format(
            type(env.__iter__()),
            iter
        ))



# Generated at 2022-06-23 14:35:09.380749
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Ensure that environ is a MutableMapping
    assert isinstance(environ, MutableMapping)

    # Ensure that the cached value was created
    assert environ.encoding == 'utf-8'

    # Ensure that it finds items that are in the environment
    assert environ['HOME'] == os.environ['HOME']

    # Ensure that it correctly decodes values in the environment
    # If the filesystem encoding is utf-8, then the enviroment variable
    # \u0905 will be unicode on Python3.  If not, it won't be.
    # Use this to test the decoding.
    os.putenv(b'\u0905', b'\u0905')

# Generated at 2022-06-23 14:35:14.948576
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron(encoding='utf-8')
    # list of all environment variables
    keys_list = []
    for key in environ:
        keys_list.append(key)

    # Environment variable 'PATH'
    assert 'PATH' in keys_list


# Generated at 2022-06-23 14:35:25.618079
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    import os
    import sys
    import unittest
    from ansible.module_utils._text import to_bytes, to_text

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.environ = _TextEnviron(encoding = 'utf-8')
            self.environ['test_key'] = u'test_value'

        def tearDown(self):
            self.environ.clear()

        def test_set_value_normal(self):
            self.assertEqual(self.environ['test_key'], u'test_value')
            self.assertEqual(os.environ['test_key'], b'test_value')
            self.assertIsInstance(self.environ['test_key'], to_text(u'').__class__)


# Generated at 2022-06-23 14:35:27.515941
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron()
    assert isinstance(env['PATH'], str)

# Generated at 2022-06-23 14:35:38.041260
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import tempfile
    fd, fname = tempfile.mkstemp()
    with os.fdopen(fd, "w") as f:
        f.write(u"""#!/bin/bash
                    export TEST=SUCCESS""")

    os.environ['TEST'] = 'FAIL'
    os.system(u"source %s" % fname)

    assert to_text(os.environ['TEST']) == 'SUCCESS'
    assert environ['TEST'] == 'SUCCESS'

    del environ['TEST']
    assert 'TEST' not in environ

    os.system(u"source %s" % fname)
    assert to_text(os.environ['TEST']) == 'SUCCESS'
    assert environ['TEST'] == 'SUCCESS'

# Generated at 2022-06-23 14:35:41.316623
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    '''
    Test the constructor of _TextEnviron
    '''
    env = _TextEnviron({'a': 'b'})
    assert env.encoding == 'utf-8'
    assert 'a' in env
    assert env['a'] == 'b'



# Generated at 2022-06-23 14:35:46.751669
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Check Undecoded string
    de = _TextEnviron(env = {'PASSWORD_UTIL': b'\xe2\x98\x83'}, encoding='utf-8')
    assert len(de) == 1
    # Check Decoded values.
    assert de['PASSWORD_UTIL'] == '☃'
    # Check if the setitem method is working as expected
    de['PASSWORD_UTIL'] = '☃'
    # Check len after setitem
    assert len(de) == 1
    # Check if value is same as the one before setitem operation
    assert de['PASSWORD_UTIL'] == '☃'

# Generated at 2022-06-23 14:35:57.107954
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Create a dictionary with one key that could not be encoded as bytes with the default
    # encoding (utf-8)
    utf16_env = {'TEST_UNICODE_U+1234': u'\U00012345'}

    # Create a _TextEnviron object with an environment that has a unicode character that cannot
    # be encoded with the default encoding
    test_environ = _TextEnviron(env=utf16_env)

    # Run __iter__ on the TextEnviron object and extract the key that could not be encoded as bytes
    # with the default encoding
    (key,) = test_environ.__iter__()

    # Make sure the key that could not be encoded as bytes with the default encoding still has the
    # unicode value
    assert key == 'TEST_UNICODE_U+1234'



# Generated at 2022-06-23 14:35:59.560182
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Arrange
    expected = 'testééé'
    environ['test'] = expected

    # Act
    result = environ['test']

    # assert
    assert(result == expected)


# Generated at 2022-06-23 14:36:08.352553
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Verify that _TextEnviron.__delitem__() calls del on the underlying os.environ
    """
    # Make sure we don't get any side effects to the real os.environ
    original_environ = dict(environ)
    try:
        # Arrange
        key = 'some-key'
        environ[key] = 'some-value'

        # Act
        del environ[key]

        # Assert
        assert key not in environ
    finally:
        # Cleanup
        environ.clear()
        environ.update(original_environ)


# Generated at 2022-06-23 14:36:12.464376
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
#    print('Testing _TextEnviron constructor')
    assert isinstance(environ._raw_environ, MutableMapping)
    assert len(environ._raw_environ) == len(environ._value_cache)
#    print('\tok')


# Generated at 2022-06-23 14:36:21.851139
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    os.environ['ANSIBLE_TEXTENVIRON_SETITEM_TEST'] = 'Testing'
    assert environ.encoding == 'utf-8'
    assert os.environ['ANSIBLE_TEXTENVIRON_SETITEM_TEST'].decode('utf-8') == 'Testing'
    assert os.environ['ANSIBLE_TEXTENVIRON_SETITEM_TEST'] == 'Testing'
    environ['ANSIBLE_TEXTENVIRON_SETITEM_TEST'] = u'Łódź'
    assert os.environ['ANSIBLE_TEXTENVIRON_SETITEM_TEST'].decode('utf-8') == u'Łódź'

# Generated at 2022-06-23 14:36:23.635868
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    try:
        del environ[b'MYVAR']
    except Exception as e:
        assert e == KeyError


# Generated at 2022-06-23 14:36:35.084848
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # This test is not meant be used as a unit test in general.
    # Instead it can be used as a quick way to check if your implementation
    # covers all the codepaths inside method __iter__() of class _TextEnviron

    # Setup a _TextEnviron instance to test
    testos_environ = {
        'KEY_1': 'VALUE_1',
        'KEY_2': 'VALUE_2',
        'KEY_3': 'VALUE_3',
        'KEY_4': 'VALUE_4',
    }
    test_environ = _TextEnviron(env=testos_environ)

    # Check the iter() return value
    iter_return_value = iter(test_environ)
    assert(isinstance(iter_return_value, object))

    # Check the returned iterator
    it_return_value

# Generated at 2022-06-23 14:36:44.871066
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Unit test for method __delitem__ of class _TextEnviron
    :return:
    """

    from ansible.module_utils.six import string_types

    try:
        environ['TEST_KEY'] = 'TEST_VALUE'
        result = environ['TEST_KEY']
        assert isinstance(result, string_types)
        assert result == 'TEST_VALUE'

        del environ['TEST_KEY']
        assert 'TEST_KEY' not in environ.keys()
        assert 'TEST_KEY' not in environ

    finally:
        if 'TEST_KEY' in environ:
            del environ['TEST_KEY']



# Generated at 2022-06-23 14:36:54.573010
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ = _TextEnviron()
    # A byte string with a high-bit char
    environ["a"] = b"\xc2"
    # A native string with a unicode char
    environ["b"] = u"\u1234"
    # A byte string with an invalid char
    environ["c"] = b"\xff"
    # A native string with a unicode char
    environ["d"] = u"\ud800"
    # Python 2 (byte string, high-bit char)
    os.environ[b"a"] = b"\xc2"
    # Python 2 (native unicode)
    # No way to do this currently in Python 2
    # Python 3 (native unicode)
    os.environ["b"] = u"\u1234"
    # Python 2 (byte string,

# Generated at 2022-06-23 14:36:56.160853
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:36:57.493813
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:37:07.541118
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    utc_environ = _TextEnviron()

    utc_environ['a'] = 'foo'
    assert isinstance(utc_environ._raw_environ['a'], bytes)
    if PY3:
        assert utc_environ._raw_environ['a'] == b'foo'
    else:
        assert utc_environ._raw_environ['a'] == u'foo'.encode('utf-8')
        assert utc_environ['a'] == u'foo'

    utc_environ['a'] = u'foo'
    assert isinstance(utc_environ._raw_environ['a'], bytes)
    if PY3:
        assert utc_environ._raw_environ['a'] == b'foo'
    else:
        assert utc_

# Generated at 2022-06-23 14:37:12.065181
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    assert len(environ) == 0
    environ['SOME_VAR'] = 'SOME_VALUE'
    assert len(environ) == 1
    assert environ['SOME_VAR'] == 'SOME_VALUE'
    del environ['SOME_VAR']
    assert len(environ) == 0

# Generated at 2022-06-23 14:37:22.206140
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    class Environ(object):
        def __len__(self):
            return 2

        def __iter__(self):
            return iter(['FOO', 'BAR'])

        def __getitem__(self, key):
            return None

        def __delitem__(self, key):
            pass

        def __setitem__(self, key, value):
            pass

    env = _TextEnviron(env={'FOO': ''}, encoding='utf-8')
    assert len(env) == 1
    env = _TextEnviron(env={'FOO': ''}, encoding='utf-8')
    assert len(env) == 1
    env = _TextEnviron(env={'FOO': '', 'BAR': ''}, encoding='utf-8')
    assert len(env) == 2
    env = _Text

# Generated at 2022-06-23 14:37:29.741079
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    '''Test method __iter__(_TextEnviron)'''
    # Create a copy of environ
    tmp_environ = _TextEnviron(env=dict(environ._raw_environ))
    # Make a list of the keys
    keys = []
    for key in tmp_environ:
        keys.append(key)
    # Make sure all the keys are in the original environ
    for key in keys:
        assert key in tmp_environ._raw_environ
    assert len(keys) == len(tmp_environ._raw_environ)



# Generated at 2022-06-23 14:37:39.240829
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import os
    os.environ['ANSIBLE_TEXT_ENVIRON_TEST'] = 'test__TextEnviron___delitem__'
    environ['ANSIBLE_TEXT_ENVIRON_TEST'] = 'test__TextEnviron___delitem__'
    assert environ['ANSIBLE_TEXT_ENVIRON_TEST'] == 'test__TextEnviron___delitem__'
    del environ['ANSIBLE_TEXT_ENVIRON_TEST']
    assert 'ANSIBLE_TEXT_ENVIRON_TEST' not in environ
    assert 'ANSIBLE_TEXT_ENVIRON_TEST' not in os.environ


# Generated at 2022-06-23 14:37:49.369529
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    class RawEnviron(object):
        def __init__(self):
            self.dirty = False
            self.data = dict()

        def __delitem__(self, key):
            del self.data[key]
            self.dirty = True

        def __getitem__(self, key):
            return self.data[key]

        def __setitem__(self, key, value):
            self.data[key] = value
            self.dirty = True

        def __iter__(self):
            return iter(self.data)

        def __len__(self):
            return len(self.data)

        def get(self, key):
            return self.data.get(key)

    # Set up initial environment
    env = RawEnviron()
    env['test1'] = '1'