

# Generated at 2022-06-23 14:27:49.473851
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    old = os.environ.copy()
    os.environ.clear()


# Generated at 2022-06-23 14:27:58.865718
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron(env=dict(BYTES=b'bytes', STR=u'str', UNICODE=u'unicode'), encoding='ascii')
    for key in env:
        assert isinstance(env[key], str)
    assert env[b'BYTES'] == 'bytes'
    assert env[u'STR'] == 'str'
    assert env[u'UNICODE'] == 'unicode'
    assert env[u'NONEXISTENT'] is None

    env[u'NONEXISTENT'] = u'unicode'
    assert env[u'NONEXISTENT'] == 'unicode'


# Generated at 2022-06-23 14:28:01.517176
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ["key1"] = "value1"
    environ["key2"] = "value2"
    assert set(environ) == {"key1", "key2", "HOME", "SHELL"}

# Generated at 2022-06-23 14:28:06.151869
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron({'foo': 'bar', 'baz': 'quux'})
    assert 'foo' in env
    assert 'baz' in env
    del env['foo']
    assert 'foo' not in env
    assert 'baz' in env



# Generated at 2022-06-23 14:28:11.023953
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Test initial state
    assert 'delitem_test' not in environ
    environ['delitem_test'] = 'delete me'
    assert 'delitem_test' in environ

    # Test method __delitem__ of class _TextEnviron
    del environ['delitem_test']
    assert 'delitem_test' not in environ


# Generated at 2022-06-23 14:28:13.293656
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ["test"] = "test"
    environ.__delitem__("test")

# Generated at 2022-06-23 14:28:15.129713
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    len(env)  # noqa: F841

# Generated at 2022-06-23 14:28:22.807498
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test default encoding
    new_env = _TextEnviron()
    assert new_env.encoding == sys.getfilesystemencoding()

    # Test specified encoding
    new_env = _TextEnviron(encoding='ascii')
    assert new_env.encoding == 'ascii'

    # Test specified encoding and environment
    new_env = _TextEnviron({'FOO': '/tmp/bar'}, encoding='ascii')
    assert len(new_env) == 1
    assert new_env['FOO'] == '/tmp/bar'
    assert new_env.encoding == 'ascii'

    # Test passing in a different environment
    new_env = _TextEnviron({'FOO': '/tmp/baz'})
    assert len(new_env) == 1

# Generated at 2022-06-23 14:28:32.188076
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    msg = 'Bad _TextEnviron.__setitem__() behaviour'

    environ.clear()
    environ['my'] = 'first'
    assert environ['my'] == 'first', msg

    # We currently assume that the underlying os.environ is only ever manipulated with ascii/utf-8
    # content, so we don't convert things on writes.
    # See: https://github.com/ansible/ansible/issues/46291#issuecomment-367601317
    environ['my'] = b'first\xe9'
    assert environ['my'] == 'firsté', msg

    environ['my'] = u'first\u20ac'
    assert environ['my'] == 'first\u20ac', msg

# Generated at 2022-06-23 14:28:35.881570
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ["KEY"] = "VALUE"
    del(environ["KEY"])
    assert "KEY" not in environ


# Generated at 2022-06-23 14:28:37.332763
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
	pass
	# assert False # TODO: implement your test here


# Generated at 2022-06-23 14:28:45.132880
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    _TextEnviron.__setitem__ should take either a unicode or bytes string and convert it to bytes
    """
    # pylint: disable=too-many-locals
    # pylint: disable=no-value-for-parameter
    # pylint: disable=too-few-public-methods
    # pylint: disable=protected-access

    # Check that unicode strings are encoded into bytes
    environ_object = _TextEnviron()
    original_value = 'This is a unicode string'
    environ_object._raw_environ = {}
    environ_object.__setitem__('set_unicode', original_value)

    if PY3:
        expected = original_value
    else:
        expected = original_value.encode('utf-8')

# Generated at 2022-06-23 14:28:46.147281
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert list(environ) == list(os.environ)



# Generated at 2022-06-23 14:28:50.572438
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert len(environ) == 0
    environ['A'] = 'a'
    environ['B'] = 'b'
    assert len(environ) == 2
    assert set(environ.keys()) == {'A', 'B'}


# Generated at 2022-06-23 14:28:54.546131
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Unit test for method __delitem__ of class _TextEnviron

    The method __delitem__ of class _TextEnviron mimics the behavior of __delitem__ of
    os.environ on py3
    """
    env = _TextEnviron()
    del env['test_key']


# Generated at 2022-06-23 14:28:57.852754
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ['abc'] = '123'
    assert 1 == len(environ)

    del os.environ['abc']
    assert 0 == len(environ)


# Generated at 2022-06-23 14:29:01.998542
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test the default constructor
    env = _TextEnviron()
    assert sys.getfilesystemencoding() == env.encoding
    # Test with a specific encoding
    env = _TextEnviron(encoding='ascii')
    assert 'ascii' == env.encoding

# Generated at 2022-06-23 14:29:05.693402
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({'one': 'two', 'three': 'four'})
    assert len(env) == 2
    assert list(env) == ['one', 'three']
    assert env['one'] == 'two'
    assert env['three'] == 'four'


# Generated at 2022-06-23 14:29:11.385861
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    key = 'foo'
    value = 'bar'
    if key in os.environ:
        del os.environ[key]
    os.environ[key] = value
    assert key in os.environ
    del environ[key]
    assert key not in os.environ


# Generated at 2022-06-23 14:29:14.211545
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    assert len(env) == len(environ)
    assert len(env) == len(os.environ)


# Generated at 2022-06-23 14:29:23.183586
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    e = {
        b'bytes': b'bytes'
    }
    t = _TextEnviron(env=e, encoding='utf-8')
    assert t.encoding == 'utf-8'
    assert t._raw_environ == e
    assert t._value_cache == {}
    assert t[b'bytes'] == u'bytes'
    assert t._value_cache[b'bytes'] == u'bytes'

    t[u'unicode'] = u'unicode'
    assert t._raw_environ[u'unicode'] == 'unicode'

    del t[u'unicode']
    assert u'unicode' not in t._raw_environ

    assert list(iter(t)) == list(iter(e))
    assert len(t) == len(e)

# Generated at 2022-06-23 14:29:28.556053
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test initializing with no environ
    env = _TextEnviron()
    # Test initializing with a default encoding
    env = _TextEnviron(encoding='ascii')
    # Test initializing with a different environ
    env = _TextEnviron({'foo': 'bar'}, encoding='ascii')

# Generated at 2022-06-23 14:29:30.829076
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    testenv = _TextEnviron()
    for i in testenv:
        pass


# Generated at 2022-06-23 14:29:33.365959
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # getenv returns bytes, so we need to use bytes to compare
    assert environ[b'PATH'] == b'/usr/bin:/bin:/usr/local/bin'

# Generated at 2022-06-23 14:29:41.480680
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test that a simple string is passed through as a bytes type
    environ['foo'] = 'bar'
    assert isinstance(environ._raw_environ['foo'], bytes)

    # Test that unicode strings are converted to bytes
    environ['foo'] = u'\u1234'
    assert isinstance(environ._raw_environ['foo'], bytes)

    # Test that nonstring types raise an error
    try:
        environ['foo'] = 123
        assert False, '_TextEnviron.__setitem__ should have raised TypeError'
    except TypeError:
        pass

    # Test that strings with non-ascii chars are encoded to bytes
    environ['foo'] = u'\u1234'

# Generated at 2022-06-23 14:29:50.927779
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron()
    print("env={0}".format(env))

    env.clear()
    env['C1'] = 'V1'
    env['C2'] = 'V2'
    env['C3'] = 'V3'
    env['C4'] = 'V4'
    env['C5'] = 'V5'

    print("env='{0}'".format(env))

    for key in env:
        print("key='{0}', value='{1}'".format(key, env[key]))


# Test code
if __name__ == "__main__":
    test__TextEnviron___iter__()

# Generated at 2022-06-23 14:29:54.634876
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = {to_text(b'foo'): to_text(b'bar')}
    test = _TextEnviron(env)
    assert isinstance(test._raw_environ[b'foo'], bytes)
    assert test[u'foo'] == u'bar'


# Generated at 2022-06-23 14:30:04.645708
# Unit test for method __iter__ of class _TextEnviron

# Generated at 2022-06-23 14:30:07.767874
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    if len(os.environ) != len(environ):
        raise AssertionError("Size of original dict and _TextEnviron instance aren't equal")


# Generated at 2022-06-23 14:30:18.286867
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # __getitem__ does not raise KeyError, so we start by checking for non-existent keys
    for key in ['no_exist', 'false', 'true', 'one', 'two', 'three', 'four', 'five']:
        assert key not in environ
        try:
            environ[key]
        except KeyError:
            pass
        else:
            assert False, 'KeyError not raised'

    # Now set various keys to values
    environ['no_exist'] = 'false'
    for key in ['false', 'true', 'one', 'two', 'three', 'four', 'five']:
        assert key not in environ
    assert 'no_exist' in environ
    assert environ['no_exist'] == u'false'

    environ['false'] = b'false'

# Generated at 2022-06-23 14:30:26.116380
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    def check_keys(env, keys):
        for k in keys:
            assert isinstance(k, str)
        for k in env:
            assert k in keys
    if PY3:
        environ_keys = os.environ.keys()
    else:
        environ_keys = [to_text(k, encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict')
                        for k in os.environ.keys()]
    check_keys(environ, environ_keys)
    test_environ = {1: 1, 2: 2, 3: 3}
    test_env = _TextEnviron(env=test_environ)
    check_keys(test_env, test_environ.keys())



# Generated at 2022-06-23 14:30:36.330644
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    _environ = _TextEnviron(encoding='ascii')
    assert 'TEST' not in _environ
    _environ['TEST'] = 'foo'
    assert 'TEST' in _environ
    assert b'foo' == os.environ[b'TEST']
    assert 'foo' == _environ['TEST']
    _environ['TEST'] = u'föö'
    assert b'f\xc3\xb6\xc3\xb6' == os.environ[b'TEST']
    assert u'föö' == _environ['TEST']
    # Make sure that changing the raw environ changes the values in this class
    os.environ[b'TEST'] = b'baz'

# Generated at 2022-06-23 14:30:45.640969
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Set some environ variables and verify
    os.environ['foo'] = b'bar'
    assert environ['foo'] == 'bar'
    os.environ['unicode_'] = b'\xc3\xb6\xe2\x98\x83'
    assert environ['unicode_'] == u'\xf6\u2603'
    # Mutate and verify
    environ['foo'] = u'\u2603'
    assert os.environ['foo'] == b'\xe2\x98\x83'
    environ['unicode_'] = 'bar'
    assert os.environ['unicode_'] == b'bar'
    # Verify that setting to binary works
    environ['foo'] = b'\xc3\xb6\xe2\x98\x83'

# Generated at 2022-06-23 14:30:47.609570
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    e = _TextEnviron()
    assert len(e) == len(os.environ)



# Generated at 2022-06-23 14:30:58.049099
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    _test_env = {
        b'utf8': b'\xc3\xa9me\xc3\xbd\xc3\xa0\xc2\xbe',
        # Test that surrogateescape doesn't work
        b'surrogate': to_bytes(u'\udcff\udcff', errors='surrogateescape'),
        b'surrogate_with_valid_char': to_bytes(u'\udcff\udcff\ufffd\udcff\udcff', errors='surrogateescape'),
    }

    env = _TextEnviron(_test_env, encoding='utf-8')

    assert env[b'utf8'] == u'\xe9me\xfd\xe0\xbe'

# Generated at 2022-06-23 14:31:04.641747
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # A new instance must not have any value
    del environ['KEY']
    assert 'KEY' not in environ
    assert 'KEY' not in os.environ

    environ['KEY'] = 'VALUE'
    assert 'KEY' in environ and environ['KEY'] == 'VALUE'
    assert 'KEY' in os.environ and os.environ['KEY'] == b'VALUE'

    # Now delete the key and test again
    del environ['KEY']
    assert 'KEY' not in environ
    assert 'KEY' not in os.environ


# Generated at 2022-06-23 14:31:14.041595
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import unittest
    import unittest.mock

    class __TextEnviron___iter__(unittest.TestCase):
        def setUp(self):
            self.env = {'hello': 'world'}
            self.env_proxy = _TextEnviron(env=self.env)
            self.assertEqual(len(self.env), len(self.env_proxy))

        def test_iter__raw_iter(self):
            with unittest.mock.patch('ansible.module_utils.six.moves.builtins.iter',
                                     wraps=iter, autospec=True) as patched_iter:
                iter(self.env_proxy)
                patched_iter.assert_called_once_with(self.env)

    unittest.main()


# Generated at 2022-06-23 14:31:21.514725
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # os.environ returns bytes on py2, strings on py3
    # Constructor should return bytes on py2, text on py3
    obj = _TextEnviron()
    if PY3:
        assert isinstance(obj['PATH'], str)
    else:
        assert isinstance(obj['PATH'], bytes)

    # Constructor should respect the encoding given
    obj = _TextEnviron(encoding='cp1252')
    if PY3:
        assert isinstance(obj['PATH'], str)
    else:
        assert isinstance(obj['PATH'], bytes)

# Generated at 2022-06-23 14:31:26.887086
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # arrange
    result = 0
    expected = 2
    # act
    test_environ = _TextEnviron({'foo': 'bar', 'boo': 'far'})
    result = len(test_environ)
    # assert
    assert result == expected, "For test_environ, expected %s, got %s" % (expected, result)


# Generated at 2022-06-23 14:31:33.534609
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Test that deleting the variable in environ deletes it in os.environ
    test_environ = _TextEnviron()
    test_environ['TEST__delitem__'] = 'This is string_to_delete'

    assert 'TEST__delitem__' in test_environ
    del test_environ['TEST__delitem__']
    assert 'TEST__delitem__' not in test_environ
    assert 'TEST__delitem__' not in os.environ


# Generated at 2022-06-23 14:31:41.649192
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that the class returns text objects when the bytes are decodable
    # Set up an environment with two strings
    test_env = {b'foo': b'bar', b'unic\xe9': b'baz'}
    environ_wrapper = _TextEnviron(env=test_env, encoding='utf-8')

    # Ensure that the wrapper returns text objects
    assert environ_wrapper[b'foo'] == u'bar'
    assert type(environ_wrapper[b'foo']) is unicode
    assert environ_wrapper[b'unic\xe9'] == u'baz'
    assert type(environ_wrapper[b'unic\xe9']) is unicode

    # Test that the class returns byte strings when the bytes are undecodable
    # Set up an environment with one byte string that can not be dec

# Generated at 2022-06-23 14:31:44.457320
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ = _TextEnviron(env={'key': 'value'})
    del environ['key']
    assert 'key' not in environ


# Generated at 2022-06-23 14:31:49.477892
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['foo'] = 'bar'
    del environ['foo']
    # Check that 'foo' is not in environ
    try:
        assert 'foo' not in environ
    except AssertionError:
        raise AssertionError('"foo" is in environ, though it should not be')


# Generated at 2022-06-23 14:31:57.004642
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test that key can be unicode string
    environ['unicode'] = 'unicode string'
    assert environ['unicode'] == to_text('unicode string', encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict')

    # Test that key can be bytes
    environ[to_bytes('bytes', encoding='utf-8')] = 'bytes string'
    assert environ[to_bytes('bytes', encoding='utf-8')] == to_text('bytes string', encoding='utf-8', nonstring='passthru', errors='surrogate_or_strict')



# Generated at 2022-06-23 14:32:00.751087
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['ANSIBLE_TEST'] = 'тест'
    assert to_text(environ._raw_environ.get('ANSIBLE_TEST')) == 'тест'
    del environ['ANSIBLE_TEST']



# Generated at 2022-06-23 14:32:15.439558
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test that __getitem__ returns the same values as os.environ
    :return:
    """
    # Test Cyrillic and other non-ascii characters
    environ['PYTHON_STR'] = six.u('черноябълка')
    environ['PYTHON_BYTES'] = b'\xd1\x87\xd0\xb5\xd1\x80\xd0\xbd\xd0\xbe\xd1\x8f\xd0\xb1\xd1\x8a\xd0\xbb\xd0\xba\xd0\xb0'
    assert environ['PYTHON_STR'] == six.u('черноябълка')

# Generated at 2022-06-23 14:32:18.049931
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Constructor
    assert isinstance(environ, MutableMapping)
    assert environ.encoding == 'utf-8'


# Generated at 2022-06-23 14:32:22.567189
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    r = []
    e = _TextEnviron(env={'a': 1, 'b': 2, 'c': 3})
    for i in e:
        r.append(i)
    assert sorted(r) == ['a', 'b', 'c']


# Generated at 2022-06-23 14:32:27.475111
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    TestTextEnviron = _TextEnviron()
    TestTextEnviron['key1'] = 'value_1'
    del TestTextEnviron['key1']
    assert TestTextEnviron.get('key1') is None
    TestTextEnviron['key2'] = 'value_2'
    del TestTextEnviron['key2']
    assert TestTextEnviron.get('key2') is None


# Generated at 2022-06-23 14:32:38.665468
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    new_env = _TextEnviron(dict([('foo', 'bar')]))
    assert len(new_env) == 1
    assert 'foo' in new_env
    assert new_env['foo'] == 'bar'
    if PY3:
        assert isinstance(new_env['foo'], str)
    else:
        assert isinstance(new_env['foo'], unicode)

    # override the value of an existing key
    new_env['foo'] = 'baz'
    assert len(new_env) == 1
    assert 'foo' in new_env
    assert new_env['foo'] == 'baz'
    if PY3:
        assert isinstance(new_env['foo'], str)
    else:
        assert isinstance(new_env['foo'], unicode)

    #

# Generated at 2022-06-23 14:32:40.896767
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # 'len(environ)' should return the number of environment variables defined
    assert len(environ) > 0



# Generated at 2022-06-23 14:32:44.861127
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    test_input_dict = {'Test': 'Foobar'}
    test_expected_text_output = {'Test': 'Foobar'}
    assert(_TextEnviron(test_input_dict).__iter__() == test_expected_text_output.__iter__())


# Generated at 2022-06-23 14:32:47.861161
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Given a TextEnviron object
    env = _TextEnviron()

    # When the iter method of the class is called
    iterated = list(iter(env))

    # Then I should get an iterable list of text string
    assert set(iterated) == set(env)

# Generated at 2022-06-23 14:32:53.308644
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_dict = {'a': 'A', 'b': 'B', 'c': 'C'}
    test_env = _TextEnviron(env=test_dict)
    del test_env['a']
    assert test_env._raw_environ == {'b': 'B', 'c': 'C'}


# Generated at 2022-06-23 14:32:55.518831
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = {'a': 'b', 'c': 'd'}
    e = _TextEnviron(env)
    assert len(e) == 2
    env['e'] = 'f'
    assert len(e) == 3
    del env['c']
    assert len(e) == 2



# Generated at 2022-06-23 14:32:57.441319
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron({'ANSIBLE_TEST_DATA': b'bar'}, 'ascii')

    assert environ['ANSIBLE_TEST_DATA'] == 'bar'

    it = iter(environ)
    assert list(it) == ['ANSIBLE_TEST_DATA']



# Generated at 2022-06-23 14:33:00.007173
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    t = _TextEnviron({'this_is': 'not_the_os_environ'})
    assert len(t) == 1



# Generated at 2022-06-23 14:33:09.527911
# Unit test for method __setitem__ of class _TextEnviron

# Generated at 2022-06-23 14:33:12.709823
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    os.environ['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'
    del environ['ANSIBLE_TEST_KEY']
    assert 'ANSIBLE_TEST_KEY' not in environ



# Generated at 2022-06-23 14:33:15.076568
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    result = []
    for env in environ:
        result.append(env)
    assert len(result) == len(environ)

# Generated at 2022-06-23 14:33:19.234881
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    test_environ = _TextEnviron()
    # KeyError if key does not exist
    from six import raise_from
    try:
        badkey = test_environ['badkey']
    except KeyError as e:
        raise_from(AssertionError("Environment variable 'badkey' does not exist"), e)
    # Test key existence
    from six import string_types
    try:
        assert 'PATH' in test_environ
    except AssertionError as e:
        raise_from(AssertionError("Environment variable 'PATH' exists in environment"), e)
    # Test key access
    try:
        assert isinstance(test_environ['PATH'], string_types)
    except AssertionError as e:
        raise_from(AssertionError("Environment variable 'PATH' is a string type"), e)

# Generated at 2022-06-23 14:33:25.015459
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron({u'foo': u'bar', u'baz': u'qux'}, encoding='utf-8')
    assert len(env) == 2

    env = _TextEnviron({b'foo': b'bar', b'baz': b'qux'}, encoding='ascii')
    assert len(env) == 2

# Generated at 2022-06-23 14:33:29.716150
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_environ = _TextEnviron()
    test_environ['test_key'] = 'test_value'
    assert 'test_key' in test_environ
    del test_environ['test_key']
    assert 'test_key' not in test_environ



# Generated at 2022-06-23 14:33:38.611910
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ.encoding == 'utf-8'
    _test_dict = {u'x1': b'val1', b'x2': b'val2', b'x3': u'val3', u'x4': u'val4'}
    textenviron = _TextEnviron(_test_dict)
    assert textenviron[u'x1'] ==  u'val1'
    assert textenviron[b'x2'] ==  u'val2'
    assert textenviron[b'x3'] ==  u'val3'
    assert textenviron[u'x4'] ==  u'val4'
    try:
        textenviron[b'x5']
        raise AssertionError('Expected exception KeyError')
    except KeyError:
        pass

# Generated at 2022-06-23 14:33:50.856789
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test __setitem__ with byte strings
    byte_strings = {b'byte_string': b'foo', b'unicode_string': b'bar',
                    b'bytes_with_null': b'baz\0'}

    for key, value in byte_strings.items():
        environ[key] = value
        assert value == environ._raw_environ[key], 'key {}: _raw_environ'.format(key)
        assert value == environ._value_cache[value], 'key {}: _value_cache'.format(key)

    # Test __setitem__ with text strings
    unicode_strings = {u'byte_string': u'foo', u'unicode_string': u'bar',
                       u'bytes_with_null': u'baz\0'}

# Generated at 2022-06-23 14:34:01.098488
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Unicode string
    env = dict(unicode_text=to_bytes('uniétaire', encoding='utf-8'))
    assert _TextEnviron(env)['unicode_text'] == 'uniétaire'

    # Bytes string
    env = dict(bytes_text=to_bytes('bytes text', encoding='utf-8'))
    assert _TextEnviron(env)['bytes_text'] == 'bytes text'

    # Bytes string in unknown encoding
    env = dict(bytes_unknown=to_bytes('bytes text', encoding='latin1'))
    assert _TextEnviron(env)['bytes_unknown'] == 'bytes text'

    # Unicode string in unknown encoding
    env = dict(unicode_unknown=to_bytes('unicode text', encoding='latin1'))
    assert _TextEnviron(env)

# Generated at 2022-06-23 14:34:12.518476
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    '''
    Test __iter__ method of _TextEnviron()
    '''
    import tempfile
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import binary_type

    def _TextEnviron_iter(obj):
        return set(list(obj))

    os.environ['MY_VAR1'] = 'my value1'
    os.environ['MY_VAR2'] = 'my value2'
    os.environ['MY_VAR3'] = 'my value3'

    # Path separator
    if sys.platform == 'win32':
        path_delimiter = ";"
    else:
        path_delimiter = ":"

    # Make sure our _TextEnviron object is a MutableMapping...

# Generated at 2022-06-23 14:34:21.574948
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test PY3 compatibility
    if PY3:
        test_environ = _TextEnviron(encoding='utf-8')
        test_environ['TEST_ENV'] = u'测试环境'
        assert test_environ['TEST_ENV'] == u'测试环境'

        test_environ = _TextEnviron(encoding='iso-8859-1')
        test_environ['TEST_ENV'] = u'测试环境'
        assert test_environ['TEST_ENV'] == u'测试环境'
        
        test_environ = _TextEnviron(encoding='big5')

# Generated at 2022-06-23 14:34:29.672231
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import mock
    if PY3:
        orig_env = {'a': '1', 'b': '2'}
    else:
        orig_env = {'a': b'1', 'b': b'2'}
    with mock.patch.object(os, 'environ', orig_env):
        text_environ = _TextEnviron()
    assert 'a' in text_environ
    assert text_environ['a'] == '1'
    assert 'b' in text_environ
    assert text_environ['b'] == '2'
    assert len(text_environ) == 2

# Generated at 2022-06-23 14:34:37.169244
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    import unittest
    import tempfile

    class Test__TextEnviron(unittest.TestCase):
        # Simple tests of the constructor and simple accessors, setters and deleters
        def setUp(self):
            self.env = _TextEnviron()

        def test_getitem(self):
            self.assertTrue(self.env['PATH'])
            if PY3:
                self.assertTrue(isinstance(self.env['PATH'], str))
            else:
                self.assertTrue(isinstance(self.env['PATH'], unicode))

        def test_setitem(self):
            self.env['FOO'] = 'BAR'
            self.assertEqual(self.env['FOO'], u'BAR')

# Generated at 2022-06-23 14:34:42.724002
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():

    # setup
    class mock_environ():
        def __len__(self):
            return 3

    class mock_os():
        def environ(self):
            return mock_environ()

    test_os = _TextEnviron(env=mock_os().environ())

    # exercise
    result = len(test_os)

    # verify
    assert result == 3



# Generated at 2022-06-23 14:34:46.480593
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Setup
    e = _TextEnviron()
    data = {'a': 'b', 'c': '6'}
    e._raw_environ = data

    # Test
    del e['a']

    # Verify
    assert data['a'] != e['a']



# Generated at 2022-06-23 14:34:49.245825
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    try:
        del environ['HOME']
    except KeyError:
        pass
    else:
        raise Exception()


# Generated at 2022-06-23 14:34:52.376872
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Check behaviour of an empty dictionary
    e = _TextEnviron()
    assert list(e) == []
    l = ['a', 'b', 'c', 'd']
    e = _TextEnviron(env=l)
    assert list(e) == l

# Generated at 2022-06-23 14:34:56.441731
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert isinstance(environ, MutableMapping)

    te = _TextEnviron()
    assert type(te) == _TextEnviron

    te = _TextEnviron(encoding='ascii')
    assert te.encoding == 'ascii'

# Generated at 2022-06-23 14:35:00.222733
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test __getitem__ function for _TextEnviron class.
    """
    environ['test_var'] = 'test_val'
    assert environ['test_var'] == 'test_val'



# Generated at 2022-06-23 14:35:04.730802
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['testdelitem'] = 'testdelitem'
    test_environ = _TextEnviron(environ=environ)
    del test_environ["testdelitem"]
    # check if item is deleted
    assert 'testdelitem' not in test_environ


# Generated at 2022-06-23 14:35:15.959037
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest

    class Test__TextEnviron___getitem__(unittest.TestCase):

        def test_not_exist(self):
            self.assertRaises(KeyError, environ.__getitem__, b'not_exist')

        def test_exist_but_invalid_type(self):
            # The input is expected to be encoded in utf-8
            self.assertRaises(TypeError, environ.__getitem__, 1)

        def test_exist_but_invalid_data(self):
            os.environ[b'invalid_data'] = b'\xff'

            # The result is expected to be decoded in utf-8
            self.assertRaises(UnicodeDecodeError, environ.__getitem__, 'invalid_data')


# Generated at 2022-06-23 14:35:18.508933
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Just make sure __iter__ doesn't throw an error
    list(environ)

# Generated at 2022-06-23 14:35:24.902530
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    test_env = _TextEnviron()
    # need to get the iterator before checking len
    it = test_env.__iter__()
    assert len(test_env) == len(os.environ)

    # I suppose there's a chance this could fail if the iterator doesn't return in the same order
    # as os.environ.items()
    for (key, value) in os.environ.items():
        assert key == it.__next__()
        assert value == test_env[key]

# Generated at 2022-06-23 14:35:36.144902
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Unit test for method __setitem__ of class _TextEnviron
    """
    # If the environment variable cannot be encoded, try to get the error message in an
    # environment where utf-8 is the encoding
    old_env = os.environ

# Generated at 2022-06-23 14:35:42.832110
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    test_data = {
        'foo': 'bar',
        'baz': 'qux',
        u'ñ': u'éçà',
        'strange': 'å∫ç'.encode('utf-8'),
    }
    environ.clear()
    environ.update(test_data)
    for key, value in test_data.items():
        value_text = to_text(value, encoding=environ.encoding, errors='surrogate_or_strict')
        assert environ[key] == value_text



# Generated at 2022-06-23 14:35:44.339147
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    txt_environ = _TextEnviron()
    assert txt_environ['HOME'] == environ['HOME']

# Generated at 2022-06-23 14:35:51.297838
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import tempfile
    import unittest

    # Create a file that contains a specific utf-8 string
    (tmp_fd, tmp_fname) = tempfile.mkstemp()

# Generated at 2022-06-23 14:35:57.311143
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Positive test
    texttype_environ = _TextEnviron({u'a': u'b', u'b': u'c'}, encoding='utf-8')
    assert len(texttype_environ) == 2
    # Negative test
    texttype_environ = _TextEnviron({1: 2}, encoding='utf-8')
    assert len(texttype_environ) == 1


# Generated at 2022-06-23 14:36:01.509968
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    test_environment = {'a': '1', 'b': '2', 'c': '3'}
    te = _TextEnviron(test_environment)
    assert list(sorted(te)) == ['a', 'b', 'c']

# Generated at 2022-06-23 14:36:11.109853
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Non-ascii characters in environment variable names (not set in env)
    assert(u'\u2019' not in environ)
    assert(u'\u2019' not in environ.keys())
    assert(u'\u2019' not in environ.values())

    # ASCII characters in environment variable names (set in env)
    os.environ['ASCII-KEY'] = 'ASCII-VALUE'
    assert(u'ASCII-KEY' in environ)
    assert(u'ASCII-KEY' in environ.keys())
    assert(u'ASCII-VALUE' in environ.values())

    # Non-ascii charaters in environment variable names (not set in env)
    assert(u'NON-ASCII-KEY' not in environ)

# Generated at 2022-06-23 14:36:18.211450
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Test initialising class _TextEnviron
    my_env = _TextEnviron()

    # Test that method __delitem__ actually modifies the environment
    my_env['test_a'] = 'test'
    assert my_env['test_a'] == 'test'
    del my_env['test_a']
    try:
        assert my_env['test_a'] == None
    except KeyError as e:
        assert e.args[0] == 'test_a'


# Generated at 2022-06-23 14:36:22.123326
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    varname = 'ANSIBLE_TEST_FOO'
    value = 'bar'
    os.environ[varname] = value
    assert to_text(os.environ[varname]) == to_text(value)

    del environ[varname]
    
    assert_exception(KeyError, os.environ.__getitem__, varname)



# Generated at 2022-06-23 14:36:27.277319
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    real_environ = os.environ
    fake_environ = {'foo': 'bar'}

    try:
        os.environ = fake_environ
        te = _TextEnviron()
        assert len(te) == 1, 'TextEnviron should return the length of the environment.'
    finally:
        os.environ = real_environ


# Generated at 2022-06-23 14:36:31.458580
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    test_env = _TextEnviron(env={b'PATH': b'/foo:/bar'}, encoding='utf-8')
    assert 'PATH' in test_env
    assert test_env['PATH'] == u'/foo:/bar'
    pass

# Generated at 2022-06-23 14:36:35.044388
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import copy

    environ_copy = copy.copy(environ)
    del environ['SHELL']
    assert len(environ_copy) == len(environ) + 1
    assert environ_copy['SHELL'] != environ['SHELL']



# Generated at 2022-06-23 14:36:39.825903
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env_iter = environ.__iter__()
    while True:
        try:
            (k, v) = env_iter.__next__()
            assert(isinstance(k, str))
            assert(isinstance(v, str))
        except StopIteration:
            break


# Generated at 2022-06-23 14:36:48.246451
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # create a test environment
    os.environ["AOEU"] = "AOEU"
    os.environ["UNICODE"] = u"\u00c5"
    os.environ["UTF8"] = b"\xc5"
    os.environ["LATIN1"] = b"\xc5"
    os.environ["NONSTRING"] = 1
    os.environ["NONUNICODETEXT"] = "ascii"
    os.environ["NONUNICODEBYTES"] = b"ascii"

    old = _TextEnviron(encoding="ascii")
    assert "AOEU" in old # sanity check
    assert isinstance(old["AOEU"], str)
    assert isinstance(old["UNICODE"], str)
    assert isinstance

# Generated at 2022-06-23 14:36:55.823526
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    class DictObj:
        def __init__(self):
            self.data = {}
            self.values = []
        def __setitem__(self, key, value):
            self.data[key] = value
        def __getitem__(self, key):
            return self.data[key]
        def __delitem__(self, key):
            del self.data[key]
        def __iter__(self):
            return iter(self.values)

    env = _TextEnviron(env=DictObj())
    assert list(env.__iter__()) == []

    env._raw_environ.values.append(123)
    assert list(env.__iter__()) == [123]

    env._raw_environ.values.append(456)

# Generated at 2022-06-23 14:37:03.476833
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    os_environ = _TextEnviron(env=environ)
    os_environ[b'test'] = b'value'
    assert os_environ[b'test'] == u'value'
    os_environ[u'test2'] = u'value2'
    assert os_environ[u'test2'] == u'value2'
    try:
        os_environ[u'test3'] = 10
        assert False
    except Exception as e:
        assert True

# Generated at 2022-06-23 14:37:08.827866
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_bytes
    environ = _TextEnviron({'a': 'b', 'c': 'd'}, encoding='utf-8')
    for key in environ:
        assert environ[key] == to_bytes(key, encoding='utf-8', nonstring='strict',
                                        errors='surrogate_or_strict')


if __name__ == '__main__':
    # Unit test for method __getitem__ of class _TextEnviron
    test__TextEnviron___getitem__()

# Generated at 2022-06-23 14:37:10.889548
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert sorted(environ.__iter__()) == sorted(os.environ.__iter__())



# Generated at 2022-06-23 14:37:20.192857
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    assert(
        b'\xed\xa0\x80\xed\xbf\xbf' == environ.__setitem__('key1', '\ud800\udfff')
    )
    assert(
        b'\xed\xa0\x80\xed\xbf\xbf' == environ.__setitem__('key2', '\ud800\udfff')
    )
    assert(
        b'\xed\xbf\xbf\xed\xa0\x80' == environ.__setitem__('key3', '\ud7ff\udc00')
    )

# Generated at 2022-06-23 14:37:23.424148
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ_test = _TextEnviron({'test': u'\u2600'})
    assert environ_test['test'] == u'\u2600'

# Generated at 2022-06-23 14:37:27.646452
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    mock_environ = {}
    env = _TextEnviron(env=mock_environ)
    env['a'] = '1'
    assert env['a'] == '1'
    del env['a']
    assert 'a' not in env



# Generated at 2022-06-23 14:37:33.788923
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Need to build a new os.environ clone (not os.environ itself) to test the __contains__ and
    # __setitem__ methods
    new_env = _TextEnviron()
    assert 'HOME' in new_env
    new_env['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'
    assert 'ANSIBLE_TEST_KEY' in new_env
    assert 'ANSIBLE_TEST_VALUE' == new_env['ANSIBLE_TEST_KEY']
    del new_env['ANSIBLE_TEST_KEY']
    assert 'ANSIBLE_TEST_KEY' not in new_env

# Generated at 2022-06-23 14:37:35.658802
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert [element for element in environ] == [element for element in environ._raw_environ]



# Generated at 2022-06-23 14:37:39.486858
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Create instance of class _TextEnviron
    text_environ = _TextEnviron(encoding='utf-8')

    # Test with os.environ returns object of class int
    assert isinstance(text_environ.__len__(), int)



# Generated at 2022-06-23 14:37:43.687999
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    _TextEnviron(env={'ANSIBLE_FORCE_COLOR': 'true',
                      b'PATH': '/home/toshio/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin',
                      'ANSIBLE_NOCOLOR': 'false'})

