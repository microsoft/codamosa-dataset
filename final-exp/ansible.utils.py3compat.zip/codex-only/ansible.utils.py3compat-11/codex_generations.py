

# Generated at 2022-06-23 14:27:53.051286
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    os.environ.pop('ANSIBLE_TEST_ENV_KEY', None)
    assert len(env) == len(os.environ)

    os.environ['ANSIBLE_TEST_ENV_KEY'] = 'bar'
    assert len(env) == len(os.environ)
    del os.environ['ANSIBLE_TEST_ENV_KEY']

    env['ANSIBLE_TEST_ENV_KEY'] = 'foo'
    assert len(env) == len(os.environ)



# Generated at 2022-06-23 14:27:56.208859
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({'a': 'b', 'c': 'd'})
    assert sorted(env.__iter__()) == ['a', 'c']



# Generated at 2022-06-23 14:28:02.475570
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    original_environ = {b'ANSIBLE_FOO': u'バー', u'ANSIBLE_BAR': 'baZ', 'ANSIBLE_BAZ': b'1234'}
    #
    # Make sure we're not changing the original os.environ
    #
    for key in original_environ:
        if isinstance(key, str):
            del os.environ[key]
        else:
            del os.environ[to_bytes(key)]

    #
    # Set the environ object we're testing on to our custom data
    #
    environ._raw_environ = original_environ.copy()
    environ._value_cache = {}

    #
    # Check that we're returning appropriate things
    #

# Generated at 2022-06-23 14:28:11.777763
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # The class is supposed to return text strings from the environment instead of byte strings
    # Mimics the behaviour of os.environ on Python3
    # Test it both on python2 and python3
    if hasattr(environ, '__test__'):
        del environ.__test__
    environ.__test__ = '我是谁'
    if PY3:
        assert environ.__test__ == '我是谁'
    # Test it on python2
    else:
        assert environ.__test__ == u'我是谁'
    if hasattr(environ, '__test__'):
        del environ.__test__


# Generated at 2022-06-23 14:28:13.544922
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    _TextEnviron.__setitem__(environ, 'key1', 'value1')
    return _TextEnviron.__getitem__(environ, 'key1')

# Generated at 2022-06-23 14:28:17.486721
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ["test_for_utf-8"] = "value of test_for_utf-8"
    assert environ["test_for_utf-8"] == "value of test_for_utf-8"
    assert "test_for_utf-8" in environ

# Generated at 2022-06-23 14:28:28.806895
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # do not modify the original 'os.envrion'
    env = dict(os.environ)

    # test case: environment variable by name of '_TextEnviron' existed
    assert os.environ['_TextEnviron'] is not None
    assert env['_TextEnviron'] is not None
    assert os.environ['_TextEnviron'] == env['_TextEnviron']
    # test case: if '__init__' is not called, the encoding is utf-8
    assert environ._TextEnviron__init__() is None
    assert environ.encoding == 'utf-8'
    # test case: if '__init__' is called, the encoding is utf-8, this case is non-sense
    assert environ._TextEnviron__init__(env=env, encoding=environ.encoding)

# Generated at 2022-06-23 14:28:31.314365
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    test_dict = {b'foo': b'bar'}
    test_obj = _TextEnviron(env=test_dict)
    assert len(test_dict) == len(test_obj)


# Generated at 2022-06-23 14:28:34.152095
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ = _TextEnviron()
    environ[to_text('hello')] = 'world'
    assert environ[to_text('hello')] == 'world'
    del environ[to_text('hello')]
    assert to_text('hello') not in environ


# Generated at 2022-06-23 14:28:37.642593
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ = _TextEnviron(env={'foo': b'bar'})
    assert len(environ) == 1
    assert environ['foo'] == u'bar'

# Generated at 2022-06-23 14:28:40.327869
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['PYTHONIOENCODING']  = 'ascii'
    assert isinstance(environ['PYTHONIOENCODING'], str)

# Generated at 2022-06-23 14:28:44.671064
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    myenv = _TextEnviron({b'a': b'1', 'b': '2', b'c': b'3'}, encoding='utf-8')
    assert myenv[b'a'] == '1'
    assert myenv['b'] == '2'
    assert myenv['c'] == '3'

# Generated at 2022-06-23 14:28:56.036247
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest

    class MockDict(MutableMapping):
        def __init__(self, *args, **kwargs):
            super(MockDict, self).__init__(*args, **kwargs)
            self.data_dict = {}

        def __getitem__(self, key):
            return self.data_dict[key]

        def __setitem__(self, key, val):
            self.data_dict[key] = val

        def __delitem__(self, key):
            del self.data_dict[key]

        def __iter__(self):
            return self.data_dict.__iter__()

        def __len__(self):
            return len(self.data_dict)


# Generated at 2022-06-23 14:29:05.732209
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    string = "value"
    as_bytes = to_bytes(string)
    UTF8_encoded = to_bytes(string, encoding='utf-8')
    UTF16_encoded = to_bytes(string, encoding='utf-16')
    DEFAULT_encoded = to_bytes(string, encoding=sys.getfilesystemencoding())

    # If os.environ has a value in it, then we can't set it back to a
    # random value and expect it to stay there.  We have to use a
    # value that already exists.
    key = 'PATH' if key in environ else 'ANSIBLE_TEST_ENV_KEY'
    saved_value = environ[key]
    # 1. If value is already bytes, it just passes through
    environ[key] = as_bytes

# Generated at 2022-06-23 14:29:15.573662
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ_copy = dict(environ)
    assert 'testenv' not in os.environ
    environ.__delitem__('testenv')
    assert 'testenv' not in os.environ
    assert 'testenv' not in environ
    environ['testenv'] = 'testval'
    assert 'testenv' in os.environ
    assert 'testenv' in environ
    environ.__delitem__('testenv')
    assert 'testenv' not in os.environ
    assert 'testenv' not in environ
    environ.clear()
    environ.update(environ_copy)


# Generated at 2022-06-23 14:29:17.994739
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ.clear()
    environ['testing'] = 'testing'
    assert isinstance(environ['testing'], str)

# Generated at 2022-06-23 14:29:21.106173
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Test that os.environ is updated when item is removed.
    """
    environ['TEST_ENVIRON__TEST_ENVIRON___delitem__'] = 'a'
    environ.__delitem__('TEST_ENVIRON__TEST_ENVIRON___delitem__')
    assert 'TEST_ENVIRON__TEST_ENVIRON___delitem__' not in os.environ


# Generated at 2022-06-23 14:29:26.888013
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Test with default encoding
    environ_instance = _TextEnviron(encoding='utf-8')
    assert 'TEST_KEY' not in environ_instance
    environ_instance['TEST_KEY'] = 'foo'
    assert 'TEST_KEY' in environ_instance
    del environ_instance['TEST_KEY']
    assert 'TEST_KEY' not in environ_instance

    # Test with non-default encoding
    environ_instance = _TextEnviron(encoding='latin-1')
    assert 'TEST_KEY' not in environ_instance
    environ_instance['TEST_KEY'] = 'foo'
    assert 'TEST_KEY' in environ_instance
    del environ_instance['TEST_KEY']
    assert 'TEST_KEY' not in environ_

# Generated at 2022-06-23 14:29:37.213393
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Unit test for method __setitem__ of class _TextEnviron.
    """

    # Create a placeholder environment
    os.environ = {}

    # Create an instance of _TextEnviron
    test_environ = _TextEnviron(env={})

    # Set the value of a single element in os.environ
    test_environ['ANSIBLE_ANSIBLE_VERSION'] = '2.7.13'

    # Create a bytestring to compare the value of the set element to
    expected_byte_string = b'2.7.13'

    # Assert the value of the element set is as expected
    assert test_environ._raw_environ['ANSIBLE_ANSIBLE_VERSION'] == expected_byte_string



# Generated at 2022-06-23 14:29:40.787074
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    result = _TextEnviron(encoding='utf-8')
    result['key'] = 'value'
    assert len(result) == 1
    assert result['key'] == 'value'



# Generated at 2022-06-23 14:29:49.442406
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils.six import u
    from ansible.module_utils._text import to_text

    env = _TextEnviron()

    # Test 1: Verify that unicode/text characters are returned
    env[u('ansible_test')] = u('ansible_unicode_value')
    check_value = env[u('ansible_test')]
    assert isinstance(check_value, to_text)
    assert check_value == u('ansible_unicode_value')

    # Test 2: Verify that non-unicode characters are returned
    env[u('ansible_test')] = u('ansible_non_unicode_value').encode('utf-8')
    check_value = env[u('ansible_test')]
    assert isinstance(check_value, to_text)


# Generated at 2022-06-23 14:29:52.646171
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # None
    try:
        _ = len(environ)
    except Exception as e:
        test = False
    else:
        test = True
    assert test
    # Defined
    try:
        _ = len(environ)
    except Exception as e:
        test = False
    else:
        test = True
    assert test


# Generated at 2022-06-23 14:29:59.537230
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron(encoding='utf-8')
    env[u'key1'] = u'value1'
    assert env[u'key1'] == u'value1'
    env[u'key2'] = to_bytes(u'value2', encoding='utf-8')
    assert env[u'key2'] == u'value2'

    env = _TextEnviron(encoding='ascii')
    env[u'key1'] = u'value1'
    assert env[u'key1'] == u'value1'
    env[u'key2'] = to_bytes(u'value2', encoding='ascii')
    assert env[u'key2'] == u'value2'


# Generated at 2022-06-23 14:30:01.313532
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron()



# Generated at 2022-06-23 14:30:04.785174
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = {'A': 'B', 'C': 'D'}
    result = set(e for e in _TextEnviron(env))
    expected = {'A', 'C'}
    assert result == expected, 'Got: {}\nExpected: {}'.format(result, expected)


# Generated at 2022-06-23 14:30:13.207869
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Test 1
    list_ = [('ANSIBLE_CACHE_PLUGIN', 'jsonfile'), ('ANSIBLE_CACHE_PLUGIN_CONNECTION', 'ansible_cache')]
    environ = _TextEnviron(env=dict(list_))
    assert len(environ) == 2

    # Test 2
    environ = _TextEnviron(encoding='utf-8')
    assert len(environ) == len(os.environ)

    # Test 3
    environ = _TextEnviron(env={})
    assert len(environ) == 0



# Generated at 2022-06-23 14:30:21.804492
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = {b'non_ascii': b'\xe4\xb8\xad\xe6\x96\x87'}
    text_env = _TextEnviron(env=env, encoding='utf-8')
    assert isinstance(text_env['non_ascii'], str)
    assert text_env['non_ascii'] == u'\u4e2d\u6587'
    assert text_env._raw_environ['non_ascii'] == b'\xe4\xb8\xad\xe6\x96\x87'
    assert text_env._value_cache[b'\xe4\xb8\xad\xe6\x96\x87'] == u'\u4e2d\u6587'


# Generated at 2022-06-23 14:30:29.455229
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    test_str = 'value'
    test_str_enc = to_bytes(test_str, encoding=environ.encoding, nonstring='strict', errors='surrogate_or_strict')
    os.environ = {}
    os.environ['key'] = test_str_enc
    os.environ['key2'] = test_str_enc
    _environ = _TextEnviron(env=os.environ)
    iter_list = list(_environ.__iter__())
    assert iter_list == ['key', 'key2']

# Generated at 2022-06-23 14:30:35.938528
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert _TextEnviron({'test': '123'}) == {'test': '123'}
    assert _TextEnviron({b'test': b'123'}) == {'test': '123'}
    assert _TextEnviron({b'test': b'123'}, encoding='utf-8') == {'test': '123'}
    assert _TextEnviron({b'test': b'123'}, encoding='ascii') == {'test': '123'}



# Generated at 2022-06-23 14:30:41.736037
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    try:
        del environ['test_key']
    except KeyError:
        # Python2 raises an exception.  Python3 doesn't
        pass

    # We rely on the fact that the set methods transform unicode to bytes for us
    environ['test_key'] = u'value1'
    assert environ['test_key'] == u'value1'
    assert os.environ['test_key'] == u'value1'.encode('utf-8')

    environ['test_key'] = 'value2'
    assert environ['test_key'] == 'value2'
    assert os.environ['test_key'] == 'value2'.encode('utf-8')

    # We rely on the fact that the get methods transform bytes to text for us

# Generated at 2022-06-23 14:30:43.065758
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    pass
    # assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:30:49.138379
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    testenviron = _TextEnviron()
    testenviron['foo'] = u'bar'
    assert testenviron['foo'] == u'bar'
    testenviron['numeric'] = 10
    assert testenviron['numeric'] == '10'
    assert type(testenviron['numeric']) == str



# Generated at 2022-06-23 14:30:59.382116
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    When setitem is called with a text object, it converts it to bytes using the specified
    encoding and sets it in the environment.
    """
    from ansible.module_utils.six import PY3

    env = _TextEnviron()
    env['ANSIBLE_TEST_KEY'] = b'ANSIBLE_TEST_VALUE'
    if PY3:
        assert env['ANSIBLE_TEST_KEY'] == b'ANSIBLE_TEST_VALUE'
        assert env._raw_environ['ANSIBLE_TEST_KEY'] == b'ANSIBLE_TEST_VALUE'
    else:
        assert env['ANSIBLE_TEST_KEY'] == u'ANSIBLE_TEST_VALUE'
        assert env._raw_environ['ANSIBLE_TEST_KEY'] == b'ANSIBLE_TEST_VALUE'

# Generated at 2022-06-23 14:31:04.007821
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    temp_environ = {'TESTKEY1': 'TESTVALUE1', 'TESTKEY2': 'TESTVALUE2'}
    t_environ = _TextEnviron(env=temp_environ)
    assert set(t_environ.__iter__()) == set(temp_environ.__iter__())


# Generated at 2022-06-23 14:31:11.148960
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Create a copy of os.environ to work on
    test_environ = os.environ.copy()
    # Delete a value from our copy of os.environ and check that it was deleted
    del test_environ['SHELL']
    assert 'SHELL' not in test_environ
    test_environ['SHELL'] = '/bin/bash'
    assert 'SHELL' in test_environ

    # Create a new instance of _TextEnviron to test with
    new_environ = _TextEnviron(env=test_environ)
    assert 'SHELL' in new_environ
    del new_environ['SHELL']
    assert 'SHELL' not in new_environ
    # Check that the original test_environ also has the value deleted from it
    assert 'SHELL' not in test_en

# Generated at 2022-06-23 14:31:18.583827
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Test for method _TextEnviron.__delitem__ of class _TextEnviron.
    """
    # Set initial values
    key = 'Key'
    value = 'Value'
    # Create temp environ
    myEnviron = _TextEnviron()
    myEnviron[key] = value
    # Execute method delete environ
    del myEnviron[key]
    # Check result
    assert key not in myEnviron.keys()



# Generated at 2022-06-23 14:31:19.642952
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) > 0



# Generated at 2022-06-23 14:31:30.413272
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ['ANSIBLE_MODULE_TEST_VAR_1'] = 'ANSIBLE_MODULE_TEST_VAR_1'
    assert len(environ) == len(os.environ)
    os.environ['ANSIBLE_MODULE_TEST_VAR_2'] = 'ANSIBLE_MODULE_TEST_VAR_2'
    assert len(environ) == len(os.environ)
    del os.environ['ANSIBLE_MODULE_TEST_VAR_1']
    assert len(environ) == len(os.environ)
    del os.environ['ANSIBLE_MODULE_TEST_VAR_2']
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:31:36.215545
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():

    test_environ = {}

    test_environ['first'] = 'apple'
    test_environ['second'] = 'orange'
    test_environ['third'] = 'grapefruit'

    text_environ = _TextEnviron(env=test_environ)

    assert(len(text_environ) == 3)

    assert(len(test_environ) == 3)


# Generated at 2022-06-23 14:31:40.503398
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ.clear()
    environ['PATH'] = 'test/test/test'
    assert len(environ) == 1
    assert 'PATH' in environ
    assert environ['PATH'] == 'test/test/test'

# Generated at 2022-06-23 14:31:51.551741
# Unit test for method __iter__ of class _TextEnviron

# Generated at 2022-06-23 14:31:58.501880
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    # Test deletion of an environment variable we have read access to
    environ['__deletable__'] = '1'
    del environ['__deletable__']
    assert os.getenv('__deletable__') is None

    # Test that deletion of an environment variable we don't have read access to raises an exception
    # since we can't detect if the variable exists
    try:
        del environ['__undeletable__']
    except KeyError:
        # If the variable doesn't exist yet, deletion will raise a KeyError
        pass
    except OSError:
        # If the variable already existed, deletion will raise an OSError on POSIX systems
        pass



# Generated at 2022-06-23 14:32:08.299770
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """Test _TextEnviron.__iter__"""
    # If there is an error in _TextEnviron.__iter__, the whole of ansible fails to start with a
    # Python error.  We want to test the pure python environment now to validate the __iter__
    # method without involving any other part of Ansible (like the imports)
    #
    # So we need to bypass Ansible's monkey patcher.  This is easy to do.  Ansible will provide
    # the module with a "self.get_bin_path" object which has a "exec_module" method.  All we have
    # to do is call that and pass in our own version of os.  Of course, we also have to provide
    # our own version of the module_utils that contains _done_after and get_bin_path.
    #
    # NOTE: this

# Generated at 2022-06-23 14:32:18.041306
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = {'SOME_KEY': u'value_1',
           u'SOME_OTHER_KEY': 'value_2',
           b'SOME_BYTES_KEY': 'value_3',
           'ANOTHER_KEY': b'\xc2\x9f\xec\xa0\x80\xe2\x84\x91'}

    os.environ.clear()
    for env_key, env_value in env.items():
        os.environ[env_key] = env_value

    # Mimic Python3 os.environ
    text_environ = _TextEnviron(encoding='utf-8')
    assert text_environ['SOME_KEY'] == u'value_1'
    assert text_environ['SOME_OTHER_KEY'] == u'value_2'


# Generated at 2022-06-23 14:32:21.258074
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    environ.__setitem__('LC_ALL', 'es_MX.utf8')
    assert environ['LC_ALL'] == 'es_MX.utf8'

# Generated at 2022-06-23 14:32:29.895316
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Note: This is a unit test that is a bit out of place.  The normal way to do this would be to
    # put the test in a class and use the class' instance of environ.  Unfortunately, part of the
    # point of this is to test the global environ and the scope of the module.
    # First test that it works for utf-8 encoded values
    environ['MY_VAR'] = u'myvalue'
    assert environ['MY_VAR'] == u'myvalue'

    # Now test that it works for non-utf8 encoded values
    environ['MY_VAR'] = b'\x80x'
    print(repr(environ['MY_VAR']))
    assert environ['MY_VAR'] == u'\x80x'

# Generated at 2022-06-23 14:32:40.990295
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import os
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3

    test_key = 'python_path'
    test_value = ':'.join(sys.path)
    os.environ[test_key] = to_bytes(test_value)
    if PY3:
        assert environ[test_key] == test_value
    else:
        assert environ[test_key] == to_text(test_value, encoding=environ.encoding,
                                            errors='surrogate_or_strict', nonstring='passthru')
    del environ[test_key]
    assert test_key not in os.environ

# Generated at 2022-06-23 14:32:48.333725
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test for valid cases for __setitem__
    # Method parameters and expected return values
    environ['foo'] = 'bar'
    assert environ['foo'] == 'bar'
    # With non string value
    environ['foo'] = [1]
    assert environ['foo'] == '[1]'

    # Test for invalid cases for __setitem__
    # Method parameters and expected return values
    # With invalid string value
    try:
        environ['foo'] = '[1'
        assert False, 'Expected non string value to fail'
    except TypeError:
        assert True
    except:
        assert False, 'Expected TypeError exception'



# Generated at 2022-06-23 14:32:58.671516
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils._text import to_text

    e = _TextEnviron(env={'SPAM': 'eggs'}, encoding='ascii')
    assert e['SPAM'] == to_text('eggs', encoding='ascii')

    e = _TextEnviron(env={'SPAM': 'eggs'}, encoding='ascii')
    assert e['SPAM'] == to_text('eggs', encoding='ascii')
    assert e['SPAM'] == to_text('eggs', encoding='ascii')

    e = _TextEnviron(env={'SPAM': 'eggs'}, encoding='utf-8')
    assert e['SPAM'] == to_text('eggs', encoding='utf-8')


# Generated at 2022-06-23 14:33:07.258034
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import unittest
    import random
    import string

    class _TextEnviron_TestCase(unittest.TestCase):
        def setUp(self):
            self.environKey = 'tingo'
            self.environValue = 'tango'
            self.maxDiff = None
            os.environ[self.environKey] = self.environValue

        def runTest(self):
            testEnv = _TextEnviron()
            expectedEnviron = os.environ.copy()
            self.assertEqual(iter(testEnv), iter(expectedEnviron))
            del os.environ[self.environKey]

    unittest.main()



# Generated at 2022-06-23 14:33:16.811742
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    def __setup_environ():
        environ = {}
        environ['a1'] = 'aaa'
        environ['a2'] = 'bbb'
        environ['a3'] = 'ccc'
        return environ

    def __examine_environ(environ, length, key, value):
        assert length == len(environ.__getattribute__('_raw_environ'))
        assert key in environ.__getattribute__('_raw_environ').keys()
        assert value == environ.__getattribute__('_raw_environ')[key]
        assert value == environ.__getattribute__('_value_cache')[key]
        assert value == environ.__getitem__(key)

    # Test with normal input
    environ = _TextEnviron()

# Generated at 2022-06-23 14:33:21.357064
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Test direct access
    d = {
        b'key1': b'value1',
        b'key2': b'value2',
        b'key3': b'value3',
    }
    env = _TextEnviron(env=d)
    assert len(env) == 3



# Generated at 2022-06-23 14:33:26.245802
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = {'foo': '\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e'}
    te = _TextEnviron(env)
    assert isinstance(te['foo'], str)
    assert te['foo'] == '日本語'

# Generated at 2022-06-23 14:33:30.690670
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    valid_key = 'ä'
    invalid_key = u'\x1b'
    valid_val = valid_key
    invalid_val = invalid_key
    environ[valid_key] = valid_val
    environ[invalid_key] = invalid_val

# Generated at 2022-06-23 14:33:33.893720
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    e = _TextEnviron()
    if PY3:
        assert e.encoding == sys.getfilesystemencoding()
    else:
        assert e.encoding == 'utf-8'



# Generated at 2022-06-23 14:33:36.416733
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ["TEST"] = "test_value"
    assert len(environ) == len(os.environ)
    del os.environ["TEST"]



# Generated at 2022-06-23 14:33:43.277221
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # Test scenario:

    # Environment variable value is Unicode, decoding succeeds with correct encoding
    os.environ['TEST_ENV_1'] = u'Test string 1'
    assert environ['TEST_ENV_1'] == u'Test string 1'

    # Environment variable value is bytes, encoding works
    os.environ['TEST_ENV_2'] = u'Test string 2'.encode('utf-8')
    assert environ['TEST_ENV_2'] == u'Test string 2'

    # Environment variable value is bytes, encoding fails
    os.environ['TEST_ENV_3'] = u'Test string 3'.encode('latin-1')

# Generated at 2022-06-23 14:33:46.035976
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert 0 == len(_TextEnviron(env={}))
    assert 1 == len(_TextEnviron(env={'a': 'b'}))



# Generated at 2022-06-23 14:33:47.062152
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    len(environ)



# Generated at 2022-06-23 14:33:50.337987
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    try:
        _TextEnviron.__setitem__("ABCD", "efgh")
    except Exception:
        _TextEnviron.__setitem__("ABCD", "efgh")
        pass


# Generated at 2022-06-23 14:33:51.846173
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['PWD'] == '/home/toshio'

# Generated at 2022-06-23 14:34:01.649292
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    TEST_KEY = 'ANSIBLE_TEST_KEY'
    class _TestBytesError(Exception):
        pass
    def _test_bytes_value_error(error_bytes, test_val):
        try:
            value = to_bytes(test_val, encoding='utf-8', nonstring='strict', errors='strict')
        except UnicodeEncodeError as e:
            actual = e.object
            if actual != error_bytes:
                raise _TestBytesError("Expected %s, got %s" % (error_bytes, actual))
            return
        raise _TestBytesError("Nonstring conversion should have failed!")

    environ[TEST_KEY] = u"test_str"
    os.environ[TEST_KEY] = "test_str"

    environ[TEST_KEY] = 5
   

# Generated at 2022-06-23 14:34:07.073029
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """
    Test __iter__ method of class _TextEnviron
    """
    env = os.environ.copy()
    env['TEST_VAR'] = 'TEST_VAR'
    m_env = _TextEnviron(env=env)
    assert ('TEST_VAR' in m_env)



# Generated at 2022-06-23 14:34:10.399486
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # when
    value = environ["PATH"]

    # then
    # When environ["PATH"] is called, it is the same as calling os.environ["PATH"]
    assert value == os.environ["PATH"]


# Generated at 2022-06-23 14:34:20.499856
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import unittest

    class tests(unittest.TestCase):
        def test_value_in_cache(self):
            import copy
            env = copy.deepcopy(os.environ)
            # Make sure we're running in the encoding that os.environ uses
            assert os.environ[b'TEST_UNICODE'].decode('utf-8') == u'\U0001f4a9'
            textenviron = _TextEnviron(env=env, encoding='utf-8')
            textenviron._value_cache[b'\xf0\x9f\x92\xa9'] = u'\U0001f4a9'
            # We're testing __getitem__ so we only need to set the undecoded value

# Generated at 2022-06-23 14:34:26.419257
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert( os.environ['PATH'] is not None )

    # Save original value of PATH
    path = environ['PATH']

    # Remove PATH.  It should still be present in environ
    del os.environ['PATH']
    assert('PATH' in environ)
    assert( len(environ) == len(os.environ) )

    # Restore PATH
    environ['PATH'] = path

# Generated at 2022-06-23 14:34:30.266447
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    text_dict = _TextEnviron(encoding='utf-8')
    assert len(text_dict) == len(os.environ)
    text_dict['HELLO'] = u'World'
    assert len(text_dict) == len(os.environ) + 1


# Generated at 2022-06-23 14:34:36.781803
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron()

    env['value'] = u'\u6f22\u5b57'
    if PY3:
        assert env['value'] == u'\u6f22\u5b57', 'TextEnviron() failed to store unicode correctly'
    else:
        assert env['value'] == u'\u6f22\u5b57'.encode('utf-8'), 'TextEnviron() failed to store unicode correctly'


# Generated at 2022-06-23 14:34:42.358229
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # Create a sample dict
    test_dict = {
        'KEY_ONE': 'Välüe 1',
        'KEY_TWO': 'Välüe 2',
        'KEY_THREE': 'Välüe 3',
    }

    # Should return an iterator on the dict keys
    assert list(environ) == list(test_dict.keys())


# Generated at 2022-06-23 14:34:50.510552
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron(encoding='ascii')
    assert env.encoding == 'ascii'
    assert env['PWD'] == os.environ['PWD']
    env['FOO'] = 'bar'
    assert env['FOO'] == 'bar'
    assert os.environ['FOO'] == 'bar'
    assert len(env) == len(os.environ)
    assert list(env.keys()) == list(os.environ.keys())
    assert list(env.values()) == list(os.environ.values())
    assert list(env.items()) == list(os.environ.items())
    del env['FOO']
    assert os.environ['FOO'] == 'bar'
    assert list(env.keys()) != list(os.environ.keys())
   

# Generated at 2022-06-23 14:34:56.480034
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import os
    import sys

    # Set up environment.
    os.environ.clear()
    os.environ["SHELL"] = "bash"

    # Make sure we are on Python 2.
    if sys.version_info[0] != 2:
        print("Code tested only on Python 2.7")
        sys.exit(1)

    # Check that _TextEnviron.__getitem__() returns unicode string on Python 2.
    env = _TextEnviron()
    assert(isinstance(env["SHELL"], unicode))
    assert(isinstance(env["SHELL"], str))



# Generated at 2022-06-23 14:35:02.306452
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    import os
    import unittest
    import sys

    class Environ(MutableMapping):

        def __init__(self, env=None, encoding=None):
            if env is None:
                env = os.environ
            self._raw_environ = env
            self._value_cache = {}
            # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
            # instead of utf-8
            if encoding is None:
                # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding() 
                # instead of utf-8
                self.encoding = sys.getfilesystemencoding()
            else:
                self.enc

# Generated at 2022-06-23 14:35:11.308278
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Function to test method `__getitem__` of class `_TextEnviron`
    Test cases are as follows:
        1. Test case when environment variables are decoded
            Expected:
                (1) Value of the environment variable is decoded
        2. Test case when environment variables are not decoded
            Expected:
                (1) Value of the environment variable is not decoded
    """

# Generated at 2022-06-23 14:35:13.781042
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    environ = _TextEnviron()
    assert len(environ) > 0


# Generated at 2022-06-23 14:35:17.977799
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    '''_TextEnviron: test __delitem__ method'''
    environ.clear()
    environ['KEY1'] = 'VALUE1'
    environ['KEY2'] = 'VALUE2'
    environ['KEY3'] = 'VALUE3'
    assert 'KEY2' in environ
    del environ['KEY2']
    assert 'KEY2' not in environ


# Generated at 2022-06-23 14:35:28.237424
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import random
    import string
    random_str = lambda n: ''.join(random.SystemRandom().choice(
        string.ascii_uppercase + string.digits) for _ in range(n))
    environ['ABC'] = '123'
    environ['DEF'] = to_text('456', 'utf-8')
    environ['GHI'] = to_bytes('789', 'utf-8')
    environ['JKL'] = to_bytes(random_str(100000), 'utf-8')
    assert len(environ) >= 4
    assert 'ABC' in environ
    assert 'DEF' in environ
    assert 'GHI' in environ
    assert 'JKL' in environ
    # Test __iter__

# Generated at 2022-06-23 14:35:31.401643
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    _environ = _TextEnviron()
    assert len(_environ) == len(os.environ)



# Generated at 2022-06-23 14:35:40.283090
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from io import StringIO
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Class _TextEnviron to test
    class _TextEnviron(MutableMapping):
        """
        Utility class to return text strings from the environment instead of byte strings

        Mimics the behaviour of os.environ on Python3
        """
        def __init__(self, env=None, encoding=None):
            if env is None:
                env = os.environ
            self._raw_environ = env
            self._value_cache = {}
            # Since we're trying to mimic Python3's os.environ, use sys.getfilesystemencoding()
            # instead of utf-8

# Generated at 2022-06-23 14:35:45.709684
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Make sure _TextEnviron is a drop-in replacement for os.environ
    """
    if PY3:
        return

    env = _TextEnviron(encoding='latin-1')
    os.environ[b'key'] = b'\xA9'
    assert env['key'] == u'\xa9'

# Generated at 2022-06-23 14:35:50.201965
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Unit test for method __setitem__ of class _TextEnviron
    """
    env = _TextEnviron(encoding='utf-8')
    env['ANSIBLE_TEST_1'] = '私'
    assert env['ANSIBLE_TEST_1'] == '私'
    env['ANSIBLE_TEST_2'] = 'Я'
    assert env['ANSIBLE_TEST_2'] == 'Я'



# Generated at 2022-06-23 14:35:59.497113
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = _TextEnviron(encoding='utf-8')
    # test set for utf-8
    env['utf-8'] = '\xa4\xa2\xa4\xa4\xa4\xa6\xa4\xa8\xa4\xaa'
    assert env['utf-8'] == '\xa4\xa2\xa4\xa4\xa4\xa6\xa4\xa8\xa4\xaa'
    # test set for non-ascii byte string
    env['latin-1'] = '\xe8\xa8\x80\xe8\xaa\x9e'
    assert env['latin-1'] == '\xe8\xa8\x80\xe8\xaa\x9e'
    # test set for non-ascii character
    env

# Generated at 2022-06-23 14:36:07.632431
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # create a mock os environment
    os_environ = {}
    # initialise mock environment for test
    env = _TextEnviron(os_environ, encoding='utf-8')
    # test setup
    key = u'ansible_become_pass'
    value = u'Łódź'
    # test execution
    env[key] = value
    # test result
    result = os_environ[key]
    assert isinstance(result, str)
    assert result == value.encode('utf-8')

# Generated at 2022-06-23 14:36:18.164540
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Expected result on Python 2
    expected_result_py2 = {
        'test_key': 'test_val',
        'test_key2': 'test_val2',
        'test_key3': 'test_val3',
    }

    # Expected result on Python 3
    expected_result_py3 = {
        'test_key': 'test_val',
        'test_key2': 'test_val2',
        'test_key3': 'test_val3',
    }

    if PY3:
        expected_result = expected_result_py3
    else:
        expected_result = expected_result_py2


# Generated at 2022-06-23 14:36:21.547811
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    raw_env = os.environ.copy()
    try:
        os.environ['foo'] = b'bar'
        os.environ['baz'] = b'qux'

        assert len(environ) == len(os.environ)
    finally:
        os.environ.clear()
        os.environ.update(raw_env)



# Generated at 2022-06-23 14:36:23.460505
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron(env=dict(foo='bar'))
    assert next(iter(env)) == 'foo'



# Generated at 2022-06-23 14:36:34.922339
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    #
    # Test for PY3
    #
    # Prepare
    environ._raw_environ = {
        'key1': 'value1'
    }
    environ.encoding = None
    PY3_save = PY3
    PY3 = True
    # Execute
    value = environ['key1']
    # Assert
    assert value == 'value1'
    # Clean up
    PY3 = PY3_save
    #
    # Test for PY2
    #
    # Prepare
    environ._raw_environ = {
        'key1': 'value1'
    }
    environ._value_cache = {
        'value1': 'value1_value_cache'
    }
    environ.encoding = None

# Generated at 2022-06-23 14:36:43.018232
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Call base class constructor without any arguments
    x = _TextEnviron()

    # Call base class constructor with arguments
    x = _TextEnviron(env={'a': '1', 'b': '2'}, encoding='utf-8')
    assert x['a'] == '1'
    assert x['b'] == '2'
    x['c'] = '3'
    assert x['c'] == '3'
    del x['a']
    assert x['c'] == '3'
    assert len(x) == 2

# Generated at 2022-06-23 14:36:45.946462
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import os
    import pytest

    if PY3:
        with pytest.raises(TypeError):
            os.environ.__iter__()
    else:
        assert hasattr(os.environ.__iter__(), '__next__')

# Generated at 2022-06-23 14:36:55.250656
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # __init__ with no arguments should have the same key/value pairs as the
    # default os.environ
    env = _TextEnviron()
    assert env == os.environ

    # Make sure that we can use mutable instances of _TextEnviron in the same
    # manner that we can use mutable instances of os.environ
    env = _TextEnviron()
    env['new_var'] = u'value'
    assert env['new_var'] == u'value'
    del env['new_var']
    assert u'new_var' not in env

    # Make sure that we can pass in a different environment variable
    env = _TextEnviron({u'PWD': '/home'})
    assert u'PWD' in env
    assert env['PWD'] == u'/home'

    # Make sure we can

# Generated at 2022-06-23 14:36:57.041949
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """Test that it returns a text string"""
    assert isinstance(environ['HOME'], str)



# Generated at 2022-06-23 14:36:59.112697
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert isinstance(_TextEnviron().__iter__(), iter)

# Generated at 2022-06-23 14:37:07.126040
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Verify __len__ works with the default values
    assert len(environ) == len(os.environ)

    # Verify it works with a custom environment and encoding
    custom_environ = {b'home': b'/home/tester', b'PATH': b'/bin:/usr/bin'}
    text_env = _TextEnviron(env=custom_environ, encoding='utf-8')
    assert len(text_env) == 2

    # Verify the method works when the environment is empty
    custom_environ = {}
    text_env = _TextEnviron(env=custom_environ, encoding='utf-8')
    assert len(text_env) == 0


# Generated at 2022-06-23 14:37:12.373231
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    this_module = sys.modules[__name__]
    assert 'test__TextEnviron___iter__' in dir(this_module)
    assert 'test__TextEnviron___iter__' in this_module.__dict__
    assert 'environ' in dir(this_module)
    assert 'environ' in this_module.__dict__


# Generated at 2022-06-23 14:37:22.485728
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    value = '#\xB6'
    # Get the raw values to compare against
    if PY3:
        raw_value = value
        raw_environ = environ
        raw_environ_dict = dict(raw_environ)
    else:
        raw_value = value.encode('utf-8')
        raw_environ = os.environ
        raw_environ_dict = raw_environ

    # Create the object and ensure it has the right values
    if PY3:
        env = _TextEnviron()
    else:
        env = _TextEnviron(encoding='utf-8')
    assert len(env) == len(raw_environ)
    assert set(env) == set(raw_environ)
    for key, value in raw_environ.items():
        assert env

# Generated at 2022-06-23 14:37:32.055140
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():

    class _EnvironSub(MutableMapping):
        def __init__(self, *args, **kwargs):
          self.dictionary = {}
          for arg in args:
            for key, value in arg.items():
              self.dictionary[key] = value

          for key, value in kwargs.items():
            self.dictionary[key] = value

        def __setitem__(self, key, value):
          self.dictionary[key] = value

        def __getitem__(self, key):
          return self.dictionary[key]

        def __delitem__(self, key):
          del self.dictionary[key]

        def __iter__(self):
            return self.dictionary.__iter__()

        def __len__(self):
            return len(self.dictionary)



# Generated at 2022-06-23 14:37:37.930026
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Make sure that the constructor works with no arguments
    noargs = _TextEnviron(encoding='utf-8')
    # Even though os.environ is a MutableMapping, it can't be assigned to so we'll just use a dict
    # for it
    args = _TextEnviron({b'/a': b'1'}, encoding='utf-8')
    # Force a cache hit
    args[b'/a']



# Generated at 2022-06-23 14:37:39.134218
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:37:41.424211
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron(env={'a': 'b', 'c': 'd'})
    assert env == {}



# Generated at 2022-06-23 14:37:51.391195
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Bytes should be decoded and returned as text, while text should be returned as-is

    E = _TextEnviron()

    # Empty case
    assert to_bytes('', encoding='utf-8') not in E

    # Byte string
    E[to_bytes('test', encoding='utf-8')] = to_bytes('passed', encoding='utf-8')
    assert E[to_bytes('test', encoding='utf-8')] == 'passed'

    # Text string
    E[to_text('test', encoding='utf-8')] = to_text('passed', encoding='utf-8')
    assert E[to_text('test', encoding='utf-8')] == 'passed'

