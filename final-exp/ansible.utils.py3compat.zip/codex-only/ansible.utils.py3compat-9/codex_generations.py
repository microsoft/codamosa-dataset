

# Generated at 2022-06-23 14:27:44.596450
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    _environ = _TextEnviron()
    _environ['key_1'] = u'\u8d64\u3044\u5922'
    assert isinstance(_environ['key_1'], str)

# Generated at 2022-06-23 14:27:51.941587
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test normal operation
    environ = _TextEnviron({'byte_str': b'foo', 'unicode_str': u'bar'})
    assert environ['byte_str'] == u'foo'
    assert environ['unicode_str'] == u'bar'

    # Test with non-ascii unicode
    environ = _TextEnviron({'unicode_str': u'\N{SNOWMAN}'})
    assert environ['unicode_str'] == u'\N{SNOWMAN}'

    # Test with special surrogate escapes
    environ = _TextEnviron({'unicode_str': u'foo\udcff'})
    assert environ['unicode_str'] == u'foo\udcff'

# Generated at 2022-06-23 14:27:52.954678
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) > 10


# Generated at 2022-06-23 14:28:01.448742
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    environ._raw_environ['TEST_KEY'] = 'Test value'
    assert environ['TEST_KEY'] == 'Test value'
    assert environ.__len__() == 1
    environ['TEST_VALUE'] = 'Test value'
    assert environ['TEST_VALUE'] == 'Test value'
    assert environ.__len__() == 2
    assert 'TEST_KEY' in environ
    assert 'NOT_THERE' not in environ
    iter_result = iter(environ)
    assert next(iter_result) == 'TEST_KEY'
    assert next(iter_result) == 'TEST_VALUE'
    del environ['TEST_KEY']
    assert 'TEST_KEY' not in environ
    assert environ.__len__() == 1

test__Text

# Generated at 2022-06-23 14:28:12.184336
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # TODO: Fix common._collections_compat to allow this test to run with python 2.6
    from six import assertCountEqual
    from ansible.module_utils import pycompat24

    def check_environ(env):
        if PY3:
            assert isinstance(env, dict)
        else:
            assert isinstance(env, pycompat24.stringclasses)
        assert 'HOME' in env
        # The value of $HOME is not available on all platforms.  If it's not available
        # then we won't be able to validate the string type.  So we only do the validation
        # if $HOME exists.
        if os.environ.get('HOME'):
            assert isinstance(env['HOME'], pycompat24.stringclasses)

    # None
    env = _TextEnviron()


# Generated at 2022-06-23 14:28:21.460438
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    # FIXME: Do a real unit test here.  The example below is not good enough
    #        because it's possible that the os.environ dict is empty and it
    #        won't catch the exception that we're looking for.
    #
    #        Also, it's highly dependent on the current environment.  For
    #        instance, if the locale is not utf-8, then we'll fail to catch
    #        the exception.
    old_environ = environ.copy()
    os.environ[to_bytes('ANSIBLE_FAKE')] = to_bytes('\200')
    environ._raw_environ = os.environ

# Generated at 2022-06-23 14:28:25.055077
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import inspect
    # method __iter__ of class _TextEnviron should be a generator function.
    assert 'generator' in inspect.getargspec(environ.__iter__).annotations

# Generated at 2022-06-23 14:28:28.492122
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['FOO'] = 'bar'
    assert 'FOO' in environ

    del environ['FOO']

    assert environ['FOO'] is KeyError


# Generated at 2022-06-23 14:28:30.323284
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['test1'] = 'testvalue'
    assert environ['test1'] == 'testvalue'
    del environ['test1']
    try:
        value = environ['test1']
        assert False, "This should not have gotten here"
    except KeyError:
        assert True



# Generated at 2022-06-23 14:28:34.179856
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Initialize object _TextEnviron
    len_object = _TextEnviron()
    # Test if length of object _TextEnviron is 0
    assert len(len_object) == 0


# Generated at 2022-06-23 14:28:37.283940
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    environ['texttest'] = 'testvalue'
    del environ['texttest']
    assert 'texttest' not in environ


# Generated at 2022-06-23 14:28:45.147521
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Empty constructor
    empty_environ = _TextEnviron()
    assert isinstance(empty_environ, MutableMapping)
    assert len(empty_environ) == len(os.environ)
    assert sorted(empty_environ.keys()) == sorted(os.environ.keys())

    # Default values
    assert empty_environ.encoding == sys.getfilesystemencoding()
    assert empty_environ._raw_environ is os.environ
    assert empty_environ._value_cache == {}

    # Custom encoding
    encoding = 'utf-8'
    utf8_environ = _TextEnviron(encoding=encoding)
    assert utf8_environ.encoding == encoding

    # Custom raw_environ not set to os.environ
    raw_environ = os.en

# Generated at 2022-06-23 14:28:52.852442
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env_bak = os.environ.copy()
    os.environ.clear()
    environ.clear()

    env_str = "This is an environment variable with a non-ascii character in it: á"
    environ[u"KEY"] = env_str
    env_str = env_str.encode('utf-8')
    assert environ['KEY'] == to_text(env_str)

    os.environ.update(env_bak)
    environ.update(env_bak)


# Generated at 2022-06-23 14:28:57.224730
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from ansible.module_utils.common._collections_compat import MutableMapping
    env = _TextEnviron(encoding='utf-8')
    it = env.__iter__()
    isinstance(env, MutableMapping)
    next(it)
    # StopIteration
    next(it)

# Generated at 2022-06-23 14:29:00.934397
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import unittest
    # Create a test environment with one key that is a byte string and one that is a text string
    test_env = {b'bar': 'baz', 'foo': 'bar'}
    environ = _TextEnviron(env=test_env)
    # Iterate through the environment using .keys() and .items()
    for key in environ.keys():
        assert isinstance(key, str)
    for k, v in environ.items():
        assert isinstance(k, str)
        assert isinstance(v, str)



# Generated at 2022-06-23 14:29:07.642224
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    if 'TEST_MODULE_ENV_VAR_1' in environ:
        del environ['TEST_MODULE_ENV_VAR_1']

    environ['TEST_MODULE_ENV_VAR_1'] = 'бла бла бла'
    assert environ['TEST_MODULE_ENV_VAR_1'] == 'бла бла бла'

    del environ['TEST_MODULE_ENV_VAR_1']

    assert 'TEST_MODULE_ENV_VAR_1' not in environ



# Generated at 2022-06-23 14:29:10.667129
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({b'foo': b'bar'})
    assert list(env.__iter__()) == ['foo']



# Generated at 2022-06-23 14:29:15.341211
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron({'a': '1', 'b': '2'})
    assert sorted(env.__iter__()) == ['a', 'b']
    env['c'] = '3'
    assert sorted(env.__iter__()) == ['a', 'b', 'c']


# Generated at 2022-06-23 14:29:21.155578
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    test__TextEnviron___delitem__(env)

    Unit test for method __delitem__ of class _TextEnviron
    """

    envvar = {'french_toast': 'I love it!'}
    text_env = _TextEnviron(envvar)

    text_env.__delitem__('french_toast')
    assert len(_TextEnviron()._raw_environ) == len(envvar)



# Generated at 2022-06-23 14:29:32.989191
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ['TEST_KEY_123'] = 'foobar'
    if PY3:
        assert environ['TEST_KEY_123'] == 'foobar'
    else:
        assert environ['TEST_KEY_123'] == u'foobar'

    environ['TEST_KEY_123'] = u'foobar'
    if PY3:
        assert environ['TEST_KEY_123'] == 'foobar'
    else:
        assert environ['TEST_KEY_123'] == u'foobar'

    environ['TEST_KEY_123'] = 123
    if PY3:
        assert environ['TEST_KEY_123'] == '123'
    else:
        assert environ['TEST_KEY_123'] == u'123'


# Generated at 2022-06-23 14:29:33.560304
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) > 0



# Generated at 2022-06-23 14:29:38.226123
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    encoding = 'utf-8'
    env = _TextEnviron(encoding=encoding)
    assert len(env) == len(os.environ)
    env['test_entry'] = 'test'
    assert len(env) == len(os.environ) + 1
    del env['test_entry']
    assert len(env) == len(os.environ)


# Generated at 2022-06-23 14:29:43.450426
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # Setup
    original_environ = {}
    original_environ['one'] = '1'
    original_environ['two'] = '2'
    original_environ['three'] = '3'
    environ = _TextEnviron(original_environ)

    # Run
    result = len(environ)

    # Verify
    assert result == 3


# Generated at 2022-06-23 14:29:54.024707
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Constructor can be passed a dictionary that is not os.environ
    env = _TextEnviron({'foo': 'bår'})
    assert env['foo'] == u'bår'
    assert isinstance(env['foo'], unicode)
    # Constructor can be passed a dictionary that is not os.environ
    env = _TextEnviron({u'foo': u'bår'})
    assert env['foo'] == u'bår'
    assert isinstance(env['foo'], unicode)
    # Constructor can be passed a dictionary that is not os.environ
    env = _TextEnviron({'foo': b'b\xc3\xa5r'})
    assert env['foo'] == u'bår'
    assert isinstance(env['foo'], unicode)
    #

# Generated at 2022-06-23 14:29:55.776921
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ = _TextEnviron()
    assert [key for key in environ] == os.environ.keys()




# Generated at 2022-06-23 14:30:02.008488
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Unit test of method __getitem__ of class _TextEnviron

    Make sure that we're getting unicode strings out of the environment
    """
    import os
    import unittest

    class MockEnviron:
        """
        A simple mock of os.environ
        """
        def __init__(self):
            self.env = {}
        def __getitem__(self, key):
            return self.env[key]
        def __setitem__(self, key, value):
            self.env[key] = value
        def __iter__(self):
            return self.env.__iter__()
        def __len__(self):
            return len(self.env)

    class TextEnvironTestCase(unittest.TestCase):
        """
        Tests for _TextEnviron
        """


# Generated at 2022-06-23 14:30:04.536564
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    env = _TextEnviron()
    assert env['HOME'] == os.environ['HOME']
    env['HOME'] = '/foo/bar'
    assert env['HOME'] == '/foo/bar'


# Generated at 2022-06-23 14:30:14.968134
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    from collections import OrderedDict
    class _MockEnviron(MutableMapping):
        def __init__(self):
            self.data = OrderedDict()
        def __delitem__(self, key):
            del self.data[key]
        def __getitem__(self, key):
            return self.data[key]
        def __setitem__(self, key, value):
            self.data[key] = value
        def __iter__(self):
            return self.data.__iter__()
        def __len__(self):
            return len(self.data)
    mock = _MockEnviron()
    mock['foo'] = 'bar'
    mock['baz'] = 'qux'
    mock['tos'] = 'u'
    mock['c'] = 'd'

# Generated at 2022-06-23 14:30:17.542388
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test to ensure it raises an error when non-string values are passed
    with pytest.raises(TypeError):
        environ['A_NON_STRING_KEY'] = 42


# Generated at 2022-06-23 14:30:25.650217
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    default_encoding = sys.getfilesystemencoding()

    def check(env, encoding, expected):
        c = _TextEnviron(env, encoding)
        assert c.encoding == encoding
        assert c['a'] == expected

    # Check that the default encoding is used when one is not given
    check({b'a': b'b'}, None, 'b')

    # Check that utf8 is used when given a non-ASCII byte string
    check({b'a': b'\xc3\xa0'}, None, u'\xe0')
    check({b'a': b'\xc3\xa0'}, 'utf-8', u'\xe0')

    # Check that utf8 is used when given a non-ASCII text string

# Generated at 2022-06-23 14:30:26.991809
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    _env = _TextEnviron()
    assert next(_env.__iter__()) is not None



# Generated at 2022-06-23 14:30:32.228997
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    text_environ = _TextEnviron()
    try:
        text_environ['key'] = 'val'
        assert text_environ[to_bytes('key')] == 'val'
    finally:
        del text_environ[to_bytes('key')]



# Generated at 2022-06-23 14:30:39.482088
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    import mock
    import pytest

    with mock.patch.dict(environ):
        env = _TextEnviron(env={})
        assert env['test__TextEnviron___getitem__'] == 'test__TextEnviron___getitem__'

    environ['test__TextEnviron___getitem__'] = 'test__TextEnviron___getitem__'
    assert environ['test__TextEnviron___getitem__'] == 'test__TextEnviron___getitem__'

    with mock.patch.dict(environ):
        env = _TextEnviron(env={})
        env['test__TextEnviron___getitem__'] = b'test__TextEnviron___getitem__'
        assert env['test__TextEnviron___getitem__'] == 'test__TextEnviron___getitem__'

# Generated at 2022-06-23 14:30:41.313707
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
  global environ
  environ['ABC'] = 'abc'
  del environ['ABC']
  try:
    assert environ['ABC'] == 'abc'
    assert False
  except KeyError:
    pass


# Generated at 2022-06-23 14:30:51.835314
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    if PY3:
        # On Python 3, this test is pointless since we don't do anything in the __iter__ method
        return

    os.environ['ANSIBLE_TEST_KEY1'] = 'ANSIBLE_TEST_VALUE1'
    os.environ['ANSIBLE_TEST_KEY2'] = 'ANSIBLE_TEST_VALUE2'
    os.environ['ANSIBLE_TEST_KEY3'] = 'ANSIBLE_TEST_VALUE3'

    assert sorted(os.environ.keys()) == sorted(environ.keys())
    for env_key, env_value in environ.items():
        assert isinstance(env_key, str)
        assert isinstance(env_value, str)

    del os.environ['ANSIBLE_TEST_KEY1']

# Generated at 2022-06-23 14:31:01.295307
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Setup a _TextEnviron object and set it's value
    e = _TextEnviron()
    e['text_value'] = 'A Value'
    # Set the 'default' value for the key in the os.environ dictionary.
    os.environ['text_value'] = 'A Value'
    assert e['text_value'] == u'A Value'
    # Change the value in os.environ and make sure we retrieve the changed value
    os.environ['text_value'] = 'A Different Value'
    assert e['text_value'] == u'A Different Value'
    # Try to retrieve a value that isn't set
    assert e.get('nonexistent_value') is None


# Generated at 2022-06-23 14:31:04.127135
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron()
    env['TEST_KEY'] = 'test_value'
    assert 'TEST_KEY' in env
    del env['TEST_KEY']
    assert 'TEST_KEY' not in env


# Generated at 2022-06-23 14:31:06.642924
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert len(environ) == len(os.environ)
    for k in environ:
        assert environ[k] == os.environ[k]
    assert environ.encoding == 'utf-8'

# Generated at 2022-06-23 14:31:14.715252
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    """
    Test the __iter__ method of _TextEnviron.  This is tested via the methods that call __iter__:
    keys(), values(), and items().
    """
    _test_environ = _TextEnviron()

    #
    # Test keys()
    #

    # Normal cases
    assert isinstance(_test_environ.keys(), type(environ.keys()))
    assert isinstance(_test_environ.keys()[0], type(environ.keys()[0]))
    assert _test_environ.keys() == environ.keys()

    #
    # Test values()
    #

    # Normal cases
    assert isinstance(_test_environ.values(), type(environ.values()))

# Generated at 2022-06-23 14:31:23.813995
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_env = _TextEnviron()
    test_env.encoding = 'utf-8'
    dict_before = dict(test_env)

    test_env['a'] = u'b'
    dict_after_a_b = dict(test_env)

    test_env['b'] = b'c'
    dict_after_b_c = dict(test_env)

    test_env.encoding = 'ascii'
    test_env['c'] = u'd'
    dict_after_c_d = dict(test_env)

    assert 'a' not in dict_before
    assert 'b' not in dict_before

    assert 'a' in dict_after_a_b
    assert 'b' in dict_after_a_b
    assert dict_after_a_b['a']

# Generated at 2022-06-23 14:31:25.487597
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:31:26.559606
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    assert environ['PATH'] == u'/usr/bin'

# Generated at 2022-06-23 14:31:30.468189
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    import os
    try:
        environ2 = _TextEnviron(env={})
        del environ2['TEST']
    except KeyError:
        pass
    else:
        assert 0, "_TextEnviron.__delitem__: KeyError not raised"


# Generated at 2022-06-23 14:31:31.641052
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    x = _TextEnviron({'x': 'y'})
    assert len(x) == 1



# Generated at 2022-06-23 14:31:36.458891
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():

    old_env = os.environ.copy()
    os.environ['ANSIBLE_TEST'] = 'foo'
    try:
        len(environ) == 1
        assert True
    finally:
        os.environ.clear()
        os.environ.update(old_env)



# Generated at 2022-06-23 14:31:48.074409
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    def test_case(os_environ, key_value_pairs, expected):
        """
        Unit test for method __getitem__ of class _TextEnviron.

        :arg dict os_environ: dict of raw environment variables to be used for the test.
        :arg dict key_value_pairs: dict of the expected key-value pairs in the test
          _TextEnviron object.
        :arg expected: expected output from _TextEnviron.__getitem__
        """
        # Create a _TextEnviron object
        test_env = _TextEnviron(env=os_environ)

        # Verify the expected key-value pairs in the _TextEnviron object
        assert len(test_env) == len(key_value_pairs)
        for key, value in key_value_pairs.items():
            assert test_

# Generated at 2022-06-23 14:31:50.038686
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    assert set(('ABC', 'abc', 'BCD')) == set(environ)


# Generated at 2022-06-23 14:31:58.733900
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    This test should be run against all python versions to ensure that the class is doing the right
    thing in each version.
    """
    # First, test that we can instantiate the class
    text_env = _TextEnviron()
    try:
        # Test that we can do operations on the object that would be expected if it was a dict
        # Test a key that doesn't exist
        text_env['test']
        assert False, 'test env did not raise KeyError'
    except KeyError:
        pass
    # Test a unicode byte string key that doesn't exist
    try:
        text_env['test\xf0'.encode('utf-8')]
        assert False, 'test env did not raise KeyError'
    except KeyError:
        pass
    # Test a key that does exist
    # This isn't very specific

# Generated at 2022-06-23 14:32:07.705875
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    tmp_environ = {
        'ansible_test': '123',
        b'ansible_test_bytes': b'123',
    }
    text_environ = _TextEnviron(env=tmp_environ)
    assert len(text_environ) == len(tmp_environ)
    assert list(text_environ.keys()) == list(tmp_environ.keys())
    assert list(text_environ.values()) == [to_text('123'), to_text('123')]
    assert text_environ['ansible_test'] == to_text('123')
    assert text_environ['ansible_test_bytes'] == to_text('123')



# Generated at 2022-06-23 14:32:10.237206
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    e = _TextEnviron()
    len(e) == len(os.environ)


# Generated at 2022-06-23 14:32:18.869754
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test constructor with no arg
    environ1 = _TextEnviron()
    assert len(environ1) > 0
    assert environ1 is not os.environ

    # Test constructor with env arg
    environ2 = _TextEnviron(env={'k1': 'v1', 'k2': 'v2'})
    assert len(environ2) == 2
    assert environ2 is not os.environ

    # Test constructor with env and encoding arg
    environ3 = _TextEnviron(env={'k1': 'v1', 'k2': 'v2'}, encoding='utf-8')
    assert len(environ3) == 2
    assert environ3 is not os.environ
    assert environ3.encoding == 'utf-8'



# Generated at 2022-06-23 14:32:19.900308
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    assert environ['foo'] == u'bar'

# Generated at 2022-06-23 14:32:28.805064
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    # Test with a utf-8 value
    os.environ['ANSIBLE_TEST_TEXT_ENVIRON'] = u'éàù'
    del environ
    environ = _TextEnviron(encoding='utf-8')
    assert u'éàù' == environ['ANSIBLE_TEST_TEXT_ENVIRON']

    # Test with a cp1252 value
    # On Windows, the environment uses the encoding returned by GetACP().  For most of the world,
    # this will be cp1252.  We need to test that as well.
    # See https://github.com/ansible/ansible/issues/43910
    # The best way to find out what GetACP() will return on your platform is to look at
    # sys.getfilesystemencoding()

# Generated at 2022-06-23 14:32:39.933796
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # pylint: disable=too-few-public-methods
    class _MockEnviron(object):
        def __init__(self, env_dict):
            self._env = env_dict
        def __getitem__(self, key):
            return self._env[key]
        def __setitem__(self, key, value):
            self._env[key] = value
        def __delitem__(self, key):
            del self._env[key]
        def __iter__(self):
            return iter(self._env)
        def __contains__(self, key):
            return key in self._env
        def __len__(self):
            return len(self._env)

    env = os.environ.copy()
    env['unicode'] = u'hiya'

# Generated at 2022-06-23 14:32:48.702130
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Test function __delitem__ of class _TextEnviron
    """
    import os
    import tempfile
    from ansible.module_utils.common._collections_compat import MutableMapping

    fd, tmpfile = tempfile.mkstemp()
    os.write(fd, b"FOO=bar\n")
    os.write(fd, b"FOO1=bar1\n")
    os.close(fd)

    old_environ = os.environ
    os.environ = {}


# Generated at 2022-06-23 14:32:55.170186
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    e = _TextEnviron(encoding='ascii')
    assert(isinstance(e.encoding, str))
    assert(e.encoding == 'ascii')

    # Test iterating over an empty environ
    e._raw_environ = {}
    itere = iter(e)
    first_item = next(itere)
    assert(False)


# Generated at 2022-06-23 14:33:03.009469
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils.six import PY3, PY2
    from ansible.module_utils._text import to_bytes, to_text

    class TestEnviron(MutableMapping):
        """
        Utility class to return text strings from the environment instead of byte strings

        Mimics the behaviour of os.environ on Python3
        """
        def __init__(self, encoding=None):
            self._encoding = encoding
            self._value_cache = {}
            self._environ = {}

        def __delitem__(self, key):
            del self._environ[key]

        def __getitem__(self, key):
            value = self._environ[key]
            # Cache keys off of the undecoded values to handle any environment variables which change
            # during a run

# Generated at 2022-06-23 14:33:12.015000
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    """
    Tests when the key exists in os.environ.

    Purpose
    -------
    Test when the key exists in os.environ, the value returned by
    _TextEnviron is bytes on Python 2 and text on Python 3.

    Prerequisites
    -------------
    The key to be searched should exist in os.environ.

    Test Process
    ------------
    1. Create an object of class _TextEnviron
    2. Delete the key from os.environ using the object
    3. Access the key from os.environ using the object
    4. Assert that the value returned is bytes on Python 2 and text on Python 3.

    Cleanup
    -------
    1. Delete the key from os.environ.
    """
    environ['ANSIBLE'] = 'ansible'

# Generated at 2022-06-23 14:33:14.014371
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    import pytest

    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:33:20.382248
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Try creating and get elements from a TextEnviron with a non-utf-8 encoding
    te = _TextEnviron(encoding='iso-8859-1')
    te['foo'] = 'bar'
    assert te['foo'] == u'bar'
    assert te._raw_environ['foo'] == b'bar'

    # Try creating and get elements from a TextEnviron with utf-8 encoding
    te = _TextEnviron()
    te['foo'] = 'bar'
    assert te['foo'] == u'bar'
    assert te._raw_environ['foo'] == b'bar'

    # Try creating a Te

# Generated at 2022-06-23 14:33:26.034330
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # _TextEnviron[key] = value, set a key:value pair in environment variable
    test_env = _TextEnviron(encoding='utf-8')
    test_env['foo'] = '非ascii'
    assert to_text(os.environ['foo'], errors='surrogate_or_strict') == '非ascii'
    del test_env



# Generated at 2022-06-23 14:33:36.533448
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    from six import StringIO
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Test for byte string keys in the underlying dict
    raw_environ = {to_bytes('a', encoding='utf-8'): to_bytes('b', encoding='utf-8')}
    environ = _TextEnviron(env=raw_environ, encoding='utf-8')
    assert isinstance(environ, MutableMapping)
    assert environ['a'] == u'b'

    # Test for byte string keys that are invalid utf-8
    raw_environ = {to_bytes('a', encoding='utf-8'): to_bytes('b', encoding='utf-8')}
    environ = _TextEnviron(env=raw_environ, encoding='utf-8')

# Generated at 2022-06-23 14:33:39.565314
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    e = _TextEnviron(encoding='utf-8')
    e['some_var'] = 'some_value'
    assert e['some_var'] == 'some_value'
    del e['some_var']
    assert 'some_var' not in e


# Generated at 2022-06-23 14:33:41.559848
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:33:46.614262
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    len_os_environ = len(os.environ)
    len_environ = len(environ)
    os.environ['KERNELVERSION'] = '5'

    assert len(environ) == len_environ + 1
    assert len(os.environ) == len_os_environ + 1



# Generated at 2022-06-23 14:33:54.736937
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():

    # make sure that the os.environ gets copied as a reference
    os.environ['__test__'] = 'test'

    # make sure that the os.environ gets copied as a reference
    environ_len = len(os.environ)

    # make sure that the len() works
    assert environ_len == len(environ)

    # make sure that the len() is not cached
    os.environ['__test__'] = 'test2'
    assert environ_len == len(environ)



# Generated at 2022-06-23 14:33:57.527277
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Tests whether _TextEnviron.__len__ returns the correct number of items.
    """
    assert len(environ) == len(os.environ)


# Generated at 2022-06-23 14:34:02.741204
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils.six import PY3
    if PY3:
        assert len(environ) == len(os.environ)
    else:
        # Hack to allow unit tests to be run against python2.7
        assert len(environ) == 1
test__TextEnviron___len__()


# Generated at 2022-06-23 14:34:14.336395
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Check that [] is used to get the default value for the environment
    _TextEnviron()

    # Check that assignment to __delitem__ propagates to the underlying dict
    env = _TextEnviron()

    key = 'foo'
    value = 'bar'
    env[key] = value
    assert env._raw_environ[key] == to_bytes(value, encoding='utf-8', nonstring='strict',
                                             errors='surrogate_or_strict')

    del env[key]
    assert env._raw_environ.get(key) is None

    # Check that getitem returns a text string
    env = _TextEnviron()

    if PY3:
        # Python3 has the correct behaviour by default
        key = 'foo'
        value = 'bar'
        env[key] = value

# Generated at 2022-06-23 14:34:22.608189
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    from ansible.module_utils.six import PY2

    env = _TextEnviron(env={'FOO': 'FOO'})
    del env['FOO']
    assert 'FOO' not in env
    assert 'FOO' not in env._raw_environ

    env = _TextEnviron(env={u'FOO': u'FOO'})
    del env['FOO']
    assert 'FOO' not in env
    assert 'FOO' not in env._raw_environ

    if PY2:
        env = _TextEnviron(encoding='utf-8', env={b'FOO': b'FOO'})
        del env['FOO']
        assert 'FOO' not in env
        assert b'FOO' not in env._raw_environ

        env = _TextEn

# Generated at 2022-06-23 14:34:27.307120
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    env = _TextEnviron()
    env.clear()
    env['a'] = '1'
    env['b'] = '2'
    env['c'] = '3'

    assert sorted(list(env)) == ['a', 'b', 'c']

# Generated at 2022-06-23 14:34:37.623607
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Test __setitem__ method of class _TextEnviron
    """
    _env = _TextEnviron(encoding='utf-8')
    _env["_foo"] = u"bar\u2601"
    assert _env["_foo"] == u"bar\u2601"
    # Make sure the string is stored in the correct type
    assert isinstance(_env._raw_environ["_foo"], bytes)
    # Make sure it isn't cached
    assert len(_env._value_cache) == 0
    # Test that using a string we don't understand doesn't break the cache
    _env["_foo"] = b"bar\xf4"
    assert isinstance(_env._raw_environ["_foo"], bytes)
    assert len(_env._value_cache) == 0
    # Store a string that doesn't decode clean

# Generated at 2022-06-23 14:34:38.630194
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) > 0


# Generated at 2022-06-23 14:34:48.099354
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # pylint: disable=protected-access
    # pylint: disable=no-member
    if PY3:
        # On Python3, _TextEnviron is just a pass-through to os.environ
        assert environ is os.environ
        return

    # Test that we get the right encoding
    assert environ.encoding == 'utf-8'

    # Make sure that we return text strings
    assert type(environ['HOME']) is str

    # Make sure that we can set values
    environ['ANSIBLE_TEST_BYTES'] = b'bytes'
    assert environ['ANSIBLE_TEST_BYTES'] == 'bytes'
    assert type(environ['ANSIBLE_TEST_BYTES']) is str

    # Make sure that setting a unicode string doesn't cause a crash

# Generated at 2022-06-23 14:34:50.064735
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    '''
    test for method _TextEnviron.__iter__()
    '''

    # No assertion, this is just checking that the code executes without error


# Generated at 2022-06-23 14:34:56.058319
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    _TextEnviron.__setitem__(environ, 'byte_value', b'some bytes')
    _TextEnviron.__setitem__(environ, 'str_value', 'some string')
    _TextEnviron.__setitem__(environ, 'unicode_value', u'Some Unicode ⌘')
    assert b'some bytes' == os.environ['byte_value']
    assert b'some string' == os.environ['str_value']
    assert b'some unicode \xe2\x8c\x98' == os.environ['unicode_value']



# Generated at 2022-06-23 14:35:02.048839
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    env = _TextEnviron({b'a': b'A', b'b': b'B'}, 'utf-8')
    assert env == {'a': 'A', 'b': 'B'}

    assert env[b'a'] == u'A'
    assert env['a'] == u'A'
    assert env[b'b'] == u'B'
    assert env['b'] == u'B'

    env[b'c'] = 'C'
    assert env['c'] == u'C'
    assert env[b'c'] == u'C'
    del env['c']
    assert list(env) == ['a', 'b']
    assert list(env.keys()) == ['a', 'b']
    assert list(env.values()) == ['A', 'B']


# Generated at 2022-06-23 14:35:06.009678
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    _env = os.environ.copy()
    try:
        _env['ANSIBLE_TEST_KEY'] = 'ANSIBLE_TEST_VALUE'
        _test_env = _TextEnviron(_env)
        assert len(_test_env) == len(_env)
    finally:
        del _env['ANSIBLE_TEST_KEY']

# Generated at 2022-06-23 14:35:10.083971
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ = dict(a=1, b=2, c=3)
    assert len(os.environ) == 3
    assert len(_TextEnviron()) == 3
    assert len(_TextEnviron(env={'a':1,'b':2,'c':3})) == 3
    assert len(_TextEnviron(env={})) == 0
    assert len(_TextEnviron(env=None)) == 3


# Generated at 2022-06-23 14:35:13.658769
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    """
    Unit test for method __setitem__ of class _TextEnviron
    """
    env_var_name = 'TEST_ENV_VAR'
    env_var_value = u'TEST_ÉNV_VÀR'

    # Check if it is throwing an exception, 'cause that means it does not accept unicode strings
    try:
        environ[env_var_name] = env_var_value
    except UnicodeEncodeError:
        assert False

    # Also check if the environment variable was successfuly set
    assert os.environ[env_var_name] == env_var_value.encode('utf-8')

# Generated at 2022-06-23 14:35:24.230617
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Test without any args
    environ = _TextEnviron()
    assert environ._raw_environ == os.environ
    assert environ.encoding == sys.getfilesystemencoding()
    assert len(environ) == len(os.environ)

    # Test with encoding passed
    environ = _TextEnviron(encoding='utf-8')
    assert environ._raw_environ == os.environ
    assert environ.encoding == 'utf-8'
    assert len(environ) == len(os.environ)

    # Test with environ passed
    environ = _TextEnviron({'foo': 'bar', 'baz': 'spam'})
    assert environ._raw_environ == {b'foo': b'bar', b'baz': b'spam'}
   

# Generated at 2022-06-23 14:35:35.248872
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-23 14:35:38.269104
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    os.environ['key1'] = b'value1'
    os.environ['key2'] = b'value2'
    assert len(environ) == 2

# Generated at 2022-06-23 14:35:45.941176
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():
    """
    Test method __getitem__ of class _TextEnviron
    """
    import shutil
    import tempfile
    import subprocess

    temp_dir = tempfile.mkdtemp(prefix="ansible_test_env")
    test_script = os.path.join(temp_dir, "test_env.py")

# Generated at 2022-06-23 14:35:49.710027
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_env = {}
    _test_env = _TextEnviron(env=test_env, encoding='utf-8')
    _test_env['a'] = u'b'
    assert 'a' in test_env
    del _test_env['a']
    assert 'a' not in test_env
    assert 'a' not in _test_env


# Generated at 2022-06-23 14:35:54.302274
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    testing_env = _TextEnviron({u'a': u'b', u'c': u'd'})

    assert testing_env[u'a'] == u'b'
    assert testing_env[u'c'] == u'd'

    del testing_env[u'a']

    assert u'a' not in testing_env
    assert testing_env[u'c'] == u'd'



# Generated at 2022-06-23 14:35:58.583942
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    if PY3:
        return
    assert 'ascii' not in environ
    os.environ['ascii'] = b'a'
    flag = False
    for key in environ:
        assert key == 'ascii'
        flag = True
    assert flag



# Generated at 2022-06-23 14:35:59.985844
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:36:03.817813
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    test_environ = _TextEnviron({b'test_key': b'test_value'})
    del test_environ['test_key']
    assert 'test_key' not in test_environ


# Generated at 2022-06-23 14:36:08.436869
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import unittest
    class Test__TextEnviron(unittest.TestCase):
        def setUp(self):
            self.env = environ
        def test_iter_call(self):
            self.env.__iter__()
    unittest.main()


# Generated at 2022-06-23 14:36:14.584626
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    env = {}
    env_mgr = _TextEnviron(env=env)

    key = u'key'
    value = u'value'
    env_mgr[key] = value
    assert env[key] == b'value'

    key = u'key2'
    value = u'value2'
    env_mgr[key] = value
    assert env[key] == b'value2'


# Generated at 2022-06-23 14:36:16.873322
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    """
    Unit test for method __len__
    """
    assert len(environ) == len(os.environ)



# Generated at 2022-06-23 14:36:20.246049
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    """
    Test constructor of class _TextEnviron.
    """
    if PY3:
        expected = os.environ.__class__
    else:
        expected = _TextEnviron
    assert isinstance(environ, expected)


# Generated at 2022-06-23 14:36:26.244903
# Unit test for method __getitem__ of class _TextEnviron
def test__TextEnviron___getitem__():

    # test for default keys like 'HOME', 'USER' and 'PATH'
    for key in os.environ:
        assert environ[key] == os.environ[key]

    # test for non-existing key
    try:
        environ['SOMETEST']
    except KeyError:
        pass
    else:
        raise AssertionError("KeyError expected")

    # test for existing key with different casing
    os.environ['SOMETEST'] = 'teST'
    assert environ['SOMETEST'] == os.environ['SOMETEST']
    assert environ['sometest'] == os.environ['sometest']



# Generated at 2022-06-23 14:36:32.096269
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    from ansible.module_utils._text import to_text
    a = {'a': to_text('foo', 'utf-8'), 'b': to_text('bar', 'utf-8'), 'c': to_text('baz', 'utf-8')}
    b = _TextEnviron(a)
    assert len(b) == 3



# Generated at 2022-06-23 14:36:33.370322
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    env = _TextEnviron()
    assert isinstance(env, _TextEnviron)
    assert len(env) == len(os.environ)



# Generated at 2022-06-23 14:36:38.028164
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    environ.clear()
    environ['key1'] = 'value1'
    assert environ['key1'] == 'value1'
    environ['key2'] = 'value2'
    assert environ['key2'] == 'value2'
    environ['key1'] = 'value3'
    assert environ['key1'] == 'value3'
    del environ['key1']
    assert environ['key1'] == 'value3'
    assert len(environ) == 2


# Generated at 2022-06-23 14:36:40.383426
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    # len of environ is two
    len_environ = len(environ)
    assert len_environ == 2


# Generated at 2022-06-23 14:36:43.424726
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():
    env = _TextEnviron()
    env['foo'] = 'bar'
    del env['foo']
    assert 'foo' not in env



# Generated at 2022-06-23 14:36:45.764403
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    import six

    env = _TextEnviron()
    for k in env.__iter__():
        assert isinstance(k, six.text_type)

# Generated at 2022-06-23 14:36:51.898430
# Unit test for method __getitem__ of class _TextEnviron

# Generated at 2022-06-23 14:36:56.064377
# Unit test for method __delitem__ of class _TextEnviron
def test__TextEnviron___delitem__():

    env = _TextEnviron({'foo': 'bar'})
    assert len(env) == 1
    env['foo']

    del env['foo']

    assert len(env) == 0


# Generated at 2022-06-23 14:37:06.630640
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Python 2:
    #   _TextEnviron(environ)
    #   _TextEnviron(environ, 'utf8')
    # Python 3:
    #   _TextEnviron()
    #   _TextEnviron(None, 'utf8')
    #   _TextEnviron(environ)
    #   _TextEnviron(environ, 'utf8')
    #   _TextEnviron(environ, 'utf8')

    test_env = os.environ.copy()
    test_env[b'ANSIBLE_TEST_BYTES_ENV_VAR'] = b'ANSIBLE_TEST_BYTES_ENV_VAR_VALUE'

# Generated at 2022-06-23 14:37:16.420806
# Unit test for constructor of class _TextEnviron
def test__TextEnviron():
    # Make sure that the constructor creates a clone
    environ_clone = _TextEnviron(env=environ, encoding='ascii')
    assert environ is not environ_clone
    assert environ == environ_clone

    # Make sure that the constructor creates a clone even when the encoding is the same
    environ_clone = _TextEnviron(env=environ, encoding='utf-8')
    assert environ is not environ_clone
    assert environ == environ_clone

    # Make sure that the constructor uses the environment even when encoding is the same
    environ_clone = _TextEnviron(env=environ, encoding='utf-8')
    assert environ is not environ_clone
    assert environ == environ_clone

    # Make sure that the constructor will use a different environment
    other_env = {}
   

# Generated at 2022-06-23 14:37:20.621023
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import MutableMapping
    # Test for setting value: bytes
    environ_ = _TextEnviron(encoding='utf-8')
    environ_['ENV_KEY_1'] = b'ABC'
    assert environ_['ENV_KEY_1'] == 'ABC'
    # Test for setting value: text
    environ_['ENV_KEY_2'] = 'ABC'
    assert environ_['ENV_KEY_2'] == 'ABC'
    # Test for setting value: non-string

# Generated at 2022-06-23 14:37:22.532857
# Unit test for method __iter__ of class _TextEnviron
def test__TextEnviron___iter__():
    environ["foo"] = "bar"
    assert "foo" in environ

# Generated at 2022-06-23 14:37:30.290984
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    test_dict = {"key_1": "value_1", "key_2": "value_2", "key_3": "value_3",
                 "key_4": "value_4", "key_5": "value_5", "key_6": "value_6"}
    encoding = 'utf-8'
    for key, value in test_dict.items():
        environ.__setitem__(key, value)
        
    print(environ)
    
    for key, value in environ.items():
        print ("%s : %s" % (key, value))


# Generated at 2022-06-23 14:37:41.027328
# Unit test for method __setitem__ of class _TextEnviron
def test__TextEnviron___setitem__():
    # Test that a _TextEnviron can be created
    test_environ = _TextEnviron({b'A': b'B'})

    # Test that a value can be set
    test_environ['A'] = 'B'
    assert test_environ == {'A': 'B'}

    # Test that a non-string param raises an error
    try:
        test_environ['A'] = 1
    except TypeError:
        pass
    except Exception:
        raise AssertionError('Dict set should raise a TypeError when a non-string value is used.')
    else:
        raise AssertionError('Dict set should raise a TypeError when a non-string value is used.')

    # Test that an exception is raised if a surrogate is received and strict errors are used

# Generated at 2022-06-23 14:37:43.116122
# Unit test for method __len__ of class _TextEnviron
def test__TextEnviron___len__():
    my_env = _TextEnviron()
    assert len(my_env) == len(os.environ)

