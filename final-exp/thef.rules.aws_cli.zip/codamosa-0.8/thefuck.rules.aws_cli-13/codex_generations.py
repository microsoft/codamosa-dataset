

# Generated at 2022-06-12 10:47:14.405813
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws ec2  run-instances --block-device-map 'volumes=ami2'") == ['aws ec2  run-instances --block-device-mappings \'volumes=ami2\'']

# Generated at 2022-06-12 10:47:16.871979
# Unit test for function match
def test_match():
    assert match(Command('aws', output='usage: aws [options] <command>'))
    assert not match(Command('git', output='usage: aws [options] <command>'))


# Generated at 2022-06-12 10:47:24.353659
# Unit test for function match

# Generated at 2022-06-12 10:47:29.410887
# Unit test for function match
def test_match():
    assert match(Command('aws --version',
                         'usage: aws [options] [ ...] [parameters]\nTo see '
                         'help text, you can run: aws help\n\nUnknown '
                         'options: --version, maybe you meant: --version-in'))
    assert not match(Command('aws --version'))


# Generated at 2022-06-12 10:47:36.573428
# Unit test for function match
def test_match():
    assert match(Command("aws ec2 describe-instances", ""))
    assert not match(Command("aws ec2 describe-instances",
                             "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo "
                             "see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> "
                             "<subcommand> help\n\nUnknown options: --profile",
                             1))


# Generated at 2022-06-12 10:47:42.034807
# Unit test for function match
def test_match():
    assert match(Command('aws cloudformation create-stack',
                         stderr='usage: aws [options] <command>  <subcommand> ' +
                         '[<subcommand> ...] [parameters]' + '\n' +
                         'aws: error: argument subcommand: ' +
                         'Invalid choice: \'create-stack\', ' +
                         'maybe you meant: \'create-stac\''))



# Generated at 2022-06-12 10:47:47.498733
# Unit test for function match
def test_match():
  command = Command('aws s3api list-buckets', '*usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n    ls                         List all objects in a bucket.\n    mb                         Creates a bucket.\nwubo-mbp:aws wubo$ ')
  assert match(command)


# Generated at 2022-06-12 10:47:49.857847
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-vpc --vpc-id vpc-foo'))
    assert not match(Command('ls'))

# Generated at 2022-06-12 10:47:59.204870
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances --output table',
             'usage:aws ec2 describe-instances [--dry-run] [--filters <value>] [--instance-ids <value>] [--max-items <value>] [--next-token <value>] [--output <value>] [--query <value>] [--region <value>] [--starting-token <value>] [--cli-input-json <value>] [--generate-cli-skeleton <value>]\n\nIncorrect Usage: Invalid choice: u\'--outputt\', maybe you meant: \'--output\'',
             'aws ec2 describe-instances'))

# Generated at 2022-06-12 10:48:00.144147
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3bb bucket')) == ['aws s3 bucket']

# Generated at 2022-06-12 10:48:11.961474
# Unit test for function match

# Generated at 2022-06-12 10:48:21.908181
# Unit test for function get_new_command
def test_get_new_command():
    output = "usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument <command>: Invalid choice: 'foobar'\n\nmaybe you meant:\n    foo\n    bar\n"
    command = 'aws elaticbeanstalk wait foobar-stack-Ready --region us-east-1'
    commands = get_new_command(MagicMock(script=command, output=output))
    assert len(commands) == 2
    assert commands[0] == 'aws elaticbeanstalk wait foo-stack-Ready --region us-east-1'
    assert commands[1] == 'aws elaticbeanstalk wait bar-stack-Ready --region us-east-1'

# Generated at 2022-06-12 10:48:30.938896
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws ec2 describe-instances --region us-east-1 --output text --filters Name=instance-state-name,Values=running Name=tag:ResourceId,Values=i-0a00c0d8001234567 Name=tag:Env,Values=prod Name=tag:Name,Values=fr-web-1") == ['aws ec2 describe-instances --region us-east-1 --output text --filters Name=instance-state-name,Values=running Name=tag:ResourceId,Values=i-0a00c0d8001234567 Name=tag:Env,Values=prod Name=tag:Name,Values=fr-web-1']

# Generated at 2022-06-12 10:48:31.489401
# Unit test for function get_new_command
def test_get_new_command():
    pass

# Generated at 2022-06-12 10:48:40.731360
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://test-bucket', ''))

# Generated at 2022-06-12 10:48:49.899350
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws elbv2"

# Generated at 2022-06-12 10:48:57.209773
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls', 'aws: error: argument command: Invalid choice: \'ls\', maybe you meant:\n  cp\n  mv\n  rm\n  sync\n\nSee \'aws help\' for descriptions of global parameters.')) == ['aws s3 cp', 'aws s3 mv', 'aws s3 rm', 'aws s3 sync']

# Generated at 2022-06-12 10:49:00.310002
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, valid choices are:\n\n'))


# Generated at 2022-06-12 10:49:11.283626
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 create-vpc --cidr-bloc 192.168.0.0/16')) == ['aws ec2 create-vpc --cidr-block 192.168.0.0/16']
    assert get_new_command(Command('aws s3 cp localdir s3://bucket/remotedir --recursive --no-sign-request')) == ['aws s3 cp localdir s3://bucket/remotedir --recursive --no-sign-request']
    assert get_new_command(Command('aws s3 sync --dryrun --size-only --exclude ".*/" ')) == ['aws s3 sync --dryrun --size-only --exclude ".*/"']

# Generated at 2022-06-12 10:49:13.806949
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls', 'Invalid choice: \'s3\', maybe you meant:\n  * s3api')) == ['aws s3api ls']

# Generated at 2022-06-12 10:49:18.465847
# Unit test for function match
def test_match():
    command = Command('aws --version', 'Invalid choice: "--version", maybe you meant: ec2 ec2-instance-connect ec2-instance-connect-setup ec2-instance-connect-upload-key-pair')
    assert match(command)


# Generated at 2022-06-12 10:49:28.484919
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws ec2 create-instance my-instance") == ['aws ec2 create-image my-instance']
    assert get_new_command("aws s3 ls mybucket") == ['aws s3 ls s3://mybucket']
    assert get_new_command("aws elb create-load-balancer my-load-balancer") == ['aws elb create-lb my-load-balancer']
    assert get_new_command("aws elb describe-load-balancers my-load-balancer") == ['aws elb describe-lbs my-load-balancer']
    assert get_new_command("aws elb describe-instance-health my-load-balancer") == ['aws elb describe-instance-health my-load-balancer']

# Generated at 2022-06-12 10:49:35.244305
# Unit test for function match
def test_match():
    output = '''
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument operation: Invalid choice, maybe you meant: ops
'''
    assert match(Command('aws', output=output)) == True
    assert match(Command('aws help', output=output)) == False



# Generated at 2022-06-12 10:49:43.331167
# Unit test for function match
def test_match():
    command_output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
       To see help text, you can run:

         aws help
         aws <command> help
         aws <command> <subcommand> help
       aws: error: argument command: Invalid choice, valid choices are:
  [...]
        maybe you meant:
  [...]
       Invalid choice: 's3api', maybe you meant:
         ses       send-receipt-ruleset"""
    assert match(Command('aws s3api help', output=command_output))


# Generated at 2022-06-12 10:49:53.711893
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws ec2 --region eu-west-1 deregister-image'

# Generated at 2022-06-12 10:50:03.259703
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 mb s3://bucketname', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\naws: error: argument subcommand: Invalid choice: \'mb\', maybe you meant:\n    cp\n    ls\n    mv\n    presign\n    rm\n    website\n')) == ['aws s3 cp s3://bucketname', 'aws s3 ls s3://bucketname', 'aws s3 mv s3://bucketname', 'aws s3 presign s3://bucketname', 'aws s3 rm s3://bucketname', 'aws s3 website s3://bucketname']


# Generated at 2022-06-12 10:50:11.864405
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws ec2 run-instance --region eu-west-1 --image ami-asdasdas --instance-type t2.micro"
    output = "An error occurred (InvalidParameterValue) when calling the RunInstances operation: Invalid AMI ID: \"ami-asdasdas\"\n\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n  To see help text, you can run:\n    aws help\n    aws <command> help\n    aws <command> <subcommand> help\naws: error: argument --region: Invalid choice: 'eu-west-1', maybe you meant: us-west-2"


# Generated at 2022-06-12 10:50:14.121863
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 list', 'aws: error: Invalid choice: "s3", maybe you meant:\n  * s3api', '/')) == ['aws s3api list']

# Generated at 2022-06-12 10:50:17.646602
# Unit test for function match
def test_match():
    """
    Function match must return True when the aws command is missing
    """
    command = Command('aws s3 ls s3:///', '')
    assert match(command)



# Generated at 2022-06-12 10:50:20.157735
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws help cli", "aws: error: argument command: Invalid choice: 'help cli', maybe you meant:\n  * cli\n  * s3api")
    assert get_new_command(command) == ['aws cli', 'aws s3api']
# End test_get_new_command

enabled_by_default = True

# Generated at 2022-06-12 10:50:31.855406
# Unit test for function match

# Generated at 2022-06-12 10:50:39.537158
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws ec2 describe-instances --filters Name=instance-type,Values=m2.xlarge", "")
    result = [replace_argument("aws ec2 describe-instances --filters Name=instance-type,Values=m2.xlarge",
                               "--filters", o) for o in re.findall(OPTIONS, "* --filters (Name,Values)* --generate-cli-skeleton")]
    assert get_new_command(command) == result


# Generated at 2022-06-12 10:50:45.209100
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 delete-volume --volume',
        'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
        'aws: error: argument subcommand: Invalid choice: '
        '\'delete-volume\', maybe you meant: \n    '
        'delete-snapshot\n    delete-tags\n    '
        'delete-volume-permission\n    describe-snapshots'))


# Generated at 2022-06-12 10:50:48.754121
# Unit test for function match
def test_match():
    assert match(Command('aws -h', ''))
    assert not match(Command('ssh -h', ''))


# Generated at 2022-06-12 10:50:50.592682
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances --instance-ids i-1234567'))
    assert not match(Command('echo "hello"'))


# Generated at 2022-06-12 10:50:58.898720
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls',
'''usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, valid choices are:''')) == [
        Command('aws s3 ls', ''),
    ]

# Generated at 2022-06-12 10:51:09.053045
# Unit test for function get_new_command
def test_get_new_command():
    input_command = Command("aws ec2 describe-instances --instance-id aws-test-instance-id --region region-1",
            "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n"
            "aws: error: argument --instance-id: Invalid choice, maybe you meant:\n"
            "                                 instance-id  Show information about a particular instance\n"
            "                                 instance-id-normalize  Normalize instance IDs in a resource group (for example,\n"
            "                                                       converting i-1234567 from short to long format).\n"
            "                                 instance-id-format  Change the format of the given instance IDs.\n")

# Generated at 2022-06-12 10:51:20.405516
# Unit test for function get_new_command

# Generated at 2022-06-12 10:51:30.184705
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 ss', 'usage: aws [options] <command> <subcommand> \
[<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\
\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument \
ec2: Invalid choice, maybe you meant:\n                 snapshot\n           \
  ssh\n           subnet\n           s3\n\n', '', 0)
    new_command = get_new_command(command)
    assert new_command == [command.script + ' snapshot',
                           command.script + ' ssh',
                           command.script + ' subnet',
                           command.script + ' s3']

# Generated at 2022-06-12 10:51:32.938771
# Unit test for function match
def test_match():
    assert match(Command('aws', 'usage: aws [options] [parameters]',
                         'Invalid choice: \'x\', maybe you meant:',
                         ' * y\n'))



# Generated at 2022-06-12 10:51:42.493114
# Unit test for function get_new_command
def test_get_new_command():
    func_test = get_new_command("aws iam create-user \
--user-name 'dev-user' \
--permissions-boundary 'arn:aws:iam::aws:policy/AdministratorAccess'")

    print("func_test")
    print(func_test)

# Generated at 2022-06-12 10:51:52.744793
# Unit test for function match

# Generated at 2022-06-12 10:52:02.625737
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    # Test for case with one option
    output_one_option = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument <subcommand>: Invalid choice, valid choices are:\n\t* s3api
aws: error: Invalid choice: 's3', maybe you meant:\n\t* s3api"""
    assert get_new_command(Command('aws s3', output_one_option)) == ['aws s3api']

    # Test for case with multiple options

# Generated at 2022-06-12 10:52:04.384639
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 subcommand')) == [
        'aws s3 sync']

# Generated at 2022-06-12 10:52:07.121149
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command("aws --help", "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]", "")) == ['aws help'])

# Generated at 2022-06-12 10:52:18.161575
# Unit test for function get_new_command

# Generated at 2022-06-12 10:52:21.377344
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 ls', "Invalid choice: 'ec', maybe you meant:\n   help\n   ls"))



# Generated at 2022-06-12 10:52:24.889717
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws s3 ls bork") == ["aws s3 ls"]
    assert get_new_command("aws s3 ls") == ["aws s3 ls"]

enabled_by_default = True

# Generated at 2022-06-12 10:52:32.481492
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 blah blah blah', '', ''))
    assert match(Command('aws ec2 blah blah blah', '', ''))
    assert match(Command('aws ec2 blah blah blah', 'usage: aws [options] [parameters]', 'usage: aws [options] [parameters]\n* blah blah blah\nmaybe you meant: blah'))
    assert not match(Command('aws ec2 blah blah blah', 'usage: aws [options] [parameters]', 'usage: aws [options] [parameters]'))
    assert not match(Command('ls -la', '', ''))
    assert not match(Command('ls', '', ''))



# Generated at 2022-06-12 10:52:38.650707
# Unit test for function match
def test_match():
    assert match(Command('aws --help',
            'usage: aws [options] [ ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws help\n  aws aws help\naws: error: argument action: Invalid choice, valid choices are:\n\n* abc\n* efg\n* ijk\n\nmaybe you meant:\n\n* abc\n\n'))


# Generated at 2022-06-12 10:52:57.943911
# Unit test for function get_new_command
def test_get_new_command():
    """ Unit test for function get_new_command."""
    from thefuck.types import Command
    from test.utils import CommandStub

    new_command = Command('aws ec2 u', '')

# Generated at 2022-06-12 10:53:01.198811
# Unit test for function match
def test_match():
    assert match(Command('aws', '', 'usage:'))
    assert not match(Command('ls', '', ''))


# Generated at 2022-06-12 10:53:06.688594
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls s3://my-bucket/'))
    assert match(Command('aws sns list-topics --region us-east-1'))
    assert match(Command('aws ec2 describe-security-groups --filters Name=ip-permission.from-port,Values=22'))


# Generated at 2022-06-12 10:53:17.343248
# Unit test for function get_new_command

# Generated at 2022-06-12 10:53:27.959613
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws ec2 maybe_you'
    out = 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\naws: error: argument subcommand: Invalid choice, maybe you meant:\n\tinstance\n\tgroup\n\timage'
    command = FakeCommand(script, out)
    new_command = get_new_command(command)
    assert new_command == ['aws ec2 instance', 'aws ec2 group', 'aws ec2 image']

# Generated at 2022-06-12 10:53:34.874832
# Unit test for function get_new_command

# Generated at 2022-06-12 10:53:46.175707
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command


# Generated at 2022-06-12 10:53:57.888765
# Unit test for function match
def test_match():
    assert match(Test(script = 'aws configure', output = 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]')) == True
    assert match(Test(script = 'aws configure', output = 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]')) == True
    assert match(Test(script = 'aws configure', output = 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]')) == True
    assert match(Test(script = 'aws configure', output = 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]')) == True

# Generated at 2022-06-12 10:53:59.078683
# Unit test for function match
def test_match():
    assert match(Command('aws output'))


# Generated at 2022-06-12 10:54:07.887680
# Unit test for function get_new_command
def test_get_new_command():
    command = type("Command", (object,), {"script": "aws ec2 stp", "output": "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n  aws <command> <subcommand> <subsubcommand> help\naws: error: argument subcommand: Invalid choice: 'stp', maybe you meant:\n\n  *  stop              Stop an instance.\n  *  start             Start an instance.\n"})
    assert get_new_command(command) == ['aws ec2 stop', 'aws ec2 start']

# Generated at 2022-06-12 10:54:38.182946
# Unit test for function get_new_command
def test_get_new_command():
    # Command with one option
    result = get_new_command(Command('aws ec2 describe-instances',
                                     'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n  error: Invalid choice: \'describe-instances\', maybe you meant:\n  * describe-instance-status\n  * describe-instances\n'
                                     ))
    assert result == ['aws ec2 describe-instance-status', 'aws ec2 describe-instances']

    # Command with two options

# Generated at 2022-06-12 10:54:44.182712
# Unit test for function match

# Generated at 2022-06-12 10:54:47.492313
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws s3 mv s3://bucket/object1 s3://bucket/object2") == (
        "aws s3 mv s3://bucket/object1 s3://bucket/object2")

# Generated at 2022-06-12 10:54:56.772257
# Unit test for function get_new_command

# Generated at 2022-06-12 10:55:00.719286
# Unit test for function match
def test_match():
    cmd = Command('aws s3 ls', '')
    assert match(cmd)
    cmd = Command('aws s3 ls --help', 'Error: unrecognized arguments: --help')
    assert not match(cmd)

# Mock for unit test for function get_new_command

# Generated at 2022-06-12 10:55:08.057410
# Unit test for function get_new_command

# Generated at 2022-06-12 10:55:17.683298
# Unit test for function match

# Generated at 2022-06-12 10:55:24.753897
# Unit test for function get_new_command

# Generated at 2022-06-12 10:55:35.928487
# Unit test for function get_new_command
def test_get_new_command():
    mock_script = 'aws ec2 describe-instances --filter "Name=image-id,Values=ami-0dfc01a072b2d9f60" --region us-east-1'

# Generated at 2022-06-12 10:55:42.091507
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command("command", "output")
    assert get_new_command(command) == ["command"]
    command = Command("command", "Invalid choice: 'misspelled', maybe you meant:\n * misspelled")
    assert get_new_command(command) == ["command"]
    command = Command("command", "Invalid choice: 'misspelled', maybe you meant:\n * correct\n * correct2")
    assert get_new_command(command) == ["command", "command"]

# Generated at 2022-06-12 10:56:34.457094
# Unit test for function match

# Generated at 2022-06-12 10:56:36.188711
# Unit test for function match
def test_match():
    assert match(Command('aws help', ''))
    assert not match(Command('aws', ''))


# Generated at 2022-06-12 10:56:44.948999
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.aws_cli import get_new_command

# Generated at 2022-06-12 10:56:52.591017
# Unit test for function match
def test_match():
    # should match
    output = "An error occurred (UnknownOperation) when calling the ListUsers operation: Unknown operation: 'eh'"
    assert match(Command(script="eh", output=output))
    # should not match
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run: aws help\n\nor aws <command> help\n\nor aws <command> <subcommand> help\n\naws: error: argument subcommand: Invalid choice, maybe you meant:\n    events\n    ecr\n    ecs\n    kms\n    config\n    firehose\n    cloudtrail\n    cloudformation"
    assert not match(Command(script="eh", output=output))

# Generated at 2022-06-12 10:57:00.156289
# Unit test for function match
def test_match():
    # When the command contains an invalid choice and some options
    command = Command('aws s3 ls', 'Invalid choice: "djkfhgkjdfhgkjd"\n    maybe you meant:\n    * list-buckets')
    assert match(command) is True

    # When the command contains an invalid choice but no options
    command = Command('aws s3 ls', 'Invalid choice: "djkfhgkjdfhgkjd"')
    assert match(command) is False


# Generated at 2022-06-12 10:57:09.790982
# Unit test for function get_new_command