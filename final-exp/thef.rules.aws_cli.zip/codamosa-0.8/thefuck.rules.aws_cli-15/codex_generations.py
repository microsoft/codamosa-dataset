

# Generated at 2022-06-12 10:47:20.556064
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.aws_cli import get_new_command
    for _ in range(10):
        assert get_new_command(
            "aws ec2 describe-regions --filters Name=optio,Values=sa-east-1"
            )[0] == "aws ec2 describe-regions --filters Name=optio,Values=sa-east-1"
    for _ in range(10):
        assert get_new_command(
            "aws ec2 describe-regions --filters Name=optio,Values=sa-east-1"
            )[0] == "aws ec2 describe-regions --filters Name=optio,Values=sa-east-1"

# Generated at 2022-06-12 10:47:28.617337
# Unit test for function match
def test_match():
	ex = "aws ec2 describe-vpcs --version\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --version: Invalid choice, maybe you meant:\n    --version-name\n    --version-id\n    --version-label\n\n"
	command = MagicMock(output=ex)
	assert match(command)


# Generated at 2022-06-12 10:47:32.350247
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='aws s3 bucket get',
                                   output='aws: error: argument command: Invalid choice: \'get\', maybe you meant: \n  * get-object')) == \
                                   ['aws s3 bucket get-object']

# Generated at 2022-06-12 10:47:42.630879
# Unit test for function match

# Generated at 2022-06-12 10:47:48.829508
# Unit test for function match
def test_match():
    output = "usage: aws [options]\n" \
             "aws: error: argument command: Invalid choice: 'cloudfromation', maybe you meant:\n" \
             "   * cloudformation\n" \
             "   * cloudwatchlogs\n" \
             "   * cloudwatch \n" \
             "See 'aws help' for descriptions of global parameters."
    assert match(Command(script='aws cloudfromation', output=output))



# Generated at 2022-06-12 10:47:58.451240
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck import types

# Generated at 2022-06-12 10:48:05.550937
# Unit test for function match
def test_match():
    assert match(Command('aws --help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice: "hola", maybe you meant: \n    help'))
    assert not match(Command('ls', ''))



# Generated at 2022-06-12 10:48:10.076728
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'usage: aws [options] [parameters]\naws: error: argument'))
    assert not match(Command('aws help', 'Invalid choice: \'bsdf\'\naws: error: argument'))
    assert not match(Command('aws help', 'aws: error: argument'))


# Generated at 2022-06-12 10:48:19.294168
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls us-west-1')) == ['aws s3 ls us-west-2', 'aws s3 ls eu-west-1', 'aws s3 ls ap-northeast-1', 'aws s3 ls us-east-1']
    assert get_new_command(Command('aws ec2 describe-instances --region us-west-1')) == ['aws ec2 describe-instances --region us-west-2', 'aws ec2 describe-instances --region eu-west-1', 'aws ec2 describe-instances --region ap-northeast-1', 'aws ec2 describe-instances --region us-east-1']

# Generated at 2022-06-12 10:48:25.211428
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("aws --version", ""))[0] == "aws --version"
    assert get_new_command(Command("aws ecs help", ""))[0] == "aws ecs help"
    assert get_new_command(Command("aws sts help", ""))[0] == "aws sts help"
    assert get_new_command(Command("aws help", ""))[0] == "aws help"
    assert get_new_command(Command("aws configure list", ""))[0] == "aws configure list"
    assert get_new_command(Command("aws configure list", ""))[1] == "aws configure list"

# Generated at 2022-06-12 10:48:32.893805
# Unit test for function match
def test_match():
    assert match(Command('aws s3 cp test.txt s3://mybucket/test.txt',
                         '\nUnknown options: cp\nusage: aws [options] \
                         <command> <subcommand> [parameters]\n  \
                         error: Invalid choice: \'cp\', maybe you meant: \
                         \n  * cp-s\n  * ups\n\nSee \'aws help\' \
                         for descriptions of global parameters.\n',
                         1))


# Generated at 2022-06-12 10:48:41.819789
# Unit test for function get_new_command

# Generated at 2022-06-12 10:48:51.055518
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="aws s3 ls", output="Invalid choice: 's3', maybe you meant:\n* s3api\n* s3control\n* s3cp\n* s3 ls", stderr="")) == ['aws s3api ls', 'aws s3control ls', 'aws s3cp ls', 'aws s3 ls']

# Generated at 2022-06-12 10:48:55.354975
# Unit test for function match
def test_match():
    output_pattern = "Invalid choice: 'invalid-option', maybe you meant:\n  " +\
                     "* option1\n  * option2"
    aws_command = "aws ec2 start-instances --invalid-option i-12345678"
    command = type('Command', (object,), {'script': aws_command, 'output': output_pattern})

    assert match(command)



# Generated at 2022-06-12 10:49:03.955345
# Unit test for function match

# Generated at 2022-06-12 10:49:14.865839
# Unit test for function match
def test_match():
    assert match(Command(script="aws ec2 help", output="usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, maybe you meant:\n    commands\n    config\n    emr\n    help\n    iam\n    info\n    kinesis\n    kms\n    lambda\n    support\n    --help\n", stderr="", exit_code=255))

# Generated at 2022-06-12 10:49:21.708076
# Unit test for function match
def test_match():
    assert match(Command(script='aws', output='usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:', stderr=None))
    assert not match(Command(script='git branch -v', output='', stderr=None))


# Generated at 2022-06-12 10:49:30.774956
# Unit test for function match

# Generated at 2022-06-12 10:49:33.248514
# Unit test for function match
def test_match():
    assert match(Command('aws not-exists config'))
    assert not match(Command('git branch'))

# Generated at 2022-06-12 10:49:43.583445
# Unit test for function match
def test_match():
    test_output = (
        "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n"
        "To see help text, you can run:\n"
        "\n"
        "  aws help\n"
        "  aws <command> help\n"
        "  aws <command> <subcommand> help\n"
        "\n"
        "aws: error: argument cli speaks-for: Invalid choice, maybe you meant: \n"
        "        * ec2\n"
        "        * ec2-instance-connect\n"
        "        * ec2-instance-connect-cli\n"
        "See 'aws help' for descriptions of global parameters.\n")

# Generated at 2022-06-12 10:49:55.525560
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\naws: error: argument subcommand: Invalid choice: \'ls\', maybe you meant:\n* ls-bucket\n* ls-buckets\n* ls-queue\n* ls-topic\n* ls-stream\n* ls-type\nSee \'aws help\' for descriptions of global parameters.\n')
    assert get_new_command(command) == ['aws s3  ls-bucket', 'aws s3  ls-buckets', 'aws s3  ls-queue', 'aws s3  ls-topic', 'aws s3  ls-stream', 'aws s3  ls-type']

# Generated at 2022-06-12 10:49:59.114527
# Unit test for function match
def test_match():
    assert match(Command('aws s3 sync s3://dev/20160331 ./20160331',
                         stderr='Error: Invalid choice: "s3", maybe you meant:',
                        ))


# Generated at 2022-06-12 10:50:06.496410
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws ec2 describe-keypairs'
    output = '''aws: error: argument operation: Invalid choice, valid choices are:
    create-key-pair
    delete-key-pair
    import-key-pair
    describe-key-pairs
    describe-key-pairs
    Maybe you meant: describe-key-pairs'''
    command = Command(script=script, output=output)
    get_new_command(command)

    assert get_new_command(command) == ['aws ec2 describe-key-pairs']

# Generated at 2022-06-12 10:50:09.741698
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws config s3', '')) == ['aws s3 sync \\\\source_folder \\\\destination_folder']
    assert get_new_command(Command('aws config s3', '')) != ['aws s3 sync source_folder destination_folder']

# Generated at 2022-06-12 10:50:13.955029
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws ec2 ass-something"

# Generated at 2022-06-12 10:50:25.429800
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('aws ec2', 'aws: error: argument command: Invalid choice: \'-\', maybe you meant:\n  * \'ec2\'\n  * \'ecr\'\n  * \'ecs\'\n')) == ['aws ec2']

# Generated at 2022-06-12 10:50:33.305877
# Unit test for function get_new_command

# Generated at 2022-06-12 10:50:41.186244
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws ec2 describe-images --image-ids $i"
    output = "aws: error: argument --image-ids: Invalid choice: '$i', maybe you meant:\n\t* 'ami-abcdefg'\n\t* 'ami-123456'"
    error = "aws ec2 describe-images --image-ids $i"
    assert(get_new_command(Command(command, output, error)) == ["aws ec2 describe-images --image-ids ami-abcdefg", "aws ec2 describe-images --image-ids ami-123456"])

# Generated at 2022-06-12 10:50:42.695385
# Unit test for function match
def test_match():
    assert match(command = Command('aws help'))
    assert not match(command = Command('aws'))


# Generated at 2022-06-12 10:50:52.298842
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.aws_cli_maybe_you_meant import get_new_command
    output = """usage: aws [options] [ ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument command: Invalid choice, valid choices are:

configure
help

Unknown options: --version
aws: error: argument command: Invalid choice: '--version'. maybe you meant:
        * --version
        * --version-label
        * --version-description
        * --version-table
        * --version-stage
        * --version-id
        * --version-count
        * --version-name
        * --version-number"""

# Generated at 2022-06-12 10:51:04.316418
# Unit test for function get_new_command
def test_get_new_command():
    command = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice: 'ec2-describe-spot-price-history', maybe you meant:
  * describe_spot_price_history
  * describe_spot_datafeed_subscription
"""
    assert get_new_command(command) == ['aws ec2 describe_spot_price_history', 'aws ec2 describe_spot_datafeed_subscription']

# Generated at 2022-06-12 10:51:06.311940
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://bucket'))


# Generated at 2022-06-12 10:51:17.405265
# Unit test for function get_new_command
def test_get_new_command():
    output_error = "Unknown options: --accesspoint-id, --account-id, --bucket, --client-request-token, --examples, --force, --no-sign-request, --no-verify-ssl, --s3-force-path-style, --s3-use-accelerate-endpoint, --url, --version, --xml.\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\naws help\naws <command> help\naws <command> <subcommand> help\naws: error: argument operation: Invalid choice, maybe you meant:\n  * restore-object\n  * get-object\n  * delete-object\n  * put-object"
    new_command = get_new_command

# Generated at 2022-06-12 10:51:19.788527
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [parameters] aws: error: argument command: Invalid choice: \'s3\', maybe you meant:', '', 1))


# Generated at 2022-06-12 10:51:26.862179
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\nuse it with the --flag option\n\n'))



# Generated at 2022-06-12 10:51:35.444991
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws ec2 terminate-instances --instance-ids i-12345678 --region us-east-1",
                 "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n"
                 "aws: error: argument operation: Invalid choice, maybe you meant:\n"
                 "* terminate-instances\n"
                 "* stop-instances\n"
                 "See 'aws help' for descriptions of global parameters.")
    assert get_new_command(command) == ["aws ec2 terminate-instances --instance-ids i-12345678 --region us-east-1",
                                        "aws ec2 stop-instances --instance-ids i-12345678 --region us-east-1"]

# Generated at 2022-06-12 10:51:39.004175
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws s3 ls --direcTory-name bktname", "")
    assert get_new_command(command) == ["aws s3 ls --directory-name bktname"]

# Generated at 2022-06-12 10:51:46.962463
# Unit test for function match
def test_match():
    """
    :return: bool
    """

# Generated at 2022-06-12 10:51:57.313484
# Unit test for function get_new_command

# Generated at 2022-06-12 10:52:00.686535
# Unit test for function match
def test_match():
    assert match(Command('aws --help', 'aws --help\nusage: aws [options] <command>\n ...', 0))
    assert not match(Command('ls', 'usage: aws [options] <command>\n ...', 0))


# Generated at 2022-06-12 10:52:23.772839
# Unit test for function get_new_command
def test_get_new_command():
    result_1 = get_new_command(Command('aws s3 ls s3://bucket-1', output='''
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
aws: error: argument command: Invalid choice, valid choices are:
'''))
    assert result_1 == ['aws s3 ls s3://bucket-1']


# Generated at 2022-06-12 10:52:30.634406
# Unit test for function match
def test_match():
    assert match(Command('aws test', 'usage: aws [options] <command> <subcommand> [parameters]\n\naws: error: argument operation: Invalid choice: \'test\', maybe you meant:\n        * test-connection\n        * test-invoke-authorizer\n        * test-invoke-method\n        * test-metric-filter\n        * test-repository-triggers', '', 1))
    assert not match(Command('ls test', 'test: not found', '', 1))


# Generated at 2022-06-12 10:52:39.323605
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://test', '', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\naws: error: too few arguments\nmaybe you meant:\n        mv\n        rb\n'))
    assert match(Command('aws ec2 describe-instances us-east-1 --filter Name=tag:', '', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\naws: error: argument --filter: expected one argument\nmaybe you meant::\n        --profile\n        --region\n        --output\n'))
    assert not match(Command('aws --version'))


# Generated at 2022-06-12 10:52:43.847119
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws cloudformation delete-stack --stack-name test')
    assert get_new_command(command) == ['aws cloudformation delete-stack --stack-name test']
    command = Command('aws cloudformation delete-stack --stack-name test2')
    assert get_new_command(command) == ['aws cloudformation delete-stack --stack-name test']

# Generated at 2022-06-12 10:52:53.918111
# Unit test for function match
def test_match():
    assert not match(Command('echo'))
    assert match(Command('aws ec2 describe-regions --region us-east-1',
        'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --region: Invalid choice: \'us-east-1\', maybe you meant:\n    us-east-2\n    us-east-1'))


# Generated at 2022-06-12 10:53:05.011610
# Unit test for function match
def test_match():
    assert (for_app('aws')(lambda: None)(
        Command('aws ec2 describe-spot-price-history',
                'usage: aws [options] <command> <subcommand> [parameters]\n\naws: error: argument subcommand: Invalid choice: \'describe-spot-price-history\', maybe you meant: describe-spot-datafeed-subscription\ndescribe-spot-fleet-instances\ndescribe-spot-fleet-request-history\ndescribe-spot-fleet-requests\ndescribe-spot-instances\ndescribe-spot-price-history\n\nTo see help text, you can run: aws help\n\n')) == True)


# Generated at 2022-06-12 10:53:16.328979
# Unit test for function get_new_command
def test_get_new_command():
    command = {'output':"usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n"
                                                                          "aws: error: argument subcommand: Invalid choice: 'ec2', maybe you meant:\n"
                                                                          "    ec2:run-instances\n"
                                                                          "    ec2:create-tags\n"
                                                                          "    ec2:create-instances\n"
                                                                          "    ec2:create-images\n",
                                                                        'script':'aws ec2'}
    new_command = get_new_command(command)

# Generated at 2022-06-12 10:53:23.412263
# Unit test for function get_new_command
def test_get_new_command():
    with open("tests/repl.py") as f:
        command_line = f.read()
    command = Command(command_line, "aws", "")
    assert get_new_command(command) == ["aws ec2 Runnstances i-123456789 --region us-east-2",
                                        "aws ec2 Runnstances i-123456789 --region us-east-1"]

# Generated at 2022-06-12 10:53:27.366992
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws help', 'aws: error: argument command: Invalid choice: \'help\', maybe you meant:\n\n* help\n  *-- helps (A list of available help commands)\n\n')) == ['aws help']


# Generated at 2022-06-12 10:53:35.823554
# Unit test for function match
def test_match():
    assert match(Command('aws --help', 'aws: error: argument --help: invalid choice: \'--help\'\n'))
    assert match(Command('aws hl', 'aws: error: argument hl: invalid choice: \'hl\'\n'))
    assert not match(Command('aws hlm', 'aws: error: argument hlm: invalid choice: \'hlm\'\n'))
    assert not match(Command('aws help', 'aws: error: argument help: invalid choice: \'help\'\n'))


# Generated at 2022-06-12 10:54:01.058004
# Unit test for function get_new_command
def test_get_new_command():
    assert ['aws s3 ls '] == get_new_command(Command('aws s3 ls ', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument command: Invalid choice: \'"s3 ls"\', maybe you meant:...', '', None, 1, None))

# Generated at 2022-06-12 10:54:05.616563
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-instances')) == [
        'aws ec2 describe-instances']
    assert get_new_command(Command('aws ec2 describe-instance')) == [
        'aws ec2 describe-instances']

# Generated at 2022-06-12 10:54:06.780619
# Unit test for function get_new_command
def test_get_new_command():
    command = ['-h']
    get_new_command(command) == ['-h']

# Generated at 2022-06-12 10:54:13.621785
# Unit test for function match
def test_match():
    assert match(Command('aws configure', 'usage: aws [options] [parameters]\naws: error: argument command: Invalid choice: "configure", maybe you meant: check-dns-rr\n* check-dns-rr\n* check-dns-soa\n* check-dns-txt\n* check-rds-parameter-group\n* check-rds-snapshot\n* check-rds-subnet-group\n* check-rds-db-cluster'))


# Generated at 2022-06-12 10:54:18.865201
# Unit test for function match
def test_match():
    assert match(Command("aws ec2command", "usage: aws [options] <command> ...", ""))
    assert match(Command("aws ec2command", "usage: aws [options] <command> ...", "Invalid choice: 'ec2command', maybe you meant:", ""))
    assert not match(Command("aws ec2command", "usage: aws [options] <command> ...", ""))


# Generated at 2022-06-12 10:54:22.108763
# Unit test for function get_new_command
def test_get_new_command():
    error_msg = "Invalid choice: 's3api', maybe you meant: \n	* s3api \n	* s3"
    command = Command('aws s3api', error_msg)
    assert get_new_command(command) == ["aws s3api", "aws s3"]

# Generated at 2022-06-12 10:54:27.079019
# Unit test for function match
def test_match():
    # Test command with error and suggestions
    command = Command('aws s3 ls --summarize')
    assert match(command)

    # Test command with error but no suggestions
    command = Command('aws s3 ls --sumasdfasdfmarize')
    assert not match(command)

    # Test command with no error
    command = Command('aws s3 ls')
    assert not match(command)



# Generated at 2022-06-12 10:54:30.164806
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws ec2 run-instances --image-id ami-2a1b"
    assert get_new_command(command) == ["aws ec2 run-instances --image-id ami-2a1b23c4"]



# Generated at 2022-06-12 10:54:35.893283
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    command = Command('aws ec2 descibe-instances', 'aws: error: argument --verbose: Invalid choice: \'-w\', maybe you meant:\n'
            '* --wasabi\n'
            '\n'
            'See \'aws help\' for descriptions of global parameters.\n', '')
    assert get_new_command(command) == ['aws ec2 describe-instances --verbose --wasabi']

# Generated at 2022-06-12 10:54:43.009253
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws ec2 describe-regions"

# Generated at 2022-06-12 10:55:42.244107
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-volumes --region us-east-1',
                      "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see \
help text, you can run: aws help\naws: error: argument operation: Invalid choice, maybe you meant: create, delete, \
describe, attach, detach, list, wait\n* create\n* delete\n* describe\n* attach\n* detach\n* list\n* wait\n\n")
    assert get_new_command(command)[0] == "aws ec2 describe-volumes --region us-east-1"
    assert get_new_command(command)[-1] == "aws ec2 describe-volumes --region us-east-1"

# Generated at 2022-06-12 10:55:45.771221
# Unit test for function match
def test_match():
    assert not match(mock_output('aws'))
    assert not match(mock_output('aws usage'))
    assert match(mock_output('aws usage: '))
    assert match(mock_output('aws usage: '))


# Generated at 2022-06-12 10:55:48.226231
# Unit test for function match
def test_match():
        assert match(Command('aws', 'usage: aws [options] <command> <subcommand> [parameters]'))
        assert not match(Command('ls', 'ls is the list command'))

#Unit test for function get_new_command

# Generated at 2022-06-12 10:55:58.880550
# Unit test for function get_new_command
def test_get_new_command():
    orig_command = "aws s3 rb s3://bucket/remote/path --dry-run"
    expected_command = "aws s3 rb s3://bucket/remote/path"

# Generated at 2022-06-12 10:56:05.268056
# Unit test for function match

# Generated at 2022-06-12 10:56:09.310547
# Unit test for function match
def test_match():
    assert match(Command('aws help',
                         "aws help\nusage: aws [options] <command> <subcommand> [parameters]\naws: error: argument command: Invalid choice: 'help', maybe you meant:\n\t--help\n",
                         '', 123))
    assert not match(Command('git commit'))


# Generated at 2022-06-12 10:56:10.119460
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-ets', ''))


# Generated at 2022-06-12 10:56:19.170533
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws ec2 describe-instances'
    output = ("usage: aws [options] <command> <subcommand> [parameters]\n"
        "To see help text, you can run:\n"
        "aws help\n"
        "aws <command> help\n"
        "aws <command> <subcommand> help\n"
        "aws: error: argument subcommand: Invalid choice,'ec2-describe-instances', maybe you meant:\n"
        "        * ec2-describe-images\n"
        "        * ec2-describe-instances\n"
        "        * ec2-describe-regions\n"
        "        * ec2-describe-tags\n"
        "        * ec2-describe-volumes\n")

# Generated at 2022-06-12 10:56:29.397955
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n    support\n    sync\n    ssm\n    swf\n    sns\n    snowball\n    s3\n    servicecatalog\n    sqs\n    sdb\n    sts\n    transfer\n    serverlessrepo\n    shield\n    shields\n    swf\n    swf-registration\n    swf-deprecation\n    swf-management')) == True
   

# Generated at 2022-06-12 10:56:35.207591
# Unit test for function match
def test_match():
    assert match(Command('aws help s', 'aws: error: too few arguments\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: Invalid choice: \'help\', maybe you meant:\n    service   List available service names.\n    help      Shows a list of commands or help for one command\n'))
