

# Generated at 2022-06-12 10:47:12.865161
# Unit test for function match
def test_match():
    assert match(Command('aws wg', ''))
    assert match(Command('aws wg', '', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-12 10:47:21.793895
# Unit test for function match
def test_match():
    print(match(Command(script="aws --help", output="Invalid choice: '--help', maybe you meant: --license --version ")))
    print(match(Command(script="aws --hep", output="Invalid choice: '--hep', maybe you meant: --help")))
    print(match(Command(script="aws --help", output="Invalid choice: '--help', maybe you meant: ")))

# Generated at 2022-06-12 10:47:32.442594
# Unit test for function get_new_command

# Generated at 2022-06-12 10:47:42.670124
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances --foo','''
usage: aws [options] <command> <subcommand> [parameters]
aws: error: argument subcommand: Invalid choice, valid choices are:

create-tags
delete-tags
describe-tags
modify-client-vpn-endpoint

You can also see help for all subcommands with aws [command] help.

aws: error: too few arguments

Unknown options: --foo'''))

# Generated at 2022-06-12 10:47:53.053532
# Unit test for function match
def test_match():
    output = "usage: aws [options] <command> <subcommand> [parameters]\nTo see help text, you can run:\n\n  aws help\n\nUnknown options: --image-id\naws: error: invalid choice: '--image-id', maybe you meant: --instance-id\n   --instance-id        The ID of the instance.\n   --image-id           The ID of the AMI, which was provided during image creation."
    error = "aws: error: invalid choice: '--image-id', maybe you meant: --instance-id"
    assert match(Command("aws ec2 create-image --image-id i-1234567890abcdef0 --name 123.png",output))
    assert not match(Command("aws s3 list", ""))

# Generated at 2022-06-12 10:48:01.113953
# Unit test for function get_new_command

# Generated at 2022-06-12 10:48:11.729877
# Unit test for function match

# Generated at 2022-06-12 10:48:22.522751
# Unit test for function match

# Generated at 2022-06-12 10:48:31.899304
# Unit test for function match
def test_match():
    assert not match(Command('git branch', ''))
    assert match(Command('aws', """usage: aws [options] <command> <subcommand> [<su
bcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument operation: Invalid choice, maybe you meant:
  operations
    list-objects
    get-object
    list-buckets
    delete-object
    head-object
    create-multipart-upload
    put-object
    upload-part
    list-multipart-uploads
    copy-object
    abort-multipart-upload""", stderr=''))

# Generated at 2022-06-12 10:48:37.125372
# Unit test for function match
def test_match():
    assert not match(Command("aws ec2 describe-instances", ""))
    assert match(Command("aws ec2 descride-instances", "usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\naws: error: argument subcommand: Invalid choice, maybe you meant:\n  SecurityGroups   ec2\n  SecurityGroupIds ec2", 1))


# Generated at 2022-06-12 10:48:48.031423
# Unit test for function match
def test_match():
    command = Command('aws ec2 --something',
                      'usage: aws [options] <command> <subcommand> [<subcommand> ...] ...\n'
                      'aws: error: argument --something: Invalid choice: \'--something\', maybe you meant:\n'
                      '   --output               The formatting style for command output.\n'
                      '   --query                The JMESPath query string. See http://jmespath.org/ for more information\n'
                      '   and examples.\n')
    assert match(command) is True
    command = Command('aws ec2 --instance-ids something',
                      'usage: aws [options] <command> <subcommand> [<subcommand> ...] ...')
    assert match(command) is False


# Generated at 2022-06-12 10:48:58.785008
# Unit test for function match

# Generated at 2022-06-12 10:49:01.565077
# Unit test for function match
def test_match():
    assert match(Command("aws cloudformation create-stack"))
    assert match(Command("aws ec2 desscribe-instances"))
    assert not match(Command("aws cloudformation create-stack", ""))


# Generated at 2022-06-12 10:49:07.843531
# Unit test for function get_new_command
def test_get_new_command():
    class fake_command:
        def __init__(self, script, output):
            self.script = script
            self.output = output
    script = 'aws logout'

# Generated at 2022-06-12 10:49:13.152232
# Unit test for function match
def test_match():
    assert match(Command('aws --region', 'aws: error: argument --region: Invalid choice: "--region", maybe you meant: aleph:1:1, alphanum:1:2'))
    assert not match(Command('aws --region', 'aws: error: argument --region: Invalid choice: "--region"'))


# Generated at 2022-06-12 10:49:17.024859
# Unit test for function match
def test_match():
    assert match(Command("aws", output="usage: blah blah blah blah Invalid choice: 'foo', maybe you meant: blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah "))
    assert match(Command("aws", output="AuthFailure: AWS was not able to validate the provided access credentials")) == False


# Generated at 2022-06-12 10:49:19.616680
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='aws r53', stdout='')
    new_command = get_new_command(command)
    assert new_command == command.script

# Generated at 2022-06-12 10:49:21.416634
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3/')) == ['aws s3 ']

# Generated at 2022-06-12 10:49:30.612651
# Unit test for function match

# Generated at 2022-06-12 10:49:41.845112
# Unit test for function match

# Generated at 2022-06-12 10:49:46.254606
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2', 'unknown-command: ec2\nusage:')) \
        == ['aws ec2']



# Generated at 2022-06-12 10:49:55.498976
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-12 10:50:06.249703
# Unit test for function match
def test_match():
    assert match(Command('aws', 'usage: aws [options] <command> <subcommand> [parameters]', 'Invalid choice: "service", maybe you meant:\n  * service\n  * services\n  * services-endpoints'))
    assert not match(Command('aws', 'usage: aws [options] <command> <subcommand> [parameters]', 'Invalid choice: "service", maybe you meant:\n  * services\n  * services-endpoints'))
    assert not match(Command('aws', 'usage: aws [options] <command> <subcommand> [parameters]', 'Invalid choice: "service", maybe you meant:\n  * service\n  * services\n  * services-endpoints\n  * services-someother-endpoint'))


# Generated at 2022-06-12 10:50:13.328589
# Unit test for function get_new_command
def test_get_new_command():
    command = type("Command", (object, ), {})
    command.output = """
usage: aws [options] [parameters]
aws: error: argument CLIENTSETOPTIONS: Invalid choice: 'ec2', maybe you meant:
        * ec2-instance
        * ec2-bundle-instance
        * ec2-cancel-conversion-task
        * ec2-cancel-export-task
        * ec2-cancel-reserved-instances-listing
    """
    command.script = "aws ec2"

# Generated at 2022-06-12 10:50:21.734569
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws --region blah blah blah"
    output = '''
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument --region: Invalid choice: 'blah', maybe you meant:
*  eu-west-1

'''
    assert get_new_command(Command(script, output)) == [
        'aws --region eu-west-1 blah blah']

# Generated at 2022-06-12 10:50:31.431157
# Unit test for function get_new_command

# Generated at 2022-06-12 10:50:42.317855
# Unit test for function get_new_command

# Generated at 2022-06-12 10:50:52.052091
# Unit test for function get_new_command
def test_get_new_command():
    # Invalid command
    cmd = "aws ec2 describe-spot-price-history --start-time 2016-12-01T00:00:00Z" \
          " --end-time 2017-01-01T00:00:00Z --instance-type m1.small"
    # What the output should be

# Generated at 2022-06-12 10:50:59.110397
# Unit test for function match
def test_match():
    assert match(Command('git branch hotfix', 'error: pathspec \'hotfix\' did not match any file(s) known to git.\n'
                                              'Did you mean this?\n'
                                              '\tmaster'))
    assert not match(Command('echo cow', ''))
    assert not match(Command('cd /etc', ''))

# Generated at 2022-06-12 10:51:09.377368
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws help"
    output = "Invalid choice: 'help', maybe you meant:\n" \
             "  * help\n" \
             "  * help-config\n" \
             "  * help-configfile\n" \
             "  * help-definition\n" \
             "  * help-help\n" \
             "  * help-script\n" \
             "  * help-scriptfile\n" \
             "  * help-config-inheritance"
    result = get_new_command(SimpleCommand(script, output))
    expected_result = ["aws help-config", "aws help-configfile", "aws help-definition", "aws help-help", 
                       "aws help-script", "aws help-scriptfile", "aws help-config-inheritance"]

# Generated at 2022-06-12 10:51:21.458794
# Unit test for function get_new_command
def test_get_new_command():
    class Command(object):
        def __init__(self, string):
            self.script = string
            self.output = "usage: aws [options] <command> <subcommand> [parameters]\n" + \
            "aws: error: argument <command>: Invalid choice: 's3mb', maybe you meant:  \n" + \
            "* s3                      \n" + \
            "* s3api\n" + \
            "aws: error: argument <command>: Invalid choice: 's3mb', maybe you meant:  \n" + \
            "* s3                      \n" + \
            "* s3api\n"
    assert get_new_command(Command("aws s3mb")) == ["aws s3", "aws s3api"]

# Generated at 2022-06-12 10:51:30.083841
# Unit test for function get_new_command
def test_get_new_command():
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: incorrect usage.\naws: error: Invalid choice: 'zzzz', maybe you meant:\n    * get-usage-forecast\n    * wait\n    * call\nSee 'aws help' for descriptions of global parameters.\n"
    script = 'aws foo'
    assert get_new_command(script, output) == ['aws get-usage-forecast', 'aws wait', 'aws call']


# Generated at 2022-06-12 10:51:38.831861
# Unit test for function match
def test_match():
    # Test a valid command with invalid choice
    assert match(Command('aws --help', 
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:',
                         'aws help\n    aws <command> help\n    aws <command> <subcommand> help\naws: error: argument operation: Invalid choice: \'--help\', maybe you meant:',
                         '  * --help'))
    # Test an invalid command with invalid choice

# Generated at 2022-06-12 10:51:43.297100
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mv source dest', 
    """aws: error: argument command: Invalid choice, 
    maybe you meant:
     * mb
     * cp
     * ls
     * rm
     * rb
     * sync
     * mv
    """, 1))



# Generated at 2022-06-12 10:51:51.756350
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    # Given
    command = Command('aws', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, valid choices are:\n\n  help\n    Invalid choice: \'help\' , maybe you meant:\n        hepl\n', '')

    # When
    new_command = get_new_command(command)

    # Then
    assert new_command == ['aws hepl']

# Generated at 2022-06-12 10:51:59.238719
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'aws: error: argument subcommand: Invalid choice, maybe you meant:\n\t* config\n\t* cloudwatch\n\t* configure\n\t* configureb\n\n However, you specified: help\n\n'))
    assert not match(Command('aws help', "aws: error: argument subcommand: Invalid choice, maybe you meant:\n\t* config\n\t* cloudwatch\n\t* configure\n\t* configureb\n\n However, you specified: help\n\n"))


# Generated at 2022-06-12 10:52:04.631593
# Unit test for function match
def test_match():
    assert match(Command('aws autoscaling udapte-auto-scaling-group',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
                         'aws: error: argument subcommand: Invalid choice: '
                         "'udapte-auto-scaling-group', maybe you meant:\n  * "
                         "update-auto-scaling-group\n  * describe-auto-scaling-groups\n"
                         "See 'aws help' for descriptions of global parameters."))



# Generated at 2022-06-12 10:52:07.331086
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command('aws ec2 --region eu-central-1 describe-instances')
    assert result == ['aws ec2 --region eu-central-1 describe-instances']

# Generated at 2022-06-12 10:52:14.687578
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws ec2 describe-instances'
    first_arg = 'ec2'
    mistake = 'ec21'
    options = ['ec2', 'elasticache', 's3', 'sns', 's3api']
    expected = ["aws ec2 describe-instances", "aws elasticache describe-instances", "aws s3 describe-instances", "aws sns describe-instances", "aws s3api describe-instances"]
    assert get_new_command(command, first_arg, mistake, options) == expected


# Generated at 2022-06-12 10:52:22.856164
# Unit test for function get_new_command
def test_get_new_command():
    # No typo 
    command = Command("aws ec2 help", "", "")
    assert get_new_command(command) == None
    # Typo 
    command = Command("aws e2 help", "usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument operation: No value for argument \n* e2\n  help\n* instance", "")
    assert get_new_command(command) == ['aws e2 help', 'aws instance help']


# Generated at 2022-06-12 10:52:32.735028
# Unit test for function match
def test_match():
    command = Command("aws ec2 authorize-security-group-ingress --help", "aws: error: argument --group-name: expected one argument\nUsage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --group-name: expected one argument\n\nUnknown options: --help\n")
    assert match(command)

######################################################################


# Generated at 2022-06-12 10:52:34.894672
# Unit test for function match
def test_match():
    assert match("aws usage: aws [options] <adfasdf>", "Invalid choice: 'usage', maybe you meant:") != None


# Generated at 2022-06-12 10:52:44.497451
# Unit test for function match
def test_match():
    invalid = "aws: error: argument command: Invalid choice: 's3li', maybe you meant:\n                      * s3ls\n                      * s3mv\n                      * s3cp\n                      * s3\n                      * s3api\n                      * s3bucket\n                      * s3api"
    result = match(Command(script='', stderr=invalid))
    assert result

    # no match
    invalid_2 = "aws: error: argument command: Invalid choice: 's3sync', maybe you meant:\n                      * s3ls\n                      * s3mv\n                      * s3cp\n                      * s3\n                      * s3api\n                      * s3bucket\n                      * s3api"
    result_2 = match(Command(script='', stderr=invalid_2))


# Generated at 2022-06-12 10:52:54.117578
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 go', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]', 'aws: error: argument subcommand: Invalid choice: \'go\', maybe you meant:\\n\\n* describe-instances\\n* describe-addresses\\n* describe-key-pairs\\n* get-console-output   '))
    assert not match(Command('aws ec2 stop', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]', ''))

# Generated at 2022-06-12 10:53:04.054695
# Unit test for function get_new_command

# Generated at 2022-06-12 10:53:09.278689
# Unit test for function match
def test_match():
    command = Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [parameters]\n\
aws: error: argument subcommand: Invalid choice, maybe you meant:\n\
                 help            \n\
                 info            \n\
                 configure')
    assert match(command) == True


# Generated at 2022-06-12 10:53:18.781240
# Unit test for function match

# Generated at 2022-06-12 10:53:24.694325
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws s3api list-buckets", "", "Invalid choice: 's3api', maybe you meant:\n  * cb\n  * cp\n  * ls\n")
    assert get_new_command(command) == ['aws cb list-buckets', 'aws cp list-buckets', 'aws ls list-buckets']

# Generated at 2022-06-12 10:53:35.819522
# Unit test for function match

# Generated at 2022-06-12 10:53:46.863588
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    script = 'aws ec2 describe-instances --output json'

# Generated at 2022-06-12 10:54:01.266966
# Unit test for function match
def test_match():

    # Create a test aws command
    fpath = '/home/scraperwiki/bin'
    cmd = 'aws s3 ls s3://'
    out = '''usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument command: Invalid choice, valid choices are:

 * cp
 * mv
 * rm
 * sync
 * ls
 * configure
 * configure set
 * configure get
 * configure list
 * configure delete
 * configure resize-auth-area
 * configure set-fast-fail
 * configure get-fast-fail
maybe you meant: ls'''

    # Create a Command object with the right path and output
    _

# Generated at 2022-06-12 10:54:03.245908
# Unit test for function match
def test_match():
    assert match(Command(script='help', output='usage:  [options] ...'))
    assert not match(Command())


# Generated at 2022-06-12 10:54:14.018451
# Unit test for function get_new_command

# Generated at 2022-06-12 10:54:15.487345
# Unit test for function match
def test_match():
    assert match(Command('aws --help', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-12 10:54:16.008769
# Unit test for function get_new_command
def test_get_new_command():
    pass

# Generated at 2022-06-12 10:54:24.371624
# Unit test for function get_new_command
def test_get_new_command():
    command=Command("aws s3 mb s3://test-add-local-file-to-bucket/ --region us-east-1")
    command.output = "An error occurred (InvalidRegion) when calling the CreateBucket operation: The specified region 'us-east-1' is not a valid region.\nCheck your command for typos and run the command again.\n\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\naws: error: argument subcommand: Invalid choice, maybe you meant:\n    cp\n    ls\n    mb\n    rb"
    assert get_

# Generated at 2022-06-12 10:54:33.804396
# Unit test for function match

# Generated at 2022-06-12 10:54:40.356091
# Unit test for function match
def test_match():
    assert (match(Command('aws help', '')) == 
    False)
    assert (match(Command('aws help', 'usage: aws [options] <command> <subcommand> [parameters]\n        To see help text, you can run:\n          aws help\n        aws help <command>\n        aws <command> help\n        aws <command> <subcommand> help\naws: error: Invalid choice: \'hlep\', maybe you meant:\n    help\n    health-event\n    health')) == 
    True)

# Generated at 2022-06-12 10:54:43.081329
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws ec2 run-instances", ['aws ec2 run-instances']) == ['aws ec2 run-instances']

# Generated at 2022-06-12 10:54:52.773880
# Unit test for function match

# Generated at 2022-06-12 10:55:17.607603
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws ec2 help") == [
        "aws ec2 help", "aws ec2 h", "aws ec2", "aws ec2 2", "aws ec2 h2p"]
    assert get_new_command("aws ec2 help --help") == [
        "aws ec2 help --help",
        "aws ec2 help --h",
        "aws ec2 help --help2",
        "aws ec2 help --h2p",
        "aws ec2 help -help",
        "aws ec2 help -h",
        "aws ec2 help -help2",
        "aws ec2 help -h2p"]

# Generated at 2022-06-12 10:55:23.691609
# Unit test for function get_new_command
def test_get_new_command():
    command = type('obj', (object,), {'output': '''usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

aws: error: argument subcommand: Invalid choice: 'foo', maybe you meant:
 * foo-bar
 * foo-baz
 * foo-bip''', 'script': 'aws foo'})

    assert get_new_command(command) == ['aws foo-bar', 'aws foo-baz', 'aws foo-bip']

# Generated at 2022-06-12 10:55:32.859574
# Unit test for function get_new_command

# Generated at 2022-06-12 10:55:42.877998
# Unit test for function get_new_command

# Generated at 2022-06-12 10:55:47.188286
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances --instance-id i-1234567890abcdef0', 'usage: aws [options] <command> <subcommand> [--region <value>] [parameters]\naws: error: argument instance-id: Invalid choice: \'--instance-id\', maybe you meant: \n  * --instance-ids\n  * --instance-type'))


# Generated at 2022-06-12 10:55:57.560327
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 help', 'usage:\naws [options] <command> <subcommand> [parameters]\n\nMaybe you meant:\n  ec2                 <subcommand>'))
    assert match(Command('aws ec2 help', 'usage:\naws [options] <command> <subcommand> [parameters]\n\nInvalid choice: \'ec2h\', maybe you meant:\n  ec2                 <subcommand>'))
    assert match(Command('aws ec2 help', 'usage:\naws [options] <command> <subcommand> [parameters]\n\nInvalid choice: \'ec2\', maybe you meant:\n  ec2                 <subcommand>'))

# Generated at 2022-06-12 10:56:04.665579
# Unit test for function match

# Generated at 2022-06-12 10:56:07.687766
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(create_command('aws -a s3')) == ['aws s3']
    assert get_new_command(create_command('aws -a s')) == ['aws s3']


# Generated at 2022-06-12 10:56:13.572031
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(__testing_command("aws ec2 stop-instance")) == ['aws ec2 stop-instances']
    assert get_new_command(__testing_command("aws ec2 stop-instances")) == ['aws ec2 stop-instances']


# The below function is to test get_new_command function
# From https://stackoverflow.com/questions/52735974/how-to-mock-user-input-for-pytest
# I got the same question even I don't think I need the mock. 
# BUT I just tried it.

# Generated at 2022-06-12 10:56:14.413619
# Unit test for function match
def test_match():
    pass # test_match


# Generated at 2022-06-12 10:56:47.511769
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command) == ["aws ec2 describe-instance-status", "aws ec2 describe-instances"]

# Generated at 2022-06-12 10:56:52.505765
# Unit test for function match
def test_match():
    output = "aws s3 ls\nUnknown  options: ls\n\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:   aws help\n   aws <command> help\n   aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n\n  synch"
    command = type('obj', (object,), {'output': output})
    assert match(command)


# Generated at 2022-06-12 10:57:01.389329
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, valid choices are:\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n  aws: error: argument subcommand: Invalid choice, maybe you meant:\n    s3api', '', 123))



# Generated at 2022-06-12 10:57:10.730699
# Unit test for function match