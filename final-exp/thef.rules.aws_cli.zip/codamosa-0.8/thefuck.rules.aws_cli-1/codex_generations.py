

# Generated at 2022-06-12 10:47:10.191441
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', ''))
    assert match(Command('aws s3 ls', 'usage:'))
    assert not match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [parameters]'))



# Generated at 2022-06-12 10:47:20.148560
# Unit test for function match
def test_match(): # noqa
    # This function fails on Windows
    if sys.platform == 'win32':
        raise SkipTest()

    # check the output contains a "maybe you meant" message and a list of options
    assert match(Command('aws s3 ls test',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
                         'aws: error: invalid choice: \'test\' (maybe you meant: s3).\n'
                         '\n'
                         '* s3\n'
                         '  sdb\n'))
    # check the output does not contain a "maybe you meant" message, this should return false

# Generated at 2022-06-12 10:47:22.004781
# Unit test for function match
def test_match():
    assert match(Command('aws', 'usage: aws [options] <command> <subcommand> [parameters]', stderr='aws: error: argument command: Invalid choice'))


# Generated at 2022-06-12 10:47:32.668613
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mv foo bar', "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, maybe you meant: ls?", "~", ""))

# Generated at 2022-06-12 10:47:39.354379
# Unit test for function match
def test_match():
    assert match(Command('aws', '', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nUnknown options: --h', '', 1))
    assert not match(Command('ls', '', '', '', 1))


# Generated at 2022-06-12 10:47:47.198247
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash, Shell

# Generated at 2022-06-12 10:47:57.269714
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 cp s3://BUCKET/FILE local', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument operation: Invalid choice, valid choices are:\n  cp\n  mv\n  rm\n  sync\n' , ' ', 0)
    assert get_new_command(command) == ['aws s3 mv s3://BUCKET/FILE local', 'aws s3 rm s3://BUCKET/FILE local', 'aws s3 sync s3://BUCKET/FILE local']

# Generated at 2022-06-12 10:48:07.913915
# Unit test for function get_new_command

# Generated at 2022-06-12 10:48:13.514632
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('echo aws help --commands', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument --commands: Invalid choice, maybe you meant:\n  * --config\n  * --cli-input-json\n  * --cli-input-yaml\n  * --query\n  * --output')) == ['echo aws help --config', 'echo aws help --cli-input-json', 'echo aws help --cli-input-yaml', 'echo aws help --query', 'echo aws help --output']



# Generated at 2022-06-12 10:48:19.996962
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://mybucket', ''))
    assert match(Command('aws ec2 run-instance --image-id ami-12345678 --count 1 --instance-type t1.micro --key-name MyKeyPair --security-groups my-security-group', ''))
    assert not match(Command('aws s3 mb s3://mybucket', 'OK'))

# Generated at 2022-06-12 10:48:31.763381
# Unit test for function match
def test_match():    
    assert match(Command('aws cloudformation2', ''))
    assert match(Command('aws cloudformation2', 'usage:aws cloudformation2'))
    assert match(Command('aws cloudformation2', 'usage:aws cloudformation2\nmaybe you meant:'))
    assert match(Command('aws cloudformation2', 'usage:aws cloudformation2\nmaybe you meant:abc'))
    assert match(Command('aws cloudformation3', '')) is False
    assert match(Command('aws cloudformation3', 'usage:aws cloudformation3')) is False
    assert match(Command('aws cloudformation3', 'usage:aws cloudformation3\nmaybe you meant:')) is False
    assert match(Command('aws cloudformation3', 'usage:aws cloudformation3\nmaybe you meant:abc')) is False


# Generated at 2022-06-12 10:48:33.463566
# Unit test for function match
def test_match():
    assert match(Command("aws", "Invalid choice: 's3', maybe you meant:", ""))


# Generated at 2022-06-12 10:48:37.266282
# Unit test for function get_new_command
def test_get_new_command():
    # Get a command
    command = Command('aws ec2 start-instances --instance-ids i-123456')
    new_command = get_new_command(command)
    assert new_command == ['aws ec2 start-instances --instance-id i-123456']

# Generated at 2022-06-12 10:48:40.085738
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls bucket', 'usage: aws [options] <command> <subcommand>\n\naws: error: argument command: Invalid choice, valid choices are:', 1, ''))


# Generated at 2022-06-12 10:48:42.412011
# Unit test for function match
def test_match():
    import subprocess
    output = subprocess.getoutput('aws s3 help')
    assert match(Command(script = 'aws s3 help', output = output))


# Generated at 2022-06-12 10:48:51.649445
# Unit test for function get_new_command

# Generated at 2022-06-12 10:48:55.845041
# Unit test for function match
def test_match():
    assert match(Command('', script='', stderr='usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\naws: error: argument subcommand: Invalid choice: \'secret\', maybe you meant:',))
    assert not match(Command('', script='', stderr='usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]'))


# Generated at 2022-06-12 10:49:04.304938
# Unit test for function get_new_command

# Generated at 2022-06-12 10:49:14.875663
# Unit test for function match

# Generated at 2022-06-12 10:49:18.960756
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]', 'Invalid choice: \'help\', maybe you meant:', 'Use "aws help" for descriptions of global parameters and cloudwatch commands.\n', ''))


# Generated at 2022-06-12 10:49:30.251987
# Unit test for function get_new_command
def test_get_new_command():
    example = "Error: usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\taws help\n\taws <command> help\n\taws <command> <subcommand> help\naws: error: argument command: Invalid choice: 'help', maybe you meant:\ndatapipeline\necr\nlambda\n\n\n\n* datapipeline\n* ecr\n* lambda\n"
    command = "aws help"
    assert get_new_command(Command(script=command, output=example)) == ["aws datapipeline", "aws ecr", "aws lambda"]


# Generated at 2022-06-12 10:49:41.459100
# Unit test for function match
def test_match():
	print("Testing match function")
	output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument operation: Invalid choice, maybe you meant:
    connect-gateway        connect-s3"""
	output2 = ""

# Generated at 2022-06-12 10:49:46.254104
# Unit test for function match
def test_match():
    assert match(Command(script='aws invalid_command',
        stderr="usage: aws [options] <command> <subcommand> [<subcommand> ...] ...",
        output="Invalid choice: 'invalid_command', maybe you meant:\n\n*", errno=64))
    assert not match(Command(script='aws', output='', errno=64))



# Generated at 2022-06-12 10:49:54.755843
# Unit test for function get_new_command
def test_get_new_command():
    output = ("usage: aws [options] <command> <subcommand> "
              "[<subcommand> ...] [parameters]\n"
              "To see help text, you can run:\n"
              "aws help\n"
              "aws <command> help\n"
              "aws <command> <subcommand> help\n"
              "aws: error: argument subcommand: Invalid choice: 'invalid'\n"
              "maybe you meant:\n"
              "    info\n"
              "    instance\n"
              "    init")
    command = Command("aws invalid", output)
    assert get_new_command(command) == ['aws info', 'aws instance', 'aws init']

# Generated at 2022-06-12 10:50:00.679971
# Unit test for function match
def test_match():
    assert match(Command('aws --version', '', ''))
    assert match(Command('aws s3 help', '', ''))
    assert not match(Command('aws s3', '', ''))
    assert not match(Command('aws s3', '', ''))
    assert not match(Command('ls', '', ''))
    assert not match(Command('ls -a', '', ''))


# Generated at 2022-06-12 10:50:08.656586
# Unit test for function match
def test_match():
    assert match(Command(command='aws help',
                         output="aws: error: argument command: Invalid choice: 'helppp', maybe you meant: \n\t* help\n\t* help-config-add\n\t* help-config-list\n\t* help-config-remove\nSee 'aws help' for descriptions of global parameters."))
    assert not match(Command(command='aws help',
                         output="aws: error: argument command: Invalid choice: 'helppp', maybe you meant: \n\t* help\n\tSee 'aws help' for descriptions of global parameters."))


# Generated at 2022-06-12 10:50:12.534506
# Unit test for function match
def test_match():
    wrong_command = Command('aws foo', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:')
    assert match(wrong_command)



# Generated at 2022-06-12 10:50:23.469049
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws s3 mb s3://'

# Generated at 2022-06-12 10:50:27.552424
# Unit test for function match
def test_match():
    assert match(Command('aws cloudformation update-stack --stack-name',
                         'An error occurred (ValidationError) when calling the UpdateStack operation: Invalid choice: \'--stack-name\', maybe you meant:',
                         ''))

# Generated at 2022-06-12 10:50:30.439153
# Unit test for function match
def test_match():
    output = 'aws: error: argument subcommand: Invalid choice, maybe you meant:\n* ec2\n* ecr\n* elasticache\n* ecs\n* s3'
    assert match(Command('aws', output=output))


# Generated at 2022-06-12 10:50:44.987357
# Unit test for function get_new_command

# Generated at 2022-06-12 10:50:53.424731
# Unit test for function match

# Generated at 2022-06-12 10:51:03.542775
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws s3 ls", " usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n"
                                   "   error: Invalid choice: 's3', maybe you meant:\n"
                                   "          * s3api\n"
                                   "          * s3-autoscaling\n"
                                   "          * s3-encryption\n"
                                   "          * s3-intelligent-tiering\n"
                                   "          * s3outposts\n"
                                   "          * s3-useast1\n"
                                   "          * s3-useast2\n"
                                   "          * s3-uswest1\n"
                                   "          * s3-uswest2\n")

# Generated at 2022-06-12 10:51:06.808818
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://test-bucket-name'))
    assert not match(Command('bs s3 mb s3://test-bucket-name'))


# Generated at 2022-06-12 10:51:17.142179
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws sqls')
    command.output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument command: Invalid choice, valid choices are:
KMS|S3|SNS|SQS|STS|codecommit|config|elasticache|elasticbeanstalk|elastictranscoder|iam|importexport|s3api|sqs|sts
maybe you meant:
  * sqs"""
    assert get_new_command(command) == ['aws sqs']

# Generated at 2022-06-12 10:51:27.004408
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws ec2 describe-volumes wrong-choice --region us-east-1"

# Generated at 2022-06-12 10:51:36.237640
# Unit test for function get_new_command
def test_get_new_command():
    output = """usage: aws [options] <command> <subcommand> [parameters]
aws: error: unrecognized arguments: --help
usage: aws [options] <command> <subcommand> [parameters]
aws: error: argument --region: expected one argument
usage: aws [options] <command> <subcommand> [parameters]
aws: error: argument --scheme: expected one argument
aws: error: argument --output: Invalid choice: 'table', maybe you meant:

  * text
  * json
"""
    script = """aws elb describe-load-balancers --region us-east-1 --scheme internet-facing --output table"""
    command = Command(script, output)

# Generated at 2022-06-12 10:51:43.404597
# Unit test for function match
def test_match():
    assert match(Command('', '', 'usage: blah blah blah Invalid choice: \'sample\', maybe you meant: * sample2'))
    assert match(Command('', '', 'usage: blah blah blah Invalid choice: \'sample\', maybe you meant: * sample1 * sample2'))
    assert not match(Command('', '', 'Something bad happened'))
    assert not match(Command('', '', 'usage: blah blah blah Invalid choice: \'sample\', maybe you meant: sample1 sample2'))


# Generated at 2022-06-12 10:51:53.769072
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws s3 mb thefuck-test-bucket-1234'

# Generated at 2022-06-12 10:52:03.508765
# Unit test for function match

# Generated at 2022-06-12 10:52:20.085000
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-something --region us-east-3', 'Invalid choice: \'ec2\' (choose from [subscriptions/help/snapshot/fact/]...'))


# Generated at 2022-06-12 10:52:26.646395
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    command = Command('aws sts get-caller-identity',
                      'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\naws: error: argument iam: Invalid choice, maybe you meant:', 0, None)
    assert get_new_command(command) == ['aws sts get-caller-identity']


enabled_by_default = True

# Generated at 2022-06-12 10:52:31.735027
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash
    command = Command('aws ec2 describe-instances',
            'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:',
            'aws help',
            'aws help ec2')

    assert get_new_command(command) == [
            'aws ec2 describe-instances'
            ]

# Generated at 2022-06-12 10:52:42.032309
# Unit test for function get_new_command

# Generated at 2022-06-12 10:52:48.575697
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 cp source.html s3://your.bucket/favicon.ico')
    command.output = """Invalid choice: 'cp', maybe you meant:
 * mb
 * rb
 * s3api
 * sync
 * \nusage:"""
    new_command = get_new_command(command)

# Generated at 2022-06-12 10:52:57.494016
# Unit test for function get_new_command
def test_get_new_command():
  thefuck_script = 'aws ec2 describe-instance'
  command = Command(script = thefuck_script, output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n* describe-instances\n* describe-instance-status\n")
  get_new_command(command)
  assert get_new_command(command) == [('aws ec2 describe-instances', ''), ('aws ec2 describe-instance-status', '')]

# Generated at 2022-06-12 10:53:10.712389
# Unit test for function match

# Generated at 2022-06-12 10:53:14.745612
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'aws: error: argument command: Invalid choice: \'help\', maybe you meant:\n\t* help\n\t* help-config\n\t* help-topics\n\t* help-syntax', '', 1))


# Generated at 2022-06-12 10:53:26.503018
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('aws kinesis help', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument command: Invalid choice: \'kinesis help\', maybe you meant:\n    help\n    describe-stream\n    list-streams\n    get-records\n    put-record\n    put-records\n')
    assert get_new_command(command1) == ['aws help', 'aws describe-stream', 'aws list-streams', 'aws get-records', 'aws put-record', 'aws put-records']

# Generated at 2022-06-12 10:53:38.204815
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws ec2 describe-regions --region us-east-2"

# Generated at 2022-06-12 10:54:07.773334
# Unit test for function match
def test_match():
    assert match(command=Command(script='aws ec2 describe-instances',
                                 stdout='usage: aws [options] [parameters]',
                                 stderr='Invalid choice: \'ec2\', maybe you meant:\n  * elb\n  * elasticache',
                                 ))



# Generated at 2022-06-12 10:54:14.324047
# Unit test for function match

# Generated at 2022-06-12 10:54:17.387005
# Unit test for function match
def test_match():
    assert not match(Command('aws s3 ls'))
    assert  match(Command('aws s3 lst', 'Invalid choice: \'lst\', maybe you meant: lst\n* ls'))


# Generated at 2022-06-12 10:54:24.880139
# Unit test for function get_new_command
def test_get_new_command():
    command1 = "aws s3 ls s3://mybucket"

# Generated at 2022-06-12 10:54:33.713213
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws s3 ls /my_bucket --region us-east-1"
    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, maybe you meant:
    mb
    rb"""
    match(command)
    new_cmd = get_new_command(command)
    assert new_cmd == ['aws s3 mb /my_bucket --region us-east-1',
                       'aws s3 rb /my_bucket --region us-east-1']

# Generated at 2022-06-12 10:54:38.868416
# Unit test for function match
def test_match():
    assert match(Command('aws', '\naws help -- ', 'usage: aws [options] <command> <subcommand> [parameters]\nMaybe you meant: dummy'))
    assert not match(Command('aws', '\naws help -- ', 'usage: aws [options] <command> <subcommand> [parameters]\nMaybe you meant: dummy', '', 1))


# Generated at 2022-06-12 10:54:47.492525
# Unit test for function get_new_command
def test_get_new_command():
    script = ["aws", "ec2", "run-instances", "--region", "us-east-1", "foo"]
    command = Command(script, "usage: aws [options] <command> <subcommand> [parameters]\n          ^Invalid choice: 'foo', maybe you meant:* foo-bar\n                        more-foo", "")
    assert get_new_command(command) == [["aws", "ec2", "run-instances", "--region", "us-east-1", "foo-bar"], ["aws", "ec2", "run-instances", "--region", "us-east-1", "more-foo"]]

# Generated at 2022-06-12 10:54:52.115693
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws autoscaling describe-notification-configurations"
    output = """Invalid choice: 'describe-notification-configurations', maybe you meant:
  * describe-notification-configurations-types"""
    command = Command(script, output)
    assert get_new_command(command) == [
        'aws autoscaling describe-notification-configurations-types']

# Generated at 2022-06-12 10:54:54.271527
# Unit test for function match
def test_match():
    assert match(Command("aws --help", "usage:"))
    assert not match(Command("aws --help", "No usage:"))


# Generated at 2022-06-12 10:55:02.833430
# Unit test for function match

# Generated at 2022-06-12 10:56:04.147493
# Unit test for function get_new_command
def test_get_new_command():
    expected = ['aws ec2 help']
    assert get_new_command(Command('aws ec2 -h',
                                   '/usr/local/awshelp',
                                   'aws: error: argument command: Invalid choice: \'-h\', maybe you meant:\n  help\n')) == expected



# Generated at 2022-06-12 10:56:09.345311
# Unit test for function get_new_command
def test_get_new_command():
    # command = aws eks --hel
    # Output of command:
    # Invalid choice: '--hel', maybe you meant:
    #   * --help
    command = Command('aws eks --hel', 'usage: aws [options] <command> <subcommand> [parameters]\n...\n\t* --help')
    fn = get_new_command(command)
    assert fn == [u'aws eks --help']



# Generated at 2022-06-12 10:56:17.936920
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    # Example output from aws-cli:
    # aws --help
    # Unknown options: --help
    # usage: aws [options] <command> <subcommand> [parameters]
    # To see help text, you can run:
    # aws help
    # aws <command> help
    # aws <command> <subcommand> help
    # aws: error: too few arguments
    # Unknown options: --help
    # usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
    # To see help text, you can run:
    # aws help
    # aws <command> help
    # aws <command> <subcommand> help
    # aws: error: too few arguments
    # Invalid choice:

# Generated at 2022-06-12 10:56:28.368367
# Unit test for function match
def test_match():
    assert match(Command("aws ec2 describe-key-pairs", "usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument command: Invalid choice: 'describe-key-pairs', maybe you meant:\n        describe-key-pair\n"))
    assert not match(Command("aws ecs describe-key-pairs", "usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument command: Invalid choice: 'describe-key-pairs', maybe you meant:\n        describe-key-pair\n"))

# Generated at 2022-06-12 10:56:29.699917
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls --abc', ''))
    assert not match(Command('ls -a', ''))

# Generated at 2022-06-12 10:56:39.419060
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws s3 ls bucket/ --recursive --human-readable --summarize"
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument operation: Invalid choice, valid choices are:\n  cp \n  ls \n  mb \n  mv \n  rb \n  rm \n  sync\nmaybe you meant:\n  mb\n  ls\n  cp"
    command = Command(script, output)

# Generated at 2022-06-12 10:56:44.949475
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws ec2 create-vpc", "aws: error: argument --cidr: Invalid CIDR '10.11.12.13/24': address 10.11.12.13 is not a valid Classless Inter-Domain Routing (CIDR) block.", "aws: error: argument --cidr: Invalid CIDR '10.11.12.13/24': address 10.11.12.13 is not a valid Classless Inter-Domain Routing (CIDR) block.")

    assert get_new_command(command) == ['aws ec2 create-vpc --cidr 10.11.12.13/24']

# Generated at 2022-06-12 10:56:50.953765
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 deecribe-instnace',
                                   'usage: aws [options] <command> <subcommand> [<subcommand> ...] [params]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\naws: error: argument command: Invalid choice, maybe you meant:\n    describe-instances\n    describe-instance-status')[0]) == 'aws ec2 describe-instances'

# Generated at 2022-06-12 10:56:53.828979
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 help', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument operation: Invalid choice, valid choices are:\n* describe-account-attributes\n* describe-addresses\n...'))
    assert match(Command('aws ec2 help', '')) == False


# Generated at 2022-06-12 10:57:02.392485
# Unit test for function match
def test_match():
    output = "usage: aws [options] <command> <subcommand> [parameters]\nTo see " \
             "help text, you can run:\n\n  aws help\n  aws <command> help\n  " \
             "aws <command> <subcommand> help\n Invalid choice: 'f', maybe you" \
             " meant:\n  federated-users\n  functions\n  function-configuration" \
             "\n  functions\n  function-configuration"
    assert get_new_command(Command('aws f', output)) == ['aws federated-users','aws functions','aws function-configuration','aws functions','aws function-configuration']