

# Generated at 2022-06-26 05:14:45.730686
# Unit test for function match

# Generated at 2022-06-26 05:14:46.650618
# Unit test for function match
def test_match():
	assert match(command) == True


# Generated at 2022-06-26 05:14:53.082784
# Unit test for function get_new_command
def test_get_new_command():
    var_0 = "aws lambda --foo"
    var_0 = Command(var_0, output="usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument command: Invalid choice: '--foo', maybe you meant:")
    var_1 = get_new_command(var_0)
    var_2 = "aws lambda --help"
    var_3 = "aws lambda get-foo"
    var_4 = "aws lambda create-foo"
    var_5 = True
    if (var_1[0] == var_2 and var_1[1] == var_3 and var_1[2] == var_4):
        var_5 = False
    assert var_5 == False

# Generated at 2022-06-26 05:14:54.982554
# Unit test for function match
def test_match():
    test_case_0()
    

# Generated at 2022-06-26 05:14:58.032670
# Unit test for function get_new_command

# Generated at 2022-06-26 05:15:07.574298
# Unit test for function match
def test_match():
    output = "aws --help\n\nUnknown options:\n  --help\n  --\n  \n\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n  To see help text, you can run:\n  \n    aws help\n    aws <command> help\n    aws <command> <subcommand> help\n  \n  Unknown options:\n    --help\n    --\n    \n  Invalid choice: '--help', maybe you meant:\n    --query\n    --metadata\n    --debug\n\naws: error: too few arguments\n"
    bool_0 = match(output)
    assert bool_0 == True


# Generated at 2022-06-26 05:15:16.277530
# Unit test for function match

# Generated at 2022-06-26 05:15:17.413153
# Unit test for function match
def test_match():
    assert match(False)
    assert match(True)
    assert match(' ')
    assert match('')


# Generated at 2022-06-26 05:15:27.445265
# Unit test for function get_new_command

# Generated at 2022-06-26 05:15:29.631703
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(['aws', 's3', 'ls']) == [
        'aws s3 list']


# Generated at 2022-06-26 05:15:37.686537
# Unit test for function get_new_command

# Generated at 2022-06-26 05:15:40.461486
# Unit test for function match
def test_match():
    var_0 = Command("aws help --fake_command", "some invalid command")
    var_1 = True
    var_2 = match(var_0)
    assert var_1 == var_2


# Generated at 2022-06-26 05:15:51.924264
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = "aws ec2 run-instances --invalid-args t2.micro --image-id ami-CBCABCDE"
    str_1 = "aws ec2 attach-volume --volume-id vol-049df61146c4d7901 --invalid-args"
    str_2 = "aws ec2 attach-volume --invalid-args vol-049df61146c4d7901 --device /dev/sdh"

# Generated at 2022-06-26 05:16:02.122905
# Unit test for function match

# Generated at 2022-06-26 05:16:13.818790
# Unit test for function match

# Generated at 2022-06-26 05:16:18.251706
# Unit test for function match
def test_match():
    # Test case 0
    # File: aws/usage/__init__.py
    # Function: match
    # Expected output: "usage:" in command.output and "maybe you meant" in command.output
    # Returned output: True, False
    assert (match(bool_0) == True)

# Generated at 2022-06-26 05:16:20.335461
# Unit test for function get_new_command
def test_get_new_command():
    bool_0 = False
    var_0 = get_new_command(bool_0)
    assert var_0 == bool_0

# Generated at 2022-06-26 05:16:22.160916
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(bool_0) == bool_0

test_case_0()

# Generated at 2022-06-26 05:16:28.076138
# Unit test for function get_new_command
def test_get_new_command():
    var_1 = 'aws'
    var_2 = 'cli53'
    var_3 = 'aws s3'
    var_4 = match(Exception(var_1))
    var_5 = match(Exception(var_2))
    var_6 = match(Exception(var_3))
    var_7 = get_new_command(var_4)
    print(var_7)
    var_8 = get_new_command(var_5)
    print(var_8)
    var_9 = get_new_command(var_6)
    print(var_9)

# Generated at 2022-06-26 05:16:32.990097
# Unit test for function match
def test_match():
    var_0 = False

# Generated at 2022-06-26 05:16:35.928771
# Unit test for function match
def test_match():
    assert match('aws usage:                                                                  ') == True


# Generated at 2022-06-26 05:16:38.343914
# Unit test for function match
def test_match():
    test_case_0()


# Generated at 2022-06-26 05:16:42.422935
# Unit test for function get_new_command
def test_get_new_command():
    os.environ["LANG"] = "en_US.UTF-8"
    command = {
        'script': './aws help'
    }
    os.environ["LANG"] = "en_US.UTF-8"
    os.environ["LANGUAGE"] = "en_US.UTF-8"
    assert get_new_command(command) == ['aws --help']

# Generated at 2022-06-26 05:16:49.194186
# Unit test for function get_new_command
def test_get_new_command():
    try:
        assert re.match("usage:.*aws.*[-h]", match)
    except AssertionError:
        test_case_0()
    else:
        pass
    finally:
        pass


# Generated at 2022-06-26 05:17:00.025156
# Unit test for function get_new_command
def test_get_new_command():
    str_0 = "aws s3 cp s3://bucket/test.txt /home/test.txt"
    str_1 = "usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument command: Invalid choice, valid choices are:\ncp\nsync\n\ncp: error: argument subcommand: Invalid choice, valid choices are:\ncp\ncopy\n\nUnknown options: -1, home/test.txt"
    obj_0 = Command(str_0, str_1)
    str_2 = "aws s3 [cp] s3://bucket/test.txt /home/test.txt"
    str_3 = "aws s3 [copy] s3://bucket/test.txt /home/test.txt"

# Generated at 2022-06-26 05:17:07.111347
# Unit test for function match
def test_match():
    commands = ['aws', 'aws ec2', 'aws s3', 'aws s3mv', 'aws s3mv testsrc.txt tests3://testbucket']
    for command in commands:
        assert_equals(match(command), bool_0)


# Generated at 2022-06-26 05:17:10.771698
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws ec2 describe-instances --filter Name=instance-type,Values=t2.micro --filter Name=instance-state-name,Values=stopped --query "Reservations[].Instances[].InstanceId"'
    assert get_new_command(command)


# Generated at 2022-06-26 05:17:24.171700
# Unit test for function get_new_command
def test_get_new_command():
    command_0 = type('', (), {})()
    command_0.script = './server.sh'

# Generated at 2022-06-26 05:17:34.992791
# Unit test for function match
def test_match():
    print("Test start.")
    command = "aws ec2 describe-instances"
    out = "Invalid choice: 'ec2', maybe you meant: \n  events\n  ecr"
    status = "usage:"
    new_cmd = [replace_argument(command, "ec2", "events"), replace_argument(command, "ec2", "ecr")]
    assert match(Command(command, out, status)) == True
    assert get_new_command(Command(command, out, status)) == new_cmd
    print("Command: ", command, "\n", "Output: ", out, "\nExpected: ", new_cmd)
    print("Test end.")

if __name__ == '__main__':
    test_case_0()
    test_match()

# Generated at 2022-06-26 05:17:40.248042
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 --help', '')
    assert get_new_command(command) == ['aws s3 cp --help']
    command = Command('aws s3', '')
    assert get_new_command(command) == ['aws s3 cp']
    command = Command('aws s3 ', '')
    assert get_new_command(command) == ['aws s3 cp']

# Generated at 2022-06-26 05:17:52.386990
# Unit test for function match
def test_match():
    # Test Case 0
    bool_0 = False

# Generated at 2022-06-26 05:18:01.723483
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(command) == [replace_argument(command.script, mistake, o) for o in options]
    assert get_new_command(command) == [replace_argument(command.script, mistake, o) for o in options]
    assert get_new_command(command) == [replace_argument(command.script, mistake, o) for o in options]
    assert get_new_command(command) == [replace_argument(command.script, mistake, o) for o in options]
    assert get_new_command(command) == [replace_argument(command.script, mistake, o) for o in options]
    assert get_new_command(command) == [replace_argument(command.script, mistake, o) for o in options]

# Generated at 2022-06-26 05:18:10.309484
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.aws import get_new_command
    a = type('', (), {'script': 'aws ec2 status --volume-ids vol-12345678',
            'output': "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nerror: Invalid choice: 'vol-12345678', maybe you meant:\n  * volume-ids\n"})
    a.__class__ = type
    error, match, new_command = get_new_command(a)


# Generated at 2022-06-26 05:18:13.965590
# Unit test for function get_new_command
def test_get_new_command():
    # Assert if the function get_new_command returns the correct output
    assert get_new_command("aws help") == ['aws help'], "test case 0 failed"

# Generated at 2022-06-26 05:18:21.479573
# Unit test for function get_new_command

# Generated at 2022-06-26 05:18:29.949749
# Unit test for function match
def test_match():
    with Mock() as mock_error:
        mock_error.output = 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nUnknown options: --blah\nInvalid choice: \'--blah\', maybe you meant:\n    --blob      \n'
    assert match(mock_error) == True


# Generated at 2022-06-26 05:18:38.174542
# Unit test for function get_new_command
def test_get_new_command():
    #  1.4 is not a mistake for the function
    command = MagicMock(script='aws 1.4', output="Invalid choice: '1.4', maybe you meant:\n * 1.4 [None]\n * 1.4.0 [None]\n * 1.4.1 [None]\n * 1.4.2 [None]\n * 1.4.3 [None]\n * 1.4.4 [None]\n * 1.4.5 [None]\n * 1.4.6 [None]\n * 1.4.7 [None]\n")
    assert get_new_command(command) == []

    #  Now let's try a real TODO: fix this test
    #  command = MagicMock(script='aws ec2 describe 1.4', output="Invalid choice: '1.4

# Generated at 2022-06-26 05:18:41.572101
# Unit test for function get_new_command
def test_get_new_command():
    command = [u'aws', u'ec2', u'descrive-instances']
    assert get_new_command(command) == []


# Generated at 2022-06-26 05:18:51.367362
# Unit test for function get_new_command
def test_get_new_command():
    commands = ["aws ec2 describe-launch-templates --launch-template-name foo", "aws ec2 describe-launch-templates --launch-template-name foo bar", "aws ec2 describe-launch-templates --launch-template-displays foo bar"]

# Generated at 2022-06-26 05:18:54.059578
# Unit test for function match
def test_match():
    assert True


# Generated at 2022-06-26 05:18:59.726681
# Unit test for function match
def test_match():
    assert match('aws s3 cp local/directory/ s3://bucket/directory/') == None


# Generated at 2022-06-26 05:19:03.566723
# Unit test for function match

# Generated at 2022-06-26 05:19:13.865566
# Unit test for function match
def test_match():
    command = Command('aws s3 ls s3://something', 'usage: aws [options]   <command> <subcommand> [<subcommand> ...]\n'
                                                  'aws: error: argument <command>: Invalid choice: \'s3 ls s3://something\', maybe you meant:\n'
                                                  '           * list-buckets',
                      'aws s3 ls s3://something')
    assert match(command)

    command = Command('aws s3 ls s3://something', '',
                      'aws s3 ls s3://something')
    assert not match(command)

    command = Command('foo', '', 'foo')
    assert not match(command)



# Generated at 2022-06-26 05:19:15.838135
# Unit test for function match
def test_match():
    assert match(set_0) == False

# Generated at 2022-06-26 05:19:27.005757
# Unit test for function match
def test_match():
    # I want this to fail
    assert not match(Command(''))

# Generated at 2022-06-26 05:19:36.217820
# Unit test for function match
def test_match():
    assert match('', '') == False
    assert match('', 'String in the output', '') == False
    assert match('', 'String in the output', 'usage:', '') == True
    assert match('', 'String in the output', 'maybe you meant:', '') == True
    assert match('', 'String in the output', 'String in the output', 'usage:', '') == False
    assert match('', 'String in the output', 'String in the output', 'maybe you meant:', '') == False


# Generated at 2022-06-26 05:19:45.538000
# Unit test for function get_new_command
def test_get_new_command():
    test_outputs = ["Invalid choice: 'subnet', maybe you meant:\n    subnets",
                    "Invalid choice: 'subnet', maybe you meant:\n    subnets\n    ssm"]
    test_inputs = ["aws ec2 help subnet", "aws ec2 help subnet"]
    for i, output in zip(test_inputs, test_outputs):
        command_0 = Command(script=i, output=output)
        print(get_new_command(command_0))
        assert get_new_command(command_0) == [i.replace("subnet", "subnets"), i.replace("subnet", "ssm")]

# Generated at 2022-06-26 05:19:53.176574
# Unit test for function get_new_command
def test_get_new_command():
        set_0 = Command(script = "usage: aws [options] [ ...] [--parameter-overrides]\n\naws: error: argument [options] [ ...]: Invalid choice",
                stdout = "aws: error: argument [options] [ ...]: Invalid choice, maybe you meant:\n\n  * --list\n  * --list-customizations\n  * --list-metrics\n  * --list-streams\n  * --list-targets\n  * --list-topics\n  * --list-types\n  * --list-unmatched-arguments\n  * --list-versions\n ",
                stderr = ""
        )
        var_0 = set_0.script

# Generated at 2022-06-26 05:19:58.413170
# Unit test for function get_new_command
def test_get_new_command():
    c = Command('aws foo --bar arg')
    c.output = 'Invalid choice: \'foo\', maybe you meant:\n\n  * bar\n  * baz\n'
    assert get_new_command(c) == ['aws bar --bar arg', 'aws baz --bar arg']

# Generated at 2022-06-26 05:20:00.592742
# Unit test for function get_new_command
def test_get_new_command():
    set_0 = set()
    var_0 = get_new_command(set_0)


# Generated at 2022-06-26 05:20:12.088542
# Unit test for function get_new_command
def test_get_new_command():
    class Command:
        def __init__(self):
            self.script = ""
            self.stdout = ""
            self.stderr = ""
            self.output = '''usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, maybe you meant:
* ec2
* ec2-instance-connect'''
            self.no_colors = False
            self.debug = False
    assert get_new_command(Command()) == ['aws ec2 ', 'aws ec2-instance-connect ']

# Generated at 2022-06-26 05:20:15.743321
# Unit test for function match
def test_match():
    test_str = 'usage: aws [options] [ ...] [parameters]\nTo see help text, you can run:\n\n  aws help'
    assert match(test_str) == True


# Generated at 2022-06-26 05:20:24.316309
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 lizt --recursive s3://my-bucket/')
    new_command = get_new_command(command)
    assert new_command == ["aws s3 ls --recursive s3://my-bucket/"]

# Generated at 2022-06-26 05:20:31.192932
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws s3 rb s3://elasticbeanstalk-ap-southeast-2-161951768157/") == ["aws s3 rb s3://elasticbeanstalk-ap-southeast-2-161951768157/"]

# Generated at 2022-06-26 05:20:33.636342
# Unit test for function match
def test_match():
    # Call the function using the mock and input strings
    # These inputs are defined in mocks/
    # assert match("aws <command>")
    assert match("aws service") is True


# Generated at 2022-06-26 05:20:40.261700
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws --help', 'aws: error: argument --help: invalid choice: \'--help\', maybe you meant:\n  --help-all\n  --help-json\n  --help-yaml\n  --version\n\naws: error: the following arguments are required: command\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n       To see help text, you can run:\n       aws help\n       aws <command> help\n       aws <command> <subcommand> help\naws: error: too few arguments\n')
    assert get_new_command(command) == ['aws --help-all', 'aws --help-json', 'aws --help-yaml', 'aws --version']

# Generated at 2022-06-26 05:20:41.940357
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("you are a very big idiot") == "you are a very big idiot"

# Generated at 2022-06-26 05:20:53.888224
# Unit test for function match

# Generated at 2022-06-26 05:20:56.192454
# Unit test for function get_new_command
def test_get_new_command():
    set_0 = set()
    var_0 = get_new_command(set_0)
    assert var_0 == None

# Generated at 2022-06-26 05:20:57.032826
# Unit test for function match
def test_match():
    assert match(set_0) == True

# Generated at 2022-06-26 05:21:19.447082
# Unit test for function match
def test_match():
    assert match(command="aws s3 ls", output="usage: aws [options] <command> <subcommand> [<subcommand>...] [parameters]") == False
    assert match(command="aws s3 ls", output="aws: error: argument subcommand: Invalid choice, valid choices are:") == False

# Generated at 2022-06-26 05:21:22.439858
# Unit test for function get_new_command
def test_get_new_command():
    # Test case 0:
    set_0 = set()
    var_0 = get_new_command(set_0)
    assert var_0 is False

# Unit tests for function match

# Generated at 2022-06-26 05:21:24.661359
# Unit test for function match
def test_match():
    assert match(Command('aws', 'usage:'))
    assert not match(Command('git', 'usage:'))


# Generated at 2022-06-26 05:21:25.935867
# Unit test for function match
def test_match():
    assert match(set_0) == bool_0


# Generated at 2022-06-26 05:21:27.754453
# Unit test for function match
def test_match():
    assert match(set_0) == True


# Generated at 2022-06-26 05:21:33.304535
# Unit test for function match
def test_match():
    script = Command('aws ec2 describe-instances --filters Name=instance-type,Values=t1.micro --query "Reservations[*].Instances[*].[InstanceId,PublicDnsName,Placement.AvailabilityZone]"')
    assert(match(script) == True)

# Generated at 2022-06-26 05:21:42.898629
# Unit test for function match
def test_match():
    set_0 = Command('aws s3 ls')
    set_0.stdout = 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nerror: Invalid choice, maybe you meant:\n  s3 ls\n  s3 ls '
    set_0.stderr = ''
    set_0.script = 'aws s3 ls'
    var_0 = match(set_0)
    assert var_0 == True


# Generated at 2022-06-26 05:21:47.277885
# Unit test for function match
def test_match():
  cmd = Command('aws configure')
  assert match(cmd) is False
  cmd = Command('aws --help')
  assert match(cmd) is False
  cmd = Command('aws ec2 describe-images --owner self')
  assert match(cmd) is False
  cmd = Command('aws ec2 describe-instances')
  assert match(cmd)is False

# Generated at 2022-06-26 05:21:56.438612
# Unit test for function get_new_command
def test_get_new_command():
    def test_case_0():
        set_0 = set()
        var_0 = get_new_command(set_0)
        set_1 = set()
        var_1 = get_new_command(set_1)
        set_2 = set()
        var_2 = get_new_command(set_2)
        set_3 = set()
        var_3 = get_new_command(set_3)
        set_4 = set()
        var_4 = get_new_command(set_4)

        assert (var_0 == var_1 == var_2 == var_3 == var_4)

    def test_case_1():
        set_0 = set()
        var_0 = get_new_command(set_0)
        set_1 = set()

# Generated at 2022-06-26 05:22:05.470872
# Unit test for function match

# Generated at 2022-06-26 05:22:33.109952
# Unit test for function get_new_command
def test_get_new_command():
    expected_results = ['']
    actual_results = get_new_command('')
    assert expected_results == actual_results

# Generated at 2022-06-26 05:22:40.650964
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command() == 'Usage: aws [options] [ ... ]'
    assert get_new_command() == 'Options:'
    assert get_new_command() == '  -a, --all                Include very long descriptions'
    assert get_new_command() == '  -c, --colors[=WHEN]      Control when to use colors; WHEN can be'
    assert get_new_command() == '  -d, --debug              Print debugging information'
    assert get_new_command() == '  -f, --fields=FIELD,...   Selector for fields, (--field name=value'
    assert get_new_command() == '  -l, --list-type=TYPE     Controls what to display: resources, table,'

# Generated at 2022-06-26 05:22:42.138259
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls'))
    assert not match(Command('ls'))


# Generated at 2022-06-26 05:22:54.500880
# Unit test for function match
def test_match():
    wildcard_0 = 'usage:'
    wildcard_2 = "cloudformation"
    wildcard_1 = 'maybe you meant:'
    wildcard_3 = 's3'
    wildcard_4 = "Invalid choice: 'cloudformation'"

    assert match(type('Command', (object,),
                        {'script': "{} {}".format(wildcard_0, wildcard_2),
                         'output': "{} {}".format(wildcard_1, wildcard_2)
                         }))
    assert not match(type('Command', (object,),
                           {'script': "{} {}".format(wildcard_3, wildcard_0),
                            'output': "{} {}".format(wildcard_1, wildcard_0)
                            }))



# Generated at 2022-06-26 05:22:57.385229
# Unit test for function match
def test_match():
    # with code coverage analysis
    assert match(Command('aws help info s3api put-object --sse-kms-key-id "$AWS_SSE_KMS_ID"', ''))
    assert not match(Command('', ''))


# Generated at 2022-06-26 05:23:02.922079
# Unit test for function get_new_command
def test_get_new_command():
    set_0 = set()
    var_0 = set()
    for var_1 in var_0:
        set_0.add(var_1)
    var_0 = str(var_1)
    var_0 = get_new_command(set_0)
    assert var_0 is not None

# Generated at 2022-06-26 05:23:04.662593
# Unit test for function match
def test_match():
    assert match(set()) == True
    assert match(set()) == True
    assert match(set()) == True
    assert match(set()) == True

# Generated at 2022-06-26 05:23:11.718213
# Unit test for function match
def test_match():
    print("Testing match...", end="")

    # Check if function flags the wrong command
    set_0 = set()
    assert (match(set_0) == False), "match function failed with set 0"

    # Check if function flags the wrong command
    set_1 = set()
    assert (match(set_1) == False), "match function failed with set 1"

    print("PASSED")


# Generated at 2022-06-26 05:23:12.226108
# Unit test for function get_new_command
def test_get_new_command():
    assert True == True

# Generated at 2022-06-26 05:23:21.072483
# Unit test for function get_new_command
def test_get_new_command():
    set_0 = set()
    set_0.output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters] To see help text, you can run:  aws help aws <command> <subcommand> help aws <command> <subcommand> <subcommand> help aws: error: argument subcommand: Invalid choice: 'rls', maybe you meant: run-instances reset-snapshot-attribute revoke-client-vpn-ingress route-table  run-instances reset-snapshot-attribute revoke-client-vpn-ingress route-tables"
    var_0 = get_new_command(set_0)
    assert var_0 == ['aws run-instances', 'aws revoke-client-vpn-ingress', 'aws route-table']

# Generated at 2022-06-26 05:24:25.681634
# Unit test for function get_new_command
def test_get_new_command():

    params = [
        (Command(script='aws', output='usage: aws [options] <command> <subcommand> [parameters]\nInvalid choice: \'adfasdf\'',),
         [])
    ]
    answers = [
        []
    ]

    for i in range(len(answers)):
        assert get_new_command(params[i]) == answers[i]

# Generated at 2022-06-26 05:24:32.724121
# Unit test for function match
def test_match():
    # assert match(Command("aws configure --profile old"))
    # assert match(Command("aws configure --profile old", "Invalid choice: '--profile', maybe you meant:  --profile-name"))
    # assert match(Command("aws configure --profile old", "Invalid choice: '--profile', maybe you meant:\n  --profile-name\n"))
    assert match(Command("aws configure --profile old", "Invalid choice: '--profile', maybe you meant:  --profile-name", False))
