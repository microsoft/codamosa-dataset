

# Generated at 2022-06-24 05:42:50.874493
# Unit test for function get_new_command
def test_get_new_command():
    from mock import Mock
    from thefuck.types import Command
    
    command = Mock(spec=Command)
    command.script = 'aws iam create-account-alias --account-alias <alias name>'
    command.output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument --account-alias: Invalid choice: '<alias name>', maybe you meant:
* AccountAlias"""
    assert get_new_command(command) == ['aws iam create-account-alias --account-alias AccountAlias']

# Generated at 2022-06-24 05:42:54.953417
# Unit test for function match
def test_match():
    assert match(make_error("Invalid choice: 's3'", {'s3': 's3api'}))
    assert not match(make_error('', {'s3': 's3api'}))


# Generated at 2022-06-24 05:43:05.260983
# Unit test for function match

# Generated at 2022-06-24 05:43:10.802003
# Unit test for function match
def test_match():
    assert match(Command("aws s3 help", "usage: aws [options] \
<command> <subcommand> [<subcommand> ...] \
[parameters]\nto see help text, you can run: \
aws help\naws <command> help\naws <command> <subcommand> help\naws: error: \
unrecognized arguments: help\n\nDid you mean this?\n\ts3\n", ""))

# Generated at 2022-06-24 05:43:16.307717
# Unit test for function match
def test_match():
    command = Command("aws ec2 --help", "usage: ...", 0)
    assert match(command)

    command = Command("aws ec2 stop-instances", "usage: ...", 0)
    assert match(command)

    command = Command("aws s3 ls s3://mybucket/mys3key", "", 0)
    assert not match(command)


# Generated at 2022-06-24 05:43:18.005944
# Unit test for function match
def test_match():
    command = Command('aws --version')
    assert match(command)



# Generated at 2022-06-24 05:43:22.266757
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws help')) == ['aws help']
    assert get_new_command(Command('aws help --help')) == ['aws help --help']
    assert get_new_command(Command('aws help --h')) == ['aws help --help']


priority = 1000

# Generated at 2022-06-24 05:43:22.926664
# Unit test for function get_new_command
def test_get_new_command():
    pass

# Generated at 2022-06-24 05:43:27.522008
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 --region us-west-2 describe-instances --instance-ids', 'aws: error: argument --region: Invalid choice, valid choices are:')
    assert get_new_command(command) == [command.script.replace('--region', '--regions')]


# Generated at 2022-06-24 05:43:30.017933
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws', 'Invalid choice: "dynamodb", maybe you meant:', '')) == ['aws dynamodb']

enabled_by_default = True

# Generated at 2022-06-24 05:43:31.752704
# Unit test for function match

# Generated at 2022-06-24 05:43:37.553473
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 start-instances', output=('usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]', 'To see help text, you can run:', '', '  aws help', '  aws <command> help', '  aws <command> <subcommand> help', 'aws: error: argument instance-id: Invalid choice: \'asd\'', 'maybe you meant:', '  acs', '  asin', '  asv', '  cwn', '  das')
    )
    )


# Generated at 2022-06-24 05:43:49.353293
# Unit test for function get_new_command

# Generated at 2022-06-24 05:43:57.338526
# Unit test for function match
def test_match():
    assert match(Command('aws help', ''))
    assert match(Command('aws help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, maybe you meant:\n  configure    \n  lambda       \n  cloudwatch   \n  cloudtrail   \n  cloudformation\n  ec2          \n  elb          '))

# Generated at 2022-06-24 05:44:00.396389
# Unit test for function get_new_command
def test_get_new_command():
    script = Script('aws s3 cp s3://suniverse/x1026.zip /home/irina')
    command = Command('aws s3 cp s3://suniverse/x1026.zip /home/irina',
                      script)
    assert get_new_command(command) == [
        'aws s3 cp s3://suniverse/x1026.zip /home/irina']

# Generated at 2022-06-24 05:44:07.726237
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.aws_cli_typo import get_new_command
    command = Command('aws --region eu-west-1 es list-domain-names --')
    command.output = ('usage: aws [options] <command> <subcommand> [parameters]\n'
                      'aws: error: argument command: Invalid choice: \'es\', '
                      'maybe you meant:\n'
                      '        ec2\n'
                      '        ecs\n'
                      '        elb\n'
                      '        elastictranscoder\n'
                      '        elasticache')
    new_command = get_new_command(command)

# Generated at 2022-06-24 05:44:09.241272
# Unit test for function match
def test_match():
    assert match(Command('aws s3 rb s3://bucket/folder'))
    assert not match(Command('ls'))


# Generated at 2022-06-24 05:44:19.345937
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws codestar cancel-job', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nerror: Invalid choice: "codestar", maybe you meant:\n\n  * cloudformation\n  * cloudsearch\n  * cloudsearchdomain\n  * cloudtrail\n')

# Generated at 2022-06-24 05:44:25.817676
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://bucket',
                         output='usage: aws [options] <command> <subcommand> [parameters]\n\n'
                                'aws: error: too few arguments'))
    assert not match(Command('aws s3 mb s3://bucket',
                             output='usage: aws [options] <command> <subcommand> [parameters]\n\n'
                                    'aws: error: no such option: --no-preserve-attributes'))



# Generated at 2022-06-24 05:44:33.218129
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws --h', 'aws: error: argument --h: Invalid choice: \\\'--\\h\\\'\n\\naws: error: argument --h: Invalid choice: \'--h\', maybe you meant:\n    --help')) == ['aws --help']
    assert get_new_command(Command('aws s3 --h', 'aws: error: argument --h: Invalid choice: \\\'--\\h\\\'\n\\naws: error: argument --h: Invalid choice: \'--h\', maybe you meant:\n    --help\n    --host\n    --profile')) == ['aws s3 --help', 'aws s3 --host', 'aws s3 --profile']

# Generated at 2022-06-24 05:44:34.880545
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws lambda list-functions'
    assert (get_new_command(command) == "aws lambda list-functions")
    

# Generated at 2022-06-24 05:44:36.080921
# Unit test for function match
def test_match():
    assert match({'script':'aws --help'})
    assert not match({'script':'ls --help'})


# Generated at 2022-06-24 05:44:42.480003
# Unit test for function get_new_command

# Generated at 2022-06-24 05:44:52.948468
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 run-instances --image-id ami-93f79973', ''))
    assert match(Command('aws ec2 run-instances --image-id ami-93f79973\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]', ''))
    assert match(Command('aws ec2 run-instances --image-id ami-93f79973\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\naws: error: argument --image-id: Invalid choice: \'ami-93f79973\', maybe you meant: ', ''))
    assert not match(Command('aws ec2 run-instances --image-id ami-93f79973', ''))
    assert not match

# Generated at 2022-06-24 05:44:56.817549
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances --region us-east-1',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [...] Invalid choice: \'describe-instances\', maybe you meant: [...]',
                         ''))


# Generated at 2022-06-24 05:45:06.886454
# Unit test for function get_new_command
def test_get_new_command():
    output = '''
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, maybe you meant:
  describe
  elastic
  rds
  emr
  cloud
  config
  kms
  ssm
  s3
  sts
  iam
  lambda
  swf
  sns
  cloudformation
'''

# Generated at 2022-06-24 05:45:09.329915
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws help [options...] <command> <subcommand> [parameters...]'
    assert get_new_command(script) == 'aws'

# Generated at 2022-06-24 05:45:11.008613
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='aws s3 lis', output="Invalid choice: 'lis', maybe you meant:\
 \n* ls\n")
    all_options = get_new_command(command)
    assert len(all_options) == 1
    assert all_options[0] == 'aws s3 ls'

# Generated at 2022-06-24 05:45:14.279404
# Unit test for function get_new_command
def test_get_new_command():
  cmd = Command("aws ec2 ls", "aws: error: argument subcommand: Invalid choice: 'ls'", "aws")
  assert(get_new_command(cmd) == ["aws ec2 list", "aws ec2 list-instances"])

# Generated at 2022-06-24 05:45:24.982961
# Unit test for function get_new_command
def test_get_new_command():
    from types import SimpleNamespace as namespace
    command = namespace(script="aws s3 mb s3://testing.jllopez", output="usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\naws help\naws <command> help\naws <command> <subcommand> help\naws: error: argument command: Invalid choice: 'mb', maybe you meant:\n\tmb\n\tmbox\n\t* mb2\n\tmb5\n\tmbc\n\tmbl\n\tmboxconvert\n\tmboxpack\n\tmbt\n\tmboxsplit\n\tmboxvalidate\n")


# Generated at 2022-06-24 05:45:29.273466
# Unit test for function match
def test_match():
    assert match(Command('aws help', "Invalid choice: 'help', maybe you meant:\n\n* iam"))
    assert not match(Command('aws iam help', "usage: aws [options] [path] [--region]"))


# Generated at 2022-06-24 05:45:38.108389
# Unit test for function match

# Generated at 2022-06-24 05:45:43.972608
# Unit test for function get_new_command
def test_get_new_command():
    def _test(script, output, expected):
        assert get_new_command(Command(script, output=output)) == expected

    _test("aws ec2", "Invalid choice: 'ec2', maybe you meant:\n  * ec2-instances\n  * ec2-volumes",
          ['aws ec2-instances', 'aws ec2-volumes'])

# Generated at 2022-06-24 05:45:53.173827
# Unit test for function get_new_command

# Generated at 2022-06-24 05:46:04.377889
# Unit test for function match
def test_match():
    output1 = (
        'aws: error: argument subcommand: Invalid choice, valid choices are:\n'
        '\tconfigure | help | iam | rds | sns | sts\naws: error: need a command '
        '\nUsage: aws [options] <command> <subcommand> [<subcommand> ...] '
        '[parameters] \nTo see help text, you can run: \n'
        '\taws help \n\taws <command> help '
        '\taws <command> <subcommand> help \naws: error: the following '
        'arguments are required: subcommand')

# Generated at 2022-06-24 05:46:11.016274
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 stop-instances --instance-ids',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --instance-ids: Invalid choice: "a"', 1))


# Generated at 2022-06-24 05:46:21.843108
# Unit test for function match

# Generated at 2022-06-24 05:46:27.626783
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances',
                        "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\n'ec2' is not a valid subcommand.",
                        ""))
    assert not match(Command('aws ec2 describe-instances',
                        "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]",
                        ""))


# Generated at 2022-06-24 05:46:33.426180
# Unit test for function match

# Generated at 2022-06-24 05:46:39.546505
# Unit test for function get_new_command
def test_get_new_command():
    new_command = 'aws s3 ls'
    assert get_new_command(Command('aws s3 lst', 'Invalid choice: \'lst\', maybe you meant: \n  s3 ls\n'))[0].script == new_command
    assert get_new_command(Command('aws s3 lst', 'Invalid choice: \'lst\', maybe you meant: \n  s3 ls\n'))[0].output == 'Invalid choice: \'lst\', maybe you meant: \n  s3 ls\n'
    new_command = 'aws s3 ls '
    assert get_new_command(Command('aws s3 lst ', 'Invalid choice: \'lst \', maybe you meant: \n  s3 ls\n'))[0].script == new_command

# Generated at 2022-06-24 05:46:48.719863
# Unit test for function get_new_command
def test_get_new_command():
    command = type("Command", (),
                {"script": "aws dynamodb list-tables --endpoint-url=http://localhost:8000",
                 "output": "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice: 'list-table', maybe you meant: "\
                           "list-tables\n* list-tables\n\n"})
    assert get_new_command(command) == ["aws dynamodb list-tables --endpoint-url=http://localhost:8000"]



# Generated at 2022-06-24 05:46:59.451862
# Unit test for function match

# Generated at 2022-06-24 05:47:05.478717
# Unit test for function get_new_command
def test_get_new_command():
    command1 = "aws ec2 describe-instances --filters Name=instance-type,Values=c3.8xlarge"
    command2 = "aws ec2 describe-instances --filters Name=instance-type,Values=c3.8xlarg"
    command3 = "aws ec2 describe-instances --filters Name=instance-type,Values=c4.4xlarge"

# Generated at 2022-06-24 05:47:15.935509
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws ec2 create-instance --imagr-id ami-12345678 --securi-groups default"

# Generated at 2022-06-24 05:47:27.093006
# Unit test for function get_new_command

# Generated at 2022-06-24 05:47:30.493925
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws ec2 ls")
    assert get_new_command(command) == ['aws ec2 list']


# Generated at 2022-06-24 05:47:36.670551
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 help',
        "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, valid choices are:\n\n* ec2\n\nmaybe you meant:\n\n* ec2\n"))



# Generated at 2022-06-24 05:47:45.691674
# Unit test for function match
def test_match():
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument <subcommand>: Invalid choice: 's3api', maybe you meant: list\n   * delete\n   * list\n   * put"
    assert match(Command(script="aws s3api", output=output))
    assert not match(Command(script="aws s3api list", output=""))
    assert not match(Command(script="aws s3api", output=""))



# Generated at 2022-06-24 05:47:49.755163
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws --version'

# Generated at 2022-06-24 05:47:57.063537
# Unit test for function match
def test_match():
    assert match(Command('aws clouddebugger get-notification-channel',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice: "clouddebugger get-notification-channel", maybe you meant:',
                         ''))

# Generated at 2022-06-24 05:48:04.401028
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-volumes --region us-east-1a --filters "Name=attachment.instance-id,Values=i-123a12bc"'))
    assert not match(Command('aws ec2 describe-volumes --region us-east-1a --filters "Name=attachment.instance-id,Values=i-123a12bc"', 'aws.txt'))
    assert not match(Command('git commit -am "test mensagem"'))



# Generated at 2022-06-24 05:48:12.126437
# Unit test for function get_new_command
def test_get_new_command():
    # Test case 1 : valid command
    script = "aws s3 ls"
    mistake = "s4"
    options = ["s3", "s3api"]
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, valid choices are:\ns3\ns3api\n\n(maybe you meant: s4)\n"

    assert get_new_command(Command(script, output)) == [script.replace(mistake, o) for o in options]

    # Test case 2 : valid command
    script = "aws ec2 describe-instances"


# Generated at 2022-06-24 05:48:16.065090
# Unit test for function match
def test_match():
    assert (match(Command('aws ec2 describe-instances --filter Name=instance-state-code,Values=16 --query Reservations[].Instances[].InstanceId')))
    assert (match(Command('aws s3 ls')))
    asser

# Generated at 2022-06-24 05:48:26.127138
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-vpcs --region eu-west-1')
    command.output = "usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\n[...]\n\nInvalid option: --region\n\nUnknown options: --region\n\nUnknown options: eu-west-1\n\nusage: aws [options] <command> <subcommand> [<subcommand> ...]\n\n[...]\n\nInvalid option: --region\n\nUnknown options: --region\n\nUnknown options: eu-west-1\n\naws: error: argument operation: Invalid choice, maybe you meant:\n        ec2\n        ecr\n        sts\n\tAgain"

# Generated at 2022-06-24 05:48:36.931428
# Unit test for function get_new_command
def test_get_new_command():                                                                                                                                                                           
    command = Command('aws help')                                                                                                                                                                                                                                                                                                                                                                  
    command.output = "usage: aws [options] [ ...] [parameters]                                                                     To see help text, you can run:                                                                                       aws help           aws <command> help                aws <command> <subcommand> help                                                           aws: error: argument operation: Invalid choice, maybe you meant:                                                             *s3                                                                                                          *s3api                                                                                                       *s3-website                                                                                                   *s3control                                                                                                    *s3outposts                                                                                                   *sdb                                                                                                          *secretsmanager"  
    assert get_new

# Generated at 2022-06-24 05:48:42.264977
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    cmd = Command('aws codecommit --delete-repository-triggers --registry-id 123 --repository-name "first-repo"', '')
    assert get_new_command(cmd) == ['aws codecommit --delete-repository-triggers --repository-name "first-repo"']



# Generated at 2022-06-24 05:48:47.441412
# Unit test for function get_new_command
def test_get_new_command():
    command = """
Invalid choice: 'asdf', maybe you meant:
  * ec2
  * create-db-subnet-group
  * create-subnet
  * delete-subnet
  * describe-subnets
  * modify-subnet-attribute
  * ec2-subnet
  * ec2subnet
      """
    assert get_new_command(command) == [
        'aws ec2',
        'aws create-db-subnet-group',
        'aws create-subnet',
        'aws delete-subnet',
        'aws describe-subnets',
        'aws modify-subnet-attribute',
        'aws ec2-subnet',
        'aws ec2subnet']

# Generated at 2022-06-24 05:48:50.205501
# Unit test for function match
def test_match():
    command = Command("aws ec2 start-instances --instance-ids --region us-east-1")
    assert match(command)


# Generated at 2022-06-24 05:49:01.611817
# Unit test for function get_new_command
def test_get_new_command():
	new_commands = get_new_command(Command('aws s3 cp file.txt s3://bucket/file.txt', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n  error: argument subcommand: Invalid choice: \'cp\', maybe you meant:\n    * cp\n    * mb\n    * mv\n    * rb\n    * rm\n    * sync'))

# Generated at 2022-06-24 05:49:10.937959
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 start-instances', 'Invalid choice: \'ec2\', maybe you meant:\n  * ec2\n  * configservice\n  * events\n  * iam\n  * cloudwatch\n  * s3\n  * opsworks\n  * sqs\n  * redshift\n  * autoscaling\n  * directconnect\n  * lambda\n  * support\n  * cloudtrail\n  * elasticache\n  * rds\n  * elasticbeanstalk\n  * ssm\n  * dynamodb\n  * cloudformation\n  * glacier\n  * ecr\n  * route53\n  * ses\n  * swf\n  * elastictranscoder\n'))

# Generated at 2022-06-24 05:49:13.032364
# Unit test for function match
def test_match():
    assert match(Command('aws help', ''))
    assert not match(Command('ls -al', ''))



# Generated at 2022-06-24 05:49:24.066842
# Unit test for function get_new_command

# Generated at 2022-06-24 05:49:27.243159
# Unit test for function get_new_command
def test_get_new_command():
    path = 'tests/samples/aws'
    with open(path, 'r') as output:
        command = Command(script = None, output = output.read())
        assert get_new_command(command) == ['aws ec2 describe-instances']

# Generated at 2022-06-24 05:49:34.151442
# Unit test for function get_new_command
def test_get_new_command():
    from tests.utils import Command


# Generated at 2022-06-24 05:49:38.582707
# Unit test for function match
def test_match():
    assert match(Command(script='aws', output='usage: aws [options]'))
    assert not match(Command(script='aws', output='usage: aw'))
    assert not match(Command(script='aws', output='Invalid choice: \'huh\'.'))


# Generated at 2022-06-24 05:49:41.413443
# Unit test for function match
def test_match():
    res = match(script="aws configure --profile test --name EMR")
    assert res == 'usage:' in res.output and "maybe you meant:" in res.output


# Generated at 2022-06-24 05:49:52.157868
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 cp foo.txt s3://bucket/bar.txt --acl public-read')
    assert get_new_command(command) == ['aws s3 cp foo.txt s3://bucket/bar.txt --acl public-read'] # when there is no mistake
    command = Command('aws configure set preview.cloudfront true')
    assert get_new_command(command) == ['aws configure set preview.cloudfront true'] # when there is no maybes
    command = Command('aws elb describe-instance-health --load-balancer-name my-lb')
    assert get_new_command(command) == ['aws elb describe-instance-health --load-balancer-name my-lb'] # when there is no mistake

# Generated at 2022-06-24 05:49:58.846246
# Unit test for function match
def test_match():
    assert match(Command(script='aws-cli', output='usage: aws [options] \
        <command> <subcommand> [<subcommand> ...] [parameters] \
        To see help text, you can run: aws help\nInvalid choice: \
        \'s3ls\', maybe you meant:\n\t* s3 ls\n'))


# Generated at 2022-06-24 05:50:02.713304
# Unit test for function match
def test_match():
    assert not match(Command("", ""))
    assert not match(Command("echo $PATH", ""))
    assert match(Command("aws ec2 describe-instances", "aws: error: argument command: Invalid choice: 'ec2-public-ips', maybe you meant:"))

# Generated at 2022-06-24 05:50:10.197296
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    # Simple command
    script = "aws s3 ls"
    output = """
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

Invalid choice: 's3', maybe you meant:
  service
  sts

Unknown options: ls
    """

    assert get_new_command(Command(script, output)) == ['aws service ls', 'aws sts ls']

    # More complex command
    script = "aws s3 '{}'"

# Generated at 2022-06-24 05:50:19.100201
# Unit test for function get_new_command
def test_get_new_command():
    command = type("command", (object,), {
        "script": "aws s3 cp foo s3://my-bucket/foo",
        "output": "aws: error: argument s3: Invalid choice: 's3://my-bucket/foo', maybe you meant:\n  * s3://my-bucket/foo\n  * s3://my-bucket/foobar\n\nSee 'aws_s3_cp help' for descriptions of global parameters.\n"})
    assert get_new_command(command) == ['aws s3 cp foo s3://my-bucket/foo', 'aws s3 cp foo s3://my-bucket/foobar']

# Generated at 2022-06-24 05:50:25.909421
# Unit test for function match
def test_match():
    # test case for invalid command
    assert match(Command('aws ec2 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]', '', 125))

    # test case for valid command
    assert not match(Command('aws ec2 ls', '<Response><Errors><Error><Code>MissingParameter</Code>', '', 125))



# Generated at 2022-06-24 05:50:34.667588
# Unit test for function match
def test_match():
	assert match(Command("aws ec2 describe-images", output="usage: aws [options] \n\
                                                                   [ ]: error: argument command: Invalid choice: 'ec2 describe-images', maybe you meant:\n\
                                                                   * describe-image-attribute\n\
                                                                   * describe-images\n\
                                                                   * describe-instance-attribute\n\
                                                                   * describe-instances\n\
                                                                   * describe-key-pair\n\
                                                                   * describe-security-groups\n\
                                                                   * describe-tags"))


# Generated at 2022-06-24 05:50:43.374602
# Unit test for function get_new_command
def test_get_new_command():
    class fake_command(object):
        output = "fake command output"
        script = "fake command script"

    test_command = fake_command()
    test_command.output = "\nError: usage:\n  aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\ninvalid choice: 'foo',maybe you meant:\n\n  * bar\n  * baz"
    test_command.script = "aws foo"
    option, = get_new_command(test_command)
    assert option == "aws bar" or  option == "aws baz"

# Generated at 2022-06-24 05:50:50.270141
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls --region blah blah',
            output='\naws s3 ls --region blah blah\nusage: aws [options] <command> <subcommand> [parameters]\n\naws: error: argument --region: Invalid choice, maybe you meant:\n  -r, --recursive  \n  -e, --endpoint   \n  -m, --max-items\n'))



# Generated at 2022-06-24 05:50:55.692211
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws autoscaling help', 'Invalid choice: autoscaling, maybe you meant:\n* autoscaling-api\n* autoscaling-group\n* autoscaling-hook', '')) == ['aws autoscaling-api help', 'aws autoscaling-group help', 'aws autoscaling-hook help']


# Generated at 2022-06-24 05:50:58.968382
# Unit test for function get_new_command
def test_get_new_command():
    ret = get_new_command(
        Command('aws ec2 run-instance --image-id ami-000000 --', ''))
    assert ret == ['aws ec2 run-instances --image-id ami-000000 --']

# Generated at 2022-06-24 05:51:10.263760
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command('aws help', 'aws: error: argument command: Invalid choice: \'help\', maybe you meant:\n\t* help-ec2\n\t* help-elbv2\n\t* help-route53\n\n')
    assert get_new_command(command1) == ['aws help-ec2', 'aws help-elbv2', 'aws help-route53']
    command2 = Command('aws help-s3', 'aws: error: argument command: Invalid choice: \'help_s3\', maybe you meant:\n\t* help-ec2\n\t* help-elbv2\n\t* help-route53\n\n')

# Generated at 2022-06-24 05:51:12.086116
# Unit test for function match
def test_match():
    assert match(Command('aws help'))
    assert not match(Command('aws'))



# Generated at 2022-06-24 05:51:18.608887
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws list-ansible-vault-keys --region us-east-1 --profile test'
    expected = 'aws list-ansible-vault-keys --region us-east-1 --profile default'
    output = """usage: aws [options]
aws: error: argument command: Invalid choice, valid choices are:

aws: error: argument command: Invalid choice, valid choices are:
        list-ansible-vault-keys <--- maybe you meant: list-ansible-vault-keys
        list-builds


aws: error: argument --profile: Invalid choice, valid choices are:
        default <--- maybe you meant: default
        test
"""
    assert get_new_command(script, output) == expected

# Generated at 2022-06-24 05:51:28.911079
# Unit test for function get_new_command

# Generated at 2022-06-24 05:51:38.283463
# Unit test for function get_new_command
def test_get_new_command():
    output = ("usage: aws [options] <command> <subcommand> [parameters]\n"
              "aws: error: argument command: Invalid choice: 'ecs', "
              "maybe you meant:\n"
              "   * ecs-cli\n"
              "   * ecs-deploy\n"
              "\n")
    script = "aws ecs"
    command = Command(script, output)
    res = get_new_command(command)
    assert res == [
        "aws ecs-cli",
        "aws ecs-deploy"
    ]

# Generated at 2022-06-24 05:51:45.404486
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('aws ec2 creeat-key-pair ') == [
        'aws ec2 create-key-pair '
    ]
    assert get_new_command('aws ec2 creeat-key-pair \n') == [
        'aws ec2 create-key-pair \n'
    ]
    assert get_new_command('aws ec2 creeat-key-pair \n \n \n') == [
        'aws ec2 create-key-pair \n \n \n'
    ]
    assert get_new_command('aws ec2 creeat-key-pair \n \n \n \n \n') == [
        'aws ec2 create-key-pair \n \n \n \n \n'
    ]

# Generated at 2022-06-24 05:51:52.006123
# Unit test for function match
def test_match():
    assert match(Command('python app.py --help',
        '''usage: app.py [-h] [--version] [--config_file CONFIG_FILE] [-v]
                  ...
        '''))
    assert not match(Command('python app.py --help',
        '''usage: app.py [-h] [--version] [--config_file CONFIG_FILE] [-v]
                  ...
        Invalid choice: '--config_file', maybe you meant:
                config-file
                config_file
        '''))



# Generated at 2022-06-24 05:52:01.573360
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-iin-valid-instance-types --query "InstanceTypes[*].InstanceType" --output text')

# Generated at 2022-06-24 05:52:09.317600
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mv s3://test.txt /tmp/test.txt',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n'
                         '\n'
                         '[snip]\n'
                         'aws: error: argument command: Invalid choice, valid choices '
                         'are:\n'
                         '* cp\n'
                         '* ls\n'
                         '[snip]\n'
                         'maybe you meant:\n'
                         '* mb\n'
                         '* mv\n'
                         '[snip]'))



# Generated at 2022-06-24 05:52:19.176010
# Unit test for function match

# Generated at 2022-06-24 05:52:23.449592
# Unit test for function match
def test_match():
    assert match(Command('aws')) == False
    assert match(Command('aws ec2')) == False
    assert match(Command('aws ec2 asdf')) == True
    assert match(Command('aws ec2 asdf --format')) == True
    assert match(Command('aws ec2 asdf --format table')) == True


# Generated at 2022-06-24 05:52:28.701554
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('aws s3 cp something s3://mybucket/', '')) == ['aws s3 cp s3://mybucket/ something']
    assert get_new_command(Command('aws s3 cp something s3://mybucket/ --recursive', '')) == ['aws s3 cp s3://mybucket/ something --recursive']



# Generated at 2022-06-24 05:52:36.231332
# Unit test for function match
def test_match():
    assert match(Command('aws help',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [--<x.x.x.x> ...] \n'
                         'The available commands are:\n'
                         '* acr                                                                    : Manage AWS Container Registry.\n'
                         'account-settings                                                         : Manage your AWS account settings.\n'
                         '...\n'
                         'extend-timeout                                                           : extend the timeout for this command\n'
                         '...\n'
                         'Invalid choice: \'acr\', maybe you meant:\n'
                         '* account-settings\n'
                         '...'))



# Generated at 2022-06-24 05:52:40.814742
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 mb s3://my-bucket', 'Invalid choice: \'mb\', maybe you meant:\n\tmb\tMake a bucket\ns3: error: argument command: Invalid choice: \'mb\'', '')) == ['aws s3 mb s3://my-bucket']
    assert get_new_command(Command('aws s3 mb s3://my-bucket', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n[snip]s3: error: argument command: Invalid choice: \'mb\'', '')) == []

# Generated at 2022-06-24 05:52:45.150355
# Unit test for function get_new_command
def test_get_new_command():
    # Get the options listed in the command.output and put them into an array.
    options = get_new_command(command)
    assert options
    # Check if the number of options is equal to number of options in the command.output.
    assert len(options) == len(re.findall(OPTIONS, command.output, flags=re.MULTILINE))