

# Generated at 2022-06-24 05:42:45.214757
# Unit test for function get_new_command
def test_get_new_command():
    command = type("Command", (), {"output": """usage: aws [options] <command> <subcommand> [parameters]
aws: error: argument subcommand: Invalid choice, maybe you meant:
*         sns
*         s3
*         s3api"""})
    assert get_new_command(command) == ['aws sns', 'aws s3', 'aws s3api']


priority = 99

# Generated at 2022-06-24 05:42:52.932554
# Unit test for function match
def test_match():
    # A command with error
    command = Command('aws s3 --help',
                      'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument <command>: Invalid choice: \'s3\', maybe you meant: \n  cloudformation\n  cloudwatch\n  dynamodb\n  ec2\n  iam\n  rds\n  route53\n  s3\n  sns\n  sqs\n\n')
    assert match(command)

    command = Command('aws help',
                      'error: the following arguments are required: command')

# Generated at 2022-06-24 05:43:03.460255
# Unit test for function get_new_command

# Generated at 2022-06-24 05:43:10.801473
# Unit test for function get_new_command
def test_get_new_command():
    aws_output = "usage: aws [options] <command> <subcommand> [parameters]\n\
To see help text, you can run:\n\
\n\
  aws help\n\
  aws <command> help\n\
  aws <command> <subcommand> help\n\
aws: error: argument operation: Invalid choice: 'list-stuff', maybe you meant:\n\
                    list-things\n"
    command = Command(script= 'aws list-stuff', output= aws_output)
    assert get_new_command(command) == ['aws list-things']

# Generated at 2022-06-24 05:43:21.954274
# Unit test for function get_new_command
def test_get_new_command():
    test_command = type('Command', (), {'script': './aws s3 lsm --recursiv  --bucket thefuck-repo', 'output':'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument operation: Invalid choice: \'lsm\', maybe you meant:\n                 ls\n                 mb\n                 sync\n                 * cp'})

# Generated at 2022-06-24 05:43:27.746812
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'Invalid choice: "helper", maybe you meant:\n    * help\n'))
    assert not match(Command('aws help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'))
    assert not match(Command('aws', 'Invalid choice: "help", maybe you meant:\n    * helper\n\n'))

# Generated at 2022-06-24 05:43:32.553085
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'usage: aws [options] [path...]', 'aws: error: Invalid choice: \'help\', maybe you meant: * ec2\n  * ecs\n  * ecs-cli\n  * ecr\n  * s3\n  * s3api\n  * s3-la', '', 1))


# Generated at 2022-06-24 05:43:34.083350
# Unit test for function match
def test_match():
    command = Command("aws ec2 run-instances --dry-run")
    assert match(command)


# Generated at 2022-06-24 05:43:42.198715
# Unit test for function match
def test_match():
    assert match(Command("aws s3", "aws: error: argument operation: Invalid choice: 's3', maybe you meant: "))
    assert match(Command("aws s3 ls", "aws: error: argument operation: Invalid choice: 's3 ls', maybe you meant: "))
    assert not match(Command("aws s3 ls", "Invalid choice: 's3 ls', maybe you meant:"))
    assert not match(Command("", "aws: error: argument operation: Invalid choice: 's3 ls', maybe you meant: "))


# Generated at 2022-06-24 05:43:49.492712
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws sndg')
    print (command)
    new_commands = get_new_command(command)
    print (new_commands)
    assert new_commands[0] == 'aws sndg'
    assert new_commands[1] == 'aws snd'
    assert new_commands[2] == 'aws sending-diagnostics'
    assert new_commands[3] == 'aws sending-stats'
    assert new_commands[4] == 'aws send'

# Generated at 2022-06-24 05:43:57.796905
# Unit test for function match
def test_match():
    assert match(Command('aws --help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] ...\naws: error: unrecognized arguments: --help\nmaybe you meant:\n\tiam\n\tinfo\n\tall\n\timport-instance\n\timport-snapshot'))
    assert not match(Command('aws', ''))
    assert not match(Command('aws', 'usage:'))
    assert not match(Command('aws', 'maybe you meant:'))


# Generated at 2022-06-24 05:44:04.406779
# Unit test for function match
def test_match():
    output1 = "usage: aws [options] <command> <subcommand> [parameters]"

# Generated at 2022-06-24 05:44:07.414684
# Unit test for function match
def test_match():
    assert match(Command('aws --help', 'aws: error: argument --help: expected one argument'))
    assert match(Command('aws s3 mb s3://bucket', 'aws: error: argument s3: Invalid choice, maybe you meant: bucket'))
    assert not match(Command('exportfoo', 'exportfoo: command not found'))


# Generated at 2022-06-24 05:44:18.078190
# Unit test for function match
def test_match():
    # Test for function command
    assert match(Command('aws ec2 describe-images',
        'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument group: Invalid choice: \'dscribe-images\', maybe you meant:\n  * describe-image-attribute\n  * describe-images\n  * describe-instance-attribute\n  * describe-instances\n  * describe-key-pairs\n  * describe-regions\n\n')
    )

# Generated at 2022-06-24 05:44:25.463523
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    command = Command('git lolcow', 'git: \'lolcow\' is not a git command. '
                     'See \'git --help\'.\n\n'
                     'Did you mean one of these?\n'
                     '   log\n'
                     '   lg\n'
                     '   log\n'
                     '\n')
    assert get_new_command(command) \
        == [replace_argument(command.script, 'lolcow', option) for option in ['log', 'lg', 'log']]

# Generated at 2022-06-24 05:44:33.794352
# Unit test for function get_new_command

# Generated at 2022-06-24 05:44:40.269399
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command(script='aws s3',
        output="usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n"
               "To see help text, you can run:\n"
               "aws help\n"
               "aws <command> help\n"
               "aws <command> <subcommand> help\n"
               "aws: error: argument subcommand: Invalid choice, maybe you meant:\n"
               "   s3api",
        stderr='Invalid choice: ''s3'', maybe you meant:',
        env={}))
           == ['aws s3api'])

# Generated at 2022-06-24 05:44:51.362551
# Unit test for function get_new_command
def test_get_new_command():
    # aws ec2 list-images
    input_string = "usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument command: Invalid choice, maybe you meant:\n  describe-images   \n  describe-snapshots\n  describe-volumes\n  import-image\n  list-images\n  register-image\n  create-image\n\n\naws: error: argument command: Invalid value 'list-images', maybe you meant:\n  describe-images   \n  describe-snapshots\n  describe-volumes\n  import-image\n  list-images\n  register-image\n  create-image\n\n\n"

# Generated at 2022-06-24 05:45:00.022970
# Unit test for function get_new_command
def test_get_new_command():
    choices = '''aws run.yml
    usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
    To see help text, you can run:

      aws help
      aws <command> help
      aws <command> <subcommand> help
    aws: error: argument subcommand: Invalid choice: 'run.yml', maybe you meant:
    * run-instances
    * run-task'''

    command = 'aws run.yml'
    assert str(get_new_command(type('', (object,), {'output': choices, 'script': command})))=='''aws run-instances'''

# Generated at 2022-06-24 05:45:08.256861
# Unit test for function get_new_command

# Generated at 2022-06-24 05:45:14.953486
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]', 'Invalid choice: \'ec2 help\', maybe you meant:\n    help\n    configure\n    configure help'))
    assert not match(Command('aws ec2 help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]', 'Invalid choice: \'ec2 help\', maybe you meant:\n    configure'))


# Generated at 2022-06-24 05:45:23.376633
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances', '', 'aws: error: argument operation: Invalid choice: \'describe-in\', maybe you meant:\n  * describe-instances'))
    assert match(Command('aws ec2 describe-instances', '', 'aws: error: argument operation: Invalid choice: \'describe-ins\', maybe you meant:\n  * describe-instances'))
    assert not match(Command('aws ec2 describe-instances', '', 'aws: error: argument operation: Invalid choice: \'describe-instances\', maybe you meant:\n  * describe-instances'))


# Generated at 2022-06-24 05:45:28.534702
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='aws s3 ls',
                           output="Invalid choice: 'ls', maybe you meant:\n* ls-b\n* ls-c\n* ls-d")) == ['aws s3 ls-b', 'aws s3 ls-c', 'aws s3 ls-d']

# Generated at 2022-06-24 05:45:30.353726
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws configure --profile foo'
    assert get_new_command(command) == [command]

# Generated at 2022-06-24 05:45:38.640689
# Unit test for function get_new_command
def test_get_new_command():
    output = """usage: aws [options] [ ...] [parameters]
To see help text, you can run:

  aws help
  aws help
  aws help

Unknown options: --some-option-that-doesnt-exist, foo
Unknown options: --some-option-that-doesnt-exist, foo
usage: aws [options] [ ...] [parameters]
aws: error: argument command: Invalid choice: '--some-option-that-doesnt-exist', maybe you meant:
    s3api         Low-level S3 API

See 'aws help' for descriptions of global parameters.
"""
    script = "aws --some-option-that-doesnt-exist"
    command = Command(script, output)

    new_commands = get_new_command(command)


# Generated at 2022-06-24 05:45:49.445951
# Unit test for function get_new_command
def test_get_new_command():
    # Valid args
    command = Command('aws s3 mb s3:://not-wrong-bucket-name', '')
    assert ['aws s3 mb s3://not-wrong-bucket-name', 'aws s3 mb s3://not-wrong-bucket-name'] == get_new_command(command)

    command = Command('aws s3 mb s3:://not-wrong-bucket-name --region us-west-2', '')
    assert ['aws s3 mb s3://not-wrong-bucket-name', 'aws s3 mb s3://not-wrong-bucket-name'] == get_new_command(command)

    # Invalid arg
    command = Command('aws s3 mb s3:://not-wrong-bucket-name --region us-west-2', '')
   

# Generated at 2022-06-24 05:45:57.218648
# Unit test for function match

# Generated at 2022-06-24 05:46:07.363802
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws ec2 describe-instances --instance-ids i-b23a6d1a'

# Generated at 2022-06-24 05:46:18.612089
# Unit test for function get_new_command

# Generated at 2022-06-24 05:46:20.017298
# Unit test for function match
def test_match():
    assert any(match(1) for command in get_new_command(commands))

# Generated at 2022-06-24 05:46:26.832640
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-volumes',
                output='usage: aws [options] <command> <subcommand> [...parameters]\nTo see help text, you can run:\naws help\naws <command> help\naws <command> <subcommand> help\naws: error: argument command: Invalid choice: \'describe-volumes\', maybe you meant:\n   delete-stack\n   describe-stack\n   generate-cli-skeleton\n   list-stacks\n   update-stack'))


# Generated at 2022-06-24 05:46:29.609939
# Unit test for function match
def test_match():
    assert match(Command('something', 'You does, does you?', 'maybe you meant: no'))
    assert not match(Command('ls', ''))


# Generated at 2022-06-24 05:46:31.147711
# Unit test for function match
def test_match():
    assert 1==1
	

# Generated at 2022-06-24 05:46:34.757063
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("aws ec2 describe-instances", "Invalid choice: 'describe-instances', maybe you meant:\n  * describe-instance\n  * describe-instances-status")) == ["aws ec2 describe-instance", "aws ec2 describe-instances-status"]

# Generated at 2022-06-24 05:46:36.565109
# Unit test for function match
def test_match():
    assert match(Command('aws lambda --sdfsd', ''))
    assert not match(Command('ls', ''))


# Generated at 2022-06-24 05:46:44.159849
# Unit test for function match

# Generated at 2022-06-24 05:46:48.756492
# Unit test for function match
def test_match():
    assert match(Command('aws --blah',
                         "usage: aws [options] [ ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n\nUnknown options: --blah\nMaybe you meant:\n\n  --batch-check-layer-existence\n  --batch-delete-image\n  --batch-get-image\n"))


# Generated at 2022-06-24 05:46:53.698568
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws s3 ls --recursive --outdir testdir",
                      "Invalid choice: '--outdir', maybe you meant:\n    --outfile")
    new_command = get_new_command(command)
    assert new_command == ["aws s3 ls --recursive --outfile testdir"]

# Generated at 2022-06-24 05:46:56.610627
# Unit test for function match
def test_match():
    # `aws configure` does not work because no ~/.aws profile is created
    assert match(Command('aws configure', '', ''))
    assert not match(Command('aws configure', 'usage', ''))


# Generated at 2022-06-24 05:47:04.691503
# Unit test for function match

# Generated at 2022-06-24 05:47:06.140432
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mv bucket', ''))


# Generated at 2022-06-24 05:47:16.437576
# Unit test for function get_new_command

# Generated at 2022-06-24 05:47:25.047135
# Unit test for function match
def test_match():
	script = "aws s3 ls s3://bucket"
	output = """usage: aws [options] [ ...] [parameters]
To see help text, you can run:

  aws help
  aws help
  aws help

Unknown options: s3 ls s3://bucket

Invalid choice: 's3', maybe you meant:
* s3api
* s3ops
* s3sync
* s3website

Run 'aws help' for descriptions of global parameters.
"""
	command = Command(script, output)
	assert match(command)


# Generated at 2022-06-24 05:47:34.816739
# Unit test for function get_new_command
def test_get_new_command():
    command = MagicMock(script='aws ec2 describe instances --filters Name=vpc-id,Values=vpc-cdde83ad,vpc-dbc9b9f4')
    command.output = """usage: aws [options] <command> <subcommand> [<subcommand> ...]
...

Unknown options: --filters, Name=vpc-id,Values=vpc-cdde83ad,vpc-dbc9b9f4
maybe you meant:
  * filters
  * delete-filters
"""
    assert get_new_command(command) == ['aws ec2 describe instances --filters', 'aws ec2 describe instances --delete-filters']

# Generated at 2022-06-24 05:47:41.538090
# Unit test for function match
def test_match():
    assert match(Command('aws s3 presign', "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\naws help\naws <command> help\naws <command> <subcommand> help\nUnknown options: presign\n\nmaybe you meant:\n    ls\n    mb\n\n"))



# Generated at 2022-06-24 05:47:49.774845
# Unit test for function get_new_command
def test_get_new_command():
    command1 = Command(script='aws ad')

# Generated at 2022-06-24 05:48:01.120628
# Unit test for function match
def test_match():
    assert match(Command('aws --help', 'aws: error: argument --verbose: invalid choice: \'-\', maybe you meant: -v, --version\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run: ...'))
    assert match(Command('aws --help', 'aws: error: argument --verbose: invalid choice: \'-\', maybe you meant: -v, --version\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run: ...'))

# Generated at 2022-06-24 05:48:05.275962
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\n...\n maybe you meant: s3api'))
    assert not match(Command('ls', ''))


# Generated at 2022-06-24 05:48:12.530334
# Unit test for function get_new_command
def test_get_new_command():
    command = """Error: Invalid choice: 'opts', maybe you meant:
                \n
                \n  * options
                \n"""
    assert 'aws --options' in get_new_command(command)
    # s3 specific
    command = """Error: Invalid choice: '--sse-kms-key-id', maybe you meant:
                \n
                \n  * --sse-kms-key-id
                \n  * --sse
                \n  * --sse-c
                \n  * --sse-c-key-md5
                \n  * --sse-c-copy-source
                \n  * --sse-c-copy-source-key
                \n  * --sse-c-copy-source-key-md5
                \n"""

# Generated at 2022-06-24 05:48:23.774339
# Unit test for function get_new_command

# Generated at 2022-06-24 05:48:33.012037
# Unit test for function match
def test_match():
    assert match(Command('aws s3 sync some-path s3://some-bucket --some-option', 'usage: aws [options] <command> <subcommand> [parameters]\n...\naws: error: argument subcommand: Invalid choice, maybe you meant:\n        sync\n        mb\n        ls\n        rb\n        cp\n        setacl\n        getacl\n        rm\n        presign\n        website\n        demonstrate-parameters\n        restore\n        compose\n        compose-object\n        move\n        cp\n        cat\n'))


# Generated at 2022-06-24 05:48:37.873521
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'usage: aws [options] <command> <subcommand> [parameters]\n\nInvalid choice: \'help\', maybe you meant:\n  * \'help-ec2\'\n  * \'help-elasticbeanstalk\'\n'))
    assert not match(Command('ls file1 file2 file3', ''))


# Generated at 2022-06-24 05:48:44.693544
# Unit test for function match
def test_match():
    match_output = "usage: aws [options] <command> <service> <args>\naws: error: Invalid choice: 'autoscaling2', maybe you meant: * auto-scaling\n\t* autoscaling\naws: error: too few arguments\n"
    not_match_output = "aws: error: too few arguments"
    assert match(MagicMock(output=match_output))
    assert not match(MagicMock(output=not_match_output))


# Generated at 2022-06-24 05:48:51.653944
# Unit test for function match
def test_match():
    # Invalid choice: 'no', maybe you meant:
    assert match(Command('aws ec2 describe-images --owner no', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]', "The argument '--owner no' expects an value")[0])
    assert not match(Command('aws ec2 describe-images --owner no', "usage: aws [options] <command> <subcommand> [<subcommand> ...]", "The argument '--owner' expects an value"))
    assert not match(Command('aws ec2 describe-images --owner no', "usage: aws [options] <command> <subcommand> [<subcommand> ...]", "The argument '--owners' expects an value"))
    # Invalid choice: 'key', maybe you meant:

# Generated at 2022-06-24 05:48:59.764309
# Unit test for function match
def test_match():
    assert match(Command('aws --help',
             'aws: error: argument command: Invalid choice: \'--help\', maybe you meant:\n  * --help-cmd\n  * --help-syntax\n  * --help-common-options ... (truncated) ... ... (truncated) ... ... (truncated) ... ... (truncated) ... ... (truncated) ...\n  * --version\n  * --endpoint-url\n  * --no-verify-ssl\n'))



# Generated at 2022-06-24 05:49:07.850576
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-instances --filtr Name=instance-state-code,Values=16,80', 'usage: aws [options] \n.\n.\n.\nInvalid choice: \'--filtr\', maybe you meant:\n*   --filter\n*   --output\n\nSee \'aws help\' for descriptions of global parameters.')) \
        == ['aws ec2 describe-instances --filter Name=instance-state-code,Values=16,80',
            'aws ec2 describe-instances --output Name=instance-state-code,Values=16,80']


# Generated at 2022-06-24 05:49:15.578146
# Unit test for function match
def test_match():
    assert match(Command('aws iam list-users','''usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

Unknown options: list-users
Invalid choices: 'list-users'
maybe you meant:
  iam list-users'''))


# Generated at 2022-06-24 05:49:26.263242
# Unit test for function match
def test_match():
    output1 = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\naws help\naws <command> help\naws <command> <subcommand> help\naws: error: argument command: Invalid choice, maybe you meant: create-instances-from-snapshot\n"
    output2 = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\naws help\naws <command> help\naws <command> <subcommand> help\naws: error: argument command: Invalid choice, maybe you meant: create-instances-from-snapshot create-instances-from-snapshot\n"

# Generated at 2022-06-24 05:49:28.778775
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws configure', 'aws: error: argument --profile: Invalid choice: \"security\", maybe you meant: \n  * --profile')
    assert get_new_command(command) == ['aws configure --profile']

# Generated at 2022-06-24 05:49:30.860604
# Unit test for function match
def test_match():
    assert match(Command('aws', 'Unknown options: --wrong'))
    assert not match(Command('ls', 'Unknown options: --wrong'))


# Generated at 2022-06-24 05:49:42.329628
# Unit test for function get_new_command

# Generated at 2022-06-24 05:49:53.314293
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws2 elb2 describe-load-balancers"
    output = "usage: aws elb describe-load-balancers [options] [<LoadBalancerNames>...]\n\nA \
            list of one or more load balancer names.\n\n  --load-balancer-names <value>\n                        \
            (string)  Invalid choice: 'elb2', maybe you meant:\n                        \
            [elb-application-load-balancers elb-classic-load-balancers elb-cross-zone-load-balancing]\
            "
    command = Command(script, output)

# Generated at 2022-06-24 05:49:59.899431
# Unit test for function get_new_command
def test_get_new_command():
    correctCmd = ['aws s3 ls s3://bucket']
    newCmd = get_new_command(Command('aws s3 ls s3://bucket', correctCmd, 'Invalid choice: \'s3://bucket\', maybe you meant:\n  * list\n  * mb\n  * rb\n  * sync\n'))
    assert newCmd == correctCmd


# Generated at 2022-06-24 05:50:08.390625
# Unit test for function match
def test_match():
    assert match(Command('aws --what-is-it', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\n\nInvalid choice: \'what-is-it\', maybe you meant:\n    configure   : The command line configuration utility\n    help        : Shows a list of commands or help for one command\n    sts         : Tool to share temporary credentials\n\n\nTo get help for a command, type \'aws help\n\n\n'))

# Generated at 2022-06-24 05:50:19.035174
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances', ''))
    assert not match(Command('aws ec2 run-instances', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, valid choices are:\n\nautoscaling\ncloudformation\ncloudfront\ncloudhsm\ncloudsearch\ncloudtrail\ncloudwatch\n'))

# Generated at 2022-06-24 05:50:28.856963
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://mybucket', "", "usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument command: Invalid choice, valid choices are:\nusage: aws [options] <command> <subcommand> [parameters]\naws: error: too few arguments\nMaybe you meant:\n\tmkdir\n"))
    assert not match(Command('aws s3 mb s3://mybucket', "", "usage: aws [options] <command> <subcommand> [parameters]\naws: error: too few arguments\nMaybe you meant:\n\tmkdir\n"))



# Generated at 2022-06-24 05:50:40.074055
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-images --owner self --image-id none',
                      "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument image-id: Invalid choice: 'none', maybe you meant: 'ami-none'?\n* ami-none\n* ami-dedf1a8e\n* ami-dedf1a8c\n* ami-dedf1a8e\n")
    assert get_new_command(command) == ['aws ec2 describe-images --owner self --image-id ami-none']


# Generated at 2022-06-24 05:50:45.638082
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]', ''))
    assert match(Command('aws help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n \n Invalid choice: \'help\', maybe you meant:    eb\n            ec2\n            configure', ''))

# Generated at 2022-06-24 05:50:48.379346
# Unit test for function match
def test_match():
    assert(match(Command('aws --version', '')))
    assert(not match(Command('aws --version', '', '')))


# Generated at 2022-06-24 05:50:59.007498
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws test')
    command.output = 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n                To see help text, you can run:\n                aws help\n                aws <command> help\n                aws <command> <subcommand> help\n                aws: error: argument command: Invalid choice: \'test\', maybe you meant:\n                * test-invoke-authorizer\n                 test-invoke-method\n                 test-invoke-stage\n                See \'aws help\' for descriptions of global parameters.'
    assert get_new_command(command) == ['aws test-invoke-authorizer', 'aws test-invoke-method', 'aws test-invoke-stage']



# Generated at 2022-06-24 05:51:04.067124
# Unit test for function get_new_command
def test_get_new_command():
    test_result = get_new_command(Command('aws s3',
                                          'aws: error: argument command: Invalid choice: "s3", maybe you meant:\n\t* s3api\n\t* s3api'))
    assert test_result == ['aws s3api', 'aws s3api']
# END unit test

# Generated at 2022-06-24 05:51:14.463553
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws ec2 describe-security-groups --group-ids g-11111111"

# Generated at 2022-06-24 05:51:25.517506
# Unit test for function get_new_command

# Generated at 2022-06-24 05:51:28.838128
# Unit test for function match

# Generated at 2022-06-24 05:51:30.685253
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws ec2 describe-availability-zones us-east-1 a") == [
        "aws ec2 describe-availability-zones us-east-1a"]

# Generated at 2022-06-24 05:51:42.129855
# Unit test for function get_new_command
def test_get_new_command():
	script = "aws ec2describe-instancestates --filters Name=\"instance-id\",Values=\"i-5309c21e\""
	output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument filter: Invalid choice: 'Name=instance-id', maybe you meant:\n        name\n"
	command = type("obj", (object,), {"script": script, "output": output})
	assert get_new_command(command) == ["aws ec2describe-instancestates --filters name=instance-id,Values=i-5309c21e"]

# Generated at 2022-06-24 05:51:51.850971
# Unit test for function match
def test_match():
    assert match(Command('aws', output='usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, maybe you meant:   cloudtrail  \n\naws <command> <subcommand> [<subcommand> ...] [parameters]\naws: error: argument subcommand: Invalid choice, maybe you meant:   delete-trail  describe-trails\n\nSee \'aws help\' for descriptions of global parameters.\n'))

# Generated at 2022-06-24 05:51:59.777805
# Unit test for function get_new_command
def test_get_new_command():
    command = type("Command", (object,), {"script": "aws ec2 terminate-instances", "output": "Invalid choice: 'terminate-instance', maybe you meant:\n* terminate-instances\n"})
    assert get_new_command(command) == ['aws ec2 terminate-instances']
    command = type("Command", (object,), {"script": "aws ec2 terminate-instance instanceId", "output": "Invalid choice: 'terminate-instance', maybe you meant:\n* terminate-instances\n"})
    assert get_new_command(command) == ['aws ec2 terminate-instances instanceId']

# Generated at 2022-06-24 05:52:03.282233
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2  decribe-instances --versoin', '')) == ['aws ec2 describe-instances --versoin','aws ec2 describe-instances --version']

# Generated at 2022-06-24 05:52:07.743788
# Unit test for function match
def test_match():
    for cmd in ['aws s3 ls', 'aws ec2']:
        assert match(Command(script=cmd, output='usage: aws [options] <command> <subcommand> [parameters]\n\naws: error: argument command: Invalid choice: \'"ec2"\', maybe you meant: ec2\n* ec2\n* ec2wait',
                             stderr='usage: aws [options] <command> <subcommand> [parameters]\n\naws: error: argument command: Invalid choice: \'"s3"\', maybe you meant: s3\n* s3\n* s3api'))

# Generated at 2022-06-24 05:52:10.413276
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws help --api <some-parameter>')
    assert get_new_command(command) == [
        'aws help --api api_gateway',
        'aws help --api apigateway']

# Generated at 2022-06-24 05:52:17.342571
# Unit test for function get_new_command

# Generated at 2022-06-24 05:52:22.175294
# Unit test for function match
def test_match():
    output = '''usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
aws: error: argument command: Invalid choice, maybe you meant:
* codecommit
* configservice
* cloudformation
  To see help text, you can run:

    aws help
    aws <command> help
    aws <command> <subcommand> help

'''
    assert match(Command('aws codecommit', output=output))


# Generated at 2022-06-24 05:52:28.605401
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances', 
    '''Unknown options: --query, --filters, Name=tag-value,Values=test
usage: aws [options] <command> <subcommand> [parameters]
aws: error: argument subcommand: Invalid choice, maybe you meant:
    instance    (possible choices: )
    instances   (possible choices: )
    interface   (possible choices: )
    internet    (possible choices: )''', ''))



# Generated at 2022-06-24 05:52:36.927752
# Unit test for function get_new_command

# Generated at 2022-06-24 05:52:42.492693
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.aws import get_new_command
    assert get_new_command(Command(script='aws help')) == \
        [Command(script='aws help', stderr='aws: error: argument operation: Invalid choice: \'help\', maybe you meant:',
         stdout='aws: error: argument operation: Invalid choice: \'help\', maybe you meant:\n\n  * help\n  * helper',
         status=1)]