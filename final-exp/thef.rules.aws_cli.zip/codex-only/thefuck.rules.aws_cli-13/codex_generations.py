

# Generated at 2022-06-24 05:42:44.120948
# Unit test for function match
def test_match():
    assert match(Command(script='aws', stderr='usage: aws [options] [ ...] [parameters]\nTo see help text, you can run:\naws help aws\naws help\n\nUnknown options: --update-user-packages\nmaybe you meant: --update-user\naws: error: argument command: Invalid choice: \'--update-user-packages\', maybe you meant:\n\tassume-role\t\t\tAssumeRole\n\tsupport\t\t\tCreateCase\naws: error: argument command: Invalid choice: \'--update-user-packages\', maybe you meant:\n\tassume-role\t\t\tAssumeRole\n\tsupport\t\t\tCreateCase\n'))



# Generated at 2022-06-24 05:42:52.186450
# Unit test for function get_new_command
def test_get_new_command():
    class Command:
        def __init__(self,output,script):
            self.output = output
            self.script = script

    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument operation: Invalid choice: 'ec2 describe-images', maybe you meant:
* describe-images
* describe-images-by-owner"""
    script = "aws ec2 describe-iamges s3"
    command = Command(output,script)
    assert get_new_command(command) == [
        "aws ec2 describe-images s3",
        "aws ec2 describe-images-by-owner s3"]

# Generated at 2022-06-24 05:42:59.097379
# Unit test for function match

# Generated at 2022-06-24 05:43:04.331974
# Unit test for function match
def test_match():
    assert match(Command('aws', output=''))
    assert match(Command('aws', output='usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]'))
    assert match(Command('aws', output="Invalid choice: 'dynamodb', maybe you meant: delete-item, describe-table, get-item, list-tables"))



# Generated at 2022-06-24 05:43:13.306835
# Unit test for function get_new_command
def test_get_new_command():
    test_command = "aws --version"
    test_command_output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

Invalid choice: '--version', maybe you meant:
  certificate
  config
  create-access-key
  ec2
  ec2-instance-connect
  help
  iam
  kms
  lambda
  ssm
  sts
  support

"""

# Generated at 2022-06-24 05:43:22.647299
# Unit test for function match
def test_match():
    output = '''
A client error (InvalidAccessKeyId) occurred when calling the ListBuckets operation: The AWS Access Key Id you provided does not exist in our records.
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, maybe you meant:
  enable-logging   permission-boundary   set-cors-configuration'''
    result = match(Command('aws subcommand', output=output))
    assert result


# Generated at 2022-06-24 05:43:25.147596
# Unit test for function get_new_command
def test_get_new_command():
    test_command = "aws s3 ls --no-such-option"
    assert get_new_command(test_command) == ["aws s3 ls --no-such-option", "aws s3 ls --no-sign-request"]

enabled_by_default = True

# Generated at 2022-06-24 05:43:32.017643
# Unit test for function get_new_command

# Generated at 2022-06-24 05:43:34.435252
# Unit test for function match
def test_match():
    assert match(Command('aws', 'Invalid choice: \'s3\' \, maybe you meant:', ''))
    assert not match(Command('aws', '', ''))


# Generated at 2022-06-24 05:43:45.634123
# Unit test for function get_new_command
def test_get_new_command():
    new_cmd = get_new_command(Command("aws --profile user ec2 describe-instance", "Invalid choice: '--profile', maybe you meant:\n  --profile\n\n  --recursive\n\n  --region\n\n  --debug\n\n  --version\n\n  --no-verify-ssl\n\n  --endpoint-url"))
    assert new_cmd == ["aws --profile user ec2 describe-instance", "aws --recursive user ec2 describe-instance", "aws --region user ec2 describe-instance", "aws --debug user ec2 describe-instance", "aws --version user ec2 describe-instance", "aws --no-verify-ssl user ec2 describe-instance", "aws --endpoint-url user ec2 describe-instance"]

# Generated at 2022-06-24 05:43:55.052878
# Unit test for function match
def test_match():
    #unit test for aws command with undefined user
    assert match(Command('aws help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, valid choices are:\n\ns3\n\n', ''))
    #unit test for aws command with defined user

# Generated at 2022-06-24 05:44:01.796604
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('aws sqs blah blah blah', 'usage: blah blah blah\n   blah blah blah\n   blah blah blah\n\nInvalid choice: \'blah\', maybe you meant:\n   *  blah-blah -- blah blah blah\n   *  blah-blah -- blah blah blah\n   blah blah blah\n   blah blah blah\n   blah blah blah\n\n')) == ['aws sqs blah-blah', 'aws sqs blah-blah'])

# Generated at 2022-06-24 05:44:08.585918
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-instances no-such-option')) == ['aws ec2 describe-instances --no-dry-run']
    assert get_new_command(Command('aws ec2 describe-instances --no-dry-run --region us-west-2 no-such-option')) == ['aws ec2 describe-instances --region us-west-2 --no-dry-run']
    assert get_new_command(Command('aws ec2 describe-instances --region us-west-2 --no-dry-run no-such-option')) == ['aws ec2 describe-instances --no-dry-run --region us-west-2']

# Generated at 2022-06-24 05:44:18.626505
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('aws s3 lsl', 'aws: error: argument operation: Invalid choice, maybe you meant: ls\n* ls\n\n')) == ['aws s3 ls']
    assert get_new_command(Command('aws s3 lsl', 'aws: error: argument operation: Invalid choice, maybe you meant: ls\n* ls\n* mb\n* rb\n* cp\n* mv\n* rm\n* sync\n* website\n\n')) == ['aws s3 ls', 'aws s3 mb', 'aws s3 rb', 'aws s3 cp', 'aws s3 mv', 'aws s3 rm', 'aws s3 sync', 'aws s3 website']

# Generated at 2022-06-24 05:44:26.798591
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws ec2 delete-key-pair --key-name nonkey"
    command = Command(script, "usage: aws [options] <command> <subcommand> [<subcommand> ...]     [parameters]   To see help text, you can run:   aws help   aws <command> help   aws <command> <subcommand> help   Unknown options: --key-name   Invalid choice: '--key-name', maybe you meant:   * --kms-key-id    * --key-id")
    assert get_new_command(command) == [
        "aws ec2 delete-key-pair --kms-key-id nonkey",
        "aws ec2 delete-key-pair --key-id nonkey"]

# Generated at 2022-06-24 05:44:32.473690
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command("aws ec2 describe-instance-status --instance-id i-12345678",
                     "Invalid choice: 'i-12345678', maybe you meant:\n  dependencies\n  i-abcd1234")
    assert get_new_command(cmd) == ["aws ec2 describe-instance-status --instance-id dependencies", "aws ec2 describe-instance-status --instance-id i-abcd1234"]

# Generated at 2022-06-24 05:44:40.046193
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'usage: aws [options] [parameters]\nAn error occurred (InvalidOption) when calling the MyCommand operation: Invalid option i\n', stderr='usage: aws [options] [parameters]\nAn error occurred (InvalidOption) when calling the MyCommand operation: Invalid option i\nAt least one of the following arguments must be specified: foo\nMaybe you meant:\n* bar'))
    assert not match(Command('aws help', 'usage: aws [options] [parameters]\nAn error occurred (InvalidOption) when calling the MyCommand operation: Invalid argument bar\nAt least one of the following arguments must be specified: foo\nMaybe you meant:\n* bar'))

# Generated at 2022-06-24 05:44:41.110433
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command()

# Generated at 2022-06-24 05:44:52.162841
# Unit test for function get_new_command
def test_get_new_command():
    a = "aws elbv2 --help"
    b = command.Command(a, "/bin/aws elbv2 --help", "Invalid choice: 'elbv2', maybe you meant:\n  * elbv2describetargetgroups"
                                                                                           " --alb\n    Display help for the all_groups command.\n  * elbv2describetargetgroups --help\n    Displ", "aws_help_nocomplete_underline")
    c = get_new_command(b)
    print(c)


# def test_get_new_command3():
#     a = "aws elbv2 --help"
#     b = command.Command(a, "/bin/aws elbv2 --help", "Invalid choice: 'elbv2', maybe you meant:\n 

# Generated at 2022-06-24 05:44:55.012309
# Unit test for function match
def test_match():
    assert match(Command('aws', 'Invalid choice: "--help", maybe you meant: "help"'))
    assert not match(Command('ls', 'Invalid choice: "--help", maybe you meant: "help"'))


# Generated at 2022-06-24 05:45:02.165682
# Unit test for function get_new_command

# Generated at 2022-06-24 05:45:09.668049
# Unit test for function match
def test_match():
    assert match(Command('aws cloudfront', 'usage: aws [options] <command> ...\nInvalid choice: \'cloudfront\', maybe you meant:\n  * configure\n  * configure\n  * configure\n  * configure\n  * configure\n  * configure\n  * configure\n  * configure\n  * configure\n  * configure\n  * configure\n  * configure\n  * configure\n  * configure\n  * configure\n  * configure\n'))


# Generated at 2022-06-24 05:45:18.561192
# Unit test for function match
def test_match():
    assert(match(Command("aws ec2 start-instances --instance-ids i-0004fd0fd007a0b89", "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\naws: error: argument subcommand: Invalid choice, maybe you meant:\n  stop-instances\n  start-instance\n  describe-instances\n  reboot-instances\n  run-instances\n   * start-instances\n  terminate-instances\n  modify-instances\n  monitor-instances\n  unmonitor-instances\n")) == True)

# Generated at 2022-06-24 05:45:20.004923
# Unit test for function match
def test_match():
    cmd = Command('aws s3 ls')
    assert match(cmd) is False


# Generated at 2022-06-24 05:45:22.008455
# Unit test for function match
def test_match():
    assert match(Command('aws help', ''))
    assert not match(Command('ls help', ''))



# Generated at 2022-06-24 05:45:33.930992
# Unit test for function match

# Generated at 2022-06-24 05:45:34.898709
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 list-instance', ''))


# Generated at 2022-06-24 05:45:46.120779
# Unit test for function match
def test_match():
    assert match(Command('aws s3:help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n  aws: error: argument subcommand: Invalid choice, maybe you meant:\n      sync?\n--help\n--version'))
    assert match(Command('aws s3:help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n  aws: error: argument subcommand: Invalid choice, maybe you meant:\n      sync?\n--help\n--version'))

# Generated at 2022-06-24 05:45:54.878603
# Unit test for function match

# Generated at 2022-06-24 05:46:06.209770
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws cloudformation describe-stacks'

# Generated at 2022-06-24 05:46:13.732048
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://bucket-name/',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
                         'aws: error: argument subcommand: Invalid choice, maybe you meant:\n'
                         '\tmb\n\tmv\n\tmb\n\tcp\n\tls\n\trm\n\tsync\n\tpresign\n\twebsite'))



# Generated at 2022-06-24 05:46:24.424271
# Unit test for function get_new_command
def test_get_new_command():
    command_input = 'aws: error: argument subcommand: Invalid choice: \'cognitio\', maybe you meant:\n\n  * cognito-idp'

# Generated at 2022-06-24 05:46:27.078835
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws --version"
    result = [
        "aws --version",
        "aws --version",
        "aws --version",
    ]
    assert get_new_command(command) == result

# Generated at 2022-06-24 05:46:32.239572
# Unit test for function match
def test_match():
    assert match(Command('aws ec2create-vol --size=30G --region=eu-west-1',
        'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]',
        'To see help text, you can run:\n'))


# Generated at 2022-06-24 05:46:39.955291
# Unit test for function match

# Generated at 2022-06-24 05:46:48.119486
# Unit test for function get_new_command
def test_get_new_command():
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\n        To see help text, you can run:\n\n            aws help\n            aws <command> help\n            aws <command> <subcommand> help\n\n        Invalid choice: '-h', maybe you meant: \n            -h, --help\n    *   --help\n\nUnknown options: -h\n"
    command = "aws -h"
    expected = ["aws --help", "aws -h, --help"]
    assert get_new_command(Command(script=command, output=output)) == expected

# Generated at 2022-06-24 05:46:56.041448
# Unit test for function get_new_command
def test_get_new_command():
    mistake = 's3'
    options = ['s3api', 's3api']
    script = 'aws s3'
    assert get_new_command(FakeCommand('aws s3', mistake, options, script)) == ['aws s3api', 'aws s3api']
    assert get_new_command(FakeCommand('aws', mistake, options, script)) == ['aws s3api', 'aws s3api']
    assert get_new_command(FakeCommand('', mistake, options, script)) == [' s3api', ' s3api']


# Generated at 2022-06-24 05:47:02.233746
# Unit test for function get_new_command

# Generated at 2022-06-24 05:47:13.857884
# Unit test for function match
def test_match():
    output_a = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n" \
               "To see help text, you can run:\n" \
               "aws help\n" \
               "aws <command> help\n" \
               "aws <command> <subcommand> help\n" \
               "aws: error: argument subcommand: Invalid choice, maybe you meant:\n" \
               "    config       configure the AWS Command Line Interface\n" \
               "    dynamodb     Amazon DynamoDB (DynamoDB Local) is a fast, fully-managed, highly scalableNo" \
               "SQL database\n" \
               "    ec2          Amazon Elastic Compute Cloud\n"


# Generated at 2022-06-24 05:47:16.769691
# Unit test for function match
def test_match():
    command1 = Command(script = "aws ec2 describe-instances")
    command2 = Command(script = "aws ec2 cdescribe-instances")
    assert match(command1)
    assert match(command2)


# Generated at 2022-06-24 05:47:23.821864
# Unit test for function match
def test_match():
    match_output_text = "usage: aws [options] <command> <subcommand> [parameters]"
    invalid_commands = ['aws --help', "aws --help subcommand"]
    valid_command = "aws --help invalid_subcommand"
    assert match(Command(valid_command, match_output_text))

# Generated at 2022-06-24 05:47:30.598139
# Unit test for function match
def test_match():
    assert match(Command('aws help', ''))
    assert match(Command('aws help', 'usage:'))
    assert match(Command('aws help', 'usage:', ''))
    assert match(Command('aws help', 'Some help text', ''))
    assert match(Command('aws help', 'Usage:', ''))
    assert not match(Command('ls', ''))
    assert not match(Command('ls', 'usage:', ''))
    assert not match(Command('ls', 'usage:', '', ''))
    assert not match(Command('ls', 'usage:', '', ''))
    assert not match(Command('ls', 'Some help text', ''))


# Generated at 2022-06-24 05:47:39.872341
# Unit test for function match

# Generated at 2022-06-24 05:47:43.512373
# Unit test for function match
def test_match():
    assert match(Command('aws foo', 'usage:\nfoo is a bad option\nmaybe you meant: bar\n'))
    assert not match(Command('aws foo', 'usage:\nfoo is a bad option\n'))

# Generated at 2022-06-24 05:47:50.654548
# Unit test for function match

# Generated at 2022-06-24 05:48:01.811986
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 stop-instance --instance-ids i-12345678',
        output='usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
        'aws: error: argument instance-ids: Invalid choice: '
        '\'i-12345678\', maybe you meant: \n* i-123456789\n* i-12345\n* i-345678')) == \
        ['aws ec2 stop-instance --instance-ids i-123456789', 'aws ec2 stop-instance --instance-ids i-12345', 'aws ec2 stop-instance --instance-ids i-345678']

# Generated at 2022-06-24 05:48:10.788391
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-regions', 'usage:', 'Invalid choice: \'ec2 describe-regions\', maybe you meant:')).output == "Invalid choice: 'ec2 describe-regions', maybe you meant:"
    assert match(Command('aws ec2 describe-regions', 'usage:', 'Invalid choice: \'ec2\', maybe you meant:')).output == "Invalid choice: 'ec2', maybe you meant:"
    assert match(Command('aws ec2 describe-regions', 'usage:', 'Invalid choice: \'ec2 describe-regons\', maybe you meant:')).output == "Invalid choice: 'ec2 describe-regons', maybe you meant:"
    assert match(Command('aws ec2 describe-regions', 'usage:', 'Invalid choice: \'ec2 describe-regiuns\', maybe you meant:')).output

# Generated at 2022-06-24 05:48:17.462459
# Unit test for function match
def test_match():
	# Invalid command
	assert not match(Command('aws s3 ls', 'usage: aws [options]', 'Invalid choice: \'s3\', maybe you meant:', '', 1)) 
	# Valid command
	assert match(Command('aws ec2 ls', 'usage: aws [options]', 'Invalid choice: \'ec2\', maybe you meant:', '', 1)) 


# Generated at 2022-06-24 05:48:23.442595
# Unit test for function get_new_command
def test_get_new_command():
    def _assert(script, mistake, output):
        assert get_new_command(Command('aws ' + script, output)) == [replace_argument('aws ' + script, mistake, o) for o in ['Option_A', 'Option_B']]
    _assert('command', 'mistake', 'Invalid choice: \'mistake\', maybe you meant:\n  * Option_A\n  * Option_B')

# Generated at 2022-06-24 05:48:26.161972
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 run-instances --image-id ami-123', ''))


# Generated at 2022-06-24 05:48:34.606179
# Unit test for function get_new_command
def test_get_new_command():
    command = type('obj', (object,), {
        'output': 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice: "s3"\nMaybe you meant:\n    service',
        'script': 'aws s3 ls'
    })
    assert "['aws service ls']" == str(get_new_command(command))

# Generated at 2022-06-24 05:48:43.369559
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 help', 'Unknown options'))
    assert match(Command('aws ec2 dhelp', 'Unknown options'))
    assert not match(Command('aws ec2 h', 'Unknown options'))
    assert not match(Command('aws ec2 dhelp',
        'usage: aws [options] <command> <subcommand> [<subcommand> ..] [parameters]\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n  dms'))


# Generated at 2022-06-24 05:48:50.936766
# Unit test for function match

# Generated at 2022-06-24 05:48:55.130426
# Unit test for function match
def test_match():
    assert match(Command('aws-help', "usage: aws [options] <command> <subcommand> [parameters]"
                           "Invalid choice: 'aws-help', maybe you meant:"
                           "* sts", '', ''))


# Generated at 2022-06-24 05:49:05.985945
# Unit test for function get_new_command

# Generated at 2022-06-24 05:49:13.082519
# Unit test for function match

# Generated at 2022-06-24 05:49:24.112036
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws backup list-backup-plans --backup-plan-ids a8c6f791-78f3-4c73-8668-f4972b9a9dde"

# Generated at 2022-06-24 05:49:32.371308
# Unit test for function get_new_command
def test_get_new_command():
    command = type("obj", (object,),
                   {"script": 'aws ec2 create-volume --size 5 --instance-id i-12345678 --volume-type gp2',
                    "output": 'usage: aws [options] <command> <subcommand> [parameters]\n[aws: error: argument \
                    --instance-id: Invalid choice: \'i-12345678\', maybe you meant:\n\n* i-123456789\n\n\
                    You can also use \'--instance-id \'\n]\naws: error: argument --instance-id: Invalid choice: \
                    \'i-12345678\', maybe you meant:\n\n* i-123456789\n\nYou can also use \'--instance-id \'\n'})

# Generated at 2022-06-24 05:49:42.671966
# Unit test for function match
def test_match():
    script = "aws s3 sync s3://this-is-a-test s3://this-is-not-a-test --delete"
    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
aws: error: argument subcommand: Invalid choice, valid choices are:
cp                          | sync
ls                          | mb
mb                          | rb
rb                          | presign
presign                     | configure
configure                   | help
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

Invalid choice: 'sync', maybe you meant:
        cp
        ls

    """
    assert match(Command(script, output))

# Generated at 2022-06-24 05:49:53.519049
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.aws_cli import get_new_command
    def test(command, match):
        new_command = get_new_command(command)
        assert len(new_command) > 0
        assert any([m.search(c) for c in new_command
                    for m in match])
        assert all([isinstance(c, str) for c in new_command])

# Generated at 2022-06-24 05:50:04.890758
# Unit test for function get_new_command
def test_get_new_command():
    original_command = 'aws ec2 describe-instances'

# Generated at 2022-06-24 05:50:14.389287
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws help', 'aws --help\nUsage: aws [options] [parameters]\n--help', None))==[
        Command('aws help', 'aws --help\nUsage: aws [options] [parameters]\n--help', None)]
    assert get_new_command(Command('aws', 'aws: error: argument --profile: Invalid choice: \'foo\', maybe you meant: \'force\'', None))==[Command('aws', 'aws: error: argument --profile: Invalid choice: \'foo\', maybe you meant: \'force\'', None)]

# Generated at 2022-06-24 05:50:18.572608
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://test/',
                         'An error occurred (BucketAlreadyOwnedByYou) when calling the CreateBucket operation: Your previous request to create the named bucket succeeded and you already own it.'))
    assert not match(Command('aws s3 mb s3://test/',
                             ''))



# Generated at 2022-06-24 05:50:29.805196
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws ec2 describe-images --owner amazon --filter \"Name=platform,Values=windows\""

# Generated at 2022-06-24 05:50:40.154922
# Unit test for function match

# Generated at 2022-06-24 05:50:43.266070
# Unit test for function match
def test_match():
    assert match(Command('aws', 'usage: aws [options] <command> <subcommand> [parameters]', 'help'))
    assert not match(Command('ls', 'usage: ls [options] <command> <subcommand> [parameters]', 'help'))



# Generated at 2022-06-24 05:50:55.333246
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws ec2 describe-volumes --volume-ids vol-00000000 vol-00000001'
    command_output = 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nInvalid choice: \'vol-00000000 vol-00000001\', maybe you meant:\n\n   * vol-00000000\n   * vol-00000001'
    new_command = get_new_command(Command(command, output=command_output))
    assert new_command == ['aws ec2 describe-volumes --volume-ids vol-00000000',
                           'aws ec2 describe-volumes --volume-ids vol-00000001']



# Generated at 2022-06-24 05:51:03.483716
# Unit test for function match
def test_match():
    assert match(Command("aws --version", "$ aws --version\naws-cli/1.11.58 Python/2.7.12 Linux/4.2.0-27-generic botocore/1.5.30"))

# Generated at 2022-06-24 05:51:06.279468
# Unit test for function match
def test_match():
    assert match(Command('whatever', output='Invalid choice: \'kms\', maybe you meant:', script='aws'))

# Generated at 2022-06-24 05:51:11.969526
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.aws_command_abbreviations import get_new_command

# Generated at 2022-06-24 05:51:18.332151
# Unit test for function get_new_command
def test_get_new_command():
    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
  To see help text, you can run:

    aws help
    aws <command> help
    aws <command> <subcommand> help

Unknown options: 'ss', maybe you meant:
  * s3
  * sts
  * ssm
aws: error: argument operation: Invalid choice, valid choices are:
"""
    command = "aws s3 sss"
    assert get_new_command(command) == ["aws s3 s3",
                                        "aws s3 sts",
                                        "aws s3 ssm"]



# Generated at 2022-06-24 05:51:21.945194
# Unit test for function get_new_command
def test_get_new_command():
    command = get_new_command('aws ec2 usag:')
    assert command == ['aws ec2 usage']
    command = get_new_command('aws ec2 usages:')
    assert command == ['aws ec2 usages']



# Generated at 2022-06-24 05:51:31.031078
# Unit test for function get_new_command

# Generated at 2022-06-24 05:51:41.399770
# Unit test for function match
def test_match():
    assert match(Command('aws', 'usage: aws [options] <command> <subcommand> [parameters]\n'
                         'aws: error: argument --ami-launch-index: Invalid choice: \'4\', maybe you meant:\n'
                         '* --ami-launch-index\n'
                         '* --block-device-mapping'))
    assert not match(Command('aws', 'usage: aws [options] <command> <subcommand> [parameters]\n'
                             'aws: error: argument --ami-launch-index: Invalid choice: \'4\'\n'
                             '* --ami-launch-index\n'
                             '* --block-device-mapping'))


# Generated at 2022-06-24 05:51:45.225107
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 help', ''))
    assert not match(Command('ls s3://test-bucket', '',
                             "A client error (NoSuchBucket) occurred when calling the ListObjects operation: The specified bucket does not exist"))

# Generated at 2022-06-24 05:51:52.158869
# Unit test for function match
def test_match():
    command = Command('aws help', 'aws: error: argument command: Invalid choice: \'help\', maybe you meant:\n  configure  Credentials and configuration settings\n  events     Manage CloudTrail events\n  help       Display help about available commands\n  iam        Manage users and their associated access keys\n  lambda     Manage AWS Lambda functions\n  s3         Manage Amazon S3 buckets and items\n  ssm        Manage EC2 Simple Systems Manager parameters\n  sts        Obtain temporary credentials\n')
    assert match(command)



# Generated at 2022-06-24 05:52:01.698149
# Unit test for function get_new_command

# Generated at 2022-06-24 05:52:11.119435
# Unit test for function get_new_command
def test_get_new_command():
    # Set command
    command = type("Command", (object,), {
        'script': 'aws ec2 authorize-security-group-ingress --group-name None --source-group None --source-group-owner None --port None --protocol None',
        'output': 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --group-name: Invalid choice, maybe you meant:\n* group-id\n* group\n\nUnknown options: --source-group, --source-group-owner, --port, --protocol\n'
    })
    # Get actual new command
    actual

# Generated at 2022-06-24 05:52:13.409802
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command('aws ec2 help')
    assert get_new_command(command) == [
        'aws ec2 help']

# Generated at 2022-06-24 05:52:21.650444
# Unit test for function match

# Generated at 2022-06-24 05:52:31.799558
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws cloudformation create-stack --stack-name aws-opsworks-cm-server-ha-dev --template-body file://dev-ha-quickstart.yaml --parameters ParameterKey=ProductName,ParameterValue=Chef --capabilities CAPABILITY_IAM --region us-east-1'
    new_command = get_new_command(command)

# Generated at 2022-06-24 05:52:36.036686
# Unit test for function get_new_command
def test_get_new_command():
    # Test 1
    command1 = make_command('aws: test')
    assert get_new_command(command1) == [
                                    "aws test",
                                    "aws ec2 test",
                                    "aws s3 test"
                                    ]