

# Generated at 2022-06-18 07:18:11.061035
# Unit test for function match

# Generated at 2022-06-18 07:18:20.964865
# Unit test for function match

# Generated at 2022-06-18 07:18:31.691497
# Unit test for function match

# Generated at 2022-06-18 07:18:39.773479
# Unit test for function get_new_command

# Generated at 2022-06-18 07:18:49.530801
# Unit test for function match

# Generated at 2022-06-18 07:18:58.772137
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n  ls\n  mb\n  rb\n  sync\n  website\n\n'))

# Generated at 2022-06-18 07:19:06.524414
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances --region us-east-1 --instance-ids i-1234567890abcdef0',
                      'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
                      'aws: error: argument instance-ids: Invalid choice: '
                      "'i-1234567890abcdef0', maybe you meant: 'i-1234567890abcdef0'")
    assert get_new_command(command) == ['aws ec2 describe-instances --region us-east-1 --instance-ids i-1234567890abcdef0']

# Generated at 2022-06-18 07:19:13.696005
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances --region us-east-1',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n\n  describe-instances\n  describe-instances-status\n  describe-instance-status\n\n'))


# Generated at 2022-06-18 07:19:21.066294
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\naws: error: argument command: Invalid choice, maybe you meant:\n  ls\n  mb\n  rb\n  cp\n  mv\n  rm\n  sync\n  website\n  s3api\n  s3control\n  configure\n')) == ['aws s3 ls', 'aws s3 mb', 'aws s3 rb', 'aws s3 cp', 'aws s3 mv', 'aws s3 rm', 'aws s3 sync', 'aws s3 website', 'aws s3 s3api', 'aws s3 s3control', 'aws s3 configure']

# Generated at 2022-06-18 07:19:32.288722
# Unit test for function get_new_command

# Generated at 2022-06-18 07:19:43.121424
# Unit test for function get_new_command

# Generated at 2022-06-18 07:19:54.380089
# Unit test for function match

# Generated at 2022-06-18 07:20:05.169249
# Unit test for function match

# Generated at 2022-06-18 07:20:12.422670
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, valid choices are:\n\n  cp\n  ls\n  mb\n  mv\n  presign\n  rb\n  rm\n  sync\n  website\n\nmaybe you meant:\n\n  s3\n'))


# Generated at 2022-06-18 07:20:19.965469
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\naws: error: argument subcommand: Invalid choice: \'ls\', maybe you meant: \n  * ls-bucket\n  * ls-buckets\n  * ls-objects\n\n')) == ['aws s3 ls-bucket', 'aws s3 ls-buckets', 'aws s3 ls-objects']

# Generated at 2022-06-18 07:20:29.897790
# Unit test for function match

# Generated at 2022-06-18 07:20:40.623424
# Unit test for function match

# Generated at 2022-06-18 07:20:52.532163
# Unit test for function match

# Generated at 2022-06-18 07:21:03.113979
# Unit test for function match

# Generated at 2022-06-18 07:21:09.907528
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n  describe-instances\n  describe-instance-status\n  describe-instance-attribute\n  describe-instance-credit-specifications\n  describe-instances-modifications\n  describe-instance-types\n  describe-instance-status\n  describe-instance-attribute\n  describe-instance-credit-specifications\n  describe-instances-modifications\n  describe-instance-types\n\n'))

# Generated at 2022-06-18 07:21:22.533210
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances --filters Name=instance-state-name,Values=running',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --filters: Invalid choice: \'Name=instance-state-name,Values=running\', maybe you meant:',
                         'aws ec2 describe-instances --filters Name=instance-state-name,Values=running'))

# Generated at 2022-06-18 07:21:31.220145
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, valid choices are:\n\n  cp\n  ls\n  mb\n  mv\n  rb\n  rm\n  sync\n  website\n\n'))


# Generated at 2022-06-18 07:21:40.420703
# Unit test for function get_new_command

# Generated at 2022-06-18 07:21:52.378370
# Unit test for function match

# Generated at 2022-06-18 07:22:01.567120
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-instances --filters Name=instance-state-code,Values=16', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --filters: Invalid choice: \'Name=instance-state-code,Values=16\', maybe you meant:', 'aws ec2 describe-instances --filters Name=instance-state-code,Values=16')) == ['aws ec2 describe-instances --filters Name=instance-state-name,Values=running']

# Generated at 2022-06-18 07:22:09.699229
# Unit test for function get_new_command

# Generated at 2022-06-18 07:22:18.868259
# Unit test for function match

# Generated at 2022-06-18 07:22:28.795934
# Unit test for function get_new_command

# Generated at 2022-06-18 07:22:37.203128
# Unit test for function get_new_command

# Generated at 2022-06-18 07:22:45.951876
# Unit test for function get_new_command

# Generated at 2022-06-18 07:22:57.692007
# Unit test for function match

# Generated at 2022-06-18 07:23:08.182679
# Unit test for function match

# Generated at 2022-06-18 07:23:18.020757
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, valid choices are:\n\n  cp\n  ls\n  mb\n  mv\n  rb\n  rm\n  sync\n  website\n\nmaybe you meant:\n\n  s3'))

# Generated at 2022-06-18 07:23:28.907091
# Unit test for function get_new_command

# Generated at 2022-06-18 07:23:39.052824
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-instances --filters Name=instance-state-code,Values=16', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --filters: Invalid choice: \'Name=instance-state-code,Values=16\', maybe you meant:', 'aws ec2 describe-instances --filters Name=instance-state-code,Values=16')) == ['aws ec2 describe-instances --filters Name=instance-state-name,Values=running']

# Generated at 2022-06-18 07:23:44.944097
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, valid choices are:\n\n  cp\n  ls\n  mb\n  mv\n  rb\n  rm\n  sync\n  website\n\n'))


# Generated at 2022-06-18 07:23:55.709426
# Unit test for function get_new_command

# Generated at 2022-06-18 07:24:06.412793
# Unit test for function match

# Generated at 2022-06-18 07:24:14.307025
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls', 'aws: error: argument subcommand: Invalid choice: \'ls\', maybe you meant: \n* ls\n* mb\n* rb\n* cp\n* mv\n* rm\n* sync\n* website\n* s3api\n* s3control\n* configure')) == ['aws s3 ls', 'aws s3 mb', 'aws s3 rb', 'aws s3 cp', 'aws s3 mv', 'aws s3 rm', 'aws s3 sync', 'aws s3 website', 'aws s3 s3api', 'aws s3 s3control', 'aws s3 configure']

# Generated at 2022-06-18 07:24:21.735880
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances', 'aws: error: argument command: Invalid choice: \'describe-instances\', maybe you meant:\n  * describe-instance-status\n  * describe-instance-attribute\n  * describe-instances-status\n\nSee \'aws help\' for descriptions of global parameters.\n')
    assert get_new_command(command) == ['aws ec2 describe-instance-status', 'aws ec2 describe-instance-attribute', 'aws ec2 describe-instances-status']

# Generated at 2022-06-18 07:24:34.997862
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances --filters Name=instance-state-name,Values=running')
    assert get_new_command(command) == ['aws ec2 describe-instances --filters Name=instance-state-name,Values=running']
    command = Command('aws ec2 describe-instances --filters Name=instance-state-name,Values=running --region us-east-1')
    assert get_new_command(command) == ['aws ec2 describe-instances --filters Name=instance-state-name,Values=running --region us-east-1']
    command = Command('aws ec2 describe-instances --filters Name=instance-state-name,Values=running --region us-east-1 --output text')

# Generated at 2022-06-18 07:24:44.373842
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, valid choices are:\n\n  cp\n  ls\n  mb\n  mv\n  rb\n  rm\n  sync\n  website\n\nmaybe you meant:\n  s3'))

# Generated at 2022-06-18 07:24:54.587262
# Unit test for function match

# Generated at 2022-06-18 07:25:04.169216
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances --filters Name=instance-state-code,Values=48 Name=instance-state-name,Values=terminated --query "Reservations[*].Instances[*].{Instance:InstanceId,Name:Tags[?Key==`Name`]|[0].Value}"')
    assert get_new_command(command) == ['aws ec2 describe-instances --filters Name=instance-state-code,Values=48 Name=instance-state-name,Values=terminated --query "Reservations[*].Instances[*].{Instance:InstanceId,Name:Tags[?Key==`Name`]|[0].Value}"']

# Generated at 2022-06-18 07:25:13.282978
# Unit test for function match
def test_match():
    assert match(Command('aws', output='usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice: \'s3\', maybe you meant:\n    s3api\n    s3'))

# Generated at 2022-06-18 07:25:23.880886
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-18 07:25:34.888859
# Unit test for function match

# Generated at 2022-06-18 07:25:44.354885
# Unit test for function match

# Generated at 2022-06-18 07:25:52.274287
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, valid choices are:\n\nconfigure\nhelp\n\nUnknown options: s3, ls\n'))

# Generated at 2022-06-18 07:26:03.496020
# Unit test for function match

# Generated at 2022-06-18 07:26:15.981216
# Unit test for function match

# Generated at 2022-06-18 07:26:22.300856
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances --filters Name=instance-state-name,Values=running',
                      'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
                      'aws: error: argument subcommand: Invalid choice: \'--filters\', maybe you meant:\n'
                      '\n'
                      '\tflowlogs\n'
                      '\tfilter\n'
                      '\t\n'
                      '\n'
                      'For more information, run \'aws help\'\n')
    assert get_new_command(command) == ['aws ec2 describe-instances flowlogs', 'aws ec2 describe-instances filter']

# Generated at 2022-06-18 07:26:31.317146
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances --filters Name=instance-state-name,Values=running', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --filters: Invalid choice: \'Name=instance-state-name,Values=running\', maybe you meant:')
    assert get_new_command(command) == ['aws ec2 describe-instances --filters Name=instance-state-name,Values=running']

# Generated at 2022-06-18 07:26:41.067748
# Unit test for function match

# Generated at 2022-06-18 07:26:50.617225
# Unit test for function match

# Generated at 2022-06-18 07:27:01.163181
# Unit test for function match

# Generated at 2022-06-18 07:27:11.095024
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, valid choices are:\n\n  cp\n  ls\n  mb\n  mv\n  rb\n  rm\n  sync\n  website\n\nmaybe you meant:\n  s3'))

# Generated at 2022-06-18 07:27:16.968462
# Unit test for function get_new_command

# Generated at 2022-06-18 07:27:27.955388
# Unit test for function match

# Generated at 2022-06-18 07:27:38.434986
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, valid choices are:\n\n  cp\n  ls\n  mb\n  mv\n  rb\n  rm\n  sync\n  website\n\n'))

# Generated at 2022-06-18 07:27:48.877557
# Unit test for function get_new_command

# Generated at 2022-06-18 07:27:59.349576
# Unit test for function match

# Generated at 2022-06-18 07:28:05.493449
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances --filter Name=instance-state-name,Values=running', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\naws: error: argument subcommand: Invalid choice, valid choices are:\n\n* describe-instances\n* describe-tags\n\nmaybe you meant:\n\n* describe-tags')
    assert get_new_command(command) == ['aws ec2 describe-tags --filter Name=instance-state-name,Values=running']