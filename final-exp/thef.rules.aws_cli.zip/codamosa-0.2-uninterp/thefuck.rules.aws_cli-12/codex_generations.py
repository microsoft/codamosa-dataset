

# Generated at 2022-06-18 07:18:10.782119
# Unit test for function get_new_command

# Generated at 2022-06-18 07:18:20.571513
# Unit test for function get_new_command

# Generated at 2022-06-18 07:18:30.742673
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n  ls\n  mb\n  rb\n  s3api\n  sync\n  website\n\n')
    assert get_new_command(command) == ['aws s3 ls', 'aws s3 mb', 'aws s3 rb', 'aws s3 s3api', 'aws s3 sync', 'aws s3 website']

# Generated at 2022-06-18 07:18:38.516118
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, valid choices are:\n\n  cp\n  ls\n  mb\n  mv\n  rb\n  rm\n  sync\n\nmaybe you meant:\n\n  s3\n'))

# Generated at 2022-06-18 07:18:48.358341
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances', 'aws: error: argument command: Invalid choice: \'describe-instances\', maybe you meant:\n  * describe-instance-status\n  * describe-instances-status\n  * describe-instance-attribute\n  * describe-instance-credit-specifications\n  * describe-instance-types\n  * describe-instances\n  * describe-instance-status\n  * describe-instance-attribute\n  * describe-instance-credit-specifications\n  * describe-instance-types\n  * describe-instances\n\nSee \'aws help\' for descriptions of global parameters.\n')

# Generated at 2022-06-18 07:18:57.657400
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances --region us-west-2 --filters Name=instance-state-name,Values=running Name=tag:Name,Values=test', 'aws: error: argument --filters: Invalid choice: \'Name=instance-state-name,Values=running Name=tag:Name,Values=test\', maybe you meant:\n  * --filter\n  * --filters-file')
    assert get_new_command(command) == ['aws ec2 describe-instances --region us-west-2 --filter Name=instance-state-name,Values=running Name=tag:Name,Values=test', 'aws ec2 describe-instances --region us-west-2 --filters-file Name=instance-state-name,Values=running Name=tag:Name,Values=test']

# Generated at 2022-06-18 07:19:03.270078
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-instances --region us-east-1 --output table', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument output: Invalid choice: \'table\', maybe you meant:\n  * text\n  * json\n  * yaml\n')) == ['aws ec2 describe-instances --region us-east-1 --output text', 'aws ec2 describe-instances --region us-east-1 --output json', 'aws ec2 describe-instances --region us-east-1 --output yaml']

# Generated at 2022-06-18 07:19:13.640938
# Unit test for function get_new_command

# Generated at 2022-06-18 07:19:21.248836
# Unit test for function get_new_command

# Generated at 2022-06-18 07:19:32.504612
# Unit test for function get_new_command

# Generated at 2022-06-18 07:19:43.668831
# Unit test for function get_new_command

# Generated at 2022-06-18 07:19:55.053047
# Unit test for function match

# Generated at 2022-06-18 07:20:05.474141
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-instances --region us-east-1 --output text --filters "Name=tag:Name,Values=foo"', 'Invalid choice: \'--output\', maybe you meant: --output-text\n\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n  To see help text, you can run:\n    aws help\n    aws <command> help\n    aws <command> <subcommand> help\naws: error: argument output: Invalid choice, valid choices are:\n* text\n* json\n')) == ['aws ec2 describe-instances --region us-east-1 --output-text --filters "Name=tag:Name,Values=foo"']

# Generated at 2022-06-18 07:20:13.893720
# Unit test for function match

# Generated at 2022-06-18 07:20:25.723635
# Unit test for function match

# Generated at 2022-06-18 07:20:36.045308
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-instances --filter "Name=instance-state-name,Values=running"', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n  error: argument --filter: Invalid choice: \'Name=instance-state-name,Values=running\', maybe you meant:\n\n* --filters\n* --filter-name\n* --filter-value\n\n')) == ['aws ec2 describe-instances --filters "Name=instance-state-name,Values=running"', 'aws ec2 describe-instances --filter-name "Name=instance-state-name,Values=running"', 'aws ec2 describe-instances --filter-value "Name=instance-state-name,Values=running"']

# Generated at 2022-06-18 07:20:46.327115
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances --region us-east-1',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n\n  describe-instances\n  describe-instances-status\n  describe-instance-status\n  describe-instance-attribute\n\n',
                         'aws ec2 describe-instances --region us-east-1'))

# Generated at 2022-06-18 07:20:52.971766
# Unit test for function get_new_command

# Generated at 2022-06-18 07:21:03.588925
# Unit test for function get_new_command

# Generated at 2022-06-18 07:21:13.213207
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n\n* ls\n* mb\n* rb\n* cp\n* rm\n* sync\n* website\n* mv\n* presign\n* ls\n* mb\n* rb\n* cp\n* rm\n* sync\n* website\n* mv\n* presign\n\n')
    assert get_new_command(command) == ['aws s3 ls']

# Generated at 2022-06-18 07:21:20.992241
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances --region us-east-1 --output text --filters Name=instance-state-name,Values=running Name=tag:Name,Values=test-instance')
    assert get_new_command(command) == ['aws ec2 describe-instances --region us-east-1 --output text --filters Name=instance-state-name,Values=running Name=tag:Name,Values=test-instance']

# Generated at 2022-06-18 07:21:28.141316
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\naws: error: argument command: Invalid choice: \'s3\', maybe you meant:\n    * s3api\n    * s3control\n    * s3', '', 1)) == ['aws s3api ls', 'aws s3control ls', 'aws s3 ls']

# Generated at 2022-06-18 07:21:33.016377
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances --region us-east-1 --output text --filters "Name=tag:Name,Values=*"')
    assert get_new_command(command) == ['aws ec2 describe-instances --region us-east-1 --output text --filters "Name=tag:Name,Values=*"']

# Generated at 2022-06-18 07:21:42.222270
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances --region us-east-1',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n\n  describe-instances\n  describe-instances-status\n  describe-instances-attribute\n  describe-instance-status\n  describe-instance-attribute\n\n'))


# Generated at 2022-06-18 07:21:53.088686
# Unit test for function match

# Generated at 2022-06-18 07:22:02.651639
# Unit test for function match

# Generated at 2022-06-18 07:22:10.622035
# Unit test for function match

# Generated at 2022-06-18 07:22:20.769706
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n* ls\n* mb\n* rb\n* cp\n* sync\n* mv\n* rm\n* set-replication-configuration\n* get-replication-configuration\n* delete-replication-configuration\n* wait\n* help\n\n')

# Generated at 2022-06-18 07:22:29.887318
# Unit test for function match
def test_match():
    assert match(Command('aws --help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, maybe you meant:', 'aws --help'))
    assert not match(Command('aws --help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice', 'aws --help'))

# Unit

# Generated at 2022-06-18 07:22:38.186975
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-instances --filters Name=instance-state-name,Values=running', '')) == ['aws ec2 describe-instances --filters Name=instance-state-name,Values=running']

# Generated at 2022-06-18 07:22:48.952245
# Unit test for function get_new_command

# Generated at 2022-06-18 07:22:57.361246
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-instances --filters Name=instance-state-name,Values=running', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\naws: error: argument subcommand: Invalid choice: \'--filters\', maybe you meant:\n  * --filter\n  * --filters-file\n\nUnknown options: Name=instance-state-name,Values=running\n')) == ['aws ec2 describe-instances --filter Name=instance-state-name,Values=running', 'aws ec2 describe-instances --filters-file Name=instance-state-name,Values=running']

# Generated at 2022-06-18 07:23:07.854620
# Unit test for function match
def test_match():
    assert match(Command('aws', 'usage: aws [options] <command> <subcommand> [parameters]', 'aws: error: argument command: Invalid choice: \'ec2\', maybe you meant:', 'aws: error: argument command: Invalid choice: \'ec2\', maybe you meant:\n\n* ec2\n* ecs\n* ecr\n* ecs-cli\n\n'))
    assert match(Command('aws', 'usage: aws [options] <command> <subcommand> [parameters]', 'aws: error: argument command: Invalid choice: \'ec2\', maybe you meant:', 'aws: error: argument command: Invalid choice: \'ec2\', maybe you meant:\n\n* ec2\n* ecs\n* ecr\n* ecs-cli\n\n'))
   

# Generated at 2022-06-18 07:23:14.839853
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-instances --filters Name=instance-state-name,Values=running', 'aws: error: argument --filters: Invalid choice: \'Name=instance-state-name,Values=running\', maybe you meant:  \n* --filter\n* --filters-file\n')) == ['aws ec2 describe-instances --filter Name=instance-state-name,Values=running', 'aws ec2 describe-instances --filters-file Name=instance-state-name,Values=running']

# Generated at 2022-06-18 07:23:25.749897
# Unit test for function match

# Generated at 2022-06-18 07:23:36.396180
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n\n  ls\n  mb\n  rb\n  sync\n  website\n\n'))

# Generated at 2022-06-18 07:23:45.002314
# Unit test for function get_new_command

# Generated at 2022-06-18 07:23:55.798144
# Unit test for function get_new_command

# Generated at 2022-06-18 07:24:06.507040
# Unit test for function get_new_command

# Generated at 2022-06-18 07:24:12.459054
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls', 'aws: error: argument command: Invalid choice: \'ls\', maybe you meant:\n  ls\n  mb\n  rb\n  s3\n  sync\n  website\n\nSee \'aws help\' for descriptions of global parameters.\n')) == ['aws s3 mb', 'aws s3 rb', 'aws s3 s3', 'aws s3 sync', 'aws s3 website']

# Generated at 2022-06-18 07:24:25.878228
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances --region us-east-1',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice: \'describe-instances\', maybe you meant:\n* describe-instance-status\n* describe-instances\n* describe-instance-attribute\n* describe-instance-credit-specifications\n* describe-instance-types\n* describe-instance-status\n* describe-instance-attribute\n* describe-instance-credit-specifications\n* describe-instance-types\n'))

# Generated at 2022-06-18 07:24:37.218462
# Unit test for function match

# Generated at 2022-06-18 07:24:44.933862
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances --filters Name=instance-state-name,Values=running --query Reservations[].Instances[].InstanceId --output text', 'aws: error: argument --filters: Invalid choice: \'Name=instance-state-name,Values=running\', maybe you meant:')
    assert get_new_command(command) == ['aws ec2 describe-instances --filters Name=instance-state-name,Values=running --query Reservations[].Instances[].InstanceId --output text', 'aws ec2 describe-instances --filters Name=instance-state-name,Values=running --query Reservations[].Instances[].InstanceId --output text']

# Generated at 2022-06-18 07:24:55.191602
# Unit test for function get_new_command

# Generated at 2022-06-18 07:25:06.608751
# Unit test for function get_new_command

# Generated at 2022-06-18 07:25:14.860405
# Unit test for function match

# Generated at 2022-06-18 07:25:23.919870
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances --filters Name=instance-state-name,Values=running --query Reservations[].Instances[].InstanceId', 'aws: error: argument --filters: Invalid choice: \'Name=instance-state-name,Values=running\', maybe you meant:\n\n  * --filter\n  * --filters-file\n\n')
    assert get_new_command(command) == ['aws ec2 describe-instances --filter Name=instance-state-name,Values=running --query Reservations[].Instances[].InstanceId', 'aws ec2 describe-instances --filters-file Name=instance-state-name,Values=running --query Reservations[].Instances[].InstanceId']

# Generated at 2022-06-18 07:25:31.984140
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances --filters Name=instance-state-name,Values=running', 'aws: error: argument --filters: Invalid choice: \'Name=instance-state-name,Values=running\', maybe you meant:\n\n  * --filter\n  * --filters-file\n\n')
    assert get_new_command(command) == ['aws ec2 describe-instances --filter Name=instance-state-name,Values=running', 'aws ec2 describe-instances --filters-file Name=instance-state-name,Values=running']

# Generated at 2022-06-18 07:25:42.055124
# Unit test for function match

# Generated at 2022-06-18 07:25:50.474879
# Unit test for function get_new_command

# Generated at 2022-06-18 07:26:08.805589
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:', ''))
    assert not match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:', ''))

#

# Generated at 2022-06-18 07:26:18.706289
# Unit test for function match

# Generated at 2022-06-18 07:26:29.396244
# Unit test for function match

# Generated at 2022-06-18 07:26:39.622788
# Unit test for function get_new_command

# Generated at 2022-06-18 07:26:42.848375
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\naws: error: argument command: Invalid choice: \'s3\', maybe you meant:', 'aws s3 ls')) == ['aws s3 ls']

# Generated at 2022-06-18 07:26:47.734533
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nUnknown options: s3\n\nUnknown options: ls\n\naws: error: argument subcommand: Invalid choice, valid choices are:\n\n* cp\n* ls\n* mb\n* mv\n* rb\n* rm\n* sync\n\nmaybe you meant:\n\n* ls\n* cp\n* mv\n* rm\n* sync\n* mb\n* rb\n\n')
    assert get_new_command

# Generated at 2022-06-18 07:26:58.800092
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\naws: error: argument subcommand: Invalid choice, maybe you meant:\n  ls\n  mb\n  rb\n  rm\n  sync\n  website\n\n')) == ['aws s3 ls', 'aws s3 mb', 'aws s3 rb', 'aws s3 rm', 'aws s3 sync', 'aws s3 website']

# Generated at 2022-06-18 07:27:08.784465
# Unit test for function match

# Generated at 2022-06-18 07:27:15.633065
# Unit test for function match

# Generated at 2022-06-18 07:27:27.191835
# Unit test for function get_new_command

# Generated at 2022-06-18 07:27:48.853302
# Unit test for function match

# Generated at 2022-06-18 07:27:59.311754
# Unit test for function match
def test_match():
    assert match(Command('aws', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]', 'Invalid choice: \'s3\', maybe you meant:\n\n* s3api\n* s3control\n* s3sync\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nUnknown options: s3', 'aws'))

# Generated at 2022-06-18 07:28:05.073567
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\naws: error: argument <command>: Invalid choice: \'s3\', maybe you meant:\n    * s3api\n    * s3control\n    * s3\n\nSee \'aws help\' for descriptions of global parameters.\n')) == ['aws s3api ls', 'aws s3control ls', 'aws s3 ls']