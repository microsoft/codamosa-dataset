

# Generated at 2022-06-22 00:51:06.674735
# Unit test for function match

# Generated at 2022-06-22 00:51:17.612422
# Unit test for function get_new_command
def test_get_new_command():
    output = '''
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument command: Invalid choice, valid choices are:

'''
    command = 'aws ec2 wait instance-running --instances'
    new_command = get_new_command(command, output)
    assert new_command == [
        'aws ec2 wait instance-running --instance-ids',
        'aws ec2 wait instance-running --instance-ids',
        'aws ec2 wait instance-running --instance-ids']

# Generated at 2022-06-22 00:51:27.865392
# Unit test for function match

# Generated at 2022-06-22 00:51:34.264409
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls --foo', '', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\naws: error: argument subcommand: Invalid choice: \'ls --foo\', maybe you meant:\n* ls\nSee \'aws help\' for descriptions of global parameters.\n'))



# Generated at 2022-06-22 00:51:37.897781
# Unit test for function match
def test_match():
    assert match(Command('aws s3 help', ''))
    assert match(Command('sudo aws s3 help', ''))
    assert not match(Command('aws s3 mv', ''))


# Generated at 2022-06-22 00:51:49.871426
# Unit test for function match

# Generated at 2022-06-22 00:51:55.359477
# Unit test for function match
def test_match():
    command = Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument operation: Invalid choice, valid choices are:\n  cp\n  mv\n  rm\n  sync\nmight you meant: op')
    assert match(command) is True


# Generated at 2022-06-22 00:52:06.104360
# Unit test for function match
def test_match():
    # Valid case
    output1 = '''
    usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
    To see help text, you can run:

       aws help
       aws <command> help
       aws <command> <subcommand> help

    aws: error: argument command: Invalid choice, valid choices are:
    '''
    assert match(Command('aws', output=output1))

    # Invalid case
    output2 = '''
    usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
    To see help text, you can run:

       aws help
       aws <command> help
       aws <command> <subcommand> help
    '''

# Generated at 2022-06-22 00:52:19.131213
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(command_mock('aws --help')) == ['aws --help'])
    assert(get_new_command(command_mock('aws ec2 --help')) == ['aws ec2 --help'])
    assert(get_new_command(command_mock('aws ec2 describe-instances --region eu-west-failed')) == ['aws ec2 describe-instances --region eu-west-1'])
    assert(get_new_command(command_mock('aws ec2 describe-instances --region eu-west-failed --filter "Name=tag:docker,Values=true"')) == ['aws ec2 describe-instances --region eu-west-1 --filter "Name=tag:docker,Values=true"'])

# Generated at 2022-06-22 00:52:30.243304
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances',
                 'usage: aws [options] <command> <subcommand> [<subcommand> ...] '
                 '[parameters]\n\nTo see help text, you can run:\n\n  aws help\n  '
                 'aws <command> help\n  aws <command> <subcommand> help\naws: error: '
                 'unrecognized arguments: ec2\n  Invalid choice: \'ec2\', maybe you meant:\n'
                 '\t* es\n\t* ecs\n\t* ec2\n\t* ecr\n', 1))


# Generated at 2022-06-22 00:52:43.730092
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws s3api --endpoint-url=http://192.168.1.10:8081 ls  --human-readable --recursive --summarize --exclude "*" --include "*gzip"'


# Generated at 2022-06-22 00:52:50.961099
# Unit test for function match
def test_match():
    output = '''
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument operation: Invalid choice, maybe you meant:
'''
    assert match(Command('aws s3 ls', output=output))
    assert not match(Command('aws s3 ls', output=''))


# Generated at 2022-06-22 00:53:02.309633
# Unit test for function get_new_command
def test_get_new_command():
	command = "aws codecommit create-repository --repository-name aws-s3-repository --repository-description 'aws-s3-repository' --region us-east-1"

# Generated at 2022-06-22 00:53:05.669005
# Unit test for function match
def test_match():
    assert match(Command('aws --help', 'usage: ...'))
    assert not match(Command('aws --help', 'usage: ...'))


# Generated at 2022-06-22 00:53:16.016445
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws ec2 describe-volumes --filters Name=size,Values=500"

# Generated at 2022-06-22 00:53:28.108529
# Unit test for function match
def test_match():
    command = Command('aws ec2 select-resource --region ap-southeast-1')
    assert match(command)

    command = Command("aws s3 ls sdfsd")
    assert match(command)

    command = Command("aws s3 ls")
    assert match(command) == False

    command = Command("aws sd")
    assert match(command) == False

    command = Command("aws s3 ls sdfsd")
    assert match(command)

    command = Command("aws s3 ls --region ap-southeast-1")
    assert match(command)

    command = Command("aws s3 ls --region cp-southeast-1")
    assert match(command)

    command = Command("aws s3 ls --region cp-southeast-1")
    assert match(command)


# Generated at 2022-06-22 00:53:40.475748
# Unit test for function match
def test_match():
    match_input1 = 'aws: error: argument command: Invalid choice: "ECC", maybe you meant: ecs ecr eci ecs-preview\nSee ' \
                   '/usr/share/doc/python-botocore/examples/awscli-configure.rst.\nusage: aws [options] <command> ' \
                   '<subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n\n  ' \
                   'aws <command> help\n  aws <command> <subcommand> help\naws: error: the following arguments are ' \
                   'required: command'

    match_result1 = match(Command(script=match_input1, stdout=None, stderr=None))
    assert match_

# Generated at 2022-06-22 00:53:46.431445
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 --help',
                         "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n"
                         "To see help text, you can run: aws help\n"
                         "aws: error: argument --help: Invalid choice, maybe you meant:\n"
                         "* help\n"
                         ""))


# Generated at 2022-06-22 00:53:56.390486
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://bucket-name',
                         '',
                         'Usage: awscli [options] <command> <subcommand> [parameters]\naws: error: argument operation: Invalid choice, valid choices are: \n\n* mb: Creates an S3 bucket.\n* rb: Deletes an empty S3 bucket.\n* ls: List S3 buckets.\n\naws: error: argument operation: Invalid choice, valid choices are:\n\n* mb: Creates an S3 bucket.\n* rb: Deletes an empty S3 bucket.\n* ls: List S3 buckets.\n\n\n',
                         1)) == True


# Generated at 2022-06-22 00:54:04.308798
# Unit test for function match
def test_match():
	assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [parameters]\n\naws: error: argument command: Invalid choice, maybe you meant:\n    ls  \n    mb  \n    mv  \n    rb  \n    rm  \n    rr  \n    sync  \n\n'))
	assert not match(Command('aws s3 ls', ''))


# Generated at 2022-06-22 00:54:10.963962
# Unit test for function match
def test_match():
    assert match(Command('aws ecr create-repository --repository-name foobar',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\naws: error: argument command: Invalid choice',
                         'error: argument command: Invalid choice: \'ecr create-repository --repository-name\', maybe you meant:',
                         '''    ecr
    ecr-apidemo
    ecs
    ecs-cli'''))


# Generated at 2022-06-22 00:54:17.501385
# Unit test for function match
def test_match():
    assert match(Command('aws', output='\n'.join([
        'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]',
        'To see help text, you can run:',
        '',
        '  aws help',
        '  aws <command> help',
        '  aws <command> <subcommand> help',
        'aws: error: argument command: Invalid choice, maybe you meant:',
        '* destroy',
        '* deploy',
        'See \'aws help\' for descriptions of global parameters.'])))


# Generated at 2022-06-22 00:54:25.349813
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 mb --sse', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\naws: error: argument command: Invalid choice: \'mb\', maybe you meant:\n        ls\n        rb\n        ui\naws s3 mb --sse', '', 0)) == ['aws s3 ls --sse', 'aws s3 rb --sse', 'aws s3 ui --sse']

# Generated at 2022-06-22 00:54:35.522960
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.aws_commands import get_new_command
    assert get_new_command(Command('aws cloudformation describe-stacks --stack-name test',
                                'Invalid choice: \'cloudformation\', maybe you meant:\n* client\n* config\n* iam\n* s3\n* sts\n\nSee \'aws help\' for descriptions of global parameters.\n')) == ["aws client describe-stacks --stack-name test", "aws config describe-stacks --stack-name test", "aws iam describe-stacks --stack-name test", "aws s3 describe-stacks --stack-name test", "aws sts describe-stacks --stack-name test"]

# Generated at 2022-06-22 00:54:41.291597
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-22 00:54:53.430997
# Unit test for function match
def test_match():
    # test function returns False when no match
    assert match(Command('aws foo')) == False

    # test function returns False when match but no 'maybe you meant:'
    assert match(Command('aws --help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\ntoo few arguments\n')) == False

    # test function returns True when match

# Generated at 2022-06-22 00:54:55.423120
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws configure --profile test"
    assert get_new_command(command) == ["aws configuring --profile test"]

# Generated at 2022-06-22 00:55:06.225052
# Unit test for function match
def test_match():
    test_input_output = [
        ('''usage: aws [options] <command> <subcommand> [parameters]
aws: error: argument subcommand: Invalid choice, maybe you meant:
* subnet
* route53
See 'aws help' for descriptions of global parameters.
''', True),
        ('''usage: aws [options] <command> <subcommand> [parameters]
aws: error: argument subcommand: Invalid choice, maybe you meant:
* subnet
* route53
See 'aws help' for descriptions of global parameters.
''', True)
    ]
    assert all(match(Command('aws', output=out)) is res
               for out, res in test_input_output)



# Generated at 2022-06-22 00:55:16.971317
# Unit test for function get_new_command
def test_get_new_command():
    example_output = '''aws: error: argument subcommand: Invalid choice: 'ec2 list-objects', maybe you meant:
        * list-objects
        * list-object-versions
        * list-object-versions
        * list-objects-v2
        * list-objects-v2'''
    example_command = Command('aws ec2 list-objects', example_output)
    assert get_new_command(example_command) == [
        'aws ec2 list-objects', 'aws ec2 list-object-versions', 'aws ec2 list-object-versions',
        'aws ec2 list-objects-v2', 'aws ec2 list-objects-v2']

# Generated at 2022-06-22 00:55:26.356110
# Unit test for function get_new_command

# Generated at 2022-06-22 00:55:36.086065
# Unit test for function get_new_command

# Generated at 2022-06-22 00:55:47.732782
# Unit test for function get_new_command
def test_get_new_command():
    print("Check the get_new_command function is working properly")
    command = Command("aws --version", "usage: aws [options] [parameters]\naws: error: argument --version: "
                      "Invalid choice: '--version', maybe you meant:\n\t--endpoint-url\n\t--no-verify-ssl\n\t"
                      "--version\n\t--debug\n\t--ca-bundle\n\t--cli-configure\n\t--profile")

    new_command = get_new_command(command)
    assert len(new_command) == 7

# Generated at 2022-06-22 00:55:58.988298
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck import types
    from thefuck.types import Command


# Generated at 2022-06-22 00:56:11.169972
# Unit test for function get_new_command

# Generated at 2022-06-22 00:56:19.540599
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\naws help\naws <command> help\naws <command> <subcommand> help\nUnknown options: ls\naws: error: argument command: Invalid choice, maybe you meant:\n*            iam\n*            s3\n', 1))


# Generated at 2022-06-22 00:56:27.592099
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws help"
    command_output = 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nUnknown options: dfs\naws: error: invalid choice: \'dfs\', maybe you meant: '
    assert get_new_command(Command(script=command, output=command_output)) == ['aws dfs help']



# Generated at 2022-06-22 00:56:31.879615
# Unit test for function match
def test_match():
    for command in [Command('aws iam', ''), Command('aws elb', '')]:
        assert match(command) is None

    for command in [Command('aws s3', ''), Command('aws ec2', '')]:
        assert match(command)

# Generated at 2022-06-22 00:56:44.350566
# Unit test for function match
def test_match():
    output="usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument <subcommand>: Invalid choice: 'ec2', maybe you meant:* ec2\n* ec2-instance-connect\n* ecs\n\nTo see help text, you can run:\naws help\naws <command> help\naws <command> <subcommand> help\n\naws: error: argument <subcommand>: Invalid choice: 'ec2', maybe you meant:* ec2\n* ec2-instance-connect\n* ecs\n\nTo see help text, you can run:\naws help\naws <command> help\naws <command> <subcommand> help"
    assert not match(Command('aws ec2', output))


# Generated at 2022-06-22 00:56:52.668173
# Unit test for function match

# Generated at 2022-06-22 00:56:59.020744
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb --region us-west-1', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument command: Invalid choice', '', 1))
    assert not match(Command('aws s3 mb --region us-west-1', 'usage: aws [options] <command> <subcommand> [parameters]\n', '', 1))


# Generated at 2022-06-22 00:57:14.931959
# Unit test for function get_new_command
def test_get_new_command():
    # Arrange
    command1 = Command("aws ec2 describe-instances --region us-east-1 --output text --instance-ids i-9eb4c0c4")
    command1.output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nInvalid choice: '--region', maybe you meant:\n                                          --profile                  Use a specific profile from your credential file\n                                          --debug                    Turn on debug logging\n                                          --endpoint-url             Override command's default URL with the given URL"

# Generated at 2022-06-22 00:57:27.323302
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command('aws ec2 imprt-image --disks', 'usage: aws [options] <command> <subcommand> [parameters]\n  error: argument --disks: invalid choice: \'\', maybe you meant: \n    --description\n    --dry-run\n    --image-id\n    --tag-specifications\n    --verbose\n\naws: error: argument --disks: invalid choice: \'\', maybe you meant: --description, --dry-run, --image-id, --tag-specifications, --verbose\n', 'aws', 'aws ec2 imprt-image --disks')

# Generated at 2022-06-22 00:57:34.982231
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("lalala", " 's3c' is not a valid aws command. See 'aws help'.")) == ["aws s3c"]
    assert get_new_command(Command("aws vpc", "'vpc' is not a valid aws command. See 'aws help'.\n\naws: error: argument subcommand: Invalid choice, maybe you meant:\n    vpcendpoint-service\n    vpcendpoint")) == ["aws vpcendpoint", "aws vpcendpoint-service"]

# Generated at 2022-06-22 00:57:38.589052
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls', 'aw: error: argument subcommand: Invalid choice: \'ls\', maybe you meant:\n\t   cp\n\t   mv\n\ts3: error: argument command: Invalid choice: \'ls\', maybe you meant:\n\t   ls\n\t   mb\n\t   mv\n\t   rb\n\t   rf\n\t   sync')) == ['aws s3 cp']

# Generated at 2022-06-22 00:57:41.695559
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', ''))
    assert not match(Command('ls s3', ''))


# Generated at 2022-06-22 00:57:53.222078
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://mybucket/', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument subcommand: Invalid choice', 'aws s3 mb s3://mybucket/', 1))
    assert not match(Command('aws s3 cp a.txt', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument subcommand: Invalid choice', 'aws s3 mb s3://mybucket/', 1))

# Generated at 2022-06-22 00:58:04.853313
# Unit test for function match

# Generated at 2022-06-22 00:58:08.933548
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws elbv2 describe-load-balancers --loadb-arn xxx')) == [
        'aws elbv2 describe-load-balancers --load-balancer-arn xxx']

# Generated at 2022-06-22 00:58:11.506997
# Unit test for function match
def test_match():
    assert(match(Command('aws iam create-account-alias --account-alias=123456789012345678901', '')))


# Generated at 2022-06-22 00:58:20.798114
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 ls --recurse', 'aws: error: argument --recurse: Invalid choice, maybe you meant:\n  --recursive\n\nusage: aws [options] <command> <subcommand> [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\naws: error: the following arguments are required: s3')
    assert get_new_command(command)[0] == 'aws s3 ls --recursive'

# Generated at 2022-06-22 00:58:34.465478
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws sqs create-queue', '', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\naws: error: argument subcommand: Invalid choice: \'create-queue\', maybe you meant:* create-queue-url\n')) == ["aws sqs create-queue-url"]

# Generated at 2022-06-22 00:58:41.174377
# Unit test for function match
def test_match():
    command = Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> '
             '[parameters]\naws: error: argument subcommand: Invalid choice: '
             "'s3 ls', maybe you meant:\n    service\n    s3api\n    s3website\n\n"
             'See \'aws help\' for descriptions of global parameters.\n')
    assert match(command)


# Generated at 2022-06-22 00:58:50.392028
# Unit test for function get_new_command

# Generated at 2022-06-22 00:58:53.971572
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws help', "''' Invalid choice: 'help', maybe you meant:   * instance-states'''")
    assert 'aws instance-states' in get_new_command(command)

# Generated at 2022-06-22 00:59:01.212269
# Unit test for function get_new_command

# Generated at 2022-06-22 00:59:01.982818
# Unit test for function get_new_command
def test_get_new_command():
    pass

# Generated at 2022-06-22 00:59:13.999683
# Unit test for function get_new_command

# Generated at 2022-06-22 00:59:18.166461
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('aws ec2 describe-images --output table') == ['aws ec2 describe-images' ]
    
    
    
from thefuck.specific.git import git_support



# Generated at 2022-06-22 00:59:29.954467
# Unit test for function match
def test_match():
    assert match(Command('aws --help', 'usage: aws [options] <command> <subcommand> [parameters]\n  error: option --help not recognized\n  maybe you meant:\n    help\n'))
    assert not match(Command('aws --help', 'usage: aws [options] <command> <subcommand> [parameters]\n  error: option --help not recognized\n'))
    assert not match(Command(' --help', 'Something went wrong'))
    assert not match(Command(' --help', 'usage: aws [options] <command> <subcommand> [parameters]\n  error: option --help not recognized\n'))
    assert not match(Command(' aws --help', 'Something went wrong'))

# Generated at 2022-06-22 00:59:41.499019
# Unit test for function match

# Generated at 2022-06-22 01:00:06.445591
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 rb s3://bucket-name --force',
                                   'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n'
                                   '[...]\n'
                                   'Invalid choice: \'rb\', maybe you meant:\n'
                                   '\tcp\n'
                                   '\tmb\n'
                                   '\trb\n')) == [
        'aws s3 cp s3://bucket-name --force',
        'aws s3 mb s3://bucket-name --force',
        'aws s3 rb s3://bucket-name --force']

# Generated at 2022-06-22 01:00:19.040555
# Unit test for function match
def test_match():
    command_output = "Invalid choice: 'cloudformation-wait', maybe you meant:\n\tcloudformation\n\tcloudwatch\n\tcloudfront\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\naws help\naws <command> help\naws <command> <subcommand> help"
    assert match(Command('aws cloudformation-wait',  command_output))


# Generated at 2022-06-22 01:00:28.891066
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws help', 'usage: aws [options] <command> <subcommand> [...]\r\naws: error: Invalid choice: \'help\', maybe you meant:\r\n* ec2 # Amazon Elastic Compute Cloud\r\n* elb # Elastic Load Balancing\r\n* help\r\n')
    assert get_new_command(command)[0] == 'aws ec2 # Amazon Elastic Compute Cloud'
    assert get_new_command(command)[1] == 'aws elb # Elastic Load Balancing'
    assert get_new_command(command)[2] == 'aws help'

enabled_by_default = True

# Generated at 2022-06-22 01:00:37.983273
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    # One option
    command = Command('aws ec2 stop-instances --instance-ids i-1234567890abcdef0')
    assert get_new_command(command) == ['aws ec2 stop-instances --instance-ids i-1234567890abcdef0']

    # More options
    command = Command('aws ec2 stop-instances --instance-ids i-1234567890abcdef0')
    assert get_new_command(command) == ['aws ec2 stop-instances --instance-ids i-1234567890abcdef0']

# Generated at 2022-06-22 01:00:48.694125
# Unit test for function get_new_command

# Generated at 2022-06-22 01:01:00.722417
# Unit test for function get_new_command