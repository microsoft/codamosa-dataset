

# Generated at 2022-06-22 00:51:05.007680
# Unit test for function get_new_command

# Generated at 2022-06-22 00:51:08.542129
# Unit test for function match
def test_match():
    assert match(Command('aws bla bla bla help', ''))
    assert not match(Command('aws bla bla help', ''))


# Generated at 2022-06-22 00:51:17.819442
# Unit test for function get_new_command
def test_get_new_command():
    expected = ['aws ec2 describe-instances']
    assert  get_new_command(Command('aws ec2 desribe-instances', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument subcommand: Invalid choice, maybe you meant:\n  * describe-instances\n')) == expected
    assert  get_new_command(Command('aws ecs desribe-instances', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument subcommand: Invalid choice, maybe you meant:\n  * describe-instances\n')) == []



# Generated at 2022-06-22 00:51:28.142786
# Unit test for function match
def test_match():
    output = ("usage: aws [options] <command> <subcommand> [<subcommand> ...]\n"
        "  [parameters]\n"
        "To see help text, you can run:\n"
        "  aws help\n"
        "  aws <command> help\n"
        "  aws <command> <subcommand> help\n"
        "aws: error: argument subcommand: Invalid choice, maybe you meant:\n"
        "  * help\n"
        "  * configure\n"
        "  * iam get-user\n"
        "  * s3 cp\n"
        "  * s3 sync\n"
        "See 'aws help' for descriptions of global parameters.\n")

# Generated at 2022-06-22 00:51:29.415350
# Unit test for function match
def test_match():
    assert match(Command('aws ec2'))


# Generated at 2022-06-22 00:51:41.468390
# Unit test for function match

# Generated at 2022-06-22 00:51:47.170118
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-22 00:51:53.196098
# Unit test for function match
def test_match():
    assert match(Command('aws', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument command: Invalid choice: \'xxxx\'', '', 0))
    assert not match(Command('aws', '', '', 0))
    assert not match(Command('', '', '', 0))


# Generated at 2022-06-22 00:52:05.153699
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws elbv2 describe-load-balancers --region us-east-1"
    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument --region: Invalid choice: 'us-east-1', maybe you meant:
  eu-west-1
* us-east-2"""
    command = type('obj', (object,), {'script': script, 'output': output})

# Generated at 2022-06-22 00:52:18.549637
# Unit test for function get_new_command
def test_get_new_command():
    cmd = Command("aws s3 ls", "usage: aws [options] <command> <subcommand> [<subcommand> ...]\n"
                                "aws: error: argument command: Invalid choice, valid choices are:\n"
                                "  s3api         \n"
                                "  s3            \n"
                                "* s3api         Call an Amazon S3 API.\n"
                                "* s3            Provide commands for managing Amazon S3 buckets and\n"
                                "                objects.\n"
                                "aws: error: argument command: Invalid choice: 's3 ls', maybe you meant:\n"
                                "* ls            List S3 buckets and objects.\n"
                                "* s3api         Call an Amazon S3 API.\n")
    assert get_new_command(cmd)

# Generated at 2022-06-22 00:52:29.253940
# Unit test for function match
def test_match():
    assert match(Command('aws --help', 'usage: aws [--version] [--help] [commands]\n\nInvalid choice: \'--help\', maybe you meant:\n * --version', ""))
    assert match(Command('aws --help', 'usage: aws [--version] [--help] [commands] Invalid choice: \'--help\', maybe you meant: * --version', ""))
    assert not match(Command('aws --help', 'usage: aws [--version] [--help] [commands]', ''))



# Generated at 2022-06-22 00:52:32.610413
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("aws ec2 list-regions", "Unknown options: --regins")) == ["aws ec2 list-regions --regions"]


enabled_by_default = True

# Generated at 2022-06-22 00:52:34.104012
# Unit test for function match
def test_match():
    command = Command('aws foo', '')
    assert match(command)


# Generated at 2022-06-22 00:52:45.501751
# Unit test for function get_new_command
def test_get_new_command():
    #Test with no replacements
    assert get_new_command(Command('aws --help', 'Invalid choice: \'--help\', maybe you meant:\n  --help \n  --profile\n  --debug    ')) == []
    #Test with single replacement
    assert get_new_command(Command('aws --gello', 'Invalid choice: \'--gello\', maybe you meant:\n  --help \n  --profile\n  --debug    ')) == ['aws --help']
    #Test with multiple replacements

# Generated at 2022-06-22 00:52:48.204759
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws ec2 describe-instnces") == ["aws ec2 describe-instances"]


# Generated at 2022-06-22 00:52:51.589861
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws ec2 create-vpcs vpc-cidr-block 10.1",command.output) =="aws ec2 create-vpc vpc-cidr-block 10.1.0.0/16"


# Generated at 2022-06-22 00:53:03.019116
# Unit test for function get_new_command

# Generated at 2022-06-22 00:53:07.034821
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 run-instance --region us-west-2')
    assert get_new_command(command) == [
        'aws ec2 run-instances --region us-west-2']

# Generated at 2022-06-22 00:53:12.795489
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-addresses',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\naws: error: argument subcommand: Invalid choice, maybe you meant:\n  * describe-addresses\n  * allocate-address\n  * associate-address',
                         ''))


# Generated at 2022-06-22 00:53:19.513997
# Unit test for function match
def test_match():
    outputs = ["usage: aws [options] <command> <subcommand> [parameters] ...",
           "aws: error: argument command: Invalid choice, maybe you meant: \n"
           "* command\n* subcommand\n* parameters\n"]
    for output in outputs:
        assert match(Command(script='aws', output=output))



# Generated at 2022-06-22 00:53:28.392441
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 run-instances --image-id blah blah blah', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] \n\naws: error: argument --image-id: Invalid choice: \'blah\', maybe you meant: \n   * ami \n   * image', '', 123)) == ['aws ec2 run-instances --image-id ami blah blah', 'aws ec2 run-instances --image-id image blah blah']

# Generated at 2022-06-22 00:53:29.407680
# Unit test for function match
def test_match():
    pass



# Generated at 2022-06-22 00:53:41.882706
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 cp views.py s3://mybucket', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nerror: Invalid choice: \'cp\', maybe you meant:\n\n* cp-object\n* cp-s\n* cp-s-s3\n\n', 'aws')

# Generated at 2022-06-22 00:53:54.006424
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws cloudfront create-invalid-distribution'

# Generated at 2022-06-22 00:53:58.843063
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("aws ec2 destinations-help")) == [
        "aws ec2 describe-destinations",
        "aws ec2 delete-destination",
        "aws ec2 create-destination"
        ]

# Generated at 2022-06-22 00:54:09.230414
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash
    command = Bash()
    command.script = 'aws s3 cp s3://bucket/data/foo.bar'

# Generated at 2022-06-22 00:54:13.457305
# Unit test for function match
def test_match():
	cmd = Command('aws s3 mv s3://a s3://b', 'aws: error: argument operation: Invalid choice, maybe you meant:\n* cp\n* ls\n* mb\n* mv\n* rb\n* rm\n* sync\n* website')
	assert match(cmd)

# Generated at 2022-06-22 00:54:16.709713
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ecs list', 'aws: error: Invalid choice: \'list\', maybe you meant:', '', 0))== ['aws ecs lists']

# Generated at 2022-06-22 00:54:24.544843
# Unit test for function get_new_command

# Generated at 2022-06-22 00:54:36.104650
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("aws s3 cp s3://mybucket/myfile.txt .",
                                   "Unknown options: 'cp', usage: aws [options] "
                                   "<command> <subcommand> [<subcommand>...] "
                                   "[parameters]\nTo see help text, you can run: "
                                   "aws help\nUnknown options: 'cp', maybe you "
                                   "meant: cw, config, events, lambda\n")) == ['aws s3 cw s3://mybucket/myfile.txt .', 'aws s3 config s3://mybucket/myfile.txt .', 'aws s3 events s3://mybucket/myfile.txt .', 'aws s3 lambda s3://mybucket/myfile.txt .']

# Generated at 2022-06-22 00:54:48.296429
# Unit test for function match
def test_match():
    command = Command('aws --version', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] '
                                      '[parameters]\nTo see help text, you can run: '
                                      'aws help\naws: error: argument --version: invalid choice: '
                                      "'--version' (maybe you meant: 's3')\n", '')

    assert match(command)


# Generated at 2022-06-22 00:54:54.603844
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command('aws sts get-session-token')) == ['aws sts get-session-token']

    assert get_new_command(
        Command('aws s3 cp --acl=public_read a.txt s3://bucket/a.txt')) ==\
        ['aws s3 cp --acl=public-read a.txt s3://bucket/a.txt']

# Generated at 2022-06-22 00:54:56.228178
# Unit test for function match
def test_match():
    assert match(Command())

# Unit Test for function get_new_command:

# Generated at 2022-06-22 00:55:01.357871
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 ls',
        'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
        'aws: error: argument subcommand: Invalid choice, maybe you meant:\n'
        'co fn')
    )


# Generated at 2022-06-22 00:55:05.865718
# Unit test for function match
def test_match():
    assert match(Command('aws', output='usage: aws [options] <command> <subcommand> [parameters]'))
    assert not match(Command('aws', output='usage: aws [options] <command> <subcommand> [parameters] maybe you meant:'))


# Generated at 2022-06-22 00:55:11.439764
# Unit test for function get_new_command
def test_get_new_command():
    aws_command = "aws ec2 help start-instances"
    assert get_new_command(Command(aws_command, "", "aws: error: argument operation: Invalid choice: 'help', maybe you meant:\n  * start-instances\n")) == [
        "aws ec2 start-instances"]

# Generated at 2022-06-22 00:55:19.177629
# Unit test for function match
def test_match():
    command = type('obj', (object,), {'output': "usage: aws [options] <command> <subcommand> [parameters]"})
    assert match(command)

    command = type('obj', (object,), {'output': "Invalid choice: 'mistake' maybe you mean: "})
    assert match(command)

    command = type('obj', (object,), {'output': "Invalid choice: 'mistake' maybe you think: "})
    assert not match(command)



# Generated at 2022-06-22 00:55:26.616696
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='aws', stderr='usage: aws [options] [parameters] [<command> <subcommand> [<subcommand> ...]]\naws: error: option --invalid is not recognized\n\nmaybe you meant:\n * --version\n * --no-verify-ssl\n * --region\n * --endpoint-url\n\naws: error: no such option: --invalid\n', stdout='')
    assert (get_new_command(command) == ['aws --version',
                                         'aws --no-verify-ssl',
                                         'aws --region',
                                         'aws --endpoint-url'])

# Generated at 2022-06-22 00:55:34.976556
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws: error: argument command: Invalid choice: \'rdss', \
        'maybe you meant:\n* rds\n* rds-db\n* rds-data\n* rds-encryption-keys\n* rds-events\n* rds-logs\n* rds-metrics\n* rds-tags\n* rds-vpc-route53'
    assert get_new_command(type('Command', (object,), {'script': 'aws', 'output': script})) == ['aws rds']

# Generated at 2022-06-22 00:55:47.014076
# Unit test for function match
def test_match():
    assert match(Command('aws ec2', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n* subnet\n* rds\n* lambda\n  ', '', 1, 'aws'))

# Generated at 2022-06-22 00:56:09.966840
# Unit test for function match

# Generated at 2022-06-22 00:56:15.601796
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws mssb', "Unknown options: 'mssb'\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, valid choices are:")) == ["aws help", "aws <command> help", "aws <command> <subcommand> help"]

# Generated at 2022-06-22 00:56:25.791399
# Unit test for function match
def test_match():
    assert match(Command('aws', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]'
                                 'To see help text, you can run:'
                                 'aws help'
                                 'aws <command> help'
                                 'aws <command> <subcommand> help'
                                 'aws: error: argument command: Invalid choice: '
                                 "'elbv2', maybe you meant:\n  * elbv2-wait"
                                 '  * elbv2-describe-account-limits'
                                 '  * elbv2-describe-tags', ''))



# Generated at 2022-06-22 00:56:38.252872
# Unit test for function match
def test_match():
    assert match(Command('aws', output="usage: aws [options] <command> <subcommand> [<subcommand> ...]\n" +
                          "aws: error: argument command: Invalid choice, valid choices are: ...\n" +
                          "aws: error: argument command: Invalid choice, maybe you meant:\n" +
                          "  * apigateway"))

    assert not match(Command('aws', output="usage: aws [options] <command> <subcommand> [<subcommand> ...]\n" +
                           "aws: error: argument command: Invalid choice, valid choices are: ...\n" +
                           "aws: error: argument command: Invalid choice, maybe you meant:\n" +
                           "  * apigateway"))



# Generated at 2022-06-22 00:56:42.790649
# Unit test for function match
def test_match():
    assert match(Command('aws --version', 'usage: aws [options] <command> <subcommand> [parameters]'))
    assert not match(Command('aws --version', 'usage: aws [options] <command> <subcommand>'))


# Generated at 2022-06-22 00:56:54.475570
# Unit test for function get_new_command

# Generated at 2022-06-22 00:57:06.233429
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command_script = "aws ec2 start-instances --instance-ids i-1234567890abcdef0"
    command_output = """
                    usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
                    To see help text, you can run:

                    aws help
                    aws <command> help
                    aws <command> <subcommand> help
                    aws: error: argument instance-ids: Invalid choice: 'i-1234567890abcdef0', maybe you meant:
                     * i-1234567890abcdef1
                     * i-1234567890abcdef2
                    """
    command = Command(script=command_script, output=command_output)
    new_command = get_new_command(command)
    assert new

# Generated at 2022-06-22 00:57:10.494093
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 mb s3://s3-bucket/ --region us-east-1', '')) == \
        ['aws s3 mb s3://s3-bucket --region us-east-1']

# Generated at 2022-06-22 00:57:22.204300
# Unit test for function get_new_command
def test_get_new_command():
    # Invalid only
    o = """Unknown options: ['--deploy', '-d'].
"""
    assert get_new_command(Command("aws --d", o)) == ['aws --deploy']
    # Invalid and valid

# Generated at 2022-06-22 00:57:30.487141
# Unit test for function match
def test_match():
    assert not match(Command('aws --version',''))
    assert not match(Command('aws apigatewayv2 get-apis',''))
    assert match(Command('aws apigatewayv2 get-apis --region us-east-1',''))
    assert not match(Command('aws apigatewayv2 get-api --api-id dummy',''))
    assert match(Command('aws apigatewayv2 get-apis --region us-east-1 --api-id dummy',''))



# Generated at 2022-06-22 00:57:54.802962
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls wron-bucket', 'aws: error: argument --bucket: expected one argument')) == ['aws s3 ls wrong-bucket']



# Generated at 2022-06-22 00:58:06.521856
# Unit test for function get_new_command
def test_get_new_command():

    from thefuck.types import Command

# Generated at 2022-06-22 00:58:10.534659
# Unit test for function match
def test_match():
    assert match(Command('aws', 'aws: command not found'))

# Generated at 2022-06-22 00:58:23.351705
# Unit test for function get_new_command
def test_get_new_command():
    one = 'aws ec2 describe-images --owners amazon --filters "Name=name,Values=amzn-ami-hvm-2018.?.??-x86_64-gp2" --query "reverse(sort_by(Images, &CreationDate))[:1].ImageId"'
    two = 'aws s3api get-objejct-acl --bucket $bucket --key $key'
    three = 'aws s3api get-objejct-acl --bucket name --key key'
    four = 'aws s3api get-objejct-acl --bucket $bucket --key key'
    five = 'aws ec2 create-snapshot --volume-id vol-1234567890abcdef0'
    six = 'aws ec2 create-snapshot --volume-id id-12345678'
    seven

# Generated at 2022-06-22 00:58:31.512126
# Unit test for function get_new_command

# Generated at 2022-06-22 00:58:42.159726
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script="aws ec2 describe-instances",
                      output="Invalid choice: 'asd', maybe you meant:\n  * asd\n  * qwe")
    assert get_new_command(command) == [
        "aws ec2 describe-instances",
        "aws ec2 describe-instances"
    ]
    command = Command(script="aws ec2 describe-instances",
                      output="Invalid choice: 'qwe', maybe you meant:\n  * asd\n  * qwe")
    assert get_new_command(command) == [
        "aws ec2 describe-instances asd",
        "aws ec2 describe-instances"
    ]

# Generated at 2022-06-22 00:58:43.973200
# Unit test for function match
def test_match():
    assert match(Command('aws help'))
    assert not match(Command('aws cloudformation'))


# Generated at 2022-06-22 00:58:52.756968
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws s3 ls", "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n  ls\n* list\n    List objects in an S3 bucket.\n")
    assert get_new_command(command) == ['aws s3 list']

# Generated at 2022-06-22 00:59:05.232425
# Unit test for function get_new_command
def test_get_new_command():
    command ='aws elb describe-load-balancers [--load-balancer-names name] [--page-size Integer] [--page-token String] [--regions region] [--output text | json] [--query JSON] [--profile TEXT]'
    mistake = 'describe-load-balancer'
    options = ['describe-load-balancers', 'describe-load-balancer-target-groups', 'describe-load-balancer-listeners', 'describe-load-balancer-attributes', 'describe-load-balancer-policies', 'describe-load-balancer-policy-types']

# Generated at 2022-06-22 00:59:17.957991
# Unit test for function match
def test_match():
    assert (match(Command('aws help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]'
                          '\nInvalid choice: \'hlep\', maybe you meant:\n    help\n'))
            == True)
    assert match(Command('aws help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]')) == False
    assert (match(Command('aws hlep', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]'
                          '\nInvalid choice: \'hlep\', maybe you meant:\n    help'))
            == True)

# Generated at 2022-06-22 01:00:13.639270
# Unit test for function get_new_command
def test_get_new_command():
    script = ["aws", "--region", "us-east-1", "ec2", "run-instance",
              "--image-id", "ami-1aebb57c", "--instance-type",
              "t1.micro", "--ssm-document", "runInstancesSSM", "--private-ip",
              "10.0.0.1"]
    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument --ssm-document: invalid choice: 'runInstancesSSM', maybe you meant:
 * run-instances
 * run-script"""
    assert get_new_

# Generated at 2022-06-22 01:00:20.888313
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command('aws s3', 'Invalid choice: \'0\', maybe you meant:\n  * 1\n  * 2\n')) == ['aws s3 1', 'aws s3 2'])
    assert(get_new_command(Command('aws s3', 'usage: aws [options] [parameters]\naws: error: argument operation: Invalid choice, valid choices are:\n  * 1\n  * 2\n')) == ['aws 1', 'aws 2'])

# Generated at 2022-06-22 01:00:24.868962
# Unit test for function match

# Generated at 2022-06-22 01:00:33.481582
# Unit test for function match
def test_match():
    assert match(Command('aws',
                output='''usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, valid choices are:

subcommands:

configure            Configure the AWS Command Line Interface.
    help             Provides usage information for AWS CLI commands.

'''))


# Generated at 2022-06-22 01:00:38.244373
# Unit test for function get_new_command
def test_get_new_command():
    # Expected result:
    # ['aws configure get', 'aws configure set', 'aws configure list']
    result = get_new_command('aws configure')
    print("Result: " + str(result))
    assert result == ['aws configure get', 'aws configure set', 'aws configure list']

# Generated at 2022-06-22 01:00:40.503272
# Unit test for function match
def test_match():
    assert match(Command('aws s3', 'Invalid choice: \'s3\', maybe you meant:', ''))
    assert not match(Command('aws s3', '', ''))


# Generated at 2022-06-22 01:00:45.962651
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 create-image --instance-id i-0b005f5d0f539ea2b --name "Devops-Labs"')
    assert get_new_command(command) == [
        'aws ec2 create-image --instance-id i-0b005f5d0f539ea2b --name Devops-Labs']

# Generated at 2022-06-22 01:00:58.067286
# Unit test for function get_new_command