

# Generated at 2022-06-22 00:51:10.706542
# Unit test for function match

# Generated at 2022-06-22 00:51:18.585470
# Unit test for function match
def test_match():
    # Create a Command object with output matching case: "maybe you meant"
    command = Command("aws ec2", "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\
                                            To see help text, you can run:\n\
                                            \n\
                                            aws help\n\
                                            aws <command> help\n\
                                            aws <command> <subcommand> help\n\
                                            aws: error: argument subcommand: Invalid choice: 'ec2', maybe you meant:  \n\
                                            * iam\n\
                                            * rds\n\
                                            * cloudformation", 1)

    # Assert that Command matches
    assert match(command)


# Generated at 2022-06-22 00:51:24.791381
# Unit test for function get_new_command
def test_get_new_command():
    def command(output):
        return type('Command', (object,), {'output': output})
    assert get_new_command(command('usage: aws [options] [parameters]\naws: error: argument command: Invalid choice: \'ec2l\', maybe you meant:  \n  * ec2\n  * ecs')) == ['aws ec2 [options] [parameters]', 'aws ecs [options] [parameters]']

# Generated at 2022-06-22 00:51:37.774399
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("aws ec2 describe-instance-attribute --instance-id i-1234abcd --attribute foo"))[0] == "aws ec2 describe-instance-attribute --instance-id i-1234abcd --attribute userData"
    assert get_new_command(Command("aws ec2 describe-instance-attribute --instance-id i-1234abcd --attribute foo"))[1] == "aws ec2 describe-instance-attribute --instance-id i-1234abcd --attribute disableApiTermination"
    assert get_new_command(Command("aws ec2 describe-instance-attribute --instance-id i-1234abcd --attribute foo"))[2] == "aws ec2 describe-instance-attribute --instance-id i-1234abcd --attribute ebsOptimized"

# Generated at 2022-06-22 00:51:43.516667
# Unit test for function get_new_command
def test_get_new_command():
    output = "Invalid choice: 'ssssssssssssss', maybe you meant: S3, ec2, dynamodb\n  * S3\n    ec2\n    dynamodb"
    command = Command('hello', output=output)
    new_commands = get_new_command(command)
    assert new_commands == ["hello S3", "hello ec2", "hello dynamodb"]

# Generated at 2022-06-22 00:51:49.984133
# Unit test for function match

# Generated at 2022-06-22 00:51:57.893388
# Unit test for function match
def test_match():
    output_of_aws = """
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n
aws: error: argument command: Invalid choice, valid choices are:\n
* elvaliate-configuration
* events
* health
* lambda
* metrics
* resource-groups
* rules
* schedule
* services
* tag
* targets
"""
    assert match(Command('aws help', output=output_of_aws)) is True
    assert match(Command('aws help', output='')) is False
    assert match(Command('aws help', output='foo')) is False


# Generated at 2022-06-22 00:52:02.639753
# Unit test for function get_new_command
def test_get_new_command():
    old_command = "aws help"
    output_message = "Invalid choice: 'help', maybe you meant: \n  * s3\n  * login\n  * boto3\n"
    command = Command(old_command, output_message)
    expected_command = ["aws s3", "aws login", "aws boto3"]
    assert get_new_command(command) == expected_command

# Generated at 2022-06-22 00:52:05.782517
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'script': 'aws', 'output': 'Invalid choice: \'abc\', maybe you meant:\n  * pqr\n  * xyz\nusage:'})

# Generated at 2022-06-22 00:52:13.754216
# Unit test for function match

# Generated at 2022-06-22 00:52:22.365254
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws --decribe-something', "aws: error: argument option: Invalid choice: '--decribe-something', maybe you meant:\n  * --describe-stacks\n  * --describe-stack-events\n  * --describe-stack-resource\n  * --describe-stack-resources")
    assert get_new_command(command) == ['aws --describe-stacks', 'aws --describe-stack-events', 'aws --describe-stack-resource', 'aws --describe-stack-resources']

# Generated at 2022-06-22 00:52:34.406367
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.aws import get_new_command
    from thefuck.types import Command
    command = Command('aws ec2 help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\naws: error: argument subcommand: Invalid choice: \'help\', maybe you meant:\n    create-volume\n    get-console-output\n    reboot-instances\n    start-instances\n    stop-instances\n    terminate-instances', '')
    new_command = get_new_command(command)
    assert new_command == ['aws ec2 create-volume', 'aws ec2 get-console-output', 'aws ec2 reboot-instances',
                           'aws ec2 start-instances', 'aws ec2 stop-instances', 'aws ec2 terminate-instances']

# Generated at 2022-06-22 00:52:42.862803
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('aws', 'usage: aws [options] <command> <subcommand>', 'Invalid choice: \'eckeck\', maybe you meant:\n    ec2\n    ecs\n    ecr\n    ecs-cli\n')) ==
            ['aws [options] <command> <subcommand>', 'aws [options] <command> <subcommand>', 'aws [options] <command> <subcommand>', 'aws [options] <command> <subcommand>', 'aws [options] <command> <subcommand>'])

# Generated at 2022-06-22 00:52:53.690419
# Unit test for function get_new_command
def test_get_new_command():
    # Set up the Command object
    script = 'drupal'
    output = 'Invalid choice: \'drupal\', maybe you meant:\n'\
             '* drupal\n'\
             '  drupal-database\n'\
             '  drupal-deploy\n'\
             '  drupal-firewall\n'\
             '  drupal-mail\n'\
             '  drupal-module\n'\
             '  drupal-profile\n'\
             '  drupal-project\n'\
             '  drupal-recover'
    command = Command(script=script, output=output)

    # Get the new command and make it a list
    new_command = get_new_command(command)
    new_command = new_command[0].split()

    # Unit

# Generated at 2022-06-22 00:53:02.309185
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3a mb s3://reins/buffe',
                                   'Invalid choice: \'mb\', maybe you meant: \
                                   move\nmove\nmake-bucket\nmv\nmb\n')) == [
        'aws s3a move s3://reins/buffe',
        'aws s3a make-bucket s3://reins/buffe',
        'aws s3a mv s3://reins/buffe',
        'aws s3a mb s3://reins/buffe']

# Generated at 2022-06-22 00:53:05.668609
# Unit test for function match
def test_match():
    assert match(Command("aws s3 ls", "Unknown options: 'foo'", ""))
    assert not match(Command("aws s3 ls foo", "", ""))



# Generated at 2022-06-22 00:53:16.016535
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command


# Generated at 2022-06-22 00:53:28.565673
# Unit test for function match

# Generated at 2022-06-22 00:53:37.325396
# Unit test for function match
def test_match():
    assert match(Command('aws s3 --help', 'usage: aws [options] <command> ' +
                        '<subcommand> [<subcommand> ...] ' +
                        '[parameters]\nTo see help text, you can run: ' +
                        'aws help\naws: error: argument command: Invalid choice: ' +
                        "'s3', maybe you meant: 's3api', 's3api-sync'\n\n" +
                        "See 'aws help' for descriptions of global parameters.",
                        ''))


# Generated at 2022-06-22 00:53:49.593297
# Unit test for function get_new_command

# Generated at 2022-06-22 00:53:59.343301
# Unit test for function get_new_command
def test_get_new_command():
    output = 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice: \'s3sdfsdfsdfsdf\', maybe you meant:\n* s3\n* s3api\n* s3-Outposts\n'
    script = 'aws s3sdfsdfsdfsdf'
    command = Command(script, output)
    assert get_new_command(command) == [
        'aws s3',
        'aws s3api',
        'aws s3-Outposts'
    ]

# Generated at 2022-06-22 00:54:09.505631
# Unit test for function get_new_command

# Generated at 2022-06-22 00:54:12.887381
# Unit test for function match
def test_match():
    assert match(Command("aws s3 mv foo bar", "usage: awscli [OPTIONS] COMMAND [ARGS]...\n\naws: error: argument [sub-command]: Invalid choice, maybe you meant:", ""))


# Generated at 2022-06-22 00:54:15.328053
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        "aws --version") == ['aws help --version']


enabled_by_default = True

# Generated at 2022-06-22 00:54:27.860693
# Unit test for function get_new_command

# Generated at 2022-06-22 00:54:39.822117
# Unit test for function match
def test_match():
    assert match(Command("aws s3 cp s3://BUCKETNAME/FILENAME DESTINATION", """
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

aws: error: argument command: Invalid choice, valid choices are:

s3api        |
s3           | 
"""))
    assert not match(Command("aws s3 cp s3://BUCKETNAME/FILENAME DESTINATION", """
Completed 256 Bytes/256 Bytes (0 Bytes/sec) with 1 file(s) remaining
download: s3://BUCKETNAME/FILENAME to DESTINATION
"""))

# Unit test

# Generated at 2022-06-22 00:54:51.940684
# Unit test for function match

# Generated at 2022-06-22 00:55:01.229110
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances --region us-east-1', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nYou must specify a region. You can also configure your region by running "aws configure".', ''))
    assert not match(Command('aws ec2 describe-instances --region us-east-1', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nYou must specify a region. You can also configure your region by running "aws configure".', ''))


# Generated at 2022-06-22 00:55:13.818903
# Unit test for function get_new_command
def test_get_new_command():
    output = """\
usage: aws [options] <command> <subcommand> [parameters]
aws: error: argument command: Invalid choice, valid choices are:

autoscaling                    | cloudformation                | cloudfront
cloudhsm                       | cloudsearch                   | cloudtrail
cloudwatch                     | datapipeline                  | directconnect
dynamodbstreams                | ec2                           | elasticache
elasticbeanstalk               | elastictranscoder             | elb
emr                            | iam                           | importexport
opsworks                       | rds                           | redshift
route53                        | s3                            | sdb
sns                            | sqs                           | storagegateway
sts                            | support                       | swf

maybe you meant:   dynamodb, deregister
"""

# Generated at 2022-06-22 00:55:19.711456
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    command = Command('aws configure', "usage: aws [options] [ ...]\naws: error: argument command: Invalid choice: 'configure', maybe you meant: \n    * configure\n    * configure", '/home/user/bin/aws')
    assert get_new_command(command) == ['/home/user/bin/aws configure']

# Generated at 2022-06-22 00:55:35.833875
# Unit test for function match

# Generated at 2022-06-22 00:55:41.062819
# Unit test for function match
def test_match():
    assert match(Command('clear', 'Invalid choice: \'clea\', maybe you meant:', ''))
    assert not match(Command('some_bad_command', 'Invalid choice: \'clea\', maybe you meant:', ''))



# Generated at 2022-06-22 00:55:49.762356
# Unit test for function match

# Generated at 2022-06-22 00:55:59.927237
# Unit test for function get_new_command
def test_get_new_command():
    # Input to unit test
    script = 'aws s3 ls s3://bucket/ --exclude * --include *.txt'
    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument operation: Invalid choice, valid choices are:
delete-objects | get-object-acl | get-object-torrent | get-object |
get-objects | list-objects | list-objects-v2 | put-object-acl |
put-object | restore-object"""

    # Expected output
    expected_output = ['aws s3 ls s3://bucket/ --exclude * --include *.txt']

    # Calling

# Generated at 2022-06-22 00:56:12.105254
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'usage: blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah maybe you meant:', ''))
    assert match(Command('aws help', 'usage: blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah maybe you meant:', ''))
    assert match(Command('aws help', 'usage: blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah blah maybe you meant:', ''))

# Generated at 2022-06-22 00:56:25.495883
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws s3 option foobar'

# Generated at 2022-06-22 00:56:29.365572
# Unit test for function get_new_command

# Generated at 2022-06-22 00:56:42.037900
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {
                'output': """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument <subcommand>: Invalid choice: 'sts2', maybe you meant:
  * start-session
  * list-session
  * cancel-session
  * get-session
  * stop-session""",
                'script': 'aws sts2'})

    options = ['aws sts start-session', 'aws sts list-session', 'aws sts cancel-session', 
            'aws sts get-session', 'aws sts stop-session']

    assert get_new_command(command) == options

# Generated at 2022-06-22 00:56:49.835379
# Unit test for function get_new_command

# Generated at 2022-06-22 00:56:53.238206
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (), {'script': "aws ec2 terminate-instances",
                                   'output': "Invalid choice: 'ec2 terminate-instances', maybe you meant:\n  * terminate-instances"})
    new_commands = get_new_command(command)
    assert new_commands[0] == "aws terminate-instances"

# Generated at 2022-06-22 00:57:06.881920
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws resourcegroupstaggingapi get-resources --region us-east-1 --filter "Key=target-type,Values=ec2-instance"'
    command += '\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
    command += 'To see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <sub'
    command += 'command> help\naws: error: argument --filter: Invalid choice: '
    command += "'target-type,Values=ec2-instance', maybe you meant:   client-reputation-score   client-location"
    command += "\nSee 'aws help' for descriptions of global parameters.\n"

# Generated at 2022-06-22 00:57:09.686811
# Unit test for function match
def test_match():
    assert match(Command('aws help', ''))
    assert match(Command('aws', ''))
    assert not match(Command('echo', ''))

# Generated at 2022-06-22 00:57:17.303448
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 wait until-exists --filters Name=instance-state-name,Values=running Name=instance-state-name,Values=shutting-down Instanceids=i-foo')) == ["aws ec2 wait until-exists --filters Name=instance-state-name,Values=running Instanceids=i-foo", "aws ec2 wait until-exists --filters Name=instance-state-name,Values=shutting-down Instanceids=i-foo"]

# Generated at 2022-06-22 00:57:29.589054
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws configservice describe-compliance'

# Generated at 2022-06-22 00:57:35.957963
# Unit test for function match
def test_match():
    command = Command("aws sfsfsf", "usage: aws [options] <command> "
                                    "<subcommand> [parameters]\n"
                                    "aws: error: argument <command>: "
                                    "Invalid choice, maybe you meant: "
                                    "s3\n"
                                    "* sdb\n", "")
    assert match(command) is True


# Generated at 2022-06-22 00:57:38.608928
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws --bogus')) == \
        ['aws --backup']


priority = 1000

# Generated at 2022-06-22 00:57:42.213262
# Unit test for function match
def test_match():
    assert match(Command('aws usage:'))
    assert not match(Command('aws'))
    assert not match(Command('aws list users'))


# Generated at 2022-06-22 00:57:46.372155
# Unit test for function get_new_command
def test_get_new_command():
	command = Command('aws ec2 help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice: \'ec2 help\', maybe you meant:  \n  elasticbeanstalk\n  ecr\n  ecs')
	result = get_new_command(command)
	assert len(result) == 3
	assert result[0] == 'aws elasticbeanstalk help'
	assert result[1] == 'aws ecr help'
	assert result[2] == 'aws ecs help'


# Generated at 2022-06-22 00:57:58.195326
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws s3api put-object --bucket test --body test.txt --key test/test.txt"
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --body: Invalid choice: 'test.txt', maybe you meant:\n    --body-checksum\n    --body-content-type\n    --body-content-md5\n    --body-content-sha2\n    --body-content-sha256\n    --body-content-sha1\n    --body-content-md5-sha256"

# Generated at 2022-06-22 00:58:10.016545
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'script': 'aws ec2 descibe-ruw', 'output': """Invalid choice: 'ec2'

Invalid choice: 'ec2', maybe you meant:
* ec2
  ecs
  ecr
  ecs-cli
  ecs-service
  ec2-instance-connect
  ec2-instance-connect
  ec2-instance-connect-cli
  ec2-instance-connect
  ec2-instance-connect-cli

See 'aws help' for descriptions of global parameters."""})
    new_commands = get_new_command(command)

# Generated at 2022-06-22 00:58:17.506570
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command("aws: error: argument subcommand: Invalid choice: 'ec2', maybe you meant:")
    assert result == ["aws: error: argument subcommand: Invalid choice: 'ec2', maybe you meant:"]

# Generated at 2022-06-22 00:58:26.276709
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

    assert get_new_command(Command('aws emr',
                                   'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice: \'emr\', maybe you meant:\n    emr',
                                   '')) == ['aws emr']

# Generated at 2022-06-22 00:58:32.519026
# Unit test for function get_new_command
def test_get_new_command():
    correct = ['aws sts get-session-token']
    mistake = 'aws sts get-session-tokens'

# Generated at 2022-06-22 00:58:44.546059
# Unit test for function match

# Generated at 2022-06-22 00:58:56.240829
# Unit test for function get_new_command
def test_get_new_command():
    expected = ["aws ec2 describe-instances", "aws ec2 describe-images"]
    assert expected == get_new_command(
        Command('aws ec2 describe-imags', '', 'Invalid choice: \'describe-imags\', maybe you meant:\n\t* describe-images\n\t* describe-instances\n\n\nusage: aws [options] [ ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\naws: error: argument command: Invalid choice, valid choices are:\n\tdescribe-images\n\tdescribe-instances', 'aws ec2 describe-imags'))

# Generated at 2022-06-22 00:58:58.282566
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 help'))
    assert not match(Command('ls'))


# Generated at 2022-06-22 00:59:08.660682
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws elbv2 create-load-balancer')) == \
           [u'aws elbv2 create-load-balancer --name', u'aws elbv2 create-load-balancer --type', u'aws elbv2 create-load-balancer --scheme']
    assert get_new_command(Command('aws cloudformation describe-stacks')) == \
           [u'aws cloudformation describe-stacks --stack-name']
    assert get_new_command(Command('aws cloudformation update-stack')) == \
           [u'aws cloudformation update-stack --template-body', u'aws cloudformation update-stack --template-url']

# Generated at 2022-06-22 00:59:19.468371
# Unit test for function match
def test_match():
    assert match(Command('aws', output='aws: error: argument subcommand: Invalid choice: "s3", maybe you meant: * s3api\n* s3'))
    assert not match(Command('aws', output='aws: error: argument subcommand: Invalid choice: "s3"'))
    assert match(Command('aws', output='aws: error: argument subcommand: Invalid choice: "polly", maybe you meant: * s3api\n* s3'))
    assert not match(Command('aws', output='aws: error: argument subcommand: Invalid choice: "polly", maybe you meant: * s3api\n* s3\n* more options'))


# Generated at 2022-06-22 00:59:27.175715
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 list instances --output table',
                      'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --output: Invalid choice, maybe you meant:\n  --output-file\n  --output-location\n  --output-format', 1))



# Generated at 2022-06-22 00:59:31.346375
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws s3 ls --sse'
    assert(get_new_command(command)) == ['aws s3 ls --sse-kms-key-id',
                                         'aws s3 ls --sse-c']

# Generated at 2022-06-22 00:59:42.600726
# Unit test for function get_new_command
def test_get_new_command():
    command = namedtuple('Command', ['script', 'output'])('aws s3 mb ...', 'usage: aws [options] <command> <subcommand> [<subcommand>...] ... Invalid choice: \'mb\', maybe you meant:\n\t*  mb')
    assert get_new_command(command) == ['aws s3 mb ...']

# Generated at 2022-06-22 00:59:53.252600
# Unit test for function match
def test_match():
    assert match(Command("aws --region us-west-1 ec2 stop-instances --instance-ids i-1234567890abcdef0", "usage: aws [options] <command> <subcommand> [<subcommand> ...]\naws: error: argument operation: Invalid choice, valid choices are:\n\tdescribe-instances\n\tdescribe-spot-instance-requests\nmaybe you meant: describe-instance")).output == "usage: aws [options] <command> <subcommand> [<subcommand> ...]\naws: error: argument operation: Invalid choice, valid choices are:\n\tdescribe-instances\n\tdescribe-spot-instance-requests\nmaybe you meant: describe-instance"


# Generated at 2022-06-22 00:59:55.159583
# Unit test for function match
def test_match():
    assert match(Command('aws', 'usage: aws [options] <command> <subcommand> '))


# Generated at 2022-06-22 01:00:07.914037
# Unit test for function match
def test_match():
    # Make sure the function match works properly
    # In an individual function, you can use a decorator to use the function match to match the specific command
    assert match(Command('aws', 'usage: aws [options] <command> <subcommand> [parameters]\n'))
    assert match(Command('aws', 'usage: aws [options] <command> <subcommand> [parameters]\n'
                         'aws: error: argument subp: Invalid choice, maybe you meant: \n'
                         '    sube\n'
                         '    subd\n'
                         ))

# Generated at 2022-06-22 01:00:19.924453
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    script = "aws cloudformation describe-stacks"

# Generated at 2022-06-22 01:00:32.450477
# Unit test for function match
def test_match():
	# Test 1
	str = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nUnknown options: -v, -h\n\nUnknown options: scp, -v, -l, -R, -h, -o, -u, -a, -t\n\naws: error: argument subcommand: Invalid choice, valid choices are:\n* configure\n* help\n"
	cmd = Command(str, "aws s3 cp test/s3://kwh-dev-s3/testfolder/ -v -l -R -h -o -u -a -t")

# Generated at 2022-06-22 01:00:44.109644
# Unit test for function get_new_command
def test_get_new_command():
    output = "usage: aws [options] <command> <subcommand> [parameters]\n" 
    output += "aws: error: argument <command>: Invalid choice, maybe you meant:\n"
    output += "  * <command>\n"
    output += "    <subcommand>\n"
    output += "    <subcommand>\n"
    output += "    <subcommand>\n"
    output += "    <subcommand>\n"
    output += "aws: error: argument <command>: Invalid choice, maybe you meant:\n"
    output += "  * <command>\n"
    output += "    <subcommand>\n"
    output += "    <subcommand>\n"
    output += "    <subcommand>\n"

# Generated at 2022-06-22 01:00:53.386418
# Unit test for function match
def test_match():
    assert(match(Command('aws keypair help', 'aws: error: argument subcommand: Invalid choice: \'keypair\', maybe you meant:\n    cloudformation\n    cloudwatch\n     * ec2\n    elasticache\n    elasticbeanstalk\n    elb\n    iam\n    rds\n    route53\n    s3\n    sns\n    sqs\n')) == True)
    assert(match(Command('aws s3 help', 'aws: error: argument subcommand: Invalid choice: \'s3\', maybe you meant:    cloudformation    cloudwatch     * ec2    elasticache    elasticbeanstalk    elb    iam    rds    route53    sns    sqs')) == True)

# Generated at 2022-06-22 01:01:01.733378
# Unit test for function match
def test_match():
    assert not match(Command('rm -rf ~/.config/fish/completions'))
    assert match(Command('aws foo bar', 'usage: aws [options] <command> \
<subcommand> [<subcommand> ...] [parameters]\nTo see help text, \
you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nUnknown options: [bar]', 'aws foo bar'))
