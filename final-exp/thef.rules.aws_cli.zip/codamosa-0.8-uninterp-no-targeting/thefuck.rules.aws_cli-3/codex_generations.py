

# Generated at 2022-06-22 00:51:08.696215
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws s3 cp test s3://test1/",
        "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n"
        "       aws: error: argument operation: Invalid choice, valid choices are:\n"
        "                 cp\n"
        "                 ls\n"
        "                 mb\n"
        "                 mv\n"
        "                 rb\n"
        "                 rm\n"
        "                 sync\n"
        "        Maybe you meant:\n"
        "                 mv\n"
        "                 cp\n"
        "                 sync")

# Generated at 2022-06-22 00:51:20.706417
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws s3 cp s3://bucke --recursive /tmp/"

# Generated at 2022-06-22 00:51:24.650814
# Unit test for function get_new_command

# Generated at 2022-06-22 00:51:35.124922
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws help --configure', '''usage: aws [options] [parameters]
aws: error: argument command: Invalid choice, maybe you meant:
  * configure
        \n''')) == ['aws configure --configure', 'aws help configure']

    assert get_new_command(Command('aws help --configure', '''usage: aws [options] [parameters]
aws: error: argument command: Invalid choice, maybe you meant:
  * configure
  * help
        \n''')) == ['aws configure --configure', 'aws help --configure', 'aws help configure']



# Generated at 2022-06-22 00:51:42.953683
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws configure set profile $profile_name --region $region', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument set: Invalid choice: \'$profile_name\', maybe you meant:\n\n* profile\n* profile-name\n* profile-names\n', '', '')) == ['aws configure set profile $profile_name --region $region', 'aws configure set profile-name --region $region', 'aws configure set profile-names --region $region']

# Generated at 2022-06-22 00:51:43.701392
# Unit test for function get_new_command

# Generated at 2022-06-22 00:51:56.104502
# Unit test for function get_new_command

# Generated at 2022-06-22 00:52:05.154261
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 get-tags')) == ['aws ec2 get-console-output']
    assert get_new_command(Command('aws ec2 get-tags --foo bar')) == ['aws ec2 get-console-output --foo bar']
    assert get_new_command(Command('aws ec2 get-tags --foo bar baz')) == ['aws ec2 get-console-output --foo bar baz']
    assert get_new_command(Command('aws --verbose ec2 get-tags --foo bar baz')) == ['aws --verbose ec2 get-console-output --foo bar baz']

# Generated at 2022-06-22 00:52:07.801672
# Unit test for function match
def test_match():
    assert match(Command('aws --output table ecr list-images --repository-name'))



# Generated at 2022-06-22 00:52:14.156549
# Unit test for function match
def test_match():
    if not match(Command('aws s3 mb s3://test', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]')):
        raise AssertionError('Output no match')
    if match(Command('aws s3 mb s3://test', None)):
        raise AssertionError('None output no match')


# Generated at 2022-06-22 00:52:26.223520
# Unit test for function get_new_command

# Generated at 2022-06-22 00:52:32.867085
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws test", "Invalid choice: 'test', maybe you meant:\n* test-subcommand")
    assert get_new_command(command) == ["aws test-subcommand"]
    command = Command("aws test", "Invalid choice: 'test', maybe you meant:\n* test1\n* test2")
    assert get_new_command(command) == ["aws test1", "aws test2"]

# Generated at 2022-06-22 00:52:44.359936
# Unit test for function get_new_command

# Generated at 2022-06-22 00:52:46.254244
# Unit test for function match
def test_match():
    assert 1 == len(list(filter(lambda c: match(c), get_commands())))


# Generated at 2022-06-22 00:52:50.474942
# Unit test for function get_new_command
def test_get_new_command():
    output = '''"Invalid choice: 'toto', maybe you meant:

* toto
'''
    script = 'aws toto'
    new_command = get_new_command(Command(script, output))
    assert new_command == ['aws toto']

# Generated at 2022-06-22 00:53:01.754879
# Unit test for function match

# Generated at 2022-06-22 00:53:13.737073
# Unit test for function get_new_command
def test_get_new_command():
    aws_command = 'aws help'
    command_output = '[AWS cli v1.10.20]\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters] \nTo see help text, you can run:\n\naws help\naws <command> help\naws <command> <subcommand> help\naws: error: argument command: Invalid choice, maybe you meant: \n'

# Generated at 2022-06-22 00:53:19.450185
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("aws ec2 describe-instances --filter Name=instance-id,Value=i-12345678", "")) == [
        'aws ec2 describe-instances --filters Name=instance-id,Values=i-12345678']
    assert get_new_c

# Generated at 2022-06-22 00:53:30.801689
# Unit test for function match

# Generated at 2022-06-22 00:53:40.578917
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 mb s3://', 
        'Error: Invalid choice: "mb", maybe you meant:\n\n* mb', 
        '')) == ['aws s3 mb s3://']
    assert get_new_command(Command('aws s3 mb s3://', 
        'Error: Invalid choice: "mb", maybe you meant:\n\n* mb\n* ls\n* rb', '')
        ) == ['aws s3 mb s3://', 'aws s3 ls s3://', 'aws s3 rb s3://']

# Generated at 2022-06-22 00:53:54.089986
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    output = """
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

aws: error: argument subcommand: Invalid choice, valid choices are:

(invalid_choice)

usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

aws: error: argument subcommand: Invalid choice, valid choices are:

* (option_1)
* (option_2)
"""

# Generated at 2022-06-22 00:54:06.702673
# Unit test for function match

# Generated at 2022-06-22 00:54:14.779571
# Unit test for function get_new_command
def test_get_new_command():
    mock_command = types.Command('aws ec2 describe-instances', 'usage: aws [options] <command> <a'
                                                              'rguments>\naws: error: argument subco'
                                                              'mmand: Invalid choice: \'describe-instance'
                                                              '\', maybe you meant:\n* describe-inst'
                                                              'ances\n\nSee \'aws help\' for descriptions of global a'
                                                              'rguments.\n')
    assert get_new_command(mock_command) == ['aws ec2 describe-instances', 'aws ec2 describe-instances']

# Generated at 2022-06-22 00:54:24.544218
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances xxx', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, valid choices are:\n    configure\n    help\n    ec2\n    ...\nInvalid choice: \'xxx\', maybe you meant:\n    ec2\n    s3\n', 1)) == True


# Generated at 2022-06-22 00:54:26.169574
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ')) == ['aws ']

# Generated at 2022-06-22 00:54:34.980513
# Unit test for function match
def test_match():
    command = Command('aws ec2', '', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\naws: error: argument <command>: Invalid choice, valid choices are:\n\n* ec2\n\nMaybe you meant:\n\n* ec2\n\n')
    assert match(command)


# Generated at 2022-06-22 00:54:37.336223
# Unit test for function match
def test_match():
    assert match(Command('aws group'))
    assert not match(Command('aws'))
    assert not match(Command('ls'))


# Generated at 2022-06-22 00:54:40.441979
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-vpcs', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument subcommand: Invalid choice: \'describe-vpcs\', maybe you meant: \n  * describe-vpcs\n  * describe-vpc-attribute\n', None))
    assert not match(Command('aws ec2 describe-vpcs', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument subcommand: Invalid choice: \'describe-vpcs\', maybe you meant: \n  * describe-vpcs\n  * describe-vpc-attribute\n', None))


# Generated at 2022-06-22 00:54:48.295092
# Unit test for function match

# Generated at 2022-06-22 00:55:00.369392
# Unit test for function get_new_command
def test_get_new_command():
	command = Command('aws ec2 describe-volumes --region us-west-2',
		'usage: aws [options] [ ...] [parameters]\naws: error: argument operation: Invalid choice',
		'maybe you meant: ec2')
	assert get_new_command(command) == ['aws ec2 describe-volumes --region us-west-2']
	command = Command('aws s3 ls',
		'usage: aws [option] [ ...] [args]\naws: error: argument operation: Invalid choice',
		'maybe you meant: s2')
	assert get_new_command(command) == ['aws s2 ls']

# Generated at 2022-06-22 00:55:03.432764
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 sync', '')
    assert get_new_command(command) == ['aws s3 sync']

# Generated at 2022-06-22 00:55:06.162674
# Unit test for function match
def test_match():
    assert match(Command('aws s3 cp foo bar', ''))
    assert not match(Command('ls foo bar', ''))


# Generated at 2022-06-22 00:55:10.308468
# Unit test for function match
def test_match():
    assert match(Command('aws --test --test', ''))
    assert match(Command('aws hyhy', ''))
    assert match(Command('aws --test --test', ''))


# Generated at 2022-06-22 00:55:21.883388
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances',
                         'usage: aws [options] &lt;command&gt; &lt;subcommand&gt; [parameters]\naws: error: argument &lt;command&gt;: Invalid choice: \'ec2 describe-instances\', maybe you meant:\n  ec2 describe-snapshots\n  ec2 describe-spot-instance-requests\n  route53 describe-reusable-delegation-sets\n  ec2 describe-incidents\n  rds describe-db-cluster-snapshots\n'))
    assert not match(Command('ls', 'usage: ls [-ABCFGHLOPRSTUWabcdefghiklmnopqrstuwx1] [file ...]'))


# Generated at 2022-06-22 00:55:33.509612
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls s3://'))
    assert match(Command('aws s3 cp a s3://'))
    assert match(Command('aws s3 cp s3:// s3://'))
    assert match(Command('aws s3 cp a s3://'))
    assert match(Command('aws s3 ls s3://'))
    assert not match(Command('ls'))
    assert not match(Command('apt-get moo'))
    assert not match(Command('aws'))
    assert not match(Command('aws s3'))
    assert not match(Command('aws s3 ls'))
    assert not match(Command('aws s3 ls s3://'))


# Generated at 2022-06-22 00:55:40.698050
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls --region uu-west-2', '', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\naws: error: argument subcommand: Invalid choice: \'-region\', maybe you meant:', '')) == ['aws s3 ls --region us-west-2', 'aws s3 ls --region eu-west-2']

# Generated at 2022-06-22 00:55:43.858673
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances --region us-east-1 asd --instance-ids i-1234567890abcdef0'))
    assert not match(Command('aws config'))



# Generated at 2022-06-22 00:55:51.106924
# Unit test for function match
def test_match():
    pattern = re.compile("(?<=Invalid choice: ')(.*)(?=', maybe you meant:)")
    assert re.search(pattern, "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice: 'nick', maybe you meant: help")


# Generated at 2022-06-22 00:56:00.671766
# Unit test for function get_new_command

# Generated at 2022-06-22 00:56:06.632727
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws cloudfront')) == ['aws cloudfront']
    assert get_new_command(Command('aws cloudfront list')) == ['aws cloudfront list-distributions']
    assert get_new_command(Command('aws cloudfront list-distributioness')) == ['aws cloudfront list-distributions']


# Generated at 2022-06-22 00:56:16.699874
# Unit test for function match

# Generated at 2022-06-22 00:56:27.980462
# Unit test for function match
def test_match():
    test_command = type('obj', (object,), {'output': 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice: \'deploy\', maybe you meant: deploy\n* deploy', 'script': 'aws deploy'})()
    assert match(test_command)

# Generated at 2022-06-22 00:56:34.082574
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls', '')) == ['aws s3 list']
    assert get_new_command(Command('aws s3 ls non-empty', '')) == ['aws s3 list non-empty']
    assert get_new_command(Command('aws s3 ls --region us-west-1', '')) == ['aws s3 list --region us-west-1']

# Generated at 2022-06-22 00:56:37.792436
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://test-bucket', ''))
    assert not match(Command('aws s3 mb s3://test-bucket', '', None))


# Generated at 2022-06-22 00:56:47.707985
# Unit test for function get_new_command
def test_get_new_command():
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n" \
             "To see help text, you can run:\n" \
             "aws help\n" \
             "aws <command> help\n" \
             "aws <command> <subcommand> help\n" \
             "aws: error: argument --instance-id: Invalid choice: 'instance2', maybe you meant:\n" \
             "* instance1"
    command = Command("aws --instance-id inctance2", output)
    assert ("aws --instance-id instance1",) == get_new_command(command)



# Generated at 2022-06-22 00:56:54.871387
# Unit test for function get_new_command
def test_get_new_command():
    command_1 = "aws ec2 describe-regions --region us-east-1"
    command_2 = "aws configure --profile prod set region us-east-1"

# Generated at 2022-06-22 00:57:06.701321
# Unit test for function get_new_command
def test_get_new_command():
    output = u"""
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, valid choices are:

list-buckets                |  List all buckets in your account
make-bucket                 |  Create a new bucket
get-bucket-location         |  Get the Region where a bucket was created
"""
    command = "aws make-buket s3"
    new_command = [['aws', 'make-bucket', 's3']]
    assert get_new_command(MagicMock(script=command, output=output)) == new_command


# Generated at 2022-06-22 00:57:18.697774
# Unit test for function get_new_command
def test_get_new_command():
    # Usage: aws s3 mb s3://BUCKET [--region <value>] [--create-bucket-configuration LocationConstraint=<value>] [...]]
    # Invalid choice: 'mb', maybe you meant: mfa
    command = Command('aws s3 mb s3://BUCKET', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument <command>: Invalid choice, valid choices are:\n\tcp\n\tls\n\tmv\n\trm\n\tmb\n\tsync\n\twebsite\n', 'aws')
   

# Generated at 2022-06-22 00:57:21.711499
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('aws ec2 describe-instance --instance-id i-XXXXXXXX') == ['aws ec2 describe-instances --instance-id i-XXXXXXXX']

# Generated at 2022-06-22 00:57:24.578511
# Unit test for function match
def test_match():
    command = Command("", "aws usage: maybe you meant:")
    assert match(command) == True


# Generated at 2022-06-22 00:57:42.821830
# Unit test for function get_new_command

# Generated at 2022-06-22 00:57:54.397628
# Unit test for function get_new_command
def test_get_new_command():
    cd = for_app('aws')

    sd = re.search(INVALID_CHOICE, "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:                                                                                                                       \n\n  aws help                                                                                                                                                                                                                            \n  aws <command> help                                                                                                                                                                                                                    \n  aws <command> <subcommand> help                                                                                                                                                                                                       \n\naws: error: argument subcommand: Invalid choice: 'eup', maybe you meant:                                                                                                                                                                \n  event-pattern  (eup)")
    assert sd.group(0) == 'eup'



# Generated at 2022-06-22 00:58:06.150014
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('aws s3 ls',
                                   '')) == ["aws s3 ls"]

# Generated at 2022-06-22 00:58:09.640832
# Unit test for function match
def test_match():
    assert match(Command('aws --version', "usage:"
                 'Invalid choice: \'--version\', maybe you meant:\n  --version \n  --verbose \n  --profile', ''))


# Generated at 2022-06-22 00:58:22.171464
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws autoscaling update-auto-scaling-group --min-size 0 --max-size 0 --auto-scaling-group-name my-asg"
    output = """\
      Invalid choice: 'upadte-auto-scaling-group', maybe you meant:
          * update-auto-scaling-group
          * create-or-update-tags
          * create-or-update-scheduled-action
          * create-or-update-load-balancer-target-group
          * put-lifecycle-hook
          * put-notification-configuration
          * put-scaling-policy
          * put-scheduled-update-group-action
          * execute-policy
    """

# Generated at 2022-06-22 00:58:29.529781
# Unit test for function match
def test_match():
    assert match(Command(script='aws something'))
    assert match(Command(script='aws something',
        output='usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\naws: error: argument command: Invalid choice, maybe you meant:\n  configure   configure aws services.\n  help        Show this message and exit.\n'))



# Generated at 2022-06-22 00:58:42.059729
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-instnace', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
        'To see help text, you can run:\n'
        '\n'
        '  aws help\n'
        '  aws <command> help\n'
        '  aws <command> <subcommand> help\n'
        'aws: error: argument command: Invalid choice, valid choices are:\n'
        'configure\n'
        '*\n'
        'ec2\n'
        's3\n'
        '\n'
        'Unknown options: describe-instnace', 'aws ec2 describe-instnace')) == ['aws ec2 describe-instances']

# Generated at 2022-06-22 00:58:46.847589
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws lambda get-event-source-mappings --max-item ERROR', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n  error: argument --max-item: invalid int value: \'ERROR\'; maybe you meant:')
    assert get_new_command(command) == ['aws lambda get-event-source-mappings --max-items ERROR']

# Generated at 2022-06-22 00:58:55.407796
# Unit test for function get_new_command
def test_get_new_command():
    assert (len(get_new_command(Command('aws ec2 run-instances --image-id ami-123')))) == 2
    assert (get_new_command(Command('aws ec2 run-instances --image-id ami-123'))[0] == 'aws ec2 run-instances --image-id ami-12345')
    assert (get_new_command(Command('aws ec2 run-instances --image-id ami-123'))[1] == 'aws ec2 run-instances --image-id ami-12')

# Generated at 2022-06-22 00:59:02.853136
# Unit test for function get_new_command

# Generated at 2022-06-22 00:59:18.411750
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws s3 help'
    new_commands = get_new_command(command)
    assert len(new_commands) == 5
    assert new_commands[0] == 'aws mb s3://'
    assert new_commands[1] == 'aws mv s3://'
    assert new_commands[2] == 'aws presign s3://'
    assert new_commands[3] == 'aws rb s3://'
    assert new_commands[4] == 'aws rm s3://'

# Generated at 2022-06-22 00:59:21.544760
# Unit test for function match
def test_match():
    assert not match(Command("", ""))
    assert match(Command("aws", "aws: error: invalid choice: 'fake', maybe you meant: "))


# Generated at 2022-06-22 00:59:33.397244
# Unit test for function get_new_command

# Generated at 2022-06-22 00:59:43.445292
# Unit test for function get_new_command
def test_get_new_command():
    """
    Unit tests for function get_new_command
    """
    from thefuck.types import Command
    from tests.utils import CommandResult

    # Test case: Successful match of Invalid choice
    command = Command('aws s3 ls MYBUCKET', CommandResult("\naws: error: argument subcommand: Invalid choice: 's3', mayb\
        e you meant:\n\t\t     cp\n\t\t     mb\n\t\t     mv\n\n\nusage: aws [options] [ ...] [parameters]\n\nTo see h\
        elp text, you can run:\n\n  aws help\n  aws help\n  aws help\n", 
        "aws s3 ls MYBUCKET\n"))
    output = get_new_command

# Generated at 2022-06-22 00:59:47.383778
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws ec2 descripe-instances", "aws: error: argument subcommand: Invalid choice: 'descripe-instances', maybe you meant:")

# Generated at 2022-06-22 00:59:56.097344
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 start-instances i-1fa'))

# Generated at 2022-06-22 01:00:08.984090
# Unit test for function get_new_command
def test_get_new_command():
    cmd = 'aws s3 cp s3://my-bucket/my-image.png img.png'

# Generated at 2022-06-22 01:00:14.146309
# Unit test for function match
def test_match():
    assert match(Command('aws s3', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n'
                         'aws: error: argument command: Invalid choice, '
                         "maybe you meant: 's'\n\n* s3"
                         ))


# Generated at 2022-06-22 01:00:17.946651
# Unit test for function match
def test_match():
    assert match(Command('aws --help', "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:")).groups() == ('--help',)


# Generated at 2022-06-22 01:00:23.631526
# Unit test for function get_new_command
def test_get_new_command():
    command = make_command("aws ec2 create-tag foo bar --tag-key baz --tag-value qux")
    output = "Unknown options: --tag-key, --tag-value"
    command.output = output
    assert get_new_command(command) == ['aws ec2 create-tags --tags Key=baz,Value=qux foo']

enabl

# Generated at 2022-06-22 01:00:47.667986
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-22 01:00:59.573861
# Unit test for function get_new_command
def test_get_new_command():
    command_error_output = '''
usage: aws [options] <command> <subcommand> [parameters]
aws: error: argument command: Invalid choice, maybe you meant:
  * deploy
  * dynamodb
  * ec2
  * ecr
  * ecs
  * efs
  * elb
  * emr
  * s3
  * simple-workflow
  * support
(choose from 'deploy', 'dynamodb', 'ec2', 'ecr', 'ecs', 'efs', 'elb', 'emr', 's3', 'simple-workflow', 'support')
'''
    new_command = get_new_command(Command('aws', command_error_output))