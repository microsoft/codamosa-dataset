

# Generated at 2022-06-22 00:51:09.833695
# Unit test for function get_new_command
def test_get_new_command():
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n"\
             "aws: error: argument <subcommand>: Invalid choice: 's3', maybe you meant: \n"\
             "  sts\n"\
             "  s3api\n"\
             "  s3cp\n"\
             "  s3ls\n"\
             "  s3\n"
    command = Command("aws s3", output)
    new_commands = get_new_command(command)

    assert new_commands == ['aws sts', 'aws s3api', 'aws s3cp', 'aws s3ls', 'aws s3']

# Generated at 2022-06-22 00:51:21.786648
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws s3 cp s3://bluk/foo.txt foo.txt"
    output = "aws: error: argument operation: Invalid choice, valid choices are:\ncp\ncp-object\n"
    command = type('Command', (object,), {'script': script, 'output': output})

    assert get_new_command(command) == ["aws s3 cp-object s3://bluk/foo.txt foo.txt"]

    output = "aws: error: argument operation: Invalid choice, valid choices are:\nfoo\nbar\nbaz\n"
    command = type('Command', (object,), {'script': script, 'output': output})


# Generated at 2022-06-22 00:51:28.385414
# Unit test for function match
def test_match():
    assert match(Command('aws elbv2', 'usage: aws [options] <command> <subcommand> [parameters]\nTo see help text, you can run:')
                 .with_output('usage: aws [options] <command> <subcommand> [parameters]\nTo see help text, you can run: aws help\naws: error: argument operation: Invalid choice: "elbv2", maybe you meant: elbv2\n * elbv2\n'))

# Generated at 2022-06-22 00:51:40.563665
# Unit test for function get_new_command
def test_get_new_command():
    print("Unit test get_new_command().\n")
    command = Command("aws s3 lst",
                      "usage: aws [options] " +
                      "\\<command> \\<subcommand> [\\<subcommand> ...] [parameters]\n" +
                      "To see help text, you can run:\n" +
                      "aws help\n" +
                      "aws \\<command> \\<subcommand> help\n" +
                      "aws \\<command> \\<subcommand> \\<subcommand> help\n\n" +
                      "Unknown options: " +
                      "lst\n" +
                      "aws: error: argument command: Invalid choice: 'lst', maybe you meant:\n" +
                      "list            List buckets in your account\n",
                      "")
    result = get_new_

# Generated at 2022-06-22 00:51:53.421032
# Unit test for function get_new_command
def test_get_new_command():
     command_string_1 = "aws ec2 describe-regions --region region-code"
     command_string_2 = "aws ec2 describe-regions --region not-valid"
     command_string_3 = "aws ec2 describe-regions --region ca-central-1"
     command_output_1 = "aws: error: argument --region: Invalid choice: 'region-code', maybe you meant: \n  \n  * ca-central-1"
     command_output_2 = "aws: error: argument --region: Invalid choice: 'not-valid', maybe you meant: \n  \n  * ca-central-1"
     command_output_3 = "aws: error: argument --region: Invalid choice: 'ca-central-1', maybe you meant: \n  \n  * ca-central-1"
     command_

# Generated at 2022-06-22 00:52:05.245431
# Unit test for function match
def test_match():
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...]\n                [parameters]\nTo see help text, you can run:\n\n  aws help\n\nUnknown options: --des, --description\nInvalid choice: '--description', maybe you meant:  --description,\n                                                   --destination,\n                                                   --default-description,\n                                                   --default-instance-name,\n                                                   --default-volume-type"
    assert(match(Command("aws ec2 create-security-group --des 'Physics Group'")) == True)
    assert(match(Command("aws ec2 create-security-group --description 'Physics Group'")) == False)

# Generated at 2022-06-22 00:52:07.908219
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script='aws ec2 help')) == ['aws ec2 help']

# Generated at 2022-06-22 00:52:17.589150
# Unit test for function get_new_command
def test_get_new_command():
    data = '''aws: error: argument command: Invalid choice: 'batch-ge', maybe you meant:
        * batch-get-item
        * batch-write-item
        * get-item
        * put-item
        '''
    command = type('', (), {})()
    command.output = data
    command.script = 'aws batch-ge'
    new_script = get_new_command(command)
    assert new_script == ['aws batch-get-item', 'aws batch-write-item', 'aws get-item', 'aws put-item']

# Generated at 2022-06-22 00:52:28.571905
# Unit test for function match
def test_match():
    assert match(Command('aws --h', 'usage', 'Invalid choice: "--AWS-PROFILE", maybe you meant:\n\n \
    \* cw\n\n \
    \* ec2\n\n \
    \* help\n\n \
    \* iam\n\n \
    \* s3\n\n'))
    assert not match(Command('aws --h', 'usage', 'Invalid choice: "foo", maybe you meant:\n\n \
    \* cw\n\n \
    \* ec2\n\n \
    \* help\n\n \
    \* iam\n\n \
    \* s3\n\n'))

# Generated at 2022-06-22 00:52:31.553545
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 to-do', 'Invalid choice: \'to-do\', maybe you meant:\ntodo  to-do\n'))


# Generated at 2022-06-22 00:52:44.359455
# Unit test for function get_new_command
def test_get_new_command():
    script = ["aws", "s3", "ls"]
    output = """Invalid choice: 'ls', maybe you meant:
                * ls
                * ls-backup
                * lsbackup
                aws: error: argument subcommand: Invalid choice, valid choices are:
                cp | la | mb | mv | rb | rm | sync | website"""
    command = Command(script, output)
    new_commands = get_new_command(command)
    # We expect that the new command is the same as the original command but with the first argument changed to any one of the options
    assert new_commands[0] == ["aws", "s3", "la"] or new_commands[1] == ["aws", "s3", "ls"] or new_commands[2] == ["aws", "s3", "ls-backup"]

# Generated at 2022-06-22 00:52:51.876732
# Unit test for function match
def test_match():
    assert match(Command("aws ec2 describe-instances", "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice: 'ec2 describe-instances', maybe you meant:\n\n  * ec2\n  * ec2-utils", 1))


# Generated at 2022-06-22 00:52:56.046407
# Unit test for function match
def test_match():
    assert_true(match(Command('aws ec2 describe-spot-price-history --start-time 2016-09-07')))
    assert_false(match(Command('aws ec2 describe-spot-price-history --end-time 2016-09-07')))


# Generated at 2022-06-22 00:53:04.006626
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws help --asdf"
    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:
  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument --asdf: Invalid choice, valid choices are:
  help
Invalid choice: '--asdf', maybe you meant one of:
  help
"""
    print(get_new_command(Command(command, output)))

# Generated at 2022-06-22 00:53:15.309174
# Unit test for function match

# Generated at 2022-06-22 00:53:19.937928
# Unit test for function match
def test_match():
    assert match(Command('aws help ec2', ''))
    assert match(Command('aws help ec2 start-instances', ''))
    assert not match(Command('aws help', ''))
    assert not match(Command('aws help ec2 start-instances', ''))


# Generated at 2022-06-22 00:53:24.382738
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://hbcs --region us-east-1'))
    assert not match(Command('aws s3 mb s3://hbcs --region us-west-1'))



# Generated at 2022-06-22 00:53:31.926254
# Unit test for function match
def test_match():
    assert(match(Command('aws configure --profile se', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\naws: error: argument --profile: Invalid choice: \'se\', maybe you meant:', '')) == True)
    assert(match(Command('aws configure', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\naws: error: argument --profile: Invalid choice: \'se\', maybe you meant:', '')) != True)
    assert(match(Command('', '', '')) != True)


# Generated at 2022-06-22 00:53:37.840222
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 start-instances --instance-ids i-1234')
    output = """
    A client error (InvalidInstanceID.Malformed) occurred when calling the StartInstances operation: Invalid id: "i-1234"

    usage: aws [options] &lt;command&gt; &lt;subcommand&gt; [parameters]
    To see help text, you can run:

      aws help
      aws &lt;command&gt; help
      aws &lt;command&gt; &lt;subcommand&gt; help

    aws: error: argument instance-ids: Invalid choice: 'i-1234', maybe you meant:
    """
    assert get_new_command(Command(command.script, output)) == ["aws ec2 start-instances --instance-ids i-12345"]

# Generated at 2022-06-22 00:53:49.796300
# Unit test for function get_new_command
def test_get_new_command():
    test_command = Command('aws ec2 help')

# Generated at 2022-06-22 00:54:00.050509
# Unit test for function get_new_command

# Generated at 2022-06-22 00:54:04.256457
# Unit test for function get_new_command

# Generated at 2022-06-22 00:54:15.394948
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws iam list-users'
    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument command: Invalid choice, valid choices are:

configure  | help  | iam  | list-users

see: 'aws help'
ERROR: Invalid choice: 'list-users', maybe you meant:
 * admin-list-users
 * list-users
 * list-users-management
 * migrate-user
 * modify-user
 * remove-user-from-group
 * reset-user-password
 * update-user
"""

# Generated at 2022-06-22 00:54:27.860748
# Unit test for function get_new_command

# Generated at 2022-06-22 00:54:39.821933
# Unit test for function match
def test_match():
    assert not match(Command('ssh user@192.168.1.1',
        'ssh: Could not resolve hostname 192.168.1.1: Name or service not known'))

# Generated at 2022-06-22 00:54:51.940570
# Unit test for function match

# Generated at 2022-06-22 00:54:58.746656
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws codestar list-projects", "usage: aws [options] <command> <subcommand> [parameters]\n\naws: error: argument command: Invalid choice, valid choices are:\n\tevents\n\tiot\n\nUnknown options: codestar\n", "aws")
    assert get_new_command(command) == ["aws events list-projects", "aws iot list-projects"]


# Generated at 2022-06-22 00:55:11.548808
# Unit test for function get_new_command

# Generated at 2022-06-22 00:55:18.378532
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 ls --versoin', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run: aws help\naws: error: argument --versoin: Invalid choice, maybe you meant:\n        --version', '')
    assert get_new_command(command) == ['aws s3 ls --version']


# Generated at 2022-06-22 00:55:25.388043
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws ec2 help")
    assert get_new_command(command) == ["aws ec2 help"]
    # Test for invalid command "aws ec2 serd" (mistake is "serd")
    command = Command("aws ec2 serd")
    assert get_new_command(command) == ["aws ec2 server-certificate"]
    # Test for invalid command "aws config list" (mistake is "list")
    command = Command("aws config list")
    assert get_new_command(command) == ['aws config lists', 'aws config list-types']

# Generated at 2022-06-22 00:55:42.407891
# Unit test for function get_new_command

# Generated at 2022-06-22 00:55:43.697345
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 d', '')) == ['aws ec2 describe-instances']

# Generated at 2022-06-22 00:55:47.797930
# Unit test for function match
def test_match():
	assert match(Command('aws s3 help'))

# Generated at 2022-06-22 00:55:59.026424
# Unit test for function get_new_command
def test_get_new_command():
    output = '''usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument operation: Invalid choice, valid choices are:

add-iam-policy-from-json
add-iam-role
add-layer-version-permission
add-user-from-saml
aggregate-it
publish-confidential-it

'''
    command = 'aws <command> <subcommand> <subcommand>'

# Generated at 2022-06-22 00:56:09.483386
# Unit test for function get_new_command
def test_get_new_command():
    output = """aws: error: unrecognized arguments: --test_arg
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument --test_arg: Invalid choice: '--test_arg', maybe you meant:
* --tenancy
* --test"""

    command = type("Command", (object,), {"output": output, "script": "aws --test_arg"})
    assert get_new_command(command) == ['aws --tenancy', 'aws --test']

# Generated at 2022-06-22 00:56:15.953847
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances', "Usage: aws [options] <command> <subcommand> [<subcommand> ..."))
    assert match(Command('aws ec2 desscribe-instances', "Invalid choice: 'desscribe-instances', maybe you meant:\n * describe-instances\n * describe-snapshots\n * describe-images"))
    assert not match(Command('aws ec2 desscribe-instances', "Invalid choice: 'desscribe-instances'"))
    assert not match(Command('aws ec2 desscribe-instances', "Unknown option"))



# Generated at 2022-06-22 00:56:26.269242
# Unit test for function match
def test_match():
    command = Command('aws version', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, maybe you meant: ec2 | elasticloadbalancing | iam | s3 | cloudformation | cloudfront | cloudwatch | dynamodb | opsworks | rds | route53 | ses | sns | sqs | storagegateway | sts | support\n')
    assert match(command) == True



# Generated at 2022-06-22 00:56:31.939308
# Unit test for function get_new_command
def test_get_new_command():
  assert get_new_command(Command('aws s3 ls', 'usage: aws [...)', '', 1, '')) == ['aws s3 ls']
  assert get_new_command(Command('aws s3 ls', 'Invalid choice: \'foo\', maybe you meant:', '', 1, '')) == []

# Generated at 2022-06-22 00:56:35.694557
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls [bucket_name]', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument operation: Invalid choice, valid choices are:\n\n                                        cp\n                                        mv\n                                        rm\n                                        sync\n                                        ls\n                                        presign\n                                        (maybe you meant: )'))


# Generated at 2022-06-22 00:56:38.458554
# Unit test for function match
def test_match():
    assert match(Command('aws s3api list-buckets', 'usage: some command\n... maybe you meant:', '', 1, None))
    assert match(Command('aws s3api list-buckets', 'usage: some command\n...', '', 1, None)) is False



# Generated at 2022-06-22 00:56:50.503546
# Unit test for function get_new_command
def test_get_new_command():
    print(get_new_command('aws command not-exists'))
    print(get_new_command('''aws: error: argument command: Invalid choice, maybe you meant:
  table
  rds
  kinesis
  configservice
  s3
  cloudsearch
  sns
  ebs
  iam
  glacier
  dynamodb
  ses
  support
  ec2
  opsworks
  importexport
  autoscaling
  elb
  directconnect
  cloudfront
  route53
  sqs
  sts
  cloudwatch
  sdb'''))
test_get_new_command()

# Generated at 2022-06-22 00:57:01.764810
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n  ls\n  cp\n  sync\n  mb\n  rb\n  ls\n  website\n  mv\n  rm\n  presign\nSee \'aws help\' for descriptions of global parameters.\n'))

# Generated at 2022-06-22 00:57:07.001347
# Unit test for function get_new_command
def test_get_new_command():
    with open('tests/commands/aws_cli_command.txt', 'r') as myfile:
        data = myfile.read()
        assert get_new_command(MagicMock(output=data)) == ['aws cloudformation deploy --stack-name testing --template-file /tmp/sample-template.yaml']

# Generated at 2022-06-22 00:57:11.642969
# Unit test for function match
def test_match():
    assert match(Command('aws s3 list', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\naws: error: argument command: Invalid choice, maybe you meant:\n    list-buckets', ''))


# Generated at 2022-06-22 00:57:24.168541
# Unit test for function get_new_command

# Generated at 2022-06-22 00:57:34.086736
# Unit test for function get_new_command
def test_get_new_command():
    original_command = 'aws ec2 describe-instances --filter Name=tag:Name,Values=jenkins'
    error_message = "aws: error: argument --filter: Invalid choice: 'jenkins', maybe you meant:\n* Name\n* tag-key\n* tag-value\n* tag:key\n* tag:value\n* type\n* value\n* vpc-id\n* vpc-id\nSee 'aws help' for descriptions of global parameters."
    command = get_new_command(Command(script=original_command, output=error_message))
    assert command == ['aws ec2 describe-instances --filter vpc-id=jenkins']

# Generated at 2022-06-22 00:57:43.621390
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {
        'script': 'aws s3 ls',
        'output': """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

aws help
aws <command> help
aws <command> <subcommand> help

Unknown options: ls.
Invalid choice: 'ls', maybe you meant:
 * ls-buckets
 * ls-objects
"""
    })
    assert ['aws s3 ls-buckets', 'aws s3 ls-objects'] == get_new_command(command)

# Generated at 2022-06-22 00:57:55.278613
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws s3 ls s3://bucket/'
    output = 'aws: error: argument command: Invalid choice: \'s3://bucket/\', maybe you meant:\n                 ls\n                 mb'
    assert get_new_command(Command(script=command, output=output))[0] == 'aws s3 ls s3://bucket/'
    assert get_new_command(Command(script=command, output=output))[1] == 'aws s3 mb s3://bucket/'
    assert get_new_command(Command(script=command, output=output))[2] == 'aws s3 ls s3://bucket/'

# Generated at 2022-06-22 00:58:02.786393
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('''usage: aws [options] <command> <subcommand> [parameters]
aws: error: argument operation: Invalid choice, maybe you meant:
  * ec2
  * configure
  * s3
  * sts
  * iam
  * elastic-beanstalk
  * directconnect
''') == ['aws ec2', 'aws configure', 'aws s3', 'aws sts', 'aws iam',
         'aws elastic-beanstalk', 'aws directconnect']

# Generated at 2022-06-22 00:58:07.727380
# Unit test for function match
def test_match():
    assert match(Command(script='aws s3 ls', output='usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]'))
    assert not match(Command(script='aws s3 ls', output='usage: ls [OPTION]... [FILE]...'))


# Generated at 2022-06-22 00:58:20.747147
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-regions', 'Invalid choice: Regions', '', 'aws'))


# Generated at 2022-06-22 00:58:30.503785
# Unit test for function match
def test_match():
    assert not match(
        Command('aws s3 help', 'aws: error: argument subcommand: Invalid choice, valid choices are:\n\ts3 | s3api | s3control\n\nSee \'aws help\' for descriptions of global parameters.', 0))
    assert not match(
        Command('aws s3 help', '', 0))
    assert not match(
        Command('aws s3 help', 'aws: error: argument subcommand: Invalid choice, valid choices are:\n\ts3 | s3api | s3control\n\nSee \'aws help\' for descriptions of global parameters.', 0, '', '', None))

# Generated at 2022-06-22 00:58:42.861785
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("aws ec2 describe_foo --bar", "Invalid choice: 'describe_foo', maybe you meant:\n\tdescribe-instances\n\tdescribe-images\n")) == ['aws ec2 describe-instances --bar', 'aws ec2 describe-images --bar']
    assert get_new_command(Command("aws ec2 describe-instances --bar", "Invalid choice: 'describe-instances', maybe you meant:\n\tdescribe-instances\n\tdescribe-images\n")) == ['aws ec2 describe-instances --bar', 'aws ec2 describe-images --bar']

# Generated at 2022-06-22 00:58:46.236167
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws s3 ls s3_bucket") == ["aws s3 ls s3_bucket"]
    assert get_new_command("aws s3 cp file s3_bucjet") == ["aws s3 cp file s3_bucket"]

# Generated at 2022-06-22 00:58:49.114372
# Unit test for function match
def test_match():
    assert match(Command('aws --version'))
    assert not match(Command('ls /etc'))

# Unit tests for function get_new_command

# Generated at 2022-06-22 00:58:51.219338
# Unit test for function get_new_command
def test_get_new_command():
    print(get_new_command("aws lambda list-funtions"))


enabled_by_default = False

# Generated at 2022-06-22 00:59:02.360715
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws s3api --delete-bucket --bucket bucket-name"

# Generated at 2022-06-22 00:59:08.936543
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\
aws: error: argument subcommand: Invalid choice, maybe you meant:\n\
    ls?\n\
    mb\n\
    rb\n\
    ls\n')) == ['aws s3 mb', 'aws s3 rb', 'aws s3 ls']

# Generated at 2022-06-22 00:59:14.153439
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'usage: aws [options] [ ...]\n\nA help\n\nsubcomands:\n        foo     Bar\n        baz     Baz\n\nmaybe you meant: foo\n\n'))
    assert not match(Command('foo', 'usage: foo [options] [ ...]\n\nA help\n\nsubcomands:\n        foo     Bar\n        baz     Baz\n\nmaybe you meant: foo\n\n'))


# Generated at 2022-06-22 00:59:19.137256
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("aws s3 ls", "usage: aws [options] <command> <subcommand> [parameters]\n\nInvalid choice: 's3', maybe you meant:\n* sts", "aws")) == ["aws sts ls"]
    assert get_new_command(Command("aws ec2 terminate-instances", "usage: aws [options] <command> <subcommand> [parameters]\n\nInvalid choice: 'terminate-instances', maybe you meant:\n* terminate-instance\n* terminate-stack", "aws")) == ["aws ec2 terminate-instance", "aws ec2 terminate-stack"]


# Generated at 2022-06-22 00:59:41.768948
# Unit test for function get_new_command
def test_get_new_command():
    # command with invalid argument
    command = Command('aws ec2 describe-instances --filters Name=instance-state-nam Value=running')
    # command output
    command.output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

Unknown options: --filters, Value=running
Invalid choice: 'Value=running', maybe you meant:
        -value, --value
        --volume-size

aws: error: argument subcommand: Invalid choice, valid choices are:
"""
    options = ["-value, --value", "--volume-size"]

# Generated at 2022-06-22 00:59:53.586012
# Unit test for function match
def test_match():
    assert match(Command('aws s3api list-bucket-tags --bucket vijay-manjunath --region us-east-1', ''))

# Generated at 2022-06-22 01:00:05.800433
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.aws_typo import get_new_command

# Generated at 2022-06-22 01:00:18.417914
# Unit test for function get_new_command

# Generated at 2022-06-22 01:00:30.487324
# Unit test for function match
def test_match():
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\naws help\naws <command> help\naws <command> <subcommand> help\naws: error: argument command: Invalid choice, valid choices are:\n"
    assert match(command=Command('aws', output=output, script='')) == False
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\naws help\naws <command> help\naws <command> <subcommand> help\naws: error: argument command: Invalid choice, valid choices are:\n* sns\n* ses\n\n"

# Generated at 2022-06-22 01:00:42.584121
# Unit test for function match
def test_match():
    assert match(Command("aws s3 ls err", None, "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nerr: Invalid choice, argument: 'err', maybe you meant: \n* lsr\n"))
    assert not match(Command("aws s3 ls", None, "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n"))

# Generated at 2022-06-22 01:00:51.006179
# Unit test for function match
def test_match():
    script = "aws kinesis list-streams --help"
    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, valid choices are:

describe-stream   | get-records        | get-shard-iterator
list-streams      | MergeShards        | put-record
put-records       | PutRecords         | SplitShard

Unknown options: --help"""
    assert match(Command(script, output)) == True


# Unit test of function get_new_command

# Generated at 2022-06-22 01:00:54.881639
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-instnaces')) == [
        'aws ec2 describe-instances']
    assert get_new_command(
        Command('aws cloudformation describe-stack-events')) == [
            'aws cloudformation describe-stacks',
            'aws cloudformation describe-stack-events']

# Generated at 2022-06-22 01:01:02.496088
# Unit test for function match
def test_match():
    err = '''usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:
\naws help\naws <command> help\naws <command> <subcommand> help\n
aws: error: argument subcommand: Invalid choice, maybe you meant:\n  config\n  configure\n'''
    assert match(Command('aws cloudformation help', err))
