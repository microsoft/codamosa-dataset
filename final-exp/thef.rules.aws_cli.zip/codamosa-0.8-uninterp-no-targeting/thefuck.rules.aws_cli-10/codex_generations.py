

# Generated at 2022-06-22 00:51:11.119181
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 create-volume --volume-type',
                    'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --volume-type: Invalid choice: \'\', maybe you meant: \n  --volume-type standard\n\n'))

# Generated at 2022-06-22 00:51:23.073620
# Unit test for function get_new_command

# Generated at 2022-06-22 00:51:29.054160
# Unit test for function match
def test_match():
    command = Command("aws", "usage: aws [options] <command> <subcommand> [parameters]\n"
        "aws: error: argument subcommand: Invalid choice: 's3l', maybe you meant:  sls ssl\n"
        "* s3 ls", "")
    assert match(command)



# Generated at 2022-06-22 00:51:31.255876
# Unit test for function match
def test_match():
    assert match(Command('aws help', ''))
    assert not match(Command('ls help', ''))



# Generated at 2022-06-22 00:51:40.921822
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws ec2 describe-instances --filters 'Name=tag:Name, Values=EDS-DEV' 'Name=instance-state-name, Values=running' --query 'Reservations[*].Instances[*].{InstanceId: InstanceId, PrivateIpAddres: PrivateIpAddress}'"
    assert get_new_command(command) == "aws ec2 describe-instances --filters 'Name=tag:Name, Values=EDS-DEV' 'Name=instance-state-name, Values=running' --query 'Reservations[*].Instances[*].{InstanceId: InstanceId, PrivateIpAddress: PrivateIpAddress}'"

# Generated at 2022-06-22 00:51:43.725730
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'usage:... maybe you meant:'))
    assert not match(Command('aws help', 'usage:... maybe you not meant:'))



# Generated at 2022-06-22 00:51:56.103671
# Unit test for function get_new_command

# Generated at 2022-06-22 00:52:06.618214
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 start-instance --instance-ids i-12345678')) == ['aws ec2 start-instances --instance-ids i-12345678', 'aws ec2 start-instance --instance-id i-12345678']
    assert get_new_command(Command('aws ec2 start-instance i-12345678')) == ['aws ec2 start-instances i-12345678', 'aws ec2 start-instance --instance-id i-12345678']
    assert get_new_command(Command('aws rds describe-db-instances --db-instance-identifier mydb')) == ['aws rds describe-db-instances --db-instance-ids mydb', 'aws rds describe-db-instances --db-instance-identifier mydb']

# Generated at 2022-06-22 00:52:15.668098
# Unit test for function match
def test_match():
    assert match({"output":"""usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

Unknown options: --yaml, usage
Error parsing parameter '--yaml': Invalid choice: 'usage', maybe you meant:
  username
  users
  show
  http
  https
  s3
"""})


# Generated at 2022-06-22 00:52:18.234841
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 help', 'usage: aws [options] [path/service/method] [parameters]\nmaybe you meant: ec2'))
    assert not match(Command('aws ec2', ''))


# Generated at 2022-06-22 00:52:32.970916
# Unit test for function get_new_command

# Generated at 2022-06-22 00:52:43.121233
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws cli help',
'''
usage: aws [options] [parameters]
aws: error: argument operation: Invalid choice, valid choices are:

* acm | add-tags-to-on-premises-instances | api-gateway | apigateway

aws: error: argument operation: Invalid choice, valid choices are:

* acm | add-tags-to-on-premises-instances | api-gateway | apigateway
''')) == ['aws acm help',
           'aws add-tags-to-on-premises-instances help',
           'aws api-gateway help',
           'aws apigateway help']



# Generated at 2022-06-22 00:52:48.811167
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 start-instance i-fipsnadnadnadsa',
                                   'usage: aws [options] <command> <subcommand> [parameters]\naw...')) == ['aws ec2 start-instances --instance-ids i-fipsnadnadnadsa']


enabled_by_default = True

# Generated at 2022-06-22 00:52:59.743718
# Unit test for function match

# Generated at 2022-06-22 00:53:12.232505
# Unit test for function match

# Generated at 2022-06-22 00:53:18.847709
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('aws s3 sync s3://deere-avl-data/H5_files/ /h5files/', '')) == \
            ['aws s3 sync s3://deere-avl-data/H5_files/ /h5files/']

# Generated at 2022-06-22 00:53:30.459487
# Unit test for function get_new_command
def test_get_new_command():
    command = type('123', (object,), {'output': 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nUnknown options: --help\nInvalid choice: \'help\', maybe you meant:\n        cloudwatch\n        configservice\n        configure\n        elastictranscoder\n        help\n        iam\n        import-image\n        kinesisvideo\n        kms\n        lambda\n        rds', 'script': 'aws help configservice'})
    assert get_new_command(command) == ['aws configure', 'aws configservice']

# Generated at 2022-06-22 00:53:39.051826
# Unit test for function match
def test_match():
    assert match(Command('aws --help', '''usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

aws: error: argument operation: Invalid choice, maybe you meant:
    describe-images
    describe-instances
    describe-security-groups
See 'aws help'''))


# Generated at 2022-06-22 00:53:50.928614
# Unit test for function match
def test_match():
    assert match(Command("aws", "usage: aws [options] <command> <subcommand> "
                         "[<subcommand> ...] [parameters]"))
    assert match(Command("aws", "usage: aws [options] <command> <subcommand> "
                         "[<subcommand> ...] [parameters]\n\nUnknown options: "
                         "--noescape, --region\n\nInvalid choice: '--noescape', "
                         "maybe you meant:\n\n* --allow-no-encryption-policies "
                         "	Allow the S3 bucket to be encrypted with AES-256, "
                         "but do not require it, nor any of the other rules."))

# Generated at 2022-06-22 00:53:59.475832
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 run-instances foo --subnet foo',
                         'usage: aws [options] <command> <subcommand> [parameters]\naws: error: too few arguments',
                         'aws ec2 run-instances foo --subnet foo',
                         'maybe you meant: foo-bar'))
    assert not match(Command('aws ec2 run-instances foo --subnet foo',
                             'usage: aws [options] <command> <subcommand> [parameters]\naws: error: too few arguments',
                             'aws ec2 run-instances foo --subnet foo',
                             'maybe you meant: foo-bar',
                             1))

# Generated at 2022-06-22 00:54:10.564644
# Unit test for function get_new_command
def test_get_new_command():
    out = "usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\n\
    The most commonly used aws commands are:\n\
        * ec2     Describe and attach Amazon EBS volumes\n\
        * s3      Manipulate Amazon S3 objects\n\
        * r3      Describe and attach Amazon R3 volumes\n\
        * i3      Describe and attach Amazon I3 volumes\n\
    \n\
    Invalid choice: 's', maybe you meant:\n\
        * s3\n\
        * r3\n\
        * i3\n\
    "
    comm = Command("aws s",out)
    assert get_new_command(comm) == ['aws s3', 'aws r3', 'aws i3']

# Generated at 2022-06-22 00:54:22.526085
# Unit test for function match

# Generated at 2022-06-22 00:54:34.707097
# Unit test for function match
def test_match():
    def assert_match(command):
        assert match(command)


# Generated at 2022-06-22 00:54:46.703185
# Unit test for function get_new_command
def test_get_new_command():
    output = "aws: error: 'eu-west-2' is not a valid value for '--region'.\n"
    output += "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n"
    output += "To see help text, you can run:\n"
    output += "taws: error: 'eu-west-2' is not a valid value for '--region'.\n"
    output += "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n"
    output += "To see help text, you can run:\n"
    output += "aws help\n"
    output += "aws <command> help\n"
    output += "aws <command> <subcommand> help\n\n"


# Generated at 2022-06-22 00:54:53.596176
# Unit test for function get_new_command
def test_get_new_command():
    args = ['aws', 'ec2', '--region', 'europe-north-1', 'start-instances']

# Generated at 2022-06-22 00:54:57.535634
# Unit test for function get_new_command
def test_get_new_command():
    incorrect_command = 'aws s3mb'''
    correct_command = 'aws s3 mb'
    
    result = get_new_command(incorrect_command)
    assert [x for x in result] == [correct_command]

# Generated at 2022-06-22 00:55:02.158964
# Unit test for function match
def test_match():
	assert match(Command("aws", "Invalid choice: 'fakestuff', maybe you meant:"))
	#assert not match(Command("aws", "Region 'eu-central-1' may not be available. Invalid choice: 'fakestuff', maybe you meant:"))


# Generated at 2022-06-22 00:55:11.547336
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws sts "getSessionToekn"', """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters] 
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

aws: error: argument command: Invalid choice: 'getSessionToekn', maybe you meant:
  * get-session-token
  * get-session-token

""")) == ['aws sts get-session-token']

# Generated at 2022-06-22 00:55:22.471939
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\naws: error: argument command: Invalid choice: \'describe\', maybe you meant:\ndescribe-stored-iscsi-volumes  DescribeStorediSCSIVolumes\ndescribe-stored-xscsi-volumes  DescribeStorediSCSIVolumes\nTo see help text, you can run:\naws help\naws <command> help\naws <command> <subcommand> help\n')) == ['aws ec2 describe-stored-iscsi-volumes ', 'aws ec2 describe-stored-xscsi-volumes ']

# Generated at 2022-06-22 00:55:28.977315
# Unit test for function match
def test_match():
    assert match(Command('aws', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\nunknown command: foo'))


# Generated at 2022-06-22 00:55:41.986397
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 do-something', 'aws: error: argument subcommand: Invalid choice: \'do-something\', maybe you meant:\n  describe-instances\n  run-instances\n')) == ['aws ec2 describe-instances', 'aws ec2 run-instances']
    assert get_new_command(Command('aws ec2 do-something', 'aws: error: argument subcommand: Invalid choice: \'do-something\', maybe you meant:\n  describe-instances\n  run-instances\n  describe-images\n  import-instance\n')) == ['aws ec2 describe-instances', 'aws ec2 run-instances', 'aws ec2 describe-images', 'aws ec2 import-instance']

# Generated at 2022-06-22 00:55:46.635009
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws ec2 describe-tags --filters Name=resource-id,Values=i-123456789"
    return_command = ['aws ec2 describe-tags --filters Name=resource-id,Values=i-123456789']
    assert get_new_command(command) == return_command

enabled_by_default = True

# Generated at 2022-06-22 00:55:57.691990
# Unit test for function match
def test_match():
    command = Command('aws s3 ls s3://', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument command: Invalid choice: \'s3\' (choose from \'autoscaling\', \'cloudfront\', \'cloudsearch\', \'cloudsearchdomain\', \'cloudtrail\', \'cloudwatch\', \'cwlogs\', \'dynamodbstreams\', \'ec2\', \'elasticache\', \'elasticbeanstalk\', \'iam\', \'rds\', \'redshift\', \'route53\', \'s3\', \'ses\', \'sns\', \'sqs\', \'swf\', \'sts\', \'support\')\n', '')
    assert match(command) == True


# Generated at 2022-06-22 00:56:10.183211
# Unit test for function get_new_command

# Generated at 2022-06-22 00:56:17.098904
# Unit test for function get_new_command

# Generated at 2022-06-22 00:56:28.186409
# Unit test for function get_new_command

# Generated at 2022-06-22 00:56:34.864108
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 start-instances --instance-ids 123', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\naws: error: argument instance-ids: Invalid choice: \'123\', maybe you meant:* i-123', '', 0, '')) == ['aws ec2 start-instances --instance-ids i-123']

# Generated at 2022-06-22 00:56:36.701566
# Unit test for function match
def test_match():
    command = Command("aws")
    assert match(command)



# Generated at 2022-06-22 00:56:48.377210
# Unit test for function match
def test_match():
    def test_match():
        assert match(Command('myscript',
         """usage: myscript <command> [<args>]

The most commonly used myscript commands are:
   logs        
   delete      Deletes a specified object.
   ses         Manage your Amazon SES email address.
...
...
...

Unknown options: [foo]
{'x': True}
Maybe you meant one of these:
   logs
   delete
   ses
...
...
...
""", ''))


# Generated at 2022-06-22 00:56:52.095408
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(run('aws elb2 ls')) == ['aws elb2 ls']
    assert get_new_command(run('aws elb ls')) == ['aws elb ls']

# Generated at 2022-06-22 00:57:07.747920
# Unit test for function get_new_command

# Generated at 2022-06-22 00:57:17.470641
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws ec2 describe-instances --filters'
    output = '''
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

aws: error: argument --filters: Invalid choice: '--filters', maybe you meant:
  * --filter
  * --filters
'''
    assert get_new_command(Command(script, output)) == [script + ' --filter', script + ' --filters']


# Generated at 2022-06-22 00:57:23.958190
# Unit test for function get_new_command
def test_get_new_command():
    get_new_command(Command('aws elb xxx --elb-names my-elb', 'usage: aws [options] &lt;command&gt; &lt;subcommand&gt; [parameters]\naws: error: argument --elb-names: Invalid choice: xxx, maybe you meant:\n  * v1', None))


# Generated at 2022-06-22 00:57:27.323465
# Unit test for function match
def test_match():
    assert match(Command('aws sns help', 'aws: error: argument operation: Invalid choice: \'sn\', maybe you meant:\n  * sn'))
    assert not match(Command('aws help', ''))



# Generated at 2022-06-22 00:57:39.607167
# Unit test for function get_new_command
def test_get_new_command():
    command = type('obj', (object,),
                   {'output': """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument command: Invalid choice: 'ec2', maybe you meant:
  * ec2
  * ecs
  * ecr
  * ecs
  * es
  * elbv2
  * elb
  * elastictranscoder
  * elastictranscoder
  * eks
  * elasticache
  * elasticbeanstalk
  * elasticbeanstalk""",
                    'script': 'aws ec2 ls'})

# Generated at 2022-06-22 00:57:42.768228
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(_) == "aws ec2 run-instances --image-id ami-12345678 --count 1 --instance-type m1.small"

# Generated at 2022-06-22 00:57:54.329009
# Unit test for function get_new_command

# Generated at 2022-06-22 00:58:05.979239
# Unit test for function get_new_command

# Generated at 2022-06-22 00:58:17.999053
# Unit test for function match
def test_match():
    assert match(Command('aws -s',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n'
                         '\taws: error: argument operation: Invalid choice, maybe you meant:\n'
                         '\t  add-permission\n'
                         '\t  invoke\n'
                         '\t  remove-permission\n'
                         '\t  wait',
                         ''))

# Generated at 2022-06-22 00:58:21.176670
# Unit test for function match
def test_match():
    # assert match(Command('aws ec2 describe-instances'))
    assert match(Command('aws ec2 describe-instanes'))



# Generated at 2022-06-22 00:58:37.780044
# Unit test for function match
def test_match():
    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:
    aws help
    aws <command> help
    aws <command> <subcommand> help
aws: error: argument command: Invalid choice, valid choices are:
'''
may be you mean:
    s3       # Amazon Simple Storage Service (S3)
"""
    assert match(Command('aws s3 ls', output))



# Generated at 2022-06-22 00:58:41.456494
# Unit test for function match
def test_match():
    assert match(Command('aws s3 help', ''))
    assert match(Command('aws help', ''))
    assert not match(Command('aws s3 ls'))
    assert not match(Command('foobar', ''))



# Generated at 2022-06-22 00:58:47.898509
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://test-bucket-us-east-name', ''))
    assert not match(Command('aws s3 mb s3://test-bucket-us-east-name', '',
                             0))
    assert not match(Command('aws s3 mb s3://test-bucket-us-east-name',
                             'A client error (BucketAlreadyExists) occurred when calling the CreateBucket operation: Bucket test-bucket-us-east-name already exists',
                             0))



# Generated at 2022-06-22 00:59:00.348412
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws cloudformation create-stak --stack-name fuck"

# Generated at 2022-06-22 00:59:12.463563
# Unit test for function get_new_command

# Generated at 2022-06-22 00:59:24.725365
# Unit test for function match

# Generated at 2022-06-22 00:59:26.531558
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws projects')) == \
            ['aws projects']

# Generated at 2022-06-22 00:59:36.680251
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("aws sts get-session-token --du <tab><tab>", "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters] \n\naws: error: argument --duration: Invalid choice: 'du', maybe you meant: \n  * --duration \n\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\naws: error: too few arguments\n", "")) == ["aws sts get-session-token --duration <tab><tab>"]

# Generated at 2022-06-22 00:59:44.968369
# Unit test for function get_new_command
def test_get_new_command():
    script_mistake = 'aws ec2 create-vpc --cidr-block 10.0.0.0/16'
    output_mistake = '''Unknown options: --cidr-block 10.0.0.0/16
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

Unknown options: --cidr-block 10.0.0.0/16
Invalid choice: 'create-vpc', maybe you meant:
  * create-vpn-connection
  * create-vpn-connection-route
  * create-vpn-gateway
'''

# Generated at 2022-06-22 00:59:49.808698
# Unit test for function match
def test_match():
    assert match(Command('aws', '', 'usage: aws [--version] [--help] '
        '<command> <subcommand> [parameters]\naws: error: argument command: '
        'Invalid choice: '
        "'molude', maybe you meant:   * list"))


# Generated at 2022-06-22 01:00:09.156273
# Unit test for function match

# Generated at 2022-06-22 01:00:10.237534
# Unit test for function match
def test_match():
    assert match(Command('aws'))


# Generated at 2022-06-22 01:00:16.436259
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws s3 result")
    command.output = "Invalid choice: 'result', maybe you meant:\n* create-bucket\n* delete-bucket\n* ls"
    assert [command.script.replace("result", o) for o in ["create-bucket", "delete-bucket", "ls"]] == get_new_command(command)

# Generated at 2022-06-22 01:00:19.560028
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://cloud_domain', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]'))


# Generated at 2022-06-22 01:00:31.919170
# Unit test for function get_new_command

# Generated at 2022-06-22 01:00:43.748052
# Unit test for function match

# Generated at 2022-06-22 01:00:45.347016
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws --version") == ["aws --version"]

# Generated at 2022-06-22 01:00:50.800872
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-availability-zones --region us-west-1a', 'usage:', ''))
    assert not match(Command('aws ec2 describe-availability-zones --region us-west-1a', '', ''))
    assert not match(Command('mysql -e "select * from user"', '', ''))

# Generated at 2022-06-22 01:00:52.782738
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('aws iam list-users "ss")') == ['aws iam list-users']

# Generated at 2022-06-22 01:00:54.811821
# Unit test for function get_new_command
def test_get_new_command():
    assert (get_new_command(Command('aws ec2', 'usage:')) == [])

