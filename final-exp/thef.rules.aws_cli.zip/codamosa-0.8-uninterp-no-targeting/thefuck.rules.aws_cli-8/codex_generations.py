

# Generated at 2022-06-22 00:51:02.629975
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws --help', 'aws: error: argument --help: Invalid choice: \'--help\', maybe you meant:\n* --hel-kms-key\n* --help\n* --help-kms-key')) == ['aws --hel-kms-key --help', 'aws --help --help', 'aws --help-kms-key --help']

# Generated at 2022-06-22 00:51:10.854571
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    output = ("usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n"
              "aws: error: argument operation: Invalid choice: 'bv', maybe you meant: "
              "b\n  bv\nb"
              "V\nb\n  bv"
              "V\nb"
              "b")
    assert get_new_command(Command('aws bv', output))[0] == "aws b"



# Generated at 2022-06-22 00:51:16.080677
# Unit test for function match
def test_match():
    assert match(Command('aws --version', 'aws: error: argument --version: Invalid choice: "--version", maybe you meant:', '', 1))
    assert match(Command('aws --version', 'aws: error: argument --version: Invalid choice: "--version", maybe you meant:\n  --endpoint-url\ndescription:', '', 1))
    assert not match(Command('aws --version', 'aws --version is not a valid command', '', 1))
    assert not match(Command('aws --version', 'version aws', '', 1))

# Generated at 2022-06-22 00:51:25.988146
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 start-instance --instance-ids bad argument', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run: aws help\naws: error: argument --instance-ids: Invalid choice: "bad argument", maybe you meant:  \n* i-bad-argument\n* i-bad-arguments\n* i-bad-aargument\n', 'aws ec2 start-instance --instance-ids bad argument', '', 0))

# Generated at 2022-06-22 00:51:30.709891
# Unit test for function get_new_command
def test_get_new_command():
    command = "aws s3api list-buckets --query 'OwnerId' --output text --all-region"
    result = get_new_command(command)
    assert result == ["aws s3api list-buckets --query OwnerId --output text --all-region"]

# Generated at 2022-06-22 00:51:34.550248
# Unit test for function match
def test_match():
    command = Command('aws some_unknown_command', "usage: ...")
    assert match(command)
    command = Command('aws some_command', "aws cli ...")
    assert not match(command)



# Generated at 2022-06-22 00:51:38.024322
# Unit test for function match
def test_match():
    # Test for command aws ec2 describe-instances --instance-ids i-4b4f9c0a
    assert match(Command('aws ec2 describe-instances --instance-ids i-4b4f9c0a',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
                         'aws: error: argument instance-ids is required\n'
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
                         'aws: error: argument instance-ids is required',
                         1, None))



# Generated at 2022-06-22 00:51:43.777329
# Unit test for function match
def test_match():
    assert_match("aws ec2", "usage: aws [options] <command> <subcommand>", "maybe you meant: ec2")
    assert_match("aws ec2", "", "")
    assert_match("aws ec2", "usage: aws [options] <command> <subcommand>", "")
    assert_match("aws ec2", "", "maybe you meant: ec2")


# Generated at 2022-06-22 00:51:52.279939
# Unit test for function match
def test_match():
    command = Command('aws ec2 describe-snapshots', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n\n* describe-snapshots')
    assert match(command)





# Generated at 2022-06-22 00:52:04.913928
# Unit test for function get_new_command
def test_get_new_command():
    result = get_new_command(Command(script="aws ec2 describe-availability-zones --region us-east-1 --filters Name=opt-out,Values=true Name=state,Values=blocked", output="usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:\n* describe-availability-zones\n* describe-regions\n\nUnknown options: --filters, Name=opt-out,Values=true, Name=state,Values=blocked"))
    assert len(result) == 2

# Generated at 2022-06-22 00:52:14.216324
# Unit test for function match
def test_match():
    assert match(Command('aws ec2', ''))
    assert match(Command('aws s3', 'An error occurred (InvalidKey) when calling the HeadBucket operation: The specified bucket is not valid'))
    assert not match(Command('ls', ''))
    assert not match(Command('ls', 'usage: ls [-ABCFGHLOPRSTUWabcdefghiklmnopqrstuwx1]'))


# Generated at 2022-06-22 00:52:23.090696
# Unit test for function get_new_command
def test_get_new_command():
    # Build a command
    command = Command('aws ec2 describe-instances --instance ids 123456',
     'usage: aws [options] <command> <subcommand> [parameters]\nTo see '
     'help text, you can run:\n\n  aws help\n  aws <command> help\n  aws '
     '<command> <subcommand> help\naws: error: argument instance: Invalid '
     'choice: \'ids\', maybe you meant: \n  --instance-ids\n(choose from '
     '\'--instance-ids\')\n\n')

    # Test
    assert get_new_command(command) == ['aws ec2 describe-instances '
                                        '--instance-ids 123456']

# Generated at 2022-06-22 00:52:31.390678
# Unit test for function match
def test_match():

	# Test command.output
    assert match(Command('aws s3 mb s3://cage-test-2016-10-26', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] ... Invalid choice: \'mb\', maybe you meant:\n* mb\n* mv\n* presign\n* rb\n* rm\n* s3\n'))

    # Test match function
    assert not match(Command('git status', ''))



# Generated at 2022-06-22 00:52:43.628035
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances --region us-west-2 --profile p256')
    command.output = ('usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
                      'aws: error: argument subcommand: Invalid choice, maybe you meant:\n'
                      '    --profile             Profile name.\n'
                      '    --region              Region name.\n')
    new_command = get_new_command(command)
    assert new_command == ['aws ec2 describe-instances --profile p256 --region us-west-2']

    command = Command('aws ec2 describe-instances --region us-west-2 --profile p256')

# Generated at 2022-06-22 00:52:51.638557
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe_instances', 'usage: aws [options] &lt;command&gt; &lt;subcommand&gt; [parameters]\naws: error: argument subcommand: Invalid choice, maybe you meant: \n  * snapshots\n  * describe-snapshots\n  * describe-security-groups\n  * describe-volumes\n  * describe-instance-status\n  * describe-reserved-instances\n  * describe-vpcs\n  * describe-instances\n  * reboot-instances'))


# Generated at 2022-06-22 00:53:03.076402
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-22 00:53:14.670122
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws sqs list-queues --region local,', 
        "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n"
        "aws: error: argument --region: Invalid choice: 'local,', maybe you meant: \n"
        "  * local\n"
        "  * localstack\n"
        "  * localstack-admin\n"
        "  * localstack-s3\n"
        "  * localstack-sqs\n"
        "  * localstack-sns\n")

# Generated at 2022-06-22 00:53:25.137202
# Unit test for function match
def test_match():
    command = Command('aws ec2 describe-instances --filters Name=tag:Name,Values=my-server-name',
                      'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
                      'aws: error: argument subcommand: Invalid choice, maybe you meant:\n'
                      '   * describe-instances\n'
                      '   * describe-instance\n'
                      '   * describe-instances-status\n'
                      '   * describe-instances-attribute\n'
                      '   * describe-instance-status', 'aws')
    assert match(command)


# Generated at 2022-06-22 00:53:33.781272
# Unit test for function match

# Generated at 2022-06-22 00:53:40.877499
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 help', 'Invalid choice: \'s3\', maybe you meant:\n'
                                     ' * sync\n'
                                     ' * website\n'
                                     ' * mb\n'
                                     ' * mv\n')
    assert get_new_command(command) == ['aws sync help', 'aws website help', 'aws mb help', 'aws mv help']

# Generated at 2022-06-22 00:53:46.575420
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-instsance --output', '')) == ['aws ec2 describe-instances --output']
    assert get_new_command(Command('aws ec2 describe-in', '')) == []

# Generated at 2022-06-22 00:53:57.468564
# Unit test for function get_new_command
def test_get_new_command():
    command_output = ("usage: aws [options] [ ...] [parameters]\n"
                      "aws: error: argument : Invalid choice, maybe you meant:\n"
                      "    add-hosted-zone\n"
                      "    add-tags\n"
                      "    add-vpc-endpoint\n"
                      "    create-hosted-zone\n"
                      "    create-instances\n")
    command = Command("aws add-hosted-zone")
    command.script = "aws add-hosted-zone"

    assert get_new_command(command) == [
        "aws add-hosted-zone",
        "aws add-tags",
        "aws add-vpc-endpoint",
        "aws create-hosted-zone",
        "aws create-instances"
    ]

# Generated at 2022-06-22 00:54:01.377844
# Unit test for function match
def test_match():
    assert match('aws s3 mb s3://smile-dg')
    assert not match('aws s3 mb s3://smile-dg --region=us-west-2')


# Generated at 2022-06-22 00:54:09.604312
# Unit test for function match
def test_match():
    command = Command('aws ec2 describe-instances --outfile test', '''usage: aws [options]  <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, valid choices are:
describe-instances
describe-instances --help
describe-instances --outfile test  ^
Invalid choice: '--outfile', maybe you meant:
  instances
  instance-id
  instance-type
''')
    assert match(command)


# Generated at 2022-06-22 00:54:11.810403
# Unit test for function match
def test_match():
    assert match(Command('foo invalid-arg', '', ''))
    assert not match(Command('foo --help', '', ''))


# Generated at 2022-06-22 00:54:19.086536
# Unit test for function get_new_command
def test_get_new_command():
    def get_mistake_options(output):
        mistake = re.search(INVALID_CHOICE, output).group(0)
        options = re.findall(OPTIONS, output, flags=re.MULTILINE)
        return mistake, options

# Generated at 2022-06-22 00:54:30.766526
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]', 'Invalid choice: \'s3\', maybe you meant:\n* s3api\n* s3browser'))
    assert not match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]', 'Invalid choice: \'s2\', maybe you meant:\n* s3api\n* s3browser'))
    assert not match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]', 'Invalid choice: \'s3\', maybe you meant:\n* s3api\n* s3browser'))


# Generated at 2022-06-22 00:54:42.078541
# Unit test for function get_new_command
def test_get_new_command():
    script = """aws cloudformation create-stack --stack-name myteststack --template-body file://home/ec2-env.json"""
    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

Unknown options: --stack-name
Invalid choice: 'myteststack', maybe you meant:

  * stack
  * stack-name
  * stack-set

aws cloudformation create-stack --stack-name myteststack"""
    command = type("Command", (object,), {"script": script, "output": output})

# Generated at 2022-06-22 00:54:43.845203
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('aws s3api') == ['aws s3api']

# Generated at 2022-06-22 00:54:49.501199
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object, ),
                   {'output': "Invalid choice: 's3ls', maybe you meant:\n  sync\n  s3",
                    'script': 'aws s3ls'})
    assert ('aws s3 sync', 'aws s3 s3') == tuple(get_new_command(command))


priority = 9999  # needed for tests

# Generated at 2022-06-22 00:55:05.218555
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws ec2 ls"

# Generated at 2022-06-22 00:55:17.981735
# Unit test for function match
def test_match():
    # Test no suggestion
    not_suggest = Command(script = 'aws ec2 describe-instances',
                          stderr = 'usage: aws [options] <command> <subcommand> [parameters]')
    assert match(not_suggest) is False
    
    # Test suggestion

# Generated at 2022-06-22 00:55:26.836644
# Unit test for function match
def test_match():
    # output of command: aws cloudfront create-invalidation --help
    assert not match(Command('aws cloudfront create-invalidation --help',
                             'usage: aws [options] <command> <subcommand> [parameters]\n\n'
                             'aws: error: argument --paths: Invalid choice: '
                             "'--help', maybe you meant: --profile, --debug, --endpoint-url, "
                             "--no-verify-ssl, --output, --query, --color"
                             '\n\nTo see help text, you can run: aws help'))
    # output of command: aws cloudfront create-invalidation -s 5s --help

# Generated at 2022-06-22 00:55:28.090950
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('') == ['']

# Generated at 2022-06-22 00:55:40.935337
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws ec2 describel"

# Generated at 2022-06-22 00:55:49.716084
# Unit test for function get_new_command

# Generated at 2022-06-22 00:55:56.179957
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws i1a2m3a4', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\naws: error: argument <command>: Invalid choice: \'i1a2m3a4\', maybe you meant:\n    * iam\n    * ima\n\naws: error: too few arguments\n')) == ['aws iam', 'aws ima']

# Generated at 2022-06-22 00:56:02.587488
# Unit test for function match

# Generated at 2022-06-22 00:56:05.314000
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 f', '')) == \
        [Command('aws s3 find-buckets', '')]

# Generated at 2022-06-22 00:56:13.933524
# Unit test for function match
def test_match():
    command1 = Command('aws s3 ls s3://dummy-bucket', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [...] Invalid choice: \'s3://dummy-bucket\', maybe you meant: [...]')
    command2 = Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]')
    command3 = Command('aws', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]')

    assert match(command1) and not match(command2) and not match(command3)


# Generated at 2022-06-22 00:56:29.881624
# Unit test for function get_new_command
def test_get_new_command():
    invocation = 'aws s3 ls s3://mybuket-0001 --region=us-east'

# Generated at 2022-06-22 00:56:32.057711
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2  stattus')) == \
        ['aws ec2  status']

# Generated at 2022-06-22 00:56:36.470519
# Unit test for function match
def test_match():
    assert match({
        'script': 'aws',
        'output': "usage: aws [options] \n\n'asdf' is not a valid choice for '--output'",
        'env': {}})



# Generated at 2022-06-22 00:56:43.914412
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws s3 presign s3://mybucket/myobject'
    output = """usage: aws [options] [ ...] [parameters]
To see help text, you can run:

  aws help
  aws  help
aws: error: invalid choice: 's3 presign s3://mybucket/myobject' (maybe you meant: s3api, s3-outposts, s3, s3control, ssm, ssm-session, sfn, ses, secretsmanager, sdb)"""

# Generated at 2022-06-22 00:56:55.519297
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-events --region us-east-1a', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument ec2: Invalid choice, maybe you meant:\n  ec2i\n* ec2\n  ec2-auto-scaling\n  ec2-autoscaling\n  ec2-db\n  ec2-dns\n  ec2-elastic-ip\n  ec2-elb\n  ec2-instance\n  ec2-key\n  ec2-launch-wizard\n  ec2-maintenance-window\n  ec2-metadata\n  ec2-metrics\n  ec2-security-group\n  ec2-vpc\n  ec2-watcher'))

# Generated at 2022-06-22 00:57:03.843081
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 blah blah blah blah','''
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument command: Invalid choice, valid choices are:

* acm
...
...
* sns
* sqs

maybe you meant: * ec2
    ''')) == ['aws ec2 blah blah blah blah']

# Generated at 2022-06-22 00:57:10.092637
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws ec2 describe-instances'
    mistake = 'ec2'
    options = ['ec2']

# Generated at 2022-06-22 00:57:21.832808
# Unit test for function match

# Generated at 2022-06-22 00:57:34.365336
# Unit test for function match

# Generated at 2022-06-22 00:57:36.886297
# Unit test for function get_new_command
def test_get_new_command():
    command = type('command', (object,), {'output': 'aws: error: argument operation: Invalid choice: \'b', 'script': 'aws b'})
    assert get_new_command(command) == ['aws s']

# Generated at 2022-06-22 00:57:59.561891
# Unit test for function match
def test_match():
    assert match(Command(script='aws ec2 describe-security-groups',
        output='Invalid choice: \'ec2 describe-security-groups\', maybe you meant:\n  '
                '* ec2-describe-security-groups')) == True
    assert match(Command(script='aws sns describe-topics',
        output='Invalid choice: \'sns describe-topics\', maybe you meant:\n  '
                '* sns-describe-topic')) == True

# Unit tests for function get_new_command

# Generated at 2022-06-22 00:58:07.256191
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
                                        'To see help text, you can run:\n\n'
                                        'aws help\n\n'
                                        'aws <command> help\n\n'
                                        'aws <command> <subcommand> help\n\n'
                                        'aws: error: argument command: Invalid choice, maybe you meant:', 0))



# Generated at 2022-06-22 00:58:15.506437
# Unit test for function get_new_command
def test_get_new_command():
    command = type('Command', (object,), {'script': 'aws ec2 describe-regions --region us-west-2',
                                         'output': "usage: awscli [options] [ ...] [parameters]\n"
                                                   +"aws: error: argument --region: Invalid choice: 'us-west-2', maybe you meant:\n"
                                                   +"\tus-west-1"})
    assert get_new_command(command) == ['aws ec2 describe-regions --region us-west-1']

# Generated at 2022-06-22 00:58:23.648726
# Unit test for function get_new_command
def test_get_new_command():
    command = type('obj', (object,), { 'script' : 'aws help', 'output' : 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]' + '\n' + 'aws: error: argument command: Invalid choice: \'helps\', maybe you meant:', 'stderr': '', 'stdout': ''})
    assert get_new_command(command) == ['aws help'], "Invalid expected return value"

# Generated at 2022-06-22 00:58:30.119054
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    assert get_new_command(Command('aws', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice: \'subsubcmd\', maybe you meant:\n  subcmd  subsubcommand', 'aws subsubcmd s3')) == ['aws subcmd s3']



# Generated at 2022-06-22 00:58:41.301916
# Unit test for function get_new_command
def test_get_new_command():
    # Correct command
    result = get_new_command(Command('aws s3 ls --recursive --human-readable --summarize'))

    # Should not get the mistake, should return the correct command
    assert result == ['aws s3 ls --recursive --human-readable --summarize']

    # Wrong command
    result = get_new_command(Command('aws s3 ls --recursive --human-readable --summarize --foooo'))

    # Should return a list of commands with --foo and --foobaz
    assert result == ['aws s3 ls --recursive --human-readable --summarize --foo',
                      'aws s3 ls --recursive --human-readable --summarize --foobaz']

# Generated at 2022-06-22 00:58:47.184526
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nUnknown options: -h\n\nUnknown options: -help', '', 123)) == True

from thefuck.rules.aws import match, get_new_command

# Generated at 2022-06-22 00:58:59.482165
# Unit test for function get_new_command

# Generated at 2022-06-22 00:59:05.289327
# Unit test for function match
def test_match():
    assert match(Command('aws --help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\nInvalid choice: \'--help\', maybe you meant:\n    --version', '', 1))
    assert not match(Command('aws --help', '', '', 1))


# Generated at 2022-06-22 00:59:12.576960
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws ecs list-tasks --cluster asdf'
    command = Command(script, 'Invalid choice: \'--cluster\', maybe you meant:\n'
        '    *  --cluster-name\n'
        '    *  --cluster-query')
    assert get_new_command(command) == [
        'aws ecs list-tasks --cluster-name asdf',
        'aws ecs list-tasks --cluster-query asdf']

# Generated at 2022-06-22 00:59:48.843901
# Unit test for function match

# Generated at 2022-06-22 00:59:56.577486
# Unit test for function match

# Generated at 2022-06-22 01:00:02.836359
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws cloudfrount list-distributions'
    mistake = re.search(INVALID_CHOICE, command.output).group(0)
    options = re.findall(OPTIONS, command.output, flags=re.MULTILINE)
    assert get_new_command(command) == replace_argument(command.script, mistake, options[0])



# Generated at 2022-06-22 01:00:15.262344
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws s3 ls s3://123.123/erro/123.txt"
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, valid choices are:\ns3api\ns3\nInvalid choice: 's3://123.123/erro/123.txt', maybe you meant:\n  s3\n  s3api"
    result = get_new_command(Cli(script, output))
    assert result == ["aws s3 ls s3://123.123/erro/123.txt"]



# Generated at 2022-06-22 01:00:27.460852
# Unit test for function match
def test_match():
    assert match(Command('aws help ec2 run-instances',
        "usage: awscli [options] <command> <subcommand> [<subcommand> ...] [parameters]\r\naws: error: argument operations: Invalid choice: 'run-instances', maybe you meant: list-groups\r\n\tlist-groups\r\n\tlist-groups-for-user\r\n\tlist-instance-profiles\r\n\tlist-users\r\n\tlist-virtual-mfa-devices\r\n",
        1))

# Generated at 2022-06-22 01:00:39.568979
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws ec2 describe-regions --output text --all-regions'
    output = '''
                A client error (InvalidParameterValue) occurred when calling the DescribeRegions operation: No value
                for parameter allRegions
                usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
                To see help text, you can run:

                aws help
                aws <command> help
                aws <command> <subcommand> help
                aws: error: argument --output: Invalid choice, valid choices are:
                json | text | table
                (maybe you meant: --region)'''
    command = Command(script, output)
    new_command = get_new_command(command)

# Generated at 2022-06-22 01:00:49.633564
# Unit test for function get_new_command
def test_get_new_command():
    aws_command = 'aws sts get-session-token'

# Generated at 2022-06-22 01:01:00.137819
# Unit test for function get_new_command
def test_get_new_command():
	command_output = """usage: aws [options] [ ...] [parameters]
To see help text, you can run:

  aws help
  aws help

Unknown options: 
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help

Unknown options: 
Invalid choice: '', maybe you meant:
  config
  create
  list
  delete

See 'aws help' for descriptions of global parameters.
"""
	command = Command('aws', command_output)
	assert get_new_command(command) == ['aws config', 'aws create', 'aws list', 'aws delete']