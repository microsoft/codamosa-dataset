

# Generated at 2022-06-22 00:51:09.177137
# Unit test for function get_new_command
def test_get_new_command():
    command = types.Command("aws s3 cp s3://foo/bar.txt .", "Unknown options: 's3'\nusage: aws [options] [ ...] [parameters] \nTo see help text, you can run:\n\n  aws help\n  aws  help\naws: error: invalid choice: 's3' (maybe you meant: 'ecs')\n* ecr\n* ecs\n* ec2", "aws", "aws")

# Generated at 2022-06-22 00:51:17.197329
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-22 00:51:26.689291
# Unit test for function match

# Generated at 2022-06-22 00:51:31.407234
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("aws s3 ls s3://shahar-test-bucket-dont-delete/", "Invalid choice: 's3://shahar-test-bucket-dont-delete/', maybe you meant:\n  cp\n  mv\n  rb\n  rm\n  sync")) == ["aws s3 ls s3://shahar-test-bucket-dont-delete/cp", "aws s3 ls s3://shahar-test-bucket-dont-delete/mv", "aws s3 ls s3://shahar-test-bucket-dont-delete/rb", "aws s3 ls s3://shahar-test-bucket-dont-delete/rm", "aws s3 ls s3://shahar-test-bucket-dont-delete/sync"]

# Generated at 2022-06-22 00:51:37.184402
# Unit test for function match
def test_match():
    test_input = {
        'output': 'aws: error: argument subcommand: Invalid choice, valid choices are:\n* ec2\n* s3'
    }
    assert(match(test_input)) == True
    # test_invalid = `aws command`
    # assert(match(test_invalid)) == False


# Generated at 2022-06-22 00:51:44.942593
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://bucket-name/ --region us-east-1',
                         'Invalid choice: "s3://bucket-name/ --region us-east-1"\n'
                         'maybe you meant:\n'
                         '    mb\n'
                         '    mb\n'
                         '    mb\n'))

# Generated at 2022-06-22 00:51:56.885137
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws ec2 describe-instances --region us-west-2 --filters Name=tag:Name,Values=cherry Name=tag:Owner,Values=vinicius.faria Name=tag:Environment,Values=production Name=instance-state-name,Values=running") == ['aws ec2 describe-instances --region us-west-2 --filters Name=tag:Name,Values=cherry Name=tag:Owner,Values=vinicius.faria Name=tag:Environment,Values=production Name=instance-state-name,Values=running', 'aws ec2 describe-instances --region us-west-2 --filters Name=tag:Name,Values=cherry Name=tag:Owner,Values=vinicius.faria Name=tag:Environment,Values=production Name=instance-state-name,Values=running']




# Generated at 2022-06-22 00:52:05.154066
# Unit test for function match
def test_match():
    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument <command>: Invalid choice, valid choices are:

configure         | help

Invalid choice: '<command>', maybe you meant:
        configure
        help
"""
    assert match(Command('aws <command>', output))
    assert not match(Command('git branch', ''))



# Generated at 2022-06-22 00:52:18.154017
# Unit test for function get_new_command
def test_get_new_command():
    import subprocess
    from thefuck.types import Command
    command = Command('aws ec2 describe-regions', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, valid choices are:\n\n* create-tags\n* describe-tags\n* delete-tags\n\nUnknown options: describe-regions', [], 'aws', 'ec2 describe-regions', '')
    assert get_new_command(command) == ['aws --help', 'aws ec2 --help', 'aws ec2 describe-tags --help']

# Generated at 2022-06-22 00:52:25.351600
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws'

# Generated at 2022-06-22 00:52:31.019461
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 ls','''usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, valid choices are:

accelerate
acm
...

Invalid choice: 'ls', maybe you meant:
 * ls-objects
 * ls-buckets
 * ls
 * mv
 * put-object
 * rm
 * rb
 * sync
''')
    assert not re.search(INVALID_CHOICE, command.output)

# Generated at 2022-06-22 00:52:32.970718
# Unit test for function match
def test_match():
    assert match(Command('aws --version', ''))
    assert not match(Command('pwd', ''))



# Generated at 2022-06-22 00:52:39.779068
# Unit test for function match
def test_match():
    assert match(Command('aws --version', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n        To see help text, you can run:\n        aws help\n        aws <command> help\n        aws <command> <subcommand> help\n        aws: error: argument --version: Invalid choice, maybe you meant: \n           --version', '', 1))

# Generated at 2022-06-22 00:52:46.882510
# Unit test for function match
def test_match():
    assert match(Command('aws help', "usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\nInvalid\
        choice: 'help', maybe you meant:\n  * 'help-ec2'\n  * 'help-elbv2'\n  * 'helper'\n  * 'help-pricing'\n  * 'help-route53'\n  * 'help-s3'\nSee 'aws help' for descriptions of global parameters"))


# Generated at 2022-06-22 00:52:50.620416
# Unit test for function match
def test_match():
    output = "The program 'aws' is currently not installed. To run 'aws' please ask your administrator to install the package 'awscli'"
    command = Command('aws s3 ls',
                      output = output)
    assert not match(command)


# Generated at 2022-06-22 00:52:57.995750
# Unit test for function get_new_command

# Generated at 2022-06-22 00:53:03.790652
# Unit test for function match
def test_match():
    assert match(Command("aws", "", "Invalid choice: 'asdf', maybe you meant: \n * asd \n * as \n * sd"))
    assert not match(Command("aws", "", ""))
    assert not match(Command("aws", "", "Invalid choice: 'asdf', maybe you meant: \n * asd \n * as \n * sd"))


# Generated at 2022-06-22 00:53:15.165399
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.shells import Bash

# Generated at 2022-06-22 00:53:26.580151
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws cloudformation list-stack-set-operations 'STACKSET-NAME' --region eu-west-1", 'aws: error: argument command: Invalid choice: \'list-stack-set-operations\', maybe you meant:\n\n  * list-stacks\n  * list-stacksets\n\nReport this to awscli@amazon.com')
    assert get_new_command(command)[:2] == [
        "aws cloudformation list-stacks 'STACKSET-NAME' --region eu-west-1",
        "aws cloudformation list-stacksets 'STACKSET-NAME' --region eu-west-1"
    ]


enabled_by_default = True

# Generated at 2022-06-22 00:53:38.864951
# Unit test for function get_new_command

# Generated at 2022-06-22 00:53:53.506545
# Unit test for function get_new_command
def test_get_new_command():
    command1 = type('Command', (), {'output': "aws --help\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\naws help\naws <command> help\naws <command> <subcommand> help\nInvalid choice: '--help', maybe you meant:\n        --cli-input-json  : Accepts JSON input.\n        --debug           : Show additional debugging output.\n        --generate-cli-skeleton : Print the JSON skeleton to standard output and exit.\n        --output          : Output format. (default: json)\n        --query           : JMESPath. (default: '*')\n        --version         : Print the AWS CLI version.\n        --color           : Color.\n\n"})

# Generated at 2022-06-22 00:53:59.985121
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command("aws s3api abc --provision", "usage: ", "* aborts \n* abort"))

# Generated at 2022-06-22 00:54:09.055009
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws ec2 describe-volumes --filters \"Name=attachment.instance-id,Values=i-abcde\""
    mistake = "\"Name=attachment.instance-id,Values=i-abcde\""
    options = ["Name=attachment.instance-id,Values=i-abcde,Values=i-abcd"]
    assert get_new_command(Command(script, "usage: aws [options] <command> <subcommand> [<subcommand> ...] blah blah blah blah blah blah blah maybe you meant: * Name=attachment.instance-id,Values=i-abcde,Values=i-abcd")) == [script.replace(mistake, option) for option in options]

# Generated at 2022-06-22 00:54:17.335935
# Unit test for function match
def test_match():
    output1 = ("usage: aws [options] [ ...] [parameters]\n"
               "To see help text, you can run:\n"
               "aws help\n"
               "aws help --remainder\n"
               "aws: error: argument invalidchoice: Invalid choice, maybe you"
               " meant: config\n")

    output2 = ("usage: aws [options] [ ...] [parameters]\n"
               "To see help text, you can run:\n"
               "aws help\n"
               "aws help --remainder\n")

    assert match(Command("aws invalidchoice", output1)) == True
    assert match(Command("aws someothercommand", output2)) == False



# Generated at 2022-06-22 00:54:20.982398
# Unit test for function match
def test_match():
    assert match(Command('aws autoscaling help', '', ''))
    assert match(Command('aws ec2 help', '', ''))
    assert not match(Command('aws iam help', '', ''))


# Generated at 2022-06-22 00:54:23.911421
# Unit test for function match
def test_match():
    assert match(Command('aws --help'))
    assert match(Command('aws', '--help'))
    assert not match(Command('aws'))


# Generated at 2022-06-22 00:54:35.996448
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws ec2 --region us-west-2 --profile default describe-regions'
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nerror: Invalid choice: 'ec2 --region us-west-2', maybe you meant:\n                 ecr\n                 ec2\n                 emr\n                 ecs\n                 elasticache"
    command = Command(script, output)
    result = get_new_command(command)

# Generated at 2022-06-22 00:54:42.369336
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nUnknown options: abc', '', 1))


# Generated at 2022-06-22 00:54:49.552504
# Unit test for function match
def test_match():
    wrong_command = (Command(script='aws s3 ls', stderr='usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\nUnknown options: s3\n')
)
    assert match(wrong_command)



# Generated at 2022-06-22 00:55:01.814828
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws elb set-load-balancer-policies-of-listener --load-balancer-name my-loadbalancer --load-balancer-port 80 --policy-names my-app-cookie-policy --region us-west-2no'

# Generated at 2022-06-22 00:55:19.173586
# Unit test for function match
def test_match():
    for_app('aws')
    script = "aws s3 rb s3://bucket --force"

# Generated at 2022-06-22 00:55:27.372099
# Unit test for function get_new_command

# Generated at 2022-06-22 00:55:37.833522
# Unit test for function get_new_command
def test_get_new_command():
    captured = Command('aws configure', 'aws: error: argument --profile: Invalid choice: \'someprofile\', maybe you meant:\n  \t-  someprofiles\n  \t-  someprofiles\n\nusage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: too few arguments\n')

    assert get_new_command(captured) == ['aws configure --profile someprofiles', 'aws configure --profile someprofiles']

# Generated at 2022-06-22 00:55:48.110092
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n" \
             "To see help text, you can run:\n" \
             "aws help\n" \
             "aws <command> help\n" \
             "aws <command> <subcommand> help\n\n" \
             "aws: error: argument subcommand: Invalid choice: 'sts', maybe you meant:\n" \
             "  * start-query\n" \
             "  * start-session\n" \
             "  * stop-query\n\n" \
             "See 'aws help' for descriptions of global parameters.\n"
    script = "aws sts"
    res = get_new_command(Command(script, output))

# Generated at 2022-06-22 00:55:56.383004
# Unit test for function match
def test_match():
    invalid_choice = ("aws ec2 describe-instances --no-paginate\n"
                      "aws: error: argument --no-paginate: Invalid choice, "
                      "maybe you meant:\n    --generate-cli-skeleton\n"
                      "    --output\n    --page-size\n    --query\n"
                      "    --no-paginate\n")
    output = Command("aws ec2 describe-instances --no-paginate", invalid_choice)
    assert match(output)


# Generated at 2022-06-22 00:56:08.440561
# Unit test for function get_new_command
def test_get_new_command():

	# case 1: AWS option is misspelled
	commandMock = mock.MagicMock()
	commandMock.output = "specify --output text or one of --query JSONPath"
	commandMock.script = "aws s3 list --outpu text"

	assert("aws s3 list --outpu jsonpath" in get_new_command(commandMock))

	# case 2: AWS option is misspelled
	commandMock = mock.MagicMock()
	commandMock.output = "usage: aws ec2 reboot-instances --instance-ids <value> [--dry-run]\naws: error: argument --instance-ids: Invalid value True: Value ('True') for param instance-ids is invalid. Expected: 'str', got 'bool'\n"

# Generated at 2022-06-22 00:56:15.333850
# Unit test for function match
def test_match():
    from thefuck.rules.aws_command_not_found import match
    assert match(Command('aws s3 ls',
                         "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, valid choices are:\ncreate-bucket  delete-bucket  ls  mb  rb  website\n(maybe you meant: s3)")
                  )


# Generated at 2022-06-22 00:56:27.343403
# Unit test for function match

# Generated at 2022-06-22 00:56:30.411851
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb bucket-name'))
    assert not match(Command('ls'))



# Generated at 2022-06-22 00:56:42.894680
# Unit test for function get_new_command

# Generated at 2022-06-22 00:56:57.143348
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 describe-instances --region ap-northeast-1 --filters')
    assert get_new_command(command) == ['aws ec2 describe-instances --region ap-northeast-1 --filter']

enabled_by_default = True

# Generated at 2022-06-22 00:57:01.339948
# Unit test for function match
def test_match():
    command = Command('aws ec2 describe-regions --region us-east-1')
    assert match(command)
    assert_not_equal(match(Command("echo aws ec2 describe-regions --region us-east-1", command.script)), True)


# Generated at 2022-06-22 00:57:13.656341
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'aws: error: invalid choice: \'help\', maybe you meant:\n    help\n    helpe'))
    assert not match(Command('aws help', 'aws: error: invalid choice: \'help\', wrong choice'))
    assert match(Command('aws help', 'aws: error: invalid choice: \'help\', maybe you meant:\n    help\n    helpe\n'))
    assert match(Command('aws help', 'aws: error: invalid choice: \'help\', maybe you meant:\n    help\n    helpe\n    helpp'))
    assert match(Command('aws help', 'aws: error: invalid choice: \'help\', maybe you meant:\n    help\n    helpp'))

# Generated at 2022-06-22 00:57:23.367029
# Unit test for function get_new_command
def test_get_new_command():
    cmd = 'aws ec2 stop-instances --instance-ids i-1234567890abcdef1234567890abcdef'
    cmd_error = 'Invalid choice: \'--instance-ids i-1234567890abcdef1234567890abcdef\', maybe you meant:\n    --instance-id  \n\n(Service: AmazonEC2; Status Code: 400; Error Code: UnknownParameter; Request ID: 1234567890abcdef)'

    assert get_new_command(Command(cmd, cmd_error)) == ['aws ec2 stop-instances --instance-id i-1234567890abcdef1234567890abcdef']

# Generated at 2022-06-22 00:57:35.143504
# Unit test for function match

# Generated at 2022-06-22 00:57:47.365358
# Unit test for function match
def test_match():
    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

Unknown options: --debugging
Unknown options: --deubgging

Invalid choice: '--debugging', maybe you meant:
         * --debug
         * --endpoint-url
         * --no-verify-ssl
         * --no-paginate
         * --no-sign-request
         * --output
         * --profile
         * --region
         * --skip-requesting-account-id
         * --version
         * --ca-bundle
         * --cli-read-timeout
         * --cli-connect-timeout"""


# Generated at 2022-06-22 00:57:59.093556
# Unit test for function get_new_command
def test_get_new_command():
    # The case where there is 1 option for the invalid choice
    script = "aws ec2 describe-tags"
    out = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, valid choices are:\n\ndescribe-tags\n\nInvalid choice: 'ec2', maybe you meant:\n\ndescribe-tags\n"
    new_command = get_new_command(Command(script, out))
    assert["aws describe-tags"] == new_command

    # The case with multiple options for the invalid choice
    script = "aws ec2 describe-tags"


# Generated at 2022-06-22 00:58:08.118626
# Unit test for function match
def test_match():
    from tests.utils import Command

    assert match(Command('aws s3 mb s3://bucket',
                         'usage: aws [options] <command> '
                         '<subcommand> [parameters]\n'
                         'aws: error: argument bucket: Invalid choice, '
                         'maybe you meant:\n'
                         '* bucket-location\n'
                         '* bucket-logging\n'
                         '* bucket-policy\n'
                         '* bucket-tagging\n'
                         '* cross-region-replication\n'))
    assert not match(Command('ls'))



# Generated at 2022-06-22 00:58:20.696096
# Unit test for function get_new_command
def test_get_new_command():
    cmd_1 = '''aws s3 cp /tmp/uftest s3://schwab-devops-playground/uftest --endpoint-url http://localhost:4567
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, valid choices are:

create-bucket  |  delete-bucket  |  list-buckets  |  list-objects

Maybe you meant one of these?

  cp
'''

# Generated at 2022-06-22 00:58:29.185849
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances --regions asdf',
                         'usage: aws [options]   [ ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws   help\n  aws   --help\naws: error: argument  : Invalid choice, valid choices are:\nusage: aws [options]   [ ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws   help\n  aws   --help\n'))
    assert not match(Command('ls'))



# Generated at 2022-06-22 00:58:57.706774
# Unit test for function get_new_command
def test_get_new_command():
    # Test if get_new_command works properly
    assert get_new_command(Command("aws s3 ls xxx",
                           "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nerror: Invalid choice: 'xxx', maybe you meant:\nsign   signin            signup           sync             ", "")) == ["aws s3 sign"]

# Generated at 2022-06-22 00:59:08.988646
# Unit test for function get_new_command
def test_get_new_command():
    expected = ["aws ec2 describe-instances",
                "aws ec2 describe-images"]
    out = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice: 'desribe-instances', maybe you meant:
    describe-instances
*   describe-images
Did you mean one of these?
"""
    assert get_new_command(type('Obj', (object,), {
        'script': 'aws ec2 desribe-instances',
        'output': out})) == expected

# Generated at 2022-06-22 00:59:14.227689
# Unit test for function match
def test_match():
    script = 'aws s3 ls s3://bucket-does-not-exist'
    output = 'An error occurred (NoSuchBucket) when calling the ListObjects operation: The specified bucket does not exist\n'
    command = Command(script, output)
    assert match(command)



# Generated at 2022-06-22 00:59:16.404895
# Unit test for function get_new_command
def test_get_new_command():
    command = thefuck.types.Command(script='aws --help',
                                    output='aws: error: argument --help: invalid choice: \'--hel\', maybe you meant:\n  --help-command')
    assert get_new_command(command) == ["aws --help-command"]

# Generated at 2022-06-22 00:59:19.220769
# Unit test for function match
def test_match():
    assert match(Command('aws --help', "usage:"))
    assert match(Command('aws --help', "")) is False


# Generated at 2022-06-22 00:59:31.292843
# Unit test for function match
def test_match():
    assert match(Command(script='',
                         stderr="usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nUnknown options: --xxx\n\naws: error: argument subcommand: Invalid choice: 'xxx', maybe you meant:  \n\n* xxx\n\nSee 'aws help' for descriptions of global parameters.\n",
                         stdout=""))

# Generated at 2022-06-22 00:59:42.262702
# Unit test for function match

# Generated at 2022-06-22 00:59:53.792419
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 --region ap-southeast-1 describe-reserved', 'usage: ec2 describe-reserved-instances [--filters <value>] [--reserved-instances-ids <value>] [--dry-run] [--region <value>] [--output <value>]\naws: error: argument --region: Invalid choice: \'ap-southeast-1\', maybe you meant: \n* us-east-1 \n* eu-west-1 \n* ap-northeast-1\n'))

# Generated at 2022-06-22 00:59:57.262828
# Unit test for function match
def test_match():
    assert match(Command('aws', output='usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]'))


# Generated at 2022-06-22 01:00:09.655115
# Unit test for function match

# Generated at 2022-06-22 01:00:53.949025
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances --region us-east-1',
                         'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\naws: error: argument operation: Invalid choice, maybe you meant:\ndescribe-instances'))



# Generated at 2022-06-22 01:00:54.950880
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws help'))[0] == 'aws help'

# Generated at 2022-06-22 01:01:04.297117
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, valid choices are:\n\n  cp\n  mb\n  rb\n  ls\n  rm\n  sync\n  website\n  mv\n  presign\n  info\n  access-points\n  wait\n\nmaybe you meant:\n  mb', '', 0)
    ) == True
