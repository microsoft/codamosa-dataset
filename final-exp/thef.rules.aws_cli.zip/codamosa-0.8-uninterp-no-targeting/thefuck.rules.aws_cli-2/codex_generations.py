

# Generated at 2022-06-22 00:51:10.408418
# Unit test for function get_new_command

# Generated at 2022-06-22 00:51:16.190511
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument command: Invalid choice', error=True))
    assert not match(Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [parameters]', error=True))


# Generated at 2022-06-22 00:51:24.361474
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command(Command("aws ec2 describe-instances --foo")) == 
        [Command("aws ec2 describe-instances --filter"),
         Command("aws ec2 describe-instances --instance-id"),
         Command("aws ec2 describe-instances --output"),
         Command("aws ec2 describe-instances --profile"),
         Command("aws ec2 describe-instances --query"),
         Command("aws ec2 describe-instances --region"),
         Command("aws ec2 describe-instances --user-data")])

enabled_by_default = True

# Generated at 2022-06-22 00:51:37.356850
# Unit test for function match

# Generated at 2022-06-22 00:51:49.300549
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 terminate-instances --instance-ids i-12345678')
    command.output = '''
sh: line 1: aws: command not found
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument instance-ids is required
Invalid choice: 'ec2', maybe you meant:

* elasticbeanstalk
* ecr
* ec2
'''

# Generated at 2022-06-22 00:51:59.240130
# Unit test for function match

# Generated at 2022-06-22 00:52:07.818977
# Unit test for function match
def test_match():
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nUnknown options: --fetch-crontrib\n\nUnknown options: --fetch-crontrib\n\nInvalid choice: '--fetch-crontrib', maybe you meant:\n* --fetch-content\n* --fetch-url"
    assert match(Command(script="aws --fetch-crontrib", output=output))
    assert not match(Command(script="aws --fetch-content", output=output))



# Generated at 2022-06-22 00:52:12.712456
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 ls --recursesive', 'aws: error: argument --recursesive: Invalid choice, valid choices are:-r,--recursive', '')
    assert get_new_command(command) == ['aws s3 ls --recursive']

enabled_by_default = True

# Generated at 2022-06-22 00:52:22.185649
# Unit test for function match
def test_match():
    assert match(Command('aws sb',
                         output="usage: aws [options] [ ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws [command] help\n  aws [command] [subcommand] help\naws: error: argument operation: Invalid choice, valid choices are: [...] Invalid choice: 'sb', maybe you meant: [...]"))
    assert not match(Command('aws sb',
                             output="usage: aws [options] [ ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws [command] help\n  aws [command] [subcommand] help"))


# Generated at 2022-06-22 00:52:29.636670
# Unit test for function match
def test_match():
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant: delete ?"
    assert match(Command('aws', output))



# Generated at 2022-06-22 00:52:35.950648
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws dynamodb')) == ['aws dynamodb']
    assert get_new_command(Command('aws dynamodb')) != ['aws dynamodb']
    assert get_new_command(Command('aws dynamodb')) != ['aws']

# Generated at 2022-06-22 00:52:48.104616
# Unit test for function match
def test_match():
	output1 = 'usage: aws [options] <command> <subcommand> [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\nerror: Invalid choice: \'sdfsdfs\', maybe you meant:\n* sqs\n* s3'
	output2 = 'usage: aws [options] <command> <subcommand> [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\nerror: Invalid choice: \'sdfsdfs\', maybe you meant:\n* sns\n* s3'

# Generated at 2022-06-22 00:52:52.259411
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 describe-instances --instance-ids i-1234567890abcdef0',
                         "Invalid choice: '--instance-ids', maybe you meant:\n  --instance-id\n  --instance-ids"))
    assert not match(Command('ls', ''))


# Generated at 2022-06-22 00:53:03.791364
# Unit test for function match
def test_match():
    assert match(command=Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [parameters] ... Options'))
    assert match(command=Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [parameters] ... Options\naws: error: argument command: Invalid choice, maybe you meant:\n    la - List all buckets in a location\n    mb - Create a bucket'))
    assert match(command=Command('aws s3 ls', 'usage: aws [options] <command> <subcommand> [parameters] ... Options\naws: error: argument command: Invalid choice, maybe you meant:\n    * la - List all buckets in a location\n    * mb - Create a bucket'))

# Generated at 2022-06-22 00:53:15.165011
# Unit test for function match
def test_match():
    assert match(
        Command("aws s3 mb s3://foo", "", "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n", 1))

# Generated at 2022-06-22 00:53:18.332552
# Unit test for function match
def test_match():
    assert match(Command('aws', '', ''))
    assert match(Command('aws help', '', ''))
    assert not match(Command('ls', '', ''))


# Generated at 2022-06-22 00:53:23.804874
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws ec2 describe-instances Invalid choice: \'invalid-instance-id\', maybe you meant:\n  instance-id\n'
    #expected_result = [
    #    'aws ec2 describe-instances instance-id'
    #]
    get_new_command(command)

# Generated at 2022-06-22 00:53:31.416218
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'usage:', 'aws: error: argument command: Invalid choice: \'help\', maybe you meant:\n  * help-api\n  * help-synopsis\n  * help-on-error\n  * help-on-usage\n  * help-open-api'))
    assert not match(Command('aws help', 'usage:', 'usage: aws [options] [ ...] [parameters] \n\nTo see help text, you can run:\n\n  aws help\n  aws help\n  aws help\n\n'))



# Generated at 2022-06-22 00:53:40.375471
# Unit test for function match
def test_match():
    assert match(Command('aws help', "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\naws: error: argument command: Invalid choice, maybe you meant:\n    elbv2     \n    ecs       \n    elasticache\n    es", "")) == True


# Generated at 2022-06-22 00:53:52.669307
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    # test one option
    command = Command('aws s3 ls bucket-name', 'aws: error: argument subcommand: Invalid choice', '')
    assert ['aws s3 ls bucket-name'] == get_new_command(command)
    # test two options

# Generated at 2022-06-22 00:54:06.982933
# Unit test for function get_new_command

# Generated at 2022-06-22 00:54:10.536506
# Unit test for function get_new_command
def test_get_new_command():
    assert(get_new_command('aws cloudformation create-stack --stack-name test123 --template-body file://test.json') == ['aws cloudformation create-stack --stack-name test123 --template-body file://test.json'])

# Generated at 2022-06-22 00:54:18.559834
# Unit test for function get_new_command

# Generated at 2022-06-22 00:54:22.030053
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("aws ec2 describe-instances -o txt --force-new-clien", "")) == ['aws ec2 describe-instances -o txt --force-new-client']

# Generated at 2022-06-22 00:54:29.183927
# Unit test for function get_new_command
def test_get_new_command():
    command = """usage: aws [options] <command> <subcommand> [<subcommand> ...]
       aws: error: argument subcommand: Invalid choice: '--version', maybe you meant:
                                 * --version
                                 * --version-only"""
    assert get_new_command(Command(script=command.split(), stdout=command)) == [['aws', '--version'], ['aws', '--version-only']]

# Generated at 2022-06-22 00:54:36.942766
# Unit test for function match
def test_match():
    command = Command("aws cloudformation create-stack --stack-name myteststack --template-body file://mytesttemplate.json --parameters ... --capabilities CAPABILITY_IAM --region us-east-1",
                      "Unknown options: --capabilities, --parameters")
    assert match(command) == True

    command = Command("aws cloudformation create-stack --stack-name myteststack --template-body file://mytesttemplate.json --parameters ... --capabilities CAPABILITY_IAM --region us-east-1",
                      "Unknown options: --capabilities, --parameters")
    assert match(command) == True


# Generated at 2022-06-22 00:54:40.549505
# Unit test for function get_new_command
def test_get_new_command():
	command = "aws: error: argument subcommand: Invalid choice: 'test', maybe you meant: "
	command = command + "'test'\n * tests"
	assert get_new_command(command) == ["aws tests"]

# Generated at 2022-06-22 00:54:42.253136
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws config get', '')) == ['aws config']

# Generated at 2022-06-22 00:54:47.642327
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws resourcegroupstaggingapi'
    mistake = re.search(INVALID_CHOICE, command.output).group(0)
    options = re.findall(OPTIONS, command.output, flags=re.MULTILINE)
    return [replace_argument(command.script, mistake, o) for o in options]

# Generated at 2022-06-22 00:54:59.699004
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws s3api put-bucket-encrytion --bucket test --server-side-encryption-configuration'
    output = 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --server-side-encryption-configuration: Invalid choice: '
    output += "'test', maybe you meant:\n\n  * enable\n  * disable"
    command = type('obj', (object,), {'script': script, 'output': output})

# Generated at 2022-06-22 00:55:06.751483
# Unit test for function get_new_command
def test_get_new_command():
    command = 'aws configure set preview.cloudfront true'
    expected = ['aws configure set preview.cloudfront true']
    assert get_new_command(command) == expected

enabled_by_default = True

priority = 1000

# Generated at 2022-06-22 00:55:15.148979
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', "usage: aws [options] [parameters]\n\n"
                         "A client error (InvalidCommand) occurred when calling the "
                         "DescribeAccountLimits operation: Invalid command.\n\n"
                         "maybe you meant:\n\n"
                         "* s3 --help\n"
                         "* s3api   (truncated)…", ''))
    assert not match(Command('aws s3 ls', '', ''))


# Generated at 2022-06-22 00:55:22.341017
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("aws redhsift", "Invalid choice: 'redhsift', maybe you meant:\n\n\t* redshift")) == ['aws "redshift"""']
    assert get_new_command(Command("aws cognit", "Invalid choice: 'cognit', maybe you meant:\n\n\t* cognito-identity\n\t* cognito-idp")) == ['aws "cognito-identity"""', 'aws "cognito-idp"""']

# Generated at 2022-06-22 00:55:28.386636
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 help', 'Unknown option: --help\nusage: aws [options] <command> <subcommand> [parameters]\n\naws: error: option --help not recognized\n', ''))
    assert not match(Command('aws help', '', ''))


# Generated at 2022-06-22 00:55:33.398091
# Unit test for function get_new_command
def test_get_new_command():
    command = """aws: error: argument subcommand: Invalid choice, valid choices are:

* ec2
* ec2-instance-connect

(maybe you meant: ec2-instance-connect)"""
    assert get_new_command(command) == ['aws ec2', 'aws ec2-instance-connect']

# Generated at 2022-06-22 00:55:43.997095
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws s3 ls', 'ls: error: unrecognized option \'--non-interactive\'\n  '
                                   'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n'
                                   '  To see help text, you can run:\n'
                                   '    aws help\n    aws <command> help\n    aws <command> <subcommand> '
                                   'help\n  aws: error: too few arguments\n  '
                                   'Maybe you meant:\n    s3 ls --non-interactive\n    swf list-closed-workflow-executions', '')
    assert get_new_command(command) == ['aws s3 ls --non-interactive', 'aws swf list-closed-workflow-executions']

# Generated at 2022-06-22 00:55:50.483031
# Unit test for function get_new_command
def test_get_new_command():
    new_command = get_new_command("aws ec2 get-console-output\nusage: aws [options] <command> <subcommand> [parameters]\naws: error: argument subcommand: Invalid choice: 'get-console-output', maybe you meant:\n    get-console-output-batch\n\tget-console-output\n")
    assert new_command == ["aws ec2 get-console-output-batch", "aws ec2 get-console-output"]



# Generated at 2022-06-22 00:55:58.347970
# Unit test for function get_new_command
def test_get_new_command():

    assert get_new_command(Command("aws ec2 help", """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, valid choices are:
...
aws: error: argument subcommand: Invalid choice: 'ec2help', maybe you meant:
  * ec2help""")) == ['aws ec2 help']


# Generated at 2022-06-22 00:56:07.293747
# Unit test for function get_new_command
def test_get_new_command():
    command.script = 'aws sts get-session-token --serial-number arn:aws:iam::123456789012:mfa/user --token-code 123456'
    command.output = 'aws: error: argument --serial-number: Invalid choice: \'arn:aws:iam::123456789012:mfa/user\', maybe you meant:'
    assert get_new_command(command) == 'aws sts get-session-token --serial-number arn:aws:iam::123456789012:mfa/user --token-code 123456'

# Generated at 2022-06-22 00:56:15.257548
# Unit test for function get_new_command
def test_get_new_command():
    command = """
usage: aws [options] &lt;command&gt; &lt;subcommand&gt; [&lt;subcommand&gt; ...] [parameters]
To see help text, you can run:

aws help
aws &lt;command&gt; help
aws &lt;command&gt; &lt;subcommand&gt; help

aws: error: argument &lt;command&gt;: Invalid choice, valid choices are:

autoscaling                    | configure                     | help

maybe you meant:

cloudformation                 | cloudfront                    | cloudsearch

Unknown options: --help"""

    assert get_new_command(Command(command, '')) == ['aws cloudformation --help']

# Generated at 2022-06-22 00:56:25.443560
# Unit test for function match
def test_match():
    assert match(Command('foo', '', ''))
    assert match(Command('foo bar', '', ''))
    assert not match(Command('ls --help', '', ''))


# Generated at 2022-06-22 00:56:38.306801
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws iam list-users"

# Generated at 2022-06-22 00:56:43.708862
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws ec2 describe-instances --foobar") == [
        "aws ec2 describe-instances",
        "aws ec2 describe-volume-status",
        "aws ec2 describe-volumes",
        "aws ec2 describe-vpn-connections",
        "aws ec2 describe-vpn-gateways"]

# Generated at 2022-06-22 00:56:51.804289
# Unit test for function match

# Generated at 2022-06-22 00:56:56.001330
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 start --instance-ids i-12345678')
    new_command = get_new_command(command)
    assert new_command == [
        'aws ec2 start-instances --instance-ids i-12345678'
    ]

# Generated at 2022-06-22 00:57:07.856507
# Unit test for function get_new_command
def test_get_new_command():
    # Test case 1
    script = u'aws configure set service_endpoint --service-name=monitoring.ap-southeast-2.amazonaws.com'

# Generated at 2022-06-22 00:57:19.861389
# Unit test for function match

# Generated at 2022-06-22 00:57:23.146232
# Unit test for function match
def test_match():
    assert match(Command('aws help',
                         'Invalid choice: "help", maybe you meant:',
                         ''))



# Generated at 2022-06-22 00:57:32.559359
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws s3 cp /tmp/foo/ s3://bucket/ --recursive"
    output = "'recursive' is not a valid value for '--recursive'.\nUsage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\nmaybe you meant:\n  s3 sync"
    assert get_new_command(FakeCommand(script, output)) == ["aws s3 cp /tmp/foo/ s3://bucket/ --recursive"]

# Generated at 2022-06-22 00:57:36.882031
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command("aws help", " 'a' is not a valid aws command.\nusage: aws [options]\nmaybe you meant:\n  s3\n  ssm", "")) == ["aws s3", "aws ssm"]

# Generated at 2022-06-22 00:57:51.204007
# Unit test for function get_new_command
def test_get_new_command():
	assert get_new_command(Command('aws ec2 creare-instance --foo foobar', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\naws help\naws <command> help\naws <command> <subcommand> help\nunknown option: --foo\nInvalid choice: \'creare-instance\', maybe you meant:\n* create-instance')) == ['aws ec2 create-instance --foo foobar']

# Generated at 2022-06-22 00:57:57.470033
# Unit test for function match
def test_match():
    command = Command('aws s3 bash --profile profile1', 'aws: error: argument subcommand: Invalid choice: \'bash\', maybe you meant: \n* batch \n* cp \n* ls \n* mb \n* mv \n* presign \n* rb \n* rm \n* sync \n* website', '', 1)
    assert match(command)


# Generated at 2022-06-22 00:58:01.308341
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 describe-instances --filters Name=i-123456,Values=test')) == ['aws ec2 describe-instances --filters Name=i-123456,Value=test']

# Generated at 2022-06-22 00:58:12.854772
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws nonexistent')
    output = 'aws: error: argument command: Invalid choice: \'nonexistent\', maybe you meant:\n  *: commands\n    codepipeline: Manage your AWS CodePipeline pipeline.\n    configuration: Modify AWS CLI configuration settings.\n    configure: Creates a default configuration file.\n    help: Obtain general information about the AWS CLI and individual AWS services.\n    ssm: The AWS Simple Systems Manager (SSM) service enables you to remotely manage the configuration of your Amazon EC2 instances, virtual machines (VMs), or servers in your on-premises environment or in an environment provided by an AWS partner.\n    '
    command.output = output
    assert get_new_command(command) == ['aws *']


# Generated at 2022-06-22 00:58:21.111244
# Unit test for function match
def test_match():
    assert not match(Command('echo "foo"', output='bar'))

# Generated at 2022-06-22 00:58:30.676594
# Unit test for function get_new_command
def test_get_new_command():
    output = "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument command: Invalid choice, maybe you meant:\ndatapipeline\nsts\n"
    script = "aws command <subcommand> [<subcommand> ...] [parameters]"
    command = type('obj', (object,), {'script': script, 'output': output})
    
    assert get_new_command(command)[0] == "aws datapipeline <subcommand> [<subcommand> ...] [parameters]"

# Generated at 2022-06-22 00:58:40.202678
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws ec2 --output table')
    output = open(os.path.join(os.path.dirname(__file__), 'aws_ex.txt'), 'r').read()
    command.output = output
    assert get_new_command(command) == ['aws ec2 --output text']
    command.output = "usage: blah blah blah"
    assert get_new_command(command) == []
    command.output = "aws: error: [Errno 2] No such file or directory"
    assert get_new_command(command) == []

# Generated at 2022-06-22 00:58:46.352610
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    script = 'aws ec2 describe-instances'
    output = '''usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:

aws help
aws <command> help
aws <command> <subcommand> help
\n'''
    example = 'aws help'
    assert (get_new_command(Command(script = script, output = output)) == [example])




# Generated at 2022-06-22 00:58:51.550890
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 run-instances', "aws: error: argument subnet-id: Invalid choice: 'test', maybe you meant: test1"))
    assert not match(Command('aws ec2 run-instances', "aws: error: argument instance-type: Inva"))


# Generated at 2022-06-22 00:59:03.189266
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 ri', '', 'aws: error: argument operation: Invalid choice: \'ri\', maybe you meant:\n  * run-instances\n   run-instances\n  * run-instances\n   run-instances\n')) == ['aws ec2 run-instances', 'aws ec2 run-instances']
    assert get_new_command(Command('aws ec2 run-instances', '', 'aws: error: argument operation: Invalid choice: \'ri\', maybe you meant:\n  * run-instances\n   run-instances\n  * run-instances\n   run-instances\n')) == ['aws ec2 run-instances', 'aws ec2 run-instances']

# Generated at 2022-06-22 00:59:11.395107
# Unit test for function match
def test_match():
    caller = MagicMock(return_value="usage: Invalid choice: '--invalid', maybe you meant: --valid", output='Invalid Output')
    assert match(caller)


# Generated at 2022-06-22 00:59:19.968952
# Unit test for function match
def test_match():
    example_command_output='''
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, maybe you meant:
  -
maybe you meant:
  -
  -
  -
'''
    assert match(Command(script="aws", output=example_command_output))


# Generated at 2022-06-22 00:59:31.042706
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws s3 l", "usage: aws [options]               <command> <subcommand> [<subcommand> ...]\n  aws: error: argument operation: Invalid choice, valid choices are:\n  * ls\n  * mb\n  * rb\n  * cp\n  * sync\n  * mv\n  * rm\n  * setacl\n  * getacl\n  * sync\n  * website\n  * presign\n  * cp\n  * mv\n  * rm\n  * ls\n  * sync\n  * restore\n  * configure", "aws s3 l")
    assert get_new_command(command) == ['aws s3 ls']



# Generated at 2022-06-22 00:59:35.007465
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws s3 mb s3://bucket") == ["aws s3 mb s3://bucket1", "aws s3 mb s3://bucket2"]


# Generated at 2022-06-22 00:59:44.101256
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws sns create-topic --name', "usage: aws [options] <command> <subcommand> [<subcommand> ...]\n\nerror: Invalid choice: '--name', maybe you meant:\n        * --name-prefix\n\nTo see help text, you can run:\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\n")) == ['aws sns create-topic --name-prefix']

# Generated at 2022-06-22 00:59:54.661375
# Unit test for function match

# Generated at 2022-06-22 01:00:07.524530
# Unit test for function get_new_command

# Generated at 2022-06-22 01:00:14.351195
# Unit test for function match
def test_match():
    assert match(Command('aws s3 ls', 'aws: error: argument subcommand: Invalid choice: \'s3 ls\', maybe you meant:\n\n  * ls\n  * sync\n\naws: error: argument subcommand: Invalid choice: \'s3 ls\', maybe you meant:\n\n  * ls\n  * sync\n\nSee \'aws help\' for descriptions of global parameters.'))


# Generated at 2022-06-22 01:00:20.351626
# Unit test for function match
def test_match():
    assert match(Command(script='aws ec2 help',
        output="usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice: 'ec2', maybe you meant: \n  elasticbeanstalk\n  ecs\n  elasticache\n  elastictranscoder")
        )


# Generated at 2022-06-22 01:00:24.327358
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws help ec2 ec2')) == ['aws help ec2 ec2']
    assert get_new_command(Command('aws help ec2 ec2 --value')) == ['aws help ec2 ec2 --value']

# Generated at 2022-06-22 01:00:48.549648
# Unit test for function get_new_command

# Generated at 2022-06-22 01:00:59.186569
# Unit test for function match
def test_match():
    assert match(Command(script='aws', stderr='Error: Invalid choice: "volumes".\n'
                                            "usage: aws [options] [parameters]\n"
                                            '\n'
                                            "aws: error: argument command: Invalid choice: 'volumes', maybe you meant:\n"
                                            '  * volumes-from\n',
                         stdout='usage: aws [options] <command> <subcommand> [parameters]\n'
                                'aws: error: argument command: Invalid choice: \'volumes\', maybe you meant:\n'
                                '  * volumes-from'))
    assert not match(Command(script='ls -la'))
