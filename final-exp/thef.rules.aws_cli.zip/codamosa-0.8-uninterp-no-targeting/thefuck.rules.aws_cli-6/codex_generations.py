

# Generated at 2022-06-22 00:51:13.657127
# Unit test for function get_new_command
def test_get_new_command():
    script = 'aws iam list-users'
    output = '''
usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument command: Invalid choice, valid choices are:

configure
ec2
help
s3api
s3
'''
    new_command1 = 'aws iam list-users'
    new_command2 = 'aws iam-list-users'
    commands = get_new_command(Command(script, output))
    assert new_command1 in commands
    assert new_command2 in commands
    assert len(commands) == 2

# Generated at 2022-06-22 00:51:18.381310
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 create-amis --image-id ami-c145958a --instance-id i-c95958a', '')) == ['aws ec2 create-image --image-id ami-c145958a --instance-id i-c95958a']

# Generated at 2022-06-22 00:51:25.836823
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.rules.aws_maybe_you_meant import get_new_command

    command = 'aws: error: argument command: Invalid choice: \'glacier\', maybe you meant:\n  * glacier\n  * glancert\n  * glicer\n  * gliser\n  * lcier\n  * slaicer\n\nSee \'aws help\' for descriptions of global parameters.\n' 
    assert get_new_command(command) == ['aws glacier', 'aws glancert', 'aws glicer', 'aws gliser', 'aws lcier', 'aws slaicer']

# Generated at 2022-06-22 00:51:27.536906
# Unit test for function match
def test_match():
    command = Command('aws')
    assert not match(command)

    command = Command('aws help')
    assert match(command)

    command = Command('aws help foo')
    assert match(command)

# Generated at 2022-06-22 00:51:39.878326
# Unit test for function get_new_command
def test_get_new_command():
    command = '''aws iam list-users
usage: aws [options] <command> <subcommand> [parameters]
aws: error: argument subcommand: Invalid choice, valid choices are:
create-virtual-mfa-device | delete-login-profile | delete-virtual-mfa-device | enable-mfa-device | get-login-profile | list-mfa-devices | list-virtual-mfa-devices | reset-password | update-login-profile | update-access-key | update-account-password-policy | update-assume-role-policy | update-group | update-login-profile | update-server-certificate | update-signing-certificate | upload-server-certificate | upload-signing-certificate
maybe you meant:
    create-login-profile | create-access-key'''

# Generated at 2022-06-22 00:51:46.837174
# Unit test for function match
def test_match():
    command = Command('aws s3 mv dir1 dir2', 'usage: aws [options] <command> <subcommand> [parameters] '
                                             '\naws: error: argument <command>: Invalid choice: '
                                             '\'mv\', maybe you meant:\n\tmb\n\tmb-size\n\tmsu\n\tmv\n\tto-json')
    assert match(command)



# Generated at 2022-06-22 00:51:52.875838
# Unit test for function match
def test_match():
    assert match(Command('aws cli', 'aws ec2 run-instances \
                --image-id ami-0323c3dd2da7fb37d \
                --count 1 \
                --instance-type t2.micro \
                --key-name MyKeyPair --min count 1 --max-count 1'))


# Generated at 2022-06-22 00:52:03.189711
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws iam list-group --no-paged')) == \
        ['aws iam list-groups --no-paged']
    assert get_new_command(Command('aws s3 bucket-delete --delete-bucket --bucket my_bucket')) == \
        ['aws s3 delete-bucket --delete-bucket --bucket my_bucket',
         'aws s3 delete-bucket --bucket my_bucket']
    assert get_new_command(Command('aws lambda list-functions --max-item 1')) == \
        ['aws lambda list-functions --max-items 1']

# Generated at 2022-06-22 00:52:12.415332
# Unit test for function get_new_command
def test_get_new_command():
    command_with_error = """
usage: aws [options] <command> <subcommand> [<subcommand> ...]
aws: error: argument subcommand: Invalid choice, valid choices are:
usage: aws [options] <command> <subcommand> [<subcommand> ...]
"""
    assert get_new_command(Command('aws s3 sync s3://bucket-something/folder/ /home/me/folder/', command_with_error))==['aws s3 sync s3://bucket-something/folder/ /home/me/folder/']



# Generated at 2022-06-22 00:52:18.698395
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws codecommit help', 'aws: error: argument command: Invalid choice: \'help\', maybe you meant:\n  * create-repository\n  * get-repository\n', 'aws codecommit help')) == ['aws codecommit create-repository', 'aws codecommit get-repository']

# Generated at 2022-06-22 00:52:27.326974
# Unit test for function match
def test_match():
    assert match(Command('aws s3cmd mb s3://bucket','''usage: aws [options] <command> <subcommand> [parameters]
aws: error: argument operation: Invalid choice, maybe you meant:
    mkdir                          Make bucket.
    mkdirs                         Make bucket or directory.
    mb                             Make bucket.
    mb --help
'''))

# Generated at 2022-06-22 00:52:28.516350
# Unit test for function match
def test_match():
	pass



# Generated at 2022-06-22 00:52:30.570894
# Unit test for function match
def test_match():
    assert match(Command('aws ec2'))
    assert not match(Command('aws ec2'))



# Generated at 2022-06-22 00:52:38.376625
# Unit test for function match

# Generated at 2022-06-22 00:52:49.547872
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command

# Generated at 2022-06-22 00:53:00.541445
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws ec2 describe-security-groups --filters Name=ip-permission.cidr,Values=0.0.0.0/0"
    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, valid choices are:

create-security-group
describe-security-groups
...

maybe you meant:
  securitygroups"""

# Generated at 2022-06-22 00:53:10.332206
# Unit test for function match
def test_match():
    assert match(Command('aws help', '', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\naws: error: argument options: Invalid choice: \'help\', maybe you meant:\n    --version             Show the version and exit\n    --color               Control whether color is used\n    --profile             Use a specific profile from your credential file'))


# Generated at 2022-06-22 00:53:21.256304
# Unit test for function match

# Generated at 2022-06-22 00:53:25.865003
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws ec2 describe-instances i-123456789") == ["aws ec2 describe-instances --instance-id i-123456789"]


# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-22 00:53:31.351189
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws autoscaling describe-autoscaling-groups', '', 'Invalid choice: "describe-autoscaling-groups", maybe you meant:\n  ^\n * describe-auto-scaling-groups\n    Describes one or more Auto Scaling groups. For more information, see DescribeAutoScalingGroups in the\n    Auto Scaling API Reference.')
    assert get_new_command(command) == ['aws autoscaling describe-auto-scaling-groups']

# Generated at 2022-06-22 00:53:41.628741
# Unit test for function get_new_command
def test_get_new_command():
    actual = get_new_command(Command('aws help', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice: \'hel\', maybe you meant: * help'))
    expected = ['aws help', 'aws help help', 'aws help hel help']
    assert actual == expected

# Generated at 2022-06-22 00:53:53.792873
# Unit test for function match

# Generated at 2022-06-22 00:54:06.341063
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('aws: error: argument subcommand: Invalid choice: \'add\', maybe you meant:\n\n  * add-on-premises-instance\n  * add-tags\n  * add-user-to-group\n\n') == ['aws add-on-premises-instance', 'aws add-tags', 'aws add-user-to-group']
    assert get_new_command('aws: error: argument subcommand: Invalid choice: \'add-on-premises-instance\', maybe you meant:\n\n  * add-tags\n  * add-user-to-group\n\n') == ['aws add-tags', 'aws add-user-to-group']

# Generated at 2022-06-22 00:54:14.574190
# Unit test for function match
def test_match():
    command_invalid = Command('aws ec2 list-instances --query 1', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --query: Invalid choice: \'1\', maybe you meant:\n    --query  (string) JMESPath query string. See http://jmespath.org/ for more information and examples\n\n')
    return match(command_invalid)


# Generated at 2022-06-22 00:54:27.087217
# Unit test for function get_new_command

# Generated at 2022-06-22 00:54:30.413374
# Unit test for function match
def test_match():
    assert match(Command(script='cmd', output='usage: cmd'))
    assert not match(Command(script='cmd', output='cmd'))


# Generated at 2022-06-22 00:54:36.474827
# Unit test for function match
def test_match():
    output = '''
usage: aws [options] <command> <subcommand> [parameters]
To see help text, you can run:
aws help;
aws <command> help;
aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, maybe you meant:
*   realm
    ls
    mb'''
    assert match(Command(script='', output=output))


# Generated at 2022-06-22 00:54:44.928614
# Unit test for function match
def test_match():
    assert match(Command("aws", "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]", "aws: error: argument command: Invalid choice: 'flase', maybe you meant: \n    * false"))
    assert match(Command("aws", "usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]", "aws: error: argument command: Invalid choice: 'flase', maybe you meant: \n    * false")) == False


# Generated at 2022-06-22 00:54:56.764493
# Unit test for function match
def test_match():
    assert match(Command('aws', 'Invalid choice: \'test\', maybe you meant:', "usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument subcommand: Invalid choice: 'test', maybe you meant: \n    * test\n    * test-method"))
    assert not match(Command('ls', '', "usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument subcommand: Invalid choice: 'test', maybe you meant: \n    * test\n    * test-method"))
    assert not match(Command('ls', '', "usage: aws [options] <command> <subcommand> [parameters]\naws: error: argument subcommand: Invalid choice: 'test', maybe you meant: \n    * test\n"))

# Generated at 2022-06-22 00:55:09.046632
# Unit test for function get_new_command

# Generated at 2022-06-22 00:55:14.501567
# Unit test for function match
def test_match():
    assert match(Command("aws help", "Invalid choice: 'helpp', maybe you meant:\n  * help"))


# Generated at 2022-06-22 00:55:25.006275
# Unit test for function get_new_command
def test_get_new_command():
    command = Command("aws elb describe-load-balancers --region us-east-1")

# Generated at 2022-06-22 00:55:36.324019
# Unit test for function match
def test_match():
    assert match({'script': 'aws iam update-user --user-name s3_access', 'output': 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --user-name: Invalid choice, maybe you meant:\n* user-name\n\n* client-token\n\n* client-token-code\n* request-token\n* user-name-code\n\nSee \'aws help\' for descriptions of global parameters.\n'}) is True


# Generated at 2022-06-22 00:55:42.801122
# Unit test for function match
def test_match():
    command = Command('command --help', 'usage: command [--option1] [--option2] [--option3]\n\nInvalid choice: \'--option4\', maybe you meant:\n\t--option1\n\t--option2\n\t--option3\n')
    assert match(command)


# Generated at 2022-06-22 00:55:50.460832
# Unit test for function get_new_command

# Generated at 2022-06-22 00:55:52.731859
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command('awslocal sqs --endpoint http://127.0.0.1:9324 createtestqueue --queue-name fifo_queue.fifo') == ['awslocal sqs --endpoint http://127.0.0.1:9324 create-queue --queue-name fifo_queue.fifo']


enabled_by_default = True

# Generated at 2022-06-22 00:56:01.489146
# Unit test for function match

# Generated at 2022-06-22 00:56:13.185347
# Unit test for function match

# Generated at 2022-06-22 00:56:25.840210
# Unit test for function match
def test_match():
    assert match(Command('aws ec2', 'usage: aws [options] &lt;command&gt; &lt;subcommand&gt; [parameters]\n\naws: error: argument &lt;command&gt;: Invalid choice, maybe you meant:\n  ec2.amazonaws.com\n  ec2.us-east-1.amazonaws.com\n  ec2.us-west-1.amazonaws.com\n  ec2.us-west-2.amazonaws.com\n  ec2.eu-west-1.amazonaws.com\n  ec2.ap-southeast-1.amazonaws.com\n  ec2.ap-northeast-1.amazonaws.com\n\nSee \'aws help\' for descriptions of global parameters.\n', 'aws ec2', 1)) == True

# Generated at 2022-06-22 00:56:38.735948
# Unit test for function match
def test_match():
    output_one="""usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help

Unknown options: foo
  (Invalid choice: 'foo', maybe you meant: 
  
   --foo)"""

# Generated at 2022-06-22 00:56:50.576903
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command(script="aws ec2 start-instances --instance-ids i-12345678",
                                   output="aws: error: argument --instance-ids: Invalid choice: 'i-12345678', maybe you meant:\n\n* i-1234567890\n* i-123456789", stderr="", exit_code=2)) in [['aws ec2 start-instances --instance-ids i-1234567890'], ['aws ec2 start-instances --instance-ids i-123456789']]

# Generated at 2022-06-22 00:56:59.541286
# Unit test for function match

# Generated at 2022-06-22 00:57:02.088445
# Unit test for function get_new_command
def test_get_new_command():
    actual = get_new_command('aws s3 ls sb')[0]
    assert actual == 'aws s3 ls s3'

# Generated at 2022-06-22 00:57:12.547814
# Unit test for function get_new_command
def test_get_new_command():
    command = type(str('Command'), (object,), {
        'script': 'aws s3 ls s3://mybucket',
        'output': 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nerror: Invalid choice: \'s3://mybucket\', maybe you meant:\n  * s3'
    })

    assert get_new_command(command)[0] == "aws s3 ls s3"


# Generated at 2022-06-22 00:57:20.133484
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws ec2 start-instances -i foo')) == ['aws ec2 start-instances -i i-e3dae3ea']
    assert get_new_command(Command('aws s3 mb s3://foo')) == ['aws s3 mb s3://foo-bar']
    assert get_new_command(Command('aws s3 mb s3://foo-bar')) == ['aws s3 mb s3://foo-bar-baz']

# Generated at 2022-06-22 00:57:23.423438
# Unit test for function match
def test_match():
    assert match(Command('aws acm list-certificates', None))
    assert not match(Command('ls', None))


# Generated at 2022-06-22 00:57:35.201313
# Unit test for function get_new_command

# Generated at 2022-06-22 00:57:41.860037
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(Command('aws s3 ls', '')) == ['aws s3 ls']

# Generated at 2022-06-22 00:57:46.086167
# Unit test for function match
def test_match():
    assert match(Command('aws s3 help', 'usage: aws [options] <command> <subcommand> [parameters]\n\naws: error: argument operation: Invalid choice, valid choices are:\n    * cp\n    * ls\n    * mb\n    * mv\n    * rb\n    * rm\n    * sync\n    * website\n\naws: error: the following arguments are required: operation\n\nusage: aws [options] <command> <subcommand> [parameters]\naws: error: too few arguments\n'))
    assert not match(Command('ls', 'ls: invalid option -- a\n'))
    assert not match(Command('ls', 'ls: you have to specify a file\n'))

# Generated at 2022-06-22 00:57:57.882754
# Unit test for function match

# Generated at 2022-06-22 00:58:21.221300
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.main import get_new_command
    script = 'aws kinesis list-streams'
    output = 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\n\nerror: Invalid choice: \'kinesis\', maybe you meant:\n\n  * events\n  * firehose\n  * logs\n'
    assert get_new_command(script, output) == [
        'aws events list-streams',
        'aws firehose list-streams',
        'aws logs list-streams']

# Generated at 2022-06-22 00:58:23.702082
# Unit test for function match
def test_match():
    assert match(Command('aws ec2 help', ''))
    assert not match(Command('ls', ''))

# Generated at 2022-06-22 00:58:25.982532
# Unit test for function get_new_command
def test_get_new_command():
    comm = Command('aws ec2-instance', 'aws: error: argument --subnet is required')
    print (get_new_command(comm))

# Generated at 2022-06-22 00:58:31.749932
# Unit test for function get_new_command
def test_get_new_command():
    from thefuck.types import Command
    output = """usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]
To see help text, you can run:

  aws help
  aws <command> help
  aws <command> <subcommand> help
aws: error: argument subcommand: Invalid choice, maybe you meant:
* monitor
* moni
* monitor-instances"""
    command = Command('aws ec2 cerate-instance --region=us-east-1', output)
    assert get_new_command(command) == ["aws ec2 create-instance --region=us-east-1"]



# Generated at 2022-06-22 00:58:38.175052
# Unit test for function get_new_command
def test_get_new_command():
    output = "usage: aws [options] <command> <subcommand> [parameters]\n\naws: error: argument <command>: Invalid choice: 'foo', maybe you meant:\n* food\n* fool"
    command = Command('aws foo', output)

    assert get_new_command(command) == ["aws food", "aws fool"]

# Generated at 2022-06-22 00:58:43.035182
# Unit test for function match
def test_match():
    assert match(Command('aws help', 'usage: aws [--version] [--help] [options] '
                          '<command> <subcommand> [<subcommand> ...]',
                          'aws: error: Invalid choice: '
                          '"help", maybe you meant:',
                          '\n  * help'))



# Generated at 2022-06-22 00:58:51.611857
# Unit test for function match
def test_match():
    result_falsy = match(Command('ls', '', 'ls: cannot access file: No such file or directory'))
    result_truthy = match(Command('aws', '', "usage: aws [options] [ ...] [parameters]   specify the available command options (if any)   describe the command's required and optional parameters, if any   provide one or more usage examples"))
    assert result_falsy is False
    assert result_truthy is True


# Generated at 2022-06-22 00:59:02.302284
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command("aws s3 mb s3://bucket") == ["aws s3 mb s3://bucket"]
    assert get_new_command("aws s3 rb s3://bucket") == ["aws s3 rb s3://bucket"]
    assert get_new_command("aws s3 mv file1 s3://bucket/file2") == ["aws s3 mv file1 s3://bucket/file2"]
    assert get_new_command("aws s3 mv s3://bucket/file1 s3://bucket/file2") == ["aws s3 mv s3://bucket/file1 s3://bucket/file2"]

# Generated at 2022-06-22 00:59:13.350339
# Unit test for function match
def test_match():

    # Test invalid command
    wrong_cmd = Command(script='aws s3 sync /tmp/prefix s3://mybucket/ --acl pub',
                        stdout="",
                        stderr="usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\n"
                               "aws: error: argument subcommand: Invalid choice, "
                               "maybe you meant: bucket-sync?\n")
    assert match(wrong_cmd) == True

    # Test valid command
    good_cmd = Command(script='aws s3 sync /tmp s3://mybucket/ --acl pub',
                       stdout="",
                       stderr="")
    assert match(good_cmd) == False



# Generated at 2022-06-22 00:59:16.663784
# Unit test for function match
def test_match():
    assert match(Command('aws s3 mb s3://bucket',
                         'usage: aws [options] <command> <subcommand> [parameters]\n'
                         'aws: error: argument --bucket is required\n'
                         '\n'
                         'S3 (ObjeSt storage):\n'
                         'mb\tcreate-bucket\t\tCreate a bucket for use with Amazon S3'))



# Generated at 2022-06-22 00:59:43.585092
# Unit test for function match
def test_match():
    assert match(Command('aws', '', ''))


# Generated at 2022-06-22 00:59:54.364253
# Unit test for function get_new_command
def test_get_new_command():
    script = "aws iam update-login-profile --user-name dummyUser"

# Generated at 2022-06-22 01:00:05.857140
# Unit test for function get_new_command
def test_get_new_command():
    command = Command('aws euca-describe-keypairs --f t2.micro', 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument --filters/-f: Invalid choice: \'t2.micro\', maybe you meant:\n* --filter\n* --format\n\n')
    assert get_new_command(command) == ['aws euca-describe-keypairs --filter t2.micro', 'aws euca-describe-keypairs --format t2.micro']

# Generated at 2022-06-22 01:00:18.468639
# Unit test for function get_new_command

# Generated at 2022-06-22 01:00:30.545235
# Unit test for function get_new_command
def test_get_new_command():
    def check_command(command, expected_command, expected_mistake, expected_options):
        assert expected_command == get_new_command(command)
        assert expected_mistake == re.search(INVALID_CHOICE, command.output).group(0)
        assert expected_options == re.findall(OPTIONS, command.output, flags=re.MULTILINE)
    from thefuck.types import Command
    #command = Command('aws', 'Invalid choice: \'eks\', maybe you meant:\n* ecr\n* ec2\n* s3\nSee \'aws help\' for descriptions of global parameters.')
    #new_command = [replace_argument(command.script, mistake, o) for o in options]

# Generated at 2022-06-22 01:00:35.278427
# Unit test for function get_new_command
def test_get_new_command():
    assert get_new_command(
        Command("aws ec2 describe-volumes", "Invalid choice: 'describe-volumes', maybe you meant:\n* describe-volume-status\n* describe-volume-attribute")) \
        == ["aws ec2 describe-volume-status", "aws ec2 describe-volume-attribute"]

# Generated at 2022-06-22 01:00:41.053307
# Unit test for function get_new_command
def test_get_new_command():
    command = Command(script='aws ec2 status',
                      output="aws: error: argument subcommand: Invalid choice: 'status', maybe you meant:\n  * stop",
                      stderr=None,
                      all_args=['aws', 'ec2', 'status'])
    assert get_new_command(command) == ['aws ec2 stop']

# Generated at 2022-06-22 01:00:50.654316
# Unit test for function get_new_command
def test_get_new_command():
    # Test 1
    test_command = type('obj', (object,), {'script': 'aws ec2-describe-instances', 'output': 'usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters] \nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument operation: Invalid choice, maybe you meant:\n  ec2-describe-instances\n  ec2-describe-security-groups\nSee \'aws help\' for descriptions of global parameters.'})
    assert get_new_command(test_command) == ['aws ec2-describe-instances', 'aws ec2-describe-security-groups']

# Generated at 2022-06-22 01:01:02.650091
# Unit test for function match
def test_match():
    assert not match(Command('aws', ''))
    assert match(Command('aws', script='aws ec2'))
    assert not match(Command('aws', script='aws ec2 describe-instances',
                             output='usage: aws [options] <command> <subcommand> [<subcommand> ...] [parameters]\nTo see help text, you can run:\n\n  aws help\n  aws <command> help\n  aws <command> <subcommand> help\naws: error: argument subcommand: Invalid choice, maybe you meant:  --cli-input-json\n\n'))