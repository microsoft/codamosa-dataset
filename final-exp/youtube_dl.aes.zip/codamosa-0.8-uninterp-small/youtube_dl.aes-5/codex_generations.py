

# Generated at 2022-06-26 10:52:53.541179
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:53:01.849929
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test case 0
    str_0 = 'Mating Crabs Busted by Sharks'
    var_0 = sub_bytes(str_0)
    decrypted = aes_cbc_decrypt(var_0)
    print(decrypted)
    assert decrypted == str_0

    # Test case 1
    str_1 = 'Mating Crabs Busted by Sharks'
    var_1 = sub_bytes(str_1)
    decrypted = aes_cbc_decrypt(var_1)
    print(decrypted)
    assert decrypted == str_1


# Generated at 2022-06-26 10:53:03.605131
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # TODO: Add test case for function aes_cbc_decrypt
    pass


# Generated at 2022-06-26 10:53:11.225953
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    FORMAT_STR_ENCRYPTED_WITH_16_BYTES_KEY = [
        ['QTxKj9XJT/N+FhyOZM3qFw==', 'Mating Crabs Busted by Sharks'],
        ['QXxoQjmZk/EZ+1rM+jrA0w==', 'Mating Crabs Busted by Sharks'],
        ['QXt9QjmZk/EZ+1rM+jrA0w==', 'Mating Crabs Busted by Sharks'],
    ]

# Generated at 2022-06-26 10:53:22.727827
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Sample case 0
    str_0 = 'Mating Crabs Busted by Sharks'
    var_0_encoded = 'TGlmZSBpdHNlbGYgaXMgYSBxdW90YXRpb24u'
    var_0_key = 'I AM LEGEND!!!'
    var_0_counter = 'abcdefghijklmnop'
    var_0_exp = 'Life itself is a quotation.'

    var_0_key_encoded = bytes_to_intlist(compat_b64decode(var_0_key))
    var_0_counter_encoded = bytes_to_intlist(compat_b64decode(var_0_counter))

# Generated at 2022-06-26 10:53:32.863589
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    input_bytes = bytes_to_intlist(b'YELLOW SUBMARINE' + b'\x10'*16)
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = [0]*16
    cipher = aes_cbc_encrypt(input_bytes, key, iv)

# Generated at 2022-06-26 10:53:43.912854
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test case 0
    key_0 = b'Jefe'
    data_0 = b'what do ya want for nothing?'

    # Test case 0
    key_1 = b'Jefe'
    data_1 = b'what do ya want for nothing?'
    iv_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

    # Test case 1
    key_2 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-26 10:53:56.521121
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test vars for function aes_cbc_decrypt
    var_0 = 'Mating Crabs Busted by Sharks'

# Generated at 2022-06-26 10:54:04.143082
# Unit test for function aes_encrypt
def test_aes_encrypt():
    str_1 = 'Mating Crabs Busted by Sharks'
    str_2 = 'Mating Crabs Busted by Sharks'
    str_2=shift_rows(str_2)
    var_2 = sub_bytes(str_2)
    key_a = '80' * 16
    expanded_key_a = key_expansion(key_a)
    var_1 = aes_encrypt(var_2, expanded_key_a)
    print(var_1)
    assert var_1 == var_2, "Error function aes_encrypt"



# Generated at 2022-06-26 10:54:08.856311
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'Q6iHUQhZUO8sx6Gwy9YHpKmDyBwT1gkvDNCaq1fK+n4='
    password = 'abc123'
    key_size_bytes = 32
    result = aes_decrypt_text(data, password, key_size_bytes)
    str_0 = 'Mating Crabs Busted by Sharks'
    assert result == str_0

# Generated at 2022-06-26 10:54:24.742855
# Unit test for function aes_decrypt

# Generated at 2022-06-26 10:54:34.435576
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # test case 1
    data = bytes_to_intlist('U2FsdGVkX1+qXvV7dRIDiOyFpDIbM5v/x5ZmzKZBt0mB8rI+XmhjJm+iPiD2Q8GvHVxgkkaZBBLkZWnMX8r1Mg==')
    key = bytes_to_intlist('12345678901234567890123456789012')
    iv = bytes_to_intlist('1234567890123456')
    result = aes_cbc_decrypt(data, key, iv)

# Generated at 2022-06-26 10:54:39.510193
# Unit test for function aes_decrypt
def test_aes_decrypt():
    str_0 = 'Mating Crabs Busted by Sharks'
    key = '1234567890ABCDEF'
    expanded_key = key_expansion(key)
    data = aes_encrypt(str_0, expanded_key)
    assert(len(data) == BLOCK_SIZE_BYTES)
    data = aes_decrypt(data, expanded_key)
    assert(len(data) == BLOCK_SIZE_BYTES)

    str_0 = 'Subsistence Marasmus Infirmity'
    key = '1234567890ABCDEF'
    expanded_key = key_expansion(key)
    data = aes_encrypt(str_0, expanded_key)
    assert(len(data) == BLOCK_SIZE_BYTES)

# Generated at 2022-06-26 10:54:50.482210
# Unit test for function aes_decrypt
def test_aes_decrypt():
    k = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]

    print("Unit test for function aes_decrypt")
    c = [0x39, 0x25, 0x84, 0x1D, 0x02, 0xDC, 0x09, 0xFB, 0xDC, 0x11, 0x85, 0x97, 0x19, 0x6A, 0x0B, 0x32]
    m = aes_decrypt(c, key_expansion(k))

# Generated at 2022-06-26 10:54:55.652353
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test case 0
    # Test description: first test case
    # Input:
    str_0 = 'Mating Crabs Busted by Sharks'
    var_0 = sub_bytes(str_0)
    # Expected output:
    exp_0 = [146, 153, 158, 137, 210, 211, 213, 151, 77, 77, 77, 77, 77, 77, 77, 77]
    # Actual output:
    
    assert var_0 == exp_0


# Generated at 2022-06-26 10:55:05.494288
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    cipher_text = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    iv = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    assert aes_cbc_decrypt(cipher_text, key, iv) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]



# Generated at 2022-06-26 10:55:12.683825
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    str_0 = '{"response": "Hello W\u006frld!"}'
    str_1 = b'T\x91\x97\x0f\x9c"\x8d\xdf\x92D\xcd\x8d\x05\xf7\xb5\x9a\xaa\x1e\x044\x85\xee\x0c\x12\x13\xca\xf5\x8f\xe0!\x14'
    var_0 = aes_cbc_decrypt(str_1, str_0, str_0)
    assert var_0 == str_0


# Generated at 2022-06-26 10:55:23.986270
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = [0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0]
    data = [0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0]

# Generated at 2022-06-26 10:55:35.616900
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """
    Tests aes_cbc_decrypt on a known input and output
    """
    # The known inputs
    cipher = bytes_to_intlist(compat_b64decode("cwpi8fsSYWpOTY59JH7R+Lg=="))
    key = bytes_to_intlist(compat_b64decode("abcdefghijklmnopqrstuvwx"))
    iv = bytes_to_intlist(compat_b64decode("0123456789ABCDEF"))

    # The expected output
    expected_output = "Mating Crabs Busted by Sharks"

    # The computed output
    output = aes_cbc_decrypt(cipher, key, iv)
    output = intlist_to_bytes(output)

    # Check that the outputs match
    assert output

# Generated at 2022-06-26 10:55:40.511734
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:56:28.711487
# Unit test for function key_expansion

# Generated at 2022-06-26 10:56:42.100089
# Unit test for function key_expansion
def test_key_expansion():
    x = '000102030405060708090a0b0c0d0e0f'
    y = '000102030405060708090a0b0c0d0e0f1011121314151617'
    z = '000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f'

    assert len(key_expansion(bytes_to_intlist(compat_b64decode(x)))) == 176
    assert len(key_expansion(bytes_to_intlist(compat_b64decode(y)))) == 208
    assert len(key_expansion(bytes_to_intlist(compat_b64decode(z)))) == 240
    return True

# Unit

# Generated at 2022-06-26 10:56:54.079911
# Unit test for function key_expansion
def test_key_expansion():
    """
    Unit test for function key_expansion
    """
    # Test case #1
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]
    
    # Expected result

# Generated at 2022-06-26 10:57:01.527525
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist('1234567890abcdef')
    result_0 = bytes_to_intlist('1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef')

    # Test of case 0
    assert key_expansion(data) == result_0


# Generated at 2022-06-26 10:57:13.675629
# Unit test for function key_expansion

# Generated at 2022-06-26 10:57:16.237879
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Mating Crabs Busted by Sharks'
    var_0 = key_expansion(str_0)
    str_1 = 'Snail loves dried seaweed'
    var_1 = key_expansion(str_1)
    str_2 = 'The brown-billed scythebill'
    var_2 = key_expansion(str_2)
    str_3 = 'Warty Toadfish'
    var_3 = key_expansion(str_3)



# Generated at 2022-06-26 10:57:26.608674
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = [0x54, 0x68, 0x61, 0x74, 0x73, 0x20, 0x6D, 0x79, 0x20, 0x4B, 0x75, 0x6E, 0x67, 0x20, 0x46, 0x75]

# Generated at 2022-06-26 10:57:40.060618
# Unit test for function key_expansion
def test_key_expansion():
    var_1 = key_expansion('0x00000000000000000000000000000000')
    print(var_1) # This should return [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0

# Generated at 2022-06-26 10:57:50.538721
# Unit test for function key_expansion
def test_key_expansion():
    key = ['0x2b', '0x7e', '0x15', '0x16', '0x28', '0xae', '0xd2', '0xa6',
           '0xab', '0xf7', '0x15', '0x88', '0x09', '0xcf', '0x4f', '0x3c']

# Generated at 2022-06-26 10:57:51.757766
# Unit test for function key_expansion
def test_key_expansion():
    print("Begin key_expansion testing")
    test_case_0()


# Generated at 2022-06-26 10:58:05.379992
# Unit test for function key_expansion
def test_key_expansion():
    var_0 = '2b28ab097eaef7cf15d2154f16a6883c'
    key_expansion_0 = key_expansion(compat_b64decode(var_0))
    assert len(key_expansion_0) == 176, 'Error in test #0'
    var_0 = '8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b'
    key_expansion_0 = key_expansion(compat_b64decode(var_0))
    assert len(key_expansion_0) == 208, 'Error in test #1'

# Generated at 2022-06-26 10:58:12.904481
# Unit test for function key_expansion
def test_key_expansion():

    data = sub_bytes(bytes_to_intlist('401112131415161718191A1B1C1D1E1F')) # key to bytes_to_intlist
    new_data = key_expansion(data) # key_expansion
    expected_data = sub_bytes(bytes_to_intlist('401112131415161718191A1B1C1D1E1FF0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF')) #key to bytes_to_intlist
    assert new_data == expected_data
    print("Key_expansion() passed")


# Generated at 2022-06-26 10:58:21.567372
# Unit test for function key_expansion
def test_key_expansion():
    test_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 10:58:32.708821
# Unit test for function key_expansion

# Generated at 2022-06-26 10:58:39.266234
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    # Input word: "Mating Crabs Busted by Sharks"
    var_0 = [77, 97, 116, 105, 110, 103, 32, 67, 114, 97, 98, 115, 32, 66, 117, 115, 116, 101, 100, 32, 98, 121, 32, 83, 104, 97, 114, 107, 115]
    # Expected output: [77, 97, 116, 105, 110, 103, 32, 67, 114, 97, 98, 115, 32, 66, 117, 115, 116, 101, 100, 32, 98, 121, 32, 83, 104, 97, 114, 107, 115, 78, 79, 116, 69, 78, 71, 83, 32, 78, 79, 69, 78, 71, 83, 32, 78, 79, 69, 78, 71, 83, 32, 78, 79

# Generated at 2022-06-26 10:58:47.991727
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    var_0 = key_expansion(key_0)

    key_1 = [0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5, 0x62, 0xf8, 0xea, 0xd2, 0x52, 0x2c, 0x6b, 0x7b]


# Generated at 2022-06-26 10:58:53.448455
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Mating Crabs Busted by Sharks'
    var_0 = sub_bytes(str_0)
    assert var_0 == [104, 96, 86, 104, 96, 86, 111, 108], "Not equal"
    temp_0 = [104, 96, 86, 104, 96, 86, 111, 108]
    assert rcon(temp_0, 1) == [98, 104, 96, 86, 104, 96, 111, 108], "Not equal"
    temp_0 = [104, 96, 86, 104, 96, 86, 111, 108]
    assert sub_word(temp_0) == [210, 51, 143, 62, 206, 187, 145, 45], "Not equal"

# Generated at 2022-06-26 10:59:02.981914
# Unit test for function key_expansion
def test_key_expansion():
    print ('\n----- Function key_expansion TEST -----')

    # AES128
    key = bytes_to_intlist('140b41b22a29beb4061bda66b6747e14')
    expanded_key = key_expansion(key)
    print ('Nb(4), Nk(4), Nr(10)')    
    print ('key: \n{}'.format(intlist_to_bytes(key)))
    print ('expanded_key: \n{}'.format(intlist_to_bytes(expanded_key)))
    print ()

    # AES192
    key = bytes_to_intlist('8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b')
    expanded_key = key_expansion(key)

# Generated at 2022-06-26 10:59:16.029730
# Unit test for function key_expansion
def test_key_expansion():
    key_expanded = key_expansion([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])

# Generated at 2022-06-26 10:59:27.998522
# Unit test for function key_expansion

# Generated at 2022-06-26 10:59:42.686004
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')

# Generated at 2022-06-26 10:59:44.044916
# Unit test for function key_expansion
def test_key_expansion():
    key_size_bytes = 32 #256-bit key
    data = key_expansion(range(key_size_bytes))
    assert len(data) == 240


# Generated at 2022-06-26 10:59:47.168678
# Unit test for function key_expansion
def test_key_expansion():
    key = list(bytes_to_intlist('123456789abcdef0'))
    re_key = list(bytes_to_intlist('123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0'))
    assert key_expansion(key) == re_key



# Generated at 2022-06-26 10:59:50.024110
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Mating Crabs Busted by Sharks'
    var_0 = key_expansion(str_0)
    print(var_0)

# Generated at 2022-06-26 10:59:53.073830
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    str_0 = 'Mating Crabs Busted by Sharks'
    var_0 = key_expansion(str_0)
    # Test case 1
    str_1 = 'U6'


# Generated at 2022-06-26 11:00:01.996095
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'Thats my Kung Fu')

# Generated at 2022-06-26 11:00:11.204891
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
    key_1 = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31]

# Generated at 2022-06-26 11:00:14.443252
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = [57, 49, 41, 33, 25, 17, 9, 1, 57, 49, 41, 33, 25, 17, 9, 1]
    var_0 = key_expansion(key_0)


# Generated at 2022-06-26 11:00:21.544535
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = "Mating Crabs Busted by Sharks"
    var_0 = key_expansion(str_0)
    str_1 = "Mating Crabs Busted by Sharks"
    var_1 = aes_encrypt(str_1, var_0)
    str_2 = "Mating Crabs Busted by Sharks"
    var_2 = aes_decrypt(var_1, var_0)
    print(var_2)



# Generated at 2022-06-26 11:00:30.089253
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]

# Generated at 2022-06-26 11:00:44.673776
# Unit test for function key_expansion
def test_key_expansion():
    str_1 = 'Mating Crabs Busted by Sharks'
    key_expansion_1 = key_expansion(str_1)

    print(sub_bytes(key_expansion_1[-16:]))
    str_2 = 'Mastering Spells of Wizards'
    key_expansion_2 = key_expansion(str_2)
    print(sub_bytes(key_expansion_2[-16:]))



# Generated at 2022-06-26 11:00:58.059992
# Unit test for function key_expansion
def test_key_expansion():
    key_size_bytes = [16, 24, 32]
    # The block of cleartext is used to generate keys for aes
    cleartext = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]

    for key_size in key_size_bytes:
        key = cleartext[:key_size]
        result = key_expansion(key)
        print("Size of key in bytes: %d" % key_size)
        print("Size of expanded key in bytes: %d" % len(result))


# Generated at 2022-06-26 11:01:10.423315
# Unit test for function key_expansion
def test_key_expansion():
    # Data block size
    block_size = BLOCK_SIZE_BYTES
    # The key size can be one of two
    # key_size_bytes = 16
    key_size_bytes = 32
    # The expanded key size is 11 times the key size
    # plus the block size
    expanded_key_size_bytes = (key_size_bytes // 4 + 7) * block_size
    # We start off with all zeros
    data = [0] * key_size_bytes
    # We fill up the key with known values
    for i in range(key_size_bytes):
        data[i] = i
    # We have a known expanded key to compare to

# Generated at 2022-06-26 11:01:12.278147
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Mating Crabs Busted by Sharks'
    var_0 = key_expansion(str_0)


# Generated at 2022-06-26 11:01:20.243542
# Unit test for function key_expansion
def test_key_expansion():
    """
    Test function key_expansion

    @returns {bool}
    """
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 11:01:29.888707
# Unit test for function key_expansion

# Generated at 2022-06-26 11:01:42.515486
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    key_expansion_0 = key_expansion(
        bytes_to_intlist(
            compat_b64decode(
                'wgBxM3q3CXrQ2Ak8r1iRjg=='
            )
        )
    )
    assert key_expansion_0 == bytes_to_intlist(
        compat_b64decode(
            'wgBxM3q3CXrQ2Ak8r1iRjg0FQbUdAE4iKQDhV7NuRx4glL7H9iGp8h7T+g/3qVbs'
        )
    )
    # Test case 1

# Generated at 2022-06-26 11:01:52.276080
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    str_0 = 'Mating Crabs Busted by Sharks'
    res_0 = key_expansion(str_0)
    var_0 = sub_bytes(str_0)
    assert res_0 == var_0

    # Test case 1
    str_0 = '4-4-4-4-4-4-4-4-4-4-4-4-4-4-4-4-'
    res_0 = key_expansion(str_0)
    var_0 = sub_bytes(str_0)
    assert res_0 == var_0


# Generated at 2022-06-26 11:02:02.725315
# Unit test for function key_expansion

# Generated at 2022-06-26 11:02:14.120294
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = bytearray('1234567890123456')
    expected_return_0 = bytearray([49, 50, 51, 52, 53, 54, 55, 56, 57, 48, 49, 50, 51, 52, 53, 54, 113, 65, 112, 67, 121, 68, 113, 66, 121, 69, 113, 65, 121, 67, 49, 50, 51, 52, 121, 50, 51, 52, 53, 121, 51, 52, 53, 54, 121, 52, 53, 54, 55, 113, 50, 121, 51, 113, 51, 121, 52, 113, 52, 121, 53])
    actual_return_0 = key_expansion(str_0)