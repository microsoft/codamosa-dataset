

# Generated at 2022-06-26 10:52:43.717009
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    test_string = '12345'
    test_key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    class Counter:
        def __init__(self):
            self.counter = bytes_to_intlist(compat_b64decode('gECAYw=='))
            self.i = 0
        def next_value(self):
            self.counter[-1] += 1
            self.i += 1
            return self.counter
    # test_case = Counter()
    # print(test_case.next_value())
    # print(test_case.next_value())
    # print(test_case.next_value())
    counter = Counter()

# Generated at 2022-06-26 10:52:54.585744
# Unit test for function aes_encrypt
def test_aes_encrypt():
    print('++++')
    key = '0x000102030405060708090A0B0C0D0E0F'
    text = '0x00112233445566778899AABBCCDDEEFF'
    data = intlist_to_bytes(bytes_to_intlist(compat_b64decode(key)))
    expanded_key = key_expansion(data)
    print(expanded_key)
    expanded_key_str = intlist_to_bytes(expanded_key)
    print(str(expanded_key_str)[2:])
    #print('len of data:', len(data))
    #print('len of expanded_key:', len(expanded_key))


# Generated at 2022-06-26 10:53:05.117372
# Unit test for function key_expansion
def test_key_expansion():
    test_data = b'\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff'
    test_data = bytes_to_intlist(test_data)
    result = key_expansion(test_data)

# Generated at 2022-06-26 10:53:12.037002
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    plaintext = aes_decrypt_text(b'5qt+q3uq7tEb2tW66+VzOg==', 'coolpassword', 32)
    assert plaintext == b'Hello world!'

    plaintext = aes_decrypt_text(b'5qt+q3uq7tEb2tW66+VzOg==', b'coolpassword', 32)
    assert plaintext == b'Hello world!'

    plaintext = aes_decrypt_text(b'5qt+q3uq7tEb2tW66+VzOg==', u'coolpassword', 32)
    assert plaintext == b'Hello world!'

    # 'aes_decrypt_text' is used to decrypt signatures
    # So it is important that it works also with unicode strings
    plaintext

# Generated at 2022-06-26 10:53:21.214902
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist(compat_b64decode('P8cbU/3qU4svQsu1PB0dJJN9R0Y='))
    key = bytes_to_intlist(compat_b64decode('UuV7I1XkJYV7mPdIuRA+5w=='))
    expanded_key = key_expansion(key)
    res_raw = aes_decrypt(data, expanded_key)
    res = intlist_to_bytes(res_raw)
    assert res == b'hello_world'



# Generated at 2022-06-26 10:53:31.870575
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test Case 0
    bytes_0 = b'\x16\xe0\xae\x1c(['

# Generated at 2022-06-26 10:53:32.966111
# Unit test for function aes_decrypt
def test_aes_decrypt():
    pass


# Generated at 2022-06-26 10:53:43.950508
# Unit test for function aes_encrypt
def test_aes_encrypt():
    test_key = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F'
    test_data = b'\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xAA\xBB\xCC\xDD\xEE\xFF'

    test_key_expanded = key_expansion(test_key)
    test_data_encrypted = aes_encrypt(test_data, test_key_expanded)


# Generated at 2022-06-26 10:53:56.549276
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test case 1
    bytes_0 = b'\x73\xca\x54\xd7\x3d\x9e\x3e\x0c\x0d\x2a\xac\x73\x66\x3f\x9f\x3a'

# Generated at 2022-06-26 10:54:00.207366
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytearray()
    key = b'\0' * 16
    iv = b'\0' * 16
    aes_cbc_decrypt(data, key, iv)


# Generated at 2022-06-26 10:54:09.321124
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    message = b'\x16\xe0\xae\x1c(['
    message_as_bytes = bytes_to_intlist(message)
    
    key = b'YT8MZo2e8WR3tysw'
    key_as_bytes = bytes_to_intlist(key)

    iv = b'abcdefghijklmnop'
    iv_as_bytes = bytes_to_intlist(iv)

    print(aes_cbc_decrypt(message_as_bytes, key_as_bytes, iv_as_bytes))


# Generated at 2022-06-26 10:54:21.224786
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = bytes_to_intlist(b'x\xba\xb0\x1b\x18\x13\r\x06\x0e\x1d\x15\x1e')
    var_0 = key_expansion(bytes_0)

# Generated at 2022-06-26 10:54:31.488375
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = b'\x0f\x0e\x15\x0e\r\r\r\r\r\r\r\r\r\r\r\r\r'
    key = b'\x0f\x0e\x15\x0e\r\r\r\r\r\r\r\r\r\r\r\r\r'
    iv = b'\x0f\x0e\x15\x0e\r\r\r\r\r\r\r\r\r\r\r\r\r'
    result = aes_cbc_decrypt(data, key, iv)

# Generated at 2022-06-26 10:54:37.896007
# Unit test for function inc
def test_inc():
    # Run 100 tests

    for test_num in range(100):
        # Create random byte array
        data = [random.randint(0, 255) for _ in range(16)]
        data_inc = inc(data)

        # Check last byte to see if it was incremented
        if data[-1] == 255 and data_inc[-1] != 255:
            return False

        # Check if every other byte is the same
        for i in range(len(data)-1):
            if data[i] != data_inc[i]:
                return False


    # If no test failed return True (all tests passed)
    return True



# Generated at 2022-06-26 10:54:48.569045
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:54:56.801997
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = b'YELLOW SUBMARINE'
    data = b'\x00'

    expected_result = intlist_to_bytes([
        0xc4, 0x4b, 0x4c, 0x66, 0x38, 0x58, 0x70, 0x60,
        0x20, 0x3b, 0x5d, 0x71, 0xa3, 0xbb, 0x3d, 0x43,
    ])
    actual_result = aes_cbc_encrypt(
        bytes_to_intlist(data), bytes_to_intlist(key),
        [0] * BLOCK_SIZE_BYTES)
    assert expected_result == actual_result


# Generated at 2022-06-26 10:55:01.000682
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:55:10.689945
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test case 0
    key_0 = b'\x4a\x7f\x53\x61\x54\x15\x39\xac\x8e\x78\x5f\x0f\x71\x8d\x9a\x51'
    iv_0 = b'\x4a\x7f\x53\x61\x54\x15\x39\xac\x8e\x78\x5f\x0f\x71\x8d\x9a\x51'
    data_0 = b'\xd1\xdb\x27\xab\x00\x9b\x76\xa3\x3c\x3f\x13\x34\x74\x07\x94\x59'

# Generated at 2022-06-26 10:55:16.828810
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key_0 = b'\x06\xa9\x21\x40\x36\xb8\xa1\x5b\x51\x2e\x03\xd5\x34\x12\x00\x06'
    iv_0 =  b'\x3d\xaf\xba\x42\x9d\x9e\xb4\x30\xb4\x22\xda\x80\x2c\x9f\xac\x41'

# Generated at 2022-06-26 10:55:26.605932
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    print('AES CBC decryption')
    encryption_key = '140b41b22a29beb4061bda66b6747e14'
    cipher_text = '4ca00ff4c898d61e1edbf1800618fb2828a226d160dad07883d04e008a7897ee2e4b7465d5290d0c0e6c6822236e1daafb94ffe0c5da05d9476be028ad7c1d81'
    iv = '5b68629feb8606f9a6667670b75b38a5'
    data = bytes_to_intlist(compat_b64decode(cipher_text))
    key = bytes_to_intlist(compat_b64decode(encryption_key))
    iv = bytes

# Generated at 2022-06-26 10:55:37.370978
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:55:48.313656
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test vector from NIST SP 800-38A (https://csrc.nist.gov/CSRC/media/Projects/Cryptographic-Standards-and-Guidelines/documents/examples/AES_CBC.pdf)
    key = compat_b64decode('MzJieXRlc2tleTIzNDU2Nzg5MGFiY2RlZmdo')
    data = compat_b64decode('dmFsdWUxMmMxM2QxNGUxNWYxNmExNzE4MTkwMTkxYTE5MmEy')
    iv = compat_b64decode('MDAwMDAwMDAwMDAwMDAwMDAwMDAw')


# Generated at 2022-06-26 10:55:53.656477
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = b'\x06\xa9\x21\x40\x36\xb8\xa1\x5b\x51\x2e\x03\xd5\x34\x12\x00\x06'
    iv =b'\x3d\xaf\xba\x42\x9d\x9e\xb4\x30\xb4\x22\xda\x80\x2c\x9f\xac\x41'

# Generated at 2022-06-26 10:55:58.462492
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0] * 16
    iv = [0] * 16
    result = aes_cbc_encrypt([], key, iv)

    assert result == [0] * 16


# Generated at 2022-06-26 10:56:07.170290
# Unit test for function inc
def test_inc():
    assert inc([0xFF, 0xFF, 0xFF]) == [0x00, 0x00, 0x00]
    assert inc([0x00, 0x00, 0x00]) == [0x00, 0x00, 0x01]
    assert inc([0x01, 0x00, 0x00]) == [0x01, 0x00, 0x01]
    assert inc([0xFF, 0x00, 0x00]) == [0xFF, 0x00, 0x01]
    assert inc([0xFF, 0xFF, 0x00]) == [0x00, 0x00, 0x01]


# Generated at 2022-06-26 10:56:11.161803
# Unit test for function inc
def test_inc():
    data = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    data = inc(data)
    print((data))



# Generated at 2022-06-26 10:56:19.310279
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key_0 = "0x000102030405060708090a0b0c0d0e0f"
    #print(key_0)
    key_0 = key_0.decode("hex")
    #print(key_0)
    key_0 = bytes_to_intlist(key_0)
    #print(key_0)
    iv_0 = "0x000102030405060708090a0b0c0d0e0f".decode("hex")
    iv_0 = bytes_to_intlist(iv_0)
    #print(iv_0)

# Generated at 2022-06-26 10:56:29.645866
# Unit test for function inc
def test_inc():
    data = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert inc(data) == b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01'

    data = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xFF'

# Generated at 2022-06-26 10:56:42.986812
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    clear_bytes_0 = b'rO0ABXNyABpvcmcuYXNzZW1ibHkuYXJyYXlzLkZsb2F0MzJBcnJheQAAAAAAAAABDAAAeHB3CAAAAAB4'
    clear_var_0 = bytes_to_intlist(compat_b64decode(clear_bytes_0))
    key = b'f!g!Ri!n!g!a!r!a!m!1!'
    iv = b'i!V!r!o!n!p!a!y!n!e!'

# Generated at 2022-06-26 10:56:46.566420
# Unit test for function key_expansion
def test_key_expansion():
    print('test_key_expansion')
    test_0()
    test_1()
    test_2()
    test_3()
    test_4()


# Generated at 2022-06-26 10:56:52.632370
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = b"This is the plain text"
    key = b"This is a 24-Byte k"
    iv = b"A random 16-Byte i"

    key = bytes_to_intlist(compat_b64decode("gqmrUQjHUVD0hU6iIpOjGw=="))
    iv = bytes_to_intlist(compat_b64decode("foH+jKWrZwqrl3qeYTyYBA=="))

# Generated at 2022-06-26 10:56:59.675166
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = [113, 238, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98]
    var_0 = key_expansion(bytes_0)
    assert var_0 == [113, 238, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98, 98,
                     218, 219, 123, 194, 150, 243, 66, 244, 195, 84, 162, 138, 180, 172, 156, 174,
                     238, 183, 146, 60, 222, 28, 226, 202, 129, 135, 158, 163, 134, 175, 53, 211,
                     161, 59, 110, 79, 247, 180, 134, 151, 232, 66, 101, 197, 249, 45, 6, 77]

# Unit

# Generated at 2022-06-26 10:57:12.649238
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:57:24.350355
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-26 10:57:30.775809
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    expanded_key_0 = key_expansion(key_0)
    key_1 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]
    expanded_key_1 = key_expansion(key_1)

# Generated at 2022-06-26 10:57:37.613179
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    bytes_0 = b'\x16\xe0\xae\x1c(['
    var_0 = sub_bytes(bytes_0)
    bytes_1 = b'\x16\xe0\xae\x1c(['
    var_1 = encrypt_block(bytes_1, var_0)


# Generated at 2022-06-26 10:57:48.943101
# Unit test for function key_expansion
def test_key_expansion():
    # Case 0
    key_0 = b'\x00\x0f\xff\x3b\x0e\x0d\x0c\x0b\n\t\x08\x07\x06\x05\x04\x03\x02\x01\x00\x0f\xff\x39\x0e\x0d\x0c\x0b\n\t\x08\x07\x06\x05\x04\x03\x02\x01\x00\x0f'

# Generated at 2022-06-26 10:57:55.573343
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode(b'CY9rzUYh03PK3k6DJie09g=='))

# Generated at 2022-06-26 10:58:06.203078
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode(b'CY9rzUYh03PK3k6DJie09g=='))
    iv = bytes_to_intlist(compat_b64decode(b'ZmhJiqL7zd/z/u6R'))
    data = bytes_to_intlist(compat_b64decode(b'yr2Sf0I/HxVFjt4l8Jl4fg=='))
    decrypted = intlist_to_bytes(aes_cbc_encrypt(data, key, iv))
    assert decrypted == b'\x16\xe0\xae\x1c(['


# Generated at 2022-06-26 10:58:15.189341
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = b'\x16\xe0\xae\x1c(['
    key = b'\xe9\x89\xd3\xee\x17\xd8i\xb2\x11\xba\x13\x9a\x91\x0b\xee\x08\xfc'
    iv = b'\x77\xd9\x9e\x7c\x19\x7b\xa8\x2c\x5f\x47\xd0\x5f\x7c\x5d\xf7\x8d'


# Generated at 2022-06-26 10:58:26.818498
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    result = aes_cbc_encrypt([65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80],
                            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
                            [17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32])
    assert (result == [72, 247, 14, 77, 173, 15, 95, 141, 237, 180, 216, 208, 79, 133, 63, 150]), "Encryption test - 1"

# Generated at 2022-06-26 10:58:36.604250
# Unit test for function key_expansion
def test_key_expansion():
    data = b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c'

    expanded_key = key_expansion(data)

# Generated at 2022-06-26 10:58:38.554725
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    pass

# Generated at 2022-06-26 10:58:47.476248
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # key = 16-Byte key
    key = [0x00] * 16
    iv = 16 * [0x00]

    # The plaintext "Hello World!" is encrypted and the ciphertext is decrypted.
    plaintext = bytes_to_intlist(compat_b64decode('SGVsbG8gV29ybGQh'))
    ciphertext = aes_cbc_encrypt(plaintext, key, iv)
    assert ciphertext == bytes_to_intlist(compat_b64decode('pFss3Iqdz7V9pv1eJ7WuIg=='))
    assert aes_cbc_decrypt(ciphertext, key, iv) == plaintext

    # The plaintext "Hello World!" is encrypted and the ciphertext is decrypted.

# Generated at 2022-06-26 10:59:01.226944
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c'
    iv = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'

# Generated at 2022-06-26 10:59:14.474839
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    import binascii

    input = []
    output = []

    # Test case 1
    key = [0x56, 0xE4, 0x7A, 0x38, 0xC5, 0x59, 0x89, 0x74, 0xBC, 0x46, 0xFF, 0xF7, 0x5B, 0xE8, 0xF1, 0x95]
    iv = [0xE6, 0x6B, 0x56, 0xBC, 0x8B, 0x46, 0xBF, 0x4E, 0xB0, 0xBB, 0x28, 0x0E, 0xFE, 0x7C, 0x43, 0xEE]

# Generated at 2022-06-26 10:59:26.670401
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b'y2nAUflv6Udaa6UZaJjZCdDDN+x1XN/K3rqyFHJNu+o=')
    expanded_key = bytes_to_intlist(b'9c2e73b55dfe9cff3873f4e4bff3f4ad')
    iv = bytes_to_intlist(b'45f0e7c0bfbf75fdd3920e2fbdf60b0d')

# Generated at 2022-06-26 10:59:36.405308
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    bytes_0 = b'\x03\x88\xda\xce\x60\xb6\xa3\x92\xf3\x28\xc2\xb9\x71\xb2\xfe\x78'
    bytes_1 = b'\xb6\x19\x05\x56\x20\xb8\x69\x44\x3d\xb6\x0a\x98\x8b\xe7\xd7\x76'

# Generated at 2022-06-26 10:59:46.222949
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    var_0 = aes_cbc_encrypt(bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07'),
                            bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c'),
                            bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'))

# Generated at 2022-06-26 10:59:55.952839
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = b'\x6d\x6c\x6e\x6f\x6e\x6c\x6e\x6f\x6e\x6c\x6e\x6f\x6e\x6c\x6e\x6f'

# Generated at 2022-06-26 11:00:08.433815
# Unit test for function key_expansion
def test_key_expansion():
    key_1 = [0x2b, 0x28, 0xab, 0x09] * 4
    key_2 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 11:00:14.594181
# Unit test for function key_expansion
def test_key_expansion():
    key = b'YELLOW SUBMARINE'
    key_bytes = bytes_to_intlist(key, 16)
    expanded_key = key_expansion(key_bytes)
    expanded_key_bytes = intlist_to_bytes(expanded_key)

# Generated at 2022-06-26 11:00:25.506296
# Unit test for function key_expansion

# Generated at 2022-06-26 11:00:32.518904
# Unit test for function key_expansion
def test_key_expansion():
    # 16 byte key expansion
    bytes_0 = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    bytes_1 = key_expansion(bytes_0)

# Generated at 2022-06-26 11:00:42.610725
# Unit test for function key_expansion
def test_key_expansion():
    bytes_key = b'RT\x94\x17\x1f\x85\xab\x0c\x16\xe0\xae'
    key_length = len(bytes_key)
    # bytes_iv = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    # iv_length = len(bytes_iv)
    bytes_expanded_key = key_expansion(bytes_key)
    expanded_key_length = len(bytes_expanded_key)
    if key_length == 16:
        assert expanded_key_length == 176
    elif key_length == 24:
        assert expanded_key_length == 208

# Generated at 2022-06-26 11:00:49.698391
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    data_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-26 11:01:02.746605
# Unit test for function key_expansion

# Generated at 2022-06-26 11:01:14.122547
# Unit test for function key_expansion
def test_key_expansion():
    #print("Test case 0")
    #test_case_0()
    print("Test case 1")
    key_1 = bytes_to_intlist(compat_b64decode('k0jTdIH0eVmfRtKxi7/X9ztbr/I='))  # iv
    key_1 = key_expansion(key_1)
    key_1 = intlist_to_bytes(key_1)

# Generated at 2022-06-26 11:01:21.720387
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    print('begin key_expansion test case 0')
    bytes_0 = b'\x16\xe0\xae\x1c(['
    var_0 = key_schedule_core(bytes_0, 1)
    print(var_0)



# Generated at 2022-06-26 11:01:30.562414
# Unit test for function key_expansion
def test_key_expansion():
    key_expansion(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f')
    #key_expansion(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f')
    #key_expansion(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f')
    #key_expansion(b'\x00\x01\x02\x

# Generated at 2022-06-26 11:01:47.602400
# Unit test for function key_expansion
def test_key_expansion():
    bytes = b'\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'
    key = key_expansion(bytes)

# Generated at 2022-06-26 11:02:00.658766
# Unit test for function key_expansion
def test_key_expansion():
    key = b'''\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'''

# Generated at 2022-06-26 11:02:11.398077
# Unit test for function key_expansion
def test_key_expansion():
    key = b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c'
    expanded_key = key_expansion(key)

    assert(expanded_key[0:4] == [0x2b, 0x7e, 0x15, 0x16])
    assert(expanded_key[4:8] == [0xa8, 0x88, 0x09, 0xcf])
    assert(expanded_key[8:12] == [0xf3, 0x7b, 0x44, 0x9b])

# Generated at 2022-06-26 11:02:23.020064
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    bytes_0 = bytes_to_intlist('b9479c220fdffd649bbd8b7c8b6f216d')
    bytes_1 = bytes_to_intlist('ce33ae7f1d53b8c7b904863d30f7b73d')
    bytes_2 = bytes_to_intlist('901c5964b3f14a3dcae05d34e9cfa8a8')
    bytes_3 = bytes_to_intlist('b98ea1ef0ee1d2be648f67a4f3a4be4b')
    bytes_4 = bytes_to_intlist('10fa31a7f1d0b8b27c9b66a10f7b0603')
    bytes_5 = bytes_to_int