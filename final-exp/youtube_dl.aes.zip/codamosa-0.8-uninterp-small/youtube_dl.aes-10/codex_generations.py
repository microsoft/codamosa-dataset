

# Generated at 2022-06-26 10:52:43.456209
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-26 10:52:45.017650
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # TODO
    raise NotImplementedError()


# Generated at 2022-06-26 10:52:55.227996
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = [206, 233, 92, 226,  31, 217, 39, 112,  54,  35, 130, 2,  249,  90, 67, 251]

# Generated at 2022-06-26 10:53:05.648458
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    print("Testcase aes_cbc_encrypt")


# Generated at 2022-06-26 10:53:14.566706
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F]

# Generated at 2022-06-26 10:53:26.802051
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # define a counter for testing
    class TestCounter(object):
        def __init__(self):
            self.i = 0

        def next_value(self):
            block = [self.i >> j & 0xFF for j in reversed(range(0, BLOCK_SIZE_BYTES * 8, 8))]
            self.i += 1
            return block

    # Test case 0
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c];
    counter = TestCounter()

# Generated at 2022-06-26 10:53:30.640818
# Unit test for function key_expansion
def test_key_expansion():

    buf_0 = []
    buf_0.append(buf_0)

    fp_0 = open('/home/mike/pycharm-community-6.0.3/bin/a.txt', 'r')
    fp_0.write(fp_0)


# Generated at 2022-06-26 10:53:42.013879
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Initialize inputs
    data = bytes_to_intlist([59, 8, 4, 247, 120, 39, 99, 112, 0, 0, 0, 0, 0, 0, 0, 0])
    expanded_key = bytes_to_intlist([111, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    # Expected output
    expected_output = bytes_to_intlist([247, 39, 120, 8, 112, 0, 4, 0, 59, 0, 0, 0, 99, 0, 0, 0])
    # Invoke function
    output = aes_decrypt(data, expanded_key)


# Generated at 2022-06-26 10:53:55.643424
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:54:06.615723
# Unit test for function key_expansion
def test_key_expansion():
    set_0 = [0x2b, 0x28, 0xab, 0x09, 0x7e, 0xae, 0xf7, 0xcf, 0x15, 0xd2, 0x15, 0x4f, 0x16, 0xa6, 0x88]
    var_0 = key_expansion(set_0)
    var_0_solution = 'hAmpY8YQA+ZvjAYJ1EW9h9T8zPpk+vw+jA/d0n0nB+RlICFhbQQJ'
    if var_0 == var_0_solution:
        print("Result is correct")
    else:
        print("Result is wrong")
        print("Expected: ")
        print(var_0_solution)
       

# Generated at 2022-06-26 10:54:20.734541
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    var_0 = aes_decrypt_text('H8WG6QaM6cgU6rzewJxWj6h+vEgdbU+oUmPkC3qD3jaxXEGXzecnBE1l8W1fjZB6oGSLyr2lg8/q3hq/jzN9XMW0bKKi0NxjTGvhC6/36Ak=', 'test', 32)
    assert var_0 == b'Hello World'


test_aes_decrypt_text()

# Generated at 2022-06-26 10:54:30.743699
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    # Two strings containing hex list representations of the correct inputs and expected outputs
    test_input_0 = "0x000102030405060708090a0b0c0d0e0f, 14"

# Generated at 2022-06-26 10:54:34.512859
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    var_0 = aes_cbc_decrypt(NotImplementedError(), aes_cbc_decrypt, NotImplementedError())
    assert type(var_0) == list
    assert var_0 == NotImplementedError()


# Generated at 2022-06-26 10:54:43.580910
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    print("Test aes_cbc_decrypt")

    data = bytes_to_intlist("4ca00ff4c898d61e1edbf1800618fb2828a226d160dad07883d04e008")
    key = bytes_to_intlist("140b41b22a29beb4061bda66b6747e14")
    iv = bytes_to_intlist("4ca00ff4c898d61e1edbf1800618fb28")
    var_0 = aes_cbc_decrypt(data, key, iv)
    print("Expected = {0}".format("plaintext"))
    print("Received = {0}\n".format(intlist_to_bytes(var_0)))


# Generated at 2022-06-26 10:54:54.234281
# Unit test for function inc
def test_inc():
    try:
        inc([0x00, 0x00, 0x00, 0x00])
    except:
        var_0 = NotImplementedError()
    else:
        var_0 = [0x00, 0x00, 0x00, 0x01]
    assert var_0 == [0x00, 0x00, 0x00, 0x01], var_0
    try:
        inc([0x00, 0x00, 0x00, 0xFF])
    except:
        var_0 = NotImplementedError()
    else:
        var_0 = [0x00, 0x00, 0x01, 0x00]
    assert var_0 == [0x00, 0x00, 0x01, 0x00], var_0

# Generated at 2022-06-26 10:55:04.667815
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    test_cases = [
        (
            NotImplementedError(),
            NotImplementedError(),
            NotImplementedError(),
            NotImplementedError()
        ),
        (
            NotImplementedError(),
            NotImplementedError(),
            NotImplementedError(),
            NotImplementedError()
        ),
        (
            NotImplementedError(),
            NotImplementedError(),
            NotImplementedError(),
            NotImplementedError()
        ),
    ]

    for case, data, key, iv, expected in test_cases:
        actual = aes_cbc_encrypt(data=data, key=key, iv=iv, )
        assert actual == expected

    return



# Generated at 2022-06-26 10:55:05.241386
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    pass


# Generated at 2022-06-26 10:55:13.595788
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    var_0 = 'ytad6wCc2Uuwe6Y8i6rj0QLr/V7UuPv0iKy7F/6HK+w='
    var_1 = '6ea9f9f0979c7fae'
    var_2 = 'T'
    var_3 = '1YAKJWRIZ9HlZR1aFv+8lQ=='
    var_4 = '+Iy30OtAQq3Zf48MFxJzpA==\n'

    print("Input:  %s" % var_0)
    print("Output: %s" % var_1)
    print("Expect: %s" % var_2)
    print("Input:  %s" % var_3)

# Generated at 2022-06-26 10:55:17.214113
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-26 10:55:22.397858
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()


# Generated at 2022-06-26 10:55:36.879203
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6,
           0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
          0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F]

# Generated at 2022-06-26 10:55:48.230099
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'\x9e\x99\xb3\\E\x06\xd0\xcb\xcd\x89\x05W1\x9b\x85\xad\xc7\x8e')
    data = bytes_to_intlist(b'\x9e\x99\xb3\\E\x06\xd0\xcb\xcd\x89\x05W1\x9b\x85\xad\xc7\x8e')
    iv = bytes_to_intlist(b'\x9e\x99\xb3\\E\x06\xd0\xcb\xcd\x89\x05W1\x9b\x85\xad\xc7\x8e')
    encrypted_data = aes_cbc

# Generated at 2022-06-26 10:56:02.106232
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytearray([0x2b, 0x28, 0xab, 0x09, 0x7e, 0xae, 0xf7, 0xcf, 0x15, 0xd2, 0x15, 0x4f, 0x16, 0xa6, 0x88, 0x3c])
    iv = bytearray([0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f])

# Generated at 2022-06-26 10:56:09.799876
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    encrypted = aes_cbc_encrypt(list(range(16)), list(range(32)), list(range(16)))
    expected = [
        231, 116, 48, 115, 162, 145, 55, 170,
        234, 182, 156, 44, 245, 3, 27, 153
    ]

    for i in range(16):
        assert encrypted[i] == expected[i]



# Generated at 2022-06-26 10:56:18.638194
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # test case 0
    bytes_0 = b'\xde\xf0\x1d-D\xf1xz\xb7r\x1a\xf5\xf4\x8b'
    bytes_1 = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f'
    bytes_2 = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f'

# Generated at 2022-06-26 10:56:27.932398
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    cleartext = [79, 59, 12, 2, 79, 35, 8, 28, 20, 2, 3, 68, 8, 9, 68, 45]
    key = [41, 53, 3, 21, 2, 13, 8, 35, 19, 26, 2, 50, 46, 4, 14, 20, 2]
    iv = cleartext
    encrypted_data = aes_cbc_encrypt(cleartext, key, iv)
    assert(encrypted_data ==
        [41, 53, 3, 21, 62, 39, 20, 2, 79, 59, 12, 2, 79, 35, 8, 28])


# Generated at 2022-06-26 10:56:41.405052
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:56:53.630624
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    bytes_0 = b'\xde\xf0\x1d-D\xf1xz\xb7r\x1a\xf5\xf4\x8b'
    bytes_1 = b'ErRsT'
    var_0 = sub_bytes(bytes_0)
    var_1 = sub_bytes(bytes_1)

    # mixed_block = xor(block, iv)
    mixed_block = xor(var_0, var_1)
    blended_mixed_block = shift_rows(mixed_block)
    blended_mixed_block = mix_columns(blended_mixed_block)
    blended_mixed_block = xor(blended_mixed_block, var_1)

# Generated at 2022-06-26 10:57:02.024318
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    print("Unit test for function aes_cbc_encrypt")
    data = b'1234567890123456'
    key = b'1234567890123456'
    iv = b'1234567890123456'
    result = aes_cbc_encrypt(data, key, iv)
    print("aes_cbc_encrypt result: %s", result)
    return True


# Generated at 2022-06-26 10:57:14.373596
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:57:27.756764
# Unit test for function key_expansion
def test_key_expansion():
    #bytes_0 = b'\xde\xf0\x1d-D\xf1xz\xb7r\x1a\xf5\xf4\x8b'
    key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    expanded_key = key_expansion(key)

# Generated at 2022-06-26 10:57:41.383807
# Unit test for function key_expansion
def test_key_expansion():
    bytes_key = b'\x14\x15\x92\x8b\x9c\xb9\xfe\xc5\x00\xf5\xc0\xbe\x1e\x27\x61\x7c'
    var_expanded = key_expansion(bytes_key)

# Generated at 2022-06-26 10:57:51.492591
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('QUJD'))


# Generated at 2022-06-26 10:57:56.738671
# Unit test for function key_expansion
def test_key_expansion():
    # Case1
    bytes_1 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    var_1 = key_expansion(bytes_1)

# Generated at 2022-06-26 10:58:08.048112
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    var_0 = key_expansion(bytes_0)

# Generated at 2022-06-26 10:58:16.922429
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    #key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c, 0xa0, 0xfa, 0xfe, 0x17, 0x88, 0x54, 0x2c, 0xb1, 0x23, 0xa3, 0x39, 0x39, 0x2a

# Generated at 2022-06-26 10:58:25.501985
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = bytes_to_intlist(compat_b64decode('NhVJvoEkX9tWLHH5fIx5Fw=='))
    key_expansion_0 = key_expansion(key_0)
    assert len(key_expansion_0) == 208
    assert intlist_to_bytes(key_expansion_0) == compat_b64decode('NhVJvoEkX9tWLHH5fIx5Fw07XIYgN/SOoxxMx0yRiPFm6vFxs1QwL1q3ZrUHju9mY8G+A==')


# Generated at 2022-06-26 10:58:35.751486
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = b'\xCC\xCE\xB5\x2E\xEF\xD8\xC3\x61\x7F\x77\x32\xB3\x9F\x42\x49\x6B'
    var_0 = key_expansion(bytes_0)
    # var_0 shoud be the following
    # b'\xcc\xce\xb5\x2e\xef\xd8\xc3\x61\x7f\x77\x32\xb3\x9f\x42\x49\x6b\xa9\x42\x8f\x4a\x7c\xe6\x38\x8a\xbb\x5c\x5e\x5c\x59\x2a\x

# Generated at 2022-06-26 10:58:46.505964
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    bytes_0 = b'\xde\xf0\x1d-D\xf1xz\xb7r\x1a\xf5\xf4\x8b'
    key_0 = bytes_to_intlist(bytes_0)
    result_0 = key_expansion(key_0)

# Generated at 2022-06-26 10:59:00.318172
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = b'\xde\xf0\x1d-D\xf1xz\xb7r\x1a\xf5\xf4\x8b'
    sub_bytes_0 = sub_bytes(bytes_0)
    key_expansion_0 = key_expansion(sub_bytes_0)
    bytes_1 = b'\xde\xf0\x1d-D\xf1xz\xb7r\x1a\xf5\xf4\x8b'
    sub_bytes_1 = sub_bytes(bytes_1)

# Generated at 2022-06-26 10:59:16.065910
# Unit test for function key_expansion
def test_key_expansion():
    key_bytes_0 = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f' # 16-Byte key

# Generated at 2022-06-26 10:59:28.029020
# Unit test for function key_expansion
def test_key_expansion():
    hex_key = b'2b7e151628aed2a6abf7158809cf4f3c'
    int_key = bytes_to_intlist(compat_b64decode(hex_key))
    expected_expanded_key = b'2b7e151628aed2a6abf7158809cf4f3cef4359d8d580aa4f7f04ef6a267eab9ba7cba6ce9da3113b5f0b8c00a60b8875f2342d37612b5fb0b33d531e0e62ef7c64a2123f0e7b5cdfb76f1cfba9dd5b5d5f5a66c8b46f2c5'
    expanded_key = key_expansion

# Generated at 2022-06-26 10:59:39.345352
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = b'\x88\x99\xaa\xbb\xcc\xdd\xee\xff\x00\x11\x22\x33\x44\x55\x66\x77'
    var_0 = key_expansion(key_0)

# Generated at 2022-06-26 10:59:46.932262
# Unit test for function key_expansion
def test_key_expansion():
    key_bytes = intlist_to_bytes(bytes_to_intlist(compat_b64decode(b'CY9rzUYh03PK3k6DJie09g==')))
    key_intlist = bytes_to_intlist(key_bytes)
    expanded_key_intlist = key_expansion(key_intlist)
    try:
        assert len(expanded_key_intlist) == 240
        assert expanded_key_intlist[15] == 0x96
        assert expanded_key_intlist[17] == 0x3c
        assert expanded_key_intlist[20] == 0x22
    except AssertionError:
        print("key_expansion test case failed. Please report this to the developer")


# Generated at 2022-06-26 10:59:56.232354
# Unit test for function key_expansion
def test_key_expansion():
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    expanded_key = key_expansion(data)
    expected_expanded_key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
                             168, 165, 199, 228, 178, 32, 225, 38, 181, 141, 198, 130,
                             69, 158, 46, 150, 190, 219, 31, 143, 195, 100, 46, 242,
                             85, 10, 248, 252, 83, 127, 110, 143, 195, 100, 46, 242,
                             85, 10, 248, 252, 83, 127, 110]

# Generated at 2022-06-26 11:00:05.517452
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = b'\x06\xe0\x9b\x03\x1c\x0d\xc7H\xb6a\x7a\xa0\x9f\x1a\x95\xe2\x8c\xa2\x3d\xcd\x1b\x1b\x6c@\xdf\xfd\xee'
    var_0 = key_expansion(key_0)

# Generated at 2022-06-26 11:00:13.271382
# Unit test for function key_expansion
def test_key_expansion():
    key = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'
    data = key_expansion(key)

# Generated at 2022-06-26 11:00:23.804214
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = b'\xde\xf0\x1d-D\xf1xz\xb7r\x1a\xf5\xf4\x8b'
    var_0 = sub_bytes(bytes_0)
    bytes_1 = b'\xde\xf0\x1d-D\xf1xz\xb7r\x1a\xf5\xf4\x8b'
    var_1 = sub_bytes(bytes_1)
    bytes_2 = b'\xde\xf0\x1d-D\xf1xz\xb7r\x1a\xf5\xf4\x8b'
    var_2 = sub_bytes(bytes_2)

# Generated at 2022-06-26 11:00:31.717041
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')
    var_0 = key_expansion(bytes_0)

# Generated at 2022-06-26 11:00:41.614083
# Unit test for function key_expansion

# Generated at 2022-06-26 11:00:53.601785
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = b'\x14\x0e\x89\x5d\xe5\x01\x99\x85\x9d\x96\x1f\x84\x89\x5d\xe5\x01'
    var_0 = key_expansion(bytes_0)


# Generated at 2022-06-26 11:00:59.866129
# Unit test for function key_expansion
def test_key_expansion():
    #key_expansion(intlist_to_bytes(bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c'), 'hex'))
    key_expansion(intlist_to_bytes(bytes_to_intlist('000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f'), 'hex'))


# Generated at 2022-06-26 11:01:11.980010
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\xa0M\x03\x1a\x1e\x01\r\x13\x01\x0e\x07\x1c5]\x80\xc2\xd0')

# Generated at 2022-06-26 11:01:20.010491
# Unit test for function key_expansion
def test_key_expansion():
    # Test vector #1
    key1 = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')

# Generated at 2022-06-26 11:01:29.766456
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = b'\xd5\x9b\x90\x0f\xe2f\xb1\xb2\xaa\x1c\x9a\x9d\x94\x92\x8ct\x98'
    var_0 = key_expansion(bytes_0)

# Generated at 2022-06-26 11:01:42.357907
# Unit test for function key_expansion
def test_key_expansion():
    
    # Case 0
    bytes_0 = bytes_to_intlist(b'\x16\x80\x84\x1d\x16\x81\x85\x1d\x16\x82\x86\x1d\x16\x83\x87\x1d')
    bytes_0 = key_expansion(bytes_0)
    bytes_0 = intlist_to_bytes(bytes_0)
    bytes_0 = compat_b64decode(bytes_0)


# Generated at 2022-06-26 11:01:54.102242
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = b'\x8e\x73\xb0\xf7\xda\x0e\x64\x52\xc8\x10\xf3\x2b\x80\x90\x79\xe5\x62\xf8\xea\xd2\x52\x2c\x6b\x7b'
    key_expansion_0 = key_expansion(bytes_0)

# Generated at 2022-06-26 11:01:59.347119
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = b'\xae\x68\x52\xf8\x12\xa2\x44\x7b\xe6\xd1\x3a\x4f\x4e\x9a\x9f\xf3'
    var_0 = key_expansion(bytes_0)
    len_0 = len(var_0)



# Generated at 2022-06-26 11:02:10.902238
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    bytes_0 = b'\x0f\x15\x71\xc9\x47\xd9\xe8\x59\x0c\xb7\xad\xd6\xaf\x7f\x67\x98\x0f\x15\x71\xc9\x47\xd9\xe8\x59'

# Generated at 2022-06-26 11:02:22.371713
# Unit test for function key_expansion