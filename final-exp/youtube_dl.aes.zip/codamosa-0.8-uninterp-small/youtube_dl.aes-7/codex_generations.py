

# Generated at 2022-06-26 10:52:46.374945
# Unit test for function aes_encrypt
def test_aes_encrypt():
    print("[INFO] Running aes_encrypt unit test...")

    # Test Data Set 1
    data = [0x19, 0x3d, 0xe3, 0xbe, 0xa0, 0xf4, 0xe2, 0x2b, 0x9a, 0xc6, 0x8d, 0x2a, 0xe9, 0xf8, 0x48, 0x08]

# Generated at 2022-06-26 10:52:54.474889
# Unit test for function inc
def test_inc():
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 255, 128]
    data2 = data + [0]
    data3 = data + [1]
    data4 = data + [254]

    for i in range(len(data)):
        assert data2[i] == data[i]
        assert data3[i] == data[i]
        assert data4[i] == data[i]

    assert inc(data) == data2
    assert inc(data2) == data3
    assert inc(data3) == data4
    assert inc(data4) == data + [255]



# Generated at 2022-06-26 10:53:00.732421
# Unit test for function key_expansion
def test_key_expansion():
    print("\nTesting function key_expansion...")
    key_expansion(None)
    assert bytes_to_intlist(key_expansion([])) == [0 for i in range(240)]
    test_case_0()
    test_case_1()
    print("\nTesting complete\n")

# @param {int[]} data         roundkey
# @param {int} rcon_iteration

# Generated at 2022-06-26 10:53:09.559279
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # encrypts [True, True, True, True, False, False, False, False]
    # key: 100110110100010100100111100110101100101011110011011110111100001
    # counter: 101010000110100111010110001110100110100101110011011000011111001
    # returns [False, False, True, False, False, False, False, True]
    # (the same result is obtained with python's Crypto.Cipher.AES)
    encrypted_data = [False, True, False, False, False, True, False, False]

# Generated at 2022-06-26 10:53:22.144291
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test case is to decrypt an empty byte array
    # using a given key and encrypted data.
    key = bytes_to_intlist(compat_b64decode('qze2nF1WaoZ8kwc45YDHgw=='))
    data = bytes_to_intlist(compat_b64decode('lJZFjYVzdtTpNSs7sEJGMQ=='))
    decrypted_data = aes_decrypt(data, key)
    assert(decrypted_data == [])
    #print(decrypted_data)
    #
    data = bytes_to_intlist(compat_b64decode('8RJGlP10S0LdHZonh8ZK+A=='))

# Generated at 2022-06-26 10:53:32.504343
# Unit test for function aes_decrypt

# Generated at 2022-06-26 10:53:39.645029
# Unit test for function key_schedule_core
def test_key_schedule_core():
    print('\n--- Unit test for key_schedule_core ---')
    input_0 = [0x01, 0x02, 0x03, 0x04]
    exp_output = [0x05, 0x06, 0x07, 0x08]
    output = key_schedule_core(input_0, 1)
    assert(output == exp_output)
    print('Test case 0: Passed')



# Generated at 2022-06-26 10:53:47.201778
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test case 0
    var_0 = [47, 172, 63, 237, 6, 66, 185, 167, 165, 250, 148, 71, 60, 196, 122, 75]
    var_1 = [203, 112, 77, 139, 192, 186, 205, 152, 47, 172, 63, 237]
    var_2 = [119, 158, 247, 4, 136, 30, 38, 55, 211, 149, 59, 37, 81, 14, 96, 9]
    expected_0 = [169, 18, 24, 13, 13, 147, 125, 37, 46, 40, 122, 252, 242, 237, 216, 83]
    expected_1 = aes_cbc_decrypt(var_0, var_1, var_2)

    # This should output 'True'.

# Generated at 2022-06-26 10:53:56.163927
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist('7L5IMOZAR1VJKXRL')
    encrypted_data = bytes_to_intlist('920223E654FD7D39')
    expected_result = bytes_to_intlist('3C29DD50C737E76E')
    expanded_key = key_expansion(key)
    result = aes_decrypt(encrypted_data, expanded_key)
    assert result == expected_result
# end test_aes_decrypt


# Generated at 2022-06-26 10:54:00.237988
# Unit test for function key_schedule_core
def test_key_schedule_core():
    global RCON

# Generated at 2022-06-26 10:54:17.629119
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    def test_counter():
        current_val = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

        def next_value():
            nonlocal current_val
            current_val[-1] += 1
            return current_val

        return next_value


# Generated at 2022-06-26 10:54:28.663915
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:54:37.025441
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # ENCRYPTION TEST VECTOR (YOUTUBE)
    iv = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
          0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    key = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
           0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
           0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    # "Hello World

# Generated at 2022-06-26 10:54:47.697948
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    ctr = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    class Counter(object):
        def __init__(self, ctr, first_value):
            self._ctr = ctr
            self._first_value = first_value

        def next_value(self):
            ctr = self._ctr
            self._ctr = xor(self._ctr, self._first_value)
            return ctr

    counter = Counter(ctr, [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0])



# Generated at 2022-06-26 10:54:54.508551
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(compat_b64decode('QPwCy5kK2tRcRtP5o+eKxX1VEEeZcLe4'))
    key = bytes_to_intlist('00000000000000000000000000000000')
    counter = AESCounter(bytes_to_intlist("00000000000000000000000000000001"))
    decrypted_data = aes_ctr_decrypt(data, key, counter)
    assert intlist_to_bytes(decrypted_data) == b'ABC'

import random


# Generated at 2022-06-26 10:55:01.697492
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key_0 = "pL";
    var_0 = key_expansion(key_0)
    cleartext = "This is a test";
    iv_0 = "This is an IVXX";
    var_1 = aes_cbc_encrypt(cleartext, var_0, iv_0)
    expected = "9Xnx6hHcAAyKjYQInfgBkJU6Dcix6Hgv"
    assert var_1 == expected


# Generated at 2022-06-26 10:55:11.083625
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    cipher = "vxO_EMgXX0oYKi_sCBQ4wq3-kTZTKGZfR8XxSxE4zm4"
    key = "2M4n3HZnC1Kj86T90aX8SfE6UanLNU72"
    counter = Counter(bytes_to_intlist(b"\x45\x8d\x6e\x2c\xe5\x98\xc5\x7a"))

# Generated at 2022-06-26 10:55:22.356267
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = "6920e299a5202a6d656e636869746f2d6865726f2d73686966742d636f6d6d756e6963617465"
    key = bytes_to_intlist(compat_b64decode(key))
    expanded_key = key_expansion(key)

    data = bytes_to_intlist(b"000102030405060708090a0b0c0d0e0f")
    cipher = aes_encrypt(data, expanded_key)

# Generated at 2022-06-26 10:55:28.505713
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Test case 0
    str_0 = "j1 mY#= '\x0c=:HI"
    var_0 = key_expansion(str_0)
    str_1 = "\\\x0b\x12\x1e\x1d\x00\n\x0e\n\x14\x15\x05\x0c\x16\x1d\x1b \x18"
    var_1 = aes_encrypt(str_1, var_0)
    assert var_1 == [78, 126, 223, 172, 217, 236, 67, 46, 194, 182, 37, 251, 15, 105, 99, 198]
    # Test case 1

# Generated at 2022-06-26 10:55:34.593018
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    password = "xxx"
    encrypted_data = "AQAIAAAACQQJAAAAgwMAAA=="
    assert aes_decrypt_text(encrypted_data, password, 16) == b'\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b'



# Generated at 2022-06-26 10:55:49.030160
# Unit test for function inc
def test_inc():
    lst = [0x19, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    assert inc(lst) == [0x1A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]

# Generated at 2022-06-26 10:56:02.213788
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    print("aes_cbc_encrypt test ... ", end="")

    cleartext = b"Crack me if you can!\x80"
    cleartext += b"\x00" * (BLOCK_SIZE_BYTES - len(cleartext) % BLOCK_SIZE_BYTES)
    key = b"YELLOW SUBMARINE"
    iv = bytes_to_intlist(key)

    data = aes_cbc_encrypt(bytes_to_intlist(cleartext), bytes_to_intlist(key), iv)
    ciphertext = intlist_to_bytes(data)
    decrypted_cleartext = intlist_to_bytes(aes_cbc_decrypt(data, bytes_to_intlist(key), iv))
    assert cleartext == decrypted_cle

# Generated at 2022-06-26 10:56:13.297382
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Plow through the test vectors in http://csrc.nist.gov/groups/STM/cavp/documents/aes/KAT_AES.zip
    # http://csrc.nist.gov/groups/STM/cavp/documents/aes/rijndaelKAT.zip
    for key_length in (16, 24, 32):
        for file_index in range(1, 199):
            with open('./testvectors/CBCMMT%03d.rsp' % file_index, 'rb') as f:
                test_data = f.read().replace(b'\r', b'')
                test_data = test_data.replace(b'\n', b'')
                test_data = test_data.replace(b'KEY = ', b'')

                test

# Generated at 2022-06-26 10:56:20.787545
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():

    str_0 = "j1 mY#= '\x0c=:HI"
    str_1 = "X3\x1f\x19\r}\x1a\x10\x0b\x06\x17\x1f\x16\x1f\x16W8\x1e\x1e"
    var_0 = key_expansion(str_0)
    str_2 = "r\x1f\x1d\x06\x0c\x13\x00\x1a\x1f8\x1e\x1e"
    var_1 = aes_cbc_encrypt(str_2, var_0, str_1)

# Generated at 2022-06-26 10:56:30.276730
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test case 0
    print("[+] Test case 0")
    str_0 = "j1 mY#= '\x0c=:HI"
    var_0 = key_expansion(str_0)

    str_1 = "2=6a&\x0fS"
    var_1 = bytes_to_intlist(bytes(str_1, "utf8"))

    str_2 = "D\rX\x7f\x03\x0f\x06\x0b\x0e$\x1c\x10\x15\x1a"
    var_2 = bytes_to_intlist(bytes(str_2, "utf8"))

    str_3 = "1\x05"

# Generated at 2022-06-26 10:56:43.481588
# Unit test for function inc
def test_inc():
    assert inc([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x01]
    assert inc([0x00, 0x00, 0x00, 0xFF]) == [0x00, 0x00, 0x01, 0x00]
    assert inc([0x00, 0x00, 0xFF, 0xFF]) == [0x00, 0x01, 0x00, 0x00]
    assert inc([0x00, 0xFF, 0xFF, 0xFF]) == [0x01, 0x00, 0x00, 0x00]
    assert inc([0xFF, 0xFF, 0xFF, 0xFF]) == [0x00, 0x00, 0x00, 0x00]


# Unit test

# Generated at 2022-06-26 10:56:55.138528
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    str_0 = "j1 mY#= '\x0c=:HI"
    var_0 = key_expansion(str_0)


# Generated at 2022-06-26 10:56:57.666350
# Unit test for function inc
def test_inc():
    data = [255, 255, 255]
    print(inc(data))
    data = [255, 255, 0]
    print(inc(data))
    data = [255, 255, 1]
    print(inc(data))


# Generated at 2022-06-26 10:57:09.454975
# Unit test for function inc
def test_inc():
    assert inc([255, 255, 255, 255]) == [0,0,0,0]
    assert inc([255, 254, 255, 255]) == [0,255,0,0]
    assert inc([254, 254, 255, 255]) == [255,255,0,0]
    assert inc([192, 168, 0, 1]) == [193, 168, 0, 1]
    assert inc([255, 1, 2, 3]) == [0, 2, 2, 3]


# Generated at 2022-06-26 10:57:20.975773
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    str_0 = "o\x1fR\x03h\x01\x14\x02\x1d\x1e\x1f|\x1b\x05\x0c\x02^"
    str_1 = "\x1a)V\x1b\x1a\x0f\x16\x1c\x04\x10\x0f\x0c\x02\x00`\x1e\x0f\x1b"

# Generated at 2022-06-26 10:57:42.319167
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'test')
    expected_value = bytes_to_intlist(b'\x54\x65\x73\x74\x46\xbc\xb2\x37\x3e\x4c\xee\xe8\x52\x6a\x6e\x6e\x6a\x6e\x6e\x6a\x6e\x6e\x6a\x6e\x6e')
    calculated_value = key_expansion(key)

    assert expected_value == calculated_value


# Generated at 2022-06-26 10:57:52.070404
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = "j1 mY#= '\x0c=:HI"

# Generated at 2022-06-26 10:58:02.517490
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = "j1 mY#= '\x0c=:HI"
    var_1 = bytes_to_intlist(b'\x99\xf5\x0c\x7e\x12\xae\xfa\xe5\x7f\x6e\x6d\xa6\x1e\x9f\x2e\xdc')
    var_2 = key_expansion(str_0)
    var_3 = var_1 == var_2
    str_1 = "Pass" if var_3 else "Fail"
    assert var_3 == True
    print("Test 1 in test_key_expansion: ", str_1)


# Generated at 2022-06-26 10:58:12.284041
# Unit test for function key_expansion

# Generated at 2022-06-26 10:58:13.772245
# Unit test for function key_expansion
def test_key_expansion():
    print('Executing test_key_expansion...')
    test_case_0()


# Generated at 2022-06-26 10:58:16.144683
# Unit test for function key_expansion
def test_key_expansion():
    for param_0 in ("j1 mY#= '\x0c=:HI",):
        # Iteration: 0
        test_case_0()


# Generated at 2022-06-26 10:58:25.663696
# Unit test for function key_expansion
def test_key_expansion():
    print ("Function key_expansion")

    expanded = key_expansion(b'Sixteen byte key')
    assert expanded == bytes_to_intlist(b'Sixteen byte key\x90\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x90\x02\x00\x00')
    expanded = key_expansion(b'Twenty four byte key')

# Generated at 2022-06-26 10:58:35.873499
# Unit test for function key_expansion
def test_key_expansion():
    initial_value = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 10:58:39.845258
# Unit test for function key_expansion
def test_key_expansion():
    try:
        test_case_0()
    except:
        print(" key_expansion  Failed")
    else:
        print(" key_expansion  Passed")



# Generated at 2022-06-26 10:58:40.974502
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()
# End of unit test for function key_expansion



# Generated at 2022-06-26 10:58:57.178629
# Unit test for function key_expansion
def test_key_expansion():

    # Verify first 7 bytes of output matches the expected value
    assert key_expansion(bytes_to_intlist("abcdefghijklmnopqrstuvwxyz012345"))[:7] == [0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67]


# Generated at 2022-06-26 10:59:05.237650
# Unit test for function key_expansion
def test_key_expansion():
    # Arrange
    test_cases = []


# Generated at 2022-06-26 10:59:07.864404
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()


# Generated at 2022-06-26 10:59:17.215431
# Unit test for function key_expansion

# Generated at 2022-06-26 10:59:28.498743
# Unit test for function key_expansion

# Generated at 2022-06-26 10:59:30.501121
# Unit test for function key_expansion
def test_key_expansion():
    print('Unit test for function key_expansion')
    test_case_0()
    print('Test finished!')



# Generated at 2022-06-26 10:59:42.076941
# Unit test for function key_expansion
def test_key_expansion():
    #Test 0
    str_0 = "j1 mY#= '\x0c=:HI"
    var_0 = key_expansion(str_0)
    assert var_0 == 'j1 mY#= \'\x0c=:HIP`Y\xc0\xa8\xfe\xf7\x11\x1dFU\x8a\x12\xe9\xdb'
    #Test 1
    str_1 = 'z\x97\xf7\x1b\x9c\x94\xe0\x02\x1a\xfa\\\x87\xaf\x00\xf6'
    var_0_1 = key_expansion(str_1)

# Generated at 2022-06-26 10:59:42.746292
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()


# Generated at 2022-06-26 10:59:43.308265
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()

 

# Generated at 2022-06-26 10:59:44.360598
# Unit test for function key_expansion
def test_key_expansion():
    # gives expected value
    test_case_0()


# Generated at 2022-06-26 11:00:14.840067
# Unit test for function key_expansion
def test_key_expansion():
    # Value from test case 0
    str_0 = "j1 mY#= '\x0c=:HI"
    var_0 = key_expansion(str_0)
    assert len(var_0) == 176

    # Value from test case 1
    str_0 = '\x9c\x1b\xbd \xc3\x0c\xe5\x1bF\xb5\xbfG\xd4\x9f\xe2\xb2\xbc\x97\xfe'
    var_0 = key_expansion(str_0)
    assert len(var_0) == 176

# Generated at 2022-06-26 11:00:15.768267
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()
    return True


# Generated at 2022-06-26 11:00:26.670157
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist("j1 mY#= '\x0c=:HI")
    expanded_key = bytes_to_intlist("j1 mY#= '\x0c=:HI" + "\x00" * 17 * 16)
    assert key_expansion(key) == expanded_key

    key = bytes_to_intlist("8W\x19\x1b\x1e\x12'W\x13\x19\x0cA\x1a")
    expanded_key = bytes_to_intlist("8W\x19\x1b\x1e\x12'W\x13\x19\x0cA\x1a" + "\x00" * 12 * 16)
    assert key_expansion(key) == expanded_key

    key = bytes_

# Generated at 2022-06-26 11:00:28.689789
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()



# Generated at 2022-06-26 11:00:29.899210
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()



# Generated at 2022-06-26 11:00:38.425237
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = "j1 mY#= '\x0c=:HI"
    str_1 = "j1 mY#= '\x0c=:HI"
    str_2 = "j1 mY#= '\x0c=:HI"
    str_3 = "j1 mY#= '\x0c=:HI"
    str_4 = "j1 mY#= '\x0c=:HI"
    str_5 = "j1 mY#= '\x0c=:HI"
    str_6 = "j1 mY#= '\x0c=:HI"
    str_7 = "j1 mY#= '\x0c=:HI"
    str_8 = "j1 mY#= '\x0c=:HI"
   

# Generated at 2022-06-26 11:00:47.937223
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = "q5d_p*vX\\Y\xc3\xde\xca\x92"
    result_0 = key_expansion(key_0)

# Generated at 2022-06-26 11:01:01.180421
# Unit test for function key_expansion
def test_key_expansion():
    list = "j1 mY#= '\x0c=:HI"
    result = key_expansion(list)

# Generated at 2022-06-26 11:01:02.211986
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()



# Generated at 2022-06-26 11:01:03.110590
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()


# Generated at 2022-06-26 11:01:59.580360
# Unit test for function key_expansion
def test_key_expansion():
    # Case 0
    str_0 = "j1 mY#= '\x0c=:HI"
    var_0 = key_expansion(str_0)

    # Case 1
    str_1 = "j1 mY#= '\x0c:HI"
    var_1 = key_expansion(str_1)

    # Case 2
    str_2 = "j1 mY#= '\x0c"
    var_2 = key_expansion(str_2)

    # Case 3
    str_3 = "j1 mY#= '"
    var_3 = key_expansion(str_3)



# Generated at 2022-06-26 11:02:11.064548
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    key = b"j1 mY#= '\x0c=:HI"

# Generated at 2022-06-26 11:02:22.608084
# Unit test for function key_expansion
def test_key_expansion():
    # test case 0
    str_0 = "j1 mY#= '\x0c=:HI"
    var_0 = key_expansion(str_0)
    def test_0(var_0):
        assert(var_0[8] == 100)
    test_0(var_0)

    # test case 1
    str_0 = "rXB7=i!#jKV7)"
    var_0 = key_expansion(str_0)
    def test_1(var_0):
        assert(var_0[104] == 122)
    test_1(var_0)

    # test case 2
    str_0 = "g3q$M"
    var_0 = key_expansion(str_0)