

# Generated at 2022-06-26 10:52:44.754611
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    b64_key = "1_lxJiHDl0Aj8KyvPoSoEQ"
    b64_iv = "U2f3j5c6lzS6S5eZ-Rpjog"
    b64_text = "jMxW9XvNyJHPrp6Dht8nNw"
    b64_expected_result = "n0uAJ9Dl7lJjQsjVR7Iu0w"

    key = bytes_to_intlist(compat_b64decode(b64_key))
    iv = bytes_to_intlist(compat_b64decode(b64_iv))
    text = bytes_to_intlist(compat_b64decode(b64_text))
    encrypted_data = aes_c

# Generated at 2022-06-26 10:52:55.140742
# Unit test for function key_expansion
def test_key_expansion():
    ints = bytes_to_intlist(b'\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff\x00')
    expanded_ints = key_expansion(ints)

# Generated at 2022-06-26 10:53:05.564688
# Unit test for function aes_encrypt
def test_aes_encrypt():
    test0 = aes_encrypt([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16], [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36]) == [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5]

# Generated at 2022-06-26 10:53:07.318528
# Unit test for function inc
def test_inc():
    i = inc([1, 2, 3])
    assert i == [1, 2, 4]
    i = inc([2, 2, 255])
    assert i == [2, 3, 0]
    i = inc([])
    assert i == []


# Generated at 2022-06-26 10:53:19.037734
# Unit test for function key_expansion
def test_key_expansion():
    int_0 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    output = key_expansion(int_0)
    assert output[0] == 109
    assert output[31] == 238
    print('Test case with input 0 succeeded')
    int_1 = [-32,0,0,0,-64,0,0,0,0,0,0,0,0,0,0,0]
    output = key_expansion(int_1)
    assert output[0] == -24
    assert output[31] == -111
    print('Test case with input 1 succeeded')

# Generated at 2022-06-26 10:53:24.111711
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert key_schedule_core([0x4d, 0xfb, 0x21, 0x2f], 1) == [0x5b, 0x59, 0xb0, 0xdf]
    assert key_schedule_core([0x6d, 0x49, 0xa8, 0x1b], 2) == [0xed, 0x72, 0xc9, 0x9f]
    assert key_schedule_core([0x6d, 0x5a, 0xc2, 0x0a], 3) == [0x8f, 0x6d, 0x5e, 0x27]


# Generated at 2022-06-26 10:53:33.582104
# Unit test for function key_expansion
def test_key_expansion():
    print("Testing AES Key Expansion...")


# Generated at 2022-06-26 10:53:39.472785
# Unit test for function key_expansion
def test_key_expansion():
    data_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    var_0 = key_expansion(data_0)

# Generated at 2022-06-26 10:53:53.020384
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(compat_b64decode('QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F'))
    key = bytes_to_intlist(compat_b64decode('hLbOtPZF0voT7T1jcQXOzA=='))
    counter = Counter()
    decrypted_data = aes_ctr_decrypt(data, key, counter)
    assert intlist_to_bytes(decrypted_data) == 'CRYPTO IS FUN!'

if __name__ == '__main__':
    test_case_0()
    test_aes_ctr_decrypt()

# Generated at 2022-06-26 10:54:04.731149
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist("09cf4f3c -62fb -40d9 -b1fb -2f1b -d853 -0e86 -53f1")
    iv = bytes_to_intlist("cf5f -a184 -52eb -40ae -5f06 -4351 -9050 -b4b2")

# Generated at 2022-06-26 10:54:23.080430
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Set up test data

    # Initialization vector
    var_iv = [199, 241, 199, 51, 0, 219, 177, 253, 37, 194, 81, 195, 242, 101, 64, 72]

    # Key in cleartext
    var_key_cleartext = [101, 118, 101, 114, 117, 110, 105, 102, 111, 114, 109, 97, 116, 101, 100]

    # Key in bytes, which will be converted to ints
    var_key_raw = b64decode("R2OjK0Z4CQW8zcDsLiyJbw==")
    var_key_ints = bytes_to_intlist(var_key_raw)

    # Plaintext in cleartext

# Generated at 2022-06-26 10:54:33.576121
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:54:42.116929
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test case 0
    # First test
    int_0 = -3301
    var_0 = sub_bytes_inv(int_0)
    int_1 = int_0
    int_2 = -3301
    var_1 = shift_rows_inv(int_2)
    int_3 = var_1
    if not var_0 == var_1:
        print('Test failed')
        return

    # Second test
    byte_0 = bytes([93, -13, -31, -35, -20, -36, 5, -124, -12, -124, 38, -127, -13, -17, -4, -6])

# Generated at 2022-06-26 10:54:52.259117
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    print("abc")
    key = "YELLOW SUBMARINE"
    iv = [0] * 16
    message = "hello world!"

    encrypted_msg = aes_cbc_encrypt(bytes_to_intlist(bytearray(message, "utf-8")), bytes_to_intlist(bytearray(key, "utf-8")), iv)
    decrypted_msg = aes_cbc_decrypt(encrypted_msg, bytes_to_intlist(bytearray(key, "utf-8")), iv)
    decrypted_msg = intlist_to_bytes(decrypted_msg).decode("utf-8").strip("\x04")

    assert (message == decrypted_msg)



# Generated at 2022-06-26 10:55:02.905680
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    iv = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    key = bytes_to_intlist(b'000102030405060708090a0b0c0d0e0f')
    iv = bytes_to_intlist(b'f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5')
    data = bytes_to

# Generated at 2022-06-26 10:55:11.928255
# Unit test for function aes_decrypt
def test_aes_decrypt():
    print("[+] Running unit test for aes_decrypt...")

    #key = [
    #    0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c
    #]
    key = [
        0x2b, 0x28, 0xab, 0x09, 0x7e, 0xae, 0xf7, 0xcf, 0x15, 0xd2, 0x15, 0x4f, 0x16, 0xa6, 0x88, 0x3c
    ]

    # data = [
    #     0x32, 0x43, 0xf6, 0xa

# Generated at 2022-06-26 10:55:22.970659
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    def test_aes_decrypt_text_inner(expected_str, password_str, data_str, key_size_bytes):
        data_str = compat_b64decode(data_str + '=' * (-len(data_str) % 4))
        password_str = password_str.encode('utf-8')
        print('test_aes_decrypt_text_inner')
        print(expected_str, password_str, data_str, key_size_bytes)

        # plaintext = expected_str.encode('utf-8')
        plaintext = aes_decrypt_text(data_str, password_str, key_size_bytes)
        print(plaintext)
        assert plaintext == expected_str.encode('utf-8'), plaintext[:200]

    test_aes_dec

# Generated at 2022-06-26 10:55:35.043454
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:55:39.167045
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    encrypted_string = "Z9mS9Lh2Wm1Tf90MIsmvx91EwW8eZ0jzZQxbAdLKS9CbuW8HJjt0ywwM1v4x4MJs"
    password = 'jZz4vS9DdQ8-UtYT'

    decrypted_data = aes_decrypt_text(encrypted_string, password, 16)
    assert decrypted_data == '687A3045'

if __name__ == '__main__':
    test_case_0()
    test_aes_decrypt_text()

# Generated at 2022-06-26 10:55:49.216004
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:56:03.779005
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F')

# Generated at 2022-06-26 10:56:14.743087
# Unit test for function key_expansion

# Generated at 2022-06-26 10:56:26.574125
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('+M5Kj7hW4q8Yc7Vb5+E6Iw=='))

# Generated at 2022-06-26 10:56:38.492970
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2d, 0x22, 0x88, 0x3c, 0x53, 0xc2, 0xa8, 0x5f, 0x93, 0x2f, 0xb7, 0x52, 0x93, 0x71, 0x3b, 0x3d]
    expanded_key = key_expansion(key)

# Generated at 2022-06-26 10:56:52.765538
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 10:57:04.496094
# Unit test for function key_expansion
def test_key_expansion():
    def get_test_key(key_size_bytes):
        test_key = [0] * key_size_bytes
        for i in range(len(test_key)):
            test_key[i] = i % 256
        return test_key

    key_sizes = [16, 24, 32]
    for key_size_bytes in key_sizes:
        test_key = get_test_key(key_size_bytes)
        expanded_key = key_expansion(test_key)
        expected_expanded_key = bytes_to_intlist(compat_b64decode(EXPECTED_KEY_EXPANSIONS[key_size_bytes]))

# Generated at 2022-06-26 10:57:15.923264
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 1
    data_in_bytes = bytes_to_intlist('helloworld')

# Generated at 2022-06-26 10:57:18.277405
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    int_0 = -3301
    int_1 = key_expansion(int_0)
    assert int_1 == -3302


# Generated at 2022-06-26 10:57:28.319010
# Unit test for function key_expansion
def test_key_expansion():
    # 16-Byte cipher key
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 10:57:29.732446
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()



# Generated at 2022-06-26 10:57:44.991493
# Unit test for function key_expansion
def test_key_expansion():
    print("Unit test for function key_expansion.")
    key_str = "f7ce0b1387f11b9e3e66c07532a5736a"

    # Convert key_str to int[]
    key = []
    for i in range(0, len(key_str), 2):
        key.append(int(key_str[i:i + 2], 16))
    print("key) " + "       " + " ".join(["%02x" % (k) for k in key]))
    data_expanded = key_expansion(key)
    print("key_expanded) " + " ".join(["%02x" % (k) for k in data_expanded]))
    assert(len(data_expanded) == 32)
    print()



# Generated at 2022-06-26 10:57:53.774209
# Unit test for function key_expansion
def test_key_expansion():
    test_input_0 = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F]


# Generated at 2022-06-26 10:58:03.615260
# Unit test for function key_expansion
def test_key_expansion():
    var_0 = bytes_to_intlist(b'YELLOW SUBMARINE')
    var_1 = key_expansion(var_0)
    var_2 = intlist_to_bytes(var_1)
    var_0_2 = b'YELLOW SUBMARINE'
    print('var_2 is ', var_2)
    print('var_0_2 type is ', type(var_0_2))
    print('var_2 type is ', type(var_2))
    print('var_2 == var_0_2 is ', var_2 == var_0_2)
    print('var_2 == b\'YELLOW SUBMARINE\' is ', var_2 == b'YELLOW SUBMARINE')


# Generated at 2022-06-26 10:58:13.343005
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'Sixteen byte key')


# Generated at 2022-06-26 10:58:22.278975
# Unit test for function key_expansion
def test_key_expansion():
    int_list = [0x0f, 0x15, 0x71, 0xc9, 0x47, 0xd9, 0xe8, 0x59, 0x0c, 0xb7, 0xad, 0xd6, 0xaf, 0x7f, 0x67, 0x98]
    expanded_key = key_expansion(int_list)
    assert(len(expanded_key) == 176)

    int_list = [0x0f, 0x15, 0x71, 0xc9, 0x47, 0xd9, 0xe8, 0x59]
    expanded_key = key_expansion(int_list)
    assert(len(expanded_key) == 176)


# Generated at 2022-06-26 10:58:33.566938
# Unit test for function key_expansion
def test_key_expansion():
    print("Running Key Expansion Tests")
    print()
    # 16 byte key
    key = [
        0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c,
    ]

# Generated at 2022-06-26 10:58:38.902305
# Unit test for function key_expansion
def test_key_expansion():
    key = intlist_to_bytes([219, 19, 77, 55, 118, 233, 223, 22, 89, 240, 175, 104, 18, 69, 33, 158])
    expandedkey = key_expansion(key)
    expected_plaintext = intlist_to_bytes([116, 94, 108, 99, 32, 105, 115, 32, 116, 101, 115, 116, 32, 114, 101, 115, 117, 108, 116])
    encryptedtext = aes_encrypt(expected_plaintext, expandedkey)
    decryptedtext = aes_decrypt(encryptedtext, expandedkey)
    assert expected_plaintext == decryptedtext


# Generated at 2022-06-26 10:58:42.972272
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()

# Generated at 2022-06-26 10:58:57.258311
# Unit test for function key_expansion
def test_key_expansion():
    # test case 1
    print("Test case 1:")
    data = bytes_to_intlist("000102030405060708090a0b0c0d0e0f")
    print("Test data       :" + intlist_to_bytes(data).hex())
    print("Test result     :" + intlist_to_bytes(key_expansion(data)).hex())
    print("Correct result  :000102030405060708090a0b0c0d0e0f10111213141516175846f2f95c43f4d7737e5e5bb1196633bea454ca7ee8bccc42baa29cb23cb96e500727531f83912f9af1743a3")

# Generated at 2022-06-26 10:58:58.128864
# Unit test for function key_expansion
def test_key_expansion():
    test_key_expansion_0()


# Generated at 2022-06-26 10:59:13.933342
# Unit test for function key_expansion
def test_key_expansion():
    data = aes_cbc_encrypt([1]*16, [1]*16, [0]*16)
    expanded_key = key_expansion([1]*16)
    assert len(expanded_key) == 176, 'expected 176 bytes of expanded key'
    assert bytes_to_intlist(compat_b64decode('JhFLHxzDJBbGgXfY64yqJA==')) == data, 'data does not match expected value'

# Generated at 2022-06-26 10:59:26.265724
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')
    var_0 = key_expansion(key_0)
    assert(compat_b64decode('LxU6I0l2Q0lwYTNdRVl+FmkmWVBTXFZ5cEp2Q0l2Q0lwYTMdUU1w') == intlist_to_bytes(var_0))
    key_1 = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c762e7160')
    var_1 = key_expansion(key_1)

# Generated at 2022-06-26 10:59:36.052581
# Unit test for function key_expansion
def test_key_expansion():
    data = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 10:59:45.926014
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    int_0 = 221
    int_1 = -3301
    int_2 = -8747
    int_3 = -3301
    key_expansion_ret = key_expansion([int_0, int_1, int_2, int_3])

# Generated at 2022-06-26 10:59:55.951146
# Unit test for function key_expansion
def test_key_expansion():

    # Given
    key = [0x5A, 0x6E, 0x04, 0x57, 0x08, 0xFB, 0x71, 0x96 , 0xF9, 0xBF, 0x7C, 0x6E, 0xF0, 0x0B, 0x79, 0x8E, 0x0A, 0xD3, 0x19, 0xA0, 0x3A, 0xE3, 0xB0, 0xC7, 0x52, 0x41, 0x1A, 0x1D, 0xED, 0x98, 0xC7, 0xA6]

# Generated at 2022-06-26 11:00:05.207327
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(bytes(b'\x00\x04\x08\x0c\x01\x05\x09\x0d\x02\x06\x0a\x0e\x03\x07\x0b\x0f'))
    data_expanded = key_expansion(data)

# Generated at 2022-06-26 11:00:07.722654
# Unit test for function key_expansion
def test_key_expansion():
    key_expansion([0]*16)
    key_expansion([0]*24)
    key_expansion([0]*32)


# Generated at 2022-06-26 11:00:14.211814
# Unit test for function key_expansion
def test_key_expansion():
    var_0 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    var_1 = key_expansion(var_0)
    assert len(var_1) == 240
    assert var_1[0] == 0x2b
    assert var_1[15] == 0x3c
    assert var_1[240-16] == 0x9f
    assert var_1[240-1] == 0x3a
    assert var_1[16] == 0xa0
    assert var_1[239] == 0xba


# Generated at 2022-06-26 11:00:25.153390
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    int_0 = 13
    key_0 = bytes_to_intlist(compat_b64decode('D0be/03zY9F3ZJ3nq3w=='))
    var_0 = key_expansion(key_0)

# Generated at 2022-06-26 11:00:25.446098
# Unit test for function key_expansion
def test_key_expansion():
    pass


# Generated at 2022-06-26 11:00:32.491950
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(compat_b64decode('aWFkZG9uLmNvbTphYmNkZWZnaGlqa2xtbm9wcXJzdA=='))
    data = intlist_to_bytes(key_expansion(data))
    assert compat_b64decode('SWhSbVFQaDlGZlBLOFRmSWl4NGRORENyRXp0MmRCLzNtdzBISmZ3Y3ZJ') == data



# Generated at 2022-06-26 11:00:42.574174
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    # Test vector:
    # key_size_bytes = 16
    key_size_bytes = 16
    data = 0x2B7E1516, 0x28AED2A6, 0xABF71588, 0x09CF4F3C
    # Expected output:
    expected_data = 0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x9, 0xCF, 0x4F, 0x3C, 0xA0, 0xFA, 0xFE, 0x17, 0x88, 0x54, 0x2C, 0xB1, 0x23, 0xA3, 0x39

# Generated at 2022-06-26 11:00:45.593415
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 1
    test_case_1()
    # Test case 2
    test_case_2()
    # Test case 3
    test_case_3()
    # Test case 4
    test_case_4()


# Generated at 2022-06-26 11:00:54.939416
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(compat_b64decode(b'KjWENl8DvZ9SfjhC1IXpeQ=='))
    key_size_bytes = len(data)
    expanded_key_size_bytes = (key_size_bytes // 4 + 7) * BLOCK_SIZE_BYTES
    data = key_expansion(data)
    assert len(data) == expanded_key_size_bytes


# Generated at 2022-06-26 11:01:06.926918
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x54, 0x68, 0x61, 0x74, 0x73, 0x20, 0x6D, 0x79, 0x20, 0x4B, 0x75, 0x6E, 0x67, 0x20, 0x46, 0x75]

# Generated at 2022-06-26 11:01:15.750660
# Unit test for function key_expansion
def test_key_expansion():
    test_data = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f'

# Generated at 2022-06-26 11:01:23.561137
# Unit test for function key_expansion
def test_key_expansion():
    #16-Byte cipher key
    key = [82, 83, 65, 49, 0, 4, -27, -128, 52, 126, -52, 125, -103, 97, -88, -19]

# Generated at 2022-06-26 11:01:31.068359
# Unit test for function key_expansion
def test_key_expansion():
    # key expansion
    # input key
    data = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
            0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]
    data = bytes_to_intlist(data)
    # call key expansion

# Generated at 2022-06-26 11:01:43.603452
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    key_0 = intlist_to_bytes([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c])
    expanded_key_0 = key_expansion(key_0)

# Generated at 2022-06-26 11:01:56.270054
# Unit test for function key_expansion
def test_key_expansion():
    test_0 = bytes_to_intlist(compat_b64decode(b'g3u1QQhX7VuOyTaOPD7Vuw=='))
    test_1 = bytes_to_intlist(compat_b64decode(b'g3u1QQhX7VuOyTaOPD7Vt4HAEo/9XgIWKx8HNOi3Nw=='))

# Generated at 2022-06-26 11:02:11.402068
# Unit test for function key_expansion
def test_key_expansion():
    int_list_0 = [255, 255, 255, 230]
    expanded_key_0 = key_expansion(int_list_0)

# Generated at 2022-06-26 11:02:23.020594
# Unit test for function key_expansion
def test_key_expansion():
    keyHex = "2b7e151628aed2a6abf7158809cf4f3c"
    expected = "2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da56a784d9045190cfef324e7738926cfbe19391f6e1b04a9e3a0f8df8c19a54f62dc2f6bf114750a8665d"
    expected_blocks = [expected[i:i+32] for i in range(0, len(expected), 32)]