

# Generated at 2022-06-26 10:52:44.759919
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = [0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xaa,0xbb,0xcc,0xdd,0xee,0xff]
    data += [0] * (BLOCK_SIZE_BYTES - len(data))
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-26 10:52:52.046330
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text("8aiIjkUB0aHu7ZiPQ4u8dV4B4CMuBjoC", "Sebastian", 16) == b"Sebastian"
    assert aes_decrypt_text("RlX7IPy28S1uCzpIo89bZ3qBZ6NkxvnN", "Sebastian", 24) == b"Sebastian"


# Generated at 2022-06-26 10:53:03.827757
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytearray(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    key = bytearray(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    iv = bytearray(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

    # expected: by

# Generated at 2022-06-26 10:53:11.332077
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = key_expansion(dict_0)

    val_0 = var_0[-4:]
    val_0 = key_schedule_core(val_0, rcon_iteration_0)
    rcon_iteration_0 += 1
    var_0 += xor(val_0, var_0[-key_size_bytes_0: 4 - key_size_bytes_0])

    for i in range(3):
        val_1 = var_0[-4:]
        var_0 += xor(val_1, var_0[-key_size_bytes_0: 4 - key_size_bytes_0])

    if key_size_bytes_0 == 32:
        val_2 = var_0[-4:]
        val_2 = sub_bytes(val_2)
       

# Generated at 2022-06-26 10:53:22.821286
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    iv = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]

# Generated at 2022-06-26 10:53:32.914861
# Unit test for function key_expansion
def test_key_expansion():
    dict_0 = {}
    dict_0[0] = 0x2b
    dict_0[1] = 0x28
    dict_0[2] = 0xab
    dict_0[3] = 0x09
    dict_0[4] = 0x7e
    dict_0[5] = 0xae
    dict_0[6] = 0xf7
    dict_0[7] = 0xcf
    dict_0[8] = 0x15
    dict_0[9] = 0xd2
    dict_0[10] = 0x15
    dict_0[11] = 0x4f
    dict_0[12] = 0x16
    dict_0[13] = 0xa6
    dict_0[14] = 0x88
    dict_0[15] = 0

# Generated at 2022-06-26 10:53:41.562429
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    test_iv = bytes_to_intlist(compat_b64decode('BLAHBLAHBLAHBLAH='))
    test_key = bytes_to_intlist(compat_b64decode('BLAHBLAHBLAHBLAH='))
    test_data = bytes_to_intlist(compat_b64decode('BLAHBLAHBLAHBLAH='))
    test_result = intlist_to_bytes(aes_cbc_decrypt(test_data, test_key, test_iv))
    assert test_result == '', 'Test decryption empty'



# Generated at 2022-06-26 10:53:55.422647
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    with open("test_file.txt", "r") as f:
        dict_0['raw_bytes'] = f.readline()
        dict_0['raw_bytes'] = dict_0['raw_bytes'].encode('utf8')
        dict_0['raw_bytes'] = compat_b64decode(dict_0['raw_bytes'])
       

# Generated at 2022-06-26 10:54:06.511699
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist("5a5f55f6d89c32dd")
    key = bytes_to_intlist("00000000000000000000000000000000")
    counter = Counter(0)
    result = aes_ctr_decrypt(data, key, counter)
    assert intlist_to_bytes(result) == b'j\xab\xb4\xf4\xf8\x1ef\x1e\x1f'


# Main
if __name__ == '__main__':
    # unit tests
    test_case_0()
    test_aes_ctr_decrypt()

    # read parameters
    with open("7.txt", "r") as f:
        cipher_text = f.read()
    cipher_text_bytes = b64decode(cipher_text)


# Generated at 2022-06-26 10:54:18.297451
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [
        0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
        0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

    iv = [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
        0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]


# Generated at 2022-06-26 10:54:35.803693
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    var_0 = {}
    var_1 = {'aes_cbc_encrypt': aes_cbc_encrypt}


# Generated at 2022-06-26 10:54:46.441195
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    print("[+] Running test case aes_cbc_encrypt")
    var_0 = []
    var_0.append("0")
    var_0.append("1")
    var_0.append("2")
    var_0.append("3")
    var_0.append("4")
    var_0.append("5")
    var_0.append("6")
    var_0.append("7")
    var_0.append("8")
    var_0.append("9")
    var_0.append("a")
    var_0.append("b")
    var_0.append("c")
    var_0.append("d")
    var_0.append("e")
    var_0.append("f")
    var_1 = aes_cbc_encrypt

# Generated at 2022-06-26 10:54:51.286259
# Unit test for function inc
def test_inc():
    print("Test inc ")
    var_0 = [0,0,0,0,0,0,0,0]
    var_0 = inc(var_0)
    print("Expected: [0, 0, 0, 0, 0, 0, 0, 1]")
    print("Received:", var_0)

test_inc()

# Generated at 2022-06-26 10:54:56.478288
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    counter = ''
    iv = ''
    key = ''
    data = ''
    expected_output = ''
    expected_output_int_list = hex_to_int_list(expected_output)

    actual_output_int_list = aes_cbc_encrypt(hex_to_int_list(data), hex_to_int_list(key), hex_to_int_list(iv))
    assert actual_output_int_list == expected_output_int_list


# Generated at 2022-06-26 10:55:00.556358
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    var_0 = {}
    var_0 = []
    var_0 = aes_cbc_encrypt(var_0, var_0, var_0)
    assert(var_0 == {})


# Generated at 2022-06-26 10:55:05.924628
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    var_0 = aes_cbc_encrypt(bytes_to_intlist("asdfasdfasdfasdf"), bytes_to_intlist("bsdfbsdfbsdfbsdf"), bytes_to_intlist("csdfcsdfcsdfcsdf"))
    assert bytes_to_intlist("csdfcsdfcsdfcsdf") == var_0


# Generated at 2022-06-26 10:55:14.040674
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:55:18.055931
# Unit test for function inc
def test_inc():
    print(inc([0] * 16))
    print(inc([255] * 16))
    print(inc([127] * 16))
    print(inc([128] * 16))
    print(inc([200] * 16))


# Generated at 2022-06-26 10:55:26.680970
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    plaintext = bytes_to_intlist(compat_b64decode(b'6bc1bee22e409f96e93d7e117393172a'))
    key = bytes_to_intlist(compat_b64decode(b'2b7e151628aed2a6abf7158809cf4f3c'))
    iv = bytes_to_intlist(b'\x00' * 16)
    cipher = bytes_to_intlist(compat_b64decode(b'7649abac8119b246cee98e9b12e9197d'))
    assert aes_cbc_encrypt(plaintext, key, iv) == cipher


# Generated at 2022-06-26 10:55:36.918769
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    var_0 = aes_cbc_encrypt([ 9,  3,  5,  0,  4,  1,  7,  2,  9,  3,  5,  0,  4,  1,  7,  2], [18,  9, 18,  9, 37,  9, 18,  9, 18,  9, 37,  9, 18,  9, 18,  9], [17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17])
    assert (var_0 == [ 19,  14,  43,   6,  56,  30,  11,  13,  19,  14,  43,  6,  56,  30,  11,  13]), var_0

# Generated at 2022-06-26 10:55:50.730154
# Unit test for function key_expansion
def test_key_expansion():
    print("Unit test for function key_expansion")
    key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

# Generated at 2022-06-26 10:56:03.157949
# Unit test for function key_expansion
def test_key_expansion():
    print("Test key_expansion...")

    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]
    key_size_bytes2 = 16
    data2 = key_expansion(data)

# Generated at 2022-06-26 10:56:08.440249
# Unit test for function key_expansion
def test_key_expansion():
    print("test function key_expansion")

    # Test case 0
    var_0 = {}
    assert 0 == key_expansion(var_0)



# Generated at 2022-06-26 10:56:15.713926
# Unit test for function key_expansion
def test_key_expansion():
    print ('Test key_expansion')
    key_expansion([83, 111, 109, 101, 32, 98, 121, 116, 101, 32, 115, 105, 110, 99, 101, 32, 72, 101, 108, 108, 111, 32, 72, 111, 119, 32, 97, 114, 101, 32, 121, 111, 117, 63])
    # Test case 0
    try:
        print ('Test case 0')
        var_0 = {}
        key_expansion(var_0)
        print('Test case 0 passed')
    except:
        print('Test case 0 failed')


# Generated at 2022-06-26 10:56:21.985388
# Unit test for function key_expansion

# Generated at 2022-06-26 10:56:31.544396
# Unit test for function key_expansion
def test_key_expansion():
    print("Testing key_expansion")

    array_0 = []
    array_1 = []
    for i in range(0, 16):
        array_0.append( i + 1 )
        array_1.append( i + 1 + 16 )
    var_0 = key_expansion(array_0)
    var_1 = key_expansion(array_1)
    assert var_0 == var_1, "var_0 and var_1 are not equal"

    array_0 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]

# Generated at 2022-06-26 10:56:44.362932
# Unit test for function key_expansion
def test_key_expansion():
    var_0 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

# Generated at 2022-06-26 10:56:52.314382
# Unit test for function key_expansion
def test_key_expansion():
    var_0 = key_expansion(intlist_to_bytes(bytes_to_intlist('000102030405060708090A0B0C0D0E0F')))
    var_1 = intlist_to_bytes(bytes_to_intlist('000102030405060708090A0B0C0D0E0F10111213141516175846F2C295F5E9BF68'))
    assert(var_0 == var_1)



# Generated at 2022-06-26 10:56:53.462267
# Unit test for function key_expansion
def test_key_expansion():
    pass


# Generated at 2022-06-26 10:57:04.701050
# Unit test for function key_expansion
def test_key_expansion():
    key1 = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')

# Generated at 2022-06-26 10:57:14.665695
# Unit test for function key_expansion
def test_key_expansion():
    pass
    # data = bytes_to_intlist(compat_b64decode('i5I5F5QkzPkwXNIsgcCL4Q=='))
    # expected_result = bytes_to_intlist(compat_b64decode('i5I5F5QkzPkwXNIsgcCL4QAAAAAA'))
    # output = key_expansion(data)
    # print(output)
    # assert output == expected_result


# Generated at 2022-06-26 10:57:25.325808
# Unit test for function key_expansion
def test_key_expansion():
    data = [0x2b, 0x28, 0xab, 0x09, 0x7e, 0xae, 0xf7, 0xcf, 0x15, 0xd2, 0x15, 0x4f, 0x16, 0xa6, 0x88, 0x3c]
    key_size_bytes = 16
    expanded_key_size_bytes = 176


# Generated at 2022-06-26 10:57:31.216821
# Unit test for function key_expansion
def test_key_expansion():
    key_input = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-26 10:57:44.093496
# Unit test for function key_expansion
def test_key_expansion():
    input_data = [6, 124, 79, 89, 198, 168, 173, 25, 190, 67, 45, 185,
                  72, 79, 22, 9, 16, 72, 79, 22, 9, 16, 72, 79, 22, 9, 16]

# Generated at 2022-06-26 10:57:45.803757
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    test_case_0()


# Generated at 2022-06-26 10:57:54.192457
# Unit test for function key_expansion
def test_key_expansion():
    input_data = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]

# Generated at 2022-06-26 10:58:05.703980
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist([
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
        0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f
    ])

# Generated at 2022-06-26 10:58:14.704477
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)

# Generated at 2022-06-26 10:58:22.726966
# Unit test for function key_expansion
def test_key_expansion():
    data = [0xf2, 0x44, 0x81, 0x1a, 0xe8, 0x0f, 0x69, 0x28, 0x3a, 0xd0, 0x36, 0x54, 0x45, 0x50, 0x83, 0x0b]
    key = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]

    res = key_expansion(key)
    print('key_expansion(key) = ', res)
    assert(res == data)



# Generated at 2022-06-26 10:58:33.876550
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    key_size_bytes = len(key)
    expanded_key_size_bytes = (key_size_bytes // 4 + 7) * BLOCK_SIZE_BYTES
    expanded_key_size_words = expanded_key_size_bytes // 4

    expanded_key = key_expansion(key)
    test_key_size_bytes = len(expanded_key)

    if(False):
        print("\n###### Unit test for function key_expansion ######")

# Generated at 2022-06-26 10:58:49.207506
# Unit test for function key_expansion
def test_key_expansion():
    # Verify that key_expansion works with a 16-byte key
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6,
           0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]

    expanded_key = key_expansion(key)

# Generated at 2022-06-26 10:58:54.218553
# Unit test for function key_expansion
def test_key_expansion():
    testkey = [0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F]
    cipherkey = key_expansion(testkey)

# Generated at 2022-06-26 10:58:57.055689
# Unit test for function key_expansion
def test_key_expansion():
    # Test case
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()



# Generated at 2022-06-26 10:58:57.929038
# Unit test for function key_expansion
def test_key_expansion():
    test_key_expansion_0()


# Generated at 2022-06-26 10:59:05.733209
# Unit test for function key_expansion

# Generated at 2022-06-26 10:59:16.727631
# Unit test for function key_expansion

# Generated at 2022-06-26 10:59:28.291285
# Unit test for function key_expansion
def test_key_expansion():
    # Test case0. aes-128
    key0 = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]
    result0 = key_expansion(key0)

# Generated at 2022-06-26 10:59:39.620544
# Unit test for function key_expansion
def test_key_expansion():
    test_key_expansion_0()
    test_key_expansion_1()
    test_key_expansion_2()
    test_key_expansion_3()
    test_key_expansion_4()
    test_key_expansion_5()
    test_key_expansion_6()
    test_key_expansion_7()
    test_key_expansion_8()
    test_key_expansion_9()
    test_key_expansion_10()
    test_key_expansion_11()
    test_key_expansion_12()
    test_key_expansion_13()
    test_key_expansion_14()
    test_key_expansion_15()
    test_key_expansion_16()
    test_key_expansion_17()
   

# Generated at 2022-06-26 10:59:40.185327
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()


# Generated at 2022-06-26 10:59:45.596450
# Unit test for function key_expansion
def test_key_expansion():
    bool_0 = True
    var_0 = key_expansion(bool_0)
    assert var_0 == 58, 'Incorrect value of var_0'
    var_1 = key_expansion(var_0)
    assert var_1 == 209, 'Incorrect value of var_1'
    var_2 = key_expansion(var_1)
    assert var_2 == 249, 'Incorrect value of var_2'
    var_3 = key_expansion(var_2)
    assert var_3 == 229, 'Incorrect value of var_3'
    var_4 = key_expansion(var_3)
    assert var_4 == 217, 'Incorrect value of var_4'
    var_5 = key_expansion(var_4)

# Generated at 2022-06-26 11:00:07.723213
# Unit test for function key_expansion
def test_key_expansion():
    master_key = bytes_to_intlist(compat_b64decode('gqLrYj2DgI1BhRVu/fTZQQ=='))
    expanded_key = key_expansion(master_key)
    assert bytes_to_intlist(compat_b64decode('gqLrYj2DgI1BhRVu/fTZQQ+j0l/mJ5m5l5l5m5n5n5n5n5o5o5o5o5')) == expanded_key



# Generated at 2022-06-26 11:00:14.187953
# Unit test for function key_expansion
def test_key_expansion():
    key1 = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-26 11:00:25.111085
# Unit test for function key_expansion
def test_key_expansion():
    """ Test case for key_expansion"""


# Generated at 2022-06-26 11:00:32.302474
# Unit test for function key_expansion
def test_key_expansion():
    # data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    # expanded_key = key_expansion([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])

    plaintext = bytes_to_intlist("yo. i am a plaintext message")
    key = bytes_to_intlist("my_aes_key_is_very_secret")
    iv = bytes_to_intlist("an initialization ve")

    expanded_key = key_expansion(key)
    encrypted_data = aes_cbc_encrypt(plaintext, expanded_key, iv)

# Generated at 2022-06-26 11:00:42.353778
# Unit test for function key_expansion
def test_key_expansion():
    print("Unit testing for key_expansion")
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
           0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F]

# Generated at 2022-06-26 11:00:49.541522
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 11:01:02.587077
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(compat_b64decode(
        b'7Vb+TCR5y6HlVL6PuUJjzg=='))

    key = bytes_to_intlist(compat_b64decode(
        b'Ug/MRU5XcY5q3NqIMC8uQQ=='))

    expected_value = bytes_to_intlist(compat_b64decode(
        b'Ug/MRU5XcY5q3NqIMC8uQTtVb+TCRs1i4QsF8TvB+0i3OyP3wqxW8UTOAn2QRdRauhA=='))

    actual_value = key_expansion(key)


# Generated at 2022-06-26 11:01:09.739555
# Unit test for function key_expansion
def test_key_expansion():
    bool_0 = [6, 1, 6, 2, 255, 3, 1, 4, 254, 1, 2, 3, 4, 2, 3, 4]
    bool_1 = key_expansion(bool_0)
    bool_2 = 16
    bool_3 = len(bool_1)
    var_0 = (bool_2 == bool_3)
    assert var_0


# Generated at 2022-06-26 11:01:17.729182
# Unit test for function key_expansion
def test_key_expansion():
    key = [43, 126, 21, 22, 40, 174, 210, 166, 171, 247, 21, 136, 9, 207, 79, 60]

# Generated at 2022-06-26 11:01:29.170942
# Unit test for function key_expansion
def test_key_expansion():
    case_0 = [0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00]

# Generated at 2022-06-26 11:02:06.419960
# Unit test for function key_expansion

# Generated at 2022-06-26 11:02:11.549996
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    result = key_expansion(key_0)


# Generated at 2022-06-26 11:02:15.200173
# Unit test for function key_expansion
def test_key_expansion():
    array_0 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    var_0 = key_expansion(array_0)
