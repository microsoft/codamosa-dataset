

# Generated at 2022-06-26 10:52:39.836351
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = b'xyz'

    class FakeCounter:
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value += 1
            return self.value

    counter = FakeCounter(0)
    key = [0] * 16

    decrypted_data = aes_ctr_decrypt(data, key, counter)
    assert decrypted_data == data


# Generated at 2022-06-26 10:52:46.964651
# Unit test for function aes_encrypt
def test_aes_encrypt():
    plain_text = [6, 3, 209, 5, 144, 8, 210, 5, 144, 8, 210, 5, 144, 8, 210, 5]
    aes_key = [6, 3, 209, 5, 144, 8, 210, 5, 144, 8, 210, 5, 144, 8, 210, 5]
    expanded_key = key_expansion(aes_key)
    key_len = len(expanded_key)
    rounds = key_len // BLOCK_SIZE_BYTES - 1
    cipher_text = aes_encrypt(plain_text, expanded_key)
    pass_case = [249, 230, 43, 137, 70, 72, 138, 64, 119, 50, 211, 11, 165, 59, 118, 240]
    assert cipher_text == pass_case

test_a

# Generated at 2022-06-26 10:52:48.785365
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    bytes_0 = b'\xab{^\x1c*\xdd$\xc9]\xf0['
    var_0 = mix_columns_inv(bytes_0)
    print(var_0)


# Generated at 2022-06-26 10:52:54.586235
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    bytes_0 = b'\xab{^\x1c*\xdd$\xc9]\xf0['
    var_0 = mix_columns_inv(bytes_0)
    print ('Test aes_decrypt_text %s passed' % (var_0 == b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'))


# Generated at 2022-06-26 10:53:05.117416
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Test case 0
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    counter = Counter(bytes_to_intlist(b'\xF0\xF1\xF2\xF3\xF4\xF5\xF6\xF7\xF8\xF9\xFA\xFB\xFC\xFD\xFE\xFF'))

# Generated at 2022-06-26 10:53:13.553448
# Unit test for function key_expansion
def test_key_expansion():
    # Expected result from https://gist.github.com/d0n0th/ef5dc77f0ec8cab7b4c4f4a3a4b2c83d
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-26 10:53:22.143968
# Unit test for function aes_encrypt
def test_aes_encrypt():
    bytes_0 = b'\xab{^\x1c*\xdd$\xc9]\xf0['
    int_array_0 = bytes_to_intlist(bytes_0)
    output = aes_encrypt(int_array_0, key_expansion(int_array_0))
    if output == [79, 13, 17, 187, 170, 54, 111, 151, 245, 35, 159, 245, 49, 28, 0, 141]:
        print('Test passed!')
    else:
        print('Test failed!')



# Generated at 2022-06-26 10:53:32.505218
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    counter_0 = Counter()
    key_0 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]

    # Test case 0

# Generated at 2022-06-26 10:53:42.895127
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    """
    Test case from https://web.archive.org/web/20171021133604/https://csrc.nist.gov/publications/detail/sp/800-38a/final
    """
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15,
           0x88, 0x09, 0xcf, 0x4f, 0x3c]
    counter = Counter(
        [0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8, 0xf9, 0xfa, 0xfb,
         0xfc, 0xfd, 0xfe, 0xff])



# Generated at 2022-06-26 10:53:49.208307
# Unit test for function inc
def test_inc():
    assert inc(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f') == b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x10'

# Generated at 2022-06-26 10:54:01.680704
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    test_key = "3q2+796tvu/erb7v"
    test_text = "ceQyDAeVhMoBxTLLTEx8oEBYZjAwZjAwZjAxZjA0ZjA0ZjA1ZTVjNzJm"
    test_len = 16
    test_result = aes_decrypt_text(test_text, test_key, test_len)
    print(test_result)


# Generated at 2022-06-26 10:54:07.058719
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    bytes_0 = b'\xab{^\x1c*\xdd$\xc9]\xf0['
    bytes_1 = b'\xad\x15\xae\x72\x8a\x66\x5a\x7a'
    var_0 = aes_ctr_decrypt(bytes_0, bytes_1, null)

test_case_0()
test_aes_ctr_decrypt()

# Generated at 2022-06-26 10:54:18.711483
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key_0 = b'\x9f\x15\x29\xc6\xbc\x5f\x5c\x48\x8e\x9a\x24\x17\x1a\x8c\x2b\xab'
    iv_0 = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'
    data_0 = b'\x6b\xc1\xbe\xe2\x2e\x40\x9f\x96\xe9\x3d\x7e\x11\x73\x93\x17\x2a'

# Generated at 2022-06-26 10:54:29.720492
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    print("TEST: aes_ctr_decrypt")
    string = "Now is the time for all good men to come to the aide of their country."

    input = bytes_to_intlist(string)
    key = "mykeymykeymykeymyk".encode('latin-1')
    key = bytes_to_intlist(key)
    expanded_key = key_expansion(key)

    counter_init = [0x12345678, 0x9abcdef0, 0x12345678, 0x9abcdef0]
    class Counter(object):
        def __init__(self):
            self.counter = counter_init[:]
        def next_value(self):
            ret = self.counter[:4]
            self.incr_counter()
            return ret


# Generated at 2022-06-26 10:54:37.594617
# Unit test for function key_expansion
def test_key_expansion():
    cipher_key_bytes_0 = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f')
    expanded_key_bytes_0 = key_expansion(cipher_key_bytes_0)

# Generated at 2022-06-26 10:54:48.251622
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test case 0
    key_0 = bytes_to_intlist(b'\x76\x49\xab\xac\x81\x19\xb2\x46\xce\xe9\x8e\x9b\x12\xe9\x19\x7d')
    iv_0 = bytes_to_intlist(b'\xbe\x27\x67\x11\x48\x00\x6e\x3c\x01\x5b\x30\xf2\x61\x59\xd7\x41')

# Generated at 2022-06-26 10:54:57.035409
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = bytes_to_intlist(compat_b64decode(b'47WDXq3rvz8W+IK6U5C5kQ=='))

    counter = AES_CTR_Counter(b'\x00' * BLOCK_SIZE_BYTES)
    data = bytes_to_intlist(compat_b64decode(b'YlZzJwDt+1lzj1HtTJyAyo+Ixg=='))

# Generated at 2022-06-26 10:55:08.081522
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Test case 0
    """
    plaintext = 'test'
    password = 'test'
    key_size_bytes = 32
    expected_decrypted_data = 'test'
    """
    plaintext = 'test'
    password = 'test'
    key_size_bytes = 32
    expected_decrypted_data = 'test'
    test_case_0.bytes_0 = b'\xab{^\x1c*\xdd$\xc9]\xf0['
    test_case_0.var_0 = mix_columns_inv(test_case_0.bytes_0)
    decrypted_data = aes_decrypt_text(plaintext, password, key_size_bytes)
    print(decrypted_data)
    print(expected_decrypted_data)

# Generated at 2022-06-26 10:55:15.389522
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test case 0
    data_0 = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    key_0 = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-26 10:55:26.082155
# Unit test for function inc
def test_inc():
    assert inc(b'\x00\x00\x00\x00') == b'\x01\x00\x00\x00'
    assert inc(b'\xff\xff\xff\xff') == b'\x00\x00\x00\x00'
    assert inc(b'\x00\x00\x00\xff') == b'\x00\x00\x01\x00'


# input data
# b'\xA8\x93\xE1\xD9\xEE\xDE\xDB\x31\xF4\x4D\x52\xB6\xB6\x9C\x26\xBF'
# b'\x00\x00\x00\x00\x00\x00\x00\x00\x00

# Generated at 2022-06-26 10:55:35.406663
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = b'1234567890abcdef1234567890abcdef'
    iv = b'1234567890abcdef'
    data = b'12345678'
    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-26 10:55:40.327366
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:55:49.813081
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = b"Test Case 0"
    key = b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    iv = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'

    data = bytes_to_intlist(data)

# Generated at 2022-06-26 10:56:02.727625
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # test message
    key = bytes_to_intlist(str.encode('YELLOW SUBMARINE'))
    iv = bytes_to_intlist(str.encode('\x00') * 16)
    message = str.encode('the quick brown fox jumps over the lazy dog')

    # run encryption
    message_blocks = bytes_to_intlist(message)
    result = aes_cbc_encrypt(
        message_blocks,
        key,
        iv
    )

    # check result

# Generated at 2022-06-26 10:56:13.796936
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    print("test_aes_cbc_encrypt")
    # test data from https://zh.wikipedia.org/wiki/Advanced_Encryption_Standard
    # data = bytes_to_intlist(b"\x6b\xc1\xbe\xe2\x2e\x40\x9f\x96\xe9\x3d\x7e\x11\x73\x93\x17\x2a")
    # key = bytes_to_intlist(b"\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c")
    # iv = bytes_to_intlist(b"\x00\x01\x02\x03\

# Generated at 2022-06-26 10:56:16.612349
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    bytes_0 = b'\xab{^\x1c*\xdd$\xc9]\xf0['
    var_0 = aes_cbc_encrypt(bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-26 10:56:28.159050
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test case 0
    bytes_0 = bytes_to_intlist(compat_b64decode(b'OiOQS0tfdJ+frKwCKuyWAF4qFspZd4FJuu7nKpXbDr0dH+yYQ2Vf1uKjn85A7xuC'))
    key_0 = bytes_to_intlist(compat_b64decode(b'P3o4d4pZv+iqeqrWOglq3g=='))
    iv_0 = bytes_to_intlist(compat_b64decode(b'zY+h0VJ6yFLLDw5U'))
    result_0 = aes_cbc_encrypt(bytes_0, key_0, iv_0)


# Generated at 2022-06-26 10:56:38.109169
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    clear_text = b'YELLOW SUBMARINE'
    cipher_text = b'\x85\xf5\x61\x4c\x19\x73\x6b\xe6\xf7\x3f\x99\xcf\xac\x51\x8a\x18'
    iv = bytearray([0] * BLOCK_SIZE_BYTES)

    key = bytearray([0] * BLOCK_SIZE_BYTES)
    assert aes_cbc_encrypt(bytearray(clear_text), bytearray(key), bytearray(iv)) == cipher_text



# Generated at 2022-06-26 10:56:52.187804
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * 16)
    data = bytes_to_intlist(b'"TITLE: " + document.title + "\\nURL: " + window.location.href')
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    #print(encrypted_data)

# Generated at 2022-06-26 10:56:59.551299
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'thebestsecretkey!')
    iv = bytes_to_intlist(b'iviviviviviviviv')
    cleartext = bytes_to_intlist(b'Hello World!')

    expected_cipher = bytes_to_intlist(b'\x5cQ\xd2\x98\x4ba\xa7\xea\x24H\xfc\x8e\n\xa3t\x92')
    cipher = aes_cbc_encrypt(cleartext, key, iv)

    assert (cipher == expected_cipher), 'aes_cbc_encrypt function failed'

    cleartext = intlist_to_bytes(aes_cbc_decrypt(cipher, key, iv))


# Generated at 2022-06-26 10:57:07.669683
# Unit test for function inc
def test_inc():
    bytes_0 = b'\xab{^\x1c*\xdd$\xc9]\xf0['
    bytes_1 = b'\xab{^\x1c*\xdd$\xc9]\xf1['
    test_bytes = inc(bytes_0)
    assert(test_bytes == bytes_1)


# Generated at 2022-06-26 10:57:19.451954
# Unit test for function key_expansion

# Generated at 2022-06-26 10:57:28.575683
# Unit test for function inc
def test_inc():
    test_input = [0x00, 0x00, 0x00, 0x00]
    test_output = [0x01, 0x00, 0x00, 0x00]
    assert inc(test_input) == test_output
    test_input = [0x00, 0x00, 0x00, 0xff]
    test_output = [0x00, 0x00, 0x01, 0x00]
    assert inc(test_input) == test_output
    test_input = [0x00, 0x00, 0xff, 0xff]
    test_output = [0x00, 0x01, 0x00, 0x00]
    assert inc(test_input) == test_output
    test_input = [0x00, 0xff, 0xff, 0xff]

# Generated at 2022-06-26 10:57:32.643717
# Unit test for function inc
def test_inc():
    data0 = [0, 0]
    data1 = inc(data0)
    assert data1 == [0, 1]


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 10:57:40.904962
# Unit test for function key_expansion
def test_key_expansion():
    c = 0
    key = [0]*32
    assert len(key_expansion(key)) == 240
    key = [0]*24
    assert len(key_expansion(key)) == 208
    key = [0]*16
    assert len(key_expansion(key)) == 176
    key = [9]*32
    for i in key_expansion(key):
        if i != 0:
            c += 1
    assert c == 176*15



# Generated at 2022-06-26 10:57:49.929886
# Unit test for function inc
def test_inc():
    assert(inc([0, 0, 0, 0, 0, 0, 0, 0]) == [0, 0, 0, 0, 0, 0, 0, 1])
    assert(inc([1, 1, 1, 1, 1, 1, 1, 1]) == [1, 1, 1, 1, 1, 1, 1, 2])
    assert(inc([1, 2, 3, 4, 5, 6, 7, 8]) == [1, 2, 3, 4, 5, 6, 7, 9])
    assert(inc([255, 255, 255, 255, 255, 255, 255, 255]) == [0, 0, 0, 0, 0, 0, 0, 0])


# Generated at 2022-06-26 10:57:51.566722
# Unit test for function inc
def test_inc():
    data_0 = b'\xab{^\x1c*\xdd$\xc9]\xf0['
    var_0 = inc(data_0)


# Generated at 2022-06-26 10:57:56.013751
# Unit test for function inc
def test_inc():
    data = [0xFF, 0xAA, 0x00, 0xF0, 0x0F] # [255, 170, 0, 240, 15]
    dec(data)
    assert data == [0xFE, 0xA9, 0xFF, 0xEF, 0x0E] # [254, 169, 255, 239, 14]

test_inc()


# Generated at 2022-06-26 10:58:07.281118
# Unit test for function inc
def test_inc():
    assert inc(
        b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f') == b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x10'

# Generated at 2022-06-26 10:58:16.263826
# Unit test for function inc
def test_inc():
    print(inc([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]))
    print(inc([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255]))
    print(inc([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255]))
    print(inc([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255]))
    print(inc([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 255, 255]))

# Generated at 2022-06-26 10:58:29.661759
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    bytes_0 = b'\x0f\x15\x71\xc9\x47\xd9\xe8\x59\x0c\xb7\xad\xd6\xaf\x7f\x67\x98'
    var_0 = key_expansion(bytes_0)


# Generated at 2022-06-26 10:58:37.076058
# Unit test for function key_expansion
def test_key_expansion():
    import json

    json_file_name = 'aes_key_expansion.json'

    with open(json_file_name) as json_file:
        data = json.load(json_file)

    key_count = 0
    for key in data:
        key_string = key.encode('utf-8')
        key_bytes = compat_b64decode(key_string)
        key_count += 1

        expanded_key = key_expansion(key_bytes)
        expanded_key_string = intlist_to_bytes(expanded_key)

        if expanded_key_string != data[key]:
            raise RuntimeError('error')

    assert key_count == 32



# Generated at 2022-06-26 10:58:47.147682
# Unit test for function key_expansion
def test_key_expansion():
    key = b'\x60\x3d\xeb\x10\x15\xca\x71\xbe\x2b\x73\xae\xf0\x85\x7d\x77\x81\x1f\x35\x2c\x07\x3b\x61\x08\xd7\x2d\x98\x10\xa3\x09\x14\xdf\xf4'

# Generated at 2022-06-26 10:58:57.306020
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = b'P\xbf\xe5\x04\x0b\x02\x08\x5c\xaf\xb1\x9e\xf5\xca\x5e\x90\x7d\xce\x0b\x07\x9b'
    bytes_0 = bytes_to_intlist(bytes_0)
    key_expansion(bytes_0)


# Generated at 2022-06-26 10:59:05.330223
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = b'\xa2\x8c\x68\x65\x68\xc0\x6a\x8d\xa8\x6d\x6c\xc6\xc6\x84\x82\x6a\x6a\x8d\x68\x82\x84\xc0\xc6\x8d\x65\x6c\x6d'
    ret_0 = key_expansion(bytes_0)

# Generated at 2022-06-26 10:59:16.727570
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 1
    bytes_0 = b'\xfd\xe9\xbd\x9d\x95\x8d\xf1\x97\xe7\x97\x91\xfa\xdb\x9f\x61\xe8'
    var_0 = key_expansion(bytes_0)

# Generated at 2022-06-26 10:59:27.796349
# Unit test for function key_expansion
def test_key_expansion():
    # print('\nkey_expansion test')
    # print('data: 7824af08efdba1d3, key: 2b7e151628aed2a6abf7158809cf4f3c')
    key_expansion(bytes_to_intlist(b'\x78\x24\xAF\x08\xEF\xDB\xA1\xD3'))
    key_expansion(bytes_to_intlist(b'\x2B\x7E\x15\x16\x28\xAE\xD2\xA6\xAB\xF7\x15\x88\x09\xCF\x4F\x3C'))



# Generated at 2022-06-26 10:59:39.098155
# Unit test for function key_expansion
def test_key_expansion():
    test = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F'
    res = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F'
    res += b'\xD6\xAA\x74\xFD\xD2\xAF\x72\xFA\xDA\xA6\x78\xF1\xD6\xAB\x76\xFE'

# Generated at 2022-06-26 10:59:46.987020
# Unit test for function key_expansion
def test_key_expansion():
    #Test case 1
    bytes_0 = aes_encrypt(b'\x5b\x68\x71\xda\xbe\x5e\x15\x46\xf2\x45\x9a\x55\x6d\x4c\x6a\x40', key_expansion(b'\xcd\x83\xfa\x03\xfe\xfd\xb3\xab\x95\x80\xc8\x68\x2a\xf9\x93\x79'))
    assert bytes_0 == b'\x69\xc4\xe0\xd8\x6a\x7b\x04\x30\xd8\xcd\xb7\x80\x70\xb4\xc5\x5a'
    #Test case 2

# Generated at 2022-06-26 10:59:56.262240
# Unit test for function key_expansion
def test_key_expansion():
    test_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 11:00:04.764609
# Unit test for function key_expansion
def test_key_expansion():
    aes_key = b'YELLOW SUBMARINE'
    key_expanded = key_expansion(aes_key)
    assert len(key_expanded)==208, 'routine failed'
    assert key_expanded[0]==89, 'routine failed'

# Mix column according to https://en.wikipedia.org/wiki/Rijndael_mix_columns

# Generated at 2022-06-26 11:00:12.753293
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f'
    var_0 = key_expansion(bytes_0)
    assert len(var_0) == 240
    assert var_0[0] == 0
    assert var_0[1] == 1
    assert var_0[2] == 2
    assert var_0[3] == 3
    assert var_0[4] == 4
    assert var_0[5] == 5
    assert var_0[6] == 6
    assert var_0[7] == 7
    assert var_0[8] == 8
    assert var_0[9] == 9
    assert var_0

# Generated at 2022-06-26 11:00:23.532178
# Unit test for function key_expansion
def test_key_expansion():
    # Test data from NIST FIPS 197 - http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    bytes_0 = b'\x00\x04\x08\x0c\x01\x05\t\r\x02\x06\n\x0e\x03\x07\x0b\x0f'
    var_0 = key_expansion(bytes_0)
    bytes_1 = b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c'
    assert var_0 == bytes_1


# Generated at 2022-06-26 11:00:31.484504
# Unit test for function key_expansion
def test_key_expansion():
    test_input = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]

# Generated at 2022-06-26 11:00:40.662366
# Unit test for function key_expansion
def test_key_expansion():
    cipher_key = [0x60,0x3d,0xeb,0x10,0x15,0xca,0x71,0xbe,0x2b,0x73,0xae,0xf0,0x85,0x7d,0x77,0x81,0x1f,0x35,0x2c,0x07,0x3b,0x61,0x08,0xd7,0x2d,0x98,0x10,0xa3,0x09,0x14,0xdf,0xf4]

# Generated at 2022-06-26 11:00:48.961154
# Unit test for function key_expansion
def test_key_expansion():

    key_0 = b'\x00\x10\x20\x30\x40\x50\x60\x70\x80\x90\xa0\xb0\xc0\xd0\xe0\xf0'
    key_1 = b'\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff'
    key_2 = b'\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff\x00\x11\x22\x33\x44\x55\x66\x77'
    key_3 = b

# Generated at 2022-06-26 11:00:55.941158
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    var_0 = key_expansion(bytes_0)


# Generated at 2022-06-26 11:01:07.917248
# Unit test for function key_expansion
def test_key_expansion():
    key = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'


# Generated at 2022-06-26 11:01:12.273923
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = bytes_to_intlist(b'\xfc\xce\x0c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    key_schedule_0 = key_expansion(key_0);


# Generated at 2022-06-26 11:01:20.245149
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F]

# Generated at 2022-06-26 11:01:47.664054
# Unit test for function key_expansion
def test_key_expansion():
    # test case 0
    # 16-Byte cipher key:
    # 0x16157e2b98a
    # After the first 16 bytes, the next block is the result of
    # mixing the SubBytes, ShiftRows and MixColumns operations on
    # the four byte block 0x1615 ^ 0x7e2b.
    key_expansion_test_case_0 = [
        0x16, 0x15, 0x7e, 0x2b
    ]

    key_expansion_test_case_0_expanded_key0 = [
        0x16, 0x15, 0x7e, 0x2b
    ]

    key_expansion_test_case_0_expanded_key1 = [
        0x7e, 0x2b, 0x16, 0x15
    ]



# Generated at 2022-06-26 11:02:01.093131
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    key_0_expanded = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

    key_1 = b'\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10'
    key_

# Generated at 2022-06-26 11:02:11.591368
# Unit test for function key_expansion
def test_key_expansion():
    bytes_0 = b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c'
    bytes_1 = b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c'
    bytes_2 = b'\xa0\xfa\xfe\x17\x88\x54\x2c\xb1\x23\xa3\x39\x39\x2a\x6c\x76\x05'

# Generated at 2022-06-26 11:02:23.223186
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c])
    expanded_key = key_expansion(key)