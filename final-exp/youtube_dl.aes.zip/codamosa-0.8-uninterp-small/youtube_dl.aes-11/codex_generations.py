

# Generated at 2022-06-26 10:52:42.064186
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    cleartext = "12345678"
    key = "1111000011110000"
    iv = "0000000000000000"

    # Test case 0: cleartext length is not a multiple of 16
    test_case_0_cleartext = cleartext
    test_case_0_key = key
    test_case_0_iv = iv
    test_case_0_expected = list(map(ord, b'\x13\x8b\x4f\x1a\x0d\xa9\xfb\xed\xd9\x7f\x31\x3d\x3c\x66\x5c\xa5'))

# Generated at 2022-06-26 10:52:46.249733
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    encrypted = "U2FsdGVkX1+tnrcH8I9yUqF3rKvbTAtIW8pV7KzZ/kcbV7E/ZF+DA9NgQOquNzhV"
    password = "password"
    key_size = 16
    expected_decrypted = "This is a test."
    assert aes_decrypt_text(encrypted, password, key_size) == expected_decrypted


# Generated at 2022-06-26 10:52:51.078643
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Test case 1
    decrypted_1 = aes_decrypt_text('SJLlF+fDlzch5o5a5D5x5Q==', '123456', 32)
    assert decrypted_1 == b'hungry-cat'

    # Test case 2
    decrypted_2 = aes_decrypt_text('7hwu2bSPzV7sdf2y8Mw/Nw==', '123456', 32)
    assert decrypted_2 == b'hungry-cat2'

    # Test case 3
    decrypted_3 = aes_decrypt_text('rTttTzHdT6u28zbep8mnmA==', '123456', 32)
    assert decrypted_3 == b'hungry-cat3'

    # Test case 4
    decrypted

# Generated at 2022-06-26 10:52:53.457554
# Unit test for function aes_encrypt
def test_aes_encrypt():
    try:
        assert aes_encrypt([], []) == []
    except:
        print("aes_encrypt failed on empty data and empty expanded_key")
        

# Generated at 2022-06-26 10:53:04.020805
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test case for function aes_cbc_decrypt
    # Input stored in file ./test_case_0_input
    # Expected output stored in file ./test_case_0_output
    input_file = open('./test_case_0_input', 'r')
    output_file = open('./test_case_0_output', 'r')
    input_list = []
    output_list = []
    for line in input_file:
        if line.find('#') != -1:
            in_str = line.split('#')[0].strip()
        else:
            in_str = line.strip()
        if len(in_str) > 0:
            input_list.append(in_str)

# Generated at 2022-06-26 10:53:11.459612
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    set_0 = set()
    var_0 = key_expansion(set_0)
    assert(var_0 == [])

    set_0 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    var_0 = key_expansion(set_0)

# Generated at 2022-06-26 10:53:22.910756
# Unit test for function aes_decrypt
def test_aes_decrypt():
    set_0 = [221, 12, 0, 42, 83, 33, 1, 125, 187, 17, 173, 174, 170, 7, 89, 246]

# Generated at 2022-06-26 10:53:28.119525
# Unit test for function aes_decrypt
def test_aes_decrypt():
    #print("Unit test for function aes_decrypt")
    # Initialize Input
    key = str("Thats my Kung Fu")
    data = str("Two One Nine Two")
    # Execute Test
    aes_decrypt(data, key)
    # Return Success
    return True


# Generated at 2022-06-26 10:53:30.123634
# Unit test for function aes_decrypt
def test_aes_decrypt():
    set_1 = set()
    var_1 = aes_decrypt(set_1)


# Generated at 2022-06-26 10:53:41.805246
# Unit test for function aes_encrypt
def test_aes_encrypt():
    print("Running unit test for function aes_encrypt")
    clear_text_string = "00112233445566778899aabbccddeeff"
    key_string = "000102030405060708090a0b0c0d0e0f"
    counter_block_string = "f0f1f2f3f4f5f6f7f8f9fafbfcfdfeff"
    counter_block_intlist = bytes_to_intlist(compat_b64decode(counter_block_string))
    clear_text_intlist = bytes_to_intlist(compat_b64decode(clear_text_string))
    key_intlist = bytes_to_intlist(compat_b64decode(key_string))
    encrypted_intlist = aes

# Generated at 2022-06-26 10:54:04.683489
# Unit test for function aes_decrypt

# Generated at 2022-06-26 10:54:11.345751
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = [0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0x07, 0xa8, 0x8d, 0xa2, 0x34]

# Generated at 2022-06-26 10:54:22.516467
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # For key and IV, 128-bit is 16 bytes, 192-bit is 24 bytes, and 256-bit is 32 bytes.
    # For input data of length L, add padding of (L mod 16)+1 up to 16 bytes.
    # For the first byte of the padding, the value is (L mod 16)+1; for others, the value is 0.
    key_b64 = 'XcZmWt1+p/hJm61Cx/y8gA=='
    key = bytes_to_intlist(compat_b64decode(key_b64))
    iv_b64 = 'nY5GS5E5AUX9z+3q4g4DwQ=='
    iv = bytes_to_intlist(compat_b64decode(iv_b64))

# Generated at 2022-06-26 10:54:32.835359
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = [0] * 16
    key = [0] * 16

    # Test data

# Generated at 2022-06-26 10:54:38.896873
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [168,206,153,104,10,250,124,25,
           174,155,60,153,30,42,164,9,
           52,48,46,91,156,19,183,34,
           83,96,139,47,12,66,27,100]
    key = bytes_to_intlist(compat_b64decode("IN7pNUp/9uV7+qokjgtuSQ=="))

    iv = [160,32,194,117,4,51,46,33,
          181,222,228,76,228,71,176,77]
    test_data_j1 = bytes_to_intlist(compat_b64decode("+jKcYxt3DqzGimJ+Zl5moQ=="))
   

# Generated at 2022-06-26 10:54:50.250411
# Unit test for function aes_decrypt
def test_aes_decrypt():
    from .compat import compat_b64decode
    from .utils import bytes_to_intlist, intlist_to_bytes
    import os
    import time
    import collections
    import binascii
    # This test will take a little of time to execute, but it runs only once
    # It runs all the test cases available in NIST 800-38a
    #  AES Decryption Test Vectors:
    #  http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf

    # The input/output data of the test cases are available in
    #  ECB VarKey.txt and ECB VarTxt.txt respectively in the link bellow
    #  http://csrc.nist.gov/groups/STM/cavp/documents/aes/K

# Generated at 2022-06-26 10:54:57.736498
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test case #0

    set_0 = set()
    var_0 = shift_rows_inv(set_0)

    set_1 = set()
    var_1 = shift_rows_inv(set_1)

    set_2 = set()
    var_2 = shift_rows_inv(set_2)

    set_3 = set()
    var_3 = shift_rows_inv(set_3)

    set_4 = set()
    var_4 = shift_rows_inv(set_4)

    set_5 = set()
    var_5 = shift_rows_inv(set_5)

    set_6 = set()
    var_6 = shift_rows_inv(set_6)

    set_7 = set()
    var_7 = shift_rows_inv(set_7)



# Generated at 2022-06-26 10:55:08.571477
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    print("Running test function test_aes_cbc_encrypt...")

    # Test case 1
    key_1 = bytes_to_intlist(compat_b64decode("6C+XGk7lzcxPSskRQQjKPw=="))
    iv_1 = bytes_to_intlist(compat_b64decode("JYDG7V4+HNNuGhavVnBN/Q=="))
    data_1 = bytes_to_intlist(compat_b64decode("lNpV7cLmf8Ojq0ZY+PUC1g=="))
    res_1 = aes_cbc_encrypt(data_1, key_1, iv_1)

# Generated at 2022-06-26 10:55:15.664626
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(compat_b64decode('YWFhYWFhYWFhYWFhYWFhYWFh'))
    key = bytes_to_intlist(compat_b64decode('YWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYQ=='))
    iv = bytes_to_intlist(compat_b64decode('YWFhYWFhYWFhYWFhYWFhYWFh'))

    encrypted = aes_cbc_encrypt(data, key, iv)
    expected_encrypted = aes_cbc_encrypt(bytes_to_intlist(b'aaaaaaaaaaaaaaa'), key, iv)

    assert encrypted == expected_encrypted



# Generated at 2022-06-26 10:55:22.927165
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Use this function to test your implementation
    set_0 = set()
    var_0 = aes_cbc_encrypt(set_0, [255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])


# Generated at 2022-06-26 10:55:36.736515
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    class Tester:
        def test_case_0(self):
            def _test():
                dict_0 = {}

                var_0 = aes_cbc_decrypt(dict_0, dict_0, dict_0)

            _test()

        def test_case_1(self):
            def _test():
                dict_0 = {}

                var_0 = aes_cbc_decrypt(dict_0, dict_0, dict_0)

            _test()

        def test_case_2(self):
            def _test():
                dict_0 = {}

                var_0 = aes_cbc_decrypt(dict_0, dict_0, dict_0)

            _test()

    test_object = Tester()
    test_object.test_case_0()
    test_object

# Generated at 2022-06-26 10:55:40.049201
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    print ("\n*** Test case 0 ***")
    test_case_0()
    print ("*** Test case 1 ***")
    test_case_1()
    print ("*** Test case 2 ***")
    test_case_2()
    print ("*** Test case 3 ***")
    test_case_3()
    print ("*** Test case 4 ***")
    test_case_4()
    print ("*** Test case 5 ***")
    test_case_5()



# Generated at 2022-06-26 10:55:49.705631
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = [0xDA, 0x39, 0xA3, 0xEE, 0x5E, 0x6B, 0x4B, 0x0D, 0x32, 0x55, 0xBF, 0xEF, 0x95, 0x60, 0x18, 0x90]
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]

# Generated at 2022-06-26 10:56:00.476372
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    global dict_0
    dict_0 = {}
    var_0 = aes_cbc_decrypt(dict_0, dict_0, dict_0)

    # Unit test for function aes_ctr_decrypt
    global dict_1
    dict_1 = {}
    var_1 = aes_ctr_decrypt(dict_1, dict_1, dict_1)

    # Unit test for function aes_decrypt
    global dict_2
    dict_2 = {}
    var_2 = aes_decrypt(dict_2, dict_2)



# Generated at 2022-06-26 10:56:11.906332
# Unit test for function inc
def test_inc():
    test_data = [0, 0, 0, 0]
    expected_result = [0, 0, 0, 1]
    assert inc(test_data) == expected_result
    test_data = [0, 0, 0, 255]
    expected_result = [0, 0, 1, 0]
    assert inc(test_data) == expected_result
    test_data = [0, 0, 255, 255]
    expected_result = [0, 1, 0, 0]
    assert inc(test_data) == expected_result
    test_data = [0, 255, 255, 255]
    expected_result = [1, 0, 0, 0]
    assert inc(test_data) == expected_result



# Generated at 2022-06-26 10:56:19.927188
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:56:23.918597
# Unit test for function aes_decrypt
def test_aes_decrypt():
    dict_0 = {}
    # Test case aes_decrypt()
    # Encrypt
    test_0 = aes_encrypt(dict_0, dict_0)
    # Decrypt
    test_0 = aes_decrypt(test_0, dict_0)


# Generated at 2022-06-26 10:56:38.277831
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    assert aes_cbc_decrypt(
        bytes_to_intlist('4ca00ff4c898d61e1edbf1800618fb2828a226d160dad07883d04e008a7897ee'
                         '2e4b7465d5290d0c0e6c6822236e1daafb94ffe0c5da05d9476be028ad7c1d81'),
        bytes_to_intlist('140b41b22a29beb4061bda66b6747e14'),
        bytes_to_intlist('4ca00ff4c898d61e1edbf1800618fb28')
    ) == bytes_to_intlist('Basic CBC mode encryption needs padding.')

# Generated at 2022-06-26 10:56:52.357747
# Unit test for function aes_decrypt
def test_aes_decrypt():
    with open('test/test_vectors/aes_decrypt.txt', 'r') as test_cases:
        next(test_cases)
        for test_case in test_cases:
            test_case = test_case.rstrip()
            if test_case:
                test_case_split = test_case.split('"')
                cipher = bytes_to_intlist(compat_b64decode(test_case_split[1]))
                encrypted_key = bytes_to_intlist(compat_b64decode(test_case_split[3]))
                plain = bytes_to_intlist(compat_b64decode(test_case_split[5]))
                encrypted = aes_decrypt(cipher, encrypted_key)
                assert encrypted == plain

    empty_dict = {}


# Generated at 2022-06-26 10:57:04.002767
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('qC73KjujjnrJI0uxcZkt+g=='))
    iv = bytes_to_intlist(compat_b64decode('u8dRt1Jg/ZzTKmD8Mf2c4Q=='))
    cipher = bytes_to_intlist(compat_b64decode('YoVuN+P/n7Pu6yekIP/lyVu+/p0bMV+6'))
    assert (aes_cbc_decrypt(cipher, key, iv) ==
            bytes_to_intlist(compat_b64decode('stjuYBjKpAIYg0o7tkEOOw==')))


# Generated at 2022-06-26 10:57:19.942292
# Unit test for function key_expansion

# Generated at 2022-06-26 10:57:28.771960
# Unit test for function key_expansion
def test_key_expansion():
    # test case #0
    key1 = [81, 212, 206, 169, 122, 144, 52, 191, 216, 94, 118, 73, 159, 243, 230, 14, 165, 27, 124, 62, 222, 153, 137, 14, 69, 65, 147, 140, 100, 91, 3, 4, 56, 114, 71, 195, 52, 112, 102, 119, 217, 168, 65, 116, 6, 123, 246, 7, 218, 69, 71, 50, 220, 254, 52, 189, 203, 104, 241, 24, 30, 231, 10, 118, 5, 13, 48, 76, 148, 92, 177, 119, 171, 107, 154, 218, 110, 59, 186, 9, 248, 100, 192, 216, 53, 25, 151, 31]

# Generated at 2022-06-26 10:57:42.135860
# Unit test for function key_expansion
def test_key_expansion():
    test_cases = []


# Generated at 2022-06-26 10:57:51.930905
# Unit test for function key_expansion
def test_key_expansion():
    var_0 = encrypt_aes128_ctr(
        [123, 28, 182, 234, 123, 28, 182, 234, 123, 28, 182, 234, 123, 28, 182, 234],
        [123, 28, 182, 234, 123, 28, 182, 234, 123, 28, 182, 234, 123, 28, 182, 234],
        [123, 28, 182, 234, 123, 28, 182, 234, 123, 28, 182, 234, 123, 28, 182, 234]
    )
    assert var_0 == [242, 24, 78, 89, 127, 231, 40, 189, 156, 7, 56, 236, 132, 210, 122, 223]
    var_1 = key_expansion([0] * 16)

# Generated at 2022-06-26 10:58:02.355063
# Unit test for function key_expansion
def test_key_expansion():
    # split test data
    #key_expansion_data = read_file("data/key_expansion.txt")
    test_case = ""

    # test loop
    for test_case in test_cases:
        expected_cipher = bytes_to_intlist(b64decode(test_case["ct"]))
        key_size = test_case["ks"] / 8

# Generated at 2022-06-26 10:58:12.121472
# Unit test for function key_expansion
def test_key_expansion():
    # test case 0
    # create argument `dict_0`
    dict_0 = {}
    # call function `key_expansion`
    var_0 = key_expansion(dict_0)
    # check return value
    assert var_0 == []
    # check variable `dict_0`
    assert dict_0 == {}
    # test case 1
    # create argument `dict_0`
    dict_0 = {}
    # call function `key_expansion`
    var_0 = key_expansion(dict_0)
    # check return value
    assert var_0 == []
    # check variable `dict_0`
    assert dict_0 == {}
    # test case 2
    # create argument `dict_0`
    dict_0 = {}
    # call function `key_expansion`
    var_

# Generated at 2022-06-26 10:58:20.753030
# Unit test for function key_expansion

# Generated at 2022-06-26 10:58:25.582268
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = []
    key_1 = []
    plaintext_0 = key_expansion(key_0)
    plaintext_1 = key_expansion(key_1)
    assert plaintext_0 == plaintext_1, "Comparing elements of same list"

# Generated at 2022-06-26 10:58:35.814515
# Unit test for function key_expansion
def test_key_expansion():
    # Case 0
    dict_0 = {}
    var_0 = key_expansion(dict_0)
    assert var_0 == dict_0

    # Case 1
    dict_0 = bytearray([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])
    var_0 = key_expansion(dict_0)

# Generated at 2022-06-26 10:58:46.572420
# Unit test for function key_expansion
def test_key_expansion():
    key = [
        0x2b, 0x7e, 0x15, 0x16,
        0x28, 0xae, 0xd2, 0xa6,
        0xab, 0xf7, 0x15, 0x88,
        0x09, 0xcf, 0x4f, 0x3c
    ]

# Generated at 2022-06-26 10:59:02.508207
# Unit test for function key_expansion
def test_key_expansion():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}
    dict_27 = {}
    dict_

# Generated at 2022-06-26 10:59:15.778584
# Unit test for function key_expansion
def test_key_expansion():
    key1 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 10:59:27.796505
# Unit test for function key_expansion

# Generated at 2022-06-26 10:59:39.098690
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = []
    key_expanded = key_expansion(key_0)

# Generated at 2022-06-26 10:59:46.986752
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'mencode')

# Generated at 2022-06-26 10:59:56.262348
# Unit test for function key_expansion
def test_key_expansion():
    b_iv = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    b_key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]

# Generated at 2022-06-26 11:00:05.518271
# Unit test for function key_expansion
def test_key_expansion():
    d = [157, 51, 188, 103, 138, 202, 105, 145, 106, 208, 87, 246, 90, 15, 213, 30,
         195, 178, 174, 61, 114, 70, 244, 47, 87, 198, 189, 139, 223, 135, 172, 47,
         191, 7, 87, 234, 136, 124, 125, 112, 177, 132, 160, 48, 168, 8, 76, 166,
         161, 105, 93, 38, 126, 155, 85, 248, 248, 168, 238, 25, 141, 173, 241, 182]
    e = key_expansion(d)
    assert len(e) == 32 * 11  # 32*11 = 352 = 176/24/32 + 7*16 = 240 + 112 = 352

    # Make sure byte 2 is 51
    assert e[2]

# Generated at 2022-06-26 11:00:13.297321
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 11:00:23.842023
# Unit test for function key_expansion
def test_key_expansion():
    key_expansion_0 = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    key_expansion_1 = key_expansion(key_expansion_0)

    assert len(key_expansion_1) == len(key_expansion_0) + (BLOCK_SIZE_BYTES - len(key_expansion_0))
    assert len(key_expansion_1) == 176


# Generated at 2022-06-26 11:00:31.717327
# Unit test for function key_expansion
def test_key_expansion():
    test_key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

# Generated at 2022-06-26 11:00:47.994665
# Unit test for function key_expansion

# Generated at 2022-06-26 11:01:01.240731
# Unit test for function key_expansion
def test_key_expansion():
    assert key_expansion([]) == []

# Generated at 2022-06-26 11:01:12.675550
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(compat_b64decode('QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F'))

# Generated at 2022-06-26 11:01:20.518461
# Unit test for function key_expansion
def test_key_expansion():
    array = bytes_to_intlist(compat_b64decode(b'KtDZS+7g1hM9TWV7ZbT+ag=='))

# Generated at 2022-06-26 11:01:22.192708
# Unit test for function key_expansion
def test_key_expansion():
    dict_0 = {}
    var_0 = key_expansion(dict_0)


# Generated at 2022-06-26 11:01:27.881634
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = compat_b64decode("UhcHw6z8U6LADU6heO9iXQ==")
    key_0 = bytes_to_intlist(key_0)
    test_case_0()
    test_1 = key_expansion(key_0)
    return test_1


# Generated at 2022-06-26 11:01:40.784274
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 11:01:53.022307
# Unit test for function key_expansion
def test_key_expansion():
    # key
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    #expected result

# Generated at 2022-06-26 11:02:03.367588
# Unit test for function key_expansion
def test_key_expansion():
    """Test key expansion"""
    # AES 128
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    expanded_key = key_expansion(key)

# Generated at 2022-06-26 11:02:14.893629
# Unit test for function key_expansion