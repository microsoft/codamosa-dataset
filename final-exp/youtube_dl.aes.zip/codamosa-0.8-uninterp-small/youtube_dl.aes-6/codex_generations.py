

# Generated at 2022-06-26 10:52:35.696544
# Unit test for function aes_encrypt
def test_aes_encrypt():
    list_0 = aes_encrypt(dict_0, var_0)


# Generated at 2022-06-26 10:52:44.909594
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist('YELLOW SUBMARINE')
    iv = bytes_to_intlist('\0' * 16)

# Generated at 2022-06-26 10:52:55.228124
# Unit test for function key_expansion
def test_key_expansion():
    dict_0 = [0x54, 0x68, 0x61, 0x74, 0x73, 0x20, 0x6D, 0x79, 0x20, 0x4B, 0x75, 0x6E, 0x67, 0x20, 0x46, 0x75]
    dict_1 = key_expansion(dict_0)

# Generated at 2022-06-26 10:53:05.648633
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    """
    Function test_aes_ctr_decrypt
    """
    test_data = {
        'key': bytes_to_intlist(compat_b64decode('U0hxUWRVZU5EcGtzQVMyUg==')),
        'counter': bytes_to_intlist(compat_b64decode('NjM5Yzc5MjRlYzMzNg==')),
        'data': bytes_to_intlist(compat_b64decode('QnB2Tk9sdTJDT2d6ZEhx')),
        'expected': bytes_to_intlist(compat_b64decode('8e23cc47f1c7c039')),
    }


# Generated at 2022-06-26 10:53:14.754475
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    text_1 = '3hHRfZiXDnRwiFaxnWjskQ=='
    password_1 = 'videopassword'
    key_size_bytes_1 = 16
    result_1 = aes_decrypt_text(text_1, password_1, key_size_bytes_1)
    expected_1 = 'SOME PLAINTEXT'
    assert result_1 == expected_1, 'Expected: %s, but was: %s' % (expected_1, result_1)

    text_2 = '4dzKfZiXDnRwiFaxnWjskQ=='
    password_2 = 'videopassword'
    key_size_bytes_2 = 16

# Generated at 2022-06-26 10:53:26.095987
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    counter = CTRCounter()

    decrypted_data = aes_ctr_decrypt(data, key, counter)
    decrypted_message = intlist_to_bytes(decrypted_data)

    assert decrypted_message == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-26 10:53:41.020388
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .crypto import aes_cbc_decrypt

# Generated at 2022-06-26 10:53:55.113593
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    cleartext = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]

# Generated at 2022-06-26 10:54:01.724184
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    from .crypto import aes_decrypt_text
    print('aes_decrypt_text unit test')
    print(aes_decrypt_text(
        b'Pj+jaFryrzr2Qe1dWSJNCvmIkP2130kl7trnqPY8V7Q=',
        'this_is_my_password', 32))



# Generated at 2022-06-26 10:54:09.775039
# Unit test for function key_expansion
def test_key_expansion():
    secret_key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))

# Generated at 2022-06-26 10:54:35.555388
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:54:45.890260
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    plaintext = b'Testing, 1 2 3'

# Generated at 2022-06-26 10:54:55.586061
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    test_input = intlist_to_bytes([0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0])
    test_key = intlist_to_bytes([0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0])

# Generated at 2022-06-26 10:54:57.040281
# Unit test for function aes_decrypt
def test_aes_decrypt():
    var_0 = aes_decrypt(None, None)
    assert var_0 == None


# Generated at 2022-06-26 10:55:06.687444
# Unit test for function aes_decrypt
def test_aes_decrypt():
    dict_1 = None
    dict_2 = None
    dict_3 = None
    dict_4 = None
    dict_5 = None
    dict_6 = None
    dict_7 = None
    dict_8 = None
    dict_9 = None
    dict_10 = None
    dict_11 = None
    dict_12 = None
    dict_13 = None
    dict_14 = None
    dict_15 = None
    dict_16 = None
    dict_17 = None
    dict_18 = None
    dict_19 = None
    dict_20 = None

    var_1 = aes_decrypt(dict_1, dict_2)


# Generated at 2022-06-26 10:55:13.370671
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    testmsg = "test message"
    testkey = [0] * BLOCK_SIZE_BYTES
    testiv = [0] * BLOCK_SIZE_BYTES
    assert aes_cbc_encrypt(bytes_to_intlist(testmsg.encode('utf-8')), testkey, testiv) == [
        179, 2, 3, 2, 176, 227, 18, 21, 172, 191, 130, 7, 1, 0, 3, 92, 192, 191, 239, 30, 233, 161, 156, 11, 0, 0, 0, 0, 0, 0, 0, 0]



# Generated at 2022-06-26 10:55:24.762861
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # pylint: disable=missing-docstring
    expected = [
        '4f4d4a4b4a4a4b4f'  # No padding
    ]

    input_data = [
        bytes_to_intlist(compat_b64decode(b'EjQ1NDE0MTQxNDU'))
    ]
    input_key = [
        bytes_to_intlist(compat_b64decode(b'QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLw=='))
    ]

# Generated at 2022-06-26 10:55:35.325326
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [173, 2, 85, 53, 105, 38, 175, 10, 61, 254, 202, 241, 178, 161, 117, 142]
    iv = [151, 39, 114, 25, 243, 231, 133, 128, 252, 3, 143, 48, 89, 46, 73, 190]
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    result = [69, 94, 150, 148, 186, 69, 250, 103, 47, 189, 93, 154, 209, 235, 143, 122]
    assert aes_cbc_encrypt(data, key, iv) == result


# Generated at 2022-06-26 10:55:41.103080
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test case 0
    print("Test case 0")
    dict_0 = [96, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

# Generated at 2022-06-26 10:55:50.223850
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:56:10.411932
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
	dict_0 = None
	dict_0 = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
	dict_0 = aes_cbc_decrypt(dict_0, [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16], [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16])
	print(dict_0)


# Generated at 2022-06-26 10:56:18.919159
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)
    data = [0x6b, 0xc1, 0xbe, 0xe2, 0x2e, 0x40, 0x9f, 0x96, 0xe9, 0x3d, 0x7e, 0x11, 0x73, 0x93, 0x17, 0x2a]
    data = aes_decrypt(data, expanded_key)

# Generated at 2022-06-26 10:56:29.613339
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test Key from FIPS-197 http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    # Nb = 4, Nk = 4, Nr = 10
    cipher_key_bytes = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    # cipher_key_bytes = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x

# Generated at 2022-06-26 10:56:42.987297
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """
    Tests aes_cbc_decrypt
    """
    # test vectors from  http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 10:56:54.728046
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')
    cipher_text = bytes_to_intlist(compat_b64decode('CRIwqt4+szDbqkNY+I0qbDe3LQz0wiw0SuxBQtAM5TDdMbjCMD/venUDW9BL'))
    iv = bytes_to_intlist('000102030405060708090a0b0c0d0e0f')

    plain_text = aes_cbc_decrypt(cipher_text, key, iv)


# Generated at 2022-06-26 10:57:00.119818
# Unit test for function inc
def test_inc():
	assert(inc([1, 0]) == [1, 1])
	assert(inc([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1])
	assert(inc([255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255]) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])


# Generated at 2022-06-26 10:57:12.648566
# Unit test for function aes_decrypt
def test_aes_decrypt():
    dict_0 = r'{"reason": "You are not logged in. Please login"}'
    dict_0 = compat_b64decode(dict_0)
    dict_0 = bytes_to_intlist(dict_0)
    dict_1 = r'["AC", "SHA256withRSA", "AES_256_CBC", "AES_128_CBC"]'
    dict_1 = compat_b64decode(dict_1)
    dict_1 = bytes_to_intlist(dict_1)

# Generated at 2022-06-26 10:57:15.723020
# Unit test for function aes_decrypt
def test_aes_decrypt():
    dict_0 = None
    dict_1 = None
    var_0 = aes_decrypt(dict_0, dict_1)


# Generated at 2022-06-26 10:57:26.214532
# Unit test for function aes_decrypt
def test_aes_decrypt():
    print('**** Test case 0:')
    print('Expected:')
    print(aes_decrypt(dict_0, None))
    print('Actual:')
    print(sub_bytes(dict_0))
    print('**** Test case 1:')
    print('Expected:')
    print(aes_decrypt([], None))
    print('Actual:')
    print(sub_bytes([]))
    print('**** Test case 2:')
    print('Expected:')
    print(aes_decrypt(None, []))
    print('Actual:')
    print(sub_bytes(None))
    print('**** Test case 3:')
    print('Expected:')
    print(aes_decrypt(None, None))
    print('Actual:')

# Generated at 2022-06-26 10:57:39.395992
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = [0xF9, 0xF1, 0xB6, 0x6B, 0xEF, 0x8E, 0x4F, 0xB4, 0x14, 0xE2, 0x7F, 0xE3, 0xB6, 0x32, 0x07, 0x8C]

# Generated at 2022-06-26 10:58:36.481310
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    test_case_0()
    assert True



# Generated at 2022-06-26 10:58:47.089787
# Unit test for function key_expansion
def test_key_expansion():
    input = [0x81, 0x34, 0xC4, 0xB7, 0xBD, 0x84, 0x5A, 0x91, 0xDC, 0xAA, 0x8C, 0xF3, 0x58, 0x17, 0xB7, 0x9C]

# Generated at 2022-06-26 10:59:01.189427
# Unit test for function key_expansion
def test_key_expansion():
    dict_0 = key_expansion([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])
    dict_1 = key_expansion([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24])
    dict_2 = key_expansion([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32])


# Generated at 2022-06-26 10:59:14.475159
# Unit test for function key_expansion
def test_key_expansion():
    user_input = bytes_to_intlist(compat_b64decode('KrI2b+X9Q2iLTF8ZKkDgPw=='), pad_to=16)
    # The user_input is the key for encrypting using AES algorithm in cbc mode.
    # The JS code that uses this user_input is as follows:
    #   var key = CryptoJS.enc.Utf8.parse(key);
    #   var iv = CryptoJS.enc.Utf8.parse(iv);
    #   var ciphertext = CryptoJS.AES.encrypt(plainText, key, {iv: iv, mode: CryptoJS.mode.CBC});
    #   ciphertext = ciphertext.toString();
    #   return ciphertext;
    # After encryption, the ciphertext was:
    #   Y

# Generated at 2022-06-26 10:59:26.669587
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 1
    dict_1 = bytes_to_intlist(compat_b64decode('NkYuYWRkcmVzc0BtZW1iZXJzaGlwLm5ldA=='))
    var_1 = key_expansion(dict_1)

# Generated at 2022-06-26 10:59:33.051032
# Unit test for function key_expansion
def test_key_expansion():
    print("Testing key_expansion ..")
    key_size_bytes = 32
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    expanded_key_size_bytes = (key_size_bytes // 4 + 7) * BLOCK_SIZE_BYTES
    exp_data = key_expansion(data)
    print(exp_data)


# Generated at 2022-06-26 10:59:43.395377
# Unit test for function key_expansion
def test_key_expansion():
    # test case 1
    dict_0 = None

# Generated at 2022-06-26 10:59:50.250124
# Unit test for function key_expansion
def test_key_expansion():
    dict_0 = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f]
    var_0 = key_expansion(dict_0)
    return var_0


# Generated at 2022-06-26 10:59:58.945272
# Unit test for function key_expansion
def test_key_expansion():
    dict_0 = bytes_to_intlist(b"\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f")
    dict_0 = key_expansion(dict_0)


# Generated at 2022-06-26 11:00:08.812810
# Unit test for function key_expansion
def test_key_expansion():
    secret_key = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    secret_key_expanded = key_expansion(secret_key)
    assert(len(secret_key_expanded) == BLOCK_SIZE_BYTES * 11)
    assert(secret_key_expanded[0] == 0x00)
    assert(secret_key_expanded[16] == 0x62)

# Generated at 2022-06-26 11:00:37.674277
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    key_expansion_0 = key_expansion(key_0)

# Generated at 2022-06-26 11:00:47.302024
# Unit test for function key_expansion
def test_key_expansion():
    data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    expected_result = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    assert (key_expansion(data) == expected_result)

# Generated at 2022-06-26 11:01:00.145590
# Unit test for function key_expansion

# Generated at 2022-06-26 11:01:12.164664
# Unit test for function key_expansion

# Generated at 2022-06-26 11:01:15.139890
# Unit test for function key_expansion
def test_key_expansion():
    dict_0 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]
    var_0 = key_expansion(dict_0)
    assert var_0 == None



# Generated at 2022-06-26 11:01:28.860927
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 11:01:40.983559
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\xf9\x80\x62\x62\x72\xfb\xfe\x29\xd8\x1f\xd0\x9f\x27\x6d\x76\x59')

# Generated at 2022-06-26 11:01:53.187617
# Unit test for function key_expansion
def test_key_expansion():
    hexString ='cf063a34d4a9a76c2c86787d3f96db71'
    print(bytes_to_intlist(compat_b64decode(hexString)))
    expanded_key = key_expansion(bytes_to_intlist(compat_b64decode(hexString)))
    print(expanded_key)
    # [207, 6, 58, 52, 212, 169, 167, 108, 44, 134, 120, 125, 63, 150, 219, 113,
    #  47, 102, 212, 121, 199, 107, 108, 79, 101, 235, 102, 55, 168, 96, 193,
    #  232, 204, 214, 77, 53, 32, 210, 40, 162, 143, 28, 102, 187, 59, 145,
    #  29,

# Generated at 2022-06-26 11:02:03.481059
# Unit test for function key_expansion
def test_key_expansion():
    input_0 = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    output_0 = []
    for i in range(16):
        output_0.append(int(i))
    output_0.extend([int(i) for i in range(0xD6, 0xD6+16)])
    output_0.extend([int(i) for i in range(0xAE, 0xAE+16)])
    output_0.extend([int(i) for i in range(0x52, 0x52+16)])

# Generated at 2022-06-26 11:02:14.942455
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    var_0 = key_expansion(key_0)