

# Generated at 2022-06-26 10:52:44.879707
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:52:49.237960
# Unit test for function inc
def test_inc():
    bool_0 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    inc(bool_0)



# Generated at 2022-06-26 10:52:56.523061
# Unit test for function aes_decrypt
def test_aes_decrypt():
    message = "L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=="
    raw_message = compat_b64decode(message)
    iv = bytes_to_intlist(raw_message[:16])
    aes_key = bytes_to_intlist(raw_message[16:32])
    encrypted_message = raw_message[32:]
    encrypted_message = bytes_to_intlist(encrypted_message)
    # Use the following commented code to test your function.
    # print aes_decrypt(encrypted_message, aes_key, iv)


# Generated at 2022-06-26 10:53:06.724047
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Create instance of ArgumentParser
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', nargs='?', const=True, default="42",
                        help='data')
    parser.add_argument('--key', nargs='?', const=True, default="42",
                        help='key')
    parser.add_argument('--iv', nargs='?', const=True, default="42",
                        help='iv')
    
    args = parser.parse_args()
    data = bytes_to_intlist(compat_b64decode(args.data))
    key = bytes_to_intlist(compat_b64decode(args.key))
    iv = bytes_to_intlist(compat_b64decode(args.iv))
    decrypted_data = aes_

# Generated at 2022-06-26 10:53:17.698942
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    iv = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    data = bytes_to_intlist(b'\x69\xc4\xe0\xd8\x6a\x7b\x04\x30\xd8\xcd\xb7\x80\x70\xb4\xc5\x5a')


# Generated at 2022-06-26 10:53:29.049684
# Unit test for function key_expansion
def test_key_expansion():
    data = [0, 0, 0, 0]

# Generated at 2022-06-26 10:53:39.548363
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    PASSWORD = 'test'
    KEY_SIZE_BYTES = 16
    CIPHER = 'NGmSgW8XkU6ARxUoJv4F+QI6QbM6B1yM2vzEEHN/8Xo='

    assert aes_decrypt_text(CIPHER, PASSWORD, KEY_SIZE_BYTES) == b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"


# Generated at 2022-06-26 10:53:53.018952
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(compat_b64decode('000000000000000'))
    key = bytes_to_intlist(compat_b64decode('2b7e151628aed2a6abf7158809cf4f3c'))
    iv = bytes_to_intlist(compat_b64decode('000102030405060708090a0b0c0d0e0f'))
    expected_encryption = bytes_to_intlist(compat_b64decode('0388dace60b6a392f328c2b971b2fe78'))
    assert aes_cbc_encrypt(data, key, iv) == expected_encryption



# Generated at 2022-06-26 10:54:04.731823
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:54:11.367158
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key_input = "3000000000000000300000000000000030000000000000003000000000000000"
    key_input = bytes_to_intlist(compat_b64decode(key_input))
    counter_input = "60000000000000006000000000000000"
    counter_input = bytes_to_intlist(compat_b64decode(counter_input))
    input_data = "8000000000000000000000000000000000000000000000000000000000000000"
    input_data = bytes_to_intlist(compat_b64decode(input_data))
    expected = "1000000000000000000000000000000000000000000000000000000000000000"
    expected = bytes_to_intlist(compat_b64decode(expected))
    class Counter():
        def __init__(self, counter_input):
            self.counter_input = counter_input

# Generated at 2022-06-26 10:56:02.610007
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Given
    do_test_case(0)


# Generated at 2022-06-26 10:56:13.653123
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test 0
    bool_0 = True
    var_0 = mix_columns(bool_0)
    # Test 1
    bool_0 = True
    var_0 = mix_columns(bool_0)
    # Test 2
    bool_0 = True
    var_0 = mix_columns(bool_0)
    # Test 3
    bool_0 = True
    var_0 = mix_columns(bool_0)
    # Test 4
    bool_0 = True
    var_0 = mix_columns(bool_0)
    # Test 5
    bool_0 = True
    var_0 = mix_columns(bool_0)
    # Test 6
    bool_0 = True
    var_0 = mix_columns(bool_0)
    # Test 7

# Generated at 2022-06-26 10:56:17.474734
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(bytes(b"Hello World"))
    key = bytes_to_intlist(bytes(b"1234567890ABCDEF"))
    iv = bytes_to_intlist(bytes(b"1234567890ABCDEF"))
    encrypted = aes_cbc_encrypt(data, key, iv)



# Generated at 2022-06-26 10:56:28.711514
# Unit test for function aes_decrypt
def test_aes_decrypt():
    print("Testing function 'test_aes_decrypt'")
    print("type(test_aes_decrypt)=" + str(type(test_aes_decrypt)))
    print("test_aes_decrypt=" + str(test_aes_decrypt))

    var_0 = base64.standard_b64decode(b'M3Ga3uV7Kx9hJflbYNDLlA==')
    print("var_0=" + str(var_0))
    print("type(var_0)=" + str(type(var_0)))

    var_1 = base64.standard_b64decode(b'ZoBi/D2QzRg/7FwWySK/0g==')
    print("var_1=" + str(var_1))

# Generated at 2022-06-26 10:56:42.100156
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]
    vector = [0x93, 0xE8, 0xFC, 0x3E, 0xF5, 0x5D, 0x1B, 0x5D, 0xEA, 0x07, 0x64, 0xF2, 0x4F, 0x52, 0xE4, 0xE9]

# Generated at 2022-06-26 10:56:54.077271
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    result = aes_cbc_encrypt([1, 2, 3, 4, 5, 6, 7, 8, 9, 16], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])

    expected_result = [4, 255, 115, 81, 250, 145, 123, 8, 57, 124, 229, 122, 241, 192, 33, 7]
    assert result == expected_result


# Generated at 2022-06-26 10:57:04.895723
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    test_input = "cHl0aG9uMzJr"
    data = bytes_to_intlist(compat_b64decode(test_input))
    key = [0xfa, 0x9a, 0xef, 0xa8, 0x52, 0x34, 0xfb, 0xd8, 0x4d, 0x1a, 0x32, 0x7c, 0x27, 0x37, 0xf2, 0x80]
    iv = [0x2a, 0x3e, 0xf1, 0xbb, 0xe5, 0xac, 0x9d, 0xcc, 0x75, 0x11, 0x22, 0xcd, 0xee, 0x80, 0x9d, 0x61]
    actual_output = aes_cbc_

# Generated at 2022-06-26 10:57:11.562551
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b'0123456789012345')
    key = bytes_to_intlist(b'0123456789abcdef')
    iv = bytes_to_intlist(b'abcdefabcdefabcd')
    expected = bytes_to_intlist(b'56B32EDFE3A56AAD')
    actual = aes_cbc_encrypt(data, key, iv)
    assert expected == actual



# Generated at 2022-06-26 10:57:17.933752
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    clear = b'hello world'
    cipher = aes_cbc_encrypt(clear, key, [0] * 16)
    decrypted = aes_cbc_decrypt(cipher, key, [0] * 16)
    assert decrypted == clear

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 10:57:28.060694
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = [0x7a, 0xaa, 0x36, 0xe4, 0x80, 0xc5, 0x5e, 0xa6]
    iv = [0x58, 0x75, 0xa5, 0x8c, 0xbf, 0xbd, 0xeb, 0x41]
    key = [0x36, 0xa5, 0x26, 0x2d, 0x13, 0x9a, 0x90, 0x84, 0x72, 0x68, 0xfc, 0x42, 0x5c, 0x6a, 0xe5, 0x3c]
    result = aes_cbc_decrypt(data, key, iv)

# Generated at 2022-06-26 10:57:46.996291
# Unit test for function inc
def test_inc():

    # Test case 0
    test_case_0()

    # Test case 1
    int_1 = 1
    expected_1 = [2]
    actual_1 = inc(int_1)
    assert actual_1 == expected_1

    # Test case 2
    int_2 = [255]
    expected_2 = [0]
    actual_2 = inc(int_2)
    assert actual_2 == expected_2

    # Test case 3
    int_3 = [255, 255, 255, 255]
    expected_3 = [0, 0, 0, 0]
    actual_3 = inc(int_3)
    assert actual_3 == expected_3

    # Test case 4
    int_4 = [254, 255, 255, 255]
    expected_4 = [255, 0, 0, 0]
   

# Generated at 2022-06-26 10:57:49.648662
# Unit test for function inc
def test_inc():
    # Case 0
    int_0 = 0
    int_0_result = inc(int_0)
    assert int_0_result == 1
    # Case 1
    int_1 = 255
    int_1_result = inc(int_1)
    assert int_1_result == 0
    # Case 2
    int_2 = 254
    int_2_result = inc(int_2)
    assert int_2_result == 255



# Generated at 2022-06-26 10:57:53.116140
# Unit test for function inc
def test_inc():
    assert inc([0,0,0,0]) == [0,0,0,1]
    assert inc([0,0,0,255]) == [0,0,1,0]
    assert inc([0,0,255,255]) == [0,1,0,0]
    assert inc([0,255,255,255]) == [1,0,0,0]

test_inc()


# Generated at 2022-06-26 10:57:53.906346
# Unit test for function inc
def test_inc():
    test_case_0()
test_inc()

# Generated at 2022-06-26 10:58:05.419525
# Unit test for function key_expansion
def test_key_expansion():
    print('Running unit test for function key_expansion...')

# Generated at 2022-06-26 10:58:07.962981
# Unit test for function inc
def test_inc():
    assert inc([0]) == [1]
    assert inc([0, 0, 0]) == [0, 0, 1]
    assert inc([0, 0, 255]) == [0, 1, 0]



# Generated at 2022-06-26 10:58:13.420814
# Unit test for function inc
def test_inc():
    print("Testing inc...")
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]
    assert inc([0, 2, 4, 6]) == [0, 2, 4, 7]
    assert inc([1, 2, 3, 4]) == [1, 2, 3, 5]
    assert inc([255]) == [0]
    assert inc([1]) == [2]
    print("inc passes tests.")



# Generated at 2022-06-26 10:58:20.382616
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 1]) == [0, 0, 0, 2]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]
    print("all test passed")

test_inc()


# Generated at 2022-06-26 10:58:25.945153
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
test_inc()



# Generated at 2022-06-26 10:58:33.486789
# Unit test for function inc
def test_inc():
    assert inc([1, 2, 3, 4]) == [1, 2, 3, 5]
    assert inc([1, 2, 3, 255]) == [1, 2, 4, 0]
    assert inc([1, 2, 255, 255]) == [1, 3, 0, 0]
    assert inc([1, 255, 255, 255]) == [2, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]


# Generated at 2022-06-26 10:58:47.894240
# Unit test for function key_expansion
def test_key_expansion():
    print("unit test for function key_expansion")
    # Test case 0
    print("  test case 0")
    str_0 = "00000000000000000000000000000000"
    intlist_0 = bytes_to_intlist(compat_b64decode(str_0))
    intlist_1 = key_expansion(intlist_0)

# Generated at 2022-06-26 10:58:53.406249
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode("ABCDEFABCDEFABCDEF"))
    key = key_expansion(key)

# Generated at 2022-06-26 10:59:02.949234
# Unit test for function key_expansion

# Generated at 2022-06-26 10:59:15.996500
# Unit test for function key_expansion

# Generated at 2022-06-26 10:59:17.713294
# Unit test for function key_expansion
def test_key_expansion():
    key_expansion()
    test_case_0()



# Generated at 2022-06-26 10:59:18.273097
# Unit test for function key_expansion
def test_key_expansion():
    return


# Generated at 2022-06-26 10:59:29.072246
# Unit test for function key_expansion
def test_key_expansion():
    int_0 = 0
    byte_0 = 0x0
    byte_1 = 0x1
    byte_4 = 0x4
    byte_6 = 0x6
    byte_8 = 0x8
    byte_12 = 0xc
    byte_14 = 0xe
    byte_255 = 0xff
    byte_127 = 0x7f
    byte_128 = 0x80
    int_16 = 16
    int_24 = 24
    int_32 = 32
    int_176 = 176
    int_208 = 208
    int_240 = 240
    int_256 = 256
    int_16_times_2 = 32
    int_16_times_3 = 48
    int_16_times_5 = 80
    int_16_times_7 = 112
    int_16_times_9 = 144


# Generated at 2022-06-26 10:59:40.905953
# Unit test for function key_expansion

# Generated at 2022-06-26 10:59:47.076161
# Unit test for function key_expansion
def test_key_expansion():
    result = key_expansion([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c])

# Generated at 2022-06-26 10:59:56.377091
# Unit test for function key_expansion
def test_key_expansion():
    key1 = [
        0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C
    ]

# Generated at 2022-06-26 11:00:11.788628
# Unit test for function key_expansion
def test_key_expansion():
    int_0 = 0

    print("Testing key_expansion function with input:")
    print("\tdata = {:s}".format("{:s}".format(str(int_0))))
    for i in range(1):
        expected_0 = int_0

        int_0 = key_expansion(int_0)
        actual_0 = int_0
        assert actual_0 == expected_0, "Test case 0:"
        print("\tReceived {:s}, expected {:s}".format(str(actual_0), str(expected_0)))
    print("\n")

# Generated at 2022-06-26 11:00:22.489977
# Unit test for function key_expansion

# Generated at 2022-06-26 11:00:30.826563
# Unit test for function key_expansion

# Generated at 2022-06-26 11:00:39.948848
# Unit test for function key_expansion
def test_key_expansion():
    print("Testing function key_expansion...", end="")
    key = [166, 231, 34, 31, 241, 158, 223, 113, 37, 193, 218, 32, 76,
           134, 245, 66, 163, 182, 41, 217, 62, 0, 66, 14, 249, 242, 230,
           197, 190]

# Generated at 2022-06-26 11:00:48.508736
# Unit test for function key_expansion
def test_key_expansion():
    data = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    rcon_iteration = 1
    key_size_bytes = len(key)
    expanded_key_size_bytes = (key_size_bytes // 4 + 7) * BLOCK_SIZE_BYTES

# Generated at 2022-06-26 11:01:01.704715
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7,
               0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    data = key_expansion(key_0)

# Generated at 2022-06-26 11:01:13.042162
# Unit test for function key_expansion
def test_key_expansion():
    int_0 = 0
    int_255 = 255
    int_128 = 128
    int_131 = 131
    int_8 = 8
    int_9 = 9
    int_10 = 10
    int_11 = 11
    int_12 = 12
    int_13 = 13
    int_14 = 14
    int_15 = 15
    int_16 = 16
    int_17 = 17
    int_18 = 18
    int_19 = 19
    int_20 = 20
    int_21 = 21
    int_22 = 22
    int_23 = 23
    int_24 = 24
    int_25 = 25
    int_26 = 26
    int_27 = 27
    int_28 = 28
    int_29 = 29
    int_30 = 30
    int_31 = 31
    int_

# Generated at 2022-06-26 11:01:27.546630
# Unit test for function key_expansion
def test_key_expansion():
    # Test case
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-26 11:01:40.415461
# Unit test for function key_expansion
def test_key_expansion():
    key = [176, 224, 130, 207, 101, 79, 15, 232, 34, 29, 214, 188, 255, 126, 187, 140, 187, 108, 247, 149, 101, 167, 236, 203, 29, 156, 213, 158, 14, 212, 180, 58]

# Generated at 2022-06-26 11:01:48.013906
# Unit test for function key_expansion
def test_key_expansion():
    data_0 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    expected_result_0 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    #test_case_0
    test_result = key_expansion(data_0)

    print(test_result)
    print(expected_result_0)
    

# Generated at 2022-06-26 11:02:15.098064
# Unit test for function key_expansion
def test_key_expansion():
    data_0 = [0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f]

# Generated at 2022-06-26 11:02:25.600355
# Unit test for function key_expansion
def test_key_expansion():
    print("------ Key expansion tests ------")
    # 0.
    data = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    key = key_expansion(data)
    print(key)
    assert len(key) == 176
    assert key[:16] == data
    assert key[16] == 0x62
    assert key[169] == 0x7B
    assert key[175] == 0xD8
    print("PASSED")

    # 1.