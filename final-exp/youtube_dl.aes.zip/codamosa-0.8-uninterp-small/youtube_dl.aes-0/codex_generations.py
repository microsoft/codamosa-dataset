

# Generated at 2022-06-26 10:52:33.809104
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    assert 1 == 1


# Generated at 2022-06-26 10:52:39.064334
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    str_0 = 'ord;'
    str_1 = 'noitces'
    var_0 = key_expansion(str_0)
    var_1 = key_expansion(str_1)
    var_2 = aes_cbc_encrypt(var_0, var_1, var_1)


# Generated at 2022-06-26 10:52:41.735311
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    str_0 = 'a;<X8|'
    str_1 = 'test_data'
    var_0 = aes_ctr_decrypt(str_0, str_1, Counter(0))

# Encrypt the data with the key and IV using AES-128-CTR

# Generated at 2022-06-26 10:52:48.575974
# Unit test for function inc
def test_inc():
    data = [0, 1, 2, 3, 4, 5]
    data_inc = inc(data)

# Generated at 2022-06-26 10:52:50.990527
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    assert aes_cbc_encrypt([0, 0, 0], [0, 0, 0], [0, 0, 0]) == [0, 0, 0]


# Generated at 2022-06-26 10:52:54.623624
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Test case 0
    str_0 = 'ord;'
    var_0 = key_expansion(str_0)
    str_1 = 'aes_encrypt'
    var_1 = aes_encrypt(str_1, var_0)
    assert('ord;' == var_1)


# Generated at 2022-06-26 10:53:05.117303
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    """
    Test that the function aes_ctr_decrypt is working (on unit test data)
    """

# Generated at 2022-06-26 10:53:08.481743
# Unit test for function aes_decrypt
def test_aes_decrypt():
    res_0 = aes_decrypt('\x33\x66\x99\xcc\x33\x66\x99\xcc', '\x00\x01\x02\x03\x00\x01\x02\x03\x00\x01\x02\x03')
    assert res_0 == '\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-26 10:53:21.071012
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-26 10:53:31.738196
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Test Case #0
    print("Test Case #0")

    str_0 = 0x14
    str_1 = 0x3
    str_2 = 0xa
    str_3 = 0x1
    str_4 = 0x0
    str_5 = 0xc
    str_6 = 0x6
    str_7 = 0x9
    str_8 = 0x8
    str_9 = 0x2
    str_10 = 0x7
    str_11 = 0x5
    str_12 = 0xd
    str_13 = 0xb
    str_14 = 0x4
    str_15 = 0x4
    str_16 = 0xe
    str_17 = 0xf
    str_18 = 0x1
    str_19 = 0xd
    str_20 = 0xa
    str

# Generated at 2022-06-26 10:53:40.439893
# Unit test for function inc
def test_inc():
    var_0 = [255, 255, 255, 255]
    var_0 = inc(var_0)
    print('%s' % var_0)


# Generated at 2022-06-26 10:53:48.794976
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    str_0 = 'ord;'
    str_1 = None
    key_size_bytes = 16
    var_0 = key_expansion(str_0)
    var_1 = key_expansion(str_0)
    var_2 = aes_encrypt(var_1, var_0)
    var_3 = aes_decrypt(var_2, var_0)
    var_4 = aes_decrypt_text(str_1, str_0, key_size_bytes)


# Generated at 2022-06-26 10:54:04.585772
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:54:14.849014
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Given
    data = 'eNpLz8/Pz8/TExO/zs7O/z8/Pz+Dg4P///z8/Pz8vL8/Pz8/PDw7+/v7//v79/f39/f39/Pz8'
    password = 'password'
    key_size_bytes = 32

    # When
    actual_text = aes_decrypt_text(data, password, key_size_bytes)

    # Then
    expected_text = 'testing'
    assert actual_text == expected_text



# Generated at 2022-06-26 10:54:26.123598
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    print("Testing aes_cbc_decrypt")
    # Random data
    key = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f'
    data = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f'
    iv = [0]*16
    key_int = bytes_to_intlist(key)
    data_int = bytes_to_intlist(data)
    iv_int = bytes_to_intlist(iv)

# Generated at 2022-06-26 10:54:35.611260
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    str_0 = 'ord;'
    var_0 = key_expansion(str_0)

# Generated at 2022-06-26 10:54:40.408546
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = 'abcdefghijklmnop'
    iv = 'abcdefghijklmnop'
    data = '1234567890123456'
    encrypted = aes_cbc_encrypt(data, key, iv)

    expected = 'Xk+WcNtOIsuwAeZo'
    assert encrypted == expected


# Generated at 2022-06-26 10:54:51.374363
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    str_0 = ('U2FsdGVkX18kFnVUWYnaEwCpjDGPjyHX9qJi3Fv5ny5ov'
             '8V5WzYwCPhep/HNy+x')
    str_1 = '0123456789abcdef'
    str_2 = 'U2FsdGVkX18u9XWU6Q2B1CzDKZl0e0mWlgYmE1iBMhfve'
    var_0 = bytes_to_intlist(compat_b64decode(str_2))
    var_1 = bytes_to_intlist(str_0)
    var_2 = bytes_to_intlist(str_1)
    var_3 = aes_cbc_dec

# Generated at 2022-06-26 10:54:58.258170
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test case 0
    # string str_0 = "order";
    str_0 = 'ord;'
    # byte k0_0 = 0x9C;
    k0_0 = 0x9C
    # byte k0_1 = 0x30;
    k0_1 = 0x30
    # byte k0_2 = 0x35;
    k0_2 = 0x35
    # byte k0_3 = 0xA5;
    k0_3 = 0xA5
    # byte k0_4 = 0xF4;
    k0_4 = 0xF4
    # byte k0_5 = 0x12;
    k0_5 = 0x12
    # byte k0_6 = 0x70;
    k0_6 = 0x70
    # byte k0

# Generated at 2022-06-26 10:55:09.020288
# Unit test for function aes_decrypt

# Generated at 2022-06-26 10:55:26.066539
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test case 0:
    str_0 = 'ord;'
    str_1 = '0'
    str_2 = 'data'
    try:
        var_0 = key_expansion(str_0)
        var_1 = bytes_to_intlist(str_1)
        var_2 = aes_cbc_decrypt(bytes_to_intlist(str_2), var_0, var_1)
        print('''The decrypted data is: ''' + intlist_to_bytes(var_2))
    except:
        print('''Test case failed''')


# Generated at 2022-06-26 10:55:36.878004
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    str_0 = 'C*7[8|\xeeVb\x87\x1a\xc8\xa1\xe7\x9e'
    str_1 = '\x86\x1bq\x8d\xa6\xfa\x1d\x96\xda\xf2\x99\xfc\xab\x82\x8a\xe0\x9b'
    counter = AESCounter()
    var_0 = bytes_to_intlist(compat_b64decode(str_0))
    var_1 = bytes_to_intlist(compat_b64decode(str_1))
    aes_ctr_decrypt(var_0, var_1, counter)


# Generated at 2022-06-26 10:55:44.126239
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    str_0 = 'ord;'
    var_1 = aes_decrypt_text(str_0, str_0, 256)
    str_1 = 'ord;'
    assert var_1 == str_1, "Haxor!"

    str_2 = ''
    assert aes_decrypt_text(str_2, str_0, 256) == str_2


# Generated at 2022-06-26 10:55:51.615174
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]

# Generated at 2022-06-26 10:56:03.377081
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:56:11.650302
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(b'HiIamAKey')
    key = [0xF8, 0xE5, 0x5F, 0x31, 0x9F, 0x2E, 0xEE, 0x8D, 0xE4, 0x42, 0x52, 0x7E, 0x03, 0xEE, 0x1D, 0xE1]
    assert key_expansion(data) == key


# Generated at 2022-06-26 10:56:18.222027
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    str_0 = 'ord;'
    var_0 = key_expansion(str_0)
    str_1 = 'ord;'
    str_2 = 'ord;'
    str_3 = 'ord;'
    str_4 = str_3.join([str_0, str_1, str_2])
    var_1 = aes_decrypt_text(var_0, str_4, 13)
    return var_1

if __name__ == '__main__':
    test_case_0()
    result = test_aes_decrypt_text()
    print(result)

# Generated at 2022-06-26 10:56:29.151368
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Test case 1:
    # Test case 1, encrypted with key '1234567890123456',
    # and counter (IO, block_count), set to (0, 0)
    encrypted_str_1 = ''.join([
        'p8upjK6OvBE6dgU6O9UHV+W6h0Y7w0Er',
        '8ONqW3qNNJnCmZP6o9A8Wk1aYKOF7n/l',
        '/iWzKl3vWEQZTnTZ9rKM/iM='
    ])
    encrypted_bytes_1 = compat_b64decode(encrypted_str_1)
    encrypted_intlist_1 = bytes_to_intlist(encrypted_bytes_1)


# Generated at 2022-06-26 10:56:42.628646
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    str_0 = 'ord;'
    str_1 = 'abc'
    str_2 = 'def'
    str_3 = 'ghi'
    var_0 = key_expansion(str_0)
    var_1 = key_expansion(str_1)
    var_2 = key_expansion(str_2)
    var_3 = key_expansion(str_3)
    var_4 = aes_encrypt(str_1, var_0)
    var_5 = aes_encrypt(str_2, var_1)
    var_6 = aes_encrypt(str_3, var_2)
    var_7 = aes_encrypt(str_0, var_3)
    var_8 = aes_decrypt(var_4, var_0)
   

# Generated at 2022-06-26 10:56:54.466076
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:57:07.626929
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    decrypt_0 = aes_ctr_decrypt('cipher_text', 'key', counter())


# Generated at 2022-06-26 10:57:19.292107
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = '12345678123456781234567812345678'
    key = bytes_to_intlist(compat_b64decode(key))
    data = 'AC29E5EFAF52876A0A2B2C73BDF5FF5A'
    data = bytes_to_intlist(compat_b64decode(data))
    iv = '00000000000000000000000000000000'
    iv = bytes_to_intlist(compat_b64decode(iv))
    result = '01BC1ACB9E9B972717F2D68B8B319D59'
    result = bytes_to_intlist(compat_b64decode(result))
    expanded_key = key_expansion(key)

# Generated at 2022-06-26 10:57:28.447573
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    cleartext = [116, 101, 115, 116]
    key = [0x2e, 0x6a, 0x1d, 0xdc, 0x3e, 0x5d, 0x46, 0xfa, 0x4d, 0x2b, 0x04, 0x02, 0x5f, 0xca, 0xdf, 0xfb]
    iv = [0x81, 0x45, 0xf5, 0x96, 0x55, 0x2e, 0x6d, 0x79, 0xf3, 0xa3, 0xab, 0xcb, 0x03, 0x3c, 0xbb, 0x7c]
    encrypted_data = aes_cbc_encrypt(cleartext, key, iv)
    assert encrypted_data


# Generated at 2022-06-26 10:57:35.322015
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = b"KEesfDew1Oz4tmQ4kU6AeU6oBc6ZiN9KBPLsFAgN1QM="
    password = "hi_there_"
    key_size_bytes = 24
    print(aes_decrypt_text(data, password, key_size_bytes))

# Main body of program

# Generated at 2022-06-26 10:57:44.542586
# Unit test for function aes_decrypt
def test_aes_decrypt():
    input_str = 'abcdef'
    input_str_arr = string_to_array(input_str)
    print(input_str_arr)
    tmp_key = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34]
    output_arr = aes_decrypt(input_str_arr, tmp_key)
    print(output_arr)


# Generated at 2022-06-26 10:57:49.230637
# Unit test for function aes_encrypt
def test_aes_encrypt():
    str_0 = 'ord;'
    str_1 = 'abcdefghijkl'
    # aes_encrypt(data, expanded_key)
    # print(aes_encrypt(str_1, str_0))
    aes_encrypt(str_1, str_0)


# Generated at 2022-06-26 10:57:56.505409
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    input_vector_0 = [42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42]
    input_vector

# Generated at 2022-06-26 10:58:03.485572
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    str_0 = 'ord;'
    var_0 = key_expansion(str_0)
    data = '5OiO'
    data = intlist_to_bytes(data)
    data = [32, 98, 120, 11, 94]
    key = 32, 98, 120, 11, 94
    counter = 0
    result = aes_ctr_decrypt(data, key, counter)
    print(result)
    return result


# Generated at 2022-06-26 10:58:13.303868
# Unit test for function aes_decrypt
def test_aes_decrypt():
    base64_0 = 'jIHyFQ8/viyTRm5UjfZq3g=='
    base64_1 = 'dAbpU0by7H8EXymUuSMBxw=='
    base64_2 = 'Fc4bDQnq3aG00j1Axv4CJg=='
    base64_3 = '+zPCjX9hJcSaOLipYTt8jg=='
    base64_4 = 'lO/Qv+zK9MPJEoO/OLkY8A=='
    base64_5 = '0JbK8+HPeaALuc4Q4Jvp3Q=='

# Generated at 2022-06-26 10:58:22.003063
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    aes_key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    counter = Counter()
    cipher = [0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8, 0xf9, 0xfa, 0xfb, 0xfc, 0xfd, 0xfe, 0xff]
    result = aes_ctr_decrypt(cipher, aes_key, counter)

# Generated at 2022-06-26 10:59:55.346065
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # decrypting the cipher text 'Hello, world'
    print('Test Case 0')
    test_case_0()
    data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    key = 'ord;'
    iv = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    result = aes_cbc_decrypt(data, key, iv)
    print(result)

# function to multiply polynomials in the field {0, 1, x, z}

# Generated at 2022-06-26 11:00:03.561533
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data_0 = "4f03dff4f4b6a7ee"
    key_0 = "0123456789abcdef"
    iv_0 = "0123456789abcdef"
    data_0 = bytes_to_intlist(compat_b64decode(data_0))
    key_0 = bytes_to_intlist(compat_b64decode(key_0))
    iv_0 = bytes_to_intlist(compat_b64decode(iv_0))
    result = aes_cbc_decrypt(data_0, key_0, iv_0)
    result = intlist_to_bytes(result)

# Generated at 2022-06-26 11:00:04.452242
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    test_case_0()



# Generated at 2022-06-26 11:00:10.311002
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    str_0 = "ord;ord;ord;ord;"
    str_1 = "ord"
    str_2 = "ord"
    key = bytes_to_intlist(str_0)
    iv = bytes_to_intlist(str_1)
    str_3 = bytes_to_intlist(str_2)
    str_4 = aes_cbc_decrypt(str_3, key, iv)
    print(str_4) # expect str_2


# Generated at 2022-06-26 11:00:21.797951
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 11:00:24.073382
# Unit test for function aes_decrypt
def test_aes_decrypt():
    str_0 = 'ord;'
    var_0 = aes_decrypt(str_0, key_expansion(str_0))


# Generated at 2022-06-26 11:00:31.878954
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test Case 0

    # T1
    block = bytes_to_intlist("06a9214036b8a15b512e03d534120006")

# Generated at 2022-06-26 11:00:32.589003
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()


# Generated at 2022-06-26 11:00:42.716007
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Given
    e_data = bytes_to_intlist(b'\xa6U\xb6\xcf\x15\xf3i\xd4\x1c\x1e\x03\x2c\x9b\x41\xcd\x16\x05\x54')

# Generated at 2022-06-26 11:00:47.996139
# Unit test for function aes_decrypt
def test_aes_decrypt():
    str_0 = 'ord;'
    var_0 = key_expansion(str_0)
    str_1 = 'ord;'
    var_1 = key_expansion(str_1)
    str_2 = 'ord;'
    var_2 = key_expansion(str_2)
    var_3 = aes_decrypt(var_0, var_1)
    var_4 = aes_decrypt(var_3, var_2)


# Generated at 2022-06-26 11:01:12.495332
# Unit test for function key_expansion
def test_key_expansion():
    print('Testing key_expansion... ', end='')

# Generated at 2022-06-26 11:01:17.387579
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'ord;'
    var_0 = key_expansion(str_0)
    assert(var_0 == 0x6f7264a1fbb95b8f)
    assert(var_0 == 0x6f7264a1fbb95b8f)
    assert(var_0 == 0x6f7264a1fbb95b8f)
    assert(var_0 == 0x6f7264a1fbb95b8f)


# Generated at 2022-06-26 11:01:26.418707
# Unit test for function key_expansion
def test_key_expansion():
    s0 = b'\x54\x68\x61\x74\x73\x20\x6D\x79\x20\x4B\x75\x6E\x67\x20\x46\x75'

# Generated at 2022-06-26 11:01:29.225663
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'ord;'
    var_0 = key_expansion(str_0)
    print(var_0)



# Generated at 2022-06-26 11:01:30.002721
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()



# Generated at 2022-06-26 11:01:42.591052
# Unit test for function key_expansion
def test_key_expansion():
    print_test_case_header(0)

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()

# Test case0
KE_0_INPUT_KEY = 'ord;'

# Generated at 2022-06-26 11:01:54.382786
# Unit test for function key_expansion
def test_key_expansion():
    # test case 0
    str_0 = 'ord;'
    var_0 = key_expansion(str_0)

    # test case 1
    str_1 = 'qjdT'
    var_1 = key_expansion(str_1)

    # test case 2
    str_2 = 'bDdJ'
    var_2 = key_expansion(str_2)

    # test case 3
    str_3 = 'C:-n'
    var_3 = key_expansion(str_3)

    # test case 4
    str_4 = 'E$hp'
    var_4 = key_expansion(str_4)

    # test case 5
    str_5 = 'j(\x0c'
    var_5 = key_expansion(str_5)

    # test case

# Generated at 2022-06-26 11:01:56.147425
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()



# Generated at 2022-06-26 11:01:57.444815
# Unit test for function key_expansion
def test_key_expansion():
    print('Testing function key_expansion')
    test_case_0()



# Generated at 2022-06-26 11:01:59.104053
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()
    print("Test passed")

# test_key_expansion()


# Generated at 2022-06-26 11:02:11.924160
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'ord;'
    var_0 = key_expansion(str_0)
    str_1 = 'ord;'
    var_1 = key_expansion(str_1)

    if (var_0 != var_1):
        return False
    if (var_0 != str_1):
        return False
    if (var_1 != str_0):
        return False
    if (str_0 != str_1):
        return False

    return True


# Generated at 2022-06-26 11:02:12.819019
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()



# Generated at 2022-06-26 11:02:24.448845
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'ord;'
    str_1 = key_expansion(str_0)
    print(str_1)
    str_2 = 'ord;'
    str_3 = key_expansion(str_2)
    print(str_3)
    str_4 = 'o`'
    str_5 = key_expansion(str_4)
    print(str_5)
    str_6 = 'o`'
    str_7 = key_expansion(str_6)
    print(str_7)
    str_8 = 'o]'
    str_9 = key_expansion(str_8)
    print(str_9)
    str_10 = 'o]'
    str_11 = key_expansion(str_10)
    print(str_11)
    str_