

# Generated at 2022-06-26 10:52:37.220232
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    text = aes_decrypt_text('zCALeamwfQ2RN8EJu+iXKQ==', '#%Y*D42', 16)
    assert "This is a test" == text



# Generated at 2022-06-26 10:52:45.597360
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    """
    Tests for aes_cbc_encrypt based off of https://github.com/videolan/vlc/blob/master/share/lua/playlist/youtube.lua
    """
    # Test Case 0
    print('Test Case 0:')
    data = [0x0f, 0x15, 0x71, 0xc9, 0x47, 0xd9, 0xe8, 0x59, 0x0c, 0xb7, 0xad, 0xd6, 0xaf, 0x7f, 0x67, 0x98]

# Generated at 2022-06-26 10:52:54.513586
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text('JxrBs+vLq3PPuJdd5bce7zW8DvI+7mJnCXQ1mveZ8Lk=', 'test', 16) == 'test'
    assert aes_decrypt_text('+ct6Ue8pZr3qjJYAP0uV7g==', 'test', 24) == 'test'
    assert aes_decrypt_text('ot0cwYBmC1QgfzegW+xdvQ==', 'test', 32) == 'test'


#------------------------------------------------------------------------------
# Helper Functions
#------------------------------------------------------------------------------


# Generated at 2022-06-26 10:53:05.031689
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    encrypted = compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')
    key = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    counter = Counter(bytes_to_intlist(compat_b64decode('C0zLd4PQ==')), 0)

    decrypted = intlist_to_bytes(aes_ctr_decrypt(bytes_to_intlist(encrypted), key, counter))

   

# Generated at 2022-06-26 10:53:11.992386
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(b'YELLOW SUBMARINE')
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    initial_counter_value = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]
    class Counter(object):
        def __init__(self, initial_value):
            self.current_value = initial_value
        def next_value(self):
            c = self.current_value
            self.current_value = [c[15] & 0xff] + c[:-1]
            return c
    counter = Counter(initial_counter_value)


# Generated at 2022-06-26 10:53:22.640477
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # input data
    data = 'U2FsdGVkX18SeUNjDNT0v0pX9BPxGx0HWlLfjRcCkIw='
    password = 'test_password'
    key_size_bytes = 16
    # function call
    result = aes_decrypt_text(data, password, key_size_bytes)
    print(result)
    # expected result
    expected = b'Hello World!'
    # compare result
    if not result == expected:
        print("Expected:", expected)
        print("Got:", result)
        print("\nTest FAILED!")
        return False
    # test passed
    print("\nTest PASSED!")
    return True


# Generated at 2022-06-26 10:53:30.725462
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    expanded_key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    data = aes_encrypt(data, expanded_key)
    assert data == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]


# Generated at 2022-06-26 10:53:32.191878
# Unit test for function aes_encrypt
def test_aes_encrypt():
    test_case_0()


# Generated at 2022-06-26 10:53:42.711973
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-26 10:53:47.865519
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 15]) == [0, 0, 0, 16]
    assert inc([0, 0, 255, 0]) == [0, 0, 255, 1]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([15, 15, 255, 255]) == [15, 16, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-26 10:54:05.952794
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:54:15.766362
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'top secret key!')
    iv = bytes_to_intlist(b'iviviviviviviviv')
    data = bytes_to_intlist(b'test123456789')
    expected = bytes_to_intlist(b'\xf7\x0f\x0c\x76\x9f\x71\x60\xff\xd6\xff\x0a\xd7\xad\x7c\x1f\x7c')
    actual = aes_cbc_encrypt(data, key, iv)
    assert (expected == actual)



# Generated at 2022-06-26 10:54:27.139826
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    plain_text = bytes_to_intlist(b'this is a test')
    iv = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]

# Generated at 2022-06-26 10:54:36.140233
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('IiDM/P5o5z5DY1l8f53r7w=='))
    iv = bytes_to_intlist('\x00' * BLOCK_SIZE_BYTES)
    data = [178, 6, 29, 165, 64, 107, 215, 108, 145, 186, 246, 236, 43, 231, 153, 226]
    assert aes_cbc_encrypt(data, key, iv) == [37, 115, 8, 129, 157, 89, 249, 123, 127, 174, 211, 61, 89, 142, 155, 123]

# Generated at 2022-06-26 10:54:45.179192
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    print('test_aes_cbc_decrypt')
    key = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]
    iv = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    data = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    decrypted_data = aes_cbc_decrypt(data, key, iv)
    print(decrypted_data)


# Generated at 2022-06-26 10:54:55.007446
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # print("Testing function aes_decrypt...")
    key = [143,194,34,208,145,203,230,143,177,246,97,206,145,92,255,84]
    data = [82,184,0,115,253,210,233,165,164,90,108,180,251,150,77,66]
    enc_data = [207,231,57,3,176,205,20,14,247,11,197,125,250,252,238,191]
    expanded_key = key_expansion(key)
    decrypted_data = aes_decrypt(data, expanded_key)
    assert decrypted_data == enc_data, "Test case failed!"
    print("Passed all test cases!")


# Generated at 2022-06-26 10:55:05.795218
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:55:11.427694
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytes_to_intlist('GyVhgJPpEjKV7Pbw')
    key = bytes_to_intlist('D8jvcWnRGH7yycoE')
    iv = bytes_to_intlist('zYqhJZ9o5AR5J5I6')
    result = aes_cbc_decrypt(data, key, iv)
    expected = bytes_to_intlist('2123141516171819')
    assert(result == expected)



# Generated at 2022-06-26 10:55:17.229090
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = [0x66, 0x10, 0xE6, 0x6A, 0x2C, 0xF6, 0x2A, 0x6E, 0x10, 0xE6, 0x6A, 0x2C, 0x00, 0x00, 0x00, 0x00]
    key = [0x72, 0xF8, 0x7C, 0x70, 0x3E, 0x3C, 0x96, 0x96, 0x76, 0x6C, 0xFA, 0xFA, 0x9E, 0xF0, 0xA2, 0x6A]

# Generated at 2022-06-26 10:55:26.809211
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist("140b41b22a29beb4061bda66b6747e14")
    iv = bytes_to_intlist("4ca00ff4c898d61e1edbf1800618fb28")
    encrypted_data = bytes_to_intlist("28a226d160dad07883d04e008a7897ee" +
                                      "2e4b7465d5290d0c0e6c6822236e1daa" +
                                      "fb94ffe0c5da05d9476be028ad7c1d81")

# Generated at 2022-06-26 10:55:37.602338
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 10:55:48.347669
# Unit test for function key_expansion
def test_key_expansion():
    test_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 10:55:53.674846
# Unit test for function key_expansion
def test_key_expansion():
    # test case 0
    test_case_0()
    a0 = 0x9A
    a1 = 0x56
    a2 = 0x36
    a3 = 0x16
    a4 = 0x9A
    a5 = 0x56
    a6 = 0x36
    a7 = 0x16
    a8 = 0x9A
    a9 = 0x56
    a10 = 0x36
    a11 = 0x16
    a12 = 0x9A
    a13 = 0x56
    a14 = 0x36
    a15 = 0x16
    key = [a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15]


# Generated at 2022-06-26 10:56:04.074366
# Unit test for function key_expansion
def test_key_expansion():
    data = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 10:56:14.997235
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    test_data_0 = [
        0x2b, 0x28, 0xab, 0x09,
        0x7e, 0xae, 0xf7, 0xcf,
        0x15, 0xd2, 0x15, 0x4f,
        0x16, 0xa6, 0x88, 0x3c,
    ]

# Generated at 2022-06-26 10:56:26.737632
# Unit test for function key_expansion
def test_key_expansion():
    key_expansion_0 = [24, 10, 113, 145, 76, 17, 189, 47, 228, 141, 105, 122, 182, 66, 97, 184]

# Generated at 2022-06-26 10:56:38.493925
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    #expanded_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c, 0xa0, 0xfa, 0xfe, 0x17, 0x88, 0x54, 0x2c, 0xb1, 0x23, 0xa3, 0x39, 0x39, 0

# Generated at 2022-06-26 10:56:48.217790
# Unit test for function key_expansion
def test_key_expansion():
    original_key = bytes_to_intlist(compat_b64decode('W8rPbx')[:16])
    expected_key = bytes_to_intlist(compat_b64decode('W8rPbxKzpqobvbO7FwH0KjQ7upuRgYFVXzH8zzq3xjDdypzGdlHV+1M'))
    assert key_expansion(original_key) == expected_key


# Generated at 2022-06-26 10:56:57.733830
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C,]

# Generated at 2022-06-26 10:57:12.611914
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'0a1b2c3d4e5f6789')
    key_expanded = key_expansion(key)
    assert len(key_expanded) == 44
    assert intlist_to_bytes(key_expanded)[:16] == b'\x0a\x1b\x2c\x3d\x4e\x5f\x67\x89\x0a\x1b\x2c\x3d\x4e\x5f\x67\x89'

# Generated at 2022-06-26 10:57:26.803827
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 1:
    # Test key: 000102030405060708090a0b0c0d0e0f
    # Test cipher: 00112233445566778899aabbccddeeff
    # Test expanded key: 000102030405060708090a0b0c0d0e0f00112233445566778899aabbccddeeff
    test_key = '000102030405060708090a0b0c0d0e0f'
    test_key = test_key.encode('utf8')
    test_key = compat_b64decode(test_key)
    test_key = bytes_to_intlist(test_key)

# Generated at 2022-06-26 10:57:40.367812
# Unit test for function key_expansion
def test_key_expansion():
    test_key = [10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25]
    test_key = bytes_to_intlist(compat_b64decode(test_key))
    test_key_expansion = key_expansion(test_key)


# Generated at 2022-06-26 10:57:43.457114
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(b'Thats my Kung Fu')
    key_expanded = key_expansion(data)
    #print(intlist_to_bytes(key_expanded))


# Generated at 2022-06-26 10:57:52.923754
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode(b'U0hOSS9LeW1mZnBoSkZ3S3Z4eU5Vdw=='))

# Generated at 2022-06-26 10:57:54.015198
# Unit test for function key_expansion
def test_key_expansion():
    string_2 = "Hello, world!"
    var_2 = 0


# Generated at 2022-06-26 10:58:05.504693
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    var_2 = []
    var_2.append(104)
    var_2.append(200)
    var_2.append(27)
    var_2.append(231)
    var_2.append(250)
    var_2.append(9)
    var_2.append(183)
    var_2.append(129)
    var_2.append(109)
    var_2.append(61)
    var_2.append(213)
    var_2.append(149)
    var_2.append(25)
    var_2.append(69)
    var_2.append(164)
    var_2.append(139)
    var_2.append(62)
    var_2.append(114)
    var_2.append

# Generated at 2022-06-26 10:58:14.250440
# Unit test for function key_expansion
def test_key_expansion():
    var_1 = "16-Byte Key"
    var_2 = "24-Byte Key"
    var_3 = "32-Byte Key"
    var_4 = "256-Byte Key"
    var_5 = "218-Byte Key"
    var_6 = "196-Byte Key"
    float_0 = -250.0
    float_1 = -1112.1
    float_2 = -155.2
    float_3 = -1325.3
    float_4 = -991.4
    float_5 = -1566.5
    float_6 = -1333.6
    float_7 = -1050.7
    float_8 = -1845.8
    float_9 = -1396.9
    float_10 = -1203.10
    float_11 = -1115

# Generated at 2022-06-26 10:58:19.271339
# Unit test for function key_expansion
def test_key_expansion():
    print('Testing Key Expansion')
    print('--------------------')

    key = bytes_to_intlist(b"thisisalabkey")
    expected_key = [116, 104, 105, 115, 105, 115, 97, 108, 97, 98, 107, 101, 121]
    expanded_key = key_expansion(key)
    print('Pass: ', expanded_key == expected_key)
    print(' ')


# Generated at 2022-06-26 10:58:30.019491
# Unit test for function key_expansion
def test_key_expansion():
    key = sub_bytes_inv('e13b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855')

# Generated at 2022-06-26 10:58:37.922389
# Unit test for function key_expansion
def test_key_expansion():
    key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    expanded_key = [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    ]


# Generated at 2022-06-26 10:58:59.724528
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode(b'gI2M4q3Gq6A4q6H4q6F4q6D4q6B4q6z4q6x4q6v4q6t4q6r4q6p4q6n4q6l4q6j4q6h4q6f4q6QoOCg=='))

# Generated at 2022-06-26 10:59:01.515731
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 0
    test_case_0()


# Generated at 2022-06-26 10:59:14.803183
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 10:59:26.979289
# Unit test for function key_expansion
def test_key_expansion():
    # key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    # expanded_key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
    #                 0xa0, 0x88, 0x23, 0x2a, 0xfa, 0x54, 0xa3, 0x6c, 0xfe, 0x2c, 0x

# Generated at 2022-06-26 10:59:36.677027
# Unit test for function key_expansion
def test_key_expansion():
    test_key1 = bytes_to_intlist(compat_b64decode("q3X1l6uGNyFaST1rSHKpHg=="))
    test_key2 = bytes_to_intlist(compat_b64decode("5xQS5PJHtL+v5c5fivh4mw=="))
    test_key3 = bytes_to_intlist(compat_b64decode("8W/OeN/teNbR9XQvN8O+RA=="))

    assert key_expansion(test_key1) == bytes_to_intlist(compat_b64decode("SL5n5dOUwZxKqtP2zS5X9g=="))
    assert key_expansion(test_key2) == bytes_to_int

# Generated at 2022-06-26 10:59:46.425241
# Unit test for function key_expansion
def test_key_expansion():
    ret = key_expansion([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])

# Generated at 2022-06-26 10:59:55.988523
# Unit test for function key_expansion
def test_key_expansion():
    var_1 = key_expansion(0.0)

# Generated at 2022-06-26 11:00:05.243733
# Unit test for function key_expansion
def test_key_expansion():
    result = key_expansion([0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f])

# Generated at 2022-06-26 11:00:13.083381
# Unit test for function key_expansion
def test_key_expansion():
    # For function test_case_0
    key1 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
            0xab, 0xf7, 0x15, 0x88, 0x9, 0xcf, 0x4f, 0x3c]

    result = key_expansion(key1)


# Generated at 2022-06-26 11:00:23.650401
# Unit test for function key_expansion
def test_key_expansion():
    # test case 0
    float_0 = 0x8fdc828f0a4ef4c4
    var_0 = aes_encrypt(float_0, key_expansion(float_0))
    # assert that var_0 is the same as 0xf58a9fcb6fff948d
    assert var_0 == 0xf58a9fcb6fff948d
    # test case 1
    float_1 = 0xd51b6c49b6e7e35a027d6a7f6dae2ec9
    var_1 = aes_encrypt(float_1, key_expansion(float_1))
    # assert that var_1 is the same as 0xa7bc1ecc8b2810f633aae2b7ff51d3c1
    assert var_

# Generated at 2022-06-26 11:00:49.057050
# Unit test for function key_expansion
def test_key_expansion():
    case_int_list = [18, 208, 103, 51, 13, 43, 71, 30, 30, 113, 187, 166, 93, 219, 164, 82, 192, 62, 59, 171, 80, 16, 14, 82, 223, 53, 32, 169, 48, 243, 229, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88, 88]

# Generated at 2022-06-26 11:00:56.783948
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode("mFu8E+ZVxPtAjv7Vu1f8gw=="))
    result = key_expansion(key)

    assert len(result) == 240
    assert result[0] == 0x2b
    assert result[239] == 0xb2



# Generated at 2022-06-26 11:01:08.970878
# Unit test for function key_expansion
def test_key_expansion():
    input_key_bytes_0 = bytes_to_intlist("8E73B0F7DA0E6452C810F32B809079E562F8EAD2522C6B7B")
    var_0 = key_expansion(input_key_bytes_0)

# Generated at 2022-06-26 11:01:17.051162
# Unit test for function key_expansion
def test_key_expansion():
    key_0 = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')

# Generated at 2022-06-26 11:01:24.998802
# Unit test for function key_expansion
def test_key_expansion():
    key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17,18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32]

# Generated at 2022-06-26 11:01:30.938422
# Unit test for function key_expansion
def test_key_expansion():
    key = map(ord, compat_b64decode("YWFhYWFhYWFhYWFhYWFhYWFhYWFh"))
    assert bytes_to_intlist(compat_b64decode("YWFhYWFhYWFhYWFhYWFhYWFhYWFhhb2JqZWN0")) == key_expansion(key)


# Generated at 2022-06-26 11:01:43.526554
# Unit test for function key_expansion
def test_key_expansion():
    # Test 1
    key = [2, 17, 168, 131, 150, 200, 9, 109, 188, 109, 91, 11, 67, 10, 239, 28]

# Generated at 2022-06-26 11:01:56.232152
# Unit test for function key_expansion
def test_key_expansion():
    # test_case_0
    key = [0, 0, 0, 0]
    key[0] = 0x2b
    key[1] = 0x7e
    key[2] = 0x15
    key[3] = 0x16

# Generated at 2022-06-26 11:02:07.055304
# Unit test for function key_expansion
def test_key_expansion():
    expanded_key = key_expansion([0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C])

# Generated at 2022-06-26 11:02:19.094207
# Unit test for function key_expansion
def test_key_expansion():
    key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]