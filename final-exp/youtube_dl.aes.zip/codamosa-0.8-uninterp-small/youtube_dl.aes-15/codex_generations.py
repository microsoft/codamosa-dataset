

# Generated at 2022-06-26 10:52:45.223013
# Unit test for function key_expansion

# Generated at 2022-06-26 10:52:54.245997
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    counter = Counter(0)
    actual = aes_ctr_decrypt(data, key, counter)
    expected = [162, 205, 82, 144, 73, 225, 34, 109, 227, 133, 186, 86, 73,
                219, 85, 73]
    assert actual == expected
    print('aes_ctr_decrypt test passed')


# Generated at 2022-06-26 10:53:01.850358
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist('YELLOW SUBMARINE')
    data += [0] * (16 - len(data))
    key = bytes_to_intlist('YELLOW SUBMARINE')
    iv = bytes_to_intlist('YELLOW SUBMARINE')
    expected_value = [89, 69, 76, 76, 79, 87, 32, 83, 85, 66, 77, 65, 82, 73, 78, 69]
    assert aes_cbc_encrypt(data, key, iv) == expected_value



# Generated at 2022-06-26 10:53:10.167923
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:53:12.552251
# Unit test for function inc
def test_inc():
    plaintext = [0] * 16
    expected_plaintext = [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    actual_plaintext = inc(plaintext)
    if expected_plaintext == actual_plaintext:
        print("Test for function inc PASSED")
    else:
        print("Test for function inc FAILED")


# Generated at 2022-06-26 10:53:23.863896
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    print('\nTest aes_cbc_decrypt')
    key = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')
    encrypted = bytes_to_intlist('7649abac8119b246cee98e9b12e9197d')
    iv = bytes_to_intlist('000102030405060708090a0b0c0d0e0f')

    decrypted = bytes_to_intlist('6bc1bee22e409f96e93d7e117393172a')

    decrypted_data = aes_cbc_decrypt(encrypted, key, iv)
    if decrypted_data == decrypted:
        print('aes_cbc_decrypt unit test successful')

# Generated at 2022-06-26 10:53:33.463581
# Unit test for function aes_encrypt
def test_aes_encrypt():
    print("Testing function aes_encrypt")
    # k = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]
    # data = [0x32, 0x43, 0xF6, 0xA8, 0x88, 0x5A, 0x30, 0x8D, 0x31, 0x31, 0x98, 0xA2, 0xE0, 0x37, 0x07, 0x34]

# Generated at 2022-06-26 10:53:38.971702
# Unit test for function key_expansion
def test_key_expansion():
    test_key = '\x00' * 32
    test_expanded_key = '\x00' * 240

    expanded_key = key_expansion(bytes_to_intlist(test_key))
    assert(list(intlist_to_bytes(expanded_key)) == list(test_expanded_key))


# Generated at 2022-06-26 10:53:53.649909
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert(aes_decrypt_text('cgGm1QtJ1aHhEhpuuGg/oSKaxaDZh/4q/zv63rsMD/s=', 'test', 16) == b'Password: test')
    assert(aes_decrypt_text('oi6z582UaVfJ+8rA3VqI6Ws+i7VxFAmHcEzXFvLpjgY=', 'test', 16) == b'Downloading movie file.')

# Generated at 2022-06-26 10:54:04.684240
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    counter = Counter.new(bytes_to_intlist(b'f0f1f2f3f4f5f6f7f8f9fafbfcfdfeff'),
                          bytes_to_intlist(b'2010040318235901'))
    assert (aes_ctr_decrypt(
        bytes_to_intlist(b'69c4e0d86a7b0430d8cdb78070b4c55a'),
        bytes_to_intlist(b'2b7e151628aed2a6abf7158809cf4f3c'),
        counter
    ) == bytes_to_intlist(b'00112233445566778899aabbccddeeff'))


# Generated at 2022-06-26 10:55:08.229460
# Unit test for function inc
def test_inc():
    assert inc([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x01]
    assert inc([0x00, 0x00, 0x00, 0xFF]) == [0x00, 0x00, 0x01, 0x00]
    assert inc([0xFF, 0xFF, 0xFF, 0xFF]) == [0x00, 0x00, 0x00, 0x00]



# Generated at 2022-06-26 10:55:10.515880
# Unit test for function inc
def test_inc():
    assert inc([0]) == [1]
    assert inc([255]) == [0]
    assert inc([1, 255]) == [2, 0]
    assert inc([255, 255]) == [0, 0]
    assert inc([1, 255, 255, 255]) == [2, 0, 0, 0]


# Generated at 2022-06-26 10:55:12.790890
# Unit test for function inc
def test_inc():
    assert inc([1]) == [2]
    assert inc([0xF0, 0xFF, 0xFF]) == [0xF1, 0, 0]
    assert inc([0xFF, 0xFF]) == [0, 0]



# Generated at 2022-06-26 10:55:16.898689
# Unit test for function inc
def test_inc():
    int_0 = inc(1)
    int_1 = inc(255)
    int_2 = inc(2)
    int_3 = inc(127)
    int_4 = inc(128)
    int_5 = inc(0)




# Generated at 2022-06-26 10:55:26.657328
# Unit test for function inc
def test_inc():
    msg =[0x11, 0x22, 0x33, 0x44]

    msg = inc(msg)
    assert(msg == [0x11, 0x22, 0x33, 0x45])

    msg = inc(msg)
    assert(msg == [0x11, 0x22, 0x33, 0x46])

    msg = inc(msg)
    assert(msg == [0x11, 0x22, 0x33, 0x47])

    msg = inc(msg)
    assert(msg == [0x11, 0x22, 0x33, 0x48])

    msg = inc(msg)
    assert(msg == [0x11, 0x22, 0x33, 0x49])

    msg = inc(msg)

# Generated at 2022-06-26 10:55:35.416238
# Unit test for function inc
def test_inc():
    # Test case 0
    byte_0 = 0x0
    byte_1 = 0x1
    byte_2 = 0xFF
    byte_3 = 0xFE
    
    result_0 = [0x1]
    result_1 = [0x2]
    result_2 = [0x0]
    result_3 = [0xFF, 0x0]
    
    assert result_0 == inc([byte_0])
    assert result_1 == inc([byte_1])
    assert result_2 == inc([byte_2])
    assert result_3 == inc([byte_3])


# Generated at 2022-06-26 10:55:38.486742
# Unit test for function inc
def test_inc():
    assert inc(bytearray(b'\x00\x00')) == bytearray(b'\x00\x01')
    assert inc(bytearray(b'\xff\xff')) == bytearray(b'\x00\x00')
    assert inc(bytearray(b'7\xa1\x84')) == bytearray(b'7\xa1\x85')



# Generated at 2022-06-26 10:55:43.338923
# Unit test for function inc
def test_inc():
    array_0 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    array_1 = [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    array_2 = [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    array_3 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]
    array_4 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0]
    array_5

# Generated at 2022-06-26 10:55:51.238912
# Unit test for function key_expansion
def test_key_expansion():
    input_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 10:55:55.332021
# Unit test for function inc
def test_inc():
    assert inc([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x01]
    assert inc([0x00, 0x00, 0x00, 0xFF]) == [0x00, 0x00, 0x01, 0x00]
    assert inc([0x00, 0x00, 0xFF, 0xFF]) == [0x00, 0x01, 0x00, 0x00]
    assert inc([0x00, 0xFF, 0xFF, 0xFF]) == [0x01, 0x00, 0x00, 0x00]
    assert inc([0xFF, 0xFF, 0xFF, 0xFF]) == [0x00, 0x00, 0x00, 0x00]

# Generated at 2022-06-26 10:56:15.322472
# Unit test for function key_expansion

# Generated at 2022-06-26 10:56:21.803782
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist([0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                            0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f])
    expanded_key = key_expansion(key)

# Generated at 2022-06-26 10:56:31.463109
# Unit test for function key_expansion
def test_key_expansion():
    assert aes_encrypt(
        [226, 194, 154, 18, 68, 255, 227, 199, 152, 115, 107, 163, 47, 140,
         176, 217, 136, 145, 167, 47, 70, 122, 27, 10, 232, 207, 182, 76,
         216, 215],
        key_expansion([170, 170, 170, 170, 170, 170, 170, 170, 170, 170,
                       170, 170, 170, 170, 170, 170])
    ) == [0, 2, 64, 192, 208, 160, 160, 160, 160, 160, 160, 160, 160, 160, 160, 160]

# Generated at 2022-06-26 10:56:42.331363
# Unit test for function key_expansion
def test_key_expansion():
    for _ in range(100):
        data = [random.randint(0, 255) for _ in range(32)]
        value = key_expansion(data)

        if not isinstance(value, list):
            print("Expected instance of list, got", type(value))
            break
        if not all(isinstance(item, int) for item in value):
            print("Expected all items of value to be int, got", value)
            break
        if any(item not in range(256) for item in value):
            print("Expected all items of value to be in range 0-255, got", value)
            break

    print("Passed")


# Generated at 2022-06-26 10:56:43.387901
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()


# Generated at 2022-06-26 10:56:45.740395
# Unit test for function key_expansion
def test_key_expansion():
    key_expansion_0 = key_expansion(intlist_to_bytes([]))



# Generated at 2022-06-26 10:56:56.388041
# Unit test for function key_expansion
def test_key_expansion():
    data = '2b7e151628aed2a6abf7158809cf4f3c'
    expected = [
        43, 120, 21, 22, 40, 174, 210, 166, 171, 247, 21, 120, 137, 200, 244,
        243, 44, 43, 120, 21, 22, 40, 174, 210, 166, 171, 247, 21, 120, 137, 200,
        244, 243, 44, 43, 120, 21, 22, 40, 174, 210, 166, 171, 247, 21, 120,
        137, 200, 244, 243, 44, 43, 120, 21, 22, 40, 174, 210, 166, 171, 247,
        21, 120, 137, 200, 244, 243, 44, 43, 120, 21, 22, 40, 174, 210, 166,
        171
    ]

# Generated at 2022-06-26 10:57:05.983695
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'peterhas5cats')
    expanded_key = key_expansion(key)

# Generated at 2022-06-26 10:57:13.060927
# Unit test for function key_expansion
def test_key_expansion():
    key = [int(x) for x in '0f1571c947d9e8590cb7add6af7f6798'.decode('hex')]
    exp_key = [int(x) for x in '0f1571c947d9e8590cb7add6af7f6798'
                                 'a0fafe1788542cb123a339392a6c7605'.decode('hex')]
    assert(key_expansion(key) == exp_key)


# Generated at 2022-06-26 10:57:24.391626
# Unit test for function key_expansion
def test_key_expansion():
    # simple test
    k = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
         0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

    w = key_expansion(k)

# Generated at 2022-06-26 10:57:52.308576
# Unit test for function key_expansion
def test_key_expansion():
    key_size_in_bytes = 32
    cipher_key = [
        0x60, 0x3D, 0xEB, 0x10, 0x15, 0xCA, 0x71, 0xBE, 0x2B, 0x73, 0xAE, 0xF0, 0x85, 0x7D, 0x77, 0x81,
        0x1F, 0x35, 0x2C, 0x07, 0x3B, 0x61, 0x08, 0xD7, 0x2D, 0x98, 0x10, 0xA3, 0x09, 0x14, 0xDF, 0xF4
    ]

# Generated at 2022-06-26 10:58:02.714754
# Unit test for function key_expansion

# Generated at 2022-06-26 10:58:10.531937
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode(b'NkFpTisT+Xs/a0/gCmY0CrQ=='))
    expanded_key = key_expansion(key)
    cipherkey = intlist_to_bytes(expanded_key)

# Generated at 2022-06-26 10:58:17.842304
# Unit test for function key_expansion
def test_key_expansion():
    print('\nUnit test for function key_expansion')
    cipher_key_text = '5468617473206D79204B756E67204675'
    cipher_key = bytes_to_intlist(compat_b64decode(cipher_key_text))

    data = [82, 104, 97, 116, 75]
    float_0 = key_schedule_core(data, 1)
    print('encrypted: ' + str(aes_encrypt(data, cipher_key)))
    print('decrypted: ' + str(aes_decrypt(float_0, cipher_key)))

    print(bytes_to_intlist(b'a'))


# Generated at 2022-06-26 10:58:27.544536
# Unit test for function key_expansion
def test_key_expansion():
    source = intlist_to_bytes([0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C])

# Generated at 2022-06-26 10:58:36.942611
# Unit test for function key_expansion
def test_key_expansion():
    input_key = bytes_to_intlist(b'A' * 32)

# Generated at 2022-06-26 10:58:46.129950
# Unit test for function key_expansion
def test_key_expansion():
    """
    Test key expansion from:
    https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf
    """
    key = bytes_to_intlist(compat_b64decode('gZ6NehLX7DYG9TZ5F1YQMw=='))
    expanded_key = bytes_to_intlist(compat_b64decode('gZ6NehLX7DYG9TZ5F1YQMw5Dm0Vbecu9'))
    assert key_expansion(key) == expanded_key


# Generated at 2022-06-26 10:58:59.773056
# Unit test for function key_expansion
def test_key_expansion():
  assert(key_expansion(bytes_to_intlist("000102030405060708090a0b0c0d0e0f")) == bytes_to_intlist("000102030405060708090a0b0c0d0e0f00112233445566778899aabbccddee00112233445566778899aabbccddee000102030405060708090a0b0c0d0e0f"))

# Generated at 2022-06-26 10:59:13.293191
# Unit test for function key_expansion
def test_key_expansion():
    test_key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]

# Generated at 2022-06-26 10:59:19.301923
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode("q3kA/6gReo0RvgMb+a2jJQ=="))
    expanded_key = bytes_to_intlist(compat_b64decode("v+VuP8o+p7YuL1Y9F+7KWx8IhORwzrbJ2sZh+UpJizbVW+M0mX9QYyvhOyf0JjKw+zOgdgHZdNq/3q06zgOFK9Y9RJdsHhteQJo5/5r5+/K+l1LkvVj0X7spbHwiE5HDOtssg=="))
    assert(key_expansion(key) == expanded_key)

#

# Generated at 2022-06-26 11:00:48.559584
# Unit test for function key_expansion
def test_key_expansion():
    test_key_input = bytes_to_intlist(
        '600db7d846b2f2ac3e1fea5a5f9a534986ee956614ddb19eadd5c8fe5bf15a5461cbd6a9568511633e88b959f6a3a6fb')

    test_key_0 = bytes_to_intlist(
        '600db7d846b2f2ac3e1fea5a5f9a534986ee956614ddb19eadd5c8fe5bf15a5461cbd6a9568511633e88b959f6a3a6fb')

# Generated at 2022-06-26 11:01:01.704696
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = "a9b53f7c38d4877a"
    str_1 = "a9b53f7c38d4877a"
    str_2 = "a9b53f7c38d4877a2c7f69b4"
    str_3 = "a9b53f7c38d4877a2c7f69b4"
    str_4 = "a9b53f7c38d4877a2c7f69b4065b3e0c"
    str_5 = "a9b53f7c38d4877a2c7f69b4065b3e0c"

    assert key_expansion(bytes_to_intlist(b64dec(str_0))) == bytes_to_intlist(b64dec(str_1))


# Generated at 2022-06-26 11:01:13.041849
# Unit test for function key_expansion
def test_key_expansion():
    # Test Case 0
    float_0 = -3052.974
    float_1 = float_0
    var_0 = key_schedule_core(float_0, float_1)
    float_0 = -3001.9717
    float_1 = float_0
    var_1 = key_schedule_core(float_0, float_1)
    float_0 = -2950.9686
    float_1 = float_0
    var_2 = key_schedule_core(float_0, float_1)
    float_0 = -2899.9655
    float_1 = float_0
    var_3 = key_schedule_core(float_0, float_1)
    float_0 = -2848.9624
    float_1 = float_0
    var_4

# Generated at 2022-06-26 11:01:20.797905
# Unit test for function key_expansion
def test_key_expansion():
    # Encrypt with aes in CBC mode. Using PKCS#7 padding
    # @param {int[]} data cipher
    # @param {int[]} key 16/24/32-Byte cipher key
    # @param {int[]} iv 16-Byte IV
    # @returns {int[]} encrypted data
    def test_cbc_encrypt(data, key, iv):
        expanded_key = key_expansion(key)
        block_count = int(ceil(float(len(data)) / BLOCK_SIZE_BYTES))

        encrypted_data = []
        previous_cipher_block = iv
        for i in range(block_count):
            block = data[i * BLOCK_SIZE_BYTES: (i + 1) * BLOCK_SIZE_BYTES]
            remaining_length = BLOCK_

# Generated at 2022-06-26 11:01:30.051296
# Unit test for function key_expansion

# Generated at 2022-06-26 11:01:42.669077
# Unit test for function key_expansion
def test_key_expansion():
    result_0 = key_expansion([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c])

# Generated at 2022-06-26 11:01:54.419314
# Unit test for function key_expansion

# Generated at 2022-06-26 11:02:06.175199
# Unit test for function key_expansion
def test_key_expansion():
    key_16 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    key_24 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]
    key_32 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32]


# Generated at 2022-06-26 11:02:16.490951
# Unit test for function key_expansion
def test_key_expansion():
    # Testcase 0
    data = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-26 11:02:24.574664
# Unit test for function key_expansion
def test_key_expansion():
    key = [48, 189, 86, 133, 83, 10, 86, 218, 31, 127, 232, 66, 55, 193, 6, 135]
    expanded_key = [48, 189, 86, 133, 83, 10, 86, 218, 31, 127, 232, 66, 55, 193, 6, 135,
                    144, 29, 170, 146, 156, 177, 3, 175, 231, 44, 108, 150, 68, 107, 234, 93]

    assert expanded_key == key_expansion(key)

