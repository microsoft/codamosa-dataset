

# Generated at 2022-06-26 10:52:45.058615
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    with open('test_data/test_case_0.txt', 'r') as f:
        data = f.read()

    payload = bytes_to_intlist(compat_b64decode(data))
    key = payload[0:16]
    cipher = payload[16:]

    ctr = Counter()

    decrypted_data = aes_ctr_decrypt(cipher, key, ctr)


# Generated at 2022-06-26 10:52:50.177874
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [0x000000, 0x010101, 0x020202, 0x030303]
    # cipher = [0x000000, 0x000000, 0x001004, 0x000001]
    data = [0x000000, 0x000000, 0x000000, 0x000000]
    expanded_key = [0x000000, 0x010101, 0x020202, 0x030303,
                    0x040404, 0x050505, 0x060606, 0x070707,
                    0x080808, 0x090909, 0x0a0a0a, 0x0b0b0b,
                    0x0c0c0c, 0x0d0d0d, 0x0e0e0e, 0x0f0f0f]
    test_aes_decrypt_0

# Generated at 2022-06-26 10:52:57.517032
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6]
    data = [1,2,3,4,5,6,7,8,9,0,1,2,3,4,5,6]
    iv = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    test = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-26 10:53:04.406768
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    assert bytes_to_intlist(aes_ctr_decrypt(bytes_to_intlist(compat_b64decode(
        'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')),
        bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE')),
        Counter(14))) == bytes_to_intlist(b'Yo')



# Generated at 2022-06-26 10:53:07.928126
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Add your test cases here.
    bool_0 = False
    bool_0 = bool_0
    var_0 = intlist_to_bytes(bool_0)
    var_0 = bytes_to_intlist(var_0)

    assert bool_0 == var_0


# Generated at 2022-06-26 10:53:13.189948
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-26 10:53:23.387823
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    en = b'Q01QIFNpZ25hdHVyZSBGb3IgVW5pZm9ybWl0eQ=='
    de = aes_decrypt_text(en, '-----BEGIN SIGNATURE FOR UNIFORMITY-----', 24)
    assert de == b'In cryptography, a block cipher mode of operation is an algorithm that uses a block cipher to provide an information service such as confidentiality or authenticity. A block cipher by itself is only suitable for the secure cryptographic transformation (encryption or decryption) of one fixed-length group of bits called a block. A mode of operation describes how to repeatedly apply a cipher\'s single-block operation to securely transform amounts of data larger than a block.'


# Generated at 2022-06-26 10:53:33.196770
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    test_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
                0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    test_iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
               0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-26 10:53:39.175262
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-26 10:53:46.927719
# Unit test for function aes_decrypt

# Generated at 2022-06-26 10:54:05.391801
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # TODO: Test case where data is not in blocks
    # Test case where data is less than block size
    # Test case where data is in blocks
    key = bytes_to_intlist(compat_b64decode('mK0wvOhm4lo4LPAcTve2QQ=='))
    iv = bytes_to_intlist(compat_b64decode('sIx3q7VuJGvyj+7pE0XoFw=='))

# Generated at 2022-06-26 10:54:17.714674
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .aes_helper import aes_cbc_encrypt
    from .aes_helper import assert_aes_cbc_decrypt_eq

    # Test vectors from:
    # https://csrc.nist.gov/projects/cryptographic-standards-and-guidelines/example-values#aes

    # Test-key
    exp_key = bytes_to_intlist(compat_b64decode('f5AuxH8Fb+Lh9RimJb6jsQ=='))


# Generated at 2022-06-26 10:54:28.031328
# Unit test for function aes_decrypt
def test_aes_decrypt():
    decoded = aes_decrypt([17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17], [3, 23, 47, 21, 16, 6, 10, 17, 34, 14, 15, 4, 22, 48, 36, 23, 28, 14, 17, 12, 26, 37, 21, 18, 10, 37, 7, 3, 35, 6, 7, 12, 25, 37, 13, 13, 26, 13, 0, 35, 30, 30, 11, 48, 21, 10, 16, 4, 17, 33, 39, 31, 3, 4, 4, 8, 0])
    assert decoded == [252, 189, 51, 120]


# Generated at 2022-06-26 10:54:36.676501
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    cipher_string = b'LW\x8d\xb5\x91\xec\x1c\x12\xf0\x1a\x9f'
    # Convert cipher_string to bytes
    cipher_byte = bytes_to_intlist(cipher_string)
    # Key for decryption
    key = b'\xf6\xa0\xe0\x20\x6d\x7a\x59\x82\xef\xc4\x54\x76\x2c\x20\xe0\xd7\xbe\x1c\x55\x66\x24\x10\x2f\x51\xb2\x2b\x88\x7c\x87\x47\xb4'
    # Convert key to bytes
    key_byte = bytes_to_

# Generated at 2022-06-26 10:54:47.397556
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    cipher = bytes_to_intlist(compat_b64decode('CRIwqt4+szDbqkNY+I0qbNXPg1XLaCM5etQ5Bt9DRFV/xIN2k8Go7jtArLIy' +
                                               'P605b071DL8C+FPYSHOXPkMMMFPAKm+Nsu0nCBMQVt9mlluHbVE/yl6VaBC' +
                                               '3Hvxr3Yrtk4LkA5rs9svCJt5fivE/EHQhzDzDzg2rTVJYtYaZh/uXx+pSlN' +
                                               'zd29Dg=='))

# Generated at 2022-06-26 10:54:55.157888
# Unit test for function aes_decrypt
def test_aes_decrypt():
    info = """
    You can change the test vector and run the test rules as follows:
    bool_0 = []
    var_0 = aes_decrypt(bool_0)
    """
    bool_0 = [239, 221, 150, 238, 125, 227, 246, 177, 203, 242, 193, 79, 225, 164, 244, 65]
    var_0 = aes_decrypt(bool_0, [0] * 240)
    assert var_0 == [255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255]


# Generated at 2022-06-26 10:55:05.967527
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:55:14.108145
# Unit test for function aes_decrypt
def test_aes_decrypt():
    input_data = bytes_to_intlist(compat_b64decode("QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F"))
    KEY = bytes_to_intlist(compat_b64decode("U0VDUkVU"))
    var_0 = aes_decrypt(input_data, key_expansion(KEY))
    print(intlist_to_bytes(var_0))
    if var_0 == bytes_to_intlist(b"SECRET TO BE KEPT PRIVATE"):
        print("passed")
    else:
        print("failed")
        exit(-1)

if __name__ == "__main__":
    test_case_0()
    test_aes_decrypt()

# Generated at 2022-06-26 10:55:25.371432
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = bytes_to_intlist(compat_b64decode('qTt6G6n0EP1MUFz4mDZ6jg=='))
    key = bytes_to_intlist(compat_b64decode('DClou1n4u4sXsP8fkZPQ3Q=='))
    data = bytes_to_intlist(compat_b64decode('NIhm+L8GHGlzMl0TgTv60xM1NpTE/Cd4td4BI4s/mmXsO/b1AiChfp5tAiQV7wW8cYkd7PuEVlhD9i1W8kMgA=='))
    result = aes_cbc_decrypt(data, key, iv)
   

# Generated at 2022-06-26 10:55:36.518113
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = [235, 67, 118, 221, 169, 248, 89, 150, 147, 38, 160, 160, 164, 33, 44, 194]
    key = [87, 152, 43, 165, 161, 111, 116, 151, 253, 156, 33, 208, 204, 210, 125, 109, 19, 183, 23, 24, 70, 108, 96, 203, 0, 84, 159, 85, 194, 101, 46]

# Generated at 2022-06-26 10:55:49.100371
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test case 1
    iv = ['\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00']
    key = ['\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00', '\x00']

# Generated at 2022-06-26 10:56:02.247630
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    var_0 = (0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0)
    var_1 = (0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0)

# Generated at 2022-06-26 10:56:13.326178
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:56:20.620261
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = 'u2FY2ToR9VuTPULkzZVFEw=='
    key = 'a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1ab'
    iv = 'a2a2a2a2a2a2a2a2a2a2a2a2a2a2a2ar'

    result = aes_cbc_decrypt(bytes_to_intlist(compat_b64decode(data)), bytes_to_intlist(key.encode('ascii')), bytes_to_intlist(iv.encode('ascii')))
    assert(result == bytes_to_intlist(b'0123456789abcdef'))

# Generated at 2022-06-26 10:56:30.195202
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:56:43.328416
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    ##############################################################################
    # BEGIN TEST AES_CBC_DECRYPT 0
    # Requires (hex):
    #   key = 2b7e151628aed2a6abf7158809cf4f3c
    #   iv = 3243f6a8885a308d313198a2e0370734
    #   cipher = 7649abac8119b246cee98e9b12e9197d
    #
    # Expects (hex):
    #   plain = 6bc1bee22e409f96e93d7e117393172a
    #
    ##############################################################################
    key_0 = 'key'
    iv_0 = 'iv'
    cipher_0 = 'cipher'


# Generated at 2022-06-26 10:56:54.994681
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:57:05.267312
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():

    # Test case 0
    bool_0 = False
    var_0 = shift_rows_inv(bool_0)
    # Test case 1
    int_0 = 1356
    int_1 = 812488
    str_0 = '3vHxTpTZoa1WZg8hJ6rXyA'
    int_2 = 491
    int_3 = 7389
    int_4 = 7
    int_5 = 68
    int_6 = 6
    str_1 = 'V7FKIBmw5uV7m8qm3qV9UCaLg5uR7l'
    int_7 = 7
    str_2 = 'IV7FKIBmw5uV7m8qm3qV9UCaLg5uR7l'
    int_8

# Generated at 2022-06-26 10:57:16.586817
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key_0 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv_0 = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-26 10:57:18.853837
# Unit test for function inc
def test_inc():
    a = [255, 255, 255, 255]
    assert inc(a) == [0, 0, 0, 0]


# Generated at 2022-06-26 10:57:29.192132
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test with a key of 16 bytes
    key = \
      [0x06, 0xa9, 0x21, 0x40, 0x36, 0xb8, 0xa1, 0x5b,
       0x51, 0x2e, 0x03, 0xd5, 0x34, 0x12, 0x00, 0x06]
    iv = [0x3d, 0xaf, 0xba, 0x42, 0x9d, 0x9e, 0xb4, 0x30,
          0xb4, 0x22, 0xda, 0x80, 0x2c, 0x9f, 0xac, 0x41]

# Generated at 2022-06-26 10:57:42.459548
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
          0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-26 10:57:49.396675
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = intlist_to_bytes(range(16))
    data = intlist_to_bytes(range(32))
    iv = intlist_to_bytes(range(16))

    encrypted = intlist_to_bytes(aes_cbc_encrypt(data, key, iv))
    decrypted = intlist_to_bytes(aes_cbc_decrypt(encrypted, key, iv))

    assert decrypted == data


# Beginning of the output from test_case_0

# Generated at 2022-06-26 10:57:55.804403
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    expanded_key_0 = key_expansion([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])
    decrypted_1 = aes_cbc_decrypt([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31], expanded_key_0, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])

# Generated at 2022-06-26 10:58:07.071540
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    aes_cbc_decrypt([122, 181, 68, 89, 132, 98, 139, 90, 227, 42, 199, 49, 166, 201, 189, 212],
  [89, 158, 110, 227, 30, 25, 5, 109, 251, 47, 142, 73, 211, 176, 18, 194], 
  [146, 129, 122, 134, 203, 236, 166, 175, 137, 226, 129, 170, 113, 188, 242, 13])


# Generated at 2022-06-26 10:58:15.388571
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    assert aes_cbc_decrypt(intlist_to_bytes([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]),
        intlist_to_bytes([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]),
        intlist_to_bytes([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])) == \
      intlist_to_bytes([128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])



# Generated at 2022-06-26 10:58:24.897206
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-26 10:58:35.228944
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    print("Test case 1: ")
    data = '52B8B85AD07BA15C09EBEF05B7A829CBE98A7C2A2A6E7F8A49A6F7E3D3F3A0EA9BC90C96CEF7A2B58F6CD7FC8A456B78A7D3DDEA25C7F8Fded24efca05cd34d43eef1093b2cb46cb0ce7d6c68'
    key = '2B7E151628AED2A6ABF7158809CF4F3C'
    iv = '000102030405060708090A0B0C0D0E0F'
    print("Correc answer is: ")
    print('Incorrect')
   

# Generated at 2022-06-26 10:58:36.442433
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test Case 0
    test_case_0()


# Generated at 2022-06-26 10:58:47.031347
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    test_case = 0

    # test case 0 begins

    var_0 = bytes_to_intlist('8A9F9BDAE34B05A18A63D8EAB2FEA1E3')
    var_1 = bytes_to_intlist('46e3b3c63e3f51b6176d7aa02a6e8921')
    var_2 = aes_cbc_decrypt(var_0, var_1, 0x0)

    test_case += 1

    # test case 0 ends

    # test case 1 begins

    var_0 = bytes_to_intlist('8a9f9bda')
    var_1 = bytes_to_intlist('46e3b3c63e3f51b6176d7aa02a6e8921')
    var_2

# Generated at 2022-06-26 10:58:50.173700
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()


# Generated at 2022-06-26 10:58:54.444247
# Unit test for function key_expansion

# Generated at 2022-06-26 10:59:03.324889
# Unit test for function key_expansion
def test_key_expansion():
    # Initial test cases
    input_list = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 10:59:16.345023
# Unit test for function key_expansion
def test_key_expansion():
    data = [99, 100, 108, 101, 105, 110, 101]

# Generated at 2022-06-26 10:59:28.201216
# Unit test for function key_expansion
def test_key_expansion():
    test_key = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    test_key = key_expansion(test_key)

# Generated at 2022-06-26 10:59:39.502679
# Unit test for function key_expansion
def test_key_expansion():
    from .utils_test import test_value, test_values
    from .utils import bytes_to_intlist, intlist_to_bytes
    key = intlist_to_bytes([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c])
    key = bytes_to_intlist(key)
    expanded_key = key_expansion(key)

# Generated at 2022-06-26 10:59:47.205405
# Unit test for function key_expansion
def test_key_expansion():
    output = [0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe, 0x2b, 0x73, 0xae, 0xf0, 0x85, 0x7d, 0x77, 0x81, 0x1f, 0x35, 0x2c, 0x07, 0x3b, 0x61, 0x08, 0xd7, 0x2d, 0x98, 0x10, 0xa3, 0x09, 0x14, 0xdf, 0xf4]

# Generated at 2022-06-26 10:59:56.516009
# Unit test for function key_expansion
def test_key_expansion():
    # Check the contents of the output arrays (ciphertext and decrypted)
    # with the cipher/decryption performed with Nodejs crypto or by hand
    # to ensure correctness.
    s = 'e000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f'
    key = bytes_to_intlist(compat_b64decode(s))
    result_key_expansion = key_expansion(key)

# Generated at 2022-06-26 11:00:05.827087
# Unit test for function key_expansion

# Generated at 2022-06-26 11:00:13.470212
# Unit test for function key_expansion

# Generated at 2022-06-26 11:00:26.872330
# Unit test for function key_expansion

# Generated at 2022-06-26 11:00:33.264397
# Unit test for function key_expansion
def test_key_expansion():
    test_key = (0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c)

# Generated at 2022-06-26 11:00:43.562854
# Unit test for function key_expansion
def test_key_expansion():
    bool_0 = aes_cbc_encrypt([4, 165, 87, 33, 239, 182, 1, 40, 209, 137, 68, 92, 97, 234, 200, 92, 95, 219, 147, 50, 41, 18, 227, 1, 60, 249, 91, 158, 189, 66, 148], [146, 227, 56, 66, 46, 136, 117, 146, 132, 30, 144, 12, 46, 102, 13, 140, 245, 44, 168, 130, 46, 152, 129, 91], [32, 174, 217, 56, 143, 44, 100, 93, 212, 124, 0, 134, 227, 250, 108, 71])

# Generated at 2022-06-26 11:00:50.109970
# Unit test for function key_expansion
def test_key_expansion():
    data = [ 
            0x54, 0x68, 0x61, 0x74, 0x73, 0x20, 0x6D, 0x79, 0x20, 0x4B, 0x75, 0x6E, 0x67, 0x20, 0x46, 0x75,
    ]


# Generated at 2022-06-26 11:01:03.190023
# Unit test for function key_expansion
def test_key_expansion():
    # Test case for key_expansion when key_size_bytes is 32
    key_0 = bytes_to_intlist("00000000000000000000000000000000")
    key_schedule_0 = key_expansion(key_0)
    test_key_schedule_0 = bytes_to_intlist("000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000")
    assert(key_schedule_0 == test_key_schedule_0)
    # Test case for key_expansion when key_size_bytes is 24
    key_1 = bytes_to_intlist("000000000000000000000000")
    key_schedule_1 = key_expansion(key_1)

# Generated at 2022-06-26 11:01:14.519806
# Unit test for function key_expansion
def test_key_expansion():
    key_size_bytes = 16
    key = [1,2,3,4, 5,6,7,8, 9,10,11,12, 13,14,15,16]

# Generated at 2022-06-26 11:01:28.361932
# Unit test for function key_expansion
def test_key_expansion():
    # Key size is 16 Byte
    key_16 = bytes_to_intlist([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c])

# Generated at 2022-06-26 11:01:40.862191
# Unit test for function key_expansion
def test_key_expansion():
    #Test case 0:
    #key = string(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x10\x11\x12\x13\x14\x15')
    
    key = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x10\x11\x12\x13\x14\x15'
    var = key_expansion(key)
    assert var == b'\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-26 11:01:46.136533
# Unit test for function key_expansion
def test_key_expansion():
    key = "140b41b22a29beb4061bda66b6747e14".decode("hex")
    expanded_key = "140b41b22a29beb4061bda66b6747e14" + "5d0689d783f34e5a3fdbaaf75d6f0d6d".decode("hex")
    assert key_expansion(key) == expanded_key



# Generated at 2022-06-26 11:01:52.958488
# Unit test for function key_expansion

# Generated at 2022-06-26 11:02:11.184216
# Unit test for function key_expansion
def test_key_expansion():
    key = [143, 194, 34, 208, 145, 203, 230, 143, 177, 246, 97, 206, 145, 92, 255, 84]

# Generated at 2022-06-26 11:02:22.807464
# Unit test for function key_expansion