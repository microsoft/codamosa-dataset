

# Generated at 2022-06-26 10:52:55.511010
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = "abcd"
    key = "abcd"
    counter = 0
    decrypted_data = aes_ctr_decrypt(data, key, counter)
    print(decrypted_data)

# test_aes_ctr_decrypt()

# print(aes_ctr_decrypt(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='),
#                       bytes_to_intlist(b'YELLOW SUBMARINE'),
#                       Counter()))


# print(aes_ctr_decrypt(compat_b64decode(b'RKcfVxCb/p6G/i6

# Generated at 2022-06-26 10:52:59.659590
# Unit test for function inc
def test_inc():
    str_0 = inc([255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255])
    str_1 = inc([0, 255, 0, 255, 0, 255, 0, 255, 0, 255, 0, 255, 0, 255, 0, 255])
    assert str_0 == [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    assert str_1 == [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0]


# Generated at 2022-06-26 10:53:08.922800
# Unit test for function aes_decrypt_text

# Generated at 2022-06-26 10:53:19.855631
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # test_0
    str_0 = "L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=="
    var_0 = sub_bytes(str_0)

    var_1 = AESCounter()
    string_0 = "YELLOW SUBMARINE"

    var_2 = "counter=%d\n" % var_1.counter
    output = aes_ctr_decrypt(var_0, var_1, string_0)

    assert(var_2 == "counter=0\n")



# Generated at 2022-06-26 10:53:30.321512
# Unit test for function aes_decrypt
def test_aes_decrypt():
    str_0 = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key_0 = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    str_0 = aes_decrypt(str_0, key_expansion(key_0))
    assert(intlist_to_bytes(str_0) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby ')

test_aes_decrypt()


# Generated at 2022-06-26 10:53:37.498041
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    xx = "01234567"
    encrypted_result = aes_cbc_encrypt(bytes_to_intlist(xx), bytes_to_intlist('0' * 16), bytes_to_intlist('0' * 16))
    #result = intlist_to_bytes(encrypted_result)
    print('result:', result)
    #assert result[0] == '\x10', 'result should be 0x10'


# Generated at 2022-06-26 10:53:46.283430
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-26 10:53:57.542556
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    input_1 = "Hawaii\x06\x06\x06\x06\x06\x06"
    input_2 = bytes_to_intlist(b'Sixteen byte key')
    input_3 = bytes_to_intlist(compat_b64decode(b'OIhSfCk5H5c0jCYQ'))
    output =  bytes_to_intlist(b'\xde0E\x19\xaa\xb1\x9c\x96\xee*\x8f\x08\xea\x92\x1b\x1a\x9b\xbc\x86R\x8d\xb4\xae\x1d\x13\x8e\xb9')

# Generated at 2022-06-26 10:54:05.834591
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(compat_b64decode('QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F'))
    #key = bytes_to_intlist(compat_b64decode('QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F'))
    key = bytes_to_intlist(compat_b64decode('QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F'))
    _ = key_expansion(key)


# Generated at 2022-06-26 10:54:17.907828
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # decrypt the text using your password here
    assert aes_decrypt_text(b"U2FsdGVkX1+sTZBfKjnLzH1Rr6m8n6Ui9UmIjSDb/x/GMi2Zh1/Fz1C/LKjAiP8N", b'1234567890', 16) == b'Hello, world!'
    assert aes_decrypt_text(b"U2FsdGVkX18XBxjxQcHmu1OZvxdEvFClANwUFzsi8AM", b'1234567890', 16) == b'This is a test'

# Generated at 2022-06-26 10:54:34.053816
# Unit test for function aes_decrypt
def test_aes_decrypt():
    assert aes_decrypt([], []) == []
    assert aes_decrypt([0] * 32, [0] * 32) == [0] * 32

# Generated at 2022-06-26 10:54:42.948729
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Prepare test data
    cipher = '6920e299a5202a6d656e636869746f2ee486920e299a5202a6d656e636869746f2e'
    key = '2b7e151628aed2a6abf7158809cf4f3c'
    iv = 'f0f1f2f3f4f5f6f7f8f9fafbfcfdfeff'
    data = bytes_to_intlist(compat_b64decode(cipher))
    key = bytes_to_intlist(compat_b64decode(key))
    iv = bytes_to_intlist(compat_b64decode(iv))

    class CounterTest():
        def __init__(self, iv):
            self.iv = iv


# Generated at 2022-06-26 10:54:53.744258
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-26 10:55:04.837123
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    print('#### test_aes_decrypt_text begin ####')

# Generated at 2022-06-26 10:55:13.302686
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    str_0 = 'U2FsdGVkX1+PDg2u9TvY8rNbLxPxMGJUzV6UfDJmd2w='
    password_0 = 'password'
    str_1 = 'U2FsdGVkX1+PDg2u9TvY8rNbLxPxMGJUzV6UfDJmd2w='
    password_1 = 'password'
    str_2 = 'U2FsdGVkX1+PDg2u9TvY8rNbLxPxMGJUzV6UfDJmd2w='
    password_2 = 'password'

# Generated at 2022-06-26 10:55:24.726896
# Unit test for function aes_decrypt
def test_aes_decrypt():
    print('Unit test for aes_decrypt')
    print('testcase 1:')
    str_0 = 'e06d3183d1415922'
    var_0 = sub_bytes_inv(str_0)
    print('Your result:', var_0)
    print('Expected:', 'f81bc95a99a8b12c')

    print('testcase 2:')
    str_0 = '27b45aa3f3c3fe64'
    var_0 = mix_columns_inv(str_0)
    print('Your result:', var_0)
    print('Expected:', '1cb3aa3e3c3fea44')

    print('testcase 3:')
    str_0 = '1cb3aa3e3c3fea44'
    var_

# Generated at 2022-06-26 10:55:32.994489
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    test_str = ("U2FsdGVkX1+WfC1OZ9Bq3bmv7eluKb8Rw7wAZPtR2v7rW1k8QA7Ma9XbIWrbdjdF")
    key = 'test'
    answer = "Test"
    test_key = aes_decrypt_text(test_str, key, 16)
    assert(answer == test_key)


# Generated at 2022-06-26 10:55:36.356076
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    str_0 = '5468697320697320612074657374'
    var_0 = bytes_to_intlist(compat_b64decode('MzwVuWJ8Dd7RMzrQQ3q+ZaRp/yj1R+W8'))
    assert aes_cbc_decrypt(var_0, bytes_to_intlist(str_0.decode('hex')), [0] * 16) == bytes_to_intlist('Sample plaintext')
    str_0 = '5468697320697320612074657374'
    var_0 = bytes_to_intlist(compat_b64decode('d1YtYB9Xpypz5SZeu5c5z5rw5FoqO2Jw'))


# Generated at 2022-06-26 10:55:40.999988
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'That means, what you can do is to have a 16 bytes long array, and append the above string, so that your array will be 35 bytes long.'
    data_0 = bytes_to_intlist(str_0)
    test_0 = key_expansion(data_0)

# Generated at 2022-06-26 10:55:45.900482
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text(
        'o4y8QsjKFt1ibdzJ2Wf1Zw==',   # encoded
        'test',                     # password
        16                          # key_size_bytes
    ).decode('utf-8') == 'test'

# ----------------------------------------------------------------------------------------------------------------------
# Sub functions


# Generated at 2022-06-26 10:56:00.957240
# Unit test for function aes_decrypt
def test_aes_decrypt():
    assert aes_decrypt(aes_encrypt([0]*16, [0]*16), [0]*16) == [0]*16
    assert aes_decrypt(aes_encrypt([0]*16, [5]*16), [5]*16) == [0]*16
    assert aes_decrypt(aes_encrypt([1, 0]*8, [0]*16), [0]*16) == [1, 0]*8
    assert aes_decrypt(aes_encrypt([1, 0]*8, [2, 3]*8), [2, 3]*8) == [1, 0]*8



# Generated at 2022-06-26 10:56:12.737424
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('DG/N/rjfVqn/tH+SIFLwQ=='))

# Generated at 2022-06-26 10:56:20.546409
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    str_1 = key_expansion(str_0)

# Generated at 2022-06-26 10:56:30.149841
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test Case 0
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-26 10:56:34.753641
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # var_0 = []
    # data_0 = []
    # key_0 = []
    # iv_0 = []
    # var_0 = aes_cbc_decrypt(data_0, key_0, iv_0)
    pass


# Generated at 2022-06-26 10:56:37.542573
# Unit test for function key_expansion
def test_key_expansion():
    int_0 = key_expansion([2, 3, 4, 7])
    int_1 = key_expansion([2, 3, 4, 7])


# Generated at 2022-06-26 10:56:51.404640
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    str_0 = ['0x8C', '0xE6', '0x1D', '0xB9', '0xC4', '0xF8', '0x5B', '0xE0', '0x1E', '0x15', '0xAD', '0x27', '0x6A', '0x11', '0x30', '0xF6', '0x20', '0x12', '0xE6', '0x21', '0x35', '0x9D', '0xE1', '0x70', '0xA1', '0xAC', '0xF1', '0x26', '0x5F', '0xFF']

# Generated at 2022-06-26 10:56:59.214033
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test case 0
    #print("---- Test case 0 ----")
    #print("previous_cipher_block = ")
    #print(previous_cipher_block)
    #print("block = ")
    #print(block)
    #print("key = ")
    #print(expanded_key)
    #print("decrypted_block = ")
    #print(decrypted_block)
    #print("decrypted_data = ")
    #print(decrypted_data)
    data_0 = [0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2, 0x2]
    key_0

# Generated at 2022-06-26 10:57:12.651240
# Unit test for function key_expansion

# Generated at 2022-06-26 10:57:13.146629
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()



# Generated at 2022-06-26 10:57:23.300698
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    str_0 = 'Rxmd0@Q5'
    var_0 = key_expansion(str_0)
    str_1 = 'eJx9U9tu2zgQhf/L1U6I4A=='
    int_0 = len(str_1)
    str_2 = var_0[0]
    str_3 = str_1
    decrypted_data = aes_cbc_decrypt(str_3, str_2, int_0)
    # print(decrypted_data)


# Generated at 2022-06-26 10:57:30.446297
# Unit test for function aes_decrypt

# Generated at 2022-06-26 10:57:43.540728
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    v0 = bytes_to_intlist(compat_b64decode("L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=="))
    v1 = bytes_to_intlist(compat_b64decode("YELLOW SUBMARINE"))
    v2 = bytes_to_intlist([0] * BLOCK_SIZE_BYTES)
    v3 = aes_cbc_decrypt(v0, v1, v2)
    v4 = intlist_to_bytes(v3)
    if v4[:40] == b'I\'m still the king of the castle Cha':
        print(v4)
        print('PASS')

# Unit

# Generated at 2022-06-26 10:57:52.984981
# Unit test for function aes_decrypt
def test_aes_decrypt():
    """
    Test case for function aes_decrypt
    """

    # Test case for aes_decrypt
    # Test case for aes_decrypt
    # Test case for aes_decrypt

    # Function aes_decrypt: Example 1
    data_0 = bytes_to_intlist('a4b4c4d4e4f4a4b4c4d4e4f4a4b4c4d4e4f4a4b4c4d4e4f4')
    key_0 = bytes_to_intlist('000102030405060708090a0b0c0d0e0f1011121314151617')
    expected_0 = bytes_to_intlist('000102030405060708090a0b0c0d0e0f')


# Generated at 2022-06-26 10:57:54.088251
# Unit test for function key_expansion
def test_key_expansion():
    # Test case in C++ project
    test_case_0()


# Generated at 2022-06-26 10:57:54.919453
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()


# Generated at 2022-06-26 10:58:01.830465
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    result = aes_cbc_decrypt(
        bytes_to_intlist('1uFqVxCsW1F8YhX9RhPuag=='),
        bytes_to_intlist('Rxmd0@Q5'),
        bytes_to_intlist('\0' * 16)
    )

    assert intlist_to_bytes(result) == 'c2QFzVd9'



# Generated at 2022-06-26 10:58:11.632792
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Call function
    cipher = [0xc8, 0x41, 0x24, 0xf3,
              0x69, 0xae, 0x2b, 0x4c,
              0xaa, 0xce, 0xe7, 0x32,
              0xbf, 0x9d, 0xae, 0xe0]

# Generated at 2022-06-26 10:58:20.219311
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test case from https://csrc.nist.gov/projects/cryptographic-algorithm-validation-program/block-ciphers#AES
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
          0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]


# Generated at 2022-06-26 10:58:21.529626
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()
    print("TEST PASS")


# Generated at 2022-06-26 10:58:34.430922
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Rxmd0@Q5'

# Generated at 2022-06-26 10:58:45.543026
# Unit test for function key_expansion
def test_key_expansion():
    print('Testing function key_expansion')
    str_0 = 'Rxmd0@Q5'
    str_1 = '84FA1E81C52F28C7F3BE3B9F7EFC8EDB'
    str_2 = 'Rxmd0@Q58F74653E9D6BA9E2CFD8AE8E734E86'
    str_3 = '84FA1E81C52F28C7F3BE3B9F7EFC8EDBAF57D5AFB2E44A30A2F2A22BCD9BCA9E'

# Generated at 2022-06-26 10:58:58.883862
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Rxmd0@Q5'
    var_0 = key_expansion(str_0)
    str_1 = 'Rxmd0@Q5Rxmd0@Q5Ruxmd0@Q5Rxud0@Q5Rxmd0@QlRxmd0@Q5Rxmd0@Q5Ruxmd0@Q5Rxud0@Q5'
    var_1 = key_expansion(str_1)

# Generated at 2022-06-26 10:59:02.711264
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = '0' * 16
    var_0 = key_expansion(str_0)
    assert(var_0 == str_0 * 11)

    test_case_0()



# Generated at 2022-06-26 10:59:15.926813
# Unit test for function key_expansion
def test_key_expansion():
    #print("Running test_key_expansion...")
    key = bytes_to_intlist('8Fvj8cX9q2c0RmIlDzJ92A==')
    expanded_key = key_expansion(key)

# Generated at 2022-06-26 10:59:27.935583
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Rxmd0@Q5'
    var_0 = key_expansion(str_0)
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-26 10:59:39.260162
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Rxmd0@Q5'
    var_0 = key_expansion(str_0)
    str_1 = 'X9yJ0#C5'
    var_1 = key_expansion(str_1)
    str_2 = 'Pm5b9^M6'
    var_2 = key_expansion(str_2)
    str_3 = 'Wd9@9*@o'
    var_3 = key_expansion(str_3)
    str_4 = 'T6b9^X9s'
    var_4 = key_expansion(str_4)
    str_5 = 'R8@j9#X9'
    var_5 = key_expansion(str_5)

# Generated at 2022-06-26 10:59:47.081381
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()

# A dictionary is used to store the test cases for the unit tests
# The number of items in the test cases dictionary will be the number of unit tests
# The name of the function used as the keys of the test cases dictionary are the functions being tested.
# For example, the keys of this dictionary will be the function names to be tested
# The values of the dictionary is a list of tuples
# Each tuple has a pair of values, the first value of the tuple is the expected output.
# The second value of the tuple is a list of inputs

# Generated at 2022-06-26 10:59:49.436879
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Rxmd0@Q5'
    var_0 = key_expansion(str_0)




# Generated at 2022-06-26 10:59:58.102830
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Rxmd0@Q5'
    var_0 = key_expansion(str_0)

# Generated at 2022-06-26 11:00:10.346415
# Unit test for function key_expansion
def test_key_expansion():
    print("test_key_expansion")
    key = 'Rxmd0@Q5'

# Generated at 2022-06-26 11:00:12.409524
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()

# Main function for function key_expansion

# Generated at 2022-06-26 11:00:22.998866
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Rxmd0@Q5'

# Generated at 2022-06-26 11:00:23.883981
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()


# Generated at 2022-06-26 11:00:25.153028
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()


# Generated at 2022-06-26 11:00:26.076558
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()
    return


# Generated at 2022-06-26 11:00:26.905397
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()
    return True



# Generated at 2022-06-26 11:00:35.392873
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Rxmd0@Q5'
    var_0 = key_expansion(str_0)
    var_0_expected = [82, 120, 109, 100, 48, 64, 81, 53, 104, 201, 154, 56, 233, 145, 182, 217, 210, 238, 219, 223, 19, 214, 56, 150, 176, 206, 207, 90, 114, 56, 66, 254, 205, 171, 203, 7, 151, 220, 97, 10, 192, 164, 195, 128, 230, 160, 124, 182, 142, 239, 202, 216, 50, 72, 208]
    assert var_0 == var_0_expected

    str_1 = 'GW6U@F6U'
    var_1 = key_expansion(str_1)

# Generated at 2022-06-26 11:00:36.289452
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()


# Generated at 2022-06-26 11:00:42.392948
# Unit test for function key_expansion
def test_key_expansion():
    """
    Figure out if key_expansion repeats and if it is deterministic.
    """
    str_0 = 'Rxmd0@Q5'
    var_0 = key_expansion(str_0)
    var_1 = key_expansion(str_0)
    var_2 = key_expansion(str_0)

    assert var_0 == var_1
    assert var_0 == var_2
    assert var_1 == var_2


# Generated at 2022-06-26 11:00:49.626363
# Unit test for function key_expansion
def test_key_expansion():
    """
    Test for function key_expansion

    @returns {bool}  True if test successful; False otherwise
    """
    test_case_0()
    return True
    


# Generated at 2022-06-26 11:01:02.666386
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = b'Rxmd0@Q5'
    str_0 = bytes_to_intlist(str_0)
    var_0 = key_expansion(str_0)
    str_1 = b'\xa5\xe0\xae\x7c\x2e\x15\x41\x4b\x44\x8f\xd3\x3c\xc7\x89\x3a\x02'
    str_1 = bytes_to_intlist(str_1)
    assert var_0[0:16] == str_1, "test_key_expansion 1"

# Generated at 2022-06-26 11:01:03.498891
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()


# Generated at 2022-06-26 11:01:07.349796
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()
    # assert var_0 == b'Rxmd0@Q5'


# Generated at 2022-06-26 11:01:10.160976
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Rxmd0@Q5'
    var_0 = key_expansion(str_0)

    
    
    
    
    
    

    

    


# Generated at 2022-06-26 11:01:11.298814
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()

# Unit tests

# Generated at 2022-06-26 11:01:19.467456
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Rxmd0@Q5'
    var_0 = key_expansion(str_0)

# Generated at 2022-06-26 11:01:29.511468
# Unit test for function key_expansion

# Generated at 2022-06-26 11:01:42.084722
# Unit test for function key_expansion
def test_key_expansion():
    assert(key_expansion([0x2B,0x7E,0x15,0x16,0x28,0xAE,0xD2,0xA6,0xAB,0xF7,0x15,0x88,0x09,0xCF,0x4F,0x3C]) == "2b7e151628aed2a6abf7158809cf4f3c2b7e151628aed2a6abf7158809cf4f3c2b7e151628aed2a6abf7158809cf4f3c2b7e151628aed2a6abf7158809cf4f3c".decode('hex'))

# Generated at 2022-06-26 11:01:43.210886
# Unit test for function key_expansion
def test_key_expansion():
    # Test 0
    test_case_0()


# Generated at 2022-06-26 11:01:51.279879
# Unit test for function key_expansion
def test_key_expansion():
    test_0_key = [r,r,r,r]
    test_0_key_expansion = [r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r]
    key_ex = key_expansion(test_0_key)
    assert cmp(test_0_key_expansion, key_ex) == 0

# Generated at 2022-06-26 11:01:53.458673
# Unit test for function key_expansion
def test_key_expansion():
    print("Testing key_expansion...")
    test_case_0()
    print("Passed")
    assert(True == True)



# Generated at 2022-06-26 11:02:04.721361
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Rxmd0@Q5'
    var_0 = key_expansion(str_0)
    assert len(var_0) == 176, 'function key_expansion failed: expected: {0}, actual {1}'.format(176, len(var_0))
    assert var_0[0] == 184, 'function key_expansion failed: expected: {0}, actual {1}'.format(184, var_0[0])
    assert var_0[1] == 207, 'function key_expansion failed: expected: {0}, actual {1}'.format(207, var_0[1])
    assert var_0[2] == 23, 'function key_expansion failed: expected: {0}, actual {1}'.format(23, var_0[2])

# Generated at 2022-06-26 11:02:05.927731
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()

# Unit test

# Generated at 2022-06-26 11:02:06.382331
# Unit test for function key_expansion
def test_key_expansion():
    test_case_0()


# Generated at 2022-06-26 11:02:16.681053
# Unit test for function key_expansion
def test_key_expansion():
    str_0 = 'Rxmd0@Q5'
    var_0 = key_expansion(str_0)

    assert isinstance(var_0, list) is True
    assert len(var_0) == 16
    assert var_0[0] == 82
    assert var_0[15] == 93

    str_1 = 'Bxmd0@Q5'
    var_1 = key_expansion(str_1)

    assert isinstance(var_1, list) is True
    assert len(var_1) == 24
    assert var_1[0] == 66
    assert var_1[15] == 93

    str_2 = 'Tbmd0@Q5'
    var_2 = key_expansion(str_2)

    assert isinstance(var_2, list) is True
   

# Generated at 2022-06-26 11:02:26.564345
# Unit test for function key_expansion
def test_key_expansion():
    # for length 16
    str_0 = 'Rxmd0@Q5'