

# Generated at 2022-06-24 11:21:37.219009
# Unit test for function key_expansion
def test_key_expansion():
    print('Testing function key_expansion')
    key16 = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')
    key24 = bytes_to_intlist('8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b')
    key32 = bytes_to_intlist('603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4')

# Generated at 2022-06-24 11:21:42.846008
# Unit test for function rotate
def test_rotate():
    test = [0x1f, 0x2e, 0x3d, 0x4c]
    expected_result = [0x2e, 0x3d, 0x4c, 0x1f]
    result = rotate(test)
    for i in range(len(result)):
        if expected_result[i] == result[i]:
            print("Right on index ", i)
        else :
            print("Wrong on index ", i)

# Generated at 2022-06-24 11:21:45.822089
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x19, 0xa0, 0x9a, 0xe9]) == [0xd4, 0xe0, 0xb8, 0x1e]

test_sub_bytes()

# Generated at 2022-06-24 11:21:52.705394
# Unit test for function mix_columns
def test_mix_columns():
    a = [0x02, 0x03, 0x01, 0x01,
         0x01, 0x02, 0x03, 0x01,
         0x01, 0x01, 0x02, 0x03,
         0x03, 0x01, 0x01, 0x02]
    b = [0x04, 0x01, 0x05, 0x05,
         0x05, 0x04, 0x01, 0x05,
         0x05, 0x05, 0x04, 0x01,
         0x01, 0x05, 0x05, 0x04]
    assert (mix_columns(a) == b)



# Generated at 2022-06-24 11:21:55.347519
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes(range(16)) == [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]


# Generated at 2022-06-24 11:22:00.426926
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    print("\nUnit Test for sub_bytes_inv")
    test_data = [0x19, 0xa0, 0x9a, 0xe9]
    assert sub_bytes_inv(test_data) == [0xD4, 0x1D, 0x8C, 0xD9], "Substitution error"
    print("Passed unit test for sub_bytes_inv")


# Generated at 2022-06-24 11:22:10.906457
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    output = mix_columns(data)
    assert(output == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01])
    # Function sub_bytes

# Generated at 2022-06-24 11:22:15.610999
# Unit test for function shift_rows
def test_shift_rows():
    test = [0] * 16
    result = shift_rows(test)
    should_be = [0] * 16
    assert result == should_be

    test = [1] + [0] * 15
    result = shift_rows(test)
    should_be = [1] + [0] * 15
    assert result == should_be

    test = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    result = shift_rows(test)
    should_be = [1, 2, 3, 4, 6, 7, 8, 5, 11, 12, 13, 9, 14, 15, 16, 10]
    assert result == should_be

    test = [1] + [0] * 15

# Generated at 2022-06-24 11:22:23.773085
# Unit test for function aes_decrypt
def test_aes_decrypt():
    from pyaes.util import hex_to_string

    data = hex_to_string("00112233445566778899aabbccddeeff")
    key = hex_to_string("000102030405060708090a0b0c0d0e0f")
    expanded_key = key_expansion(key)
    assert aes_decrypt(aes_encrypt(data, expanded_key), expanded_key) == data

    data = hex_to_string("69c4e0d86a7b0430d8cdb78070b4c55a")
    key = hex_to_string("000102030405060708090a0b0c0d0e0f1011121314151617")
    expanded_key = key_expansion(key)
    assert a

# Generated at 2022-06-24 11:22:30.616295
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,   \
           17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32]
    iv = [33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48]
    data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-24 11:22:39.353972
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [
        0x8E, 0x7C, 0xA2, 0x61,
        0x2A, 0x75, 0x14, 0xAA,
        0x30, 0x7A, 0x8C, 0xDB,
        0xA2, 0x69, 0x95, 0x11
    ]
    data_shifted = shift_rows_inv(data)
    data_shifted_expect = [
        0x8E, 0x7C, 0xA2, 0x61,
        0x2A, 0x75, 0x14, 0xAA,
        0x30, 0x7A, 0x8C, 0xDB,
        0xA2, 0x69, 0x95, 0x11
    ]

# Generated at 2022-06-24 11:22:40.727204
# Unit test for function rotate
def test_rotate():
    assert rotate([0, 1, 2, 3]) == [1, 2, 3, 0]
    assert rotate([2, 3, 4, 5]) == [3, 4, 5, 2]


# Generated at 2022-06-24 11:22:49.017486
# Unit test for function key_expansion
def test_key_expansion():
    # Test values taken from http://www.inconteam.com/software-development/41-encryption/55-aes-test-vectors
    Nr = 10
    if(key_size == 128):
        Nr = 10
    elif(key_size == 192):
        Nr = 12
    elif(key_size == 256):
        Nr = 14

    # Test values taken from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf


# Generated at 2022-06-24 11:22:55.296737
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x00, 0x11, 0x22, 0x33]) == [0x63, 0xca, 0xb7, 0x04]



# Generated at 2022-06-24 11:23:02.489388
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    print(aes_cbc_encrypt('abcdefghijklmnopqrstuvwxyz'.encode('ascii'), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15], [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]))



# Generated at 2022-06-24 11:23:11.968267
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert(sub_bytes_inv([0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb])
           == [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f])



# Generated at 2022-06-24 11:23:18.915263
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c,
        0x0d, 0x0e, 0x0f
    ]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c,
          0x0d, 0x0e, 0x0f]

# Generated at 2022-06-24 11:23:25.202814
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    This test only serves to completely cover the function aes_decrypt_text
    """
    password = '1234567890123456'
    aes_decrypt_text('b64', password, 16)
    aes_decrypt_text('b64', password, 24)
    aes_decrypt_text('b64', password, 32)

test_aes_decrypt_text()


# Generated at 2022-06-24 11:23:31.874725
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    input = [0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf]
    result = [0x1, 0x5, 0x9, 0xd, 0x2, 0x6, 0xa, 0xe, 0x3, 0x7, 0xb, 0xf, 0x4, 0x8, 0xc]
    assert(shift_rows_inv(input) == result)

# Generated at 2022-06-24 11:23:34.341565
# Unit test for function rotate
def test_rotate():
    assert rotate([3,1,2,1]) == [1,2,1,3]
    print("All test cases passed")


# Generated at 2022-06-24 11:23:38.468373
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([0x00 for _ in range(16)])) == [0x00 for _ in range(16)]
    assert sub_bytes_inv(sub_bytes([0xFF for _ in range(16)])) == [0xFF for _ in range(16)]



# Generated at 2022-06-24 11:23:41.950391
# Unit test for function rotate
def test_rotate():
    assert rotate([3,4,5,6]) == [4,5,6,3]
    assert rotate([1,2,3,4]) == [2,3,4,1]
    assert rotate([0,1,0,1]) == [1,0,1,0]



# Generated at 2022-06-24 11:23:46.351733
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0x01, 0x01, 0x01, 0x01]
    print("------------------- Unit test for function mix_columns -------------------")
    print("The input data:\n", data)
    print("The result data:\n", mix_columns(data))



# Generated at 2022-06-24 11:23:57.628632
# Unit test for function key_expansion
def test_key_expansion():
    test_key = bytes_to_intlist(compat_b64decode('nhTZW8iKjSHdCi97kXhXnQ=='))

# Generated at 2022-06-24 11:24:05.825968
# Unit test for function key_expansion
def test_key_expansion():
    data = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-24 11:24:13.085981
# Unit test for function key_schedule_core
def test_key_schedule_core():
    test_data = [0x01, 0x02, 0x03, 0x04]
    assert key_schedule_core(test_data, 1) == [0x01, 0x03, 0x04, 0x08]
    assert key_schedule_core(test_data, 2) == [0x01, 0x04, 0x0c, 0x05]



# Generated at 2022-06-24 11:24:22.446055
# Unit test for function key_expansion

# Generated at 2022-06-24 11:24:29.725729
# Unit test for function mix_columns

# Generated at 2022-06-24 11:24:40.193304
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode(b'C0q0H8FwO+b2J1ZhgrRdzC9Xc+fRyIvh'))
    iv = bytes_to_intlist(compat_b64decode(b'Yt+5z5p3/K3pP/o/gJWxs1NMhj1NQMdR'))
    data = bytes_to_intlist(compat_b64decode(b'roflcopter'))

    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-24 11:24:47.949619
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .compat import compat_b64decode
    from .aes_cipher import aes_cipher_decrypt
    from .aes_expanded_key import AESExpandedKey

    class TestCounter(object):
        def __init__(self, counter):
            self.counter = counter
            self.counter_block = None

        def next_value(self):
            if self.counter_block is None:
                self.counter_block = [self.counter & 0xFF, (self.counter >> 8) & 0xFF, (self.counter >> 16) & 0xFF, (self.counter >> 24) & 0xFF]
                self.counter += 1
                return self.counter_block

# Generated at 2022-06-24 11:24:50.201718
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    input_data=[0x29, 0x02, 0x00, 0x00]
    expected_data=[0xa4, 0x4a, 0x4a, 0x4a]
    assert sub_bytes_inv(input_data) == expected_data
    

test_sub_bytes_inv()

# Generated at 2022-06-24 11:24:58.791613
# Unit test for function inc
def test_inc():
    print('Testing function inc')

    input = [0x01] * 16
    expected = [0x02] * 16
    actual = inc(input)
    print("inc([0x01]*16) =", actual)
    print("expected:", expected)
    assert actual == expected, 'inc error'

    input = [0xff] * 16
    expected = [0x00] * 16
    actual = inc(input)
    print("inc([0xff]*16) =", actual)
    print("expected:", expected)
    assert actual == expected, 'inc error'

    input = [0x00, 0x01, 0xff, 0x00]
    expected = [0x00, 0x02, 0x00, 0x01]
    actual = inc(input)

# Generated at 2022-06-24 11:25:00.073007
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]
    result = mix_column(data, MIX_COLUMN_MATRIX)

    print(result)



# Generated at 2022-06-24 11:25:05.677066
# Unit test for function rijndael_mul
def test_rijndael_mul():
    test_input = [0x57, 0x83, 0x4F, 0xAD, 0x4F, 0x7E, 0x82, 0x6F]
    test_output = [0x1E, 0x0E, 0xEA, 0x9B, 0xB1, 0x70, 0xD0, 0x7B]
    for i in range(len(test_input)):
        for j in range(len(test_input)):
            result = rijndael_mul(test_input[i], test_input[j])
            if(test_output[i] != result):
                print('False, ', test_input[i], test_input[j])
                print('result: ', result)
                print('Expected: ', test_output[i])

# Generated at 2022-06-24 11:25:17.209278
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    ciphertext = bytes_to_intlist(compat_b64decode('''
                L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==
                '''))

# Generated at 2022-06-24 11:25:22.437526
# Unit test for function xor
def test_xor():
    assert xor([0x57, 0x0c, 0x90, 0xfa], [0x5d, 0xf0, 0xa0, 0xff]) == [0x0a, 0xfc, 0x30, 0x0f]
    assert xor([0x57, 0x0c, 0x90], [0x5d, 0xf0, 0xa0]) == [0x0a, 0xfc, 0x30]
#test_xor()



# Generated at 2022-06-24 11:25:24.655140
# Unit test for function inc
def test_inc():
    data = [0]
    print(":",[x for x in inc(data)])
    assert(inc(data) == [1])
    data = [255]
    assert(inc(data) == [0])
    data = [1, 255, 0]
    assert(inc(data) == [2, 0, 1])


# Generated at 2022-06-24 11:25:32.832882
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    test_data = bytes((0x29, 0xC4, 0x54, 0x7B, 
                       0xD4, 0x32, 0x4E, 0x08,
                       0xC8, 0x52, 0x7E, 0xD5,
                       0x02, 0xBD, 0x68, 0x9A))
    test_data_inv = shift_rows_inv(test_data)
    test_data2 = shift_rows(test_data_inv)
    if test_data == test_data2:
        pass

# Generated at 2022-06-24 11:25:42.064587
# Unit test for function aes_encrypt

# Generated at 2022-06-24 11:25:52.254103
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-24 11:26:00.688851
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class MyCounter(object):
        def next_value(self):
            return [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    key = [17, 173, 231, 139, 42, 77, 21, 113, 51, 202, 221, 155, 37, 110, 39, 233,
           74, 136, 116, 110, 76, 217, 142, 162, 108, 65, 182, 150, 47, 69, 19, 25]
    counter = MyCounter()
    data = [56] * 32
    data = aes_ctr_decrypt(data, key, counter)
    assert data == [0] * 32



# Generated at 2022-06-24 11:26:07.563455
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]
    expect = [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76, ]
    result = sub_bytes(data)
    if result == expect:
        return True
    else:
        return False



# Generated at 2022-06-24 11:26:17.213908
# Unit test for function key_schedule_core
def test_key_schedule_core():
    # key = 0x2b 0x7e 0x15 0x16 0x28 0xae 0xd2 0xa6 0xab 0xf7 0x15 0x88 0x09 0xcf 0x4f 0x3c
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    core = key_schedule_core(key, 1)
    print("Key Schedule Core:\n", core)
    
    # Check for expected output

# Generated at 2022-06-24 11:26:22.728412
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    encrypted = "Lo0P7wIek22qBvCPtnp0W8hbR0H1Yf+aIpPAeWlxlNTJnfDhAAknsMNuoQ+EkP53"
    plain = "This string should be decoded with the AES-256-CTR algorithm.\n"
    key = "The key should be 32 byte."
    decrypted = aes_decrypt_text(encrypted, key, 32)
    assert decrypted == plain
    return True

# Generated at 2022-06-24 11:26:31.957355
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0x32,0x43,0xf6,0xa8,0x88,0x5a,0x30,0x8d,0x31,0x31,0x98,0xa2,0xe0,0x37,0x07,0x34]

# Generated at 2022-06-24 11:26:39.398370
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    plaintext  = [0x10, 0x11, 0x12, 0x13, 0x20, 0x21, 0x22, 0x23, 0x30, 0x31, 0x32, 0x33, 0x40, 0x41, 0x42, 0x43]
    print("plaintext:", [hex(x) for x in plaintext])
    ciphertext = shift_rows(plaintext)
    print("ciphertext:", [hex(x) for x in ciphertext])
    plaintext_inv = shift_rows_inv(ciphertext)
    print("plaintext_inv:", [hex(x) for x in plaintext_inv])



# Generated at 2022-06-24 11:26:51.033337
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """Unit test for function aes_decrypt_text"""
    print('aes_decrypt_text')
    B64_VALID_INPUT = 'sGmdT9qVnhj8W+7VfvnDhA=='
    B64_INVALID_INPUT = B64_VALID_INPUT + 'x'
    KEY_SIZE_BITS = 128

# Generated at 2022-06-24 11:26:55.119142
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([0x0e])) == [0x0e]
    assert sub_bytes_inv(sub_bytes([0x10])) == [0x10]
    assert sub_bytes_inv(sub_bytes([0xff])) == [0xff]
    assert sub_bytes_inv(sub_bytes([0x00])) == [0x00]
    assert sub_bytes_inv(sub_bytes([0x11])) == [0x11]
test_sub_bytes_inv()



# Generated at 2022-06-24 11:27:06.773405
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = [0x76, 0x49, 0xAB, 0xAC, 0x81, 0x19, 0xB2, 0x46, 0xCE, 0xE9, 0x8E, 0x9B, 0x12, 0xE9, 0x19, 0x7D]
    key = [0xE6, 0x09, 0x6D, 0x67, 0x11, 0x67, 0x67, 0x65, 0x6E, 0x63, 0x65, 0x6D, 0x69, 0x6E, 0x67, 0x6A]
    # plain: {"id":209634,"token":"b8afaf0a060a82ec0b2dc56a59fde55ce60d84b9"}

# Generated at 2022-06-24 11:27:09.123158
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]
    assert rotate([4,3,2,1]) == [3,2,1,4]

test_rotate()



# Generated at 2022-06-24 11:27:16.996388
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x01, 0x02, 0x03, 0x04]
    rcon_iteration = 0
    expected = [0x01, 0x03, 0x05, 0x0f]
    actual = key_schedule_core(data, rcon_iteration)
    assert expected == actual
    data = [0x01, 0x02, 0x03, 0x04]
    rcon_iteration = 1
    expected = [0x02, 0x06, 0x0a, 0x1e]
    actual = key_schedule_core(data, rcon_iteration)
    assert expected == actual
    data = [0x01, 0x02, 0x03, 0x04]
    rcon_iteration = 2

# Generated at 2022-06-24 11:27:23.837904
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key1 = [0, 0, 0, 0]
    key2 = [0xFF, 0xFF, 0xFF, 0xFF]
    key1_out = [0x01, 0x00, 0x00, 0x00]
    key2_out = [0x01, 0x00, 0x00, 0x00]
    assert(key_schedule_core(key1, 0) == key1_out)
    assert(key_schedule_core(key2, 0) == key2_out)



# Generated at 2022-06-24 11:27:30.127965
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    print('Unit test for shift_rows_inv')

# Generated at 2022-06-24 11:27:35.039144
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x00,0x00,0x00,0x00]
    rcon_iteration = 1
    assert key_schedule_core(data, rcon_iteration) == [0x01,0x00,0x00,0x00]

test_key_schedule_core()



# Generated at 2022-06-24 11:27:38.918833
# Unit test for function xor
def test_xor():
    assert xor([0xFF, 0x23, 0xA7, 0x1C], [0xA3, 0xC0, 0x23, 0x1B]) == [0x5C, 0xE3, 0x84, 0x07]
    print('Test xor passed!')



# Generated at 2022-06-24 11:27:50.014836
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test for aes_decrypt_text
    Test for every possible key size (128-Bit, 192-Bit and 256-Bit)
    """
    encodedData = "fZl7m3mq3Zez7VOKFgDcUPn0Htq3X9YGQIjZ2cTZ92tT0RERERERERERERERr"
    encodedData = encodedData.decode('base64')
    password = "password".encode('utf-8')
    key_size_bytes1 = 16
    key_size_bytes2 = 24
    key_size_bytes3 = 32

    decryptedData1 = aes_decrypt_text(encodedData, password, key_size_bytes1)

# Generated at 2022-06-24 11:28:01.561216
# Unit test for function key_expansion
def test_key_expansion():
    key_cipher = []
    cipher_key = []
    # Test Vectors with keys of length 16 bytes
    test_key_cipher = [
        "000102030405060708090a0b0c0d0e0f",
        "d6aa74fdd2af72fadaa678f1d6ab76fe",
        "b692cf0b643dbdf1be9bc5006830b3fe",
        "b6ff744ed2c2c9bf6c590cbf0469bf41",
        "47f7f7bc95353e03f96c32bcfd058dfd"]

# Generated at 2022-06-24 11:28:06.189240
# Unit test for function mix_columns
def test_mix_columns():
    column = [10, 2, 3, 25]
    column_mixed = mix_column(column, MIX_COLUMN_MATRIX)
    print("[10, 2, 3, 25] mixed is: " + str(column_mixed))
    assert(column_mixed == [26, 64, 27, 119])

# Generated at 2022-06-24 11:28:18.429973
# Unit test for function mix_columns
def test_mix_columns():
    # 4x4 matrix
    test_data1 = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result1 = mix_columns(test_data1)
    expected1 = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    print('unit test 1: ', result1 == expected1)

    # 4x1 matrix

# Generated at 2022-06-24 11:28:28.340761
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert (mix_columns(data) == data)
    data = [0xdb, 0x13, 0x53, 0x44, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]

# Generated at 2022-06-24 11:28:32.813633
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert shift_rows_inv(shift_rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]



# Generated at 2022-06-24 11:28:34.650196
# Unit test for function inc
def test_inc():
    print("Unit Test 1")
    print("Unit Test 2")
    print("Unit Test 3")
    print("Unit Test done!")



# Generated at 2022-06-24 11:28:38.946436
# Unit test for function sub_bytes
def test_sub_bytes():
    print("Testing sub_bytes....")
    a = [0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xaa,0xbb,0xcc,0xdd,0xee,0xff]
    b = sub_bytes(a)
    if (b != [0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76]):
        print("Test failed.")


# Generated at 2022-06-24 11:28:47.568147
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = [0] * 16

    data = [0] * 16 * 2
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    decrypted_data = aes_cbc_decrypt(encrypted_data, key, iv)
    assert data == decrypted_data

    data = bytes_to_intlist(b'message')
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    decrypted_data = aes_cbc_decrypt(encrypted_data, key, iv)
    assert data == decrypted_data



# Generated at 2022-06-24 11:28:56.377542
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns(data)
    if data_mixed == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]:
        return True
    else:
        return False


# Generated at 2022-06-24 11:29:08.119049
# Unit test for function key_expansion
def test_key_expansion():
    # AES-128
    assert (bytes_to_intlist(compat_b64decode(
        'NkJCa2NvbTlmQ2t2NkFyRG91bHpMVXhJaEZmTlZrc0tTd3FxMGxr'
        'RzJVeCtZaG9zdVB6ZW1nZ2lsQVRSd1c=')) ==
        key_expansion(bytes_to_intlist(compat_b64decode(
            'NkJCa2NvbTlmQ2t2NkFyRG91bHpMVXhJaEZmTlZrc0tTd3FxMGxr'))))

    # AES-192

# Generated at 2022-06-24 11:29:09.317811
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    for i in range(256):
        assert SBOX_INV[SBOX[i]] == i



# Generated at 2022-06-24 11:29:17.440940
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert shift_rows_inv([0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]) == [0x63, 0x53, 0xe0, 0x8c, 0x09, 0xd0, 0xba, 0x04, 0xcd, 0xe7, 0x70, 0x51, 0x60, 0xe1, 0xb7, 0xca]



# Generated at 2022-06-24 11:29:26.634131
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xDB, 0x13, 0x53, 0x45,
            0xF2, 0x0A, 0x22, 0x5C,
            0x01, 0x01, 0x01, 0x01,
            0x01, 0x01, 0x01, 0x01]
    answer = [0x8E, 0x4D, 0xA1, 0xBC,
              0x9F, 0xDC, 0x58, 0x9D,
              0x01, 0x01, 0x01, 0x01,
              0x01, 0x01, 0x01, 0x01]
    result = mix_columns(data)
    if result == answer:
        print("Correct")
    else:
        print("Incorrect")



# Generated at 2022-06-24 11:29:36.292022
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data1 = [0x63, 0x7c, 0x77, 0x7b,
            0xf2, 0x6b, 0x6f, 0xc5,
            0x30, 0x01, 0x67, 0x2b,
            0xfe, 0xd7, 0xab, 0x76]
    data2 = [0x5f, 0x72, 0x64, 0x15,
            0x57, 0xf5, 0xbc, 0x92,
            0xf7, 0xbe, 0x3b, 0x29,
            0x1d, 0xba, 0x0b, 0xa0]

# Generated at 2022-06-24 11:29:41.509622
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0, 255):
        for j in range(0, 255):
            if (i * j) % 0xFF != rijndael_mul(i, j):
                print(j, "*", i, "=", i * j)
                return False
    return True



# Generated at 2022-06-24 11:29:52.203977
# Unit test for function aes_decrypt_text

# Generated at 2022-06-24 11:29:57.723714
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]
    assert rotate([1, 2, 3, 4, 5, 6, 7, 8]) == [2, 3, 4, 5, 6, 7, 8, 1]



# Generated at 2022-06-24 11:30:04.393917
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist(b'01234567012345670123456701234567')
    iv = bytes_to_intlist(b'00000000000000000000000000000000')
    data = bytes_to_intlist(b'000102030405060708090a0b0c0d0e0f')
    ciphertext = aes_cbc_encrypt(data, key, iv)
    text = aes_cbc_decrypt(ciphertext, key, iv)
    assert text == data



# Generated at 2022-06-24 11:30:14.971526
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    plain = 'Basic CBC mode encryption needs padding.'
    plain = bytes_to_intlist(plain.encode('utf-8'))

# Generated at 2022-06-24 11:30:25.304583
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Sample data, cipher key and encrypted data
    data = bytes_to_intlist(b'Counter must be 16 bytes!')
    sample_key = bytes_to_intlist(b"01234567890123450123456789012345")
    sample_counter = Counter(bytes_to_intlist(b"1234567890abcdef"))

    # Encrypt data
    encrypted_data = aes_encrypt(data, key_expansion(sample_key))
    # Decrypt encrypted data
    decrypted_data = aes_ctr_decrypt(encrypted_data, sample_key, sample_counter)
    # Check if decrypted data equals data
    assert intlist_to_bytes(decrypted_data) == b'Counter must be 16 bytes!'


# Generated at 2022-06-24 11:30:29.677557
# Unit test for function xor
def test_xor():
    assert xor([0x11,0x22,0x33,0x44],[0x44,0x33,0x22,0x11])==[0x55,0x11,0x11,0x55]



# Generated at 2022-06-24 11:30:34.562399
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    decrypted_data = aes_cbc_decrypt(TEST_CIPHER_BYTES, TEST_AES_KEY, TEST_IV)
    assert intlist_to_bytes(decrypted_data) == TEST_DATA_BYTES



# Generated at 2022-06-24 11:30:41.628418
# Unit test for function xor
def test_xor():
    assert xor([0, 0, 0, 0], [0, 0, 0, 0]) == [0, 0, 0, 0]
    assert xor([0, 0, 0, 0], [1, 1, 1, 1]) == [1, 1, 1, 1]
    assert xor([1, 0, 0, 0], [0, 1, 0, 0]) == [1, 1, 0, 0]
    assert xor([1, 0, 0, 0], [0, 1, 1, 1]) == [1, 1, 1, 1]
# An additonal test of xor can be seen in test_expand_key() (below)



# Generated at 2022-06-24 11:30:47.346078
# Unit test for function aes_encrypt
def test_aes_encrypt():
    test_key = "000102030405060708090A0B0C0D0E0F"
    test_data = "00112233445566778899AABBCCDDEEFF"

# Generated at 2022-06-24 11:30:56.244143
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-24 11:31:03.863715
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76]
    data_shifted = [0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76]
    data_shifted = shift_rows_inv(data_shifted)
    assert(data == data_shifted)
    
test_shift_rows_inv()

#

# Generated at 2022-06-24 11:31:12.987193
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import random
    import unittest

    class Counter:
        def __init__(self):
            self.i = 0

        def next_value(self):
            result = []
            for i in range(BLOCK_SIZE_BYTES):
                result.insert(0, (self.i & 0xff000000) >> 24)
                self.i <<= 8
            return result

    class TestAesCtrDecrypt(unittest.TestCase):
        def setUp(self):
            self.key = [random.randint(0, 255) for i in range(BLOCK_SIZE_BYTES)]
            self.data = [random.randint(0, 255) for i in range(1000)]
            self.counter = Counter()

        def test_aes_ctr_decrypt(self):
            encrypted = a

# Generated at 2022-06-24 11:31:14.926160
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x13) == 0xfe



# Generated at 2022-06-24 11:31:26.209587
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x00]
    assert sub_bytes([0x01, 0x01, 0x01, 0x01]) == [0x4D, 0x4D, 0x4D, 0x4D]
    assert sub_bytes([0x02, 0x02, 0x02, 0x02]) == [0x98, 0x98, 0x98, 0x98]
    assert sub_bytes([0x03, 0x03, 0x03, 0x03]) == [0x11, 0x11, 0x11, 0x11]