

# Generated at 2022-06-24 11:21:33.857059
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    counter = Counter()
    key = [0x00] * 16
    data = [0x00] * 16
    expanded_key = key_expansion(key)
    cipher_counter_block = aes_encrypt(counter.next_value(), expanded_key)
    decrypted_data = aes_ctr_decrypt(data, key, counter)
    assert decrypted_data == [0] * 16



# Generated at 2022-06-24 11:21:44.389240
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .crypto import aes_decrypt
    from .aes_counter_mode import AESCounterMode
    for key_length in [16, 24, 32]:
        for data_length in range(1, 32 + 1):
            class TestCounter(object):
                def __init__(self):
                    self.ctr = bytes_to_intlist(compat_b64decode('AAAAAAAAAAAAAAAA'))
                def next_value(self):
                    ret = self.ctr
                    self.ctr = list(map(lambda x: x + 1, self.ctr))
                    return ret
            counter = TestCounter()
            key = bytes_to_intlist(b'0' * key_length)
            data = bytes_to_intlist(b'0' * data_length)

# Generated at 2022-06-24 11:21:47.980679
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3,4]) == [2,3,4,1]
    assert rotate([]) == []
    assert rotate(['a','b','c']) == ['b', 'c', 'a']
test_rotate()



# Generated at 2022-06-24 11:21:53.412074
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    cipher = 'AAEAAHOrKDpBbwfzgCiBJAe06vZ9lX9gxFZ8KdWQYQs'
    password = 'This is a password'
    key_size_bytes = 24
    expected_plaintext = 'This is some test text'

    actual_plaintext = aes_decrypt_text(cipher, password, key_size_bytes)
    if actual_plaintext != expected_plaintext:
        raise AssertionError('Expected: ' + expected_plaintext +
                             '\nActual: ' + actual_plaintext)



# Generated at 2022-06-24 11:21:57.284463
# Unit test for function mix_column
def test_mix_column():
    a = [0xdb, 0x0f, 0x2b, 0xe8]
    b = [0x01, 0x01, 0x01, 0x01]
    c = mix_column(a, MIX_COLUMN_MATRIX)
    print("c = ", c)
    assert(c == b)
    d = mix_column(b, MIX_COLUMN_MATRIX_INV)
    print("d = ", d)
    assert(d == a)


# Generated at 2022-06-24 11:22:00.585222
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x00, 0x12, 0x52, 0xFF]) == [0x63, 0x08, 0x05, 0xA5]
#TODO Unit test for function sub_bytes
# print("sub_bytes" + str(sub_bytes([0x00, 0x12, 0x52, 0xFF])))


# Generated at 2022-06-24 11:22:08.312958
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test_vec = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
    data_mixed = mix_columns(test_vec)
    data_unmixed = mix_columns_inv(data_mixed)
    if (test_vec != data_unmixed):
        print("Test failed")
        print(test_vec)
        print(data_mixed)
        print(data_unmixed)
    else:
        print("Test passed")



# Generated at 2022-06-24 11:22:14.469704
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(b'0123456789abcdef')
    iv = bytes_to_intlist(b'fedcba9876543210')
    data = bytes_to_intlist(b'f2ae6b1e19c9c6e7')
    expanded_key = key_expansion(key)
    cipher = aes_cbc_encrypt(data, expanded_key, iv)
    decrypted = aes_cbc_decrypt(cipher, key, iv)
    assert decrypted == data


# Generated at 2022-06-24 11:22:16.890677
# Unit test for function rotate
def test_rotate():
    assert rotate((0, 1, 2, 3, 4, 5, 6, 7, 8, 9)) == (1, 2, 3, 4, 5, 6, 7, 8, 9, 0)



# Generated at 2022-06-24 11:22:18.777718
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
    data_shifted = shift_rows_inv(data)
    print(data_shifted)



# Generated at 2022-06-24 11:22:30.000047
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Reference test vectors from FIPS-197
    # http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf

    key = bytes_to_intlist(compat_b64decode('2b7e151628aed2a6abf7158809cf4f3c'))
    plaintext = bytes_to_intlist(compat_b64decode('6bc1bee22e409f96e93d7e117393172a'))
    iv = bytes_to_intlist(compat_b64decode('000102030405060708090A0B0C0D0E0F'))

# Generated at 2022-06-24 11:22:34.630780
# Unit test for function inc
def test_inc():
    data = [x for x in range(16)]
    for i in range(16):
        assert inc(data)[i] == i + 1
    assert inc(data)[0] == 0
    assert inc(data)[1] == 0
    assert inc(data)[2] == 0
    assert inc(data)[3] == 0
    data = data[::-1]  # reverse data
    for i in range(16):
        assert inc(data)[i] == i + 1

test_inc()



# Generated at 2022-06-24 11:22:40.533238
# Unit test for function inc
def test_inc():
    inp = [0, 0, 0, 0]
    data = inc(inp)
    assert(data == [0, 0, 0, 1])
    data = inc(data)
    assert(data == [0, 0, 1, 0])
    data = inc(data)
    assert(data == [0, 0, 1, 1])
    data = inc(data)
    assert(data == [0, 0, 2, 0])
    data = inc(data)
    assert(data == [0, 0, 2, 1])
    data = inc(data)
    assert(data == [0, 0, 3, 0])
    data = inc(data)
    assert(data == [0, 0, 3, 1])
    data = inc(data)
    assert(data == [0, 0, 4, 0])


# Generated at 2022-06-24 11:22:49.939554
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    modified = [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]
    assert sub_bytes(data) == modified


# Generated at 2022-06-24 11:22:56.103610
# Unit test for function inc
def test_inc():
    i = 0
    while i < 256:
        data = [0] * 16
        data[15] = i
        inc(data)
        if data[15] != i + 1:
            print("Error at: " + str(i))
        i += 1


# Generated at 2022-06-24 11:22:58.904485
# Unit test for function rijndael_mul
def test_rijndael_mul():
  if (rijndael_mul(0x57, 0x83) != 0xC1 or rijndael_mul(0x13, 0x53) != 0xFE or
  rijndael_mul(0xCA, 0xD3) != 0x27 or rijndael_mul(0xD3, 0x9B) != 0x20):
    return False
  return True



# Generated at 2022-06-24 11:22:59.920134
# Unit test for function rotate
def test_rotate():
    assert rotate([2, 3, 4, 5]) == [3, 4, 5, 2]



# Generated at 2022-06-24 11:23:08.497644
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = "Hello World".encode('utf-8')
    key = bytes_to_intlist("YELLOW SUBMARINE")
    iv = [0] * 16
    encrypted = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted) == b'\xc6\xe8\xdb\x8a\xa2\x0a\x36\x45\xcc\x66\x72\x8a\x3d\xa7\x5a\x5d'
    # assert intlist_to_bytes(encrypted) == b'\x4B\xFB\xA6\x07\xE8\x63\x20\xF5\x8B\xE5\xB7\x30\x53\xC8\x22

# Generated at 2022-06-24 11:23:12.656280
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xDB, 0x13, 0x53, 0x45,
            0xF2, 0x0A, 0x22, 0x5C,
            0x01, 0x01, 0x01, 0x01,
            0x01, 0x01, 0x01, 0x01]
    expected = [0x8E, 0x4D, 0xA1, 0xBC,
                0x9F, 0xDC, 0x58, 0x9D,
                0x01, 0x00, 0x00, 0x00,
                0x01, 0x00, 0x00, 0x00]
    assert mix_columns(data) == expected



# Generated at 2022-06-24 11:23:18.481670
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    ciphertext1 = [0x76, 0x49, 0xab, 0xac, 0x81, 0x19, 0xb2, 0x46, 0xce, 0xe9, 0x8e, 0x9b, 0x12, 0xe9, 0x19, 0x7d]

# Generated at 2022-06-24 11:23:28.732261
# Unit test for function mix_columns
def test_mix_columns():
    a = [0x02, 0x03, 0x01, 0x01, 0x01, 0x02, 0x03, 0x01, 0x01, 0x01, 0x02, 0x03, 0x03, 0x01, 0x01, 0x02]
    b = [0x04, 0x01, 0x05, 0x05, 0x05, 0x04, 0x01, 0x05, 0x05, 0x05, 0x04, 0x01, 0x01, 0x05, 0x05, 0x04]
    c = mix_columns(a)
    print(c)
    d = mix_columns(b, matrix=MIX_COLUMN_MATRIX_INV)
    print(d)
    print(xor(c, d))


# Generated at 2022-06-24 11:23:30.278081
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0xFF):
        for j in range(0xFF):
            assert(rijndael_mul(i,j) == multiply(i,j))

test_rijndael_mul()


# Generated at 2022-06-24 11:23:41.113879
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    test_key = [
        0x2B,0x7E,0x15,0x16,0x28,0xAE,0xD2,0xA6,
        0xAB,0xF7,0x15,0x88,0x09,0xCF,0x4F,0x3C
    ]
    test_iv = [
        0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,
        0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F
    ]

# Generated at 2022-06-24 11:23:46.830511
# Unit test for function shift_rows
def test_shift_rows():
    plaintext = '00112233445566778899aabbccddeeff'
    plaintext = [int(plaintext[i:i + 2], 16) for i in range(len(plaintext)) if i % 2 == 0]
    plaintext = shift_rows(plaintext)
    print(plaintext)
    plaintext = shift_rows_inv(plaintext)
    print(plaintext)



# Generated at 2022-06-24 11:23:51.924171
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # '0123456789' in Base64
    data = bytes_to_intlist(compat_b64decode('MDEyMzQ1Njc4OQ=='))

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * BLOCK_SIZE_BYTES)
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    print('encrypted_data: {encrypted_data}'.format(**locals()))

# Generated at 2022-06-24 11:24:01.041118
# Unit test for function inc
def test_inc():
    arg = [0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0]
    expected = [0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1]
    assert(inc(arg) == expected)

    arg = [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF]
    expected = [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x0]
    assert(inc(arg) == expected)


# Generated at 2022-06-24 11:24:10.681344
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Example from WEB
    cipher = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    iv = bytes_to_intlist(compat_b64decode('\x00' * 16))
    expanded_key = key_expansion(key)
    data = aes_cbc_decrypt(cipher, key, iv)

# Generated at 2022-06-24 11:24:14.358492
# Unit test for function mix_column
def test_mix_column():
    data = [0x57, 0x65, 0x2B, 0xB9]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    print(data_mixed)
    assert data_mixed == [0xCB, 0x2D, 0x91, 0xD0]
    print("Mix column: pass") 


# Generated at 2022-06-24 11:24:22.954905
# Unit test for function sub_bytes
def test_sub_bytes():
    test_vector = [0x03, 0xca, 0x00, 0xa7, 0x54, 0x3e, 0x15, 0x1a, 0x50, 0x12, 0xfa, 0xaf, 0xdb, 0x8e, 0xfb]
    assert(sub_bytes(test_vector) == [0x52, 0x7c, 0xe6, 0x4f, 0x4d, 0xd1, 0x1f, 0x52, 0xa4, 0xc7, 0x35, 0x76, 0x48, 0x7a, 0x0c])


# Generated at 2022-06-24 11:24:28.729042
# Unit test for function key_expansion
def test_key_expansion():
    print("Test for function key_expansion")
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    key_expanded = key_expansion(key)

    print(key_expanded)


# Generated at 2022-06-24 11:24:33.069551
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text('L5u5I5gZ7q3+jQ2J7zDhWzzuX7Y62R09lBV7FJbW8Oo=', 'password', 16) == b'Hello World!'



# Generated at 2022-06-24 11:24:34.945101
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([0x53, 0, 0, 0])) == [0x53, 0, 0, 0]



# Generated at 2022-06-24 11:24:38.801031
# Unit test for function rotate
def test_rotate():
    assert rotate([1,0,0,0]) == [0,0,0,1]
    assert rotate([0,0,0,1]) == [0,0,1,0]
    assert rotate([0,0,1,0]) == [0,1,0,0]
    assert rotate([0,1,0,0]) == [1,0,0,0]



# Generated at 2022-06-24 11:24:41.850030
# Unit test for function shift_rows
def test_shift_rows():
    data_shifted = shift_rows([0] * 16)

# Generated at 2022-06-24 11:24:48.604691
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    mixed_data = mix_columns(data)
    assert mixed_data == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]



# Generated at 2022-06-24 11:24:57.882412
# Unit test for function key_expansion
def test_key_expansion():
    #test data from http://www.inconteam.com/software-development/41-encryption/55-aes-test-vectors
    key = [0x2b,0x7e,0x15,0x16,0x28,0xae,0xd2,0xa6,0xab,0xf7,0x15,0x88,0x09,0xcf,0x4f,0x3c]

# Generated at 2022-06-24 11:25:05.152894
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter:
        def __init__(self):
            self._counter = 0

        def next_value(self):
            l = []
            for i in range(BLOCK_SIZE_BYTES / 4):
                l.append(self._counter)
                self._counter += 1
            return l

    # Test 1
    counter = Counter()
    data = bytes_to_intlist(compat_b64decode('o/eKvOhb3qF56gJN8Y6j1/zNbJg='))
    key = bytes_to_intlist(compat_b64decode('mjYkZDFmYmIxOWMw'))

    decrypted_data = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-24 11:25:16.921188
# Unit test for function aes_encrypt
def test_aes_encrypt():
    print("-Function aes_encrypt...", end='')

# Generated at 2022-06-24 11:25:24.746823
# Unit test for function key_expansion
def test_key_expansion():
    test_key = b'\xe8@\xaea\x94\xcc\xfc\x8e\xe2\x81\x9d\xb8\xea\x1e\x98\xec\xc0\xba\xa8\xcd\xb2\x1f\x95\x96\xaa\x10\xaf'

# Generated at 2022-06-24 11:25:31.369959
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    test_decrypt("/test/test_aes_decrypt_text_128.txt", 16)
    test_decrypt("/test/test_aes_decrypt_text_192.txt", 24)
    test_decrypt("/test/test_aes_decrypt_text_256.txt", 32)
    print("Test aes_decrypt_text finished successfully")



# Generated at 2022-06-24 11:25:38.063173
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0x100):
        for j in range(0x100):
            result = rijndael_mul(i, j)
            expected_result = (i * j) % 0x100
            if(result != expected_result):
                return False
    return True


# Generated at 2022-06-24 11:25:45.498441
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xDB, 0x13,
            0x53, 0x45,
            0xD3, 0x51,
            0xF3, 0x53]
    expected = [0x8E, 0x4D,
                0xA1, 0xBC,
                0x9F, 0xDC,
                0x58, 0xF6]
    encrypted = mix_columns(data)
    assert encrypted == expected



# Generated at 2022-06-24 11:25:47.725937
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    for i in range(0,256):
        assert sub_bytes_inv([SBOX[i]])[0] == i



# Generated at 2022-06-24 11:25:58.915390
# Unit test for function aes_encrypt
def test_aes_encrypt():
    #Test case 1
    data = bytes_to_intlist(compat_b64decode('gZOJfmZh+tRdX9CYq3qwfQ=='))
    key = bytes_to_intlist(compat_b64decode('Qg8k0lIPwQ2l2vskClbzsA=='))
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(aes_encrypt(data, expanded_key)) == compat_b64decode('W8VhA5OmH0j5bp5A5O5gTw==')

    #Test case 2

# Generated at 2022-06-24 11:26:02.439469
# Unit test for function shift_rows
def test_shift_rows():
    sample = range(16)
    # Shift rows 1, 2 and 3 by corresponding number
    expected = [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
    assert shift_rows(sample) == expected



# Generated at 2022-06-24 11:26:11.984236
# Unit test for function aes_decrypt
def test_aes_decrypt():
    encrypted = compat_b64decode('8mPUW0gfutKjF2q3bjvqhWqpfZrg18zjGiAiy7v0tWk=')
    encrypted = bytes_to_intlist(encrypted)
    expanded_key = key_expansion(bytes_to_intlist(b'NwUJ!XYjN'))
    decrypted = aes_decrypt(encrypted, expanded_key)
    assert intlist_to_bytes(decrypted) == b'Hello World!'



# Generated at 2022-06-24 11:26:21.706672
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0xD4, 0xBF, 0x5D, 0x30,
            0xE0, 0xB4, 0x52, 0xAE,
            0xB8, 0x41, 0x11, 0xF1,
            0x1E, 0x27, 0x98, 0xE5]
    assert (shift_rows_inv(data) == [0xD4, 0xE0, 0xB8, 0x1E,
                                    0xBF, 0xB4, 0x41, 0x27,
                                    0x5D, 0x52, 0x11, 0x98,
                                    0x30, 0xAE, 0xF1, 0xE5])



# Generated at 2022-06-24 11:26:23.189483
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x83) == 0xC1



# Generated at 2022-06-24 11:26:26.631768
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]



# Generated at 2022-06-24 11:26:35.519621
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .crypto import get_aes_cbc_decryptor
    from .shim import aes_cbc_decrypt

    data = compat_b64decode(bytestring('pOdvXbbUY+M0R8zQWV7vPF3qB3w='))
    key = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]

# Generated at 2022-06-24 11:26:42.916547
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist('140b41b22a29beb4061bda66b6747e14')
    iv = bytes_to_intlist('4ca00ff4c898d61e1edbf1800618fb28')
    plaintext = bytes_to_intlist('6bc1bee22e409f96e93d7e117393172aae2d8a571e03ac9c9eb76fac45af8e5130c81c46a35ce411e5fbc1191a0a52eff69f2445df4f9b17ad2b417be66c3710')

# Generated at 2022-06-24 11:26:46.749163
# Unit test for function mix_column
def test_mix_column():
    a = [0xDB, 0x13, 0x53, 0x45]

    a_mixed = mix_column(a, MIX_COLUMN_MATRIX)
    print(a_mixed)

    a_inv_mixed = mix_column(a_mixed, MIX_COLUMN_MATRIX_INV)
    print(a_inv_mixed)



# Generated at 2022-06-24 11:26:57.192106
# Unit test for function rijndael_mul

# Generated at 2022-06-24 11:27:06.529556
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    data_in = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]
    data_out = sub_bytes_inv(data_in)
    data_out_correct = [0x53, 0xCA, 0xB1, 0x9C, 0x08, 0xF2, 0xBC, 0x02, 0x2D, 0x35, 0x84, 0x29, 0xE0, 0xA3, 0x05, 0xD1]
    if data_out == data_out_correct:
        print('Test Passed')
    else: raise AssertionError('Test Failed')
test_sub_bytes_inv() # Run the unit test


# Generated at 2022-06-24 11:27:15.584127
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x32, 0x88, 0x31, 0xe0,
            0x43, 0x5a, 0x31, 0x37,
            0xf6, 0x30, 0x98, 0x07,
            0xa8, 0x8d, 0xa2, 0x34]
    
    data_shifted = shift_rows_inv(data)
    assert data_shifted == [0x32, 0x43, 0xf6, 0xa8,
                            0x88, 0x5a, 0x30, 0x8d,
                            0x31, 0x31, 0x98, 0xa2,
                            0xe0, 0x37, 0x07, 0x34]

test_shift_rows_inv()

# Generated at 2022-06-24 11:27:20.141388
# Unit test for function aes_encrypt
def test_aes_encrypt():
    txt = "hello world"
    passwd = 'a password'
    iv = 'iviviviviviviviv'
    encrypted = aes_cbc_encrypt(txt, passwd, iv)
    decrypted = aes_cbc_decrypt(encrypted, passwd, iv)
    assert(decrypted == 'hello world')

test_aes_encrypt()

# Generated at 2022-06-24 11:27:28.065543
# Unit test for function mix_columns
def test_mix_columns():
    assert mix_columns([0xdb, 0xf2, 0xd4, 0x6a, 0x45, 0x7e, 0x16, 0xab, 0x88, 0x3c, 0x9a, 0x9b, 0x1f, 0xe3, 0x15, 0xa7]) == [0x04, 0xe0, 0x48, 0x28, 0x66, 0xcb, 0xf8, 0x06, 0x81, 0x19, 0xd3, 0x26, 0xe5, 0x9a, 0x7a, 0x4c]

# Generated at 2022-06-24 11:27:29.537739
# Unit test for function rotate
def test_rotate():
    assert rotate([0x0a, 0x09, 0x08, 0x07]) == [0x09, 0x08, 0x07, 0x0a]

# Generated at 2022-06-24 11:27:31.484067
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3,4]) == [2,3,4,1]
    assert rotate([0xB,0xD,0x9,0xE]) == [0xD,0x9,0xE,0xB]



# Generated at 2022-06-24 11:27:41.333956
# Unit test for function xor
def test_xor():
    assert xor([0x00, 0x00, 0x00, 0x00], [0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x00]
    assert xor([0x01, 0x01, 0x01, 0x01], [0x01, 0x01, 0x01, 0x01]) == [0x00, 0x00, 0x00, 0x00]
    assert xor([0x01, 0x01, 0x01, 0x01], [0x02, 0x02, 0x02, 0x02]) == [0x03, 0x03, 0x03, 0x03]

# Generated at 2022-06-24 11:27:50.727917
# Unit test for function aes_encrypt
def test_aes_encrypt():
    print("Testing function aes_encrypt")
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F]
    plaintext = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF]

# Generated at 2022-06-24 11:27:53.540180
# Unit test for function rijndael_mul
def test_rijndael_mul():
    # test implementation of xtime function
    assert rijndael_mul(0x57, 0x83) == 0xC1



# Generated at 2022-06-24 11:27:57.201574
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(len(SBOX)):
        for j in range(len(SBOX)):
            c = rijndael_mul(i,j)
            assert(c == galois_mul(i,j))



# Generated at 2022-06-24 11:28:05.586774
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv([0x8D, 0x01, 0x02, 0x04, 0xF1, 0x62, 0x05, 0xF3, 0x56, 0xC6, 0xF4, 0x79, 0xCC, 0xF2, 0x8B, 0x46]) == [0x96, 0x49, 0x92, 0x71, 0x0a, 0xb7, 0xdc, 0xaf, 0x5f, 0xf3, 0x90, 0x00, 0xfe, 0x91, 0xe0, 0xd2]



# Generated at 2022-06-24 11:28:17.686395
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x63, 0x7c, 0x77, 0x7b,
            0xf2, 0x6b, 0x6f, 0xc5,
            0x30, 0x01, 0x67, 0x2b,
            0xfe, 0xd7, 0xab, 0x76]
    data = shift_rows_inv(data)
    data = shift_rows_inv(data)
    assert(data == [0x63, 0x7c, 0x77, 0x7b,
                    0xf2, 0x6b, 0x6f, 0xc5,
                    0x30, 0x01, 0x67, 0x2b,
                    0xfe, 0xd7, 0xab, 0x76])



# Generated at 2022-06-24 11:28:28.323079
# Unit test for function key_expansion

# Generated at 2022-06-24 11:28:34.544784
# Unit test for function aes_decrypt

# Generated at 2022-06-24 11:28:44.004466
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    decrypted_str = aes_decrypt_text(
        'GR1/NkfXbN/yU6P/2d+awK/Ci/gvV7SZGxRbV7I8Xv5nqC4y6E4uYl88HB1a4bBpEaqz1Zg==',
        '9313b6af-f664-4c95-8ad6-f53f2a2e2d1c',
        32
    )
    assert decrypted_str == '{"data": ["Hello World!"]}'


# Generated at 2022-06-24 11:28:47.262820
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3,4]) == [2,3,4,1]
test_rotate()
print("test_rotate passed")


# Generated at 2022-06-24 11:28:59.086703
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = [143,194,34,208,145,203,230,143,177,246,97,206,145,92,255,84]
    cipher = [40,159,166,151,55,18,165,83,195,182,131,163,105,76,66,127,242,
              254,214,220,116,166,148,139,18,24,245,75,169,161,128,7,214,180,
              159,166,178,210,7,68,180,109,162,255,81,244,47,8,221,193,50,
              116,250,45,52,180,11,202,225,248,199,72,43,35,144,139,219,15]

# Generated at 2022-06-24 11:29:08.877935
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Tests for function aes_decrypt_text
    """

    # test_aes_decrypt_text_16_128_ctr
    encrypted_data = 'KBRWQ2wcBnNlEgTIYX9Keg=='
    password = 'test1test'
    plaintext = aes_decrypt_text(encrypted_data, password, 16)
    # Output:
    # plaintext = '16 Byte key'
    assert plaintext == b'16 Byte key'

    # test_aes_decrypt_text_24_192_ctr
    encrypted_data = 'J5cfY94E1t/L9Iop/QDVyQ=='
    password = 'test2test'
    plaintext = aes_decrypt_text(encrypted_data, password, 24)
   

# Generated at 2022-06-24 11:29:15.744234
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = 0x2b7e151628aed2a6abf7158809cf4f3c
    iv = 0x000102030405060708090a0b0c0d0e0f
    data = 0x6bc1bee22e409f96e93d7e117393172a
    expected = 0x7649abac8119b246cee98e9b12e9197d


# Generated at 2022-06-24 11:29:25.798148
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = [0x39, 0x25, 0x84, 0x1d, 0x02, 0xdc, 0x09, 0xfb, 0xdc, 0x11, 0x85, 0x97, 0x19, 0x6a, 0x0b, 0x32]
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)

# Generated at 2022-06-24 11:29:31.140288
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for x in range(0xFF):
        for y in range(0xFF):
            if rijndael_mul(x, y) != rijndael_mul_slow(x, y):
                print("x=0x%02x y=0x%02x" % (x, y))



# Generated at 2022-06-24 11:29:46.297155
# Unit test for function key_expansion
def test_key_expansion():
    # Test vector 1
    sub_key1 = [0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe, 0x2b, 0x73, 0xae, 0xf0, 0x85, 0x7d, 0x77, 0x81, 0x1f, 0x35, 0x2c, 0x07, 0x3b, 0x61, 0x08, 0xd7, 0x2d, 0x98, 0x10, 0xa3, 0x09, 0x14, 0xdf, 0xf4]

# Generated at 2022-06-24 11:29:54.640067
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Compare decrypted ciphertext with cleartext in unit test
    """
    def _test(encrypted_data, cleartext, key_size_bytes=16):
        decrypted_data = aes_decrypt_text(encrypted_data, cleartext, key_size_bytes)
        assert decrypted_data == cleartext

    _test(
        'U2FsdGVkX1/lYbULZvO+rQkMj0fBmkmcwzvYPKH0YmA=',
        'This is a secret message!')

# Generated at 2022-06-24 11:29:59.464978
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0x100):
        for j in range(0x100):
            assert(rijndael_mul(i, j) == ((i * j) % 0x100))


test_rijndael_mul()



# Generated at 2022-06-24 11:30:09.047028
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)
    text = [0x6b, 0xc1, 0xbe, 0xe2, 0x2e, 0x40, 0x9f, 0x96,
            0xe9, 0x3d, 0x7e, 0x11, 0x73, 0x93, 0x17, 0x2a]

# Generated at 2022-06-24 11:30:22.537935
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode("K7gNU3sdo+OL0wNhqoVWhr3g6s6So3uu/8XpnKgS9Ng="))
    iv = bytes_to_intlist(compat_b64decode("h0/EhCgFm+8Z1Yj9sOiMI6aDBU6zHg6j"))

    # Test cleartext "Test Test Test"
    cleartext = [84, 101, 115, 116, 84, 101, 115, 116, 84, 101, 115, 116, 84, 101, 115, 116]

# Generated at 2022-06-24 11:30:32.325088
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AesCounter
    from .format_converters import hex_to_intlist, intlist_to_hex
    data = '69dda8455c7dd4254bf353b773304eec0ec7702330098ce7f7520d1cbbb20fc388d1b0adb5054dbd7370849dbf0b88d393f252e764f1f5f7ad97ef79d59ce29f5f51eeca32eabedd9afa9329'
    key = '36f18357be4dbd77f050515c73fcf9f2'
    counter = AesCounter('0CoJUm6Qyw8W8jud')


# Generated at 2022-06-24 11:30:38.393181
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # This ia a test to check if the python decryption is working
    text = aes_decrypt_text(
        'aV0pIk6ZjzfRvJkZwV7y+j2yc9Xv3qe3uKjU/B6Uc1s=',
        'b',
        32
    )
    print('Test text: {0}'.format(text))
    assert text == b'Hello, world!'



# Generated at 2022-06-24 11:30:44.592331
# Unit test for function xor
def test_xor():
    expected = [0x9a, 0xbc, 0x20, 0x2a]
    data1 = [0x42, 0x6c, 0x6f, 0x63]
    data2 = [0xd8, 0xd6, 0x4f, 0x68]
    result = xor(data1, data2)
    assert result == expected, '%s != %s' % (result, expected)
    print('%s == %s' % ('xor', expected))


# Generated at 2022-06-24 11:30:52.108574
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    test_case = [[0x19, 0x3d, 0xe3, 0xbe, 0xa0, 0xf4, 0xe2, 0x2b, 0x9a, 0xc6, 0x8d, 0x2a, 0xe9, 0xf8, 0x48, 0x08]]
    expected_result = [0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb]
    assert sub_bytes_inv(test_case[0]) == expected_result



# Generated at 2022-06-24 11:31:00.042334
# Unit test for function aes_encrypt
def test_aes_encrypt():
  test_key = bytes_to_intlist(b'this is a 24 byte key!')
  expanded_key = key_expansion(test_key)

  test_data = bytes_to_intlist(b'hello world !!!')
  assert aes_encrypt(test_data, expanded_key) == bytes_to_intlist(b'\x10O\x8d\x84\x7f\x17\xcf\t\xfc\xfb\x1c\xcb\xb8\x84p\x11\xaf#')

# Generated at 2022-06-24 11:31:09.187638
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-24 11:31:17.553242
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test_data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    test_data = [0xcb, 0x56, 0xfa, 0xac, 0x52, 0xf9, 0x5e, 0x8f, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns_inv(test_data)
    print([hex(x) for x in result])

# Generated at 2022-06-24 11:31:20.500964
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x00, 0x00, 0x00, 0x00]) == [0x63, 0x7c, 0x77, 0x7b]
    assert sub_bytes([254, 255, 254, 255]) == [0x68, 0x4f, 0x3a, 0x1b]



# Generated at 2022-06-24 11:31:30.145450
# Unit test for function xor