

# Generated at 2022-06-24 11:21:35.595475
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0xf2, 0xd4, 0x6f, 0x45, 0x7f, 0xf7, 0xfe, 0x7b, 0xef, 0x09, 0x3e, 0xdd, 0x94, 0xc0, 0x4e]
    data_mixed = mix_columns(data)
    print("Original data: {}".format([hex(x) for x in data]))
    print("Data after mix columns: {}".format([hex(x) for x in data_mixed]))
#test_mix_columns()

# Generated at 2022-06-24 11:21:38.360239
# Unit test for function mix_column
def test_mix_column():
    result = mix_column([0xDB, 0x13, 0x53, 0x45], MIX_COLUMN_MATRIX)
    print(result)



# Generated at 2022-06-24 11:21:46.102224
# Unit test for function key_schedule_core

# Generated at 2022-06-24 11:21:52.740824
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    if(shift_rows_inv([0x63, 0x53, 0xe0, 0x8c, 0x09, 0x60, 0xe1, 0x04,
                       0xcd, 0xc0, 0x44, 0x02, 0xac, 0xce, 0x0d, 0x75]) !=
       [0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38,
        0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb]):
        print("shift_rows_inv failed")
        exit()


# Generated at 2022-06-24 11:22:02.882887
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x63, 0xCA, 0xB7, 0x04, 0x09, 0x53, 0xD0, 0x51, 0xCD, 0x60, 0xE0, 0xE7, 0xBA, 0x70, 0xE1, 0x8C]
    data_shifted = [0x63, 0xCA, 0xB7, 0x04, 0xD0, 0x51, 0xCD, 0x60, 0xE0, 0xE7, 0xBA, 0x70, 0xE1, 0x8C, 0x09, 0x53]
    assert shift_rows(data) == data_shifted

test_shift_rows()



# Generated at 2022-06-24 11:22:12.477934
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from .utils import print_bytes_as_hex
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-24 11:22:18.915480
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    byte = [0x54, 0x77, 0x6F, 0x20, 0x4F, 0x6E, 0x65, 0x20, 0x4E, 0x69, 0x6E, 0x65, 0x20, 0x54, 0x77, 0x6F]
    byte_expected = [0xBA, 0x84, 0xE8, 0x1B, 0x75, 0xA4, 0x68, 0x12, 0x9D, 0xC1, 0x37, 0x6C, 0xEC, 0xF1, 0x83, 0x33]
    assert sub_bytes_inv(byte) == byte_expected



# Generated at 2022-06-24 11:22:29.455863
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key=b"YELLOW SUBMARINE"
    encrypted=compat_b64decode("L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==")
    iv = bytes_to_intlist(b"\x00" * 16)
    decrypted_intlist = aes_cbc_decrypt(bytes_to_intlist(encrypted), bytes_to_intlist(key), iv)
    decrypted = b"I'm back and I'm ringin' the bell \n"
    assert decrypted == intlist_to_bytes(decrypted_intlist)
aes_decrypt_test = test_aes_decrypt()

# Generated at 2022-06-24 11:22:40.738262
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode(b'7KZ9fEuO7VhYq3wTnT/r/w=='))

# Generated at 2022-06-24 11:22:49.018524
# Unit test for function aes_decrypt_text

# Generated at 2022-06-24 11:22:56.517896
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    data = [0x63, 0x53, 0xe0, 0x8c, 0x09, 0x60, 0xe1, 0x04, 0xcd, 0x70, 0xb7, 0x51, 0xba, 0xa6, 0x1e, 0x1d]
    actual = sub_bytes_inv(data)
    expected = [0x63, 0x53, 0x7c, 0x68, 0x16, 0xc0, 0xc2, 0x04, 0x0d, 0x60, 0x4f, 0x69, 0x13, 0x9a, 0x2e, 0xb2]
    assert actual == expected
# Test shift_rows

# Generated at 2022-06-24 11:23:07.559155
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .counter import Counter
    from .key_expansion import key_expansion
    from .aes_encrypt import aes_encrypt
    from .xor_byte_arrays import xor_byte_arrays
    from .utils import bytes_to_intlist, intlist_to_bytes
    from .compat import compat_b64decode

    encrypted = compat_b64decode(
        'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMT'
        'JULu/6/kXX0KSvoOLSFQ=='
    )
    key = bytes_to_intlist(
        b'YELLOW SUBMARINE'
    )
    counter = Counter(0)

    expanded_key = key_exp

# Generated at 2022-06-24 11:23:15.850202
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data0 = [0x63, 0xca, 0xb7, 0x04, 0xe0, 0x09, 0x8e, 0x6c, 0x7b, 0x2a, 0x2b, 0x7e, 0xaf, 0xf7, 0xab, 0xa6]
    expected0 = [0x63, 0xca, 0xb7, 0x04, 0x09, 0x8e, 0x6c, 0xe0, 0x2a, 0x7b, 0xaf, 0x7e, 0x7e, 0xf7, 0xab, 0xa6]
    assert(shift_rows_inv(data0) == expected0)
    print("Test shift_rows_inv passed")


# Generated at 2022-06-24 11:23:21.172495
# Unit test for function key_expansion

# Generated at 2022-06-24 11:23:26.848478
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Example from http://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38a.pdf

    import binascii

    data = bytes_to_intlist(binascii.a2b_hex(
        "e8b64b066e840e2630f01d90f524b3888baa9714c9d23fc0f0ebc46f33763285"
        "5a24b5a5a5b1e429c4d4d984bc8c757e826044ffcda57d04bef52e887ea112a5"))


# Generated at 2022-06-24 11:23:35.356733
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from .aes_cbc_counter import AesCbcCounter

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    plaintext = b'1234567812345678'
    encrypted = aes_cbc_encrypt(bytes_to_intlist(plaintext), key, iv)
    assert len(encrypted) == 16

    cbc_counter = AesCbcCounter(key=key, iv=iv)
    decrypted = cbc_counter.crypt(intlist_to_bytes(encrypted))


# Generated at 2022-06-24 11:23:38.559082
# Unit test for function shift_rows
def test_shift_rows():
    data = [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
    data_shifted = shift_rows(data)
    print(data_shifted)



# Generated at 2022-06-24 11:23:45.979344
# Unit test for function shift_rows
def test_shift_rows():
    a = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    b = shift_rows(a)
    c = [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
    assert b == c, "Error in shift_rows()"
    print("shift_rows() passed tests")


# Generated at 2022-06-24 11:23:51.852114
# Unit test for function sub_bytes_inv

# Generated at 2022-06-24 11:23:59.100292
# Unit test for function rotate
def test_rotate():
    state = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    expected_state = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0]
    actual_state = rotate(state)
    if actual_state != expected_state:
        print("[rotate] failed")
        print("expected_state:", expected_state)
        print("actual_state:", actual_state)



# Generated at 2022-06-24 11:24:06.770954
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    key = b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c'
    counter_block = b'\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf7\xf8\xf9\xfa\xfb\xfc\xfd\xfe\xff'

# Generated at 2022-06-24 11:24:15.885790
# Unit test for function mix_column
def test_mix_column():
    data = [0x32, 0x88, 0x31, 0xe0]
    expected = [0x01, 0x02, 0x03, 0x01]
    print("Testing mix_column ...")
    result = mix_column(data, MIX_COLUMN_MATRIX)
    print("Result: %s" % str([hex(x) for x in result]))
    print("Expected: %s" % str([hex(x) for x in expected]))
    if(result == expected):
        print("Success")
    else:
        print("Failed")

# Generated at 2022-06-24 11:24:20.214283
# Unit test for function key_schedule_core
def test_key_schedule_core():
    word0 = 0x01001101
    word1 = 0x01010101
    expected = [word0, word1, 0x01000101, 0x01010101]
    actual = key_schedule_core([word0, word1, 0x01000101, 0x01010101], 1)
    assert actual == expected



# Generated at 2022-06-24 11:24:26.867187
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range(256):
        for b in range(256):
            c = rijndael_mul(a, b)
            d = a * b
            assert (c == d % 256)
test_rijndael_mul()


# Generated at 2022-06-24 11:24:34.214145
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    enc_text = "QWYxRjRGMjI0RUMxMjEyNTY1N0IwOUIxNjMzOTMwN0M"
    password = "changeme"
    key_size = 16
    dec_text = aes_decrypt_text(enc_text, password, key_size)
    print (dec_text)
    print (len(dec_text))

test_aes_decrypt_text()



# Generated at 2022-06-24 11:24:43.776620
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    input = [0xeb, 0x9f, 0x77, 0x81, 0xb7, 0x34, 0xca, 0x5e, 0x56, 0x7c, 0x5d, 0x44, 0x73, 0x9f, 0x82, 0x22]
    output = [0xe4, 0x4e, 0x4a, 0x12, 0x69, 0x73, 0xc4, 0x42, 0x62, 0x8e, 0x2a, 0x14, 0x95, 0x77, 0x7e, 0x82]
    assert(output == mix_columns_inv(input)), "unit test fail"
# Execute test
test_mix_columns_inv()


# Generated at 2022-06-24 11:24:52.503119
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns_inv(data)
    assert result == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    print(result)



# Generated at 2022-06-24 11:25:02.069080
# Unit test for function aes_decrypt
def test_aes_decrypt():
    from .aes_cipher import aes_cipher
    test_data = [0x32,0x43,0xf6,0xa8,0x88,0x5a,0x30,0x8d,0x31,0x31,0x98,0xa2,0xe0,0x37,0x07,0x34]
    key = b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c'

# Generated at 2022-06-24 11:25:09.563404
# Unit test for function xor
def test_xor():
    assert xor([0x1, 0x2, 0x3, 0x4], [0x5, 0x6, 0x7, 0x8]) == [0x4, 0x4, 0x4, 0xC]
    print("Passed unit tests")

# Generated at 2022-06-24 11:25:15.779615
# Unit test for function xor
def test_xor():
    assert xor([0, 1, 0, 0], [0, 0, 1, 0]) == [0, 1, 1, 0]
    assert xor([1, 1, 1, 1], [0, 0, 1, 0]) == [1, 1, 0, 1]
    assert xor([0, 1, 0, 0], [1, 1, 1, 1]) == [1, 0, 1, 1]


# Generated at 2022-06-24 11:25:21.398298
# Unit test for function inc
def test_inc():
    data = [0x00, 0x00, 0x00, 0x00]
    assert inc(data) == [0x00, 0x00, 0x00, 0x01]
    data = [0x00, 0x00, 0x00, 0xFF]
    assert inc(data) == [0x00, 0x00, 0x01, 0x00]
    data = [0x00, 0x00, 0xFF, 0xFF]
    assert inc(data) == [0x00, 0x01, 0x00, 0x00]
    data = [0x00, 0xFF, 0xFF, 0xFF]
    assert inc(data) == [0x01, 0x00, 0x00, 0x00]

# Generated at 2022-06-24 11:25:33.869390
# Unit test for function aes_decrypt
def test_aes_decrypt():

    def test_128(cleartext, key, cipher):
        expanded_key = key_expansion(key)
        assert aes_decrypt(cipher, expanded_key) == cleartext

    def test_192(cleartext, key, cipher):
        expanded_key = key_expansion(key)
        assert aes_decrypt(cipher, expanded_key) == cleartext

    def test_256(cleartext, key, cipher):
        expanded_key = key_expansion(key)
        assert aes_decrypt(cipher, expanded_key) == cleartext


# Generated at 2022-06-24 11:25:41.746639
# Unit test for function shift_rows
def test_shift_rows():
    test = [0x63, 0x53, 0xe0, 0x8c, 0x09, 0x60, 0xe1, 0x04, 0xcd, 0x70, 0xb7, 0x51, 0xba, 0xa6, 0xf5, 0x81]
    result = shift_rows(test)
    assert result == [0x63, 0x53, 0x09, 0x60, 0xba, 0xa6, 0x61, 0x04, 0xe0, 0x70, 0xf5, 0x51, 0xcd, 0xb7, 0x8c, 0x81]


# Generated at 2022-06-24 11:25:52.019686
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Unit test for function aes_decrypt_text
    """
    from .aes import aes_decrypt_text
    from .compat import compat_b64encode, compat_chr
    from .utils import bytearray_to_intlist, intlist_to_bytes

    # https://cryptopals.com/sets/2/challenges/10

# Generated at 2022-06-24 11:25:57.513852
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0, 0) == 0
    assert rijndael_mul(0xdb, 0x13) == 0x49
    assert rijndael_mul(0xdb, 0x01) == 0xdb
    assert rijndael_mul(0x11, 0x11) == 0x1b
    assert rijndael_mul(0x11, 0x1b) == 0x1f



# Generated at 2022-06-24 11:26:03.063338
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print('[*] Testing rijndael_mul')
    assert(rijndael_mul(0x57, 0x83) == 0xc1)
    assert(rijndael_mul(0x83, 0x57) == 0xc1)
    assert(rijndael_mul(0x57, 0x13) == 0xfe)
    assert(rijndael_mul(0x13, 0x57) == 0xfe)



# Generated at 2022-06-24 11:26:14.048899
# Unit test for function xor
def test_xor():
    data1 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    data2 = [0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5,
                 0x62, 0xf8, 0xea, 0xd2, 0x52, 0x2c, 0x6b, 0x7b]

# Generated at 2022-06-24 11:26:15.794116
# Unit test for function rotate
def test_rotate():
    assert ([1, 2, 3, 4, 5] == rotate([5, 1, 2, 3, 4]))
    assert ([1, 2, 3, 4, 5] == rotate([1, 2, 3, 4, 5]))


# Generated at 2022-06-24 11:26:25.406218
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test Vectors (added by me)
    print("Test Vectors (added by me): ")
    data = "579da0a7c3f09816".decode("hex")
    data = bytes_to_intlist(data)
    key = "19b06c98b8d15e68".decode("hex")
    key = bytes_to_intlist(key)
    expanded_key = key_expansion(key)
    decrypted_data = aes_decrypt(data, expanded_key)
    decrypted_data = intlist_to_bytes(decrypted_data)
    print("plaintext = " + decrypted_data.encode("hex"))
    print("\n")

    # Test Vectors (added by me)

# Generated at 2022-06-24 11:26:33.221631
# Unit test for function aes_decrypt_text

# Generated at 2022-06-24 11:26:43.388686
# Unit test for function xor
def test_xor():
    assert(xor([0x01, 0x01, 0x01, 0x01], [0x00, 0x00, 0x00, 0x00]) == [0x01, 0x01, 0x01, 0x01])
    assert(xor([0x00, 0x00, 0x00, 0x00], [0x01, 0x01, 0x01, 0x01]) == [0x01, 0x01, 0x01, 0x01])
    assert(xor([0x01, 0x01, 0x01, 0x01], [0x01, 0x01, 0x01, 0x01]) == [0x00, 0x00, 0x00, 0x00])

# Generated at 2022-06-24 11:26:54.156181
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-24 11:27:01.562356
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x3A, 0x4F, 0xF4, 0x9E, 0xDE, 0x65, 0x95, 0xC7, 0x8F, 0x59, 0x9D, 0xBC, 0x2B, 0x6F, 0x26, 0x28]
    data_shifted = shift_rows_inv(data)
    assert data_shifted == [0x3A, 0xDE, 0x8F, 0x2B, 0x4F, 0x95, 0x59, 0x6F, 0xF4, 0xC7, 0x9D, 0x26, 0x9E, 0x65, 0xBC, 0x28]

# Generated at 2022-06-24 11:27:14.887488
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-24 11:27:24.908998
# Unit test for function key_expansion

# Generated at 2022-06-24 11:27:26.888396
# Unit test for function rotate
def test_rotate():
    assert rotate([0, 1, 2, 3]) == [1, 2, 3, 0]
    assert rotate([1, 1, 2, 3]) == [1, 2, 3, 1]



# Generated at 2022-06-24 11:27:37.108386
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    iv = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
            1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 1,
            2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 1]

    # Encrypt and decrypt

# Generated at 2022-06-24 11:27:47.747832
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]
    data_shifted = shift_rows(data)
    assert(data_shifted == [0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0x07, 0xa8, 0x8d, 0xa2, 0x34])



# Generated at 2022-06-24 11:27:52.952135
# Unit test for function shift_rows
def test_shift_rows():
    # Check every possible combination
    for value in range(2 ** 8):
        # Set data to 5 values
        data = [i & 0b11111111 for i in range(value, value + 5)]
        data_shifted = shift_rows(data)
        # Reorder the data back
        data_reordered = []
        for column in range(4):
            for row in range(4):
                data_reordered.append(data[((column + row) & 0b11) * 4 + row])
        assert(data_shifted == data_reordered)



# Generated at 2022-06-24 11:28:04.004394
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Just a random 128bit key and IV
    key = bytes_to_intlist(b'z\x02\x8c\xb9\xdb\xd0\xe5\xc8W\xbe\xde\x0be\x93\xe6\xe4\x1f\xe9')
    iv = bytes_to_intlist(b'#\xba\xa0\xbf\xa7Y\xf4\x18\xc9\x14\xfc\xe4\xba\x1d3\x1d\x9e\xbb\x9d')

    # The program should print this message

# Generated at 2022-06-24 11:28:10.327003
# Unit test for function mix_column
def test_mix_column():
    test_value = [0xdb, 0x13, 0x53, 0x45]
    result = mix_column(test_value, MIX_COLUMN_MATRIX)
    #print(bytearray(result))
    #assert(bytearray(result) == bytearray([0x8e, 0x4d, 0xa1, 0xbc]))


# Generated at 2022-06-24 11:28:22.844485
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode(b'YJi+goTovWybfvA/RsnI7w=='))
    iv = bytes_to_intlist(compat_b64decode(b'/v/H5+jS/g0bc5/W8ZvHmg=='))
    data = bytes_to_intlist(compat_b64decode(b'PZo3qZ+tBkQX9Zf15yd8QQ=='))

    encrypted_data = aes_cbc_encrypt(data, key, iv)
    expected_encrypted_data = bytes_to_intlist(compat_b64decode(b'k6fE/NX9a6H/JG3qh3zj7Q=='))

# Generated at 2022-06-24 11:28:33.021793
# Unit test for function aes_decrypt

# Generated at 2022-06-24 11:28:38.533519
# Unit test for function shift_rows
def test_shift_rows():
    assert shift_rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]) == [0, 1, 2, 3, 5, 6, 7, 4, 10, 11, 8, 9, 15, 12, 13, 14]
    assert shift_rows([10, 10, 12, 13, 14, 15, 14, 15, 16, 16, 17, 17, 18, 19, 12, 13]) == [10, 10, 13, 14, 15, 16, 17, 18, 19, 12, 13, 14, 15, 16, 17, 18]



# Generated at 2022-06-24 11:28:48.276451
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test vector from wikipedia
    iv = bytes_to_intlist(compat_b64decode(b'3ad77bb40d7a3660a89ecaf32466ef97'))
    key = bytes_to_intlist(compat_b64decode(b'2b7e151628aed2a6abf7158809cf4f3c'))
    data = bytes_to_intlist('Hello World')
    expected = bytes_to_intlist(compat_b64decode(b'7649abac8119b246cee98e9b12e9197d'
                                                 b'5086cb9b507219ee95db113a917678b2'))
    actual = aes_cbc_encrypt(data, key, iv)
    assert actual == expected


# Generated at 2022-06-24 11:28:56.845084
# Unit test for function xor
def test_xor():
    list1 = [0x2b,0x7e,0x15,0x16,0x28,0xae,0xd2,0xa6,0xab,0xf7,0x15,0x88,0x09,0xcf,0x4f,0x3c]
    list2 = [0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f]

# Generated at 2022-06-24 11:29:08.149675
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    expanded_key = key_expansion([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c])
    enc = aes_encrypt(data, expanded_key)

# Generated at 2022-06-24 11:29:12.278404
# Unit test for function mix_column
def test_mix_column():
    data = [0x57, 0x88, 0xc0, 0xfe]
    mixed1 = mix_column(data, MIX_COLUMN_MATRIX)
    mixed2 = mix_column(mixed1, MIX_COLUMN_MATRIX_INV)

    print("Mix column: {}".format(data))
    print("Mixed result: {}".format(mixed1))
    print("Result after mix column and mix column inv: {}\n".format(mixed2))



# Generated at 2022-06-24 11:29:20.330069
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-24 11:29:30.566816
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [73, 108, 32, 104, 97, 118, 101, 32, 97, 32, 109, 97, 100, 32,
            112, 114, 111, 98, 108, 101, 109]

# Generated at 2022-06-24 11:29:37.122083
# Unit test for function aes_decrypt_text

# Generated at 2022-06-24 11:29:47.903196
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .counters import Counter
    from .data import cipher_key_16, cipher_key_24, cipher_key_32, cipher_data_intarray, plain_data_intarray

    for key in [cipher_key_16, cipher_key_24, cipher_key_32]:
        counter = Counter(0)
        decrypted_data = aes_ctr_decrypt(cipher_data_intarray, key, counter)
        assert plain_data_intarray == decrypted_data

        counter = Counter(0x123456789abcdef0)
        decrypted_data = aes_ctr_decrypt(cipher_data_intarray, key, counter)
        assert plain_data_intarray == decrypted_data

        counter = Counter(0x123456789abcdef0)
        counter.next_value()

# Generated at 2022-06-24 11:29:52.958333
# Unit test for function mix_column
def test_mix_column():
    assert(mix_column([0xdb, 0x13, 0x53, 0x45], MIX_COLUMN_MATRIX) == [0x8e, 0x4d, 0xa1, 0xbc])
    assert(mix_column([0x8e, 0x4d, 0xa1, 0xbc], MIX_COLUMN_MATRIX_INV) == [0xdb, 0x13, 0x53, 0x45])



# Generated at 2022-06-24 11:30:04.286977
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    '''
    Test function
    '''
    key = bytes_to_intlist('qw8Jqw8Jqw8Jqw8Jqw8Jqw8Jqw8Jqw8J')
    iv = [0] * 16

# Generated at 2022-06-24 11:30:08.640144
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x19,0x3d,0xe3,0xbe]
    result = sub_bytes(data)
    if result == [0xd4,0x27,0x11,0xae] :
        ans = True
    else:
        ans = False
    return ans

# Function: ShiftRows()

# Generated at 2022-06-24 11:30:14.882200
# Unit test for function sub_bytes
def test_sub_bytes():
    a1 = [0x19, 0xa0, 0x9a, 0xe9]
    sub_bytes(a1)
    # Expected result: [0xd4, 0xe0, 0xb8, 0x1e]
    a2 = [0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef]
    sub_bytes(a2)
    # Expected result: [0x68, 0x8d, 0xca, 0x4d, 0x73, 0x4b, 0x42, 0x75]



# Generated at 2022-06-24 11:30:17.958155
# Unit test for function rotate
def test_rotate():
    data = [0x00, 0x10, 0x20, 0x30]
    data_result = rotate(data)
    print(data_result)



# Generated at 2022-06-24 11:30:22.690975
# Unit test for function sub_bytes
def test_sub_bytes():
    print('\tTest sub_bytes: ', end='')
    data = [0x52, 0x09, 0x6a]
    test_data = [0x63, 0xca, 0xb7]
    data = sub_bytes(data)
    for i in range(len(data)):
        assert data[i] == test_data[i]
    print('Ok')

# Generated at 2022-06-24 11:30:27.743906
# Unit test for function xor
def test_xor():
    data1 = [0x11, 0x11]
    data2 = [0x01, 0x01]
    expected = [0x10, 0x10]
    result = xor(data1, data2)
    assert result == expected


# Generated at 2022-06-24 11:30:35.499895
# Unit test for function key_expansion
def test_key_expansion():
    # Test vector 1
    data = bytes_to_intlist(compat_b64decode(b"U3ByaW5nQmxhZGUAAAAAAA=="))

# Generated at 2022-06-24 11:30:45.397192
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
  # The test vectors are taken from:
  # https://tools.ietf.org/html/rfc3602#section-4
  # TODO: Use the test vectors from
  # https://tools.ietf.org/html/rfc3602#page-13
  # once we are able to handle the 16-Byte MAC that is included in the data.
  iv = [50, 53, 55, 57, 49, 51, 53, 49, 50, 51, 52, 53, 54, 55, 56, 57]
  key = [0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10, 0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10]

# Generated at 2022-06-24 11:30:52.994878
# Unit test for function shift_rows
def test_shift_rows():
    data = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
    data_shifted = shift_rows(data)
    assert (data_shifted == [0,1,2,3,5,6,7,4,10,11,8,9,15,12,13,14]), "Expected [0,1,2,3,5,6,7,4,10,11,8,9,15,12,13,14], got {}".format(data_shifted)

test_shift_rows()


# Generated at 2022-06-24 11:31:02.471158
# Unit test for function sub_bytes
def test_sub_bytes():
    print("Testing sub_bytes...")
    data = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    result = sub_bytes(data)
    answer = [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]
    if (result != answer):
        print("sub_bytes test 1 failed!")
        print("Output:", result)

# Generated at 2022-06-24 11:31:12.086037
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vector 1
    # NIST SP 800-38A pp 52
    # http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    data = bytes_to_intlist(compat_b64decode('''
    C8 0E DA 02 3B A0 20 EA 44 73 83 74 0B E6 86 B3
    '''))
    key = bytes_to_intlist(compat_b64decode('''
    2B 7E 15 16 28 AE D2 A6 AB F7 15 88 09 CF 4F 3C
    '''))

# Generated at 2022-06-24 11:31:23.006754
# Unit test for function xor

# Generated at 2022-06-24 11:31:31.413992
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode(b'+I33EAOkBJloWJX8CvABRkA=='))
    iv = bytes_to_intlist(compat_b64decode(b'3q4d4PGQD0QmzA/VBfV8wg=='))
    data = bytes_to_intlist(compat_b64decode(b'P5/zzdQwTDw/UO1fUuJ6q9YJ4b4k2Q4D4H4+JokHYCnjw=='))

    decrypted_data = intlist_to_bytes(aes_cbc_decrypt(data, key, iv))

    assert (decrypted_data == b'I am the walrus')

