

# Generated at 2022-06-24 11:21:32.581320
# Unit test for function aes_decrypt

# Generated at 2022-06-24 11:21:36.773748
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [x for x in range(0, 16)]
    print(data)
    print(shift_rows_inv(shift_rows(data)))



# Generated at 2022-06-24 11:21:46.281211
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data1 = '5cb5b5c527382908ff869a9413d7b43647b406964d3a6bc36e729a286c1a2f6d'
    key1 = '86b19dbd42fea2eb356ced7c2332ec88'
    iv1 = '3efa7e9838b08fa4a4f4eb4fa4f31e96'

    assert aes_cbc_decrypt(bytes_to_intlist(compat_b64decode(data1)), bytes_to_intlist(compat_b64decode(key1)), bytes_to_intlist(compat_b64decode(iv1))) == bytes_to_intlist('63616c69656e6365')



# Generated at 2022-06-24 11:21:53.878949
# Unit test for function key_expansion

# Generated at 2022-06-24 11:21:59.151894
# Unit test for function mix_column
def test_mix_column():
    data = [0xca, 0x4b, 0x4c, 0x69]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    assert data_mixed == [0xee, 0x7f, 0xfe, 0x2c]



# Generated at 2022-06-24 11:22:10.574512
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    data = [0x52, 0x9c, 0x6a, 0x4a, 0x90, 0x0b, 0x5e, 0x38, 0x13, 0x0a, 0xc5, 0xe4, 0x58, 0x30, 0x8a, 0x1c]
    expected_result = [0xa4, 0x68, 0x6b, 0x02, 0x9c, 0x9f, 0x5b, 0x6a, 0x7f, 0x35, 0xea, 0x50, 0xf2, 0x2b, 0x43, 0x49]
    result = sub_bytes_inv(data)
    assert result == expected_result, '%s != %s' % (result, expected_result)



# Generated at 2022-06-24 11:22:18.217960
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0xf2, 0xd4, 0x7b, 0x33, 0x9d, 0xf3, 0x4c, 0xa0, 0x2e, 0xfe, 0x4a, 0x9c, 0x3c, 0x23, 0x8a]
    mix_columns_inv_data = mix_columns_inv(data)
    print(mix_columns_inv_data)

    print([0x04, 0xe0, 0x48, 0x28, 0x66, 0xcb, 0xf8, 0x06, 0x81, 0x19, 0xd3, 0x26, 0xe5, 0x9a, 0x7a, 0x4c])

# Generated at 2022-06-24 11:22:19.557711
# Unit test for function rotate
def test_rotate():
    assert rotate([0x53, 0xCA, 0xB1, 0x9D]) == [0xCA, 0xB1, 0x9D, 0x53]



# Generated at 2022-06-24 11:22:28.289094
# Unit test for function inc
def test_inc():
    print('Testing function inc')
    for i in range(10):
        data = [1, 2, 3, 4]
        data_inc = inc(data)
        print(data_inc)
        assert(data_inc[-1] == data[-1] + 1)
        for j in range(len(data) - 2, -1, -1):
            if data[j] != 255:
                assert(data_inc[j] == data[j])
    print('Function inc works properly')



# Generated at 2022-06-24 11:22:32.201013
# Unit test for function mix_columns
def test_mix_columns():
    testdata = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns(testdata)
    print(result)



# Generated at 2022-06-24 11:22:40.634078
# Unit test for function aes_encrypt
def test_aes_encrypt():
    def assert_aes_encrypt(key, data, expected_cipher):
        expanded_key = key_expansion(key)
        cipher = aes_encrypt(data, expanded_key)
        assert cipher == expected_cipher

    # Test Vector #1: ECB-AES128.Encrypt
    key = [
        0x2b, 0x7e, 0x15, 0x16,
        0x28, 0xae, 0xd2, 0xa6,
        0xab, 0xf7, 0x15, 0x88,
        0x09, 0xcf, 0x4f, 0x3c
    ]

# Generated at 2022-06-24 11:22:48.952881
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist(compat_b64decode("""
        beQSriAZYFrz1BpM1FvZnX4EN3q4it4e
    """))
    data = bytes_to_intlist(compat_b64decode("""
        NLtZC2Q7Vh0Fg1z7VNOYQDho2xDLxRaO
    """))

    # Test normal case
    expanded_key = key_expansion(key)
    decrypted_data = aes_decrypt(data, expanded_key)
    assert decrypted_data == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    # Test that padding is removed
    data = bytes_to_

# Generated at 2022-06-24 11:22:55.259364
# Unit test for function rotate
def test_rotate():
    data = [1, 2, 3, 4]
    rotate_data = rotate(data)
    assert rotate_data == [2, 3, 4, 1]



# Generated at 2022-06-24 11:23:00.252251
# Unit test for function mix_columns
def test_mix_columns():
    print("Testing mix_columns")
    data = [0xdb, 0x13, 0x53,
            0x45, 0xf2, 0x0a,
            0x22, 0x5c, 0x01,
            0x01, 0x01, 0x01]
    data_mixed_expected = [0x8e, 0x9f, 0x7f, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x8e, 0x9f, 0x7f]
    data_mixed = mix_columns(data)
    if(data_mixed == data_mixed_expected):
        print("passed")
    else:
        print("failed")
        print("Expected:",data_mixed_expected)
        print

# Generated at 2022-06-24 11:23:02.762244
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes(b'f' * 15) == [0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66,
                                    0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66, 0x66]

# Generated at 2022-06-24 11:23:06.911710
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    for i in range(len(SBOX_INV)):
        assert sub_bytes(sub_bytes_inv([i])) == [i]

# Generated at 2022-06-24 11:23:09.498447
# Unit test for function mix_column
def test_mix_column():
    assert mix_column([0xdb, 0x13, 0x53, 0x45], MIX_COLUMN_MATRIX) == [0x8e, 0x4d, 0xa1, 0xBC]



# Generated at 2022-06-24 11:23:14.861581
# Unit test for function aes_encrypt
def test_aes_encrypt():
    test_e_key_intlist = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    test_e_state_intlist = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]

# Generated at 2022-06-24 11:23:24.363087
# Unit test for function key_expansion
def test_key_expansion():
    data = [
        0x2b,0x7e,0x15,0x16,0x28,0xae,0xd2,0xa6,0xab,0xf7,0x15,0x88,0x09,0xcf,0x4f,0x3c
    ]

# Generated at 2022-06-24 11:23:35.095077
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6,
           0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]

    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
          0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F]


# Generated at 2022-06-24 11:23:38.083757
# Unit test for function mix_column
def test_mix_column():
    test_data = [0x5c, 0x8e, 0x5a, 0x9d]
    data_mixed = mix_column(test_data, MIX_COLUMN_MATRIX)
    if data_mixed == [0x68, 0xe2, 0x22, 0x1a]:
        print("test_mix_column pass")
    else:
        print("test_mix_column fail")


# Generated at 2022-06-24 11:23:45.685814
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    import base64
    from .utils import bytes_to_intlist, intlist_to_bytes
    from .cipher_state import CipherState
    test_key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    test_iv = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F')

# Generated at 2022-06-24 11:23:50.701331
# Unit test for function shift_rows
def test_shift_rows():
    data = [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
    assert shift_rows(data) == [0, 1, 2, 3, 5, 6, 7, 4, 10, 11, 8, 9, 15, 12, 13, 14]



# Generated at 2022-06-24 11:23:58.375966
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    # Vector input and output taken from AES specification http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    test_data = [0x63, 0x53, 0xE0, 0x8C, 0x09, 0x60, 0xE1, 0x04, 0xCD, 0x70, 0xB7, 0x51, 0xBA, 0xCA, 0xD0, 0xE7]
    assert (sub_bytes_inv(sub_bytes(test_data)) == test_data)



# Generated at 2022-06-24 11:24:06.382047
# Unit test for function aes_encrypt
def test_aes_encrypt():
    #print("Unit test for function aes_encrypt")
    data = [0x54, 0x77, 0x6F, 0x20, 0x4F, 0x6E, 0x65, 0x20, 0x4E, 0x69, 0x6E, 0x65, 0x20, 0x54, 0x77, 0x6F]
    expanded_key = key_expansion([0x54, 0x68, 0x61, 0x74, 0x73, 0x20, 0x6D, 0x79, 0x20, 0x4B, 0x75, 0x6E, 0x67, 0x20, 0x46, 0x75])

# Generated at 2022-06-24 11:24:12.491578
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from .compat import compat_b64encode
    from .utils import intlist_to_bytes

    iv = bytes_to_intlist('\x00' * 16)
    key = bytes_to_intlist('YELLOW SUBMARINE')
    data = bytes_to_intlist('Some text')
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert(compat_b64encode(intlist_to_bytes(encrypted_data)) == b'cNx6+R1cJXx82A5/qjttbg==')



# Generated at 2022-06-24 11:24:15.975747
# Unit test for function sub_bytes
def test_sub_bytes():
    test_data = [0x09, 0xcf, 0x4f, 0x3c]
    expected_result = [0x53, 0xca, 0x0b, 0x1a]
    assert sub_bytes(test_data) == expected_result
test_sub_bytes()


# Generated at 2022-06-24 11:24:20.061777
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert(mix_columns_inv(mix_columns([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16])) == [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16])


# Generated at 2022-06-24 11:24:29.825616
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0xa1, 0xfb, 0x57, 0x5d]
    data_expected = [0x02, 0x02, 0x02, 0x02, 0x03, 0x03, 0x03, 0x03, 0x01, 0x01, 0x01, 0x01, 0x1f, 0x1f, 0x1f, 0x1f]
    assert mix_columns_inv(data) == data_expected


# Generated at 2022-06-24 11:24:36.362835
# Unit test for function key_expansion
def test_key_expansion():
    print("Testing function key_expansion...")
    key = [0] * 16
    key[0] = 1

    expanded_key = key_expansion(key)

    if len(expanded_key) != 176:
        print("Error: The length of expanded key was wrong")
        exit(1)

    if len(expanded_key) != len(set(expanded_key)):
        print("Error: The expanded key contained duplicate blocks")
        exit(1)

    print("All tests successful!")



# Generated at 2022-06-24 11:24:42.994030
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test_data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns_inv(test_data)
    assert result == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01], "Mix column inv function not working"
    print("test_mix_columns_inv passed")

test_mix_columns_inv()


# Generated at 2022-06-24 11:24:47.220179
# Unit test for function sub_bytes

# Generated at 2022-06-24 11:24:55.647090
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    plaintext = [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76, 0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0]

# Generated at 2022-06-24 11:25:04.893456
# Unit test for function sub_bytes
def test_sub_bytes():
    input = []
    expected = []
    try:
        sub_bytes(input)
        assert(False)
    except ValueError:
        pass
    input = [0xFF]
    expected = [0xA3]
    output = sub_bytes(input)
    assert(expected == output)
    input = [0xAB, 0xAA]
    expected = [0xA3, 0xA2]
    output = sub_bytes(input)
    assert(expected == output)
    input = [0xAB, 0xAA, 0x87]
    expected = [0xA3, 0xA2, 0x86]
    output = sub_bytes(input)
    assert(expected == output)
    input = [0xAB, 0xAA, 0x87, 0x9E]

# Generated at 2022-06-24 11:25:16.667343
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    aes_cbc_data = (
        b'f20bdba6ff29eed7b046d1df9fb70000'
        b'58b1ffb4210a580f748b4ac714c001bd'
        b'4a61044426fb515dad3f21f18aa577c0'
        b'bdf302936266926ff37dbf7035d5eeb4'
    )
    aes_cbc_key = (
        b'140b41b22a29beb4061bda66b6747e14'
    )
    aes_cbc_iv = (
        b'4ca00ff4c898d61e1edbf1800618fb28'
    )

# Generated at 2022-06-24 11:25:24.625317
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-24 11:25:34.629847
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test vectors from: http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    vector_count = 4

# Generated at 2022-06-24 11:25:43.507685
# Unit test for function aes_decrypt
def test_aes_decrypt():
    counter = Counter(bytearray(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'))
    cipher_data = bytearray(b'\x69\xc4\xe0\xd8\x6a\x7b\x04\x30\xd8\xcd\xb7\x80\x70\xb4\xc5\x5a')
    key = bytearray(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

    decrypted_data

# Generated at 2022-06-24 11:25:53.191712
# Unit test for function key_schedule_core
def test_key_schedule_core():
    rcon_iteration = 0
    result = key_schedule_core([0x00, 0x00, 0x00, 0x00], rcon_iteration)
    assert result == [0x01, 0x00, 0x00, 0x00], result
    rcon_iteration = 1
    result = key_schedule_core([0x00, 0x00, 0x00, 0x00], rcon_iteration)
    assert result == [0x02, 0x00, 0x00, 0x00], result
    rcon_iteration = 2
    result = key_schedule_core([0x00, 0x00, 0x00, 0x00], rcon_iteration)
    assert result == [0x04, 0x00, 0x00, 0x00], result
    rcon_

# Generated at 2022-06-24 11:25:56.865790
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]
    assert rotate([1, 2, 3]) == [2, 3, 1]
    assert rotate([1, 2]) == [2, 1]
    assert rotate([1]) == [1]



# Generated at 2022-06-24 11:26:00.943417
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([1, 1, 1, 1]) == [1, 1, 2, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-24 11:26:07.980505
# Unit test for function shift_rows
def test_shift_rows():
    # Test with 0x01020304
    data = [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10]
    # Result
    result = [0x01, 0x05, 0x09, 0x0d, 0x02, 0x06, 0x0a, 0x0e, 0x03, 0x07, 0x0b, 0x0f, 0x04, 0x08, 0x0c, 0x10]
    assert shift_rows(data) == result
    # Test with 0xffeeddcc

# Generated at 2022-06-24 11:26:22.131791
# Unit test for function rijndael_mul
def test_rijndael_mul():
    result = rijndael_mul(0x57, 0x83)
    if (result != 0xc1):
        raise Exception('rijndael_mul unit test failed')
    result = rijndael_mul(0x83, 0x57)
    if (result != 0xc1):
        raise Exception('rijndael_mul unit test failed')
    result = rijndael_mul(0x13, 0x57)
    if (result != 0xfe):
        raise Exception('rijndael_mul unit test failed')
    result = rijndael_mul(0x57, 0x13)
    if (result != 0xfe):
        raise Exception('rijndael_mul unit test failed')
    print('rijndael_mul unit test passed')



# Generated at 2022-06-24 11:26:31.473820
# Unit test for function mix_column
def test_mix_column():
    #        data = [0x57, 0x83, 0x89, 0x8f]
    #        data_1 = [0xc6, 0x5c, 0x0f, 0x78]
    #        data_2 = [0x4a, 0x6e, 0x2e, 0x19]
    #        data_3 = [0x61, 0x0f, 0x83, 0x75]
    data_1 = [0x02, 0x03, 0x01, 0x01]
    data_2 = [0x01, 0x02, 0x03, 0x01]
    data_3 = [0x01, 0x01, 0x02, 0x03]
    data_4 = [0x03, 0x01, 0x01, 0x02]

    #

# Generated at 2022-06-24 11:26:40.060074
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Encryption with static key and static counter
    counter = Counter(b'\x00' * BLOCK_SIZE_BYTES)
    cipher = aes_ctr(
        b'\x00' * BLOCK_SIZE_BYTES,
        b'12345678abcdefgh',
        counter)
    assert (aes_ctr_decrypt(cipher, bytes_to_intlist(b'12345678abcdefgh'), counter)
            == bytes_to_intlist(b'\x00' * BLOCK_SIZE_BYTES))

    # Encryption with static key and incremented counter
    cipher = aes_ctr(
        bytes_to_intlist(b'1234567812345678'),
        bytes_to_intlist(b'12345678abcdefgh'),
        counter)

# Generated at 2022-06-24 11:26:44.837694
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-24 11:26:56.494259
# Unit test for function mix_columns
def test_mix_columns():
    matrix = MIX_COLUMN_MATRIX
    data = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected = [0x8E, 0x4D, 0xA1, 0xBC, 0x9F, 0xDC, 0x58, 0x9D, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]

    assert mix_columns(data, matrix) == expected

test_mix_columns()


# Generated at 2022-06-24 11:27:06.161118
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(compat_b64decode('sPvVjAuIGwg3Au2x/0jfaQ=='))

# Generated at 2022-06-24 11:27:20.271098
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-24 11:27:26.598988
# Unit test for function inc
def test_inc():
    data = [0] * 4
    data = inc(data)
    assert data == [1, 0, 0, 0]
    data = inc(data)
    assert data == [2, 0, 0, 0]
    data = [255, 255, 255, 255]
    data = inc(data)
    assert data == [0, 0, 0, 0]



# Generated at 2022-06-24 11:27:34.370557
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert mix_columns_inv(mix_columns([0xdb, 0x13, 0x53, 0x45,
                                   0xf2, 0x0a, 0x22, 0x5c,
                                   0x01, 0x01, 0x01, 0x01,
                                   0x01, 0x01, 0x01, 0x01])) == [0xdb, 0x13, 0x53, 0x45,
                                   0xf2, 0x0a, 0x22, 0x5c,
                                   0x01, 0x01, 0x01, 0x01,
                                   0x01, 0x01, 0x01, 0x01]

test_mix_columns_inv()


# Generated at 2022-06-24 11:27:37.016472
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print("Testing rijndael_mul...")
    assert rijndael_mul(0x57, 0x83) == 0xC1



# Generated at 2022-06-24 11:27:49.210225
# Unit test for function aes_decrypt_text

# Generated at 2022-06-24 11:28:01.473949
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    # Test Vector
    # 0xdb, 0x13, 0x53, 0x45
    # 0x53, 0x81, 0x19, 0x3d
    # 0x7e, 0xc1, 0x25, 0x26
    # 0x76, 0x14, 0xb2, 0xfd
    input_test = [0xdb, 0x13, 0x53, 0x45,
                  0x53, 0x81, 0x19, 0x3d,
                  0x7e, 0xc1, 0x25, 0x26,
                  0x76, 0x14, 0xb2, 0xfd]
    # 0x8e, 0x20, 0xfa, 0x67
    # 0x65, 0xd2, 0xb2, 0x32
    # 0x

# Generated at 2022-06-24 11:28:12.760541
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    test_matrix = [0xA5, 0x84, 0x99, 0x8D, 0x0D, 0xBD, 0xB1, 0x54, 0x50, 0xA1, 0x8C, 0x40, 0x3C, 0x0A, 0xD6, 0xBF,
                   0xD8, 0x9D, 0xD0, 0x5A, 0x8D, 0x30, 0x84, 0x25, 0xA1, 0x98, 0x70, 0xB7, 0xD5, 0x7F, 0x66, 0xF5]

# Generated at 2022-06-24 11:28:25.994872
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test cases from FIPS-197
    test_vectors = {
        '2b' * 16: '000102030405060708090a0b0c0d0e0f',  # 128 bit
        '8e' * 16: '000102030405060708090a0b0c0d0e0f1011121314151617',  # 192 bit
        '3a' * 16: '000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f',  # 256 bit
    }
    for plain_text, key in test_vectors.items():
        key = bytes_to_intlist(compat_b64decode(key))
        plain_text = bytes_to_

# Generated at 2022-06-24 11:28:31.028767
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x57, 0x83, 0xf9, 0x8e, 0x44, 0x3c, 0x60, 0x65, 0x1a, 0x6c, 0xda, 0x0d, 0x18, 0x98, 0x25, 0xfc]) == [0x76, 0x6b, 0x69, 0x3e, 0xee, 0x6d, 0x2e, 0x33, 0x8b, 0xfe, 0xe6, 0xfa, 0x22, 0xc1, 0xfa, 0xb9]



# Generated at 2022-06-24 11:28:36.767704
# Unit test for function aes_decrypt
def test_aes_decrypt():
    import pytest
    # aes_decrypt(data, expanded_key)
    data = "BxnkqeUb3qI3Jl2fXn+/Rg==".encode('ascii')
    data = bytes_to_intlist(compat_b64decode(data))
    expanded_key = 'a830f3e43e9c1e59d70cfd62e8aa873f97df18f07d7c142bec5a8a7b9c5edd87fa88a55b542ef3f0c3d87b1a28e04cad8b7a9bac85dd29d0c47cc0e8e4b2ce4d'.decode('hex')
    expanded_key = bytes_to_intlist(expanded_key)


# Generated at 2022-06-24 11:28:41.915600
# Unit test for function rijndael_mul
def test_rijndael_mul():
    # Test examples from FIPS-197, A.2
    assert rijndael_mul(0x57, 0x83) == 0xC1
    assert rijndael_mul(0x83, 0x57) == 0xC1
    assert rijndael_mul(0x13, 0x13) == 0x1B
    assert rijndael_mul(0x0E, 0x0B) == 0x7B
    assert rijndael_mul(0x0B, 0x0E) == 0x7B
    assert rijndael_mul(0x01, 0x01) == 0x01
    assert rijndael_mul(0x01, 0x02) == 0x02

# Generated at 2022-06-24 11:28:53.035635
# Unit test for function mix_columns
def test_mix_columns():
    print("\nUnit test for function mix_columns")
    data = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0x01, 0x01, 0x01, 0x01]
    data_mixed = [0x8e, 0x4d, 0xa1, 0xbc,
                  0x9f, 0xdc, 0x58, 0x9d,
                  0x01, 0x01, 0x01, 0x01,
                  0x01, 0x01, 0x01, 0x01]
    print("data = {}".format(data))
    data = mix_columns(data)
    print

# Generated at 2022-06-24 11:29:00.203675
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # AES-128 encryption example data from http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    test_cleartext = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    test_key = bytes_to_intlist(compat_b64decode('CY9rzUYh03PK3k6DJie09g=='))

# Generated at 2022-06-24 11:29:04.828212
# Unit test for function key_schedule_core
def test_key_schedule_core():
    test_value = [0x01, 0x02, 0x03, 0x04]
    expected_value = [0x01, 0x01, 0x01, 0x05]
    ret = key_schedule_core(test_value, 1)
    assert ret == expected_value, "Error in key_schedule_core. Test value: {}, expected value: {}, actual value: {}".format(test_value, expected_value, ret)
    print("Test for function key_schedule_core passed.")
# test_key_schedule_core()



# Generated at 2022-06-24 11:29:10.321201
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print('------------------------{}------------------------'.format(sys._getframe().f_code.co_name))
    for i in range(0x100):
        for j in range(0x100):
            if(rijndael_mul(i, j) != gf_mul(i, j)):
                print('i: {}, j: {}, ans: {}, gf_mul: {}'.format(i, j, rijndael_mul(i, j), gf_mul(i, j)))


# Generated at 2022-06-24 11:29:20.315222
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert [0x0, 0x1, 0x2, 0x3] == sub_bytes_inv(sub_bytes([0x0, 0x1, 0x2, 0x3]))

# Generated at 2022-06-24 11:29:25.581711
# Unit test for function inc
def test_inc():
    assert inc([1, 2, 3, 4]) == [1, 2, 3, 5]
    assert inc([3, 3, 3, 3]) == [3, 3, 3, 4]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-24 11:29:35.682490
# Unit test for function aes_decrypt_text

# Generated at 2022-06-24 11:29:42.310045
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Test Vectors
    # https://csrc.nist.gov/projects/cryptographic-algorithm-validation-program/block-ciphers
    key_strings = {'128': '2b7e151628aed2a6abf7158809cf4f3c', '192': '8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b', '256': '603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4'}
    key_bytes = dict((k, list(reversed(bytes_to_intlist(compat_b64decode(v))))) for k, v in key_strings.items())
    key_bytes

# Generated at 2022-06-24 11:29:52.768518
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(compat_b64decode('V2hhdCB3b3VsZCBhIFNvdW5kY2FyZC1zaGFyZWQgY3JlZiBkbyB3aXRoIGEgY3JlZg=='))
    key = bytes_to_intlist(compat_b64decode('QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejEyMzQ1Njc4OTA='))

# Generated at 2022-06-24 11:30:04.209864
# Unit test for function mix_columns
def test_mix_columns():
    pass
#
# def test_key_schedule_core():
#     keys = [0x2b, 0x28, 0xab, 0x09]
#     result = key_schedule_core(keys, 1)
#     print([hex(x) for x in result])
#     assert result == [0x56, 0xbc, 0xf0, 0x0a]
#
# def test_rotate():
#     data = [0x2b, 0x28, 0xab, 0x09]
#     result = rotate(data)
#     print(result)
#     assert result == [0x28, 0xab, 0x09, 0x2b]
#
# def test_sub_bytes():
#     data = [0x2b, 0x28, 0xab, 0x09

# Generated at 2022-06-24 11:30:06.500837
# Unit test for function rotate
def test_rotate():
    assert rotate([0x01, 0x23, 0x45, 0x67]) == [0x23, 0x45, 0x67, 0x01]



# Generated at 2022-06-24 11:30:14.470432
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key =       [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv  =       [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-24 11:30:25.355538
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0xab, 0xab, 0xab, 0xab]
    assert(mix_columns_inv(data) == [0x8e, 0x4d, 0xa1, 0xbc,
                                     0x9f, 0xdc, 0x58, 0x9d,
                                     0x01, 0x01, 0x01, 0x01,
                                     0xab, 0xab, 0xab, 0xab])
    print('test_mix_columns_inv [passed]')
test_mix_columns_inv()


# Generated at 2022-06-24 11:30:34.849833
# Unit test for function shift_rows
def test_shift_rows():
    assert shift_rows([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]) == [1, 2, 3, 4, 6, 7, 8, 5, 11, 12, 13, 9, 15, 16, 14, 10]
    assert shift_rows([1, 2, 3, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]) == [1, 2, 3, 3, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 5, 6]

# Generated at 2022-06-24 11:30:43.285571
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-24 11:30:53.697336
# Unit test for function inc
def test_inc():
    data = inc([0 for i in range(16)])
    assert data == [1 for i in range(16)]
    data = inc([0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff])
    assert data == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    data = inc([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    assert data == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]



# Generated at 2022-06-24 11:30:58.257328
# Unit test for function inc
def test_inc():
    data = b'\x00' * 16
    assert inc(data) == b'\x01' * 16
    data = b'\xFF' * 15 + b'\xFE'
    assert inc(data) == b'\x01' + b'\x00' * 15

# Generated at 2022-06-24 11:31:07.802577
# Unit test for function mix_columns
def test_mix_columns():
    # Without mix columns
    data = [0xdb, 0xf2, 0xd4, 0xab,
            0x2a, 0x22, 0x79, 0x2b,
            0xb3, 0x39, 0xbe, 0xa4,
            0x4b, 0x29, 0x7d, 0x8d]
    assert mix_columns(data) == [0x04, 0xe0, 0x48, 0x28,
                                 0x66, 0xcb, 0xf8, 0x06,
                                 0x81, 0x19, 0xd3, 0x26,
                                 0xe5, 0x9a, 0x7a, 0x4c]
    # With mix columns

# Generated at 2022-06-24 11:31:18.648915
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
        data = [0xdb, 0x13, 0x53, 0x45,
                0xf2, 0x0a, 0x22, 0x5c,
                0x01, 0x01, 0x01, 0x01,
                0xab, 0xab, 0xab, 0xab]
        data_mixed = mix_columns_inv(data)
        data_unmixed = mix_columns(data_mixed, MIX_COLUMN_MATRIX_INV)
        assert data_unmixed == data

test_mix_columns_inv()

# Generated at 2022-06-24 11:31:28.982342
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter

    class ExampleAESCounter(AESCounter):
        """
        Example implementation of AESCounter (which must be extended)
        """

        def __init__(self):
            AESCounter.__init__(self)
            self.current_value_hexstr = '00000000000000000000000000000000'

        def next_value(self):
            """
            Return next counter block
            """
            self.current_value_intlist = bytes_to_intlist(
                compat_b64decode(self.current_value_hexstr))

            self.current_value_hexstr = intlist_to_hexstr(
                self.increment_big_endian(self.current_value_intlist))

            return self.current_value_intlist