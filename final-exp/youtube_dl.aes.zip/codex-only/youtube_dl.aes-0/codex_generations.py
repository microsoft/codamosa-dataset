

# Generated at 2022-06-24 11:21:31.932642
# Unit test for function sub_bytes
def test_sub_bytes():
    test_sub_bytes = [0x19, 0xa0, 0x9a, 0xe9, 0x3d, 0xf4, 0xc6, 0xf8, 0xe3, 0xe2, 0x8d, 0x48, 0xbe, 0x2b, 0x2a, 0x08]
    assert sub_bytes(test_sub_bytes) == [0xd4, 0xe0, 0xb8, 0x1e, 0x27, 0xbf, 0xb4, 0x41, 0x11, 0x98, 0x5d, 0x52, 0xae, 0xf1, 0xe5, 0x30]
# Test case for function sub_bytes
test_sub_bytes()


# Generated at 2022-06-24 11:21:40.042578
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'key1234567890123456')
    iv = bytes_to_intlist(b'iv1234567890123456')
    data = bytes_to_intlist(b'TEST STRING')
    cipher = aes_cbc_encrypt(data, key, iv)
    assert cipher == [90, 53, 163, 139, 102, 60, 182, 191, 188, 94, 33, 193, 247, 102, 224, 190]
    assert intlist_to_bytes(cipher) == b'Z5\xa3\x8bf<\xb6\xbf\xbc^!\xc1\xf7f\xe0\xbe'

# Generated at 2022-06-24 11:21:47.695965
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
  data = bytes_to_intlist(b'ABCDEF123')
  key = bytes_to_intlist(b'1234567891234567')
  iv = bytes_to_intlist(b'0123456789ABCDEF')
  res = aes_cbc_encrypt(data, key, iv)
  assert res == [11, 224, 30, 73, 160, 160, 160, 160, 160, 160, 160, 160, 160, 160, 160, 160]
  return 'test_aes_cbc_encrypt passed'
print(test_aes_cbc_encrypt())


# Generated at 2022-06-24 11:21:53.505559
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print('Testing rijndael_mul')
    print('Expected value: 0. Got value:', rijndael_mul(0x57, 0x83))
    if(rijndael_mul(0x57, 0x83) == 0xC1):
        print('Test passed')
    else:
        print('Test failed')
    print()



# Generated at 2022-06-24 11:21:57.631200
# Unit test for function sub_bytes
def test_sub_bytes():
    a = [0x1b, 0x37, 0x37, 0x33, 0x3a, 0x36, 0x3f, 0x40, 0x40, 0x20, 0x2d, 0x2e, 0x0e, 0x0e, 0x0e, 0x13]
    b = sub_bytes(a)
    for x in range(len(a)):
        assert(a[x] != b[x])
    return True
# Function for shiting the unit in the array by specified count

# Generated at 2022-06-24 11:22:05.490613
# Unit test for function shift_rows

# Generated at 2022-06-24 11:22:07.552425
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert [SBOX_INV[x] for x in [SBOX[x] for x in range(256)]] == list(range(256))



# Generated at 2022-06-24 11:22:11.063924
# Unit test for function inc
def test_inc():
    assert inc([0]) == [1]
    assert inc([255]) == [0]
    assert inc([0, 0]) == [0, 1]
    assert inc([0, 255]) == [1, 0]
    assert inc([255, 255]) == [0, 0]



# Generated at 2022-06-24 11:22:21.039234
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Basic
    key = bytes_to_intlist(compat_b64decode(b'6CgqJzKX+tI4lAhDm1cLUA=='))
    iv = bytes_to_intlist(compat_b64decode(b'2Bdu/NbZd7vd/N27pG66Pw=='))
    inp = bytes_to_intlist(compat_b64decode(b'8jJyp5Adun/s1sR2uI6qvg=='))

    out = aes_cbc_encrypt(inp, key, iv)

    assert out == bytes_to_intlist(compat_b64decode(b'rBEhTf1JjY6ibfU+x/zcUA=='))
    #

# Generated at 2022-06-24 11:22:23.008585
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    test_data = [0x5e, 0x7a, 0x5a, 0x4c]
    test_data_rev = sub_bytes_inv(sub_bytes(test_data))
    assert test_data_rev == test_data



# Generated at 2022-06-24 11:22:32.317587
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-24 11:22:39.916853
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key = [0x2b, 0x28, 0xab, 0x09]
    rcon_iteration = 1
    output = key_schedule_core(key, rcon_iteration)
    output = [x for x in output]
    assert output == [0xa0, 0x88, 0x23, 0x2a]
    key = [0x56, 0x77, 0x91, 0x1F]
    rcon_iteration = 2
    output = key_schedule_core(key, rcon_iteration)
    output = [x for x in output]
    assert output == [0xC5, 0xFA, 0x92, 0xA3]

# Generated at 2022-06-24 11:22:40.787798
# Unit test for function rotate
def test_rotate():
    assert(rotate([1, 2, 3, 4]) == [2, 3, 4, 1])


# Generated at 2022-06-24 11:22:45.124141
# Unit test for function mix_column
def test_mix_column():
    print(bytes(mix_column([0xDB, 0x13, 0x53, 0x45], MIX_COLUMN_MATRIX)))
    assert bytes(mix_column([0xDB, 0x13, 0x53, 0x45], MIX_COLUMN_MATRIX)) == b'\x8e\x4d\xa1\xbc'
    assert bytes(mix_column([0x01, 0x02, 0x03, 0x04], MIX_COLUMN_MATRIX)) == b'\x01\x02\x03\x04'
    print('All passed')

# Generated at 2022-06-24 11:22:51.501090
# Unit test for function aes_decrypt

# Generated at 2022-06-24 11:22:56.136540
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0x01, 0x01, 0x01, 0x01]
    data_mixed = [0x8e, 0x4d, 0xa1, 0xbc,
                  0x9f, 0xdc, 0x58, 0x9d,
                  0x01, 0x01, 0x01, 0x01,
                  0x01, 0x01, 0x01, 0x01]
    assert(mix_columns(data) == data_mixed)
    print('[+] test_mix_columns: ok')
# test_mix_columns

# Generated at 2022-06-24 11:22:58.374234
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    for i in range(256):
        y = sub_bytes(sub_bytes_inv([i]))

# Generated at 2022-06-24 11:23:08.214958
# Unit test for function aes_encrypt
def test_aes_encrypt():
    result = aes_encrypt([0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0x07, 0xa8, 0x8d, 0xa2, 0x34], key_expansion([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]))

# Generated at 2022-06-24 11:23:12.893172
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    """Unit test for function mix_columns_inv"""
    test = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0x01, 0x01, 0x01, 0x01]
    expected = [0x8e, 0x4d, 0xa1, 0xbc,
                0x9f, 0xdc, 0x58, 0x9d,
                0x01, 0x01, 0x01, 0x01,
                0x01, 0x01, 0x01, 0x01]
    assert expected == mix_columns_inv(test)
    print("test_mix_columns_inv passed")



# Generated at 2022-06-24 11:23:18.714125
# Unit test for function mix_column
def test_mix_column():
    # This is the result of multiplying the 0th row vector of the matrix on the left
    # by the vector on the right
    test_input = [0x02, 0x01, 0x01, 0x03]
    test_output = [0x0e, 0x09, 0x0d, 0x0b]
    assert test_output == mix_column(test_input, MIX_COLUMN_MATRIX)

    # This is the result of multiplying the 2nd row vector of the matrix on the left
    # by the vector on the right
    test_input = [0x01, 0x01, 0x02, 0x03]
    test_output = [0x09, 0x0e, 0x0b, 0x0d]

# Generated at 2022-06-24 11:23:23.981228
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x7E, 0x39, 0x4A, 0x7C]
    data_result = [0x63, 0xEB, 0x9F, 0xA0]
    data = sub_bytes(data)
    print(data_result == data)
#test_sub_bytes()


# Generated at 2022-06-24 11:23:35.068571
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode(
        "qCJq5/f/Lg47a5NvJmXnCw=="))
    iv = bytes_to_intlist(compat_b64decode(
        "ZDpWPVn0A5FvX0htr1EPZg=="))
    data = bytes_to_intlist(compat_b64decode(
        "XriWtH8VWFz0x5O+OZzD3qr5/B7TGkzc/4/X9q3/IoU="))


# Generated at 2022-06-24 11:23:39.379803
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist(compat_b64decode('K7NYW3SP8rvQcAqrhJDdgA=='))
    cipher = bytes_to_intlist(compat_b64decode('oN/k/pJt+B0TtXosTtT7fA=='))
    expanded_key = key_expansion(key)
    result = aes_decrypt(cipher, expanded_key)
    assert result == [195, 105, 25, 133, 128, 77, 217, 11, 160, 162, 176, 194, 144, 65, 235, 39]

# Generated at 2022-06-24 11:23:44.676073
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [99] * 16
    iv = [114] * 16
    data_in = [114] * 16
    data_out = aes_cbc_decrypt(data_in, key, iv)
    assert data_out == [0] * 16

# Generated at 2022-06-24 11:23:49.907994
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0x01, 0x01, 0x01, 0x01]
    data = mix_columns(data)
    expected_data = [0x8e, 0x4d, 0xa1, 0xbc,
                     0x9f, 0xdc, 0x58, 0x9d,
                     0x01, 0x01, 0x01, 0x01,
                     0x01, 0x01, 0x01, 0x01]
    assert data == expected_data


# Generated at 2022-06-24 11:24:02.295024
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
           0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    expanded_key = key_expansion(key)

# Generated at 2022-06-24 11:24:05.407452
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3]) == [2, 3, 1]
    assert rotate([1, 1, 2, 3]) == [1, 2, 3, 1]

# Generated at 2022-06-24 11:24:13.299214
# Unit test for function inc
def test_inc():
    # test sanity
    assert inc([0]) == [1]
    assert inc([1]) == [2]
    assert inc([254]) == [255]
    assert inc([255]) == [0]
    # test overflow
    assert inc([0, 0]) == [0, 1]
    assert inc([0, 1]) == [0, 2]
    assert inc([254, 255]) == [255, 0]
    assert inc([255, 0]) == [255, 1]
    assert inc([255, 255]) == [0, 0]
    # test sanity
    assert inc([0, 1, 2]) == [0, 1, 3]
    assert inc([0, 1, 255]) == [0, 2, 0]
    assert inc([255, 255, 255]) == [0, 0, 0]


# Generated at 2022-06-24 11:24:22.630753
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Adapted from: https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38a.pdf
    key = [40, 52, 62, 27, 121, 219, 226, 19, 155, 175, 10, 90, 39, 96, 51, 221]
    counter = CounterJavascript(0)


# Generated at 2022-06-24 11:24:32.161589
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = '000102030405060708090A0B0C0D0E0F'.decode('hex')
    data = '00112233445566778899AABBCCDDEEFF'.decode('hex')
    cipher = '69C4E0D86A7B0430D8CDB78070B4C55A'.decode('hex')

    expanded_key = key_expansion(key)
    decrypted_data = aes_decrypt(cipher, expanded_key)

    if decrypted_data == data:
        print("Test for aes_decrypt passed.")
    else:
        print("Test for aes_decrypt failed.")



# Generated at 2022-06-24 11:24:40.831219
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist(compat_b64decode('sZsPTTzTg8j+m0zJkYHdXA=='))
    encrypted = bytes_to_intlist(compat_b64decode('/tR+YkE/XSE+a/Npzd3rLA=='))
    expected = bytes_to_intlist(compat_b64decode('Karina Janáková'))
    expanded_key = key_expansion(key)
    decrypted = aes_decrypt(encrypted, expanded_key)
    assert decrypted == expected
    # print('aes_decrypt: OK')



# Generated at 2022-06-24 11:24:48.338365
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    msg = [0x19, 0xa0, 0x9a, 0xe9, 0x3d, 0xf4, 0xc6, 0xf8, 0xe3, 0xe2, 0x8d, 0x48, 0xbe, 0x2b, 0x2a, 0x08]
    sub_bytes_inv_result = [0xd4, 0xe0, 0xb8, 0x1e, 0x27, 0xbf, 0xb4, 0x41, 0x11, 0x98, 0x5d, 0x52, 0xae, 0xf1, 0xe5, 0x30]
    assert sub_bytes_inv(msg) == sub_bytes_inv_result
    print("sub_bytes_inv function is correct")


# Generated at 2022-06-24 11:24:57.828284
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = compat_b64decode('AQABAQAtAQhBAwNB/wMAAQAAPgAWADRANXAHmAGQAZwA6AHYAMgA0AFsAOQB3ADQAOAArAGkATgAzADUAeABdADoAcwBSAFwAfwBTAHkAcwBzAE0AVQBRAGEAZwBPAHAAUAB7AEUASABANGhxcwV2dWQ1OXVfXmx9XmZxLQ==')
    password = 'password'
    key_size_bytes = 16
    decrypted_data = aes_decrypt_text(data, password, key_size_bytes)

# Generated at 2022-06-24 11:25:05.859935
# Unit test for function mix_columns
def test_mix_columns():
    print("Testing mix_columns...")
    data = [0x01, 0x02, 0x03, 0x01, 0x01, 0x02, 0x03, 0x01, 0x01, 0x02, 0x03, 0x01, 0x01, 0x02, 0x03, 0x01]
    expected = [0x02, 0x03, 0x01, 0x01, 0x01, 0x02, 0x03, 0x01, 0x01, 0x02, 0x03, 0x01, 0x02, 0x03, 0x01, 0x01]
    actual = mix_columns(data)
    assert(expected == actual)
    print("mix_columns passed unit test")

test_mix_columns()



# Generated at 2022-06-24 11:25:17.315460
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data_bytes = compat_b64decode(b'CRIwqt4+szDbqkNY+I0qbNXPg1XLaCM5etQ5Bt9DRFV/xIN2k8Go7jtArLIyP605'
                                  b'4dM47Xxxp7axagf2ab7eDm+SehUkC7h6yk2wI48Ss8LcGcY0rPpCJ4mwKZxuR8Fz'
                                  b'0OfqBqs4tIb6VgqGtV6z0vj/3r3Jrlkt3efj+m9dJYsQ==')

# Generated at 2022-06-24 11:25:21.917781
# Unit test for function aes_decrypt
def test_aes_decrypt():
    cipher = aes_encrypt(list(range(16)), key_expansion(list(range(16))))
    assert cipher == [100, 0, 75, 45, 79, 159, 213, 254, 154, 122, 2, 254, 68, 189, 133, 254]
    assert aes_decrypt(cipher, key_expansion(list(range(16)))) == list(range(16))



# Generated at 2022-06-24 11:25:33.902305
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    test_data = '6bc1bee22e409f96e93d7e117393172a'
    key = '2b7e151628aed2a6abf7158809cf4f3c'
    iv = '000102030405060708090a0b0c0d0e0f'
    expected_result = '7649abac8119b246cee98e9b12e9197d'
    data = bytes_to_intlist(compat_b64decode(test_data.encode('utf-8')))
    key = bytes_to_intlist(compat_b64decode(key.encode('utf-8')))
    iv = bytes_to_intlist(compat_b64decode(iv.encode('utf-8')))
    result = int

# Generated at 2022-06-24 11:25:42.944658
# Unit test for function key_schedule_core
def test_key_schedule_core():
    test_input1 = [0x2b, 0x28, 0xab, 0x09]
    # Round 1
    expected_output1 = [0x80, 0x1b, 0x36, 0x6c]
    assert expected_output1 == key_schedule_core(test_input1, 1)
    # Round 2
    expected_output2 = [0x46, 0x7f, 0xf2, 0xf9]
    assert expected_output2 == key_schedule_core(expected_output1, 2)
    # Round 3
    expected_output3 = [0x5e, 0xed, 0x6a, 0x70]
    assert expected_output3 == key_schedule_core(expected_output2, 3)
    # Round 4

# Generated at 2022-06-24 11:25:52.817752
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns(data)
    data_mixed_expected = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
                           0x01]
    if data_mixed != data_mixed_expected:
        raise Exception
    print("mix_columns() test ok")



# Generated at 2022-06-24 11:25:58.813096
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data_shifted = shift_rows_inv([
        0x63, 0xca, 0xb7, 0x04, 0xc0, 0xf2, 0x6f, 0x6b, 0x77, 0x7b, 0xf2, 0xc0, 0x04, 0x6b, 0xca, 0x63
    ])
    print(data_shifted)

    data_shifted = shift_rows_inv([
        0x8e, 0x9f, 0x12, 0x2d, 0x13, 0xfd, 0x5d, 0x56, 0x52, 0x55, 0xfd, 0x20, 0x2d, 0x5d, 0x12, 0x9f
    ])
    print(data_shifted)



# Generated at 2022-06-24 11:26:05.218450
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    print("Start testing function mix_columns_inv()")
    test_data = [0xDB,0x13,0x53,0x45,0xF2,0x0A,0x22,0x5C,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01]
    mix_col_inv = mix_columns_inv(test_data)
    print("mix_columns_inv() result = ", mix_col_inv)
    print("End testing function mix_columns_inv()")

test_mix_columns_inv()


# Generated at 2022-06-24 11:26:10.401507
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    value = [x for x in range(0, 256)]

    print("Unit test for function sub_bytes_inv")
    assert value == sub_bytes_inv(sub_bytes(value)), "Unit test for function sub_bytes_inv failed"
    print("Unit test for function sub_bytes_inv succeeded")


# Generated at 2022-06-24 11:26:12.538268
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3,4]) == [2,3,4,1]


# Generated at 2022-06-24 11:26:18.465265
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xaa,0xbb,0xcc,0xdd,0xee,0xff]
    data_expected = [0x63,0x7C,0x77,0x7B,0xF2,0x6B,0x6F,0xC5,0x30,0x01,0x67,0x2B,0xFE,0xD7,0xAB,0x76]
    data_actual = sub_bytes(data)
    assert data_expected==data_actual, "Test sub_bytes failed."
test_sub_bytes()


# Generated at 2022-06-24 11:26:23.243806
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x2b, 0x28, 0xab, 0x09]
    rcon_iteration = 1
    expected = [0x00, 0x0c, 0x0d, 0x09]
    assert key_schedule_core(data, rcon_iteration) == expected
    print(key_schedule_core(data, rcon_iteration))
test_key_schedule_core()


# Generated at 2022-06-24 11:26:31.287798
# Unit test for function aes_encrypt
def test_aes_encrypt():
    text = '000102030405060708090a0b0c0d0e0f'.encode('ascii')
    key = '101112131415161718191a1b1c1d1e1f'.encode('ascii')
    iv = key

    encrypted = aes_cbc_encrypt(bytes_to_intlist(text), bytes_to_intlist(key), bytes_to_intlist(iv))
    encrypted = intlist_to_bytes(encrypted)
    assert encrypted == 'B3B06813D09B15E58EE1BD906F2C7362'.encode('ascii')



# Generated at 2022-06-24 11:26:38.072229
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = map(ord, "YELLOW SUBMARINE")
    counter = Counter.from_int(0)
    encrypted = bytes_to_intlist(compat_b64decode("""QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F""".replace(' ', '')))
    decrypted = aes_ctr_decrypt(encrypted, key, counter)

    assert intlist_to_bytes(decrypted) == b"I'm back and I'm ringin' the bell"
    print(intlist_to_bytes(decrypted))



# Generated at 2022-06-24 11:26:50.034044
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test vector from http://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38a.pdf, appendix F
    cipher = bytes_to_intlist('4CA64EF4B4B4378E4D638F77C51761C6')
    key = bytes_to_intlist('2B7E151628AED2A6ABF7158809CF4F3C')
    iv = bytes_to_intlist('F0F1F2F3F4F5F6F7F8F9FAFBFCFDFEFF')
    data = aes_cbc_decrypt(cipher, key, iv)

# Generated at 2022-06-24 11:26:55.572473
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0x35, 0x08, 0x13, 0x2b, 0x28, 0x2e, 0x33, 0x0a, 0x32, 0x3a, 0x0c, 0x0d, 0x07, 0x2d, 0x0a, 0x01]
    data_mixed = mix_columns_inv(data)
    assert data_mixed == [0x53, 0xfb, 0x10, 0x20, 0x5e, 0x7f, 0x43, 0x2f, 0xd9, 0xc8, 0xcf, 0x34, 0xef, 0x3c, 0x54, 0xa5]
test_mix_columns_inv()



# Generated at 2022-06-24 11:27:05.661051
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0xab, 0xab, 0xab, 0xab]
    data = mix_columns_inv(data)
    assert(data == [0x75, 0xdb, 0xc3, 0x25,
                    0x13, 0x53, 0x0a, 0x65,
                    0x01, 0x01, 0x01, 0x01,
                    0xab, 0xab, 0xab, 0xab])
    print('mix_columns_inv pass unit test')



# Generated at 2022-06-24 11:27:18.219692
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    mix_columns_test = mix_columns([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
                                   ((1, 2, 3, 4),
                                    (2, 3, 4, 1),
                                    (3, 4, 1, 2),
                                    (4, 1, 2, 3)))
    mix_columns_test_inv = mix_columns_inv(mix_columns_test)
    print(mix_columns_test_inv)
# test_mix_columns_inv()

# Generated at 2022-06-24 11:27:24.574995
# Unit test for function inc
def test_inc():
    assert(inc([10, 10, 10, 10]) == [10, 10, 10, 11])
    assert(inc([10, 10, 10, 255]) == [10, 10, 11, 0])
    assert(inc([10, 10, 255, 255]) == [10, 11, 0, 0])
    assert(inc([255, 255, 255, 255]) == [0, 0, 0, 0])


# Generated at 2022-06-24 11:27:27.392549
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert shift_rows_inv([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]) == [0, 1, 2, 3, 5, 6, 7, 4, 10, 11, 8, 9, 15, 12, 13, 14]



# Generated at 2022-06-24 11:27:35.038672
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x01, 0x02, 0x03, 0x04]
    assert key_schedule_core(data, 2) == [0x01, 0x02, 0x05, 0x0a]
    assert key_schedule_core(data, 3) == [0x01, 0x02, 0x0a, 0x14]
    assert key_schedule_core(data, 7) == [0x01, 0x02, 0x22, 0x81]


test_key_schedule_core()



# Generated at 2022-06-24 11:27:43.011819
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
  # From https://csrc.nist.gov/csrc/media/projects/cryptographic-standards-and-guidelines/documents/examples/aes_core128.pdf
  import binascii
  # key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
  # iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0

# Generated at 2022-06-24 11:27:51.717104
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(compat_b64decode('/XYq8MqY1EIhLz/M9F9+Zg=='))
    key = bytes_to_intlist('yqI1YowEiLc/z9F9ZM+'.encode('ASCII'))
    expanded_key = bytes_to_intlist(compat_b64decode('Jc7Z2Qvksrkw33V+mOtFm7pPYdDm0TuVuXjX3dZ3Cag='))
    expected_result = bytes_to_intlist(compat_b64decode('Qz/6o4PZ+mWP6JlUjw0QYQ=='))

# Generated at 2022-06-24 11:27:56.490682
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0xFF, 0x05, 0x10, 0x0B]
    expected = [0xFF, 0x66, 0x9A, 0xEB]
    result = sub_bytes(data)
    for i in range(0, 4):
        assert result[i] == expected[i]


# Generated at 2022-06-24 11:28:06.712594
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert(rijndael_mul(0x57, 0x83) == 0xC1)
    assert(rijndael_mul(0x57, 0x13) == 0xFE)
    assert(rijndael_mul(0xCA, 0xFE) == 0x17)
    assert(rijndael_mul(0xCA, 0x13) == 0xD3)
    assert(rijndael_mul(0xCA, 0x01) == 0xCA)
    assert(rijndael_mul(0xCA, 0x02) == 0x94)
    assert(rijndael_mul(0xCA, 0x03) == 0x4E)

# Generated at 2022-06-24 11:28:18.855823
# Unit test for function inc
def test_inc():
    data = [0 for i in range(16)]
    data = inc(data)
    assert(data == [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    data = inc(data)
    assert(data == [2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    data = inc(data)
    assert(data == [3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    data = [255 for i in range(16)]
    data = inc(data)

# Generated at 2022-06-24 11:28:26.110226
# Unit test for function inc
def test_inc():
    assert(inc([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x01])
    assert(inc([0x00, 0x00, 0x00, 0xFF]) == [0x00, 0x00, 0x01, 0x00])
    assert(inc([0xFF, 0xFF, 0xFF, 0xFF]) == [0x00, 0x00, 0x00, 0x00])
    print("inc test passed")



# Generated at 2022-06-24 11:28:35.842456
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
	clear_data = "This is test data that needs to be encrypted."
	print('Clear data:', clear_data)
	key = '12345678123456781234567812345678'
	iv = 0x12345678123456781234567812345678
	
	print('key + iv length: ', len(key+iv))
	print('key:', key)
	print('iv:', iv)
	
	data = bytes_to_intlist(bytearray(clear_data, 'utf-8'))
	print(data)
	key = bytes_to_intlist(bytearray(key, 'utf-8'))
	print(key)
	# iv = bytes_to_intlist(bytearray(iv, 'utf-8'))
	# print(iv)
	


# Generated at 2022-06-24 11:28:47.647345
# Unit test for function mix_column
def test_mix_column():
    assert mix_column([0xdb,0x13,0x53,0x45],[(0x02,0x03,0x01,0x01),(0x01,0x02,0x03,0x01),(0x01,0x01,0x02,0x03),(0x03,0x01,0x01,0x02)])==[0x8e,0x4d,0xa1,0xbc]

# Generated at 2022-06-24 11:28:55.214690
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'yI6X8Y2UyYiGzrOj')
    iv = bytes_to_intlist(compat_b64decode(b'TzM0TkY0QkQxRU8='))
    encrypted = aes_cbc_encrypt([], key, iv)
    assert intlist_to_bytes(encrypted) == b' w/\xde\x7f\xe9\xa5\xcb\x17\xda\xfd\x02\xfd\x03\x00\x00\x00\x00\x00'
# End unit test



# Generated at 2022-06-24 11:29:03.377909
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    print ("Unit test for function sub_bytes_inv")
    for i in range(len(SBOX)):
        s = sub_bytes_inv([SBOX[i]])[0]
        if s != i:
            print ("Error when i=0x%X" % i)
            return
    print ("Finished unit test for function sub_bytes_inv")
    
    

# Generated at 2022-06-24 11:29:10.932572
# Unit test for function aes_encrypt
def test_aes_encrypt():
    ciphertext_aes = '1ab7d8d167c2d7f3e3bf3ce7d8eac7841e7fe5c363e99f5'
    cipher_aes = aes_encrypt(bytes_to_intlist(compat_b64decode(ciphertext_aes)), \
                             bytes_to_intlist("b8bf1916f79e0f6a320e2aab85f2ce2c7d3e72e1f743ddd"))
    assert cipher_aes == bytes_to_intlist("4d4c59ff42f912bc6d1149d29dd2ba7bf93139e3c6b162ea")



# Generated at 2022-06-24 11:29:20.268930
# Unit test for function aes_encrypt

# Generated at 2022-06-24 11:29:30.517774
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x63, 0x53, 0xe0, 0x8c, 0x09, 0x60, 0xe1, 0x04, 0xcd, 0x70, 0xb7, 0x51,
            0xba, 0xca, 0xd0, 0xe7, 0x82, 0x91, 0x6e, 0xc2, 0x6a, 0x2f, 0xcb, 0xe8,
            0x20, 0xef, 0xbf, 0xb3, 0x18, 0x1d, 0xa0, 0x5a, 0x52, 0x3b, 0xd6, 0xb3,
            0x29, 0xe3, 0x2f, 0x84]
    data_shifted = shift_rows(data)
    # 128 bit key
   

# Generated at 2022-06-24 11:29:36.554282
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter:
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value += 1
            return self.value

    data = bytes_to_intlist(b"\x17\x99\x8d\x15\x9a\xcd\x9f\x1a\x7f\x0e\x04\x8e\x93\x03\xed\x7f")
    key = bytes_to_intlist(b"\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f")
    counter = Counter(1)
    output = aes_ctr_

# Generated at 2022-06-24 11:29:47.508456
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(compat_b64decode('Qk5HMmtNekF5d3V3eHZxOEpjM1RlZ1d5bE9oQ2V5cjhWdDVCS3FsNVkzNWpJRk1C'))
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]

# Generated at 2022-06-24 11:29:55.279223
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    print("Function aes_cbc_encrypt")

# Generated at 2022-06-24 11:30:01.541077
# Unit test for function aes_decrypt
def test_aes_decrypt():
    from .test_values import aes_enc_dec_test_values
    for key, data, cipher in aes_enc_dec_test_values:
        decrypted = aes_decrypt(cipher, key_expansion(key))
        assert decrypted == data



# Generated at 2022-06-24 11:30:10.180140
# Unit test for function aes_encrypt

# Generated at 2022-06-24 11:30:14.797359
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]
    assert rotate([]) == []



# Generated at 2022-06-24 11:30:25.252165
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x02, 0x04, 0x05, 0x08, 0x09, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1D, 0x1E, 0x1F, 0x20, 0x21]
    data_shifted = shift_rows_inv(data)
    assert(data_shifted == [0x02, 0x09, 0x15, 0x1E, 0x04, 0x17, 0x18, 0x20, 0x05, 0x1A, 0x1D, 0x21, 0x08, 0x19, 0x1F, 0x16])


# Generated at 2022-06-24 11:30:33.431944
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist('00112233445566778899aabbccddeeff')
    expanded_key = bytes_to_intlist('000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f')
    cipher = aes_encrypt(data, expanded_key)
    if not intlist_to_bytes(cipher) == b'69c4e0d86a7b0430d8cdb78070b4c55a':
        print('test_aes_encrypt failed')



# Generated at 2022-06-24 11:30:38.684969
# Unit test for function inc
def test_inc():
    print('Testing unit inc')
    assert([0x01] == inc([0x00]))
    assert([0x00, 0x01] == inc([0x00, 0x00]))
    assert([0x00, 0x01] == inc([0xff, 0xff]))
    assert([0x01, 0x00] == inc([0xff, 0xff, 0xff, 0xff]))
    print('Passed')



# Generated at 2022-06-24 11:30:42.239836
# Unit test for function xor
def test_xor():
    data1 = [17, 16, 37, 161]
    data2 = [16, 17, 161, 37]
    data = xor(data1, data2)
    assert data == [1, 1, 224, 128]



# Generated at 2022-06-24 11:30:50.705097
# Unit test for function key_expansion
def test_key_expansion():
    # 16-Byte key
    key = bytes_to_intlist("2b7e151628aed2a6abf7158809cf4f3c")
    expanded_key = bytes_to_intlist("2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da56a784d9045190cfef324e7738926cfbe9fcaa3a2070c4d8df93fae0a633a7d9b8cc873c23dc62b8f4a42c8")
    if key_expansion(key) != expanded_key:
        return False

    # 24-Byte key

# Generated at 2022-06-24 11:30:57.616895
# Unit test for function xor
def test_xor():
    data1=[0x2b,0x7e,0x15,0x16,0x28,0xae,0xd2,0xa6,0xab,0xf7,0x15,0x88,0x09,0xcf,0x4f,0x3c]
    data2=[0x32,0x43,0xf6,0xa8,0x88,0x5a,0x30,0x8d,0x31,0x31,0x98,0xa2,0xe0,0x37,0x07,0x34]
    res=xor(data1,data2)

# Generated at 2022-06-24 11:31:00.405649
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range(256):
        for b in range(256):
            assert rijndael_mul(a,b) == (a*b)%0xFF


# Generated at 2022-06-24 11:31:09.340265
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert b'This is a test!' == aes_decrypt_text(b'AbRbfBZ1ToE +n2WtPfBbQ==', b'123', 16)
    assert b'This is a test!' == aes_decrypt_text(b'jU4p6b4zcUYsiwU14eVxDg==', b'12345678', 24)
    assert b'This is a test!' == aes_decrypt_text(b'qZgxPcTVaFYf9XBeVyqB3w==', b'1234567890123456', 32)



# Generated at 2022-06-24 11:31:21.105167
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # 128-bit key test vector
    k = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    # 16-byte plain text
    p = [0x6b, 0xc1, 0xbe, 0xe2, 0x2e, 0x40, 0x9f, 0x96, 0xe9, 0x3d, 0x7e, 0x11, 0x73, 0x93, 0x17, 0x2a]

    aes_result = aes_encrypt(p, key_expansion(k))
    decrypted_result = aes_dec

# Generated at 2022-06-24 11:31:30.528994
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('6C3YBpqemjxecgX9X9WNHw=='))
    iv = bytes_to_intlist(compat_b64decode('zWfF2X9iCXnIe0v8btjUwg=='))
    data = bytes_to_intlist(compat_b64decode('aF/N8/85oIBJb/vt1iDqI3gx1tqiFZ9XukZtTQPm+R4='))