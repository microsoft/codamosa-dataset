

# Generated at 2022-06-24 11:21:25.692548
# Unit test for function rotate
def test_rotate():
    unittest.main(argv=['first-arg-is-ignored'], exit=False)


# Generated at 2022-06-24 11:21:34.064806
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    assert aes_cbc_encrypt([0] * 16, [0] * 16, [0] * 16) == [
        218, 235, 247, 64, 101, 149, 171, 148, 153, 193, 169, 168, 143, 65, 252, 59
    ]
    assert aes_cbc_encrypt([0] * 17, [0] * 16, [0] * 16) == [
        218, 235, 247, 64, 101, 149, 171, 148, 153, 193, 169, 168, 143, 65, 252, 59, 16
    ]



# Generated at 2022-06-24 11:21:44.520278
# Unit test for function aes_encrypt

# Generated at 2022-06-24 11:21:52.683811
# Unit test for function key_expansion
def test_key_expansion():
    data = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-24 11:22:03.474146
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import sys
    import struct

    encrypted_data = 'FjZua7wPn2Ql8NaVyUYa117n7nrrpWZIuXaZ1+e0G/w='
    password = '1234'

    print(sys.version)
    print('encoded_string: ' + encrypted_data)
    print('decoded_string: ' + aes_decrypt_text(encrypted_data, password, 32).decode('utf-8'))

    print('\nPython 2')
    print('encoded_string: ' + encrypted_data)
    print('decoded_string: ' + aes_decrypt_text(encrypted_data, password.decode('latin-1'), 32).decode('utf-8'))

    print('\nJava')

# Generated at 2022-06-24 11:22:07.564243
# Unit test for function xor
def test_xor():
    a = [0x32, 0x88, 0x31, 0xE0]
    b = [0x43, 0x5A, 0x31, 0x37]
    assert(xor(a, b) == [0x71, 0xD2, 0x00, 0xD7])



# Generated at 2022-06-24 11:22:19.034333
# Unit test for function key_expansion
def test_key_expansion():
    # 16-Byte
    key = bytes_to_intlist(b'\xff' * 16)

# Generated at 2022-06-24 11:22:23.823180
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    input_data = [0xDB, 0x13, 0x53, 0x45,
                  0xF2, 0x0A, 0x22, 0x5C,
                  0x01, 0x01, 0x01, 0x01,
                  0xAB, 0xAB, 0xAB, 0xAB]
    output_data = [0x75, 0xF9, 0xC2, 0xA4,
                   0x2F, 0xCB, 0x91, 0xD2,
                   0x9B, 0x3F, 0xEF, 0x42,
                   0xD0, 0x6E, 0xD6, 0x87]
    assert mix_columns_inv(input_data) == output_data

test_mix_columns_inv()

# Generated at 2022-06-24 11:22:27.190403
# Unit test for function sub_bytes
def test_sub_bytes():
    test_data = [0x29, 0x7c, 0x75, 0x39]
    assrt(sub_bytes(test_data) == [0xb8, 0xe9, 0x11, 0x3d])



# Generated at 2022-06-24 11:22:29.579418
# Unit test for function sub_bytes
def test_sub_bytes():
    data = bytearray([0x0F, 0x17, 0x27, 0x37])
    result = sub_bytes(data)
    print("Sub bytes unit test:")
    print("Input: {}".format(data))
    print("Output: {}".format(result))



# Generated at 2022-06-24 11:22:40.821356
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-24 11:22:43.596494
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [1, 2, 4, 5,
            10, 11, 12, 14,
            9, 12, 11, 10,
            8, 7, 10, 9]
    data_expected = [1, 2, 4, 5,
                     10, 11, 12, 14,
                     11, 10, 9, 12,
                     10, 9, 8, 7]
    print('Shift rows test')
    print(data)
    print(shift_rows_inv(data))
    print(data_expected)


test_shift_rows_inv()


# Generated at 2022-06-24 11:22:53.664279
# Unit test for function aes_decrypt
def test_aes_decrypt():
    message = "Attack at dawn!"
    data = bytes_to_intlist(message.encode('ascii'))
    iv = [0] * 16
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]
    expanded_key = key_expansion(key)
    print(expanded_key)
    enc_data = aes_cbc_encrypt(data, key, iv)
    dec_data = aes_cbc_decrypt(enc_data, key, iv)
    assert dec_data == data
    end_message = intlist_to_

# Generated at 2022-06-24 11:22:59.772919
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import base64
    from .counter import Counter
    from .aes_cipher import aes_ctr_encrypt

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    counter = Counter(bytes_to_intlist(b'\x00' * (BLOCK_SIZE_BYTES // 2)))
    plain = 'YOURE ABOUT TO ENCRYPT SOMETHING!'
    plain = [ord(c) for c in plain]

    # Encrypt it
    encrypted = aes_ctr_encrypt(plain, key, counter)
    decrypted = aes_ctr_decrypt(encrypted, key, counter)

    # Test encryption

# Generated at 2022-06-24 11:23:08.404694
# Unit test for function aes_decrypt_text

# Generated at 2022-06-24 11:23:16.942579
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test function aes_decrypt_text with example from
    http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    """
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'Password'
    key_size_bytes = 16
    nonce = [177, 161, 244, 128, 84, 143, 225, 115]

# Generated at 2022-06-24 11:23:20.267026
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 0x01) == [0x01, 0x03, 0x04, 0x0C]
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 0x02) == [0x01, 0x05, 0x09, 0x13]
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 0x03) == [0x01, 0x0D, 0x09, 0x0B]



# Generated at 2022-06-24 11:23:22.222648
# Unit test for function sub_bytes
def test_sub_bytes():
    sample = [0x19, 0xa0, 0x9a, 0xe9]
    expected = [0xd4, 0xe0, 0xb8, 0x1e]
    assert sub_bytes(sample) == expected
test_sub_bytes()

# Generated at 2022-06-24 11:23:30.231268
# Unit test for function aes_encrypt

# Generated at 2022-06-24 11:23:41.113490
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class TestClass(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            return self.value

    data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    counter = TestClass([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
    decrypted = aes_ctr_

# Generated at 2022-06-24 11:23:42.297292
# Unit test for function inc
def test_inc():
    assert inc([0] * 16) == [1] * 16
    assert inc([255] * 16) == [0] * 15 + [1]



# Generated at 2022-06-24 11:23:50.403196
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    password = 'password'
    encrypted_data = 'rRAF6oEk6yczU6p3qY4W9gFGbA6TtlgRfQP6SQe+LQw='

    assert aes_decrypt_text(encrypted_data, password, key_size_bytes=16) == b'hello world'
    assert aes_decrypt_text(encrypted_data, password, key_size_bytes=24) == b'hello world'
    assert aes_decrypt_text(encrypted_data, password, key_size_bytes=32) == b'hello world'

# Generated at 2022-06-24 11:23:59.868803
# Unit test for function aes_encrypt
def test_aes_encrypt():
    print("Verifying function aes_encrypt")
    k1 = bytes_to_intlist(compat_b64decode("AhOx/Fxlbt+NcRhZjT/XhQ=="))
    k2 = bytes_to_intlist(compat_b64decode("YKjDZ+mX9Jgf/mh4+h7g4w=="))
    d1 = bytes_to_intlist(compat_b64decode("fQ2AJtKLBIQyWOzEw+DH1g=="))
    d2 = bytes_to_intlist(compat_b64decode("+Wwb5x5vLnYM/LY+oCQJFQ=="))
    c1 = aes_encrypt(k1, k2)
   

# Generated at 2022-06-24 11:24:09.566455
# Unit test for function mix_column
def test_mix_column():
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    data_mix = mix_column(data,MIX_COLUMN_MATRIX)
    if(data_mix[0] != 5 or data_mix[4] != 12 or data_mix[8] != 17 or data_mix[12] != 24):
        print("Error in mix_column")
        return False
    data_mix = mix_column(data_mix,MIX_COLUMN_MATRIX_INV)
    for i in range(4):
        if(data_mix[i] != data[i]):
            print("Error in mix_column")
            return False
    return True



# Generated at 2022-06-24 11:24:17.007034
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([0, 0, 0, 0])) == [0, 0, 0, 0]
    assert sub_bytes_inv(sub_bytes([0xFF, 0xFF, 0xFF, 0xFF])) == [0xFF, 0xFF, 0xFF, 0xFF]
    assert sub_bytes_inv(sub_bytes([0xAB, 0xCD, 0xEF, 0x12])) == [0xAB, 0xCD, 0xEF, 0x12]



# Generated at 2022-06-24 11:24:19.154161
# Unit test for function rotate
def test_rotate():
    assert(rotate([1,2,3]) == [2,3,1])


# Generated at 2022-06-24 11:24:26.338299
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-24 11:24:37.637918
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0x02, 0x01, 0x01, 0x03, 0x03, 0x02, 0x01, 0x01,
            0x01, 0x03, 0x02, 0x01, 0x01, 0x01, 0x03, 0x02]
    known_result = [0x0e, 0x0b, 0x0d, 0x09, 0x09, 0x0e, 0x0b, 0x0d,
                    0x0d, 0x09, 0x0e, 0x0b, 0x0b, 0x0d, 0x09, 0x0e]
    if mix_columns_inv(data) != known_result:
        print('Unit test for function mix_columns_inv failed')
        exit(1)



# Generated at 2022-06-24 11:24:46.766275
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F]

# Generated at 2022-06-24 11:24:57.073234
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    cleartext = "Cleartext"
    assert(len(cleartext) % BLOCK_SIZE_BYTES != 0)

    encrypted_cleartext = "6d8b6bad26b6a4f6d1c4e1a6c4d6ad2b6df4a6d1b6a9b6a2ac6d2c6a8a6c2d6f1b6a1b6a9a6c1f6d2b6ebc6324839"

    key = b"PlaintextKey"
    iv = b"PlaintextIV"

    cleartext_bytes = intlist_to_bytes(bytes_to_intlist(key))
    iv_bytes = intlist_to_bytes(bytes_to_intlist(iv))
    key_bytes = int

# Generated at 2022-06-24 11:25:04.894076
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(compat_b64decode(b'QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F'))
    key = bytes_to_intlist(compat_b64decode(b'MTIzNDU2Nzg5MGFiY2RlZmdoaWprbG1ub3BxcnN0'))
    counter = Counter()

    # Decrypt with aes in counter mode
    assert intlist_to_bytes(aes_ctr_decrypt(data, key, counter)) == b'Crypto is fun!'
test_aes_ctr_decrypt()


# Generated at 2022-06-24 11:25:16.667132
# Unit test for function key_expansion
def test_key_expansion():
    assert key_expansion(compat_b64decode('x' * 16)) == compat_b64decode(b'vKtqZtsnI/c/YpJt/vfBjyR/Pzk8h/ALNrqvb9XcxpRFBV4A+Y2O4A==')

# Generated at 2022-06-24 11:25:19.388303
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert 0x57 == rijndael_mul(0x57, 0x01)
    assert 0xfa == rijndael_mul(0x57, 0x02)
    assert 0x8c == rijndael_mul(0x57, 0x03)
# Matrix multiplication

# Generated at 2022-06-24 11:25:27.061591
# Unit test for function sub_bytes
def test_sub_bytes():
    print("Testing sub_bytes()")
    # Test vector from FIPS 197, page 22, Appendix B
    assert sub_bytes([0x32, 0x88, 0x31, 0xe0]) == [0x19, 0xa0, 0x9a, 0xe9]
    print("Pass")
test_sub_bytes()



# Generated at 2022-06-24 11:25:37.237980
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x19, 0xa0, 0x9a, 0xe9, 0x3d, 0xf4, 0xc6, 0xf8, 0xe3, 0xe2, 0x8d, 0x48, 0xbe, 0x2b, 0x2a, 0x08]
    sub_bytes(data)
    ciphertext = [0xd4, 0xe0, 0xb8, 0x1e, 0x27, 0xbf, 0xb4, 0x41, 0x11, 0x98, 0x5d, 0x52, 0xae, 0xf1, 0xe5, 0x30]
    assert data == ciphertext, 'SubBytes function is not correct'
    print('SubBytes function is correct')



# Generated at 2022-06-24 11:25:44.987878
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class MockCounter(object):
        def __init__(self):
            self.counter = bytes_to_intlist(b'\x00' * BLOCK_SIZE_BYTES)

        def next_value(self):
            self.counter[15] += 1
            return self.counter

    counter = MockCounter()
    cipher = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    expected_plaintext = b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '


# Generated at 2022-06-24 11:25:54.225231
# Unit test for function key_expansion
def test_key_expansion():
    exp_key= key_expansion([0x6a,0x6a,0x6a,0x6a,0x6a,0x6a,0x6a,0x6a,0x6a,0x6a,0x6a,0x6a,0x6a,0x6a,0x6a,0x6a])

# Generated at 2022-06-24 11:26:02.361597
# Unit test for function xor
def test_xor():
    data1 = [0x04, 0x46, 0x7f, 0x7e]
    data2 = [0x58, 0xf3, 0x2c, 0x8a]
    result = xor(data1, data2)
    assert result == [0x5C, 0xB5, 0x53, 0xF4]

# Generated at 2022-06-24 11:26:14.019030
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist('12345678901234567890123456789012')
    iv = bytes_to_intlist('12345678901234561234567890123456')
    data = '6465787412345678'
    print(intlist_to_bytes(aes_cbc_encrypt(bytes_to_intlist(data), key, iv)))
    print(aes_cbc_encrypt(bytes_to_intlist(data), key, iv))
    print(aes_cbc_encrypt(bytes_to_intlist('123456'), key, iv))
    print(aes_cbc_encrypt(bytes_to_intlist('12345'), key, iv))

# Generated at 2022-06-24 11:26:23.646570
# Unit test for function key_expansion
def test_key_expansion():
    import binascii
    from .data import test_key_expansion_vectors
    key_size = 16
    for key, expected_expanded_key in test_key_expansion_vectors:
        expanded_key = key_expansion(bytes_to_intlist(key))
        expanded_key_hex = binascii.hexlify(intlist_to_bytes(expanded_key))
        expected_hex = binascii.hexlify(compat_b64decode(expected_expanded_key))
        if expanded_key_hex != expected_hex:
            print("Failed key expansion with key_size=%s:" % key_size)
            print("  key:    %s" % binascii.hexlify(key))

# Generated at 2022-06-24 11:26:32.656843
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist(compat_b64decode(b"gqkFq3DhqGKZpdgV7GpX/Nlz7AuWeNkTgQNuihbHjHQ="))
    encrypted_key = bytes_to_intlist(compat_b64decode(b"DT95nJcLm+fZLxN5S9vf/5yk5IpzC3qAWW8/wCiGSZ4="))
    iv = bytes_to_intlist(compat_b64decode(b"0kMocDVfizGpZP3q3GXsUA=="))

# Generated at 2022-06-24 11:26:40.826122
# Unit test for function key_expansion

# Generated at 2022-06-24 11:26:42.683632
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert test_key_schedule_core() == [0xe0, 0x25, 0xb5, 0x7b]


# Generated at 2022-06-24 11:26:44.690296
# Unit test for function xor
def test_xor():
    xor([0xFF, 0xAA], [0xFF, 0x00]) == [0x00, 0xAA]



# Generated at 2022-06-24 11:26:55.159326
# Unit test for function inc
def test_inc():
    data = [0, 0, 0, 0]

# Generated at 2022-06-24 11:27:06.823332
# Unit test for function mix_columns
def test_mix_columns():
    data = (0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01)
    expect = (0x8E, 0x4D, 0xA1, 0xBC, 0x9F, 0xDC, 0x58, 0x9D, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01)
    data_mixed = mix_columns(data)
    assert data_mixed == expect, 'the function mix_columns is incorrect'
    print('the function mix_columns is correct')



# Generated at 2022-06-24 11:27:20.300170
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Counter mode example from http://csrc.nist.gov/groups/ST/toolkit/BCM/documents/proposedmodes/ctr/ctr-example.pdf
    # The 2nd message is not really valid because the counter value is re-used which is not allowed.
    # But the example should work with it.
    messages = [
        'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==',
        '4Hq3EdYFg4YkwPVPfEqwIA=='
    ]
    key_size_bytes = 16

# Generated at 2022-06-24 11:27:24.812451
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert key_schedule_core([0x01, 0x05, 0x01, 0x01], 1) == [0x01, 0xa4, 0x01, 0x01]

# Generated at 2022-06-24 11:27:26.837497
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x83) == 0xc1
    # Add your own unit tests here


# Generated at 2022-06-24 11:27:32.231431
# Unit test for function shift_rows
def test_shift_rows():
    plaintext = [0x32, 0x88, 0x31, 0xE0, 0x43, 0x5A, 0x31, 0x37, 0xF6, 0x30, 0x98, 0x07, 0xA8, 0x8D, 0xA2, 0x34]
    ciphertext = [0x32, 0x88, 0x31, 0xE0, 0x43, 0x5A, 0x31, 0x37, 0xF6, 0x30, 0x98, 0x07, 0xA8, 0x8D, 0xA2, 0x34]
    cipher = Cipher()
    cipher.shift_rows(plaintext)
    print("shift_rows", plaintext)
    assert (plaintext == ciphertext), "failed unit test"



# Generated at 2022-06-24 11:27:38.227121
# Unit test for function inc
def test_inc():
    test_inputs = [
        [[0, 0, 0, 0], [1, 0, 0, 0]],
        [[0, 0, 0, 255], [0, 0, 1, 0]],
        [[0, 255, 255, 255], [1, 0, 0, 0]]
    ]

    for ti in test_inputs:
        assert inc(ti[0]) == ti[1]



# Generated at 2022-06-24 11:27:49.209982
# Unit test for function shift_rows
def test_shift_rows():
    for i in range(256):
        data = [i for j in range(4)]
        expected_data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
        for j in range(4):
            expected_data[j * 4 + 1] = data[j * 4 + 1]
            expected_data[j * 4 + 2] = data[j * 4 + 2]
            expected_data[j * 4 + 3] = data[j * 4 + 3]
        expected_data[0] = data[0]
        actual_data = shift_rows(data)
        assert actual_data == expected_data, "Shift rows failed at index %d" % i
test_shift_rows()


# Generated at 2022-06-24 11:28:01.474349
# Unit test for function sub_bytes

# Generated at 2022-06-24 11:28:10.793347
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x32,0x88,0x31,0xe0,0x43,0x5a,0x31,0x37,0xf6,0x30,0x98,0x07,0xa8,0x8d,0xa2,0x34,]
    assert shift_rows(data) == [0x32, 0x88, 0xf6, 0x30, 0x43, 0x98, 0xa2, 0x34, 0x31, 0x5a, 0x07, 0xa8, 0xe0, 0x31, 0x8d, 0x37]



# Generated at 2022-06-24 11:28:15.853353
# Unit test for function key_schedule_core
def test_key_schedule_core():
    print("Unit test for function key_schedule_core")
    data = [0x54, 0x77, 0x6F, 0x20]
    rcon_iteration = 1
    output = [0x6b, 0xe2, 0x2e, 0x89]
    print('The input data is: ', [hex(x) for x in data])
    print('The output data is: ', [hex(x) for x in key_schedule_core(data,rcon_iteration)])


test_key_schedule_core()
print('----------------------------------------')



# Generated at 2022-06-24 11:28:20.081588
# Unit test for function mix_column
def test_mix_column():
    plaintext = (0xd4, 0xe0, 0xb8, 0x1e)
    ciphertext = mix_column(plaintext, MIX_COLUMN_MATRIX)
    assert ciphertext == (0x04, 0xe0, 0x48, 0x28), ciphertext



# Generated at 2022-06-24 11:28:28.971093
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 0]) == [0, 1, 0, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 0, 0]) == [1, 0, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 0, 0, 0]) == [255, 0, 0, 1]
    assert inc([255, 255, 255, 255]) == [255, 255, 255, 255]

# Generated at 2022-06-24 11:28:30.939148
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x19, 0x3d, 0xe3, 0xbe]
    assert sub_bytes(data) == [0xd4, 0x27, 0x11, 0xae]


# Generated at 2022-06-24 11:28:43.074600
# Unit test for function shift_rows
def test_shift_rows():
    test_data = [0x63, 0xCA, 0xB7, 0x04,
                 0xF6, 0x09, 0xD6, 0x61,
                 0xC2, 0xE0, 0xC0, 0xF7,
                 0xFF, 0xED, 0x21, 0x67]
    result = shift_rows(test_data)
    expected = [0x63, 0xF6, 0xC2, 0xFF,
                0xCA, 0x09, 0xE0, 0xED,
                0xB7, 0xD6, 0xC0, 0x21,
                0x04, 0x61, 0xF7, 0x67]
    assert(result == expected)
    print("test_shift_rows passed")


# Generated at 2022-06-24 11:28:53.463895
# Unit test for function key_expansion
def test_key_expansion():
    key = [ord(t) for t in "1qaz3edc5tgb7ujm8ik,"]

# Generated at 2022-06-24 11:29:03.229215
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    # Corret key
    key = "140b41b22a29beb4061bda66b6747e14"
    key_hex = [int(key[i:i+2], 16) for i in range(0, len(key), 2)]
    state = "4ca00ff4c898d61e1edbf1800618fb2828a226d160dad07883d04e008a7897ee2e4b7465d5290d0c0e6c6822236e1daafb94ffe0c5da05d9476be028ad7c1d81"
    state_hex = [int(state[i:i+2], 16) for i in range(0, len(state), 2)]

# Generated at 2022-06-24 11:29:07.610421
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0x100):
        for j in range(0x100):
            a = i
            b = j
            c = rijndael_mul(a, b)
            assert c == (a * b) % 0x100
    print('Function rijndael_mul passed')

test_rijndael_mul()


# Generated at 2022-06-24 11:29:14.780747
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .counter import Counter

    class CounterTest(Counter):
        def next_value(self):
            return [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 123]

    key = bytes_to_intlist(compat_b64decode(b'QIK2sFvSAHP5mJNq'), BLOCK_SIZE_BYTES)
    c = CounterTest()
    d = aes_ctr_decrypt([83,97,108,117,116,111,32,83,97,110,115,32,68,111,109,105,110,103,111], key, c)

# Generated at 2022-06-24 11:29:23.192140
# Unit test for function mix_column
def test_mix_column():
        data = [0xdb, 0x13, 0x53, 0x45]
        data_mixed = mix_column(data,MIX_COLUMN_MATRIX)
        assert(data_mixed == [0x8e, 0x9f, 0x77, 0xa0])

        data = [0x8e, 0x9f, 0x77, 0xa0]
        data_mixed = mix_column(data,MIX_COLUMN_MATRIX_INV)
        assert(data_mixed == [0xdb, 0x13, 0x53, 0x45])


# Generated at 2022-06-24 11:29:34.917465
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert mix_columns_inv([215, 170, 53, 236]) == [22, 213, 11, 102]
    assert mix_columns_inv([0, 0, 0, 0]) == [0, 0, 0, 0]
    assert mix_columns_inv([0xA4, 0xA4, 0xA4, 0xA4]) == [0xA4, 0xA4, 0xA4, 0xA4]
    assert mix_columns_inv([0xF2, 0xF2, 0xF2, 0xF2]) == [0xF2, 0xF2, 0xF2, 0xF2]

# Generated at 2022-06-24 11:29:36.195710
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]



# Generated at 2022-06-24 11:29:38.312817
# Unit test for function rotate
def test_rotate():
    assert rotate([0x52, 0x09, 0x6A, 0xD5]) == [0x09, 0x6A, 0xD5, 0x52]



# Generated at 2022-06-24 11:29:42.254938
# Unit test for function shift_rows
def test_shift_rows():
    plain = [1, 2, 3, 4,
             5, 6, 7, 8,
             9, 10, 11, 12,
             13, 14, 15, 16]
    expected = [1, 2, 3, 4,
                6, 7, 8, 5,
                11, 12, 9, 10,
                16, 13, 14, 15]
    shifted = shift_rows(plain)
    assert expected == shifted



# Generated at 2022-06-24 11:29:51.759688
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Verify AES-128-CBC encrypted against https://tools.ietf.org/html/rfc3602#section-4
    data = bytes_to_intlist(compat_b64decode('a/XIq3FOBL/1vzcEjSvuw=='))
    key = bytes_to_intlist(compat_b64decode('HWd7vpi1LsJj7ZM8M70uVQ=='))
    iv = bytes_to_intlist(compat_b64decode('CJnLnBlldVtIH+R/RGr/Xg=='))
    result = aes_cbc_decrypt(data, key, iv)
    assert intlist_to_bytes(result) == b'Single block msg'



# Generated at 2022-06-24 11:30:03.601519
# Unit test for function key_schedule_core

# Generated at 2022-06-24 11:30:05.632685
# Unit test for function rotate
def test_rotate():
    assert rotate([2, 3, 4, 5]) == [3, 4, 5, 2]


# Generated at 2022-06-24 11:30:15.715778
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import re
    import string

    # Example from https://en.wikipedia.org/wiki/Advanced_Encryption_Standard#Examples_of_use
    def _load_file(file_name):
        with open(file_name) as f:
            contents = f.read()

        return [int(i) for i in contents.split(',')]

    key = _load_file('aes_ctr_key.txt')
    cipher = _load_file('aes_ctr_cipher.txt')
    counter = Counter(31, 14, 9, 28, 131)

    decrypted_message = aes_ctr_decrypt(cipher, key, counter)
    decrypted_message = intlist_to_bytes(decrypted_message)
    decrypted_message = compat_b64decode(decrypted_message)

   

# Generated at 2022-06-24 11:30:17.927325
# Unit test for function xor
def test_xor():
    data1 = bytearray.fromhex("c967c8d8")
    data2 = bytearray.fromhex("53f6ea57")
    data = xor(data1, data2)
    if len(data) == 4:
        return True
    else:
        return False

# Generated at 2022-06-24 11:30:29.030390
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from .crypto import AES_KEY
    iv = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    data = "Hello, world!\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
    result = '\x7a\x3e\x9d\xa3\x89\xb6\x88\xba\x2d\x1a\xae\x6d\xf6\x36\xfd\x2d'

# Generated at 2022-06-24 11:30:31.953156
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x13) == 0xfe



# Generated at 2022-06-24 11:30:34.284036
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x55, 0x55]) == [0x52, 0x52]


# Generated at 2022-06-24 11:30:42.896411
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    matrix = ((0x02, 0x03, 0x01, 0x01), (0x01, 0x02, 0x03, 0x01), (0x01, 0x01, 0x02, 0x03), (0x03, 0x01, 0x01, 0x02))

# Generated at 2022-06-24 11:30:49.170233
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    input = [58, 50, 42, 34, 26, 18, 10, 2, 60, 52, 44, 36, 28, 20, 12, 4,
             62, 54, 46, 38, 30, 22, 14, 6, 64, 56, 48, 40, 32, 24, 16, 8,
             57, 49, 41, 33, 25, 17, 9, 1, 59, 51, 43, 35, 27, 19, 11, 3,
             61, 53, 45, 37, 29, 21, 13, 5, 63, 55, 47, 39, 31, 23, 15, 7]

# Generated at 2022-06-24 11:30:55.801335
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    decrypted_data = aes_ctr_decrypt(bytes_to_intlist(compat_b64decode(b'K6dvU8DBouU=')),
                                     [0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf, 0x0],
                                     _TestCounter())
    assert intlist_to_bytes(decrypted_data) == b'HelloWorld'


# Generated at 2022-06-24 11:31:03.672026
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00010203, 0x04050607, 0x08090a0b, 0x0c0d0e0f]

# Generated at 2022-06-24 11:31:14.797970
# Unit test for function key_schedule_core
def test_key_schedule_core():
    print("TESTING key_schedule_core")
    print("Test 1...")
    result = key_schedule_core([0x00, 0x00, 0x00, 0x00], 1)
    print("Expected result: ", end="")
    for x in [0x01, 0x00, 0x00, 0x00]:
        print("{:02x}".format(x), end="")
    print("\nActual result:   ", end="")
    for x in result:
        print("{:02x}".format(x), end="")
    print("\n")
    print("Test 2...")
    result = key_schedule_core([0x7c, 0x77, 0x76, 0x74], 2)
    print("Expected result: ", end="")
   

# Generated at 2022-06-24 11:31:21.921557
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    print('Testing function aes_decrypt_text...')
    data_b64 = 'Qa1Yw1+VdY8lkpPV7kJbtA=='
    password = 'password'
    assert aes_decrypt_text(data_b64, password, 32) == b'Hello World!'

    data_b64 = 'zV7gHBwXP8Bc7pZH+kOjKp5Jv9XW7zRK'
    password = 'password'
    assert aes_decrypt_text(data_b64, password, 32) == b'Longer Message...'

    data_b64 = '+1/RbMt/n1E+T9TKESPnFwoSFIJDPic+wYj96kHHs4s='
   

# Generated at 2022-06-24 11:31:30.989619
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test_data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
                 0x5f, 0x72, 0x64, 0x15, 0x57, 0xf5, 0xbc, 0x92, 0xf7, 0xbe, 0x3b, 0x29, 0x1d, 0xb9, 0xf9, 0x1a]
    a = mix_columns_inv(test_data)