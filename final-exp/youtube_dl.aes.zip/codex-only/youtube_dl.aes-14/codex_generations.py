

# Generated at 2022-06-24 11:21:35.633371
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test_data = [0xdb, 0xf2, 0xe6, 0x6a, 0xbd, 0x24, 0x90, 0x2e, 0x50, 0x32, 0x92, 0xdc, 0x56, 0xda, 0xbb, 0xab]
    expected_result = [0x53, 0x81, 0x53, 0x8e, 0xbf, 0x85, 0x60, 0x87, 0x76, 0x4e, 0x69, 0x87, 0x06, 0xa4, 0x45, 0xbf]
    result = mix_columns_inv(test_data)

# Generated at 2022-06-24 11:21:45.726013
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    import unittest
    import codecs
    data = bytes_to_intlist("001122334455667788990112233445566778899011223344556677889901122334455667788990112233445566778899011223344556677889901122334455667788990112233445566778899")
    # DO NOT CHANGE IV
    iv = bytes_to_intlist(codecs.decode(b'v\x9d\x14\xb4\xaa\xde\xfd\xea\xfd\xdf\x0e\xfc\xc2\x4c\x8b\x0b\x04', 'hex_codec'))
    # DO NOT CHANGE KEY
    key = bytes_to

# Generated at 2022-06-24 11:21:51.850156
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = b'\x00'*16
    key = b'\x00'*16
    iv = b'\x00'*16
    expected = b'\x66\xe9\x4b\xd4\xef\x8a\x2c\x3b\x88\x4c\xfa\x59\xca\x34\x2b\x2e'
    assert aes_cbc_encrypt(bytes_to_intlist(data), bytes_to_intlist(key), bytes_to_intlist(iv)) == bytes_to_intlist(expected)


# Generated at 2022-06-24 11:21:57.885814
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x0e, 0x32, 0x3b, 0xe9, 0x0e, 0x23, 0x93, 0x7b, 0x9a, 0xc2, 0xa7, 0x1e, 0x13, 0x6e, 0x6d]
    data_mixed = [0xfb, 0x0e, 0x32, 0xca, 0xe9, 0xf8, 0x05, 0x9a, 0x7b, 0x6a, 0xc2, 0x3a, 0x1e, 0x93, 0x6e, 0x6d]
    assert data_mixed == mix_columns(data)

# Generated at 2022-06-24 11:22:05.667562
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    key_size_bytes = 32

    # Open decrypted sample file
    with open('data/aes_decrypted.txt', 'rb') as f:
        decrypted_data = f.read()

    # Load sample cipher text
    cipher_file = 'data/aes_encrypted.txt'
    with open(cipher_file, 'rb') as f:
        cipher_data = f.read()

    # Decode cipher
    decoded_cipher_data = compat_b64decode(cipher_data)

    # Decrypt
    decrypted_data_same = aes_decrypt_text(cipher_data, 'hello', key_size_bytes)

    # Compare

# Generated at 2022-06-24 11:22:12.556618
# Unit test for function mix_column
def test_mix_column():
    data = [0x63, 0x53, 0xE0, 0x8C]
    data_mixed = [0x5F, 0x72, 0x64, 0x15]
    assert(mix_column(data, MIX_COLUMN_MATRIX) == data_mixed)
    data_mixed_inv = [0x63, 0x53, 0xE0, 0x8C]
    assert(mix_column(data_mixed, MIX_COLUMN_MATRIX_INV) == data_mixed_inv)
    
test_mix_column()

# Generated at 2022-06-24 11:22:19.636063
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv([0x00, 0x01, 0x02, 0x03]) == [0x00, 0x01, 0x02, 0x03]
    assert sub_bytes_inv([0x00, 0xa4, 0x68, 0x9c]) == [0x00, 0x63, 0xbd, 0xe9]
    assert sub_bytes_inv([0x00, 0x2b, 0x7e, 0x15]) == [0x00, 0x32, 0x88, 0xeb]
    assert sub_bytes_inv([0x00, 0x2b, 0x7a, 0x15]) == [0x00, 0xae, 0x68, 0xf7]

# Generated at 2022-06-24 11:22:30.099724
# Unit test for function aes_encrypt
def test_aes_encrypt():
    """
    Test function aes_encrypt by verifying one of the NIST test cases
    http://www.inconteam.com/software-development/41-encryption/55-aes-test-vectors#aes-cbc
    """
    print("test aes_encrypt: ", end="")
    data = bytes_to_intlist(compat_b64decode(
        "gRmr7V0pJdWZzh3j1M6awQ=="))
    key = bytes_to_intlist(compat_b64decode(
        "81EHmjDpYbzJEZKFVLkGMw=="))

# Generated at 2022-06-24 11:22:33.691883
# Unit test for function mix_column
def test_mix_column():
    block = [0xDB, 0x13, 0x53, 0x45]
    result = mix_column(block, MIX_COLUMN_MATRIX)
    print(result)
#test_mix_column()


# Generated at 2022-06-24 11:22:40.992478
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    cipher = 'BKJeJgO/NUFoLXBqN/JYK1FJwS1oyryxTKpAe+I8Z4n4KAX4tZEA'
    password = '24789b'
    plaintext = aes_decrypt_text(cipher, password, 16)
    print('Decrypted data: '+plaintext)
    print('success!')
    # print(plaintext.decode('utf-8'))



# Generated at 2022-06-24 11:22:42.449297
# Unit test for function key_schedule_core
def test_key_schedule_core():
    test0 = [0x00, 0x00, 0x00, 0x00]
    assert key_schedule_core(test0, 1) == [0x01, 0x00, 0x00, 0x00]



# Generated at 2022-06-24 11:22:46.805704
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist(b'0' * 32) # b'12348765876543211234567898765432')
    data = bytes_to_intlist(b'0' * 16)
    expanded_key = key_expansion(key)
    result = aes_decrypt(data, key)
    print(result)
    assert result == data



# Generated at 2022-06-24 11:22:51.619310
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns(data)
    expected = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    return result == expected



# Generated at 2022-06-24 11:22:56.474457
# Unit test for function rijndael_mul
def test_rijndael_mul():
    # results from table in Appendix B of https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf
    assert rijndael_mul(0xE, 0x1) == 0xE
    assert rijndael_mul(0xE, 0x2) == 0xC
    assert rijndael_mul(0xE, 0x4) == 0x3
    assert rijndael_mul(0xE, 0x8) == 0x9
    assert rijndael_mul(0x1, 0xE) == 0xE
    assert rijndael_mul(0x2, 0xE) == 0xC

# Generated at 2022-06-24 11:22:59.804160
# Unit test for function xor
def test_xor():
    data1 = [0x1,0x1,0x1,0x1]
    data2 = [0x4,0x4,0x4,0x4]
    result = xor(data1, data2)
    if result[0] == 0x5 and result[1] == 0x5 and result[2] == 0x5 and result[3] == 0x5:
        print("xor function works properly")
    else:
        print("xor function does not work properly")



# Generated at 2022-06-24 11:23:04.873247
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08]
    print(mix_columns(data, MIX_COLUMN_MATRIX))
    print(result)
    print(mix_columns(result, MIX_COLUMN_MATRIX_INV))
    print

# Generated at 2022-06-24 11:23:15.439980
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Encrypted with mcrypt
    hex_data = 'a3b3a381a3f9a382a3a2a39ea3fda3a1a3fda383a383a383a383a383a383a383a383a383a383a383a383a383a383a383a383a383a383a383a383a383a383a383a383a383a383a383a383a382a39ea3fda3a1a3fda3a3a3ac'
    iv = '000102030405060708090a0b0c0d0e0f'
    key = '000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f'

    data = bytes_to

# Generated at 2022-06-24 11:23:20.237024
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import random
    for _ in range(100):
        key = [random.randint(0, 255) for _ in range(32)] #random key
        counter_value = random.randint(0, 10000000000) #random counter
        data = [random.randint(0, 255) for _ in range(random.randint(27, 32))]
        class Counter:
            def __init__(self, initial_value):
                self.value = initial_value
            def next_value(self):
                self.value += 1
                return [self.value >> (i * 8) & 0xFF for i in range(16)]

        decrypted_data = aes_ctr_decrypt(data, key, Counter(counter_value))

# Generated at 2022-06-24 11:23:26.384918
# Unit test for function mix_column
def test_mix_column():
    data = [0xF2, 0x6F, 0x7D, 0xC1]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    data_mixed_inv = mix_column(data_mixed, MIX_COLUMN_MATRIX_INV)
    print(data_mixed)
    print(data_mixed_inv)
    assert(data == data_mixed_inv)



# Generated at 2022-06-24 11:23:29.781026
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range(0, 256):
        for b in range(0, 256):
            c = rijndael_mul(a, b)
            if (c):
                d = rijndael_mul(c, 0x1B)
                if (a != d):
                    print("Error!")



# Generated at 2022-06-24 11:23:38.299359
# Unit test for function aes_encrypt
def test_aes_encrypt():
    assert aes_encrypt(bytes_to_intlist(compat_b64decode('47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=')), bytes_to_intlist('11111111111111111111111111111111')) == bytes_to_intlist(b'\xfa\xce\x1f\x9b\x9d\x41\x59\x31\xb7\x54\x30\xbb\xff\xfd\x82\x9e')


# Generated at 2022-06-24 11:23:41.145839
# Unit test for function inc
def test_inc():
    assert inc([1]) == [2]
    assert inc([1,1]) == [1,2]
    assert inc([1, 255]) == [2,0]
    assert inc([1, 1, 255]) == [1,2,0]
    assert inc([255]) == [0]
    assert inc([255,255]) == [0,0]



# Generated at 2022-06-24 11:23:46.404413
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv([0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]) == [0x19, 0xa0, 0x9a, 0xe9, 0x3d, 0xf4, 0xc6, 0xf8, 0xe3, 0xe2, 0x8d, 0x48, 0xbe, 0x2b, 0x2a, 0x08]



# Generated at 2022-06-24 11:23:50.642096
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class TestCounter:
        def __init__(self, value):
            self.value = value
        def next_value(self):
            self.value += 1
            return bytes_to_intlist(bytes([self.value]))

    key = bytes_to_intlist(u"\x60\x3d\xeb\x10\x15\xca\x71\xbe\x2b\x73\xae\xf0\x85\x7d\x77\x81" +
                           u"\x1f\x35\x2c\x07\x3b\x61\x08\xd7\x2d\x98\x10\xa3\x09\x14\xdf\xf4")
    counter = TestCounter(1)

# Generated at 2022-06-24 11:23:51.579346
# Unit test for function xor
def test_xor():
    assert xor([1,2,3,4], [5,6,7,8]) == [6,4,4,12]


# Generated at 2022-06-24 11:23:57.913475
# Unit test for function aes_encrypt
def test_aes_encrypt():
    assert aes_encrypt(bytes_to_intlist(b'\0' * 16), bytes_to_intlist(b'\0' * 176)) == bytes_to_intlist(b'\x66\xe9\x4b\xd4\xef\x8a\x2c\x3b\x88\x4c\xfa\x59\xca\x34\x2b\x2e')



# Generated at 2022-06-24 11:24:03.940389
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xd4, 0xe0, 0xb8, 0x1e, 0xbf, 0xb4, 0x41, 0x27, 0x5d, 0x52, 0x11, 0x98, 0x30, 0xae, 0xf1, 0xe5]
    data_mixed = mix_columns(data, MIX_COLUMN_MATRIX)
    print("mix_columns")
    print("data       :", data)
    print("data_mixed :", data_mixed)

# Generated at 2022-06-24 11:24:09.321204
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b"Test dat")
    key = bytes_to_intlist(b"0" * 32)
    iv = bytes_to_intlist(b"0" * 16)

    assert intlist_to_bytes(aes_cbc_encrypt(data, key, iv)) == compat_b64decode(
        "7/15CDh6lm7VuP/8Nv7EEXhcveQg="
    )



# Generated at 2022-06-24 11:24:16.209699
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x04, 0x07, 0x52, 0x0D]) == [0x27, 0x9A, 0x3D, 0xF4]
    assert sub_bytes([0x35, 0x11, 0xA9, 0xF8]) == [0x41, 0x4B, 0x2E, 0x84]
    assert sub_bytes([0xF8, 0x0B, 0xA7, 0x83]) == [0x0F, 0xB7, 0xC1, 0x1F]
    assert sub_bytes([0x45, 0x29, 0x43, 0x1B]) == [0x5F, 0x1C, 0x0B, 0xE6]

# Generated at 2022-06-24 11:24:24.587682
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-24 11:24:31.229705
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    data = [0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    data_inv = sub_bytes_inv(data)
    data_expected = [0, 0, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
    assert data_inv == data_expected

# Generated at 2022-06-24 11:24:32.698126
# Unit test for function inc
def test_inc():
    for i in range(-10, 1000):
        d = [i & 255 for i in range(4)]
        assert inc(d) == [i + 1 & 255 for i in range(4)]
    print("inc OK")
test_inc()



# Generated at 2022-06-24 11:24:41.002572
# Unit test for function inc
def test_inc():
    assert(inc([0]) == [1])
    assert(inc([1]) == [2])
    assert(inc([255]) == [0])
    assert(inc([0, 0]) == [0, 1])
    assert(inc([0, 255]) == [1, 0])
    assert(inc([255, 255]) == [0, 0])
    assert(inc([0, 0, 0]) == [0, 0, 1])
    assert(inc([0, 255, 255]) == [1, 0, 0])
    assert(inc([255, 255, 255]) == [0, 0, 0])
    return "test_inc passed"
# Testing function inc
print(test_inc())


# Generated at 2022-06-24 11:24:47.374238
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    data = [0x52, 0x7c, 0xe6, 0x30, 0x59, 0x37, 0xea, 0xa6, 0x6e, 0x3b, 0x4f, 0xf2, 0x7f, 0x29, 0xc0, 0xd1]
    data = sub_bytes_inv(data)
    assert(data == [0x00, 0x04, 0x08, 0x0c, 0x10, 0x14, 0x18, 0x1c, 0x20, 0x24, 0x28, 0x2c, 0x30, 0x34, 0x38, 0x3c])



# Generated at 2022-06-24 11:24:52.930837
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0xa0, 0xa0, 0xa0, 0xa0]
    expected = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0xa0, 0xa0, 0xa0, 0xa0]
    actual = mix_columns(data)
    assert actual == expected, 'Expected %s, got %s' % (expected, actual)


# Generated at 2022-06-24 11:25:04.719311
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    print ("Running test_aes_cbc_decrypt...")
    from .aes_cbc import aes_cbc_encrypt
    from .aes_ctr import Counter

    key = compat_b64decode(
        b'vRfSJW8HjKzOwcwLDvJzAOSA8OV08OEVjY/FjoOY1cKPw7zCrQ==')
    iv = compat_b64decode(b'YsDhDDsVFjIMFA==')

# Generated at 2022-06-24 11:25:12.269384
# Unit test for function mix_column
def test_mix_column():
    data = [0xDB, 0x13, 0x53, 0x45]
    data_exp = [0x8E, 0x4D, 0xA1, 0xBC]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX_INV)
    assert data_mixed == data_exp

test_mix_column()


# Generated at 2022-06-24 11:25:22.437568
# Unit test for function mix_column
def test_mix_column():
    assert mix_column([0xDB, 0x13, 0x53, 0x45], MIX_COLUMN_MATRIX) == [0x8e, 0x4d, 0xa1, 0xbc]
    assert mix_column([0x8e, 0x4d, 0xa1, 0xbc], MIX_COLUMN_MATRIX_INV) == [0xDB, 0x13, 0x53, 0x45]
    assert mix_column([0x69, 0x20, 0xc8, 0x7d], MIX_COLUMN_MATRIX) == [0xb4, 0x8a, 0x03, 0xd1]

# Generated at 2022-06-24 11:25:30.972422
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x19, 0xa0, 0x9a, 0xe9, 0x3d, 0xf4, 0xc6, 0xf8, 0xe3, 0xe2, 0x8d, 0x48, 0xbe, 0x2b, 0x2a, 0x08]
    print(shift_rows(shift_rows_inv(data)))
    assert data == shift_rows(shift_rows_inv(data))
test_shift_rows_inv()


# Generated at 2022-06-24 11:25:40.650623
# Unit test for function key_expansion

# Generated at 2022-06-24 11:25:51.899397
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    assert aes_cbc_encrypt([], [0]*16, [0]*16) == []
    assert aes_cbc_encrypt([1], [0]*16, [0]*16) == [
        186,
        154,
        252,
        227,
        205,
        201,
        119,
        44,
        246,
        51,
        214,
        214,
        151,
        208,
        78,
        192,
    ]

# Generated at 2022-06-24 11:26:01.189352
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = '46b9dd2b0ba88d13233b3feb743eeb243fcd52ea62b81b82b50c27646ed5762fd75dc4ddd8c0f200cb05019d67b592f6fc821c49479ab48640292eacb3b7c4be'
    data = bytes_to_intlist(compat_b64decode(data))
    key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    key = bytes_to_intlist(bytes(key))
    class counter():
        def __init__(self):
            self.value = 0


# Generated at 2022-06-24 11:26:05.495053
# Unit test for function mix_column
def test_mix_column():
    original = [0x57, 0x4d, 0x6b, 0x35]
    mixed = mix_column(original, MIX_COLUMN_MATRIX)
    assert mixed == [0xFE, 0xFF, 0xBB, 0xB0]
    mixed_inverted = mix_column(mixed, MIX_COLUMN_MATRIX_INV)
    assert mixed_inverted == original



# Generated at 2022-06-24 11:26:12.576839
# Unit test for function aes_decrypt
def test_aes_decrypt():
    from .test_data import aes_test_vectors
    for tv in aes_test_vectors:
        encrypted = bytes_to_intlist(compat_b64decode(tv['ct']))
        key = bytes_to_intlist(compat_b64decode(tv['key']))
        expanded_key = key_expansion(key)
        decrypted = aes_decrypt(encrypted, expanded_key)
        assert decrypted == bytes_to_intlist(compat_b64decode(tv['pt']))



# Generated at 2022-06-24 11:26:16.757156
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x63, 0x53, 0xe0, 0x8c, 0x09, 0x60, 0xe1, 0x04, 0xcd, 0xc0, 0x44, 0x02, 0xac, 0x80, 0x9e, 0x1e]
    expected_result = [0x63, 0x53, 0x09, 0x60, 0xcd, 0xc0, 0x45, 0x44, 0x02, 0xac, 0x80, 0x9e, 0x1e, 0x04, 0xc0, 0xe1]
    assert shift_rows(data) == expected_result



# Generated at 2022-06-24 11:26:25.293892
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-24 11:26:33.172029
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import base64

    class counter:
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value += 1
            return bytes_to_intlist(self.value.to_bytes(BLOCK_SIZE_BYTES, 'big'))

    data = base64.b64decode(
        b'hNz/KGYyA8Qq3Hq7VjQ9Gd1IW8fvDTuY7jm4xmvoM7y8mvD+/n/6kh+U6r/UEdj1')
    key = base64.b64decode(b'Nf8a9X+I7CI6ETvH3qQjJQ==')
    ctr = counter(0)

    assert int

# Generated at 2022-06-24 11:26:39.774798
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    PASSWORD = 'password'
    CIPHER =  'Ef/AluzTjI6N8ilOdNtfv0sY2/HU6fr8x2Wd+vA7mjI='
    PLAINTEXT = b'The quick brown fox jumps over the lazy dog'

    assert aes_decrypt_text(CIPHER, PASSWORD, 16) == PLAINTEXT
    assert aes_decrypt_text(CIPHER, PASSWORD, 24) == PLAINTEXT
    assert aes_decrypt_text(CIPHER, PASSWORD, 32) == PLAINTEXT


# Generated at 2022-06-24 11:26:41.704010
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0x100):
        for j in range(0x100):
            assert rijndael_mul(i, j) == hex(i * j).replace('L', '')[2:]

test_rijndael_mul()

# Generated at 2022-06-24 11:26:48.439866
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    KEY_SIZE_BITS = 128

    data = 'Qxu1dHU1BmlD8ACoAAA=='
    password = 'password'
    expected = 'plaintext'

    decrypted = aes_decrypt_text(data, password, KEY_SIZE_BITS // 8)
    assert decrypted == expected


# Generated at 2022-06-24 11:26:58.386526
# Unit test for function mix_column

# Generated at 2022-06-24 11:27:00.716068
# Unit test for function mix_column
def test_mix_column():
    assert(mix_column([0xdb, 0x13, 0x53, 0x45], MIX_COLUMN_MATRIX)==[0x8e, 0x4d, 0xa1, 0xbc])



# Generated at 2022-06-24 11:27:09.602639
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0x01, 0x01, 0x01, 0x01]
    matrix = ((0x02, 0x03, 0x01, 0x01),
              (0x01, 0x02, 0x03, 0x01),
              (0x01, 0x01, 0x02, 0x03),
              (0x03, 0x01, 0x01, 0x02))


# Generated at 2022-06-24 11:27:18.981138
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    data = [0x63, 0xEB, 0x9F, 0xA0, 0xC0, 0x2F, 0x93, 0x92, 0xAB, 0x30, 0xAF, 0xC7, 0x20, 0xCB, 0x2B, 0xA2]
    data = sub_bytes_inv(data)
    assert(data == [0x00, 0x44, 0x88, 0xcc, 0x11, 0x55, 0x99, 0xdd, 0x22, 0x66, 0xaa, 0xee, 0x33, 0x77, 0xbb, 0xff])



# Generated at 2022-06-24 11:27:21.570929
# Unit test for function xor
def test_xor():
    assert xor([0x01, 0x02], [0x01, 0x02]) == [0x00, 0x00]


test_xor()



# Generated at 2022-06-24 11:27:28.092275
# Unit test for function key_schedule_core

# Generated at 2022-06-24 11:27:35.663507
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    k = [0x00]*16
    d = [0x00]*16
    c = [0x00]*16
    ctr = ArrayCounter()
    ctr.set_value(d)
    assert aes_ctr_decrypt(c, k, ctr) == d

    k = [0x00]*16
    d = [0x00]*16
    c = [0x00]*16

    c_bytes = intlist_to_bytes(c)
    d_bytes = intlist_to_bytes(d)
    k_bytes = intlist_to_bytes(k)


# Generated at 2022-06-24 11:27:47.876495
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test aes_decrypt_text()

    Test cases are from https://jsfiddle.net/Leq5h5cd/
    """

# Generated at 2022-06-24 11:27:56.770027
# Unit test for function mix_column
def test_mix_column():
    assert mix_column([0x01, 0x02, 0x03, 0x04],MIX_COLUMN_MATRIX) == [0x02,0x03,0x01,0x01]
    assert mix_column([0x01, 0x01, 0x01, 0x01], MIX_COLUMN_MATRIX) == [0x01, 0x01, 0x01, 0x01]
    assert mix_column([0xDB, 0x13, 0x53, 0x45], MIX_COLUMN_MATRIX) == [0x8E, 0x4D, 0xA1, 0xBC]

# Generated at 2022-06-24 11:28:00.918423
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print("Testing function rijndael_mul")
    assert rijndael_mul(0x57, 0x83) == 0xc1, "Got {}".format(rijndael_mul(0x57, 0x83))
    print("All tests passed")



# Generated at 2022-06-24 11:28:03.829746
# Unit test for function rotate
def test_rotate():
    data = [1,2,3,4]
    expected = [2,3,4,1]
    assert rotate(data) == expected


# Generated at 2022-06-24 11:28:13.723137
# Unit test for function shift_rows
def test_shift_rows():
    assert(shift_rows([0x39, 0x02, 0xdc, 0x19,
                         0x25, 0xdc, 0x11, 0x6a,
                         0x84, 0x09, 0x85, 0x0b,
                         0x1d, 0xfb, 0x97, 0x32])
                 == [0x39, 0x25, 0x84, 0x1d,
                 0x02, 0xdc, 0x09, 0xfb,
                 0xdc, 0x11, 0x85, 0x97,
                 0x19, 0x6a, 0x0b, 0x32])



# Generated at 2022-06-24 11:28:17.284788
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range(256):
        for b in range(256):
            assert(rijndael_mul(a, b) == galois_mul(a, b))



# Generated at 2022-06-24 11:28:20.614837
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    res = shift_rows_inv(shift_rows([x for x in range(16)]))
    if res != [x for x in range(16)]:
        print("failed")
        print(res)
    else:
        print("pass")



# Generated at 2022-06-24 11:28:31.429518
# Unit test for function aes_decrypt
def test_aes_decrypt():
    import binascii
    data = bytes_to_intlist('32 43 f6 a8 88 5a 30 8d 31 31 98 a2 e0 37 07 34')
    expanded_key = bytes_to_intlist('54 68 61 20 70 61 73 73 77 6f 72 64 20 54 68 61 20 62 6c 6f 63 6b 20 6f 66 20 73 68 61 72 65 20 61 6e 64 20 6f 66 20 73 68 61 72 65')
    expected = bytes_to_intlist('4e 65 78 74 20 4d 61 6e 69 63 20 42 65 20 72 79 20 41 64 64 65 64 20 77 69 74 68 69 6e 20 74 68 65 20 62 75 69 6c 64 20 6f 72 20 64 6f 63 6b')

    result = aes_decrypt(data, expanded_key)
    assert(expected == result)

#

# Generated at 2022-06-24 11:28:42.181571
# Unit test for function aes_encrypt
def test_aes_encrypt():
    p_key = [212, 11, 170, 61, 37, 25, 107, 45, 197, 78, 69, 54, 38, 87, 181, 147]
    p_data = [93, 187, 215, 69, 79, 24, 174, 102, 180, 160, 121, 160, 239, 175, 99, 42]
    p_expected_result = [175, 149, 249, 133, 44, 226, 191, 180, 235, 35, 158, 87, 189, 76, 191, 19]
    p_expanded_key = key_expansion(p_key)

    assert aes_encrypt(p_data, p_expanded_key) == p_expected_result

test_aes_encrypt()

# Generated at 2022-06-24 11:28:48.209106
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf]
    assert shift_rows_inv(shift_rows(data)) == data



# Generated at 2022-06-24 11:28:57.530440
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert mix_columns(data) == expected

# Generated at 2022-06-24 11:29:00.308320
# Unit test for function rijndael_mul
def test_rijndael_mul():
    a = 0x57
    b = 0x83
    c = rijndael_mul(a, b)
    if c == 0xc1:
        print('Function rijndael_mul is correct')
    else:
        print('Function rijndael_mul is incorrect')



# Generated at 2022-06-24 11:29:03.623677
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x6b,0x0d,0xb4,0x47])== [0x6f,0x25,0x69,0x22]


# Generated at 2022-06-24 11:29:10.739657
# Unit test for function mix_column
def test_mix_column():
    assert mix_column([0xD4, 0xBF, 0x5D, 0x30], MIX_COLUMN_MATRIX) == [0x04, 0x66, 0x81, 0xE5]
    assert mix_column([0x04, 0x66, 0x81, 0xE5], MIX_COLUMN_MATRIX_INV) == [0xD4, 0xBF, 0x5D, 0x30]
    assert mix_column([0xD4, 0xBF, 0x5D, 0x30], MIX_COLUMN_MATRIX_INV) != [0x04, 0x66, 0x81, 0xE5]

# Generated at 2022-06-24 11:29:20.270271
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .counter import BytesCounter

    iv = bytes_to_intlist(compat_b64decode(b'4MCzu+7vhr8WODX5X2P5Sg=='))
    key = bytes_to_intlist(compat_b64decode(b'5Q5d-znSJgDvi+CGs5WxFw=='))
    counter = BytesCounter(iv)

# Generated at 2022-06-24 11:29:28.708163
# Unit test for function xor
def test_xor():
    result = xor([], [])
    print(result)
    assert [] == result

    result = xor([1], [1])
    print(result)
    assert [0] == result

    result = xor([1], [2])
    print(result)
    assert [3] == result

    result = xor([1, 2, 3], [1, 2, 3])
    print(result)
    assert [0, 0, 0] == result

    result = xor([1, 2, 3], [4, 5, 6])
    print(result)
    assert [5, 7, 5] == result



# Generated at 2022-06-24 11:29:35.323785
# Unit test for function shift_rows
def test_shift_rows():
    data = [1, 2, 3, 4,
            5, 6, 7, 8,
            9, 10, 11, 12,
            13, 14, 15, 16]

    data_shifted = [5, 2, 3, 4,
                    9, 6, 7, 8,
                    13, 10, 11, 12,
                    1, 14, 15, 16]

    data_shifted = shift_rows(data)
    print(data_shifted)
    return bytes(data_shifted) == bytes(data_shifted)


# Generated at 2022-06-24 11:29:39.215513
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for b in range(0, 256):
        for a in range(0, 256):
            assert(rijndael_mul(a, b) == RIJNDAEL_EXP_TABLE[(RIJNDAEL_LOG_TABLE[a] + RIJNDAEL_LOG_TABLE[b]) % 0xFF])

# Generated at 2022-06-24 11:29:48.991120
# Unit test for function mix_columns
def test_mix_columns():
    print("Testing Mix Columns...")
    data = read_file("MixColumnTest.txt", "hex")
    print("\tTest 0")
    possible_results = mix_columns(data)
    expected_result = read_file("MixColumnTestResult.txt", "hex")
    if isinstance(expected_result, list):
        expected_result = expected_result[0]
    result = False
    for item in possible_results:
        if item == expected_result:
            result = True
    print_result(result)
    print("\tTest 1")
    possible_results = mix_columns(data, MIX_COLUMN_MATRIX_INV)
    expected_result = read_file("InvMixColumnTestResult.txt", "hex")

# Generated at 2022-06-24 11:29:56.007498
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, initial_value):
            self.counter = initial_value

        def next_value(self):
            self.counter = (self.counter + 1) % 256
            return [self.counter for __ in range(16)]

    ciphertext = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    real_key = bytes_to_intlist(b'secret')


# Generated at 2022-06-24 11:30:01.194879
# Unit test for function mix_column
def test_mix_column():
    val = mix_column([0x01, 0x02, 0x03, 0x04], MIX_COLUMN_MATRIX)
    assert val == [0x02, 0x03, 0x01, 0x01], "mix_column is not correct: {0}".format(val)
    print("Unit test for function mix_column is passed.")



# Generated at 2022-06-24 11:30:04.209620
# Unit test for function inc
def test_inc():
    data = [255, 255, 255, 255]
    expected = [0, 0, 0, 0]
    data = inc(data)
    assert data == expected, "inc() failed."



# Generated at 2022-06-24 11:30:12.913455
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x29, 0x2e, 0x43, 0xc9, 0xa2, 0xd8, 0x7c, 0x01, 0x3d, 0x36, 0x54, 0xa1, 0xec, 0xf0, 0x06, 0x13]
    expected = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x1c, 0x16, 0xd6, 0x70, 0xed, 0x25, 0x8b, 0x57]
    assert sub_bytes(data) == expected


# Generated at 2022-06-24 11:30:15.878142
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x54, 0x77, 0x6F, 0x20]
    iteration = 1
    expected = [0xE2, 0x65, 0x3A, 0xC8]
    actual = key_schedule_core(data, iteration)
    assert actual == expected



# Generated at 2022-06-24 11:30:27.010919
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert (
        aes_decrypt_text(
            'z/HlI5I5jpOjtSzQtF5D54xC8WfY4j4iZkyaA0PXcEI',
            'password',
            16
        ) ==
        b'I love cupcakes'
    )
    assert (
        aes_decrypt_text(
            'VUxNhGRPrYHpN/6jZFV9/d8kMhFJvwCRybxmKjTOmWY',
            'password',
            24
        ) ==
        b'I love cupcakes'
    )

# Generated at 2022-06-24 11:30:33.179585
# Unit test for function mix_columns
def test_mix_columns():
    data = [0x8e, 0x20, 0xfa, 0x08, 0xae, 0x1d, 0xfa, 0x13, 0x9d, 0x84, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00]
    result = [0x8e, 0x20, 0xfa, 0x08, 0xae, 0x1d, 0xfa, 0x13, 0x9d, 0x84, 0x00, 0x00, 0x20, 0x00, 0x00, 0x00]
    assert result == mix_columns(data)



# Generated at 2022-06-24 11:30:42.038037
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0x07, 0xa8, 0x8d, 0xa2, 0x34]
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)
    encrypted_data = aes_encrypt(data, expanded_key)

# Generated at 2022-06-24 11:30:48.516519
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    IV = bytes_to_intlist(compat_b64decode("QUg8btZwfA5jtHZ7NGhOOA=="))
    PLAINTEXT = bytes_to_intlist(b"abcdefghijklmnoprstuvwxyz012345678901234567890123456789")
    CIPHERTEXT = bytes_to_intlist(compat_b64decode("AAjJzNL1iaVQ2qJMEUjKG1fco+U6YsUWfX9Jvczc+BlgiDyVnGwDmO0dns0aE44+ZVHrWmX8Ae2Q="))

# Generated at 2022-06-24 11:30:57.189329
# Unit test for function shift_rows

# Generated at 2022-06-24 11:31:03.809512
# Unit test for function inc
def test_inc():
    data = [1, 3, 0, 1]
    assert inc(data) == [1, 3, 0, 2]

    data = [1, 3, 0, 255]
    assert inc(data) == [1, 3, 1, 0]

    data = [1, 3, 255, 255]
    assert inc(data) == [1, 4, 0, 0]

    data = [255, 255, 255, 255]
    assert inc(data) == [0, 0, 0, 0]



# Generated at 2022-06-24 11:31:07.921806
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert shift_rows_inv(shift_rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]



# Generated at 2022-06-24 11:31:15.494560
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = 'aabbccddeeffgghh'
    key = '000102030405060708090a0b0c0d0e0f'
    data_int_list = bytes_to_intlist(data.encode())
    key_int_list = bytes_to_intlist(key.encode())
    expanded_key_int_list = key_expansion(key_int_list)
    result = aes_encrypt(data_int_list, expanded_key_int_list)
    result_bytes = intlist_to_bytes(result)
    result_bytes_str = result_bytes.decode()
    print(result_bytes_str)



# Generated at 2022-06-24 11:31:22.295545
# Unit test for function aes_decrypt
def test_aes_decrypt():
  key = [2,9,92,43,11,121,1,34,56,78,90,42,49,23,42,43]
  data = [2,9,22,43,11,121,1,34,56,78,90,42,49,23,42,43]
  expanded_key = key_expansion(key)
  assert aes_decrypt(data, expanded_key) == key
from __future__ import unicode_literals

from base64 import b64encode
from math import ceil
from hashlib import sha1

from .compat import compat_b64decode
from .utils import bytes_to_intlist, intlist_to_bytes

BLOCK_SIZE_BYTES = 16



# Generated at 2022-06-24 11:31:31.142578
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range(0xFF + 1):
        for b in range(0xFF + 1):
            c = rijndael_mul(a, b)
            d = rijndael_mul(b, a)
            e = rijndael_mul(a, 0)
            f = rijndael_mul(0, b)
            g = rijndael_mul(0, 0)
            assert c == d, f"Error in rijndael_mul({a}, {b})"
            assert e == 0, f"Error in rijndael_mul({a}, 0)"
            assert f == 0, f"Error in rijndael_mul(0, {b})"