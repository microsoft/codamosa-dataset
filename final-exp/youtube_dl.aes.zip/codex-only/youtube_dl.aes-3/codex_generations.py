

# Generated at 2022-06-24 11:21:32.503457
# Unit test for function mix_columns_inv

# Generated at 2022-06-24 11:21:35.408366
# Unit test for function xor
def test_xor():
    data1 = [1, 1, 1, 1]
    data2 = [1, 1, 1, 1]
    expected = [0, 0, 0, 0]
    result = xor(data1, data2)
    print(result)



# Generated at 2022-06-24 11:21:38.645054
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv([0,0,0,0]) == [0x52,0x9,0x6a,0xd5]



# Generated at 2022-06-24 11:21:48.415267
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-24 11:21:54.886415
# Unit test for function inc
def test_inc():
    data = [0x00, 0x00, 0x00, 0x00]
    assert inc(data) == [0x00, 0x00, 0x00, 0x01]

    data = [0x00, 0x00, 0x00, 0xFF]
    assert inc(data) == [0x00, 0x00, 0x01, 0x00]

    data = [0x00, 0x00, 0xFF, 0xFF]
    assert inc(data) == [0x00, 0x01, 0x00, 0x00]

    data = [0xFF, 0xFF, 0xFF, 0xFF]
    assert inc(data) == [0x00, 0x00, 0x00, 0x00]



# Generated at 2022-06-24 11:22:01.978541
# Unit test for function shift_rows
def test_shift_rows():
    data = [0, 1, 2, 3,
            4, 5, 6, 7,
            8, 9, 10, 11,
            12, 13, 14, 15]
    expect = [0, 1, 2, 3,
              5, 6, 7, 4,
              10, 11, 8, 9,
              15, 12, 13, 14]
    actual = shift_rows(data)
    for e, a in zip(expect, actual):
        if e != a:
            print("Shift rows failed")
            break
    else:
        print("Shift rows passed")



# Generated at 2022-06-24 11:22:08.354215
# Unit test for function aes_decrypt
def test_aes_decrypt():
    input = bytes_to_intlist(compat_b64decode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXo='))
    key = bytes_to_intlist(compat_b64decode('MDEyMzQ1Njc4OUFCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFla'))

    output = aes_decrypt(input, key)
    expected = bytes_to_intlist(compat_b64decode('ROY5+5fV7hGeDYFOYAa7MxgBdzPdHq3t'))

    print(intlist_to_bytes(output) == intlist_to_bytes(expected))

# Generated at 2022-06-24 11:22:19.239497
# Unit test for function key_expansion
def test_key_expansion():
    if key_expansion([2, 1, 3, 4, 5, 7, 6, 8, 10, 9, 11, 12, 13, 15, 14, 16]) != [
            2, 1, 3, 4, 5, 7, 6, 8, 10, 9, 11, 12, 13, 15, 14, 16,
            14, 14, 13, 13, 16, 15, 15, 13, 13, 16, 15, 15, 13, 13, 16, 15,
            13, 13, 16, 15, 15, 13, 13, 16, 15, 15, 13, 13, 16, 15, 15, 13,
            15, 13, 13, 16, 15, 15, 13, 13, 16, 15, 15, 13, 13, 16, 15, 15]:
        raise ValueError("Test key_expansion failed")

# Generated at 2022-06-24 11:22:29.774063
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0, 0, 0, 0]
    rcon_iteration = 1
    ret = key_schedule_core(data, rcon_iteration)
    assert(ret == [0x01, 0x00, 0x00, 0x00])
    data = [0x1f, 0x1e, 0x1d, 0x1c]
    rcon_iteration = 1
    ret = key_schedule_core(data, rcon_iteration)
    assert(ret == [0x1f, 0x1e, 0x1d, 0x1c])
    data = [0x1f, 0x1e, 0x1d, 0x1c]
    rcon_iteration = 2
    ret = key_schedule_core(data, rcon_iteration)

# Generated at 2022-06-24 11:22:40.879236
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = bytes_to_intlist(compat_b64decode('qCi1/aZVnMnMvS7KOm+KBw=='))
    key = bytes_to_intlist(compat_b64decode('rQ6rq3zW2i9XbHZD57UNWA=='))
    data = bytes_to_intlist(compat_b64decode('A9X1b/FA/KH+PZAo/PdH/w=='))

# Generated at 2022-06-24 11:22:46.174773
# Unit test for function xor
def test_xor():
    data1 = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]
    data2 = [0x88, 0x99, 0xa3, 0x9f, 0x48, 0x82, 0x79, 0x8a, 0x83, 0xb9, 0xa9, 0xbe, 0x78, 0x1f, 0x3f, 0x4e]

# Generated at 2022-06-24 11:22:49.643616
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    state = [0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
             0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    answer = mix_columns_inv(state)
    print(answer)


# test_mix_columns_inv()


# Generated at 2022-06-24 11:22:57.009271
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0xFF, 0x44, 0xC5, 0x53, 0xD7, 0x6D, 0x9F]
    expected = [0x8c, 0x6c, 0x2a, 0xef, 0x0b, 0xb9, 0x45]
    actual = sub_bytes(data)
    assert_equal(expected, actual)



# Generated at 2022-06-24 11:23:00.177727
# Unit test for function xor
def test_xor():
    assert xor([1,1],[0,1]) == [1,0]

#
#   key = [t0, t1, t2, t3] (16 bytes)
#   key_words = [[t0, t1, t2, t3], [t4, t5, t6, t7], [t8, t9, t10, t11], [t12, t13, t14, t15]] (4 words/4*4 bytes)
#

# Generated at 2022-06-24 11:23:08.681506
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    from .compat import compat_b64encode, compat_b64decode, compat_str
    from .utils import bytes_to_intlist, intlist_to_bytes

    # Test case from rfc3686 (http://tools.ietf.org/html/rfc3686)
    test_key = 'aefaefaefaefaefaefaefaefaefaefaefaefaefaefaefae'
    test_iv = '7a43ec1d9c0a5a78'
    test_cipher = '0388dace60b6a392f328c2b971b2fe78'
    test_plain = '6bc1bee22e409f96e93d7e117393172a'

    # test encryption/decryption
    cipher = aes_

# Generated at 2022-06-24 11:23:17.032101
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    '''
    aes_cbc_encrypt("'Twas brillig, and the slithy toves")
    '''
    #cleartext = [84, 39, 87, 97, 115, 32, 98, 114, 105, 108, 108, 105, 103, 33, 32, 97, 110, 100, 32, 116, 104, 101, 32, 115, 108, 105, 116, 104, 121, 32, 116, 111, 118, 101, 115, 33]
    key = bytes_to_intlist(b'ABCDEFGHIJKLMNOP')
    iv = bytes_to_intlist(b'ABCDEFGHIJKLMNOP')
    data = b"'Twas brillig, and the slithy toves"

    data = bytes_to_intlist(data)
    encrypted = aes_cbc_enc

# Generated at 2022-06-24 11:23:18.769015
# Unit test for function shift_rows
def test_shift_rows():
    assert(test_data == shift_rows(shift_rows(test_data)))
    assert(test_data == shift_rows(shift_rows(shift_rows(test_data))))
    assert(test_data == shift_rows(shift_rows(shift_rows(shift_rows(test_data)))))



# Generated at 2022-06-24 11:23:28.733396
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-24 11:23:34.580608
# Unit test for function aes_encrypt

# Generated at 2022-06-24 11:23:43.365288
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    test_key = [
        0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c
    ]
    test_iv = [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f
    ]

# Generated at 2022-06-24 11:23:56.988708
# Unit test for function key_expansion
def test_key_expansion():
    expanded = key_expansion(bytes_to_intlist(b'\x01\x23\x45\x67\x89\xab\xcd\xef\xf0\x12\x34\x56\x67\x78\x9a\xbc'))

# Generated at 2022-06-24 11:24:00.920892
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x01, 0x00, 0x00, 0x00]
    rcon_iteration = 1
    result = key_schedule_core(data, rcon_iteration)
    assert result == [0x02, 0x00, 0x00, 0x00]


# Generated at 2022-06-24 11:24:10.569135
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist('6bc1bee22e409f96e93d7e117393172a')
    expanded_key = bytes_to_intlist('603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4')
    assert aes_decrypt(data, expanded_key) == bytes_to_intlist('ae2d8a571e03ac9c9eb76fac45af8e51')

    data = bytes_to_intlist('ae2d8a571e03ac9c9eb76fac45af8e51')

# Generated at 2022-06-24 11:24:20.421674
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, counter):
            self.counter = counter

        def next_value(self):
            return self.counter

    assert aes_ctr_decrypt(
        bytes_to_intlist(compat_b64decode('''
            tBB6Sz2+T0d1O6Uc
            rwH6l8EoO/LpL1Xs
            4s8bWerRdRvH0Y4f
            Zq8WdF0SlIr2b9XS
            '''
        )),
        bytes_to_intlist('00112233445566778899aabbccddeeff'),
        Counter(bytes_to_intlist('fedcba9876543210'))
    ) == bytes_to_int

# Generated at 2022-06-24 11:24:26.484818
# Unit test for function inc
def test_inc():
    assert inc([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x01]
    assert inc([0xFF, 0xFF, 0xFF, 0xFF]) == [0x00, 0x00, 0x00, 0x00]
    assert inc([0x11, 0x12, 0x13, 0x14]) == [0x11, 0x12, 0x13, 0x15]
    assert inc([0x01, 0x01, 0x01, 0x01]) == [0x01, 0x01, 0x01, 0x02]
    print('test_inc: OK')
#test_inc()



# Generated at 2022-06-24 11:24:37.710809
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = [
        0x45, 0x83, 0xca, 0x1d,
        0x00, 0x17, 0x16, 0xeb,
        0x40, 0x97, 0x19, 0x91,
        0x94, 0x17, 0x48, 0x68
    ]


# Generated at 2022-06-24 11:24:45.222692
# Unit test for function mix_columns
def test_mix_columns():
    def test_mix_columns(data, expected_result):
        mixed = mix_columns(data)
        if mixed != expected_result:
            print('Error in test_mix_columns():')
            print('Data: ' + ''.join(format(x, '02x') for x in data))
            print('Mixed: ' + ''.join(format(x, '02x') for x in mixed))
            print('Expected result: ' + ''.join(format(x, '02x') for x in expected_result))


# Generated at 2022-06-24 11:24:50.687777
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert(rijndael_mul(0x57, 0x83) == 0xc1)
    assert(rijndael_mul(0x13, 0xca) == 0x01)
    assert(rijndael_mul(0x01, 0x02) == 0x02)


# Generated at 2022-06-24 11:24:59.963324
# Unit test for function shift_rows
def test_shift_rows():
    assert shift_rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]) == [0, 1, 2, 3, 5, 6, 7, 4, 10, 11, 8, 9, 15, 12, 13, 14]
    assert shift_rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]) == shift_rows([] + shift_rows(shift_rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])))



# Generated at 2022-06-24 11:25:06.215822
# Unit test for function aes_encrypt
def test_aes_encrypt():
    cipher = "d1145faa71de1a1ef09f008204a5e0d5"
    plaintext = "ffeeddccbbaa99887766554433221100"
    key = "000102030405060708090a0b0c0d0e0f"
    key_expanded = ''
    for index in range(16):
        key_expanded += key
    input_bytes = bytes_to_intlist(compat_b64decode(plaintext))
    key_expanded = bytes_to_intlist(compat_b64decode(key_expanded))
    cipher_output = aes_encrypt(input_bytes,key_expanded)
    cipher_bytes = bytes_to_intlist(compat_b64decode(cipher))

# Generated at 2022-06-24 11:25:17.482019
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import datetime

    class TestCase(object):
        def __init__(self, data, password, key_size_bytes, result):
            self.data = data
            self.password = password
            self.key_size_bytes = key_size_bytes
            self.result = result


# Generated at 2022-06-24 11:25:26.139117
# Unit test for function xor
def test_xor():
    data1 = [0x57, 0x69, 0x6b, 0x69]
    data2 = [0x00, 0x4b, 0xa6, 0x8a]
    expected = [0x57, 0x2e, 0xc5, 0xe3]
    assert xor(data1, data2) == expected
    print("test_xor - test passed")

# Generated at 2022-06-24 11:25:35.219432
# Unit test for function shift_rows
def test_shift_rows():
    assert shift_rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]) == [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
    assert shift_rows([15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0]) == [15, 11, 7, 3, 14, 10, 6, 2, 13, 9, 5, 1, 12, 8, 4, 0]

# Generated at 2022-06-24 11:25:39.615006
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x2, 0x2) == 0x4
    assert rijndael_mul(0x2, 0x3) == 0x6
    assert rijndael_mul(0x2, 0x9) == 0x12
    print("Passed rijndael_mul test")


# Generated at 2022-06-24 11:25:45.644259
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    correct = [0x57, 0x33, 0xA6, 0xBD, 0xF1, 0x76, 0xC1, 0x78, 0xB8, 0xD6, 0xDE, 0x6C, 0x2E, 0x26, 0xC1, 0x8B]
    out = mix_columns_inv(correct)
    for i in range(0,4):
        for j in range(0,4):
            if out[i*4+j] != 0:
                print(i)
                print(j)
                print (out[i*4+j])
                print("haha")
                break
    # print(correct)
    # print(out)

# test_mix_columns_inv()


# Generated at 2022-06-24 11:25:54.633427
# Unit test for function key_expansion
def test_key_expansion():
    res = key_expansion([0x4e, 0x15, 0x48, 0x1e, 0x61, 0x97, 0x0b, 0x4d, 0x96, 0x0d, 0xee, 0x25, 0x7c, 0x10, 0xdf, 0x0b])
    res = bytes_to_intlist(intlist_to_bytes(res)[::-1])

# Generated at 2022-06-24 11:26:05.695783
# Unit test for function mix_columns
def test_mix_columns():
    from base64 import b16decode

    original_data = b16decode("008182838485868788898A8B8C8D8E8F")
    after_mix_columns = b16decode("01050F151D75B6ED9A9A4C4E71B8FFDC")
    # Test for SBOX
    assert(mix_columns(original_data) == after_mix_columns)
    after_mix_columns_inv = b16decode("01050F151D75B6ED9A9A4C4E71B8FFDC")
    # Test for SBOX_INV
    assert(mix_columns(original_data,MIX_COLUMN_MATRIX_INV) == after_mix_columns_inv)

test_mix_column

# Generated at 2022-06-24 11:26:14.621357
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Test vector from: https://tools.ietf.org/html/rfc3686
    # Section 6.1
    assert (
        aes_decrypt_text(
            b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==',
            b'Jefe',
            32
        ) ==
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    )

# Generated at 2022-06-24 11:26:18.067534
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    print("mix_columns_inv should work as the inverse of mix_columns")
    data = (0xdb, 0x13, 0x53, 0x45)
    data_mixed = mix_columns(data)
    data_mixed_inv = mix_columns_inv(data_mixed)
    if data_mixed_inv == data:
        print("Successful")
    else:
        print("Failed")


if __name__ == "__main__":
    test_mix_columns_inv()

# Generated at 2022-06-24 11:26:26.171672
# Unit test for function mix_column
def test_mix_column():
    data = [0x9C,0x6E,0x3c,0x66]
    matrix = ((0x2, 0x3, 0x1, 0x1),
             (0x1, 0x2, 0x3, 0x1),
             (0x1, 0x1, 0x2, 0x3),
             (0x3, 0x1, 0x1, 0x2))
    print(mix_column(data, matrix))
    print(b'\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10')

# Generated at 2022-06-24 11:26:33.565314
# Unit test for function aes_encrypt
def test_aes_encrypt():
    block = [
        0x32, 0x43, 0xf6, 0xa8,
        0x88, 0x5a, 0x30, 0x8d,
        0x31, 0x31, 0x98, 0xa2,
        0xe0, 0x37, 0x07, 0x34
    ]

# Generated at 2022-06-24 11:26:40.958727
# Unit test for function key_schedule_core
def test_key_schedule_core():
    test_key = [0x2b, 0x7e, 0x15, 0x16]
    expected_key = [0x8e, 0x73, 0xb0, 0xf7]

    key = key_schedule_core(test_key, 1)
    if key != expected_key:
        print(test_key)
        print(expected_key)
        print(key)
        print("test_key_schedule_core failed")
    else:
        print("test_key_schedule_core passed")


test_key_schedule_core()


# Generated at 2022-06-24 11:26:53.183612
# Unit test for function xor
def test_xor():
    assert xor([0x57, 0x00, 0x42, 0x15, 0xde, 0xad, 0xbe, 0xef, 0xfe, 0xed, 0xa0, 0xba, 0xda, 0x00, 0x4c, 0x43],
    [0x57, 0x00, 0x42, 0x15, 0xde, 0xad, 0xbe, 0xef, 0xfe, 0xed, 0xa0, 0xba, 0xda, 0x00, 0x4c, 0x43]) == [0]*16

# Generated at 2022-06-24 11:26:59.296546
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xDB, 0x13, 0x53, 0x45,
        0xF2, 0x0A, 0x22, 0x5C,
        0x01, 0x01, 0x01, 0x01,
        0x01, 0x01, 0x01, 0x01]
    expected_result = [0x8E, 0x4D, 0xA1, 0xBC,
        0x9F, 0xDC, 0x58, 0x9D,
        0x01, 0x01, 0x01, 0x01,
        0x01, 0x01, 0x01, 0x01]
    assert expected_result == mix_columns_inv(data)
    print("test_mix_columns_inv passed.")



# Generated at 2022-06-24 11:27:03.011877
# Unit test for function rotate
def test_rotate():
    assert rotate([0x2, 0x3, 0x1, 0x1]) == [0x3, 0x1, 0x1, 0x2]


# Generated at 2022-06-24 11:27:14.914968
# Unit test for function aes_encrypt

# Generated at 2022-06-24 11:27:25.518956
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # From http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    key = bytes_to_intlist(compat_b64decode('2b7e151628aed2a6abf7158809cf4f3c'))
    iv = bytes_to_intlist(compat_b64decode('000102030405060708090a0b0c0d0e0f'))

# Generated at 2022-06-24 11:27:31.252114
# Unit test for function rotate
def test_rotate():
    assert rotate([0x01, 0x01, 0x01, 0x01]) == [0x01, 0x01, 0x01, 0x01]
    assert rotate([0x02, 0x02, 0x02, 0x02]) == [0x02, 0x02, 0x02, 0x02]
    assert rotate([0x03, 0x03, 0x03, 0x03]) == [0x03, 0x03, 0x03, 0x03]
    assert rotate([0x04, 0x04, 0x04, 0x04]) == [0x04, 0x04, 0x04, 0x04]
    assert rotate([0x05, 0x05, 0x05, 0x05]) == [0x05, 0x05, 0x05, 0x05]

# Generated at 2022-06-24 11:27:35.103303
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    data = [0x1f, 0x1d, 0x0c, 0x03, 0xa6, 0x6b, 0x75, 0xfd, 0xdf, 0x40, 0x2a, 0xa5, 0x2f, 0x20, 0x87, 0x00]
    test_data = sub_bytes_inv(data)
    correct_data = [0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0xa2, 0xc2, 0xa7, 0x24, 0xec]
    assert test_data == correct_data



# Generated at 2022-06-24 11:27:43.036056
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    import time
    start_time = time.time()
    #data = bytes_to_intlist('A' * 128)
    #key = bytes_to_intlist(b'k' * 32)
    #iv = bytes_to_intlist(b'i' * 16)
    data = bytes_to_intlist(compat_b64decode('U2FsdGVkX1+s0nzyzvnTmOUWj+Y6UJk6rZlI2bwKs8Fk7c6WiL+6vX9WpKd6YHU6'))

# Generated at 2022-06-24 11:27:50.639896
# Unit test for function rotate
def test_rotate():
    data = [0x32, 0x10, 0x52, 0x38]
    ans = [0x10, 0x52, 0x38, 0x32]
    ans2 = [0x52, 0x38, 0x32, 0x10]
    ans3 = [0x38, 0x32, 0x10, 0x52]
    test = rotate(data)
    test2 = rotate(test)
    test3 = rotate(test2)
    if ans == test and ans2 == test2 and ans3 == test3:
        print('Unit test for functions rotate passed!')
    else:
        print('Unit test for functions rotate failed!')



# Generated at 2022-06-24 11:27:57.246980
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'vzflfiWwGUBbMeVZlhoyvzflfQsUczM6Uc0aUczM6Uc2Q=='
    password = 'thisismypassword'
    encrypted = '{"id":"thisismyid","key":"thisismykey"}'
    decrypted = aes_decrypt_text(data, password, 32)
    assert decrypted == encrypted



# Generated at 2022-06-24 11:28:07.179171
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):

        def __init__(self, value):
            self.value = value

        def next_value(self):
            next_value, self.value = self.value, self.value + 1
            return [next_value >> i & 0xff for i in (24, 16, 8, 0)]

    class Test(object):

        def __init__(self, key, data, counter):
            self.key = key
            self.data = data
            self.counter = counter

        def run(self):
            decrypted = aes_ctr_decrypt(self.data, self.key, self.counter)
            if decrypted != self.data:
                return False
            return True


# Generated at 2022-06-24 11:28:16.758877
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    cipher = bytes_to_intlist(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')
    iv = [0] * 16
    data = aes_cbc_decrypt(cipher, key, iv)
    assert intlist_to_bytes(data) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '

# Generated at 2022-06-24 11:28:27.688858
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(
        b'MZ\xbb\xbb\xbb\xbb\xbb\xbb\xbb\xbb\xbb\xbb\xbb\xbb\xbb\xbb\xbb')
    key = bytes_to_intlist(
        b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    iv = bytes_to_intlist(16 * [0])
    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-24 11:28:30.073478
# Unit test for function sub_bytes
def test_sub_bytes():
    a = [0x19, 0xa0, 0x9a, 0xe9]
    b = [0xd4, 0xe0, 0xb8, 0x1e]
    assert sub_bytes(a) == b

test_sub_bytes()


# Generated at 2022-06-24 11:28:36.741978
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [
        0x19, 0xa0, 0x9a, 0xe9,
        0x3d, 0xf4, 0xc6, 0xf8,
        0xe3, 0xe2, 0x8d, 0x48,
        0xbe, 0x2b, 0x2a, 0x08]
    data_shifted = shift_rows_inv(data)
    for i in range(4):
        for j in range(4):
            assert data_shifted[i * 4 + j] == data[i + 4 * j]

test_shift_rows_inv()

# Generated at 2022-06-24 11:28:46.801127
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = intlist_to_bytes([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])
    key = intlist_to_bytes([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])
    expanded_key = key_expansion(key)
    encrypted_data = aes_encrypt(data, expanded_key)
    decrypted_data = aes_decrypt(encrypted_data, expanded_key)
    assert(data == decrypted_data)
    return 'Pass'
#print(test_aes_decrypt())


# Generated at 2022-06-24 11:28:58.706908
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import unittest
    class TestCounter(object):
        def __init__(self, initial_value):
            self.value = initial_value
        def next_value(self):
            self.value = intlist_to_bytes(aes_encrypt(self.value,
                                                      key_expansion([0] * 16)))
            return self.value
    class TestAESCTRDecrypt(unittest.TestCase):
        def _test(self, key, data, counter_value, expected_result):
            key = bytes_to_intlist(compat_b64decode(key))
            data = bytes_to_intlist(compat_b64decode(data))
            counter_value = bytes_to_intlist(compat_b64decode(counter_value))
            expected_result = bytes

# Generated at 2022-06-24 11:29:02.092601
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x01, 0x02, 0x03, 0x04]
    expected = [0x01, 0x00, 0x00, 0x05]
    actual = key_schedule_core(data, 1)

# Generated at 2022-06-24 11:29:10.773773
# Unit test for function aes_encrypt
def test_aes_encrypt():
    test_data = [0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0x07, 0xa8, 0x8d, 0xa2, 0x34]
    test_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-24 11:29:13.492554
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key = [0x01, 0x01, 0x01, 0x01]
    expected_result = [0x01, 0x01, 0x01, 0x01]
    result = key_schedule_core(key, 0)
    assert result == expected_result



# Generated at 2022-06-24 11:29:23.035550
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    KEY = bytes_to_intlist(compat_b64decode('qCqDRBbwjlt4D4i7ZUhWpA=='))
    IV = bytes_to_intlist(compat_b64decode('D4i7ZUhWpA=='))
    CIPHER = bytes_to_intlist(compat_b64decode('FCH0V6UZ/6X9j0B+J0q/3g=='))

    assert(b'encryption test') == intlist_to_bytes(aes_cbc_decrypt(CIPHER, KEY, IV))

# Generated at 2022-06-24 11:29:27.556260
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [1,2,3,4]
    sboxed = [0x63, 0x7C, 0x77, 0x7B]
    assert sub_bytes(data) == sboxed



# Generated at 2022-06-24 11:29:32.429648
# Unit test for function inc
def test_inc():
    test_data = [1, 2, 3, 4, 5]
    result_data = [1, 2, 3, 4, 6]
    assert(inc(test_data) == result_data)
    test_data = [1, 1, 1, 1, 255]
    result_data = [1, 1, 1, 2, 0]
    assert(inc(test_data) == result_data)
# --------------------------------------------

# Generated at 2022-06-24 11:29:39.814122
# Unit test for function mix_columns
def test_mix_columns():
    testdata = [0xDB, 0x13, 0x53, 0x45,
                0xF2, 0x0A, 0x22, 0x5C,
                0x01, 0x01, 0x01, 0x01,
                0xAB, 0xAB, 0xAB, 0xAB]
    mix_data = mix_columns(testdata)
    assert mix_data == [0x8E, 0x4D, 0xA1, 0xBC,
                        0x9F, 0xDC, 0x58, 0x9D,
                        0x01, 0x01, 0x01, 0x01,
                        0xF4, 0xA5, 0x24, 0xD0]

# Generated at 2022-06-24 11:29:46.410854
# Unit test for function rotate
def test_rotate():
    assert rotate([0, 1, 2, 3]) == [1, 2, 3, 0]
    assert rotate([0, 1, 2, 3, 4, 5, 6, 7]) == [1, 2, 3, 4, 5, 6, 7, 0]
    assert rotate([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
# Actually write the unit tests
test_rotate()


# Generated at 2022-06-24 11:29:50.902782
# Unit test for function inc
def test_inc():
    x = data = [0x01, 0x01, 0x01, 0x01, 0x01]
    y = inc(x)
    if (y == [-1, 0, 0, 0, 0]):
        print("inc  works")
    else:
        print("inc Not works")
    return
test_inc()


# Generated at 2022-06-24 11:30:02.821715
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # key = ['2b', '7e', '15', '16', '28', 'ae', 'd2', 'a6', 'ab', 'f7', '15', '88', '09', 'cf', '4f', '3c']
    key = '2b7e151628aed2a6abf7158809cf4f3c'
    iv = '000102030405060708090a0b0c0d0e0f'
    plaintext = '6bc1bee22e409f96e93d7e117393172aae2d8a571e03ac9c9eb76fac45af8e5130c81c46a35ce411e5fbc1191a0a52eff69f2445df4f9b17ad2b417be66c3710'
    cipher

# Generated at 2022-06-24 11:30:14.020338
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = b'test'
    key = b'foobarfoobarfoob'
    iv = b'1234567890123456'
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    encrypted_data = b''.join(map(chr, encrypted_data))
    assert encrypted_data == b'\xcc\x9e\xacN\xb1\xe2\xfa\xf6\x00\x00\x00\x00\x00\x00\x00\x00\x00'

    data = b'test'
    key = b'foobarfoobarfoobar'
    iv = b'1234567890123456'
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    encrypted_data = b''.join

# Generated at 2022-06-24 11:30:16.971887
# Unit test for function xor
def test_xor():
    data1 = [1, 2, 3, 4]
    data2 = [5, 6, 7, 8]

# Generated at 2022-06-24 11:30:27.526111
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x45, 0x6e, 0x66, 0x20, 0x65, 0x63]
    expect_data = [0x45, 0x6e, 0x66, 0x20, 0x65, 0x63]
    expect_result = [0x45, 0x6e, 0x66, 0x20, 0x65, 0x63]
    expect_result[0] = expect_result[0] ^ RCON[1]
    result = key_schedule_core(data, 1)
    assert (result == expect_result)
    assert (data == expect_data)
test_key_schedule_core()


# Generated at 2022-06-24 11:30:35.486232
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJUBQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    class Counter(object):
        def __init__(self, start_value):
            self._start_value = start_value
            self._value = start_value

        def next_value(self):
            self._value = intlist_to_bytes(bytes_to_intlist(self._value) + 1)
            return self._value
    counter = Counter('\x00' * BLOCK_SIZE_BYTES)
    decrypted_data = aes_ctr

# Generated at 2022-06-24 11:30:45.395685
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert(mix_columns_inv(mix_columns([1, 2, 3, 4])) == [1, 2, 3, 4])
    assert(mix_columns_inv(mix_columns([14, 11, 13, 9])) == [14, 11, 13, 9])
    assert(mix_columns_inv(mix_columns([0x2, 0x3, 0x1, 0x1])) == [0x2, 0x3, 0x1, 0x1])

# Generated at 2022-06-24 11:30:53.835089
# Unit test for function aes_decrypt
def test_aes_decrypt():
  key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F]
  cipher = [0x69, 0xC4, 0xE0, 0xD8, 0x6A, 0x7B, 0x04, 0x30, 0xD8, 0xCD, 0xB7, 0x80, 0x70, 0xB4, 0xC5, 0x5A]
  data = aes_decrypt(cipher, key)

# Generated at 2022-06-24 11:31:02.890188
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """Unit test for function aes_decrypt_text
    """
    from .utils import bytes_to_hex
    from .compat import compat_urllib_parse_unquote

    def test_vectors(vectors):
        for key_size_bytes, key, data, expected in vectors:
            assert aes_decrypt_text(data, key, key_size_bytes) == expected.encode('utf-8')


# Generated at 2022-06-24 11:31:12.382807
# Unit test for function key_expansion
def test_key_expansion():
    key_16_bytes = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    key_24_bytes = [0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5, 0x62, 0xf8, 0xea, 0xd2, 0x52, 0x2c, 0x6b, 0x7b]

# Generated at 2022-06-24 11:31:23.276175
# Unit test for function aes_cbc_encrypt