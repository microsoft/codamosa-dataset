

# Generated at 2022-06-24 11:21:28.040558
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    expanded_key = key_expansion(key)
    assert aes_encrypt(data, expanded_key) == [16, 64, 32, 16, 40, 64, 32, 16, 40, 128, 64, 32, 16, 40, 128, 64]

    data = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

# Generated at 2022-06-24 11:21:38.038544
# Unit test for function aes_encrypt
def test_aes_encrypt():
    print("Testing function aes_encrypt")
    for key in [
        [101, 201, 236, 243] * 4,
        [152, 185, 75, 182] * 4,
        [174, 248, 137, 254] * 4
    ]:
        expanded_key = key_expansion(key)
        for cleartext in [
            [48, 113, 93, 88] * 4,
            [118, 0, 53, 101] * 4,
            [224, 12, 81, 216] * 4
        ]:
            cipher = aes_encrypt(cleartext, expanded_key)
            if cipher != aes_encrypt(cleartext, expanded_key):
                raise ValueError('aes_encrypt is not working properly')
    print("Test passed")
#test_aes_encrypt()


# Generated at 2022-06-24 11:21:40.806509
# Unit test for function xor
def test_xor():
    assert xor([0x57, 0x83, 0xf5, 0x27], [0x13, 0x53, 0xf9, 0x2d]) == [0x44, 0xd0, 0x0c, 0x0a]



# Generated at 2022-06-24 11:21:44.608786
# Unit test for function shift_rows
def test_shift_rows():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    data_shifted = shift_rows(data)
    assert(data_shifted == [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15])



# Generated at 2022-06-24 11:21:52.740757
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-24 11:21:55.805111
# Unit test for function sub_bytes
def test_sub_bytes():
    round_key = [0] * 16
    assert sub_bytes(round_key) == [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]


# Generated at 2022-06-24 11:22:01.827381
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    state = [0xdb, 0xf2, 0xd4, 0x6f,
             0xe9, 0xc3, 0xeb, 0x09,
             0x23, 0x1b, 0xd7, 0xf1,
             0x80, 0x71, 0xee, 0x2e]
    state = mix_columns_inv(state)
    expected = [0xb0, 0xbb, 0x90, 0x23,
                0x9b, 0xc1, 0xe8, 0x71,
                0x24, 0x7c, 0x67, 0x9e,
                0x63, 0xec, 0x77, 0x32]
    assert(state == expected)

test_mix_columns_inv()



# Generated at 2022-06-24 11:22:04.626661
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([1, 2, 3, 4])) == [1, 2, 3, 4]



# Generated at 2022-06-24 11:22:13.596189
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [161, 168, 40, 89, 224, 192, 128, 136, 219, 184,
           118, 133, 183, 90, 197, 179, 94, 191, 95, 252,
           122, 95, 212, 6, 109, 169, 109, 214, 195, 165]
    data = [161, 168, 40, 89, 224, 192, 128, 136, 219, 184,
            118, 133, 183, 90, 197, 179]
    iv = [255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
          255, 255, 255, 255, 255, 255]
    expected = [161, 168, 40, 89, 224, 192, 128, 136, 219, 184,
                118, 133, 183, 90, 197, 179]

# Generated at 2022-06-24 11:22:16.377098
# Unit test for function inc
def test_inc():
    data = [1, 255, 255, 255]
    print('before: {}'.format(data))
    print('after: {}'.format(inc(data)))
    assert inc(data) == [2, 0, 0, 0]

# Generated at 2022-06-24 11:22:22.347951
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    assert data_mixed == [0x8e, 0x4d, 0xa1, 0xbc]
    # Test inverse function
    data_mixed = mix_column(data_mixed, MIX_COLUMN_MATRIX_INV)
    assert data_mixed == data

test_mix_column()



# Generated at 2022-06-24 11:22:27.517633
# Unit test for function key_schedule_core
def test_key_schedule_core():
    original_data = [0x00, 0x00, 0x00, 0x00]
    expected_result = [0x01, 0x00, 0x00, 0x00]

    result = key_schedule_core(original_data, 1)

    print(result == expected_result)


test_key_schedule_core()


# Generated at 2022-06-24 11:22:31.374187
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]) \
        == [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]
    return True


# Generated at 2022-06-24 11:22:34.662942
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text('bVcEbHBhcw==', 'asdfghjkl1234', 16) != 'bVcEbHBhcw=='


# Generated at 2022-06-24 11:22:39.167318
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert (rijndael_mul(0x57, 0x83) == 0xC1)
    assert (rijndael_mul(0x13, 0x0E) == 0x0C)
    assert (rijndael_mul(0xE0, 0x01) == 0xE0)
    print("rijndael_mul unit test passed")



# Generated at 2022-06-24 11:22:41.609174
# Unit test for function shift_rows
def test_shift_rows():
    data = [column + row for row in range(4) for column in range(4)]
    data_shifted = shift_rows(data)
    assert data_shifted == [0, 1, 2, 3, 5, 6, 7, 4, 10, 11, 8, 9, 15, 12, 13, 14]



# Generated at 2022-06-24 11:22:49.628055
# Unit test for function key_expansion
def test_key_expansion():
    # known test case from
    # http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    data = bytes_to_intlist(compat_b64decode('C8A64537A0B3A93FC8A64537A0B3A93F'))
    expected = bytes_to_intlist(compat_b64decode('C8A64537A0B3A93FC8A64537A0B3A93FFE0C9C2E4A7FE0C9C2E4A7FE0C9C2E4A7') + '\x01\x02\x03\x04\x01\x02\x03\x04\x01\x02\x03\x04')
    assert int

# Generated at 2022-06-24 11:22:59.327192
# Unit test for function aes_encrypt

# Generated at 2022-06-24 11:23:02.467832
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b'YELLOW SUBMARINE')
    key = [0x00] * 16
    iv = [0x00] * 16
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    print(encrypted_data)
    encrypted_data = intlist_to_bytes(encrypted_data)
    print(compat_b64encode(encrypted_data))


# Generated at 2022-06-24 11:23:10.471614
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x95, 0x71, 0xb6, 0x8e, 0x6d,
            0x25, 0x2e, 0x1c, 0x7a, 0x92,
            0x4b, 0x7e, 0x5f, 0xc4, 0xad,
            0xd4, 0xa4, 0xaf, 0x8a, 0x51]
    data = shift_rows_inv(data)


# Generated at 2022-06-24 11:23:18.014020
# Unit test for function key_expansion

# Generated at 2022-06-24 11:23:24.732626
# Unit test for function xor
def test_xor():
	data1 = [0x12, 0x23, 0x34, 0x45]
	data2 = [0x30, 0x41, 0x52, 0x63]
	out = xor(data1, data2)
	assert out == [0x22, 0x62, 0x66, 0x26], "xor function failed"

# Generated at 2022-06-24 11:23:27.284716
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([0,0xa,0xf,0x5])) == [0,0xa,0xf,0x5]


# Generated at 2022-06-24 11:23:35.538554
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Cipher
    cipher = bytes_to_intlist(compat_b64decode(('U2FsdGVkX1/L7VlN+OuI7VwO/ZuqI5o5r5r5eRxCX9yhV7Prl1+MFpV7saG3kq3d'
                                                'uF7vxX9zgYBkU6fyEuQ2wcgBjZdlvsAIM0sj2zv0X9Cxdxyk/MyjKm0b0wT8gfWK').encode('ascii')))
    # Key

# Generated at 2022-06-24 11:23:38.124393
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x10,0x20,0x30,0x40]) == [0x7c, 0x9a, 0xb1, 0x4d]



# Generated at 2022-06-24 11:23:45.715390
# Unit test for function mix_columns
def test_mix_columns():
    test_vector = [0xdb, 0x0f, 0x02, 0x01]
    test_vector_mixed = mix_column(test_vector,MIX_COLUMN_MATRIX)
    assert test_vector_mixed == [0x8e, 0x4d, 0xa1, 0xbc]

    test_vector = [0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    test_vector_mixed = mix_columns(test_vector)

# Generated at 2022-06-24 11:23:50.281825
# Unit test for function inc
def test_inc():
    assert inc([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x01]
    assert inc([0x00, 0x00, 0x00, 0xff]) == [0x00, 0x00, 0x01, 0x00]
    assert inc([0x7e, 0x57, 0x1d, 0x0e]) == [0x7e, 0x57, 0x1d, 0x0f]
    assert inc([0xff, 0xff, 0xff, 0xff]) == [0x00, 0x00, 0x00, 0x00]



# Generated at 2022-06-24 11:23:52.614510
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key = [0x00, 0x04, 0x08, 0x0c]
    assert key_schedule_core(key, 1) == [0x01, 0x05, 0x09, 0x0d]
    assert key_schedule_core(key, 2) == [0x02, 0x06, 0x0A, 0x0E]



# Generated at 2022-06-24 11:24:01.067383
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import random
    import string

    class Counter():
        def __init__(self, seed):
            self.count = seed
        def next_value(self):
            self.count += 1
            return bytes_to_intlist(compat_b64decode(
                compat_b64encode('{:016}'.format(self.count).encode())
            ))

    for _ in range(100):
        data = ''.join(
            random.choice(string.ascii_letters) for _ in range(random.randint(0, 1024))
        ).encode()

# Generated at 2022-06-24 11:24:06.190886
# Unit test for function inc
def test_inc():
    data = [0x00, 0x00, 0x00, 0x00]
    res = inc(data)
    assert res == [0x00, 0x00, 0x00, 0x01]
    res = inc(res)
    assert res == [0x00, 0x00, 0x00, 0x02]



# Generated at 2022-06-24 11:24:13.359687
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    datalist = [0x63,0x63,0x63,0x63,0x63,0x63,0x63,0x63,0x63,0x63,0x63,0x63,0x63,0x63,0x63,0x63]
    cipher_with_function = sub_bytes_inv(datalist)
    cipher_by_hand = sub_bytes(datalist)
    print(cipher_with_function)
    print(cipher_by_hand)
    if cipher_with_function == cipher_by_hand:
        print('The test passed successfully.')
    else:
        print('Something went wrong.')
#test_sub_bytes_inv()


# Generated at 2022-06-24 11:24:22.666568
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-24 11:24:24.280923
# Unit test for function xor
def test_xor():
    assert xor([1,2,3,4], [2,2,2,1]) == [3,0,1,5]



# Generated at 2022-06-24 11:24:25.416242
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3,4]) == [2,3,4,1]


# Generated at 2022-06-24 11:24:28.576239
# Unit test for function xor
def test_xor():
    """Test that xor function produces the correct result"""
    assert xor([0xFF, 0x01, 0x01, 0x01], [0x0F, 0x0F, 0x0F, 0x0F]) == [0xF0, 0x0E, 0x0E, 0x0E]
    print("Test of function xor : Pass")



# Generated at 2022-06-24 11:24:33.612214
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    input = "teststring"
    key = "testkeytestkey"
    iv = "testivtestivte"
    output = "kaE8iXA1/Y0M+jGQ"
    test = aes_cbc_encrypt(
        bytes_to_intlist(bytearray(input, 'utf8')),
        bytes_to_intlist(bytearray(key, 'utf8')),
        bytes_to_intlist(bytearray(iv, 'utf8'))
    )
    assert intlist_to_bytes(test) == bytearray(output, 'utf8')
test_aes_cbc_encrypt()



# Generated at 2022-06-24 11:24:36.440452
# Unit test for function inc
def test_inc():
    assert inc([0] * 16) == [1] * 16
    assert inc([255] * 16) == [0] * 15 + [1]



# Generated at 2022-06-24 11:24:38.054930
# Unit test for function shift_rows
def test_shift_rows():
    data_test = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    data_shifted = shift_rows(data_test)
    print(data_shifted)



# Generated at 2022-06-24 11:24:43.625625
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x52, 0x09, 0x6A, 0xD5, 
            0x30, 0x36, 0xA5, 0x38,
            0xBF, 0x40, 0xA3, 0x9E,
            0x81, 0xF3, 0xD7, 0xFB]
    print(shift_rows(data))



# Generated at 2022-06-24 11:24:48.105289
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Encrypted data
    data = b'MkKjR5EzHhsZbCxn1h+ZBQ=='
    # Encryption password
    password = '#1dj8$=dp?.ak//j1V$~%*0X'

    decrypted_data = aes_decrypt_text(data, password, 16)

    # You can verify this decrypted data on http://aesencryption.net/
    print(decrypted_data)



# Generated at 2022-06-24 11:24:54.830103
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x31, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]) == [0x63, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]



# Generated at 2022-06-24 11:25:06.637838
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    cipher = compat_b64decode(
        'rtZvTMjW+U8r6J0rqr3I6T9yA+jz/m+gI2fwzVWvDm8=')
    key = compat_b64decode(
        'MFEwDQYJYIZIAWUDBAIDBQAEQIe3UKrRW+3T/Jvyd8yL0qykJ4qh3BH4ImuaZ0w==')
    iv = compat_b64decode(
        'tO5uVl5zt+fvV7YwPyjOGg==')
    expanded_key = key_expansion(bytes_to_intlist(key))

# Generated at 2022-06-24 11:25:17.818786
# Unit test for function key_expansion
def test_key_expansion():
    test_key_size = [16, 24, 32]

# Generated at 2022-06-24 11:25:25.088865
# Unit test for function shift_rows
def test_shift_rows():
    data_input = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    data_output = shift_rows(data_input)
    data_output_correct = [1, 2, 3, 4, 6, 7, 8, 5, 11, 12, 13, 9, 14, 15, 16, 10]
    if(data_output == data_output_correct):
        print("test_shift_rows: OK")
    else:
        print("test_shift_rows: FAILED")

test_shift_rows()


# Generated at 2022-06-24 11:25:34.820254
# Unit test for function xor
def test_xor():
    data1 = [0x02, 0x3c, 0x6e, 0x8a, 0x7c, 0x78, 0x9e, 0x2b, 0x5e, 0x7d, 0x5a, 0x96, 0x0f, 0x4c, 0x35, 0x98]
    data2 = [0x92, 0x13, 0x29, 0x2d, 0x52, 0x51, 0x53, 0x45, 0x3c, 0x47, 0x4b, 0x4f, 0x09, 0x14, 0x1f, 0x17]
    data = xor(data1, data2)

# Generated at 2022-06-24 11:25:42.688822
# Unit test for function shift_rows
def test_shift_rows():
    test_data = [0x63, 0xca, 0xb7, 0x04,
                 0x6f, 0x6e, 0x6c, 0x69,
                 0x65, 0x77, 0x7f, 0x72,
                 0x6b, 0x20, 0x6f, 0x6f]
    assert shift_rows(test_data) == [0x63, 0x6f, 0x65, 0x6b,
                                     0xca, 0x6e, 0x77, 0x20,
                                     0xb7, 0x6c, 0x7f, 0x6f,
                                     0x04, 0x69, 0x72, 0x6f]



# Generated at 2022-06-24 11:25:45.842034
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert(rijndael_mul(0x57, 0x83) == 0xc1)
    assert(rijndael_mul(0x13, 0x57) == 0xfe)



# Generated at 2022-06-24 11:25:48.694428
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    print("mix_columns_inv")
    print(data)
    print(mix_columns_inv(data))


# Generated at 2022-06-24 11:25:58.477906
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = bytes_to_intlist(compat_b64decode('K0RIi1M/6uW4aPQM6FxT6g=='))
    cipher = bytes_to_intlist(compat_b64decode('voLfVuHnxl1dDseziAduXQ=='))

    class MockCounter(object):
        def next_value(self):
            return [0] * 16

    counter = MockCounter()
    plain = aes_ctr_decrypt(cipher, key, counter)
    #print(intlist_to_bytes(plain))
    assert intlist_to_bytes(plain) == b'panda'


# Generated at 2022-06-24 11:26:02.439085
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key = [0x2B, 0x28, 0xAB, 0x09]
    rcon_iteration = 1
    output = [0xA4, 0x68, 0x6B, 0x02]
    assert key_schedule_core(key, rcon_iteration) == output
    
    

# Generated at 2022-06-24 11:26:04.651995
# Unit test for function inc
def test_inc():
    assert inc([0,0,0,0]) == [0,0,0,1]
    assert inc([255,255,255,255]) == [0,0,0,0]
    assert inc([0,0,255,255]) == [0,1,0,0]


# Generated at 2022-06-24 11:26:14.676748
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'00010203050607080A0B0C0D0F101112')
    iv = bytes_to_intlist(b'0F1E2D3C4B5A697879788899A9B8C7D6')

    data = bytes_to_intlist(b'00112233445566778899AABBCCDDEEFF')
    expected = [
        0xD8, 0x20, 0x39, 0x3A, 0x6D, 0xD5, 0x5C, 0x11, 0x9B, 0x07, 0x46, 0xF7,
        0x4B, 0x4F, 0xBF, 0x27
    ]

# Generated at 2022-06-24 11:26:23.912674
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-24 11:26:24.769783
# Unit test for function inc
def test_inc():
    for i in range(0, 20):
        print(i & 0b1111)



# Generated at 2022-06-24 11:26:29.118975
# Unit test for function key_schedule_core
def test_key_schedule_core():
    print("\nkey schedule core")
    key = [0x54, 0x68, 0x61, 0x74]
    result = key_schedule_core(key, 1)
    print("result", result)
    print("expected", [0xE2, 0xFC, 0xC1, 0x5A])


# Generated at 2022-06-24 11:26:35.965143
# Unit test for function mix_columns
def test_mix_columns():
    b = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    assert mix_columns(b) == result



# Generated at 2022-06-24 11:26:47.907100
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist(
        compat_b64decode(
            'qjKkCfYK4BiigwYLjOvRDA=='
        )
    )
    expanded_key = bytes_to_intlist(
        compat_b64decode(
            '8CgzuLQRfRQjlRbxATEBZajV3lq6lh/6/Fn6z/u4/vn4Mg='
        )
    )
    result = aes_decrypt(
        data,
        expanded_key
    )
    expect = bytes_to_intlist(
        compat_b64decode(
            't0KIPGAqOa3pRD3wLjxT+w=='
        )
    )
    assert result == expect

# Generated at 2022-06-24 11:26:50.675816
# Unit test for function shift_rows
def test_shift_rows():
    assert(shift_rows(list(range(16))) ==
           [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15])



# Generated at 2022-06-24 11:26:52.452887
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]
    assert rotate([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 1]

# Generated at 2022-06-24 11:27:00.474972
# Unit test for function aes_decrypt
def test_aes_decrypt():
    """
    Unit test for function aes_decrypt
    """
    # The following S-box were generated by using the following code:
    #
    #     import Crypto.Cipher.AES as AES
    #     aes = AES.new(bytes([1 for _ in range(16)]), AES.MODE_ECB)
    #     for i in range(256):
    #         print(aes.encrypt(bytes([i]))[0])

# Generated at 2022-06-24 11:27:09.541803
# Unit test for function aes_decrypt

# Generated at 2022-06-24 11:27:19.213539
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16]
    data_shifted = [0x01, 0x06, 0x11, 0x16, 0x02, 0x07, 0x12, 0x13, 0x03, 0x08, 0x05, 0x14, 0x04, 0x09, 0x10, 0x15]
    shifted = shift_rows(data)
    assert shifted == data_shifted
    return True



# Generated at 2022-06-24 11:27:21.530020
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([0,1,2,3])) == [0,1,2,3]



# Generated at 2022-06-24 11:27:25.850744
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x19, 0xa0, 0x9a, 0xe9, 0x3d, 0xf4, 0xc6, 0xf8, 0xe3, 0xe2, 0x8d, 0x48, 0xbe, 0x2b, 0x2a, 0x08]
    print("Shift rows inv: {}".format(shift_rows_inv(data)))



# Generated at 2022-06-24 11:27:28.763768
# Unit test for function mix_column
def test_mix_column():
    expected = [0x7b, 0x9c, 0xce, 0x23]
    data = [0x12, 0x34, 0x56, 0x78]
    result = mix_column(data, MIX_COLUMN_MATRIX)
    assert(result == expected)



# Generated at 2022-06-24 11:27:35.998872
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # pylint: disable=bad-whitespace
    # pylint: disable=bad-continuation
    key              = [ 0x2b, 0x7e, 0x15, 0x16,
                         0x28, 0xae, 0xd2, 0xa6,
                         0xab, 0xf7, 0x15, 0x88,
                         0x09, 0xcf, 0x4f, 0x3c ]
    cipher           = [ 0x87, 0x4d, 0x61, 0x91,
                         0xb6, 0x20, 0xe3, 0x26,
                         0x1b, 0xef, 0x68, 0x64,
                         0x99, 0x0d, 0xb6, 0xce ]

# Generated at 2022-06-24 11:27:45.673809
# Unit test for function inc
def test_inc():
    assert inc([]) == []
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]
    print('test_inc passed')
        


# Generated at 2022-06-24 11:27:49.516090
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = []
    for column in range(4):
        data += [MIX_COLUMN_MATRIX_INV[column][x] for x in range(4)]
    data_mixed = mix_columns(data)
    assert(data == data_mixed)



# Generated at 2022-06-24 11:27:53.990803
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv([0x19, 0xa0, 0x9a, 0xe9]) == [0xD4, 0x27, 0x11, 0xAE]



# Generated at 2022-06-24 11:28:05.006132
# Unit test for function aes_encrypt
def test_aes_encrypt():
    KEY = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    PLAINTEXT = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]

# Generated at 2022-06-24 11:28:15.756950
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # See: https://en.wikipedia.org/wiki/Block_cipher_mode_of_operation#Counter_.28CTR.29
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'password'
    key_size_bytes = 16

    decrypted_data = aes_decrypt_text(data, password, key_size_bytes)
    assert decrypted_data == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-24 11:28:26.203828
# Unit test for function sub_bytes
def test_sub_bytes():
    data_in = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    data_out = sub_bytes(data_in)
    assert data_out == [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]

# Generated at 2022-06-24 11:28:35.991476
# Unit test for function shift_rows
def test_shift_rows():
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    data_shifted = shift_rows(data)
    assert (data_shifted[0] == 1)
    assert (data_shifted[1] == 5)
    assert (data_shifted[2] == 9)
    assert (data_shifted[3] == 13)
    assert (data_shifted[4] == 2)
    assert (data_shifted[5] == 6)
    assert (data_shifted[6] == 10)
    assert (data_shifted[7] == 14)
    assert (data_shifted[8] == 3)
    assert (data_shifted[9] == 7)

# Generated at 2022-06-24 11:28:41.467463
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x83) == 0xc1
    assert rijndael_mul(0x13, 0x02) == 0x26
    assert rijndael_mul(0x13, 0x01) == 0x13
    assert rijndael_mul(0x0e, 0x09) == 0x2d
    assert rijndael_mul(0x57, 0x13) == 0xfe
    assert rijndael_mul(0x57, 0x01) == 0x57
    assert rijndael_mul(0x0b, 0x0b) == 0x17
    assert rijndael_mul(0x0e, 0x01) == 0x0e
    assert rijndael_mul

# Generated at 2022-06-24 11:28:48.662032
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    test_data = [0, 1, 2, 3,
                 4, 5, 6, 7,
                 8, 9, 10, 11,
                 12, 13, 14, 15]
    expected_result = [0, 1, 2, 3,
                       5, 6, 7, 4,
                       10, 11, 8, 9,
                       15, 12, 13, 14]
    assert shift_rows_inv(test_data) == expected_result



# Generated at 2022-06-24 11:28:59.157139
# Unit test for function aes_decrypt_text

# Generated at 2022-06-24 11:29:02.206621
# Unit test for function shift_rows
def test_shift_rows():
    correct_data = [1, 0, 0, 0,
                    0, 0, 1, 0,
                    0, 1, 0, 0,
                    0, 0, 0, 1]
    assert (correct_data == shift_rows([0, 0, 0, 1,
                                        1, 0, 0, 0,
                                        0, 1, 0, 0,
                                        0, 0, 1, 0]))



# Generated at 2022-06-24 11:29:05.425746
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    password = 'password'
    data = b'Fk5VxsaMcZovcswieVLzpw=='
    plaintext = b'Hello World!'

    assert aes_decrypt_text(data, password, key_size_bytes=16) == plaintext



# Generated at 2022-06-24 11:29:13.261117
# Unit test for function xor

# Generated at 2022-06-24 11:29:24.184168
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_cipher import aes_encrypt

    class TestCounter(object):
        def __init__(self):
            self.x = 0

        def next_value(self):
            self.x += 1
            return [0] * 16

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    counter = TestCounter()
    data = bytes_to_intlist(b'abc')

    assert aes_ctr_decrypt(aes_encrypt(data, key), key, counter) == data
# Unit test: Implicit test of function aes_ctr_decrypt



# Generated at 2022-06-24 11:29:33.124622
# Unit test for function mix_columns
def test_mix_columns():
    assert mix_columns([0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]) == [0x8e, 0x4d, 0xa1, 0xbc,
                                                                                                                              0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]

# Generated at 2022-06-24 11:29:40.461202
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data1 = [0x00, 0x01, 0x02, 0x03]
    data2 = [0x00, 0x01, 0x02, 0x03]
    data3 = [0x01, 0x01, 0x01, 0x01]
    data4 = [0x01, 0x01, 0x01, 0x02]
    data5 = [0x01, 0x01, 0x01, 0x03]
    data6 = [0x01, 0x01, 0x02, 0x03]
    data7 = [0x01, 0x01, 0x01, 0x01]
    data8 = [0x01, 0x01, 0x02, 0x02]
    data9 = [0x01, 0x01, 0x03, 0x03]
   

# Generated at 2022-06-24 11:29:44.104667
# Unit test for function sub_bytes
def test_sub_bytes():
    test_data_bytes = [0x01, 0x00, 0x00, 0x01]
    test_data_str = string.join([chr(x) for x in test_data_bytes], "")
    assert sub_bytes(test_data_bytes) == [0x51, 0x3c, 0xa3, 0x65]
    assert sub_bytes(test_data_str) == [0x51, 0x3c, 0xa3, 0x65]

# Generated at 2022-06-24 11:29:54.644316
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test1 = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    test2 = [0x53, 0xca, 0x1a, 0xae, 0x77, 0x09, 0x94, 0x6a, 0x67, 0xbb, 0x72, 0xf3, 0x6e, 0x3c, 0x91, 0x76]

# Generated at 2022-06-24 11:30:01.629353
# Unit test for function mix_column
def test_mix_column():
    assert mix_column([0xdb, 0x13, 0x53, 0x45], MIX_COLUMN_MATRIX) == [0x8e, 0x4d, 0xa1, 0xbc]
    assert mix_column([0x8e, 0x4d, 0xa1, 0xbc], MIX_COLUMN_MATRIX_INV) == [0xdb, 0x13, 0x53, 0x45]



# Generated at 2022-06-24 11:30:09.479934
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = 'This is a key123'
    key = bytes_to_intlist(key)
    key = key_expansion(key)
    iv = [13, 23, 54, 89, 54, 1, 45, 132]
    test_vector = 'Hello World!123'
    test_vector = bytes_to_intlist(test_vector)
    test_vector = aes_cbc_encrypt(test_vector, key, iv)
    test_output = aes_cbc_decrypt(test_vector, key, iv)
    test_expected = [72, 101, 108, 108, 111, 32, 87, 111, 114, 108, 100, 33, 49, 50, 51]
    assert test_output == test_expected



# Generated at 2022-06-24 11:30:16.873069
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    test_data = [0x19, 0xA0, 0x9A, 0xE9, 0x3D, 0xF4, 0xC6, 0xF8, 0xE3, 0xE2, 0x8D, 0x48, 0xBE, 0x2B, 0x2A, 0x08]
    encrypted_data = sub_bytes(test_data)
    print(list(map(hex, encrypted_data)))
    decrypted_data = sub_bytes_inv(encrypted_data)
    print(list(map(hex, decrypted_data)))
    assert test_data == decrypted_data


#test_sub_bytes_inv()
PI_01 = [x for x in range(0, 4)]
PI_02 = [x for x in range(4, 8)]
PI_

# Generated at 2022-06-24 11:30:26.689050
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    ans = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    if (mix_columns_inv(data) == ans):
        return True
    else:
        return False



# Generated at 2022-06-24 11:30:35.183884
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    assert aes_cbc_encrypt(b'This is a short test', b'YELLOW SUBMARINE', [0] * 16) == bytes_to_intlist(
        compat_b64decode(
            b'gBm3wphtC1FtSWmulWjQbL9OZiDfH5ep5+5CwR1FxEzQ0rg/NxlHvN/ZD0jX3/'
            b'mN/'
        ))


# Generated at 2022-06-24 11:30:45.169054
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    def get_test_vector(test_vector):
        key_raw = test_vector[0]
        iv_raw = test_vector[1]
        input_raw = test_vector[2]
        output_raw = test_vector[3]
        key = bytes_to_intlist(compat_b64decode(key_raw))
        iv = bytes_to_intlist(compat_b64decode(iv_raw))
        input = bytes_to_intlist(compat_b64decode(input_raw))
        output = bytes_to_intlist(compat_b64decode(output_raw))
        return (key, iv, input, output)


# Generated at 2022-06-24 11:30:54.591686
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Example Vector 1
    data = bytes_to_intlist(b'\x6b\xc1\xbe\xe2\x2e\x40\x9f\x96\xe9\x3d\x7e\x11\x73\x93\x17\x2a')
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-24 11:31:03.182124
# Unit test for function inc
def test_inc():
    assert inc([0xff, 0xff, 0xff, 0xff]) == [0x00, 0x00, 0x00, 0x00]
    assert inc([0x01, 0x00, 0x01, 0x01]) == [0x01, 0x00, 0x01, 0x02]
    assert inc([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x01]
    assert inc([0x00, 0x00, 0x00, 0x01]) == [0x00, 0x00, 0x00, 0x02]
    assert inc([0x01, 0x01, 0x01, 0x01]) == [0x01, 0x01, 0x01, 0x02]



# Generated at 2022-06-24 11:31:07.680220
# Unit test for function shift_rows
def test_shift_rows():
    data = range(16)
    # Change data
    data = shift_rows(data)
    expected_data = [0, 4, 8, 12, 1, 2, 3, 7, 5, 6, 10, 11, 9, 13, 14, 15]

    return data == expected_data
print('Shift rows test: ')
print(test_shift_rows())


# Generated at 2022-06-24 11:31:21.060645
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert(mix_columns_inv([]) == [])
    assert(mix_columns_inv([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x00])
    assert(mix_columns_inv([0x05, 0x04, 0x03, 0x02]) == [0x05, 0x04, 0x03, 0x02])
    # Test case from https://en.wikipedia.org/wiki/Rijndael_mix_columns

# Generated at 2022-06-24 11:31:30.497125
# Unit test for function aes_decrypt
def test_aes_decrypt():
    cipher = [0x39, 0x25, 0x84, 0x1d, 0x02, 0xdc, 0x09, 0xfb,
              0xdc, 0x11, 0x85, 0x97, 0x19, 0x6a, 0x0b, 0x32]
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)
    decrypted = aes_decrypt(cipher, expanded_key)