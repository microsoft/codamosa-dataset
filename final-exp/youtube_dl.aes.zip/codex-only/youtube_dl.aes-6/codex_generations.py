

# Generated at 2022-06-24 11:21:33.501880
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = compat_b64decode('JkWbhreQ5bYrYIvtUEtClA==')
    encrypted = aes_encrypt(
        bytes_to_intlist(compat_b64decode('oLxrHhEtZz1A/eOktCw1Nw==')),
        bytes_to_intlist(key)
    )
    assert intlist_to_bytes(encrypted) == compat_b64decode('qdfiOR8Wn7AtU+b6u9iVzg==')



# Generated at 2022-06-24 11:21:41.910106
# Unit test for function mix_columns
def test_mix_columns():
    test_data0 = [57, 49, 41, 33, 25, 17, 9, 1, 58, 50, 42, 34, 26, 18, 10, 2, 59, 51, 43, 35, 27, 19, 11, 3, 60, 52, 44, 36]
    test_data1 = [113, 105, 97, 89, 81, 73, 65, 57, 49, 41, 33, 25, 17, 9, 1, 58, 50, 42, 34, 26, 18, 10, 2, 59, 51, 43, 35]
    test_data0_expected = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28]
    test_data1_expected

# Generated at 2022-06-24 11:21:50.934278
# Unit test for function key_expansion
def test_key_expansion():
    def _test_key_expansion_single(key, expected_expanded_keys):
        expanded_key = key_expansion(key)
        assert len(expanded_key) == len(expected_expanded_keys)
        assert expanded_key == expected_expanded_keys


# Generated at 2022-06-24 11:21:54.805050
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data_origin = [0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]
    data_after = shift_rows_inv(shift_rows(data_origin))
    for i in range(len(data_origin)):
        assert data_origin[i] == data_after[i]



# Generated at 2022-06-24 11:22:01.642606
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    print("Test shift_rows_inv(data):")
    data = [i for i in range(16)]
    # print("data: ", data)
    data_shifted = shift_rows_inv(data)
    # print("data_shifted: ", data_shifted)
    data_restored = shift_rows(data_shifted)
    # print("data_restored: ", data_restored)
    print("data == data_restored ? ", data == data_restored)
    # assert data == data_restored



# Generated at 2022-06-24 11:22:06.805976
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    decrypted_data = aes_decrypt_text('Rpd+jNF9X2AQLwp1MTvI2Q==',
                                      '4iF4hLRjKczkCp8a9MoHXQ==',
                                      16)
    assert decrypted_data == 'test'
    #print decrypted_data



# Generated at 2022-06-24 11:22:12.231735
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print("[+] Testing rijndael_mul()")
    a = 4
    b = 4
    c = rijndael_mul(a,b)
    print("[+] Function OUTPUT: ",c)
    print("[+] Function RESULT: PASS")


# Generated at 2022-06-24 11:22:19.426078
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    test_data = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c][::-1]
    test_result = [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76][::-1]

    if sub_bytes_inv(test_data) == test_result:
        return True
    else:
        return False


# Generated at 2022-06-24 11:22:29.953346
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-24 11:22:34.939758
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    shifted = shift_rows_inv(data)
    assert(shifted == [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15])



# Generated at 2022-06-24 11:22:39.982005
# Unit test for function xor
def test_xor():
    assert xor([0, 0, 0, 0], [0, 0, 0, 0]) == [0, 0, 0, 0]
    assert xor([1, 1, 1, 1], [2, 2, 2, 2]) == [3, 3, 3, 3]
    assert xor([255, 255, 255, 255], [254, 254, 254, 254]) == [1, 1, 1, 1]
    print("function xor is correct")
#test_xor()



# Generated at 2022-06-24 11:22:43.808809
# Unit test for function aes_decrypt_text

# Generated at 2022-06-24 11:22:53.701391
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """
    Test for function aes_cbc_decrypt
    """
    # Test case 1 taken from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf

# Generated at 2022-06-24 11:22:58.579540
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # key and iv as specified in the article
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

    # cipher as specified in the article

# Generated at 2022-06-24 11:23:08.243312
# Unit test for function mix_column
def test_mix_column():
    #https://en.wikipedia.org/wiki/Rijndael_mix_columns
    assert mix_column([0,1,2,3],MIX_COLUMN_MATRIX)==[0,2,4,6]
    assert mix_column([0,2,4,6],MIX_COLUMN_MATRIX_INV)==[0,1,2,3]
    assert mix_column([0xdb,0x13,0x53,0x45],MIX_COLUMN_MATRIX)==[0x8e,0x4d,0xa1,0xbc]

# Generated at 2022-06-24 11:23:12.935238
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xDB, 0x13, 0x53, 0x45,
            0xF2, 0x0A, 0x22, 0x5C,
            0x01, 0x01, 0x01, 0x01,
            0x01, 0x01, 0x01, 0x01]
    expected = [0x8E, 0x4D, 0xA1, 0xBC,
                0x9F, 0xDC, 0x58, 0x9D,
                0x01, 0x01, 0x01, 0x01,
                0x01, 0x01, 0x01, 0x01]
    actual = mix_columns(data)
    if expected != actual:
        print('test_mix_columns expected: %s' % expected)

# Generated at 2022-06-24 11:23:16.359061
# Unit test for function sub_bytes
def test_sub_bytes():
    print("Testing sub_bytes: ", end="")
    data = [0x6A, 0x20, 0xC4, 0x69]
    assert (sub_bytes(data) == [0x0D, 0x8F, 0xA7, 0xC2])
    data = [0xCB, 0xF4, 0xD8, 0x7B]
    assert (sub_bytes(data) == [0xA1, 0x90, 0x39, 0xF1])
    print("Passed")


# Main
if __name__ == '__main__':
    test_sub_bytes()

# Generated at 2022-06-24 11:23:25.900784
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-24 11:23:32.608303
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]

# Generated at 2022-06-24 11:23:38.132903
# Unit test for function mix_column
def test_mix_column():
    assert mix_column([0xD4, 0xBF, 0x5D, 0x30], MIX_COLUMN_MATRIX) == [0x04, 0x66, 0x81, 0xE5]
    assert mix_column([0x04, 0x66, 0x81, 0xE5], MIX_COLUMN_MATRIX) == [0xE5, 0x9F, 0xD3, 0x19]
    assert mix_column([0xE5, 0x9F, 0xD3, 0x19], MIX_COLUMN_MATRIX) == [0xFD, 0x4C, 0xE2, 0x1E]

# Generated at 2022-06-24 11:23:42.741556
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x3b, 0x66, 0x48, 0xf1, 0x43, 0x9e, 0x0d, 0x2a, 0xf4, 0xdc, 0x7f, 0x5b, 0xd0, 0x7b, 0xe4, 0x0b]) == [0x1a, 0xcb, 0x7e, 0x5a, 0x3e, 0x1f, 0x71, 0x62, 0xdb, 0x7d, 0x81, 0x18, 0x0d, 0xe9, 0x2b, 0x3a]



# Generated at 2022-06-24 11:23:50.502641
# Unit test for function mix_column
def test_mix_column():
    result = mix_column([0xdb, 0xf2, 0xd4, 0x30], MIX_COLUMN_MATRIX)
    print(result)
    assert result == [0x8e, 0xe3, 0x1e, 0x26]
    result = mix_column([0x8e, 0xe3, 0x1e, 0x26], MIX_COLUMN_MATRIX_INV)
    print(result)
    assert result == [0xdb, 0xf2, 0xd4, 0x30]


# Generated at 2022-06-24 11:24:02.295150
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .random_generator import RandomGenerator
    from .utils import str_to_bytes
    from .compat import compat_ord

    def bytes_to_intlist(data):
        return [compat_ord(x) for x in data]

    # Test vector taken from http://tools.ietf.org/html/rfc3686#section-6
    nonce = 'UNIVOIP'
    counter = Counter(bytes_to_intlist(nonce))
    key = bytes_to_intlist('36f18357be4dbd77f050515c73fcf9f2')
    cipher = bytes_to_intlist('e46218c0a53cbeca695ae45faa8952aa' +
                              '0e311bde9d4e01726d3184c34451')

   

# Generated at 2022-06-24 11:24:06.699252
# Unit test for function mix_columns
def test_mix_columns():
    print("Test mix_columns")
    for i in range(4):
        data = bytearray(4)
        data[i] = 0x0E
        print("Data = " + str(list(data)))
        data = mix_columns(data)
        print("Data mixed = " + str(list(data)))
        print("Data unmixed = " + str(list(mix_columns(data, MIX_COLUMN_MATRIX_INV))))


# Generated at 2022-06-24 11:24:14.241332
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    test_vectors = [
        ['L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==',
         'YELLOW SUBMARINE',
         '0e.io.mozilla',
         'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '],
    ]
    for iv, key, counter, plain in test_vectors:
        iv = compat_b64decode(iv)
        key = bytes_to_intlist(bytes(key, 'utf-8'))
        counter = int(counter)
        plain = bytes_to_intlist(bytes(plain, 'utf-8'))


# Generated at 2022-06-24 11:24:19.147922
# Unit test for function shift_rows
def test_shift_rows():
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    result = [1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15, 4, 8, 12, 16]
    assert shift_rows(data) == result



# Generated at 2022-06-24 11:24:28.212931
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test_data = [0x6E, 0xF5, 0xD6, 0xD6,
                 0x2, 0x76, 0x60, 0xE3,
                 0xDD, 0x88, 0x82, 0x2E,
                 0xB, 0xB3, 0x40, 0x4D,]
    expected_result = [0X8E, 0x4D, 0xA1, 0xBC,
                       0X9B, 0x1F, 0x5B, 0x80,
                       0XD6, 0x7D, 0xC4, 0x3F,
                       0X19, 0xE1, 0xA0, 0x60,]
    assert mix_columns_inv(test_data) == expected_result

# Generated at 2022-06-24 11:24:36.915639
# Unit test for function sub_bytes
def test_sub_bytes():
    result = sub_bytes([0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf])
    expected_result = [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]
    assert result == expected_result
    print("sub_bytes function passed the unit test")



# Generated at 2022-06-24 11:24:44.243376
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xf0, 0xe1, 0xd2, 0xc3, 0x84, 0x95, 0xa6, 0xb7, 0x48, 0x59, 0x6a, 0x7b, 0x0c, 0x1d, 0x2e, 0x3f]
    data_mixed = mix_columns_inv(data)
    print(data_mixed)
    assert data_mixed[0] == 0xbe
    assert data_mixed[1] == 0x39
    assert data_mixed[2] == 0x4a
    assert data_mixed[3] == 0x4c
    assert data_mixed[4] == 0x58
    assert data_mixed[5] == 0xcf
    assert data_mixed[6] == 0xd0

# Generated at 2022-06-24 11:24:51.137763
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key = [0x01, 0x23, 0x45, 0x67]
    rcon_iteration = 0
    out = key_schedule_core(key, rcon_iteration)
    expected = [0x2b, 0x7e, 0x15, 0x16]
    assert out == expected

    key = [0x2b, 0x7e, 0x15, 0x16]
    rcon_iteration = 1
    out = key_schedule_core(key, rcon_iteration)
    expected = [0xa8, 0x3c, 0x19, 0xd4]
    assert out == expected

    key = [0xa8, 0x3c, 0x19, 0xd4]
    rcon_iteration = 2

# Generated at 2022-06-24 11:24:56.512241
# Unit test for function xor
def test_xor():
    assert xor([0x02, 0x03, 0x01, 0x01], [0xe, 0xb, 0xd, 0x9]) == [0xec, 0xb7, 0xdc, 0x98]
    print("Test xor success")



# Generated at 2022-06-24 11:25:01.206789
# Unit test for function shift_rows
def test_shift_rows():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    expected = [0, 1, 2, 3, 5, 6, 7, 4, 10, 11, 8, 9, 15, 12, 13, 14]
    assert shift_rows(data) == expected

test_shift_rows()



# Generated at 2022-06-24 11:25:11.385777
# Unit test for function mix_column
def test_mix_column():
    data = [0xDB, 0x13, 0x53, 0x45]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    # print(data_mixed)
    # print(data_mixed[2], "Should be 95")
    assert data_mixed[2] == 95



# Generated at 2022-06-24 11:25:21.804031
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    """
    @returns {bool}  True if test passed
    """
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * 16)
    data = bytes_to_intlist(b'We dont need no education')
    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-24 11:25:33.900710
# Unit test for function aes_encrypt
def test_aes_encrypt():
  data = bytes_to_intlist(b'1234567890abcdef')
  expanded_key = bytes_to_intlist(b'000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F')
  assert intlist_to_bytes(aes_encrypt(data, expanded_key)) == (b'\x69\xc4\xe0\xd8\x6a\x7b\x04\x30\xd8\xcd\xb7\x80\x70\xb4\xc5\x5a')

if __name__ == "__main__":
  test_aes_encrypt()
  

# Generated at 2022-06-24 11:25:38.853072
# Unit test for function inc
def test_inc():
    output = []
    for i in range(256):
        output.append(inc([0] * 16)[15])

    for i in range(16):
        print(output[i * 16:(i + 1) * 16])
    print(output == list(range(1, 256)) + [0])



# Generated at 2022-06-24 11:25:48.833860
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0, 0, 0, 1]
    rcon_iteration = 1
    result = key_schedule_core(data, rcon_iteration)
    assert result == [0, 1, 0, 0]
    data = [1, 1, 1, 1]
    rcon_iteration = 2
    result = key_schedule_core(data, rcon_iteration)
    assert result == [0, 1, 1, 0]
    data = [0, 1, 0, 1]
    rcon_iteration = 3
    result = key_schedule_core(data, rcon_iteration)
    assert result == [0, 0, 0, 1]



# Generated at 2022-06-24 11:25:56.507270
# Unit test for function aes_decrypt

# Generated at 2022-06-24 11:26:01.277805
# Unit test for function mix_columns
def test_mix_columns():
    HEX_DATA = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    HEX_DATA_MIXED = [0x8E, 0x4D, 0xA1, 0xBC, 0x9F, 0xDC, 0x58, 0x9D, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    print(",".join(map(hex, mix_columns(HEX_DATA, MIX_COLUMN_MATRIX))))

# Generated at 2022-06-24 11:26:05.449219
# Unit test for function mix_columns
def test_mix_columns():
    data = [0x02, 0x03, 0x01, 0x01,
            0x01, 0x02, 0x03, 0x01,
            0x01, 0x01, 0x02, 0x03,
            0x03, 0x01, 0x01, 0x02]
    ans = [0x04, 0x01, 0x02, 0x03,
           0x03, 0x04, 0x01, 0x02,
           0x02, 0x03, 0x04, 0x01,
           0x01, 0x02, 0x03, 0x04]
    print(mix_columns(data) == ans)



# Generated at 2022-06-24 11:26:11.459876
# Unit test for function mix_column
def test_mix_column():
    data = [0xDB, 0x13, 0x53, 0x45]
    expected = [0x8E, 0x4D, 0xA1, 0xBC]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)

    if(data_mixed != expected):
        raise ValueError("mix_column failed")

test_mix_column()


# Generated at 2022-06-24 11:26:18.163937
# Unit test for function key_expansion
def test_key_expansion():
    def test(expected, data):
        result = key_expansion(data)
        assert result == expected, 'Expected %r, got %r' % (expected, result)

# Generated at 2022-06-24 11:26:26.234222
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-24 11:26:35.091913
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert mix_columns(data, MIX_COLUMN_MATRIX) == result
    assert mix_columns(result, MIX_COLUMN_MATRIX_INV) == data

test_mix_column

# Generated at 2022-06-24 11:26:36.970759
# Unit test for function rotate
def test_rotate():
    data = [1, 2, 3, 4]
    assert [2, 3, 4, 1] == rotate(data)



# Generated at 2022-06-24 11:26:48.824737
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist(b"\x49\x76\x20\x6e\x20\x74\x72\x75\x65\x64\x20\x6c\x69\x66\x65\x20")
    expanded_key = key_expansion(bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'))
    res = aes_decrypt(data, expanded_key)

# Generated at 2022-06-24 11:26:49.846884
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    data = [0] * 16
    assert sub_bytes_inv(data) == data



# Generated at 2022-06-24 11:26:55.451349
# Unit test for function sub_bytes
def test_sub_bytes():
    input_d = [0xa0, 0x10, 0x9a, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    output_d = [0x4f, 0x4e, 0x4d, 0x38, 0x38, 0x38, 0x38, 0x38, 0x38, 0x38, 0x38, 0x38]
    result = sub_bytes(input_d)
    if result == output_d:
        print("Unit test passed!")



# Generated at 2022-06-24 11:27:02.638486
# Unit test for function sub_bytes
def test_sub_bytes():
    a = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    assert sub_bytes(a) == [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,]


# Generated at 2022-06-24 11:27:08.124366
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist("10a58869d74be5a374cf867cfb473859")
    expanded_key = bytes_to_intlist("603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4")
    assert aes_encrypt(data, expanded_key) == bytes_to_intlist("f3eed1bdb5d2a03c064b5a7e3db181f8")



# Generated at 2022-06-24 11:27:16.467311
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert mix_columns_inv([0x8e, 0xca, 0x9e, 0x00, 0x88, 0x0b, 0x98, 0x00, 0x98, 0x00, 0x05, 0x00, 0x4d, 0x54, 0xfb, 0x00]) == [0x8e, 0xca, 0x9e, 0x00, 0x88, 0x0b, 0x98, 0x00, 0x98, 0x00, 0x05, 0x00, 0x4d, 0x54, 0xfb, 0x00]
test_mix_columns_inv()



# Generated at 2022-06-24 11:27:18.665745
# Unit test for function sub_bytes
def test_sub_bytes():
    for i in range(16):
        assert(SBOX[SBOX_INV[i]] == i)



# Generated at 2022-06-24 11:27:22.950259
# Unit test for function xor
def test_xor():
    expected_res = [0, 0, 0, 0]
    data1 = [1, 0, 0, 1]
    data2 = [1, 0, 0, 1]
    res = xor(data1, data2)
    assert res == expected_res

# Generated at 2022-06-24 11:27:29.590461
# Unit test for function sub_bytes
def test_sub_bytes():
    data0 = [0x00, 0x10, 0x20, 0x30]
    data1 = [0x0F, 0x1F, 0x2F, 0x3F]
    data2 = [0xFF, 0xEF, 0xDF, 0xCF]
    data3 = [0xFF, 0x00, 0x0F, 0xF0]
    data4 = [0x0F, 0x10, 0xF0, 0xFF]
    assert sub_bytes(data0) == [0x63, 0xCA, 0xB7, 0x04]
    assert sub_bytes(data1) == [0xA6, 0xD2, 0xF5, 0x4F]

# Generated at 2022-06-24 11:27:39.598403
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    key = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]

# Generated at 2022-06-24 11:27:50.361929
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    expanded_key = key_expansion(key)

# Generated at 2022-06-24 11:28:01.558666
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist(compat_b64decode(b'ce5O5f/um5mi5QNk8ywg/g=='))
    key = bytes_to_intlist(compat_b64decode(b'yAaA0qhxmLE0zGpS1F9Xvg=='))
    iv = bytes_to_intlist(compat_b64decode(b'UdTkjrd9Xgcd7VuE6Ji+Hg=='))
    enc = aes_cbc_decrypt(data, key, iv)
    enc = intlist_to_bytes(enc)
    print(enc)
    print(b'{"codec": "aac", "mime": "audio/mp4a-latm"}')

#

# Generated at 2022-06-24 11:28:08.925641
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 1]) == [0, 0, 0, 2]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 1, 0]) == [0, 0, 1, 1]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]


# Generated at 2022-06-24 11:28:18.060871
# Unit test for function key_expansion
def test_key_expansion():
    import binascii
    data = bytes_to_intlist(binascii.unhexlify('2b7e151628aed2a6abf7158809cf4f3c'))
    data = key_expansion(data)
    assert binascii.hexlify(intlist_to_bytes(data)) == b'2b7e151628aed2a6abf7158809cf4f3c776140c20d14d8bd0bbe46c1e17a9d9f2'
# Test key_expansion
test_key_expansion()



# Generated at 2022-06-24 11:28:28.181663
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00'*16)

    cleartext = b'Play that funky music'
    padded_cleartext = b'Play that funky music\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b'
    cleartext_intlist = bytes_to_intlist(padded_cleartext)


# Generated at 2022-06-24 11:28:36.994068
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist("2b7e151628aed2a6abf7158809cf4f3c")

# Generated at 2022-06-24 11:28:44.156226
# Unit test for function xor
def test_xor():
    val1 = [128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    val2 = [4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    assert(xor(val1,val2) == [132, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])

# Generated at 2022-06-24 11:28:54.190428
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    iv = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]

# Generated at 2022-06-24 11:29:00.917329
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # From http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-24 11:29:03.742371
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x83) == 0xc1

test_rijndael_mul()


# Generated at 2022-06-24 11:29:11.801700
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytes_to_intlist(
        compat_b64decode(
            "4a4ec7c46b10c427d2c4965e6eb59cc6b5d6b5c6af1b6f5f73e3d3db60865572"
            "6c4d2ef9b01c4f4ee4d4bed25e6e5f6aa5f6eb75e6e5f6aa5f6eb7"
        )
    )
    key = [0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf, 0x0]

# Generated at 2022-06-24 11:29:18.442810
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    result = aes_decrypt_text('Q2V7lZRiEuVdbBiiyauPJyhtFDmXm1Fjo8ro+5efh0ZlMBgBd5l+Hw==', 'My32BitPassword', 24)
    assert result == b'Hello World\x80\x80\x80\x80\x80\x80\x80\x80\x80\x80\x80'
    print('Test function "test_aes_decrypt_text" passed')



# Generated at 2022-06-24 11:29:26.956254
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data1 = [0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0x07, 0xa8, 0x8d, 0xa2, 0x34]
    data1_shifted = shift_rows_inv(data1)

    data2 = [0x32, 0x88, 0x43, 0x5a, 0xf6, 0x30, 0xa8, 0x8d, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]

    if data2 == data1_shifted:
        print("Passed")
    else:
        print("Failed")



# Generated at 2022-06-24 11:29:36.441015
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .mocks import mock_counter
    key = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]

# Generated at 2022-06-24 11:29:39.127458
# Unit test for function xor
def test_xor():
    assert (xor([1, 2, 3], [4, 5, 6]) == [5, 7, 5])



# Generated at 2022-06-24 11:29:48.906991
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    encrypted = aes_cbc_encrypt([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])
    decrypted = aes_cbc_decrypt(encrypted, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])

# Generated at 2022-06-24 11:29:55.981982
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x1f, 0x1e, 0x1d, 0x1c, 0x1b, 0x1a, 0x19, 0x18, 0x17, 0x16, 0x15, 0x14, 0x13, 0x12, 0x11, 0x10]
    data_shifted = [0x1c, 0x1d, 0x1e, 0x1f, 0x18, 0x19, 0x1a, 0x1b, 0x14, 0x15, 0x16, 0x17, 0x10, 0x11, 0x12, 0x13]
    assert shift_rows_inv(data) == data_shifted


ROUNDS_AES_128 = 10
ROUNDS_AES_192 = 12
ROUNDS_AES_

# Generated at 2022-06-24 11:30:05.448467
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    encrypted_text = "V9XlL0YARV4tvEtCZ7V/AqjmBgVq3BeM0Of1iHXA1ZKTW+0kQw55hfwHm+zR6R5g"
    password = "100100100100100100100100100100100100100100100100100100100100100"
    key_size_bytes = 32
    plaintext = aes_decrypt_text(encrypted_text, password, key_size_bytes)
    assert plaintext == "Break me if you can!"



# Generated at 2022-06-24 11:30:08.555465
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert(rijndael_mul(0x57, 0x83) == 0xc1)
    print("Unit test for function rijndael_mul is successful")
    
test_rijndael_mul()


# Generated at 2022-06-24 11:30:16.225780
# Unit test for function aes_decrypt
def test_aes_decrypt():
    test_key = intlist_to_bytes(
        [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C],
        False)
    test_data = intlist_to_bytes(
        [0x3A, 0xD7, 0x7B, 0xB4, 0x0D, 0x7A, 0x36, 0x60, 0xA8, 0x9E, 0xCA, 0xF3, 0x24, 0x66, 0xEF, 0x97],
        False)

# Generated at 2022-06-24 11:30:22.092759
# Unit test for function shift_rows
def test_shift_rows():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    expected_result = [0, 1, 2, 3, 5, 6, 7, 4, 10, 11, 8, 9, 15, 12, 13, 14]
    data_after_shift = shift_rows(data)
    assert expected_result == data_after_shift
#test_shift_rows()



# Generated at 2022-06-24 11:30:29.697507
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a_key, b_key in itertools.product(range(0x100), range(0x100)):
        a = rijndael_mul(a_key, b_key)
        b = rijndael_mul(b_key, a_key)
        if(a != b):
            print("Associative property doesn't hold")
        if(rijndael_mul(a_key, b_key) != rijndael_mul(a_key, b_key)):
            print("Commutative property doesn't hold")



# Generated at 2022-06-24 11:30:33.719303
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    data_mixed_inv = mix_column(data_mixed, MIX_COLUMN_MATRIX_INV)
    assert(data == data_mixed_inv)



# Generated at 2022-06-24 11:30:42.439422
# Unit test for function aes_encrypt
def test_aes_encrypt():
    cleartext = [0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0x07, 0xa8, 0x8d, 0xa2, 0x34]
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-24 11:30:48.849434
# Unit test for function xor

# Generated at 2022-06-24 11:30:57.426724
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key1 = [0x2B, 0x7E, 0x15, 0x16]
    answer1 = [0xA0, 0xFA, 0xFE, 0x17]
    result1 = key_schedule_core(key1, 1)

    key2 = [0xA8, 0xF7, 0x89, 0x7C]
    answer2 = [0x84, 0x7B, 0x8A, 0x7D]
    result2 = key_schedule_core(key2, 2)

    key3 = [0x35, 0xE1, 0xF7, 0xBA]
    answer3 = [0x2E, 0x5A, 0xA5, 0x5A]
    result3 = key_schedule_core(key3, 3)

   

# Generated at 2022-06-24 11:31:03.525555
# Unit test for function shift_rows
def test_shift_rows():
    data_test = [1, 2, 3, 4,
                 5, 6, 7, 8,
                 9, 10, 11, 12,
                 13, 14, 15, 16]
    data_expected = [1, 2, 3, 4,
                     6, 7, 8, 5,
                     11, 12, 9, 10,
                     16, 13, 14, 15]

    data_shifted = shift_rows(data_test)

    assert data_shifted == data_expected



# Generated at 2022-06-24 11:31:12.801608
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-24 11:31:23.659211
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    print('Function mix_columns_inv test')
    input_ = [0x13, 0x06, 0x07, 0x05, 0x02, 0x06, 0x07, 0x07, 0x16, 0x02, 0x0b, 0x04, 0x0d, 0x0f, 0x06, 0x05]
    # Input
    print('Input data')
    for i in range(4):
        for j in range(4):
            print('%02X' % input_[i * 4 + j], end=' ')
        print()
    # Output
    output = mix_columns_inv(input_)
    print('Output data')

# Generated at 2022-06-24 11:31:25.704526
# Unit test for function xor
def test_xor():
    a = [1, 2]
    b = [3, 4]
    res = xor(a, b)
    assert(res[0] == 2)
    assert(res[1] == 6)

