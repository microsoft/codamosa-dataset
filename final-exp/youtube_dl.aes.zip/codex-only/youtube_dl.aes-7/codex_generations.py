

# Generated at 2022-06-24 11:21:32.336360
# Unit test for function mix_columns
def test_mix_columns():
    # AES example from http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf (page 12)
    data = [0xD4, 0xE0, 0xB8, 0x1E,
            0xBF, 0xB4, 0x41, 0x27,
            0x5D, 0x52, 0x11, 0x98,
            0x30, 0xAE, 0xF1, 0xE5]

# Generated at 2022-06-24 11:21:37.611477
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    for plain in range(256):
        for key in range(256):
            plain_column = [plain, plain, plain, plain]
            encrypted_column = mix_columns(plain_column)
            decrypted_column = mix_columns_inv(encrypted_column)
            if decrypted_column != plain_column:
                print("Failed on plain: " + str(plain) + " key: " + str(key))



# Generated at 2022-06-24 11:21:39.231672
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3,4]) == [2,3,4,1]


# Generated at 2022-06-24 11:21:48.953431
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # aes cbc encrypt: two blocks
    data = bytes_to_intlist(compat_b64decode('QUJDREVGRw=='))
    key = bytes_to_intlist(compat_b64decode('ZWxkZS0zZm9yZWpvbg=='))
    iv = bytes_to_intlist(compat_b64decode('Zm9yZWpvbm5hcHB5'))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('Jt9e9tSVPfyzq/7s/sDi+w==')

    # aes cbc encrypt: two blocks with padding
    data = bytes_to_intlist

# Generated at 2022-06-24 11:21:54.657214
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert mix_columns_inv([0xdb, 0xe7, 0x86, 0x8b, 0x2b, 0x73, 0x37, 0xda, 0x36, 0x98, 0x21, 0x42, 0x2f, 0x71, 0x9b, 0xdc]) == [0xdb, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]

test_mix_columns_inv()

 

# Generated at 2022-06-24 11:22:01.905090
# Unit test for function shift_rows
def test_shift_rows():
    data_test = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    shift_rows_test = [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
    data_shifted = shift_rows(data_test)
    for i in range(16):
        if(data_shifted[i] != shift_rows_test[i]):
            return False
    return True



# Generated at 2022-06-24 11:22:07.296807
# Unit test for function mix_column
def test_mix_column():
    original = [0xdb, 0x13, 0x53, 0x45]
    mixed = mix_column(original, MIX_COLUMN_MATRIX)
    correct = [0x8e, 0x4d, 0xa1, 0xbc]
    assert mixed == correct
    print('Unit test for function mix_column passed!')
test_mix_column()


# Generated at 2022-06-24 11:22:15.950415
# Unit test for function key_schedule_core

# Generated at 2022-06-24 11:22:20.621244
# Unit test for function mix_column
def test_mix_column():
    sample_data = [0xdb, 0x13, 0x53, 0x45]
    expected = [0x8e, 0x4d, 0xa1, 0xbc]
    actual = mix_column(sample_data, MIX_COLUMN_MATRIX)
    assert expected == actual, "mix_column failed"
    print("mix_column succeeded")



# Generated at 2022-06-24 11:22:31.035529
# Unit test for function key_expansion
def test_key_expansion():
    data = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x3a\x3b\x3c\x3d\x3e\x3f'

# Generated at 2022-06-24 11:22:35.500919
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert shift_rows_inv([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]) == [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]

test_shift_rows_inv()



# Generated at 2022-06-24 11:22:39.334898
# Unit test for function shift_rows
def test_shift_rows():
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    assert [5, 2, 3, 4, 9, 6, 7, 8, 13, 10, 11, 12, 1, 14, 15, 16] == shift_rows(data)
    print('Test passed!')
    
test_shift_rows()
# why using & 0b11?

# To reduce the time of xor, we can use numpy ndarray

# Generated at 2022-06-24 11:22:43.399061
# Unit test for function mix_columns
def test_mix_columns():
    assert mix_columns([1, 0, 0, 0]) == [1, 0, 0, 0]
    assert mix_columns([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert mix_columns([1, 0xE, 0xB, 0xD]) == [1, 0xE, 0xB, 0xD]
    assert mix_columns([0xDB, 0x13, 0x53, 0x45]) == [0x8E, 0x4D, 0xA1, 0xBC]



# Generated at 2022-06-24 11:22:47.907978
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3,4]) == [2,3,4,1]
    assert rotate([2,3,4,1]) == [3,4,1,2]


# Generated at 2022-06-24 11:22:50.611833
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key = [0x2b, 0x7e, 0x15, 0x16]
    result = key_schedule_core(key, 1)
    assert(result == [0xA0, 0xFA, 0xFE, 0x17])
    
# run the test if the file is executed standalone
if __name__ == "__main__":
    test_key_schedule_core()


# Generated at 2022-06-24 11:22:55.061350
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """
    assert aes_cbc_decrypt(aes_cbc_encrypt(data, key, iv), key, iv) == data
    """
    data = list(range(200))
    key = list(range(32))
    iv = list(range(16))
    assert aes_cbc_decrypt(aes_cbc_encrypt(data, key, iv), key, iv) == data

# Generated at 2022-06-24 11:23:02.910315
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    data_shifted = shift_rows_inv(data)
    print(data)
    print(data_shifted)
    data_shifted_inv = shift_rows_inv(data_shifted)
    print(data_shifted_inv)
    assert data == data_shifted_inv



# Generated at 2022-06-24 11:23:10.693218
# Unit test for function aes_encrypt
def test_aes_encrypt():
    test_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    test_data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]

    expanded_key = key_expansion(test_key)
    cipher = aes_encrypt(test_data, expanded_key)


# Generated at 2022-06-24 11:23:17.761867
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    clr_data = bytes_to_intlist("L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==")
    key = bytes_to_intlist("YELLOW SUBMARINE")
    iv = bytes_to_intlist("\x00" * 16)

    cbc_encrypted_data = aes_cbc_encrypt(clr_data, key, iv)
    decrypted_data = aes_cbc_decrypt(cbc_encrypted_data, key, iv)
    assert decrypted_data == clr_data

# ========================== CBC ==========================



# Generated at 2022-06-24 11:23:28.556449
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test function aes_decrypt_text

    @see http://tools.ietf.org/html/rfc3686#section-9
    """
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    nonce = [0x00, 0x00, 0x00, 0x30, 0x00, 0x00, 0x00, 0x00]

# Generated at 2022-06-24 11:23:35.981228
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    text = 'Um9sbGluJyBpbiBteSA1LjAKV2l0aCBteSByYWctdG9wIGRvd24gc28gbXkgaGFpciBjYW4gYmxvdwpUaGUgZ2lybGllcyBvbiBzdGFuZGJ5IHdhdmluZyBqdXN0IHRvIHNheSBoaQpEaWQgeW91IHN0b3A/IE5vLCBJIGp1c3QgZHJvdmUgYnkK'
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16


# Generated at 2022-06-24 11:23:42.423214
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    data = sub_bytes_inv(b'\x31\x3b\x6c\xb6\x15\xca\xaa\x6d\x49\x4b\x20\x4c\x9d\x97\xfd\x48')
    result = b'\x32\x43\xF6\xA8\x88\x5A\x30\x8D\x31\x31\x98\xA2\xE0\x37\x07\x34'
    assert result == bytes(data)



# Generated at 2022-06-24 11:23:46.930168
# Unit test for function inc
def test_inc():
    d = [0, 0, 0, 0]
    assert inc(d) == [0, 0, 0, 1]
    d = [0, 0, 0, 1]
    assert inc(d) == [0, 0, 1, 0]
    d = [0, 0, 0, 255]
    assert inc(d) == [0, 0, 1, 0]
    d = [0, 0, 255, 255]
    assert inc(d) == [0, 1, 0, 0]
    d = [0, 255, 255, 255]
    assert inc(d) == [1, 0, 0, 0]


test_inc()


# Generated at 2022-06-24 11:23:58.487163
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0xab, 0xab, 0x4d, 0x0e]
    data = mix_columns_inv(data)
    answer = [0x8e, 0x4d, 0xa1, 0xbc,
              0x9f, 0xdc, 0x58, 0x9d,
              0x01, 0x01, 0x01, 0x01,
              0xab, 0xab, 0xab, 0xab]
    assert data == answer


test_mix_columns_inv()

# Generated at 2022-06-24 11:24:06.433428
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-24 11:24:18.116961
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('wKxJtFRs+tnlHnurM+RB1A=='))
    expected_key = bytes_to_intlist(compat_b64decode('wKxJtFRs+tnlHnurM+RB1AQQRgBFw0+b5rAc0rV6jK9X/NjZO02scdNl4N4zq3h'))
    expanded_key = key_expansion(key)
    assert expanded_key == expected_key

    key = bytes_to_intlist(compat_b64decode('o9eI+nEEQuB05KcyBkhzGA=='))

# Generated at 2022-06-24 11:24:25.691989
# Unit test for function aes_encrypt
def test_aes_encrypt():
    """
    test_aes_encrypt: test aes_encrypt function
    """
    # print("\nTest aes_encrypt function")
    data = [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    key = [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    expanded_key = key_expansion(key)
    res = aes_encrypt(data, expanded_key)

# Generated at 2022-06-24 11:24:34.992014
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0x01, 0x01, 0x01, 0x01]
    assert mix_columns_inv(data) == [0x8e, 0x4d, 0xa1, 0xbc,
                                     0x9f, 0xdc, 0x58, 0x9d,
                                     0x01, 0x01, 0x01, 0x01,
                                     0x01, 0x01, 0x01, 0x01]



# Generated at 2022-06-24 11:24:41.730063
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # note that the function under test may not be fully compatible with the official JWPlayer version
    # (the official version may use a different encryption method)
    key_size_bytes = 16
    data = b'-VHc5N4Ez68cT-B-dVhdqQ'
    password = b'secret'
    assert aes_decrypt_text(data, password, key_size_bytes) == b'{"sources":[]}'



# Generated at 2022-06-24 11:24:47.643932
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x53, 0xca, 0x7d, 0xa2, 0x94, 0x9e, 0xd8, 0x56, 0xf5, 0x6e, 0x67, 0x58, 0xcb, 0x21, 0x14, 0x4b]) == \
           [0xd5, 0x5a, 0x3d, 0x0b, 0x2c, 0x6b, 0x1c, 0xc0, 0x97, 0x3f, 0x45, 0x2d, 0x80, 0x1d, 0x8d, 0xaa]



# Generated at 2022-06-24 11:24:49.231401
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]
    result = mix_column(data, MIX_COLUMN_MATRIX)
    assert(result == [0x8e, 0x4d, 0xa1, 0xbc])



# Generated at 2022-06-24 11:24:55.971180
# Unit test for function mix_column
def test_mix_column():
    data = [1, 2, 3, 4]
    mixed = mix_column(data, MIX_COLUMN_MATRIX)
    mixed_inverted = mix_column(mixed, MIX_COLUMN_MATRIX_INV)
    assert mixed == [4, 34, 205, 169]
    assert mixed_inverted == data
    print("test_mix_column: OK")
if __name__ == "__main__":
    test_mix_column()


# Generated at 2022-06-24 11:24:58.634299
# Unit test for function rotate
def test_rotate():
    data = [1,2,3,4,5,6]
    res = aes.rotate(data)
    new_data = res[-1:] + res[0:-1]
    assert new_data == data




# Generated at 2022-06-24 11:25:04.434827
# Unit test for function key_expansion
def test_key_expansion():
    test_key_1 = bytes_to_intlist(compat_b64decode('CjKiuEbvJcgHIGmFYnr/kg=='))
    test_key_2 = bytes_to_intlist(compat_b64decode('CjKiuEbvJcgHIGmFYnr/kpMpMpMpMpMp'))
    test_key_3 = bytes_to_intlist(compat_b64decode('CjKiuEbvJcgHIGmFYnr/kpMpMpMpMpMpMpMpMpMpMpMpMpMpMpMpMpMpMp'))

    print('key_expansion')
    expanded_key_1 = key_expansion(test_key_1)
    expanded_key_2 = key_expansion(test_key_2)


# Generated at 2022-06-24 11:25:09.355097
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    test_data = 'M1ykZdhbxMxLQX9OndoY//+6Y1hdn0W58k8lB6vu1r+CxvFjfQ9Xz0Y+PQ6MkM6GmcRgT+bD0ZU6Hq'
    test_key = 'test'
    test_key_bytes = len(test_key)
    test_result = aes_decrypt_text(test_data, test_key, test_key_bytes)
    test_result_expected = '<stream:stream xmlns:stream="http://etherx.jabber.org/streams" xmlns="jabber:client" version="1.0" to="localhost">'
    assert test_result == test_result_expected


# Generated at 2022-06-24 11:25:20.357406
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-24 11:25:32.685407
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    expected = [0x00, 0x05, 0x0a, 0x0f, 0x04, 0x09, 0x0e, 0x03, 0x08, 0x0d, 0x02, 0x07, 0x0c, 0x01, 0x06, 0x0b]
    assert shift_rows(data) == expected



# Generated at 2022-06-24 11:25:36.117776
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    expected = [0x19, 0xa0, 0x9a, 0xe9]
    assert(sub_bytes_inv([0xd4, 0x27, 0x11, 0xae]) == expected)
    print("Test sub_bytes_inv - PASSED")



# Generated at 2022-06-24 11:25:40.422661
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x19, 0x3d, 0xe3, 0xbe,
          0xa0, 0xf4, 0xe2, 0x2b,
          0x9a, 0xc6, 0x8d, 0x2a,
          0xe9, 0xf8, 0x48, 0x08]
    data_shifted = [0x19, 0xbe, 0x2b, 0x3d,
         0xa0, 0x48, 0x2a, 0xf4,
         0x9a, 0x08, 0xe3, 0xc6,
         0xe9, 0x3d, 0xf4, 0xf8]
    assert shift_rows(data) == data_shifted

test_shift_rows()


# Generated at 2022-06-24 11:25:46.374271
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    data = [0x0c, 0x04, 0x0c, 0x0c]
    data = sub_bytes_inv(data)
    assert data == [0x20, 0x20, 0x20, 0x20], "Sub bytes inverses failed"
    print("function sub_bytes_inv passed all tests")



# Generated at 2022-06-24 11:25:49.969150
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0xff, 0xf, 0xff, 0xff]) == [0x0, 0x10, 0x0, 0x0]



# Generated at 2022-06-24 11:26:00.135467
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    test_key = [43,126,21,22,40,174,210,166,171,247,21,136,9,207,79,60]
    test_counter_block = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    test_counter_arrow = lambda: test_counter_block
    test_counter = lambda: test_counter_arrow
    test_data = [106,140,204,216,225,149,63,122,11,138,89,6,250,245,44,127]
    test_decrypted_data = aes_ctr_decrypt(test_data, test_key, test_counter)

# Generated at 2022-06-24 11:26:04.438750
# Unit test for function sub_bytes
def test_sub_bytes():
    input = [0x11, 0x22, 0x33, 0x44]
    output = sub_bytes(input)
    answer = [0xa1, 0xee, 0x59, 0xaf]
    if output == answer:
        print("Success")
    else:
        print("Fail: " + output)


# Generated at 2022-06-24 11:26:09.982201
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]
    print(mix_column(data, MIX_COLUMN_MATRIX))
    print(mix_column(data, MIX_COLUMN_MATRIX_INV))
test_mix_column()


# Generated at 2022-06-24 11:26:14.053809
# Unit test for function inc
def test_inc():
    data = [0xFF, 0xFF, 0xFF, 0x0F]
    data_expected = [0x00, 0x00, 0x00, 0x10]
    data_output = inc(data)
    return data_output == data_expected
test_inc()


# Generated at 2022-06-24 11:26:23.645062
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # example from https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38a.pdf
    # Appendix F.2.1: AES-128 (Nk=4, Nr=10)
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-24 11:26:31.108639
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    assert(data_mixed == [0x8e, 0x4d, 0xa1, 0xbc])
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX_INV)
    assert(data_mixed == [0x8d, 0x01, 0x02, 0x04])
    print('test mix_column is OK')
test_mix_column()



# Generated at 2022-06-24 11:26:42.768424
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = "abcdabcdabcdabcdabcdabcdabcdabcd"
    key = "12345678901234561234567890123456"
    iv = "abcdefghijklmnop"
    data = bytes_to_intlist(data.encode("utf-8"))
    key = bytes_to_intlist(key.encode("utf-8"))
    iv = bytes_to_intlist(iv.encode("utf-8"))
    e = intlist_to_bytes(aes_cbc_encrypt(data, key, iv))
    e = compat_b64decode(e)
    e = e.decode("utf-8")

# Generated at 2022-06-24 11:26:53.594072
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    m = [0x32,0x88,0x31,0xe0,0x43,0x5a,0x31,0x37,0xf6,0x30,0x98,0x07,0xa8,0x8d,0xa2,0x34]
    res = [0x5F,0x7B,0xF2,0x50,0xAF,0xF8,0x68,0x98,0x03,0x9C,0x2E,0xD0,0x8E,0xA6,0xC6,0x04]
    if(mix_columns_inv(m) == res):
        print("PASS")
    else:
        print("FAIL")

test_mix_columns_inv()


# Generated at 2022-06-24 11:26:56.875980
# Unit test for function sub_bytes
def test_sub_bytes():
    (cipher_text, key) = encryption("plain_text.txt")
    print("Before sub_bytes: ", cipher_text)
    cipher_text = sub_bytes(cipher_text)
    print("After sub_bytes: ", cipher_text)



# Generated at 2022-06-24 11:27:08.007307
# Unit test for function inc
def test_inc():
    data = [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
            0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF]
    data = inc(data)
    expected = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01]
    assert data == expected, "Unit test for function inc() failed"



# Generated at 2022-06-24 11:27:16.471547
# Unit test for function mix_columns

# Generated at 2022-06-24 11:27:20.373730
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    from .test import aesTests
    from .test import aes_decrypt_text as test_aes_decrypt_text
    for test in aesTests:
        test_aes_decrypt_text(test)
# End of unit test



# Generated at 2022-06-24 11:27:27.236178
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x19, 0x3d, 0xe3, 0xbe, 0xa0, 0xf4, 0xe2, 0x2b, 0x9a, 0xc6, 0x8d, 0x2a, 0xe9, 0xf8, 0x48, 0x08]
    shifted = [0xbe, 0xe2, 0x2b, 0x9a, 0x19, 0xc6, 0x8d, 0x2a, 0xa0, 0xf8, 0x48, 0x08, 0x3d, 0xf4, 0xe3, 0xe9]
    assert shift_rows_inv(shifted) == data



# Generated at 2022-06-24 11:27:33.894349
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-24 11:27:40.768485
# Unit test for function aes_encrypt
def test_aes_encrypt():
    from .utils import bytes_to_intlist, intlist_to_bytes
    key = bytes_to_intlist("YELLOW SUBMARINE")
    data = bytes_to_intlist("1234567890123456")
    result = bytes_to_intlist("\x06'\x1a\x71\x19\x38\x3a\x76\x7c\x19\x6d\x61\x66\x33\x18\x6d\x2b")
    assert aes_encrypt(data, key_expansion(key)) == result


# Generated at 2022-06-24 11:27:50.014242
# Unit test for function sub_bytes
def test_sub_bytes():
    a = [0x6A, 0xB2, 0xD6, 0x6E, 0x6F, 0xD7, 0xB6, 0xA6, 0xDB, 0x76, 0xB2, 0x36, 0xBB, 0xF6, 0xEE, 0x26]
    b = [0xB2, 0xEE, 0x26, 0x6F, 0x76, 0x36, 0xDB, 0x6A, 0xF6, 0x6E, 0xB2, 0xD6, 0xA6, 0x6D, 0xB6, 0xBB]
    assert sub_bytes(a) == b
    print("Passed test sub_bytes")


# Generated at 2022-06-24 11:28:01.559371
# Unit test for function key_expansion
def test_key_expansion():
    _test_key_expansion("2b7e151628aed2a6abf7158809cf4f3c", "8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b")
    _test_key_expansion("2b7e151628aed2a6abf7158809cf4f3c762e7160c960a878c", "8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b4e59ff04f2d9f268")

# Generated at 2022-06-24 11:28:06.671013
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    if(data_mixed == [0x8e, 0x4d, 0xa1, 0xbc]):
        return True
    else:
        return False



# Generated at 2022-06-24 11:28:15.598120
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist('abcdefghijklmnop')
    expanded_key = bytes_to_intlist('000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f')
    assert intlist_to_bytes(aes_decrypt(data, expanded_key)) == compat_b64decode('MkTgYIH+w0mSZ3q0q1cJjQ==')



# Generated at 2022-06-24 11:28:17.511309
# Unit test for function rotate
def test_rotate():
    assert rotate([0, 1, 2, 3]) == [1, 2, 3, 0]



# Generated at 2022-06-24 11:28:28.286974
# Unit test for function aes_encrypt
def test_aes_encrypt():
    """
    @returns {boolean} true for success, false for failure
    """
    clear = [0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef, 0xfe, 0xdc, 0xba, 0x98, 0x76, 0x54, 0x32, 0x10]
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-24 11:28:33.804736
# Unit test for function xor
def test_xor():
    data1 = [1,2,3,4,5,6,7,8,9]
    data2 = [9,8,7,6,5,4,3,2,1]
    if xor(data1, data2) == [10, 10, 10, 10, 10, 10, 10, 10, 10]:
        return True
    else:
        return False

#print(test_xor())


# Generated at 2022-06-24 11:28:35.297149
# Unit test for function rotate
def test_rotate():
    assert rotate([0x10, 0x20, 0x30, 0x40]) == [0x20, 0x30, 0x40, 0x10]



# Generated at 2022-06-24 11:28:42.311530
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x09, 0xcf, 0x4f, 0x3c]
    rcon_iteration = 1
    correct = [0xef, 0x09, 0xcf, 0x3c]
    assert key_schedule_core(data, rcon_iteration) == correct
    return "test_key_schedule_core passed"



# Generated at 2022-06-24 11:28:53.345000
# Unit test for function shift_rows_inv

# Generated at 2022-06-24 11:28:57.101179
# Unit test for function xor
def test_xor():
    data1 = [0x1, 0x2, 0x3, 0x4]
    data2 = [0x5, 0x6, 0x7, 0x8]
    assert xor(data1, data2) == [0x4, 0x4, 0x4, 0xC]
    print("xor() unit test successful")



# Generated at 2022-06-24 11:29:00.104018
# Unit test for function inc
def test_inc():
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 1]) == [0, 0, 0, 2]



# Generated at 2022-06-24 11:29:09.684687
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import os
    import random

    class Counter(object):
        def __init__(self, initial_value):
            self.value = initial_value

        def next_value(self):
            ret = bytes_to_intlist(self.value)
            self.value = intlist_to_bytes(bytes_to_intlist(self.value) + 1)
            return ret

    raw_key = os.urandom(16)
    ctr = Counter(os.urandom(16))

    data = aes_ctr_decrypt(
        bytes_to_intlist(b"test"),
        bytes_to_intlist(raw_key),
        ctr)
    data = intlist_to_bytes(data)
    assert data == 'test'


# Generated at 2022-06-24 11:29:20.100184
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .aes_cbc_encrypt import aes_cbc_encrypt
    from .key_expansion import KeyExpansion
    from .counter import Counter

    iv = [42] * BLOCK_SIZE_BYTES
    key = range(1, BLOCK_SIZE_BYTES + 1)
    plain = [0] * 4096
    encrypted_data = aes_cbc_encrypt(plain, key, iv)
    decrypted_data = aes_cbc_decrypt(encrypted_data, key, iv)
    assert decrypted_data == plain

    iv = [42] * BLOCK_SIZE_BYTES
    key = range(1, BLOCK_SIZE_BYTES + 1)
    plain = [0] * 4097

# Generated at 2022-06-24 11:29:30.278913
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x00, 0x01, 0x02, 0x03,
            0x04, 0x05, 0x06, 0x07,
            0x08, 0x09, 0x0a, 0x0b,
            0x0c, 0x0d, 0x0e, 0x0f]
    data_shifted = shift_rows(data)
    assert data_shifted == [0x00, 0x01, 0x02, 0x03,
                            0x05, 0x06, 0x07, 0x04,
                            0x0a, 0x0b, 0x08, 0x09,
                            0x0f, 0x0c, 0x0d, 0x0e], "Error on shift_rows"



# Generated at 2022-06-24 11:29:38.063060
# Unit test for function key_expansion
def test_key_expansion():
    assert key_expansion(bytearray(b'\x00' * 16)) == bytearray(b'\x00' * 16 + b'\x62' * 48 + b'\x9c' * 80 + b'\xc6' * 112 + b'\xf0' * 144 + b'\x1a' * 176 + b'\x44' * 208 + b'\x6e' * 240 + b'\x98' * 272 + b'\xc2' * 304 + b'\xec' * 336 + b'\x16' * 368)

# Generated at 2022-06-24 11:29:40.042423
# Unit test for function mix_column
def test_mix_column():
    assert mix_column([0x8e, 0x20, 0xfa, 0x2c], MIX_COLUMN_MATRIX) == [0xe8, 0xdf, 0x9c, 0x1c]
test_mix_column()



# Generated at 2022-06-24 11:29:42.836881
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([1,2,3,4]) == ([0x63, 0x3c, 0xa5, 0xe0])
    print("Sub bytes test passed")
#Unit test for function shift_rows

# Generated at 2022-06-24 11:29:48.025944
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range(0, 255):
        for b in range(0, 255):
            assert rijndael_mul(a, b) == (a * b) % 256
# Run unit tests
test_rijndael_mul()



# Generated at 2022-06-24 11:29:59.554664
# Unit test for function mix_columns
def test_mix_columns():
    a = [0x02, 0x03, 0x01, 0x01, 0x02, 0x03, 0x01, 0x01, 0x02, 0x03, 0x01, 0x01, 0x02, 0x03, 0x01, 0x01]
    b = [0x01, 0x01, 0x02, 0x03, 0x01, 0x01, 0x02, 0x03, 0x01, 0x01, 0x02, 0x03, 0x01, 0x01, 0x02, 0x03]
    data_mul = mix_columns(b)
    for i in range(16):
        assert(data_mul[i] == a[i])
        print(hex(data_mul[i]))
    print("Mix columns pass")



# Generated at 2022-06-24 11:30:01.324670
# Unit test for function xor
def test_xor():
    assert xor([1, 2, 3, 4], [0, 0, 1, 1]) == [1, 2, 2, 5]



# Generated at 2022-06-24 11:30:03.613747
# Unit test for function shift_rows
def test_shift_rows():
  assert list(shift_rows([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])) == list(
    [1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15, 4, 8, 12, 16])
test_shift_rows()



# Generated at 2022-06-24 11:30:10.072621
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(compat_b64decode(b'Kj9Q7VZ/EPc='))
    key = bytes_to_intlist(compat_b64decode(b'T9D4ADqZ3q0='))
    expanded_key = key_expansion(key)
    cipher = aes_encrypt(data, expanded_key)
    assert cipher == bytes_to_intlist(compat_b64decode(b'+G4rf4Xq3h8='))


# Generated at 2022-06-24 11:30:17.167151
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    ciphertext = '9PHZvQsCVS60sjbAgwc7Om+L2aOo+CmZMxzXhC9ucO1z4f+4h6uB0VpJY6u+7qSOEQ2ynhJ9Pf+5R5IBLof5odfboU6M5pF90UKuq7E8QgZSw9XCsP5td5R5A5MKXPbxs59hlGQUIDQQQSSSQQCzFZZZDlGZYDbkzyMy4p4TbhywGBg=='
    password = 'test'
    key_size_bytes = 32
    plaintext = aes_decrypt_text(ciphertext, password, key_size_bytes)

# Generated at 2022-06-24 11:30:21.014421
# Unit test for function inc

# Generated at 2022-06-24 11:30:25.659342
# Unit test for function rijndael_mul
def test_rijndael_mul():
    if rijndael_mul(0x57, 0x13) != 0xFE:
        return False
    return True
#print(test_rijndael_mul())




# Generated at 2022-06-24 11:30:28.441030
# Unit test for function rotate
def test_rotate():
    data = [1, 2, 3, 4]
    print(rotate(data))


# Generated at 2022-06-24 11:30:40.083021
# Unit test for function key_schedule_core
def test_key_schedule_core():
    print("Expect the following output, given input: 0x2b, 0x7e, 0x15, 0x16 and iteration 0:")
    print(key_schedule_core([0x2b, 0x7e, 0x15, 0x16], 0))
    print("Expect the following output, given input: 0xa0, 0xfa, 0xfe, 0x17 and iteration 1:")
    print(key_schedule_core([0xa0, 0xfa, 0xfe, 0x17], 1))
    print("Expect the following output, given input: 0x88, 0x54, 0x2c, 0xb1 and iteration 2:")
    print(key_schedule_core([0x88, 0x54, 0x2c, 0xb1], 2))

# Generated at 2022-06-24 11:30:42.321238
# Unit test for function inc
def test_inc():
    assert inc([1,2,255,255]) == [1,3,0,0]

test_inc()


# Generated at 2022-06-24 11:30:48.874581
# Unit test for function inc
def test_inc():
    data = [0x00, 0x00, 0x00, 0x00]
    data = inc(data)
    assert data == [0x00, 0x00, 0x00, 0x01]
    data = [0x00, 0x00, 0xFF, 0xFF]
    data = inc(data)
    assert data == [0x00, 0x01, 0x00, 0x00]
    data = [0xFF, 0xFF, 0xFF, 0xFF]
    data = inc(data)
    assert data == [0x00, 0x00, 0x00, 0x00]



# Generated at 2022-06-24 11:30:54.760358
# Unit test for function xor
def test_xor():
    # given
    data1 = [255, 255, 255, 255]
    data2 = [1, 0, 1, 0]

    # when
    actual_result = xor(data1, data2)

    # then
    expected_result = [254, 255, 254, 255]
    assert actual_result == expected_result, "xor failed, expected_result: %s, actual_result: %s" \
                                             % (expected_result, actual_result)



# Generated at 2022-06-24 11:31:02.350535
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]
    data_shifted = shift_rows_inv(data)
    assert data_shifted == [0x63, 0x53, 0xcd, 0xba, 0xca, 0x09, 0x60, 0x70, 0xb7, 0xd0, 0xe0, 0xe1, 0x04, 0x51, 0xe7, 0x8c]



# Generated at 2022-06-24 11:31:11.946841
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode(
        '6K7u6ZmY6ZuG6Zu76K6p6K6v6K6x6K6y6K6/6K+d'))
    iv = bytes_to_intlist(compat_b64decode('+Pitfdm/0vqc0ZWm'))

# Generated at 2022-06-24 11:31:22.903474
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    input = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]
    output = sub_bytes_inv(input)
    expected_output = [0x00, 0x44, 0x88, 0xcc, 0xf1, 0x55, 0x99, 0xdd, 0x5a, 0xee, 0x22, 0x66, 0xaa, 0x2e, 0x72, 0xb6]
    if output == expected_output:
        print("test passed")
    else:
        print("test failed")
        print("input is", input)
        print("output is", output)

