

# Generated at 2022-06-24 11:21:30.135321
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    n = 4
    m = 4
    data = []
    for i in range(128):
        data.append(i ^ (i * 2))
    for i in range(100):
        data = mix_columns_inv(data)
    for i in range(128):
        data = mix_columns_inv(data)
        print(data[i])
        if(data[i] != (i ^ (i * 2))):
            return False
    return True

# Generated at 2022-06-24 11:21:38.855063
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]
    expected_sub_bytes = [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]

    sub_bytes = sub_bytes(data)
    assert expected_sub_bytes == sub_bytes


# Generated at 2022-06-24 11:21:46.415715
# Unit test for function key_expansion

# Generated at 2022-06-24 11:21:54.664288
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print("Testing function rijndael_mul()")
    assert(rijndael_mul(3, 9) == 22)
    assert(rijndael_mul(3, 1) == 3)
    assert(rijndael_mul(3, 2) == 6)
    assert(rijndael_mul(3, 3) == 9)
    assert(rijndael_mul(9, 4) == 77)
    assert(rijndael_mul(5, 6) == 100)
    print("OK")



# Generated at 2022-06-24 11:21:58.673522
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb,0x13,0x53,0x45]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    print(data_mixed)


# Generated at 2022-06-24 11:22:02.085848
# Unit test for function rotate
def test_rotate():
    assert rotate([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15])==[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,0]


# Generated at 2022-06-24 11:22:07.182510
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range(0x100):
        for b in range(0x100):
            assert rijndael_mul(a, b) == RIJNDAEL_EXP_TABLE[(RIJNDAEL_LOG_TABLE[a] + RIJNDAEL_LOG_TABLE[b]) % 0xFF], \
                "{} * {} != {}".format(a, b, rijndael_mul(a, b))
test_rijndael_mul()



# Generated at 2022-06-24 11:22:11.028884
# Unit test for function key_schedule_core
def test_key_schedule_core():
    test_data = [0x54, 0x77, 0x6f, 0x20]
    result = key_schedule_core(test_data, 1)

    print(result)
    assert result == [0x75, 0xF3, 0xC6, 0xF4]



# Generated at 2022-06-24 11:22:14.318870
# Unit test for function key_schedule_core
def test_key_schedule_core():
    a = [0x2B, 0x28, 0xAB, 0x09]
    b = key_schedule_core(a, 1)
    assert b == [0xA4, 0x68, 0x6B, 0x02]

test_key_schedule_core()



# Generated at 2022-06-24 11:22:21.248544
# Unit test for function xor
def test_xor():
    a = [0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0]
    b = [1, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1]
    c = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
    assert(xor(a,b) == c)



# Generated at 2022-06-24 11:22:31.213658
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    encrypted = [0x87, 0x4d, 0xfd, 0xb1, 0x52, 0xa9, 0x10, 0x81, 0xf3, 0xd7, 0x09, 0x3c, 0x21, 0x02, 0x83, 0xf7]
    counter = AESCounter(0)
    assert aes_ctr_decrypt(encrypted, key, counter) == [0x66, 0x6f, 0x6f]



# Generated at 2022-06-24 11:22:39.353136
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range(0, 256):
        for b in range(0, 256):
            assert (b == 0) == (rijndael_mul(a, b) == 0), "result is 0 when b=0"
            if b != 0:
                assert rijndael_mul(a, inverse(b)) == a, "inverse property"
                assert rijndael_mul(a, b) == rijndael_mul(b, a), "commutative property"
                assert rijndael_mul(rijndael_mul(a, b), c) == rijndael_mul(a, rijndael_mul(b, c)), "associative property"



# Generated at 2022-06-24 11:22:45.594783
# Unit test for function sub_bytes
def test_sub_bytes():
    test_data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    output = [0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76]
    assert sub_bytes(test_data) == output


# Generated at 2022-06-24 11:22:50.896409
# Unit test for function shift_rows
def test_shift_rows():
    test_string = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    result = shift_rows(test_string)
    expected = [0x00, 0x01, 0x02, 0x03, 0x07, 0x04, 0x05, 0x06, 0x0b, 0x08, 0x09, 0x0a, 0x0f, 0x0c, 0x0d, 0x0e]
    print(result)
    assert result == expected


# Generated at 2022-06-24 11:22:57.254671
# Unit test for function sub_bytes
def test_sub_bytes():
    input = [0x19, 0x3d, 0xe3, 0xbe, 0xa0, 0xf4, 0xe2, 0x2b, 0x9a, 0xc6, 0x8d, 0x2a, 0xe9, 0xf8, 0x48, 0x08]
    output = [0xd4, 0x27, 0x11, 0xae, 0xe0, 0xbf, 0x98, 0xf1, 0xb8, 0xb4, 0x5d, 0xe5, 0x1e, 0x41, 0x52, 0x30]
    assert sub_bytes(input) == output
# Test function
test_sub_bytes()

# ShiftRows

# Generated at 2022-06-24 11:23:07.821080
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print("testing rijndael_mul...")
    test_list = [[1, 1, 2], [0x00, 0x01, 0x01], [0x02, 0x03, 0x06], [0x04, 0x05, 0x19],
                 [0x06, 0x07, 0x1e], [0x08, 0x09, 0x14], [0x0a, 0x0b, 0x0a], [0x0c, 0x0d, 0x0d]]
    for t in test_list:
        if rijndael_mul(t[0], t[1]) != t[2]:
            print("test failed, data:", t)
            exit(1)

    print("test passed.")



# Generated at 2022-06-24 11:23:12.361806
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    count = 0
    for x in range(len(SBOX)):
        temp = sub_bytes_inv([SBOX[x]])
        if temp[0] != x:
            print(x, ":", temp[0])
            count += 1
    if count > 0:
        print("count:", count)
    else:
        print("All tests passed!")



# Generated at 2022-06-24 11:23:15.288359
# Unit test for function aes_encrypt
def test_aes_encrypt():
    M = 0x32    #'2'
    K = 0x2b    #'+'
    C = 0x39       #
    C_pre = aes_encrypt([M], [K] * 16)
    C_pre = C_pre[0]

    assert (C_pre == C)
test_aes_encrypt()    

# Generated at 2022-06-24 11:23:23.679483
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    data = [0x63, 0xEB, 0x9F, 0xA0, 0x30, 0xC1, 0xA2, 0x88, 0xB2, 0xD0, 0x5B, 0xE4, 0xD4, 0x93, 0x21, 0x22]
    result = sub_bytes_inv(data)
    assert result == [0xC2, 0xF6, 0x8C, 0xB1, 0x78, 0x9E, 0x42, 0x6E, 0xCF, 0xDE, 0xD1, 0x80, 0xE9, 0x4C, 0xE5, 0x5E]



# Generated at 2022-06-24 11:23:31.041719
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    """
    Encrypt a string in counter mode, decrypt it and check correctness
    """
    key = "36f18357be4dbd77f050515c73fcf9f2"
    encrypted_data = "69dda8455c7dd4254bf353b773304eec0ec7702330098ce7f7520d1cbbb20fc388d1b0adb5054dbd7370849dbf0b88d393f252e764f1f5f7ad97ef79d59ce29f5f51eeca32eabedd9afa9329"
    counter = Counter()

# Generated at 2022-06-24 11:23:39.202650
# Unit test for function sub_bytes
def test_sub_bytes():
    assert(sub_bytes([0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0x10, 0xd, 0xc, 0xb, 0xa, 0xE, 0xF]) == [0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76])
    

# Generated at 2022-06-24 11:23:51.306285
# Unit test for function key_expansion

# Generated at 2022-06-24 11:24:00.694717
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert shift_rows_inv([
        0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c
    ]) == [0x63, 0x53, 0xe0, 0x8c, 0x09, 0xd0, 0xba, 0x04, 0xcd, 0xe7, 0x70, 0x51, 0xca, 0xe1, 0xb7, 0x60]
    print("Function shift_rows_inv: PASSED")
    return
# test_shift_rows_inv()
# key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12

# Generated at 2022-06-24 11:24:06.562125
# Unit test for function rotate
def test_rotate():
    assert rotate([0, 1, 2, 3]) == [1, 2, 3, 0]
    assert rotate([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0]

# Generated at 2022-06-24 11:24:17.737205
# Unit test for function key_schedule_core
def test_key_schedule_core():
    print('Testing key_schedule_core...', end='')
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 0x01) == [0x01, 0x02, 0x03, 0x05]
    assert key_schedule_core([0x01, 0x02, 0x03, 0x05], 0x02) == [0x01, 0x04, 0x07, 0x0D]
    assert key_schedule_core([0x01, 0x04, 0x07, 0x0D], 0x03) == [0x01, 0x08, 0x0F, 0x19]
    print('Passed')


test_key_schedule_core()



# Generated at 2022-06-24 11:24:25.465779
# Unit test for function key_expansion
def test_key_expansion():
    print("Unit test for function key_expansion")
    print("starting key = 0x2b7e151628aed2a6abf7158809cf4f3c")
    print("expected expanded key = 0x2b7e151628aed2a6abf7158809cf4f3c0b0f32e082a28ac4ae4f7a4e2a4b7e151628aed2a6abf7158809cf4f3c0b0f32e082a28ac4ae4f7a4e2a")

# Generated at 2022-06-24 11:24:28.923411
# Unit test for function shift_rows
def test_shift_rows():
    data = [0] * 16
    for i in range(4):
        data[i] = i
    for i in range(4):
        data[4 + i] = 4 + i
    for i in range(4):
        data[8 + i] = 8 + i
    for i in range(4):
        data[12 + i] = 12 + i
    data_shifted = shift_rows(data)
    print(data_shifted)
    assert data == [x for x in data_shifted]



# Generated at 2022-06-24 11:24:34.179511
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .utils import xor
    from .aes import key_expansion

    class Counter:
        def __init__(self, counter=0):
            self.counter = counter
        def next_value(self):
            value = self.counter.to_bytes(16, 'big')
            self.counter += 1
            return bytes_to_intlist(value)

    data = bytes_to_intlist(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')

# Generated at 2022-06-24 11:24:36.322332
# Unit test for function mix_columns
def test_mix_columns():
    plaintext = bytes(range(16))
    mix_columns(plaintext)



# Generated at 2022-06-24 11:24:45.418455
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    input_data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert mix_columns_inv(input_data) == data_mixed
    print("Test mix_columns_inv() OK")

# Generated at 2022-06-24 11:24:50.541468
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [0x2b7e, 0x1516, 0x28ae, 0xd2a6, 0xabf7, 0x1588, 0x09cf, 0x4f3c]
    input = [0x6bc1, 0xbee2, 0x2e40, 0x9f96, 0xe93d, 0x7e11, 0x7393, 0x172a, 0xae2d, 0x8a57, 0x1e03, 0xac9c, 0x9eb7, 0x6fac, 0x45af, 0x8e51]

# Generated at 2022-06-24 11:25:01.134200
# Unit test for function shift_rows
def test_shift_rows():
    # Test data
    data = [0x63, 0xC0, 0xAB, 0x20, 0xEF, 0x1F, 0xDF, 0xB1, 0x69, 0x46, 0x99, 0x5B, 0xC4, 0x93, 0xB9, 0x6E]
    data_shifted = shift_rows(data)
    # Data must become
    # 0x63, 0x20, 0xAB, 0xC0, 0xEF, 0xB1, 0xDF, 0x1F, 0x69, 0x5B, 0x99, 0x46, 0xC4, 0x6E, 0xB9, 0x93

# Generated at 2022-06-24 11:25:08.745687
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0xFF):
        for j in range(0xFF):
            assert rijndael_mul(i, j) == galois_multiply(i, j)



# Generated at 2022-06-24 11:25:14.006991
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    f = open("ECB_Test.txt", 'rb')
    data = f.read()
    f.close()
    data = binascii.hexlify(data)  # string
    data = [data[i: i + 2] for i in range(0, len(data), 2)]
    data = [int(x, 16) for x in data]
    data = shift_rows_inv(data)
    for i in range(len(data)):
        print("%02x" % data[i], end='')  # print well
    print("")
    return 0



# Generated at 2022-06-24 11:25:22.257916
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    ct = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    pt = [0x8E, 0xE2, 0x4F, 0xDD, 0x02, 0x1C, 0xA8, 0x36, 0x07, 0x58, 0x06, 0x55, 0x1C, 0xE6, 0x4A, 0x7D]
    print(mix_columns_inv(ct) == pt)



# Generated at 2022-06-24 11:25:33.930722
# Unit test for function aes_encrypt
def test_aes_encrypt():
    plaintext=b"Two One Nine Two"
    plaintext=bytes_to_intlist(plaintext)
    key_bytes=b"\x54\x68\x61\x74\x73\x20\x6D\x79\x20\x4B\x75\x6E\x67\x20\x46\x75"
    key=bytes_to_intlist(key_bytes)
    #print(key)
    expanded_key = key_expansion(key)
    #print(expanded_key)
    round_keys=expanded_key[:16]
    print(round_keys)
    print(aes_encrypt(plaintext, expanded_key))

if __name__ == '__main__':
    test_aes_encrypt()



# Generated at 2022-06-24 11:25:39.538740
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0, 1, 2, 3,
            4, 5, 6, 7,
            8, 9, 10, 11,
            12, 13, 14, 15]
    data_shift = shift_rows(data)
    data_shift_inv = shift_rows_inv(data_shift)
    assert(data_shift_inv == data)



# Generated at 2022-06-24 11:25:44.359699
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
    data_shifted = shift_rows_inv(data)
    print(data_shifted)
    for column in range(4):
        for row in range(4):
            assert(data_shifted[((column - row) & 0b11) * 4 + row] == data[((column + row) & 0b11) * 4 + row])



# Generated at 2022-06-24 11:25:49.256992
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected = [0x8e, 0xe3, 0xb5, 0xa0, 0x8b, 0x10, 0xfb, 0x2b, 0x8d, 0x99, 0x39, 0x2a, 0x1c, 0xb9, 0x60, 0x5b]
    result = mix_columns_inv(data)
    for a, b in zip(result, expected):
        if a != b:
            print('Mix_columns_inv error !!')
            break
# Unit test

# Generated at 2022-06-24 11:25:54.333030
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    print('test sub_bytes_inv')
    data = [0xd4,0xe0,0xb8,0x1e,
            0x27,0xbf,0xb4,0x41,
            0x11,0x98,0x5d,0x52,
            0xae,0xf1,0xe5,0x30]
    expected = sub_bytes_inv(sub_bytes(data))
    assert data == expected
    print('Pass')



# Generated at 2022-06-24 11:25:59.072408
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x83) == 0xc1
test_rijndael_mul()



# Generated at 2022-06-24 11:26:01.518347
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0] * 16
    assert sub_bytes(data) == [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]


# Generated at 2022-06-24 11:26:07.474126
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = bytes_to_intlist(compat_b64decode('gIxl1w7TA+mYp7Vm1q3uAA=='))
    key = bytes_to_intlist(compat_b64decode('r8gvMAl9eSAH2Gj/Wusg/w=='))
    data = bytes_to_intlist(compat_b64decode('c+yTZAjf4g4sDdUZkzQlFw=='))

    assert aes_cbc_decrypt(data, key, iv) == bytes_to_intlist(b'Hello world!')



# Generated at 2022-06-24 11:26:17.423242
# Unit test for function key_schedule_core
def test_key_schedule_core():
    input_key = [0x01, 0x02, 0x03, 0x04]
    expected_output = [0x01, 0x03, 0x05, 0x0f]
    assert key_schedule_core(input_key, 1) == expected_output
    return

test_key_schedule_core()



# Generated at 2022-06-24 11:26:20.675025
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x00, 0x00, 0x00, 0x00]
    rcon_iteration = 0x0
    assert key_schedule_core(data, rcon_iteration) == [0x01, 0x00, 0x00, 0x00]



# Generated at 2022-06-24 11:26:23.887004
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x19, 0xa0, 0x9a, 0xe9]
    data = sub_bytes(data)
    assert(data == [0xd4, 0xe0, 0xb8, 0x1e])



# Generated at 2022-06-24 11:26:31.962738
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist("140b41b22a29beb4061bda66b6747e14")

# Generated at 2022-06-24 11:26:40.528469
# Unit test for function mix_columns
def test_mix_columns():
    start = [0x63, 0x53, 0xe0, 0x8c, 0x09, 0x60, 0xe1, 0x04, 0xcd, 0x70, 0xb7, 0x51, 0xba, 0xca, 0xd0, 0xe7]
    exp = [0x5f, 0x72, 0x64, 0x15, 0x57, 0xf5, 0xbc, 0x92, 0xf7, 0xbe, 0x3b, 0x29, 0x1d, 0xb9, 0xf9, 0x1a]
    assert(exp == mix_columns(start))

# Generated at 2022-06-24 11:26:43.041583
# Unit test for function mix_column
def test_mix_column():
    mixed = mix_column([0xB1, 0xD0, 0x48, 0xCB], MIX_COLUMN_MATRIX)
    assert mixed == [0x30, 0x3B, 0xDD, 0x34]
    print('Mix column OK')



# Generated at 2022-06-24 11:26:47.828247
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = "HelloWorld".encode('ascii')
    data = bytes_to_intlist(data)
    key = bytes_to_intlist("YELLOW SUBMARINE".encode('ascii'))
    iv = [0] * 16
    encrypted_data = aes_cbc_encrypt(data, key, iv)

    expected_data = [197, 32, 186, 92,
                     186, 94, 215, 153,
                     9, 222, 78, 166,
                     193, 162, 17, 218]
    assert(encrypted_data == expected_data)



# Generated at 2022-06-24 11:26:57.932583
# Unit test for function aes_decrypt
def test_aes_decrypt():

    print("aes_decrypt")

    ciph = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode(b'YELLOW SUBMARINE'))
    nonce = 0
    counter = AES128Counter(nonce)
    decr = aes_ctr_decrypt(ciph, key, counter)
    print(intlist_to_bytes(decr))
    assert intlist_to_bytes(decr) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '


# Generated at 2022-06-24 11:27:09.522216
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0xab, 0xab, 0xab, 0xab]
    data_mixed = mix_columns(data)
    assert data_mixed == [0x8e, 0x4d, 0xa1, 0xbc,
                          0x9f, 0xdc, 0x58, 0x9d,
                          0x01, 0x01, 0x01, 0x01,
                          0xe5, 0x38, 0x30, 0x4e]



# Generated at 2022-06-24 11:27:13.501452
# Unit test for function xor
def test_xor():
    assert(xor([0xA, 0xA], [0x6, 0x6]) == [0xC, 0xC])



# Generated at 2022-06-24 11:27:18.483317
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x01, 0x01, 0x01, 0x01]) == [0x1E, 0x2D, 0xB8, 0xD0]
    assert sub_bytes([0xFF, 0xFF, 0xFF, 0xFF]) == [0x11, 0x22, 0x33, 0x44]
    assert sub_bytes([0x4D, 0x59, 0xF2, 0x0F]) == [0x5B, 0x57, 0xF5, 0x31]
    assert sub_bytes([0xE3, 0x43, 0x33, 0xB5]) == [0xCE, 0x84, 0x21, 0x50]

# Generated at 2022-06-24 11:27:21.072119
# Unit test for function xor
def test_xor():
    data1 = [1,2,3,4]
    data2 = [5,6,7,8]
    print(xor(data1,data2))
    return



# Generated at 2022-06-24 11:27:31.858884
# Unit test for function rijndael_mul

# Generated at 2022-06-24 11:27:41.607497
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'Sixteen byte key')
    iv = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f')
    cleartext = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f')
    # This test is to ensure the padding algorithm works.


# Generated at 2022-06-24 11:27:43.725816
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3,4]) == [2,3,4,1]

# Generated at 2022-06-24 11:27:56.089753
# Unit test for function rijndael_mul
def test_rijndael_mul():
    a = 0x01
    b = 0x03
    c = rijndael_mul(a, b)
    assert c == 0x05
    assert rijndael_mul(a, 0x5b) == 0x5b
    assert rijndael_mul(a, 0x9a) == 0x9a
    assert rijndael_mul(a, 0x4b) == 0x4b
    assert rijndael_mul(a, 0x8b) == 0x8b
    assert rijndael_mul(a, 0x65) == 0x65
    assert rijndael_mul(a, 0x7b) == 0x7b
    assert rijndael_mul(a, 0x01) == 0x01
    assert rij

# Generated at 2022-06-24 11:27:57.800997
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert(rijndael_mul(4,4) == 0x1b)


# Generated at 2022-06-24 11:27:58.572193
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]

# Generated at 2022-06-24 11:28:06.537826
# Unit test for function shift_rows
def test_shift_rows():
    test_value1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    test_value2 = [1, 6, 11, 16, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12]

    if shift_rows(test_value1) != test_value2:
        print("Failed")
    else:
        print("Success")



# Generated at 2022-06-24 11:28:18.730544
# Unit test for function aes_decrypt
def test_aes_decrypt():
    print("Challenge 04 AES decryption")
    counter = Counter()

# Generated at 2022-06-24 11:28:27.540401
# Unit test for function key_expansion
def test_key_expansion():
    # Test data: https://en.wikipedia.org/wiki/Advanced_Encryption_Standard
    key = bytes_to_intlist(compat_b64decode(b'awggawgawggawgx8'))
    correct_expanded_key = bytes_to_intlist(compat_b64decode(b'awggawgawggawgx8FQmC/or98N7F+eTj3Dq6n3/6x8Bl7cXdhfWQNfCvT6oACwB+'))
    expanded_key = key_expansion(key)
    assert expanded_key == correct_expanded_key



# Generated at 2022-06-24 11:28:31.429950
# Unit test for function key_schedule_core
def test_key_schedule_core():
    expected_result = [0x54, 0x66, 0xEF, 0x19]
    data = [0x66, 0xEF, 0x19, 0x54]

    assert (key_schedule_core(data, 0x01) == expected_result)



# Generated at 2022-06-24 11:28:33.892097
# Unit test for function shift_rows
def test_shift_rows():
    data = []
    for i in range(16):
        data.append(i)
    shifted_data = shift_rows(data)
    print(shifted_data)



# Generated at 2022-06-24 11:28:43.736717
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    test_data = [0x63, 0x53, 0xe0, 0x8c, 0x09, 0x60, 0xe1, 0x04, 0xcd, 0x70, 0xb7, 0x51, 0xba, 0xa6, 0x86, 0x2e]
    assert sub_bytes_inv(test_data) == [0x63, 0x53, 0xe0, 0x8c, 0x09, 0x60, 0xe1, 0x04, 0xcd, 0x70, 0xb7, 0x51, 0xba, 0xa6, 0x86, 0x2e]



# Generated at 2022-06-24 11:28:47.383439
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 1) == [0x01, 0x02, 0x03, 0x05]



# Generated at 2022-06-24 11:28:54.753938
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    input = [0x00, 0x01, 0x02, 0x03, 0x10, 0x11, 0x12, 0x13, 0x20, 0x21, 0x22, 0x23, 0x30, 0x31, 0x32, 0x33]
    expected_output = [0x00, 0x10, 0x20, 0x30, 0x01, 0x11, 0x21, 0x31, 0x02, 0x12, 0x22, 0x32, 0x03, 0x13, 0x23, 0x33]
    assert expected_output == shift_rows_inv(input)



# Generated at 2022-06-24 11:28:59.410398
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = compat_b64decode('YWJjZGVmZ2g=') # abcdefgh
    plain = compat_b64decode('NDU2Nzg5YWJjZA==') # 456789abcd
    assert aes_encrypt(bytes_to_intlist(plain), bytes_to_intlist(key)) == [48, 247, 185, 11, 202, 176, 203, 122, 54, 18, 164, 110, 231, 45, 162, 35]


# Generated at 2022-06-24 11:29:06.953032
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xD4, 0xbf, 0x5d, 0x30, 0xe0, 0xb4, 0x52, 0xae, 0xb8, 0x41, 0x11, 0xf1, 0x1e, 0x27, 0x98, 0xe5]
    print("".join("{:02x}".format(x) for x in data))
    data = mix_columns(data)
    print("".join("{:02x}".format(x) for x in data))


test_mix_columns()

# Generated at 2022-06-24 11:29:09.417572
# Unit test for function xor
def test_xor():
    assert (xor(data1=[0xab, 0xcd, 0xef], data2=[0x01, 0x23, 0x40])) == [0xaa, 0xee, 0xaf]



# Generated at 2022-06-24 11:29:14.515322
# Unit test for function aes_decrypt
def test_aes_decrypt():
    from .utils import hex_to_bytes
    data_hex = ""
    key_hex = ""
    key_bytes = hex_to_bytes(key_hex)
    data_bytes = hex_to_bytes(data_hex)
    data = bytes_to_intlist(data_bytes, 1)
    key = bytes_to_intlist(key_bytes, 1)
    expanded_key = key_expansion(key)
    answer = aes_decrypt(data, expanded_key)
    
    print("Test unit of aes_decrypt is done! ")
    # print(intlist_to_hex(answer))
    # print(intlist_to_hex(expanded_key))
    assert intlist_to_hex(answer) == ""

# Generated at 2022-06-24 11:29:18.580988
# Unit test for function inc
def test_inc():
    assert inc([1, 2, 3]) == [1, 2, 4]
    assert inc([1, 2, 255]) == [1, 3, 0]
    assert inc([255, 255, 255]) == [0, 0, 0]



# Generated at 2022-06-24 11:29:26.995490
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # pylint: disable=line-too-long
    assert aes_decrypt_text('U0FGRU5Z6hyzO6UfI1RE3g==', 'password', 16) == 'password'
    assert aes_decrypt_text('U0FGRU5Z6hyzO6UfI1RE3g==', 'password', 24) == 'password'
    assert aes_decrypt_text('U0FGRU5Z6hyzO6UfI1RE3g==', 'password', 32) == 'password'
    assert aes_decrypt_text('YhV1J+smgD7zZ2HfPdJzsg==', 'password', 16) == 'password1'

# Generated at 2022-06-24 11:29:35.213240
# Unit test for function aes_decrypt
def test_aes_decrypt():
    cipher = bytes_to_intlist(compat_b64decode(b"Kj3q3yI1gq9XEBUjD5WQPQ=="))
    expanded_key = key_expansion(bytes_to_intlist(
        compat_b64decode(b"G4skPZoTzfVxNx6jzPVWR30rB8FauVil")
        ))
    decrypted_key = aes_decrypt(cipher, expanded_key)
    assert intlist_to_bytes(decrypted_key) == b"0123456789abcdef"



# Generated at 2022-06-24 11:29:46.771880
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .compat import compat_ord
    from .counter import Counter
    from .crypto import decrypt as _decrypt

    key = [compat_ord(c) for c in "000102030405060708090A0B0C0D0E0F"]
    counter = Counter(compat_ord("0F"), 0, False)
    encrypted_data = bytes_to_intlist("69C4E0D86A7B0430D8CDB78070B4C55A".decode("hex"))

    decrypted_data = aes_ctr_decrypt(encrypted_data, key, counter)
    if intlist_to_hex(decrypted_data) != "00112233445566778899AABBCCDDEEFF":
        raise Exception("Failed to decrypt data")

# Generated at 2022-06-24 11:29:50.546945
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    for i in range(0, 16):
        assert(SBOX[SBOX_INV[i]] == i)
    for i in range(0, 128):
        assert(SBOX_INV[SBOX[i]] == i)


test_shift_rows_inv()



# Generated at 2022-06-24 11:29:57.722083
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    test_data = [0x19, 0xa0, 0x9a, 0xe9, 0x3d, 0xf4, 0xc6, 0xf8, 0xe3, 0xe2, 0x8d, 0x48, 0xbe, 0x2b, 0x2a, 0x08]
    assert (sub_bytes_inv(test_data) == test_data)



# Generated at 2022-06-24 11:30:07.028656
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Encrypt with aes in ECB mode
    # 128-bit key
    key = compat_b64decode(b'GawgguFyGrWKav7AX4VKUg')
    # 16-Byte plain text
    plain = list(range(BLOCK_SIZE_BYTES))
    expanded_key = key_expansion(bytes_to_intlist(key))
    cipher = aes_encrypt(plain, expanded_key)
    state = aes_decrypt(cipher, expanded_key)
    plain_2 = aes_encrypt(state, expanded_key)
    assert cipher == plain_2
    assert state == plain
    # 256-bit key

# Generated at 2022-06-24 11:30:16.539278
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    text = [0x19, 0xa0, 0x9a, 0xe9, 0x3d, 0xf4, 0xc6, 0xf8, 0xe3, 0xe2, 0x8d, 0x48, 0xbe, 0x2b, 0x2a, 0x08]
    text_result = [0x19, 0xa0, 0x9a, 0xe9, 0x8d, 0xf4, 0xc6, 0xf8, 0xe3, 0x3d, 0x48, 0xbe, 0x2b, 0xe2, 0x08, 0x2a]
    assert text_result == shift_rows_inv(text), 'Error in shift_rows_inv'
test_shift_rows_inv()

# Generated at 2022-06-24 11:30:26.802126
# Unit test for function sub_bytes
def test_sub_bytes():
    plain = [0xF0, 0x02, 0x00, 0x89, 0xD0, 0x8D, 0x0D, 0x03, 0x04, 0x00, 0x80, 0x02, 0x00, 0xF4, 0x40, 0x01]
    _sbox = sub_bytes(plain)
    expected = [0x7B, 0xA7, 0x03, 0x59, 0xC1, 0xF7, 0x66, 0x7D, 0xC2, 0x11, 0xC6, 0x1E, 0x6D, 0x12, 0x68, 0x25]
    assert _sbox == expected


# Generated at 2022-06-24 11:30:31.965695
# Unit test for function key_schedule_core
def test_key_schedule_core():
    input = [0x1f, 0x07, 0x1d, 0x0e]
    expected = [0x8d, 0x4f, 0x1f, 0x42]
    assert(expected == key_schedule_core(input, 1))
    assert([0x9b, 0x75, 0x2e, 0x45] == key_schedule_core(input, 2))



# Generated at 2022-06-24 11:30:39.363513
# Unit test for function inc
def test_inc():
    data = [1, 0]
    assert inc(data) == [1, 1], "inc function fail"
    data = [255, 255]
    assert inc(data) == [0, 0, 1], "inc function fail"
    data = [255]
    assert inc(data) == [0, 1], "inc function fail"
    data = [0, 1]
    assert inc(data) == [0, 2], "inc function fail"
    data = [0, 255]
    assert inc(data) == [1, 0], "inc function fail"



# Generated at 2022-06-24 11:30:43.156632
# Unit test for function shift_rows
def test_shift_rows():
    message = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    result = [1, 2, 3, 4, 6, 7, 8, 5, 11, 12, 13, 9, 15, 16, 14, 10]
    assert(shift_rows(message) == result)


# Generated at 2022-06-24 11:30:53.569346
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    NONCE_LENGTH_BYTES = 8

    data = bytes_to_intlist(compat_b64decode('G5n+Yw8mjKUfnnd5mh6vX9W1d8hODjK6PxU5Ly5oWGpLKj5f5zCitF1f9WExD8jeS0oGZpzzHYR7KOwEd0o4Qg=='))
    password = bytes_to_intlist('password')

    key = password[:16] + [0] * 16
    key = aes_encrypt(key[:BLOCK_SIZE_BYTES], key_expansion(key)) * 16

    nonce = data[:NONCE_LENGTH_BYTES]

# Generated at 2022-06-24 11:30:56.209923
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([0, 0, 0, 0])) == [0, 0, 0, 0]



# Generated at 2022-06-24 11:31:03.844469
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import random
    import binascii
    data = binascii.a2b_hex('69dda8455c7dd4254bf353b773304eec0ec7702330098ce7f7520d1cbbb20fc388d1b0adb5054dbd7370849dbf0b88d393f252e764f1f5f7ad97ef79d59ce29f5f51eeca32eabedd9afa9329')
    expanded_key = key_expansion(binascii.a2b_hex('603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4'))


# Generated at 2022-06-24 11:31:13.867937
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    counter = Counter(bytes_to_intlist(compat_b64decode('AAECAwQFBgcICQoLDA0ODw==')))
    decrypted_data = aes_ctr_decrypt(data, key, counter)
    print(decrypted_data)


# Generated at 2022-06-24 11:31:18.649165
# Unit test for function xor
def test_xor():
    a = [4, 6, 0, 2]
    b = [11, 3, 7, 5]
    c = xor(a, b)
    assert c == [15, 5, 7, 7], "Expect [15, 5, 7, 7], got {}".format(c)
    print("Result of xor function: OK")



# Generated at 2022-06-24 11:31:28.683495
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    p = '56e47a38c5598974bc46903dba290349'
    c = 'c30e32ffedc0774e6aff6af0869f71aa'
    k = '36f18357be4dbd77f050515c73fcf9f2'
    iv = '69dda8455c7dd4254bf353b773304eec'
    kk = 'cbc'

    assert aes_cbc_encrypt(bytes_to_intlist(compat_b64decode(p)), bytes_to_intlist(compat_b64decode(k)), bytes_to_intlist(compat_b64decode(iv))) == bytes_to_intlist(compat_b64decode(c))
