

# Generated at 2022-06-24 11:21:30.766480
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert (key_schedule_core([1, 2, 3, 4], 1) == [2, 3, 4, 3])
    assert (key_schedule_core([5, 6, 7, 8], 2) == [13, 14, 12, 15])

test_key_schedule_core()



# Generated at 2022-06-24 11:21:39.863395
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    plaintext = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
                 0x12, 0x11, 0xFF, 0xAA, 0x3C, 0x10, 0x2F, 0xC7, 0x1A, 0x1C, 0xF1, 0xC5, 0x11, 0x1C, 0x31, 0x2B]

# Generated at 2022-06-24 11:21:47.529400
# Unit test for function aes_encrypt
def test_aes_encrypt():
    test_data = bytes_to_intlist(b'test data')
    expanded_key = key_expansion(bytes_to_intlist(b'haufhaufhaufhauf'))
    enc_test_data = aes_encrypt(test_data, expanded_key)
    assert (intlist_to_bytes(enc_test_data) == b'\x83\x01\x9b\xfe\x83\x01\x9b\xfe\x83\x01\x9b\xfe\x83\x01\x9b\xfe')



# Generated at 2022-06-24 11:21:50.851882
# Unit test for function inc
def test_inc():
    data = [0x11,0x12,0xff]
    print(int_to_hex(inc(data)))
    # 0x11 0x13 0x00

# TODO: Use Types to make sure we're not mixing different lengths of data

# Generated at 2022-06-24 11:21:54.633205
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for x in xrange(0, 0x100):
        for y in xrange(0, 0x100):
            mul_result = rijndael_mul(x, y)
            aes_result = aes_mul(x, y)
            # Print only the first mismatch
            assert mul_result == aes_result

# Generated at 2022-06-24 11:22:04.003856
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert (sub_bytes_inv([0x53, 0xca, 0x0b, 0x52]) == [0x47, 0x6d, 0x56, 0xbb])
    assert (sub_bytes_inv([0x52, 0xca, 0x0b, 0x53]) == [0xbb, 0x6d, 0x56, 0x47])
    assert (sub_bytes_inv([0x0b, 0xca, 0x53, 0x52]) == [0x56, 0x6d, 0x47, 0xbb])
    assert (sub_bytes_inv([0x0b, 0xca, 0x52, 0x53]) == [0x56, 0x6d, 0xbb, 0x47])

# Generated at 2022-06-24 11:22:09.586589
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
           0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]

# Generated at 2022-06-24 11:22:20.888381
# Unit test for function mix_column
def test_mix_column():
    a = [0xca, 0xca, 0xca, 0xc9]
    b = [0xca, 0xca, 0xca, 0xca]
    c = [0xca, 0xca, 0xca, 0xcb]

    a_mixed = mix_column(a, MIX_COLUMN_MATRIX)
    b_mixed = mix_column(b, MIX_COLUMN_MATRIX)
    c_mixed = mix_column(c, MIX_COLUMN_MATRIX)

    print("a_mixed =", a_mixed)
    print("b_mixed =", b_mixed)
    print("c_mixed =", c_mixed)

    return(a_mixed and b_mixed and c_mixed)



# Generated at 2022-06-24 11:22:24.144347
# Unit test for function rotate
def test_rotate():
    # data = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    data = [0x2b, 0x7e, 0x15]
    for i in range(4):
        data = rotate(data)
        print([hex(x) for x in data])



# Generated at 2022-06-24 11:22:33.410151
# Unit test for function shift_rows
def test_shift_rows():
    init_data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    shifted_data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    assert shift_rows(init_data) == shifted_data, "Shift rows failed"

    init_data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    shifted_data = [1, 2, 3, 4, 6, 7, 8, 9, 11, 12, 13, 14, 16, 15, 16, 16]
    assert shift_rows(init_data) == shifted_data, "Shift rows failed"

   

# Generated at 2022-06-24 11:22:36.061549
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range(0x100):
        for b in range(0x100):
            result1 = rijndael_mul(a, b)
            result2 = rijndael_mul(b, a)
            assert (result1 == result2)



# Generated at 2022-06-24 11:22:42.964641
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    ciphertext = """mIxOQQtZtvOtZ1eBzbOWrT3Xb0/fStoLR/QRwLN0xKGZs1sdeNgFJrSV
                    fH9ezzFOyUYlYUD4V6xz3qLn+ZUjEWgtWnV8i9X2FmsV7YryY+pwf8wm
                    Qu5BE5ii5AxLc/W8Vv5QPJy7BkC+YOYw8zv5O5O5l5EG+sn5SrhH/J0
                    TloL1Nkcj4U6bvx6J/0"""

# Generated at 2022-06-24 11:22:48.155614
# Unit test for function sub_bytes
def test_sub_bytes():
    plain_hex = ""
    plain_text = [int(x, 16) for x in plain_hex]
    print(sub_bytes(plain_text))
    assert sub_bytes(plain_text) == []

# Performs the mix column transformation

# Generated at 2022-06-24 11:22:51.628903
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    print('=====')
    data = [0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]
    print(data)
    data = shift_rows_inv(data)
    print(data)
    print('=====')


# Generated at 2022-06-24 11:22:52.931498
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0, 0, 0, 0, 0xFF]) == [0, 0, 0, 0, 0, 0, 1, 0]



# Generated at 2022-06-24 11:22:59.256992
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = [50, 66, 179, 133, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0]
    input = [10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10]
    output = aes_encrypt(input, key_expansion(key))
    assert output[8] == 128

    key = [50, 66, 179, 133, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0]
    encrypted_video_file = open('/Users/rongyin/Work/Youtube-DL/youtube_dl/extractor/udemy.py', 'rb')
    encrypted_video_file.seek(0)
    encrypted_video_content = encrypted

# Generated at 2022-06-24 11:23:01.519399
# Unit test for function xor
def test_xor():
    data1 = [0x10, 0x11, 0x12, 0x13]
    data2 = [0xa0, 0xb0, 0xc0, 0xd0]
    assert xor(data1, data2) == [0xb0, 0xa1, 0xd2, 0xc3]



# Generated at 2022-06-24 11:23:09.331673
# Unit test for function mix_column
def test_mix_column():
    data = [0xf1, 0xf2, 0xf3, 0xf4]
    matrix = ((0x02, 0x03, 0x01, 0x01),
              (0x01, 0x02, 0x03, 0x01),
              (0x01, 0x01, 0x02, 0x03),
              (0x03, 0x01, 0x01, 0x02))
    mixed_data = mix_column(data, matrix)
    assert mixed_data[0] == 0xe4
    assert mixed_data[1] == 0x4d
    assert mixed_data[2] == 0xbf
    assert mixed_data[3] == 0x1a


test_mix_column()


# Generated at 2022-06-24 11:23:17.428015
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Unit test for function aes_decrypt_text
    """
    data = b'+DzS9X7VuLzIIJ3kqE4wYG4OPVuRfRjB7VuIVv2kAJWfRjB'
    password = b'\xe0\xb6\xb3\xe3\x81\x8f\xe1\x85\x92F\xd5\xe1\x85\x92F\xe0\xb6\xb3\xe1\x85\x92F\xe1\x85\x92'

    plaintext = aes_decrypt_text(data, password, len(password))

# Generated at 2022-06-24 11:23:25.115374
# Unit test for function mix_columns
def test_mix_columns():
    test_input = [0xdb,0x13,0x53,0x45,0xf2,0x0a,0x22,0x5c,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01]
    expected_output = [0x8e,0x4d,0xa1,0xbc,0x9f,0xdc,0x58,0x9d,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01]
    assert mix_columns(test_input) == expected_output

# Generated at 2022-06-24 11:23:28.331046
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 1]
    assert rotate([1, 2, 3, 4, 5, 6]) == [2, 3, 4, 5, 6, 1]
    assert rotate([1]) == [1]


# Generated at 2022-06-24 11:23:35.910750
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # AES-128 Encryption Test
    print("AES-128 Test")
    key = [0x00010203, 0x04050607, 0x08090A0B, 0x0C0D0E0F]
    key = key_expansion(key)
    data = [0x00112233, 0x44556677, 0x8899AABB, 0xCCDDEEFF]
    data = aes_encrypt(data, key)
    print(data)
    if data != [0x69C4E0D8, 0x6A7B0430, 0xD8CDB780, 0x70B4C55A]:
        print("Test fail")
    else:
        print("Test pass")

    # AES-192 Encryption Test
    print("AES-192 Test")
    key

# Generated at 2022-06-24 11:23:46.189293
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x63, 0xca, 0xb7, 0x04, 0xd3, 0x9b, 0xf1, 0x2b, 0xbe, 0x03, 0xd1, 0xbd, 0x4d, 0xe7, 0x6b, 0x90]
    expected = [0x63, 0x9b, 0xd1, 0xe7, 0xb7, 0xf1, 0x04, 0x90, 0xca, 0x2b, 0xbd, 0x6b, 0x04, 0xbe, 0x4d, 0xd3]
    actual = shift_rows(data)
    assert(expected == actual)

test_shift_rows()


# Generated at 2022-06-24 11:23:48.762756
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range(256):
        for b in range(256):
            c = rijndael_mul(a, b)
            assert(c == RIJNDAEL_EXP_TABLE[(RIJNDAEL_LOG_TABLE[a] + RIJNDAEL_LOG_TABLE[b]) % 0xFF])



# Generated at 2022-06-24 11:24:02.254732
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_cipher import aes_encrypt
    from .aes_counter import AESCounter

    def xor(a, b):
        # a, b are intlists
        return [ia ^ ib for (ia, ib) in zip(a, b)]

    # Test Vectors, from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # 128 bit key
    key = bytes_to_intlist(compat_b64decode(b'GZy6sIZ6wl9NJOKB-jnmVg'))
    # Message to be encrypted
    pt = bytes_to_intlist(b'Single block msg')
    # Init. vector

# Generated at 2022-06-24 11:24:10.301802
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x00, 0x01, 0x02, 0x03,
            0x10, 0x11, 0x12, 0x13,
            0x20, 0x21, 0x22, 0x23,
            0x30, 0x31, 0x32, 0x33,
            0x40, 0x41, 0x42, 0x43,
            0x50, 0x51, 0x52, 0x53,
            0x60, 0x61, 0x62, 0x63,
            0x70, 0x71, 0x72, 0x73]
    print(shift_rows_inv(data))



# Generated at 2022-06-24 11:24:16.718982
# Unit test for function inc
def test_inc():
    assert inc([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x01]
    assert inc([0x00, 0x00, 0x00, 0xFF]) == [0x00, 0x00, 0x01, 0x00]
    assert inc([0x00, 0x00, 0xFF, 0xFF]) == [0x00, 0x01, 0x00, 0x00]
    assert inc([0x00, 0xFF, 0xFF, 0xFF]) == [0x01, 0x00, 0x00, 0x00]
    assert inc([0xFF, 0xFF, 0xFF, 0xFF]) == [0x00, 0x00, 0x00, 0x00]
test_inc()

# Generated at 2022-06-24 11:24:24.858012
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = '140b41b22a29beb4061bda66b6747e14'.decode('hex')
    data = '4ca00ff4c898d61e1edbf1800618fb2828a226d160dad07883d04e008a7897ee2e4b7465d5290d0c0e6c6822236e1daafb94ffe0c5da05d9476be028ad7c1d81'.decode('hex')
    ctr = Counter(bytes_to_intlist(compat_b64decode('CzkSVp1/Et4b/G2B4C4X3g==')))
    assert aes_ctr_decrypt(bytes_to_intlist(data), bytes_to_intlist(key), ctr) == bytes_to

# Generated at 2022-06-24 11:24:35.615520
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    """
    >>> test_sub_bytes_inv()
    Testing sub_bytes_inv()... Passed.
    """

    print("Testing sub_bytes_inv()...", end="")
    data = sub_bytes_inv(sub_bytes([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]))
    assert data == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]

    data = sub_bytes_inv(sub_bytes([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 1, 2, 3, 4, 5]))

# Generated at 2022-06-24 11:24:39.112727
# Unit test for function xor
def test_xor():
    x = [1, 2, 3, 4, 5, 6, 7, 8]
    y = [8, 7, 6, 5, 4, 3, 2, 1]
    z = [9, 9, 9, 9, 9, 9, 9, 9]
    assert xor(x,y) == z


# Generated at 2022-06-24 11:24:41.502179
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]

# Generated at 2022-06-24 11:24:46.493338
# Unit test for function inc
def test_inc():
    assert inc([1, 2, 3, 4]) == [1, 2, 3, 5]
    assert inc([1, 2, 3, 255]) == [1, 2, 4, 0]
    assert inc([1, 2, 255, 255]) == [1, 3, 0, 0]
    assert inc([1, 255, 255, 255]) == [2, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-24 11:24:54.241364
# Unit test for function inc
def test_inc():
    data = [255, 0, 0, 0]
    assert inc(data) == [0, 0, 0, 1]
    data = [0, 0, 0, 0]
    assert inc(data) == [0, 0, 0, 1]
    data = [0, 0, 0, 255]
    assert inc(data) == [0, 0, 1, 0]
    data = [255, 255, 255, 255]
    assert inc(data) == [0, 0, 0, 0]



# Generated at 2022-06-24 11:25:01.409208
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test_data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected_result = [0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert(expected_result == mix_columns_inv(test_data))



# Generated at 2022-06-24 11:25:06.564561
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data_test = [0x54, 0x77, 0x6F, 0x20, 0x4F, 0x6E, 0x65, 0x20, 0x4E, 0x69, 0x6E, 0x65, 0x20, 0x54, 0x77, 0x6F]
    shifted = shift_rows(data_test)
    print([hex(x) for x in shifted])
    unshifted = shift_rows_inv(shifted)
    print([hex(x) for x in unshifted])



# Generated at 2022-06-24 11:25:17.779998
# Unit test for function key_expansion
def test_key_expansion():
    key = [143, 194, 34, 208, 145, 203, 230, 143, 177, 246, 97, 206, 145, 92, 255, 84]

# Generated at 2022-06-24 11:25:20.443771
# Unit test for function rijndael_mul
def test_rijndael_mul():
    a = 0x57
    b = 0x83
    expected_cipher = 0xf2
    actual_cipher = rijndael_mul(a, b)

    assert actual_cipher == expected_cipher, "Actual cipher value is " + hex(actual_cipher)



# Generated at 2022-06-24 11:25:33.837372
# Unit test for function aes_decrypt
def test_aes_decrypt():
	
	f = open("aes_test_dec.txt","rb")
	test_bytes = intlist_to_bytes(bytes_to_intlist(f.read()))
	f.close()
	key = bytes_to_intlist(compat_b64decode("YzY2YjI0YzM2NTZmODk1YjE3NGM3ZjhlMzk3OGYyYTk="))
	expanded_key = key_expansion(key)
	result_cipher = intlist_to_bytes(aes_decrypt(bytes_to_intlist(test_bytes), expanded_key))
	print("[+] test_aes_decrypt:								Passed")

# Generated at 2022-06-24 11:25:43.049400
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    test_vectors = [([0x19, 0xa0, 0x9a, 0xe9,
                      0x3d, 0xf4, 0xc6, 0xf8,
                      0xe3, 0xe2, 0x8d, 0x48,
                      0xbe, 0x2b, 0x2a, 0x08],
                     [0x19, 0xa0, 0x9a, 0xe9,
                      0xbe, 0x2b, 0x2a, 0x08,
                      0xe3, 0xe2, 0x8d, 0x48,
                      0x3d, 0xf4, 0xc6, 0xf8])]
    for test_vector in test_vectors:
        ciphertext = test_vector[0]
        expected_plaintext = test_vector[1]



# Generated at 2022-06-24 11:25:50.672253
# Unit test for function rotate
def test_rotate():
	assert rotate([0,1,2,3,4])==[1,2,3,4,0]
	assert rotate([1,2,3,4,0])==[2,3,4,0,1]
	assert rotate([2,3,4,0,1])==[3,4,0,1,2]
	assert rotate([3,4,0,1,2])==[4,0,1,2,3]
	assert rotate([4,0,1,2,3])==[0,1,2,3,4]


# Generated at 2022-06-24 11:25:52.678011
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert mix_columns_inv(mix_columns([2, 3, 1, 1])) == [2, 3, 1, 1]



# Generated at 2022-06-24 11:25:58.719237
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns(data)
    expected = [0x8E, 0x4D, 0xA1, 0xBC, 0x9F, 0xDC, 0x58, 0x9D, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    if result != expected:
        print('FAIL: test_mix_columns')
        print('Input:', data)
        print('Result:', result)

# Generated at 2022-06-24 11:26:06.723017
# Unit test for function aes_decrypt
def test_aes_decrypt():
    def test(data, expanded_key, expected):
        actual = aes_decrypt(data, expanded_key)
        assert actual == expected, 'Expected: %s\nActual:   %s' % (expected, actual)

    # https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38a.pdf
    # Appendix F (p.51)
    expected = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]

# Generated at 2022-06-24 11:26:14.934402
# Unit test for function key_expansion
def test_key_expansion():
    test1_input = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-24 11:26:24.226808
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    """Test for shift_rows_inv function"""
    print("Test for function shift_rows_inv: ")
    test_vector = [0x63, 0xCA, 0xB7, 0x04, 0x09, 0x53, 0xD0, 0x51, 0xCD, 0x60, 0xE0, 0xE7, 0xBA,
                   0x70, 0xE1, 0x8C, 0x7F, 0x4E, 0xF2, 0x4B, 0xC3, 0xD1, 0x81, 0x20, 0xDA, 0xE2, 0x17, 0x5F, 0x7C, 0xA1]
    result = shift_rows_inv(test_vector)
    print("Test vector: ", test_vector)
   

# Generated at 2022-06-24 11:26:32.954456
# Unit test for function mix_columns
def test_mix_columns():
    input = [0x63, 0xeb, 0x9f, 0xa0, 0x30, 0x2f, 0xfc, 0xaa, 0x66, 0xcb, 0xf8,
             0x71, 0x8d, 0x6d, 0x81, 0x9d]
    output = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x5f, 0x18, 0x2e, 0x93, 0x39,
              0x2d, 0x38, 0x15, 0xb3, 0x28]
    assert mix_columns(input) == output
    assert mix_columns(input, MIX_COLUMN_MATRIX_INV) == input
test_mix_columns()



# Generated at 2022-06-24 11:26:38.720078
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    assert data_mixed == [0x8e, 0x4d, 0xa1, 0xbc]
    data_mixed = mix_column(data_mixed, MIX_COLUMN_MATRIX_INV)
    assert data_mixed == [0xdb, 0x13, 0x53, 0x45]



# Generated at 2022-06-24 11:26:45.232784
# Unit test for function mix_columns
def test_mix_columns():
    input = [0xdb, 0x13, 0x53, 0x45,
             0xf2, 0x0a, 0x22, 0x5c,
             0x01, 0x01, 0x01, 0x01,
             0xab, 0xab, 0xab, 0xab]
    output = [0x8e, 0x4d, 0xa1, 0xbc,
              0x9f, 0xdc, 0x58, 0x9d,
              0x01, 0x01, 0x01, 0x01,
              0xe5, 0x38, 0x32, 0x7a]

    assert mix_columns(input) == output, "Unit test for function mix_columns failed"


test_mix_columns()



# Generated at 2022-06-24 11:26:47.701788
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(SBOX) == [x for x in range(256)]



# Generated at 2022-06-24 11:26:53.886460
# Unit test for function inc
def test_inc():
    print("Testing inc:")
    print(inc([0x11, 0xfe, 0xaa, 0x11]))
    print(inc([0x11, 0xfe, 0xab, 0x10]))
    print(inc([0xff, 0xff, 0xff, 0xff]))
    print(inc([0x00, 0x00, 0x00, 0x00]))



# Generated at 2022-06-24 11:26:57.468488
# Unit test for function rotate
def test_rotate():
    data = [0x63, 0xca, 0xb7, 0x04]
    expected = [0xca, 0xb7, 0x04, 0x63]
    rotated = rotate(data)
    print

# Generated at 2022-06-24 11:27:07.081300
# Unit test for function key_schedule_core
def test_key_schedule_core():
    input_str_1 = bytes.fromhex("000102030405060708090a0b0c0d0e0f")
    input_bytes_1 = [input_str_1[i] for i in range(16)]

    assert key_schedule_core(input_bytes_1, 1) == [0x53, 0xef, 0x96, 0x20, 0xa4, 0xba, 0xd5, 0x31,
                                                   0x2b, 0x69, 0xf8, 0x50, 0xd2, 0x9b, 0x2a, 0x6f]

    input_str_2 = bytes.fromhex("d6aa74fdd2af72fadaa678f1d6ab76fe")

# Generated at 2022-06-24 11:27:20.301680
# Unit test for function inc
def test_inc():
    print("Testing inc...")
    cases = [
        ([0, 0, 0, 0], [0, 0, 0, 1]),
        ([0xFF, 0xFF, 0xFF, 0xFF], [0, 0, 0, 0]),
        ([0xFF, 0xFF, 0xFF, 0xFE], [0xFF, 0xFF, 0xFF, 0xFF]),
        ([0xAB, 0xBC, 0xCD, 0xD9], [0xAB, 0xBC, 0xCD, 0xDA]),
    ]
    for (plain, expected_result) in cases:
        result = inc(plain)
        if result == expected_result:
            print("Success: inc({}) -> {}".format(plain, result))

# Generated at 2022-06-24 11:27:25.166702
# Unit test for function rotate
def test_rotate():
    global rotate

# Generated at 2022-06-24 11:27:33.861508
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .utils import lz_string_decompress
    from .aes import aes_cbc_decrypt, AesCounter

    from .compat import compat_urlparse
    from .compat import compat_urllib_parse_urlparse

    url = 'https://www.youtube.com/watch?v=GjmeyNN8r_M'
    queries = compat_urlparse.parse_qs(
        compat_urllib_parse_urlparse.urlparse(url).query)
    cipher = bytes_to_intlist(
        compat_b64decode(queries['c'][0].encode('utf-8')))
    cipher = lz_string_decompress(''.join([chr(i) for i in cipher]))

# Generated at 2022-06-24 11:27:42.945865
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data_in = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_out = [0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0xab, 0x49, 0x6e, 0xfd, 0x4b, 0xf3, 0x30, 0xb5]
    assert mix_columns_inv(data_in) == data_out



# Generated at 2022-06-24 11:27:51.654413
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Encrypt and decrypt with key_size=24 and verify if results are the same.
    """
    import math

    TEXT = """
        Lorem Ipsum is simply dummy text of the printing and typesetting industry.
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
        when an unknown printer took a galley of type and scrambled it to make a type
        specimen book. It has survived not only five centuries, but also the leap into
        electronic typesetting, remaining essentially unchanged. It was popularised in
        the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
        and more recently with desktop publishing software like Aldus PageMaker
        including versions of Lorem Ipsum.
    """
    PASSWORD = "password"

    KEY_SIZE = 24


# Generated at 2022-06-24 11:28:02.056596
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv([0x10, 0x20, 0x30, 0x40, 0x50, 0x60, 0x70, 0x80, 0x90, 0xa0, 0xb0, 0xc0, 0xd0, 0xe0, 0xf0, 0x00]) == [0x10, 0x20, 0x30, 0x40, 0x50, 0x60, 0x70, 0x80, 0x90, 0xa0, 0xb0, 0xc0, 0xd0, 0xe0, 0xf0, 0x00]

# Generated at 2022-06-24 11:28:12.888331
# Unit test for function key_expansion

# Generated at 2022-06-24 11:28:24.199167
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x32, 0x88, 0x31, 0xe0,
            0x43, 0x5a, 0x31, 0x37,
            0xf6, 0x30, 0x98, 0x07,
            0xa8, 0x8d, 0xa2, 0x34]
    golden = [0x32, 0x88, 0x31, 0xe0,
              0x43, 0x5a, 0x31, 0x37,
              0xf6, 0x30, 0x98, 0x07,
              0xa8, 0x8d, 0xa2, 0x34]
    assert shift_rows(data) == golden

test_shift_rows()

# Generated at 2022-06-24 11:28:31.550162
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * 16)

    plaintext = b'X' * 32 + b'Y' * 16 + b'Z' * 15
    cipher = aes_cbc_encrypt(bytes_to_intlist(plaintext), key, iv)

# Generated at 2022-06-24 11:28:42.865356
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import unittest
    from .utils import intlist_to_bytes
    from .compat import compat_b64encode

    class TestAesDecryptText(unittest.TestCase):
        def test_aes_decrypt_text(self):
            data = 'K4Y4W4Y'
            encrypted_data = 'lA8zDZHfvZhKPQF5x5Kjdw=='
            password = 'passwd'
            key_size_bytes = 16  # 128-Bit
            decrypted_data = aes_decrypt_text(encrypted_data, password, key_size_bytes)
            self.assertEqual(decrypted_data.decode('utf-8'), data)

    unittest.main()

# Generated at 2022-06-24 11:28:47.141645
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    result = aes_decrypt_text(b'f1d2d2f924e986ac86fdf7b36c94bcdf82f9', 'password', 16)
    assert result == b'This is some plaintext!'



# Generated at 2022-06-24 11:28:59.086425
# Unit test for function mix_columns_inv

# Generated at 2022-06-24 11:29:01.812682
# Unit test for function key_expansion
def test_key_expansion():
    key = list(range(0, 16))
    expected = list(range(0, 240))
    assert key_expansion(key) == expected


# Generated at 2022-06-24 11:29:10.686894
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert mix_columns_inv([0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]) == [0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]

# Generated at 2022-06-24 11:29:20.270599
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    cleartext = bytes_to_intlist('0102030405060708090a0b0c0d0e0f102122232425262728292a2b2c2d2e2f303132333435363738393a3b3c3d3e3f')
    cipherkey = bytes_to_intlist('000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f')
    iv = bytes_to_intlist('202122232425262728292a2b2c2d2e2f303132333435363738393a3b3c3d3e3f')


# Generated at 2022-06-24 11:29:27.211708
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AesCounter
    counter = AesCounter(intlist_to_bytes(bytes_to_intlist(compat_b64decode('qT7uB9ndWwk='))))
    key = bytes_to_intlist(compat_b64decode('zJjDLCZRQhl9Xkdq7OjKlA=='))

# Generated at 2022-06-24 11:29:31.237042
# Unit test for function inc
def test_inc():
    print("Unit test for function inc")
    data = [0, 255, 255]
    print("Input: {}".format(data))
    print("Expected output: [1, 0, 0]")
    result = inc(data)
    print("Result: {}".format(result))
    assert(result == [1, 0, 0])



# Generated at 2022-06-24 11:29:38.441622
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    TEST_VALUES = {
        "https://example.com/example.html": "",
        "http://example.com/example.html": "",
        "http://example.com/": "",
        "http://example.com/?q=%s": "",
        "http://example.com/search": "",
        "http://example.com/video/%s/get-info": "",
        "http://example.com/v/%s": "",
        "http://example.com/v/%s?el=embedded&ps=default&eurl=&gl=US&hl=en": ""}

# Generated at 2022-06-24 11:29:48.485755
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .jsontools import jsontools
    import json

    # Test vectors from Wikipedia
    # https://en.wikipedia.org/wiki/Block_cipher_mode_of_operation#Counter_.28CTR.29

    def get_counter():
        c = 0
        while True:
            yield [c & 0xFF, (c >> 8) & 0xFF, (c >> 16) & 0xFF, (c >> 24) & 0xFF,
                   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            c += 1
    counter = get_counter()

    def test_vector(key, encrypted, plaintext):
        key = bytes_to_intlist(compat_b64decode(key))

# Generated at 2022-06-24 11:29:50.012306
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    for i in range(0, 256):
        assert i == SBOX_INV[SBOX[i]]



# Generated at 2022-06-24 11:29:56.707971
# Unit test for function aes_encrypt
def test_aes_encrypt():
    from .utils import u8, u32, dehex

    print(u8(aes_encrypt(dehex('00112233445566778899aabbccddeeff'), dehex('000102030405060708090A0B0C0D0E0F101112131415161718191A1B1C1D1E1F'))))

# Generated at 2022-06-24 11:30:08.136914
# Unit test for function inc
def test_inc():
    assert inc([0]) == [1]
    assert inc([254]) == [255]
    assert inc([255]) == [0]
    assert inc([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 6]
    assert inc([1, 2, 3, 4, 255]) == [1, 2, 3, 5, 0]
    assert inc([1, 2, 3, 255, 255]) == [1, 2, 4, 0, 0]
    assert inc([1, 2, 255, 255, 255]) == [1, 3, 0, 0, 0]
    assert inc([1, 255, 255, 255, 255]) == [2, 0, 0, 0, 0]
    assert inc([255, 255, 255, 255, 255]) == [0, 0, 0, 0, 0]



# Generated at 2022-06-24 11:30:15.907337
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    # xor = 0x84204d13
    # print(hex(xor))
    # for x in range(256):
    #     for y in range(256):
    #         for z in range(256):
    #             for w in range(256):
    #                 if x ^ y ^ z ^ w == xor:
    #                     print(x, y, z, w)
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX_INV)

# Generated at 2022-06-24 11:30:20.397065
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    import binascii
    cleartext = bytes_to_intlist(b'Here is some data for the encrypt')
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    encrypted = aes_cbc_encrypt(cleartext, key, iv)
    encrypted_hex = binascii.hexlify(bytearray(encrypted))
    expected_encrypted_hex = b'29c3505f571420f6402299b31a02d73a00000000000000000000000000000000'

    assert encrypted_hex == expected_encrypted_hex



# Generated at 2022-06-24 11:30:30.569300
# Unit test for function mix_columns
def test_mix_columns():
    # Test 1
    str1 = [0xdb, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    expected1 = [0xdd, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    assert test_mix_columns_helper(str1, expected1)

    # Test 2
    str2 = [0x47, 0x75, 0xe0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    expected2 = [0x47, 0x15, 0x13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

# Generated at 2022-06-24 11:30:34.784667
# Unit test for function rijndael_mul
def test_rijndael_mul():
    # Non-zero test
    assert rijndael_mul(0x57, 0x83) == 0xC1
    # Zero test
    assert rijndael_mul(0x57, 0x00) == 0x00
    print('Passed')


# Generated at 2022-06-24 11:30:43.222296
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    S_TEST = '{"key":"quirky and unapologetic","iv":"838053a30f9c6f22","data":"xlxztiJhq3YfKjF6n0PcjQSP0qf3+A3uJ7e8/2831uYFsv5YJWF5M7Lio0g+bNcSj39v0H/pW8x/OO+g4jywvQ=="}'
    key = bytes_to_intlist(compat_b64decode(S_TEST['key']))
    iv = bytes_to_intlist(compat_b64decode(S_TEST['iv']))
    data = bytes_to_intlist(compat_b64decode(S_TEST['data']))

# Generated at 2022-06-24 11:30:53.633380
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(bytes(range(16)))
    key_expanded = key_expansion(key)
    assert len(key_expanded) == 176
    assert key_expanded[:16] == key

    key = bytes_to_intlist(bytes(range(16)) + bytes(range(24)))
    key_expanded = key_expansion(key)
    assert len(key_expanded) == 208
    assert key_expanded[:24] == key

    key = bytes_to_intlist(bytes(range(16)) + bytes(range(24)) + bytes(range(32)))
    key_expanded = key_expansion(key)
    assert len(key_expanded) == 240
    assert key_expanded[:32] == key



# Generated at 2022-06-24 11:31:02.803449
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key16 = bytes_to_intlist(compat_b64decode(b'6e2e191556d3166a38813cbf42cfce6e'))
    key24 = bytes_to_intlist(compat_b64decode(b'6e2e191556d3166a38813cbf42cfce6e14fecabef1a9b9e'))
    key32 = bytes_to_intlist(compat_b64decode(b'6e2e191556d3166a38813cbf42cfce6e14fecabef1a9b9e6ab07b0ff9b2d2158'))

# Generated at 2022-06-24 11:31:04.497850
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57,0x83) == 0xc1

# Generated at 2022-06-24 11:31:13.342429
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # aes_decrypt test
    # Ciphertext: 656c4b4f1f4c2974ab66d6c8e633b2c2
    # Key:        abb8f6ddbdc6ccce34467713bde6dccd
    cipher = bytes_to_intlist(compat_b64decode(b'ZmxhZ3t5b3VyX3VuZGV0ZXJtaW5lZF9mcmVlZG9tX2lzX21vcmVfY29tcGxleF90aGFuX2NvbXBsZXhfZnJlZWRvbX08L2ZsYWc+'))

# Generated at 2022-06-24 11:31:17.518375
# Unit test for function sub_bytes
def test_sub_bytes():
    see_t = '00' * 128
    for i in range(16):
        see_t += ' %02x' % SBOX[i]
    assert(binascii.hexlify(bytes(sub_bytes([x for x in range(16)]))) == see_t)


# Generated at 2022-06-24 11:31:28.223993
# Unit test for function sub_bytes