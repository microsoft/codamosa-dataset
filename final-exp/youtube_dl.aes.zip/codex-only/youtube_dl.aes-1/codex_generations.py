

# Generated at 2022-06-24 11:21:38.039005
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test vector from NIST SP 800-38A, Appendix F.3 CBC-AES256.Encrypt
    key = bytes_to_intlist(compat_b64decode(
        'Vf9Tl7VQ2Bsw/NGlIIDMlP0/FJ2EF/A+6UeLyhiU/uY='))
    iv = bytes_to_intlist(compat_b64decode('R0o+WH2yX1Yj0aAi1zUcgA=='))

# Generated at 2022-06-24 11:21:45.828008
# Unit test for function mix_columns
def test_mix_columns():
    mix_column_vector = mix_column([0x02, 0x03, 0x01, 0x01], MIX_COLUMN_MATRIX)
    assert mix_column_vector == [0x04, 0x0E, 0x0E, 0x0B]
    input_data = [0x02, 0x03, 0x01, 0x01, 0x01, 0x02, 0x03, 0x01, 0x01, 0x01, 0x02, 0x03, 0x03, 0x01, 0x01, 0x02]

# Generated at 2022-06-24 11:21:53.331802
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * BLOCK_SIZE_BYTES)
    data = b'\x01'*BLOCK_SIZE_BYTES
    encrypted = aes_cbc_encrypt(bytes_to_intlist(data), key, iv)
    encrypted = intlist_to_bytes(encrypted)
    # print(encrypted.hex())
    assert encrypted == b'\x35\x8f\x1f\x20\xd9\xc2\xce\xe3\x89\x3b\xbd\x87\xee\x9e\xd3\xda'


# Generated at 2022-06-24 11:21:55.725665
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    a = [0x19, 0xa0, 0x9a, 0xe9]
    b = sub_bytes_inv(a)
    c = [0x32, 0x88, 0x31, 0xe0]
    assert b == c
test_sub_bytes_inv()

# Generated at 2022-06-24 11:21:57.385922
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3,4]) == [2,3,4,1]
    assert rotate([1]) == [1]
    assert rotate([]) == []



# Generated at 2022-06-24 11:21:59.996487
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x1F, 0xC5]) == [0x5A, 0x18]

# Rijndael adds 2^8 to the sub_bytes value, then XORs the previous sub_bytes
# and the next sub_bytes.

# Generated at 2022-06-24 11:22:05.180562
# Unit test for function sub_bytes
def test_sub_bytes():
    test_data = [0x00, 0x01, 0x02, 0x03,
                 0x04, 0x05, 0x06, 0x07,
                 0x08, 0x09, 0x0a, 0x0b,
                 0x0c, 0x0d, 0x0e, 0x0f]
    expect_data = [0x63, 0x7c, 0x77, 0x7b,
                   0xf2, 0x6b, 0x6f, 0xc5,
                   0x30, 0x01, 0x67, 0x2b,
                   0xfe, 0xd7, 0xab, 0x76]
    result = sub_bytes(test_data)
    print('Test SubBytes:', result == expect_data)



# Generated at 2022-06-24 11:22:16.643241
# Unit test for function rijndael_mul

# Generated at 2022-06-24 11:22:20.651631
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x54, 0x77, 0x6F, 0x20]
    expected = [0x75, 0xF4, 0xC6, 0x1F]
    ksc = key_schedule_core(data, 1)
    assert ksc == expected


# Generated at 2022-06-24 11:22:25.133237
# Unit test for function aes_encrypt
def test_aes_encrypt():
    test_data = "hello"
    clear_data = test_data.encode()
    key_data = "thomasmore".encode()
    clear_data = bytes_to_intlist(clear_data)    
    key_data = bytes_to_intlist(key_data)
    key_expanded = key_expansion(key_data)
    cipher_data = aes_encrypt(clear_data,key_expanded)
    cipher_data = intlist_to_bytes(cipher_data)
    cipher_data = compat_b64decode(cipher_data)
    print("Original data:")
    print(test_data)
    print("Cipher data:")
    print(cipher_data)
    return cipher_data



# Generated at 2022-06-24 11:22:36.354419
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = '140b41b22a29beb4061bda66b6747e14'.decode('hex')
    iv = '4ca00ff4c898d61e1edbf1800618fb28'.decode('hex')
    data = ['28a226d160dad07883d04e008a7897ee'.decode('hex')]
    decrypted_data = aes_cbc_decrypt(data, key, iv)
    assert decrypted_data == '000102030405060708090a0b0c0d0e0f'.decode('hex')



# Generated at 2022-06-24 11:22:45.481287
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    DATA = list('abcdefghijklmnop')
    DATA_INT2 = list('abcdefghijklmnop')

    key = bytes_to_intlist('YELLOW SUBMARINE')
    counter = Counter(intlist_to_bytes(bytes_to_intlist('\x00\x00\x00\x00\x00\x00\x00\x00')))

    ct = aes_ctr_decrypt(DATA, key, counter)
    assert ct == DATA_INT2
    print('OK: aes_ctr_decrypt')
test_aes_ctr_decrypt()

print('\n\n')



# Generated at 2022-06-24 11:22:54.111028
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0] * 16
    expanded_key = [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    result = aes_encrypt(data, expanded_key)
    expected_result = [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    assert result == expected_result
    data = [0] * 16

# Generated at 2022-06-24 11:22:56.194732
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print("Unit test for rijndael_mul...")
    assert rijndael_mul(0x57, 0x83) == 0xC1
    print("Passed!")


# Generated at 2022-06-24 11:23:07.521921
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes(16)
    iv = bytes(16)
    data = "This is a secret message!\x08\x08\x08\x08\x08\x08\x08\x08"
    encrypted_data = aes_cbc_encrypt(bytes_to_intlist(data), bytes_to_intlist(key), bytes_to_intlist(iv))

# Generated at 2022-06-24 11:23:12.097992
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0xa4, 0xfb, 0xcf, 0x7c]
    data_mixed = mix_columns(data)
    data_mixed_expected = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0xdd, 0x7d, 0xd3, 0x0b]
    return data_mixed_expected == data_mixed

test_mix_columns()


# Generated at 2022-06-24 11:23:19.003702
# Unit test for function key_expansion
def test_key_expansion():
    import random
    key = bytes_to_intlist(random.randrange(0, 256**16).to_bytes(16, "big"))
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176
    assert expanded_key[len(expanded_key) - 16: ] == key

    key = bytes_to_intlist(random.randrange(0, 256**24).to_bytes(24, "big"))
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 208
    assert expanded_key[len(expanded_key) - 24: ] == key

    key = bytes_to_intlist(random.randrange(0, 256**32).to_bytes(32, "big"))
    expanded_key = key_expansion(key)

# Generated at 2022-06-24 11:23:24.934449
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    data = [0x63, 0xCA, 0xB7, 0x04, 0x09, 0x53, 0xD0, 0x51, 0xCD, 0x60, 0xE0, 0xE7, 0xBA, 0x70, 0xE1, 0x8C]
    assert sub_bytes_inv(data) == [0x53, 0xD1, 0x87, 0x40, 0x4E, 0xD8, 0xAE, 0xF9, 0x5F, 0xA0, 0x3A, 0x93, 0xD7, 0xC1, 0x22, 0x13]

# Generated at 2022-06-24 11:23:28.732934
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x54, 0x77, 0x6F, 0x20]
    rcon_iteration = 1
    
    assert key_schedule_core(data, rcon_iteration) == [0xE0, 0x37, 0x7F, 0xB1]
test_key_schedule_core()



# Generated at 2022-06-24 11:23:30.556092
# Unit test for function sub_bytes
def test_sub_bytes():
    x = [0x19, 0xa0, 0x9a, 0xe9]
    assert sub_bytes(x) == [0xd4, 0xe0, 0xb8, 0x1e]



# Generated at 2022-06-24 11:23:39.147118
# Unit test for function mix_columns
def test_mix_columns():
    assert mix_columns([0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]) == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]



# Generated at 2022-06-24 11:23:44.991175
# Unit test for function shift_rows
def test_shift_rows():
    assert shift_rows([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]) == (
        [1, 2, 3, 4, 6, 7, 8, 5, 11, 12, 13, 9, 15, 16, 14, 10])



# Generated at 2022-06-24 11:23:57.012702
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = "1a52b7cf8c869b52de7590aba724e1d6"
    key = bytes_to_intlist(compat_b64decode(key))
    data = "3f84c6f2ce6b95e6"
    data = bytes_to_intlist(compat_b64decode(data))
    info = "c43a0a9d0e165abf56cc2f2c8d8b2a37"
    info = bytes_to_intlist(compat_b64decode(info))

# Generated at 2022-06-24 11:24:05.372964
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = '2b7e151628aed2a6abf7158809cf4f3c'
    iv = '000102030405060708090a0b0c0d0e0f'
    data = '7649abac8119b246cee98e9b12e9197d8964e0b149c10b7b682e6e39aaeb731c'
    plain = '6bc1bee22e409f96e93d7e117393172a'

    output = aes_cbc_decrypt(bytes_to_intlist(compat_b64decode(data)), bytes_to_intlist(compat_b64decode(key)),
                             bytes_to_intlist(compat_b64decode(iv)))


# Generated at 2022-06-24 11:24:15.976443
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b'1234567890123456')
    key = bytes_to_intlist(b'1234567890123456')
    iv = bytes_to_intlist(b'abcdefghijklmnop')
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == b'\xf3a\xc7\x1e\x9c\'\x171\x91\x15\x04S\xe4\xfe\x1b\x18\xef\x9f\xe0\x1f^\x19'
    print('Success!')

# Generated at 2022-06-24 11:24:26.213312
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test vector from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-24 11:24:33.971691
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x1, 0x2, 0x3, 0x4]) == [0x63, 0x7C, 0x77, 0x7B]
    assert sub_bytes([0x19, 0xA0, 0x9A, 0xE9]) == [0xD4, 0x27, 0x11, 0xAE]

# Input:  data = 4-byte array
# Output: data = 4-byte array

# Generated at 2022-06-24 11:24:39.236764
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x00, 0x04, 0x08, 0x0c]
    data = key_schedule_core(data, 1)
    print('Test key_schedule_core:')
    print(data)
    if data == [0x05, 0x0c, 0x02, 0x0f]:
        print('Test key_schedule_core: Success')
    else:
        print('Test key_schedule_core: Failure')



# Generated at 2022-06-24 11:24:42.624631
# Unit test for function inc
def test_inc():
    data = [0, 0, 0]
    assert list(inc(data)) == [0, 0, 1]

    data = [0, 0, 255]
    assert list(inc(data)) == [0, 1, 0]

    data = [255, 255, 255]
    assert list(inc(data)) == [0, 0, 0]



# Generated at 2022-06-24 11:24:45.860156
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert key_schedule_core([2, 3, 4, 5], 1) == [5, 98, 46, 3]
    assert key_schedule_core([5, 98, 46, 3], 2) == [3, 5, 98, 46]
    return True



# Generated at 2022-06-24 11:24:48.091167
# Unit test for function xor
def test_xor():
    data1 = [1, 0]
    data2 = [0, 1]
    result = xor(data1, data2)
    assert (result == [1, 1])
    return



# Generated at 2022-06-24 11:24:57.651937
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    def assert_aes_cbc_decrypt(data, key, iv, expected):
        data = bytes_to_intlist(compat_b64decode(data))
        key = bytes_to_intlist(compat_b64decode(key))
        iv = bytes_to_intlist(compat_b64decode(iv))
        expected = bytes_to_intlist(compat_b64decode(expected))
        actual = aes_cbc_decrypt(data, key, iv)
        assert actual == expected

    # This is an example where mcrypt is wrong and OpenSSL is right
    # See #927 and #914

# Generated at 2022-06-24 11:25:01.001870
# Unit test for function rotate
def test_rotate():
    nums = list(range(10))
    for _ in range(10):
        nums = rotate(nums)
    assert nums == list(range(10)), "rotate failed"
    print("rotate test passed!")



# Generated at 2022-06-24 11:25:08.750531
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0x100):
        for j in range(0x100):
            assert rijndael_mul(i, j) == gmul(i, j)
test_rijndael_mul()


# Generated at 2022-06-24 11:25:17.384257
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb]) == [0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]
# End test for function sub_bytes



# Generated at 2022-06-24 11:25:28.806187
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 1) == [0x01, 0x03, 0x04, 0x0C]
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 2) == [0x01, 0x04, 0x07, 0x07]
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 3) == [0x01, 0x05, 0x0a, 0x0e]
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 4) == [0x01, 0x06, 0x0f, 0x08]

# Generated at 2022-06-24 11:25:39.317058
# Unit test for function sub_bytes
def test_sub_bytes():
    input = [0x00, 0x11, 0x22, 0x33,
             0x44, 0x55, 0x66, 0x77,
             0x88, 0x99, 0xaa, 0xbb,
             0xcc, 0xdd, 0xee, 0xff]
    output = [0x63, 0x7C, 0x77, 0x7B,
              0xF2, 0x6B, 0x6F, 0xC5,
              0x30, 0x01, 0x67, 0x2B,
              0xFE, 0xD7, 0xAB, 0x76]
    assert sub_bytes(input) == output, "sub_bytes operation failed"
    print('sub_bytes unit test passed')
test_sub_bytes()



# Generated at 2022-06-24 11:25:44.813818
# Unit test for function inc
def test_inc():
    assert(inc([255]) == [0])
    assert(inc([255, 255]) == [0, 0])
    assert(inc([0, 255, 255]) == [1, 0, 0])
    assert(inc([0, 1, 255, 255]) == [0, 2, 0, 0])



# Generated at 2022-06-24 11:25:53.803158
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = bytes_to_intlist(compat_b64decode("g5WG+8Eyw7e4IO4Fb4wxVt/9XtI/NjKq3t+e/sl52EI="))
    counter = Counter(bytes_to_intlist(compat_b64decode("pfmI1D9J0Y64ZS5oEUIm5Q==")))
    data = bytes_to_intlist(compat_b64decode("pZd3vIgEd+oOtLgG+Eq3qy+cx92/TJf/XsZQkfcZN/s="))
    assert(data == aes_ctr_decrypt(data, key, counter))


# Generated at 2022-06-24 11:26:05.612640
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    print("\n# Unit test for function aes_ctr_decrypt")
    class Counter(object):
        def __init__(self, value):
            self.value = value
        def next_value(self):
            self.value = add(self.value, [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])
            return self.value
    key1_hex = "2b7e151628aed2a6abf7158809cf4f3c"
    key1 = bytes_to_intlist(bytearray.fromhex(key1_hex))

# Generated at 2022-06-24 11:26:14.595207
# Unit test for function inc
def test_inc():
    data = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    assert inc(data) == [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01]

# Generated at 2022-06-24 11:26:19.880325
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    test_plaintext = 'hi'
    test_password = 'test'
    test_key_size_bytes = 16
    test_data = aes_encrypt_text(test_plaintext, test_password, test_key_size_bytes)
    assert(aes_decrypt_text(test_data, test_password, test_key_size_bytes) == test_plaintext)



# Generated at 2022-06-24 11:26:21.265030
# Unit test for function shift_rows
def test_shift_rows():
    state = [i for i in range(16)]
    print(state)
    state_shifted = shift_rows(state)
    print(state_shifted)



# Generated at 2022-06-24 11:26:24.774852
# Unit test for function rotate
def test_rotate():
    lst = [0,1,2,3]
    assert rotate(lst) == [1,2,3,0]
    lst = [1,2,3,4,5,6]
    assert rotate(lst) == [2,3,4,5,6,1]
    lst = [1,2]
    assert rotate(lst) == [2,1]


# Generated at 2022-06-24 11:26:28.689524
# Unit test for function key_expansion
def test_key_expansion():
    rcon_iteration = [
        0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36,
        0x6c, 0xd8, 0xab, 0x4d, 0x9a, 0x2f, 0x5e, 0xbc, 0x63, 0xc6,
        0x97, 0x35, 0x6a, 0xd4, 0xb3, 0x7d, 0xfa, 0xef, 0xc5, 0x91,
        0x39
    ]

# Generated at 2022-06-24 11:26:32.071251
# Unit test for function mix_column
def test_mix_column():
    try:
        assert(mix_column([0xdb, 0x13, 0x53, 0x45], MIX_COLUMN_MATRIX) == [0x8e, 0x4d, 0xa1, 0xbc])
    except AssertionError:
        print("test for mix_column failed")



# Generated at 2022-06-24 11:26:41.469969
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(compat_b64decode('IQ8zx2WxZv1m4t4zM9d865aWRIpv4dwCBVu/42B8sF8='))
    key = bytes_to_intlist(compat_b64decode('MV7pOnhZC8e7xuRIfwp70Q=='))
    result = aes_encrypt(data, key)
    assert result == [232, 245, 245, 16,
                      24, 64, 131, 26,
                      49, 48, 14, 33,
                      86, 195, 11, 140]
#test_aes_encrypt()



# Generated at 2022-06-24 11:26:50.967553
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv([0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb]) == [0x39, 0x02, 0xdc, 0x19, 0x25, 0xdc, 0x11, 0x6a, 0x84, 0x09, 0x85, 0x0b, 0x1d, 0xfb, 0x97, 0x32]



# Generated at 2022-06-24 11:26:59.575973
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-24 11:27:05.414954
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]
    assert mix_column(data, MIX_COLUMN_MATRIX) == [0x8e, 0x4d, 0xa1, 0xbc]



# Generated at 2022-06-24 11:27:11.492287
# Unit test for function mix_columns
def test_mix_columns():
    result = mix_columns([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])
    assert result == [4, 11, 10, 5, 7, 8, 15, 12, 6, 3, 13, 14, 9, 10, 11, 16], \
        "Mix_columns function is not correct, got {}".format(
            result)
    print("Mix_columns test passed.")



# Generated at 2022-06-24 11:27:18.660379
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key = [0x00, 0x00, 0x00, 0x02]
    rcon_iteration = 1
    expected = [0x00, 0x00, 0x1C, 0x02]
    result = key_schedule_core(key, rcon_iteration)
    if result == expected:
        print("Test for key_schedule_core(): PASS")
    else:
        print("Test for key_schedule_core(): FAIL")
#test_key_schedule_core()



# Generated at 2022-06-24 11:27:25.237535
# Unit test for function xor
def test_xor():
    a = [0x5A, 0x6D, 0x36, 0xDD]
    b = [0x85, 0x9A, 0xC2, 0x26]
    c = [0xdf, 0xf7, 0xf4, 0xfb]
    expected = [0xdb, 0xfd, 0xd2, 0xd9]
    assert (xor(a,b) == expected)
    assert (xor(a,c) == xor(expected,c))
    print('test_xor PASSED')
test_xor()



# Generated at 2022-06-24 11:27:33.920956
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = b'\x00' * 16
    iv = b'\x00' * 16
    data = b'\x00' * 16
    assert aes_cbc_encrypt(data, key, iv) == b'\x66\xe9\x4b\xd4\xef\x8a\x2c\x3b\x88\x4c\xfa\x59\xca\x34\x2b\x2e'
    data = b'\x00' * 15 + b'a'

# Generated at 2022-06-24 11:27:43.098633
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x63, 0xeb, 0x9f, 0xa0, 0x30, 0xc1, 0x76, 0xab, 0x84, 0x31, 0x95, 0x17, 0x67, 0x15, 0x94, 0x16]
    expected = [0x63, 0xeb, 0x9f, 0xa0, 0x84, 0x31, 0x95, 0x17, 0x67, 0x15, 0x94, 0x16, 0x30, 0xc1, 0x76, 0xab]
    assert shift_rows(data) == expected

test_shift_rows()



# Generated at 2022-06-24 11:27:48.904790
# Unit test for function xor
def test_xor():
    assert xor([1, 1, 1, 1], [0, 1, 0, 1]) == [1, 0, 1, 0]


# Generated at 2022-06-24 11:27:53.453328
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 1) == [0x02, 0x04, 0x01, 0xb2]
    assert key_schedule_core([0xca, 0xfe, 0x77, 0x88], 20) == [0x41, 0x3f, 0x4b, 0x91]


# Generated at 2022-06-24 11:28:04.644230
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Unit test for function aes_decrypt_text
    """
    import hashlib

    PASSWORD = hashlib.sha256('test123').digest()
    CIPHER_TEXT = 'AAk_5aSh8m0w4fhGzE00mQ=='

    assert (
        aes_decrypt_text(CIPHER_TEXT, PASSWORD, len(PASSWORD)) ==
        b'This is a test text'
    )


# AES Constants

# Generated at 2022-06-24 11:28:10.741050
# Unit test for function inc
def test_inc():
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([255, 0, 0, 1]) == [255, 0, 0, 2]
    assert inc([0, 1, 0, 255]) == [0, 1, 1, 0]



# Generated at 2022-06-24 11:28:23.221243
# Unit test for function sub_bytes

# Generated at 2022-06-24 11:28:28.220603
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # c = aes_encrypt([0] * 16, key_expansion([0] * 16), [0] * 16)
    # cipher = aes_ctr_decrypt(c, [0] * 16, Counter([0] * 16))
    # print(cipher)
    print('In aes_ctr_decrypt function')
    print('Unit test for function aes_ctr_decrypt. Pass')

# Generated at 2022-06-24 11:28:37.025177
# Unit test for function xor
def test_xor():
    assert(xor([0x11, 0x22, 0x33, 0x44, 0x55, 0xAA, 0xFF, 0xFE], [0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7]) == [0xB1, 0x83, 0x81, 0xE7, 0xF1, 0x0F, 0x49, 0x49])
    assert(xor([0x11, 0x22, 0x33, 0x44, 0x55, 0xAA, 0xFF, 0xFE], [0xA0]) == [0xB1, 0x22, 0x33, 0x44, 0x55, 0xAA, 0xFF, 0xFE])
   

# Generated at 2022-06-24 11:28:43.272210
# Unit test for function sub_bytes
def test_sub_bytes():
    # Test data is taken from http://en.wikipedia.org/wiki/Rijndael_mix_columns
    test_data = [0xDB, 0x13, 0x53, 0x45]
    test_result = [0x8e, 0x4d, 0xa1, 0xbc]
    assert(sub_bytes(test_data) == test_result)



# Generated at 2022-06-24 11:28:47.344660
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0] * 16
    result = shift_rows_inv(data)
    assert result == [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]



# Generated at 2022-06-24 11:28:59.155149
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    plain_text = [0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0x07, 0xa8, 0x8d, 0xa2, 0x34]
    plain_text_ans = [0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0x07, 0xa8, 0x8d, 0xa2, 0x34]
    plain_text_ans = shift_rows_inv(plain_text)
    if plain_text == plain_text_ans:
        print("Unit test for function shift_rows_inv passed")



# Generated at 2022-06-24 11:29:06.505573
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [0,1,2,3,4,5,6,7,8,9,0,1,2,3,4,5]
    data = [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5]
    result_data = aes_decrypt(data, key)
    assert(result_data == [240, 172, 216, 211, 173, 12, 81, 116, 130, 206, 98, 98, 98, 98, 98, 98])


# Generated at 2022-06-24 11:29:13.636200
# Unit test for function mix_columns
def test_mix_columns():
    input_bytes = [0xdb, 0xf2, 0xd4, 0x6e, 0x45, 0xf9, 0x3e, 0x0b, 0x8e, 0xf0, 0xa3, 0x2c, 0x72, 0x4d, 0xb7, 0xa3]
    output_bytes = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x70, 0x2b, 0x3e, 0xb5, 0x4a, 0x85, 0x1d]
    assert mix_columns(input_bytes) == output_bytes

# Generated at 2022-06-24 11:29:25.430869
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
          0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    # This input is padded with 0x10 extra bytes

# Generated at 2022-06-24 11:29:33.737029
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range (0x100):
        for b in range(0x100):
            result = rijndael_mul(a,b)
            assert rijndael_mul(result, rijndael_mul_inv(b)) == a
            assert rijndael_mul(result, rijndael_mul_inv(a)) == b
            assert rijndael_mul(rijndael_mul_inv(a), b) == result
            assert rijndael_mul(rijndael_mul_inv(b), a) == result



# Generated at 2022-06-24 11:29:41.153676
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data_16 = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]
    data_24 = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]

# Generated at 2022-06-24 11:29:50.511849
# Unit test for function aes_decrypt
def test_aes_decrypt():
    expanded_key_string = "8e a2 b7 ca 51 67 45 bf ea fc 49 90 4b 49 60 89"
    
    expanded_key = bytes_to_intlist(compat_b64decode(expanded_key_string))
    
    data_string = "7d fd 5c a5 4b dc c9 55 0a ce fc 49 51 bc b5 e6"
    data = bytes_to_intlist(compat_b64decode(data_string))
    
    result_string = "16 a0 b6 8b 44 b2 e5 49 28 4a d9 bc 9e b7 6c 5b"
    result = bytes_to_intlist(compat_b64decode(result_string))
    

# Generated at 2022-06-24 11:30:02.223631
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test function aes_decrypt_text() for all key sizes
    """
    import base64

    def hex_to_intlist(hex_string):
        return [int('0x' + hex_string[i: i + 2], 16) for i in range(0, len(hex_string), 2)]

    # test vectors from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf

# Generated at 2022-06-24 11:30:10.293126
# Unit test for function inc
def test_inc():
    assert inc([0 for i in range(4)]) == [0x01, 0x00, 0x00, 0x00]
    assert inc([0xFF for i in range(4)]) == [0x00, 0x00, 0x00, 0x01]
    assert inc([0x01, 0x01, 0x01, 0x01]) == [0x02, 0x01, 0x01, 0x01]
    assert inc([0x00, 0xFF, 0xFF, 0xFF]) == [0x01, 0x00, 0x00, 0x00]



# Generated at 2022-06-24 11:30:21.374157
# Unit test for function key_expansion
def test_key_expansion():
    if not test_key_expansion.tested:
        test_aes()
        test_key_expansion.tested = True


# Generated at 2022-06-24 11:30:27.401366
# Unit test for function xor
def test_xor():
    assert xor([1, 2, 3, 4, 5], [5, 4, 3, 2, 1]) == [4, 6, 0, 6, 4]
    assert xor([1, 2, 3], [6, 7, 8]) == [7, 5, 11]
    print("Test xor SUCCESSED")

# Generated at 2022-06-24 11:30:35.455751
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = '123456789abcdefg'
    expanded_key = key_expansion('123456789abcdefg')
    assert aes_encrypt(bytes_to_intlist(data.encode('latin-1')), expanded_key) == bytes_to_intlist('zZtT/TtTzZtT/TtTzZtT/TtTzZtT/TtTzZtT/TtTzZtT/TtTzZtT/TtTzZtT/TtTzZtT/TtT'.encode('latin-1'))

# Generated at 2022-06-24 11:30:40.236512
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert(rijndael_mul(0x57, 0x83) == 0xc1)
    assert(rijndael_mul(0x83, 0x57) == 0xc1)
    assert(rijndael_mul(0x57, 0x13) == 0xfe)
    assert(rijndael_mul(0x13, 0x57) == 0xfe)



# Generated at 2022-06-24 11:30:48.801578
# Unit test for function shift_rows_inv

# Generated at 2022-06-24 11:30:57.368664
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytes_to_intlist(compat_b64decode(
        b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    iv = [0] * 16
    key = [0x0102030405060708,
           0x090a0b0c0d0e0f10,
           0x1112131415161718,
           0x19191a1b1c1d1e1f]
    key = intlist_to_bytes(key)
    result = aes_cbc_decrypt(data, key, iv)
    assert intlist_to_bytes(result) == b"hello"



# Generated at 2022-06-24 11:31:07.097274
# Unit test for function aes_decrypt
def test_aes_decrypt():
    import binascii, sys
    key = bytearray(binascii.a2b_hex('000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f'))
    data =  bytearray(binascii.a2b_hex('69c4e0d86a7b0430d8cdb78070b4c55a'))
    expected = bytearray(binascii.a2b_hex('00112233445566778899aabbccddeeff'))
    expanded_key = key_expansion(key)
    decrypted_data = aes_decrypt(data, expanded_key)

# Generated at 2022-06-24 11:31:18.563460
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    #password = 'testpassword'
    #data = 'WJuNhbK0G/dKtOYZBYJhfDtL5JE+oPYkmv9XWn+DH7FHy1zDh5xvQ5W5nc8YVQCJHkS7V9XWbKj6V'
    password = '123456'
    data = 'VHl2ypS/u3qXBbW8sqm6cg=='
    plaintext = aes_decrypt_text(data, password, 32)

# Generated at 2022-06-24 11:31:28.906942
# Unit test for function xor
def test_xor():
    data1 = [0x19, 0x3D, 0xE3, 0xBE, 0xA0, 0xF4, 0xE2, 0x2B, 0x9A, 0xC6, 0x8D, 0x2A, 0xE9, 0xF8, 0x48, 0x08]
    data2 = [0x39, 0x25, 0x84, 0x1D, 0x02, 0xDC, 0x09, 0xFB, 0xDC, 0x11, 0x85, 0x97, 0x19, 0x6A, 0x0B, 0x32]