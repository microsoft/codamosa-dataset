

# Generated at 2022-06-24 11:21:27.436012
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = [43, 126, 21, 22, 40, 174, 210, 166, 171, 247, 21, 136, 9, 207, 79, 60]
    data = [99, 124, 101, 124, 164, 100, 124, 101, 124, 164, 100, 124, 101, 124, 164, 100]
    counter = Counter()
    assert aes_ctr_decrypt(data, key, counter) == [99, 124, 101, 124, 164, 100, 124, 101, 124, 164, 100, 124, 101, 124, 164, 100]



# Generated at 2022-06-24 11:21:33.202702
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key = [0x01, 0x02, 0x03, 0x04]
    expected = [0x01, 0x03, 0x04, 0x08]
    assert key_schedule_core(key, 1) == expected
    print("Test key_schedule_core() successful!")
#test_key_schedule_core()



# Generated at 2022-06-24 11:21:37.434805
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key_input = [0x2b, 0x7e, 0x15, 0x16]
    key_expected = [0xa0, 0x88, 0x23, 0x2a]
    assert key_schedule_core(key_input, 1) == key_expected
test_key_schedule_core()


# Generated at 2022-06-24 11:21:45.774047
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns(data)
    expected = [0x8E, 0x4D, 0xA1, 0xBC, 0x9F, 0xDC, 0x58, 0x9D, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert result == expected



# Generated at 2022-06-24 11:21:53.441696
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, init_value):
            self.init_value = init_value
            self.current_value = init_value

        def next_value(self):
            self.current_value += 1
            return self.init_value

    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
           0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    counter = Counter(1)

# Generated at 2022-06-24 11:22:01.407829
# Unit test for function mix_columns
def test_mix_columns():
    print("Test mix columns")
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected_output = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns(data, MIX_COLUMN_MATRIX)
    if result == expected_output:
        print("Test case passed")
    else:
        print

# Generated at 2022-06-24 11:22:07.598808
# Unit test for function key_schedule_core
def test_key_schedule_core():
    correct_answer = [0x1b, 0x00, 0x00, 0x00]
    input_data = [0x00, 0x00, 0x00, 0x00]
    rcon_iteration = 1    
    
    assert key_schedule_core(input_data, rcon_iteration) == correct_answer, "key_schedule_core() not working"
test_key_schedule_core()



# Generated at 2022-06-24 11:22:15.045948
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist('00112233445566778899aabbccddeeff')
    key = bytes_to_intlist('000102030405060708090a0b0c0d0e0f')
    iv = bytes_to_intlist('f0f1f2f3f4f5f6f7f8f9fafbfcfdfeff')
    counter = Counter(iv)
    decrypted_data = aes_ctr_decrypt(data, key, counter)

    assert(decrypted_data == bytes_to_intlist('69c4e0d86a7b0430d8cdb78070b4c55a'))


# Generated at 2022-06-24 11:22:19.758307
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected = [0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert shift_rows(data) == expected

# Generated at 2022-06-24 11:22:26.576144
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x1, 0x2, 0x3, 0x4]
    rcon_iteration = 0

    data_expected = [0x2, 0x3, 0x4, 0x1]

    data_actual = key_schedule_core(data, rcon_iteration)

    assert data_expected == data_actual



# Generated at 2022-06-24 11:22:34.631032
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0x5e, 0xc2, 0x0a, 0x22, 0x14, 0x52, 0x4f, 0x09, 0x8d, 0x1e, 0x32, 0x46, 0x85, 0xe3, 0xca, 0xa3]
    data_result = mix_columns_inv(data)
    print(data_result)
    assert data_result == [0x5e, 0xc2, 0x0a, 0x22, 0x14, 0x52, 0x4f, 0x09, 0x8d, 0x1e, 0x32, 0x46, 0x85, 0xe3, 0xca, 0xa3]
# test_mix_columns_inv()


# Generated at 2022-06-24 11:22:45.103231
# Unit test for function aes_decrypt
def test_aes_decrypt():
  from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
  from cryptography.hazmat.backends import default_backend
  iv = [62, 138, 186, 78, 131, 174, 195, 85, 12, 202, 188, 160, 144, 240, 8, 237]
  key = [205, 119, 237, 191, 97, 220, 23, 84, 16, 66, 147, 191, 120, 183, 146, 35, 28, 148, 124, 224, 50, 163, 161, 29, 215, 4, 202, 15, 2, 14, 9, 23]
  cipher = Cipher(algorithms.AES(bytes(key)), modes.CBC(bytes(iv)), backend=default_backend())
  decryptor = cipher.decryptor()

# Generated at 2022-06-24 11:22:50.220347
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    output = mix_columns_inv(data)
    expected_output = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]

    return output == expected_output

# Generated at 2022-06-24 11:22:59.343064
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(b'\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff')

# Generated at 2022-06-24 11:23:04.518174
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # From https://wiki.openssl.org/index.php/EVP_Symmetric_Encryption_and_Decryption#Encrypting_the_Message
    # AES-192-CBC key
    KEY = (0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
           0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f)
    # AES-192-CBC IV

# Generated at 2022-06-24 11:23:15.439604
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    input = [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16]
    expected = [0x01, 0x06, 0x11, 0x16, 0x02, 0x07, 0x12, 0x09, 0x03, 0x08, 0x13, 0x10, 0x04, 0x09, 0x14, 0x11]
    result = shift_rows_inv(input)
    print("input     : " + str(input))
    print("expected  : " + str(expected))
    print("result    : " + str(result))

# Generated at 2022-06-24 11:23:20.977833
# Unit test for function aes_encrypt

# Generated at 2022-06-24 11:23:23.660825
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0xDB, 0x13, 0x53, 0x45]
    assert sub_bytes(data) == [0x8e, 0xc4, 0xa6, 0xfc]


# Generated at 2022-06-24 11:23:31.016986
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    print(sub_bytes([0x52, 0x09, 0x6A, 0xD5, 0x30, 0x36, 0xA5, 0x38, 0xBF, 0x40, 0xA3, 0x9E, 0x81, 0xF3, 0xD7, 0xFB]))



# Generated at 2022-06-24 11:23:36.712977
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test_vec = [0, 79, 167, 243]
    result = [232, 3, 91, 119, 255, 70, 65, 153]
    data_mixed = mix_column(test_vec, MIX_COLUMN_MATRIX_INV)
    print(data_mixed)
    assert data_mixed == result


# Generated at 2022-06-24 11:23:44.727716
# Unit test for function aes_decrypt
def test_aes_decrypt():
    print("Test AES decrypt")
    data = bytes_to_intlist(b'\xdd\x94\x0e\x23\x2a\x21\x0c\x79\xfe\xc0\x0c\x21\xa8\x39\x77\x1b')
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')   # 16-Byte key

# Generated at 2022-06-24 11:23:48.124061
# Unit test for function key_schedule_core
def test_key_schedule_core():
    test_input = [0x01, 0x02, 0x03, 0x04]
    assert key_schedule_core(test_input, 0) == [0x01, 0x03, 0x05, 0x0F]
    assert key_schedule_core(test_input, 1) == [0x01, 0x03, 0x05, 0x0F]
    return True

test_key_schedule_core()

# Generated at 2022-06-24 11:23:58.925027
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-24 11:24:00.243231
# Unit test for function rotate
def test_rotate():
    test_array = [1, 2, 3, 4]
    assert rotate(test_array) == [2, 3, 4, 1]



# Generated at 2022-06-24 11:24:03.997541
# Unit test for function xor
def test_xor():
    assert xor(xor([0x01, 0x01], [0xFF, 0xFF]), [0xFF, 0xFF]) == [0x01, 0x01]



# Generated at 2022-06-24 11:24:09.321916
# Unit test for function inc
def test_inc():
    print(inc([0x01, 0x2f, 0x45, 0xaa]))
    print(inc([0x01, 0x2f, 0x45, 0xff]))
    print(inc([0x01, 0x2f, 0xff, 0xff]))
    print(inc([0xff, 0xff, 0xff, 0xff]))
    print(inc([0x00, 0x00, 0x00, 0x00]))



# Generated at 2022-06-24 11:24:15.918255
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert mix_columns_inv(data) == result
    print("Unit test for function mix_columns_inv passed!")
test_mix_columns_inv()


# Generated at 2022-06-24 11:24:18.561534
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    __salted__ = compat_b64decode('ObR5j9XOZW8G4f4AZD3i3fI/U6z8b6lN/DzGkvC9XSE=')
    assert aes_cbc_encrypt([], bytes_to_intlist(b'YELLOW SUBMARINE'), [0]*16) == __salted__
test_aes_cbc_encrypt()



# Generated at 2022-06-24 11:24:24.247281
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = '9prJ4UD4+vHt063qw3JpfA=='
    password = 'pass'
    key_size_bytes = 16
    result = aes_decrypt_text(data, password, key_size_bytes)
    assert(result=='test')
    return result


# Generated at 2022-06-24 11:24:29.472445
# Unit test for function inc
def test_inc():
    print("Unit test for function inc")
    a = [0, 0, 0, 0]
    b = [0, 0, 0, 1]
    c = [0, 0, 0, 255]
    d = [0, 0, 0, 0, 0]
    e = [0, 0, 0, 255, 255]
    print("a,b,c,d,e:", a, b, c, d, e, sep="\n")
    print("b == inc(a) :", b == inc(a))
    print("c == inc(b) :", c == inc(b))
    print("d == inc(c) :", d == inc(c))
    print("e == inc(d) :", e == inc(d))
    print("a == inc(e) :", a == inc(e))


# Generated at 2022-06-24 11:24:40.820736
# Unit test for function rijndael_mul

# Generated at 2022-06-24 11:24:48.130384
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-24 11:24:52.648541
# Unit test for function xor
def test_xor():
    assert xor([1, 2, 3, 4], [1, 2, 3, 4]) == [0, 0, 0, 0]
    assert xor([1, 2, 3, 4], [0, 0, 0, 0]) == [1, 2, 3, 4]
    assert xor([1, 2, 3, 4], [1, 1, 1, 1]) == [0, 3, 2, 5]
    assert xor([1, 2, 3, 4], [4, 3, 2, 1]) == [5, 1, 1, 5]
    return "Test for xor successful!"


# Generated at 2022-06-24 11:24:58.019064
# Unit test for function mix_columns
def test_mix_columns():
    TEST_TXT = [0x04, 0xE0, 0x48, 0x28, 0x66, 0xCB, 0xF8, 0x06, 0x81, 0x19, 0xD3, 0x26, 0xE5, 0x9A, 0x7A, 0x4C]
    EXPECTED_TXT = [0x04, 0x66, 0xCB, 0xF8, 0x06, 0x81, 0x19, 0xD3, 0x26, 0xE5, 0x9A, 0x7A, 0x4C, 0xE0, 0x48, 0x28]
    TEST_RESULT = mix_columns(TEST_TXT)
    TEST_FLAG = EXPECTED_TXT == TEST_RESULT

# Generated at 2022-06-24 11:25:07.326933
# Unit test for function key_expansion

# Generated at 2022-06-24 11:25:13.377751
# Unit test for function xor
def test_xor():
    data1 = [1, 2, 3]
    data2 = [1, 2, 3]
    assert([2, 4, 6] == xor(data1, data2))
    data1 = [1, 2, 3]
    data2 = [2, 2, 3]
    assert([3, 0, 0] == xor(data1, data2))



# Generated at 2022-06-24 11:25:22.596986
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    def test_aes_cbc_encrypt_unit(message, key, iv, expected):
        data = bytes_to_intlist(message)
        key = bytes_to_intlist(key)
        iv = bytes_to_intlist(iv)
        expected = bytes_to_intlist(expected)
        resulting_message = intlist_to_bytes(aes_cbc_encrypt(data, key, iv))
        assert resulting_message == expected, "Fail: expected " + expected.encode('hex') + " got " + resulting_message.encode('hex')
    test_aes_cbc_encrypt_unit("hello world!", "123456789abcdefg", "abcdefghijklmnop", "abcdefghijklmnopfbegkwjuohhlsbrzc")

# Generated at 2022-06-24 11:25:27.003689
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = []
    for i in range(16):
        data.append(i)
    mixed_data = mix_columns(data)
    for i in range(16):
        print(hex(mixed_data[i]), end="")
        if(i % 4 == 3):
            print()
    print()
    inv_data = mix_columns_inv(mixed_data)
    for i in range(16):
        print(hex(inv_data[i]), end="")
        if(i % 4 == 3):
            print()


# Generated at 2022-06-24 11:25:37.500077
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # from the example in slide
    a = bytes_to_intlist(b"\x19\x3d\xe3\xbe\xa0\xf4\xe2\x2b")
    b = bytes_to_intlist(b"\x9e\x99\xa7\xbf\x3e\xdc\x9a\x85")
    c = bytes_to_intlist(b"\xad\x7f\xad\xfd\x7c\x9a\x12\x04")
    key = bytes_to_intlist(b"\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c")
    expanded_

# Generated at 2022-06-24 11:25:40.504860
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0,1,2,3,  4,5,6,7,  8,9,10,11, 12,13,14,15]
    data = shift_rows(data)
    data = shift_rows_inv(data)
    print (data)



# Generated at 2022-06-24 11:25:49.796018
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    print("Unit test for function shift_rows_inv")
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    data_shifted = shift_rows(data)
    data_inv = shift_rows_inv(data_shifted)
    print("Input:", data)
    print("Shift rows", data_shifted)
    print("Shift rows inverse:", data_inv)
    if data == data_inv:
        print("Test passed")
    else:
        print("Test failed")



# Generated at 2022-06-24 11:25:54.473413
# Unit test for function sub_bytes_inv

# Generated at 2022-06-24 11:26:04.499096
# Unit test for function shift_rows
def test_shift_rows():
        s = [0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]
        t = [0x63, 0x53, 0xe0, 0x8c, 0x09, 0xd0, 0xba, 0x04, 0xcd, 0x60, 0xe7, 0x51, 0xba, 0x70, 0xe1, 0xb7]
        assert(shift_rows(s) == t)



# Generated at 2022-06-24 11:26:07.002599
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([0]*16)) == [0]*16



# Generated at 2022-06-24 11:26:12.118492
# Unit test for function xor
def test_xor():
    assert xor([1,0,1,1], [0,1,0,0]) == [1,1,1,1]
#Unit test for function sub_bytes

# Generated at 2022-06-24 11:26:18.442550
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test_data = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns_inv(test_data)
    for i in range(4):
        print(" ".join("0x{:02x}".format(x) for x in result[i*4: (i+1)*4]))
    # 0x01 0x01 0x01 0x01
    # 0x5D  0x4E  0x0B  0x7A
    # 0x45  0x0C  0x2F  0x3C
    # 0x30  0

# Generated at 2022-06-24 11:26:25.607588
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """
    Unit test for function aes_cbc_decrypt
    """
    encryption_key = bytes_to_intlist(b'YELLOW SUBMARINE')
    data = bytes_to_intlist(b'\x44\x41\x04\x1b\x4b\xef\xf4\xfb\x4d\x55\x52\x51\x46\x49\x4c\x45')
    iv = [0] * 16

    decrypted_data = aes_cbc_decrypt(data, encryption_key, iv)
    assert intlist_to_bytes(decrypted_data) == b'DAVE SAYS HI!'


# Generated at 2022-06-24 11:26:33.312682
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-24 11:26:42.806211
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test_data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    test_result = mix_columns_inv(test_data)
    assert test_result == [0x50, 0x88, 0xD8, 0x42, 0x5F, 0xD6, 0xE6, 0x4C, 0x4B, 0x65, 0xE6, 0x45, 0x7A, 0xE4, 0x4A, 0x4E]



# Generated at 2022-06-24 11:26:48.521906
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3]) == [2,3,1]
    assert rotate([4,5,6]) == [5,6,4]
    assert rotate([7,8,9]) == [8,9,7]
    
test_rotate()


# Generated at 2022-06-24 11:26:58.120286
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
  d = [0x0F, 0x0E, 0x0D, 0x0C, 0x0B, 0x0A, 0x09, 0x08, 0x07, 0x06, 0x05, 0x04, 0x03, 0x02, 0x01, 0x00]
  assert shift_rows_inv(d) == [0x00, 0x05, 0x0A, 0x0F, 0x01, 0x06, 0x0B, 0x0C, 0x02, 0x07, 0x08, 0x0D, 0x03, 0x04, 0x09, 0x0E]
  print("[*] Function shift_rows_inv() passed!")
test_shift_rows_inv()



# Generated at 2022-06-24 11:27:06.123587
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb]) == [0x66, 0xe9, 0x4b, 0xd4, 0xef, 0x8a, 0x2c, 0x3b, 0x88, 0x4c, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4]



# Generated at 2022-06-24 11:27:20.271509
# Unit test for function inc
def test_inc():
    assert(inc([1]) == [2])
    assert(inc([254]) == [255])
    assert(inc([255]) == [0])
    assert(inc([1, 2, 3]) == [1, 2, 4])
    assert(inc([1, 2, 255]) == [1, 3, 0])
    assert(inc([1, 255, 255]) == [2, 0, 0])
    assert(inc([255, 255, 255]) == [0, 0, 0])
    assert(inc([1, 2, 3, 4]) == [1, 2, 3, 5])
    assert(inc([1, 2, 3, 255]) == [1, 2, 4, 0])
    assert(inc([1, 2, 255, 255]) == [1, 3, 0, 0])

# Generated at 2022-06-24 11:27:23.180027
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x1, 0x2]) == [0x63, 0x2]
    assert sub_bytes([0x1, 0x2]) == [0x63, 0x2]



# Generated at 2022-06-24 11:27:27.991322
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert mix_columns_inv(mix_columns(data)) == data



# Generated at 2022-06-24 11:27:35.616602
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        """
        Provides a counter for use with aes_ctr_decrypt
        """
        def __init__(self, start):
            """
            @param {int[]} start  16-Byte block
            """
            self.counter = start

        def next_value(self):
            assert len(self.counter) == 16
            self.counter = increment_bytes(self.counter)
            return self.counter

    data = bytes_to_intlist(compat_b64decode(
        'L779nVhkYs9WECj8E/mRnA=='))

    key = bytes_to_intlist(compat_b64decode(
        'zq3L6C7ZjfNB2S5gy5iX0A=='))

    counter = Counter

# Generated at 2022-06-24 11:27:46.627953
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    data = [0x6f, 0x2f, 0x8c, 0xb3, 0x03, 0x7b, 0xce, 0x53, 0x9a, 0xcc, 0x2a, 0xbf, 0x1a, 0xfd, 0x92, 0xee]
    data = sub_bytes_inv(data)
    print(data)
    assert data == [0x98, 0x56, 0x9a, 0x8e, 0xd7, 0x58, 0x39, 0x44, 0x52, 0x4b, 0x55, 0x56, 0x35, 0x70, 0x69, 0x3d]



# Generated at 2022-06-24 11:27:52.225405
# Unit test for function rijndael_mul
def test_rijndael_mul():
        for i in range(0xFF):
                for j in range(0xFF):
                        my_ans = rijndael_mul(i, j)
                        galois_field_ans = gf_mul(i, j)
                        if(my_ans != galois_field_ans):
                                return False
        return True
# assert(test_rijndael_mul())



# Generated at 2022-06-24 11:27:53.540426
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert(sub_bytes_inv(SBOX) == range(256))



# Generated at 2022-06-24 11:27:58.152345
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    assert aes_cbc_decrypt([117, 100, 116, 104, 89, 49,
                            255, 223, 110, 129, 159, 119,
                            0, 0, 0, 0], [88, 68, 122, 52,
                                         103, 2, 49, 103,
                                         82, 41, 110, 215,
                                         15, 86, 154, 35], [10, 2, 5, 2,
                                                              0, 4, 6, 7,
                                                              4, 5, 2, 1,
                                                              8, 6, 7, 1]) == [35, 12, 24, 64,
                                                                                 190, 43, 30, 20,
                                                                                 11, 28, 23, 64,
                                                                                 100, 160, 160, 160]

# Generated at 2022-06-24 11:28:00.790725
# Unit test for function mix_column
def test_mix_column():
    test_data = [0xdf, 0x39, 0xde, 0xef]
    result = mix_column(test_data, MIX_COLUMN_MATRIX)
    assert result == [0x04, 0x66, 0x81, 0xe5]

    result = mix_column(result, MIX_COLUMN_MATRIX_INV)
    assert result == test_data


test_mix_column()



# Generated at 2022-06-24 11:28:05.041363
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print("test_rijndael_mul")
    for i in range(0, 256):
        for j in range(0, 256):
            assert(rijndael_mul(i, j) == expected_rijndael_mul(i, j))



# Generated at 2022-06-24 11:28:17.511227
# Unit test for function inc
def test_inc():
    data = [0, 0, 0, 0]
    assert inc(data) == [0, 0, 0, 1]
    assert inc(data) == [0, 0, 1, 2]
    assert inc(data) == [0, 0, 2, 3]
    assert inc(data) == [0, 0, 3, 4]
    assert inc(data) == [0, 0, 4, 5]
    assert inc(data) == [0, 0, 5, 6]
    assert inc(data) == [0, 0, 6, 7]
    assert inc(data) == [0, 0, 7, 8]
    assert inc(data) == [0, 0, 8, 9]
    assert inc(data) == [0, 0, 9, 10]
    assert inc(data) == [0, 0, 10, 11]

# Generated at 2022-06-24 11:28:20.804869
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range(0x100):
        for b in range(0x100):
            assert rijndael_mul(a,b) == GF256_MUL_TABLE[a][b]
            

# Generated at 2022-06-24 11:28:27.394494
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0xA4, 0x68, 0x6B, 0x02]
    rcon_iteration = 1

    result = key_schedule_core(data, rcon_iteration)

    assert result == [0xB1, 0x1C, 0x19, 0xEC]


# Generated at 2022-06-24 11:28:33.535162
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0xab, 0xab, 0xab, 0xab]
    data_mixed = mix_columns(data)
    data_expected = [0x8e, 0x4d, 0xa1, 0xbc,
                     0x9f, 0xdc, 0x58, 0x9d,
                     0x01, 0x01, 0x01, 0x01,
                     0xcd, 0xce, 0xcd, 0xcd]
    assert data_mixed == data_expected


# Generated at 2022-06-24 11:28:44.805003
# Unit test for function shift_rows
def test_shift_rows():
    assert (shift_rows([0] * 16) == [0] * 16)
    assert (shift_rows([1] * 16) == [1] * 16)
    assert (shift_rows([2] * 16) == [2] * 16)
    assert (shift_rows([3] * 16) == [3] * 16)
    assert (shift_rows([4] * 16) == [4] * 16)
    assert (shift_rows([5] * 16) == [5] * 16)
    assert (shift_rows([6] * 16) == [6] * 16)
    assert (shift_rows([7] * 16) == [7] * 16)
    assert (shift_rows([8] * 16) == [8] * 16)
    # Start shift rows

# Generated at 2022-06-24 11:28:58.642436
# Unit test for function aes_decrypt
def test_aes_decrypt():
  cipher_data=[[0x69, 0xc4, 0xe0, 0xd8, 0x6a, 0x7b, 0x04, 0x30, 0xd8, 0xcd, 0xb7, 0x80, 0x70, 0xb4, 0xc5, 0x5a]]

# Generated at 2022-06-24 11:29:03.704683
# Unit test for function inc
def test_inc():
    assert inc([0,0,0,0]) == [0,0,0,1]
    assert inc([0,0,0,255]) == [0,0,1,0]
    assert inc([255,255,255,255]) == [0,0,0,0]

test_inc()



# Generated at 2022-06-24 11:29:06.765093
# Unit test for function inc
def test_inc():
    assert(inc([0, 0, 0]) == [0, 0, 1])
    assert(inc([0, 1, 255]) == [0, 2, 0])
    assert(inc([0, 255, 255]) == [1, 0, 0])



# Generated at 2022-06-24 11:29:12.327543
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('GawgguFyGrWKav7AX4VKUg'))
    iv = bytes_to_intlist(compat_b64decode('SmuFyGrWKav7AX4VKUg'))

    encrypted = aes_cbc_encrypt(bytes_to_intlist('Hello World and stuff'), key, iv)
    decrypted = aes_cbc_decrypt(encrypted, key, iv)

    assert decrypted == bytes_to_intlist('Hello World and stuff')



# Generated at 2022-06-24 11:29:22.805036
# Unit test for function mix_column
def test_mix_column():
    plain_text = [1,2,3,4]
    cipher_text = mix_column(plain_text, MIX_COLUMN_MATRIX)
    print("Cipher text: " + string_to_hex(cipher_text))
    plain_text = mix_column(cipher_text, MIX_COLUMN_MATRIX_INV)
    print("Plain text: " + string_to_hex(plain_text))
# test_mix_column()


# Generated at 2022-06-24 11:29:31.721576
# Unit test for function inc
def test_inc():
    a = [0, 255]
    b = inc(a)
    assert(a == [0, 255])
    assert(b == [1, 0])

    a = [0, 0, 255]
    b = inc(a)
    assert(a == [0, 0, 255])
    assert(b == [0, 1, 0])

    a = [255, 255, 255]
    b = inc(a)
    assert(a == [255, 255, 255])
    assert(b == [0, 0, 0])

    a = [1, 5, 6]
    b = inc(a)
    assert(a == [1, 5, 6])
    assert(b == [1, 6, 7])



# Generated at 2022-06-24 11:29:43.617174
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100]
    expanded_key = key_expansion([100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100])
    encrypted_data = aes_encrypt(data, expanded_key)
    print(encrypted_data)
    # [155, 0, 1, 146, 88, 172, 140, 183, 31, 133, 50, 96, 113, 201, 165, 80]


# Generated at 2022-06-24 11:29:52.023335
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .crypto import AES_CTR_Counter, aes_cbc_encrypt
    key = bytes_to_intlist(b'1234567890123456')
    counter = AES_CTR_Counter(0).next_value
    data = bytes_to_intlist(b'message')
    cipher = aes_ctr_decrypt(data, key, counter)
    assert cipher == aes_cbc_encrypt(data, key, counter=[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])


# Generated at 2022-06-24 11:30:02.065170
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b'hello world')
    key = bytes_to_intlist(b'1234567890123456')
    iv = bytes_to_intlist(b'abcdefghijklmnop')
    expected_cipher = bytes_to_intlist(b'\x7b\x63\x0c\xcf\x92\x8b\x0c\x35\xf1\x76\x1a\x26\x3d\x72\x7b\x93')
    cipher = aes_cbc_encrypt(data, key, iv)
    assert expected_cipher == cipher

# Generated at 2022-06-24 11:30:07.809003
# Unit test for function shift_rows
def test_shift_rows():
    # Test data
    data = [0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0]
    # Expected output
    data_shifted = [0x0, 0x0, 0x0, 0x0,
                    0x0, 0x0, 0x0, 0x0,
                    0x0, 0x0, 0x0, 0x0,
                    0x0, 0x0, 0x0, 0x0]
    data_shifted_res = shift_rows(data)

# Generated at 2022-06-24 11:30:19.207748
# Unit test for function mix_column
def test_mix_column():
    print('Testing Mix Column...')
    data = [0xdb, 0x13, 0x53, 0x45]
    result = mix_column(data,MIX_COLUMN_MATRIX)
    print(result)
    if(result == [0x8e, 0x4d, 0xa1, 0xbc]):
        print('Test OK\n')
        return 1
    else:
        print('Test FAILED\n')
        return 0

# Generated at 2022-06-24 11:30:29.666703
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = [0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77]
    key = [0x00, 0x01, 0x02, 0x03, 0x05, 0x06, 0x07, 0x08, 0x0A, 0x0B, 0x0C, 0x0D, 0x0F, 0x10, 0x11, 0x12]
    data = aes_decrypt(data, key_expansion(key))

# Generated at 2022-06-24 11:30:36.044057
# Unit test for function shift_rows
def test_shift_rows():
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    data_shifted = [1, 2, 3, 4, 6, 7, 8, 5, 11, 12, 13, 9, 14, 10, 15, 16]
    assert(data_shifted == shift_rows(data))
test_shift_rows()



# Generated at 2022-06-24 11:30:45.956521
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    for plaintext, key, iv in CIPHERTEXTS:
        assert plaintext == intlist_to_bytes(aes_cbc_decrypt(bytes_to_intlist(compat_b64decode(plaintext), True),
                                                             bytes_to_intlist(compat_b64decode(key), True),
                                                             bytes_to_intlist(compat_b64decode(iv), True)))



# Generated at 2022-06-24 11:30:54.972941
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_ctr_counters import Counter_ab_16_byte
    from .aes_cbc_decrypt import AES_128_BLOCK_SIZE_BYTES
    from .crypto import hex_to_bytes

    class ConstCounter(object):
        def __init__(self, const_value):
            self.const_value = const_value
        def next_value(self):
            return self.const_value

    def test_encryption_of_single_block():
        key = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5]
        iv = [6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1]
        const_counter = Const

# Generated at 2022-06-24 11:31:03.104345
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    from json import loads
    from os.path import dirname, join

    for key_size_bytes in (16, 24, 32):
        filename = join(dirname(__file__), 'data/aes_decrypt_text_%d.json' % (key_size_bytes * 8))
        with open(filename) as in_file:
            for line in in_file:
                value = loads(line)
                plaintext = value['plaintext'].strip()
                ciphertext = value['ciphertext'].strip()
                password = value['password'].strip()
                result = aes_decrypt_text(ciphertext, password, key_size_bytes)

                if result != plaintext:
                    raise Exception('AssertionError')



# Generated at 2022-06-24 11:31:06.583477
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [5] * BLOCK_SIZE_BYTES
    data = [5] * BLOCK_SIZE_BYTES
    assert data == aes_decrypt(aes_encrypt(data, key), key)
test_aes_decrypt()



# Generated at 2022-06-24 11:31:08.601172
# Unit test for function sub_bytes
def test_sub_bytes():
    assert(sub_bytes([0x19, 0xa0, 0x9a, 0xe9]) == [0xd4, 0xe0, 0xb8, 0x1e])
    print('passed')


# Generated at 2022-06-24 11:31:16.618050
# Unit test for function xor
def test_xor():
    b1 = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77]
    b2 = [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF]
    b1XORb2 = [x ^ y for x, y in zip(b1, b2)]
    print(b1XORb2)



# Generated at 2022-06-24 11:31:19.921190
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    for i in range(4):
        for j in range(4):
            a1 = [0] * 16
            a2 = [0] * 16
            a1[i * 4 + j] = 1
            a2[j * 4 + ((i - j) & 0b11)] = 1
            assert shift_rows_inv(shift_rows(a1)) == a1
            assert shift_rows(shift_rows_inv(a1)) == a1
            assert shift_rows_inv(a2) == a1
            assert shift_rows(a1) == a2

# Add round key

# Generated at 2022-06-24 11:31:26.062108
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([0, 0, 0, 0])) == [0, 0, 0, 0]
    assert sub_bytes_inv(sub_bytes([27, 2, 85, 21])) == [27, 2, 85, 21]
    assert sub_bytes_inv(sub_bytes([17, 17, 17, 17])) == [17, 17, 17, 17]

