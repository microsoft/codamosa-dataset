

# Generated at 2022-06-24 11:21:37.137588
# Unit test for function sub_bytes

# Generated at 2022-06-24 11:21:46.718162
# Unit test for function aes_decrypt
def test_aes_decrypt():
    test_data = bytes_to_intlist(bytes(bytearray.fromhex('0ec775b3544c563211c512a7223546d5')))
    test_key = bytes_to_intlist(bytes(bytearray.fromhex('98c7f1fb8d43f9e0e91245d15175966d6b35308d3cefe6e2b624e8edf4a4db27')))
    test_result = b'\xe4\xf0\x68\xdc\x8f\x4e\x97\x0c\x8d\x02\x48\x69\x87\xf8\x6c\x97'


# Generated at 2022-06-24 11:21:54.973054
# Unit test for function xor
def test_xor():
    assert xor([0, 0, 1, 0], [1, 1, 0, 1]) == [1, 1, 1, 1]
    assert xor([0, 1, 0, 1], [1, 1, 0, 1]) == [1, 0, 0, 0]
    assert xor([0, 0, 1, 0], [1, 1, 0, 1]) == [1, 1, 1, 1]
    assert xor([0, 1, 0, 1], [1, 1, 0, 1]) == [1, 0, 0, 0]
    print("Unit test for function xor: passed")


# Generated at 2022-06-24 11:21:58.002186
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]
    data = mix_column(data, MIX_COLUMN_MATRIX)
    assert(data[0] == 0x8e)
    assert(data[1] == 0x4d)
    assert(data[2] == 0xa1)
    assert(data[3] == 0xbc)



# Generated at 2022-06-24 11:22:09.869125
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns_inv(data)
    expected = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert data_mixed == expected


test_mix_columns_inv()
assert hex(rijndael_mul(0x57, 0x83))

# Generated at 2022-06-24 11:22:18.745036
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    dec = bytes_to_intlist(compat_b64decode("L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=="))
    key = bytes_to_intlist(compat_b64decode("YELLOW SUBMARINE"))
    counter = AESCounter(0)
    assert(intlist_to_bytes(aes_ctr_decrypt(dec, key, counter)) == b"Yo, VIP Let's kick it Ice, Ice, baby Ice, Ice, baby ")


# Generated at 2022-06-24 11:22:22.681466
# Unit test for function mix_columns
def test_mix_columns():
    data = (0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3)
    matrix = MIX_COLUMN_MATRIX
    data_expected = (0, 0, 0, 0, 1, 3, 0, 1, 2, 2, 3, 2, 3, 3, 0, 3)
    data_mixed = mix_columns(data, matrix)
    if data_mixed == data_expected:
        print("Passed")
    else:
        print("Failed")
        print(data_mixed)



# Generated at 2022-06-24 11:22:31.084800
# Unit test for function xor
def test_xor():
    data1 = [0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88]
    data2 = [0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
             0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert xor(data1, data2)[0:8] == [0x10, 0x23, 0x32, 0x45, 0x54, 0x67, 0x76, 0x89]



# Generated at 2022-06-24 11:22:41.567702
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist(b'Sixteen byte key')
    cipher = bytes_to_intlist(b'\xc6\x8f\xe7\x9c\xad\xa4\x86\xa7\x19\x10\x49\x8e\x7f\x62\x88\x73')
    data = bytes_to_intlist(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    expanded_key = key_expansion(key)
    assert aes_decrypt(cipher, expanded_key) == data
test_aes_decrypt()


# Generated at 2022-06-24 11:22:47.129318
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    plain = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    print("plain:", plain)
    plain_shifted = shift_rows(plain)
    print("plain_shifted:", plain_shifted)
    plain_shifted_inv = shift_rows_inv(plain_shifted)
    print("plain_shifted_inv:", plain_shifted_inv)

# Generated at 2022-06-24 11:22:51.481474
# Unit test for function mix_columns
def test_mix_columns():
    original_data = [0xdb, 0x13, 0x53, 0x45,
                     0xf2, 0x0a, 0x22, 0x5c,
                     0x01, 0x01, 0x01, 0x01,
                     0x01, 0x01, 0x01, 0x01]
    data = original_data[:]
    data = mix_columns(data)
    data = mix_columns(data, MIX_COLUMN_MATRIX_INV)
    assert original_data == data
    print("Unit test for function mix_columns passed")


# Generated at 2022-06-24 11:22:55.094971
# Unit test for function key_expansion
def test_key_expansion():
    data = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]
    print(key_expansion(data))



# Generated at 2022-06-24 11:23:00.307918
# Unit test for function aes_encrypt
def test_aes_encrypt():
    import yct.plaintext_generator
    import yct.utils
    import yct.text_sequence_generator
    for plaintext in yct.plaintext_generator.plaintext_generator(32):
        key = yct.utils.byte_to_intlist(yct.utils.hex_to_bytes("2B7E151628AED2A6ABF7158809CF4F3C"))
        cipher = aes_encrypt(yct.utils.byte_to_intlist(plaintext), key_expansion(key))
        cipher2 = yct.utils.hex_to_intlist("3925841D02DC09FBDC118597196A0B32")
        assert cipher == cipher2



# Generated at 2022-06-24 11:23:04.451028
# Unit test for function rotate
def test_rotate():
    """
    Implements unit test for function rotate
    """
    assert rotate([5,6,7,8]) == [6,7,8,5]
    assert rotate(rotate(rotate(rotate([5,6,7,8])))) == [5,6,7,8]
    assert rotate([5,6,7,8]) != [5,7,8,6]
    assert rotate([5,6,7,8]) != [6,7,8,9]
    assert rotate([5,6,7,8]) != [8,6,7,5]
    print('Success: rotate')



# Generated at 2022-06-24 11:23:07.988613
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x00]) == [0x63]



# Generated at 2022-06-24 11:23:11.851669
# Unit test for function key_expansion
def test_key_expansion():
    assert key_expansion([0] * 32) == bytes_to_intlist(compat_b64decode(b"""
        0QW4K8JvX9S0y+c27kPwK45FhHEt1RlIKZcB7Vu0wy8=
    """))



# Generated at 2022-06-24 11:23:18.853655
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Test vectors deviated from https://en.wikipedia.org/wiki/Block_cipher_mode_of_operation#Counter_.28CTR.29
    # because they did not specify counter, key and nonce
    # Values taken from http://csrc.nist.gov/groups/ST/toolkit/BCM/documents/proposedmodes/ctr/ctr-vectors.txt
    key = bytes_to_intlist('603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4')
    counter = Counter(0)

# Generated at 2022-06-24 11:23:22.732452
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 1) == [0x02, 0x04, 0x01, 0x09]



# Generated at 2022-06-24 11:23:25.401747
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x3a, 0xb7, 0x9f, 0x05]) == [0xfe, 0x4c, 0x52, 0x4f]



# Generated at 2022-06-24 11:23:30.067170
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist("ssl-confused-tls")
    expanded_key = key_expansion(data)
    assert intlist_to_bytes(aes_encrypt(data, expanded_key)) == b'\x1c\xe7\x8f\xef\x03\x58\x9d\x98\x6d\xb6\xf3\x15\x2a\x32\xf3\x5f'



# Generated at 2022-06-24 11:23:41.036129
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xA, 0xB, 0xC, 0xD, 0xE, 0xF]) == \
           [0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76]

# Generated at 2022-06-24 11:23:52.023071
# Unit test for function aes_encrypt
def test_aes_encrypt():
    txt = "Hello World! I'm so happy today.\n"
    key = "k1y9hg7xdehemkfz"
    iv = "12345678abcdefgh"

    data = bytes_to_intlist(txt.encode("latin1"))
    key = bytes_to_intlist(key.encode("latin1"))
    iv = bytes_to_intlist(iv.encode("latin1"))
    expanded_key = key_expansion(key)
    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-24 11:23:56.474736
# Unit test for function mix_columns
def test_mix_columns():
    print("test mix_columns...")
    data = [0x9, 0xB, 0xD, 0xE]
    result = mix_columns(data)
    print(result)



# Generated at 2022-06-24 11:24:02.270328
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    word = [0x63,0x7C,0x77,0x7B,0xF2,0x6B,0x6F,0xC5,0x30,0x01,0x67,0x2B,0xFE,0xD7,0xAB,0x76]
    expected = [0x52,0x09,0x6A,0xD5,0x30,0x36,0xA5,0x38,0xBF,0x40,0xA3,0x9E,0x81,0xF3,0xD7,0xFB]
    assert expected == sub_bytes_inv(word)
#test_sub_bytes_inv()


# Generated at 2022-06-24 11:24:04.722122
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3,4,5]) == [2,3,4,5,1]


# Generated at 2022-06-24 11:24:08.804827
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print("\nTest rijndael_mul:")
    print("[1, 2, 3, 4] * [2, 3, 4, 1]:", end = " ")
    print([rijndael_mul(x,y) for x, y in zip(MIX_COLUMN_MATRIX[0], MIX_COLUMN_MATRIX[1])])
    print("[4, 1, 1, 2] * [4, 1, 2, 3]:", end = " ")
    print([rijndael_mul(x,y) for x, y in zip(MIX_COLUMN_MATRIX[3], MIX_COLUMN_MATRIX[1])])
    print(rijndael_mul(1, 1))



# Generated at 2022-06-24 11:24:19.445748
# Unit test for function key_expansion
def test_key_expansion():
    # key size: 16 Byte
    key = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')

# Generated at 2022-06-24 11:24:22.844651
# Unit test for function shift_rows
def test_shift_rows():
    assert shift_rows([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]) == [1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15, 4, 8, 12, 16]



# Generated at 2022-06-24 11:24:27.661648
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = "00112233445566778899aabbccddeeff"
    data = to_bytes(data)
    data = mix_columns(data)
    data = mix_columns_inv(data)
    data = to_hex(data)
    assert data == "00112233445566778899aabbccddeeff"


# Generated at 2022-06-24 11:24:31.081198
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x01, 0x01, 0x01, 0x01]) == [0x63, 0x63, 0x63, 0x63]


# Generated at 2022-06-24 11:24:41.771070
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x83) == 0xC1
    assert rijndael_mul(0x13, 0x53) == 0xFE
    assert rijndael_mul(0x47, 0x42) == 0xF7
    assert rijndael_mul(0x1B, 0xE0) == 0x3C
    assert rijndael_mul(0xFA, 0x83) == 0xE5
    assert rijndael_mul(0x13, 0x54) == 0x01
    assert rijndael_mul(0x47, 0x43) == 0x8E
    assert rijndael_mul(0x1B, 0xE1) == 0x84
    assert rijndael

# Generated at 2022-06-24 11:24:49.554224
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    known_text = '''
    The quick brown fox jumps over the lazy dog

    A long time ago, in a galaxy far, far away...

    The Cryptograffiti Project

    Brian LaMacchia

    Crypto party

    SHA-1 is not secure

    The Modern Cryptography CookBook for Just Developers

    Cryptographic right answers, backdoored

    No more secrets

    Trust no one

    The only secure system is one that is powered off, cast in a block
    of concrete and sealed in a lead-lined room with armed guards --
    and even then I have my doubts.
    '''

    known_password = 'abcdefghijklmnop'
    known_key_size_bytes = 32

# Generated at 2022-06-24 11:24:55.346922
# Unit test for function mix_columns
def test_mix_columns():
    expected1 = [0xF2, 0x2F, 0x71, 0x4E,
                 0x83, 0xEF, 0xFC, 0x66,
                 0x79, 0xC9, 0x38, 0xD6,
                 0x17, 0xA2, 0x36, 0x91]
    expected2 = [0x10, 0x2B, 0x88, 0xB0,
                 0x36, 0x33, 0x1B, 0x6E,
                 0x67, 0xC6, 0x6D, 0x83,
                 0xC3, 0x44, 0xF2, 0xE0]

# Generated at 2022-06-24 11:25:06.065092
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b'abcdefghijklmnop')
    key = bytes_to_intlist(b'1234567890123456')
    key = key + [0]*16
    iv = bytes_to_intlist(b'qazwsxedcrfvtgby')
    enc = aes_cbc_encrypt(data, key, iv)

    assert enc == [
        0x30, 0xc0, 0x0e, 0x31, 0x08, 0xda, 0x4e, 0x4a,
        0x13, 0x5f, 0x7e, 0x40, 0xf5, 0xbd, 0x36, 0xf0
    ]


# Generated at 2022-06-24 11:25:11.142642
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_inv = mix_columns_inv(data)
    assert data_inv == [0x8E, 0x4D, 0xA1, 0xBC, 0x9F, 0xDC, 0x58, 0x9D, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]


test_mix_columns_inv()

# Generated at 2022-06-24 11:25:20.226352
# Unit test for function mix_columns
def test_mix_columns():
    result = mix_columns([0x4, 0x4, 0x4, 0x4, 0x4, 0x4, 0x4, 0x4, 0x4, 0x4, 0x4, 0x4, 0x4, 0x4, 0x4, 0x4])
    expected = [0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10]
    assert(result == expected)
test_mix_columns()


# Generated at 2022-06-24 11:25:29.391401
# Unit test for function rijndael_mul
def test_rijndael_mul():
    test_values = (0x57, 0x83, 0x98, 0x16, 0x28, 0xae, 0xd2, 0xa6,
                   0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c)
    for a in range(0, 0xFF):
        for b in range(0, 0xFF):
            p = rijndael_mul(a, b)

# Generated at 2022-06-24 11:25:32.491346
# Unit test for function rotate
def test_rotate():
    assert rotate([0x0,0x1,0x2,0x3]) == [0x1,0x2,0x3,0x0]


# Generated at 2022-06-24 11:25:37.855309
# Unit test for function key_schedule_core
def test_key_schedule_core():
    test_data = [0x01, 0x02, 0x03, 0x04]
    iteration_count = 1
    expected_result = [0x01, 0x03, 0x05, 0x0F]
    actual_result = key_schedule_core(test_data, iteration_count)
    assert actual_result == expected_result, "Expected {}, but got {}".format(expected_result, actual_result)



# Generated at 2022-06-24 11:25:49.652276
# Unit test for function aes_encrypt

# Generated at 2022-06-24 11:25:58.111742
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0x07, 0xa8, 0x8d, 0xa2, 0x34]
    data_shifted = [0x32, 0x88, 0x31, 0xe0, 0x5a, 0x31, 0x37, 0x43, 0x30, 0x98, 0x07, 0xf6, 0x8d, 0xa2, 0x34, 0xa8]
    assert shift_rows(data) == data_shifted



# Generated at 2022-06-24 11:26:05.291738
# Unit test for function aes_decrypt
def test_aes_decrypt():
    input_data = bytes_to_intlist('54776F204F6E65204E696E652054776F')
    expanded_key = key_expansion(bytes_to_intlist('5468617473206D79204B756E67204675'))
    expected_output = bytes_to_intlist('746865206B696420646F6E277420706C6179')
    actual_output = aes_decrypt(input_data, expanded_key)
    print(actual_output)
    print(expected_output)
    assert actual_output == expected_output
test_aes_decrypt()


# Generated at 2022-06-24 11:26:09.487070
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert([0x04, 0x66, 0x81, 0xE5] == mix_columns_inv([0x69, 0xC4, 0xE0, 0xD8]))



# Generated at 2022-06-24 11:26:16.016851
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 1) == [0x01, 0x03, 0x04, 0x05]



# Generated at 2022-06-24 11:26:21.332891
# Unit test for function shift_rows
def test_shift_rows():
    print("Shift rows test")
    i = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    out = shift_rows(i)
    print("Input :  " + "".join("{:02x}".format(x) for x in i))
    print("Output : " + "".join("{:02x}".format(x) for x in out))

# Generated at 2022-06-24 11:26:23.499028
# Unit test for function inc
def test_inc():
    data = [0x00, 0x00, 0x00, 0x01]
    print(bytes(data))
    print(bytes(inc(data)))



# Generated at 2022-06-24 11:26:32.532106
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """
    Test data taken from http://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38a.pdf
    Appendix F.2  Example Vectors
    """

# Generated at 2022-06-24 11:26:38.796984
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0] * 16
    data[0] = 0xF2
    data[5] = 0x06
    data[10] = 0xFF
    data[15] = 0xAA
    # shoud be equal to
    data_expected = [0] * 16
    data_expected[0] = 0xF2
    data_expected[5] = 0xAA
    data_expected[10] = 0xFF
    data_expected[15] = 0x06
    assert shift_rows_inv(shift_rows(data)) == data_expected



# Generated at 2022-06-24 11:26:42.708988
# Unit test for function mix_column
def test_mix_column():
    assert mix_column([0xDB, 0x13, 0x53, 0x45], MIX_COLUMN_MATRIX) == [0x8E, 0x4D, 0xA1, 0xBC]
    assert mix_column([0x8E, 0x4D, 0xA1, 0xBC], MIX_COLUMN_MATRIX_INV) == [0xDB, 0x13, 0x53, 0x45]


test_mix_column()



# Generated at 2022-06-24 11:26:55.368098
# Unit test for function mix_columns
def test_mix_columns():
    m = [[0xdb, 0x13, 0x53, 0x45],
         [0xf2, 0x0a, 0x22, 0x5c],
         [0x01, 0x01, 0x01, 0x01],
         [0x5d, 0xf0, 0xfa, 0x1f]]
    assert mix_columns(flatten(m)) == flatten_nested_lists([[0x8e, 0x4d, 0xa1, 0xbc],
                                                [0x9f, 0xa0, 0x10, 0x20],
                                                [0x01, 0x01, 0x01, 0x01],
                                                [0x01, 0x1f, 0x1f, 0x1f]])

# Generated at 2022-06-24 11:27:00.334280
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert mix_columns_inv(data) == expected



# Generated at 2022-06-24 11:27:08.046955
# Unit test for function inc
def test_inc():
    data = [0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    print(inc(data))



# Generated at 2022-06-24 11:27:20.328832
# Unit test for function inc
def test_inc():
    if inc([0, 0, 0, 0]) != [0, 0, 0, 1]:
        return False
    if inc([1, 0, 0, 0]) != [1, 0, 0, 1]:
        return False
    if inc([0, 1, 0, 0]) != [0, 1, 0, 1]:
        return False
    if inc([0, 0, 1, 0]) != [0, 0, 1, 1]:
        return False
    if inc([0, 0, 0, 255]) != [0, 0, 1, 0]:
        return False
    if inc([0, 0, 255, 255]) != [0, 1, 0, 0]:
        return False
    if inc([0, 255, 255, 255]) != [1, 0, 0, 0]:
        return False

# Generated at 2022-06-24 11:27:29.537468
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test: aes_decrypt_text
    """
    def test(message, password):
        for key_size_bytes in (16, 24, 32):
            ciphertext = aes_encrypt_text(message, password, key_size_bytes)
            plaintext = aes_decrypt_text(ciphertext, password, key_size_bytes)
            assert plaintext == message, 'aes_decrypt_text'
    test('Some cleartext', 'Correct Horse Battery Staple')
    test(
        'Verifying that the correct password gets us to a readable message is important.',
        'password'
    )



# Generated at 2022-06-24 11:27:39.568597
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    cipher = bytes_to_intlist(
        compat_b64decode(
            'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    counter = Counter.new(BSON.decode(b'foobar')[0])

    decrypted = intlist_to_bytes(
        aes_ctr_decrypt(cipher, key, counter))
    assert decrypted.startswith(b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby ')


# -----------------------------------------------------------------------------

# Constants
# Rijndael S-box
sbox

# Generated at 2022-06-24 11:27:49.128222
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA, 0xAA]
    expected = [0xB8, 0xF7, 0xB1, 0xA2, 0xE3, 0x9E, 0x61, 0xA8, 0x80, 0x29, 0xF2, 0xBB, 0xF9, 0x90, 0x1F, 0x88]
    assert sub_bytes(data) == expected


# Generated at 2022-06-24 11:27:58.458920
# Unit test for function mix_columns
def test_mix_columns():
    print('Unit test for function mix_columns')
    matrix = ((0, 1, 2, 3), (4, 5, 6, 7), (8, 9, 10, 11), (12, 13, 14, 15))
    data_matrix_mixed = mix_columns([x for x in range(16)], matrix)
    print('After mix_columns:')
    print(data_matrix_mixed)
    assert(mix_columns([x for x in range(16)]) == data_matrix_mixed)
    print('Unit test passed')


# Generated at 2022-06-24 11:28:07.784840
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    def check_encrypt(cleartext, expected, key, iv):
        encrypted = aes_cbc_encrypt(cleartext, key, iv)
        assert encrypted == expected

    cleartext = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd,
                 0xee, 0xff]
    expected = [0x69, 0xc4, 0xe0, 0xd8, 0x6a, 0x7b, 0x04, 0x30, 0xd8, 0xcd, 0xb7, 0x80, 0x70, 0xb4,
                 0xc5, 0x5a]

# Generated at 2022-06-24 11:28:19.389704
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-24 11:28:28.845606
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Test with key size: 256-Bit (32)
    # encrypted_data = 'Qwv1cFmW8ll9qrqr1pHvguYsnDg8TzBbNxHPwFv+NtE1pZ9XlLkfJRIvNYbY0W/y'
    data = 't8ZcJzKcyw63MvYnW+Q2XJGzkk65j1+vnmGelZk8xR0='
    password = 'password'
    key_size_bytes = 32
    actual = aes_decrypt_text(data, password, key_size_bytes)
    expected = 'The counter mode of operation is another example of the use of an unstructured block cipher as a stream cipher.'
    print(actual)
    # print

# Generated at 2022-06-24 11:28:34.957656
# Unit test for function aes_decrypt
def test_aes_decrypt():
    assert(
        intlist_to_bytes(
            aes_decrypt(
                bytes_to_intlist('69C4E0D86A7B0430D8CDB78070B4C55A'),
                bytes_to_intlist('603DEB1015CA71BE2B73AEF0857D77811F352C073B6108D72D9810A30914DFF4')))
        == '00112233445566778899aabbccddeeff')



# Generated at 2022-06-24 11:28:42.008972
# Unit test for function xor
def test_xor():
    data1 = [0x37, 0x13, 0x39]
    data2 = [0x2b, 0x0a, 0x17]
    data_xor = xor(data1, data2)
    print (data_xor)
    assert data_xor == [0x1c, 0x19, 0x2e]


# Generated at 2022-06-24 11:28:46.083289
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x19, 0xa0, 0x9a, 0xe9]) == [0xd4, 0xe0, 0xb8, 0x1e]


# Generated at 2022-06-24 11:28:58.641981
# Unit test for function mix_columns
def test_mix_columns():
    # Test 1
    data = [0x19, 0x3d, 0xe3, 0xbe, 0xa0, 0xf4, 0xe2, 0x2b, 0x9a, 0xc6, 0x8d, 0x2a, 0xe9, 0xf8, 0x48, 0x08]
    data_mixed = mix_columns(data)
    assert(data_mixed == [0xd4, 0xe0, 0xb8, 0x1e, 0x27, 0xbf, 0xb4, 0x41, 0x11, 0x98, 0x5d, 0x52, 0xae, 0xf1, 0xe5, 0x30])
    # Test 2

# Generated at 2022-06-24 11:29:08.429866
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [
                0x19,0xa0,0x9a,0xe9,0x3d,0xf4,0xc6,0xf8,0xe3,0xe2,0x8d,0x48,0xbe,0x2b,0x2a,0x08
            ]
    expected_output = [
                0xd4,0xe0,0xb8,0x1e,0x27,0xbf,0xb4,0x41,0x11,0x98,0x5d,0x52,0xae,0xf1,0xe5,0x30,

                ]

# Generated at 2022-06-24 11:29:10.175422
# Unit test for function rotate
def test_rotate():
    assert rotate(
        [0x2b, 0x28, 0xab, 0x09]) == [0x28, 0xab, 0x09, 0x2b]



# Generated at 2022-06-24 11:29:15.960602
# Unit test for function mix_column
def test_mix_column():
    assert mix_column([0x14, 0x11, 0xE2, 0xB2], MIX_COLUMN_MATRIX) == [0x4e, 0x27, 0xae, 0x7d]


# Generated at 2022-06-24 11:29:21.836804
# Unit test for function mix_column
def test_mix_column():
    A = 0x57
    B = 0x83
    C = 0xE9
    D = 0x7E
    E = 0xD3
    F = 0xF2
    G = 0x3B
    H = 0x4C
    data_test = [A, B, C, D]
    assert mix_column(data_test, MIX_COLUMN_MATRIX) == [E, F, G, H]



# Generated at 2022-06-24 11:29:30.181880
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    import base64
    assert aes_cbc_encrypt(
        bytes_to_intlist(b'1234567890123456'),
        bytes_to_intlist(b'YELLOW SUBMARINE'),
        bytes_to_intlist(b'\x00' * 16)
    ) == bytes_to_intlist(base64.b64decode(b'CRIwqt4+szDbqkNY+I0qbDe3LQz0wiw0'
                                           b'SuxBQtAM5TDdMbjCMD/venUDW9BLPEXODbk6a48o'))

# Generated at 2022-06-24 11:29:44.241190
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv([0x52, 0x09, 0x6A, 0xD5, 0x30, 0x36, 0xA5, 0x38, 0xBF, 0x40, 0xA3, 0x9E, 0x81, 0xF3, 0xD7, 0xFB]) == [0xA4, 0x68, 0x6B, 0x02, 0x9C, 0x9F, 0x5B, 0x6A, 0xF2, 0x6B, 0x77, 0xB3, 0x73, 0x2B, 0xFE, 0xD3]



# Generated at 2022-06-24 11:29:50.337107
# Unit test for function shift_rows
def test_shift_rows():
    x = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    y = shift_rows(x)[:]
    assert y == [0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11]



# Generated at 2022-06-24 11:29:56.829308
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert shift_rows_inv([4, 8, 12, 16, 5, 9, 13, 17, 6, 10, 14, 18, 7, 11, 15, 19]) == [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
    assert shift_rows_inv([5, 9, 13, 17, 6, 10, 14, 18, 7, 11, 15, 19, 4, 8, 12, 16]) == [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 4, 5, 6, 7]

# Generated at 2022-06-24 11:30:01.601062
# Unit test for function inc
def test_inc():
    x = [1, 2, 3, 4, 255]
    assert inc(x) == [1, 2, 3, 5, 0]
    assert inc([0, 0, 0, 0, 0]) == [0, 0, 0, 0, 1]



# Generated at 2022-06-24 11:30:10.229329
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .test_vectors import (
        AES_KEY_128, AES_KEY_192, AES_KEY_256,
        AES_COUNTER, AES_COUNTER_VALUE, AES_DATA_COUNTER_128,
        AES_DATA_COUNTER_192, AES_DATA_COUNTER_256)
    key = bytes_to_intlist(AES_KEY_128)
    data = bytes_to_intlist(compat_b64decode(AES_DATA_COUNTER_128))
    decrypted_data = aes_ctr_decrypt(data, key, AES_COUNTER())
    expected = 'Counter Mode Test'

# Generated at 2022-06-24 11:30:15.097793
# Unit test for function xor
def test_xor():
    test_data_1 = [1, 0, 0, 1]
    test_data_2 = [1, 1, 1, 0]
    assert xor(test_data_1, test_data_2) == [0, 1, 1, 1]


test_xor()

# Generated at 2022-06-24 11:30:19.732993
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3,4]) == [2,3,4,1]
    assert rotate([1,2,3,4,5,6,7,8]) == [2,3,4,5,6,7,8,1]
    assert rotate([1]) == [1]


# Generated at 2022-06-24 11:30:26.184046
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x54, 0x77, 0x6F, 0x20]
    rcon_iteration = 1
    output = [0x54, 0x47, 0x64, 0x21]
    assert key_schedule_core(data, rcon_iteration) == output
    print("Test key_schedule_core Passed")



# Generated at 2022-06-24 11:30:34.959139
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-24 11:30:38.685024
# Unit test for function xor
def test_xor():
    original1 = [0x01, 0x02, 0x03, 0x04]
    original2 = [0x04, 0x03, 0x02, 0x01]
    result = xor(original1, original2)
    print("[debug] result from xor: " + str(result))

# Generated at 2022-06-24 11:30:45.650021
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0xf2, 0xd4, 0x6e, 0x45, 0xf9, 0xa5, 0xfe, 0x19, 0x5d, 0xb1, 0x3e, 0x52, 0x21, 0x5c, 0x94]
    data_mixed = mix_columns(data)
    assert data_mixed == [0x8e, 0x04, 0x0d, 0x0e, 0x2b, 0x2f, 0xb4, 0x34, 0x90, 0x49, 0xde, 0x4c, 0x76, 0x89, 0xab, 0xfa]
    print("Function Mix_Columns is working properly")


if __name__ == "__main__":
    test_mix_columns()

# Generated at 2022-06-24 11:31:00.919720
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x2b,0x7e,0x15,0x16,0x28,0xae,0xd2,0xa6,0xab,0xf7,0x15,0x88,0x09,0xcf,0x4f,0x3c]
    iv = [0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f]

# Generated at 2022-06-24 11:31:13.724149
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    print("")
    print("Testing aes_decrypt_text")

    password = "Passwort"


# Generated at 2022-06-24 11:31:16.171461
# Unit test for function rotate
def test_rotate():
    assert rotate([0x63, 0xeb, 0x9f, 0xa0]) == [0xeb, 0x9f, 0xa0, 0x63]



# Generated at 2022-06-24 11:31:23.120806
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    if not bool(os.environ.get("YTDL_TEST", False)):
        return
    data = bytes_to_intlist(compat_b64decode(
        'KrD0yeTvT8TgTjKFY6w3i6Z1c6U+W6R9XlBMi2SRyI='))
    key = bytes_to_intlist(compat_b64decode('MzPY9Ho3/q/jvF7dN/t1uw=='))
    iv = bytes_to_intlist(compat_b64decode('n0E1REj+HHIu4w4w0Zgsdw=='))
    output = aes_cbc_decrypt(data, key, iv)

# Generated at 2022-06-24 11:31:27.907072
# Unit test for function key_schedule_core
def test_key_schedule_core():
    expected = [0x2,0x3,0x0,0x1]
    actual = key_schedule_core([1,2,3,4], 1)
    if expected == actual:
        print("key_sched_core Test: Pass")
    else:
        print("key_sched_core Test: Fail")