

# Generated at 2022-06-22 06:29:29.763045
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    input = 0xE1
    output = 0x77
    if sub_bytes_inv([input])[0] != output:
        print("[Error] fail testing sub_bytes inverse")
        print("\tinput = ", hex(input))
        print("\toutput = ", hex(sub_bytes_inv([input])[0]))
    else:
        print("[Info] testing sub_bytes inverse success")
# Unit test
test_sub_bytes_inv()


# Generated at 2022-06-22 06:29:37.650445
# Unit test for function rotate
def test_rotate():
    assert ((rotate([1, 2, 3, 4, 5, 6, 7, 8])) == [2, 3, 4, 5, 6, 7, 8, 1])
    assert ((rotate([1, 2, 3, 4, 5, 6, 7, 8])) != [2, 3, 4, 5, 6, 7, 88, 1])
    assert ((rotate([1, 2, 3, 4, 5, 6, 7, 8])) != [6, 7, 8, 1, 2, 3, 4, 5])
    
test_rotate()



# Generated at 2022-06-22 06:29:48.000157
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from . import crypto
    key = 'QkFMAQMAABAAAARLQ0FBRAAAAAChNTkhhYjM1YWYwZTk1NGExNTczNzg0MmEyNjYwNzkyOTllZgA='
    data = 'd1BiTnZ6T3Z3WWpZdytKMmA='
    key = compat_b64decode(key)
    key = bytes_to_intlist(key)
    data = compat_b64decode(data)
    data = bytes_to_intlist(data)
    count = crypto.Counter(0)
    result = aes_ctr_decrypt(data, key, count)

# Generated at 2022-06-22 06:29:54.427714
# Unit test for function shift_rows
def test_shift_rows():
    data= [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    assert(shift_rows(data) == [0x00, 0x05, 0x0a, 0x0f, 0x04, 0x09, 0x0e, 0x03, 0x08, 0x0d, 0x02, 0x07, 0x0c, 0x01, 0x06, 0x0b])



# Generated at 2022-06-22 06:29:58.432529
# Unit test for function sub_bytes
def test_sub_bytes():
    assert [0x63, 0x53, 0xE0, 0x8C, 0x09, 0x60, 0xE1, 0x04, 0xCD, 0x70, 0xB7, 0x51, 0xBA, 0xCA, 0xB4, 0x4D] == \
           sub_bytes([0x19, 0xa0, 0x9a, 0xe9, 0x3d, 0xf4, 0xc6, 0xf8, 0xe3, 0xe2, 0x8d, 0x48, 0xbe, 0x2b, 0x2a, 0x08])



# Generated at 2022-06-22 06:30:08.888413
# Unit test for function xor
def test_xor():
    assert xor([0xFF, 0xFF, 0xFF, 0xFF], [0xFF, 0xFF, 0xFF, 0xFF]) == [0x0, 0x0, 0x0, 0x0]
    assert xor([0xFF, 0x00, 0xFF, 0x00], [0xFF, 0x00, 0xFF, 0x00]) == [0x0, 0x0, 0x0, 0x0]
    assert xor([0xFF, 0xFF, 0xFF, 0xFF], [0x0, 0x0, 0x0, 0x0]) == [0xFF, 0xFF, 0xFF, 0xFF]

# Generated at 2022-06-22 06:30:20.655360
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytes_to_intlist(b'a' * 32)
    key = bytes_to_intlist(b'a' * 16)
    iv = bytes_to_intlist(b'a' * 16)

    assert(hex(intlist_to_bytes(aes_cbc_decrypt(data, key, iv)))                         == '0xe6fbc299337f81116b58f2293e4e4339')
    assert(hex(intlist_to_bytes(aes_cbc_decrypt(data, bytes_to_intlist(b'a' * 24), iv))) == '0xf2a1e44577dfd687c8a0b95a2b1fa3e1')

# Generated at 2022-06-22 06:30:29.256204
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    expected_decrypted_data = [0x54, 0x77, 0x6f, 0x20, 0x4f, 0x6e, 0x65, 0x20, 0x4e, 0x69, 0x6e, 0x65, 0x20, 0x54,
                               0x77, 0x6f]

# Generated at 2022-06-22 06:30:33.473903
# Unit test for function mix_columns
def test_mix_columns():
    mixed = [0xdb, 0x13, 0x53, 0x45,
             0xf2, 0x0a, 0x22, 0x5c,
             0x01, 0x01, 0x01, 0x01,
             0x01, 0x01, 0x01, 0x01]
    original = [0xd4, 0xbf, 0x5d, 0x30,
                0xe0, 0xb4, 0x52, 0xae,
                0xb8, 0x41, 0x11, 0xf1,
                0x1e, 0x27, 0x98, 0xe5]
    assert(mix_columns(original, MIX_COLUMN_MATRIX) == mixed)

# Generated at 2022-06-22 06:30:40.734558
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xDB, 0x13, 0x53, 0x45,
            0xF2, 0x0A, 0x22, 0x5C,
            0x01, 0x01, 0x01, 0x01,
            0x01, 0x01, 0x01, 0x01]

    actual = mix_columns(data)

    expected = [0x8E, 0x4D, 0xA1, 0xBC,
                0x9F, 0xDC, 0x58, 0x9D,
                0x01, 0x01, 0x01, 0x01,
                0x01, 0x01, 0x01, 0x01]
    print(expected)
    print(actual)
    return True

test_mix_columns()

# AES Encryption

# Generated at 2022-06-22 06:31:00.477618
# Unit test for function key_expansion
def test_key_expansion():
  key = [83, 189, 231, 80, 85, 156, 180, 210, 73, 167, 34, 24, 73, 228, 236, 116, 117, 209, 160, 122, 254, 55, 204, 164, 232, 219, 152, 165, 11, 243, 97, 217]

# Generated at 2022-06-22 06:31:09.756914
# Unit test for function mix_columns
def test_mix_columns():
    data_in = [0xdb, 0xf2, 0xd4, 0x6f, 0xbc, 0x7d, 0x76, 0x91, 0x25, 0x3b, 0x10, 0x0c, 0x52, 0x3e, 0xcf, 0xda]
    expected_out = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x26, 0x76, 0xba, 0xd4, 0x09, 0x0d, 0x70]
    out = mix_columns(data_in)
    assert(out == expected_out), f"Expected: {expected_out} Got: {out}"



# Generated at 2022-06-22 06:31:20.832919
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Example taken from https://en.wikipedia.org/wiki/Block_cipher_mode_of_operation#Counter_.28CTR.29
    encrypted = '69dda8455c7dd4254bf353b773304eec0ec7702330098ce7f7520d1cbbb20fc388d1b0adb5054dbd7370849dbf0b88d393f252e764f1f5f7ad97ef79d59ce29f5f51eeca32eabedd9afa9329'
    expected = 'This is a 48-byte message (exactly 3 AES blocks)'

# Generated at 2022-06-22 06:31:29.983638
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
    encrypted_data = aes_ctr_decrypt(data, [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], IncrementCounter('', 16))
    assert encrypted_data == [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]


# Generated at 2022-06-22 06:31:34.158447
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    expected = [1, 6, 11, 16, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12]
    assert shift_rows_inv(data) == expected



# Generated at 2022-06-22 06:31:39.918557
# Unit test for function mix_column
def test_mix_column():
    input_data = [0x02, 0x03, 0x01, 0x01]
    data_mixed = mix_column(input_data, MIX_COLUMN_MATRIX)
    assert(data_mixed == [0x04, 0x0E, 0x0E, 0x04])
    #print(data_mixed)



# Generated at 2022-06-22 06:31:44.336987
# Unit test for function mix_column
def test_mix_column():
    # Given
    data_input = [0xDB, 0x13, 0x53, 0x45]
    # When
    data_output = mix_column(data_input,MIX_COLUMN_MATRIX)
    # Then
    print(data_output)
    assert data_output == [0x8E, 0x4D, 0xA1, 0xBC]



# Generated at 2022-06-22 06:31:52.331429
# Unit test for function mix_column
def test_mix_column():
    print("Unit test for function mix_column")
    # 0xdb ^ 0x01 ^ 0x01 ^ 0x01 ^ 0x01 ^ 0x01 ^ 0x01 ^ 0x01 ^ 0x01 ^ 0x01 ^ 0x01 ^ 0x01 ^ 0x01 ^ 0x01 ^ 0x01 ^ 0x01 ^ 0x01 ^ 0x01 ^ 0x01 ^
    data = [0xdb, 0x13, 0x53, 0x45]
    data_after_mix_col = mix_column(data, MIX_COLUMN_MATRIX_INV)
    print(data_after_mix_col)
    print("Unit test for function mix_column")

test_mix_column()



# Generated at 2022-06-22 06:31:56.939486
# Unit test for function mix_column
def test_mix_column():
    data = [0xDB, 0x13, 0x53, 0x45]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    assert(data_mixed == [0x01, 0x01, 0x01, 0x01])


# Generated at 2022-06-22 06:32:04.385550
# Unit test for function inc
def test_inc():
    data = [0, 0, 0, 0]
    x = inc(data)
    assert x == [1, 0, 0, 0]
    x = inc(x)
    assert x == [2, 0, 0, 0]
    x = inc(x)
    assert x == [3, 0, 0, 0]
    x = inc(x)
    assert x == [0, 1, 0, 0]
    x = inc(x)
    assert x == [1, 1, 0, 0]
    x = inc(x)
    assert x == [2, 1, 0, 0]
    x = inc(x)
    assert x == [3, 1, 0, 0]



# Generated at 2022-06-22 06:32:18.696991
# Unit test for function key_expansion
def test_key_expansion():
    from .compat import compat_b64decode

    # AES-128

# Generated at 2022-06-22 06:32:22.003978
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes(bytes.fromhex('3925841d02dc09fbdc118597196a0b32')) == bytes.fromhex('d4bf5d30e0b452aeb84111f11e2798e5')


# Generated at 2022-06-22 06:32:32.640706
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    cleartext = bytes_to_intlist(b'1234567812345678')
    cipherkey = bytes_to_intlist(b'12345678123456781234567812345678')
    iv = bytes_to_intlist(b'1234567887654321')
    encrypted = aes_cbc_encrypt(cleartext, cipherkey, iv)
    assert(compat_b64decode(b'YShjCwDgxl3q5q5ZAVI8FQ==') == intlist_to_bytes(encrypted))



# Generated at 2022-06-22 06:32:34.738439
# Unit test for function shift_rows
def test_shift_rows():
    data = []
    for i in range(16):
        data.append(i)
    print(shift_rows(data))



# Generated at 2022-06-22 06:32:46.555397
# Unit test for function sub_bytes
def test_sub_bytes():
    print("Unittest for function sub_bytes")
    test_data = [0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f]
    expected_result = [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]
    result = sub_bytes(test_data)
    if result == expected_result:
        print("Test passed")

# Generated at 2022-06-22 06:32:57.282026
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist(b'\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff')
    expanded_key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f')

# Generated at 2022-06-22 06:33:01.168173
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert(mix_columns_inv(mix_columns([1, 2, 3, 4])) == [1, 2, 3, 4])
    assert(mix_columns_inv(mix_columns([0, 0, 0, 0])) == [0, 0, 0, 0])
    assert(mix_columns_inv(mix_columns([0x10, 0x20, 0x30, 0x40])) == [0x10, 0x20, 0x30, 0x40])
    assert(mix_columns_inv(mix_columns([0xFF, 0xFF, 0xFF, 0xFF])) == [0xFF, 0xFF, 0xFF, 0xFF])



# Generated at 2022-06-22 06:33:08.598957
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    data = [0x0,0x1,0x2,0x3,0x4,0x5,0x6,0x7,0x8,0x9,0xa,0xb,0xc,0xd,0xe,0xf]
    print(data)
    data_inv = sub_bytes_inv(data)
    print(data_inv)
    data_sub = sub_bytes(data_inv)
    print(data_sub)
#test_sub_bytes_inv()    



# Generated at 2022-06-22 06:33:19.141103
# Unit test for function aes_encrypt
def test_aes_encrypt():
    ### Example from https://en.wikipedia.org/wiki/Advanced_Encryption_Standard#Example_vectors
    key = [ 0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c ]
    plain_text = [ 0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d,  0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34 ]

# Generated at 2022-06-22 06:33:25.036466
# Unit test for function rijndael_mul
def test_rijndael_mul():
    n = 16
    for i in range(n):
        for j in range(n):
            print ("%x * %x = %x" % (i, j, rijndael_mul(i, j)))
    assert rijndael_mul(0x57, 0x83) == 0xc1
test_rijndael_mul()



# Generated at 2022-06-22 06:33:31.452835
# Unit test for function mix_columns
def test_mix_columns():
    column = [0xdb, 0x13, 0x53, 0x45]
    result = mix_columns(column)
    assert(0x8e == result[0] and 0x4d == result[1] and 0xa1 == result[2] and 0xbc == result[3])



# Generated at 2022-06-22 06:33:33.740993
# Unit test for function rotate
def test_rotate():
    assert(rotate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]) == [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 1])



# Generated at 2022-06-22 06:33:37.119974
# Unit test for function mix_columns
def test_mix_columns():
    data = [0x0e, 0x09, 0x0d, 0x0b, 0x0b, 0x0e, 0x09, 0x0d, 0x0d, 0x0b, 0x0e, 0x09, 0x09, 0x0d, 0x0b, 0x0e]
    data_mixed = mix_columns(data)
    print(data_mixed)
#test_mix_columns()



# Generated at 2022-06-22 06:33:42.937584
# Unit test for function aes_encrypt
def test_aes_encrypt():
    cleartext = [0x54, 0x68, 0x65, 0x20, 0x71, 0x75, 0x66, 0x63, 0x6B, 0x20, 0x62, 0x72, 0x6F, 0x77, 0x6E, 0x20, 0x66, 0x6F, 0x78, 0x20, 0x6A, 0x75, 0x6D, 0x70, 0x20, 0x6F, 0x76, 0x65, 0x72, 0x20, 0x74, 0x68, 0x65, 0x20, 0x6C, 0x61, 0x7A, 0x79, 0x20, 0x64, 0x6F, 0x67]

# Generated at 2022-06-22 06:33:46.549815
# Unit test for function xor
def test_xor():
    assert xor([1, 3, 5], [2, 4, 6]) == [3, 7, 11]
#test_xor()

print("xor unit test passed!")



# Generated at 2022-06-22 06:33:55.076148
# Unit test for function aes_encrypt
def test_aes_encrypt():
    test_arr = [
        0x00112233,
        0x44556677,
        0x8899aabb,
        0xccddeeff,
    ]
    # test_arr = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]
    test_arr = bytes_to_intlist(intlist_to_bytes(test_arr))
    
    # assert 0==1

    # key = key_expansion([0x2b7e1516, 0x28aed2a6, 0xabf71588, 0x09cf4f3c])
    # key = key_

# Generated at 2022-06-22 06:33:58.550286
# Unit test for function inc
def test_inc():
    data = bytes([0x00, 0xFF, 0x00, 0x00])
    assert inc(data) == bytes([0x01, 0x00, 0x00, 0x00])



# Generated at 2022-06-22 06:34:10.369959
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = [0x5a, 0x3e, 0x5f, 0x1d, 0x52, 0xac, 0x74, 0x0b, 0x13, 0x07, 0x8c, 0x78, 0xf2, 0x14, 0x8a, 0x1c]

# Generated at 2022-06-22 06:34:13.671763
# Unit test for function shift_rows
def test_shift_rows():
    assert shift_rows([0x9f, 0xbf, 0xdf, 0xff, 0x00, 0x10, 0x20, 0x30, 0x40, 0x50, 0x60, 0x70, 0x80, 0x90, 0xa0, 0xb0]) == [0x9f,0xbf,0xdf,0xff,0x10,0x00,0x30,0x20,0x70,0x60,0x50,0x40,0xb0,0xa0,0x90,0x80]



# Generated at 2022-06-22 06:34:22.025830
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = bytes_to_intlist(b'Sixteen byte key')
    expanded_key = key_expansion(key)
    data = bytes_to_intlist(b'0123456789abcdef')
    cipher = aes_encrypt(data, expanded_key)
    assert intlist_to_bytes(cipher) == b'\x37\xa6\xef\x53\x7f\x45\x94\x0d\x6a\x27\x7d\xab\xa6\xf7\xd7\xfe'
# End of unit test function


# Generated at 2022-06-22 06:34:41.809036
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    input_data = '''
        6420666F726d205B6F75743D31333A31343A31343A31333A31343A31343A31323A31323A31323A31323A31323A31323A31323A31323A31323A31323A31323A3132305D'''
    input_key = '''
        166E64323437316234316665313465346436653662323339623331623134313961333832353265326232356366636613635306463633461626631623938'''
    input_iv = '''
        31323334353637383941424344454647'''

    key1 = bytes_to_intlist(compat_b64decode(input_key))


# Generated at 2022-06-22 06:34:51.146809
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0x00, 0x44, 0x88, 0xcc,
            0x11, 0x55, 0x99, 0xdd,
            0x22, 0x66, 0xaa, 0xee,
            0x33, 0x77, 0xbb, 0xff]
    key = [0x00, 0x01, 0x02, 0x03,
           0x04, 0x05, 0x06, 0x07,
           0x08, 0x09, 0x0a, 0x0b,
           0x0c, 0x0d, 0x0e, 0x0f]
    expanded_key = key_expansion(key)
    encrypted_data = aes_encrypt(data, expanded_key)

# Generated at 2022-06-22 06:35:03.233514
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Input must be base64 encoded string
    msg = "itxCBA2sOmIN0FWs3AnkZA=="
    assert aes_decrypt_text(msg, "g8fUWpHJN+iU", 16) == "Hello World!"
    assert aes_decrypt_text(msg, "Jpp772b+wv6DyUzP", 24) == "Hello World!"
    assert aes_decrypt_text(msg, "jFwcGxW+JfYDZMzR", 32) == "Hello World!"

    msg = "R+R7l4Byt4b0t3q0mZbA7Q=="

# Generated at 2022-06-22 06:35:06.929900
# Unit test for function xor
def test_xor():
    data1 = [1,2,3]
    data2 = [2,3,4]
    data = xor(data1,data2)
    assert data == [3,1,7]


# Generated at 2022-06-22 06:35:14.076942
# Unit test for function inc
def test_inc():
    assert(inc([0, 0, 0, 0]) == [0, 0, 0, 1])
    assert(inc([0, 0, 0, 255]) == [0, 0, 1, 0])
    assert(inc([0, 0, 255, 255]) == [0, 1, 0, 0])
    assert(inc([0, 255, 255, 255]) == [1, 0, 0, 0])
    assert(inc([255, 255, 255, 255]) == [0, 0, 0, 0])
    print("inc test passed!")


# Generated at 2022-06-22 06:35:26.252418
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    import pytest

    # Testing the example data in http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # Example 6.5

    # Cipher
    cipher = bytes_to_intlist(compat_b64decode(b'CRIwqt4+szDbqkNY+I0qbNXPg1X LaCM5etQ5Bt9DRFV/xIN2k8Go7jtArLIy'
                                              b'P605b071DL8C+FPYSHOXPkMMMFPAKm+'
                                              b'Nsu0nCBMQVt9mlluHbVE/yl6VaBCjNU'))
    # Key

# Generated at 2022-06-22 06:35:37.227524
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    given_input = [0x19, 0x3d, 0xe3, 0xbe, 0xa0, 0xf4, 0xe2, 0x2b, 0x9a, 0xc6, 0x8d, 0x2a, 0xe9, 0xf8, 0x48, 0x08]
    given_output = [0xd4, 0x27, 0x11, 0xae, 0xe0, 0xbf, 0x98, 0xf1, 0xb8, 0xb4, 0x5d, 0xe5, 0x1e, 0x41, 0x52, 0x30]
    assert sub_bytes_inv(given_input) == given_output


# Generated at 2022-06-22 06:35:44.799980
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x00, 0x10, 0x20, 0x30, 0x40, 0x50, 0x60, 0x70, 0x80, 0x90, 0xA0, 0xB0, 0xC0, 0xD0, 0xE0, 0xF0]) == [0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]



# Generated at 2022-06-22 06:35:49.474610
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    block_1 = [0x2, 0x4, 0x6, 0x8, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0]
    block_1_res = [0x2, 0x4, 0x6, 0x8, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0]

# Generated at 2022-06-22 06:35:58.091339
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns_inv(data)
    assert data_mixed == [0x95, 0x5e, 0x2a, 0x7c, 0x93, 0xd1, 0xd2, 0xed, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02]
    print('Unit test for mix_column_inv passed.')



# Generated at 2022-06-22 06:36:11.647750
# Unit test for function xor
def test_xor():
    data1 = [x for x in bytearray.fromhex(
        '13 11 7e 9a 57 43')]
    data2 = [x for x in bytearray.fromhex(
        '39 02 dc 19 23 2a')]
    expected = [x for x in bytearray.fromhex(
        '2A 13 52 81 7C 69')]
    result = xor(data1, data2)
    assert result == expected



# Generated at 2022-06-22 06:36:12.880666
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert(rijndael_mul(0x57, 0x13) == 0xFE)


# Generated at 2022-06-22 06:36:16.271780
# Unit test for function shift_rows
def test_shift_rows():
    assert(shift_rows([0x63, 0x53, 0xe0, 0x8c, 0x09, 0x60, 0xe1, 0x04, 0xcd, 0x70, 0xb7, 0x51, 0xba, 0xa6, 0x34, 0x20]) == [0x63, 0x53, 0x53, 0x53, 0x8c, 0x09, 0x60, 0xe1, 0x34, 0x20, 0xcd, 0x70, 0x0e, 0x1c, 0x38, 0x70])
    
test_shift_rows()

# Generated at 2022-06-22 06:36:27.802883
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytes_to_intlist(compat_b64decode(b'O8xafxB9X+FvJGnnOz8gqLwqf+rI6v+BJf8mp6xIb6XDUzHHYb6W8JcMw+FH1Mk5'))
    key = bytes_to_intlist(compat_b64decode(b'FQH7hJyAQmc/c+hdvPtq3Nt9N4Z/BzLk'))
    iv = bytes_to_intlist(compat_b64decode(b'Z9i4Bz0YWp+OyCwESy49Rw=='))


# Generated at 2022-06-22 06:36:32.282867
# Unit test for function inc
def test_inc():
    data = [0, 0, 0, 0]
    assert inc(data) == [0, 0, 0, 1]
    assert inc(data) == [0, 0, 0, 2]
    assert inc(data) == [0, 0, 0, 3]
    data = [0, 0, 255, 255]
    assert inc(data) == [0, 1, 0, 0]
    data = [255, 255, 255, 255]
    assert inc(data) == [0, 0, 0, 0]

# Generated at 2022-06-22 06:36:41.303268
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert(sub_bytes_inv([0x63, 0xEB, 0x9F, 0xA0, 0x30, 0xC0, 0xCD, 0x3B, 0x3F, 0xC3, 0xC5, 0xD4, 0x9A, 0x66, 0xEB, 0xF4]) == [0x39, 0x25, 0x84, 0x1D, 0x02, 0xDC, 0x09, 0xFB, 0xDC, 0x11, 0x85, 0x97, 0x19, 0x6A, 0x0B, 0x32])
    
    

# Generated at 2022-06-22 06:36:49.468414
# Unit test for function mix_column
def test_mix_column():
    for data in range(0x00, 0x100):
        data = [data, 0x00, 0x00, 0x00]
        data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
        data_mixed_inv = mix_column(data_mixed, MIX_COLUMN_MATRIX_INV)
        assert data == data_mixed_inv
    print('Mix column unit test is passed')


if __name__ == '__main__':
    test_mix_column()

# Generated at 2022-06-22 06:36:58.563995
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    # Check mix_columns_inv against mix_columns
    if (mix_columns_inv(mix_columns(data)) == data):
        print('Mix columns inversion OK')
    else:
        print('Mix columns inversion NOK')



# Generated at 2022-06-22 06:37:06.694794
# Unit test for function aes_decrypt_text

# Generated at 2022-06-22 06:37:08.904322
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    result = shift_rows_inv(data)
    print("shift_rows_inv test:")
    print("input:", data)
    print("output:", result)

test_shift_rows_inv()



# Generated at 2022-06-22 06:37:32.775433
# Unit test for function aes_encrypt
def test_aes_encrypt():
    ## required test for project 4
    plaintext = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-22 06:37:37.394588
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert(mix_columns_inv([0xdb, 0xc0, 0x43, 0x0, 0xd2, 0xd1, 0xc6, 0x0, 0xb8, 0x8d, 0x6a, 0x0, 0x1a, 0xdc, 0xdf, 0x0]) == [0xdb, 0x13, 0x53, 0x45, 0xda, 0xcd, 0x50, 0x0, 0xb8, 0x15, 0x6e, 0x4f, 0x1a, 0x2e, 0xda, 0x41])



# Generated at 2022-06-22 06:37:43.528394
# Unit test for function sub_bytes
def test_sub_bytes():
    print("Testing the sub_bytes function:")
    assert(sub_bytes([1, 2, 3, 4]) == [0x63, 0x7c, 0x77, 0x7b])
    assert(sub_bytes([0x88, 0x99, 0xaa, 0xbb]) == [0x68, 0x89, 0x94, 0x8f])
    print("Passed")



# Generated at 2022-06-22 06:37:54.871784
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    import binascii

    key = bytearray(b'YELLOW SUBMARINE')

# Generated at 2022-06-22 06:38:05.790665
# Unit test for function mix_columns
def test_mix_columns():
    column_vector = [0x01, 0x02, 0x03, 0x04]
    result = mix_column(column_vector, MIX_COLUMN_MATRIX)
    assert(result == [0x02, 0x03, 0x01, 0x01])

    column_vector = [0x0e, 0x0b, 0x0d, 0x09]
    result = mix_column(column_vector, MIX_COLUMN_MATRIX)
    assert(result == [0x09, 0x0e, 0x0b, 0x0d])

    column_vector = [0x0e, 0x0b, 0x0d, 0x09]
    result = mix_column(column_vector, MIX_COLUMN_MATRIX_INV)

# Generated at 2022-06-22 06:38:13.693751
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-22 06:38:16.780248
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    a = [SBOX[i] for i in range(0x100)]
    a = sub_bytes_inv(a)
    assert a == [i for i in range(0x100)]



# Generated at 2022-06-22 06:38:27.992935
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = "2b7e151628aed2a6abf7158809cf4f3c"
    iv = "000102030405060708090A0B0C0D0E0F"
    plaintext = b"Hello World!"
    expected_cyphertext = "W8aZbA7/uwDmIho7YWNoKg=="
    actual_cyphertext = intlist_to_bytes(aes_cbc_encrypt(bytes_to_intlist(plaintext), bytes_to_intlist(compat_b64decode(key)), bytes_to_intlist(compat_b64decode(iv))))
    assert actual_cyphertext == compat_b64decode(expected_cyphertext)


# Generated at 2022-06-22 06:38:32.296685
# Unit test for function rotate
def test_rotate():
    inp = [1,2,3,4,5]
    exp = [2,3,4,5,1]
    out= rotate(inp)
    if exp != out:
        raise AssertionError("Error in rotating")

# Generated at 2022-06-22 06:38:42.920865
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test case 1
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]