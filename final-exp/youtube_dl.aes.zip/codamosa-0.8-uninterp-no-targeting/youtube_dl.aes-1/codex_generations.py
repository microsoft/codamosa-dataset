

# Generated at 2022-06-22 06:29:26.011338
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = range(16)
    data_shifted = shift_rows_inv(data)
    assert data == shift_rows(data_shifted)



# Generated at 2022-06-22 06:29:33.393621
# Unit test for function shift_rows_inv

# Generated at 2022-06-22 06:29:42.691996
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Tests aes_decrypt_text
    """

# Generated at 2022-06-22 06:29:50.234913
# Unit test for function aes_encrypt
def test_aes_encrypt():
	# https://www.cosic.esat.kuleuven.be/nessie/testvectors/bc/aes/AES-CBC.test-vectors
	tests = []
	tests.append({
		'key': b'2b7e151628aed2a6abf7158809cf4f3c',
		'plain': b'6bc1bee22e409f96e93d7e117393172a',
		'cipher': b'7649abac8119b246cee98e9b12e9197d'
	})

# Generated at 2022-06-22 06:29:53.839350
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x00, 0x10, 0x20, 0x30, 0x40, 0x50, 0x60, 0x70, 0x80, 0x90, 0xa0, 0xb0, 0xc0, 0xd0, 0xe0, 0xf0]) == [0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]

# Generated at 2022-06-22 06:30:05.546146
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    assert intlist_to_bytes(aes_ctr_decrypt(bytes_to_intlist(b''),
                                            bytes_to_intlist(b'\x01' * 16),
                                            EncryptionCounter(0))) == b''
    assert intlist_to_bytes(aes_ctr_decrypt(bytes_to_intlist(b'test'),
                                            bytes_to_intlist(b'\x01' * 16),
                                            EncryptionCounter(0))) == b'test'
    assert intlist_to_bytes(aes_ctr_decrypt(bytes_to_intlist(b'test'),
                                            bytes_to_intlist(b'\x01' * 16),
                                            EncryptionCounter(3))) == b'\x00' * 3 + b'test'
   

# Generated at 2022-06-22 06:30:09.814766
# Unit test for function rotate
def test_rotate():
    assert rotate([0x1, 0x2, 0x3, 0x4]) == [0x2, 0x3, 0x4, 0x1]
    assert rotate([0x1, 0x2, 0x3, 0x4]) != [0x1, 0x2, 0x3, 0x4]



# Generated at 2022-06-22 06:30:13.992266
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    # Data from http://csrc.nist.gov/archive/aes/rijndael/rijndael-vals.zip
    data = [0x4D, 0x4C, 0x32, 0x69, 0x73, 0x41, 0x38, 0x77, 0x48, 0x54, 0x63, 0x2B, 0x79, 0x6F, 0x71, 0x49]
    data_shifted = shift_rows_inv(data)
    assert data_shifted == [0x4D, 0x41, 0x32, 0x79, 0x48, 0x4C, 0x63, 0x2B, 0x73, 0x38, 0x54, 0x6F, 0x71, 0x77, 0x6F, 0x49]



# Generated at 2022-06-22 06:30:17.568156
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert(shift_rows_inv([0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]) == [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76])


# Generated at 2022-06-22 06:30:19.544923
# Unit test for function shift_rows
def test_shift_rows():
    assert(shift_rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]) == [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15])



# Generated at 2022-06-22 06:30:35.714439
# Unit test for function aes_encrypt
def test_aes_encrypt():
    from .aes_inverted import aes_decrypt

    data = [28, 199, 235, 68, 140, 162,  24, 216,  82, 170,  43,  92, 26, 160, 148, 93]
    dec_data = [244, 37, 130, 209, 53, 35, 59, 50, 7, 93, 163, 101, 121, 121, 193, 251]
    key = [33,  34,  35,  36,  37,  38,  39,  40,  41,  42,  43,  44,  45,  46,  47,  48]


# Generated at 2022-06-22 06:30:37.774978
# Unit test for function shift_rows
def test_shift_rows():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    result = [0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11]
    assert result == shift_rows(data)



# Generated at 2022-06-22 06:30:46.304010
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x19, 0x3d, 0xe3, 0xbe, 0xa0, 0xf4, 0xe2, 0x2b, 0x9a, 0xc6, 0x8d, 0x2a, 0xe9, 0xf8, 0x48, 0x08]
    data_shifted = shift_rows_inv(data)
    for i in range(4):
        for j in range(4):
            assert data_shifted[i][j] == data[j][i]

test_shift_rows_inv()

# Generated at 2022-06-22 06:30:57.489176
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, start=0, end=float("inf")):
            self.counter = start
            self.end = end

        def next_value(self):
            if self.counter >= self.end:
                raise Exception()

            result = self.counter.to_bytes(BLOCK_SIZE_BYTES, "big")
            self.counter += 1
            return bytes_to_intlist(result)

    data = "hello world"
    key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    counter = Counter(0)

# Generated at 2022-06-22 06:31:01.766361
# Unit test for function mix_column
def test_mix_column():
    data = [0x95, 0x4e, 0x44, 0x1e]
    result = mix_column(data, MIX_COLUMN_MATRIX)
    assert result == [0x57, 0x38, 0x7b, 0x2d]



# Generated at 2022-06-22 06:31:10.168130
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    print(aes_decrypt_text('CK7FJgMvCjWwRbPn+aUIllqFypg=', 'password', 16))

    print(
        aes_decrypt_text(
            'CK7FJgMvCjWwRbPn+aUIllqFypg=',
            'This is a longer password',
            16
        )
    )

    print(
        aes_decrypt_text(
            'afmFYp+7GFYqJU8rkU6jrq6F+U3dE3H4w4njxQAAZj4=',
            'password',
            16
        )
    )


# Addition in GF(2^8)

# Generated at 2022-06-22 06:31:21.071962
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = "0x35 0x61 0xA7 0x2B 0xDA 0x8A 0xEA 0xD9 0xA8 0xDA 0xA2 0x89 0x02 0xFB 0xCA 0x3A".split()
    data = bytes_to_intlist(bytes(bytearray.fromhex(data[0])))
    
    key = "0x2B 0x7E 0x15 0x16 0x28 0xAE 0xD2 0xA6 0xAB 0xF7 0x15 0x88 0x09 0xCF 0x4F 0x3C".split()
    key = bytes_to_intlist(bytes(bytearray.fromhex(key[0])))
    
    expanded_key = key_expansion(key)

    decrypted_

# Generated at 2022-06-22 06:31:30.759509
# Unit test for function inc
def test_inc():
    data = [0, 0, 0, 0]
    expected = [0, 0, 0, 1]
    assert(inc(data) == expected)
    data = [0, 0, 0, 255]
    expected = [0, 0, 1, 0]
    assert(inc(data) == expected)
    data = [0, 0, 255, 255]
    expected = [0, 1, 0, 0]
    assert(inc(data) == expected)
    data = [255, 255, 255, 255]
    expected = [0, 0, 0, 0]
    assert(inc(data) == expected)



# Generated at 2022-06-22 06:31:40.312757
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0]*16
    data[0] = 0x63
    data[5] = 0x6c
    data[10] = 0x63
    data[15] = 0x72
    result = sub_bytes(data)
    assert [0x52, 0x6c, 0xe3, 0x89, 0xf7, 0xb2, 0x27, 0x9c, 0xe1, 0x8c, 0x5f, 0xb2, 0x01, 0x01, 0x01, 0x01] == result



# Generated at 2022-06-22 06:31:50.948710
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    import binascii

# Generated at 2022-06-22 06:32:06.748703
# Unit test for function shift_rows
def test_shift_rows():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    assert (shift_rows(data) == [0, 1, 2, 3, 5, 6, 7, 4, 10, 11, 8, 9, 15, 12, 13, 14])



# Generated at 2022-06-22 06:32:12.129131
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]

# Generated at 2022-06-22 06:32:21.723295
# Unit test for function sub_bytes
def test_sub_bytes():
    print('[Unit test for function sub_bytes]')
    key = [0xF6,0x9F,0x24,0x45,0xDF,0x4F,0x9B,0x17,0xAD,0x2B,0x41,0x7B,0xE6,0x6C,0x37,0x10]
    sub_bytes_test=sub_bytes(key)
    print(sub_bytes_test)

# Generated at 2022-06-22 06:32:34.414133
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """
    Unit test for function aes_cbc_decrypt
    """
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]

# Generated at 2022-06-22 06:32:38.914639
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x19, 0xa0, 0x9a, 0xe9]
    test = [0x6a, 0x1c, 0x45, 0x2b]
    assert sub_bytes(data) == test


# Generated at 2022-06-22 06:32:48.802910
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, counter):
            self.counter = counter

        def next_value(self):
            self.counter[-1] += 1
            return self.counter


# Generated at 2022-06-22 06:33:00.740439
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xE4, 0xF6, 0xF6, 0x64, 0xE4, 0xF6, 0xF6, 0x64, 0xE4, 0xF6, 0xF6, 0x64, 0xE4, 0xF6, 0xF6, 0x64]
    data_mixed = mix_columns(data)
    assert data_mixed == [0x5C, 0x04, 0x2E, 0xD8, 0x9B, 0x72, 0xF6, 0x1B, 0x74, 0xAC, 0x2A, 0xA9, 0xB6, 0x1A, 0xC3,  0xB2]

# Generated at 2022-06-22 06:33:06.807087
# Unit test for function aes_decrypt_text

# Generated at 2022-06-22 06:33:08.686812
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x83) == 0xc1
    assert rijndael_mul(0x83, 0x57) == 0xc1
    assert rijndael_mul(0x57, 0x13) == 0xfe



# Generated at 2022-06-22 06:33:13.162247
# Unit test for function mix_columns
def test_mix_columns():
    data = [0x63, 0x53, 0xe0, 0x8c, 0x09, 0x60, 0xe1, 0x04, 0xcd, 0x70, 0xb7, 0x51, 0xba, 0xa6, 0x6e, 0x08]
    data_mixed = [0x5f, 0x72, 0x64, 0x15, 0x57, 0xf5, 0xbc, 0x92, 0xf7, 0xbe, 0x3b, 0x29, 0x1d, 0xb9, 0xf9, 0x1a]
    assert data_mixed == mix_columns(data)
    assert data == mix_columns(data_mixed, MIX_COLUMN_MATRIX_INV)

# Generated at 2022-06-22 06:33:30.362954
# Unit test for function aes_decrypt
def test_aes_decrypt():
	key1 = bytes_to_intlist(compat_b64decode('kyoKjzmZa4Faj1J7NoUSrQ=='))
	key2 = bytes_to_intlist(compat_b64decode('kyoKjzmZa4Faj1J7NoUSrg=='))
	key3 = bytes_to_intlist(compat_b64decode('kyoKjzmZa4Faj1J7NoUSrw=='))
	print('key1:', key1)
	print('key2:', key2)
	print('key3:', key3)
	# key1: [143, 236, 76, 132, 29, 122, 203, 1, 223, 70, 41, 81, 110, 2, 93, 2]
	# key2: [

# Generated at 2022-06-22 06:33:32.564035
# Unit test for function inc
def test_inc():
    test1 = [0, 1, 2]
    if inc(test1) == [0,1,3]:
        print("inc passed")
    else:
        print("inc failed")
    test2 = [255, 255, 255]
    if inc(test2) == [0,0,0]:
        print("inc passed")
    else:
        print("inc failed")


# Generated at 2022-06-22 06:33:38.097047
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key = [0x54, 0x68, 0x61, 0x74]
    key_core = key_schedule_core(key, 1)
    assert(key_core == [0xE2, 0xFC, 0xE9, 0xA7])
    print('test_key_schedule_core passed')

test_key_schedule_core()



# Generated at 2022-06-22 06:33:50.760296
# Unit test for function key_schedule_core
def test_key_schedule_core():
    # AES-128 encryption key
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]


# Generated at 2022-06-22 06:33:54.578239
# Unit test for function xor
def test_xor():
    assert xor([0x54, 0x77, 0x6F], [0x20, 0x6D, 0x6F]) == [0x74, 0x1A, 0x00]



# Generated at 2022-06-22 06:34:04.983585
# Unit test for function xor
def test_xor():
    print('Testing function xor...', end='')
    assert(xor([0x32, 0x88, 0x31, 0xe0], [0x43, 0x5a, 0x31, 0x37]) == [0x71, 0xd2, 0x00, 0xd7])
    assert(xor([0x2b, 0x7e, 0x15, 0x16], [0xa0, 0xfb, 0xae, 0xd]) == [0x89, 0x85, 0xbd, 0xf])
    assert(xor([0x32, 0x43, 0xf6, 0xa8], [0x88, 0x5a, 0x30, 0x3d]) == [0xb0, 0x11, 0xc6, 0x95])

# Generated at 2022-06-22 06:34:16.157884
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = [182, 84, 235, 149, 64, 28, 10, 66, 255, 1, 131, 154, 233, 65, 202, 209]
    key = [163, 168, 206, 155, 121, 75, 233, 7, 182, 134, 159, 239, 110, 102, 177, 59]

# Generated at 2022-06-22 06:34:25.266149
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    plaintext = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]

# Generated at 2022-06-22 06:34:35.460618
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0xf2, 0xd4, 0x6e, 0x45, 0xf9, 0x2e, 0x8f, 0x59, 0x83, 0x7e, 0x21, 0x8a, 0xf1, 0x95, 0xfd]
    result = mix_columns(data)
    expected = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0xe3, 0x5e, 0xf0, 0x52, 0x72, 0x82, 0x2c, 0x6d, 0xe1, 0x9b]
    assert result == expected


# Generated at 2022-06-22 06:34:42.124122
# Unit test for function rotate
def test_rotate():
    l1 = [1, 2, 3, 4]
    l2 = [2, 3, 4, 1]
    l3 = [4, 1, 2, 3]
    assert(rotate(rotate(rotate(l1))) == l1)
    assert(rotate(l1) == l2)
    assert(rotate(l2) == l3)
    assert(rotate(l3) == l1)



# Generated at 2022-06-22 06:36:28.971925
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, nonce):
            self._counter = bytes_to_intlist(compat_b64decode(nonce))[-4:]

        def next_value(self):
            self._counter = inc_array(self._counter)
            return [0] * 4 + self._counter

    key = bytes_to_intlist(compat_b64decode('U6DEyq6qxU6DEyq6qxU6DEyq6qxU6DEyq6qx'))

# Generated at 2022-06-22 06:36:40.510708
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .utils import intlist_to_hexstr
    from .key_expansion import Nk, Nb

    data = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = [ 0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c ]

# Generated at 2022-06-22 06:36:44.231558
# Unit test for function shift_rows
def test_shift_rows():
    assert(shift_rows([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]) == [1, 2, 3, 4, 6, 7, 8, 5, 10, 11, 12, 9, 14, 15, 16, 13])




# Generated at 2022-06-22 06:36:54.284262
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist("MUAHAHAHAHAHAHA")
    key = bytes_to_intlist("2b7e151628aed2a6abf7158809cf4f3c")
    iv = bytes_to_intlist("000102030405060708090a0b0c0d0e0f")

    encrypted = aes_cbc_encrypt(data, key, iv)
    print("aes_cbc_encrypt('{}', '{}', '{}') = '{}'".format(data, key, iv, encrypted))
    assert(encrypted == [207, 150, 218, 63, 137, 219, 134, 35, 194, 237, 70, 1, 51, 251, 61, 109])
    return(0)


# Generated at 2022-06-22 06:37:00.682326
# Unit test for function rijndael_mul
def test_rijndael_mul():
    """Test rijndael_mul function."""
    v1 = [1, 2, 4, 8, 16, 32, 64, 128, 29, 59, 119, 238, 197, 145, 27, 54]
    v2 = [99, 124, 119, 123, 242, 107, 111, 197, 48, 1, 103, 43, 254, 215, 171, 118]
    v_r = [99, 124, 119, 123, 242, 107, 111, 197, 48, 1, 103, 43, 254, 215, 171, 118]
    v_o = [0] * 16
    for i in range(0, 16):
        v_o[i] = rijndael_mul(v1[i], v2[i])

    # assert v_o == v_r

# Generated at 2022-06-22 06:37:07.580027
# Unit test for function inc
def test_inc():
    assert(inc([0,0,0,0]) == [0,0,0,1])
    assert(inc([1,2,3,0]) == [1,2,3,1])
    assert(inc([1,2,3,255]) == [1,2,4,0])
    assert(inc([255,255,255,255]) == [0,0,0,0])

test_inc()

# Generated at 2022-06-22 06:37:16.292042
# Unit test for function rotate
def test_rotate():
    assert rotate([2,3,4,5]) == [3,4,5,2]
    assert rotate([2,3,4,5,6]) == [3,4,5,6,2]
    assert rotate([2,3,4,5,6,6]) == [3,4,5,6,6,2]
    assert rotate([2,3,4,5,6,6,6]) == [3,4,5,6,6,6,2]


# Generated at 2022-06-22 06:37:27.748187
# Unit test for function aes_decrypt

# Generated at 2022-06-22 06:37:36.764252
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x52, 0x09, 0x6A, 0xD5, 0x30, 0x36, 0xA5, 0x38, 0xBF, 0x40, 0xA3, 0x9E, 0x81, 0xF3, 0xD7, 0xFB]
    result = [0x7B, 0x15, 0x93, 0xB1, 0x6C, 0x8D, 0xAB, 0x59, 0x80, 0xF5, 0xEE, 0xF6, 0xDF, 0xED, 0xA5, 0x06]
    assert sub_bytes(data) == result


# Generated at 2022-06-22 06:37:47.777651
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = 'QOW1wOFl3zMnyvE8WXTcBA=='
    cipher = 'VA5v5FN5fkJxKwzfS4I0B8CpP4oX9ER4Dl0QIbF8WnaJ/bArpnw=='
    key = 'IzH4vv86gbMkGV4y'

# Generated at 2022-06-22 06:38:06.877667
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = "000102030405060708090a0b0c0d0e0f"
    key = bytes_to_intlist(compat_b64decode(key))
    expected_encrypted_data = "69c4e0d86a7b0430d8cdb78070b4c55a"
    expected_encrypted_data = bytes_to_intlist(compat_b64decode(expected_encrypted_data))
    expanded_key = key_expansion(key)
    data = [0] * BLOCK_SIZE_BYTES
    encrypted_data = aes_encrypt(data, expanded_key)
    assert expected_encrypted_data == encrypted_data

test_aes_encrypt()



# Generated at 2022-06-22 06:38:10.219030
# Unit test for function rotate
def test_rotate():
    assert rotate([0x19, 0xA0, 0x9A, 0xE9]) == [0xA0, 0x9A, 0xE9, 0x19], "Something wrong with rotate function"
test_rotate()



# Generated at 2022-06-22 06:38:18.574616
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('quR/2hFz4N1TDHJ87V8htg=='))
    expanded_key = bytes_to_intlist(compat_b64decode('quR/2hFz4N1TDHJ87V8htn2nV8hPtR+g9LzEymz+shTWMY1ZhT1IrIj+eAZTpFoT'))
    assert key_expansion(key) == expanded_key



# Generated at 2022-06-22 06:38:30.245724
# Unit test for function xor
def test_xor():
    assert xor([0x01, 0x02, 0x03, 0x04],
               [0x05, 0x06, 0x07, 0x08]) == [0x04, 0x04, 0x04, 0x0c]
    assert xor([0x03, 0xf7, 0x33, 0x9b],
               [0x04, 0x66, 0x7c, 0x90]) == [0x07, 0x91, 0x4f, 0x0b]
    assert xor([0x01, 0x01, 0x01, 0x01],
               [0x01, 0x01, 0x01, 0x01]) == [0x00, 0x00, 0x00, 0x00]

# Generated at 2022-06-22 06:38:33.957626
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    input = list(range(16))
    expected = [0xe, 0xd, 0x9, 0x0, 0x0, 0x0, 0xc, 0xa, 0xa, 0x0, 0x7, 0x4, 0x0, 0x1, 0x7, 0x4]
    output = mix_columns_inv(input)
    print("input =", input)
    print("output =", output)
    print("expected =", expected)
    assert(output == expected)
test_mix_columns_inv()


# Generated at 2022-06-22 06:38:44.150464
# Unit test for function aes_decrypt

# Generated at 2022-06-22 06:38:52.293353
# Unit test for function key_expansion
def test_key_expansion():
    global key_expansion

# Generated at 2022-06-22 06:39:04.150153
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Test decryption of ciphertext
    ciphertext = (
        'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')
    ciphertext = bytes_to_intlist(compat_b64decode(ciphertext))
    key = bytes_to_intlist('YELLOW SUBMARINE')
    counter = Counter(0, use_bigendian=True)
    plaintext = aes_ctr_decrypt(ciphertext, key, counter)
    plaintext = intlist_to_bytes(plaintext)
    # plaintext = plaintext.decode('ascii')