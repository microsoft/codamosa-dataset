

# Generated at 2022-06-22 06:29:38.793250
# Unit test for function key_expansion

# Generated at 2022-06-22 06:29:47.902847
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    input = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    output = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    print(shift_rows_inv(input) == output)
    # add unit test for shift_rows_inv



# Generated at 2022-06-22 06:29:54.169385
# Unit test for function rijndael_mul
def test_rijndael_mul():
    # test_1
    a = 0x57
    b = 0x83
    expected = 0xc1
    actual = rijndael_mul(a, b)
    assert actual == expected, "actual = %d, expected = %d" % (actual, expected)
    # test_2
    a = 0x57
    b = 0x13
    expected = 0xfe
    actual = rijndael_mul(a, b)
    assert actual == expected, "actual = %d, expected = %d" % (actual, expected)
    print('test_rijndael_mul() - PASSED!')


# Generated at 2022-06-22 06:30:05.818948
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # test vectors from https://csrc.nist.gov/CSRC/media/Projects/Cryptographic-Standards-and-Guidelines/documents/examples/AES_CBC.pdf
    KEY = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    IV = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
          0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]


# Generated at 2022-06-22 06:30:14.623954
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x53, 0xCA, 0x4C, 0x0E, 0x10, 0xFB, 0x2B, 0xAE, 0xF6, 0xAA, 0x3D, 0x19, 0x67, 0x5D, 0xC5, 0x50]
    result = sub_bytes(data)
    assert result == [0x63, 0xEB, 0x9F, 0xA0, 0xC0, 0x2F, 0x93, 0x92, 0xAB, 0x30, 0xAF, 0xC7, 0x20, 0xCB, 0x2D, 0xA2]


# Generated at 2022-06-22 06:30:25.746920
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Test vector 1
    key = bytes_to_intlist("603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4")
    nonce = bytes_to_intlist("f0f1f2f3f4f5f6f7f8f9fafbfcfdfeff")
    counter = lambda: nonce


# Generated at 2022-06-22 06:30:35.868736
# Unit test for function mix_column
def test_mix_column():
    print("Unit test for mix_column")
    if mix_column([0x02, 0x03, 0x01, 0x01], MIX_COLUMN_MATRIX) == [0x04, 0x0E, 0x0E, 0x05]:
        print("Test case 1 pass")
    else:
        print("Test case 1 fail")
    if mix_column([0x1A, 0x2E, 0x72, 0x96], MIX_COLUMN_MATRIX_INV) == [0x39, 0x02, 0xDC, 0x19]:
        print("Test case 2 pass")
    else:
        print("Test case 2 fail")



# Generated at 2022-06-22 06:30:46.682329
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data_in = [0xdb, 0xf2, 0xd4, 0x6f, 0x45, 0x7f, 0xf5, 0x3a,
               0xa5, 0x33, 0x05, 0x71, 0x99, 0xa2, 0xb2, 0x1d]
    data_out = [0x04, 0x66, 0x81, 0xe5, 0xe0, 0xcb, 0x19, 0x9a,
               0x48, 0xf8, 0xd3, 0x7a, 0x28, 0x06, 0x26, 0x4c]
    data = mix_columns_inv(data_in)
    print(data)
    return


# Generated at 2022-06-22 06:30:57.891746
# Unit test for function key_expansion

# Generated at 2022-06-22 06:31:08.330679
# Unit test for function aes_encrypt
def test_aes_encrypt():
  # Block test case as in FIPS 197
  key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
  state = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]

# Generated at 2022-06-22 06:31:17.861408
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    if sub_bytes_inv(sub_bytes([0, 1, 2, 3])) == [0, 1, 2, 3]:
        print("Subbytes unit test passed")
    else:
        print("Subbytes unit test failed")



# Generated at 2022-06-22 06:31:28.983699
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert shift_rows_inv(shift_rows([0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34])) == [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]

# Generated at 2022-06-22 06:31:40.650404
# Unit test for function aes_decrypt
def test_aes_decrypt():
    test_cipher = bytes_to_intlist(compat_b64decode('+sgnsHs3q/c2/gSlPWCjF/Sb57GTTxkPwR/Cj4M4ByA='))
    test_key = bytes_to_intlist(compat_b64decode('uZ1V5v2i5n9XqddB0H2jz7YzyS8SxkOi'))

# Generated at 2022-06-22 06:31:51.109033
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    """
    @returns {bool} True if the tests succeed
    """
    def test(key, iv, data, expect_encryption):
        encryption = aes_cbc_encrypt(
            bytes_to_intlist(data),
            bytes_to_intlist(key),
            bytes_to_intlist(iv))
        encryption = intlist_to_bytes(encryption)
        return encryption == expect_encryption


# Generated at 2022-06-22 06:32:01.147598
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from . import compat_b64decode
    from .utils import bytes_to_intlist, intlist_to_bytes

    data = bytes_to_intlist(compat_b64decode('G1/zpv/8NlWzC9X4HDO4aayV7UKPDHWUyV7gwKSrUfD6xuQ6UjcVXULCk1eRRD7q'))
    key = bytes_to_intlist(compat_b64decode('9XnB9yr8dWJA0RvRuwYpoA=='))
    iv = bytes_to_intlist(compat_b64decode('oWz+vfCwY5t5l5CxBn1xvA=='))
    assert intlist_to_bytes

# Generated at 2022-06-22 06:32:11.395787
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():

    from .aes_cbc_encrypt import aes_cbc_encrypt

    def aes_cbc_decrypt_test(data, key, iv):
        key_byte = compat_b64decode(key)
        iv_byte = compat_b64decode(iv)
        key_int = bytes_to_intlist(key_byte)
        iv_int = bytes_to_intlist(iv_byte)
        input_byte = compat_b64decode(data)
        input_int = bytes_to_intlist(input_byte)
        output_int = aes_cbc_decrypt(input_int, key_int, iv_int)
        output_byte = intlist_to_bytes(output_int)

# Generated at 2022-06-22 06:32:19.903571
# Unit test for function xor
def test_xor():
    assert [0] == xor([0], [0])
    assert [1] == xor([0], [1])
    assert [0] == xor([1], [1])
    assert [0, 1] == xor([1, 0], [1, 0])
    assert [1, 0] == xor([1, 1], [0, 1])
    assert [0, 1] == xor([0, 1], [0, 0])
    assert [1, 0] == xor([0, 1], [1, 1])
    assert [0, 0] == xor([1, 1], [1, 1])



# Generated at 2022-06-22 06:32:23.818318
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x13) == 0xfe
    assert rijndael_mul(0x80, 0xBC) == 0x1B
    assert rijndael_mul(0xEA, 0x57) == 0xAC



# Generated at 2022-06-22 06:32:34.801692
# Unit test for function mix_columns
def test_mix_columns():
    test_data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert result == mix_columns(test_data)


test_mix_columns()



# Generated at 2022-06-22 06:32:46.676846
# Unit test for function xor
def test_xor():
    data1 = [0x19, 0x3d, 0xe3, 0xbe, 0xa0, 0xf4, 0xe2, 0x2b, 0x9a, 0xc6, 0x8d, 0x2a, 0xe9, 0xf8, 0x48, 0x08]
    data2 = [0xa0, 0x88, 0x23, 0x2a, 0xfa, 0xa3, 0x6e, 0x6f, 0x8b, 0x9c, 0xc9, 0x7d, 0x2b, 0x83, 0x7b, 0x10]
    result = xor(data1, data2)

# Generated at 2022-06-22 06:33:02.402892
# Unit test for function mix_columns
def test_mix_columns():
    test_data = [0xdb, 0x13, 0x53, 0x45,
                 0xf2, 0x0a, 0x22, 0x5c,
                 0x01, 0x01, 0x01, 0x01,
                 0xab, 0xab, 0xab, 0xab]
    test_data_mixed = [0x8e, 0x4d, 0xa1, 0xbc,
                       0x9f, 0xdc, 0x58, 0x9d,
                       0x01, 0x01, 0x01, 0x01,
                       0xcd, 0xd4, 0xbd, 0x1f]
    print(mix_columns(test_data, MIX_COLUMN_MATRIX) == test_data_mixed)

# Generated at 2022-06-22 06:33:13.557644
# Unit test for function sub_bytes
def test_sub_bytes():
    input_data = [0x52, 0x09, 0x6A, 0xD5, 0x30, 0x36, 0xA5, 0x38, 0xBF, 0x40, 0xA3, 0x9E, 0x81, 0xF3, 0xD7, 0xFB]
    output_data = [0x04, 0xE0, 0x48, 0x28, 0x66, 0xCB, 0xF8, 0x06, 0x81, 0x19, 0xD3, 0x26, 0xE5, 0x9A, 0x7A, 0x4C]
    assert sub_bytes(input_data) == output_data
    print("Passed unit test for function sub_bytes()")
test_sub_bytes()



# Generated at 2022-06-22 06:33:25.387171
# Unit test for function key_expansion
def test_key_expansion():
    from .utils import hex_to_intlist, intlist_to_hex

    dataa = hex_to_intlist('00010203 04050607 08090a0b 0c0d0e0f 10111213 14151617 18191a1b 1c1d1e1f')
    exdataa = hex_to_intlist('00010203 04050607 08090a0b 0c0d0e0f 10111213 14151617 18191a1b 1c1d1e1f 21222324 25262728 292a2b2c 2d2e2f30 31323334 35363738 3c3d3e3f')
    assert intlist_to_hex(key_expansion(dataa)) == intlist_to_hex(exdataa)

    datab = hex_

# Generated at 2022-06-22 06:33:31.641070
# Unit test for function rotate
def test_rotate():
    test_data = [0xFF, 0xFF, 0xFF, 0xFF]
    assert rotate(test_data) == [0xFF, 0xFF, 0xFF, 0xFF, 0xFF]
    assert test_data == [0xFF, 0xFF, 0xFF, 0xFF]
    assert rotate(test_data) == [0xFF, 0xFF, 0xFF, 0xFF, 0xFF]
    assert test_data == [0xFF, 0xFF, 0xFF, 0xFF]



# Generated at 2022-06-22 06:33:35.900959
# Unit test for function shift_rows
def test_shift_rows():
    data = [0b10110111, 0b10001110, 0b10010011, 0b10011101,
            0b11101101, 0b01100111, 0b10111100, 0b01101100,
            0b01110100, 0b11110011, 0b01111001, 0b11010110,
            0b00111111, 0b01001101, 0b11001110, 0b00011110]

# Generated at 2022-06-22 06:33:42.528688
# Unit test for function key_expansion
def test_key_expansion():
    test_key_expansion = [17, 15, 42, 248, 4, 32, 26, 255, 237, 255, 200, 255, 48, 11, 8, 141]

# Generated at 2022-06-22 06:33:54.319015
# Unit test for function aes_decrypt
def test_aes_decrypt():
    from .utils import hex_to_intlist, intlist_to_hex


# Generated at 2022-06-22 06:34:04.868795
# Unit test for function aes_decrypt
def test_aes_decrypt():
    """
    Unit test encrypt
    """
    data = bytes_to_intlist("000102030405060708090a0b0c0d0e0f")
    key = bytes_to_intlist("000102030405060708090a0b0c0d0e0f")
    expanded_key = key_expansion(key)

# Generated at 2022-06-22 06:34:05.972791
# Unit test for function rotate
def test_rotate():
    assert(rotate([1,2,3,4]) == [2,3,4,1])



# Generated at 2022-06-22 06:34:16.128724
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb,0x13,0x53,0x45,0xf2,0x0a,0x22,0x5c,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01]
    m_data = mix_columns(data)
    print(m_data)
    data = [0x53,0xca,0x3c,0x27,0xcd,0x60,0x91,0x04,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01]
    m_data = mix_columns(data)
    print(m_data)



# Generated at 2022-06-22 06:34:31.315194
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf])) == [0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf]

# Generated at 2022-06-22 06:34:33.062522
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert(rijndael_mul(0x57, 0x83) == 0xc1)
    assert(rijndael_mul(0x83, 0x13) == 0x01)
    assert(rijndael_mul(0x13, 0x57) == 0xf9)



# Generated at 2022-06-22 06:34:44.393224
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x9A, 0x23, 0x6D, 0xB3, 0x80, 0x8A, 0xF9, 0x12, 0x3E, 0xD0, 0x12, 0x2E, 0xB6, 0x0D, 0xBA, 0x8E]) == [0x1f, 0x99, 0x15, 0xae, 0x5a, 0x18, 0x5a, 0x1e, 0x5a, 0x8c, 0x5f, 0x01, 0x3f, 0x13, 0x7a, 0x2b]

# Generated at 2022-06-22 06:34:45.240524
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert mix_columns_inv(mix_columns(STRING)) == STRING



# Generated at 2022-06-22 06:34:54.972412
# Unit test for function aes_encrypt
def test_aes_encrypt():
    import binascii
    message = bytes_to_intlist(binascii.unhexlify('4920776f756c64206c6962296e207468652073742063616e206861736c20746f206974'))
    key = bytes_to_intlist(binascii.unhexlify('0f1571c947d9e8590cb7add6af7f6798'))
    expected = bytes_to_intlist(binascii.unhexlify('1b27c4614ab02b38a58b8c313a79745f'))
    expanded_key = key_expansion(key)
    actual = aes_encrypt(message, expanded_key)
    assert actual == expected

# Generated at 2022-06-22 06:35:05.078636
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    test_data = [1, 2, 3, 5, 6, 7, 8, 11, 12, 13, 14, 15, 16, 17, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 31, 32, 33, 34, 35, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69]
    encoded = sub_bytes(test_data)
    decoded = sub_bytes_inv(encoded)
    assert decoded == test_data



# Generated at 2022-06-22 06:35:14.348439
# Unit test for function aes_decrypt
def test_aes_decrypt():
    print("Unit test for function aes_decrypt started.")
    test_result = True

    # test_data=bytes_to_intlist("6b c1 be e2 2e 40 9f 96 e9 3d 7e 11 73 93 17 2a")
    test_data = bytes_to_intlist("ce a7 40 3d ba e4 62 93 5e 23 6b cd 9a 3a db 03")
    test_key = bytes_to_intlist("2b 7e 15 16 28 ae d2 a6 ab f7 15 88 09 cf 4f 3c")
    test_block = bytes_to_intlist("f0 f1 f2 f3 f4 f5 f6 f7 f8 f9 fa fb fc fd fe ff")
    test_expanded_key = key_expansion(test_key)
   

# Generated at 2022-06-22 06:35:18.314903
# Unit test for function rotate
def test_rotate():
    data = [0x01, 0x02, 0x03, 0x04]
    assert rotate(data) == [0x02, 0x03, 0x04, 0x01]


# Generated at 2022-06-22 06:35:29.363282
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x32, 0x88, 0x31, 0xe0,
            0x43, 0x5a, 0x31, 0x37,
            0xf6, 0x30, 0x98, 0x07,
            0xa8, 0x8d, 0xa2, 0x34]
    res  = [0x32, 0x88, 0x31, 0xe0,
            0xf6, 0x88, 0x98, 0x07,
            0x07, 0x8d, 0xa2, 0x34,
            0x43, 0x5a, 0x31, 0x37]
    print("Test shift_rows: ", shift_rows(data) == res)
test_shift_rows()


# Generated at 2022-06-22 06:35:41.671764
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self,IV):
            self.counter = IV

        def next_value(self):
            self.counter  = intlist_to_bytes(bytes_to_intlist(self.counter) + 1)
            return self.counter

    class TestSet(object):
        '''
        Class for testing aes_ctr_decrypt
        '''
        def __init__(self,cipher):
            self.cipher = cipher

        def test(self,IV,key,text):
            return text == aes_ctr_decrypt(self.cipher,key,Counter(IV))
        

# Generated at 2022-06-22 06:35:54.395144
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test_data = [1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 1, 1, 1, 1]
    mci = mix_columns_inv(test_data)
    assert mci == [14, 11, 13, 9, 9, 14, 11, 13, 13, 9, 14, 11, 11, 13, 9, 14]
    print("test_mix_columns_inv passed")

test_mix_columns_inv()


# Generated at 2022-06-22 06:35:55.681698
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([0xB7, 0x54, 0x14, 0xA5])) == [0xB7, 0x54, 0x14, 0xA5]



# Generated at 2022-06-22 06:36:07.268516
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x05, 0x55, 0x55, 0x5d, 0x01]
    data_mixed = mix_columns_inv(data)
    data_expected = [0x8e, 0xe6, 0xdf, 0x9f, 0x11, 0x0a, 0x4a, 0xc4, 0x17, 0x0b, 0x04, 0x0b, 0x14, 0x96, 0x0b, 0x17]
    assert data_mixed == data_expected



# Generated at 2022-06-22 06:36:12.069414
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    cleartext = b'\x11\x22\x33\x44\x55\x66\x77\x88\x99\xAA\xBB\xCC\xDD\xEE'
    key = bytes_to_intlist(b'\x11\x22\x33\x44\x55\x66\x77\x88\x99\xAA\xBB\xCC\xDD\xEE\xFF\x00')
    iv = bytes_to_intlist(b'\xAA\xAA\xAA\xAA\xAA\xAA\xAA\xAA\xAA\xAA\xAA\xAA\xAA\xAA\xAA\xAA')

# Generated at 2022-06-22 06:36:21.684746
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert mix_columns_inv(data) == result



# Generated at 2022-06-22 06:36:32.573543
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = bytes_to_intlist('kLfNb+Xl37g1VbYjYh3qVg==')
    key = bytes_to_intlist('kLfNb+Xl37g1VbYjYh3qVg==')
    data = bytes_to_intlist('kLfNb+Xl37g1VbYjYh3qVg==')
    assert aes_cbc_decrypt(data, key, iv) == [103953, 574640, 55764, 496890, 53776, 589957, 54717, 533042, 55906, 499797, 55452, 495705, 53496, 585512, 53266, 537483]



# Generated at 2022-06-22 06:36:43.649228
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b'hello world')
    iv = bytes_to_intlist(b'init vector')
    key = bytes_to_intlist(b'secret key ')
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    print(list(map(hex, encrypted_data)))
    # [0xa6, 0x78, 0x35, 0xd3, 0x86, 0x84, 0x2b, 0x51, 0x93, 0x0a, 0xac, 0x8f, 0x09, 0xdc, 0x3a, 0x52, 0x6c, 0x2a, 0xdb, 0x1b, 0x65, 0x85, 0x96, 0x98, 0x9f, 0x2

# Generated at 2022-06-22 06:36:54.139492
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01'
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]

# Generated at 2022-06-22 06:36:55.592695
# Unit test for function xor
def test_xor():
    assert xor([0x11, 0x22, 0x33, 0x44], [0x44, 0x33, 0x22, 0x11]) == [0x55, 0x11, 0x11, 0x55]



# Generated at 2022-06-22 06:37:01.349530
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-22 06:37:19.246640
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0x02, 0x03, 0x01, 0x01,
            0x01, 0x02, 0x03, 0x01,
            0x01, 0x01, 0x02, 0x03,
            0x03, 0x01, 0x01, 0x02]
    assert mix_columns_inv(data) == [0x0e, 0x0b, 0x0d, 0x09,
                                    0x09, 0x0e, 0x0b, 0x0d,
                                    0x0d, 0x09, 0x0e, 0x0b,
                                    0x0b, 0x0d, 0x09, 0x0e]

test_mix_columns_inv()
 

# Generated at 2022-06-22 06:37:22.425140
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([1, 2, 3, 4, 5, 6, 7, 8, 9])) == [1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-22 06:37:26.726193
# Unit test for function xor
def test_xor():
    assert xor([0x01, 0x02, 0x03, 0x04],
    [0x04, 0x03, 0x02, 0x01]) == [0x05, 0x01, 0x01, 0x05]


# Function for key expansion

# Generated at 2022-06-22 06:37:35.440946
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x09] * 16
    print([hex(x) for x in data])
    result = key_schedule_core(data, 0)
    print([hex(x) for x in result])
    assert result == [
        0x0a, 0x0b, 0x0c, 0x0d,
        0x0e, 0x0f, 0x00, 0x01,
        0x02, 0x03, 0x04, 0x05,
        0x06, 0x07, 0x08, 0x09,
    ]


test_key_schedule_core()



# Generated at 2022-06-22 06:37:46.679270
# Unit test for function xor
def test_xor():
    assert xor([0x1], [0x3]) == [0x2]
    assert xor([0x1, 0x2], [0x4, 0x5]) == [0x5, 0x7]
    assert xor([0x29, 0x3f, 0x17, 0x3a], [0xad, 0x59, 0x17, 0x6a]) == [0x84, 0x66, 0x00, 0x50]
    assert xor([0x13, 0x41, 0x34, 0x69, 0xef], [0xaa, 0x77, 0xea, 0x3f, 0x5d]) == [0xb9, 0x36, 0xde, 0x56, 0xb2]

# Generated at 2022-06-22 06:37:53.900037
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x10, 0x20, 0x30, 0x40]) == [0x6d, 0xab, 0x9e, 0xaf]
    assert sub_bytes([0x00, 0x00, 0x00, 0x00]) == [0x63, 0x00, 0x00, 0x00]
    assert sub_bytes([0xff, 0xff, 0xff, 0xff]) == [0xda, 0x3f, 0xff, 0xff]
    print('Test sub_bytes function: Success')


# Generated at 2022-06-22 06:38:05.364313
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
  X = [0x6B, 0xC1, 0xBE, 0xE2, 0x2E, 0x40, 0x9F, 0x96, 0xE9, 0x3D, 0x7E, 0x11, 0x73, 0x93, 0x17, 0x2A]
  cmp = [0xBA, 0x84, 0xE8, 0x1D, 0x75, 0xB9, 0xC0, 0xF1, 0x5D, 0xE4, 0x9A, 0xC2, 0x86, 0xDF, 0xB5, 0xC7]
  d = sub_bytes_inv(X)
  if (d == cmp):
    print("Unit test passed")
  else:
    print("Unit test failed")

# Generated at 2022-06-22 06:38:11.594221
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'I8X-WzEuNT7EdWoDsb47iY8mFZjK4M4b4B_iHzym9QhfS08Kws-LmP5TVZN5D5_R'
    password = '__J4CKD4N13L_'
    expected = 'Hello World'
    actual = aes_decrypt_text(data, password, 16)
    assert expected == actual


# Generated at 2022-06-22 06:38:23.794014
# Unit test for function key_expansion
def test_key_expansion():
    expanded_key_192 = key_expansion([0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5, 0x62, 0xf8, 0xea, 0xd2, 0x52, 0x2c, 0x6b, 0x7b])

# Generated at 2022-06-22 06:38:28.678891
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0]*16
    for i in range(4):
        for j in range(4):
            data[i*4+j] = i*4+j
    print(shift_rows(data))
    print(shift_rows_inv(shift_rows(data)))
# test_shift_rows_inv()
        


# Generated at 2022-06-22 06:38:39.659871
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist('0123456789abcdeffedcba9876543210')  # TestVector #1
    cipher = bytes_to_intlist('d8f532538289ef7d06b506a4fd5be9c9')

    res = intlist_to_bytes(aes_decrypt(cipher, key_expansion(key)))
    assert (res != cipher)  # Check if the function has decrypted the cipher
    assert (res == b'abcdefghijklmnop')  # Check if the correct cleartext has been decrypted


# Generated at 2022-06-22 06:38:41.916717
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]


# Generated at 2022-06-22 06:38:51.030260
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    encrypted_data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    counter = Counter(0)
    decrypted = aes_ctr_decrypt(encrypted_data, key, counter)
    assert intlist_to_bytes(decrypted) == b"Yo, VIP Let's kick it Ice, Ice, baby Ice, Ice, baby "
# Run test case only when the module is invoked directly
if __name__ == "__main__":
    test_aes_ctr_decrypt()
    print("All tests pass")

# Generated at 2022-06-22 06:38:57.206775
# Unit test for function shift_rows
def test_shift_rows():
    data = [1, 2, 3, 4,
            5, 6, 7, 8,
            9, 10, 11, 12,
            13, 14, 15, 16]
    
    assert shift_rows(data) == [1, 6, 11, 16,
                                2, 7, 12, 9,
                                3, 8, 13, 10,
                                4, 5, 14, 15]
test_shift_rows()

# Generated at 2022-06-22 06:39:04.312798
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x19, 0xa0, 0x9a, 0xe9,
            0x3d, 0xf4, 0xc6, 0xf8,
            0xe3, 0xe2, 0x8d, 0x48,
            0xbe, 0x2b, 0x2a, 0x08]
    expected_result = [0x19, 0xe9, 0xa0, 0x9a,
                       0x3d, 0xf8, 0xf4, 0xc6,
                       0xe3, 0x48, 0xe2, 0x8d,
                       0xbe, 0x08, 0x2b, 0x2a]
    assert shift_rows(data) == expected_result, "shift rows failed"
    print('test_shift_rows OK')

