

# Generated at 2022-06-22 06:29:32.153288
# Unit test for function rijndael_mul
def test_rijndael_mul():
    if len(RIJNDAEL_EXP_TABLE) != 256:
        print("Error: RIJNDAEL_EXP_TABLE. Wrong length: " + str(len(RIJNDAEL_EXP_TABLE)))
        return False
    if len(RIJNDAEL_LOG_TABLE) != 256:
        print("Error: RIJNDAEL_LOG_TABLE. Wrong length: " + str(len(RIJNDAEL_LOG_TABLE)))
        return False

# Generated at 2022-06-22 06:29:40.827012
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = b'Hello world!'
    key = bytes_to_intlist(compat_b64decode('0NuOt3LdqlwqV7LT1Bnaag=='))
    iv = bytes_to_intlist(compat_b64decode('QYCAN4L4JjycvnmT'))

    cipher = aes_cbc_encrypt(bytes_to_intlist(data), key, iv)
    cipher = intlist_to_bytes(cipher)

    assert cipher == compat_b64decode('wg/pB0F/pc9Ca/IWeMm6cQ==')



# Generated at 2022-06-22 06:29:46.456576
# Unit test for function rotate
def test_rotate():
    assert (rotate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]) == [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 1])
    assert (rotate([]) == [])
    assert (rotate([1]) == [1])


# Generated at 2022-06-22 06:29:54.678170
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist('fa98bc9a8bc0')
    expanded_key = bytes_to_intlist('8deedc3f3b90f9b42451c1badecdc228f0e2059f1b13454d')
    output = aes_encrypt(data, expanded_key)
    expected = bytes_to_intlist('1a14f8d2c50ad86bdd2ce9e82c890cf0')
    assert(expected == output)



# Generated at 2022-06-22 06:30:00.598058
# Unit test for function sub_bytes

# Generated at 2022-06-22 06:30:01.409237
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert 0 == rijndael_mul(0x57, 0x13)



# Generated at 2022-06-22 06:30:03.936985
# Unit test for function inc
def test_inc():
    test_data = b'\xFF'

# Generated at 2022-06-22 06:30:06.850722
# Unit test for function rotate
def test_rotate():
    data = [0x53, 0xCA, 0xD9, 0xD7]
    assert rotate(data) == [0xCA, 0xD9, 0xD7, 0x53]



# Generated at 2022-06-22 06:30:15.965019
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter:
        def __init__(self, nonce, position):
            self.nonce = nonce
            self.position = position

        def next_value(self):
            pos = self.position
            self.position += 1
            return self.nonce + [pos // 0x1000000 % 0x100,
                                 pos // 0x10000 % 0x100,
                                 pos // 0x100 % 0x100,
                                 pos % 0x100]


# Generated at 2022-06-22 06:30:27.254570
# Unit test for function key_expansion

# Generated at 2022-06-22 06:30:36.578785
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text('WYhc253rfe3qpo9vZJP1fZotz','password',16) == b'Hello World!'
    print('Passed')



# Generated at 2022-06-22 06:30:43.789941
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import json
    import os
    test_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(test_dir, 'aes.json')) as fo:
        for data in json.load(fo):
            for key_size_bytes in 16, 24, 32:
                assert aes_decrypt_text(data['enc'], data['pass'], key_size_bytes) == data['plain']



# Generated at 2022-06-22 06:30:46.099866
# Unit test for function xor
def test_xor():
    assert xor([1, 0, 0, 0], [0, 1, 1, 0]) == [1, 1, 1, 0]



# Generated at 2022-06-22 06:30:55.492467
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'pN9vL9i/H4qG4hgw8fQ2t/HZ5B3qrG5f5H0QXB0yRdzO5YD1CEMpzJ0K1FkO+L0I'
    password = 'testpassword'
    result = aes_decrypt_text(data, password, 32)
    assert result == 'I am a test message!'

# Mix columns
inv_matrix = [0x0E, 0x0B, 0x0D, 0x09]
matrix = [0x02, 0x03, 0x01, 0x01]


# Generated at 2022-06-22 06:31:04.383017
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from ._test_vectors import AES_CTR_TEST_VECTORS
    for _, test_vector in AES_CTR_TEST_VECTORS.items():
        decrypted_data = \
            aes_ctr_decrypt(
                bytes_to_intlist(test_vector['ciphertext']),
                bytes_to_intlist(test_vector['key']),
                test_vector['counter'])
        plaintext = intlist_to_bytes(decrypted_data)
        assert plaintext == test_vector['plaintext']



# Generated at 2022-06-22 06:31:16.038664
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value = intlist_to_bytes(
                aes_counter_increment(bytes_to_intlist(self.value)))
            return bytes_to_intlist(self.value)


# Generated at 2022-06-22 06:31:27.551952
# Unit test for function key_expansion
def test_key_expansion():
    """
    Simple test function
    """

# Generated at 2022-06-22 06:31:40.015462
# Unit test for function xor
def test_xor():
    assert xor([0x11,0x00,0x11,0x00],[0x00,0x11,0x00,0x11]) == [0x11,0x11,0x11,0x11]
    assert xor([0x44,0x44,0x44,0x44],[0x44,0x44,0x44,0x44]) == [0x00,0x00,0x00,0x00]
    assert xor([0x11,0x22,0x33,0x44],[0x1a,0x2a,0x3a,0x4a]) == [0x0b,0x08,0x01,0x06]

# Generated at 2022-06-22 06:31:46.779358
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist('e065c9a11f8cc8fbc5974da456967a54')
    expanded_key = bytes_to_intlist('1111111111111111111111111111111111111111111111111111111111111111')
    assert (intlist_to_bytes(aes_decrypt(data, expanded_key)) == b'00000000000000000000000000000000')


# Generated at 2022-06-22 06:31:58.042190
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Example AES CBC encryption
    # Source: https://de.wikipedia.org/wiki/Advanced_Encryption_Standard
    key = bytes_to_intlist(compat_b64decode("jxwHm0A/DuRHoIrQiYlXBQ=="))
    iv = bytes_to_intlist(compat_b64decode("4jnY+3q3Z9o9DX8h"))
    output = bytes_to_intlist(compat_b64decode("e1GdshX9TvTQWMaWDAS0mQ=="))
    assert aes_cbc_decrypt(output, key, iv) == bytes_to_intlist(b"Textbook Hub")


# Generated at 2022-06-22 06:32:11.135417
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    def get_hex(data):
        return ''.join(format(x, '02x') for x in data)

    # From FIPS-197, example:

# Generated at 2022-06-22 06:32:21.536682
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data_shifted = b"\x94\x98\x0e\x00\x08\x0f\x0b\x02\x0b\x06\x0d\x07\x00\x0e\x02\x00\x09\x0a\x0e\x00\x07\x0c\x0b\x05\x07\x01\x0c\x0f\x07\x02\x08\x03\x05\x06\x0d"
    data_original = shift_rows_inv(data_shifted)

# Generated at 2022-06-22 06:32:34.173021
# Unit test for function key_schedule_core
def test_key_schedule_core():
    test_input = [0x01, 0x02, 0x03, 0x04]
    test_output = key_schedule_core(test_input, 0)
    test_expected = [0x01, 0x01, 0x01, 0x05]
    if test_output != test_expected:
        return False

    test_input = [0x01, 0x01, 0x01, 0x05]
    test_output = key_schedule_core(test_input, 1)
    test_expected = [0x02, 0x02, 0x02, 0x0A]
    if test_output != test_expected:
        return False

    test_input = [0x02, 0x02, 0x02, 0x0A]

# Generated at 2022-06-22 06:32:45.466263
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from . import CoreUtils
    data = CoreUtils.byte_string_to_int_list("this is a test")
    key = CoreUtils.byte_string_to_int_list("this a key!!!")
    iv = CoreUtils.byte_string_to_int_list("1234567890123456")

    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert(CoreUtils.int_list_to_byte_string(encrypted_data) == b"\xff\x9c)i\x8b\x87\x94\x95\x98\x85\xd6\x1c\xd9\xfa\x8f\x87\xb7\xfb\xb4")

# Generated at 2022-06-22 06:32:49.571984
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    data_mixed = mix_columns(data, MIX_COLUMN_MATRIX)
    data_mixed_inverted = mix_columns_inv(data_mixed)
    assert data == data_mixed_inverted



# Generated at 2022-06-22 06:32:57.522573
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x00, 0x00, 0x00, 0x00]
    rcon_iteration = 1
    if(key_schedule_core(data, rcon_iteration) == [0x01, 0x00, 0x00, 0x00]):
        print("Unit test for function key_schedule_core: Sucess")
    else:
        print("Unit test for function key_schedule_core: Failed")
#test_key_schedule_core()


# Generated at 2022-06-22 06:33:02.973007
# Unit test for function mix_column
def test_mix_column():
    d = [0xdb, 0x13, 0x53, 0x45]
    d_mixed = mix_column(d, MIX_COLUMN_MATRIX)
    print(d_mixed)
    d_mixed_inv = mix_column(d_mixed, MIX_COLUMN_MATRIX_INV)
    print(d_mixed_inv)

    assert d == d_mixed_inv



# Generated at 2022-06-22 06:33:07.311065
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    # Test 1
    test_data = [80, 229, 74, 219, 23, 28, 135, 176, 38, 148, 173, 16, 142, 194, 208, 203]
    result = mix_columns_inv(test_data)
    assert result == [208, 168, 160, 188, 244, 186, 169, 48, 47, 114, 246, 146, 216, 15, 100, 153]
    # Test 2
    test_data = [80, 229, 74, 219, 23, 28, 135, 176, 38, 148, 173, 16, 142, 194, 208, 203]
    result = mix_columns_inv(test_data)
    assert result == [208, 168, 160, 188, 244, 186, 169, 48, 47, 114, 246, 146, 216, 15, 100, 153]



# Generated at 2022-06-22 06:33:18.419611
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .counter import Counter
    from .aes import bytes_to_intlist
    
    key = bytes_to_intlist('000102030405060708090A0B0C0D0E0F')
    counter = Counter(bytes_to_intlist('0000000000000001'))
    data = bytes_to_intlist('6BC1BEE22E409F96E93D7E117393172A'
                            'AE2D8A571E03AC9C9EB76FAC45AF8E51')
    expected = bytes_to_intlist('501B5C8D420A5E5D3B1E281A39D83760'
                                '4A4F13D14A8A8DFEFA1BBF45E9D2E95B')
    
    decrypted

# Generated at 2022-06-22 06:33:30.221818
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert(rijndael_mul(0x57, 0x83) == 0xC1)
    assert(rijndael_mul(0x13, 0x53) == 0xFE)
    assert(rijndael_mul(0xCA, 0xFE) == 0x69)
    assert(rijndael_mul(0xA0, 0xFE) == 0x44)
    assert(rijndael_mul(0x5B, 0xC9) == 0xD7)
    assert(rijndael_mul(0x7B, 0x9B) == 0xCF)
    assert(rijndael_mul(0xFB, 0xD4) == 0x9C)

# Generated at 2022-06-22 06:33:38.842319
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    key_size_bytes = 32
    key = [0] * key_size_bytes
    message = 'Hello world!'
    assert aes_decrypt_text(aes_decrypt_text(message.encode('utf-8'), 'password', key_size_bytes), 'password', key_size_bytes) == message



# Generated at 2022-06-22 06:33:45.612401
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert (sub_bytes_inv([0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]) ==
            [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f])



# Generated at 2022-06-22 06:33:49.195906
# Unit test for function xor
def test_xor():
    data1 = [0x01, 0x02, 0x03, 0x04]
    data2 = [0xf1, 0xf2, 0xf3, 0xf4]
    data = xor(data1, data2)
    print(data)



# Generated at 2022-06-22 06:34:01.664325
# Unit test for function key_expansion
def test_key_expansion():
    # verify with known cipher
    data = bytes_to_intlist(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-22 06:34:13.405723
# Unit test for function key_expansion
def test_key_expansion():
    key = intlist_to_bytes([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c], False)

# Generated at 2022-06-22 06:34:21.001610
# Unit test for function mix_column
def test_mix_column():
    test_data = [1, 1, 1, 1]
    print("Test data: ", test_data)
    test_mix = mix_column(test_data, MIX_COLUMN_MATRIX)
    print("Test mix column result", test_mix)
    test_mix_inv = mix_column(test_mix, MIX_COLUMN_MATRIX_INV)
    print("Test mix result after mix inverse", test_mix_inv)
    error = False
    for i in range(4):
        if (test_mix_inv[i] != test_data[i]):
            error = True
            break
    if (error):
        print("Error in function mix_column")
    else:
        print("Test function mix_column successfully")



# Generated at 2022-06-22 06:34:32.755969
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31]
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    cipher = a

# Generated at 2022-06-22 06:34:43.541255
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    prev_state = [0x52, 0x09, 0x6A, 0xD5, 0x30, 0x36, 0xA5, 0x38, 0xBF, 0x40, 0xA3, 0x9E, 0x81, 0xF3, 0xD7, 0xFB]
    expected_state = [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF]
    actual_state = sub_bytes_inv(prev_state)
    assert expected_state == actual_state



# Generated at 2022-06-22 06:34:53.290780
# Unit test for function inc
def test_inc():
    assert inc([0x0, 0x0, 0x0, 0x0]) == [0x0, 0x0, 0x0, 0x1]
    assert inc([0x0, 0x0, 0x0, 0x1]) == [0x0, 0x0, 0x0, 0x2]
    assert inc([0x0, 0x0, 0x0, 0x2]) == [0x0, 0x0, 0x0, 0x3]
    assert inc([0x0, 0x0, 0x0, 0x3]) == [0x0, 0x0, 0x0, 0x4]
    assert inc([0x0, 0x0, 0x0, 0x4]) == [0x0, 0x0, 0x0, 0x5]

# Generated at 2022-06-22 06:34:56.509928
# Unit test for function rotate
def test_rotate():
    assert rotate([0, 1, 2, 3]) == [1, 2, 3, 0]
    assert rotate([6, 7, 8, 9]) == [7, 8, 9, 6]


# Generated at 2022-06-22 06:35:09.606459
# Unit test for function mix_column
def test_mix_column():
    mc_matrix = ((0x02, 0x03, 0x01, 0x01),
                 (0x01, 0x02, 0x03, 0x01),
                 (0x01, 0x01, 0x02, 0x03),
                 (0x03, 0x01, 0x01, 0x02))
    d = mix_column((0x7e, 0x0a, 0x7c, 0xfa), mc_matrix)
    print(d)
    assert(d == [0xEC, 0xFA, 0xEC, 0x7E])
test_mix_column()


# Generated at 2022-06-22 06:35:21.723023
# Unit test for function rijndael_mul
def test_rijndael_mul():
    # Test multiplication by 1
    for i in range(0,256):
        print(i, rijndael_mul(i, 1))
        assert(rijndael_mul(i,1) == i)

    # Test multiplication by 2
    for i in range(0,256):
        print(i, rijndael_mul(i, 2))
        assert(rijndael_mul(i,2) == RIJNDAEL_EXP_TABLE[(RIJNDAEL_LOG_TABLE[i] + 1) % 0xFF])

    # Test multiplication by 3
    for i in range(0,256):
        print(i, rijndael_mul(i, 3))

# Generated at 2022-06-22 06:35:32.846730
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text('QAQAQQQAQQQQAAQAQAAQAAQEAIAAAPAAAQAQAIAAAEAIAAgAIAAAPAAAPAPAPAPAPAPAPAPAPAPAPAPAPAPAPAPAPAPAPAPAP', 'foo', 16) == b'bar'
    assert aes_decrypt_text('QAQAQQQAQQQQAAQAQAAQAAQEAIAAAPAAAQAQAIAAAEAIAAgAIAAAPAAAPAPAPAPAPAPAPAPAPAPAPAPAPAPAPAPAPAPAPAPAP', 'banana', 16) == b'banana'

# Generated at 2022-06-22 06:35:38.001626
# Unit test for function mix_column

# Generated at 2022-06-22 06:35:47.010705
# Unit test for function sub_bytes
def test_sub_bytes():
    assert [0x63, 0xca, 0xb7, 0x04] == sub_bytes([0x19, 0xa0, 0x9a, 0xe9])
    assert [0xba, 0x84, 0xe8, 0x1b] == sub_bytes([0x76, 0x4f, 0xf4, 0x26])
    assert [0x1e, 0x03, 0x1d, 0xda] == sub_bytes([0xa7, 0x9b, 0x8a, 0x6c])
    assert [0x7c, 0xeb, 0x85, 0x40] == sub_bytes([0x3e, 0x1b, 0x8d, 0x01])
    assert [0x9d, 0x14, 0x5f, 0x74] == sub

# Generated at 2022-06-22 06:35:52.151036
# Unit test for function inc
def test_inc():
    a = [1, 2, 3]
    assert inc(a) == [1, 2, 4]
    a = [1, 255, 255]
    assert inc(a) == [2, 0, 0]
    a = [255, 255, 255]
    assert inc(a) == [0, 0, 0]



# Generated at 2022-06-22 06:35:53.860269
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    print(data_mixed)


if __name__ == "__main__":
    test_mix_column()

# Generated at 2022-06-22 06:36:02.554967
# Unit test for function xor
def test_xor():
    data1 = [0x01, 0x02, 0x03, 0x04]
    data2 = [0xFF, 0xFE, 0xFD, 0xFC]
    data3 = [0x00, 0x00, 0x00, 0x00]
    check = [0xFE, 0xFC, 0xFA, 0xF8]
    assert xor(data1, data2) == check
    assert xor(data1, data3) == data1
    assert xor(data2, data3) == data2



# Generated at 2022-06-22 06:36:06.195998
# Unit test for function mix_columns
def test_mix_columns():
    column = [0x01, 0x01, 0x01, 0x01]
    result = [0x02, 0x03, 0x01, 0x01]
    assert(mix_column(column, MIX_COLUMN_MATRIX) == result)


# Generated at 2022-06-22 06:36:10.474371
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    test = [0xC6, 0x63, 0x63, 0xA5, 0xF2, 0x7F, 0x7F, 0xD5, 0x30, 0x6B, 0x20, 0xCB, 0xED, 0xFC, 0x3B, 0x91]
    result = [0xC6, 0xC6, 0xC6, 0xC6, 0xF2, 0xF4, 0xF8, 0xFC, 0x30, 0x60, 0xC0, 0x89, 0xED, 0xDA, 0xB4, 0x91]
    assert test == result


# Generated at 2022-06-22 06:36:32.686597
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10]
    shifted = [0x01, 0x06, 0x0b, 0x10, 0x05, 0x0a, 0x0f, 0x04, 0x09, 0x0e, 0x03, 0x08, 0x0d, 0x02, 0x07, 0x0c]
    assert(shift_rows(data) == shifted)
    print('Test case for function shift_rows passed')
    return



# Generated at 2022-06-22 06:36:41.212931
# Unit test for function aes_decrypt
def test_aes_decrypt():
    test_key = bytes_to_intlist('0001020305060708090a0b0c0d0e0f10')
    test_msg = bytes_to_intlist('00112233445566778899aabbccddeeff')

    expanded = key_expansion(test_key)
    encrypted = aes_ecb_encrypt(test_msg, expanded)
    decrypted = aes_ecb_decrypt(encrypted, expanded)

    assert decrypted == test_msg
    print(intlist_to_bytes(decrypted))


# Generated at 2022-06-22 06:36:44.569158
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print("Unit Test: function rijndael_mul()")
    if(rijndael_mul(0x57, 0x13) != 0xFE):
        print("Unit Test: Failed")
    else:
        print("Unit Test: Succeed")



# Generated at 2022-06-22 06:36:46.561281
# Unit test for function sub_bytes
def test_sub_bytes():
    data = bytearray([0xC9, 0x92, 0xEF, 0x96])
    sub_bytes(data)
    assert data[0] == 0x75
    assert data[1] == 0xC8
    assert data[2] == 0xE6
    assert data[3] == 0xF1


# Generated at 2022-06-22 06:36:54.757783
# Unit test for function mix_columns
def test_mix_columns():
    assert mix_columns([0xdb,0x13,0x53,0x45,0xf2,0x0a,0x22,0x5c,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x01]) == [0x8E, 0x9F, 0x89, 0xDD, 0xCB, 0xD3, 0x4B, 0xE9, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]

test_mix_columns()



# Generated at 2022-06-22 06:37:00.299332
# Unit test for function mix_columns
def test_mix_columns():
    test_data = [0x53, 0xca, 0xfe, 0xba, 0x45, 0xd4, 0xb2, 0x90, 0x4a, 0x76, 0xa8, 0x60, 0x25, 0xfb, 0x8f, 0x84]
    expected_data = [0x8c, 0xc4, 0x4a, 0x9a, 0x39, 0x7b, 0x2e, 0x99, 0xbf, 0x86, 0x13, 0x8d, 0xd6, 0xcb, 0x74, 0x3f]
    assert mix_columns(test_data) == expected_data



# Generated at 2022-06-22 06:37:04.104732
# Unit test for function rotate
def test_rotate():
    assert rotate(list('abcde')) == list('bcdea')
    assert rotate(list('bcdea')) == list('cdeab')
    assert rotate(list('cdeab')) == list('deabc')
    assert rotate(list('deabc')) == list('eabcd')
    assert rotate(list('eabcd')) == list('abcde')


# Generated at 2022-06-22 06:37:05.543324
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0, 0xFF):
        for j in range(0, 0xFF):
            assert rijndael_mul(i, j) == rijndael_mul_inv(j, i)

# Generated at 2022-06-22 06:37:17.150357
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    """
    Test function aes_ctr_decrypt
    """
    import struct
    import sys

    data = b'hello world!!'
    key = b'YELLOW SUBMARINE'
    key = bytes_to_intlist(key)
    key = key * (4 if sys.maxsize > 2 ** 32 else 2)
    key = intlist_to_bytes(key)

    class Counter:
        def __init__(self, iv):
            self._iv = iv

        def next_value(self):
            iv = bytes_to_intlist(self._iv)
            self._iv = intlist_to_bytes(iv)
            return intlist_to_bytes(iv)

    counter = Counter(b'\x00' * 16)

# Generated at 2022-06-22 06:37:28.574660
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist('4a4b4c4d4e4f505152535455565758595a5b5c5d5e5f606162636465666768696a6b6c6d6e6f7071')

# Generated at 2022-06-22 06:38:06.668326
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert shift_rows_inv(shift_rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    assert shift_rows_inv(shift_rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])) != [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16]

if __name__ == '__main__':
    test_shift_rows_inv()


# Generated at 2022-06-22 06:38:16.188211
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]

    data_mixed = mix_columns(data)
    assert data_mixed == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    print("test_mix_columns passed")

# Generated at 2022-06-22 06:38:25.361822
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data=bytes_to_intlist(compat_b64decode('rzr/J7Z9+P/uH/Gp4MfA=='))
    print(data)
    key=bytes_to_intlist(compat_b64decode('QFUGcU1TG+U3q3UxW6UgEb+Dn9nstKvR'))
    print(key)
    iv=bytes_to_intlist(compat_b64decode('L8WJgnqpoqjs7yhJ'))
    print(iv)
    expanded_key = key_expansion(key)
    temp_data=aes_encrypt(data,expanded_key)
    print(temp_data)



# Generated at 2022-06-22 06:38:29.669496
# Unit test for function sub_bytes

# Generated at 2022-06-22 06:38:40.528905
# Unit test for function mix_column
def test_mix_column():
    data1 = [0x01, 0x02, 0x03, 0x04]
    data2 = [0x05, 0x06, 0x07, 0x08]
    data3 = [0x09, 0x0A, 0x0B, 0x0C]
    data4 = [0x0D, 0x0E, 0x0F, 0x10]
    print(mix_column(data1, MIX_COLUMN_MATRIX))
    print(mix_column(data2, MIX_COLUMN_MATRIX))
    print(mix_column(data3, MIX_COLUMN_MATRIX))
    print(mix_column(data4, MIX_COLUMN_MATRIX))


# Generated at 2022-06-22 06:38:51.695161
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from .utils import bytes_to_intlist, intlist_to_bytes

    key = bytes_to_intlist(b'thekeyis16byte!')
    iv  = bytes_to_intlist(b'1234567890123456')
    cleartext  = bytes_to_intlist(b'This is a cleartext')
    ciphertext = bytes_to_intlist(b'\xb9\x95\x15L\tj\x88\xdf\x93\x1b\x9d\x9e\x08\xf8\xdb\x96\x07\x14')

    assert aes_cbc_encrypt(cleartext, key, iv) == ciphertext



# Generated at 2022-06-22 06:39:02.643389
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x63, 0xca, 0xb7, 0x04, 0xf1, 0x51, 0x10, 0x7a, 0x76, 0x72, 0x66, 0xfb, 0x15, 0x16, 0xc1, 0x6a]
    data_shifted = [0x6a, 0x63, 0xca, 0xb7, 0x04, 0xf1, 0x51, 0x10, 0x7a, 0x76, 0x72, 0x66, 0xfb, 0x15, 0x16, 0xc1]
    assert shift_rows_inv(data_shifted) == data
test_shift_rows_inv()