

# Generated at 2022-06-22 06:29:25.220463
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert ('\x08\x00\x00\x00\x00\x00\x00\x00' +
            '\x00\x00\x00\x00\x00\x00\x00\x00' +
            '\x00\x00\x00\x00\x00\x00\x00\x00' +
            '\x00\x00\x00\x00\x00\x00\x00\x08') == aes_decrypt_text('QUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQQ==', 'awesomepassword', 16)

# Generated at 2022-06-22 06:29:26.876295
# Unit test for function aes_encrypt

# Generated at 2022-06-22 06:29:38.546493
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # This test is from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # On page 20
    # Input data
    data = '6bc1bee22e409f96e93d7e117393172aae2d8a571e03ac9c9eb76fac45af8e5130c81c46a35ce411e5fbc1191a0a52eff69f2445df4f9b17ad2b417be66c3710'
    data = bytes_to_intlist(compat_b64decode(data))
    key = '2b7e151628aed2a6abf7158809cf4f3c'
    key = bytes_to_intlist(compat_b64decode(key))

# Generated at 2022-06-22 06:29:42.896351
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    result = sub_bytes_inv([0x63, 0xEB, 0x9F, 0xA0])
    assert result == [0x4D, 0x11, 0x7C, 0x10], result
    

# Generated at 2022-06-22 06:29:44.474901
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert(rijndael_mul(2, 3) == 6)
    assert(rijndael_mul(6, 3) == 0xD)
    assert(rijndael_mul(3, 0) == 0)
    return True



# Generated at 2022-06-22 06:29:47.440284
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print("Unit test for rijndael_mul")
    a = 0x57
    b = 0x13
    result = rijndael_mul(a, b)
    assert result == 0xFE
    print("Unit test passed")


# Generated at 2022-06-22 06:29:55.892547
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 1]) == [0, 0, 0, 2]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-22 06:29:57.907571
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [1, 2, 3, 4]
    rcon_iteration = 1
    result = key_schedule_core(data, rcon_iteration)
    expected = [0x1b, 0x3a, 0x21, 0x02]
    assert result == expected



# Generated at 2022-06-22 06:29:59.237087
# Unit test for function xor
def test_xor():
    assert xor([1, 2, 3, 4], [5, 6, 7, 8]) == [1 ^ 5, 2 ^ 6, 3 ^ 7, 4 ^ 8]



# Generated at 2022-06-22 06:30:02.154470
# Unit test for function rotate
def test_rotate():
    data0 = [0x3A, 0xD7, 0x7B, 0xB4]
    rotate(data0)
    if data0 == [0xD7, 0x7B, 0xB4, 0x3A]:
        print ("Pass")
    else:
        print ("Fail")


# Generated at 2022-06-22 06:30:17.395328
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    result = key_expansion(data)

# Generated at 2022-06-22 06:30:21.374652
# Unit test for function rotate
def test_rotate():
    data = [0x11, 0x22, 0x33, 0x44]
    assert(rotate(data) == [0x22, 0x33, 0x44, 0x11])



# Generated at 2022-06-22 06:30:25.033631
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test_data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected_result = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert(expected_result == mix_columns_inv(test_data))



# Generated at 2022-06-22 06:30:35.991543
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from .crypto import iv, key, get_random_bytes
    from .compat import compat_b64encode
    from .aes import get_aes_cbc_decrypt
    data = get_random_bytes(16)
    key = key[:16]
    example = 'TkzwJmQhCvV8WJnJoX9V7A=='
    encrypted = aes_cbc_encrypt(data, key, iv)
    print(compat_b64encode(intlist_to_bytes(encrypted)))
    decrypted = get_aes_cbc_decrypt(key)(intlist_to_bytes(encrypted), key, iv)
    print(decrypted)
    assert compat_b64encode(intlist_to_bytes(encrypted)) == example
    assert intlist_

# Generated at 2022-06-22 06:30:47.251388
# Unit test for function aes_decrypt

# Generated at 2022-06-22 06:30:55.742679
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    iv = bytes_to_intlist(compat_b64decode('zM6D+XcYI33pYn+H0LJjKw=='))
    key = bytes_to_intlist(compat_b64decode('mjhTZnVUN+U8M6oAbJbmeA=='))
    print(intlist_to_bytes(aes_cbc_encrypt(
            bytes_to_intlist(compat_b64decode('YjY4YTJmYmI3NmY4')),
            key, iv)))


# Generated at 2022-06-22 06:31:03.692943
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(compat_b64decode("1KmRi+b4g4ZGD4zuuI+Y0w=="))
    key = bytes_to_intlist(compat_b64decode("pY+YIumKTYc4KE4Z5a5fQQ=="))
    expected_result = bytes_to_intlist(compat_b64decode("CZK+HdR1nGGXXBvXbKjJoA=="))
    expanded_key = key_expansion(key)
    assert aes_encrypt(data, expanded_key) == expected_result



# Generated at 2022-06-22 06:31:11.048725
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytearray('testdata', 'utf-8')
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11,
            0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f]

# Generated at 2022-06-22 06:31:20.178094
# Unit test for function xor
def test_xor():
    assert xor([0x11, 0x22, 0x33, 0x44], [0xFF, 0xFF, 0xFF, 0xFF]) == [0xEE, 0xDD, 0xCC, 0xBB]
    assert xor([0x11, 0x22, 0x33, 0x44], [0x00, 0x00, 0x00, 0x00]) == [0x11, 0x22, 0x33, 0x44]
    assert xor([0x00, 0x00, 0x00, 0x00], [0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x00]



# Generated at 2022-06-22 06:31:31.328947
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    actual = mix_columns_inv(data)
    expected = [0x8e, 0x9f, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    print(expected)
    print(actual)
    assert expected == actual

# Generated at 2022-06-22 06:31:44.096293
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(b'\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xAA\xBB\xCC\xDD\xEE\xFF')
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F')
    expanded_key = key_expansion(key)

# Generated at 2022-06-22 06:31:49.550043
# Unit test for function inc
def test_inc():
    data = [255] * 16
    for i in range(1000):
        data = inc(data)
    assert data == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]



# Generated at 2022-06-22 06:31:53.641286
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test_data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected_data = [0x8e, 0x9f, 0x17, 0x15, 0xd2, 0xb9, 0xa4, 0x1c, 0x88, 0x01, 0x17, 0x01, 0x00, 0x00, 0x00, 0x00]
    actual_data = mix_columns_inv(test_data)
    assert expected_data == actual_data, 'Expected data: {}, Actual data: {}'.format(expected_data, actual_data)
#test

# Generated at 2022-06-22 06:31:59.429846
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]
    assert key_schedule_core(key,0) == [0xc8, 0x09, 0x0f, 0xca, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
# Test key_schedule_core()
#test_key_schedule_core()

# Generated at 2022-06-22 06:32:04.569292
# Unit test for function rotate
def test_rotate():
    assert rotate([1]) == [1]
    assert rotate([1,2,3]) == [2,3,1]
    assert rotate([1,2,3,4]) == [2,3,4,1]



# Generated at 2022-06-22 06:32:13.672350
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = compat_b64decode('/WfJv7VjQ1+3lCXo8LZKIg==')
    data = '074aef8ec07415c3536d9f0ce3251c859435cbcc'
    data = bytes_to_intlist(compat_b64decode(data))
    expanded_key = key_expansion(key)
    result = aes_decrypt(data, expanded_key)
    result = intlist_to_bytes(result)
    assert result == compat_b64decode('o5+5lffF6eiGZ6oX9+x21A==')
test_aes_decrypt()



# Generated at 2022-06-22 06:32:17.859293
# Unit test for function xor
def test_xor():
    data1 = [x for x in range(1, 5)]
    data2 = [x for x in range(5, 9)]
    print("data1:", data1)
    print("data2:", data2)
    print("run test_xor():", xor(data1, data2))
# run test_xor()



# Generated at 2022-06-22 06:32:24.803210
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    try:
        assert(shift_rows_inv([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]) == [1, 6, 11, 16, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12])
    except AssertionError:
        print('shift_rows_inv failed')
        return
    print('shift_rows_inv passed')

# Generated at 2022-06-22 06:32:29.431488
# Unit test for function mix_column
def test_mix_column():
    plain = [0, 1, 2, 3]
    plain_mix = mix_column(plain, MIX_COLUMN_MATRIX)
    assert plain_mix == [0, 13, 10, 7]



# Generated at 2022-06-22 06:32:32.264079
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]



# Generated at 2022-06-22 06:32:42.532923
# Unit test for function xor
def test_xor():
    data1 = [0x01, 0x01, 0x01, 0x01]
    data2 = [0x01, 0x01, 0x01, 0x01]
    res = xor(data1, data2)
    assert res == [0x0, 0x0, 0x0, 0x0], res

# Generated at 2022-06-22 06:32:49.443924
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = 'YELLOW SUBMARINE'
    key = bytes_to_intlist(key)
    iv = [0] * 16

    with open('set2ch10.txt', 'r') as f:
        data = bytes_to_intlist(compat_b64decode(f.read()))

    actual_output = aes_cbc_encrypt(data, key, iv)
    with open('set2ch10_output.enc', 'rb') as f:
        expected_output = bytes_to_intlist(f.read())

    assert actual_output == expected_output
test_aes_cbc_encrypt()



# Generated at 2022-06-22 06:33:00.430021
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    msg = [0x19, 0x3d, 0xe3, 0xbe, 0xa0, 0xf4, 0xe2, 0x2b, 0x9a, 0xc6, 0x8d, 0x2a, 0xe9, 0xf8, 0x48, 0x08]
    expected = [0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0x07, 0xa8, 0x8d, 0xa2, 0x34]
    assert_equal(sub_bytes_inv(msg), expected)

# Test given 2x2 matrix * 2x2 matrix

# Generated at 2022-06-22 06:33:10.656598
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(b'\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff')
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expected = bytes_to_intlist(b'\x69\xc4\xe0\xd8\x6a\x7b\x04\x30\xd8\xcd\xb7\x80\x70\xb4\xc5\x5a')


# Generated at 2022-06-22 06:33:20.654034
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Test vector 1
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
           0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    vector = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
              0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]

# Generated at 2022-06-22 06:33:23.430572
# Unit test for function xor
def test_xor():
    assert(xor([0x11, 0x11], [0x1, 0x1]) == [0x10, 0x10])



# Generated at 2022-06-22 06:33:26.862066
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x01, 0x02, 0x03, 0x04]
    expected = [0x01, 0x02, 0x04, 0x0b]
    assert key_schedule_core(data, 1) == expected



# Generated at 2022-06-22 06:33:33.847384
# Unit test for function sub_bytes
def test_sub_bytes():
    test_data = [0x63, 0x9d, 0x66, 0x7c, 0xda, 0xfa, 0xfa, 0xac, 0x74, 0xf1, 0xfe, 0x8e, 0xfe, 0x52, 0x05, 0x38]
    expected_data = [0xC6, 0x3E, 0x3F, 0xF5, 0x3C, 0xD0, 0x2E, 0x27, 0x8D, 0x46, 0xA1, 0xCD, 0x46, 0xC4, 0x46, 0x40]
    actual_data = sub_bytes(test_data)
    print("[Unit Test] Test Sub Bytes")
    show_data(actual_data, expected_data)



# Generated at 2022-06-22 06:33:41.596980
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = (
        "twx5BtZJzbevY0WGcfNq3j1V0c4Ovf1+7L8xoPuaja7OjAKI9XV7m+F0ZipJQ7iaMvz"
        "8fKRzpZ7VscZvslXd7I8nA=="
    )
    password = "gw89ea54x5"
    decrypted_data = aes_decrypt_text(data, password, 16)


# Generated at 2022-06-22 06:33:52.559011
# Unit test for function aes_decrypt
def test_aes_decrypt():
    print("test AES decryption...")
    key_hex = "2b7e151628aed2a6abf7158809cf4f3c"
    key = bytes_to_intlist(compat_b64decode(key_hex))
    message_hex = "3ad77bb40d7a3660a89ecaf32466ef97"
    message = bytes_to_intlist(compat_b64decode(message_hex))
    cipher_hex = "3ad77bb40d7a3660a89ecaf32466ef97"
    cipher = bytes_to_intlist(compat_b64decode(cipher_hex))
    expanded_key = key_expansion(key)
    decrypted = aes_decrypt(cipher, expanded_key)

# Generated at 2022-06-22 06:34:06.079068
# Unit test for function mix_columns
def test_mix_columns():
    c = mix_columns((0xdb, 0x13, 0x53, 0x45,
                     0xf2, 0x0a, 0x22, 0x5c,
                     0x01, 0x01, 0x01, 0x01,
                     0x01, 0x01, 0x01, 0x01))
    if c == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]:
        print("mix_columns: OK")
    else:
        print("mix_columns: Failed")
        print(c)



# Generated at 2022-06-22 06:34:16.992709
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test Oracle Documentation Example
    key = bytes_to_intlist(compat_b64decode('2b7e151628aed2a6abf7158809cf4f3c'))
    iv = bytes_to_intlist(compat_b64decode('000102030405060708090A0B0C0D0E0F'))
    cipher = bytes_to_intlist(compat_b64decode('7649ABAC8119B246CEE98E9B12E9197D'))


# Generated at 2022-06-22 06:34:25.950074
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    #test vector from http://tools.ietf.org/html/rfc3602#section-2
    data = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f'

# Generated at 2022-06-22 06:34:37.242636
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist('00010203050607080a0b0c0d0f101112')
    iv = bytes_to_intlist('1415161718191a1b1c1d1e1f20212224')

# Generated at 2022-06-22 06:34:48.161566
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0x53, 0x69, 0x67, 0x42, 0x7a, 0x41, 0x4e, 0x62, 0x32, 0x34, 0x39, 0x38, 0x35, 0x30, 0x33, 0x66]

# Generated at 2022-06-22 06:34:51.672855
# Unit test for function key_schedule_core
def test_key_schedule_core():
    pass
    #assert key_schedule_core([0x00, 0x00, 0x00, 0x00], 0x01) == [0x01, 0x02, 0x04, 0x08]


# Generated at 2022-06-22 06:34:57.635472
# Unit test for function xor
def test_xor():
    a = [0x57, 0x69, 0x6b, 0x69] 
    b = [0xd8, 0x3f, 0x88, 0x9b]
    xored = xor(a,b)
    assert xored == [0x8f, 0x56, 0xe0, 0xf0]
    print("Tests passed!")

test_xor()


# Generated at 2022-06-22 06:35:07.398348
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytes_to_intlist("4ca00ff4c898d61e1edbf1800618fb2828a226d160dad07883d04e008a7897ee2e4b7465d5290d0c0e6c6822236e1daafb94ffe0c5da05d9476be028ad7c1d81")
    key = bytes_to_intlist("140b41b22a29beb4061bda66b6747e14")
    iv = bytes_to_intlist("4ca00ff4c898d61e1edbf1800618fb28")
    expected = bytes_to_intlist("Basic CBC mode encryption needs padding.")
    assert expected == aes_cbc_decrypt(data, key, iv)



# Generated at 2022-06-22 06:35:15.749333
# Unit test for function key_expansion
def test_key_expansion():
    key1 = [42] * 16
    expanded_key1 = key_expansion(key1)
    assert len(expanded_key1) == 176
    assert expanded_key1[:16] == key1

    key2 = [42] * 24
    expanded_key2 = key_expansion(key2)
    assert len(expanded_key2) == 208
    assert expanded_key2[:24] == key2

    key3 = [42] * 32
    expanded_key3 = key_expansion(key3)
    assert len(expanded_key3) == 240
    assert expanded_key3[:32] == key3
test_key_expansion()



# Generated at 2022-06-22 06:35:20.599684
# Unit test for function inc
def test_inc():
    assert inc([0x00, 0x00]) == [0x00, 0x01]
    assert inc([0xFF, 0x00]) == [0x00, 0x01]
    assert inc([0xFF, 0xFF]) == [0x00, 0x00]



# Generated at 2022-06-22 06:35:36.239371
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter:
        def __init__(self, base = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]):
            self._base = base

        def next_value(self):
            self._base = add_bytes(self._base, [1])
            return self._base

    def test(key, ctr, data):
        counter = Counter(ctr)
        b64_decrypted_data = aes_ctr_decrypt(
            bytes_to_intlist(compat_b64decode(data)),
            bytes_to_intlist(compat_b64decode(key)),
            counter
        )
        return intlist_to_bytes(b64_decrypted_data)

    # Test vectors:
    # Source:

# Generated at 2022-06-22 06:35:46.589491
# Unit test for function key_schedule_core

# Generated at 2022-06-22 06:35:58.311425
# Unit test for function aes_decrypt_text

# Generated at 2022-06-22 06:36:10.526279
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x63, 0x7C, 0x77, 0x7B,
            0xF2, 0x6B, 0x6F, 0xC5,
            0x30, 0x01, 0x67, 0x2B,
            0xFE, 0xD7, 0xAB, 0x76]
    data_shifted = shift_rows_inv(data)
    assert data_shifted == [
        0x63, 0xF2, 0x30, 0xFE,
        0x7C, 0x6B, 0x01, 0xD7,
        0x77, 0x6F, 0x67, 0xAB,
        0x7B, 0xC5, 0x2B, 0x76,
    ]
    return "test passed!"


# Generated at 2022-06-22 06:36:21.560749
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x53, 0xCA) == 0x01
    assert rijndael_mul(0xCA, 0x53) == 0x01
    assert rijndael_mul(0x01, 0x01) == 0x01
    assert rijndael_mul(0xD3, 0x9D) == 0x59
    assert rijndael_mul(0x9D, 0xD3) == 0x59
    assert rijndael_mul(0x97, 0x97) == 0xE3
    assert rijndael_mul(0x97, 0xC3) == 0x59
    assert rijndael_mul(0xC3, 0x97) == 0x59
    assert rijndael_m

# Generated at 2022-06-22 06:36:31.679483
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Set 1, problem 7, AES in ECB mode
    data = bytes_to_intlist('6bc1bee22e409f96e93d7e117393172a')
    key = bytes_to_intlist('YELLOW SUBMARINE')
    iv = [0] * 16
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(aes_encrypt(data, expanded_key)) == compat_b64decode(
        'C3l4uI4gCWZ7VuHJNL5+5A==')

    data = bytes_to_intlist('ae2d8a571e03ac9c9eb76fac45af8e51')
    key = bytes_to_intlist('YELLOW SUBMARINE')

# Generated at 2022-06-22 06:36:43.133743
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-22 06:36:53.758170
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # This is our test string.
    msg_str = "Attack at dawn"
    print("Test string: ", msg_str)
    # Convert to bytes.
    msg_bytes = bytearray()
    msg_bytes.extend(map(ord, msg_str))
    print("Test string in bytes: ", msg_bytes)

    # Generate a key.
    key_bytes = os.urandom(16)
    print("Key: ", key_bytes)

    # Perform encryption.
    expanded_key = key_expansion(key_bytes)
    encrypted_bytes = aes_encrypt(msg_bytes, expanded_key)
    print("Encrypted bytes: ", encrypted_bytes)
    # Try decryption.
    decrypted_bytes = aes_decrypt(encrypted_bytes, expanded_key)

# Generated at 2022-06-22 06:37:04.344022
# Unit test for function aes_encrypt
def test_aes_encrypt():
    encoded_hex = "69c4e0d86a7b0430d8cdb78070b4c55a"
    key = bytes_to_intlist("2b7e151628aed2a6abf7158809cf4f3c")
    expanded_key = key_expansion(key)

    msg = 'hello'
    msg_bytes = [ord(i) for i in msg]
    msg_len = len(msg)

    # Encrypt given message
    encrypted_data = aes_encrypt(msg_bytes, expanded_key)

    # Check if encryption is correct
    assert (intlist_to_bytes(encrypted_data)).hex() == encoded_hex
    print("aes_encrypt() function unit test successful")



# Generated at 2022-06-22 06:37:07.854421
# Unit test for function rotate
def test_rotate():
    input_bytes = [0x00, 0x00, 0x00, 0x00]
    expected_output = [0x00, 0x00, 0x00, 0x01]
    rotate_test_output = rotate(input_bytes)
    assert expected_output == rotate_test_output
    return 'test_rotate passes'
print(test_rotate())


# Generated at 2022-06-22 06:37:20.600143
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Message: 'Hello World!', Password: 'test123', key_size_bytes: 32
    data = '8WYhMk1uwf6tT7dZcSoybT9KfTcTb4sDy4Y4Kj62QMc'
    password = 'test123'
    key_size_bytes = 32
    if aes_decrypt_text(data, password, key_size_bytes) != b'Hello World!':
        raise RuntimeError



# Generated at 2022-06-22 06:37:22.367951
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [x for x in range(16)]
    data_shifted = shift_rows_inv(data)
    for row in range(4):
        for column in range(4):
            assert (row + column) & 0b11 == data_shifted[row * 4 + column] % 4



# Generated at 2022-06-22 06:37:26.714739
# Unit test for function xor
def test_xor():
    data1 = [0, 0, 0, 0]
    data2 = [1, 1, 1, 1]
    assert xor(data1, data2) == [1, 1, 1, 1]
# End unit test for function xor



# Generated at 2022-06-22 06:37:36.041638
# Unit test for function sub_bytes
def test_sub_bytes():
    print("Testing function sub_bytes...", end="")

# Generated at 2022-06-22 06:37:43.854705
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    data = bytes_to_intlist(compat_b64decode('3rerjd9LhTU='))
    expected_result = bytes_to_intlist(compat_b64decode('U0MTYwNjI4MDI='))
    assert aes_encrypt(data, key_expansion(key)) == expected_result
    return True

test_aes_encrypt()



# Generated at 2022-06-22 06:37:53.569268
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    inv = mix_columns_inv(mix_columns([0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]))
    assert(inv == [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01])
test_mix_columns_inv()

# pylint: disable=invalid-name

# Generated at 2022-06-22 06:38:02.355985
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytes_to_intlist('AC1E37BFB15599E5F40Eef805488281d')
    key = bytes_to_intlist('E3715215B4F87F6C8E0B12E27AB5C5AC')
    iv = bytes_to_intlist('00000000000000000000000000000000')
    expected = bytes_to_intlist('6bc1bee22e409f96e93d7e117393172a')
    result = aes_cbc_decrypt(data, key, iv)
    assert result == expected



# Generated at 2022-06-22 06:38:09.435688
# Unit test for function mix_column
def test_mix_column():
    plain_text = [0xdb, 0x13, 0x53, 0x45]
    plain_text_mixed = mix_column(plain_text, MIX_COLUMN_MATRIX)
    assert plain_text_mixed == [0x8e, 0x4d, 0xa1, 0xbc]
    plain_text_mixed = mix_column(plain_text_mixed, MIX_COLUMN_MATRIX_INV)
    assert plain_text_mixed == plain_text


# Test cases

# Generated at 2022-06-22 06:38:21.116865
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    key_size_bytes = 32
    key = bytes_to_intlist(bytearray("A"*key_size_bytes))
    iv = bytes_to_intlist([0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1] + [0]*(BLOCK_SIZE_BYTES - 8))
    expanded_key = key_expansion(key)

    # test Encrypt
    test_string = u""
    test_array = aes_cbc_encrypt(bytes_to_intlist(test_string.encode('utf-8')), expanded_key, iv)
    test_string_encrypted = compat_b64encode(intlist_to_bytes(test_array))

# Generated at 2022-06-22 06:38:24.448299
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist('YELLOW SUBMARINE')
    if key_expansion(key) != bytes_to_intlist('YELLOW SUBMARINEYELLOW SUBMARINEYELLOW SUBMARINE1234567887654321'):
        print('unit test for key_expansion FAILED')



# Generated at 2022-06-22 06:38:49.399753
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x6a, 0x84, 0x86, 0xf6, 0x77, 0x96, 0x69, 0x6a, 0x7c, 0x7c, 0x74, 0xf2, 0x04, 0x17, 0x37, 0x08]
    data_shifted = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    data_shifted[1]  = data[1]
    data_shifted[5]  = data[5]
    data_shifted[9]  = data[9]

# Generated at 2022-06-22 06:38:58.912359
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)

    print(len(expanded_key))
    for i in range(len(expanded_key)):
        print(hex(expanded_key[i]), end = "")
        if i % 4 == 3 and i != len(expanded_key) - 1:
            print()
    print()
    print()



# Generated at 2022-06-22 06:39:08.734727
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Example from Cryptography I
    # https://www.coursera.org/learn/crypto/lecture/x7Dyd/lecture-4-1-aes-encryption
    key = bytes_to_intlist("140b41b22a29beb4061bda66b6747e14".decode("hex"))  # 128-Bit
    password = bytes_to_intlist("36f18357be4dbd77f050515c73fcf9f2".decode("hex"))
    data = "CRIwqt4+szDbqkNY+I0qbNXPg1XLaCM5etQ5Bt9DRFV/xIN2k8Go7jtArLIyP605"