

# Generated at 2022-06-22 06:29:25.489307
# Unit test for function mix_columns
def test_mix_columns():
    print(mix_columns([0xdb, 0xf2, 0xd4, 0x20, 0x15, 0xab, 0x5b, 0x15, 0x50, 0x0e, 0x15, 0xdd, 0x1f, 0xa3, 0x5b, 0x14]))
    print([0x04, 0x66, 0x81, 0xe5, 0xe0, 0xcb, 0x19, 0x9a, 0x48, 0xf8, 0xd3, 0x7a, 0x28, 0x06, 0x26, 0x4c])
    # print([0x04, 0x66, 0x81, 0xe5, 0xe0, 0xcb, 0x19, 0x9a, 0x48, 0xf8, 0xd3, 0

# Generated at 2022-06-22 06:29:33.067289
# Unit test for function mix_columns
def test_mix_columns():
    block = [0xdb, 0x13, 0x53, 0x45,
             0xf2, 0x0a, 0x22, 0x5c,
             0x01, 0x01, 0x01, 0x01,
             0x01, 0x01, 0x01, 0x01]
    mixed_block = mix_columns(block)
    expected_block = [0x8e, 0x4d, 0xa1, 0xbc,
                      0x9f, 0xdc, 0x58, 0x9d,
                      0x01, 0x01, 0x01, 0x01,
                      0x01, 0x01, 0x01, 0x01]
    assert expected_block == mixed_block


test_mix_columns()

# Generated at 2022-06-22 06:29:35.638542
# Unit test for function shift_rows
def test_shift_rows():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    expected = [0, 1, 2, 3, 5, 6, 7, 4, 10, 11, 8, 9, 15, 12, 13, 14]
    assert shift_rows(data) == expected



# Generated at 2022-06-22 06:29:46.955939
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    iv = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    cipher = [229, 199, 117, 117, 78, 241, 148, 177, 208, 174, 188, 47, 45, 97, 70, 92,
        209, 132, 114, 53, 142, 242, 240, 75, 165, 172, 52, 133, 252, 205, 52, 10]

    decrypted_data = aes_cbc_decrypt(cipher, key, iv)

# Generated at 2022-06-22 06:29:58.662740
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b,0x7e,0x15,0x16,0x28,0xae,0xd2,0xa6,0xab,0xf7,0x15,0x88,0x09,0xcf,0x4f,0x3c]
    expanded_key = key_expansion(key)

# Generated at 2022-06-22 06:30:08.907845
# Unit test for function key_expansion
def test_key_expansion():
    aes_key = bytes_to_intlist(compat_b64decode(
        b'Cv1X9HJ+SyCm6nqcu6cwUg=='))

# Generated at 2022-06-22 06:30:13.450291
# Unit test for function mix_column
def test_mix_column():
    # Test vector 1
    data = [0xdb, 0x13, 0x53, 0x45]
    expected = [0x8e, 0x4d, 0xa1, 0xbc]
    
    actual = mix_column(data, MIX_COLUMN_MATRIX)
    print("Testing mix_column...")
    assert actual == expected, "Fail"
    print("OK")

test_mix_column()




# Generated at 2022-06-22 06:30:24.582260
# Unit test for function key_expansion
def test_key_expansion():
    print("test_key_expansion")

# Generated at 2022-06-22 06:30:27.412551
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0, 256):
        for j in range(0, 256):
            x = rijndael_mul(i, j)
            y = i * j
            y = y % 0x100
            #print("{:3d} {:3d} {:3d} {:3d}".format(i, j, x, y))
            assert x == y, "Failed unit test on rijndael_mul"
    print("Passed all unit tests on rijndael_mul")


# Generated at 2022-06-22 06:30:29.229768
# Unit test for function shift_rows
def test_shift_rows():
    assert shift_rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]) == [0, 1, 2, 3, 5, 6, 7, 4, 10, 11, 8, 9, 15, 12, 13, 14]



# Generated at 2022-06-22 06:30:57.166639
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    import binascii
    test_data = 'Hello World!'
    test_key = bytes_to_intlist(b'\x00' * 16)
    test_iv = bytes_to_intlist(b'\x00' * 16)
    encrypted_data = aes_cbc_encrypt(bytes_to_intlist(test_data.encode('ascii')), test_key, test_iv)
    decrypted_data = aes_cbc_decrypt(encrypted_data, test_key, test_iv)
    decrypted_data = intlist_to_bytes(decrypted_data)
    if decrypted_data.decode('ascii') == test_data:
        print('test_aes_cbc_encrypt: Success.')

# Generated at 2022-06-22 06:31:04.067868
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    print(aes_decrypt_text(
        b'dddlHHkcw5xFph5lQ2hJlq5+AsoCX5l/aIAW+EgvN2KjHkxNUV8/d4czCv4K4t/Ty9tGnWTMdM=',
        b'demo',
        16
    ).decode('utf-8'))


# Generated at 2022-06-22 06:31:15.685883
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    test_data = [0x6e, 0xc6, 0xa9, 0x51, 0x3b, 0x05, 0x75, 0x69, 0x0e, 0x7e, 0x73, 0x3c, 0x31, 0x09, 0x58, 0x2a]
    actual = sub_bytes_inv(test_data)
    expected = [0xee, 0x4c, 0xc5, 0xd5, 0xb5, 0x0c, 0xfc, 0xeb, 0xcb, 0xf7, 0xf1, 0xbd, 0x64, 0x8e, 0x93, 0x72]
    if actual != expected:
        raise Exception("Substitute bytes test failed!")
    else:
        print("Substitute bytes test passed!")


# Generated at 2022-06-22 06:31:21.909633
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    password = 'foo'
    key_size_bytes = 32
    data = 'CxNxFjKX8hvkZ4mVI4o/DpWfN8YML1RQa1PS6xnHW/X8AX5Z5VUksiM5GjE8W2zU'

    assert(aes_decrypt_text(data, password, key_size_bytes) == 'bar')



# Generated at 2022-06-22 06:31:32.468607
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-22 06:31:37.641246
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x18, 0x53, 0x2c, 0x8a]
    expected = [0x91, 0xdc, 0x5d, 0x3b]
    assert sub_bytes(data) == expected



# Generated at 2022-06-22 06:31:41.759417
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]
    assert rotate([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 1]
    assert rotate([1, 2, 3, 4, 5, 6]) == [2, 3, 4, 5, 6, 1]



# Generated at 2022-06-22 06:31:51.523567
# Unit test for function mix_column
def test_mix_column():
    print('Executing Tests for mix_column')
    columns = []
    for i in range(4):
        column = []
        for j in range(4):
            column.append(j * 4 + i)
        columns.append(column)
    columns2 = []
    for i in range(4):
        columns2.append(mix_column(columns[i], [
                        [2, 3, 1, 1], [1, 2, 3, 1], [1, 1, 2, 3], [3, 1, 1, 2]]))
    columns2_expect = [
        [2, 3, 1, 1], [1, 2, 3, 1], [1, 1, 2, 3], [3, 1, 1, 2]]
    error = 0
    if(columns2 != columns2_expect):
        error

# Generated at 2022-06-22 06:31:59.043591
# Unit test for function xor
def test_xor():
    print('test_xor()...')
    assert xor([2, 3, 4], [1, 2, 3]) == [3, 1, 7]
    assert xor([2, 3, 4], [1, 2, 4]) == [3, 1, 0]
    assert xor([2, 3, 4], [1, 3, 4]) == [3, 0, 0]
    assert xor([2, 3, 4], [2, 3, 4]) == [0, 0, 0]
    print('pasa')



# Generated at 2022-06-22 06:32:10.528051
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # ciphertext of AES_ENCRYPT_TEST_VECTOR_1 (ref: https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf)
    expected = [0x5a, 0x8d, 0xef, 0x2f, 0x0c, 0x0e, 0x87, 0x4c, 0x93, 0x88, 0xfb, 0x4c, 0x3e, 0xaa, 0x60, 0x86]

# Generated at 2022-06-22 06:32:27.620567
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Example from https://www.cs.ucsb.edu/~koc/cs178/projects/JT/aes.c
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c,]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,]

# Generated at 2022-06-22 06:32:29.239401
# Unit test for function inc
def test_inc():
    # Test inc up to 255
    data = [1] * 16
    for i in range(255):
        data = inc(data)

    if data != [255] * 16:
        print("Test inc failed")
    else:
        print("Test inc passed")


# Generated at 2022-06-22 06:32:37.495201
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [1, 2, 3, 4]
    data = key_schedule_core(data, 1)
    assert data == [1, 2, 3, 4]
    data = key_schedule_core(data, 2)
    assert data == [1, 2, 3, 4]
    data = key_schedule_core(data, 4)
    assert data == [1, 2, 3, 4]
    data = key_schedule_core(data, 8)
    assert data == [1, 2, 3, 4]
    data = key_schedule_core(data, 0x10)
    assert data == [1, 2, 3, 4]
    data = key_schedule_core(data, 0x20)
    assert data == [1, 2, 3, 4]
    data = key_schedule_

# Generated at 2022-06-22 06:32:39.293785
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    for i in range(0, 256):
        assert SBOX_INV[SBOX[i]] == i



# Generated at 2022-06-22 06:32:40.772459
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert(rijndael_mul(0x57, 0x13) == 0xfe)
    assert(rijndael_mul(0x57, 2) == 0xae)

test_rijndael_mul()

# Generated at 2022-06-22 06:32:52.245318
# Unit test for function mix_column
def test_mix_column():
    for row in range(4):
        for col in range(4):
            data = [0 for i in range(4)]
            for data_bit in range(8):
                data[col] = 1 << data_bit
                res = mix_column(data, MIX_COLUMN_MATRIX)
                test_res = mix_column(data, MIX_COLUMN_MATRIX_INV)
                try:
                    assert res == test_res
                except AssertionError as e:
                    e.args += (
                        '({:08b}, {:08b}, {:08b})'.format(row, col, data[0]),)
                    raise
    return True


# Generated at 2022-06-22 06:33:02.838619
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Test vectors from: http://www.inconteam.com/software-development/41-encryption/55-aes-test-vectors#aes-ecb-128
    data = bytes_to_intlist(compat_b64decode(b'/Tk6Lf9RGElDj1RzW8uHlw=='))
    expanded_key = bytes_to_intlist(compat_b64decode(b'eCgvzOUi4f0Z/N4kGIu/Z0/rl7XSJyhBVpAkyru5GR5E5iLZmRyxkR0b8xjOe7qO'))

# Generated at 2022-06-22 06:33:12.923155
# Unit test for function xor
def test_xor():
    assert xor([0x01, 0x02, 0x03, 0x04, 0x05], [0xF1, 0xF2, 0xF3, 0xF4, 0xF5]) == [0xF0, 0xF0, 0xF0, 0xF0, 0xF0]
    assert xor([0x01, 0x02, 0x03, 0x04, 0x05], [0x00, 0xF2, 0xF3, 0xF4, 0xF5]) != [0xF0, 0xF0, 0xF0, 0xF0, 0xF0]
    print("test_xor PASSED")
test_xor()


# Generated at 2022-06-22 06:33:15.528353
# Unit test for function shift_rows
def test_shift_rows():
    data = [x for x in range(16)]
    print("Before shift:", end=' ')
    print(data)
    data_shifted = shift_rows(data)
    print("After shift:", end=' ')
    print(data_shifted)



# Generated at 2022-06-22 06:33:19.609043
# Unit test for function inc

# Generated at 2022-06-22 06:33:34.659023
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([1]*16) == [0x63]*16


# Generated at 2022-06-22 06:33:42.072503
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # AES-128-CTR test vectors from
    # http://www.inconteam.com/software-development/41-encryption/55-aes-test-vectors
    class TestCounter(object):
        def __init__(self, first_block):
            self.first_block = first_block
            self.counter = 1

        def next_value(self):
            if self.counter:
                block, self.counter = self.first_block, 0
            else:
                block = [0] * 16
            return block


# Generated at 2022-06-22 06:33:47.889046
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x82, 0x12, 0x00, 0x13]) == [0xd2, 0xc8, 0x53, 0x84]
    assert sub_bytes([0x16, 0x06, 0x70, 0x3b]) == [0x9e, 0x19, 0x2a, 0xfa]
test_sub_bytes()


# Generated at 2022-06-22 06:34:00.277718
# Unit test for function shift_rows

# Generated at 2022-06-22 06:34:12.161307
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert key_schedule_core([0x2b, 0x7e, 0x15, 0x16], 1) == [0x8e, 0x9b, 0xbc, 0xbc]
    assert key_schedule_core([0x8e, 0x9b, 0xbc, 0xbc], 2) == [0x2f, 0x08, 0x4c, 0x99]
    assert key_schedule_core([0x2f, 0x08, 0x4c, 0x99], 3) == [0x3f, 0xca, 0x97, 0x8b]
    assert key_schedule_core([0x3f, 0xca, 0x97, 0x8b], 4) == [0x7b, 0xc4, 0x4c, 0x63]

# Generated at 2022-06-22 06:34:14.677772
# Unit test for function rotate
def test_rotate():
    assert ([0, 1, 2, 3] == rotate([0, 1, 2, 3])), "Rotate function did not return expected result."
    assert ([2, 3, 0, 1] == rotate([0, 1, 2, 3], 2)), "Rotate function did not return expected result."
    assert ([3, 0, 1, 2] == rotate([0, 1, 2, 3], 3)), "Rotate function did not return expected result."



# Generated at 2022-06-22 06:34:18.446102
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xDB, 0x13, 0x53, 0x45,
            0xF2, 0x0A, 0x22, 0x5C,
            0x01, 0x01, 0x01, 0x01,
            0xDF, 0xDF, 0xDF, 0xDF]
    result = [0x8E, 0xE3, 0xB5, 0x0F,
              0x32, 0x56, 0x34, 0x2B,
              0xF5, 0x8B, 0x43, 0xE9,
              0x04, 0xD7, 0xCC, 0x36]
    assert mix_columns_inv(data) == result


# Generated at 2022-06-22 06:34:26.729388
# Unit test for function aes_encrypt

# Generated at 2022-06-22 06:34:38.489865
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv([0xD4, 0xBF, 0x5D, 0x30]) == [0x65, 0xF9, 0xC5, 0x97]
    assert sub_bytes_inv([0x6C, 0x31, 0x59, 0x61]) == [0x42, 0x2D, 0xF0, 0x02]
    assert sub_bytes_inv([0x82, 0x7C, 0x1A, 0x55]) == [0xB2, 0xA1, 0xE8, 0x7D]
    assert sub_bytes_inv([0xBF, 0x37, 0x4F, 0x64]) == [0x35, 0x2E, 0xD0, 0xB3]

# Generated at 2022-06-22 06:34:44.851716
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x00, 0x00, 0x00, 0x00]
    assert key_schedule_core(data, 1) == [0x01, 0x00, 0x00, 0x00]
    data = [0x01, 0x02, 0x03, 0x04]
    assert key_schedule_core(data, 1) == [0x01, 0x03, 0x05, 0x09]

# Generated at 2022-06-22 06:35:12.713522
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from . import js_cipher_aes_cbc_pkcs7

    for i in range(10):
        data = [i for i in range(i)]
        # data += [0] * (BLOCK_SIZE_BYTES - len(data))
        key = [i for i in range(16)]
        iv = [i for i in range(16)]
        encrypted_data = aes_cbc_encrypt(data, key, iv)
        encrypted_data_js = js_cipher_aes_cbc_pkcs7.aes_cbc_encrypt(data, key, iv)
        assert encrypted_data == encrypted_data_js

    for i in [16, 32]:
        data = [i for i in range(i)]
        # data += [0] * (BLOCK_SIZE

# Generated at 2022-06-22 06:35:24.163451
# Unit test for function aes_decrypt

# Generated at 2022-06-22 06:35:29.779812
# Unit test for function key_schedule_core
def test_key_schedule_core():
    dut = key_schedule_core([0x00, 0x00, 0x00, 0x00], 5)
    assert dut == [0x0A, 0xD5, 0x5A, 0xF5], "test_key_schedule_core failed!"
    print('test_key_schedule_core success!')
test_key_schedule_core()


# Generated at 2022-06-22 06:35:36.057703
# Unit test for function key_schedule_core
def test_key_schedule_core():
    expected = [0xef, 0xaa, 0xfb, 0x43]
    result = key_schedule_core([0x2b, 0x7e, 0x15, 0x16], 1)
    assert result == expected, 'Result: {0}, expected: {1}'.format(result, expected)



# Generated at 2022-06-22 06:35:38.540687
# Unit test for function rotate
def test_rotate():
    assert (rotate([1, 2, 3, 4, 5])) == [2, 3, 4, 5, 1]
    return True


# Generated at 2022-06-22 06:35:47.733789
# Unit test for function mix_columns
def test_mix_columns():
    global MIX_COLUMN_MATRIX, MIX_COLUMN_MATRIX_INV
    # Test data taken from http://blog.fpmurphy.com/2009/09/rijndael-mix-columns-method-example.html
    data = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]

# Generated at 2022-06-22 06:35:51.549254
# Unit test for function aes_decrypt
def test_aes_decrypt():
    assert 16 == len(aes_decrypt(aes_encrypt([0] * 16, [0] * 176), [0] * 176))
test_aes_decrypt()


# Generated at 2022-06-22 06:35:55.585116
# Unit test for function sub_bytes
def test_sub_bytes():
    input_test_data = [0x61, 0xAA, 0xB5, 0x75]
    expected_result = [0xF2, 0xA7, 0xD5, 0x68]
    assert sub_bytes(input_test_data) == expected_result
test_sub_bytes()



# Generated at 2022-06-22 06:36:08.028118
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AesCounter
    from .utils import intlist_to_bytes
    key = (0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c, 0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8, 0xf9, 0xfa, 0xfb, 0xfc, 0xfd, 0xfe, 0xff, 0x00, 0x01, 0x02, 0x03)

# Generated at 2022-06-22 06:36:14.123450
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'f3Jz0ePxWQutDmE+lCq3nA=='
    password = 'test'
    assert aes_decrypt_text(data, password, 16) == 'test'
    assert aes_decrypt_text(data, password, 24) == 'test'
    assert aes_decrypt_text(data, password, 32) == 'test'


# Generated at 2022-06-22 06:37:40.139856
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0xf2, 0xd4, 0x6f, 0x45, 0xff, 0x34, 0xab, 0x2e, 0x03, 0xbd, 0xe5, 0x3b, 0x39, 0xbe, 0x2e]
    result = [0x8e, 0xd0, 0x0e, 0xdb, 0x2f, 0x0a, 0x32, 0xd2, 0xa6, 0x10, 0x8c, 0x3f, 0x63, 0xe4, 0x8b, 0x27]
    assert mix_columns(data) == result
    assert mix_columns(data, MIX_COLUMN_MATRIX_INV) == data
    
    
test_mix_columns()

# Generated at 2022-06-22 06:37:51.012046
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    """
    Verify if the function aes_cbc_encrypt works fine
    """
    # Test Case 1

# Generated at 2022-06-22 06:37:51.951142
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes(test_data) == ref_data
    return 'test_sub_bytes passed'



# Generated at 2022-06-22 06:38:02.065872
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0x63, 0x53, 0xe0,
            0x8c, 0x09, 0x60,
            0xc6, 0x83, 0x7f,
            0x0b,0x21, 0xf1]

    data_mixed = mix_columns_inv(data)
    expected_data = [0x63, 0x53, 0xe0,
                     0x8c, 0x09, 0x60,
                     0xc6, 0x83, 0x7f,
                     0x0b,0x21, 0xf1]
    assert data_mixed == expected_data
test_mix_columns_inv()



# Generated at 2022-06-22 06:38:05.322756
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv([0x39,0x02,0xdc,0x19]) == [0x7d,0x31,0xe9,0xc4]



# Generated at 2022-06-22 06:38:09.876974
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 1]
    assert rotate([1, 2, 3, 4, 5, 6, 7]) == [2, 3, 4, 5, 6, 7, 1]
    assert rotate([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 1]


# Generated at 2022-06-22 06:38:21.167821
# Unit test for function key_schedule_core
def test_key_schedule_core():
    print("Test for function key_schedule_core")
    data = [0x00, 0x01, 0x02, 0x03]
    assert(key_schedule_core(data, 1) == [0x01, 0x01, 0x01, 0x01])
    assert(key_schedule_core(data, 2) == [0x02, 0x02, 0x02, 0x02])
    assert(key_schedule_core(data, 3) == [0x04, 0x04, 0x04, 0x04])
    assert(key_schedule_core(data, 4) == [0x08, 0x08, 0x08, 0x08])
    print("Test passed!")


test_key_schedule_core()


# Generated at 2022-06-22 06:38:23.222636
# Unit test for function mix_columns
def test_mix_columns():
    print(mix_columns(range(16)))
    print(mix_columns(range(16), MIX_COLUMN_MATRIX_INV))




# Generated at 2022-06-22 06:38:35.127869
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv([0x52,0x09,0x6a,0xd5,0x30,0x36,0xa5,0x38,0xbf,0x40,0xa3,0x9e,0x81,0xf3,0xd7,0xfb]) == [0x63,0xc0,0xe4,0x09,0x89,0x9d,0xec,0x1b,0xb7,0x6f,0x7f,0x67,0x2b,0x3e,0x8e,0x83]
    print("test_sub_bytes_inv success!")
#test_sub_bytes_inv()


testSBOX = sub_bytes([0x48, 0x07, 0x4a, 0x60])


# Generated at 2022-06-22 06:38:46.457323
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0x07, 0xa8, 0x8d, 0xa2, 0x34]