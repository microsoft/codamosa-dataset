

# Generated at 2022-06-22 06:29:21.281910
# Unit test for function inc
def test_inc():
    plaintext = [0, 1, 2, 6, 207, 255]
    plaintext = [0x00, 0x80, 0x98, 0x2A, 0xAF, 0xF0, 0xFF]
    for p in plaintext:
        assert inc([p]) == [(p + 1) % 256]


# Generated at 2022-06-22 06:29:23.424046
# Unit test for function rotate
def test_rotate():
    test_data = [1,2,3,4,5]
    assert rotate(test_data) == [2,3,4,5,1]


# Generated at 2022-06-22 06:29:32.359855
# Unit test for function key_schedule_core
def test_key_schedule_core():

    data1 = [0x1f, 0x1e, 0x1d, 0x1c]
    assert (key_schedule_core(data1, 1) == [0x1d, 0x1d, 0x1f, 0x1a])

    data2 = [0x2f, 0x2e, 0x2d, 0x2c]
    assert (key_schedule_core(data2, 2) == [0x29, 0x22, 0x35, 0x18])

    data3 = [0x3f, 0x3e, 0x3d, 0x3c]
    assert (key_schedule_core(data3, 3) == [0x30, 0x27, 0x41, 0x06])


# Generated at 2022-06-22 06:29:37.097520
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]
    assert rotate([1, 2, 3]) == [2, 3, 1]



# Generated at 2022-06-22 06:29:47.837008
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-22 06:29:53.472295
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print('Unit Testing Rijndael Multiplication:')
    test_pairs = ((0x57, 0x83), (0x13, 0x01), (0xA9, 0x5B), (0xA0, 0x50))
    for a, b in test_pairs:
        result = rijndael_mul(a, b)
        print(f"({hex(a)}, {hex(b)}) --> {hex(result)}")


test_rijndael_mul()



# Generated at 2022-06-22 06:30:05.294469
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b"0123456789abcdef")
    key = bytes_to_intlist(b"000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f")
    iv = bytes_to_intlist(b"101112131415161718191a1b1c1d1e1f")
    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-22 06:30:10.960439
# Unit test for function sub_bytes
def test_sub_bytes():
    # Test sub_bytes function, input all zero state, output should be all non-zero
    # state
    all_zero = [0] * 16
    sub_bytes_output = sub_bytes(all_zero)
    # If sub_bytes(all_zero) succeeds, then all element of sub_bytes_output should
    # be non-zero
    for x in sub_bytes_output:
        if x == 0:
            return False
    return True



# Generated at 2022-06-22 06:30:21.482568
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 1) == [0x02, 0x03, 0x04, 0x01]
    assert key_schedule_core([0x00, 0x00, 0x00, 0x00], 1) == [0x00, 0x00, 0x00, 0x00]
    assert key_schedule_core([0x01, 0x01, 0x01, 0x01], 1) == [0x01, 0x01, 0x01, 0x01]
    assert key_schedule_core([0xAA, 0xAA, 0xAA, 0xAA], 1) == [0xAA, 0xAA, 0xAA, 0xAA]

# Generated at 2022-06-22 06:30:29.671674
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Test vector from http://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38a.pdf Appendix F.2.3
    class NextCounter(object):
        def __init__(self):
            self.i = 0
        def next_value(self):
            self.i += 1
            return bytes_to_intlist(compat_b64decode('6JC0vBkYyhxi8EuYiDGTQA=='))

    data = bytes_to_intlist(compat_b64decode('1BDC0/jqgP/tAOJtN5+/R1lhl2eZ0+BKjDCCfvdImLk='))

# Generated at 2022-06-22 06:31:03.398644
# Unit test for function inc
def test_inc():
    print("Test inc: ", end='')
    assert(inc([1, 3, 3, 7]) == [1, 3, 4, 0])
    assert(inc([0, 0, 0, 0]) == [0, 0, 0, 1])
    assert(inc([255, 255, 255, 255]) == [0, 0, 0, 0])
    print("Ok")
test_inc()


# Generated at 2022-06-22 06:31:08.628687
# Unit test for function mix_column
def test_mix_column():
    assert(mix_column([0xDB, 0x13, 0x53, 0x45], MIX_COLUMN_MATRIX) == [0x8E, 0x4D, 0xA1, 0xBC])
    assert(mix_column([0x8E, 0x4D, 0xA1, 0xBC], MIX_COLUMN_MATRIX_INV) == [0xDB, 0x13, 0x53, 0x45])



# Generated at 2022-06-22 06:31:19.721392
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    inp = bytes_to_intlist(b'\x6c\x0f\x8f\x93\x5a\x88\x02\x2a\x18\x0d\xeb\x8a\xfc\xa9\xac\x38')
    key = bytes_to_intlist(b'\x30\x4f\x4c\x4e\x4a\x49\x55\x4f\x4b\x4b\x43\x4a\x52\x52\x4d\x00')

# Generated at 2022-06-22 06:31:31.705167
# Unit test for function mix_columns
def test_mix_columns():
    def hex2decimal(s):
        return int(s, 16)

    def test_case(s1, s2, s3):
        a = [hex2decimal(x) for x in s1]
        b = [hex2decimal(x) for x in s2]
        if mix_column(a, MIX_COLUMN_MATRIX) == b:
            print("Test case: PASS")
        else:
            print("Test case: FAIL")

    s1 = "02 03 01 01"
    s2 = "04 0c 02 02"
    s3 = "0c 0f 0d 09"
    s4 = "0d 0e 0b 0d"
    s5 = "09 0f 0e 0b"
    s6 = "0b 0d 09 0e"

    test

# Generated at 2022-06-22 06:31:42.381158
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = (AES.key_schedule_core([0, 0, 0, 0], 1))
    assert(data == [0, 0, 0, 1])

    data = (AES.key_schedule_core([1, 2, 3, 4], 1))
    assert(data == [2, 3, 4, 1])

    data = (AES.key_schedule_core([0x00010203, 0x04050607, 0x08090a0b, 0x0c0d0e0f], 1))
    assert(data == [0x01020304, 0x05060708, 0x090a0b0c, 0x0d0e0f10])


test_key_schedule_core()



# Generated at 2022-06-22 06:31:47.714047
# Unit test for function shift_rows
def test_shift_rows():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    expected_data = [0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11]
    assert expected_data == shift_rows(data)

# Generated at 2022-06-22 06:31:58.886699
# Unit test for function xor

# Generated at 2022-06-22 06:32:10.353977
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-22 06:32:20.947421
# Unit test for function mix_columns
def test_mix_columns():
    print("mix_columns", end=' -> ')
    data = [0xdb, 0xf2, 0xd4, 0x6f, 0x45, 0xa4, 0x7a, 0x25, 0x52, 0x16, 0xcc, 0x1d, 0xae, 0x10, 0x2c, 0x31]
    result = mix_columns(data)
    result_expected = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x26, 0x9b, 0x9c, 0x3a, 0xfa, 0xa4, 0xe2]
    if result == result_expected:
        print("PASSED")

# Generated at 2022-06-22 06:32:33.546781
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class DummyCounter(object):
        def __init__(self, counter=0):
            self.counter = counter
        def next_value(self):
            out = [self.counter & 0xff, (self.counter >> 8) & 0xff, (self.counter >> 16) & 0xff, (self.counter >> 24) & 0xff,
                   0, 0, 0, 0,
                   0, 0, 0, 0,
                   0, 0, 0, 0]
            self.counter += 1
            return out
    data = bytes_to_intlist(b'\x7a\x27\xac\x19\x8c\x1b\x5c')

# Generated at 2022-06-22 06:32:59.049896
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]
    data_shifted = shift_rows_inv(data)
    assert(data_shifted == [0x63, 0xb7, 0xe0, 0x70, 0xca, 0xd0, 0x60, 0xe1, 0x04, 0x51, 0xba, 0x8c, 0x09, 0xe7, 0xcd, 0x53])
    print("Test shift_rows_inv success!")


# Generated at 2022-06-22 06:33:08.089585
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key1 = [0x00, 0x00, 0x00, 0x00]
    round1_expected_output = [0x01, 0x00, 0x00, 0x00]
    result = key_schedule_core(key1, 1)
    if result == round1_expected_output:
        print("Unit test for function key_schedule_core in aes.py: pass")
    else:
        print("Unit test for function key_schedule_core in aes.py: fail")

test_key_schedule_core()


# Generated at 2022-06-22 06:33:13.091419
# Unit test for function xor
def test_xor():
    data1 = [0x1f, 0x0f, 0x1f, 0x0f]
    data2 = [0x2a, 0x2a, 0x2a, 0x2a]
    assert xor(data1, data2) == [0x25, 0x25, 0x25, 0x25]



# Generated at 2022-06-22 06:33:15.552350
# Unit test for function shift_rows
def test_shift_rows():
    input_ = [x for x in range(16)]
    output = [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
    assert shift_rows(input_) == output



# Generated at 2022-06-22 06:33:26.503336
# Unit test for function mix_column
def test_mix_column():
    test_a = [0x0f, 0x0f, 0x0f, 0x0f]
    data_a_mixed = mix_column(test_a, MIX_COLUMN_MATRIX)
    assert data_a_mixed == [0x1b, 0x1b, 0x1b, 0x1b]

    test_b = [0x1b, 0x1b, 0x1b, 0x1b]
    data_b_mixed = mix_column(test_b, MIX_COLUMN_MATRIX_INV)
    assert data_b_mixed == [0x0f, 0x0f, 0x0f, 0x0f]

# Generated at 2022-06-22 06:33:32.871918
# Unit test for function mix_columns
def test_mix_columns():
    test_data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns(test_data)
    print(format(result[0], '02x'))
    print(format(result[1], '02x'))
    print(format(result[2], '02x'))
    print(format(result[3], '02x'))
    
    
#test_mix_columns()

# Generated at 2022-06-22 06:33:41.322183
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .aes import aes_cbc_encrypt
    from .utils import hex_to_intlist, intlist_to_hex

    for i in range(1, 33):
        key = [i] * 32
        iv = [0] * 16
        data = [i] * 64
        data = aes_cbc_encrypt(data, key, iv)
        decrypted_data = aes_cbc_decrypt(data, key, iv)
        print(intlist_to_hex(data))
        print(intlist_to_hex(decrypted_data))


# Generated at 2022-06-22 06:33:52.265387
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]
    assert inc([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2]

# Generated at 2022-06-22 06:33:58.941742
# Unit test for function shift_rows
def test_shift_rows():
    data_shifted = []
    for row in range(4):
        data_shifted.append(row * 4)
    data_shifted = shift_rows(data_shifted)
    for row in range(4):
        for column in range(4):
            assert(data_shifted[row * 4 + column] == column * 4 + row)
test_shift_rows()



# Generated at 2022-06-22 06:34:06.507751
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test with data provided by Youtube
    """
    cipher = 'h/Eu5w5cO4z4DDUR4MiepfXb1xkdwoSgS7cPEucPn64BwCQ2RnfbZzTQTmrJXA7votnfFXRaD1Hq3sjJ8PnGgR0H/T2QzgF8Xvxih0yHm0qf3q/d8sM0AaOZz4C4ty/p/'
    password = 'youtube'
    key_size_bytes = 32
    plaintext = aes_decrypt_text(cipher, password, key_size_bytes)

# Generated at 2022-06-22 06:34:24.128963
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = 'Hello World!'.encode('utf-8')
    key = '1234567890123456'.encode('utf-8')
    iv = '1234567890123456'.encode('utf-8')
    # Python 2/3 compat
    if type(iv) is bytes:
        iv = [ord(i) for i in iv]
    #
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    encrypted_data = intlist_to_bytes(encrypted_data)

# Generated at 2022-06-22 06:34:35.827161
# Unit test for function aes_encrypt

# Generated at 2022-06-22 06:34:43.717138
# Unit test for function key_schedule_core
def test_key_schedule_core():
    test = [0xFF, 0xFF, 0xFF, 0xFF]
    assert key_schedule_core(test, 1) == [0xF, 0x1, 0x75, 0xDF]
    assert key_schedule_core(test, 2) == [0xF, 0xFF, 0xFF, 0xE7]
    assert key_schedule_core(test, 3) == [0xF, 0xFF, 0xFF, 0x7]

test_key_schedule_core()



# Generated at 2022-06-22 06:34:53.505990
# Unit test for function aes_encrypt
def test_aes_encrypt():
    from .utils import bytes_to_intlist, intlist_to_bytes
    from .crypto import AES_KEY, AES_IV, AES_EXPANDED_KEY
    assert aes_encrypt(bytes_to_intlist(b'\x00' * 16), AES_EXPANDED_KEY) == bytes_to_intlist(b"\x1A\xD6\x0E\xC6\xA6\xA2\x1B\x1C\x17\x21\x91\x80\x72\xF9\xD0\x9E")

# Generated at 2022-06-22 06:34:57.144572
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    expected = [0x45, 0x11, 0xA2, 0xBF, 0x78, 0x1B, 0xB6, 0x6E, 0x87, 0x3B, 0xA7, 0xD5, 0xBA, 0x3F, 0x54, 0xF1]
    data = [0xF5, 0x0E, 0xD8, 0xF1, 0x32, 0x98, 0x4B, 0x6C, 0x88, 0xDA, 0xF8, 0x5A, 0x35, 0x4D, 0x48, 0x19]
    assert(mix_columns_inv(data) == expected)



# Generated at 2022-06-22 06:35:07.162448
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0,0) == 0
    assert rijndael_mul(0,1) == 0
    assert rijndael_mul(1,0) == 0
    assert rijndael_mul(1,1) == 1
    assert rijndael_mul(1,2) == 2
    assert rijndael_mul(1,4) == 4
    assert rijndael_mul(1,8) == 8
    assert rijndael_mul(1,3) == 3
    assert rijndael_mul(2,3) == 6
    assert rijndael_mul(3,2) == 9
    assert rijndael_mul(4,4) == 0x1b
    assert rijndael_mul

# Generated at 2022-06-22 06:35:18.545788
# Unit test for function mix_column
def test_mix_column():
    for i in range(4):
        for j in range(4):
            data = [0] * 4
            data[i] = 1
            matrix = [[0] * 4 for _ in range(4)]
            matrix[j][i] = 1
            mixed = mix_column(data, matrix)
            print(data, mixed)
            # data that is not mixed is not changed
            #if data[k] != mixed[k]:
            #    return False
    return True
print(test_mix_column())
mixed_column_matrix = [[2, 3, 1, 1], [1, 2, 3, 1], [1, 1, 2, 3], [3, 1, 1, 2]]
data = [1, 0, 0, 0]
print(mix_column(data, mixed_column_matrix))


# Generated at 2022-06-22 06:35:25.393859
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist('another key')
    expanded_key = bytes_to_intlist('01234567890123456789012345678901')
    cipher = aes_encrypt(data, expanded_key)
    assert intlist_to_bytes(cipher).encode('hex') == 'a843659649c09f6b7ebe08597e9d7f9c'



# Generated at 2022-06-22 06:35:27.157168
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [11, 22, 33, 44, 22, 0, 1, 2, 3, 4, 55, 6, 7, 99, 123, 99]
    print(shift_rows_inv(shift_rows(data)))
    print(shift_rows_inv(data))

# test_shift_rows_inv()



# Generated at 2022-06-22 06:35:38.593670
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76]
    data_shifted = [0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0xC5, 0x6F, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76]
    assert(data_shifted == shift_rows(data))

# Generated at 2022-06-22 06:35:58.775001
# Unit test for function inc
def test_inc():
    assert inc([1, 2, 3, 4]) == [1, 2, 3, 5]
    assert inc([1, 2, 3, 255]) == [1, 2, 4, 0]
    assert inc([1, 2, 255, 255]) == [1, 3, 0, 0]
    assert inc([1, 255, 255, 255]) == [2, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-22 06:36:00.495784
# Unit test for function rotate
def test_rotate():
    assert rotate([0,1,2,3,4]) == [1,2,3,4,0]


# from http://stackoverflow.com/questions/24665854/how-to-flatten-list-of-tuples-in-python

# Generated at 2022-06-22 06:36:08.374391
# Unit test for function mix_columns
def test_mix_columns():
        input = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
        output = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
        assert mix_columns(input) == output
        print("Test mix_columns passed")
test_mix_columns()


# Generated at 2022-06-22 06:36:19.288209
# Unit test for function key_expansion

# Generated at 2022-06-22 06:36:21.232460
# Unit test for function xor
def test_xor():
    assert [i ^ j for i, j in zip([1,2,3],[4,5,6])] == [5,7,5]


# Generated at 2022-06-22 06:36:25.205879
# Unit test for function inc
def test_inc():
    data = [0, 0, 0, 1]
    assert inc(data) == [0, 0, 1, 1]
    data = [0, 1, 0, 255]
    assert inc(data) == [0, 1, 1, 0]
    data = [255, 255, 255, 255]
    assert inc(data) == [0, 0, 0, 0]
    data = [1, 2, 3, 4]
    assert inc(data) == [1, 2, 3, 5]



# Generated at 2022-06-22 06:36:27.221738
# Unit test for function sub_bytes
def test_sub_bytes():
    output = sub_bytes(range(1, 9))
    expected = [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5]
    assert output == expected



# Generated at 2022-06-22 06:36:33.100809
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF]
    expected = [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]
    actual = sub_bytes(data)
    if actual != expected:
        raise Exception("Incorrect output: " + str(actual))

test_sub_bytes()



# Generated at 2022-06-22 06:36:43.730102
# Unit test for function key_expansion
def test_key_expansion():
    result = key_expansion([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c])

# Generated at 2022-06-22 06:36:54.235972
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    expanded_key = key_expansion(key)
    data = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    counter = Counter(2)
    cleartext = aes_ctr_decrypt(data, expanded_key, counter)
    cleartext_text = intlist_to_bytes(cleartext)
    assert cleartext_text == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '
# Unit test
test_aes_ctr_decrypt()

# Generated at 2022-06-22 06:37:30.553602
# Unit test for function xor
def test_xor():
    assert xor([0x0f, 0x0f, 0x0f, 0x0f], [0x02, 0x02, 0x02, 0x02]) == [0x0d, 0x0d, 0x0d, 0x0d]



# Generated at 2022-06-22 06:37:38.627103
# Unit test for function rijndael_mul
def test_rijndael_mul():
    examples = [(0,0),(0x57,0x13),(0x81,0xCF),(0xCE,0x75)]
    expected = [0,0xFE,0x17,0xA6]
    wrong = False
    for example, expected in zip(examples, expected):
        actual = rijndael_mul(example[0],example[1])
        if actual != expected:
            print('Error: Actual result {0} is different than expected result {1}'.format(actual, expected))
            wrong = True
    if wrong == False:
        print('rijndael_mul test passed')



# Generated at 2022-06-22 06:37:49.608188
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .utils import bytes_to_intlist, intlist_to_bytes, split_len
    from .crypto import aes_cbc_decrypt, aes_ctr_decrypt

    key = bytes_to_intlist(compat_b64decode('hJtXIZ2uSN5kbQfbtTNWbpdmhkV8FJG-Onbc6mxCcYg'))
    nonce = bytes_to_intlist(compat_b64decode('ZmhBbmRQVlRvWjIwVFJtcEtDUm9ibEl6'))

# Generated at 2022-06-22 06:37:51.300681
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv([0xDA, 0xDC, 0x6A, 0x7B]) == [0x45, 0x91, 0xF1, 0x05]
    print("test_sub_bytes_inv: passed")
#test_sub_bytes_inv()



# Generated at 2022-06-22 06:37:55.661579
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = [48, 38, 178, 201, 46, 111, 210, 221, 38, 236, 142, 216, 18, 20, 140, 112]
    key = [11, 151, 175, 24, 117, 50, 174, 200, 198, 160, 160, 142, 98, 70, 152, 160, 198, 233, 92, 230, 85, 243, 71, 2]

# Generated at 2022-06-22 06:38:01.530065
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert(rijndael_mul(0x57, 0x83) == 0xc1)
    assert(rijndael_mul(0x13, 0x09) == 0x0e)
    assert(rijndael_mul(0x0c, 0x03) == 0x01)
    print('Unit test pass!')

test_rijndael_mul()


# Generated at 2022-06-22 06:38:09.911084
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert [0x00, 0x44, 0x88, 0xCC, 0x11, 0x55, 0x99, 0xDD, 0x22, 0x66, 0xAA, 0xEE, 0x33, 0x77, 0xBB, 0xFF] == sub_bytes_inv([0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f])



# Generated at 2022-06-22 06:38:21.634412
# Unit test for function key_expansion
def test_key_expansion():
    key_16 = bytes_to_intlist(b'1234567890123456')
    key_24 = bytes_to_intlist(b'123456789012345678901234')
    key_32 = bytes_to_intlist(b'12345678901234567890123456789012')

    key_16_exp = bytes_to_intlist(compat_b64decode(b'F3o2QnxsaXszM1H8nfEkIgDZpFIkTdTizTfPW0xmJi6XyVB6Hm8oUzV7miQa6bZDdYl0LmfmS7iN5M5XD74QQ=='))
    key_24_exp = bytes_to_int

# Generated at 2022-06-22 06:38:32.000419
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    pt = [0xdb, 0x13, 0x53, 0x45,
          0xf2, 0x0a, 0x22, 0x5c,
          0x01, 0x01, 0x01, 0x01,
          0x01, 0x01, 0x01, 0x01]
    ct = [0x8e, 0x4d, 0xa1, 0xbc,
          0x9f, 0xdc, 0x58, 0x9d,
          0x01, 0x01, 0x01, 0x01,
          0x01, 0x01, 0x01, 0x01]
    mix_columns_inv(ct) == pt



# Generated at 2022-06-22 06:38:42.645587
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, block):
            self.block = block
            self.counter = 0

        def next_value(self):
            self.counter += 1
            return self.block

    def check(key, block, expected_data):
        counter = Counter(block)
        data = aes_encrypt(expected_data, key_expansion(key), counter)
        decrypted_data = aes_ctr_decrypt(data[:], key, counter)
        assert intlist_to_bytes(decrypted_data) == expected_data

    expected_data = compat_b64decode('fGoaVJr99Fqxqm7ZhTnHtD1oDfRTT8gD')