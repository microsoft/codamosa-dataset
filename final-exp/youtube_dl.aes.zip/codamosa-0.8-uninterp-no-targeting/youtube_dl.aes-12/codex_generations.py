

# Generated at 2022-06-22 06:29:32.261754
# Unit test for function key_expansion
def test_key_expansion():
    output = key_expansion([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c])
    assert len(output) == 176
    assert bytes_to_intlist(intlist_to_bytes(output)) == output
    assert bytes_to_intlist(b64decode('U2FsdGVkX1+zZpxU6jkMCJT2TmFhz4GEuQe4vuO94D4=')) == output

# Generated at 2022-06-22 06:29:40.881270
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]) == [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]



# Generated at 2022-06-22 06:29:49.028516
# Unit test for function rotate
def test_rotate():
    result = rotate([0x0, 0x4, 0x8, 0xC])
    assert result == [0x4, 0x8, 0xC, 0x0]
    result = rotate([0x0, 0x4, 0x8, 0xC], n=3)
    assert result == [0xC, 0x0, 0x4, 0x8]
    result = rotate([0x0, 0x4, 0x8, 0xC], n=5)
    assert result == [0x8, 0xC, 0x0, 0x4]



# Generated at 2022-06-22 06:30:01.212985
# Unit test for function aes_decrypt
def test_aes_decrypt():
    if True:
        data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
        expanded_key = key_expansion(data)
        decrypted_data = aes_decrypt(data, expanded_key)
        print(decrypted_data)
        assert aes_encrypt(decrypted_data, expanded_key) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    if True:
        data_bytes = b'\0' * BLOCK_SIZE_BYTES
        key_bytes = b'\1' * BLOCK_SIZE_BYTES

# Generated at 2022-06-22 06:30:13.884916
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Comparing with https://software.intel.com/sites/default/files/article/165683/aes-wp-2012-09-22-v01.pdf
    data = bytes_to_intlist(compat_b64decode(
        '4BF92F637F04D599D851D357CBCFEE608649C72269BA3EE23C7E9D2FEB0F4A4C'))

# Generated at 2022-06-22 06:30:17.795694
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test_str = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert mix_columns_inv(test_str) == [0x53, 0xF1, 0x0A, 0x71, 0x8E, 0x23, 0x2A, 0x4A, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    print('Mix Columns Inverse unit test passed successfully')
test_mix_columns_inv()


# Generated at 2022-06-22 06:30:19.434903
# Unit test for function shift_rows
def test_shift_rows():
    assert shift_rows([x for x in range(16)]) == [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
test_shift_rows()



# Generated at 2022-06-22 06:30:21.012324
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for x in range(0,256):
        for y in range(0,256):
            if (x*y != rijndael_mul(x,y)):
                print("Test failed, inputs %d %d", x, y)
    print("Test passed")


# Generated at 2022-06-22 06:30:23.580775
# Unit test for function inc
def test_inc():
    assert inc([255, 254, 253, 252]) == [255, 255, 254, 253]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]


# Generated at 2022-06-22 06:30:35.057383
# Unit test for function aes_decrypt

# Generated at 2022-06-22 06:30:46.922393
# Unit test for function xor
def test_xor(): 
    a = [0x9b, 0x0e, 0x7c, 0x8f] 
    b = [0x4d, 0x4c, 0xd4, 0x7a] 
    assert(xor(a,b) == [0xd6, 0x4a, 0xa8, 0xf5])
    print("Test xor is passed")
test_xor()


# Generated at 2022-06-22 06:30:56.617660
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xFF, 0xFF, 0xFF, 0xFF,
            0xFF, 0xFF, 0xFF, 0xFF,
            0xFF, 0xFF, 0xFF, 0xFF,
            0xFF, 0xFF, 0xFF, 0xFF]
    actual = mix_columns(data)
    expected = [0xEF, 0xFF, 0xFF, 0xFF,
                0xFF, 0xEF, 0xFF, 0xFF,
                0xFF, 0xFF, 0xEF, 0xFF,
                0xFF, 0xFF, 0xFF, 0xEF]
    print('Test mix_columns: {0}'.format('success' if actual == expected else 'failure'))



# Generated at 2022-06-22 06:31:01.084360
# Unit test for function rotate
def test_rotate():
    assert(rotate([1,2,3]) == [2,3,1])
    assert(rotate([1,2,3,4,5,6,7,8,9]) == [2,3,4,5,6,7,8,9,1])


# Generated at 2022-06-22 06:31:05.888350
# Unit test for function rotate
def test_rotate():
    assert [1, 2, 3, 4] == rotate([2, 3, 4, 1])
    assert [1, 2, 3, 4] == rotate([3, 4, 1, 2])
    assert [1, 2, 3, 4] == rotate([4, 1, 2, 3])



# Generated at 2022-06-22 06:31:11.902213
# Unit test for function mix_columns
def test_mix_columns():
    data = [0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17]
    data_mixed = mix_columns(data)
    print(bytes(data_mixed))
    assert data_mixed == [0x04, 0x0E, 0x0D, 0x01, 0x0B, 0x08, 0x03, 0x0F, 0x06, 0x0A, 0x0C, 0x00, 0x0F, 0x07, 0x01, 0x0D]



# Generated at 2022-06-22 06:31:20.995266
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [
        0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6,
        0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C
    ]
    data = [
        0x76, 0x49, 0xAB, 0xAC, 0x81, 0x19, 0xB2, 0x46,
        0xCE, 0xE9, 0x8E, 0x9B, 0x12, 0xE9, 0x19, 0x7D
    ]

# Generated at 2022-06-22 06:31:30.305183
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    assert[
        162, 159, 142, 221, 148, 221, 226, 47, 104, 146, 232, 2, 205,
        251, 152, 251] == aes_cbc_encrypt([0] * 16, [
            0] * 16, [0] * 16)
    assert[
        101, 204, 43, 157, 174, 121, 123, 168, 117, 81, 229, 72, 41,
        35, 236, 33] == aes_cbc_encrypt([0] * 16, [
            0] * 16, [1] * 16)



# Generated at 2022-06-22 06:31:41.986624
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x00, 0x00, 0x00, 0x00]
    # Round 1
    round1_out = [0x01, 0x00, 0x00, 0x00]
    test_result = key_schedule_core(data, 1)
    if test_result != round1_out:
        raise Exception("key_schedule_core round 1 failed")

    # Round 2
    round2_out = [0x02, 0x00, 0x00, 0x00]
    test_result = key_schedule_core(test_result, 2)
    if test_result != round2_out:
        raise Exception("key_schedule_core round 2 failed")

    # Round 3
    round3_out = [0x04, 0x00, 0x00, 0x00]
   

# Generated at 2022-06-22 06:31:49.840078
# Unit test for function rotate
def test_rotate():
    assert rotate([0x01, 0x02, 0x03, 0x04]) == [0x02, 0x03, 0x04, 0x01]
    assert rotate([0xab, 0xcd, 0xef, 0x01]) == [0xcd, 0xef, 0x01, 0xab]
    assert rotate([0x01, 0x01, 0x01, 0x01]) == [0x01, 0x01, 0x01, 0x01]



# Generated at 2022-06-22 06:31:54.171295
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert (aes_decrypt_text(
        'NrNrAUGrYC+Qx2l9X+1nCQ==',
        'password',
        32)
        == b'Yo, ho ho!')



# Generated at 2022-06-22 06:32:07.547624
# Unit test for function shift_rows
def test_shift_rows():
    test = [0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51,
            0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]
    res = shift_rows(test)
    assert res == [0x63, 0x53, 0x33, 0x43, 0x09, 0x60, 0x70, 0x80,
                   0x8c, 0xca, 0xba, 0xab, 0x04, 0x51, 0xe1, 0xe7]



# Generated at 2022-06-22 06:32:11.524545
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range(0, 0xFF):
        for b in range(0, 0xFF):
            if(rijndael_mul(a, b) != int(hex(a)[-1], 16) * int(hex(b)[-1], 16)):
                print("Test failed on: " + hex(a) + " * " + hex(b))


# Generated at 2022-06-22 06:32:13.267893
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x01, 0x02, 0x03, 0x04]
    test = key_schedule_core(data, 0x01)
    assert test == [0x02, 0x04, 0x01, 0x0b]

# Generated at 2022-06-22 06:32:25.171044
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """
    Encrypts with key: '140b41b22a29beb4061bda66b6747e14'
             IV:      '4ca00ff4c898d61e1edbf1800618fb28'
             Data:    '66877857a63770c098a8c9d9ebf72a35'
    As said in http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    this should result to
            Cipher:  'c30e32ffedc0774e6aff6af0869f71aa'
    """
    key_hex = '140b41b22a29beb4061bda66b6747e14'

# Generated at 2022-06-22 06:32:34.103057
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key1 = bytes_to_intlist(compat_b64decode(b'CY9rzUYh03PK3k6DJie09g=='))
    d1 = bytes_to_intlist(compat_b64decode(b'Rkb4jvAyEpdIkla0DhD6ejM2NiA3SbEULCXche07zKM='))
    iv1 = bytes_to_intlist(compat_b64decode(b'L7Ror5JZesTL6VfG'))
    assert intlist_to_bytes(aes_cbc_decrypt(d1, key1, iv1)) == b'This is a test string for CBC'


# Generated at 2022-06-22 06:32:45.367418
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-22 06:32:51.766442
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Raw data
    raw_data = bytes_to_intlist(b'X') + [1] * (BLOCK_SIZE_BYTES - 1)

    # Password
    password = bytes_to_intlist(b'1234567890123456')
    password = password * (32 // BLOCK_SIZE_BYTES)

    # Encrypt
    expanded_key = key_expansion(password[:32])
    nonce = [0] * BLOCK_SIZE_BYTES
    nonce[0] = 1
    class Counter(object):
        __value = nonce

        def next_value(self):
            temp = self.__value
            self.__value = inc(self.__value)
            return temp

    encryp

# Generated at 2022-06-22 06:32:55.373459
# Unit test for function sub_bytes
def test_sub_bytes():
    assert (sub_bytes([1, 2, 3, 4]) == [0x63, 0x7c, 0x77, 0x7b])
    assert (sub_bytes([0x00, 0x00, 0x00, 0x00]) == [0x63, 0x7c, 0x77, 0x7b])
    assert (sub_bytes([0x11, 0x12, 0x13, 0x14]) == [0x6b, 0x9f, 0x4e, 0x20])
    assert (sub_bytes([0xf4, 0xee, 0x8e, 0x88]) == [0x97, 0x48, 0x53, 0x2d])



# Generated at 2022-06-22 06:33:04.358681
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-22 06:33:09.010243
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = "00112233445566778899aabbccddeeff"
    iv = "000102030405060708090a0b0c0d0e0f"
    data = "00112233445566778899aa"

    expected_result = "20794655cb9a7b8a74ee11a27df9fb50"
    result = intlist_to_bytes(aes_cbc_encrypt(bytes_to_intlist(data), bytes_to_intlist(key), bytes_to_intlist(iv)))
    assert result == expected_result

    data = "0" * 32
    expected_result = "59d6b0f05e6ecc75f8a25f92ea18d995a3c740496380f70d6d7"
   

# Generated at 2022-06-22 06:33:14.850882
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]
    assert rotate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 3, 4, 5, 6, 7, 8, 9, 10, 1]



# Generated at 2022-06-22 06:33:26.651482
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    clear_text = bytes('1111222233334444', 'utf-8')
    clear_text_intlist = bytes_to_intlist(clear_text)
    key_intlist = bytes_to_intlist(compat_b64decode('GawgguFyGrWKav7AX4VKUg'))
    iv_intlist = bytes_to_intlist(compat_b64decode('YF40PFnagTFgWBBa'))
    expected_cipher_intlist = bytes_to_intlist(compat_b64decode('0DC8CE69FBCC40D9'))
    encryption_result = aes_cbc_encrypt(clear_text_intlist, key_intlist, iv_intlist)
    assert encryption_result == expected_cipher_intlist

# Generated at 2022-06-22 06:33:38.096845
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    from .utils import compat_ord
    from base64 import b64encode, b64decode
    from .compat import compat_b
    # 256-Bit key
    data = b'MhcrxEyIJ1zZCWhU6ESsUjg9Xh7PcRlNvV8XY+xNzGw='
    password = '123456'
    decrypted = aes_decrypt_text(data, password, 32)
    assert decrypted == compat_b('2\r\nhell\no\n0\n\n')
    # 256-Bit key (modified signature)
    data = b'MhcrxEyIJ1zZCWhU6ESsUjg9Xh7PcRlNvV8XY+xNzGx'

# Generated at 2022-06-22 06:33:50.760509
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Set 1, Challenge 7
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    expanded_key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    assert intlist_to_bytes(aes_encrypt(data, expanded_key)) == b'\x57\xd1\x8e\xbc\xe9\x9f\x3a\x58\x30\x00\x00\x00\x00\x00\x00\x00'

    # Set 1, Challenge 2
    data = bytes_to

# Generated at 2022-06-22 06:34:00.590276
# Unit test for function aes_decrypt
def test_aes_decrypt():
    test_data = [[2, 0, 0, 0], [88, 44, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]
    assert aes_decrypt(test_data, [1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0]) == \
           [[2, 0, 0, 0], [88, 44, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]



# Generated at 2022-06-22 06:34:11.283126
# Unit test for function sub_bytes
def test_sub_bytes():
    input = [0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F]
    output = [0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76]
    assert(sub_bytes(input)==output)


# Generated at 2022-06-22 06:34:16.838109
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0xFF):
        for j in range(0xFF):
            assert rijndael_mul(i, j) == RIJNDAEL_EXP_TABLE[(RIJNDAEL_LOG_TABLE[i] + RIJNDAEL_LOG_TABLE[j]) % 0xFF]

# Generated at 2022-06-22 06:34:20.265649
# Unit test for function key_schedule_core
def test_key_schedule_core():
    ksc=key_schedule_core([0x2b, 0x28, 0xab, 0x09],[0x01])
    if(ksc ==[0x00, 0xa0, 0x48, 0x98]):
        return('True')
    else:
        return('False')
print(test_key_schedule_core())



# Generated at 2022-06-22 06:34:31.950880
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # 256-Byte key
    key = [0] * 32
    expanded_key = key_expansion(key)

    # Encrypt all-zero block
    block = [0] * BLOCK_SIZE_BYTES
    cipher = aes_encrypt(block, expanded_key)

    # Decrypt
    plain = aes_decrypt(cipher, expanded_key)

    # Make sure all-zero block was decrypted correctly
    assert plain == block

    # Test decryption of cipher from aes_encrypt
    test_cipher = bytes_to_intlist(compat_b64decode(
        'X9arKGtH0s28OZYZEAdiQQ=='))
    assert len(test_cipher) == BLOCK_SIZE_BYTES
    test_plain = aes_dec

# Generated at 2022-06-22 06:34:44.080766
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(compat_b64decode('pOaaSdS/nX8mvG/ZdzKZHw=='))
    key = [0x2b, 0x7e, 0x15, 0x16,
           0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88,
           0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-22 06:34:55.348772
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    block = [0xDB, 0x13, 0x53, 0x45,
             0xF2, 0x0A, 0x22, 0x5C,
             0x01, 0x01, 0x01, 0x01,
             0x01, 0x01, 0x01, 0x01]
    assert mix_columns_inv(block) == block
    assert mix_columns_inv(mix_columns(block)) == block

test_mix_columns_inv()


# Generated at 2022-06-22 06:35:04.321309
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert(shift_rows_inv([0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]) == [0x63, 0x53, 0xe0, 0x8c, 0x09, 0xd0, 0xba, 0x04, 0xcd, 0xe7, 0x70, 0x51, 0x60, 0xe1, 0xb7, 0xca])



# Generated at 2022-06-22 06:35:06.136673
# Unit test for function rotate
def test_rotate():
    data = [1, 2, 3, 4]
    assert rotate(data) == [2, 3, 4, 1]



# Generated at 2022-06-22 06:35:15.362266
# Unit test for function mix_columns
def test_mix_columns():
    test_data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    # result = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns(test_data)
    print(result)
    print([hex(x) for x in result])



# Generated at 2022-06-22 06:35:25.332268
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = [0x8e, 0x9f, 0x7d, 0xbc, 0xfb, 0xca, 0x94, 0x30, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert data_mixed == mix_columns_inv(data)



# Generated at 2022-06-22 06:35:37.502563
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aescbc import aes_cbc_decrypt
    from .utils import str_to_intlist, intlist_to_str

    plaintext = str_to_intlist("L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==")
    ciphertext = str_to_intlist("69dda8455c7dd4254bf353b773304eec0ec7702330098ce7f7520d1cbbb20fc388d1b0adb5054dbd7370849dbf0b88d393f252e764f1f5f7ad97ef79d59ce29f5f51eeca32eabedd9afa9329")

# Generated at 2022-06-22 06:35:46.149705
# Unit test for function mix_column
def test_mix_column():
    data = [0x01, 0x02, 0x03, 0x04]
    data_mixcol = mix_column(data, MIX_COLUMN_MATRIX)
    data_mixcol_inv = mix_column(data_mixcol, MIX_COLUMN_MATRIX_INV)
    print("Mix-Column test:")
    print("Input:")
    print(data)
    print("Expected output:")
    print(data)
    print("Output:")
    print(data_mixcol_inv)
    print("")

# Uncomment this function to test mix_column
#test_mix_column()



# Generated at 2022-06-22 06:35:57.729943
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    iv = bytes_to_intlist(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')

# Generated at 2022-06-22 06:36:00.218146
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    print("Test shift_rows_inv")
    data = [0 for x in range(16)]
    print("Original: ")
    print(data)

    data = shift_rows(data)
    print("\nAfter ShiftRows: ")
    print(data)

    data = shift_rows_inv(data)
    print("\nAfter ShiftRowsInverse: ")
    print(data)



# Generated at 2022-06-22 06:36:01.824733
# Unit test for function mix_column
def test_mix_column():
    state = [0xdb, 0x13, 0x53, 0x45]
    assert mix_column(state, MIX_COLUMN_MATRIX) == [0x8e, 0x4d, 0xa1, 0xbc]



# Generated at 2022-06-22 06:36:19.856478
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class TestCounter(object):
        def next_value(self):
            return [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]
    data = [241, 173, 159, 177, 125, 18, 77, 77, 44, 180, 23, 25, 14, 203,
            44, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    key = [45, 12, 57, 238, 241, 173, 159, 177, 125, 18, 77, 77, 44, 180, 23,
           25]
    output = aes_ctr_decrypt(data, key, TestCounter())

# Generated at 2022-06-22 06:36:22.406108
# Unit test for function shift_rows
def test_shift_rows():
    test_data = [0 for i in range(16)]
    for i in range(16):
        test_data[i] = i
    print("Test shift rows: ", shift_rows(test_data))



# Generated at 2022-06-22 06:36:27.848983
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    plain = [0xCC, 0x41, 0x81, 0x79]
    ct = [0xC9, 0xF2, 0x25, 0x8D]
    assert sub_bytes(sub_bytes_inv(ct)) == ct
    assert sub_bytes_inv(sub_bytes(plain)) == plain
    return True



# Generated at 2022-06-22 06:36:39.160631
# Unit test for function key_expansion
def test_key_expansion():
    kex = key_expansion([0x3b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c])
    assert(kex[0x00] == 0x3b)
    assert(kex[0x01] == 0x7e)
    assert(kex[0x02] == 0x15)
    assert(kex[0x03] == 0x16)
    assert(kex[0x04] == 0x28)
    assert(kex[0x05] == 0xae)
    assert(kex[0x06] == 0xd2)

# Generated at 2022-06-22 06:36:43.075736
# Unit test for function shift_rows
def test_shift_rows():
    assert shift_rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]) == [0,1,2,3,5,6,7,4,10,11,8,9,15,12,13,14]

# Generated at 2022-06-22 06:36:51.044841
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import re

    alphabet = ''
    for i in range(0x20, 0x7F):
        alphabet += chr(i)
    m = re.search('[^%s]' % re.escape(alphabet), aes_decrypt_text(r'zwiVhy+A1RxM7mH4tKjXg==', 'password', 32))
    if m:
        raise RuntimeError('test_aes_decrypt_text: ' + repr(m.group()))



# Generated at 2022-06-22 06:37:02.518326
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x5a, 0x01, 0x01, 0x01]) == [0x34, 0x02, 0x02, 0x02]
    assert sub_bytes([0x5a, 0x82, 0x02, 0x02]) == [0x34, 0x7b, 0x6b, 0x21]
    assert sub_bytes([0x5a, 0x02, 0x5a, 0x2f]) == [0x34, 0x36, 0x34, 0x0f]
    assert sub_bytes([0x5a, 0x02, 0x02, 0x02]) == [0x34, 0x36, 0x6c, 0x3f]


# Generated at 2022-06-22 06:37:11.061090
# Unit test for function shift_rows
def test_shift_rows():
    test_data = [0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16]
    result = shift_rows(test_data)
    expected = [0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16, 0x16]
    assert expected == result


# Generated at 2022-06-22 06:37:14.608911
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    for i in range(256):
        assert i == SBOX_INV[SBOX[i]]
        assert i == SBOX[SBOX_INV[i]]


# Generated at 2022-06-22 06:37:23.582752
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # test cases taken from http://www.inconteam.com/software-development/41-encryption/55-aes-test-vectors
    test_key = '603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4'
    test_data1 = '6bc1bee22e409f96e93d7e117393172a'
    test_data2 = 'ae2d8a571e03ac9c9eb76fac45af8e51'
    test_data3 = '30c81c46a35ce411e5fbc1191a0a52ef'
    test_data4 = 'f69f2445df4f9b17ad2b417be66c3710'

# Generated at 2022-06-22 06:37:50.172567
# Unit test for function key_schedule_core
def test_key_schedule_core():

    # Input
    input_data = [0x01, 0x02, 0x03, 0x04]
    rcon_iteration = 1
    expected_result = [0x01, 0x03, 0x05, 0x0f]
    result = key_schedule_core(input_data, rcon_iteration)
    #Output
    if not expected_result == result:
        raise Exception("Error: Expected Result: %s. Actual Result: %s. \nFor Input: %s" % (expected_result, result, input_data))
    else:
        print("Success! key_schedule_core: Result: %s. \nFor Input: %s" % (result, input_data))


# Generated at 2022-06-22 06:38:01.815189
# Unit test for function mix_columns
def test_mix_columns():
    for i in range(4):
        a = random.randint(0, 255)
        b = random.randint(0, 255)
        c = random.randint(0, 255)
        d = random.randint(0, 255)
        input = [a, b, c, d]
        output = mix_column(input, MIX_COLUMN_MATRIX)
        input_str = "a = {}, b = {}, c = {}, d = {}".format(
            hex(a), hex(b), hex(c), hex(d))
        output_str = "a = {}, b = {}, c = {}, d = {}".format(
            hex(output[0]), hex(output[1]), hex(output[2]), hex(output[3]))

# Generated at 2022-06-22 06:38:12.263067
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    plain_text_columns = [0xD4, 0xBF, 0x5D, 0x30,
                          0xE0, 0xB4, 0x52, 0xAE,
                          0xB8, 0x41, 0x11, 0xF1,
                          0x1E, 0x27, 0x98, 0xE5]
    cipher_text = [0x04, 0x66, 0x81, 0xE5,
                   0xE0, 0xCB, 0x19, 0x9A,
                   0x48, 0xF8, 0xD3, 0x7A,
                   0x28, 0x06, 0x26, 0x4C]
    cipher_text_mixed = mix_columns_inv(cipher_text)
    assert cipher

# Generated at 2022-06-22 06:38:15.245731
# Unit test for function aes_decrypt
def test_aes_decrypt():
    assert aes_decrypt(aes_encrypt([0]*16, [0]*176), [0]*176) == [0]*16



# Generated at 2022-06-22 06:38:26.879975
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]

# Generated at 2022-06-22 06:38:31.510027
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    data_shifted = shift_rows_inv(shift_rows(data))
    assert data == data_shifted



# Generated at 2022-06-22 06:38:41.893203
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-22 06:38:46.551555
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0xFF, 0xFF, 0xFF, 0xFF]
    rcon_iteration = 1
    expected = [0xC2, 0xBF, 0xC9, 0xA0]
    result = key_schedule_core(data, rcon_iteration)
    assert expected == result
    return

# Generated at 2022-06-22 06:38:54.499345
# Unit test for function inc
def test_inc():
    data = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    data_crypted = [0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    assert data_crypted == inc(data)



# Generated at 2022-06-22 06:38:56.299675
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x83) == 0xc1

