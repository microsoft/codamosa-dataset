

# Generated at 2022-06-22 06:29:29.134838
# Unit test for function shift_rows
def test_shift_rows():
    data = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
    data_shifted = [0,5,10,15,4,9,14,3,8,13,2,7,12,1,6,11]
    assert shift_rows(data) == data_shifted
    return 'Passed'

# Generated at 2022-06-22 06:29:39.737027
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .counter import Counter

# Generated at 2022-06-22 06:29:51.433483
# Unit test for function inc
def test_inc():
    test = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    assert inc(test) == [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1]
    test = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1]
    assert inc(test) == [0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0]
    test = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0]
    assert inc(test)

# Generated at 2022-06-22 06:30:03.603423
# Unit test for function key_expansion
def test_key_expansion():
    # ==== Test vector ====
    key = bytes_to_intlist(b"000102030405060708090a0b0c0d0e0f")

# Generated at 2022-06-22 06:30:08.351100
# Unit test for function sub_bytes
def test_sub_bytes():
    byte = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    expected = [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]
    assert sub_bytes(byte) == expected


# Generated at 2022-06-22 06:30:12.856659
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert(key_schedule_core([0x39, 0x02, 0xdc, 0x19], 0x01) == [0x62, 0x2d, 0xdc, 0x24])



# Generated at 2022-06-22 06:30:17.440398
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = bytearray(16)
    data[0] = 0xFF
    data[1] = 0x11
    data[2] = 0x22
    data[3] = 0x33
    data[4] = 0x44
    data[5] = 0x55
    data[6] = 0x66
    data[7] = 0x77
    data[8] = 0x88
    data[9] = 0x99
    data[10] = 0xAA
    data[11] = 0xBB
    data[12] = 0xCC
    data[13] = 0xDD
    data[14] = 0xEE
    data[15] = 0xFF
    data = shift_rows_inv(data)
    print(data)

# Generated at 2022-06-22 06:30:22.125587
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key = [0x2b, 0x7e, 0x15, 0x16]
    key_exp = [0x8e, 0x73, 0xb0, 0xf7]
    assert key_schedule_core(key, 1) == key_exp



# Generated at 2022-06-22 06:30:26.333931
# Unit test for function rotate
def test_rotate():
    tmp = [0x00, 0x01, 0x02, 0x00]
    assert rotate([0x00, 0x01, 0x02, 0x03]) == tmp
    assert rotate(rotate(rotate(tmp))) == tmp
    assert rotate([0x55, 0x55, 0x55, 0x55]) == [0x55, 0x55, 0x55, 0x55]



# Generated at 2022-06-22 06:30:29.558636
# Unit test for function xor
def test_xor():
    assert xor([0x2d,0x43,0x90,0x9b],[0x73,0x53,0x90,0x9b]) == [0x5e,0x10,0x00,0x00]
test_xor()


# Generated at 2022-06-22 06:30:45.671843
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text(
        "DMC1zIjXb2ZmR0s0dmF4Vjd3TkxicTdwSmpDcS1FOC9ZWXNlOENUZDlHdURaUyJ9",
        "03a976511e2cbe3a7f26808fb7af3c05",
        24) == b'{"iv":"hGgaE66Pkz9qWqpP","cipher":"AES-128-CBC","s":"QtVnRydjdBB7rJkO","k":"b0KY7fqp0LIIq3hL"}'
# {{{ Counter

# Generated at 2022-06-22 06:30:53.062221
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    output = shift_rows_inv([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])
    print(output)
    if(output == [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]):
        print("shift_rows_inv test passed")
    else:
        print("shift_rows_inv test failed")


# Generated at 2022-06-22 06:31:05.153085
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]) == [0, 0, 0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    assert inc([0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]) == [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

# Generated at 2022-06-22 06:31:12.019224
# Unit test for function mix_columns
def test_mix_columns():
    with open("mix_columns.txt") as f:
        for line in f:
            data = [int(i, 16) for i in line.split(" ")[:-1]]
            expected = [int(i, 16) for i in line.split(" ")[-1].split("\n")[0].split("|")[1:]]
            assert(mix_columns(data) == expected)
test_mix_columns()



# Generated at 2022-06-22 06:31:16.768442
# Unit test for function mix_columns
def test_mix_columns():
    DATA = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    print("DATA:\t\t", DATA)
    DATA_MIXED = mix_columns(DATA)
    print("DATA_MIXED:\t", DATA_MIXED)
    print("EXPECTED:\t", [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01])
test_mix_

# Generated at 2022-06-22 06:31:20.468712
# Unit test for function xor
def test_xor():
    assert xor([1, 2, 3, 4], [1, 2, 3, 4]) == [0, 0, 0, 0]
    assert xor([1, 2, 3, 4], [1, 2, 4, 4]) == [0, 0, 7, 0]

# Generated at 2022-06-22 06:31:31.849736
# Unit test for function aes_encrypt
def test_aes_encrypt():
    print('Testing function aes_encrypt')
    from .utils import bytes_to_intlist, intlist_to_bytes

    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    ciphertext = bytes_to_intlist(b'\xc6\xa1\x3b\x37\x87\x8f\x5b\x82\x6f\x4f\x81\x62\xa1\xc8\xd8\x79')
    expanded_key = key_expansion(key)

# Generated at 2022-06-22 06:31:41.292184
# Unit test for function key_schedule_core
def test_key_schedule_core():
	test_key = [0x4c, 0x1f, 0xef, 0x63]
	assert key_schedule_core(test_key, 0x01) == [0x47, 0x1f, 0xef, 0x63]
	assert key_schedule_core(test_key, 0x02) == [0x7f, 0x13, 0xef, 0x63]
	assert key_schedule_core(key_schedule_core(test_key, 0x01), 0x01) == [0x7f, 0x13, 0xef, 0x63]


# Generated at 2022-06-22 06:31:51.076513
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns(data)
    expected = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    if data_mixed != expected:
        print("mix_columns is not correct")



# Generated at 2022-06-22 06:32:01.150803
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    key = 'e12lJvT8BcWQO1xgTlXsBJU6HbU6w='
    plaintext = 'hello\nworld\n'

    class Counter(object):
        __value = [0] * BLOCK_SIZE_BYTES

        def next_value(self):
            temp = self.__value
            self.__value = inc(self.__value)
            return temp

    key = bytes_to_intlist(compat_b64decode(key))
    key = key[:len(key[:32])] + [0] * (32 - len(key[:32]))
    key = aes_encrypt(key[:BLOCK_SIZE_BYTES], key_expansion(key)) * 2
    print('key - ',  key)


# Generated at 2022-06-22 06:32:20.909247
# Unit test for function key_expansion

# Generated at 2022-06-22 06:32:29.006415
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class TestCounter(object):
        def __init__(self, value):
            self.value = value
        def next_value(self):
            self.value += 1
            return self.value
    data_b64 = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    data = bytes_to_intlist(compat_b64decode(data_b64))

# Generated at 2022-06-22 06:32:37.357580
# Unit test for function key_expansion

# Generated at 2022-06-22 06:32:39.176594
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert shift_rows_inv(shift_rows(SBOX_INV)) == SBOX_INV



# Generated at 2022-06-22 06:32:45.884524
# Unit test for function mix_column
def test_mix_column():
    assert mix_column([0xA1, 0x1A, 0xAA, 0x11], MIX_COLUMN_MATRIX) == [0x37, 0xD7, 0xB6, 0xCE]
    assert mix_column([0x37, 0xD7, 0xB6, 0xCE], MIX_COLUMN_MATRIX_INV) == [0xA1, 0x1A, 0xAA, 0x11]



# Generated at 2022-06-22 06:32:47.181223
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x29, 0x2A, 0x2B, 0x2C]
    data = sub_bytes(data)
    print("SubBytes Result: %s" % data)


# Generated at 2022-06-22 06:32:54.091046
# Unit test for function mix_column
def test_mix_column():
    result = mix_column([2, 3, 0, 1], MIX_COLUMN_MATRIX)
    assert(result == [1, 2, 1, 1])
    result = mix_column([2, 3, 0x1a, 1], MIX_COLUMN_MATRIX_INV)
    assert(result == [0x1a, 0x1a, 0x1a, 0x1a])


# Generated at 2022-06-22 06:32:59.171250
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0xFF):
        for j in range(0xFF):
            if(rijndael_mul(i, j) != (i * j) % 0x100):
                print('Test failed for rijndael_mul')
    print('Test passed for rjindael_mul')


# Generated at 2022-06-22 06:33:06.065198
# Unit test for function aes_decrypt_text

# Generated at 2022-06-22 06:33:16.879763
# Unit test for function key_expansion
def test_key_expansion():
    test_key = "2b7e151628aed2a6abf7158809cf4f3c"
    test_key = bytes_to_intlist(compat_b64decode(test_key))
    test_key_expansion = "2b7e151628aed2a6abf7158809cf4f3c9b2102f59098eadac909d0d2263f80a76a8bb77b5b502067fcde05cefcdc608f5174f62222c6b7a7baa2d"
    test_key_expansion = bytes_to_intlist(compat_b64decode(test_key_expansion))
    assert key_expansion(test_key) == test_key_expansion


# Generated at 2022-06-22 06:33:50.621299
# Unit test for function inc
def test_inc():
    assert inc([0]*4) == [1]*4
    assert inc([0]*4 + [1]) == [1]*4 + [2]
    assert inc([0]*4 + [2]) == [1]*4 + [3]
    assert inc([0]*4 + [3]) == [1]*4 + [4]
    assert inc([0]*4 + [4]) == [1]*4 + [5]
    assert inc([0]*4 + [5]) == [1]*4 + [6]
    assert inc([0]*4 + [6]) == [1]*4 + [7]
    assert inc([0]*4 + [7]) == [1]*4 + [8]
    assert inc([0]*4 + [8]) == [1]*4 + [9]

# Generated at 2022-06-22 06:34:02.981881
# Unit test for function sub_bytes_inv

# Generated at 2022-06-22 06:34:06.638280
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    state = [0xFF, 0x00, 0x00, 0x00,
             0xFF, 0x00, 0x00, 0x00,
             0xFF, 0x00, 0x00, 0x00,
             0xFF, 0x00, 0x00, 0x00]
    state_moved = shift_rows(state)
    state_moved = shift_rows_inv(state_moved)
    assert state == state_moved


# Generated at 2022-06-22 06:34:10.083070
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert(rijndael_mul(0x57, 0x83) == 0xC1)
    assert(rijndael_mul(0x83, 0x13) == 0x01)



# Generated at 2022-06-22 06:34:15.874282
# Unit test for function mix_columns
def test_mix_columns():
    for i in range(1000):
        data = np.random.randint(0, 256, 16)
        data_mixed = mix_columns(data)
        assert(repr(np.array(mix_columns_slow(data))) == repr(np.array(data_mixed)))
test_mix_columns()

# Generated at 2022-06-22 06:34:18.403394
# Unit test for function sub_bytes
def test_sub_bytes():
    data_1 = [0x6a, 0xfb, 0x34, 0x87]
    assert sub_bytes(data_1) == [0xcd, 0x16, 0x83, 0x40]
    data_2 = [0x39, 0x25, 0x84, 0x1d]
    assert sub_bytes(data_2) == [0x9d, 0x3b, 0x7d, 0xd5]



# Generated at 2022-06-22 06:34:23.409279
# Unit test for function xor
def test_xor():
    assert(xor([0xFF, 0xFF, 0xFF, 0xFF], [0x00, 0x00, 0x00, 0x00]) == [0xFF, 0xFF, 0xFF, 0xFF])
    assert(xor([0x00, 0x00, 0x00, 0x00], [0xFF, 0xFF, 0xFF, 0xFF]) == [0xFF, 0xFF, 0xFF, 0xFF])
    assert(xor([0xFF, 0xFF, 0xFF, 0xFF], [0xFF, 0xFF, 0xFF, 0xFF]) == [0x00, 0x00, 0x00, 0x00])

# Generated at 2022-06-22 06:34:33.399227
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    test_cipher = [5, 238, 252, 35, 150, 106, 28, 44,
                   243, 25, 128, 216, 151, 100, 159, 109]
    test_key = [43, 126, 21, 22, 40, 174, 210, 166, 171, 247, 21, 136, 9, 207, 79, 60]
    test_counter = Counter(intlist_to_bytes([0, 0, 0, 0, 0, 0, 0, 0]))
    assert aes_ctr_decrypt(test_cipher, test_key, test_counter) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

# Generated at 2022-06-22 06:34:45.108355
# Unit test for function aes_decrypt
def test_aes_decrypt():
    print('Testing aes_decrypt()')
    def test_aes_decrypt_instance(key, data, expected):
        expanded_key = key_expansion(key)
        actual = aes_decrypt(data, expanded_key)
        actual_text = intlist_to_bytes(actual)
        expected_text = intlist_to_bytes(expected)
        if actual == expected:
            print('OK')
        else:
            print('Failed')
            print('Key is:', key, '\nData is:', data, '\nExpected is:', expected, '\nActual is:', actual)


# Generated at 2022-06-22 06:34:48.192501
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0xab, 0xab, 0xab, 0xab]
    result = mix_columns_inv(data)
    for x in result:
        assert x == 0x00


if __name__ == '__main__':
    test_mix_columns_inv()