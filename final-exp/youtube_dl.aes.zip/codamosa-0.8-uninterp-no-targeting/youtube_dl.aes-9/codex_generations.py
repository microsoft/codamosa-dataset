

# Generated at 2022-06-22 06:29:28.170195
# Unit test for function mix_columns
def test_mix_columns():
    m = [[0x01, 0x01, 0x01, 0x01],
         [0x02, 0x02, 0x02, 0x02],
         [0x03, 0x03, 0x03, 0x03],
         [0x04, 0x04, 0x04, 0x04]]
    result = [0x04, 0x04, 0x04, 0x04, 0x08, 0x08, 0x08, 0x08, 0x0C, 0x0C, 0x0C, 0x0C, 0x10, 0x10, 0x10, 0x10]
    assert mix_columns(m) == result


test_mix_columns()



# Generated at 2022-06-22 06:29:32.146856
# Unit test for function sub_bytes
def test_sub_bytes():
    assert (sub_bytes([0x19, 0xa0, 0x9a, 0xe9]) == [0xd4, 0xe0, 0xb8, 0x1e])



# Generated at 2022-06-22 06:29:42.199929
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [176,227,21,169,78,150,165,57,196,187,61,29,122,245,116,139]

# Generated at 2022-06-22 06:29:51.302851
# Unit test for function aes_encrypt
def test_aes_encrypt():
    clear_text = bytes_to_intlist('00112233445566778899aabbccddeeff')
    encrypted_text = bytes_to_intlist('69c4e0d86a7b0430d8cdb78070b4c55a')
    expanded_key = bytes_to_intlist('000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f')
    test = aes_encrypt(clear_text, expanded_key) == encrypted_text
    print('Unit test for function aes_encrypt passed: %s' % test)
    return test
if __name__ == '__main__':
    test_aes_encrypt()  # Unit test for function aes_encrypt


# Generated at 2022-06-22 06:30:03.485217
# Unit test for function key_expansion
def test_key_expansion():
    data = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15,
            0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-22 06:30:11.067520
# Unit test for function rotate
def test_rotate():
    print("Test for rotate")
    print("Test for rotate 1")
    # Test case 1:
    data = [12, 23, 34, 45]
    data_after_rotate = [23, 34, 45, 12]
    data_rotated = rotate(data)
    if data_rotated == data_after_rotate:
        print("Test case 1 has passed!")
    else:
        print("Test case 1 has failed!")

    print("Test for rotate 2")
    # Test case 2:
    data = [12, 23, 34, 45, 56]
    data_after_rotate = [23, 34, 45, 56, 12]
    data_rotated = rotate(data)
    if data_rotated == data_after_rotate:
        print("Test case 2 has passed!")

# Generated at 2022-06-22 06:30:13.797410
# Unit test for function inc
def test_inc():
    data = [255, 255, 255, 255]
    assert inc(data) == [0, 0, 0, 0]

    data = [0, 0, 0, 0]
    assert inc(data) == [0, 0, 0, 1]

    data = [0, 0, 0, 255]
    assert inc(data) == [0, 0, 1, 0]



# Generated at 2022-06-22 06:30:22.848263
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02]) == [0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04, 0x04]



# Generated at 2022-06-22 06:30:34.493009
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-22 06:30:37.937625
# Unit test for function rotate
def test_rotate():
    assert rotate([0x00, 0x01, 0x02, 0x03]) == [0x01, 0x02, 0x03, 0x00]
    assert rotate([0x04, 0x05, 0x06, 0x07]) == [0x05, 0x06, 0x07, 0x04]


# Generated at 2022-06-22 06:30:58.248524
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    p = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]

# Generated at 2022-06-22 06:31:07.309657
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    print("Test mix_columns_inv()")
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]

    data_mixed = mix_columns_inv(data)
    data_mixed = [hex(x) for x in data_mixed]
    print("Data mixed: ", data_mixed)

# Generated at 2022-06-22 06:31:18.855827
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    import unittest
    import binascii
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-22 06:31:30.122566
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('mvR/WbT8KmZiX10idLz64tO8hV737ySl'))
    iv = bytes_to_intlist(compat_b64decode('iC1v4zq3yKP+2sUmD0RUlg=='))
    crypted = bytes_to_intlist(compat_b64decode('yC6Hnjjm+ptfqm3e6BEkmQ=='))
    data = bytes_to_intlist('username=123456')
    assert aes_cbc_encrypt(data, key, iv) == crypted


# Generated at 2022-06-22 06:31:34.203502
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x01, 0x02, 0x03, 0x04,
            0x05, 0x06, 0x07, 0x08,
            0x09, 0x0a, 0x0b, 0x0c,
            0x0d, 0x0e, 0x0f, 0x10]
    data = shift_rows(data)
    data = shift_rows_inv(data)
    assert(data == [0x01, 0x02, 0x03, 0x04,
                    0x05, 0x06, 0x07, 0x08,
                    0x09, 0x0a, 0x0b, 0x0c,
                    0x0d, 0x0e, 0x0f, 0x10])

test_shift_rows_inv()


# Generated at 2022-06-22 06:31:44.133542
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    assert aes_cbc_encrypt(
        bytes_to_intlist(b'abcdefghijklmnopqrstuvwxyz'),
        bytes_to_intlist(b'12345123451234512'),
        bytes_to_intlist(b'abcdefghijklmnop')
    ) == bytes_to_intlist(compat_b64decode(b'e4n4+bevfZG5HZQz7G6hWg=='))


# Generated at 2022-06-22 06:31:47.479827
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    plaintext = [0]*16
    data = []
    for column in range(4):
        for row in range(4):
            plaintext[(column + row) & 0b11] = row
            data.append(plaintext[row])
    data_shifted = shift_rows_inv(data)
    for i in range(16):
        #print(data_shifted[i])
        if(data_shifted[i] != i):
            print("FAILED")
            return
    print("PASSED")

# test_shift_rows_inv()



# Generated at 2022-06-22 06:31:55.933486
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    encrypted = 'Ag3laUg5|5X5l5e5a5c5e5h5a5n5w5d5l5o5a5a5f5o5n5e5h5n5k5a5m5V5w5n5n5j5'
    expected = 'The super secret message'
    password = 'test123'
    key_size_bytes = 16
    decrypted = aes_decrypt_text(encrypted, password, key_size_bytes)
    assert decrypted == expected



# Generated at 2022-06-22 06:32:04.086298
# Unit test for function mix_column
def test_mix_column():
    error_occur = False
    data = [0xdb, 0x13, 0x53, 0x45]
    mixed = mix_column(data, MIX_COLUMN_MATRIX)
    mixed_correct = [0x8e, 0x4d, 0xa1, 0xbc]
    print("mix_column input: ", data)
    print("mix_column output:", mixed)
    print("mix_column correct:", mixed_correct)
    try:
        assert(mixed == mixed_correct)
    except:
        error_occur = True
    finally:
        if error_occur:
            print("mix_column error")
        else:
            print("mix_column pass")



# Generated at 2022-06-22 06:32:07.682888
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([0,1,2,3])) == [0,1,2,3]
    assert sub_bytes_inv(sub_bytes(range(16))) == range(16)

# Generated at 2022-06-22 06:32:25.090945
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]
    expanded_key = key_expansion(key)
    iv = [0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0]

# Generated at 2022-06-22 06:32:35.815151
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]  # key
    iv = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]  # iv
    cipher = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]  # cipher
    
    cipher_in_byte = bytes(cipher)
    iv_in_byte = bytes(iv)
    key_in_byte = bytes(key)
    
    cipher_in_str = str(cipher_in_byte)
    iv_in_str = str(iv_in_byte)
    key_in_

# Generated at 2022-06-22 06:32:46.555282
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10]
    expected_data = [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]
    assert sub_bytes(data) == expected_data
    print("Test PASS")

# test_sub_bytes()


# Generated at 2022-06-22 06:32:52.298933
# Unit test for function mix_column
def test_mix_column():
    state = [0xdb, 0x13, 0x53, 0x45]
    printt(mix_column(state, MIX_COLUMN_MATRIX))

    state = [0x93, 0x53, 0x7a, 0xde]
    printt(mix_column(state, MIX_COLUMN_MATRIX_INV))



# Generated at 2022-06-22 06:32:54.389836
# Unit test for function inc
def test_inc():
    assert inc(bytes.fromhex("00 00 00 00")) == bytes.fromhex("00 00 00 01")
    assert inc(bytes.fromhex("00 00 00 FF")) == bytes.fromhex("00 00 01 00")



# Generated at 2022-06-22 06:33:03.959474
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key0 = [0x2B, 0x7E, 0x15, 0x16]
    key1 = [0xA8, 0x9F, 0xC5, 0x3A]
    key1_ = key_schedule_core(key0, 1)
    assert key1 == key1_

    key2 = [0xFB, 0xD2, 0x19, 0x2F]
    key2_ = key_schedule_core(key1, 2)
    assert key2 == key2_
    
    key3 = [0xAC, 0x66, 0x82, 0x27]
    key3_ = key_schedule_core(key2, 3)
    assert key3 == key3_


# Generated at 2022-06-22 06:33:09.874393
# Unit test for function key_schedule_core
def test_key_schedule_core():
    # Known plaintext: 0x8000000000000000
    rcon_iteration = 1
    data = [0x0, 0x0, 0x0, 0x0]
    data = key_schedule_core(data, rcon_iteration)

    assert data[0] == 0x01
    assert data[1] == 0x00
    assert data[2] == 0x00
    assert data[3] == 0x00


# Generated at 2022-06-22 06:33:14.933731
# Unit test for function mix_column
def test_mix_column():
    data = [0x01, 0x02, 0x03, 0x04]
    data2 = [0x05, 0x06, 0x07, 0x08]
    print("Data 1: ", end="")
    print(data)
    print("Data 2: ", end="")
    print(data2)
    print("Data mix ", end="")
    data = mix_column(data, MIX_COLUMN_MATRIX)
    print(data)
    print("Data 2 mix ", end="")
    data2 = mix_column(data2, MIX_COLUMN_MATRIX)
    print(data2)



# Generated at 2022-06-22 06:33:26.700804
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    assert aes_cbc_encrypt([], key, iv) == []


# Generated at 2022-06-22 06:33:33.796763
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    test_data = (0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c)
    test_data_shifted = shift_rows_inv(test_data)
    assert(test_data_shifted == (0x63, 0x53, 0xe0, 0x8c, 0x09, 0xd0, 0xba, 0x04, 0xcd, 0xe7, 0x70, 0x51, 0xca, 0x60, 0xba, 0x04))
    print("shift_rows_inv passed")


test_shift_rows_inv()


# Generated at 2022-06-22 06:33:51.842946
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter

    data = bytes_to_intlist(compat_b64decode('QVdTIGNhbiBiZSBmdWxsIG9mIGVycm9ycywgYnV0IGRvIGl0IHdvcmsgYXQgbGVhc3Q='))
    key = bytes_to_intlist('YELLOW SUBMARINE')
    counter = AESCounter(bytes_to_intlist('\x00' * BLOCK_SIZE_BYTES))

    decrypted_data = aes_ctr_decrypt(data, key, counter)
    decrypted_data = intlist_to_bytes(decrypted_data)

    answer = b'AES can be full of errors, but do it work at least'
    assert decrypted_data == answer
# A

# Generated at 2022-06-22 06:34:03.769432
# Unit test for function aes_decrypt
def test_aes_decrypt():
    KEY = (0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c)

# Generated at 2022-06-22 06:34:05.009061
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Input data: cleartext
    data = compa

# Generated at 2022-06-22 06:34:15.653148
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(compat_b64decode('ecu5pDT4O7wvKZ6AB/U6hjUW+X8/vnUQNn7KjN/x/D8='))

# Generated at 2022-06-22 06:34:18.691629
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = bytes.fromhex("db135345fec03941")
    data_mixed = mix_columns_inv(data)
    assert data_mixed == bytes.fromhex("74dff9a7929c6f49")



# Generated at 2022-06-22 06:34:26.839853
# Unit test for function aes_decrypt

# Generated at 2022-06-22 06:34:38.599161
# Unit test for function sub_bytes_inv

# Generated at 2022-06-22 06:34:49.100751
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns(data, MIX_COLUMN_MATRIX)
    print(hex(result[0]), hex(result[1]), hex(result[2]), hex(result[3]))
    print(hex(result[4]), hex(result[5]), hex(result[6]), hex(result[7]))
    print(hex(result[8]), hex(result[9]), hex(result[10]), hex(result[11]))

# Generated at 2022-06-22 06:34:58.880898
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert mix_columns(data) == data_mixed



# Generated at 2022-06-22 06:35:07.651856
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]
    assert shift_rows_inv(data) == [0x63, 0x53, 0xe0, 0x8c, 0x09, 0xd0, 0xba, 0x70, 0xcd, 0x60, 0xca, 0x04, 0xba, 0x70, 0xe7, 0x51]


test_shift_rows_inv()



# Generated at 2022-06-22 06:35:24.340744
# Unit test for function inc
def test_inc():
    assert (inc([0, 0, 0, 0]) == [1, 0, 0, 0])
    assert (inc([0, 0, 0, 1]) == [0, 0, 1, 0])
    assert (inc([0, 0, 0, 255]) == [0, 0, 1, 0])
    assert (inc([0, 0, 255, 255]) == [0, 1, 0, 0])
    assert (inc([0, 255, 255, 255]) == [1, 0, 0, 0])
    assert (inc([255, 255, 255, 255]) == [0, 0, 0, 0])
# Test for function inc
test_inc()

# KEY EXPANSION

# Generated at 2022-06-22 06:35:31.775796
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    """
    Test aes_cbc_encrypt function
    """
    cleartext = b'YELLOW SUBMARINE'
    key = bytes_to_intlist(compat_b64decode('W7iHk1NPw5h0rZvb8WUVzQ=='))
    iv = [0] * 16

    encrypted_data = aes_cbc_encrypt(bytes_to_intlist(cleartext), key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('9HZbiVFU/EjKxtnV/HbwwQ==')


# Generated at 2022-06-22 06:35:43.581405
# Unit test for function aes_decrypt
def test_aes_decrypt():
    input_str = "b0dbae45b4f3e6f4ab6e873c7e2e0b2c7f1d4204d00462c2f2a168f7d73fb12b"

# Generated at 2022-06-22 06:35:53.262761
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected = [0x53, 0xF1, 0xD8, 0x20, 0x30, 0x56, 0xA2, 0x54, 0x02, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns_inv(data)
    print("Result:", end=" ")
    for x in data:
        print("{:02x}".format(x), end=" ")
    print()

# Generated at 2022-06-22 06:36:04.061785
# Unit test for function xor
def test_xor():
    assert xor([0x30, 0x30, 0x30, 0x30], [0x10, 0x10, 0x10, 0x10]) == [0x20, 0x20, 0x20, 0x20]
    assert xor([0x11, 0x11, 0x11, 0x11], [0x11, 0x11, 0x11, 0x11]) == [0x00, 0x00, 0x00, 0x00]
    assert xor([0x11, 0x22, 0x33, 0x44], [0x44, 0x33, 0x22, 0x11]) == [0x55, 0x11, 0x11, 0x55]



# Generated at 2022-06-22 06:36:11.731707
# Unit test for function rijndael_mul
def test_rijndael_mul():
    input = ((0x57, 0x83),
             (0x83, 0x57))
    output = ((0xfe, 0x24),
              (0x24, 0xfe))
    for i in range(len(input)):
        for j in range(len(input[i])):
            if rijndael_mul(input[i][j], input[j][i]) != output[i][j]:
                print("Assertion error in rijndael_mul, for ", bin(input[i][j]), bin(input[j][i]))
    print("Unit test for rijndael_mul PASSED")



# Generated at 2022-06-22 06:36:14.135479
# Unit test for function shift_rows
def test_shift_rows():
    data_shifted = shift_rows([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16])
    assert data_shifted == [1,2,3,4,6,7,8,5,10,11,12,9,14,15,16,13], "Incorrect result."
    return True



# Generated at 2022-06-22 06:36:23.874254
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Execute function
    data_raw = "this is a test".encode('utf-8')
    data = bytes_to_intlist(data_raw)
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    result = aes_cbc_encrypt

# Generated at 2022-06-22 06:36:34.536352
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist([0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xA, 0xB, 0xC, 0xD, 0xE, 0xF])

# Generated at 2022-06-22 06:36:44.291882
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text('VjFaV1pHUTJZejB4TkRBMlpXSXROV1ZuYTFZeQ==', '1234', 16) == b'Text 1'
    assert aes_decrypt_text('VjFaV1pHUTJZejB4TkRBVjBUMD0=', '1234', 16) == b'Text 2'
    assert aes_decrypt_text('VjFaV1pHUTJZejB4TkRBMWJYQmxaVzVqYjIwdQ==', '1234', 16) == b'Text 3'


# Generated at 2022-06-22 06:36:56.790845
# Unit test for function shift_rows
def test_shift_rows():
    data = list(range(0, 16))
    data_shifted = shift_rows(data)
    assert data_shifted == [0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11]



# Generated at 2022-06-22 06:37:05.651929
# Unit test for function shift_rows
def test_shift_rows():
    test_vectors = [
        [[0x4, 0xC, 0x4, 0x4], [0x4, 0x4, 0xC, 0x4]],
        [[0x4, 0x4, 0x4, 0x4], [0x4, 0x4, 0x4, 0x4]],
        [[0x7, 0xF, 0x9, 0x1], [0x7, 0x1, 0xF, 0x9]],
        [[0xD, 0x5, 0x0, 0x6], [0xD, 0x0, 0x5, 0x6]],
        [[0x9, 0x1, 0x2, 0x3], [0x9, 0x3, 0x1, 0x2]],
    ]

# Generated at 2022-06-22 06:37:07.259234
# Unit test for function rotate
def test_rotate():
    assert(rotate([1, 2, 3]) == [2, 3, 1])
    print("rotate: Pass")



# Generated at 2022-06-22 06:37:16.370806
# Unit test for function shift_rows
def test_shift_rows():
    data = [0, 1, 2, 3,
            2, 3, 4, 5,
            4, 5, 6, 7,
            6, 7, 8, 9]
    expected = [0, 1, 2, 3,
                4, 5, 6, 7,
                8, 9, 10, 11,
                12, 13, 14, 15]
    print("data after shifting rows:")
    print(shift_rows(data))
    print("expected:")
    print(expected)



# Generated at 2022-06-22 06:37:27.789332
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-22 06:37:35.096800
# Unit test for function mix_columns
def test_mix_columns():
    for i in range(256):
        for j in range(256):
            for k in range(256):
                for l in range(256):
                    data = [i, j, k, l]
                    data_mixed = mix_columns(data)
                    data_mixed_inv = mix_columns(data_mixed, matrix=MIX_COLUMN_MATRIX_INV)
                    if data != data_mixed_inv:
                        print('Error:', i, j, k, l, data_mixed_inv, '!=', data)



# Generated at 2022-06-22 06:37:38.124606
# Unit test for function inc
def test_inc():
    data = [0] * 16
    assert inc(data) == [0] * 15 + [1]
    data = [0] + [255] * 15
    assert inc(data) == [1] * 16
    data = [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    assert inc(data) == [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]


# Generated at 2022-06-22 06:37:48.713519
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    test_key = bytes_to_intlist(b"\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f")
    test_plaintext = b"Bacon ipsum dolor amet filet mignon porchetta\nribeye tail bacon. Pork loin short loin boudin\ncorned beef leberk"
    test_password = "dummy_password"
    test_nonce = [0] * 8


# Generated at 2022-06-22 06:37:59.807598
# Unit test for function aes_decrypt
def test_aes_decrypt():
    sample_data = "5468697320697320616e204956343536"
    sample_data_decoded = bytes_to_intlist(compat_b64decode(sample_data))
    sample_key = "5468697320697320616e204956343536"
    sample_key_decoded = bytes_to_intlist(compat_b64decode(sample_key))
    sample_expanded_key = key_expansion(sample_key_decoded)
    output = aes_decrypt(sample_data_decoded, sample_expanded_key)
    expected_output = "2b7e151628aed2a6abf7158809cf4f3c"

# Generated at 2022-06-22 06:38:11.307137
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Unit test for function aes_decrypt_text
    """
    #
    # Example 1:
    # AES-128-CTR (NIST SP 800-38A)
    #
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    nonce = [0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7]
    plaintext = '6bc1bee22e409f96e93d7e117393172a'

# Generated at 2022-06-22 06:38:20.690978
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = bytes_to_intlist(bytearray(16))
    data = bytes_to_intlist(bytearray(16))
    counter = DummyCounter()
    encrypted_data = aes_ctr_decrypt(data, key, counter)
    assert encrypted_data == data


# Generated at 2022-06-22 06:38:32.249244
# Unit test for function xor
def test_xor():
	assert xor([0xff, 0xaa], [0x99, 0xbb]) == [0x66, 0x11]
	assert len(xor([0x7, 0x6, 0x7, 0x6, 0x7, 0x6, 0x7, 0x6], [0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5])) == 8
	# data1 and data2 has different length
	assert len(xor([0x7, 0x6, 0x7, 0x6, 0x7, 0x6, 0x7], [0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5, 0x5])) == 8
	# data1 or data2 is

# Generated at 2022-06-22 06:38:42.880037
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    state = [0x19,0xa0,0x9a,0xe9,0x3d,0xf4,0xc6,0xf8,0xe3,0xe2,0x8d,0x48,0xbe,0x2b,0x2a,0x08]
    result = [0x52,0x09,0x6a,0xd5,0x30,0x36,0xa5,0x38,0xbf,0x40,0xa3,0x9e,0x81,0xf3,0xd7,0xfb]
    if sub_bytes_inv(state) == result:
        print ("sub_bytes_inv() is correct")
    else:
        print ("sub_bytes_inv() is incorrect")



# Generated at 2022-06-22 06:38:51.537965
# Unit test for function shift_rows
def test_shift_rows():
    data = [0 for i in range(16)]
    data[0] = 0b00000001
    data[5] = 0b00000100
    data[10] = 0b00001000
    data[15] = 0b10000000
    data_shifted = shift_rows(data)
    assert data_shifted[0] == 0b00000001
    assert data_shifted[1] == 0b00000100
    assert data_shifted[2] == 0b00001000
    assert data_shifted[3] == 0b10000000
    assert data_shifted[4] == 0b00000001
    assert data_shifted[9] == 0b00000100
    assert data_shifted[14] == 0b00001000
    assert data_shifted[15] == 0b10000000

# Generated at 2022-06-22 06:38:54.853696
# Unit test for function rotate
def test_rotate():
    a = [1,2,3]
    rotate(a)
    assert a == [2,3,1]
    rotate(a)
    assert a == [3,1,2]
    rotate(a)
    assert a == [1,2,3]


# Generated at 2022-06-22 06:38:56.629070
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    for key, value in SBOX_INV.items():
        assert SBOX[value] == key

# Generated at 2022-06-22 06:39:03.350545
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns_inv(data)
    assert data_mixed == [0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55,0x55]

