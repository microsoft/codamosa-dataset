

# Generated at 2022-06-22 06:29:36.428662
# Unit test for function xor
def test_xor():
    test_data1 = [0x0, 0x1, 0x2, 0x3]
    test_data2 = [0x4, 0x5, 0x6, 0x7]
    expected_result = [0x4, 0x4, 0x6, 0x4]
    assert xor(test_data1, test_data2) == expected_result



# Generated at 2022-06-22 06:29:41.861332
# Unit test for function sub_bytes
def test_sub_bytes():
    """
    Sbox
    """
    data = [0 for i in range(4)]
    print("Sbox test:")
    for i in range(4):
        for j in range(4):
            data[j] = i + (j * 4)
            print("%02x" % data[j], end='')
        sub_bytes(data)
        print(" -> ", end='')
        for j in range(4):
            print("%02x" % data[j], end='')
        print()
    print()



# Generated at 2022-06-22 06:29:49.356033
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    password = 'foobarbaz'
    plaintext = 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ' \
                'labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris ' \
                'nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit ' \
                'esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt ' \
                'in culpa qui officia deserunt mollit anim id est laborum.'


# Generated at 2022-06-22 06:30:01.548351
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-22 06:30:02.550153
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([165, 13, 80, 19]) == [164, 190, 59, 29]


# Generated at 2022-06-22 06:30:04.237175
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for x in range(0xFF+1):
        for y in range(0xFF+1):
            if rijndael_mul(x, y) != x * y % 0x100:
                return False
    return True


# Generated at 2022-06-22 06:30:15.089917
# Unit test for function aes_decrypt
def test_aes_decrypt():
    assert aes_decrypt(aes_encrypt([1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4],
                                   key_expansion([1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4])),
                       key_expansion([1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4])) == \
        [1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]

# Generated at 2022-06-22 06:30:18.660377
# Unit test for function sub_bytes
def test_sub_bytes():
    expected_result = [0x63, 0xeb, 0x9f, 0xa0]
    assert sub_bytes([0x53, 0xca, 0x0f, 0x0a]) == expected_result



# Generated at 2022-06-22 06:30:21.418511
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]



# Generated at 2022-06-22 06:30:29.635391
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-22 06:30:55.642027
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert key_schedule_core([0xF0, 0x03, 0x02, 0x01], 0) == [0xF1, 0xD8, 0xEB, 0x13]
    assert key_schedule_core([0xF1, 0xD8, 0xEB, 0x13], 1) == [0xF0, 0x8F, 0x29, 0x2E]
    assert key_schedule_core([0xF0, 0x8F, 0x29, 0x2E], 2) == [0xF9, 0x5B, 0x1B, 0xD8]

# Generated at 2022-06-22 06:31:07.250103
# Unit test for function mix_columns
def test_mix_columns():
    print("Testing mix_columns...")
    test_case = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected_result = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns(test_case)

# Generated at 2022-06-22 06:31:14.697400
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    plain = 'a' * 32
    key = [0] * 16
    iv = [0] * 16
    encoded = aes_cbc_encrypt(bytes_to_intlist(plain.encode('utf-8')),
                              key, iv)
    encoded = intlist_to_bytes(encoded)
    result = compat_b64decode('Pw2G/f6S5B6U5gF9XRvPRw==')
    assert encoded == result

# Generated at 2022-06-22 06:31:16.810893
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert(key_schedule_core([2, 3, 1, 1], 1) == [0x3, 0x7, 0x4, 0x9])



# Generated at 2022-06-22 06:31:22.550923
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]
    exp_bytes = [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]
    assert sub_bytes(data) == exp_bytes



# Generated at 2022-06-22 06:31:33.338918
# Unit test for function aes_decrypt_text

# Generated at 2022-06-22 06:31:44.053190
# Unit test for function aes_encrypt
def test_aes_encrypt():

    data2 = [0x33, 0x88, 0x86, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    data1 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-22 06:31:47.757640
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3]) == [2,3,1]
    assert rotate([]) == []
    assert rotate([1]) == [1]
    assert rotate([1,2,3,4]) == [2,3,4,1]


# Generated at 2022-06-22 06:31:50.241518
# Unit test for function xor
def test_xor():
    return xor([1,2,3,4,5], [6,7,8,9,10])


# Generated at 2022-06-22 06:31:55.306696
# Unit test for function mix_columns
def test_mix_columns():
    assert mix_columns([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]) == [2, 3, 1, 1, 5, 6, 4, 4, 8, 9, 7, 7, 12, 13, 11, 11]

# Generated at 2022-06-22 06:32:16.716256
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x01, 0x02, 0x03, 0x04]
    rcon_iteration = 0x01
    expected_result = [0x02, 0x03, 0x04, 0x05]
    calculated_result = key_schedule_core(data, rcon_iteration)
    print("data for key_schedule_core: {}".format(data))
    print("Expected result: {}".format(expected_result))
    print("Calculated result: {}".format(calculated_result))
    if calculated_result == expected_result:
        print("Test for key_schedule_core PASSED")
    else:
        print("Test for key_schedule_core FAILED")
#test_key_schedule_core()


# Generated at 2022-06-22 06:32:27.180949
# Unit test for function shift_rows
def test_shift_rows():
    data = bytearray([0x00, 0x04, 0x08, 0x0c, 0x01, 0x05, 0x09, 0x0d, 0x02, 0x06, 0x0a, 0x0e, 0x03, 0x07, 0x0b, 0x0f])
    data_shifted = shift_rows(data)
    assert data_shifted == bytearray(
        [0x00, 0x01, 0x02, 0x03, 0x05, 0x06, 0x07, 0x04, 0x0a, 0x0b, 0x08, 0x09, 0x0e, 0x0f, 0x0c, 0x0d]), "shift_rows() failed"
    print("shift_rows() success")



# Generated at 2022-06-22 06:32:36.740989
# Unit test for function shift_rows
def test_shift_rows():
    assert shift_rows([0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f]) == [0x00,0x05,0x0a,0x0f,0x04,0x09,0x0e,0x03,0x08,0x0d,0x02,0x07,0x0c,0x01,0x06,0x0b]

# Generated at 2022-06-22 06:32:47.341174
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    print("Testing aes_ctr_decrypt...")
    # Known test cases (from https://web.archive.org/web/20151017233955/http://csrc.nist.gov/groups/STM/cavp/documents/aes/KAT_CTR.zip)

# Generated at 2022-06-22 06:32:59.103979
# Unit test for function shift_rows
def test_shift_rows():
    test_input = [0x02, 0x03, 0x00, 0x01, 
                  0x01, 0x00, 0x03, 0x02, 
                  0x03, 0x02, 0x01, 0x00, 
                  0x00, 0x01, 0x02, 0x03]
    test_output_expected = [0x02, 0x01, 0x02, 0x03, 
                            0x03, 0x02, 0x03, 0x01, 
                            0x01, 0x03, 0x01, 0x02, 
                            0x00, 0x02, 0x00, 0x03]
    test_output = shift_rows(test_input)

# Generated at 2022-06-22 06:33:07.495671
# Unit test for function sub_bytes
def test_sub_bytes():
    # Test 1
    test_data = [0x53, 0xca, 0xfe, 0x10, 0x56, 0xdc, 0xb2, 0x48, 0x5b, 0xab, 0x66, 0xcb, 0x7a, 0x46, 0x7b, 0x8b]
    expected_result = [0x13, 0x8e, 0xe4, 0x18, 0x30, 0xf2, 0xde, 0x6a, 0x9c, 0x3c, 0x23, 0xaf, 0x2f, 0x6b, 0x2b, 0x9d]
    assert sub_bytes(test_data) == expected_result, "Test 1 failed.\n"
    # Test 2

# Generated at 2022-06-22 06:33:17.385717
# Unit test for function key_schedule_core
def test_key_schedule_core():

    # Test Case #1
    data = [0x01, 0x02, 0x03, 0x04]
    rcon_iteration = 1
    output = key_schedule_core(data, 1)
    expected_output = [0x02, 0x03, 0x04, 0x01]
    if output != expected_output:
        return False

    # Test Case #2
    data = [0x04, 0x05, 0x06, 0x07]
    rcon_iteration = 2
    output = key_schedule_core(data, 2)
    expected_output = [0x04, 0x05, 0x06, 0x07]
    if output != expected_output:
        print(output)
        return False

    return True

# Generated at 2022-06-22 06:33:28.650202
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x6C, 0x2F, 0x3F, 0x4D, 0xB4, 0x96, 0x9F, 0x6E, 0x8C, 0x38, 0xA1, 0x49, 0x21, 0x2C, 0xB1, 0x8F]
    expected_data = [0x57, 0x8B, 0x9A, 0x1E, 0x53, 0xB0, 0xF5, 0x2E, 0xAD, 0x9B, 0xC6, 0x53, 0xB3, 0x87, 0x2B, 0x54]
    assert sub_bytes(data) == expected_data


# Generated at 2022-06-22 06:33:38.734997
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Test vector from http://tools.ietf.org/html/rfc3686#section-6
    data = '''+//AAD/////wAz3qzfhj5xvx8M5Df/jJjcZ9XSBcuvUA8y5W5zYkL1tgKvdea
              P8GQ+z0oXjdgysPBAG/m0q0+wKjvlpv0ToJ/vv8ZoKPcy9XD+J2rB5WlUI5
              9+41tB4Q='''

# Generated at 2022-06-22 06:33:50.809329
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')
    expected = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c762e7160361b7a38e9a6e3f535e00dc6b')
    assert key_expansion(key) == expected

    key = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c762e7160361b7a38e9a6e3f535e00dc6b')

# Generated at 2022-06-22 06:34:06.789544
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='.encode()).decode())
    data = bytes_to_intlist(compat_b64decode('bRtKRX9Y67nTElz42EK7mw=='.encode()).decode())
    iv = bytes_to_intlist(compat_b64decode('o0HsNgl3qz/TZNOkTZRJxA=='.encode()).decode())

    result = aes_cbc_decrypt(data, key, iv)

# Generated at 2022-06-22 06:34:17.140476
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [12, 13, 14, 15, 11, 8, 5, 6, 3, 10, 9, 7, 2, 1, 4, 0]
    iv = [9, 5, 12, 13, 8, 5, 12, 13, 15, 5, 12, 13, 14, 5, 12, 13]

# Generated at 2022-06-22 06:34:19.254662
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    a = [1, 2, 3, 4,
         5, 6, 7, 8,
         9, 10, 11, 12, 
         13, 14, 15, 16]
    print(shift_rows_inv(a))

# Generated at 2022-06-22 06:34:28.392548
# Unit test for function mix_column
def test_mix_column():
    data = [0xDB, 0x13, 0x53, 0x45]
    # print([hex(x) for x in mix_column(data, MIX_COLUMN_MATRIX)])
    assert(mix_column(data, MIX_COLUMN_MATRIX) ==
           [0x8E, 0x4D, 0xA1, 0xBC])
    assert(mix_column(data, MIX_COLUMN_MATRIX_INV) ==
           [0x49, 0xC6, 0xAD, 0x47])
    return "PASS"



# Generated at 2022-06-22 06:34:32.587491
# Unit test for function inc
def test_inc():
    for _ in range(100):
        data = [random.randint(0, 255) for i in range(16)]
        print(data)
        print(inc(data))
        print('\n')

#test_inc()



# Generated at 2022-06-22 06:34:36.678026
# Unit test for function key_schedule_core
def test_key_schedule_core():
    plain = [0x01, 0x02, 0x04, 0x08]
    print(key_schedule_core(plain, 1))

test_key_schedule_core()


# Generated at 2022-06-22 06:34:47.643627
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    def test_aes_cbc_encrypt():
        import random
        import string

        def sbox(v):
            return SBOX[v]

        def inv_sbox(v):
            return INV_SBOX[v]

        def rcon(i):
            return RCON[i]

        def test_encrypt():
            data = [random.randint(0, 255) for _ in range(16)]
            key = [random.randint(0, 255) for _ in range(16)]
            iv = [random.randint(0, 255) for _ in range(16)]

            encrypted_data = aes_cbc_encrypt(data, key, iv)
            assert len(encrypted_data) % BLOCK_SIZE_BYTES == 0

            decrypted_data = aes_cbc_dec

# Generated at 2022-06-22 06:34:52.841658
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert(key_schedule_core([1, 2, 3, 4], 1) == [0xe, 0xe, 0x12, 0xb])
    assert(key_schedule_core([0xF2, 0xF3, 0xF4, 0xF5], 3) == [0xC, 0xC, 0x6, 0x6])
    print('All tests passed!')


# Generated at 2022-06-22 06:35:03.092291
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    # Test case 1
    test_date = [200, 201, 202, 203]
    result = sub_bytes_inv(test_date)
    assert result == [109, 250, 130, 161]
    # Test case 2
    test_date = [161, 139, 75, 255]
    result = sub_bytes_inv(test_date)
    assert result == [100, 59, 150, 131]
    # Test case 3
    test_date = [246, 84, 33, 97]
    result = sub_bytes_inv(test_date)
    assert result == [4, 236, 111, 185]


# Test case
# test_sub_bytes_inv()



# Generated at 2022-06-22 06:35:12.935484
# Unit test for function key_schedule_core
def test_key_schedule_core():
    test_data_1 = [0x1, 0x2, 0x3, 0x4]
    assert key_schedule_core(test_data_1, 1) == [0xE, 0x1, 0x2, 0x3]
    assert key_schedule_core(test_data_1, 2) == [0x2, 0x3, 0x4, 0x9]
    test_data_2 = [0x0, 0x0, 0x0, 0x0]
    assert key_schedule_core(test_data_2, 1) == [0x0, 0x0, 0x0, 0x2]


test_key_schedule_core()



# Generated at 2022-06-22 06:35:41.582280
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x63, 0xEB, 0x9F, 0xA0, 0x30, 0xC0, 0xCD, 0x30, 0x40, 0xFF, 0x39, 0x40, 0xB2, 0x15, 0x18, 0x90]
    data = shift_rows(data)
    data = shift_rows_inv(data)
    assert(data == [0x63, 0xEB, 0x9F, 0xA0, 0x30, 0xC0, 0xCD, 0x30, 0x40, 0xFF, 0x39, 0x40, 0xB2, 0x15, 0x18, 0x90])
    print("[*] Test passed")
# test_shift_rows_inv()



# Generated at 2022-06-22 06:35:47.009736
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    plaintext = "Attack at dawn".encode()
    assert aes_cbc_encrypt(plaintext, 'YELLOW SUBMARINE', '\x00' * 16) == b'\xC8\x0E\xDF\xF1\xFB\x13\x1A\xE8\xB6\x1E\x2A\x14\x87\xFB\x8B\x77'

# Generated at 2022-06-22 06:35:52.148245
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = [0, 1, 2]
    key = [0, 1, 2, 3]
    iv = [4, 5, 6, 7]
    result = aes_cbc_encrypt(data, key, iv)
    expected = [1, 5, 61, 46]
    assert result == expected


# Generated at 2022-06-22 06:36:04.220106
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .counter import Counter
    from .aes_cbc_decrypt import aes_cbc_decrypt
    import unittest


# Generated at 2022-06-22 06:36:07.029348
# Unit test for function inc
def test_inc():
    for i in range(0, 255):
        data = [i]
        assert inc(data) == [i + 1]
    data = [255]
    assert inc(data) == [0]



# Generated at 2022-06-22 06:36:18.064102
# Unit test for function key_expansion

# Generated at 2022-06-22 06:36:28.338105
# Unit test for function aes_decrypt

# Generated at 2022-06-22 06:36:39.685237
# Unit test for function aes_decrypt_text

# Generated at 2022-06-22 06:36:51.044975
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
	#Use a known key and cleartext, check if the result is the same as online
	#key in bytes
	BKEY = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
	#cleartext in bytes
	BCLEARTEXT = [0x6b, 0xc1, 0xbe, 0xe2, 0x2e, 0x40, 0x9f, 0x96, 0xe9, 0x3d, 0x7e, 0x11, 0x73, 0x93, 0x17, 0x2a]
	#iv in bytes

# Generated at 2022-06-22 06:36:59.330590
# Unit test for function shift_rows
def test_shift_rows():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    data_shifted = shift_rows(data)
    expected_result = [0, 1, 2, 3, 7, 4, 5, 6, 10, 11, 8, 9, 13, 14, 15, 12]
    assert data_shifted == expected_result

# Generated at 2022-06-22 06:37:19.516713
# Unit test for function rotate
def test_rotate():
    data = [[0x32, 0x88, 0x31, 0xe0],
            [0x43, 0x5a, 0x31, 0x37],
            [0xf6, 0x30, 0x98, 0x07],
            [0xa8, 0x8d, 0xa2, 0x34]]
    result = [[0x88, 0x31, 0xe0, 0x32],
              [0x5a, 0x31, 0x37, 0x43],
              [0x30, 0x98, 0x07, 0xf6],
              [0x8d, 0xa2, 0x34, 0xa8]]
    for a, b in zip(data, result):
        assert rotate(a) == b



# Generated at 2022-06-22 06:37:24.721657
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    b = bytearray(b"\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f")
    assert sub_bytes_inv(sub_bytes(b)) == b



# Generated at 2022-06-22 06:37:35.833015
# Unit test for function aes_decrypt
def test_aes_decrypt():
    cipher_text = [0x69, 0xC4, 0xE0, 0xD8, 0x6A, 0x7B, 0x04, 0x30, 0xD8, 0xCD, 0xB7, 0x80, 0x70, 0xB4, 0xC5, 0x5A]
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-22 06:37:36.858945
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert(rijndael_mul(0x57, 0x13) == 0xFE)
test_rijndael_mul()



# Generated at 2022-06-22 06:37:39.192295
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    print("%02x %02x %02x %02x" % (data_mixed[0], data_mixed[1], data_mixed[2], data_mixed[3]))



# Generated at 2022-06-22 06:37:42.871610
# Unit test for function shift_rows
def test_shift_rows():
    data = range(16)
    assert shift_rows(data) == [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]



# Generated at 2022-06-22 06:37:53.845502
# Unit test for function aes_decrypt
def test_aes_decrypt():
    #Test data from https://csrc.nist.gov/CSRC/media/Projects/Cryptographic-Standards-and-Guidelines/documents/examples/AES_Core128.pdf
    data = bytes_to_intlist(compat_b64decode("rEz2lMeZDLoBJwEw+C5L1g=="))
    key = bytes_to_intlist("2b7e151628aed2a6abf7158809cf4f3c")
    expanded_key = key_expansion(key)
    decrypted = aes_decrypt(data,expanded_key)

# Generated at 2022-06-22 06:38:05.273673
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    print('Unit test for function aes_cbc_decrypt')

# Generated at 2022-06-22 06:38:13.457483
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv([0xcf, 0x4f, 0x3c, 0x09, 0x86, 0x7c, 0x9b, 0x1d, 0x02, 0x70, 0x55, 0x39, 0x21, 0x5d, 0xa4, 0xdf]) == [0x0C, 0x12, 0x08, 0x50, 0xA2, 0x52, 0xD0, 0x92, 0xDA, 0xDD, 0x13, 0x46, 0xB4, 0xA7, 0xFC, 0x40]

# Generated at 2022-06-22 06:38:24.272233
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .compat import unhexlify
    from .aes_counter import AES_CTR_Counter

    cipher = bytes_to_intlist(unhexlify(b'6920e299a5202a6d656e636869746f2a5') + b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    key = bytes_to_intlist(unhexlify(b'6920e299a5202a6d656e636869746f20'))
    counter = AES_CTR_Counter(i=0)
    decrypted_data = aes_ctr_decrypt(cipher, key, counter)

# Generated at 2022-06-22 06:38:55.621659
# Unit test for function key_expansion
def test_key_expansion():
    data = b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c'
    res = key_expansion(data)

# Generated at 2022-06-22 06:38:59.208938
# Unit test for function xor
def test_xor():
    a = [1, 0, 1, 1]
    b = [1, 1, 0, 0]
    c = [0, 1, 1, 1]
    print(xor(a, b))
    print(xor(a, c))



# Generated at 2022-06-22 06:39:03.784988
# Unit test for function mix_column
def test_mix_column():
    result = mix_column([0, 0, 0, 0], [[1, 0, 0, 1], [0, 1, 1, 0], [1, 1, 0, 0], [0, 0, 1, 1]])
    assert(result == [0, 1, 1, 0])

