

# Generated at 2022-06-22 06:29:20.492367
# Unit test for function rijndael_mul
def test_rijndael_mul():
    # import pdb; pdb.set_trace()
    for i in range(256):
        for j in range(256):
            c = rijndael_mul(i, j)
            assert (i == 0 or j == 0 or c == ((i * j) % 0xFF))



# Generated at 2022-06-22 06:29:31.193230
# Unit test for function mix_columns
def test_mix_columns():
    a = [0x6c, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    res = [0xa0, 0xfa, 0xfe, 0x17, 0x88, 0x54, 0x2c, 0xb1, 0x23, 0xa3, 0x39, 0x39, 0x2a, 0x6c, 0x76, 0x05]
    assert mix_columns(a) == res



# Generated at 2022-06-22 06:29:41.805366
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(b'000102030405060708090a0b0c0d0e0f')
    expanded_key = key_expansion(bytes_to_intlist(b'000102030405060708090a0b0c0d0e0f'))
    assert aes_encrypt(data, expanded_key) == bytes_to_intlist(b'69c4e0d86a7b0430d8cdb78070b4c55a')

    data = bytes_to_intlist(b'ffffeeeeddddccccbbbbaaaa99998888')
    expanded_key = key_expansion(bytes_to_intlist(b'000102030405060708090a0b0c0d0e0f'))
    assert aes

# Generated at 2022-06-22 06:29:50.568198
# Unit test for function key_expansion
def test_key_expansion():
    # Test with the AES-128 cipher key
    key = bytes_to_intlist(b"\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c")
    expanded_key = key_expansion(key)


# Generated at 2022-06-22 06:29:52.046854
# Unit test for function xor
def test_xor():
    test = [[0x20,0x20],[0x20,0x20]]
    test2 = xor(test, test)
    assert test2 == [0, 0]


# Generated at 2022-06-22 06:29:57.482055
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    test_data = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected_data = [0x8E, 0xE3, 0xB2, 0x01, 0xBF, 0xD2, 0xD6, 0x4F, 0x1B, 0x27, 0x8A, 0xF1, 0xC4, 0x97, 0x2D, 0xB3]
    assert mix_columns_inv(test_data) == expected_data



# Generated at 2022-06-22 06:30:02.584634
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0x01, 0x01, 0x01, 0x01]
    data_mixed = [0x8e, 0x4d, 0xa1, 0xbc,
                  0x9f, 0xdc, 0x58, 0x9d,
                  0x01, 0x2e, 0x4c, 0x69,
                  0x4e, 0x55, 0x53, 0x7a]
    assert mix_columns(data) == data_mixed
test_mix_columns()


# Generated at 2022-06-22 06:30:07.232258
# Unit test for function mix_columns
def test_mix_columns():
    plain = [[0xdb, 0xf2, 0xd4, 0x6f], [0x45, 0xa4, 0x9a, 0xa4], [0xdc, 0x4f, 0x1a, 0x2f], [0xea, 0xd2, 0xf7, 0x48]]
    cipher = [[0x8e, 0x4d, 0xa1, 0xbc], [0x9f, 0xdc, 0x58, 0x9d], [0x1c, 0x16, 0x67, 0xd9], [0x8d, 0x91, 0x2e, 0x53]]
    assert mix_columns(plain, MIX_COLUMN_MATRIX) == cipher

# Generated at 2022-06-22 06:30:15.055855
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    data = [0x52, 0x7c, 0xe6, 0x30, 0x86, 0xa5, 0x2b, 0xe0, 0xf0, 0x47, 0x95, 0x89, 0x33, 0xaf, 0x3a, 0xa0]
    output = sub_bytes_inv(data)
    assert output == [0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    print("Test Passed")
#test_sub_bytes_inv()



# Generated at 2022-06-22 06:30:19.586476
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x01, 0x02, 0x03, 0x04,
            0x05, 0x06, 0x07, 0x08,
            0x09, 0x0a, 0x0b, 0x0c,
            0x0d, 0x0e, 0x0f, 0x10]
    expected = [0x01, 0x05, 0x09, 0x0d,
                0x02, 0x06, 0x0a, 0x0e,
                0x03, 0x07, 0x0b, 0x0f,
                0x04, 0x08, 0x0c, 0x10]
    result = shift_rows(data)
    assert result == expected

test_shift_rows()

# Generated at 2022-06-22 06:30:34.149340
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert mix_columns_inv(mix_columns([0xF2, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01])) == [0xF2, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    return "test_mix_columns_inv passed"



# Generated at 2022-06-22 06:30:40.782189
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    encrypted_base64_string = '8H4eJhBjygRNOgRzmX+JYg=='
    expected_decrypted_base64_string = '7sZ+a6qJ7xjK3qyA7rUQ+6g='
    encrypted_string = compat_b64decode(encrypted_base64_string)
    expected_decrypted_string = compat_b64decode(expected_decrypted_base64_string)
    encrypted = bytes_to_intlist(encrypted_string)
    expected_decrypted = bytes_to_intlist(expected_decrypted_string)
    key = [80, 100, 126, 219, 119, 131, 227, 193, 137, 193, 213, 127, 123, 172, 247, 242]

# Generated at 2022-06-22 06:30:48.960571
# Unit test for function mix_columns
def test_mix_columns():
    input = [0xdb, 0xf2, 0xd4, 0x6d, 0xbc, 0x9b, 0x8d, 0x7a, 0x37, 0x52, 0x7e, 0xa3, 0xf9, 0xc3, 0xe7, 0x4f]
    output = [0x04, 0xe0, 0x48, 0x28, 0x66, 0xcb, 0xf8, 0x06, 0x81, 0x19, 0xd3, 0x26, 0xe5, 0x9a, 0x7a, 0x4c]
    assert output == mix_columns(input)
    assert input == mix_columns(output, matrix=MIX_COLUMN_MATRIX_INV)

test_mix_columns()


# Generated at 2022-06-22 06:30:59.865858
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    import binascii

# Generated at 2022-06-22 06:31:02.809327
# Unit test for function shift_rows
def test_shift_rows():
    input_data = []
    for i in range(16):
        input_data.append(i)
    output_data = shift_rows(input_data)
    print(output_data)



# Generated at 2022-06-22 06:31:08.581181
# Unit test for function shift_rows
def test_shift_rows():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    assert shift_rows(data) == [0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11]

test_shift_rows()

# Generated at 2022-06-22 06:31:19.673095
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    cipher = '6d50868055d2a3a3e869f22d24d0afd2'
    key    = '72d37eb68b1c0a5a441414506b6d733d'
    iv     = '5b831c4a1fdf5fe01d4f4a4e6f2be534'

    cipher = bytes_to_intlist(compat_b64decode(cipher))
    key    = bytes_to_intlist(compat_b64decode(key))
    iv     = bytes_to_intlist(compat_b64decode(iv))

    decrypted = aes_cbc_decrypt(cipher, key, iv)


# Generated at 2022-06-22 06:31:21.600315
# Unit test for function xor
def test_xor():
    print("testing  xor function")
    assert (xor([3,4,5],[123,32,10]) == [126, 36, 15])
    print("passed")


# Generated at 2022-06-22 06:31:32.394013
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-22 06:31:37.253940
# Unit test for function rotate
def test_rotate():
    if rotate([1,2,3,4])==[2,3,4,1]:
        print("Unit test for rotate() passed")
    else:
        print("Unit test for rotate() failed")
    return


# Generated at 2022-06-22 06:31:51.203005
# Unit test for function mix_columns
def test_mix_columns():
    word_hex = [0xdb, 0xf2, 0xd4, 0x6f, 0xbc, 0x10, 0x06, 0x64, 0xfe, 0xca, 0xf8, 0x5d, 0xe2, 0xc6, 0x6a, 0x86]
    word_mixed = mix_columns(word_hex)
    word_mixed_test = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x26, 0x4c, 0x4e, 0x59, 0x04, 0xee, 0x7e]
    if(word_mixed == word_mixed_test):
        print("Success")
        return True

# Generated at 2022-06-22 06:32:01.263815
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-22 06:32:11.201062
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    expanded_key = key_expansion(key)
    data = sub_bytes([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])
    data = shift_rows(data)
    data = mix_columns(data)
    data = xor([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16], data)
    data = aes_decrypt(data, expanded_key)
    print(data)
test_aes_decrypt()

# Generated at 2022-06-22 06:32:21.536307
# Unit test for function aes_encrypt
def test_aes_encrypt():
    """
    Test function aes_encrypt
    """
    # Test data taken from
    # http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf

    # Test Case 1

# Generated at 2022-06-22 06:32:29.350869
# Unit test for function aes_encrypt

# Generated at 2022-06-22 06:32:33.757114
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xA4, 0x68, 0x6B, 0x02, 0x9C, 0x9F, 0x5B, 0x6A, 0x7F, 0x35, 0xEA, 0x50, 0xF2, 0x2B, 0x43, 0x49]
    expected = [0x04, 0x66, 0x81, 0xE5, 0xE0, 0xCB, 0x19, 0x9A, 0x48, 0xF8, 0xD3, 0x7A, 0x28, 0x06, 0x26, 0x4C]
    output = mix_columns_inv(data)
    print(output)
    if output != expected:
        print("Failed")
    else:
        print("All good")



# Generated at 2022-06-22 06:32:43.030952
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = [0] * 16
    data = b"This is cleartext data to test the function aes_cbc_encrypt with. This is a really really long block of text, so that we can test that the function splits the text in multiple blocks"
    encrypted_data = aes_cbc_encrypt(bytes_to_intlist(data), key, iv)
    decrypted_data = aes_cbc_decrypt(encrypted_data, key, iv)
    assert data == intlist_to_bytes(decrypted_data)



# Generated at 2022-06-22 06:32:44.634603
# Unit test for function mix_columns
def test_mix_columns():
    column = [0xdb, 0x13, 0x53, 0x45]
    expected = [0x8e, 0x4d, 0xa1, 0xbc]
    assert mix_columns(column) == expected
test_mix_columns()

# Generated at 2022-06-22 06:32:51.777142
# Unit test for function key_expansion
def test_key_expansion():
    test_key = (0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
                0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c)

# Generated at 2022-06-22 06:32:55.292961
# Unit test for function sub_bytes
def test_sub_bytes():
    print("test_sub_bytes")
    test_string = "Hello, world!"
    SubBytes_test_string = sub_bytes(test_string)
    print(SubBytes_test_string)
    assert SubBytes_test_string == "W_\x08&\xdb\x93\x02\x8d"
    assert sub_bytes("I love Python!") == "@\xa7\xe5\xcd\x98\x1d\xdd\x0c\xf9\x04\xca\x1d"
    print("Passed!")
    print("-" * 30)


# Generated at 2022-06-22 06:33:01.673154
# Unit test for function key_expansion
def test_key_expansion():
    from .tests import run_test_key_expansion
    run_test_key_expansion()



# Generated at 2022-06-22 06:33:12.727174
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .crypto import aes_cbc_decrypt

    def make_counter():
        c = [0] * 4
        i = 0
        while True:
            yield c[:]
            c[i] = c[i] + 1
            i = (i + 1) % 4

    iv, key, data = aes_cbc_decrypt('6f4b6c8cc6b4d25e2cde07fbd6d52b6f',
                                    '2b7e151628aed2a6abf7158809cf4f3c',
                                    '6539e9b1c43f3f8eea04ef5f5a5a5f5f')

# Generated at 2022-06-22 06:33:24.536697
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = [
        0x69, 0x20, 0xe2, 0x99, 0xa5, 0x20, 0x2a, 0x6d,
        0x65, 0x6e, 0x63, 0x68, 0x69, 0x74, 0x6f, 0x2a,
    ]
    key = bytes_to_intlist([
        0xae, 0x68, 0x52, 0xf8, 0x12, 0x10, 0x67, 0xcc,
        0x4b, 0xf7, 0xa5, 0x76, 0x55, 0x77, 0xf3, 0x9e,
    ])
    counter = AESCounter(0)
    decrypted = aes_ctr_decrypt(data, key, counter)
    expected = bytes_to

# Generated at 2022-06-22 06:33:35.457343
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-22 06:33:42.452929
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # test vector: http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf#page=12&zoom=100,63,492
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    expanded_key = key_expansion(key)
    cipher = bytes_to_intlist(compat_b64decode('2DFC2DF0A9307B0D53FC34FDAD88A33F'))
    assert intlist_to_bytes(aes_decrypt(cipher, expanded_key)) == compat_b64decode('00112233445566778899aabbccddeeff')



# Generated at 2022-06-22 06:33:48.230494
# Unit test for function mix_column
def test_mix_column():
    data_mixed = mix_column([0x32, 0x88, 0x31, 0xe0], MIX_COLUMN_MATRIX)
    if data_mixed == [0xED, 0x80, 0x77, 0x2B]:
        print ('Success')
    else:
        print ('Failed')
# test_mix_column()



# Generated at 2022-06-22 06:33:51.851947
# Unit test for function inc
def test_inc():
    assert inc([0]) == [1]
    assert inc([255]) == [0]
    assert inc([255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255]) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    assert inc([255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 254]) == [255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255]

test_inc()



# Generated at 2022-06-22 06:33:59.158256
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([x for x in range(0, 256)])) == [x for x in range(0, 256)]
    assert sub_bytes_inv(sub_bytes([0xB2, 0x00, 0xB6, 0x84])) == [0xB2, 0x00, 0xB6, 0x84]



# Generated at 2022-06-22 06:34:04.391757
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    assert data_mixed == [0x8e, 0x4d, 0xa1, 0xbc]


# Generated at 2022-06-22 06:34:10.051309
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Unit test for function aes_decrypt_text
    """
    test_text = "Hello World!"
    key_size_bytes = 32
    password = "test_password"
    data = aes_encrypt_text(test_text, password, key_size_bytes)
    result = aes_decrypt_text(data, password, key_size_bytes)
    assert result == test_text



# Generated at 2022-06-22 06:34:25.953759
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * 16)
    data = bytes_to_intlist(b'\x01\x02\x03\x04\x05\x06\x07\x08'
                            b'\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10'
                            b'\x11\x12\x13\x14\x15\x16\x17\x18'
                            b'\x19\x1a\x1b\x1c\x1d\x1e\x1f\x20')
    result = aes_cbc_encrypt(data, key, iv)


# Generated at 2022-06-22 06:34:37.125680
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    print("Testing unit for function aes_cbc_decrypt")
    key = [0x5d, 0x9d, 0x4e, 0xf2, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    iv = [0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]

# Generated at 2022-06-22 06:34:41.965905
# Unit test for function xor
def test_xor():
    data1 = (0x03, 0x33, 0x33, 0x03)
    data2 = (0xaa, 0xaa, 0xaa, 0xaa)
    assert(xor(data1, data2) == (0xa9, 0x99, 0x99, 0xa9))



# Generated at 2022-06-22 06:34:45.672618
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    cleartext = intlist_to_bytes([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])
    cipher_key = intlist_to_bytes([32, 103, 233, 18, 76, 179, 39, 55, 217, 230, 205, 128, 129, 71, 31, 113])
    iv = intlist_to_bytes([45, 40, 23, 12, 57, 75, 128, 180, 240, 179, 74, 90, 136, 91, 233, 37])

    cipher = aes_cbc_encrypt(bytes_to_intlist(cleartext),
                             bytes_to_intlist(cipher_key),
                             bytes_to_intlist(iv))

# Generated at 2022-06-22 06:34:56.935748
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print("RIJNDAEL_MUL")
    print("1 * 2 = " + str(rijndael_mul(0x01, 0x02)))
    print("1 * 4 = " + str(rijndael_mul(0x01, 0x04)))
    print("1 * 8 = " + str(rijndael_mul(0x01, 0x08)))
    print("1 * 3 = " + str(rijndael_mul(0x01, 0x03)))
    print("1 * 5 = " + str(rijndael_mul(0x01, 0x05)))
    print("1 * 9 = " + str(rijndael_mul(0x01, 0x09)))

# Generated at 2022-06-22 06:35:01.404737
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    print("\nUnit test for function mix_columns_inv")
    data = [0x3C, 0x3A, 0x59, 0x5F, 0xA5, 0xA8, 0xA9, 0xA6, 0xB1, 0xB2, 0xB3, 0xB0, 0xB9, 0xB8, 0xBF, 0xBE]
    assert mix_columns_inv(data) == [0x3C, 0x3A, 0x59, 0x5F, 0xA5, 0xA8, 0xA9, 0xA6, 0xB1, 0xB2, 0xB3, 0xB0, 0xB9, 0xB8, 0xBF, 0xBE]

test_mix_columns_inv

# Generated at 2022-06-22 06:35:07.130699
# Unit test for function mix_column
def test_mix_column():
    data = [0x02, 0x03, 0x01, 0x01]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    assert data_mixed == [0x04, 0x0c, 0x09, 0x0b]
    print("Function mix_column passes.")

# Generated at 2022-06-22 06:35:10.767401
# Unit test for function rotate
def test_rotate():
    input = np.array([0x2, 0x3, 0x1, 0x1])
    output = rotate(input)
    assert all(output == np.array([0x3, 0x1, 0x1, 0x2]))



# Generated at 2022-06-22 06:35:22.372581
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [
        0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d,
        0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34
    ]

# Generated at 2022-06-22 06:35:25.117645
# Unit test for function rotate

# Generated at 2022-06-22 06:35:48.289960
# Unit test for function key_expansion
def test_key_expansion():
    import random as rd
    from .compat import compat_b64decode
    KEY_LEN_LIST = [16, 24, 32]
    LEN_LIST = [176, 208, 240]
    l = random_intlist(26)
    x0 = bytes_to_intlist(compat_b64decode(l[0]))
    x1 = key_expansion(x0)
    x2 = bytes_to_intlist(compat_b64decode(l[1]))
    assert x1 == x2
    x0 = bytes_to_intlist(compat_b64decode(l[2]))
    x1 = key_expansion(x0)
    x2 = bytes_to_intlist(compat_b64decode(l[3]))
    assert x1

# Generated at 2022-06-22 06:35:50.202462
# Unit test for function mix_column
def test_mix_column():
    state = [0xdb, 0x13, 0x53, 0x45]
    print(mix_column(state, MIX_COLUMN_MATRIX_INV))
    print(mix_column(state, MIX_COLUMN_MATRIX))


# Generated at 2022-06-22 06:36:02.331207
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = "140b41b22a29beb4061bda66b6747e14"
    iv = "4ca00ff4c898d61e1edbf1800618fb28"
    cipher = "28a226d160dad07883d04e008a7897ee2e4b7465d5290d0c0e6c6822236e1daafb94ffe0c5da05d9476be028ad7c1d81"
    decrypted = aes_cbc_decrypt(bytes_to_intlist(compat_b64decode(cipher)), bytes_to_intlist(compat_b64decode(key)), bytes_to_intlist(compat_b64decode(iv)))

# Generated at 2022-06-22 06:36:06.777356
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    result = shift_rows_inv(a)
    print('Shifted array: %s' % result)
    

# Generated at 2022-06-22 06:36:13.415506
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x19, 0x3d, 0xe3, 0xbe, 0xa0, 0xf4, 0xe2, 0x2b, 0x9a, 0xc6, 0x8d, 0x2a, 0xe9, 0xf8, 0x48, 0x08]
    assert shift_rows_inv(shift_rows(data)) == data
    print("shift_rows_inv function is OK")



# Generated at 2022-06-22 06:36:20.686079
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    mixed = mix_columns([3, 14, 15, 9, 8, 9, 4, 5])
    mixed_inv = mix_columns_inv(mixed)
    assert mixed_inv == [3, 14, 15, 9, 8, 9, 4, 5], "Error in mix columns inverse"

# Generated at 2022-06-22 06:36:30.146908
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert(mix_columns_inv(mix_columns([0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01])) == [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01])
test_mix_columns_inv()



# Generated at 2022-06-22 06:36:41.159830
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    import random

    data = bytes_to_intlist(b'00112233445566778899AABBCCDDEEFF')
    cleartext = bytes_to_intlist(
        b'32 43 f6 a8 88 5a 30 8d 31 31 98 a2 e0 37 07 34')
    key = bytes_to_intlist(
        b'\x60\x3d\xeb\x10\x15\xca\x71\xbe\x2b\x73\xae\xf0\x85\x7d\x77\x81' +
        b'\x1f\x35\x2c\x07\x3b\x61\x08\xd7\x2d\x98\x10\xa3\x09\x14\xdf\xf4')
   

# Generated at 2022-06-22 06:36:50.755714
# Unit test for function rotate
def test_rotate():
    assert rotate([0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]) == [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x00]
    return True



# Generated at 2022-06-22 06:37:02.215791
# Unit test for function mix_columns
def test_mix_columns():
    test_vector = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns(test_vector)
    assert result == expected, 'Error: failed to mix columns'
    print('Mix columns passed unit tests')



# Generated at 2022-06-22 06:37:51.133313
# Unit test for function key_expansion
def test_key_expansion():
    assert bytes_to_intlist(compat_b64decode('6x5j9UJHlYb/Nclt1FwdjQ==')) == key_expansion(bytes_to_intlist('1234567890ABCDEF1234567890ABCDEF'.encode('ascii')))
test_key_expansion()



# Generated at 2022-06-22 06:37:57.393516
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    input = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    output = [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]

    assert shift_rows(input) == output
    assert shift_rows_inv(output) == input



# Generated at 2022-06-22 06:38:00.603545
# Unit test for function rotate
def test_rotate():
    assert(rotate([0x63, 0x53, 0xe0, 0x8c]) == [0x53, 0xe0, 0x8c, 0x63])


# Generated at 2022-06-22 06:38:08.599616
# Unit test for function mix_column
def test_mix_column():
    data = [0x1, 0x2, 0x3, 0x4]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    assert data_mixed == [0x2, 0x3, 0x1, 0x1]
    data_mixed = mix_column(data_mixed, MIX_COLUMN_MATRIX_INV)
    assert data == data_mixed



# Generated at 2022-06-22 06:38:17.353227
# Unit test for function aes_encrypt
def test_aes_encrypt():
    num_tests = 0
    for key_size in [16, 24, 32]:
        for data_size in [16, 24, 32]:
            for iv_size in [16, 24, 32]:
                key = bytes_to_intlist(b'a' * key_size)
                expanded = key_expansion(key)
                data = bytes_to_intlist(b'a' * data_size)
                print(len(data))
                cipher = aes_encrypt(data, expanded)
                num_tests += 1

    print('done', num_tests)



# Generated at 2022-06-22 06:38:26.165004
# Unit test for function mix_columns
def test_mix_columns():
    block = [0x02, 0x03, 0x01, 0x01,
             0x01, 0x02, 0x03, 0x01,
             0x01, 0x01, 0x02, 0x03,
             0x03, 0x01, 0x01, 0x02]
    assert mix_columns(block, MIX_COLUMN_MATRIX) == block
    assert mix_columns(mix_columns(block, MIX_COLUMN_MATRIX), MIX_COLUMN_MATRIX_INV) == block



# Generated at 2022-06-22 06:38:35.910560
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():

    data = bytes_to_intlist(b'attack at dawn')

    class FakeCounter:
        def __init__(self):
            self.count = 0

        def next_value(self):
            self.count += 1
            return bytes_to_intlist(b'\x00' * BLOCK_SIZE_BYTES)

    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    counter = FakeCounter()

# Generated at 2022-06-22 06:38:47.421385
# Unit test for function xor
def test_xor():
    assert xor([1,1,1,1], [0,0,0,0]) == [1,1,1,1]
    assert xor([0,0,0,0], [1,1,1,1]) == [1,1,1,1]
    assert xor([1,1,1,1], [1,1,1,1]) == [0,0,0,0]
    assert xor([0,0,0,0], [0,0,0,0]) == [0,0,0,0]
    assert xor([10101010,10101010,10101010,10101010], [10101010,10101010,10101010,10101010]) == [0,0,0,0]


# Generated at 2022-06-22 06:38:52.341900
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0xCA, 0xFE, 0xBA, 0xBE]
    rcon_iteration = 0
    assert key_schedule_core(data, rcon_iteration) == [0xDA, 0x26, 0x93, 0xF6]



# Generated at 2022-06-22 06:39:04.221803
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Arrange
    data = intlist_to_bytes([1, 2, 3])
    key = intlist_to_bytes([1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8])
    iv = intlist_to_bytes([1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8])

    # Act
    encrypted_data = aes_cbc_encrypt(bytes_to_intlist(data), bytes_to_intlist(key), bytes_to_intlist(iv))