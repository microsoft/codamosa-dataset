

# Generated at 2022-06-22 06:29:19.210145
# Unit test for function inc
def test_inc():
    assert inc([255]) == [0]
    assert inc([0]) == [1]
    assert inc([0, 0, 0]) == [0, 0, 1]
    assert inc([255, 255, 255]) == [0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]
    assert inc([127, 255, 255]) == [128, 0, 0]



# Generated at 2022-06-22 06:29:27.117621
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    plain_text = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected = [0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c]

    actual = mix_columns_inv(plain_text)

    assert(actual == expected)

test_mix_columns_inv()



# Generated at 2022-06-22 06:29:34.683737
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3,4],[3,3,3,3],[2,2,2,2]) == ([2,3,4,1],[3,3,3,3],[2,2,2,2])
    assert rotate([4,4,4,4],[4,4,4,4],[4,4,4,4]) == ([4,4,4,4],[4,4,4,4],[4,4,4,4])



# Generated at 2022-06-22 06:29:38.296020
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Test vectors from https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf
    data = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-22 06:29:41.288822
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3,4]) == [2,3,4,1]


# Generated at 2022-06-22 06:29:48.617077
# Unit test for function rotate
def test_rotate():
    assert rotate([0x02, 0x03, 0x01, 0x01]) == [0x03, 0x01, 0x01, 0x02]
    assert rotate([0x01, 0x01, 0x01, 0x01]) == [0x01, 0x01, 0x01, 0x01]
    assert rotate([0x01, 0x01, 0x01, 0x01]) != [0x02, 0x02, 0x02, 0x02]



# Generated at 2022-06-22 06:29:53.314215
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    # get the small case from the book
    data = [0x63, 0x53, 0xe0, 0x8c, 0x09, 0x60, 0xe1, 0x04, 0xcd, 0x70, 0xb7, 0x51, 0xba, 0xca, 0xd0, 0xe7]

    # input should be 1 column, the first one
    input_column = data[0: 4]

    # output should be the first column of the matrix inverse
    expected_output = [0x04, 0x66, 0x81, 0xe5]

    # do the mix column on this first column
    output_column = mix_column(input_column, MIX_COLUMN_MATRIX_INV)
    assert output_column == expected_output

    # now do the mix column of the whole

# Generated at 2022-06-22 06:30:05.143304
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-22 06:30:15.190308
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Test vector from from FIPS-197
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    data = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]
    expanded_key = key_expansion(key)

# Generated at 2022-06-22 06:30:21.679932
# Unit test for function mix_column
def test_mix_column():
    data = [1, 2, 3, 4]
    assert mix_column(data, MIX_COLUMN_MATRIX) == [0x14, 0x11, 0x1A, 0x3]
    assert mix_column(data, MIX_COLUMN_MATRIX_INV) == [0x9, 0xA, 0xF, 0x4]



# Generated at 2022-06-22 06:30:34.974522
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x3e, 0x1a, 0x4f, 0x15]) == [0x53, 0x4d, 0x50, 0x43]
    assert sub_bytes([0x4a, 0x20, 0x4d, 0x10]) == [0x54, 0x4a, 0x4f, 0x43]

# Generated at 2022-06-22 06:30:46.524592
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Unit test for function aes_decrypt_text
    """
    import re
    from .aes_cipher import aes_encrypt_text

    def _test(_password, _data):
        key_size_bytes = len(_password)
        ciphertext = aes_encrypt_text(_data, _password, key_size_bytes)
        plaintext = aes_decrypt_text(ciphertext, _password, key_size_bytes)
        assert plaintext == _data.encode('utf-8')

    _test('a' * 16, 'a' * 16)
    _test('a' * 24, 'a' * 24)
    _test('a' * 32, 'a' * 32)
    _test('a' * 8, 'a' * 8)

# Generated at 2022-06-22 06:30:57.695021
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class MonotonicCounter(object):
        def __init__(self):
            self._count = 0

        def next_value(self):
            output = [self._count & 0xff] * 16
            self._count += 1
            return output
    # From https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf Appendix C
    cipher = bytes_to_intlist(compat_b64decode(
        b'LeMlE1Brg6ei5oqvmD9pScX7VGrYlb6u'))
    key = [0] * 16
    counter = MonotonicCounter()

# Generated at 2022-06-22 06:30:59.613944
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([0]*16)) == [0]*16



# Generated at 2022-06-22 06:31:00.645825
# Unit test for function rijndael_mul
def test_rijndael_mul():
    # Test that the function is working correctly
    assert(rijndael_mul(0x57, 0x13) == 0xfe)



# Generated at 2022-06-22 06:31:09.815213
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    """Function to test the function sub_bytes_inv
    It takes no argument.
    It doesn't return anything.
    """

# Generated at 2022-06-22 06:31:12.749117
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text('QM63xwfQ2IyBmsu8WFCpAg==', 'asdf', 16) == b'Hello World!'



# Generated at 2022-06-22 06:31:23.772871
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytes_to_intlist(
        compat_b64decode(
            'T2Ys0+I/WO4X9B4vc4bNvC8tcsWVtH0wzq3V7vI8/C0='
        )
    )
    key = bytes_to_intlist(
        compat_b64decode(
            'Wg7b9XoHNSGZdIgrZ8WpDFBHKxTkSsQs1vgGLsUsEo4='
        )
    )
    iv = bytes_to_intlist(
        compat_b64decode(
            'mX9XbGu1mEiZ/e8kSaFz/w=='
        )
    )
    result = aes_cbc_decrypt

# Generated at 2022-06-22 06:31:29.834211
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = []
    for i in range(0, 16, 4):
        data += [i, i + 1, i + 2, i + 3]
    data = shift_rows(data)
    data = shift_rows_inv(data)
    for i in range(16):
        if i % 4 == 0:
            print('\n')
        print(data[i], end='\t')



# Generated at 2022-06-22 06:31:38.513511
# Unit test for function aes_decrypt
def test_aes_decrypt():
	ciphertext = [0x1c,0xb7,0x51,0x1d,0x62,0xfb,0xa6,0xc6,0x2f,0x42,0x17,0x7f,0xf9,0xa1,0x5a,0xca]
	key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-22 06:31:54.484895
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0xFF, 0xFF, 0xFF, 0xFF]
    rcon_iteration = 0
    assert key_schedule_core(data, rcon_iteration) == [0xFF, 0xE8, 0xFF, 0xFF]

    data = [0xFF, 0xE8, 0xFF, 0xFF]
    rcon_iteration = 1
    assert key_schedule_core(data, rcon_iteration) == [0xFF, 0xD4, 0xFF, 0xFF]


# Generated at 2022-06-22 06:31:58.843591
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    inp = [0x19, 0xa0, 0x9a, 0xe9]
    print(inp)
    outs = sub_bytes(inp)
    print(outs)
    out_invs = sub_bytes_inv(outs)
    print(out_invs)
    print("-----------------")


# Generated at 2022-06-22 06:32:03.112612
# Unit test for function rotate
def test_rotate():
    data = [0x01, 0x02, 0x03, 0x04]
    assert rotate(data) == [0x02, 0x03, 0x04, 0x01]


# Generated at 2022-06-22 06:32:09.290905
# Unit test for function key_schedule_core
def test_key_schedule_core():
    print("Test sub_bytes")
    data = [0x1, 0x2, 0x3, 0x4]
    assert(sub_bytes(data) == [0x63, 0x53, 0xe0, 0x8c])

    print("Test key_schedule_core")
    data = [0x2, 0x3, 0x4, 0x5]
    assert(key_schedule_core(data, 2) == [0x6e, 0xc9, 0x8f, 0xa7])



# Generated at 2022-06-22 06:32:20.201675
# Unit test for function key_expansion

# Generated at 2022-06-22 06:32:28.526141
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')

# Generated at 2022-06-22 06:32:37.118071
# Unit test for function aes_encrypt
def test_aes_encrypt():
    assert aes_encrypt([1,2,3,4], [1,2,3,4]) == [0, 0, 0, 0]
    assert aes_encrypt([0,0,0,0], [0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0]) == [1,2,3,4]
    assert aes_encrypt([1,2,3,4], [1,2,3,4, 5,6,7,8, 9,10,11,12, 13,14,15,16]) == [0, 0, 0, 0]

# Generated at 2022-06-22 06:32:47.489402
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F]

# Generated at 2022-06-22 06:32:53.116671
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF]) == [SBOX[x] for x in [0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF]]
    assert sub_bytes([0xE7, 0xE1, 0x72, 0x06, 0x77, 0xAF, 0xC0, 0xA2]) == [SBOX[x] for x in [0xE7, 0xE1, 0x72, 0x06, 0x77, 0xAF, 0xC0, 0xA2]]

# Generated at 2022-06-22 06:32:58.401354
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert(
        aes_decrypt_text(
            "COuOm/+X9QzZm8M1SJJzMg==",
            "my super secret password",
            24
        ) == b"Yay! I can decrypt text!"
    )
test_aes_decrypt_text()



# Generated at 2022-06-22 06:33:06.646677
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert(shift_rows_inv([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])
           == [0, 1, 2, 3, 5, 6, 7, 4, 10, 11, 8, 9, 15, 12, 13, 14])



# Generated at 2022-06-22 06:33:16.893586
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key =         [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                   0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F]
    counter = Counter(0)
    expected = [0xF7, 0xFB, 0x3F, 0x99, 0x76, 0x59, 0x3D, 0x6D,
                0x07, 0x39, 0x38, 0xF9, 0x8E, 0x83, 0x9D, 0x6B]

    encrypted = aes_ctr_encrypt(expected, key, counter)

# Generated at 2022-06-22 06:33:18.611276
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [x for x in range(16)]
    data_shifted = shift_rows_inv(shift_rows(data))
    assert(data == data_shifted)
    print("Unit test for function shift_rows_inv passed")

test_shift_rows_inv()


# Generated at 2022-06-22 06:33:30.253525
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    print("\n# Unit test for function aes_cbc_decrypt")

    key = bytes_to_intlist(compat_b64decode('gVn6pTCzemcH7vZ8FsRHxg=='))
    iv = bytes_to_intlist(compat_b64decode('iZ7dD1/xuLhS30YJmckMTA=='))
    cipher = bytes_to_intlist(compat_b64decode(
        '7kYjKquREy7M9XcT0V7KG2QdFRZ7xuZiS+f7YkgyLG3DqyGJNAbi4zK4ParOG4Zw'))

# Generated at 2022-06-22 06:33:40.199463
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns_inv(data)
    data_expected = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    print(data_mixed == data_expected)
test_mix_columns_inv()

# Generated at 2022-06-22 06:33:44.541927
# Unit test for function shift_rows
def test_shift_rows():
    assert shift_rows(list(range(16))) == [0, 4, 8, 12, 1, 5, 9, 1, 2, 6, 10, 14, 3, 7, 11, 15]


# Generated at 2022-06-22 06:33:46.461851
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert shift_rows_inv(shift_rows([0] * 16)) == [0] * 16



# Generated at 2022-06-22 06:33:49.123785
# Unit test for function rotate
def test_rotate():
    result = rotate([1, 2, 3, 4])
    assert result == [2, 3, 4, 1], 'Rotate failed'



# Generated at 2022-06-22 06:34:01.584234
# Unit test for function key_expansion
def test_key_expansion():
    from .aes_cipher import Cipher
    from .aes_constants import AES_KEY_SIZE
    from random import randint
    for i in range(len(AES_KEY_SIZE)):
        key_size_bytes = AES_KEY_SIZE[i]
        key = [randint(0,255) for _ in range(key_size_bytes)]
        expanded_key = key_expansion(key)
        assert len(expanded_key) == (key_size_bytes // 4 + 7) * BLOCK_SIZE_BYTES
        cipher = Cipher(expanded_key, i)
        # Test that the same expanded key is used for encryption and decryption
        ciphertext = cipher.encrypt(expanded_key)
        assert cipher.decrypt(ciphertext) == expanded_key
test_key_expansion

# Generated at 2022-06-22 06:34:11.775291
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns(data)
    assert data_mixed == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]



# Generated at 2022-06-22 06:34:28.995264
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vectors taken from https://en.wikipedia.org/wiki/Advanced_Encryption_Standard
    data = bytes_to_intlist(bytearray(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')))
    key = bytes_to_intlist(bytearray(compat_b64decode('YELLOW SUBMARINE')))
    iv = bytes_to_intlist([0] * BLOCK_SIZE_BYTES)

    data = aes_ctr_decrypt(data, key, Counter(iv))

# Generated at 2022-06-22 06:34:38.666618
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected_data = [0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    if mix_columns_inv(data) == expected_data:
        return True
    else:
        return False
print(test_mix_columns_inv())


# Generated at 2022-06-22 06:34:49.161566
# Unit test for function aes_encrypt
def test_aes_encrypt():
    plaintext = bytes_to_intlist(b'\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff')
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-22 06:34:57.862920
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist("Sample text")
    key = bytes_to_intlist("1234567890123456")
    iv = bytes_to_intlist("abcdefghijklmnop")

    encrypted_data = aes_cbc_encrypt(data, key, iv)
    expected_data = bytes_to_intlist("\x4C\x4C\x79\x6D\xA7\x6E\xA7\xD8\xE7\x6E\x10\x47\x3C\xB3\x67\x7B")

    assert encrypted_data == expected_data


# Generated at 2022-06-22 06:35:02.182566
# Unit test for function rotate
def test_rotate():
    data = [1,2,3,4]
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]
    assert rotate(data) == [2, 3, 4, 1]


# Generated at 2022-06-22 06:35:11.115710
# Unit test for function shift_rows
def test_shift_rows():
    data = [i for i in range(16)]
    row_shifted = shift_rows(data)

    expected = [i for i in range(16)]

    for i in range(4):
        expected[i], expected[i + 4], expected[i + 8], expected[i + 12] = expected[(i & 0b11) * 4 + i], expected[((i + 1) & 0b11) * 4 + i], expected[((i + 2) & 0b11) * 4 + i], expected[((i + 3) & 0b11) * 4 + i]

    assert row_shifted == expected



# Generated at 2022-06-22 06:35:15.606716
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key = [0x2b, 0x28, 0xab, 0x09]
    assert key_schedule_core(key, 1) == [0xA4, 0x68, 0x6B, 0x02]



# Generated at 2022-06-22 06:35:26.741140
# Unit test for function inc
def test_inc():
    inp = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    assert inc(inp) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]
    inp = [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    assert inc(inp) == [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]
    inp = [255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
   

# Generated at 2022-06-22 06:35:36.515221
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x00, 0x11, 0x22, 0x33]) == [0x00, 0x44, 0x88, 0xcd], "sub_bytes test 1 failed"
    assert sub_bytes([0xff, 0xee, 0xdd, 0xcc]) == [0xff, 0xbb, 0x77, 0x33], "sub_bytes test 2 failed"
    assert sub_bytes([0x62, 0x9b, 0x01, 0xb1]) == [0x62, 0x04, 0xd2, 0xaf], "sub_bytes test 3 failed"
    print("sub_bytes passed all tests")
test_sub_bytes()



# Generated at 2022-06-22 06:35:46.750407
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # key = 0x000102030405060708090a0b0c0d0e0f
    cyphertext_ecb = [0x6c, 0xc2, 0x48, 0x8a, 0x7a, 0x90, 0x49, 0x3f, 0xf3, 0xd2, 0xc8, 0xe9, 0x2c, 0x59, 0xe8, 0x00]
    data = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]

# Generated at 2022-06-22 06:36:05.441986
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    assert mix_columns_inv([0x02, 0x03, 0x01, 0x01,
                            0x01, 0x02, 0x03, 0x01,
                            0x01, 0x01, 0x02, 0x03,
                            0x03, 0x01, 0x01, 0x02]) == [0x0E, 0x0B, 0x0D, 0x09,
                                                        0x09, 0x0E, 0x0B, 0x0D,
                                                        0x0D, 0x09, 0x0E, 0x0B,
                                                        0x0B, 0x0D, 0x09, 0x0E]

# Generated at 2022-06-22 06:36:16.592418
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
	encryptedData = bytes_to_intlist(compat_b64decode(
		'U2FsdGVkX1/rI2U6+FkcJi8WO4N9XQiPC1ZVzvf8sCdT/kLZXiT7bIR/YvcYa7nB'))
	#print(encryptedData)
	key = bytes_to_intlist(b'1234567890123456')
	iv = [] # 16-Byte initialization vector
	for i in range(len(key)):
		iv.append(0)
	#print(iv)
	decryptedData = aes_cbc_decrypt(encryptedData,key,iv)
	decryptedDataStr = intlist_to_bytes(decryptedData)
	#print(decryptedData

# Generated at 2022-06-22 06:36:28.145718
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from . import aes

    key = aes._aes_key_expansion(list(bytes_to_intlist(b'140b41b22a29beb4061bda66b6747e14')))

# Generated at 2022-06-22 06:36:31.229734
# Unit test for function rotate
def test_rotate():
    assert rotate([0, 1]) == [1, 0]
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]



# Generated at 2022-06-22 06:36:35.843152
# Unit test for function inc
def test_inc():
    data1 = [0]*16
    assert inc(data1) == [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1]
    data2 = [255]*16
    assert inc(data2) == [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    data3 = [1,255,0,0,0,0,0,0,0,0,0,0,0,0,255,255]
    assert inc(data3) == [2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]



# Generated at 2022-06-22 06:36:44.869988
# Unit test for function aes_decrypt

# Generated at 2022-06-22 06:36:54.710827
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0xf2, 0xd4, 0x6f, 0x45, 0xf1, 0x43, 0x58, 0x7e, 0xab, 0xa2, 0x2e, 0x85, 0x4d, 0x92, 0x7a]
    data_mixed = mix_columns(data)
    if data_mixed == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08]:
        return True
    else:
        return False
test_mix_columns()


# Generated at 2022-06-22 06:37:02.846267
# Unit test for function sub_bytes
def test_sub_bytes():
    assert sub_bytes([0x19, 0x3d, 0xe3, 0xbe, 0xa0, 0xf4, 0xe2, 0x2b, 0x9a, 0xc6, 0x8d, 0x2a, 0xe9, 0xf8, 0x48, 0x08]) == [0xd4, 0xe0, 0xb8, 0x1e, 0x27, 0xbf, 0xb4, 0x41, 0x11, 0x98, 0x5d, 0x52, 0xae, 0xf1, 0xe5, 0x30]


# Generated at 2022-06-22 06:37:14.160167
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0xf2, 0xd4, 0x6f, 0x45, 0x9f, 0x98, 0xba, 0x75, 0xdc, 0x84, 0xdd, 0xd9, 0x7d, 0x24, 0x70]
    d1 = [0x02, 0x03, 0x01, 0x01, 0x01, 0x02, 0x03, 0x01, 0x01, 0x01, 0x02, 0x03, 0x03, 0x01, 0x01, 0x02]
    print(mix_columns(data))
    print(d1)
    assert(mix_columns(data) == d1)
    print("===== Unit test for function mix_columns: PASSED =====")


# Generated at 2022-06-22 06:37:22.191892
# Unit test for function xor
def test_xor():
    assert xor([0x00, 0x00, 0x00, 0x00], [0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x00]
    assert xor([0x31, 0x32, 0x33, 0x34], [0xab, 0x00, 0x00, 0xcd]) == [0x9a, 0x32, 0x33, 0xe9]



# Generated at 2022-06-22 06:37:31.430827
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    data_shifted = shift_rows_inv(data)

    for row in range(4):
        for column in range(4):
            assert data_shifted[row * 4 + column] == data[row + 4 * column]
test_shift_rows_inv()

# Generated at 2022-06-22 06:37:40.054589
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist(compat_b64decode('g9YVOzI1eDlwJQ2PvJShI+upNWn0+d1x8xFJX9qY3Y=')[:16])
    data = bytes_to_intlist('469466426559217e4392809d0a403b15'.decode('hex'))
    encrypted = aes_encrypt(data, key_expansion(key))
    assert intlist_to_bytes(aes_decrypt(encrypted, key_expansion(key))) == intlist_to_bytes(data)


# Generated at 2022-06-22 06:37:50.917847
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """ Aes cbc decrypt a string
    """
    iv = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    key = [4, 2, 1, 2, 3, 2, 4, 2, 1, 2, 3, 2, 4, 2, 1, 2]
    data = [1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4]
    data = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]

# Generated at 2022-06-22 06:37:59.695901
# Unit test for function aes_encrypt
def test_aes_encrypt():
    msg = b64decode('lT9x6Uo6cCpjwffm6m/U6w==')
    key = b64decode('Tk1MkIXTlpNQ1JWWVNPQg==')
    c = aes_encrypt(bytes_to_intlist(msg), bytes_to_intlist(key))
    c = intlist_to_bytes(c)
    print(c)
    assert c == b64decode('4V7hGLOHnr4YVJ+E9XSfVg==')


# Generated at 2022-06-22 06:38:06.536176
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]
    mixed = mix_column(data, MIX_COLUMN_MATRIX)
    mixed = mix_column(mixed, MIX_COLUMN_MATRIX_INV)
    assert mixed == data



# Generated at 2022-06-22 06:38:10.355244
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    text = aes_decrypt_text('EK/CCKr1uNXMXFQ2VuLJbg==', 'whatpassword', 16)
    assert text == 'AES encryption is awesome'
    print('AES decryption test passed')


# Generated at 2022-06-22 06:38:22.077476
# Unit test for function inc
def test_inc():
    test_vector = [0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x00]
    for i in range(16):
        inc_test_vector = inc(test_vector[i:])
        if i == 15:
            expected_vector = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01]

# Generated at 2022-06-22 06:38:27.920842
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key = [0x2b, 0x28, 0xab, 0x09]
    expected = [0xb0, 0xa0, 0x02, 0x69]
    assert key_schedule_core(key, 1) == expected
    print("Test key_schedule_core: PASS")

test_key_schedule_core()


# Generated at 2022-06-22 06:38:30.244545
# Unit test for function sub_bytes
def test_sub_bytes():
    x = [0 for i in range(16)]
    assert sub_bytes(x) == SBOX
    return True

# Generated at 2022-06-22 06:38:40.919915
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
          0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-22 06:39:03.476003
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    def encrypt(text):
        return aes_decrypt_text(aes_encrypt_text(text, 'test'), 'test', 16)
    assert 'hello, world!'.encode('utf-8') == encrypt('hello, world!')
    assert 'hello, world!'.encode('utf-8') == encrypt(u'hello, world!')
    assert 'hello, world!'.encode('utf-8') == encrypt('hello, world!')
    assert 'hello, world!'.encode('utf-8') == encrypt(u'hello, world!')
    print('aes_decrypt_text: OK')

if __name__ == '__main__':
    test_aes_decrypt_text()

