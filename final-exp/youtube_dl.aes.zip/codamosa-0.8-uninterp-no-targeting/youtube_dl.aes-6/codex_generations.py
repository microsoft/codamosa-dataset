

# Generated at 2022-06-22 06:29:20.061320
# Unit test for function shift_rows
def test_shift_rows():
    data = (0x8e, 0x20, 0xfa, 0x2b, 0xca, 0x34, 0x2b, 0xbd, 0xf3, 0xd0, 0x11, 0x47, 0x7f, 0xa9, 0x4a, 0x0d)
    print(shift_rows(data))



# Generated at 2022-06-22 06:29:25.577711
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-22 06:29:29.281765
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range(0xFF):
        for b in range(0xFF):
            assert rijndael_mul(a, b) == mul(a, b, RIJNDAEL_EXP_TABLE, RIJNDAEL_LOG_TABLE)



# Generated at 2022-06-22 06:29:35.034240
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter:
        def __init__(self, initial_value):
            self.value = initial_value

        def next_value(self):
            block = [ord(c) for c in self.value]
            block = block + [0] * (BLOCK_SIZE_BYTES - len(block))

            # Increment counter
            self.value = self.value or chr(0)
            self.value = chr(ord(self.value[0]) + 1)
            return block

    counter = Counter('')
    data = bytes_to_intlist(compat_b64decode('ZDhkZWE5YjEzYmM5Njg5ZmJlNTFkYjcyZjZkOTY1YzY='))

# Generated at 2022-06-22 06:29:41.148553
# Unit test for function mix_columns
def test_mix_columns():
    rnd = random.Random(0)
    column = [rnd.getrandbits(8) for i in range(4)]
    mixed_column = mix_columns(column)
    return mixed_column == [0xeb, 0x3a, 0xb9, 0x4f]

print(test_mix_columns())


# Generated at 2022-06-22 06:29:48.092963
# Unit test for function key_expansion
def test_key_expansion():
    for k in [16, 24, 32]:
        for i in range(10):
            key = [compat_b64decode(''.join(('%02x' % j) * k)) for j in range(1, k+1)]
            key = bytes_to_intlist(key)

            expanded_key = key_expansion(key)

            assert len(expanded_key) == (k // 4 + 6) * BLOCK_SIZE_BYTES



# Generated at 2022-06-22 06:29:50.737391
# Unit test for function xor
def test_xor():
    data1 = [0x00, 0x00, 0x00, 0x00]
    data2 = [0x01, 0x01, 0x01, 0x01]
    expected_output = [0x01, 0x01, 0x01, 0x01]
    assert xor(data1, data2) == expected_output



# Generated at 2022-06-22 06:29:54.877227
# Unit test for function rotate
def test_rotate():
    assert (rotate([1, 2, 3, 4]) == [2, 3, 4, 1])
    assert (rotate([1, 2, 3, 4, 64]) == [2, 3, 4, 64, 1])



# Generated at 2022-06-22 06:30:02.694462
# Unit test for function rotate
def test_rotate():
    assert rotate([0x01, 0x02, 0x03, 0x04]) == [0x02, 0x03, 0x04, 0x01]
    assert rotate([0xFF, 0xFF, 0xFF, 0xFF]) == [0xFF, 0xFF, 0xFF, 0xFF]
    assert rotate([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x00]

# Generated at 2022-06-22 06:30:12.067354
# Unit test for function key_expansion
def test_key_expansion():
    import base64
    key = bytes_to_intlist(compat_b64decode('/J0nX/+t1q3qJp83r1LJgHdx9c+JzQ2RlGZfzYaA8Y0='))
    assert intlist_to_bytes(key_expansion(key)) == compat_b64decode('LDp8dCh/xl+L0Pndh/v0X8WJ+Z1zNPDV0o0YQTh8W7xuLQy+S6imJ1v06ijTInq3mDZmV7BHJbMhP7uB2QcU6SdTpxjsCXHfkqD3sz4VuDvw==')
    key = bytes_to_intlist

# Generated at 2022-06-22 06:30:25.414478
# Unit test for function sub_bytes

# Generated at 2022-06-22 06:30:32.540496
# Unit test for function xor
def test_xor():
    l1 = [x for x in range(0, 16)]
    l2 = [x for x in range(16, 32)]
    l3 = xor(l1,l2)
    for i in range(0, len(l3)):
        if l3[i] != l1[i]^l2[i]:
            print("Test XOR failed", l3[i], " != ", l1[i]^l2[i])
            return False
    return True

# Generated at 2022-06-22 06:30:38.051255
# Unit test for function mix_column
def test_mix_column():
    data = [0xdb, 0x13, 0x53, 0x45]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    expected_data_mixed = [0x8e, 0x4d, 0xa1, 0xbc]
    if data_mixed != expected_data_mixed:
        print('Test case of mix_column failed')



# Generated at 2022-06-22 06:30:40.758655
# Unit test for function mix_column
def test_mix_column():
    data = [0xFF, 0xFF, 0xFF, 0xFF]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    for i in range(4):
        assert(data_mixed[i] == 0xFF)
    print("unit test for mix_column passed")
test_mix_column()



# Generated at 2022-06-22 06:30:42.786273
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert shift_rows_inv(shift_rows([0] * 16)) == [0] * 16



# Generated at 2022-06-22 06:30:50.084174
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x83) == 0xc1
    assert rijndael_mul(0x83, 0x57) == 0xc1
    assert rijndael_mul(0x57, 0x13) == 0xfe
    assert rijndael_mul(0x13, 0x57) == 0xfe
    assert rijndael_mul(0x13, 0x01) == 0x13
    assert rijndael_mul(0x01, 0x13) == 0x13
    assert rijndael_mul(0xcf, 0x01) == 0xcf
    assert rijndael_mul(0xab, 0xcd) == 0x58

# Generated at 2022-06-22 06:30:59.720741
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0xab, 0xab, 0xab, 0xab]
    data_mixed = mix_columns_inv(data)
    data_unmixed = mix_columns(data_mixed)
    print(["%02x" % x for x in data])
    print(["%02x" % x for x in data_mixed])
    print(["%02x" % x for x in data_unmixed])



# Generated at 2022-06-22 06:31:09.459364
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist(b"v\xa1\x0b\x06\xdb\xaa\x98\xc8\x81\x9b\x3d\x8e\x3c\x3a\x81\x8b\xa2\xbc\x1a\x02\xa8\x81\x9b\x9f\xea\xaf\x5c\x5e\x25\x0e\xc4\x4b")
    iv = bytes_to_intlist(b"\x38\x41\x45\x80\x39\xf2\x9f\x1d\x85\x7f\x3b\x45\x62\x92\x82\x9a")

# Generated at 2022-06-22 06:31:16.087817
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    expected = [151, 131, 178, 241, 57, 240, 48, 145, 234, 14, 105, 217, 240, 238, 202, 13]
    iv = [0] * 16
    key = [i%256 for i in range(16)]
    data = [i%256 for i in range(16)]
    decrypted = aes_cbc_decrypt(data, key, iv)
    print(decrypted)
    assert decrypted == expected
   


# Generated at 2022-06-22 06:31:22.186363
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expect_data = [0x8E, 0x4D, 0xA1, 0xBC, 0x9F, 0xDC, 0x58, 0x9D, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert (mix_columns_inv(data) == expect_data)



# Generated at 2022-06-22 06:31:30.998622
# Unit test for function aes_decrypt
def test_aes_decrypt():
    for key in [b'\x00' * 16, b'\x00' * 24, b'\x00' * 32]:
        print(aes_decrypt(aes_encrypt(b'\x00' * 16, key_expansion(key)), key_expansion(key)))

    # add more tests here



# Generated at 2022-06-22 06:31:40.140122
# Unit test for function mix_column
def test_mix_column():
    data1 = [0x02, 0x03, 0x01, 0x01]
    assert(mix_column(data1, MIX_COLUMN_MATRIX) == [0x04, 0x01, 0x01, 0x02])
    data2 = [0x63, 0x53, 0xe0, 0x8c]
    assert(mix_column(data2, MIX_COLUMN_MATRIX) == [0x5f, 0x72, 0xc0, 0xd8])



# Generated at 2022-06-22 06:31:50.949183
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import sys
    try:
        _input = raw_input
    except NameError:
        _input = input
    if sys.version_info >= (3, 0):
        _input = eval('input')
    if sys.version_info >= (3, 0):
        password = bytes(_input("password: "), 'utf-8')
    else:
        password = _input("password: ")
    encrypted = bytes_to_intlist(compat_b64decode("RmB+ntsxz75w3A4ppvJH+jOc1CWaQT0Sb96R9YpOMoI=", "utf-8"))
    key_size_bytes = 32

# Generated at 2022-06-22 06:31:56.442001
# Unit test for function key_schedule_core
def test_key_schedule_core():
    byte_data = [0x00, 0x00, 0x00, 0x00]
    data1 = key_schedule_core(byte_data, 1)
    print(data1)
    data2 = key_schedule_core(data1, 1)
    print(data2)

test_key_schedule_core()



# Generated at 2022-06-22 06:32:08.900192
# Unit test for function key_expansion
def test_key_expansion():
    assert bytes_to_intlist(compat_b64decode('Rmcgdh1lRRyAsj+EW22vUKDCjAco+1ASXhV7xuZfKjI=')) == key_expansion([0] * 32)
    assert bytes_to_intlist(compat_b64decode('dHUuKjUgmczJ0C6poU6rKkrBpZT6PZU0/2bGo/sYsKs=')) == key_expansion([1] * 32)
    assert bytes_to_intlist(compat_b64decode('8y7VuOvwFtCq3t3q8XElWb5vdrR5E5b5i5B5zKL+vDQ=')) == key_expansion

# Generated at 2022-06-22 06:32:16.156434
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0xCA, 0xFE, 0xBA, 0xBE, 0xDE, 0xAD, 0xBE, 0xEF]
    output = sub_bytes(data)
    expected = [0x73, 0x7D, 0x95, 0x05, 0x67, 0x26, 0xF5, 0xE0]
    assert (output == expected)

#def inv_sub_bytes(data):
#    return [SBOX_INV[x] for x in data]

# Generated at 2022-06-22 06:32:22.984625
# Unit test for function mix_column
def test_mix_column():
    for column_num in range(4):
        for row_num in range(4):
            assert(mix_column([4,4,4,4], MIX_COLUMN_MATRIX)[row_num] == mix_column([column_num+1,4,4,4], MIX_COLUMN_MATRIX)[column_num])

test_mix_column()


# Generated at 2022-06-22 06:32:34.373590
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test function aes_decrypt_text
    """
    password = 'test' * 4
    key_size_bytes = 16
    data = 'ykZan8gZExbD42q3LX1Jm0A8iCZuw1JxK7thTpTlCFr7i14LnoGXV7ZeOIb2QV7B'

    plaintext = aes_decrypt_text(data, password, key_size_bytes)

    assert plaintext == '1234567890', 'Decryption failed'
# Test for function aes_decrypt_text
test_aes_decrypt_text()



# Generated at 2022-06-22 06:32:45.665593
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x13) == 0xc1
    assert rijndael_mul(0xC1, 0x03) == 0x42
    assert rijndael_mul(0xC1, 0x01) == 0xC1
    assert rijndael_mul(0x13, 0x13) == 0xFE
    assert rijndael_mul(0x13, 0x01) == 0x13
    assert rijndael_mul(0x01, 0x01) == 0x01
    assert rijndael_mul(0x01, 0x02) == 0x02
    assert rijndael_mul(0x01, 0x03) == 0x03

# Generated at 2022-06-22 06:32:55.774035
# Unit test for function xor
def test_xor():
    data1 = [0x1, 0x3, 0x3, 0x7]
    data2 = [0x2, 0x4, 0x6, 0x8]
    assert xor(data1, data2) == [0x3, 0x7, 0x5, 0xF]
    data1 = [0x2, 0x4, 0x6, 0x8]
    data2 = [0x2, 0x4, 0x6, 0x8]
    assert xor(data1, data2) == [0x0, 0x0, 0x0, 0x0]



# Generated at 2022-06-22 06:33:03.658115
# Unit test for function xor
def test_xor():
    assert xor([0x01, 0x01, 0x01, 0x01], [0x01, 0x01, 0x01, 0x01]) == [0x00, 0x00, 0x00, 0x00]



# Generated at 2022-06-22 06:33:08.038153
# Unit test for function inc
def test_inc():
    assert(inc([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x01])
    assert(inc([0x00, 0x00, 0x00, 0xff]) == [0x00, 0x00, 0x01, 0x00])
    assert(inc([0x00, 0x00, 0xff, 0xff]) == [0x00, 0x01, 0x00, 0x00])
    assert(inc([0x00, 0xff, 0xff, 0xff]) == [0x01, 0x00, 0x00, 0x00])
    assert(inc([0xff, 0xff, 0xff, 0xff]) == [0x00, 0x00, 0x00, 0x00])
    print('Teste inc() Ok')

# Generated at 2022-06-22 06:33:18.994572
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Block 1
    data = bytes_to_intlist(compat_b64decode('LTZfNX9dYtS1f0RlBtCwBw=='))

# Generated at 2022-06-22 06:33:30.280164
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key =      '2b7e151628aed2a6abf7158809cf4f3c'
    cipher =   '3925841d02dc09fbdc118597196a0b32'
    expected = '6bc1bee22e409f96e93d7e117393172a'
    key = bytes_to_intlist(compat_b64decode(key))
    cipher = bytes_to_intlist(compat_b64decode(cipher))
    expected = intlist_to_bytes(bytes_to_intlist(compat_b64decode(expected)))
    expanded_key = key_expansion(key)
    p = aes_decrypt(cipher, expanded_key)
    print(p)
    print(intlist_to_bytes(p))

# Generated at 2022-06-22 06:33:36.044238
# Unit test for function rotate
def test_rotate():
    assert rotate([0, 1, 2, 3]) == [1, 2, 3, 0]
    assert rotate([0, 1, 2, 3, 4]) == [1, 2, 3, 4, 0]
    assert rotate([0]) == [0]
    assert rotate(['a', 'b', 'c', 'd']) == ['b', 'c', 'd', 'a']



# Generated at 2022-06-22 06:33:36.852194
# Unit test for function inc
def test_inc():
    return inc([255, 255, 255]) == [0, 0, 0]

print(test_inc())



# Generated at 2022-06-22 06:33:48.565716
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert (sub_bytes_inv(sub_bytes([0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f,0x10])) == [0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f,0x10])

test_sub_bytes_inv()

# Generated at 2022-06-22 06:33:54.890283
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]
    assert shift_rows_inv(shift_rows(data)) == data
    
test_shift_rows_inv()

# Generated at 2022-06-22 06:34:06.529655
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # encrypt with aes_encrypt
    data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    expanded_key = key_expansion(key)
    print('encrypted:', aes_encrypt(data, expanded_key))
    # decrypt with aes_decrypt
    data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    key

# Generated at 2022-06-22 06:34:14.542155
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data_to_test = [0x3C, 0x4C, 0x50, 0x15, 0x3B, 0x3E, 0x53, 0x5C, 0x35, 0x28, 0x56, 0x1A, 0x55, 0x39, 0x5B, 0x10]
    mixed_data = mix_columns(data_to_test)
    mixed_data_inv = mix_columns_inv(mixed_data)
    assert(data_to_test == mixed_data_inv)

# Generated at 2022-06-22 06:34:23.878272
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data_in = [0x01, 0x02, 0x03, 0x04]
    data_out = key_schedule_core(data_in, 1)
    assert(data_out == [0x02, 0x03, 0x04, 0x01])

test_key_schedule_core()



# Generated at 2022-06-22 06:34:26.864426
# Unit test for function rotate
def test_rotate():
    assert rotate([0x05, 0x0A, 0x0F, 0x04]) == [0x0A, 0x0F, 0x04, 0x05]



# Generated at 2022-06-22 06:34:37.960718
# Unit test for function key_expansion
def test_key_expansion():
    key_128 = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]
    key_192 = [0x8E, 0x73, 0xB0, 0xF7, 0xDA, 0x0E, 0x64, 0x52, 0xC8, 0x10, 0xF3, 0x2B, 0x80, 0x90, 0x79, 0xE5,
               0x62, 0xF8, 0xEA, 0xD2, 0x52, 0x2C, 0x6B, 0x7B]
    key_

# Generated at 2022-06-22 06:34:48.784683
# Unit test for function aes_encrypt
def test_aes_encrypt():
    cipher_key = [212, 215, 202, 199, 161, 163, 187, 191, 140, 141, 222, 232, 151, 146, 147, 153, 90, 130, 150, 169, 76, 82, 66, 59, 60, 77, 142, 89, 251, 209, 251, 132]
    state = [69, 110, 72, 102, 243, 196, 1, 198, 117, 220, 147, 22, 252, 206, 172, 30]

# Generated at 2022-06-22 06:34:55.083985
# Unit test for function key_schedule_core
def test_key_schedule_core():
    key = [0x2b, 0x28, 0xab, 0x09]
    result = key_schedule_core(key, 1)
    correct = [0xa4, 0x68, 0x6b, 0x02]
    print("{} is correct: {}".format(result, result == correct))

#test_key_schedule_core()


# Generated at 2022-06-22 06:35:06.196601
# Unit test for function key_expansion
def test_key_expansion():
    key = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]
    round_key = key_expansion(key)

# Generated at 2022-06-22 06:35:11.432581
# Unit test for function mix_columns
def test_mix_columns():
    text = [0x02, 0x03, 0x01, 0x01,
            0x01, 0x02, 0x03, 0x01,
            0x01, 0x01, 0x02, 0x03,
            0x03, 0x01, 0x01, 0x02]
    print(mix_columns(text))



# Generated at 2022-06-22 06:35:14.151546
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3]) == [2,3,1]
    assert rotate([0,0,0]) == [0,0,0]


# Generated at 2022-06-22 06:35:26.289546
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = b'vJ8BZWwDbgjTtTkJtTv8tT0qgqZaQjXaTLvHtTTWqMwgqCjRqLg=='
    password = 'password'
    plaintext = aes_decrypt_text(data, password, key_size_bytes=16)
    assert plaintext == b'Plaintext'

    data = b'vJ8BZWwDbgjTtTkJtTv8tT0qgqZaQjXaTLvHtTTWqMwgqCjRqLg=='
    password = 'very-long-password'
    plaintext = aes_decrypt_text(data, password, key_size_bytes=24)

# Generated at 2022-06-22 06:35:37.134915
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert(mix_columns_inv(data) == [0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08, 0x08])

# Generated at 2022-06-22 06:35:48.661048
# Unit test for function mix_columns
def test_mix_columns():
    m1 = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    m2 = [0x8e, 0xa2, 0xb7, 0xc1, 0x8e, 0xa2, 0xb7, 0xc1, 0x8e, 0xa2, 0xb7, 0xc1, 0x8e, 0xa2, 0xb7, 0xc1]

# Generated at 2022-06-22 06:35:50.731179
# Unit test for function rotate
def test_rotate():
    assert rotate([1,2,3,4]) == [2,3,4,1]
    assert rotate([11,22,33,44]) == [22,33,44,11]
    assert rotate([111, 222, 333, 444]) == [222, 333, 444, 111]


# Generated at 2022-06-22 06:36:02.868074
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = bytes_to_intlist(compat_b64decode(b'Z3VucwAAAAAAAOcAAACNAAAAbgAAAAFzAAADNQAAAwUAAAMZAAAAGQAAAAtzAAAC3AAAAxUAAANJAAAAHQAAADn'))
    counter = AESCounter(bytes_to_intlist(compat_b64decode(b'AAAAAAAAAAAAAAAA')))
    cipher = bytes_to_intlist(compat_b64decode(b'/+MYqz3T3y3yVvhClLKZj9RkUeuoZKsaaW4vMzVRJviqwjw=='))
    plain = aes_ctr_decrypt(cipher, key, counter)

# Generated at 2022-06-22 06:36:14.480145
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = bytearray([0x63, 0xCA, 0xB7, 0x04, 0x09, 0x53, 0xD0, 0x51, 
                      0xCD, 0x60, 0xE0, 0xE7, 0xBA, 0x70, 0xE1, 0x8C])
    res = shift_rows_inv(data)
    data_inv = bytearray([0x63, 0x7C, 0x77, 0x7B, 0xF2, 0x6B, 0x6F, 0xC5, 
                          0x30, 0x01, 0x67, 0x2B, 0xFE, 0xD7, 0xAB, 0x76])
    assert(res == data_inv)



# Generated at 2022-06-22 06:36:23.900316
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import binascii

# Generated at 2022-06-22 06:36:28.135424
# Unit test for function inc
def test_inc():
    print("Test inc: ")
    print(inc([0,0,0,0]))
    print(inc([1,0,0,0]))
    print(inc([1,2,0,0]))
    print(inc([1,2,3,0]))
    print(inc([1,2,3,4]))
    print(inc([0,0,0,255]))
    print(inc([0,0,255,255]))
    print(inc([0,255,255,255]))
    print(inc([255,255,255,255]))
    print("")


# Generated at 2022-06-22 06:36:33.745012
# Unit test for function inc
def test_inc():
    assert inc(bytearray.fromhex("01")) == bytearray.fromhex("02")
    assert inc(bytearray.fromhex("10")) == bytearray.fromhex("11")
    assert inc(bytearray.fromhex("ff")) == bytearray.fromhex("00")
    assert inc(bytearray.fromhex("ff ff ff ff")) == bytearray.fromhex("00 00 00 00")
    assert inc(bytearray.fromhex("11 ff ff ff")) == bytearray.fromhex("12 00 00 00")
    assert inc(bytearray.fromhex("ff ff ff 00")) == bytearray.fromhex("00 00 00 01")



# Generated at 2022-06-22 06:36:37.302641
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = list(range(16))
    data_shifted = shift_rows_inv(shift_rows(data))
    print('Test shift row')
    print(data == data_shifted)



# Generated at 2022-06-22 06:36:45.478479
# Unit test for function aes_decrypt

# Generated at 2022-06-22 06:36:55.538518
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # this test is taken from the jschlack code
    # https://github.com/Anorov/jschlack
    data = bytes_to_intlist('10000000000000010000000000000000000000000000001')
    key = bytes_to_intlist('000000000000000000000000000000000000000000000000')
    iv = bytes_to_intlist('0123456789abcdefff0123456789abcde')

    output = aes_cbc_encrypt(data, key, iv)
    output_str = intlist_to_bytes(output)


# Generated at 2022-06-22 06:37:11.589200
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    actual_key = bytes_to_intlist(compat_b64decode(
        b"7Dlvbe4I4aeJjw65RnE+p1FGb5axzE8g"))
    actual_iv = bytes_to_intlist(compat_b64decode(
        b"jKuQy8WgYXHEvGpO67cJjA=="))
    cipher = bytes_to_intlist(compat_b64decode(
        b"K6hfUxCeZ6q274U6+6g+eQ=="))
    decrypted = aes_cbc_decrypt(cipher, actual_key, actual_iv)
    print(intlist_to_bytes(decrypted))


# Generated at 2022-06-22 06:37:20.274460
# Unit test for function mix_column
def test_mix_column():
    data = [127, 2, 3, 4]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    expected = [166, 120, 22, 184]
    for x, y in zip(data_mixed, expected):
        if(x != y):
            print(x, y)
    for row in range(4):
        mixed = 0
        for column in range(4):
            # xor is (+) and (-)
            mixed ^= rijndael_mul(expected[column], MIX_COLUMN_MATRIX_INV[row][column])
        assert(data[row] == mixed)
    print('test mix_column pass!')


# Generated at 2022-06-22 06:37:31.834286
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-22 06:37:42.493831
# Unit test for function xor
def test_xor():
    assert xor([0x00, 0x00, 0x00, 0x00], [0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x0]
    assert xor([0x00, 0x00, 0x00, 0x00], [0xFF, 0xFF, 0xFF, 0xFF]) == [0xFF, 0xFF, 0xFF, 0xFF]
    assert xor([0xFF, 0xFF, 0xFF, 0xFF], [0x00, 0x00, 0x00, 0x00]) == [0xFF, 0xFF, 0xFF, 0xFF]

# Generated at 2022-06-22 06:37:53.235479
# Unit test for function sub_bytes
def test_sub_bytes():
    """test_sub_bytes"""
    data = [0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb]
    res_list = sub_bytes(data)

# Generated at 2022-06-22 06:38:04.888583
# Unit test for function key_expansion
def test_key_expansion():
    data16 = bytes_to_intlist(compat_b64decode('VJPmHcZomK07m8Bx/i7m43g=='))
    data24 = bytes_to_intlist(compat_b64decode('VJPmHcZomK07m8Bx/i7m4l9qUzHpZAvA'))
    data32 = bytes_to_intlist(compat_b64decode('VJPmHcZomK07m8Bx/i7m4l9qUzHpZAvAjyL7B1fQ2Dc='))


# Generated at 2022-06-22 06:38:09.202885
# Unit test for function shift_rows
def test_shift_rows():
     data = [7] * 16
     data_shifted = shift_rows(data)
     expected_shifted = [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
     print(data_shifted)
     assert data_shifted == expected_shifted


# Generated at 2022-06-22 06:38:20.847784
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11,
           0x12, 0x13, 0x14, 0x15, 0x16, 0x17]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-22 06:38:26.272619
# Unit test for function shift_rows
def test_shift_rows():
    from random import shuffle
    data = [i for i in range(16)]
    for i in range(100):
        assert shift_rows(shift_rows(data)) == data
        assert shift_rows(shift_rows(data)) == shift_rows(data)
        shuffle(data)



# Generated at 2022-06-22 06:38:33.734074
# Unit test for function inc
def test_inc():
    # increment value 1 byte
    print(inc([1]))
    # increment value 4 byte
    print(inc([1, 0, 255, 0]))
    # increment value 16 byte
    print(inc([1, 0, 255, 0, 1, 0, 255, 0, 1, 0, 255, 0, 1, 0, 255, 0]))
    # increment value 255 byte
    data = [1]
    for i in range(0, 255):
        data += [0]
    # data[-1] = 254
    print(inc(data))



# Generated at 2022-06-22 06:38:46.263142
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text(b'QUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQQ==', 'password', 16) == b'1' * 64
    assert aes_decrypt_text(b'QUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFQ==', 'password', 16) == b'1' * 64 + b'2'



# Generated at 2022-06-22 06:38:56.629393
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = b'hello world!'
    key = b'Sixteen byte key'
    iv = b'Sixteen byte iv!'

    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert encrypted_data == b'\x7f\xb3\x0c\x0d\xfb\xfc\x27\x7a\xbd\xcb\x6e\x1a\xcd\x9b\x4e\xee\x7e\x8c\xe2\xc0\x09\x44\x8b\x9f\x4d\x4b\x8f\x91\x39\x3c'



# Generated at 2022-06-22 06:39:08.001712
# Unit test for function aes_decrypt
def test_aes_decrypt():

    data = [0x69, 0x20, 0xe2, 0x99, 0xa5, 0x20, 0x2a, 0x6d, 0x65, 0x6e, 0x63, 0x68, 0x69, 0x74, 0x6f, 0x2a]