

# Generated at 2022-06-22 06:29:25.635239
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Test vector from https: //en.wikipedia.org/wiki/Advanced_Encryption_Standard
    key = bytes_to_intlist('00112233445566778899aabbccddeeff')
    data = bytes_to_intlist('00112233445566778899aabbccddeeff')
    expanded_key = key_expansion(key)

# Generated at 2022-06-22 06:29:37.415706
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .keycounter import KeyCounter
    from .aes import sub_bytes, shift_rows, mix_columns, add_round_key
    class Counter(object):
        def __init__(self):
            self.index = -1
        def next_value(self):
            self.index += 1
            counter_block = key_expansion(key)[self.index * BLOCK_SIZE_BYTES: (self.index + 1) * BLOCK_SIZE_BYTES]
            return sub_bytes(shift_rows(mix_columns(add_round_key(counter_block, key_expansion(key)))))


# Generated at 2022-06-22 06:29:43.949966
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print("[+] Testing rijndael_mul...")
    assert rijndael_mul(0x57, 0x83) == 0xC1
    assert rijndael_mul(0x83, 0x57) == 0xC1
    print("[+] Tests passed!")

test_rijndael_mul()


# Generated at 2022-06-22 06:29:52.433222
# Unit test for function mix_columns

# Generated at 2022-06-22 06:29:58.149044
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    print('test_mix_columns_inv')
    data = [0xdb, 0x13, 0x53, 0x45,
            0xf2, 0x0a, 0x22, 0x5c,
            0x01, 0x01, 0x01, 0x01,
            0xab, 0xab, 0xab, 0xab]
    output = mix_columns_inv(data)
    print(output)
    print(hex(output[0]))

# Generated at 2022-06-22 06:30:03.966160
# Unit test for function aes_decrypt_text

# Generated at 2022-06-22 06:30:15.055685
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # verlinkt
    data = bytes_to_intlist(compat_b64decode('QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F'))
    expanded_key = bytes_to_intlist(compat_b64decode('QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLw=='))
    assert aes_encrypt(data, expanded_key) == [32, 83, 74, 24, 3, 125, 122, 60, 16, 64, 137, 113, 82, 132, 12, 119]

    # Wikipedia


# Generated at 2022-06-22 06:30:26.347354
# Unit test for function aes_decrypt
def test_aes_decrypt():
    iv = [17,  110, 156, 235, 244, 23,  250, 164, 18,  163, 42,  25,  172, 22,  145, 103]
    key = [58,  201, 155, 173, 53,  232, 23,  67,  13,  116, 185, 247, 79,  137, 35,  28]

# Generated at 2022-06-22 06:30:28.648803
# Unit test for function shift_rows
def test_shift_rows():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    expected = [0, 1, 2, 3, 5, 6, 7, 4, 10, 11, 8, 9, 15, 12, 13, 14]
    assert shift_rows(data) == expected
    print('Test for shift_rows passed')


# Generated at 2022-06-22 06:30:39.132103
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0x00,0xAA,0xBB,0xCC,0xDD,0xEE,0xFF,0x01,0x23,0x45,0x67,0x89,0xAB,0xCD,0xEF,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00]

# Generated at 2022-06-22 06:30:51.308260
# Unit test for function inc
def test_inc():
    assert inc([1, 2, 3]) == [1, 2, 4]
    assert inc([1, 2, 255]) == [1, 3, 0]
    assert inc([1, 255, 255]) == [2, 0, 0]
    assert inc([255, 255, 255]) == [0, 0, 0]



# Generated at 2022-06-22 06:31:00.868724
# Unit test for function aes_encrypt
def test_aes_encrypt():
    test_key = bytes_to_intlist(compat_b64decode(
        b'ZRiG7z1hMM9tmKXydPxrZg=='))
    test_data = bytes_to_intlist(compat_b64decode(
        b'rMf0z/5YHOo5WzNw/GjNeQ=='))
    expanded_key = list(range(208))

    encrypted = aes_encrypt(test_data, expanded_key)
    assert encrypted == test_key
# End of unit test for function aes_encrypt


# Generated at 2022-06-22 06:31:07.877091
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    assert(aes_cbc_decrypt(
        bytes_to_intlist('7649abac8119b246cee98e9b12e9197d'),
        bytes_to_intlist('36f18357be4dbd77f050515c73fcf9f2'),
        bytes_to_intlist('69dda8455c7dd4254bf353b773304eec')) ==
           bytes_to_intlist('000102030405060708090a0b0c0d0e0f'))



# Generated at 2022-06-22 06:31:17.505692
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
     assert shift_rows_inv(shift_rows([0x32,0x43,0xf6,0xa8,0x88,0x5a,0x30,0x8d,0x31,0x31,0x98,0xa2,0xe0,0x37,0x07,0x34]))  == [0x32,0x43,0xf6,0xa8,0x88,0x5a,0x30,0x8d,0x31,0x31,0x98,0xa2,0xe0,0x37,0x07,0x34]
test_shift_rows_inv()

# Generated at 2022-06-22 06:31:20.965080
# Unit test for function sub_bytes
def test_sub_bytes():
    random.seed()
    for i in range(1, 50):
        data = [random.randint(0, 255) for j in range(4)]
        for k in range(4):
            data[k] = SBOX[data[k]]
        test_data = sub_bytes(data)
        assert data == test_data, "SBOX failed"


# Generated at 2022-06-22 06:31:26.032397
# Unit test for function inc
def test_inc():
    for i in range(256):
        data = [i] * 16
        assert inc(data) == [i + 1] * 16
test_inc()


# Generated at 2022-06-22 06:31:33.719737
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x8e, 0x0b, 0x76, 0xbc, 0xd8, 0xc1, 0x84, 0x48, 0x03, 0xef, 0x78, 0x81, 0x30, 0x4d, 0x4e, 0x5b]
    assert shift_rows_inv(data) == [0x8e, 0x0b, 0x76, 0xbc, 0xd8, 0xc1, 0x84, 0x48, 0x03, 0xef, 0x78, 0x81, 0x30, 0x4d, 0x4e, 0x5b]


# Generated at 2022-06-22 06:31:39.871863
# Unit test for function inc
def test_inc():
    assert inc([1, 2, 3, 4]) == [1, 2, 3, 5]
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([1, 2, 3, 255]) == [1, 2, 4, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-22 06:31:42.597981
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x08,0x01,0x01,0x01]
    expected = [0x54,0x65,0x73,0x74]
    result = sub_bytes(data)
    assert result == expected


# Generated at 2022-06-22 06:31:51.659688
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # AES CBC Test vectors from
    # https://tools.ietf.org/html/rfc3602#section-4
    key1 = bytes_to_intlist(compat_b64decode('YUJQREUwNTIwNzU0NDA5NDkz'))
    iv1 = bytes_to_intlist(compat_b64decode('AAAAAAECAwQFBgcICQoL'))
    data1 = bytes_to_intlist(compat_b64decode('YUJQREUwNTIxM0ZCRjAyMzRFRjU4Njc4OTg4NzY4N0ZCRjAyMzQxNzYzODk4NzY1MjEzQkYw'))
    assert aes_cbc_decrypt

# Generated at 2022-06-22 06:32:01.617294
# Unit test for function shift_rows
def test_shift_rows():
    data = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
    data_shifted = shift_rows(data)
    assert data_shifted == [0, 5, 10,15, 4,   9, 14, 3,  8, 13,  2,  7, 12, 1,  6, 11]
    print("test_shift_rows: OK")

test_shift_rows()



# Generated at 2022-06-22 06:32:11.650196
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .utils import bytes_to_intlist, intlist_to_bytes
    from .compat import compat_str
    from .aes_counter import AESCounter

    key = bytes_to_intlist(b'\x00' * 16)
    counter = AESCounter.new(
        bytes_to_intlist(b'\x00' * 8),
        nonce=b'\x00' * 8)

    # Test 1
    cipher = bytes_to_intlist(b'\x69\xc4\xe0\xd8\x6a\x7b\x04\x30\xd8\xcd\xb7' +
                              b'\x80\x70\xb4\xc5\x5a')

# Generated at 2022-06-22 06:32:21.599717
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-22 06:32:26.238253
# Unit test for function mix_column
def test_mix_column():
    data = [0xD4, 0xBF, 0x5D, 0x30]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    if data_mixed == [0x04, 0x66, 0x81, 0xE5]:
        print('Mix column: OK')
    else:
        print('Mix column: Fail')


# Generated at 2022-06-22 06:32:36.100417
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # key = "e60655d3e31e8c43b99580f6c790e6af"
    key = "0b142666bda190c1d34664b95a2e293a"
    # iv = "a7d89544b0620e0e52b58d7a9cf9c489"
    iv = bytes_to_intlist("5c5f5f5a539f9b7d9b977891e5a2a541")
    data = "c6b7eeef13dc3d0e5e70a8e5a5f374c1"
    data = "2e7dc098874e65c42f86b9bd9cee1489"

# Generated at 2022-06-22 06:32:47.187273
# Unit test for function sub_bytes

# Generated at 2022-06-22 06:32:51.430802
# Unit test for function mix_column
def test_mix_column():
    test_data = [0x63, 0xEB, 0x9F, 0xA0]
    assert mix_column(test_data, MIX_COLUMN_MATRIX) == [0x8C, 0x9D, 0x6E, 0x9C]
    assert mix_column(test_data, MIX_COLUMN_MATRIX_INV) == [0x4F, 0x01, 0xA1, 0xD0]


# Generated at 2022-06-22 06:32:56.693909
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x1f, 0x07, 0x1d, 0x0e]
    rcon_iteration = 1

    expected = [0xa4, 0x68, 0x6b, 0x02]
    actual = key_schedule_core(data, rcon_iteration)

    assert expected == actual


# Generated at 2022-06-22 06:33:01.422326
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import base64

    def dec(data, password, key_size_bytes):
        return aes_decrypt_text(
            data=base64.b64encode(data).decode('ASCII'),
            password=password,
            key_size_bytes=key_size_bytes)


# Generated at 2022-06-22 06:33:12.432205
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from .aes_cbc_encrypt import aes_cbc_encrypt_bytes
    data = [0] * 128
    key = [0] * 16
    iv = [0] * 16
    ciphertext = aes_cbc_encrypt_bytes(intlist_to_bytes(data), intlist_to_bytes(key), intlist_to_bytes(iv))

# Generated at 2022-06-22 06:33:30.069027
# Unit test for function aes_encrypt
def test_aes_encrypt():
    test_key = key_expansion([0] * 16)
    test_block = [0] * 16
    test_result = aes_encrypt(test_block, test_key)
    expected_result = [0x66, 0xe9, 0x4b, 0xd4, 0xef, 0x8a, 0x2c, 0x3b, 0x88, 0x4c, 0xfa, 0x59, 0xca, 0x34, 0x2b, 0x2e]
    assert test_result == expected_result

    test_key = intlist_to_bytes(range(16))
    test_block = intlist_to_bytes(range(16))
    test_result = aes_encrypt(test_block, test_key)

# Generated at 2022-06-22 06:33:33.558705
# Unit test for function rotate
def test_rotate():
    assert rotate([0x0, 0x1, 0x2, 0x3]) == [0x1, 0x2, 0x3, 0x0]



# Generated at 2022-06-22 06:33:34.264165
# Unit test for function shift_rows
def test_shift_rows():
    print(shift_rows(range(16)))

# Generated at 2022-06-22 06:33:38.293651
# Unit test for function shift_rows
def test_shift_rows():
    data = [0x63, 0xca, 0xb7, 0x04,
            0x6b, 0x65, 0xfd, 0x0a,
            0xbe, 0x1c, 0x6c, 0x94,
            0x08, 0xfe, 0x77, 0x2b]

    data_shifted = [0x63, 0x6b, 0xbe, 0x08,
                    0xca, 0x65, 0x1c, 0xfe,
                    0xb7, 0xfd, 0x6c, 0x77,
                    0x04, 0x0a, 0x94, 0x2b]

    assert shift_rows(data) == data_shifted
test_shift_rows()



# Generated at 2022-06-22 06:33:50.765202
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class FixedCounter(object):
        def __init__(self, counter):
            self.counter = bytes_to_intlist(counter)

        def next_value(self):
            return self.counter


# Generated at 2022-06-22 06:34:00.872574
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Test Vector #1 AES128-CBC
    # http://csrc.nist.gov/publications/nistpubs/800-38A/sp800-38A.pdf
    # "The Examples for Use of HMAC-SHA-1"
    key = bytes_to_intlist(compat_b64decode(b'Zm9vYmFyZm9vYmFy'))
    data = bytes_to_intlist(compat_b64decode(b'Zm9vYmFyZm9vYmFyZm9vYmFyZm9vYmFy'))

# Generated at 2022-06-22 06:34:06.430023
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert(key_schedule_core(bytearray.fromhex("2b7e151628aed2a6abf7158809cf4f3c"), 1) == bytearray.fromhex("8e473dea095fd543e72f16a8a8190df3"))


# KeyExpansion algorithm

# Generated at 2022-06-22 06:34:15.169079
# Unit test for function xor
def test_xor():
    assert xor([0, 0, 0, 0], [1, 1, 1, 1]) == [1, 1, 1, 1]
    assert xor([1, 0, 1, 1], [1, 1, 0, 0]) == [0, 1, 1, 1]
    assert xor([0, 0, 1, 1], [1, 1, 1, 0]) == [1, 1, 0, 1]
    assert xor([0, 0, 0, 1], [0, 1, 1, 0]) == [0, 1, 1, 1]
    return 'Test for function xor is passed'


print(test_xor())



# Generated at 2022-06-22 06:34:20.269660
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert shift_rows_inv(shift_rows([0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]) ==
        [0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c])



# Generated at 2022-06-22 06:34:28.139476
# Unit test for function mix_column
def test_mix_column():
    import itertools
    for row1, row2 in itertools.product(range(16), repeat=2):
        mixed_row = mix_column([row1, row2, 0, 0], MIX_COLUMN_MATRIX)
        mixed_row_inv = mix_column(mixed_row, MIX_COLUMN_MATRIX_INV)
        if ([row1, row2, 0, 0] != mixed_row_inv):
            print("Error")



# Generated at 2022-06-22 06:34:49.607254
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns_inv(data)
    expected_result = [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    assert (result == expected_result)
    print("Unit test passed.")


if __name__ == "__main__":
    test_mix_columns_inv()

# Generated at 2022-06-22 06:34:53.540089
# Unit test for function rotate
def test_rotate():
    assert rotate([0, 1, 2, 3]) == [1, 2, 3, 0]
    assert rotate([0, 1, 2, 3, 4]) == [1, 2, 3, 4, 0]


# Generated at 2022-06-22 06:35:05.410336
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
	key = [43, 126, 21, 22, 40, 174, 210, 166, 171, 247, 21, 136, 9, 207, 79, 60]
	iv = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
	# From https://www.tutorialspoint.com/cryptography_with_python/cryptography_with_python_aes_cbc_mode_encryption.htm
	cipher_text = (compat_b64decode('XgQfjKdU6eBuoPbB0VZzQepbKjPkH0m0'), [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])

# Generated at 2022-06-22 06:35:07.438300
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([1,2,3,4])) == [1,2,3,4]


# Generated at 2022-06-22 06:35:13.668668
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    original = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    shifted = shift_rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])
    shifted_inv = shift_rows_inv(shifted)
    assert(original == shifted_inv)



# Generated at 2022-06-22 06:35:24.874162
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-22 06:35:32.593256
# Unit test for function shift_rows
def test_shift_rows():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    data_shifted = shift_rows(data)
    print(data_shifted)
    if(data_shifted == [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]): print("shift rows test: PASSED")
    else: print("shift rows test: FAILED")
    return

# Generated at 2022-06-22 06:35:34.955366
# Unit test for function xor
def test_xor():
    assert (xor([1,2,3,4,5,6], [6,5,4,3,2,1])) == [7, 7, 7, 7, 7, 7]
    assert (xor([1,1,1,1,1,1,1,1], [1,1,1,1,1,1,1,1])) == [0,0,0,0,0,0,0,0]


# Generated at 2022-06-22 06:35:45.697591
# Unit test for function aes_decrypt_text

# Generated at 2022-06-22 06:35:57.185895
# Unit test for function aes_decrypt_text

# Generated at 2022-06-22 06:36:38.778908
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-22 06:36:43.803174
# Unit test for function rijndael_mul

# Generated at 2022-06-22 06:36:49.979248
# Unit test for function shift_rows
def test_shift_rows():
    test_data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    answer =    [0, 1, 2, 3, 5, 6, 7, 4, 10, 11, 8, 9, 15, 12, 13, 14]
    assert shift_rows(test_data) == answer


# Generated at 2022-06-22 06:36:55.110604
# Unit test for function key_expansion
def test_key_expansion():
    data=bytes_to_intlist(compat_b64decode(b'rZFVpK0oKkeI/NycX0NuOw=='))
    key_size_bytes = len(data)
    expanded_key_size_bytes = (key_size_bytes // 4 + 7) * BLOCK_SIZE_BYTES

    k_exp=key_expansion(data)

    print(intlist_to_bytes(k_exp))
    print(len(k_exp))
#test_key_expansion()


# Generated at 2022-06-22 06:37:02.069697
# Unit test for function mix_column
def test_mix_column():
    assert mix_column([0xdb, 0x13, 0x53, 0x45], MIX_COLUMN_MATRIX) == [0x8e,0x4d,0xa1,0xbc]
    assert mix_column([0x8e, 0x4d, 0xa1, 0xbc], MIX_COLUMN_MATRIX_INV) == [0xdb, 0x13, 0x53, 0x45]
    
test_mix_column()

# Generated at 2022-06-22 06:37:04.625804
# Unit test for function shift_rows
def test_shift_rows():
    data = []
    for column in range(4):
        for row in range(4):
            data.append(row + column)

    print (data)
    data = shift_rows(data)
    print (data)



# Generated at 2022-06-22 06:37:07.854649
# Unit test for function xor
def test_xor():
    data1 = [1, 2, 3, 4]
    data2 = [4, 3, 2, 1]
    result = xor(data1, data2)
    print(result)
    if result != [5, 1, 1, 5]:
        print("Test xor Failed!")
        return False
    return True
    
    


# Generated at 2022-06-22 06:37:13.832916
# Unit test for function rotate
def test_rotate():
    assert (rotate([1, 2, 3, 4]) == [2, 3, 4, 1])
    assert (rotate([5, 6, 7, 8]) == [6, 7, 8, 5])



# Generated at 2022-06-22 06:37:24.484892
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    result = mix_columns(data)

    assert(result == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01])



# Generated at 2022-06-22 06:37:35.588563
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(compat_b64decode(
        'U2FsdGVkX19g7VkvhU6zGyx6bPBKQ8Bv6IuCZlFF/mG1wKjIkPrDfRnnoM5UrVr5'))
    key = bytes_to_intlist(b'Sixteen byte key')
    iv = bytes_to_intlist(b'Sixteen byte IV')
    encrypted = intlist_to_bytes(aes_cbc_encrypt(data, key, iv))

# Generated at 2022-06-22 06:38:06.746517
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-22 06:38:16.807253
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key_array = [143, 194, 34, 208, 145, 203, 230, 143, 177, 246, 97, 206, 145, 92, 255, 84, 48, 165, 35, 113, 168, 141, 221, 168, 133, 236, 208, 164, 9, 33, 197]
    key = bytes_to_intlist(compat_b64decode('3JvxwFB7IOWnRjt9yb9DHA=='))
    iv_array = [105, 99, 111, 100, 101] + [0] * (BLOCK_SIZE_BYTES - 5)
    iv = bytes_to_intlist(compat_b64decode('aW9kZQ=='))

# Generated at 2022-06-22 06:38:23.761252
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    data_inv = [0, 13, 10, 7, 4, 1, 14, 11, 8, 5, 2, 15, 12, 9, 6, 3]
    assert(shift_rows_inv(data) == data_inv)
    assert(shift_rows(data_inv) == data)

# Generated at 2022-06-22 06:38:28.424482
# Unit test for function rijndael_mul
def test_rijndael_mul():
    a, b = 210, 237
    expected = 135
    res = rijndael_mul(a, b)
    assert res == expected, "Expected %r but got %r" % (expected, res)



# Generated at 2022-06-22 06:38:33.218145
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [x for x in range(0, 16)]
    data_encoded = shift_rows(data)
    data_decoded = shift_rows_inv(data_encoded)
    print("Test shift_rows_inv: ", data == data_decoded)



# Generated at 2022-06-22 06:38:43.690199
# Unit test for function aes_decrypt_text

# Generated at 2022-06-22 06:38:52.066948
# Unit test for function mix_column
def test_mix_column():
    a = [0x02, 0x03, 0x01, 0x01]
    b = [0x01, 0x02, 0x03, 0x01]
    c = [0x01, 0x01, 0x02, 0x03]
    d = [0x03, 0x01, 0x01, 0x02]
    my_a = mix_column(a, MIX_COLUMN_MATRIX)
    my_b = mix_column(b, MIX_COLUMN_MATRIX)
    my_c = mix_column(c, MIX_COLUMN_MATRIX)
    my_d = mix_column(d, MIX_COLUMN_MATRIX)
    print(my_a)
    print(my_b)
    print(my_c)

# Generated at 2022-06-22 06:39:03.973509
# Unit test for function key_expansion
def test_key_expansion():
    def test_data(data):
        print(data)
        assert key_expansion(data) == bytes_to_intlist(compat_b64decode(expected_value))
    data = bytes_to_intlist(b'\x00' * 16)
    expected_value = (
        'zWrgYV7PY0xKxRZ9XJLsipVb0G6r3q6Tq+cvMudJ6FvU4EORqNlZ9K'
        'Nv4SJyFphRoz/8/zYpGyTOeLt81EmtGm9Zg5fUA==')
    test_data(data)
    data = bytes_to_intlist(b'\x00' * 24)