

# Generated at 2022-06-22 06:29:22.942846
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    data = [14, 11, 13,  9, 9, 14, 11, 13, 13,  9, 14, 11, 11, 13,  9, 14]
    assert mix_columns_inv(data) == data
    data = [14, 9, 11, 13,  9, 14, 11, 13, 13,  9, 14, 11, 11, 13,  9, 14]
    assert mix_columns_inv(data) == data
test_mix_columns_inv()
test_mix_columns_inv()

# Generated at 2022-06-22 06:29:34.280769
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    assert aes_ctr_decrypt(
        [114, 131, 241, 249, 18, 77, 78, 66, 29, 109, 168, 190, 53, 168, 66, 243],
        [30, 29, 10, 20, 8, 34, 5, 22, 118, 66, 5, 115, 2, 19, 48, 22],
        Counter([3, 227, 156, 50, 190, 214, 158, 101, 108, 37, 204, 31, 134, 212, 137, 38, 0, 0, 0, 0, 0, 0, 0, 0])
    ) == [49, 140, 45, 22, 249, 195, 207, 215, 173, 199, 144, 189, 51, 209, 91, 142]
# End of unit test for function aes_ctr_decrypt


# Generated at 2022-06-22 06:29:42.661133
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    # Test vector came from https://csrc.nist.gov/csrc/media/projects/cryptographic-standards-and-guidelines/documents/examples/AES_Core128_Inv.pdf
    test_data = [int(x, 16) for x in "d4bf5d30 e9be2c63 13f2d340 3b8a1578 776f0b22 bf64c4ef 053c1567 5d38c5fe".split()]
    assert sub_bytes_inv(sub_bytes(test_data)) == test_data, "SubBytes function has error"



# Generated at 2022-06-22 06:29:46.191238
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]
    assert rotate([3, 4, 1, 2]) == [4, 1, 2, 3]



# Generated at 2022-06-22 06:29:55.891147
# Unit test for function rotate
def test_rotate():
    test_data = [1,2,3,4]
    assert rotate(test_data) == [2,3,4,1]
    assert rotate( rotate(test_data) ) == [3,4,1,2]
    assert rotate( rotate(rotate(test_data)) ) == [4,1,2,3]
    assert rotate( rotate(rotate(rotate(test_data)))) == [1,2,3,4]
    assert rotate( rotate(rotate(rotate(rotate(test_data))))) == [2,3,4,1]
# Test function rotate
test_rotate()


# Generated at 2022-06-22 06:30:01.154197
# Unit test for function shift_rows
def test_shift_rows():
    block1 = [0x00, 0x01, 0x02, 0x03,
              0x10, 0x11, 0x12, 0x13,
              0x20, 0x21, 0x22, 0x23,
              0x30, 0x31, 0x32, 0x33]
    block2 = shift_rows(block1)
    assert block2[0:4] == [0x00, 0x10, 0x20, 0x30]
    assert block2[4:8] == [0x01, 0x11, 0x21, 0x31]
    assert block2[8:12] == [0x02, 0x12, 0x22, 0x32]
    assert block2[12:16] == [0x03, 0x13, 0x23, 0x33]

# Generated at 2022-06-22 06:30:03.109206
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    '''
    This function checks the sub_bytes_inv function by testing a matrix
    '''
    
    if sub_bytes_inv(sub_bytes(list(range(16)))) != list(range(16)):
        print("ERROR in sub_bytes_inv\n")

# Generated at 2022-06-22 06:30:07.704259
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    x = [0xdb, 0x13, 0x53, 0x45,
         0xf2, 0x0a, 0x22, 0x5c,
         0x01, 0x01, 0x01, 0x01,
         0x01, 0x01, 0x01, 0x01]

    y = [0x75, 0xf3, 0xc6, 0xf4,
         0xdb, 0x7b, 0x89, 0x9f,
         0x9c, 0x9e, 0x7e, 0xec,
         0x2e, 0x7c, 0x91, 0x9b]


# Generated at 2022-06-22 06:30:11.959146
# Unit test for function rotate
def test_rotate():
    print("Testing rotate")
    if rotate([0,1,2,3]) != [1,2,3,0]:
        print("Error")
    else:
        print("OK")


# Generated at 2022-06-22 06:30:22.328354
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .utils import bytes_to_intlist, intlist_to_bytes
    import random
    import string

    key = bytes_to_intlist(b'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')
    iv = bytes_to_intlist(b'aaaaaaaaaaaaaaaa')
    test1 = b'aaaaaaaaaaaaaaaa'
    d1 = aes_cbc_decrypt(bytes_to_intlist(test1), key, iv)
    assert len(d1) == len(test1)
    assert d1 == bytes_to_intlist(test1)
    iv = bytes_to_intlist(b'bbbbbbbbbbbbbbbb')
    test2 = b'aaaaaaaaaaaaaaab'
    d2 = aes_cbc_decrypt(bytes_to_intlist(test2), key, iv)

# Generated at 2022-06-22 06:30:35.197022
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(2, 3) == 6
    assert rijndael_mul(3, 4) == 12
    assert rijndael_mul(51, 4) == 204
    assert rijndael_mul(32, 3) == 96
    assert rijndael_mul(15, 15) == 225
    assert rijndael_mul(64, 64) == 0
    assert rijndael_mul(0, 5) == 0
    assert rijndael_mul(5, 0) == 0



# Generated at 2022-06-22 06:30:46.683558
# Unit test for function aes_encrypt
def test_aes_encrypt():
    test_data = "0x32 0x43 0xf6 0xa8 0x88 0x5a 0x30 0x8d 0x31 0x31 0x98 0xa2 0xe0 0x37 0x07 0x34 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x00".replace("0x", "").replace(" ", ",")
    test_key = "0x2b 0x7e 0x15 0x16 0x28 0xae 0xd2 0xa6 0xab 0xf7 0x15 0x88 0x09 0xcf 0x4f 0x3c".replace("0x", "").replace(" ", ",")

# Generated at 2022-06-22 06:30:57.892024
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    clear_text = bytes_to_intlist(compat_b64decode('CRIwqt4+szDbqkNY+I0qbNXPg1XLaCM5etQ5Bt9DRFV/xIN2k8Go7jtArLIy' +
                                                   'P605b071DL8C+FPYSHOXPkMMMFPAKm+Nsu0nCBMQVt9mlluHbVE/yl6VaBC' +
                                                   '3Hvlu0XSQ9H6V7B8m0QkUNGvFUIrUQQTjO8TMoQMP+ETTUxVPf0Utwj4=')
                                  )

# Generated at 2022-06-22 06:31:06.254051
# Unit test for function inc
def test_inc():
    import unittest
    test_cases = { '00': '01',
                   '0f': '10',
                   'ff': '00' }
    for key, value in test_cases.items():
        data = [int(k, 16) for k in [key[0], key[1], 0, 0]]
        data = inc(data)
        expected = [int(v, 16) for v in [value[0], value[1], 0, 0]]
        assert data == expected, "expected %s, got %s" % (expected, data)



# Generated at 2022-06-22 06:31:17.780480
# Unit test for function aes_decrypt
def test_aes_decrypt():
    print("Finding AES Key")
    plainText = bytes_to_intlist("Some turing complete language")
    plainText += [0, 0, 0, 0, 0, 0, 0]
    print("Plaintext:", plainText)

    key = bytes_to_intlist("Something that looks random")
    expanded_key = key_expansion(key)

    cipherText = aes_encrypt(plainText, expanded_key)
    print("AES encrypted:", cipherText)

    decrypted = aes_decrypt(cipherText, expanded_key)
    print("AES decrypted:", decrypted)
    if decrypted == plainText:
        print("AES decryption successful!")
    else:
        print("AES decryption failed")


if __name__ == "__main__":
    test_a

# Generated at 2022-06-22 06:31:28.885220
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import hashlib
    import random

    data = bytearray([random.randrange(256) for _ in range(random.randrange(10000))])
    key = hashlib.md5(str(random.random()).encode()).digest()
    nonce = random.randrange(1 << 64)
    counter = lambda: bytearray([(nonce >> 8 * i) & 0xff for i in range(8)])

    # Encrypt with OpenSSL
    import subprocess

# Generated at 2022-06-22 06:31:40.650348
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    ciphertext = bytes_to_intlist(compat_b64decode(
        'ZDQzZGQ2ZDkzZmRlZmJlZjM3MGI0YWIwMDY5ZDFiZTIzMjBlNTk5OThlZGIyNGI5ZjlkY2YzY2Q2NzA1ZGMxN2NjZmE2MmY0MzNhYWYyYzYwYTg3ZGJiZmRhNjUxYmRlYmU2N2NiMmEyYmYyZTY1N2JjYjQ2Y2Q2MzIzNWI=\n'))

# Generated at 2022-06-22 06:31:46.269113
# Unit test for function rijndael_mul
def test_rijndael_mul():
    if(rijndael_mul(2, 3) != 6):
        return False
    if(rijndael_mul(3, 5) != 10):
        return False
    if(rijndael_mul(4, 6) != 3):
        return False
    return True

# Generated at 2022-06-22 06:31:51.854976
# Unit test for function xor
def test_xor():
    return xor([0x54, 0x77, 0x6f, 0x20],
               [0x4f, 0x6e, 0x65, 0x20]) == [0x1b, 0x19, 0x0b, 0x00]


# Generated at 2022-06-22 06:32:01.523346
# Unit test for function mix_columns
def test_mix_columns():
    assert(mix_columns([0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0xc6, 0xc6, 0xc6, 0xc6]) == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x8d, 0x8d, 0x8d, 0x8d])

# Generated at 2022-06-22 06:32:15.459593
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = b'vkJm9pCY3q68qjH836vznghB7+Rg1f2wCkF83+QMjJ4='
    password = 'secret'
    key_size_bytes = 16

    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == b'Hello world!'



# Generated at 2022-06-22 06:32:24.761911
# Unit test for function shift_rows
def test_shift_rows():
    assert (shift_rows([0x39, 0x02, 0xdc, 0x19, 0x25, 0xdc, 0x11, 0x6a, 0x84, 0x09, 0x85, 0x0b, 0x1d, 0xfb, 0x97, 0x32])
            == [0x39, 0x25, 0x84, 0x09, 0x02, 0xdc, 0x1d, 0xfb, 0xdc, 0x11, 0x85, 0x0b, 0x19, 0x6a, 0x97, 0x32])
test_shift_rows()


# Generated at 2022-06-22 06:32:35.778433
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist('140b41b22a29beb4061bda66b6747e14'.decode('hex'))  # 16-byte key
    iv = bytes_to_intlist('4ca00ff4c898d61e1edbf1800618fb28'.decode('hex'))  # 16-byte iv
    cipher = bytes_to_intlist('28a226d160dad07883d04e008a7897ee2e4b7465d5290d0c0e6c6822236e1daafb94ffe0c5da05d9476be028ad7c1d81'.decode('hex'))  # 48-byte cipher
    expected_decrypted_data = bytes_to_intlist('Basic CBC mode encryption needs padding.'.encode('utf-8'))


# Generated at 2022-06-22 06:32:45.130924
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert([0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c] ==
           shift_rows_inv([0x63, 0x53, 0xe0, 0x8c, 0x09, 0xd0, 0xe1, 0xb7, 0xba, 0x51, 0x8c, 0x04, 0xcd, 0xe7, 0x70, 0x60]))



# Generated at 2022-06-22 06:32:51.640935
# Unit test for function aes_encrypt
def test_aes_encrypt():
    """
    Testing aes_encrypt function
    """
    data = list(map(int, "0123456789abcdef".encode()))
    expanded_key = list(map(int, "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f".encode()))
    expected = list(map(int, "69c4e0d86a7b0430d8cdb78070b4c55a".encode()))
    test = aes_encrypt(data, expanded_key)
    assert expected == test, "Result: {}".format(test)
test_aes_encrypt()


# Generated at 2022-06-22 06:32:59.962042
# Unit test for function mix_column
def test_mix_column():
    data = [0x02, 0x03, 0x01, 0x01]
    expected = [0x06, 0x01, 0x01, 0x02]
    actual = mix_column(data, MIX_COLUMN_MATRIX)
    assert expected == actual

    data = [0x01, 0x02, 0x03, 0x01]
    expected = [0x04, 0x01, 0x01, 0x03]
    actual = mix_column(data, MIX_COLUMN_MATRIX)
    assert expected == actual



# Generated at 2022-06-22 06:33:01.562779
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert key_schedule_core([0x00, 0x00, 0x00, 0x00], 0x01) == [0x01, 0x00, 0x00, 0x00]



# Generated at 2022-06-22 06:33:06.302126
# Unit test for function xor
def test_xor():
    test = [0xfe, 0xed, 0xfa, 0xce]
    key = [0x01, 0x23, 0x45, 0x67]
    key = xor(test, key)
    print(key)

test_xor()


# Generated at 2022-06-22 06:33:14.073378
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    counter = AESCounter({'ctr': (14, 0)}).next_value()
    data = bytes_to_intlist(
        compat_b64decode('+2xOS6o06Jb2LAnBjCK0AQ=='))
    data = aes_ctr_decrypt(data, key, counter)
    assert intlist_to_bytes(data) == b'15985409864/videos?o'



# Generated at 2022-06-22 06:33:25.488573
# Unit test for function aes_decrypt
def test_aes_decrypt():
    cipher = [43, 126, 21, 22, 40, 174, 210, 166, 171, 247, 21, 136, 9, 207, 79, 60]
    key = [42, 152, 72, 177, 230, 28, 82, 87, 43, 182, 223, 57, 74, 78, 163, 56, 242, 10, 23,
           192, 205, 136, 194, 110, 12, 228, 97, 212, 171, 124]
    result = aes_decrypt(cipher, key)
    assert result == [101, 121, 74, 104, 98, 71, 99, 105, 79, 105, 74, 66, 77, 84, 73, 52]
    print('Unit test for function aes_decrypt performed')
test_aes_decrypt()


# Generated at 2022-06-22 06:33:33.194873
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x0f, 0x15, 0x71, 0xc9]
    expected = [0xC4, 0xE0, 0xC8, 0x7B]
    assert sub_bytes(data) == expected


# Generated at 2022-06-22 06:33:40.026761
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x54, 0x77, 0x6F, 0x20]
    rcon_iteration = 1
    expected_result = [0xE0, 0x54, 0x9B, 0x1E]

    result = key_schedule_core(data, rcon_iteration)

    print("Key Schedule Core Results:  {}".format(result))
    print("Expected Result:            {}".format(expected_result))
    print("Test Passed:                {}".format(result == expected_result))
    test_passed = result == expected_result
    assert test_passed



# Generated at 2022-06-22 06:33:41.942753
# Unit test for function shift_rows
def test_shift_rows():
    data_shifted = shift_rows([0] * 16)
    assert len(data_shifted) == 16
    assert data_shifted == [0, 1, 2, 3, 5, 6, 7, 4, 10, 11, 8, 9, 15, 12, 13, 14]

test_shift_rows()



# Generated at 2022-06-22 06:33:45.852102
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    test_data = []
    for i in range(0x10):
        test_data.append(i)
    shift_rows_inv(test_data)
    return test_data



# Generated at 2022-06-22 06:33:57.061281
# Unit test for function aes_encrypt
def test_aes_encrypt():
    plaintext_hex = '00112233445566778899aabbccddeeff'
    cipherkey_hex = '000102030405060708090a0b0c0d0e0f'
    expected_cipher_hex = '69c4e0d86a7b0430d8cdb78070b4c55a'

    plaintext = bytes_to_intlist(compat_b64decode(plaintext_hex))
    cipherkey = bytes_to_intlist(compat_b64decode(cipherkey_hex))
    expanded_key = key_expansion(cipherkey)

    cipher = aes_encrypt(plaintext, expanded_key)
    assert intlist_to_bytes(cipher).encode('hex') == expected_cipher_hex



# Generated at 2022-06-22 06:34:06.105799
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    KEY = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f')
    IV = bytes_to_intlist(b'\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff')
    data = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f')
    encrypted_data = aes_cbc_enc

# Generated at 2022-06-22 06:34:17.032329
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'ZagZeRXSUWcVB8KPpk+JrFNE3GxJwCEq3DZkuKQ1Q+M='
    password = 'Password'
    assert aes_decrypt_text(data, password, 16) == 'Test 1234'

    data = '+c6jHM9XhnW8hmD5gsy0r12rHk0jmw8pDfYBmEdCHpv/9XSpAx/B2RomZxiN/dIq3DZkuKQ1Q+M='
    password = 'Test123'
    assert aes_decrypt_text(data, password, 24) == 'RVAR is short for RunVAriable, which is an obfuscated script that is the main payload for this infection chain.'


# Generated at 2022-06-22 06:34:20.166159
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x83) == 0xc1
    print("rijndael_mul works correctly")


# Generated at 2022-06-22 06:34:23.001399
# Unit test for function sub_bytes_inv
def test_sub_bytes_inv():
    assert sub_bytes_inv(sub_bytes([x for x in range(16)])) == [x for x in range(16)]


# Generated at 2022-06-22 06:34:28.995249
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    s = '{"key":"zWm8NbvOpnFjNkWHX","nonce":"M8fMh1LI/Gw=","ciphertext":"Isj6vfUxl4i9XlQjbBiP5Rh0="}'
    data = bytes_to_intlist(compat_b64decode(s))
    key = bytes_to_intlist(compat_b64decode('zWm8NbvOpnFjNkWHX'))
    nonce = bytes_to_intlist(compat_b64decode('M8fMh1LI/Gw='))

    class Counter(object):
        def __init__(self, nonce):
            self._nonce = nonce
            self._counter = -1


# Generated at 2022-06-22 06:34:39.497548
# Unit test for function key_schedule_core
def test_key_schedule_core():
    # Input
    b = [0x01, 0x02, 0x03, 0x04]
    rcon_iteration = 1

    # Expected output
    expected = [0x01, 0x03, 0x04, 0x0C]

    assert key_schedule_core(b, rcon_iteration) == expected



# Generated at 2022-06-22 06:34:49.100860
# Unit test for function mix_columns
def test_mix_columns():
    ct = [0xDB, 0x13, 0x53, 0x45, 0xF2, 0x0A, 0x22, 0x5C, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    expected = [0x8E, 0xE2, 0xA8, 0xD6, 0xBE, 0x1D, 0xB1, 0x6C, 0xE0, 0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2]
    test = mix_columns(ct)
    assert(expected == test)
test_mix_columns()



# Generated at 2022-06-22 06:35:01.153215
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Test case 1
    result = aes_encrypt(bytes_to_intlist(compat_b64decode(b'rNrPXStH/CZdTw==')), bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f'))
    assert result == bytes_to_intlist(compat_b64decode(b'WKjvn9i/RlE4lN4='))

    # Test case 2
    result = aes_encrypt(bytes_to_intlist(b'\x00' * 16), bytes_to_intlist(b'\x00' * 16))

# Generated at 2022-06-22 06:35:11.163115
# Unit test for function shift_rows
def test_shift_rows():
    test = [0x63,0xCA,0xB7,0x04,0x09,0x53,0xD0,0x51,0xCD,0x60,0xE0,0xE7,0xBA,0x70,0xE1,0x8C]
    result = [0x63,0x53,0xE0,0x8C,0x09,0x60,0xE1,0x04,0xCD,0xE7,0x70,0x51,0xBA,0xCA,0xB7,0xD0]
    assert result == shift_rows(test)



# Generated at 2022-06-22 06:35:14.823060
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0xFF, 0xFF, 0xFF, 0xFF]
    expected = [0xFF, 0xFF, 0xFF, 0xFF]
    assert expected == key_schedule_core(data, rcon_iteration=0)
    print("Successfully pass test")

if __name__ == "__main__":
    test_key_schedule_core()


# Generated at 2022-06-22 06:35:26.635137
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # pylint: disable=protected-access
    from .pycrypto_aes import _pycrypto_aes_encrypt

    class Counter(object):
        """
        @returns {int[]}  16-Byte counter block
        """
        def __init__(self, value):
            """
            @param {int[]} value  16-Byte counter block
            """
            self.value = value

        def next_value(self):
            """
            @returns {int[]}  16-Byte counter block
            """
            # pylint: disable=invalid-unary-operand-type
            self.value = intlist_to_bytes(
                intlist_add(bytes_to_intlist(self.value), [1]))
            return self.value


# Generated at 2022-06-22 06:35:38.934796
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0x07, 0xa8, 0x8d, 0xa2, 0x34]

# Generated at 2022-06-22 06:35:47.524131
# Unit test for function mix_columns_inv
def test_mix_columns_inv():
    # Input, output taken from example on Wikipedia
    d = [0xdb, 0xf2, 0xd4, 0x6f, 0x43, 0x75, 0xd7, 0x87, 0x9d, 0x59, 0x98, 0x67, 0x4c, 0x3a, 0xe6, 0xde]
    result = [0xbd, 0xf1, 0x4c, 0x30, 0x5a, 0xd2, 0xe2, 0x22, 0x71, 0x2f, 0x4b, 0x7e, 0x85, 0x9d, 0x75, 0x38]
    assert mix_columns_inv(d) == result


# Generated at 2022-06-22 06:35:48.823184
# Unit test for function rotate
def test_rotate():
    assert rotate([1, 2, 3, 4]) == [2, 3, 4, 1]
    print("Function rotate() passed unit test successfully!")

test_rotate()


# Generated at 2022-06-22 06:35:52.267748
# Unit test for function shift_rows
def test_shift_rows():
    assert shift_rows([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]) == [1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15, 4, 8, 12, 16]
    assert shift_rows([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]



# Generated at 2022-06-22 06:36:05.358825
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7, 0xf8, 0xf9, 0xfa, 0xfb, 0xfc, 0xfd, 0xfe, 0xff]
    iv = [0xe0, 0xe1, 0xe2, 0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xeb, 0xec, 0xed, 0xee, 0xef]

# Generated at 2022-06-22 06:36:07.632423
# Unit test for function mix_column
def test_mix_column():
    data = [0x3c, 0x06, 0x47, 0x5e]
    data_mixed = mix_column(data, MIX_COLUMN_MATRIX)
    assert(data_mixed == [0x9f, 0x5f, 0x0, 0xe4])



# Generated at 2022-06-22 06:36:11.337783
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(256):
        for j in range(256):
            assert rijndael_mul(i, j) == rijndael_mul_ref(i, j)
            assert rijndael_mul(i, j) == ((i * j) % 0x100)



# Generated at 2022-06-22 06:36:13.241588
# Unit test for function shift_rows
def test_shift_rows():
    data = [x for x in range(16)]
    expected = [0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15]
    result = shift_rows(data)
    print("Shift rows: " + str(expected == result))



# Generated at 2022-06-22 06:36:23.820858
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
          0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-22 06:36:26.811562
# Unit test for function inc
def test_inc():
    print('\n' + '#' * 25 + 'Unit test for inc' + '#' * 25)
    x = 0
    for _ in range(1000):
        print('x:', hex(x), 'inc:', hex(inc(x)[0]))
        assert inc(x)[0] == x + 1, 'x: %d, inc: %d' % (x, inc(x)[0])
        x += 1


# Generated at 2022-06-22 06:36:31.842141
# Unit test for function sub_bytes
def test_sub_bytes():
    data = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    assert sub_bytes(data) == [0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76]

# Generated at 2022-06-22 06:36:41.164890
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytes_to_intlist(compat_b64decode('CiqeQDl5+6HaMuU6r5ECiw=='))
    key = bytes_to_intlist(compat_b64decode('GawgguFyGrWKav7AX4VKUg'))
    iv = bytes_to_intlist(compat_b64decode('qTZf0T37tALaTQ54WL8uKA=='))
    assert intlist_to_bytes(aes_cbc_decrypt(data, key, iv)) == b'Hey there!'


# Generated at 2022-06-22 06:36:46.107999
# Unit test for function inc
def test_inc():
    for i in range(0, 256):
        data = [i]
        result = inc(data)
        data.append(data[0] + 1)
        assert result == data
# # Unit test for function inc
# test_inc()



# Generated at 2022-06-22 06:36:55.415448
# Unit test for function shift_rows
def test_shift_rows():
    print("Test shift_rows()")
    data_to_test = [
        0x00, 0x04, 0x08, 0x0C,
        0x01, 0x05, 0x09, 0x0D,
        0x02, 0x06, 0x0A, 0x0E,
        0x03, 0x07, 0x0B, 0x0F
    ]
    data_expected = [
        0x00, 0x04, 0x08, 0x0C,
        0x05, 0x09, 0x0D, 0x01,
        0x0A, 0x0E, 0x02, 0x06,
        0x0F, 0x03, 0x07, 0x0B
    ]

# Generated at 2022-06-22 06:37:13.219940
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    KEY = bytes_to_intlist(b'YELLOW SUBMARINE')
    IV = bytes_to_intlist(b'\x00' * BLOCK_SIZE_BYTES)

    encrypted = b''
    with open('challenge10.txt') as f:
        encrypted = f.read()
        encrypted = compat_b64decode(encrypted.strip().encode('ascii'))
        encrypted = bytes_to_intlist(encrypted)
        # print('bytes_to_intlist', bytes_to_intlist(encrypted))
        # print('intlist_to_bytes', intlist_to_bytes(encrypted))

    decrypted_data = aes_cbc_decrypt(encrypted, KEY, IV)
    # print('decrypted_data', decrypted_data)
    decrypted = intlist_to_

# Generated at 2022-06-22 06:37:17.689028
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key_hex = "000102030405060708090a0b0c0d0e0f"
    key = bytes_to_intlist(compat_b64decode(key_hex))
    expanded_key = key_expansion(key)

    message_hex = "69c4e0d86a7b0430d8cdb78070b4c55a"
    message = bytes_to_intlist(compat_b64decode(message_hex))

    expected_plaintext_hex = "00112233445566778899aabbccddeeff"
    expected_plaintext = bytes_to_intlist(compat_b64decode(expected_plaintext_hex))

    ciphertext = aes_encrypt(expected_plaintext, expanded_key)
    plaintext = aes

# Generated at 2022-06-22 06:37:29.197417
# Unit test for function aes_encrypt
def test_aes_encrypt():
	key128 = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
	data = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]
	resultat = aes_encrypt(data,key_expansion(key128))

# Generated at 2022-06-22 06:37:38.956310
# Unit test for function aes_decrypt
def test_aes_decrypt():
    from .compat import compat_b64decode
    iv = [0] * 16
    key = bytes_to_intlist(compat_b64decode("Wq3CiGp1c+NSGhle8ZPWUg=="))
    encrypted_data = bytes_to_intlist(compat_b64decode("aM2UlvFIWJU6y0gXMpGxLE/a8WbnwNhZz+g/k/2rH8Y="))
    assert aes_cbc_decrypt(encrypted_data, key, iv)[:71] == bytes_to_intlist(compat_b64decode("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"))

test_aes_decrypt()

# Generated at 2022-06-22 06:37:46.527935
# Unit test for function shift_rows
def test_shift_rows():
    data_to_shift = b'test'
    data_shifted = b'tes '
    test_data = []
    for x in data_to_shift:
        test_data.append(ord(x))
    result = shift_rows(test_data)
    result_string = bytes(result)
    print('{:s} == {:s} : {:b}'.format(data_shifted, result_string, data_shifted == result_string))



# Generated at 2022-06-22 06:37:58.028129
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .crypto_aes_cbc_pkcs7 import pkcs7_unpad
    from .utils import hex_to_intlist

    key = b'YELLOW SUBMARINE'
    data = b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    counter = CountFromZero()
    decrypted_data = aes_ctr_decrypt(bytes_to_intlist(compat_b64decode(data)), bytes_to_intlist(key), counter)
    decrypted_string = intlist_to_bytes(pkcs7_unpad(decrypted_data))


# Generated at 2022-06-22 06:38:05.364347
# Unit test for function shift_rows
def test_shift_rows():
    data = list(range(16))
    for i in range(4):
        data = rotate(data)
        assert shift_rows(data) == list(range(16))
    return True
#print(f'passed test_shift_rows: {test_shift_rows()}')


# Generated at 2022-06-22 06:38:12.830848
# Unit test for function inc
def test_inc():
    data = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    expected_result = [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01]
    real_result = inc(data)
    assert(real_result == expected_result)

test_inc()



# Generated at 2022-06-22 06:38:24.210787
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    assert shift_rows_inv(range(16)) == range(16)
    assert shift_rows_inv(range(16, 32)) == [16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]
    assert shift_rows_inv([12, 9, 6, 3, 13, 10, 7, 4, 14, 11, 8, 5, 15, 12, 9, 6]) == [12, 13, 14, 15, 9, 10, 11, 12, 6, 7, 8, 9, 3, 4, 5, 6]
    assert shift_rows_inv(range(32, 48)) == [32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47]



# Generated at 2022-06-22 06:38:34.608895
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb,0x13,0x53,0x45,
            0xf2,0x0a,0x22,0x5c,
            0x01,0x01,0x01,0x01,
            0xab,0xab,0xab,0xab,]
    res = mix_columns(data)
    assert(res == [
        0x8e,0x4d,0xa1,0xbc,
        0x9f,0xdc,0x58,0x9d,
        0x01,0x01,0x01,0x01,
        0x01,0x01,0x01,0x01,
    ])



# Generated at 2022-06-22 06:38:57.348819
# Unit test for function mix_column
def test_mix_column():
    data = [0xDB, 0x13, 0x53, 0x45]
    expected = [0x8E, 0x4D, 0xA1, 0xBC]
    assert(mix_column(data, MIX_COLUMN_MATRIX) == expected)



# Generated at 2022-06-22 06:39:08.217021
# Unit test for function key_schedule_core
def test_key_schedule_core():
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 0) == [0x02, 0x03, 0x04, 0x01]
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 1) == [0x04, 0x01, 0x02, 0x3d]
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 2) == [0x08, 0x3d, 0x04, 0x01]
    assert key_schedule_core([0x01, 0x02, 0x03, 0x04], 3) == [0x10, 0x01, 0x02, 0x03]

test_key_schedule_core()
