

# Generated at 2022-06-18 12:56:48.630485
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Test vector from https://tools.ietf.org/html/rfc3686#section-6
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'Jefe'
    key_size_bytes = 16
    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == b'what do ya want for nothing?'



# Generated at 2022-06-18 12:56:57.853407
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))

# Generated at 2022-06-18 12:57:00.314192
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:57:12.615605
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text(
        'U2FsdGVkX1+h+wJZ7d+ZYQY1Ynjy9v/xXm4b4/4n7n0=',
        'password',
        16
    ) == b'Hello World!'
    assert aes_decrypt_text(
        'U2FsdGVkX1+h+wJZ7d+ZYQY1Ynjy9v/xXm4b4/4n7n0=',
        'password',
        24
    ) == b'Hello World!'

# Generated at 2022-06-18 12:57:24.283552
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='))
    iv = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='))
    data = bytes_to_intlist(compat_b64decode('5Zu95a6M5oiQ5Zu+'))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('z5mFe9Z/5L+h5oGv5Yqg5YWs5Y+4')



# Generated at 2022-06-18 12:57:36.997348
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Test vectors from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # Appendix F.2.1
    key = bytes_to_intlist(compat_b64decode(b'GawgguFyGrWKav7AX4VKUg'))
    data = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))

# Generated at 2022-06-18 12:57:46.116326
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]

# Generated at 2022-06-18 12:57:57.809200
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]

# Generated at 2022-06-18 12:58:08.720915
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text(
        'Qf6bz7VXpj6u+6bv8XevsH1x8T+ouTlL',
        'password',
        16
    ) == b'Hello World!'
    assert aes_decrypt_text(
        'Qf6bz7VXpj6u+6bv8XevsH1x8T+ouTlL',
        'password',
        24
    ) == b'Hello World!'
    assert aes_decrypt_text(
        'Qf6bz7VXpj6u+6bv8XevsH1x8T+ouTlL',
        'password',
        32
    ) == b'Hello World!'



# Generated at 2022-06-18 12:58:16.146180
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    expected_plaintext = b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '
    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == expected_plaintext



# Generated at 2022-06-18 12:58:28.446598
# Unit test for function key_expansion
def test_key_expansion():
    assert key_expansion(bytes_to_intlist(b'\x00' * 16)) == bytes_to_intlist(b'\x00' * 176)
    assert key_expansion(bytes_to_intlist(b'\x00' * 24)) == bytes_to_intlist(b'\x00' * 208)
    assert key_expansion(bytes_to_intlist(b'\x00' * 32)) == bytes_to_intlist(b'\x00' * 240)

    assert key_expansion(bytes_to_intlist(b'\x00' * 16)) == bytes_to_intlist(b'\x00' * 176)

# Generated at 2022-06-18 12:58:38.734145
# Unit test for function key_expansion

# Generated at 2022-06-18 12:58:49.815324
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:59:01.311804
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:59:13.932951
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:59:20.626794
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:59:32.429496
# Unit test for function key_expansion

# Generated at 2022-06-18 12:59:42.178149
# Unit test for function key_expansion
def test_key_expansion():
    # Test vectors from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # Appendix F.1.1
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 12:59:53.181823
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:59:59.904239
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7QXuBt3j0qE9AcTqp9wA=='))
    expanded_key = bytes_to_intlist(compat_b64decode('gI7QXuBt3j0qE9AcTqp9wA+K4nFcP+pjyj9qM7V9HlU='))
    assert key_expansion(key) == expanded_key



# Generated at 2022-06-18 13:00:14.245437
# Unit test for function key_expansion
def test_key_expansion():
    # Test vectors from http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    # Appendix B.  Example Vectors
    # AES-128
    key = bytes_to_intlist(compat_b64decode('2b7e151628aed2a6abf7158809cf4f3c'))
    expanded_key = bytes_to_intlist(compat_b64decode('2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da5'
                                                     '73b160ecb8e3935f65f3551'))
    assert key_expansion(key) == expanded_key

    # AES-192

# Generated at 2022-06-18 13:00:18.194273
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:27.461253
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:38.260483
# Unit test for function key_expansion

# Generated at 2022-06-18 13:00:48.889855
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:59.847001
# Unit test for function key_expansion

# Generated at 2022-06-18 13:01:12.556625
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:01:25.440032
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:01:37.489290
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 13:01:50.676331
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CzYsRiF3uIx1Zu0xmF9K/A=='))
    expanded_key = bytes_to_intlist(compat_b64decode('CzYsRiF3uIx1Zu0xmF9K/A=='))
    assert key_expansion(key) == expanded_key

    key = bytes_to_intlist(compat_b64decode('CzYsRiF3uIx1Zu0xmF9K/A=='))
    expanded_key = bytes_to_intlist(compat_b64decode('CzYsRiF3uIx1Zu0xmF9K/A=='))
    assert key_exp

# Generated at 2022-06-18 13:02:06.043786
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:17.194587
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:22.119426
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7wzFhb6EQj8nkKH+uEew=='))
    expanded_key = bytes_to_intlist(compat_b64decode('gI7wzFhb6EQj8nkKH+uEewEqx0pv9H7dT1sjXv1+G2A='))
    assert key_expansion(key) == expanded_key



# Generated at 2022-06-18 13:02:34.754790
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176

# Generated at 2022-06-18 13:02:46.094597
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:57.367987
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:07.093357
# Unit test for function key_expansion

# Generated at 2022-06-18 13:03:19.710664
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('/iQfKs4Gj+8LQJf4MR1DZw=='))
    expanded_key = bytes_to_intlist(compat_b64decode('/iQfKs4Gj+8LQJf4MR1DZw=='))
    assert key_expansion(key) == expanded_key

    key = bytes_to_intlist(compat_b64decode('/iQfKs4Gj+8LQJf4MR1DZw=='))
    expanded_key = bytes_to_intlist(compat_b64decode('/iQfKs4Gj+8LQJf4MR1DZw=='))
    assert key_expansion(key)

# Generated at 2022-06-18 13:03:30.759507
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:41.852438
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:01.392691
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:11.714515
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('Cz4p+ZJQzqe9H6m6YTQQ8w=='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:04:19.309592
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:29.568520
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:40.829758
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:50.361904
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-18 13:04:57.740242
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-18 13:05:08.842427
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CmU/9qh1E1lhsu9n/UywJw=='))

# Generated at 2022-06-18 13:05:21.102734
# Unit test for function key_expansion
def test_key_expansion():
    """
    Test for function key_expansion
    """
    key_size_bytes = 16
    key = [0] * key_size_bytes
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176
    assert expanded_key[0:4] == [0x2b, 0x7e, 0x15, 0x16]
    assert expanded_key[4:8] == [0x28, 0xae, 0xd2, 0xa6]
    assert expanded_key[8:12] == [0xab, 0xf7, 0x15, 0x88]
    assert expanded_key[12:16] == [0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:33.180442
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CmU/9qhF9oXQj9xJW6iHiQ=='))
    expanded_key = bytes_to_intlist(compat_b64decode('CmU/9qhF9oXQj9xJW6iHiQ=='))
    expanded_key += bytes_to_intlist(compat_b64decode('/8YnI98q5iYQjbNTFZ6LfQ=='))
    expanded_key += bytes_to_intlist(compat_b64decode('5P1n9YxJkCxQjbNTFZ6LfQ=='))

# Generated at 2022-06-18 13:06:00.732443
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]