

# Generated at 2022-06-18 12:56:49.341690
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, initial_value):
            self.value = initial_value

        def next_value(self):
            self.value += 1
            return self.value

    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    counter = Counter(0)

# Generated at 2022-06-18 12:56:58.328912
# Unit test for function aes_decrypt

# Generated at 2022-06-18 12:57:10.770259
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    expanded_key = key_expansion(key)
    cipher = aes_encrypt(data, expanded_key)

# Generated at 2022-06-18 12:57:22.894051
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-18 12:57:28.158664
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    iv = bytes_to_intlist(compat_b64decode('2jmj7l5rSw0yVb/vlWAYkK/YBwk='))
    cipher = bytes_to_intlist(compat_b64decode('5aaC5qKm5oqA5pyvAAAAAA=='))
    expanded_key = key_expansion(key)
    assert aes_decrypt(cipher, expanded_key) == iv



# Generated at 2022-06-18 12:57:30.372768
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x01, 0x02, 0x03, 0x04]
    rcon_iteration = 1
    expected = [0x01, 0x03, 0x05, 0x0F]
    assert key_schedule_core(data, rcon_iteration) == expected
    print("Test key_schedule_core: Success")

test_key_schedule_core()


# Generated at 2022-06-18 12:57:34.632515
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuTq6K0xNq8uHiXqew=='))
    iv = bytes_to_intlist(compat_b64decode('q9+E3jkJ9D0YWj4P3QCZjw=='))
    data = bytes_to_intlist(compat_b64decode('YWJjZA=='))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('ZGZneWdnc2ZmeGdncw==')



# Generated at 2022-06-18 12:57:45.047805
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .utils import bytes_to_intlist, intlist_to_bytes
    from .compat import compat_b64decode

    class Counter(object):
        def __init__(self, nonce):
            self.nonce = nonce
            self.counter = 0

        def next_value(self):
            counter_block = self.nonce + [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, self.counter]
            self.counter += 1
            return counter_block


# Generated at 2022-06-18 12:57:57.606010
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test function aes_decrypt_text
    """
    import base64
    import os

    def test_aes_decrypt_text_with_key_size(key_size_bytes):
        """
        Test function aes_decrypt_text with 'key_size_bytes'
        """
        password = os.urandom(key_size_bytes)
        data = os.urandom(1024)
        encrypted_data = aes_encrypt_text(data, password, key_size_bytes)
        decrypted_data = aes_decrypt_text(encrypted_data, password, key_size_bytes)
        assert data == decrypted_data


# Generated at 2022-06-18 12:58:06.388301
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]
    expanded_key = key_expansion(key)
    cipher = aes_encrypt(data, expanded_key)

# Generated at 2022-06-18 12:58:22.285926
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode(b'C8E7B9EFD9C147D8D9CCDF2E2C751B81'))
    iv = bytes_to_intlist(compat_b64decode(b'00000000000000000000000000000000'))
    cipher = bytes_to_intlist(compat_b64decode(b'0EC7702330098CE7F7520D1CBBB20FC3'))
    plain = bytes_to_intlist(compat_b64decode(b'00000000000000000000000000000000'))
    assert aes_cbc_decrypt(cipher, key, iv) == plain


# Generated at 2022-06-18 12:58:34.339172
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuTq9XF+Ao5RKFhSqg=='))
    iv = bytes_to_intlist(compat_b64decode('qT67kNxEbxxLXa0hF9yjkw=='))

# Generated at 2022-06-18 12:58:38.622727
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:58:44.404953
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .utils import bytes_to_intlist, intlist_to_bytes
    from .aes_cbc import aes_cbc_decrypt
    from .aes_ecb import aes_ecb_encrypt
    from .aes_ctr import Counter

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    counter = Counter(b'\x00' * 8)

# Generated at 2022-06-18 12:58:56.570629
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuTqyj9J4l+eQaiz0Q=='))
    iv = bytes_to_intlist(compat_b64decode('qT7XOJndT6nH1E8MjCzRrw=='))
    cipher = bytes_to_intlist(compat_b64decode('LK+zWk/lQ2NrJtRv/xYHjA=='))
    plain = bytes_to_intlist(compat_b64decode('foobar'))
    assert aes_cbc_decrypt(cipher, key, iv) == plain



# Generated at 2022-06-18 12:59:02.993540
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuTq8P0xjQnPfQP70Q=='))
    iv = bytes_to_intlist(compat_b64decode('qkPvFqE+6EkLc5IyHGMhUg=='))
    data = bytes_to_intlist(compat_b64decode('qkPvFqE+6EkLc5IyHGMhUg=='))
    assert aes_cbc_decrypt(data, key, iv) == [0] * 16



# Generated at 2022-06-18 12:59:15.203864
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, initial_value):
            self.value = initial_value

        def next_value(self):
            self.value += 1
            return self.value

    data = bytes_to_intlist(compat_b64decode(
        'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode(
        'YELLOW SUBMARINE'))
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-18 12:59:24.039494
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZbDRPZ6WYQ=='))
    iv = bytes_to_intlist(compat_b64decode('qT7u9qT7u9qT7u9q'))

# Generated at 2022-06-18 12:59:36.113588
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 12:59:44.457460
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test vector from https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf
    key = bytes_to_intlist(compat_b64decode(b'2b7e151628aed2a6abf7158809cf4f3c'))
    iv = bytes_to_intlist(compat_b64decode(b'000102030405060708090a0b0c0d0e0f'))

# Generated at 2022-06-18 13:00:00.590850
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import base64

# Generated at 2022-06-18 13:00:12.541162
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, start_value):
            self.counter = start_value

        def next_value(self):
            self.counter += 1
            return intlist_to_bytes(self.counter)

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    cipher = bytes_to_intlist(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')
    counter = Counter(0)
    plain = aes_ctr_decrypt(cipher, key, counter)

# Generated at 2022-06-18 13:00:23.169804
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test function aes_decrypt_text
    """
    import base64
    import os

    # Test vectors from https://tools.ietf.org/html/rfc3686

# Generated at 2022-06-18 13:00:30.785201
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import base64
    import binascii
    import os
    import random
    import string

    def random_string(length):
        return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))

    def random_bytes(length):
        return os.urandom(length)

    def random_intlist(length):
        return [random.randint(0, 255) for _ in range(length)]

    def random_int(min_value, max_value):
        return random.randint(min_value, max_value)

    def random_choice(choices):
        return random.choice(choices)

    def random_bool():
        return random.choice([True, False])


# Generated at 2022-06-18 13:00:40.122053
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'QVNjQWVzRXh0ZW5zaW9ucy5jb20vZG93bmxvYWQvYWVzLWV4dGVuc2lvbnMtMjAxNi0xMS0xMi5qcw=='
    password = 'password'
    key_size_bytes = 16
    expected_result = b'AesExtensions.com/download/aes-extensions-2016-11-12.js'
    result = aes_decrypt_text(data, password, key_size_bytes)
    assert result == expected_result


# Generated at 2022-06-18 13:00:50.851231
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Test vector from https://tools.ietf.org/html/rfc3686#section-6
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    nonce = bytes_to_intlist(b'\x00\x00\x00\x30\x00\x00\x00\x00')

# Generated at 2022-06-18 13:01:02.131990
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cipher import aes_encrypt

    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    counter = AESCounter(bytes_to_intlist(compat_b64decode(b'f83OJ3D2xF1Bg8vub9tLe1g==')))
    data = bytes_to_intlist(compat_b64decode(b'KDlTtXchhZTGufMYmOYGS4HffxPSUrfmqCHXaI9wOGY='))

# Generated at 2022-06-18 13:01:14.755389
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test function aes_decrypt_text
    """
    # Test vectors from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # Appendix F.3.1 - F.3.3

# Generated at 2022-06-18 13:01:27.479756
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 13:01:39.045226
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cipher import aes_encrypt
    from .aes_cipher import aes_decrypt
    from .aes_cipher import key_expansion
    from .aes_cipher import xor
    from .aes_cipher import aes_ctr_decrypt

    class TestCounter(AESCounter):
        def __init__(self, counter_block):
            self.counter_block = counter_block

        def next_value(self):
            return self.counter_block


# Generated at 2022-06-18 13:01:53.714859
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:04.683665
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:11.646285
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('Cz4hcgjf+iBZOJyAQQMZ0A=='))
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(expanded_key) == compat_b64decode('Cz4hcgjf+iBZOJyAQQMZ0A==' + '+f9XxkKzPuLhgw==')



# Generated at 2022-06-18 13:02:21.333708
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176
    assert expanded_key[0:16] == key
    assert expanded_key[16:32] == [0xa0, 0xfa, 0xfe, 0x17, 0x88, 0x54, 0x2c, 0xb1, 0x23, 0xa3, 0x39, 0x39, 0x2a, 0x6c, 0x76, 0x05]

# Generated at 2022-06-18 13:02:33.825105
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:44.042693
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:56.006093
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:06.121892
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:17.593577
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:29.519382
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:42.669023
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7QX+FvQkJ9Bf9zQ4F9eg=='))
    expanded_key = bytes_to_intlist(compat_b64decode('gI7QX+FvQkJ9Bf9zQ4F9egNuLrWj9pVl3zsO1YUOt1M='))
    assert key_expansion(key) == expanded_key



# Generated at 2022-06-18 13:03:54.171199
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:02.370868
# Unit test for function key_expansion

# Generated at 2022-06-18 13:04:12.599340
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:20.437796
# Unit test for function key_expansion

# Generated at 2022-06-18 13:04:31.029808
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:42.237525
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:51.388429
# Unit test for function key_expansion

# Generated at 2022-06-18 13:04:58.652329
# Unit test for function key_expansion

# Generated at 2022-06-18 13:05:10.229830
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')

# Generated at 2022-06-18 13:05:32.837126
# Unit test for function key_expansion

# Generated at 2022-06-18 13:05:42.462470
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:53.999158
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')

# Generated at 2022-06-18 13:06:05.693841
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]