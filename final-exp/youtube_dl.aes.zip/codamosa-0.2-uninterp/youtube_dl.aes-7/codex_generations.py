

# Generated at 2022-06-18 12:56:38.399530
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    expanded_key = key_expansion(key)
    result = aes_encrypt(data, expanded_key)
    assert intlist_to_bytes(result) == compat_b64decode('3rebe0m41sTq/jLYTd7Ej5jbBZZqxM0EJ84LL7Ggzz0k=')



# Generated at 2022-06-18 12:56:49.244856
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-18 12:56:58.364632
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    expected = b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '
    result = aes_decrypt_text(data, password, key_size_bytes)
    assert result == expected

# Generated at 2022-06-18 12:57:10.827433
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:57:22.985668
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test for function aes_decrypt_text
    """
    import base64
    import random
    import string

    def random_string(length):
        """
        Generate random string
        """
        return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))

    def test(data, password, key_size_bytes):
        """
        Test for function aes_decrypt_text
        """
        decrypted_data = aes_decrypt_text(data, password, key_size_bytes)
        assert decrypted_data == b'Hello World!'


# Generated at 2022-06-18 12:57:29.585130
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('Cz4hcgjf+iBZ9ZjQXJ0/cw=='))
    expanded_key = bytes_to_intlist(compat_b64decode('Cz4hcgjf+iBZ9ZjQXJ0/cw=='
                                                    '9XcZj+OZPxHxKjm6y+b/wg=='
                                                    'QjQXJ0/cw=='))
    assert key_expansion(key) == expanded_key


# Generated at 2022-06-18 12:57:32.821979
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:57:43.524730
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QVkv3wVdW6dWgjSdr21w=='))
    iv = bytes_to_intlist(compat_b64decode('q83vVhve+F9eMmwTkXWc3g=='))
    data = bytes_to_intlist(compat_b64decode('Zm9vYmFy'))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('3f8f12f14ee3d743b4846a0fb57c45b4')



# Generated at 2022-06-18 12:57:56.474041
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('6C73D5240A948C86981BC294814D'))
    iv = bytes_to_intlist(compat_b64decode('3DAFBA429D9EB430B422DA802C9F'))
    data = bytes_to_intlist(compat_b64decode('F20BDBA6FF29EED7B046D1DF9FB7000058B1FFB4210A580F748B4AC714C001BD4A61044426FB515D'))

# Generated at 2022-06-18 12:58:06.334721
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value += 1
            return self.value

    data = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode(b'YELLOW SUBMARINE'))
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-18 12:58:21.448368
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QIuixkLQ9JqJ3vQOkcg=='))
    iv = bytes_to_intlist(compat_b64decode('qCiGt9m7BNW8tNtYzPqafQ=='))
    data = bytes_to_intlist(compat_b64decode('qCiGt9m7BNW8tNtYzPqafQ=='))
    assert aes_cbc_decrypt(data, key, iv) == bytes_to_intlist(b'\x00' * 16)


# Generated at 2022-06-18 12:58:29.531518
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 12:58:38.614107
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    expanded_key = key_expansion(key)
    decrypted_data = aes_decrypt(data, expanded_key)
    assert intlist_to_bytes(decrypted_data) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 12:58:49.631453
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-18 12:59:00.309330
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    expanded_key = key_expansion(key)
    decrypted_data = aes_decrypt(data, expanded_key)
    assert intlist_to_bytes(decrypted_data) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 12:59:12.804136
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vector from https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf
    key = bytes_to_intlist(compat_b64decode('U0hBMjU2IFRlc3QgS2V5'))
    cipher = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    expected_cleartext = bytes_to_intlist(compat_b64decode('6bc1bee22e409f96e93d7e117393172a'))
    expanded_key = key_

# Generated at 2022-06-18 12:59:22.965550
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]

# Generated at 2022-06-18 12:59:35.060860
# Unit test for function aes_decrypt

# Generated at 2022-06-18 12:59:43.867890
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .aes_cbc_encrypt import aes_cbc_encrypt
    from .aes_ctr_encrypt import aes_ctr_encrypt
    from .aes_ctr_decrypt import aes_ctr_decrypt
    from .aes_cbc_decrypt import aes_cbc_decrypt
    from .aes_ctr_counter import AESCounter
    from .aes_cbc_counter import AESCBCCounter
    from .aes_cbc_counter import AESCBCCounter
    from .aes_ctr_counter import AESCounter
    from .aes_cbc_encrypt import aes_cbc_encrypt
    from .aes_ctr_encrypt import aes_ctr_encrypt
    from .aes_ctr_decrypt import aes_ctr_decrypt

# Generated at 2022-06-18 12:59:54.959206
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * 16)
    data = bytes_to_intlist(b'\x00' * 16)
    assert aes_cbc_decrypt(data, key, iv) == [0] * 16

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * 16)
    data = bytes_to_intlist(b'\x00' * 32)
    assert aes_cbc_decrypt(data, key, iv) == [0] * 32

    key = bytes_to_intlist(b'YELLOW SUBMARINE')

# Generated at 2022-06-18 13:00:09.926004
# Unit test for function key_expansion

# Generated at 2022-06-18 13:00:21.048789
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:29.525482
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:40.941984
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:51.676917
# Unit test for function key_expansion
def test_key_expansion():
    # Test vectors from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # Appendix F.2.1 - Example Vectors for AES-128
    key = bytes_to_intlist(compat_b64decode('gZ6mYgYT6/B1CZpBfh0fIg=='))

# Generated at 2022-06-18 13:01:03.307261
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gZy6sIZ6wl9NJOKB-jnmVQ'))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:01:16.018267
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:28.327985
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:39.873853
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 13:01:52.163514
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:02:06.569862
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CQ5OuNyJ7v+V6ZuIj9xqww=='))

# Generated at 2022-06-18 13:02:17.700897
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:02:28.087300
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7QVkv3yq9qJIXwJzAQbQ=='))

# Generated at 2022-06-18 13:02:39.654449
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7O6WpXfV0Kt8kPjqYsMw=='))

# Generated at 2022-06-18 13:02:50.993609
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:02.189216
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:09.890629
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:21.713745
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('mFgEQmwgCAA='))
    expanded_key = bytes_to_intlist(compat_b64decode('mFgEQmwgCAAxNk0zNkFBMDhCRjdENzAxQTI3NUYzMkE3NjIxNkQ4RDdDQzA4MkM3MjhCQTExQTdFQTQwMkU2MkU3NjIxNkQ4RDdDQzA4MkM3MjhCQTExQTdFQTQwMkU2MkU='))
    assert key_expansion(key) == expanded_key


# Generated at 2022-06-18 13:03:32.588412
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI4nRqkPt3Q6NzF9c0XJbw=='))
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(expanded_key) == compat_b64decode('gI4nRqkPt3Q6NzF9c0XJbw==' + '0' * (176 - 16))

    key = bytes_to_intlist(compat_b64decode('gI4nRqkPt3Q6NzF9c0XJb3n4NfZj0Rtw'))
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(expanded_key) == compat_b64dec

# Generated at 2022-06-18 13:03:44.976597
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('Czc3Czc3Czc3Czc3Czc3Czc3Czc3Czc3Czc3Czc3Czc3Czc3Czc3Czc3Czc3Czc3'))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:04:00.926815
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CmU6/XFZOJzrWxlf2AQa+w=='))
    expanded_key = bytes_to_intlist(compat_b64decode('CmU6/XFZOJzrWxlf2AQa+wG+aZDz8VuXkfj1eVUj+6Y='))
    assert key_expansion(key) == expanded_key



# Generated at 2022-06-18 13:04:11.240802
# Unit test for function key_expansion

# Generated at 2022-06-18 13:04:19.485053
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176

# Generated at 2022-06-18 13:04:29.930366
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:41.159979
# Unit test for function key_expansion

# Generated at 2022-06-18 13:04:50.569698
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 13:04:57.931534
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:09.328599
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:21.336150
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:33.608850
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CQRiFZV4h4KThzk4+sRigw=='))
    expanded_key = key_expansion(key)