

# Generated at 2022-06-18 12:56:36.692927
# Unit test for function key_schedule_core
def test_key_schedule_core():
    data = [0x01, 0x02, 0x03, 0x04]
    data = key_schedule_core(data, 1)
    assert data == [0x01, 0x01, 0x01, 0x05]
    data = key_schedule_core(data, 2)
    assert data == [0x02, 0x02, 0x02, 0x0A]
    data = key_schedule_core(data, 3)
    assert data == [0x04, 0x04, 0x04, 0x14]
    data = key_schedule_core(data, 4)
    assert data == [0x08, 0x08, 0x08, 0x28]
    data = key_schedule_core(data, 5)

# Generated at 2022-06-18 12:56:48.138699
# Unit test for function aes_encrypt

# Generated at 2022-06-18 12:56:53.013356
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:57:04.201564
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_cbc import aes_cbc_decrypt
    from .aes_cbc import aes_cbc_encrypt
    from .aes_cbc import aes_cbc_decrypt
    from .aes_cbc import aes_cbc_encrypt
    from .aes_cbc import aes_cbc_decrypt
    from .aes_cbc import aes_cbc_encrypt
    from .aes_cbc import aes_cbc_decrypt
    from .aes_cbc import aes_cbc_encrypt
    from .aes_cbc import aes_cbc_decrypt
    from .aes_cbc import aes_cbc_encrypt
    from .aes_cbc import aes_cbc_decrypt
   

# Generated at 2022-06-18 12:57:15.707988
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuTqyj9J4l+ePZwLNhQ=='))
    iv = bytes_to_intlist(compat_b64decode('qT7XOJndT6nH1E8M9bMmGg=='))
    data = bytes_to_intlist(compat_b64decode('qT7XOJndT6nH1E8M9bMmGg=='))
    assert aes_cbc_decrypt(data, key, iv) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]


# Generated at 2022-06-18 12:57:27.939992
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    data = bytes_to_intlist(b'\x32\x43\xf6\xa8\x88\x5a\x30\x8d\x31\x31\x98\xa2\xe0\x37\x07\x34')
    expanded_key = key_expansion(key)
    cipher = aes_encrypt(data, expanded_key)

# Generated at 2022-06-18 12:57:39.237564
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(compat_b64decode("L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=="))
    key = bytes_to_intlist(compat_b64decode("YELLOW SUBMARINE"))
    expanded_key = key_expansion(key)
    assert aes_encrypt(data, expanded_key) == bytes_to_intlist(compat_b64decode("3K3k2s7K/5wOe/UOiKxbSQF9gF2tzcoj"))



# Generated at 2022-06-18 12:57:47.294656
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Test vectors from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # Appendix F.2.1 - CTR-AES128.Encrypt
    key = bytes_to_intlist(compat_b64decode('GZy6sIZ6wl9NJOKB-jnmVg'))
    counter = Counter(bytes_to_intlist(compat_b64decode('QA93SuHc3dJr6td0')))
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
   

# Generated at 2022-06-18 12:57:58.278628
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cbc import aes_cbc_encrypt
    from .aes_ecb import aes_ecb_encrypt
    from .aes_key_wrap import aes_key_unwrap
    from .aes_key_wrap import aes_key_wrap
    from .aes_ofb import aes_ofb_encrypt
    from .aes_cbc import aes_cbc_decrypt
    from .aes_ecb import aes_ecb_decrypt
    from .aes_ofb import aes_ofb_decrypt
    from .aes_cbc import aes_cbc_encrypt
    from .aes_ecb import aes_ecb_encrypt

# Generated at 2022-06-18 12:58:06.362669
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(b'\x32\x43\xf6\xa8\x88\x5a\x30\x8d\x31\x31\x98\xa2\xe0\x37\x07\x34')

# Generated at 2022-06-18 12:58:17.269604
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:58:24.322529
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:58:35.548262
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='))
    iv = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='))
    data = bytes_to_intlist(compat_b64decode('U3ByaW5nQmxhZGU='))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('bG9vYmFyIGlzIGEgZ3JlYXQgZGF0YWJhc2U=')



# Generated at 2022-06-18 12:58:44.879923
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test function aes_decrypt_text
    """
    import base64
    import os

    # Test vectors from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # Appendix F.3.1 - F.3.3

# Generated at 2022-06-18 12:58:58.014334
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:59:09.324655
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('gZH75aKtMNXdH40UhPkqTg=='))
    iv = bytes_to_intlist(compat_b64decode('qCiLQ9bO6j9TV4Mv'))
    data = bytes_to_intlist(compat_b64decode('XF4G4gszEKs='))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('3f8bfbbd5e05d44e68da725fc7f0b142')



# Generated at 2022-06-18 12:59:20.328938
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test function aes_decrypt_text
    """
    import base64
    import sys

    if sys.version_info[0] == 2:
        # Python 2
        import urllib
        urlopen = urllib.urlopen
    else:
        # Python 3
        import urllib.request
        urlopen = urllib.request.urlopen

    # Test vector from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    cipher = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'Password'
    key_size_bytes = 16

# Generated at 2022-06-18 12:59:31.925567
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * 16)
    data = bytes_to_intlist(b'\x00' * 16)
    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-18 12:59:41.821061
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import base64
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    # Test vectors from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # Appendix F.3.3  CTR-AES128.Encrypt
    # Appendix F.3.6  CTR-AES256.Encrypt

# Generated at 2022-06-18 12:59:52.601867
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:04.663112
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 13:00:15.785327
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cbc import aes_cbc_decrypt
    from .aes_cbc import aes_cbc_encrypt
    from .aes_cbc import test_aes_cbc_encrypt
    from .aes_cbc import test_aes_cbc_decrypt

    test_aes_cbc_encrypt()
    test_aes_cbc_decrypt()

    def test_aes_ctr_decrypt_helper(key, counter, data, expected):
        counter = AESCounter(counter)
        decrypted_data = aes_ctr_decrypt(data, key, counter)
        assert decrypted_data == expected

    # Test vectors from http://csrc.nist.gov/publications/nistpubs/

# Generated at 2022-06-18 13:00:25.978233
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, start_value):
            self.value = start_value

        def next_value(self):
            self.value += 1
            return bytes_to_intlist(compat_b64decode(b'K7gNU3sdo+OL0wNhqoVWhr3g6s1xYv72ol/pe/Unols='))

    key = bytes_to_intlist(compat_b64decode(b'ZAPnhUmwJosbtYXGm2eDsQ=='))
    data = bytes_to_intlist(compat_b64decode(b'+ywGJLW0Qj7DVvqzs3ZzTg=='))
    counter = Counter(0)
    decrypted

# Generated at 2022-06-18 13:00:35.808030
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value = intlist_to_bytes(
                bytes_to_intlist(self.value) + [1])
            return self.value

    key = compat_b64decode(b'ZAPnhwmwJ9JucA9ih00yuw==')
    counter = Counter(compat_b64decode(b'BgIAAACkAABSU0EyAAQAAAEAAQ=='))
    data = compat_b64decode(b'+/d4XdQ4Zz4G+8u1j7Y/w==')
    assert aes_ctr_decrypt(data, key, counter) == b'Hello World!'

# Unit

# Generated at 2022-06-18 13:00:40.745440
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'QWxhZGRpbjpvcGVuIHNlc2FtZQ=='
    password = 'password'
    key_size_bytes = 16
    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == b'Alice:open sesame'



# Generated at 2022-06-18 13:00:50.223829
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test function aes_decrypt_text
    """
    import os
    import sys
    import unittest

    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from youtube_dl.utils import encode_compat_str

    class TestAesDecryptText(unittest.TestCase):
        def test_aes_decrypt_text(self):
            self.assertEqual(
                aes_decrypt_text(
                    'XgwqhLlZt5Q=',
                    'test',
                    16),
                encode_compat_str('test'))

    unittest.main()



# Generated at 2022-06-18 13:01:01.476155
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 13:01:14.172614
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:26.983468
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_cipher import aes_encrypt
    from .aes_cipher import aes_decrypt
    from .aes_cipher import key_expansion
    from .aes_cipher import xor
    from .aes_cipher import aes_ctr_encrypt
    from .aes_cipher import aes_ctr_decrypt
    from .aes_cipher import Counter

    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    counter = Counter(0)

# Generated at 2022-06-18 13:01:29.985236
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'QVZBQk9SX1JFUVVFU1RfVE9fQ0hBUl9UWVBFX0hPTUU='
    password = 'password'
    key_size_bytes = 16
    assert aes_decrypt_text(data, password, key_size_bytes) == b'AES_REQUEST_TO_CHAR_TYPE_HOME'



# Generated at 2022-06-18 13:01:42.489230
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:55.155183
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:02:05.506824
# Unit test for function key_expansion

# Generated at 2022-06-18 13:02:16.736290
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:25.300033
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:37.485729
# Unit test for function key_expansion

# Generated at 2022-06-18 13:02:49.086579
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:00.117228
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:03:08.688020
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:21.487710
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:03:33.181718
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gZmv6ZW/6YWQ5Y2X5Y+L5YWz5LqU5a2m5Y+377yM5LiN5piv5ZCm5Y2X5Y+L5YWz5LqU5a2m5Y+3'))
    expanded_key = bytes_to_intlist(compat_b64decode('gZmv6ZW/6YWQ5Y2X5Y+L5YWz5LqU5a2m5Y+377yM5LiN5piv5ZCm5Y2X5Y+L5YWz5LqU5a2m5Y+3'))
    assert key_expansion(key) == expanded

# Generated at 2022-06-18 13:03:45.718464
# Unit test for function key_expansion

# Generated at 2022-06-18 13:03:56.834930
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-18 13:04:06.932941
# Unit test for function key_expansion

# Generated at 2022-06-18 13:04:16.465911
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7+/8q/xjQDYK3hjSb5Mg=='))
    expanded_key = bytes_to_intlist(compat_b64decode('gI7+/8q/xjQDYK3hjSb5Mg=='))
    assert key_expansion(key) == expanded_key

    key = bytes_to_intlist(compat_b64decode('gI7+/8q/xjQDYK3hjSb5Mg=='))
    expanded_key = bytes_to_intlist(compat_b64decode('gI7+/8q/xjQDYK3hjSb5Mg=='))
    assert key_exp

# Generated at 2022-06-18 13:04:26.223659
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:37.021780
# Unit test for function key_expansion

# Generated at 2022-06-18 13:04:48.103251
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:04:56.328152
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('Cz4hcj+7ZyNxTqmR7u3B3g=='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:05:08.077037
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CQ2/yQ=='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:05:21.823799
# Unit test for function key_expansion
def test_key_expansion():
    key_128 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:34.703377
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:40.818244
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7+JXqeB0JYMqyb5Z5LNw=='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:05:48.022589
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CY9rzUYh03PK3k6DJie09g=='))
    expected = bytes_to_intlist(compat_b64decode('xMqh7cKZj6Y0fcjh8ul+VgMgYtLkCz64m8gVtM3Lf9M='))
    assert key_expansion(key) == expected



# Generated at 2022-06-18 13:05:58.005959
# Unit test for function key_expansion
def test_key_expansion():
    """
    Test key_expansion
    """
    key_16 = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    key_24 = bytes_to_intlist(b'\x8e\x73\xb0\xf7\xda\x0e\x64\x52\xc8\x10\xf3\x2b\x80\x90\x79\xe5\x62\xf8\xea\xd2\x52\x2c\x6b\x7b')

# Generated at 2022-06-18 13:06:08.524043
# Unit test for function key_expansion