

# Generated at 2022-06-18 12:56:46.411937
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * 16)

# Generated at 2022-06-18 12:56:55.546955
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode(b'YELLOW SUBMARINE'))
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)
    assert intlist_to_bytes(decrypted_data) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 12:57:07.668663
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Test vector from https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf
    # Appendix C.1
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    plain

# Generated at 2022-06-18 12:57:20.001772
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuTqej9qdM1M/Zwv6w=='))
    iv = bytes_to_intlist(compat_b64decode('q9+E3L7vW/0='))
    cipher = bytes_to_intlist(compat_b64decode('q9+E3L7vW/0=\n'))
    assert aes_cbc_decrypt(cipher, key, iv) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]


# Generated at 2022-06-18 12:57:32.070385
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test function aes_decrypt_text
    """
    import base64
    import sys

    if sys.version_info[0] == 2:
        import unittest2 as unittest
    else:
        import unittest


# Generated at 2022-06-18 12:57:43.351164
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .utils import bytes_to_intlist, intlist_to_bytes
    from .compat import compat_b64decode
    from .aes_cipher import aes_cipher
    from .aes_counter import aes_counter

    # Test vector from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    key = bytes_to_intlist(compat_b64decode(b'GawgguFyGrWKav7AX4VKUg'))
    counter = aes_counter(bytes_to_intlist(compat_b64decode(b'Q0h6YluF3YM7oARJ5Jlf/A')))

# Generated at 2022-06-18 12:57:56.337080
# Unit test for function key_expansion

# Generated at 2022-06-18 12:58:05.661703
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = [0] * 16
    data = bytes_to_intlist(b'hello world')
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == b'\x9b\x9b\x9b\x9b\x9b\x9b\x9b\x9b\x9b\x9b\x9b\x9b\x9b\x9b\x9b\x9b'
    print('test_aes_cbc_encrypt passed')

test_aes_cbc_encrypt()


# Generated at 2022-06-18 12:58:15.798305
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'Q0RCLUJBU0U2NC1TSEEyNTYtQ0hBTkdF'
    password = 'password'
    key_size_bytes = 32
    expected_result = '{"ct":"Q0RCLUJBU0U2NC1TSEEyNTYtQ0hBTkdF","s":"Q0RCLUJBU0U2NC1TSEEyNTYtQ0hBTkdF","hint":"Q0RCLUJBU0U2NC1TSEEyNTYtQ0HBTkdF"}'
    assert aes_decrypt_text(data, password, key_size_bytes) == expected_result



# Generated at 2022-06-18 12:58:26.261287
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7mKxJjG9uZ6eix3l0nVA=='))
    iv = bytes_to_intlist(compat_b64decode('XgxjYW1lZGlhbw=='))
    data = bytes_to_intlist(compat_b64decode('XgxjYW1lZGlhbw=='))
    decrypted_data = aes_cbc_decrypt(data, key, iv)
    assert decrypted_data == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]


# Generated at 2022-06-18 12:58:34.145607
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 1]) == [0, 0, 0, 2]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]

test_inc()


# Generated at 2022-06-18 12:58:42.090119
# Unit test for function inc
def test_inc():
    assert inc([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x01]
    assert inc([0x00, 0x00, 0x00, 0xFF]) == [0x00, 0x00, 0x01, 0x00]
    assert inc([0x00, 0x00, 0xFF, 0xFF]) == [0x00, 0x01, 0x00, 0x00]
    assert inc([0x00, 0xFF, 0xFF, 0xFF]) == [0x01, 0x00, 0x00, 0x00]
    assert inc([0xFF, 0xFF, 0xFF, 0xFF]) == [0x00, 0x00, 0x00, 0x00]



# Generated at 2022-06-18 12:58:49.324577
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:58:57.348086
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:59:04.417117
# Unit test for function inc
def test_inc():
    assert inc([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x01]
    assert inc([0x00, 0x00, 0x00, 0xFF]) == [0x00, 0x00, 0x01, 0x00]
    assert inc([0x00, 0x00, 0xFF, 0xFF]) == [0x00, 0x01, 0x00, 0x00]
    assert inc([0x00, 0xFF, 0xFF, 0xFF]) == [0x01, 0x00, 0x00, 0x00]
    assert inc([0xFF, 0xFF, 0xFF, 0xFF]) == [0x00, 0x00, 0x00, 0x00]



# Generated at 2022-06-18 12:59:16.477667
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CQ5O3YqX7fu9S4rf/gMh4w=='))

# Generated at 2022-06-18 12:59:22.330528
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:59:29.621050
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:59:36.616615
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:59:45.733849
# Unit test for function inc
def test_inc():
    data = [0, 0, 0, 0]
    data = inc(data)
    assert data == [0, 0, 0, 1]
    data = inc(data)
    assert data == [0, 0, 1, 0]
    data = inc(data)
    assert data == [0, 0, 1, 1]
    data = inc(data)
    assert data == [0, 1, 0, 0]
    data = inc(data)
    assert data == [0, 1, 0, 1]
    data = inc(data)
    assert data == [0, 1, 1, 0]
    data = inc(data)
    assert data == [0, 1, 1, 1]
    data = inc(data)
    assert data == [1, 0, 0, 0]
    data = inc(data)

# Generated at 2022-06-18 12:59:58.048573
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:10.194827
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:21.283172
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:29.671796
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7JY+u6/3qbqQN/z7nDQ=='))

# Generated at 2022-06-18 13:00:41.046133
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:51.827701
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:03.477858
# Unit test for function key_expansion

# Generated at 2022-06-18 13:01:16.118451
# Unit test for function key_expansion

# Generated at 2022-06-18 13:01:28.417088
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:39.957508
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:55.537800
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:05.766083
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode(b'C9vKl+k3eX8Kk4jvKw=='))

# Generated at 2022-06-18 13:02:17.013982
# Unit test for function key_expansion

# Generated at 2022-06-18 13:02:24.710090
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:36.837589
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:48.328952
# Unit test for function key_expansion
def test_key_expansion():
    data = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    data = key_expansion(data)

# Generated at 2022-06-18 13:02:59.221466
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('Cz0sPQo='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:03:08.253563
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:21.021741
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:31.980459
# Unit test for function key_expansion

# Generated at 2022-06-18 13:03:49.577351
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:56.525328
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7F+YFwUZVFMmRzkPZFTw=='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:04:06.492718
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:04:16.098764
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('Cz0qb+uXyBfVlHs/X9lQ7Q=='))

# Generated at 2022-06-18 13:04:25.742223
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:36.364873
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:47.595144
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:55.867569
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:07.053240
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:18.842053
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI0GAILBdukQOQ=='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:05:41.166651
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')

# Generated at 2022-06-18 13:05:52.895517
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:06:00.755952
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7QX+XeVYM8eDQzNrNxZg=='))
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176