

# Generated at 2022-06-18 12:56:27.732657
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes import aes_encrypt
    from .aes import key_expansion
    from .aes import aes_decrypt
    from .aes import aes_ctr_encrypt
    from .aes import aes_ctr_decrypt
    from .aes import Counter

    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    counter = Counter(0)

# Generated at 2022-06-18 12:56:32.814336
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='))
    iv = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='))
    data = bytes_to_intlist(compat_b64decode('U3ByaW5nQmxhZGU='))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('CY9rzj1vb/gNkH+KjE+RQ==')



# Generated at 2022-06-18 12:56:42.436389
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Test vector from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'password'
    key_size_bytes = 16
    expected_plaintext = 'Basic CBC mode encryption needs padding.'

    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == expected_plaintext



# Generated at 2022-06-18 12:56:48.999865
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    expected_plaintext = b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '
    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == expected_plaintext



# Generated at 2022-06-18 12:56:54.840731
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    expected = b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '
    result = aes_decrypt_text(data, password, key_size_bytes)
    assert result == expected



# Generated at 2022-06-18 12:57:06.675581
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value = (self.value + 1) % (2 ** 64)
            return intlist_to_bytes(self.value, 8)

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    counter = Counter(0)
    data = bytes_to_intlist(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')
    data = compat_b64decode(intlist_to_bytes(data))
    data = bytes_to_intlist(data)
    decrypted_data

# Generated at 2022-06-18 12:57:19.177022
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Test vector from https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf
    key = bytes_to_intlist(compat_b64decode('2b7e151628aed2a6abf7158809cf4f3c'))
    data = bytes_to_intlist(compat_b64decode('3243f6a8885a308d313198a2e0370734'))
    expected = bytes_to_intlist(compat_b64decode('3925841d02dc09fbdc118597196a0b32'))
    expanded_key = key_expansion(key)
    actual = aes_encrypt(data, expanded_key)
    assert actual == expected



# Generated at 2022-06-18 12:57:23.607560
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:57:35.400968
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='))
    iv = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='))
    data = bytes_to_intlist(compat_b64decode('U3ByaW5nQmxhZGU='))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('zM6xnF/WjW9hIW+/7eX+aw==')


# Generated at 2022-06-18 12:57:45.617145
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Test vector from NIST SP 800-38A
    # http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # Appendix F.1.1 AES-128 (Nk=4, Nr=10)
    key = bytes_to_intlist(compat_b64decode('gUuT/zJ1sHZ5m7D3j+WqTA=='))
    plaintext = bytes_to_intlist(compat_b64decode('6bc1bee22e409f96e93d7e117393172a'))
    ciphertext = bytes_to_intlist(compat_b64decode('f58c4c04d6e5f1ba779eabfb5f7bfbd6'))
    expanded

# Generated at 2022-06-18 12:58:00.901105
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 12:58:12.565598
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = [0] * 16

# Generated at 2022-06-18 12:58:24.324160
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7F+YJQ/Zc9jB1p/d+XrQ=='))
    iv = bytes_to_intlist(compat_b64decode('ZmI5YzY5NzMwNjI0MjE0Mg=='))

# Generated at 2022-06-18 12:58:35.543920
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test vector from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # Appendix F.2.5 CBC-AES256.Encrypt
    key = bytes_to_intlist(compat_b64decode(
        'gI0GAILBdu7T53akrFmMyTAnVKmC+NmpdRq2l/MJqg='))
    iv = bytes_to_intlist(compat_b64decode(
        'lT2UvDUmQwewm6mMoiw4Ig=='))
    data = bytes_to_intlist(compat_b64decode(
        'D0U0zjfJ1MlYs3aAQ9xjQg=='))


# Generated at 2022-06-18 12:58:42.021020
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuTqeX8YKFj6zs0FJg=='))
    iv = bytes_to_intlist(compat_b64decode('qT7XOJLcKlYM65pX9EIeOA=='))
    cipher = bytes_to_intlist(compat_b64decode('qT7XOJLcKlYM65pX9EIeOA=='))
    plain = bytes_to_intlist(compat_b64decode('qT7XOJLcKlYM65pX9EIeOA=='))
    assert aes_cbc_decrypt(cipher, key, iv) == plain



# Generated at 2022-06-18 12:58:54.324045
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vectors from http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    # Appendix C.1
    key = bytes_to_intlist(compat_b64decode('2b7e151628aed2a6abf7158809cf4f3c'))
    expanded_key = key_expansion(key)
    cipher = bytes_to_intlist(compat_b64decode('3ad77bb40d7a3660a89ecaf32466ef97'))
    plain = aes_decrypt(cipher, expanded_key)
    assert plain == bytes_to_intlist(compat_b64decode('6bc1bee22e409f96e93d7e117393172a'))

    # Appendix C.2
    key

# Generated at 2022-06-18 12:59:02.519449
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QDZuM7C6KOkLz0ILu5g=='))
    iv = bytes_to_intlist(compat_b64decode('qCiGt9mhYMKY+5M8WLKXOQ=='))
    data = bytes_to_intlist(compat_b64decode('XvM9C/e0b/8DQjqejvqejg=='))
    assert aes_cbc_decrypt(data, key, iv) == bytes_to_intlist(b'abcdefghijklmnop')



# Generated at 2022-06-18 12:59:14.788908
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 12:59:23.852052
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    iv = bytes_to_intlist(compat_b64decode('AxY8DCtDaGlsbGljb3RoZQ=='))
    cipher = bytes_to_intlist(compat_b64decode('f20bdba6ff29eed7b046d1df9fb7000058b1ffb4210a580f748b4ac714c001bd4a61044426fb515dad3f21f18aa577c0bdf302936266926ff37dbf7035d5eeb4'))

# Generated at 2022-06-18 12:59:35.933684
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 12:59:47.060833
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('/QS5z6TkYWf9cGyjq/RzXZg=='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 12:59:57.901753
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:10.035527
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:21.141402
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:29.556220
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:40.989352
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7+3qkJi0/Y1Md1/TjbPw=='))

# Generated at 2022-06-18 13:00:51.726976
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:03.360277
# Unit test for function key_expansion

# Generated at 2022-06-18 13:01:16.018821
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:28.327813
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:41.693738
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:53.902238
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:04.809530
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI2DV/vK8sL+KjRv1ZJbvA=='))

# Generated at 2022-06-18 13:02:15.481307
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:02:23.963310
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:36.177287
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:47.773773
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:58.705672
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7mKjbU6JXqZu2WZ+vf0w=='))

# Generated at 2022-06-18 13:03:07.925454
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-18 13:03:20.743154
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:34.668456
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:03:47.236086
# Unit test for function key_expansion
def test_key_expansion():
    test_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:58.052640
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:08.284492
# Unit test for function key_expansion
def test_key_expansion():
    key_16 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:17.432826
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:27.239144
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:33.810432
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CmU/9qh1E1lhsu9rD4UHrw=='))
    expanded_key = bytes_to_intlist(compat_b64decode('CmU/9qh1E1lhsu9rD4UHrwgq0+lz3n3x/v9xH7jY6fk='))
    assert key_expansion(key) == expanded_key



# Generated at 2022-06-18 13:04:45.642453
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:53.567578
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:00.238015
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CzkqX3JtM2JkN2RlNzRmM2Q0ZjNkNmYzZDZmM2Q2ZjNkNmYzZA=='))

# Generated at 2022-06-18 13:05:18.074825
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CY9rzUYh03PK3k6DJie09g=='))
    expanded_key = bytes_to_intlist(compat_b64decode('xCyEvnBf6Qk9LmRs3/Ao0MxF9nulO8DZuwOlIy1Bg8U='))
    assert key_expansion(key) == expanded_key



# Generated at 2022-06-18 13:05:26.573857
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:37.830508
# Unit test for function key_expansion

# Generated at 2022-06-18 13:05:49.718584
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:54.798139
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7W6cYbvf7P3VQrpTt0Ow=='))

# Generated at 2022-06-18 13:06:06.544446
# Unit test for function key_expansion