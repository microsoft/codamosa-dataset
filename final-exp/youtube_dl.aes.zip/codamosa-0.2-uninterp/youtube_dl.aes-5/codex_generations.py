

# Generated at 2022-06-18 12:56:26.474666
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns(data)
    assert data_mixed == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns(data, MIX_COLUMN_MATRIX_INV)

# Generated at 2022-06-18 12:56:38.603897
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import base64
    import random
    import string

    def random_string(length):
        return ''.join(random.choice(string.ascii_letters) for _ in range(length))

    def random_bytes(length):
        return bytes_to_intlist([random.randint(0, 255) for _ in range(length)])

    def test_decrypt(data, password, key_size_bytes):
        decrypted_data = aes_decrypt_text(data, password, key_size_bytes)
        assert decrypted_data == plaintext

    for _ in range(100):
        plaintext = random_string(random.randint(1, 100))
        password = random_string(random.randint(1, 32))
        key_size_bytes = random.choice([16, 24, 32])



# Generated at 2022-06-18 12:56:47.902304
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    counter = Counter(0)
    assert intlist_to_bytes(aes_ctr_decrypt(data, key, counter)) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '


# Generated at 2022-06-18 12:56:57.777338
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns(data)
    assert data_mixed == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns(data_mixed, MIX_COLUMN_MATRIX_INV)
    assert data_mixed

# Generated at 2022-06-18 12:57:09.423670
# Unit test for function key_expansion

# Generated at 2022-06-18 12:57:22.079514
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 12:57:33.936845
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='))
    iv = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='))
    data = bytes_to_intlist(compat_b64decode('5Zu95a6M5q+U5Lit5paH5Lu2'))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('c+3hFGPjbgzGdrC+MHgoRQ==')



# Generated at 2022-06-18 12:57:44.617384
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 12:57:57.561680
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns(data)
    assert data_mixed == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns(data_mixed, MIX_COLUMN_MATRIX_INV)
    assert data_mixed

# Generated at 2022-06-18 12:58:06.362552
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test vector from https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf
    key = bytes_to_intlist(compat_b64decode('2b7e151628aed2a6abf7158809cf4f3c'))
    iv = bytes_to_intlist(compat_b64decode('000102030405060708090a0b0c0d0e0f'))
    data = bytes_to_intlist(compat_b64decode('7649abac8119b246cee98e9b12e9197d'))

# Generated at 2022-06-18 12:58:35.880523
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    cipher = [0x39, 0x25, 0x84, 0x1d, 0x02, 0xdc, 0x09, 0xfb, 0xdc, 0x11, 0x85, 0x97, 0x19, 0x6a, 0x0b, 0x32]
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 12:58:45.441562
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, start):
            self.start = start

        def next_value(self):
            self.start += 1
            return self.start

    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:58:58.681128
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuTqeVl0g1M1iX+eDw=='))
    iv = bytes_to_intlist(compat_b64decode('qCiM3VF9xN9xN9xN9xN9xN9xN9xN9xN9'))

# Generated at 2022-06-18 12:59:11.217487
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vector from http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    cipher = bytes_to_intlist(compat_b64decode('0EC7702330098CE7F7520D1CBBB20FC388D1B0ADB5054DBD7370849DBF0B88D393F252E764F1F5F7AD97EF79D59CE29F5F51EECA32EABEDC9C6E87DD75E7A21D2330807252AE0066D59CEEFA5F2748EA80BAB81'))
    state = bytes

# Generated at 2022-06-18 12:59:21.947579
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('C8E7B9E2B1E4F7A0D2FDD4D38CB58BDB'))
    iv = bytes_to_intlist(compat_b64decode('00000000000000000000000000000000'))
    data = bytes_to_intlist(compat_b64decode('E8F0A1A9B9D9A8C8E8F0A1A9B9D9A8C8'))
    decrypted_data = aes_cbc_decrypt(data, key, iv)

# Generated at 2022-06-18 12:59:33.773683
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = bytes_to_intlist(compat_b64decode('K7gNU3sdo+OL0wNhqoVWhr3g6s1xYv72ol/pe/Unols='))
    data = bytes_to_intlist(compat_b64decode('XvM5DJpQJ3UQ2sDZzNtjFw=='))
    counter = Counter(bytes_to_intlist(compat_b64decode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXoxMjM0NTY3OA==')))

# Generated at 2022-06-18 12:59:43.148260
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:59:54.227277
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value = intlist_to_bytes(
                intlist_to_bytes(self.value) + 1)
            return bytes_to_intlist(self.value)

    data = bytes_to_intlist(compat_b64decode(
        'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode(
        'YELLOW SUBMARINE'))

# Generated at 2022-06-18 13:00:03.746503
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vector from FIPS-197
    key = bytes_to_intlist(compat_b64decode('2b7e151628aed2a6abf7158809cf4f3c'))
    cipher = bytes_to_intlist(compat_b64decode('3ad77bb40d7a3660a89ecaf32466ef97'))
    expanded_key = key_expansion(key)
    assert aes_decrypt(cipher, expanded_key) == bytes_to_intlist(compat_b64decode('6bc1bee22e409f96e93d7e117393172a'))



# Generated at 2022-06-18 13:00:14.956072
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cipher import aes_encrypt
    from .aes_cipher import aes_decrypt
    from .aes_cipher import key_expansion
    from .aes_cipher import xor

    # Test vectors from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:39.144521
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    expected_plaintext = 'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '

    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == expected_plaintext



# Generated at 2022-06-18 13:00:49.938023
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 13:01:01.051119
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import base64
    import binascii
    import os
    import random
    import string

    def random_string(length):
        return ''.join(random.choice(string.ascii_letters) for _ in range(length))

    def random_bytes(length):
        return os.urandom(length)

    def random_intlist(length):
        return [random.randint(0, 255) for _ in range(length)]

    def random_intlist_of_length(length):
        return random_intlist(random.randint(0, length))

    def random_intlist_of_length_multiple_of(length):
        return random_intlist(random.randint(0, length) * length)


# Generated at 2022-06-18 13:01:13.784416
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value = intlist_to_bytes(
                intlist_to_bytes(self.value) + 1)
            return bytes_to_intlist(self.value)

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    counter = Counter(b'\x00' * BLOCK_SIZE_BYTES)
    data = bytes_to_intlist(b'\x00' * BLOCK_SIZE_BYTES)
    assert aes_ctr_decrypt(data, key, counter) == [0] * BLOCK_SIZE_BYTES


# Generated at 2022-06-18 13:01:26.375963
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .utils import bytes_to_intlist, intlist_to_bytes

    class TestCounter(AESCounter):
        def __init__(self, counter_block):
            self.counter_block = counter_block
            self.counter = 0

        def next_value(self):
            self.counter += 1
            return self.counter_block

    key = bytes_to_intlist(compat_b64decode('K7gNU3sdo+OL0wNhqoVWhr3g6s1xYv72ol/pe/Unols='))
    counter_block = bytes_to_intlist(compat_b64decode('f2c7f0e3c80d4c3c'))

# Generated at 2022-06-18 13:01:31.735628
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 13:01:41.178359
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(compat_b64decode(
        'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode(
        'YELLOW SUBMARINE'))
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)
    assert intlist_to_bytes(decrypted_data) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 13:01:53.549543
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cbc import aes_cbc_decrypt
    from .aes_cbc import aes_cbc_encrypt
    from .aes_cbc import test_aes_cbc_encrypt
    from .aes_cbc import test_aes_cbc_decrypt

    test_aes_cbc_encrypt()
    test_aes_cbc_decrypt()

    key = bytes_to_intlist(compat_b64decode('K7gNU3sdo+OL0wNhqoVWhr3g6s1xYv72ol/pe/Unols='))

# Generated at 2022-06-18 13:02:04.557247
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import base64
    import json
    import os
    import sys

    from .utils import bytes_to_intlist, intlist_to_bytes

    if sys.version_info >= (3, 0):
        unicode = str

    # Test vectors from https://tools.ietf.org/html/rfc3686

# Generated at 2022-06-18 13:02:15.134627
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value += 1
            return self.value

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    data = bytes_to_intlist(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)
    assert intlist_to_bytes(decrypted_data) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 13:02:29.794406
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 13:02:37.661224
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]
    print("test_inc() passed")

test_inc()


# Generated at 2022-06-18 13:02:49.278939
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:58.918175
# Unit test for function inc
def test_inc():
    data = [0, 0, 0, 0]
    assert inc(data) == [0, 0, 0, 1]
    assert inc(data) == [0, 0, 0, 2]
    data = [0, 0, 0, 255]
    assert inc(data) == [0, 0, 1, 0]
    data = [0, 0, 255, 255]
    assert inc(data) == [0, 1, 0, 0]
    data = [0, 255, 255, 255]
    assert inc(data) == [1, 0, 0, 0]
    data = [255, 255, 255, 255]
    assert inc(data) == [0, 0, 0, 0]

# Generated at 2022-06-18 13:03:08.089822
# Unit test for function inc
def test_inc():
    assert inc([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x01]
    assert inc([0x00, 0x00, 0x00, 0xFF]) == [0x00, 0x00, 0x01, 0x00]
    assert inc([0x00, 0x00, 0xFF, 0xFF]) == [0x00, 0x01, 0x00, 0x00]
    assert inc([0x00, 0xFF, 0xFF, 0xFF]) == [0x01, 0x00, 0x00, 0x00]
    assert inc([0xFF, 0xFF, 0xFF, 0xFF]) == [0x00, 0x00, 0x00, 0x00]



# Generated at 2022-06-18 13:03:10.601471
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 13:03:13.065176
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 13:03:15.949254
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 13:03:22.346948
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CQ2N/j0a/l8='))
    expanded_key = bytes_to_intlist(compat_b64decode('CQ2N/j0a/l8+XqE3h/gO8+QMb+/y0+q3w/l8='))
    assert key_expansion(key) == expanded_key



# Generated at 2022-06-18 13:03:30.001706
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 13:03:43.207229
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:03:54.681883
# Unit test for function key_expansion
def test_key_expansion():
    assert key_expansion(bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))) == bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    assert key_expansion(bytes_to_intlist(compat_b64decode('2AvVhdsgUs0FSA3SDFAdag=='))) == bytes_to_intlist(compat_b64decode('2AvVhdsgUs0FSA3SDFAdag=='))
    assert key_expansion(bytes_to_intlist(compat_b64decode('3AvVhmFLUs0KTA3Kprsdag=='))) == bytes_to

# Generated at 2022-06-18 13:04:00.323166
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CY9rzUYh03PK3k6DJie09g=='))
    expanded_key = bytes_to_intlist(compat_b64decode('xCyev1Wj4oLkF0aXFcJ0T8r/Y9nL8uP+CdfGtUYh03PK3k6DJie09g=='))
    assert key_expansion(key) == expanded_key



# Generated at 2022-06-18 13:04:06.952738
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode(b'CY9rzUYh03PK3k6DJie09g=='))
    expected = bytes_to_intlist(compat_b64decode(b'xMqh9HZ0KsAo6j1+h2mvXtW0QsN4EtVg5RkLKVSe8k8='))
    assert key_expansion(key) == expected



# Generated at 2022-06-18 13:04:16.506051
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:26.267484
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('Cz0nNy9kYXNoYm9hcmQ='))

# Generated at 2022-06-18 13:04:37.066773
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:48.103391
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:04:56.328554
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:07.829845
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CQkFBAoFBQ=='))

# Generated at 2022-06-18 13:05:22.297613
# Unit test for function key_expansion
def test_key_expansion():
    key_size_bytes = 16
    key = [0] * key_size_bytes
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176
    assert expanded_key[:key_size_bytes] == key

    key_size_bytes = 24
    key = [0] * key_size_bytes
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 208
    assert expanded_key[:key_size_bytes] == key

    key_size_bytes = 32
    key = [0] * key_size_bytes
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 240
    assert expanded_key[:key_size_bytes] == key


# Generated at 2022-06-18 13:05:35.340275
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:44.096965
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:55.672850
# Unit test for function key_expansion

# Generated at 2022-06-18 13:06:07.000239
# Unit test for function key_expansion