

# Generated at 2022-06-18 12:56:30.529879
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:56:41.941650
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, initial_value):
            self.value = initial_value

        def next_value(self):
            self.value += 1
            return bytes_to_intlist(compat_b64decode(
                'Zm9vYmFy'))

    key = bytes_to_intlist(compat_b64decode('QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejEyMzQ1Njc4OTA='))

# Generated at 2022-06-18 12:56:50.435464
# Unit test for function key_expansion

# Generated at 2022-06-18 12:57:02.847558
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value += 1
            return self.value

    data = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode(b'YELLOW SUBMARINE'))
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-18 12:57:14.795470
# Unit test for function key_expansion

# Generated at 2022-06-18 12:57:27.330485
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Test vector from http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    key = bytes_to_intlist(compat_b64decode('U0hBMjU2X1JTQV9LRVlfVFlQRQ=='))
    data = bytes_to_intlist(compat_b64decode('U0hBMjU2X1JTQV9LRVlfVFlQRQ=='))
    expected = bytes_to_intlist(compat_b64decode('QkFTRV9DSEFSX1RFWFQ='))
    expanded_key = key_expansion(key)
    result = aes_encrypt(data, expanded_key)
    assert result == expected


# Generated at 2022-06-18 12:57:31.458645
# Unit test for function mix_columns
def test_mix_columns():
    data = [0xdb, 0x13, 0x53, 0x45, 0xf2, 0x0a, 0x22, 0x5c, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns(data)
    assert data_mixed == [0x8e, 0x4d, 0xa1, 0xbc, 0x9f, 0xdc, 0x58, 0x9d, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]
    data_mixed = mix_columns(data_mixed, MIX_COLUMN_MATRIX_INV)
    assert data_mixed

# Generated at 2022-06-18 12:57:43.010232
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Test vectors from https://github.com/videojs/http-streaming/blob/master/test/fixtures/aes-128-cbc-hmac-sha1.txt
    # IV = 0x00000000000000000000000000000000
    # KEY = 0x00000000000000000000000000000000
    # CIPHER = 0xC8DDF76B5D9EBCFA9AE9C9C2A8463A9A
    # PLAINTEXT = 0x00000000000000000000000000000000
    # HMAC = 0xBB1D6929E95937287FA37D129B756746
    assert aes_decrypt_text(
        'C8DDF76B5D9EBCFA9AE9C9C2A8463A9A',
        '',
        16
    ) == b'\x00' * 16

    # IV = 0x

# Generated at 2022-06-18 12:57:54.326264
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    expanded_key = key_expansion(key)
    assert aes_encrypt(data, expanded_key) == bytes_to_intlist(compat_b64decode('3K3k2s7eVNljYQ=='))



# Generated at 2022-06-18 12:58:04.157838
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, initial_value):
            self.value = initial_value

        def next_value(self):
            self.value = (self.value + 1) % (2 ** 64)
            return intlist_to_bytes(self.value, 8)

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    counter = Counter(0)
    cipher = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    plain = aes_ctr_decrypt(cipher, key, counter)
    assert intlist_to

# Generated at 2022-06-18 12:58:17.691881
# Unit test for function key_expansion

# Generated at 2022-06-18 12:58:27.450395
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='))
    iv = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='))
    data = bytes_to_intlist(compat_b64decode('U3ByaW5nQmxhZGU='))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('4kFqezaQzKVuP3LKx1uPjw==')



# Generated at 2022-06-18 12:58:38.480921
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QDZmQ0Ll5f5yBxZDpzA=='))
    iv = bytes_to_intlist(compat_b64decode('q83zs6+L3lYj78bB3r1rOw=='))
    data = bytes_to_intlist(compat_b64decode('nh6zLpJnH7LjVRKuAfWwx5j3dK6i4TqKm0X+Qz+RM6w='))
    decrypted_data = aes_cbc_decrypt(data, key, iv)

# Generated at 2022-06-18 12:58:49.492484
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:59:00.795338
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vector from http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    expanded_key = key_expansion(key)
    assert aes_decrypt(data, expanded_key) == bytes_to_intlist(b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby ')



# Generated at 2022-06-18 12:59:12.968870
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode(b'6Cf1Z9aWtWOMdaP9GbB4hQ=='))
    iv = bytes_to_intlist(compat_b64decode(b'qT7uFRhkaljV60AK'))
    data = bytes_to_intlist(compat_b64decode(b'+9hG1DqJ9WV5vHt0oQ=='))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode(b'+9hG1DqJ9WV5vHt0oQ==')



# Generated at 2022-06-18 12:59:21.816267
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode(b'6C3EA0477630CE21A2CE334AA746C2CD'))
    iv = bytes_to_intlist(compat_b64decode(b'C782DC4C098C66CBD9CD27D825682C81'))
    data = bytes_to_intlist(b'Single block msg')
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode(b'5104A106168A72D9790D41EE8EDAD388')



# Generated at 2022-06-18 12:59:31.979187
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QDZuM7C3zJmc2+Jq4mg=='))
    iv = bytes_to_intlist(compat_b64decode('qCiGt9F2uiiTvcwD6jQ7bQ=='))
    data = bytes_to_intlist(compat_b64decode('qCiGt9F2uiiTvcwD6jQ7bQ=='))
    assert aes_cbc_decrypt(data, key, iv) == bytes_to_intlist(b'\x00' * 16)



# Generated at 2022-06-18 12:59:41.849973
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = [0] * BLOCK_SIZE_BYTES
    data = bytes_to_intlist(b'hello world')
    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-18 12:59:52.650504
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    iv = bytes_to_intlist(compat_b64decode('AxY8DCtDaGlsbGljb3RoZQ=='))
    data = bytes_to_intlist(compat_b64decode('KDlTtgcJZRt33+7Y07qwqw=='))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    encrypted_data_expected = bytes_to_intlist(compat_b64decode('3up8VbbDSG6Rb5vzf7kZsQ=='))
    assert encrypted_data == encrypted_data_expected


# Generated at 2022-06-18 13:00:07.395840
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:18.953198
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:28.061106
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:39.197690
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:49.989145
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:01:01.102574
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:01:13.784160
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:26.375739
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:31.735121
# Unit test for function key_expansion

# Generated at 2022-06-18 13:01:38.864718
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CQ2s4+X9Zq4='))
    expanded_key = bytes_to_intlist(compat_b64decode('CQ2s4+X9Zq4=BVnhJz5LZDQF8G1+p/jvYQ5JY+Y9Q8='))
    assert key_expansion(key) == expanded_key



# Generated at 2022-06-18 13:01:51.001767
# Unit test for function key_expansion
def test_key_expansion():
    # Test vector from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    key = bytes_to_intlist(compat_b64decode('gI0GAILBdu7F03ohF2ffWw=='))
    expanded_key = bytes_to_intlist(compat_b64decode('gI0GAILBdu7F03ohF2ffWwvICgRQJqVuQbxvwquPQS87tk+iNk0ZXfDgAo3vF8+A'))
    assert key_expansion(key) == expanded_key



# Generated at 2022-06-18 13:02:03.048030
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:08.530135
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI0GAILBdukQxZVz+A0sFC6J1g=='))
    expected = bytes_to_intlist(compat_b64decode('gI0GAILBdukQxZVz+A0sFC6J1gMghLgfEw4xNhf5d6hFtRJQeXv9lKL3wMgLH0YH3+8EFRquPQtsYjrFmYhNg=='))
    assert key_expansion(key) == expected


# Generated at 2022-06-18 13:02:19.183614
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CzgVBAoAAA=='))
    expanded_key = key_expansion(key)
    expected_expanded_key = bytes_to_intlist(compat_b64decode('CzgVBAoAAAoHBwsHCwoHBw=='))
    assert expanded_key == expected_expanded_key

    key = bytes_to_intlist(compat_b64decode('CzgVBAoAAAoHBws='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:02:30.435797
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:41.265287
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:53.032130
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:03.931394
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176
    assert expanded_key[:16] == key
    assert expanded_key[16:32] == [0xa0, 0xfa, 0xfe, 0x17, 0x88, 0x54, 0x2c, 0xb1, 0x23, 0xa3, 0x39, 0x39, 0x2a, 0x6c, 0x76, 0x05]

# Generated at 2022-06-18 13:03:16.116052
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:28.004520
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176
    assert expanded_key[:16] == key
    assert expanded_key[16:32] == [0xa0, 0xfa, 0xfe, 0x17, 0x88, 0x54, 0x2c, 0xb1, 0x23, 0xa3, 0x39, 0x39, 0x2a, 0x6c, 0x76, 0x05]
    assert expanded_key[-16:]

# Generated at 2022-06-18 13:03:44.160104
# Unit test for function key_expansion
def test_key_expansion():
    key_128 = bytes_to_intlist(compat_b64decode('CY9rzUYh03PK3k6DJie09g=='))
    key_192 = bytes_to_intlist(compat_b64decode('+4QDU1NzEzmCj7mCDdVl9g=='))
    key_256 = bytes_to_intlist(compat_b64decode('0J3W+s6m0m1QmwcVjDVLCQ=='))


# Generated at 2022-06-18 13:03:55.499020
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI0GAILBdukQOQ=='))
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(expanded_key) == compat_b64decode('gI0GAILBdukQOQ==' + '6zFz4p/eX6JbsmB3vf8Mkw==')

    key = bytes_to_intlist(compat_b64decode('gI0GAILBdukQOQ==' + '6zFz4p/eX6JbsmB3vf8Mkw=='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:04:05.089696
# Unit test for function key_expansion
def test_key_expansion():
    key_128 = bytes_to_intlist(compat_b64decode('gZy6sIZ6wl9NJOKB-jnmVQ'))
    key_192 = bytes_to_intlist(compat_b64decode('gZy6sIZ6wl9NJOKB-jnmVQgZy6sIZ6wl9NJOKB-jnmVQ'))
    key_256 = bytes_to_intlist(compat_b64decode('gZy6sIZ6wl9NJOKB-jnmVQgZy6sIZ6wl9NJOKB-jnmVQgZy6sIZ6wl9NJOKB-jnmVQ'))


# Generated at 2022-06-18 13:04:14.832281
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-18 13:04:21.591673
# Unit test for function key_expansion

# Generated at 2022-06-18 13:04:32.048692
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CQ4W8y0XFhY='))

# Generated at 2022-06-18 13:04:43.311803
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:52.227946
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:59.267168
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:10.867084
# Unit test for function key_expansion

# Generated at 2022-06-18 13:05:26.941707
# Unit test for function key_expansion
def test_key_expansion():
    key_16 = bytes_to_intlist(compat_b64decode('gZy6sIZ6wl9NJOKB-jnmVQ'))
    key_24 = bytes_to_intlist(compat_b64decode('gZy6sIZ6wl9NJOKB-jnmVQQsK-Z6lMhG'))
    key_32 = bytes_to_intlist(compat_b64decode('gZy6sIZ6wl9NJOKB-jnmVQQsK-Z6lMhG0tC-YqXdM8YkZH-wdVgWOlAzw'))


# Generated at 2022-06-18 13:05:34.801568
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI4nN1rKgv8Y6KxVvb9uQQ=='))
    expanded_key = bytes_to_intlist(compat_b64decode('gI4nN1rKgv8Y6KxVvb9uQQ+ZTJZ+jBqYvXVuZ+yJf7s='))
    assert key_expansion(key) == expanded_key



# Generated at 2022-06-18 13:05:40.889372
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gIqzq2KF+Au+dZhF7kqZVw=='))

# Generated at 2022-06-18 13:05:52.556485
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7RqX+uQQ6hK4nM9sF3OQ=='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:06:00.556499
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CmU/9qh1E1lhsu9xBdlnCA=='))