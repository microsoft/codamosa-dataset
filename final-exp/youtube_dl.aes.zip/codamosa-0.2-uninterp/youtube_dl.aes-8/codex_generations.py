

# Generated at 2022-06-18 12:56:30.247528
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]
    expanded_key = key_expansion(key)
    decrypted_data = aes_decrypt(data, expanded_key)

# Generated at 2022-06-18 12:56:41.582353
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vector from http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    cipher = bytes_to_intlist(compat_b64decode('0ec7702330098ce7f7520d1cbbb20fc388d1b0adb5054dbd7370849dbf0b88d393f252e764f1f5f7ad97ef79d59ce29f5f51eeca32eabedd9afa9329'))
    expanded_key = key_expansion(key)
    assert aes_decrypt(cipher, expanded_key) == bytes_to_int

# Generated at 2022-06-18 12:56:49.374454
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vector from http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    data = bytes_to_intlist(compat_b64decode('3AvVhmFLUs0KTA3Kprsdag=='))
    expanded_key = key_expansion(key)
    assert aes_decrypt(data, expanded_key) == bytes_to_intlist(compat_b64decode('aes_decrypt'))


# Generated at 2022-06-18 12:56:58.365031
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    from .test_utils import assert_equal
    from .test_utils import assert_true
    from .test_utils import assert_false

    # Test vectors from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # Appendix F.3.3 CTR-AES256.Encrypt
    # Appendix F.3.4 CTR-AES256.Decrypt

# Generated at 2022-06-18 12:57:10.433002
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    iv = bytes_to_intlist(compat_b64decode('AxY8DCtDaGlsbGljb3RoZQ=='))
    data = bytes_to_intlist(compat_b64decode('KDlTtgcJZRt33+7vS6An2w=='))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('3up8VlhBfVpXZzPd9v4OQ==')



# Generated at 2022-06-18 12:57:22.314943
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]

# Generated at 2022-06-18 12:57:29.151796
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Test vector from http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    data = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]

# Generated at 2022-06-18 12:57:41.669972
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value = intlist_to_bytes(bytes_to_intlist(self.value) + 1)
            return self.value

    data = compat_b64decode(
        'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')
    key = compat_b64decode('YELLOW SUBMARINE')
    counter = Counter(compat_b64decode('\x00' * BLOCK_SIZE_BYTES))

# Generated at 2022-06-18 12:57:54.739315
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuTqej9qdM6M/sB3jA=='))
    iv = bytes_to_intlist(compat_b64decode('qoTbPR1VfXwKZszF/iX6uw=='))
    cipher = bytes_to_intlist(compat_b64decode('K1/xBn7X9mC1+JyWvWv3CA=='))

# Generated at 2022-06-18 12:58:03.064192
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(compat_b64decode(
        'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode(
        'YELLOW SUBMARINE'))
    counter = Counter(bytes_to_intlist(compat_b64decode(
        'AAAAAAAAAAAAAAAA')))

    assert intlist_to_bytes(aes_ctr_decrypt(data, key, counter)) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '


# Generated at 2022-06-18 12:58:19.222908
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value = (self.value + 1) % (2 ** 64)
            return bytes_to_intlist(self.value.to_bytes(16, 'big'))

    data = bytes_to_intlist(compat_b64decode(
        'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt

# Generated at 2022-06-18 12:58:28.353480
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-18 12:58:38.676718
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuTq8D1orM9FxX8gJA=='))
    iv = bytes_to_intlist(compat_b64decode('qT7XoVrK8a1orM9FxX8gJA=='))
    cipher = bytes_to_intlist(compat_b64decode('qT7XoVrK8a1orM9FxX8gJA=='))
    plain = bytes_to_intlist(compat_b64decode('qT7XoVrK8a1orM9FxX8gJA=='))
    assert aes_cbc_decrypt(cipher, key, iv) == plain



# Generated at 2022-06-18 12:58:48.608069
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QIuixkdMLCOJf5PqQmA=='))
    iv = bytes_to_intlist(compat_b64decode('q83vQH4j3RG2lh0p9ybDdA=='))
    cipher = bytes_to_intlist(compat_b64decode('XlLzzuZYKbHtjYQa4uQTjQ=='))
    plain = bytes_to_intlist(compat_b64decode('foobar'))
    assert aes_cbc_decrypt(cipher, key, iv) == plain



# Generated at 2022-06-18 12:59:00.388932
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, start_value):
            self.value = start_value

        def next_value(self):
            self.value += 1
            return [self.value] * BLOCK_SIZE_BYTES

    data = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode(b'YELLOW SUBMARINE'))
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)
    assert intlist_to

# Generated at 2022-06-18 12:59:12.927808
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Unit test for function aes_decrypt_text
    """
    import os
    import sys
    import unittest

    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from youtube_dl.utils import encode_compat_str


# Generated at 2022-06-18 12:59:23.018515
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value = (self.value + 1) % (2 ** 64)
            return intlist_to_bytes(self.value, 8)

    key = bytes_to_intlist('YELLOW SUBMARINE')
    counter = Counter(0)
    data = compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')
    decrypted_data = aes_ctr_decrypt(bytes_to_intlist(data), key, counter)
    assert intlist_to_bytes(decrypted_data)

# Generated at 2022-06-18 12:59:35.116764
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuetJU9LcJkI1qLkZg=='))
    iv = bytes_to_intlist(compat_b64decode('q83UoRQKZszA4rOQTqOQcA=='))
    data = bytes_to_intlist(compat_b64decode('q83UoRQKZszA4rOQTqOQcA=='))
    decrypted_data = aes_cbc_decrypt(data, key, iv)
    assert decrypted_data == bytes_to_intlist(compat_b64decode('q83UoRQKZszA4rOQTqOQcA=='))



# Generated at 2022-06-18 12:59:43.899831
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-18 12:59:55.005692
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, start_value):
            self.value = start_value

        def next_value(self):
            self.value += 1
            return [self.value] * BLOCK_SIZE_BYTES

    data = bytes_to_intlist(compat_b64decode(
        'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)
    assert intlist_to_

# Generated at 2022-06-18 13:00:10.930722
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cipher import aes_encrypt
    from .aes_key_expansion import key_expansion
    from .aes_cipher import aes_encrypt

    class TestCounter(AESCounter):
        def __init__(self):
            self.counter = 0

        def next_value(self):
            self.counter += 1
            return [self.counter] * BLOCK_SIZE_BYTES

    counter = TestCounter()

    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
   

# Generated at 2022-06-18 13:00:21.918251
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cbc import aes_cbc_decrypt
    from .aes_cbc import aes_cbc_encrypt
    from .aes_cbc import test_aes_cbc_encrypt
    from .aes_cbc import test_aes_cbc_decrypt
    from .aes_cbc import test_aes_cbc_decrypt_2
    from .aes_cbc import test_aes_cbc_decrypt_3
    from .aes_cbc import test_aes_cbc_decrypt_4
    from .aes_cbc import test_aes_cbc_decrypt_5
    from .aes_cbc import test_aes_cbc_decrypt_6

# Generated at 2022-06-18 13:00:27.752413
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16

    assert aes_decrypt_text(data, password, key_size_bytes) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 13:00:38.725719
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .utils import bytes_to_intlist, intlist_to_bytes
    from .aes import aes_encrypt
    from .aes import key_expansion
    from .aes import aes_ctr_decrypt

    class Counter(object):
        def __init__(self, initial_value):
            self.value = initial_value

        def next_value(self):
            self.value = [self.value[i] + 1 for i in range(len(self.value))]
            return self.value

    data = bytes_to_intlist(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')

# Generated at 2022-06-18 13:00:45.992541
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 13:00:56.648312
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('K7nyNqTqb0xqTQ=='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:01:09.271188
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter:
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value = intlist_to_bytes(
                bytes_to_intlist(self.value)
                + [0, 0, 0, 0, 0, 0, 0, 1]
            )
            return self.value

    data = compat_b64decode(
        'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOL'
        'SFQ=='
    )
    key = compat_b64decode('YELLOW SUBMARINE')
    counter = Counter(compat_b64decode('\x00' * 8))
   

# Generated at 2022-06-18 13:01:22.100711
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:34.243249
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, start_value):
            self.value = start_value

        def next_value(self):
            self.value += 1
            return self.value

    data = bytes_to_intlist(compat_b64decode(
        'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode(
        'YELLOW SUBMARINE'))
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-18 13:01:41.216458
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 13:01:56.049942
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:59.620409
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 13:02:04.956960
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('h/EuU5yv5QNp5FDgKm5dNg=='))
    expected = bytes_to_intlist(compat_b64decode('h/EuU5yv5QNp5FDgKm5dNgFzf1rM7m3w+/j9/vL+9w=='))
    assert key_expansion(key) == expected



# Generated at 2022-06-18 13:02:07.611607
# Unit test for function inc
def test_inc():
    data = [0, 0, 0, 0]
    for i in range(256):
        print(data)
        data = inc(data)

# test_inc()


# Generated at 2022-06-18 13:02:18.415196
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:29.173797
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:36.176570
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 13:02:42.390151
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 13:02:53.985254
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('K7nyNqTm/f0nsIWqUHs+JQ=='))

# Generated at 2022-06-18 13:03:01.202496
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 13:03:14.809648
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:26.784913
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:34.992655
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:47.563571
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176

# Generated at 2022-06-18 13:03:58.309031
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:08.531559
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:17.620560
# Unit test for function key_expansion

# Generated at 2022-06-18 13:04:27.472096
# Unit test for function key_expansion
def test_key_expansion():
    key_size_bytes = 16
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:38.132284
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:49.010593
# Unit test for function key_expansion

# Generated at 2022-06-18 13:04:59.652255
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7j+MqD6erxXhvf9JbQHw=='))

# Generated at 2022-06-18 13:05:11.528165
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:23.064541
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI1QZuVzKVd9eM1wqZqH3Q=='))

# Generated at 2022-06-18 13:05:35.622046
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:44.290614
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:05:55.717196
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7+FqV/kG+8tP/CxNy+A=='))
    expanded_key = bytes_to_intlist(compat_b64decode('gI7+FqV/kG+8tP/CxNy+A=='))
    assert key_expansion(key) == expanded_key

    key = bytes_to_intlist(compat_b64decode('gI7+FqV/kG+8tP/CxNy+A=='))
    expanded_key = bytes_to_intlist(compat_b64decode('gI7+FqV/kG+8tP/CxNy+A=='))
    assert key_expansion(key)

# Generated at 2022-06-18 13:06:07.001112
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]