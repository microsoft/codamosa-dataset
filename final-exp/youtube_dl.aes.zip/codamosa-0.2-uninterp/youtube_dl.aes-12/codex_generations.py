

# Generated at 2022-06-18 12:56:40.448032
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('wHqhxD7YZKzv/f3PqPyuft9eH7E='))
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176
    assert intlist_to_bytes(expanded_key) == compat_b64decode(
        'wHqhxD7YZKzv/f3PqPyuft9eH7E=+4G3hF2lQbS9xrtXaN6i8yvwz1M5f0jouK')



# Generated at 2022-06-18 12:56:47.044892
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:56:51.104927
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:57:03.036380
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vectors from http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    # Appendix C - Example Vectors
    key = bytes_to_intlist(compat_b64decode('2b7e151628aed2a6abf7158809cf4f3c'))
    cipher = bytes_to_intlist(compat_b64decode('3ad77bb40d7a3660a89ecaf32466ef97'))
    expanded_key = key_expansion(key)
    assert aes_decrypt(cipher, expanded_key) == bytes_to_intlist(compat_b64decode('6bc1bee22e409f96e93d7e117393172a'))


# Generated at 2022-06-18 12:57:05.498489
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:57:17.387481
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test for function aes_decrypt_text
    """
    import base64
    import hashlib
    import random
    import string

    def random_string(length):
        return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))

    def test_decrypt_text(data, password, key_size_bytes):
        """
        Test for function aes_decrypt_text
        """
        decrypted_data = aes_decrypt_text(data, password, key_size_bytes)
        assert decrypted_data == b'Hello World!'

    def test_decrypt_text_with_hash(data, password, key_size_bytes):
        """
        Test for function aes_decrypt_text
        """
        password = hashlib

# Generated at 2022-06-18 12:57:29.198257
# Unit test for function shift_rows

# Generated at 2022-06-18 12:57:33.544904
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = [0] * BLOCK_SIZE_BYTES
    data = bytes_to_intlist(b'hello world')
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == b'\x9d\x8c\x8d\x4c\x1a\xea\xbf\x1a\x9d\x8c\x8d\x4c\x1a\xea\xbf\x1a'

# Generated at 2022-06-18 12:57:44.359577
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 12:57:53.281772
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:58:13.904054
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    iv = bytes_to_intlist(compat_b64decode('AxY8DCtDaGlsbGljb3RoZQ=='))
    data = bytes_to_intlist(compat_b64decode('KDlTtgcJZRt33Vu4+Zql0g=='))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('3up8VlhB4IVDtj3V8uJl8w==')



# Generated at 2022-06-18 12:58:25.529786
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    iv = bytes_to_intlist(compat_b64decode('AxY8DCtDaGlsbGljb3RoZQ=='))
    data = bytes_to_intlist(compat_b64decode('KDlTtgcJZRt33igAAmYg+Q=='))
    expected_result = bytes_to_intlist(compat_b64decode('3/N7DYwH4l8s1IjM9wnN6w=='))
    result = aes_cbc_encrypt(data, key, iv)
    assert result == expected_result



# Generated at 2022-06-18 12:58:36.856808
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 12:58:47.839942
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test function aes_decrypt_text
    """
    import base64
    import random
    import string

    def random_string(length):
        return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))

    for _ in range(100):
        password = random_string(random.randint(1, 32))
        key_size_bytes = random.choice([16, 24, 32])
        plaintext = random_string(random.randint(1, 1024))

        cipher = aes_encrypt_text(plaintext, password, key_size_bytes)
        decrypted_text = aes_decrypt_text(cipher, password, key_size_bytes)

        assert plaintext == decrypted_text

    # Test with known values
   

# Generated at 2022-06-18 12:58:59.731321
# Unit test for function key_expansion

# Generated at 2022-06-18 12:59:12.245149
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, initial_value):
            self.value = initial_value

        def next_value(self):
            self.value = (self.value + 1) % (2 ** 64)
            return intlist_to_bytes(self.value, 8)

    key = bytes_to_intlist(compat_b64decode('K7gNU3sdo+OL0wNhqoVWhr3g6s1xYv72ol/pe/Unols='))
    counter = Counter(0)
    cipher = bytes_to_intlist(compat_b64decode('XvK/d5r8KFQz+5tLK6dTbLMF6jJ01+Y5zpjqdQ=='))
    plain = bytes_

# Generated at 2022-06-18 12:59:22.604609
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test vectors from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    key = bytes_to_intlist(compat_b64decode('2b7e151628aed2a6abf7158809cf4f3c'))
    iv = bytes_to_intlist(compat_b64decode('000102030405060708090a0b0c0d0e0f'))
    data = bytes_to_intlist(compat_b64decode('6bc1bee22e409f96e93d7e117393172a'))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode

# Generated at 2022-06-18 12:59:34.689187
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 12:59:43.642120
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, initial_value):
            self.value = initial_value

        def next_value(self):
            self.value += 1
            return self.value

    key = bytes_to_intlist(compat_b64decode(b'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4'))
    counter = Counter(0)
    data = bytes_to_intlist(compat_b64decode(b'MTIzNDU2Nzg5YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4'))
    decrypted_data = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-18 12:59:54.731574
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    data = bytes_to_intlist(b'\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:00:11.810602
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Unit test for function aes_decrypt_text
    """
    import os
    import sys
    import unittest

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

    from . import aes


# Generated at 2022-06-18 13:00:22.697908
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    from .utils import bytes_to_intlist, intlist_to_bytes
    from .compat import compat_b64encode

    def test_aes_decrypt_text_with_key_size(key_size_bytes):
        password = 'password'
        plaintext = 'Hello World!'
        nonce = [0] * 8

        key = password[:key_size_bytes] + [0] * (key_size_bytes - len(password))
        key = aes_encrypt(key[:BLOCK_SIZE_BYTES], key_expansion(key)) * (key_size_bytes // BLOCK_SIZE_BYTES)

        class Counter(object):
            __value = nonce + [0] * (BLOCK_SIZE_BYTES - NONCE_LENGTH_BYTES)


# Generated at 2022-06-18 13:00:28.644076
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 13:00:40.019547
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-18 13:00:47.262478
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 13:00:55.781972
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    expected_plaintext = b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '
    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == expected_plaintext

test_aes_decrypt_text()


# Generated at 2022-06-18 13:01:00.891453
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'rXj8/u/hgGq/tj+mw/w=='
    password = 'password'
    key_size_bytes = 16
    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == b'Hello World!'



# Generated at 2022-06-18 13:01:13.171431
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cbc import aes_cbc_decrypt
    from .aes_cbc import aes_cbc_encrypt
    from .aes_cbc import aes_cbc_encrypt_pkcs7
    from .aes_cbc import aes_cbc_decrypt_pkcs7
    from .aes_cbc import aes_cbc_encrypt_pkcs7_iv
    from .aes_cbc import aes_cbc_decrypt_pkcs7_iv
    from .aes_cbc import aes_cbc_encrypt_pkcs7_iv_key
    from .aes_cbc import aes_cbc_decrypt_pkcs7_iv_key

# Generated at 2022-06-18 13:01:26.161499
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-18 13:01:38.085708
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, start):
            self.start = start

        def next_value(self):
            self.start += 1
            return self.start

    data = bytes_to_intlist(compat_b64decode(
        'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-18 13:01:54.882771
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QDZuKHvF4V6a8e9tLNjJyEBbRmCs5'))
    iv = bytes_to_intlist(compat_b64decode('DCl5VpVHXawQrE9XOeZSVQ=='))

# Generated at 2022-06-18 13:02:01.256533
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-18 13:02:10.358100
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QDZuT0L6aNm1A9GiXFA=='))
    iv = bytes_to_intlist(compat_b64decode('qCiGt9mhYMKY+5Mhic/Wzw=='))
    cipher = bytes_to_intlist(compat_b64decode('qCiGt9mhYMKY+5Mhic/Wzw=='))
    plain = aes_cbc_decrypt(cipher, key, iv)
    assert intlist_to_bytes(plain) == compat_b64decode('qCiGt9mhYMKY+5Mhic/Wzw==')



# Generated at 2022-06-18 13:02:19.275143
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QIuixkdMk3tL7EVfSGA=='))
    iv = bytes_to_intlist(compat_b64decode('q83vEyBd1Fp0oE9QJj7Vlg=='))
    data = bytes_to_intlist(compat_b64decode('ZW5jcnlwdGVkX2RhdGE='))
    decrypted_data = aes_cbc_decrypt(data, key, iv)
    assert intlist_to_bytes(decrypted_data) == b'encrypted_data'



# Generated at 2022-06-18 13:02:30.593681
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QIuixkdMLCOJf9XaRXw=='))
    iv = bytes_to_intlist(compat_b64decode('qT7TqG6gMOLN0EiPkR0b7A=='))
    cipher = bytes_to_intlist(compat_b64decode('7D0B2f5f7fcc55b7cbf5d4c5d444fd29'))
    plain = bytes_to_intlist(compat_b64decode('6bc1bee22e409f96e93d7e117393172a'))
    assert aes_cbc_decrypt(cipher, key, iv) == plain



# Generated at 2022-06-18 13:02:41.387934
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 13:02:53.164915
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 13:03:02.234354
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    iv = bytes_to_intlist(compat_b64decode('2jmj7l5rSw0yVb/vlWAYkK/YBwk='))
    data = bytes_to_intlist(compat_b64decode('3AvVhmFLUs0KTA3Kprsdag=='))

    assert intlist_to_bytes(aes_cbc_decrypt(data, key, iv)) == b'abc'


# Generated at 2022-06-18 13:03:09.915453
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuTqej9qdM6MksWxZQ=='))
    iv = bytes_to_intlist(compat_b64decode('q9jcZX+zTdu0LX8ZJgvr9Q=='))
    cipher = bytes_to_intlist(compat_b64decode('LK+sDYFoTlY6xKcBxCjE7rIaJQMfkFKy6UwjQs7Q3v4='))
    plain = bytes_to_intlist(compat_b64decode('48656c6c6f20776f726c64'))
    assert aes_cbc_decrypt(cipher, key, iv)

# Generated at 2022-06-18 13:03:21.714207
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 13:03:33.655595
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:46.340179
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:57.364296
# Unit test for function key_expansion
def test_key_expansion():
    key_16 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:07.427082
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:16.823323
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:26.356549
# Unit test for function key_expansion

# Generated at 2022-06-18 13:04:37.292080
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:48.305711
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:56.425860
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:07.988601
# Unit test for function key_expansion
def test_key_expansion():
    assert key_expansion(bytes_to_intlist(b'\x00' * 16)) == bytes_to_intlist(b'\x00' * 176)
    assert key_expansion(bytes_to_intlist(b'\x00' * 24)) == bytes_to_intlist(b'\x00' * 208)
    assert key_expansion(bytes_to_intlist(b'\x00' * 32)) == bytes_to_intlist(b'\x00' * 240)

    assert key_expansion(bytes_to_intlist(b'\x00' * 16)) == bytes_to_intlist(b'\x00' * 176)

# Generated at 2022-06-18 13:05:23.606467
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:35.801400
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:44.411875
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gIqzqY8YgQ=='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:05:49.638746
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:05:59.163790
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:06:07.192522
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7QXuBt3j0qE9AcTm3jAQ=='))
    expanded_key = bytes_to_intlist(compat_b64decode('gI7QXuBt3j0qE9AcTm3jAQK1xM9cOe2+/K0Y3/Ij3F4='))
    assert key_expansion(key) == expanded_key

