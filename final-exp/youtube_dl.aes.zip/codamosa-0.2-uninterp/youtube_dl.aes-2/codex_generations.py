

# Generated at 2022-06-18 12:56:29.090226
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 12:56:39.287566
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    expanded_key = key_expansion(key)
    cipher = aes_encrypt(data, expanded_key)
    assert intlist_to_bytes(cipher) == compat_b64decode('3K3kS7yE9zjmJ7ybMqXO6gzctVQeM1iC')



# Generated at 2022-06-18 12:56:46.921299
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:56:55.070843
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(aes_decrypt(data, expanded_key)) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 12:57:06.913059
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vector from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    key = bytes_to_intlist(compat_b64decode('GawgguFyGrWKav7AX4VKUg'))
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    expanded_key = key_expansion(key)
    decrypted_data = aes_decrypt(data, expanded_key)

# Generated at 2022-06-18 12:57:19.437611
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytes_to_intlist(compat_b64decode(b'CRIwqt4+szDbqkNY+I0qbNXPg1XLaCM5etQ5Bt9DRFV/xIN2k8Go7jtArLIy'
                                             b'P605b071DL8C+FPYSHOXPkMMMFPAKm+Nsu0nCBMQVt9mlluHbVE/yl6VaBC'
                                             b'3HvxTWjE5jg3C+PnNlvzsFqumhWKBzDaUaFQUEh5mwWog=='))

# Generated at 2022-06-18 12:57:30.841359
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, initial_value):
            self.value = initial_value

        def next_value(self):
            self.value += 1
            return self.value

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    data = bytes_to_intlist(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-18 12:57:42.967329
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cbc import aes_cbc_decrypt
    from .aes_cbc import aes_cbc_encrypt
    from .aes_cbc import test_aes_cbc_encrypt
    from .aes_cbc import test_aes_cbc_decrypt
    from .aes_cbc import test_aes_cbc_encrypt_decrypt

    test_aes_cbc_encrypt()
    test_aes_cbc_decrypt()
    test_aes_cbc_encrypt_decrypt()

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    counter = AESCounter(bytes_to_intlist(b'\x00' * 16))

    # Test vectors

# Generated at 2022-06-18 12:57:54.645707
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b'1234567890123456')
    key = bytes_to_intlist(b'1234567890123456')
    iv = bytes_to_intlist(b'1234567890123456')
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == b'\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f\x7f'


# Generated at 2022-06-18 12:58:04.479700
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('K7gNU3sdo+OL0wNhqoVWhr3g6s1xYv72ol/pe/Unols='))
    iv = bytes_to_intlist(compat_b64decode('i45FVt72X+GzP6uM9bI1xw=='))
    data = bytes_to_intlist(compat_b64decode('qCiLORiDYp1zBd2QFh0ZsA=='))
    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-18 12:58:21.913753
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuTq8+8L9l31rDyPxw=='))
    iv = bytes_to_intlist(compat_b64decode('qoC4iRpj9Fw0A8kKjwdqKg=='))
    cipher = bytes_to_intlist(compat_b64decode('qoC4iRpj9Fw0A8kKjwdqKg=='))
    plain = bytes_to_intlist(compat_b64decode('qoC4iRpj9Fw0A8kKjwdqKg=='))
    assert aes_cbc_decrypt(cipher, key, iv) == plain



# Generated at 2022-06-18 12:58:34.074204
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test function aes_decrypt_text
    """
    import base64
    import os
    import random
    import string

    def random_string(length):
        """
        Generate random string
        """
        return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(length))

    def test_aes_decrypt_text_with_key_size(key_size_bytes):
        """
        Test function aes_decrypt_text with key_size_bytes
        """
        for _ in range(100):
            password = random_string(random.randint(1, 32))
            plaintext = random_string(random.randint(1, 1024))

# Generated at 2022-06-18 12:58:41.190348
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cbc import aes_cbc_decrypt
    from .aes_cbc import aes_cbc_encrypt
    from .aes_cbc import test_aes_cbc_encrypt
    from .aes_cbc import test_aes_cbc_decrypt
    from .aes_cbc import test_aes_cbc_encrypt_decrypt
    from .aes_cbc import test_aes_cbc_encrypt_decrypt_with_iv
    from .aes_cbc import test_aes_cbc_encrypt_decrypt_with_iv_and_padding
    from .aes_cbc import test_aes_cbc_encrypt_decrypt_with_iv_and_padding_

# Generated at 2022-06-18 12:58:52.828633
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_cipher import aes_encrypt
    from .aes_cipher import aes_decrypt
    from .aes_cipher import key_expansion
    from .aes_cipher import aes_encrypt_block
    from .aes_cipher import aes_decrypt_block
    from .aes_cipher import xor
    from .aes_cipher import add_round_key
    from .aes_cipher import sub_bytes
    from .aes_cipher import inv_sub_bytes
    from .aes_cipher import shift_rows
    from .aes_cipher import inv_shift_rows
    from .aes_cipher import mix_columns
    from .aes_cipher import inv_mix_columns

# Generated at 2022-06-18 12:59:02.632103
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 12:59:12.346606
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuTqej9qdMhx1TrwOA=='))
    iv = bytes_to_intlist(compat_b64decode('+//uXNlK3eH6Kan1AQ=='))
    data = bytes_to_intlist(compat_b64decode('V2ViS2l0IGlzIGdvb2Q='))
    assert aes_cbc_decrypt(data, key, iv) == bytes_to_intlist(b'WebKit is good')



# Generated at 2022-06-18 12:59:22.680193
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cbc import aes_cbc_decrypt
    from .aes_cbc import aes_cbc_encrypt
    from .aes_cbc import test_aes_cbc_encrypt
    from .aes_cbc import test_aes_cbc_decrypt
    from .aes_cbc import test_aes_cbc_encrypt_decrypt
    from .aes_cbc import test_aes_cbc_encrypt_decrypt_with_padding
    from .aes_cbc import test_aes_cbc_encrypt_decrypt_with_padding_and_iv
    from .aes_cbc import test_aes_cbc_encrypt_decrypt_with_padding_and_iv_

# Generated at 2022-06-18 12:59:33.347693
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vector from http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    data = bytes_to_intlist(compat_b64decode('3AvVhmFLUs0KTA3Kprsdag=='))
    expanded_key = key_expansion(key)
    decrypted_data = aes_decrypt(data, expanded_key)
    assert decrypted_data == bytes_to_intlist(compat_b64decode('a' * 16))



# Generated at 2022-06-18 12:59:42.847755
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * 16)
    cipher = bytes_to_intlist(b'\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b\x0b')
    plain = aes_cbc_decrypt(cipher, key, iv)

# Generated at 2022-06-18 12:59:53.903121
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vector from http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    expanded_key = key_expansion(key)
    cipher = bytes_to_intlist(compat_b64decode('0ec7702330098ce7f7520d1cbbb20fc388d1b0adb5054dbd7370849dbf0b88d393f252e764f1f5f7ad97ef79d59ce29f5f51eeca32eabedd9afa9329'))
    plain = aes_decrypt(cipher, expanded_key)
    assert intlist

# Generated at 2022-06-18 13:00:09.660929
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'QVZRSU5DQVJEXzEyOF9CeXRlcw=='
    password = 'password'
    key_size_bytes = 16
    assert aes_decrypt_text(data, password, key_size_bytes) == 'AES_128_Bytes'

    data = 'QVZRSU5DQVJEXzI1Nl9CeXRlcw=='
    password = 'password'
    key_size_bytes = 32
    assert aes_decrypt_text(data, password, key_size_bytes) == 'AES_256_Bytes'

    data = 'QVZRSU5DQVJEXzI1Nl9CeXRlcw=='
    password = 'password'
    key_size_bytes = 24
    assert a

# Generated at 2022-06-18 13:00:20.820870
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value = (self.value + 1) % (1 << 128)

# Generated at 2022-06-18 13:00:28.316072
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)
    assert intlist_to_bytes(decrypted_data) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 13:00:39.508705
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, initial_value):
            self.value = initial_value

        def next_value(self):
            self.value += 1
            return self.value

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    data = bytes_to_intlist(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-18 13:00:50.268760
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, start_value):
            self.value = start_value

        def next_value(self):
            self.value += 1
            return [self.value] * BLOCK_SIZE_BYTES

    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    counter = Counter(0)

# Generated at 2022-06-18 13:01:01.529700
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import random
    from .aes_counter import AESCounter

    def random_bytes(n):
        return [random.randint(0, 255) for _ in range(n)]

    def random_key():
        return random_bytes(16)

    def random_counter():
        return AESCounter(random_bytes(16))

    def random_data(n):
        return random_bytes(n)

    def random_test():
        key = random_key()
        counter = random_counter()
        data = random_data(random.randint(0, 1024))
        return key, counter, data

    for _ in range(100):
        key, counter, data = random_test()
        assert aes_ctr_decrypt(aes_ctr_encrypt(data, key, counter), key, counter) == data



# Generated at 2022-06-18 13:01:14.236129
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cipher import aes_encrypt
    from .aes_cipher import aes_decrypt
    from .aes_cipher import key_expansion
    from .aes_cipher import xor
    from .aes_cipher import aes_ctr_decrypt

    class TestCounter(AESCounter):
        def __init__(self, counter_block):
            self.counter_block = counter_block

        def next_value(self):
            return self.counter_block


# Generated at 2022-06-18 13:01:27.088610
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value = (self.value + 1) % 256
            return [self.value] * 16

    data = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode(b'YELLOW SUBMARINE'))
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-18 13:01:35.088731
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    expected = b"Yo, VIP Let's kick it Ice, Ice, baby Ice, Ice, baby "
    actual = aes_decrypt_text(data, password, key_size_bytes)
    assert actual == expected



# Generated at 2022-06-18 13:01:39.616607
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'QVZBTkNFTUVOVQ=='
    password = 'password'
    key_size_bytes = 16
    expected = 'EVENTNO'
    actual = aes_decrypt_text(data, password, key_size_bytes)
    assert actual == expected



# Generated at 2022-06-18 13:01:52.909979
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7QYxBnKjJgNlOd5G4lLg=='))
    expected_expanded_key = bytes_to_intlist(compat_b64decode(
        'gI7QYxBnKjJgNlOd5G4lLg+rDzR+3T4nL0j6vRzKXV0='))
    expanded_key = key_expansion(key)
    assert expanded_key == expected_expanded_key



# Generated at 2022-06-18 13:02:04.090215
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:14.562095
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(compat_b64decode('CY9rzUYh03PK3k6DJie09g=='))

# Generated at 2022-06-18 13:02:23.406589
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CQkJAA=='))

# Generated at 2022-06-18 13:02:36.023508
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CmU/9qhF9/WgXnzpDqd5Zg=='))

# Generated at 2022-06-18 13:02:47.489646
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:52.262681
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:03.146277
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:14.498438
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:03:26.416871
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:03:43.508528
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:03:54.921625
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 13:04:02.770175
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('K7nyNqh4Pc/zj7njnjA7w=='))

# Generated at 2022-06-18 13:04:12.957760
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:20.613269
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:31.208487
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:42.423215
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:51.526825
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176

# Generated at 2022-06-18 13:04:58.775879
# Unit test for function key_expansion
def test_key_expansion():
    key_size_bytes = 16
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:10.324407
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7mKjbz6Zs='))
    expected = bytes_to_intlist(compat_b64decode('gI7mKjbz6Zs=fjZC1iYzk4N2Y='))
    assert key_expansion(key) == expected

    key = bytes_to_intlist(compat_b64decode('gI7mKjbz6Zs=fjZC1iYzk4N2Y='))

# Generated at 2022-06-18 13:05:31.907763
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:41.755447
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-18 13:05:53.569095
# Unit test for function key_expansion
def test_key_expansion():
    from .utils import bytes_to_intlist, intlist_to_bytes
    from .compat import compat_b64decode
    from .aes import key_expansion

    key = bytes_to_intlist(compat_b64decode('CmU/9qhF9/WgXzFy2vMcZw=='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:06:04.086039
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]