

# Generated at 2022-06-18 12:56:38.642660
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 12:56:46.581339
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    expected = 'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '
    assert aes_decrypt_text(data, password, key_size_bytes) == expected



# Generated at 2022-06-18 12:56:57.218269
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test function aes_decrypt_text
    """
    import base64
    import random

    def test_vector(data, password, key_size_bytes):
        """
        Test vector
        """
        data = base64.b64encode(data)
        decrypted_data = aes_decrypt_text(data, password, key_size_bytes)
        assert decrypted_data == data

    test_vector(b'', '', 16)
    test_vector(b'', '', 24)
    test_vector(b'', '', 32)
    test_vector(b'\x00', '', 16)
    test_vector(b'\x00', '', 24)
    test_vector(b'\x00', '', 32)

# Generated at 2022-06-18 12:57:08.861624
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 12:57:11.387612
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:57:23.352085
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:57:29.817697
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('C8AEDFDAF43C09AF'))
    iv = bytes_to_intlist(compat_b64decode('0000000000000000'))
    data = bytes_to_intlist(compat_b64decode('0000000000000000'))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('C8AEDFDAF43C09AF')

    key = bytes_to_intlist(compat_b64decode('C8AEDFDAF43C09AF'))
    iv = bytes_to_intlist(compat_b64decode('0000000000000000'))

# Generated at 2022-06-18 12:57:38.738620
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 12:57:47.029177
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, initial_value):
            self.value = initial_value

        def next_value(self):
            self.value = (self.value + 1) % (2 ** 64)
            return intlist_to_bytes(self.value, 8)

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    counter = Counter(0)
    data = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    decrypted_data = aes_ctr_decrypt(data, key, counter)
    assert decrypted

# Generated at 2022-06-18 12:57:58.060022
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cipher import aes_encrypt
    from .aes_cipher import aes_decrypt
    from .aes_cipher import key_expansion
    from .aes_cipher import xor

    class TestCounter(AESCounter):
        def __init__(self, counter_block):
            self.counter_block = counter_block

        def next_value(self):
            return self.counter_block

    key = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    counter_block = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    counter = TestCounter

# Generated at 2022-06-18 12:58:15.272052
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * 16)
    data = bytes_to_intlist(b'\x00' * 16)
    assert aes_cbc_decrypt(data, key, iv) == bytes_to_intlist(b'\x00' * 16)

    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * 16)
    data = bytes_to_intlist(b'\x00' * 32)
    assert aes_cbc_decrypt(data, key, iv) == bytes_to_intlist(b'\x00' * 32)

    key = bytes_to_intlist

# Generated at 2022-06-18 12:58:26.672402
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuTq8+0p0Y3+zJy2Dw=='))
    iv = bytes_to_intlist(compat_b64decode('q83zs6+L3lMvb5y7'))

# Generated at 2022-06-18 12:58:38.032981
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-18 12:58:49.019918
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)
    data = bytes_to_intlist(b'\x69\xc4\xe0\xd8\x6a\x7b\x04\x30\xd8\xcd\xb7\x80\x70\xb4\xc5\x5a')
    decrypted_data = aes_decrypt(data, expanded_key)

# Generated at 2022-06-18 12:58:59.371087
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    iv = bytes_to_intlist(compat_b64decode('2gF4YmwEIvxVlFMXDjEeOQ=='))
    cipher = bytes_to_intlist(compat_b64decode('f2cHhC9+94f7vX3aD3tNuA=='))
    expanded_key = key_expansion(key)
    assert aes_decrypt(cipher, expanded_key) == iv

# Generated at 2022-06-18 12:59:12.023874
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vector from https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf
    # Appendix C.2
    key = bytes_to_intlist(compat_b64decode('lU8a/0KL4B1IWJHeYxUfJw=='))
    cipher = bytes_to_intlist(compat_b64decode('7XJjOiMvjBjA4/j+MdGxDDcXC982xDerYH4o9tZ6W94='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 12:59:22.451671
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:59:34.519753
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test vector from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    key = bytes_to_intlist(compat_b64decode('gI0GAILBdu7T53akrFmMyA=='))
    iv = bytes_to_intlist(compat_b64decode('qC8v6RjsTbV1ZqK8zsM3wQ=='))
    cipher = bytes_to_intlist(compat_b64decode('LK5vMup4XD0YU9JzJT1i4w=='))
    plain = bytes_to_intlist(compat_b64decode('Single block msg'))


# Generated at 2022-06-18 12:59:42.022886
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(aes_decrypt(data, expanded_key)) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 12:59:52.920184
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QXuBtQ4BQ9hUQKlLgNw=='))
    iv = bytes_to_intlist(compat_b64decode('q83vEyBd1Nl5TmB9q9mVkw=='))
    cipher = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    plain = bytes_to_intlist(compat_b64decode('jn0DCtGt9n8EtFjVl5KlHg=='))


# Generated at 2022-06-18 13:02:11.369346
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:21.143276
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('/6X5O5+/vX1z+f3T/H4='))
    expanded_key = bytes_to_intlist(compat_b64decode('/6X5O5+/vX1z+f3T/H4=Jf8b+Kv9j+2f9/w=='))
    assert key_expansion(key) == expanded_key

    key = bytes_to_intlist(compat_b64decode('/6X5O5+/vX1z+f3T/H4=Jf8b+Kv9j+2f9/w=='))

# Generated at 2022-06-18 13:02:33.607205
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:43.783256
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:55.505771
# Unit test for function key_expansion

# Generated at 2022-06-18 13:03:04.357771
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7+FyqD5JzrKL+z/eE3Zg=='))
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(expanded_key) == compat_b64decode('gI7+FyqD5JzrKL+z/eE3Zg==' + 'H9bH6/K/0Yzf+Y/P6UZxw==' + '+mj+0Zv9HmP/kfz+lGcc=' + '=')



# Generated at 2022-06-18 13:03:16.311180
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:28.239105
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176

# Generated at 2022-06-18 13:03:35.697187
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:47.904650
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:59.935182
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:10.097745
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:18.748194
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:04:28.656048
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:40.260066
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:49.926387
# Unit test for function key_expansion
def test_key_expansion():
    # Test vectors from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    key = bytes_to_intlist(compat_b64decode('gI0GAILBdu7F03oh4K+s8w=='))
    expected_expanded_key = bytes_to_intlist(compat_b64decode('gI0GAILBdu7F03oh4K+s8w=='))
    expanded_key = key_expansion(key)
    assert expanded_key == expected_expanded_key

    key = bytes_to_intlist(compat_b64decode('m8rOF0j/j+2KkcWHjSdUrg=='))
    expected_expanded_key = bytes_to_int

# Generated at 2022-06-18 13:04:57.336479
# Unit test for function key_expansion

# Generated at 2022-06-18 13:05:08.406223
# Unit test for function key_expansion

# Generated at 2022-06-18 13:05:20.898526
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-18 13:05:32.858189
# Unit test for function key_expansion
def test_key_expansion():
    # Test vectors from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # Appendix F.1.1 - AES-128 (Nk=4, Nr=10)
    key = bytes_to_intlist(compat_b64decode('gZ0zwrv4NuT4f1KPmrnUMA=='))
    expanded_key = bytes_to_intlist(compat_b64decode('gZ0zwrv4NuT4f1KPmrnUMAwvOFHq+3r9+ydx8fX1zv0=\n'))
    assert key_expansion(key) == expanded_key

    # Appendix F.1.2 - AES-192 (Nk=6, Nr

# Generated at 2022-06-18 13:05:44.669152
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:55.760905
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CmU/OI4yc0I='))

# Generated at 2022-06-18 13:06:07.000984
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7QXqy3Zj4gP3wvJb8fTQ=='))