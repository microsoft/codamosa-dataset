

# Generated at 2022-06-18 12:56:46.921225
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * BLOCK_SIZE_BYTES)
    data = bytes_to_intlist(b'\x00' * BLOCK_SIZE_BYTES)
    assert aes_cbc_decrypt(data, key, iv) == data

    data = bytes_to_intlist(b'\x00' * (BLOCK_SIZE_BYTES - 1))
    assert aes_cbc_decrypt(data, key, iv) == data

    data = bytes_to_intlist(b'\x00' * (BLOCK_SIZE_BYTES + 1))
    assert aes_cbc_decrypt(data, key, iv) == data

    data = bytes_

# Generated at 2022-06-18 12:56:57.318118
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    cipher = [0x39, 0x25, 0x84, 0x1d, 0x02, 0xdc, 0x09, 0xfb, 0xdc, 0x11, 0x85, 0x97, 0x19, 0x6a, 0x0b, 0x32]
    expanded_key = key_expansion(key)
    state = aes_decrypt(cipher, expanded_key)

# Generated at 2022-06-18 12:57:08.183553
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QXuBt3j0qEaL+/H1S8yF9izNkWOd5GzNtWmNSXuI='))
    iv = bytes_to_intlist(compat_b64decode('qL1j6cjnlFzotgjRkQF9GQ=='))
    data = bytes_to_intlist(compat_b64decode('+ZYvJDtP6PRf5j0D3A=='))
    assert intlist_to_bytes(aes_cbc_decrypt(data, key, iv)) == b'foobar'


# Generated at 2022-06-18 12:57:20.786266
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    expanded_key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    expanded_key += bytes_to_intlist(compat_b64decode('2A/n0eDdCJghl+VJx8CrQg=='))
    expanded_key += bytes_to_intlist(compat_b64decode('0adfb183a15c5f3d931ae2=='))

# Generated at 2022-06-18 12:57:32.883838
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b'1234567890123456')
    key = bytes_to_intlist(b'1234567890123456')
    iv = bytes_to_intlist(b'1234567890123456')
    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-18 12:57:43.561434
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    iv = bytes_to_intlist(compat_b64decode('AxY8DCtDaGlsbGljb3RoZQ=='))
    data = bytes_to_intlist(compat_b64decode('KDlTtgcJkbRx+j5ts0VUjg=='))

    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('3up8VlhBfVpXZzPuAqoKrrQ==')



# Generated at 2022-06-18 12:57:56.520263
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7FybZKjn8='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 12:58:06.336052
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QMZ+OJvJb8DJmB/6ZmA=='))
    iv = bytes_to_intlist(compat_b64decode('qoY4TVlq5L2gJYQ=='))
    data = bytes_to_intlist(compat_b64decode('qoY4TVlq5L2gJYQ=='))
    assert aes_cbc_decrypt(data, key, iv) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]


# Generated at 2022-06-18 12:58:08.998989
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    decrypted_data = aes_decrypt_text(data, password, key_size_bytes)
    assert decrypted_data == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 12:58:20.769327
# Unit test for function aes_decrypt

# Generated at 2022-06-18 12:58:27.250538
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]


# Generated at 2022-06-18 12:58:29.721814
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:58:32.648908
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:58:37.318689
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]
    print("test_inc: OK")

test_inc()



# Generated at 2022-06-18 12:58:43.279324
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:58:50.294815
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:59:01.593374
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:59:09.738570
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:59:16.846707
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:59:22.616405
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:59:32.966575
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CzgV3uP3a/x66q5FbvO9wg=='))
    expanded_key = bytes_to_intlist(compat_b64decode('CzgV3uP3a/x66q5FbvO9wgEiLGuR/8jbTkrwTqV8zv4='))
    assert key_expansion(key) == expanded_key

# Generated at 2022-06-18 12:59:42.578101
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:59:53.567728
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:05.261740
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:16.326616
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:26.402413
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXoxMjM0NTY3ODkw'))

# Generated at 2022-06-18 13:00:36.487771
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:47.262469
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:58.175332
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7mKjy+tLZVtYy/xYWbXQ=='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:01:10.470741
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:26.209122
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:38.134152
# Unit test for function key_expansion
def test_key_expansion():
    key_size_bytes = 16
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:50.820878
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:02.869337
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:12.938846
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 13:02:22.267667
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:34.882456
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:46.143758
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:57.413312
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('Cz4hcgjzw7JZlJk3'))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:03:07.131948
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:24.614269
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:33.840036
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:46.551226
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:57.538351
# Unit test for function key_expansion

# Generated at 2022-06-18 13:04:07.598569
# Unit test for function key_expansion

# Generated at 2022-06-18 13:04:16.939140
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CQRiO8OoVx2+XBx8vLZLZjFH4i5jM4R2EDp1H1uWuys='))
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(expanded_key) == compat_b64decode('CQRiO8OoVx2+XBx8vLZLZjFH4i5jM4R2EDp1H1uWuys=')


# Generated at 2022-06-18 13:04:26.443167
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:37.339099
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CQRiF3Z9+GBDMIFHGxgZ/A=='))
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(expanded_key) == compat_b64decode('CQRiF3Z9+GBDMIFHGxgZ/A==' + 'LXJZ5Mq/QsRk1Vbvb9w==')

    key = bytes_to_intlist(compat_b64decode('CQRiF3Z9+GBDMIFHGxgZ/CQRiF3Z9+GBDMIFHGxgZ/A=='))
    expanded_key = key_expansion(key)
    assert intlist_to

# Generated at 2022-06-18 13:04:48.349003
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:55.904001
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('K7nyNqTj9nVU0wi9GATDtXOqJd8='))
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 240
    assert intlist_to_bytes(expanded_key[:16]) == compat_b64decode('K7nyNqTj9nVU0wi9GATDtXOqJd8=')
    assert intlist_to_bytes(expanded_key[-16:]) == compat_b64decode('1XC/pYZm+Px+TjGv5y4B1M7E+8A=')



# Generated at 2022-06-18 13:05:17.394376
# Unit test for function key_expansion

# Generated at 2022-06-18 13:05:26.199399
# Unit test for function key_expansion

# Generated at 2022-06-18 13:05:37.516024
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:49.671715
# Unit test for function key_expansion

# Generated at 2022-06-18 13:05:59.166099
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI2DVUY7ZuY3zjRp1S4Dkw=='))