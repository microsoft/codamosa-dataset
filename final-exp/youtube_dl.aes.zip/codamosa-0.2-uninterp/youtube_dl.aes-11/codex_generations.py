

# Generated at 2022-06-18 12:56:43.540512
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176

# Generated at 2022-06-18 12:56:51.127987
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 12:57:02.050066
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QDZuDq3Mq1Xl8qwz1xA=='))
    iv = bytes_to_intlist(compat_b64decode('/D9lV7q7Bq2eIW+8PZwvbg=='))
    cipher = bytes_to_intlist(compat_b64decode('XFboGn4tXKZwIc1/W9ir6g=='))
    plain = bytes_to_intlist(compat_b64decode('Hello World!'))
    assert aes_cbc_decrypt(cipher, key, iv) == plain



# Generated at 2022-06-18 12:57:14.177481
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b'1234567890123456')
    key = bytes_to_intlist(b'1234567890123456')
    iv = bytes_to_intlist(b'1234567890123456')
    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-18 12:57:26.457229
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 12:57:39.093464
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('C8AEDFDA1C8AEDFDA1C8AEDFDA1C8AEDF'))
    iv = bytes_to_intlist(compat_b64decode('C8AEDFDA1C8AEDFDA1C8AEDFDA1C8AEDF'))
    data = bytes_to_intlist(compat_b64decode('C8AEDFDA1C8AEDFDA1C8AEDFDA1C8AEDF'))
    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-18 12:57:45.518722
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:57:57.741363
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test vector from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    key = bytes_to_intlist(compat_b64decode('gI0GAILBdu7T53akrFmMyg=='))
    iv = bytes_to_intlist(compat_b64decode('qC8v6uKBxVQsH1/TKv5nsQ=='))
    cipher = bytes_to_intlist(compat_b64decode('LK5vMGIx4NpLxQl+uJl5nQ=='))
    plain = bytes_to_intlist(compat_b64decode('Single block msg'))


# Generated at 2022-06-18 12:58:08.635216
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    expanded_key = key_expansion(key)
    assert aes_encrypt(data, expanded_key) == bytes_to_intlist(compat_b64decode('3K3k2s2v2+7w+6x+6bwM3K3k2s2v2+7w+6x+6bwM='))


# Generated at 2022-06-18 12:58:20.409593
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QZuTqyj0xqPYOB9XOcA=='))
    iv = bytes_to_intlist(compat_b64decode('qCiGt9mhYM6FyBJv1hPj1A=='))
    cipher = bytes_to_intlist(compat_b64decode('qCiGt9mhYM6FyBJv1hPj1A=='))
    plain = bytes_to_intlist(compat_b64decode('qCiGt9mhYM6FyBJv1hPj1A=='))
    assert aes_cbc_decrypt(cipher, key, iv) == plain



# Generated at 2022-06-18 12:58:38.259019
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 12:58:49.313430
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, initial_value):
            self.value = initial_value

        def next_value(self):
            self.value += 1
            return self.value

    data = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-18 12:58:58.594206
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    expected_plaintext = b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '
    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == expected_plaintext


# Generated at 2022-06-18 12:59:11.180505
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, initial_value):
            self.value = initial_value

        def next_value(self):
            self.value += 1
            return [self.value] * BLOCK_SIZE_BYTES

    data = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode(b'YELLOW SUBMARINE'))
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)
    assert intlist_to

# Generated at 2022-06-18 12:59:21.904716
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 12:59:33.720733
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cbc import aes_cbc_encrypt
    from .aes_cbc import aes_cbc_decrypt
    from .aes_cbc import aes_cbc_decrypt_verify_pkcs7
    from .aes_cbc import aes_cbc_encrypt_pkcs7
    from .aes_cbc import aes_cbc_decrypt_verify_pkcs7
    from .aes_cbc import aes_cbc_encrypt_pkcs7
    from .aes_cbc import aes_cbc_decrypt_verify_pkcs7
    from .aes_cbc import aes_cbc_encrypt_pkcs7

# Generated at 2022-06-18 12:59:43.110331
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value = (self.value + 1) % (2 ** 64)
            return bytes_to_intlist(self.value.to_bytes(16, byteorder='big'))

    data = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-18 12:59:54.181817
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 13:00:05.955270
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 13:00:17.041191
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value += 1
            return self.value

    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-18 13:00:29.310817
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:40.796478
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:00:51.584777
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:03.200642
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:15.866283
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CmU/9qh1E1lhsu9n/UywMw=='))

# Generated at 2022-06-18 13:01:28.237130
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:01:39.788834
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:01:52.162790
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-18 13:02:03.570297
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:02:13.829279
# Unit test for function key_expansion
def test_key_expansion():
    # Test vectors from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # Appendix F.1.1 AES-128 (Nk=4, Nr=10)
    key = bytes_to_intlist(compat_b64decode(b'GZy6sIZ6wl9NJOKB-jnmVQ'))
    expanded_key = bytes_to_intlist(compat_b64decode(b'GZy6sIZ6wl9NJOKB-jnmVQx3EPn8uPtFyAQ8TJL6c0BZ5wLK1hqFbvfBEQiJ0j1S'))
    assert key_expansion(key) == expanded_key

    # Appendix F

# Generated at 2022-06-18 13:03:08.190178
# Unit test for function key_expansion

# Generated at 2022-06-18 13:03:20.929357
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('Cz0+Cg=='))
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:03:31.893880
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:43.942365
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:55.308007
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-18 13:04:04.758529
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:14.483921
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 13:04:21.427729
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:32.048747
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 13:04:43.267627
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:57.541536
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:08.456635
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:16.649702
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI4nRqkPvV4xN2YJY6rUHA=='))
    expanded_key = bytes_to_intlist(compat_b64decode('gI4nRqkPvV4xN2YJY6rUHJT+j2J9uLrI1Yjz5k0QX9Q='))
    assert key_expansion(key) == expanded_key



# Generated at 2022-06-18 13:05:25.771847
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CQ2/nQ=='))
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(expanded_key) == compat_b64decode('CQ2/nQ==' + 'BQ==' * 15)

    key = bytes_to_intlist(compat_b64decode('CQ2/nQ==' + 'BQ==' * 15))
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(expanded_key) == compat_b64decode('CQ2/nQ==' + 'BQ==' * 15 + 'BQ==' * 16)


# Generated at 2022-06-18 13:05:37.158164
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176

# Generated at 2022-06-18 13:05:49.671909
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-18 13:05:59.163790
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI2DYQYiB/zsRcLnYT/zsA=='))