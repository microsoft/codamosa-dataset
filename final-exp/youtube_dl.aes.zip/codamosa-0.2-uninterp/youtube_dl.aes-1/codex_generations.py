

# Generated at 2022-06-18 12:56:26.315681
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b'1234567890123456')
    key = bytes_to_intlist(b'1234567890123456')
    iv = bytes_to_intlist(b'1234567890123456')
    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-18 12:56:32.423549
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value += 1
            return self.value

    data = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode(b'YELLOW SUBMARINE'))
    counter = Counter(0)
    decrypted_data = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-18 12:56:41.980877
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * 16)
    data = bytes_to_intlist(b'\x00' * 16)
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == b'\x8c\xa6\x4d\xe9\xc1\xb1\x23\xa7\xdc\x4a\x65\x58\xcf\x0a\x0c\x6f'


# Generated at 2022-06-18 12:56:51.758539
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='))
    iv = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='))
    data = bytes_to_intlist(compat_b64decode('U3ByaW5nQmxhZGU='))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted_data) == compat_b64decode('zVNhbSZtaWxsO3NhbSZtaWxsO3NhbSZtaWxsOw==')



# Generated at 2022-06-18 12:57:03.133616
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))

# Generated at 2022-06-18 12:57:15.026741
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, start):
            self.start = start

        def next_value(self):
            self.start += 1
            return [self.start] * BLOCK_SIZE_BYTES

    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    counter = Counter(0)

# Generated at 2022-06-18 12:57:27.520386
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vector from https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(aes_decrypt(data, expanded_key)) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 12:57:40.211138
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 12:57:44.616145
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0x100):
        for j in range(0x100):
            assert rijndael_mul(i, j) == (i * j) % 0x100



# Generated at 2022-06-18 12:57:57.518672
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # Test vector from http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))

# Generated at 2022-06-18 12:58:12.656376
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-18 12:58:24.564270
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text('QfV7b6l0QaXmJl8=', 'test', 16) == b'12345678'
    assert aes_decrypt_text('QfV7b6l0QaXmJl8=', 'test', 24) == b'12345678'
    assert aes_decrypt_text('QfV7b6l0QaXmJl8=', 'test', 32) == b'12345678'
    assert aes_decrypt_text('QfV7b6l0QaXmJl8=', 'test', 16) == b'12345678'
    assert aes_decrypt_text('QfV7b6l0QaXmJl8=', 'test', 24) == b'12345678'

# Generated at 2022-06-18 12:58:33.079376
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    password = 'YELLOW SUBMARINE'
    key_size_bytes = 16
    expected_plaintext = b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '
    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == expected_plaintext



# Generated at 2022-06-18 12:58:41.174404
# Unit test for function shift_rows_inv
def test_shift_rows_inv():
    data = [0x63, 0xca, 0xb7, 0x04, 0x09, 0x53, 0xd0, 0x51, 0xcd, 0x60, 0xe0, 0xe7, 0xba, 0x70, 0xe1, 0x8c]
    data_shifted = shift_rows_inv(data)
    assert data_shifted == [0x63, 0x53, 0xe0, 0x8c, 0x09, 0xd0, 0xba, 0x04, 0xcd, 0x60, 0xb7, 0x51, 0xba, 0x70, 0xe1, 0xe7]
    print("test_shift_rows_inv() passed")

test_shift_rows_inv()


# Generated at 2022-06-18 12:58:52.781106
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]
    expanded_key = key_expansion(key)

# Generated at 2022-06-18 12:59:02.610896
# Unit test for function aes_decrypt_text

# Generated at 2022-06-18 12:59:14.832848
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-18 12:59:23.506113
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('gI7QDZuWx5LlPnBj0asfzg=='))
    iv = bytes_to_intlist(compat_b64decode('qT7XOJloU3vqJjh3fEJQRQ=='))
    cipher = bytes_to_intlist(compat_b64decode('LK1MjiqEzqJ4SAf3c8uLmA=='))
    plain = bytes_to_intlist(compat_b64decode('XchHdlJHRXg='))
    assert aes_cbc_decrypt(cipher, key, iv) == plain



# Generated at 2022-06-18 12:59:35.589099
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test vectors from http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf
    # Appendix C - Example Vectors
    # AES-128 (Nk=4, Nr=10)
    key = bytes_to_intlist(compat_b64decode('2b7e151628aed2a6abf7158809cf4f3c'))
    cipher = bytes_to_intlist(compat_b64decode('3ad77bb40d7a3660a89ecaf32466ef97'))
    expected_state = bytes_to_intlist(compat_b64decode('6bc1bee22e409f96e93d7e117393172a'))
    expanded_key = key_expansion(key)
    state = aes

# Generated at 2022-06-18 12:59:42.848688
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(aes_decrypt(data, expanded_key)) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-18 13:00:16.723029
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x83) == 0xc1
    assert rijndael_mul(0x83, 0x13) == 0x01
    assert rijndael_mul(0x13, 0x57) == 0xfe
    assert rijndael_mul(0xfe, 0x13) == 0x57
    assert rijndael_mul(0x13, 0x13) == 0x1b
    assert rijndael_mul(0x1b, 0x13) == 0x57
    assert rijndael_mul(0x57, 0x1b) == 0x83
    assert rijndael_mul(0x83, 0x1b) == 0x13

# Generated at 2022-06-18 13:00:20.315355
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0x100):
        for j in range(0x100):
            assert rijndael_mul(i, j) == (i * j) % 0x100



# Generated at 2022-06-18 13:00:23.111971
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range(0x100):
        for b in range(0x100):
            assert rijndael_mul(a, b) == galois_mul(a, b)



# Generated at 2022-06-18 13:00:30.766226
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x83) == 0xc1
    assert rijndael_mul(0x83, 0x13) == 0x01
    assert rijndael_mul(0x13, 0x57) == 0xfe
    assert rijndael_mul(0x57, 0x13) == 0xfe
    assert rijndael_mul(0x13, 0x83) == 0x01
    assert rijndael_mul(0x83, 0x57) == 0xc1
    assert rijndael_mul(0x57, 0x57) == 0x04
    assert rijndael_mul(0x13, 0x13) == 0x0e

# Generated at 2022-06-18 13:00:34.566558
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0x100):
        for j in range(0x100):
            assert rijndael_mul(i, j) == (i * j) % 0x100



# Generated at 2022-06-18 13:00:37.718067
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for i in range(0, 0xFF):
        for j in range(0, 0xFF):
            assert rijndael_mul(i, j) == (i * j) % 0xFF



# Generated at 2022-06-18 13:00:42.352869
# Unit test for function rijndael_mul
def test_rijndael_mul():
    for a in range(0x100):
        for b in range(0x100):
            assert rijndael_mul(a, b) == rijndael_mul(b, a)
            assert rijndael_mul(a, 0) == 0
            assert rijndael_mul(a, 1) == a
            assert rijndael_mul(a, 2) == rijndael_mul(a, 1) ^ a
            assert rijndael_mul(a, 3) == rijndael_mul(a, 2) ^ a
            assert rijndael_mul(a, 4) == rijndael_mul(a, 2) ^ rijndael_mul(a, 2)
            assert rijndael_mul(a, 5)

# Generated at 2022-06-18 13:00:53.346574
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x83) == 0xc1
    assert rijndael_mul(0x83, 0x13) == 0x01
    assert rijndael_mul(0x13, 0x57) == 0xfe
    assert rijndael_mul(0x57, 0x13) == 0xfe
    assert rijndael_mul(0x13, 0x83) == 0x01
    assert rijndael_mul(0x83, 0x57) == 0xc1
    assert rijndael_mul(0x57, 0x57) == 0x4f
    assert rijndael_mul(0x13, 0x13) == 0x0e

# Generated at 2022-06-18 13:01:04.999272
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x83) == 0xc1
    assert rijndael_mul(0x83, 0x13) == 0x01
    assert rijndael_mul(0x13, 0x57) == 0xfe
    assert rijndael_mul(0x57, 0x13) == 0xfe
    assert rijndael_mul(0x13, 0x83) == 0x01
    assert rijndael_mul(0x83, 0x57) == 0xc1
    assert rijndael_mul(0x57, 0x57) == 0x4f
    assert rijndael_mul(0x13, 0x13) == 0x0e

# Generated at 2022-06-18 13:01:18.264653
# Unit test for function rijndael_mul
def test_rijndael_mul():
    assert rijndael_mul(0x57, 0x83) == 0xc1
    assert rijndael_mul(0x83, 0x13) == 0x01
    assert rijndael_mul(0x13, 0x57) == 0xfe
    assert rijndael_mul(0x57, 0x13) == 0xfe
    assert rijndael_mul(0x13, 0x83) == 0x01
    assert rijndael_mul(0x83, 0x57) == 0xc1
    assert rijndael_mul(0x57, 0x57) == 0x4f
    assert rijndael_mul(0x13, 0x13) == 0x0e

# Generated at 2022-06-18 13:01:59.863075
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:08.814769
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:19.423108
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:30.800454
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:02:41.553098
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CmU/9qhF9/WgXnzpzkYTmQ=='))

# Generated at 2022-06-18 13:02:53.390693
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:04.271193
# Unit test for function key_expansion

# Generated at 2022-06-18 13:03:16.311556
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI/uV/m0XqY='))

# Generated at 2022-06-18 13:03:28.183521
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:03:33.777564
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('CQ5O3ZxrjbC1VZuL9qKD9Q=='))
    expected = bytes_to_intlist(compat_b64decode('CQ5O3ZxrjbC1VZuL9qKD9Q+6ZT4nNhxvjQnNq8uKdGc='))
    assert key_expansion(key) == expected



# Generated at 2022-06-18 13:04:49.124220
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:04:57.171753
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:08.409731
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gI7sNrWxob+eRVvb6kR/gw=='))
    expected = bytes_to_intlist(compat_b64decode('gI7sNrWxob+eRVvb6kR/gw==' + '+P3XJfD7Q0YF9atRcL7Btw=='))
    assert key_expansion(key) == expected

    key = bytes_to_intlist(compat_b64decode('gI7sNrWxob+eRVvb6kR/gw==' + '+P3XJfD7Q0YF9atRcL7Btw=='))

# Generated at 2022-06-18 13:05:20.897589
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-18 13:05:32.858101
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:05:42.456250
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('/mQGAmkR3+mIqJYQ5v5DnsQ=='))
    expanded_key = bytes_to_intlist(compat_b64decode('/mQGAmkR3+mIqJYQ5v5DnsQ=='))
    assert key_expansion(key) == expanded_key

    key = bytes_to_intlist(compat_b64decode('/mQGAmkR3+mIqJYQ5v5DnsQ=='))
    expanded_key = bytes_to_intlist(compat_b64decode('/mQGAmkR3+mIqJYQ5v5DnsQ=='))
    assert key_expansion(key)

# Generated at 2022-06-18 13:05:54.001667
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-18 13:06:05.693833
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]