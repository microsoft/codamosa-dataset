

# Generated at 2022-06-12 16:23:49.240202
# Unit test for function aes_decrypt
def test_aes_decrypt():
    original_data = '000102030405060708090a0b0c0d0e0f'
    original_key = '00112233445566778899aabbccddeeff'
    original_expanded_key = [
        0x00112233, 0x44556677, 0x8899aabb, 0xccddeeff,
        0xd6aa74fd, 0xd2af72fa, 0xdaa678f1, 0xd6ab76fe,
        0xb692cf0b, 0x64a08615, 0xce4aaaf3, 0xddfbd7f7,
        0x6c33dc76, 0x2e5a917f, 0x3c9b51fd, 0x59dffd8d,
    ]
    original_c

# Generated at 2022-06-12 16:23:57.700713
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = "4ca00ff4c898d61e1edbf1800618fb2828a226d160dad07883d04e008a7897ee2e4b7465d5290d0c0e6c6822236e1daafb94ffe0c5da05d9476be028ad7c1d81"
    key = "140b41b22a29beb4061bda66b6747e14"
    iv = "4ca00ff4c898d61e1edbf1800618fb28"
    expected_res = "Basic CBC mode encryption needs padding."

# Generated at 2022-06-12 16:24:09.855205
# Unit test for function aes_encrypt
def test_aes_encrypt():

    print(":::: Unit test for function aes_encrypt")
    #Variables to encrypt
    data = bytes_to_intlist([79, 1, 57, 74, 0, 251, 152, 238, 216, 221, 39, 240, 59, 25, 104, 221])
    key = bytes_to_intlist([63, 203, 133, 209, 0, 134, 201, 31, 206, 169, 22, 199, 54, 228, 132, 225, 232, 20, 71, 45, 89, 35, 133, 33, 161, 70, 63, 195, 119, 89, 253, 167])
    iv = bytes_to_intlist([164, 26, 46, 89, 175, 20, 48, 121, 139, 242, 208, 131, 176, 66, 105, 41])


# Generated at 2022-06-12 16:24:19.213482
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = "2b7e151628aed2a6abf7158809cf4f3c"
    data = "3ad77bb40d7a3660a89ecaf32466ef97"

    data_intlist = bytes_to_intlist(compat_b64decode(data))
    key_intlist = bytes_to_intlist(compat_b64decode(key))
    expanded_key = key_expansion(key_intlist)

    cipher = aes_encrypt(data_intlist, expanded_key)
    decrypted = aes_decrypt(cipher, expanded_key)

    return data_intlist == decrypted

if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-12 16:24:32.194070
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .aes_cbc import aes_cbc_encrypt
    from .utils import bytes_to_intlist

    key = bytes_to_intlist('140b41b22a29beb4061bda66b6747e14')
    iv = bytes_to_intlist('4ca00ff4c898d61e1edbf1800618fb28')
    data = bytes_to_intlist('28a226d160dad07883d04e008a7897ee2e4b7465d5290d0c0e6c6822236e1daafb94ffe0c5da05d9476be028ad7c1d81')

    assert aes_cbc_decrypt(data, key, iv) == bytes_to_intlist('Basic CBC mode encryption needs padding.')
    
    key

# Generated at 2022-06-12 16:24:37.323751
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .test_utils import random_bytes, random_intlist

    def random_counter():
        return random_intlist(16)

    for i in range(10):
        data = random_bytes(random.randint(8, 16))
        key = random_intlist(16)
        counter = random_counter
        assert aes_ctr_decrypt(aes_ctr_encrypt(data, key, counter), key, counter) == bytes_to_intlist(data)

# Generated at 2022-06-12 16:24:47.514453
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = b'\x8e\x73\xb0\xf7\xda\x0e\x64\x52\xc8\x10\xf3\x2b\x80\x90\x79\xe5\x62\xf8\xea\xd2\x52\x2c\x6b\x7b'
    iv = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'
    text = b'hello world'

    result = aes_cbc_encrypt(bytes_to_intlist(text), bytes_to_intlist(key), bytes_to_intlist(iv))
    expected = compat

# Generated at 2022-06-12 16:24:58.884659
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist("36f18357be4dbd77f050515c73fcf9f2")
    iv = bytes_to_intlist("69dda8455c7dd4254bf353b773304eec")
    cipher = bytes_to_intlist("e46218c0a53cbeca695ae45faa8952aa0e311bde9d4e01726d3184c34451")
    expected_plain = intlist_to_bytes("The Magic Words are Squeamish Ossifrage")
    plain = aes_cbc_decrypt(cipher, key, iv)
    assert expected_plain == intlist_to_bytes(plain), "AES CBC decryption failed."



# Generated at 2022-06-12 16:25:08.748912
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data_test_encrypt = [169, 81, 82, 85, 253, 63, 126, 220, 2, 188, 74, 221, 158, 49, 129, 106]

# Generated at 2022-06-12 16:25:20.291672
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Test 1
    _key = "1234567890abcdefghijklmnopqrstuvwxyzABCDEF"
    enc = "V2lkSTJxVGxRPT0="  # Base64 encoded
    dec = aes_decrypt_text(enc, _key, 32)  # 256-Bit
    assert(dec == "1234567890abcdef")
    # Test 2
    _key = "1234567890abcdefghijklmnopqrstuvwx"
    enc = "RlRjWEZtVjF3PT0="  # Base64 encoded
    dec = aes_decrypt_text(enc, _key, 24)  # 192-Bit
    assert(dec == "1234567890abcdef")
    # Test 3

# Generated at 2022-06-12 16:25:31.308136
# Unit test for function key_expansion
def test_key_expansion():
    new_expanded_key = key_expansion(bytes_to_intlist(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'))
    # new: 176 bytes
    #expanded = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    #            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    #            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    #            0, 0, 0

# Generated at 2022-06-12 16:25:36.952489
# Unit test for function inc
def test_inc():
    for i in range(256):
        assert(inc([i])[0] == i + 1)
    assert(inc([255, 255, 255, 255, 255, 255, 255, 255]) == [0, 0, 0, 0, 0, 0, 0, 0])
    print("Successfully tested function inc")


# Generated at 2022-06-12 16:25:44.397464
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]
    assert inc([1, 2, 3, 4]) == [1, 2, 3, 5]
    assert inc([255, 255, 255, 253]) == [255, 255, 255, 254]



# Generated at 2022-06-12 16:25:48.340146
# Unit test for function inc
def test_inc():
    data = [0x11, 0x00, 0x00, 0x00]
    data2 = inc(data)
    assert data2 == [0x11, 0x00, 0x00, 0x01]



# Generated at 2022-06-12 16:25:57.970189
# Unit test for function inc
def test_inc():
    assert inc(bytes.fromhex('00')) == bytes.fromhex('01')
    assert inc(bytes.fromhex('01')) == bytes.fromhex('02')
    assert inc(bytes.fromhex('ff')) == bytes.fromhex('00')
    assert inc(bytes.fromhex('c0')) == bytes.fromhex('c1')
    assert inc(bytes.fromhex('10' * 16)) == bytes.fromhex('11' * 16)
    assert inc(bytes.fromhex('f0' * 16)) == bytes.fromhex('00' * 15 + '01')


# Generated at 2022-06-12 16:26:05.846670
# Unit test for function inc
def test_inc():
    if inc([0, 0, 0, 0]) != [0, 0, 0, 1]:
        return False
    if inc([255, 255, 255, 255]) != [0, 0, 0, 0]:
        return False
    if inc([1, 2, 3, 4]) != [1, 2, 3, 5]:
        return False
    if inc([127, 255, 0, 255]) != [128, 0, 1, 0]:
        return False
    return True


# Generated at 2022-06-12 16:26:16.895014
# Unit test for function key_expansion
def test_key_expansion():
    key = {
        '128': bytes_to_intlist(compat_b64decode('GQej0/OXZ7v9JAtO+FV7Cg==')),
        '192': bytes_to_intlist(compat_b64decode('q0X0oHgZf/zc8q3L+FV7CigfPmSrcY39')),
        '256': bytes_to_intlist(compat_b64decode('tRYo0x/OZ+zfTtNR/A/OTZc1jBQfHWtyjJh7n+yg=='))
    }

# Generated at 2022-06-12 16:26:23.355559
# Unit test for function inc
def test_inc():
    data = [0, 0, 0, 0]
    assert inc(data) == [0, 0, 0, 1]
    data = [0, 0, 0, 255]
    assert inc(data) == [0, 0, 1, 0]
    data = [255]*16
    assert inc(data) == [0]*15 + [1]



# Generated at 2022-06-12 16:26:27.354478
# Unit test for function inc
def test_inc():
    n = 20
    data = [1]*n
    for i in range(n):
        assert inc(data) == [0]*i + [1]*(n-i)


# Generated at 2022-06-12 16:26:39.571864
# Unit test for function inc
def test_inc():
    #test 1
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]
    #test 2
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    #test 3
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    #test 4
    assert inc([0, 0, 0, 254]) == [0, 0, 0, 255]
    #test 5
    assert inc([0, 1, 0, 255]) == [0, 1, 1, 0]
    #test 6
    assert inc([1, 1, 1, 1]) == [1, 1, 1, 2]
    #test 7
    assert inc([1, 1, 9, 9]) == [1, 1, 10, 0]



# Generated at 2022-06-12 16:26:54.522172
# Unit test for function key_expansion
def test_key_expansion():
    key = [41, 214, 159, 26, 139, 9, 78, 53, 209, 34, 26, 178, 130, 230, 237, 209]

# Generated at 2022-06-12 16:27:05.777241
# Unit test for function key_expansion

# Generated at 2022-06-12 16:27:11.974740
# Unit test for function key_expansion
def test_key_expansion():
    assert (
        key_expansion(b'\x00' * 16) ==
        bytes_to_intlist(compat_b64decode(
            b'AgYBAQEBBAQBAQEBBAUBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAg=='))
    )
    assert (
        key_expansion(b'\x00' * 24) ==
        bytes_to_intlist(compat_b64decode(
            b'AgYBAQEBBAQBAQEBBAUBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAgQBBQEFBAEGBwQ='))
    )

# Generated at 2022-06-12 16:27:24.079882
# Unit test for function key_expansion

# Generated at 2022-06-12 16:27:35.816115
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00] * BLOCK_SIZE_BYTES
    expanded_key = []
    for i in range(11):
        expanded_key += key
        key = key_expansion(key)

# Generated at 2022-06-12 16:27:47.609713
# Unit test for function key_expansion
def test_key_expansion():
    def assert_data_equal(data, expected):
        assert len(data) == len(expected)
        assert data == expected

# Generated at 2022-06-12 16:27:53.729352
# Unit test for function key_expansion

# Generated at 2022-06-12 16:28:05.098653
# Unit test for function key_expansion

# Generated at 2022-06-12 16:28:16.405191
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist([
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
        0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f
    ])

# Generated at 2022-06-12 16:28:24.200537
# Unit test for function key_expansion
def test_key_expansion():
    key_size_bytes = 16
    expanded_key = key_expansion(range(key_size_bytes))
    assert len(expanded_key) == 176
    key_size_bytes = 24
    expanded_key = key_expansion(range(key_size_bytes))
    assert len(expanded_key) == 208
    key_size_bytes = 32
    expanded_key = key_expansion(range(key_size_bytes))
    assert len(expanded_key) == 240


# Generated at 2022-06-12 16:28:39.078188
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')

# Generated at 2022-06-12 16:28:51.807693
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10]

# Generated at 2022-06-12 16:29:03.182203
# Unit test for function key_expansion

# Generated at 2022-06-12 16:29:14.853096
# Unit test for function key_expansion
def test_key_expansion():
    expanded_key = key_expansion(bytes_to_intlist(compat_b64decode(b'VUVDMgAAACAAKsQAAcCAAAAAYABuYA=')))

# Generated at 2022-06-12 16:29:27.040345
# Unit test for function key_expansion
def test_key_expansion():
    assert aes_encrypt([0] * 16, key_expansion([0] * 16)) == [238, 244, 244, 238, 238, 244, 244, 238, 238, 244, 244, 238, 238, 244, 244, 238]
    assert aes_encrypt([0] * 16, key_expansion([0] * 24)) == [238, 244, 244, 238, 238, 244, 244, 238, 238, 244, 244, 238, 238, 244, 244, 238]
    assert aes_encrypt([0] * 16, key_expansion([0] * 32)) == [238, 244, 244, 238, 238, 244, 244, 238, 238, 244, 244, 238, 238, 244, 244, 238]

# Generated at 2022-06-12 16:29:39.169628
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:29:47.824762
# Unit test for function key_expansion
def test_key_expansion():
    x = key_expansion([0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f])
    assert bytes_to_intlist(compat_b64decode('pAoJlP8fT+QZsCdYX9YY/Q==')) == x

# Generated at 2022-06-12 16:30:00.502405
# Unit test for function key_expansion
def test_key_expansion():
    # test data came from http://www.inconteam.com/software-development/41-encryption/55-aes-test-vectors
    key_128 = bytes_to_intlist('\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    key_192 = bytes_to_intlist('\x8e\x73\xb0\xf7\xda\x0e\x64\x52\xc8\x10\xf3\x2b\x80\x90\x79\xe5\x62\xf8\xea\xd2\x52\x2c\x6b\x7b')
    key_256 = bytes

# Generated at 2022-06-12 16:30:10.349242
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    key_expanded = key_expansion(key)
    assert key_expanded[:16] == key
    assert len(key_expanded) == 240  # For 256-bit key

    key = [0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5]
    # 0x62, 0x

# Generated at 2022-06-12 16:30:22.169988
# Unit test for function key_expansion
def test_key_expansion():
    key = [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
        0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f
    ]

# Generated at 2022-06-12 16:30:38.721143
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gImbFXFhBJYXH+jKPGMDW1g=='))
    expanded_key = bytes_to_intlist(compat_b64decode('gImbFXFhBJYXH+jKPGMDW1g==nWzC8vAi+YSTmoJbVYGEu8O1hUp7dgAH+/Ruw7VkBfk='))
    result = key_expansion(key)
    assert result == expanded_key



# Generated at 2022-06-12 16:30:50.717619
# Unit test for function key_expansion
def test_key_expansion():
    key_size_bytes = 32
    key = [0] * key_size_bytes
    expanded_key_size_bytes = 240
    expanded_key = key_expansion(key)
    assert len(expanded_key) == expanded_key_size_bytes
    assert bytes_to_intlist(compat_b64decode('zvFHrsWcBfDl1E9Xr6UvB6rYIw5ytjxGzfMKTH3hr8Q=')) == expanded_key[:16]
    assert bytes_to_intlist(compat_b64decode('vR0jKZlJ/dltlX3qf3KjhpQiM/d1xmQj22i00O4Due4=')) == expanded_key[-16:]
# end of test_

# Generated at 2022-06-12 16:31:02.655691
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:13.264020
# Unit test for function key_expansion
def test_key_expansion():
    print("test_key_expansion")
    key = bytes_to_intlist(compat_b64decode(b'QkFWSFRBQ1RPUg=='))
    expanded_key = bytes_to_intlist(compat_b64decode(b'QkFWSFRBQ1RPUhFTVEVQTUlOSVNXRU5ETE9HSVNUQ1JFVFVST1hBTElDVFRSQU5TSUdORUNEU1NPTUJFWElDT05ERUxORFdFUlNJT04='))
    assert(expanded_key == key_expansion(key))
    print("success")



# Generated at 2022-06-12 16:31:25.603820
# Unit test for function key_expansion
def test_key_expansion():
    expanded = key_expansion([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00])

# Generated at 2022-06-12 16:31:34.383588
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist([0xfe, 0xff, 0xe9, 0x92, 0x86, 0x65, 0x73, 0x1c, 0x6d, 0x6a, 0x8f, 0x94, 0x67, 0x30, 0x83, 0x08])

# Generated at 2022-06-12 16:31:46.677426
# Unit test for function key_expansion
def test_key_expansion():
    key_size_bytes_list = [16, 24, 32]
    test_key = [
        0x2b, 0x28, 0xab, 0x09,
        0x7e, 0xae, 0xf7, 0xcf,
        0x15, 0xd2, 0x15, 0x4f,
        0x16, 0xa6, 0x88, 0x3c,
    ]
    for key_size_bytes in key_size_bytes_list:
        key = test_key[:key_size_bytes]
        expanded_key = key_expansion(key)
        assert len(expanded_key) == (key_size_bytes // 4 + 7) * BLOCK_SIZE_BYTES

    aes_key = "MOCK_KEY"
    aes_key_hex

# Generated at 2022-06-12 16:31:56.847133
# Unit test for function key_expansion
def test_key_expansion():
    # 16 Byte key
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:32:08.667415
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:17.635921
# Unit test for function key_expansion
def test_key_expansion():
    # http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    data = bytes_to_intlist([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c])

# Generated at 2022-06-12 16:32:42.118729
# Unit test for function key_expansion
def test_key_expansion():
    # Sample test vectors from NIST
    key_16 = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')

# Generated at 2022-06-12 16:32:53.662061
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x53, 0x33, 0x47, 0x4a, 0x4b, 0x4d, 0x31, 0x77, 0x34, 0x30, 0x31, 0x43, 0x4b, 0x30, 0x42, 0x59]
    expanded = key_expansion(key)

# Generated at 2022-06-12 16:33:05.705906
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    expanded_key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA+LAa5BzRqO3j/3fHm7n1k+Mhg9PQ=='))
    if expanded_key != key_expansion(key):
        print('Failed Unit Test for function key_expansion')
        print('Generated: ', intlist_to_bytes(key_expansion(key)).encode('string_escape'))
        print('Expected : ', intlist_to_bytes(expanded_key).encode('string_escape'))
# Unit test

# Generated at 2022-06-12 16:33:18.070158
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('YlH+V7lzSwFxOkPtNg2hiQ=='))
    assert key == [183, 145, 218, 146, 64, 23, 162, 251, 183, 56, 15, 251, 23, 64, 237, 82]

    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176