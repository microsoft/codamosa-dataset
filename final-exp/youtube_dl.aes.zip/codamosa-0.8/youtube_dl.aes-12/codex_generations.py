

# Generated at 2022-06-12 16:23:39.837599
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'dJbdarL1MytyaRbGvdPkdfFgnq3OqrM8eD0zmX9j1q3uq7Bk4n6uw7VlbrLTv8Ci6S5rsfU5Q=='
    password = 'password'
    key_size_bytes = 16
    assert aes_decrypt_text(data, password, key_size_bytes) == b'test'

# Generated at 2022-06-12 16:23:48.929947
# Unit test for function key_expansion
def test_key_expansion():
    # function key_expansion(data: Array<number, 1>) : Array<number, 1>
    KEY = intlist_to_bytes([
        0x2b, 0x7e, 0x15, 0x16,
        0x28, 0xae, 0xd2, 0xa6,
        0xab, 0xf7, 0x15, 0x88,
        0x09, 0xcf, 0x4f, 0x3c
    ])

# Generated at 2022-06-12 16:23:57.442232
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    ciphertext = intlist_to_bytes([
        0xea, 0x02, 0x47, 0x14, 0xad, 0x5c, 0x4d, 0x84, 0xdf, 0x1a, 0x3f, 0x6b, 0x2e, 0x71, 0xb0, 0xd4,
        0x98, 0x7e, 0x0c, 0x13, 0xaf, 0x50, 0x3d, 0xdc, 0xa5, 0xea, 0x2d, 0x1a, 0x7e, 0x47, 0x33, 0x85
    ])

# Generated at 2022-06-12 16:24:09.531873
# Unit test for function key_expansion
def test_key_expansion():
    key_sizes = [16, 24, 32]
    for key_size in key_sizes:
        key = [0] * key_size
        expanded_key = key_expansion(key)
        assert len(expanded_key) == ((key_size // 4 + 7) * 16)


# Generated at 2022-06-12 16:24:19.251892
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = [ord(b) for b in compat_b64decode('QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F')]
    key = [ord(b) for b in compat_b64decode('603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4')]
    iv = [ord(b) for b in compat_b64decode('F58C4C04D6E5F1BA779EABFB5F7BFBD6')]

# Generated at 2022-06-12 16:24:32.194855
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff,
            0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-12 16:24:39.605658
# Unit test for function aes_encrypt
def test_aes_encrypt():
  global BLOCK_SIZE_BYTES
  BLOCK_SIZE_BYTES = 16
  # Original Pass: 00000000000000000000000000000000

# Generated at 2022-06-12 16:24:51.796559
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test cases from http://csrc.nist.gov/groups/STM/cavp/index.html#CAVPPIP
    with open('data/CBCGFSbox128.rsp', 'rb') as f:
        for line in f:
            line = line.decode('utf-8')
            if line.startswith('Count'):
                count = int(line.split('= ')[1])
            elif line.startswith('Key'):
                key = bytes_to_intlist(compat_b64decode(line.split('= ')[1]))
            elif line.startswith('IV'):
                iv = bytes_to_intlist(compat_b64decode(line.split('= ')[1]))

# Generated at 2022-06-12 16:25:04.020900
# Unit test for function key_expansion

# Generated at 2022-06-12 16:25:13.524814
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:25:31.025653
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'Y1hEbUFtZWxzZjA/N2c5Zg=='
    password = '2Mkc5Y5q5q5zdqp5ckt'
    decrypted_data = aes_decrypt_text(data, password, 32)

    assert decrypted_data == b'11EDE60CEE'

# [Internal]


# Generated at 2022-06-12 16:25:43.725803
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Test vectors from https://software.intel.com/en-us/articles/aes-instructions-test-data
    AES256_KEY = ['2b', '7e', '15', '16', '28', 'ae', 'd2', 'a6', 'ab', 'f7', '15', '88', '09', 'cf', '4f', '3c']
    AES256_KEY = bytes_to_intlist(bytearray(AES256_KEY))

    AES256_CIPHER1 = ['8d', 'a4', 'e7', 'ab', 'e4', '15', 'd2', '15', '4f', '09', 'f2', '6a', '51', '30', '67', 'cd']

# Generated at 2022-06-12 16:25:53.092108
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    assert aes_cbc_encrypt(
        bytes_to_intlist('YELLOW SUBMARINE'),
        bytes_to_intlist('YELLOW SUBMARINE'),
        bytes_to_intlist('\x00' * BLOCK_SIZE_BYTES)
    ) == bytes_to_intlist('\x4b\xd4\x4f\xcd\x25\x60\x43\x23\x90\x19\x63\xe7\x2d\x3d\x96\xdef\x39\x82\x88\x3c\x5e\x5f\x04\xe8\x53\x0d\x6c\x1e\x6c\x96')


# Generated at 2022-06-12 16:26:06.163540
# Unit test for function mix_columns
def test_mix_columns():
    test_vector = [0xdb, 0xf2, 0xd4, 0x6f, 0x45, 0x7f, 0x01, 0x3c, 0x8f, 0x86, 0xc3, 0x5b, 0x2d, 0xe9, 0x17, 0x92]
    result = mix_columns(test_vector)
    expected_result = [0x04, 0xe0, 0x48, 0x28, 0x66, 0xcb, 0xf8, 0x06, 0x81, 0x19, 0xd3, 0x26, 0xe5, 0x9a, 0x7a, 0x4c]
    for x, y in zip(result, expected_result):
        if(x != y):
            print("Fail")
            exit(0)


# Generated at 2022-06-12 16:26:17.142606
# Unit test for function inc
def test_inc():
    assert inc([25, 25, 25, 25, 25, 25, 25, 25, 25, 25]) == [25, 25, 25, 25, 25, 25, 25, 25, 25, 26]
    assert inc([255, 255, 255, 255, 255, 255, 255, 255, 255, 255]) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    assert inc([255, 255, 255, 255, 255, 255, 255, 255, 255, 254]) == [255, 255, 255, 255, 255, 255, 255, 255, 255, 255]
    assert inc([0, 0, 0, 0, 0, 0, 0, 0, 0, 0]) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 1]

# Generated at 2022-06-12 16:26:30.646535
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:26:35.727069
# Unit test for function inc
def test_inc():
    assert inc([0x00,0x00,0x00,0x01]) == [0x00,0x00,0x00,0x02]
    assert inc([0x00,0x00,0x00,0x03]) == [0x00,0x00,0x00,0x04]
    assert inc([0x00,0x00,0x00,0xFF]) == [0x00,0x00,0x01,0x00]
    assert inc([0x00,0x00,0x01,0x00]) == [0x00,0x00,0x01,0x01]
    assert inc([0x00,0x00,0x01,0x01]) == [0x00,0x00,0x01,0x02]

# Generated at 2022-06-12 16:26:44.970116
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [
        0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c
    ]


# Generated at 2022-06-12 16:26:58.009933
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Asserts that aes_decrypt works correctly
    """
    # pylint: disable=invalid-name

# Generated at 2022-06-12 16:27:05.417925
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    ct_bytes = "QXdJQ0FQWUNBUABjTEJtQ08wYkFQYWlsVzFOSURjdXA0TE1OcWZjUkp1OEJXYmVwR0RidQ=="
    key_size_bytes = 16
    password = "password"
    decrypted_bytes = "The quick brown fox jumps over the lazy dog."
    assert aes_decrypt_text(ct_bytes, password, key_size_bytes) == decrypted_bytes

# Generated at 2022-06-12 16:27:22.318285
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode(b'CMSY1KJqlpDh99CZB+zGrg=='))
    iv = bytes_to_intlist(compat_b64decode(b'f9lsVl0/8PRpflGbF/Nx/A=='))
    data = bytes_to_intlist(compat_b64decode(b'u0DmSzPMdgFmYW0tYWVlNWM4NzM1YTlhMzYwMWFlMjUxZGI='))
    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-12 16:27:30.211737
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(bytearray('test', 'utf-8'))
    key = bytes_to_intlist(bytearray([1] * 16))
    iv = bytes_to_intlist(bytearray([2] * 16))
    encrypted = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted) == bytearray(compat_b64decode(
        'zPjWBlow+LKj5fZJiEaIZw=='))



# Generated at 2022-06-12 16:27:42.095700
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from .decryptor_aes_cbc import _get_encrypted_key_and_iv
    def assert_wv_encryption_result(key_hex, data_hex, expected_result_hex):
        key = bytes_to_intlist(compat_b64decode(key_hex))
        data = bytes_to_intlist(compat_b64decode(data_hex))
        expected_result = bytes_to_intlist(compat_b64decode(expected_result_hex))
        result = aes_cbc_encrypt(data, key, [0] * 16)
        assert result == expected_result

# Generated at 2022-06-12 16:27:52.598690
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    iv = intlist_to_bytes(AES_CBC_IV)
    key = intlist_to_bytes([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])
    data = intlist_to_bytes([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])
    encrypted_data = aes_cbc_encrypt(bytes_to_intlist(data), bytes_to_intlist(key), bytes_to_intlist(iv))
    # this is example from R.H.Davis's book
    assert encrypted_data == [1, 77, 2, 77, 3, 77, 4, 77, 5, 77, 6, 77, 7, 77, 8, 77]

# Generated at 2022-06-12 16:28:03.578895
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    testdata = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    encrypted_data = aes_cbc_encrypt

# Generated at 2022-06-12 16:28:13.078069
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    rgb_key = "O" * 32
    rgb_iv = "O" * 16
    rgb_data = "O" * 17
    rgb_data_encrypted = "O" * 32
    data = bytes_to_intlist(rgb_data)
    encrypted_data = aes_cbc_encrypt(data, bytes_to_intlist(rgb_key), bytes_to_intlist(rgb_iv))
    assert intlist_to_bytes(encrypted_data) == rgb_data_encrypted
    assert len(encrypted_data) == 32


# Generated at 2022-06-12 16:28:23.025731
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
          0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-12 16:28:35.168810
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('K7gNU3sdo+OL0wNhqoVWhr3g6s1xYv72ol/pe/Unols='))
    iv = bytes_to_intlist(compat_b64decode('i45FVt72rrmI1dMPHrLZCw=='))
    data = bytes_to_intlist(compat_b64decode('WISE-PaaS/RMM'))

    encrypted_data = aes_cbc_encrypt(data, key, iv)
    decrypted_data = aes_cbc_decrypt(encrypted_data, key, iv)

    assert data == decrypted_data



# Generated at 2022-06-12 16:28:43.658680
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode('gIaE0+DpyeJWEDjw0TGzPQ=='))
    iv = bytes_to_intlist(compat_b64decode('kWj8zwHKl+ZN/EZgutpugw=='))
    inp = bytes_to_intlist(compat_b64decode('VhKjZg4YqX4HFeQhOd7kSA=='))

    res = aes_cbc_encrypt(inp, key, iv)
    assert intlist_to_bytes(res) == compat_b64decode('B+1Z/bH3Xfh2guxuC7x5yw==')
    #print(res)
# ------------------------------------------------------------------------------


# Generated at 2022-06-12 16:28:56.790628
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
	data = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF]
	key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F]

# Generated at 2022-06-12 16:29:08.690272
# Unit test for function key_expansion
def test_key_expansion():
    data = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:29:21.627901
# Unit test for function key_expansion
def test_key_expansion():
    test_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:29:34.416186
# Unit test for function key_expansion

# Generated at 2022-06-12 16:29:44.491280
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\0' * 16)

# Generated at 2022-06-12 16:29:57.037420
# Unit test for function key_expansion

# Generated at 2022-06-12 16:30:03.203449
# Unit test for function key_expansion
def test_key_expansion():
    for key_size in [16, 24, 32]:
        for i in range(10):
            key = [0] * key_size
            for k in range(key_size):
                key[k] = i
            expanded = key_expansion(key)
            assert len(expanded) == (key_size // 4 + 7) * BLOCK_SIZE_BYTES

test_key_expansion()



# Generated at 2022-06-12 16:30:12.033967
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist('140b41b22a29beb4061bda66b6747e14')
    res = key_expansion(key)
    assert intlist_to_bytes(res) == compat_b64decode(
        b'f20bdba6ff29eed7b046d1df9fb7000058b1ffb4210a580f748b4ac714c001bd4a61044426fb515dad3f21f18aa577c0bdf302936266926ff37dbf7035d5eeb4')
    key = bytes_to_intlist('140b41b22a29beb4061bda66b6747e14f73104e48d9')
    res = key_expansion(key)
    assert intlist_to_bytes(res) == compat

# Generated at 2022-06-12 16:30:22.348073
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode(b'CbH7zZDf8oLnhSv50NQ2eQ=='))
    assert key_expansion(key) == bytes_to_intlist(compat_b64decode(b'YRi5BuXcXKjGDrYBFhCVZgRz1x2x56aO59q3qnvq0eLXIgGjKfrmHmKYFz1RZx1xQUNDZ5Aqoo3mETHMAyCuNjKgDv+Y1Q2eQ=='))



# Generated at 2022-06-12 16:30:32.406183
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(compat_b64decode(
        'JhEgRjogRjA0QTExQjg3MEJGQUZDRUIyQTI5QThGRkQ2NTFFQzM1OUJCRg=='))
    res = key_expansion(data)
    data = intlist_to_bytes(res)

# Generated at 2022-06-12 16:30:45.509725
# Unit test for function key_expansion
def test_key_expansion():
    key_128 = bytes_to_intlist(compat_b64decode('YKWpX8Mv7VuOE/Nk/7VZWw=='))
    assert bytes_to_intlist(compat_b64decode('q3Kj5QVa/+ePNjKwOwZ1DQOQ2YqLbB9cxMTAzFpA0Ao=')) == key_expansion(key_128)

    key_192 = bytes_to_intlist(compat_b64decode('6ZmI6I2j5Y+R5aSn5ZOlAA=='))

# Generated at 2022-06-12 16:30:54.299571
# Unit test for function key_expansion
def test_key_expansion():
    for key_size in [16, 24, 32]:
        for rnd in range(100):
            key = [0] * key_size
            for i in range(key_size):
                key[i] = (i + rnd) % 256

            expanded_key = key_expansion(key)
            decrypted_key = aes_decrypt(expanded_key, expanded_key)
            assert decrypted_key[:key_size] == key



# Generated at 2022-06-12 16:31:06.566376
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:13.987691
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    for size in [16, 24, 32]:
        assert len(key_expansion(key[:size])) == 176 if size == 16 else 208 if size == 24 else 240



# Generated at 2022-06-12 16:31:22.762488
# Unit test for function key_expansion
def test_key_expansion():
    decoded_key = compat_b64decode(b'NQ ==')
    plain = bytes_to_intlist(decoded_key)
    expanded = bytes_to_intlist(compat_b64decode(b'NQA = LwY = ONg = C04 = Eg == LwY = C04 = ONg = C04 = Eg == ONg = C04 = Eg == ONg = C04 = Eg == ONg = C04='))
    assert expanded == key_expansion(plain)
test_key_expansion()



# Generated at 2022-06-12 16:31:32.734277
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:45.702575
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:55.985135
# Unit test for function key_expansion
def test_key_expansion():
    # generated with: https://www.samiam.org/key-schedule.html

    def round_trip(key, expected_expanded_key):
        expanded_key = key_expansion(key)
        assert expected_expanded_key == expanded_key


# Generated at 2022-06-12 16:32:06.820920
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:11.089339
# Unit test for function key_expansion
def test_key_expansion():
    key_size_bytes = 32
    key = [0] * key_size_bytes
    data = [0] * key_size_bytes * 2
    expanded_key = key_expansion(data)
    assert(len(expanded_key) == 240)


# Generated at 2022-06-12 16:32:19.378737
# Unit test for function key_expansion
def test_key_expansion():
    key = [123, 217, 19, 11, 24, 26, 85, 45, 114, 184, 27, 162, 37, 112, 222, 209, 241, 24, 175, 144, 173, 53, 196,
           29, 24, 26, 17, 218, 131, 236, 53, 209]

    expanded_key = key_expansion(key)

# Generated at 2022-06-12 16:32:37.972286
# Unit test for function key_expansion
def test_key_expansion():
    # works only with keysize 16 byte
    key = [0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe, 0x2b, 0x73, 0xae, 0xf0, 0x85, 0x7d, 0x77, 0x81]

# Generated at 2022-06-12 16:32:45.524530
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:58.129156
# Unit test for function key_expansion
def test_key_expansion():
    TEST_KEY_EXPANSION_VECTOR_1 = bytes_to_intlist('\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')

# Generated at 2022-06-12 16:33:07.848014
# Unit test for function key_expansion

# Generated at 2022-06-12 16:33:19.696496
# Unit test for function key_expansion