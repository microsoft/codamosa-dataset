

# Generated at 2022-06-12 16:23:48.915031
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    COUNTER = FixedCounter(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    decrypted_data = aes_ctr_decrypt(
        bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')),
        bytes_to_intlist(compat_b64decode(b'YELLOW SUBMARINE')),
        COUNTER
    )

# Generated at 2022-06-12 16:23:57.440772
# Unit test for function key_expansion
def test_key_expansion():
    assert key_expansion(bytes_to_intlist(compat_b64decode('YNIkcVlgmGpfEtHE0iyB1Q=='))) == bytes_to_intlist(compat_b64decode('Ww0I2Q7Vu5r5OEfZaLCKe1EpckRE7ueTPiESt40SpN06bw=='))

# Generated at 2022-06-12 16:24:09.532540
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-12 16:24:19.252467
# Unit test for function aes_encrypt

# Generated at 2022-06-12 16:24:32.194312
# Unit test for function aes_decrypt
def test_aes_decrypt():
    res_list = []
    with open('../test/test_output.txt', 'r') as f:
        for line in f.readlines():
            res_list.append(int(line))
    i = 0    
    key = '1234567890abcdef'
    key = bytes_to_intlist(key.encode('utf-8'))
    key_expanded = key_expansion(key)

    for i in range(256):
        for j in range(256):
            for k in range(256):
                for l in range(256):
                    data = [i,j,k,l,5,6,7,8,1,2,3,4,2,2,2,2]
                    res = aes_decrypt(data, key_expanded)

# Generated at 2022-06-12 16:24:39.605814
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key_base64 = 'C8gMbtLZpN25ZTu8zPdDHQ=='
    iv_base64 = '8jKkUgLnx6j5U6JZUdpGMg=='
    ciphertext_base64 = 'JzF4p4LdC+RvMZB+GZb1Iy+j2WhJvzHWY3qLwjN0xEk='
    plaintext_expected_base64 = 'CBSTEJX0pDVy8/P0pFMDExOkhPTkU6Oj8/Pg=='

    key = compat_b64decode(key_base64)
    key = bytes_to_intlist(key)

    iv = compat_b64decode(iv_base64)

# Generated at 2022-06-12 16:24:51.747361
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    @returns {bool}  True iff test passed
    """
    # pylint: disable=unused-argument
    def next_value(*args):
        """
        Returns next counter block
        """
        temp = nonce
        nonce[-1] += 1
        return temp

    assert aes_decrypt_text('MTIzNDU2Nzg5MDEyMzQ1Ng', 'password', 16) == b'1234567890'
    assert aes_decrypt_text('MTIzNDU2Nzg5MDEyMzQ1Njc4OTAxMjM0NTY3ODkwMTIzNDU2', 'password', 24) == b'1234567890' * 3

# Generated at 2022-06-12 16:25:02.807058
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    import binascii

    cleartext = bytes_to_intlist(b'abcdefabcdefabcdefabcdefabcdefab')
    key = bytes_to_intlist(b'0123456789abcdef0123456789abcdef')
    iv = bytes_to_intlist(b'0123456789abcdef0123456789abcdef')
    expected_cipher = 'c9f5a5d60f5cbe8fc6f2d418bd1e3b91'

    cipher = aes_cbc_encrypt(cleartext, key, iv)
    assert binascii.hexlify(intlist_to_bytes(cipher)) == expected_cipher



# Generated at 2022-06-12 16:25:10.600150
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:25:22.091076
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode(b'U0h6Y0ZWUjZiU21ZMjBZbkx6WkU='))
    iv = bytes_to_intlist(compat_b64decode(b'Z0l4ZWtzVGlRc0R6Rk5YXzJPWGs='))
    encrypted = aes_cbc_encrypt([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15], key, iv)

# Generated at 2022-06-12 16:25:37.766284
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .crypto import Counter

    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    expanded_key = key_expansion(key)
    counter = Counter(
        num=5,
        inc=6,
        prefix=bytes_to_intlist(compat_b64decode('AAAAAAAAAAAAAA==')),
    )

    decrypted_data = aes_ctr_decrypt(data, expanded_key, counter)

# Generated at 2022-06-12 16:25:49.671517
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Example implementing AES-128 (Nk=4, Nr=10)
    # See FIPS-197 section 5.3
    test_data = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d,
                 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]
    test_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
                0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:25:57.075935
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    encrypted_data = 'CigQ43gNqjzq8EQxCSAvwU5Dn1ZZyNH8YeErWpzvnYnh6JeFZaPrsxg=='
    password = '0123456789abcdef'
    key_size_bytes = 16
    plaintext = "Live long and prosper"
    assert aes_decrypt_text(encrypted_data, password, key_size_bytes) == plaintext



# Generated at 2022-06-12 16:26:09.322621
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # reference: http://csrc.nist.gov/groups/STM/cavp/documents/aes/KAT_CBC.zip
    key = (0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c)
    iv = (0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
          0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f)

# Generated at 2022-06-12 16:26:14.710794
# Unit test for function inc
def test_inc():
    print(inc([0x23, 0x53, 0xD5]))
    print(inc([0x23, 0x53, 0xFF]))
    print(inc([0x23, 0xFF, 0xFF]))
    print(inc([0xFF, 0xFF, 0xFF]))


# Generated at 2022-06-12 16:26:18.980125
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = '1vHX/hWhc/x4f4wW8Nv7HbJzPnSVbSQ2Q8+vYXCHz4c='
    password = 'test'
    key_size_bytes = 16
    result = aes_decrypt_text(data, password, key_size_bytes)
    assert result == b"This is a test"

# Generated at 2022-06-12 16:26:32.072089
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """
    Test function aes_cbc_decrypt
    """
    # test data from http://www.inconteam.com/software-development/41-encryption/55-aes-test-vectors#aes-cbc-128
    # key: 0x2b7e151628aed2a6abf7158809cf4f3c
    # iv: 0x000102030405060708090a0b0c0d0e0f
    # cipher: 0x7649abac8119b246cee98e9b12e9197d5086cb9b507219ee95db113a917678b273bed6b8e3c1743b7116e69e22229516
    # plaintext: 0x6bc1bee22e409f96e93d7e

# Generated at 2022-06-12 16:26:43.100851
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .counter import Counter
    from .utils import bytes_to_intlist, intlist_to_bytes

    class TestCounter(Counter):
        def __init__(self):
            self.i = 0

        def next_value(self):
            v = [self.i % 256] * 16
            self.i += 1
            return v

    counter = TestCounter()

    data_list = "This is a test".encode('utf-8')
    data = bytes_to_intlist(data_list)
    key = [0] * 32
    decrypted_data = aes_ctr_decrypt(data, key, counter)
    decrypted_data_list = intlist_to_bytes(decrypted_data)
    assert decrypted_data_list == data_list

# Generated at 2022-06-12 16:26:50.893890
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    >>> data = "Z5MtiwxVtF+DtL8WYJy0v+p/NAN/Dby4/W4Xg/v/d0+eCy2Qr8YwfIyv+VI="
    >>> key = "test"
    >>> assert aes_decrypt_text(data, key, 32) == "test"
    """
    pass



# Generated at 2022-06-12 16:27:03.127696
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Known values
    # Input: "EnDwBiAoAA=="
    # Password: "star wars"
    # Key size: 128-Bit
    # Expected output: "test"
    result = aes_decrypt_text('EnDwBiAoAA==', 'star wars', 16)
    assert result == b'test'

    # Input: "DpvhB3qH+78rjKUkuhR33g=="
    # Password: "star wars"
    # Key size: 192-Bit
    # Expected output: "test"
    result = aes_decrypt_text('DpvhB3qH+78rjKUkuhR33g==', 'star wars', 24)
    assert result == b'test'

    # Input: "UWJ/Bx7bms

# Generated at 2022-06-12 16:27:13.177544
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
  '''
  Test script for aes decryption in CBC mode

  Test vectors are taken from:
    * http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    * https://www.cosic.esat.kuleuven.be/nessie/testvectors/bc/aes/AES-CBC.test-vectors
  '''
  # Test vector 1 of NIST publication 800-38a
  key_1 = bytes_to_intlist(compat_b64decode('gI0GAILBdu7T53akrFmMyT/Hqe+TiiyuxXUFfM4d0v8='))

# Generated at 2022-06-12 16:27:24.300864
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """
    Example from:
    http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    """

# Generated at 2022-06-12 16:27:36.018233
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:27:47.815222
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .aes_cbc import aes_cbc_encrypt
    from .aes_cbc import aes_cbc_decrypt
    from .key_expansion import key_expansion
    from .constants import AES_BLOCK_SIZE

    def int_pack(x):
        return list(bytes_to_intlist(x))

    def int_unpack(x):
        return intlist_to_bytes(x)

    def test_string(string):
        key = int_pack('YELLOW SUBMARINE')
        iv = int_pack('\x00' * AES_BLOCK_SIZE)
        string = int_pack(string)
        encrypted = aes_cbc_encrypt(string, key, iv)
        decrypted = aes_cbc_decrypt(encrypted, key, iv)

# Generated at 2022-06-12 16:27:56.341702
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():

    #test vectors taken from https://www.inconteam.com/software-development/41-encryption/55-aes-test-vectors

    # decryption
    # AES-CBC 128 Bit Key Decryption
    data = bytes_to_intlist("7649abac8119b246cee98e9b12e9197d")
    key = bytes_to_intlist("2b7e151628aed2a6abf7158809cf4f3c")
    iv  = bytes_to_intlist("000102030405060708090a0b0c0d0e0f")
    result = intlist_to_bytes(aes_cbc_decrypt(data, key, iv))
    assert result == b"6bc1bee22e409f96e93d7e117393172a"

# Generated at 2022-06-12 16:28:06.346468
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
        iv = bytes_to_intlist(compat_b64decode("oCmTrmawYz8K1MZ13j+Zwg=="))
        key = bytes_to_intlist(compat_b64decode("QWu807IxPd2Qn5C5wi5LIw=="))
        data = bytes_to_intlist(compat_b64decode("1310LKjt66cO+1stGt1yJg=="))
        assert aes_cbc_decrypt(data, key, iv) == bytes_to_intlist(b"foobar")


# Generated at 2022-06-12 16:28:17.056689
# Unit test for function aes_decrypt

# Generated at 2022-06-12 16:28:30.134917
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:28:40.857455
# Unit test for function aes_decrypt
def test_aes_decrypt():
    TEST_VECTORS = [
        ('c47b0294dbbbee0fec4757f22ffeee3587ca4730c3d33b691df38bab076bc558',
         '2b28627e2a270036a6f6f6d2a4300317',
         '601ec313775789a5b7a7f504bbf3d228'),
    ]

    for ciphertext_hex, key_hex, plaintext_hex in TEST_VECTORS:
        ciphertext = bytes_to_intlist(compat_b64decode(ciphertext_hex))
        key = bytes_to_intlist(compat_b64decode(key_hex))
        plaintext = bytes_to_intlist(compat_b64decode(plaintext_hex))
       

# Generated at 2022-06-12 16:28:50.521950
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = bytes_to_intlist('6bc1bee22e409f96e93d7e117393172a')
    key = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')
    expanded_key = key_expansion(key)
    decrypted_data = aes_decrypt(data, expanded_key)
    decrypted_data = intlist_to_bytes(decrypted_data)
    assert decrypted_data.hex() == '3ad77bb40d7a3660a89ecaf32466ef97'



# Generated at 2022-06-12 16:29:01.968039
# Unit test for function key_expansion
def test_key_expansion():
    data = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]
    data = bytes_to_intlist(compat_b64decode(b"U2FsdGVkX18YFVGw0DHo8Nvfz9/jK0Jp"))
    print(data)
    data = key_expansion(data)
    print(data)



# Generated at 2022-06-12 16:29:09.663818
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x60\x3d\xeb\x10\x15\xca\x71\xbe\x2b\x73\xae\xf0\x85\x7d\x77\x81')[:]
    expected_key = bytes_to_intlist(b'\x60\x3d\xeb\x10\x15\xca\x71\xbe\x2b\x73\xae\xf0\x85\x7d\x77\x81\x1f\x35\x2c\x07\x3b\x61\x08\xd7\x2d\x98\x10\xa3\x09\x14\xdf\xf4')
    expanded_key = key_expansion(key)


# Generated at 2022-06-12 16:29:22.530283
# Unit test for function key_expansion

# Generated at 2022-06-12 16:29:35.492583
# Unit test for function key_expansion
def test_key_expansion():
    def equality_test(key, expects):
        result = key_expansion(key)
        print(result)
        print(expects)
        assert result == expects
        print("Succeeded for %s" % key)


# Generated at 2022-06-12 16:29:43.346465
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]

# Generated at 2022-06-12 16:29:55.188823
# Unit test for function key_expansion

# Generated at 2022-06-12 16:30:05.840008
# Unit test for function key_expansion
def test_key_expansion():
    assert_array_equals(
        key_expansion(
            bytes_to_intlist(
                compat_b64decode(
                    'kCzvD3u4qQINuLtd/+iYMf0hQmvQTq52xD3i9zOMywM='))),
        bytes_to_intlist(
            compat_b64decode(
                'X6EVnnpBnKjHnTyiIMTFDiaFUQ5n5YHl0/zNl7lLg2P/o7P/6DIGU6N/uKjZU0/1+TmT'
                'XiuNIg==')))



# Generated at 2022-06-12 16:30:13.376555
# Unit test for function key_expansion
def test_key_expansion():
    #Test Key Size: 16 Byte
    key = bytes_to_intlist("2B7E151628AED2A6ABF7158809CF4F3C")
    result = key_expansion(key)

# Generated at 2022-06-12 16:30:22.522391
# Unit test for function key_expansion
def test_key_expansion():
    result = key_expansion(bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c'))
    expected = bytes_to_intlist(
        '2b7e151628aed2a6abf7158809cf4f3c739f1fa928768b95c2f38'
        'c259bb3d3c23adcceff785faa3f60d4bbd28e4c9dc9804b6931c7f'
    )
    assert result == expected

# Generated at 2022-06-12 16:30:27.139402
# Unit test for function key_expansion
def test_key_expansion():
    expected_key = bytes_to_intlist(compat_b64decode("""AQIDBAUGBwgJCgsMDQ4PEA=="""))
    expanded_key = key_expansion(bytes_to_intlist(b"AQIDBAUGBwgJCgsMDQ4PEA"))
    assert expected_key == expanded_key, "Result: {}".format(intlist_to_bytes(expanded_key))



# Generated at 2022-06-12 16:30:44.063745
# Unit test for function key_expansion
def test_key_expansion():
    key1 = bytes_to_intlist("000102030405060708090A0B0C0D0E0F")
    result1 = key_expansion(key1)

# Generated at 2022-06-12 16:30:54.223768
# Unit test for function key_expansion
def test_key_expansion():
    test_key_16 = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')
    test_key_24 = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c762e7160')
    test_key_32 = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da5')


# Generated at 2022-06-12 16:31:06.520363
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe, 0x2b, 0x73, 0xae, 0xf0, 0x85, 0x7d, 0x77, 0x81, 0x1f, 0x35, 0x2c, 0x07, 0x3b, 0x61, 0x08, 0xd7, 0x2d, 0x98, 0x10, 0xa3, 0x09, 0x14, 0xdf, 0xf4]

# Generated at 2022-06-12 16:31:18.079994
# Unit test for function key_expansion
def test_key_expansion():
    """
    Test the key_expansion function against the test vectors in
    http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    """
    for key_size_bytes in [16, 24, 32]:
        for i in range(1, 6):
            with open("test_vectors/AES_{}_KeyExpansion.txt".format(key_size_bytes * 8)) as f:
                for line in f:
                    data, expanded_key = line.split(' = ')
                    data = intlist_to_bytes(bytes_to_intlist(bytes(compat_b64decode(data))))
                    expanded_key = intlist_to_bytes(bytes_to_intlist(bytes(compat_b64decode(expanded_key))))

# Generated at 2022-06-12 16:31:30.153255
# Unit test for function key_expansion
def test_key_expansion():
    # reference http://en.wikipedia.org/wiki/Rijndael_key_schedule
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-12 16:31:41.860751
# Unit test for function key_expansion
def test_key_expansion():
    data = [0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe, 0x2b, 0x73, 0xae, 0xf0, 0x85, 0x7d, 0x77, 0x81,
            0x01, 0x35, 0x2c, 0x07, 0x3b, 0x61, 0x08, 0xd7, 0x2d, 0x98, 0x10, 0xa3, 0x09, 0x14, 0xdf, 0xf4]

# Generated at 2022-06-12 16:31:53.222598
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')

# Generated at 2022-06-12 16:31:59.077335
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist("000102030405060708090a0b0c0d0e0f")
    expanded_key = key_expansion(key)
    assert intlist_to_bytes(expanded_key) == compat_b64decode(
        b'AJyq3+BVoOt/hJ0Wpk8cZMYjXa+gF0Q2xDV7zKwfOF+V7njBc5sk5U6fZU9NbP/o'
    )



# Generated at 2022-06-12 16:32:11.004802
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('q83vBE5ZmF8o4zxkpS4jvP6umH4Zxjsm'))
    ret = key_expansion(key)

# Generated at 2022-06-12 16:32:19.287033
# Unit test for function key_expansion
def test_key_expansion():
    # 256-Bit
    key = (182, 230, 69, 195, 77, 77, 118, 246, 178, 201, 214, 165, 0, 81,
           134, 234)
    expanded_key = (182, 230, 69, 195, 77, 77, 118, 246, 178, 201, 214, 165, 0,
                    81, 134, 234, 167, 68, 77, 117, 192, 214, 252, 110, 241,
                    145, 198, 38, 112, 189, 64, 43, 40, 224, 85, 22, 203, 64,
                    85, 186, 128, 48, 230, 230, 127, 228, 71, 70, 13, 180,
                    182, 47, 78, 175, 196, 236, 223, 21, 7, 118, 205, 70, 149,
                    222, 171, 140, 164, 178, 72)

# Generated at 2022-06-12 16:32:37.890411
# Unit test for function key_expansion
def test_key_expansion():
    """Test for key expansion"""
    key1 = bytes_to_intlist(compat_b64decode('AQIDBAUGBwgJCgsMDQ4PEA=='))
    assert key_expansion(key1) == bytes_to_intlist(
        compat_b64decode(
            'AQIDBAUGBwgJCgsMDQ4PEA4QDhAOEBQUDhAOEBgUDhAOEBwUDhAOEBAYEBQgGBQYEBwgGBQgH'
            'CAcGBQgHCAgICAcGBQgHCAgICAgIDAgHCAgICAgICAQICAgICAgICAQICAgICAg'))

# Generated at 2022-06-12 16:32:42.951054
# Unit test for function key_expansion
def test_key_expansion():
    encrypted_data = bytes_to_intlist(compat_b64decode(b'YWJjZGVmZ2hpamtsbW5vcA=='))
    key = bytes_to_intlist(compat_b64decode(b'YWJjZGVmZ2hpamtsbW5vcGx3Y3c='))
    result = key_expansion(key)
    assert result == encrypted_data


# Generated at 2022-06-12 16:32:54.386244
# Unit test for function key_expansion
def test_key_expansion():
    # AES-128
    key = bytes_to_intlist(compat_b64decode(b'gI0GAILBdu7F3hMh+nr0zA=='))
    expanded_key = bytes_to_intlist(compat_b64decode(b'Guzc+/sNUTiezO/YsDeybZ+eVlO/NrNbBAaTfTUg7VU='))
    assert key_expansion(key) == expanded_key
    # AES-192
    key = bytes_to_intlist(compat_b64decode(b'eTZ+lDZag7TZG9P32nc7Hw=='))

# Generated at 2022-06-12 16:33:06.253586
# Unit test for function key_expansion

# Generated at 2022-06-12 16:33:18.448952
# Unit test for function key_expansion