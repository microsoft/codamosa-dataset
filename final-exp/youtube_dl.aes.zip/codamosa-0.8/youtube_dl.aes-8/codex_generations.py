

# Generated at 2022-06-12 16:23:29.935138
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    data = [0x87, 0x4d, 0x61, 0x91, 0xb6, 0x20, 0xe3, 0x26, 0x1b, 0xef, 0x68, 0x64, 0x99, 0x0d, 0xb6, 0xce]
    counter = Counter(0)

# Generated at 2022-06-12 16:23:34.416640
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # given
    data=b"aes_encrypt"
    aes_key=b"aes_key"
    # when
    enc=aes_encrypt(bytes_to_intlist(data),bytes_to_intlist(aes_key))
    # then

# Generated at 2022-06-12 16:23:44.973568
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # key = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    # iv = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    # data = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    key = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    iv = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

# Generated at 2022-06-12 16:23:53.888959
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # given
    dec_step = aes_decrypt
    key1 = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]

# Generated at 2022-06-12 16:24:02.800012
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(compat_b64decode("GawgguFyGrWKav7AX4VKUg"))
    cleartext = b"hello world1234"
    iv = bytes_to_intlist(compat_b64decode("6vfFByWvBkRyUvvk"))
    expected_cipher = compat_b64decode("XOe4Z4EQ+f8MViOLwO36Bk+U6aE=")
    assert intlist_to_bytes(aes_cbc_encrypt(bytes_to_intlist(cleartext), key, iv)) == expected_cipher



# Generated at 2022-06-12 16:24:13.728122
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = [
        0x32, 0x43, 0xf6, 0xa8,
        0x88, 0x5a, 0x30, 0x8d,
        0x31, 0x31, 0x98, 0xa2,
        0xe0, 0x37, 0x07, 0x34,
    ]
    expanded_key = [
        0x2b, 0x7e, 0x15, 0x16,
        0x28, 0xae, 0xd2, 0xa6,
        0xab, 0xf7, 0x15, 0x88,
        0x09, 0xcf, 0x4f, 0x3c,
    ] * (10 + 1)
    

# Generated at 2022-06-12 16:24:20.009276
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_cipher import aes_cipher
    assert aes_cipher(
        string_to_bytes(
            'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
        ),
        string_to_bytes('YELLOW SUBMARINE')) == \
        string_to_bytes('Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby ')

# ------------------------------------------------------------------------------


# Generated at 2022-06-12 16:24:29.191945
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    text = 'FgmtjKQPGFyNuVQ2CKbxuDzWBg0nwXuL7/ph/e3qr7rI0lKjHw+Dqh3tB4Fn53G9'
    password = 'hello world!'
    if aes_decrypt_text(text, password, 32) != b'hello world!':
        raise AssertionError("Unit test for 'aes_decrypt_text' failed.")



# Generated at 2022-06-12 16:24:39.958859
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test for aes_decrypt_text
    """
    import os
    import pickle

    data_file_path = os.path.join(os.path.dirname(__file__), '..', 'test', 'data', 'aes.pickle')
    with open(data_file_path, 'rb') as data_file:
        data = pickle.load(data_file)

    test_password = 'Pepper'
    assert intlist_to_bytes(sub_bytes(sub_bytes_inv(bytes_to_intlist(test_password.encode('utf-8'))))) == test_password.encode('utf-8')
    for test_data in data:
        test_data = dict(test_data)

# Generated at 2022-06-12 16:24:52.402076
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Example from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    key = bytes_to_intlist(compat_b64decode(
        b'GawgguFyGrWKav7AX4VKUg'))
    cipher = bytes_to_intlist(compat_b64decode(
        b'laK9cXBdnaTu4SdDeKnI'))
    counter = Counter(bytes_to_intlist(compat_b64decode(
        b'6u5yJATlRH5rL+VxxM9')))
    decrypted = intlist_to_bytes(
        aes_ctr_decrypt(cipher, key, counter))
    assert decrypted == b'Single block msg'

# Generated at 2022-06-12 16:25:08.163941
# Unit test for function aes_decrypt
def test_aes_decrypt():
    sample_data = '''KjT8EwT1iz3so6UHgu+Uye21yUc9YqKH'''
    sample_key = '''wKjA7fTX5+5CrsVyZe5pYehGJcAwxdO1'''
    sample_iv = '''4K0DzOdjJLrX+2uITt0xWA=='''

# Generated at 2022-06-12 16:25:19.309998
# Unit test for function aes_encrypt
def test_aes_encrypt():
    import os
    import random
    iv = [
        14, 3, 4, 15, 5, 10, 2, 8, 13, 0, 9, 6, 11, 1, 12, 7
    ]
    counter = Counter(iv)
    key = os.urandom(16)
    key = [ord(i) for i in key]
    data = os.urandom(random.randint(0, 100))
    data = [ord(i) for i in data]
    encrypted_1 = aes_ctr_encrypt(data, key, counter)
    expanded_key = key_expansion(key)
    encrypted_2 = aes_cbc_encrypt(data, key, expanded_key[:16])
    assert(encrypted_1 == encrypted_2)
if __name__ == "__main__":
    test_

# Generated at 2022-06-12 16:25:28.900035
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [0] * BLOCK_SIZE_BYTES
    expanded_key = [0] * BLOCK_SIZE_BYTES * (10 + 1)
    expected = [0x66, 0xe9, 0x4b, 0xd4, 0xef, 0x8a, 0x2c, 0x3b, 0x88, 0x4c, 0xfa, 0x59, 0xca, 0x34, 0x2b, 0x2e]
    actual = aes_encrypt(data, expanded_key)
    assert(expected == actual)

    data = [0] * BLOCK_SIZE_BYTES
    expanded_key = [0] * BLOCK_SIZE_BYTES * (12 + 1)

# Generated at 2022-06-12 16:25:40.921466
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, start=0):
            self.start = start

        def next_value(self):
            length = 16
            value = self.start
            self.start += 1
            return [0] * (length - len(hex(value)[2:])) + bytes_to_intlist(hex(value)[2:].encode('ascii'))

    data = bytes_to_intlist(b'Counter mode test')
    key = bytes_to_intlist(b'1234567890abcdef')

    counter = Counter(0)
    cipher = aes_ctr_decrypt(data, key, counter)
    assert intlist_to_bytes(cipher) == b'Counter mode test'

# Generated at 2022-06-12 16:25:49.907971
# Unit test for function aes_encrypt
def test_aes_encrypt():
    plain_text = bytes_to_intlist("abcdefghijklmnop")
    key = bytes_to_intlist("1234567890abcdef1234567890abcdef")
    encrypted_text = aes_encrypt(plain_text, key)
    if encrypted_text != [168, 90, 207, 70, 251, 47, 13, 109,
                          220, 19, 14, 68, 0, 84, 170, 144]:
        print("AES does not work correctly")
        sys.exit(1)
    print("Unit test for function aes_encrypt: passed!")



# Generated at 2022-06-12 16:25:57.133011
# Unit test for function key_expansion

# Generated at 2022-06-12 16:26:09.373826
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    data = [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10]

# Generated at 2022-06-12 16:26:19.128686
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    DATA = bytes_to_intlist(compat_b64decode(
        b"KDlTtXchhZTGufMYmOYGS4HffxPSUrfmqCHXaI9wOGY="))
    KEY = bytes_to_intlist(compat_b64decode(
        b"cf063aa1986011899a7c3b5a540a7ef483949524b2e92c6b4575a4ecfc4"))

# Generated at 2022-06-12 16:26:23.966183
# Unit test for function aes_encrypt
def test_aes_encrypt():
  data = bytes_to_intlist(b'\xab\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')

# Generated at 2022-06-12 16:26:32.708525
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_cipher import aes_ctr_decrypt
    key = bytes_to_intlist(b'1' * BLOCK_SIZE_BYTES)
    iv = bytes_to_intlist(b'2' * BLOCK_SIZE_BYTES)
    data = bytes_to_intlist(b'data')

    enc_data = aes_ctr_decrypt(data, key, IvCounter(iv))
    assert intlist_to_bytes(enc_data) == b'data'


# Generated at 2022-06-12 16:26:45.247264
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = '00112233445566778899AABBCCDDEEFF'
    data = bytes_to_intlist(data.decode('hex'))
    key = '000102030405060708090A0B0C0D0E0F'
    key = bytes_to_intlist(key.decode('hex'))
    iv = 'FEDCBA9876543210'
    iv = bytes_to_intlist(iv.decode('hex'))
    res = aes_cbc_encrypt(data, key, iv)
    assert res == [
        251, 54, 137, 51, 197, 232, 144, 179, 70, 202,
        6, 52, 207, 170, 119, 146,
    ], res


# Generated at 2022-06-12 16:26:58.523126
# Unit test for function aes_decrypt
def test_aes_decrypt():
    def hex_to_intlist(s):
        return list(bytearray.fromhex(s))

    def intlist_to_hex(l):
        return ''.join(format(x, '02x') for x in l)

    def encrypt_and_decrypt(expected_hex, key_hex, iv_hex):
        key = hex_to_intlist(key_hex)
        expected = hex_to_intlist(expected_hex)
        encrypted = aes_cbc_encrypt(expected, key, hex_to_intlist(iv_hex))
        decrypted = aes_cbc_decrypt(encrypted, key, hex_to_intlist(iv_hex))
        assert expected == decrypted
        assert expected_hex == intlist_to_hex(decrypted)

    # Encryption and decryption

# Generated at 2022-06-12 16:27:08.078767
# Unit test for function key_expansion

# Generated at 2022-06-12 16:27:12.978707
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:27:24.228750
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    counter = Counter(0x1234, BLOCK_SIZE_BYTES)
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    encrypted_data = aes_ctr_decrypt(data, key, counter)
    assert encrypted_data == [0x1e, 0xbc, 0x7a, 0xcc, 0x52, 0x46, 0xee, 0x92, 0xe7, 0xaa, 0x9b, 0xa0, 0x70, 0x1c, 0x26, 0x0e]


# Generated at 2022-06-12 16:27:31.272208
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = bytes_to_intlist('abcdefghijklmnop')
    key = bytes_to_intlist('adfasdfadsasdftwertwertwertwertwe')
    cipher = bytes_to_intlist('9f18b6a1b6d8143040e7e7c75b36f7b8')
    assert aes_cbc_decrypt(cipher, key, iv) == bytes_to_intlist('hello world')



# Generated at 2022-06-12 16:27:36.214802
# Unit test for function inc
def test_inc():
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]
    assert inc([255, 255, 255, 254]) == [255, 255, 255, 255]
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]


# Generated at 2022-06-12 16:27:48.041843
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    print('Testing function aes_cbc_encrypt')
    from .utils import to_bytes
    from .compat import compat_b64decode
    import base64

    key = [137,80,78,71,13,10,26,10,0,0,0,13,73,72,68,82]
    iv = [99,124,119,123,242,107,111,197,48,1,103,43,254,215,171,118]

# Generated at 2022-06-12 16:27:56.488843
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:28:08.841314
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # This is from the test vectors of section A.1 of
    # http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    key = bytes_to_intlist("2b7e151628aed2a6abf7158809cf4f3c")
    iv = bytes_to_intlist("000102030405060708090a0b0c0d0e0f")

# Generated at 2022-06-12 16:28:22.469058
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-12 16:28:35.481436
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    from .common import get_data

    data = get_data('test/test_aes_decrypt_text/1/data.b64')
    password = get_data('test/test_aes_decrypt_text/1/password-utf8.bin')
    expected_plaintext = get_data('test/test_aes_decrypt_text/1/plaintext-utf8.bin')
    key_size_bytes = 16

    plaintext = aes_decrypt_text(data, password, key_size_bytes)

    assert plaintext == expected_plaintext


    data = get_data('test/test_aes_decrypt_text/2/data.b64')
    password = get_data('test/test_aes_decrypt_text/2/password-utf8.bin')
    expected

# Generated at 2022-06-12 16:28:43.835743
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-12 16:28:56.949081
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    plaintext1 = [
                0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
                0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff
                ]

# Generated at 2022-06-12 16:29:06.799597
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    print("testing aes_ctr_decrypt")

# Generated at 2022-06-12 16:29:19.277845
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class TestCounter:
        def __init__(self, value):
            self.value = value

        def next_value(self):
            value = self.value
            self.value = [self.value[i] + 1 if i == len(self.value) - 1 else self.value[i] for i in range(len(self.value))]
            return value


    class TestCase():
        def __init__(self, key, iv, ciphertext, plaintext):
            self.key = bytes_to_intlist(compat_b64decode(key))
            self.iv = bytes_to_intlist(compat_b64decode(iv))
            self.ciphertext = bytes_to_intlist(compat_b64decode(ciphertext))
            self.plaintext = bytes_to_int

# Generated at 2022-06-12 16:29:26.829573
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    from base64 import b64encode
    from .aes import aes_encrypt_text

    clear = b64encode(b"Example")
    password = "s3cr3t!"
    key_size_bytes = 32

    encrypted = aes_encrypt_text(clear, password, key_size_bytes)
    decrypted = aes_decrypt_text(encrypted, password, key_size_bytes)

    assert (decrypted == b"Example")



# Generated at 2022-06-12 16:29:38.173892
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    password = "qwertz"
    key_size_bytes = 16
    result = b"""
<script>alert('XSS');</script><noscript>(XSS)</noscript>
<script>alert('XSS');</script><noscript>(XSS)</noscript>
<script>alert('XSS');</script><noscript>(XSS)</noscript>
"""
    assert aes_decrypt_text("ci+wViRJNOovr64o+lk3ug==", password, key_size_bytes) == result
    assert aes_decrypt_text("ci+wViRJNOovr64o+lk3ug==", password.encode('utf-8'), key_size_bytes) == result



# Generated at 2022-06-12 16:29:47.154085
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = b'\x32\x43\xf6\xa8\x88\x5a\x30\x8d\x31\x31\x98\xa2\xe0\x37\x07\x34'
    key = b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c'
    iv = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'


# Generated at 2022-06-12 16:29:59.355050
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Taken from https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38a.pdf
    import binascii
    data = b'Two One Nine Two'
    key = b'0f1571c947d9e8590cb7add6afe798'.decode('hex')
    iv = b'00000000000000000000000000000000'.decode('hex')

    result = aes_cbc_encrypt(bytes_to_intlist(data), bytes_to_intlist(key), bytes_to_intlist(iv))
    expected = b'7bdb6e3b432667eb06f4d14bff2fbd0f'.decode('hex')

    assert intlist_to_bytes(result) == expected


# Generated at 2022-06-12 16:30:47.682375
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4]
    iv = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    data = [1, 2, 3]

    result_data = aes_cbc_encrypt(data, key, iv)


# Generated at 2022-06-12 16:30:50.429901
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    cleartext = b'1234567890123456'
    # cleartext = b'123456789012345'

    assert aes_cbc_encrypt(cleartext, b'1234567890123456', b'1234567890123456') == b'\xf1\x63>\x88\x8d\xe6\xb2\x9c\x1b\x90\xfb\xca\x38\x84\x92\x85\xd2'



# Generated at 2022-06-12 16:31:02.312047
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    iv = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    data = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07')
    print(data)
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    decrypted_data = aes_cbc_decrypt(encrypted_data, key, iv)
    assert decrypted_data == data


# Generated at 2022-06-12 16:31:14.079930
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from .aes_decrypt import aes_cbc_decrypt
    from .utils import bytes_to_intlist, intlist_to_bytes

    cleartext = "Hello world. This is a top secret message."
    cleartext = bytes_to_intlist(cleartext.encode('utf-8'))
    key = bytes_to_intlist(compat_b64decode('vzKWZpJxHq3d+JYgvyrkKg=='))
    iv = bytes_to_intlist(compat_b64decode('9XpjYkA8Jn1w+//FuzI7+A=='))

    encrypted = aes_cbc_encrypt(cleartext, key, iv)

# Generated at 2022-06-12 16:31:23.503373
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = '140b41b22a29beb4061bda66b6747e14'.decode('hex')
    iv = '4ca00ff4c898d61e1edbf1800618fb28'.decode('hex')
    data = '28ae22c775a4fae3'.decode('hex')
    encrypted_data = 'af5a5a5c5fb5e593960d5b068d80579a'.decode('hex')
    assert aes_cbc_encrypt(data, key, iv) == encrypted_data


# Generated at 2022-06-12 16:31:29.511579
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    import codecs
    assert aes_cbc_encrypt(bytes_to_intlist(b'Hello World!'), bytes_to_intlist(b'YELLOW SUBMARINE'), bytes_to_intlist(b'sixteen byte key')) == bytes_to_intlist(codecs.decode('9db20490e8b6e38dafcab1aa2a1b0c2e', 'hex'))



# Generated at 2022-06-12 16:31:36.402470
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():

    test_data = (
        ("6bc1bee22e409f96e93d7e117393172a", "ae2d8a571e03ac9c9eb76fac45af8e51", "30c81c46a35ce411e5fbc1191a0a52ef"),
        ("ae2d8a571e03ac9c9eb76fac45af8e51", "30c81c46a35ce411e5fbc1191a0a52ef", "f69f2445df4f9b17ad2b417be66c3710"),
    )

    for cleartext, key_b64, ciphertext_b64 in test_data:
        key = bytes_to_intlist(compat_b64decode(key_b64))
        iv = [0] * 16


# Generated at 2022-06-12 16:31:48.070765
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    iv = [118,72,69,119,82,52,60,23,84,129,65,117,133,127,4,60]
    key = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31]

# Generated at 2022-06-12 16:31:56.447856
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist("1a1f1d8d1847244a9ad87b787c7e0f8a")
    iv = bytes_to_intlist("e53d8c89b2a9f02c")
    cleartext = bytes_to_intlist("b93e96eff6a8ac6d35")
    encrypted = aes_cbc_encrypt(cleartext, key, iv)
    assert intlist_to_bytes(encrypted) == compat_b64decode("Lmba+FxH2eCRPwuc6PjU6g==")

# Generated at 2022-06-12 16:32:07.821876
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test vector 1
    cleartext = 'Single block msg'
    clearkey = 'This is a key123'
    iv = '000102030405060708090a0b0c0d0e0f'
    cleartext_bytes = intlist_to_bytes(bytes_to_intlist(cleartext))
    key_bytes = intlist_to_bytes(bytes_to_intlist(clearkey))
    iv_bytes = intlist_to_bytes(bytes_to_intlist(iv))
    encrypted_data = aes_cbc_encrypt(bytes_to_intlist(cleartext_bytes),
                                     bytes_to_intlist(key_bytes),
                                     bytes_to_intlist(iv_bytes))

# Generated at 2022-06-12 16:32:18.063587
# Unit test for function key_expansion
def test_key_expansion():
    import binascii
    key = bytes_to_intlist(bytearray(b'\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f\x10'))

# Generated at 2022-06-12 16:32:30.177533
# Unit test for function key_expansion
def test_key_expansion():
    result = key_expansion(compat_b64decode('1KrObqw3qg2mVbztFwmR9g=='))
    reference = bytes_to_intlist(compat_b64decode('1KrObqw3qg2mVbztFwmR9uCHYI2V7EuKjA1ft7hJGtH+MzjKxACD5Z5Y5YiFjrDwHq3Qe'))
    assert(result == reference)

    result = key_expansion(compat_b64decode('W8oqy/oNgM0vVDXsnxOf8HZlNUk/jYUv'))

# Generated at 2022-06-12 16:32:40.937820
# Unit test for function key_expansion
def test_key_expansion():
    data = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:32:52.772856
# Unit test for function key_expansion
def test_key_expansion():
    # Test vector 1: 128-bit key
    data = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:33:05.135136
# Unit test for function key_expansion

# Generated at 2022-06-12 16:33:17.404782
# Unit test for function key_expansion
def test_key_expansion():
    # 16-Byte key
    key = [43, 126, 21, 22, 40, 174, 210, 166, 171, 247, 21, 136, 9, 207, 79, 60]