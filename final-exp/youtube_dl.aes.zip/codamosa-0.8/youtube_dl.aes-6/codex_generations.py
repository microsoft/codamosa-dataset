

# Generated at 2022-06-12 16:23:51.748727
# Unit test for function aes_decrypt
def test_aes_decrypt():
    
    # test for 128 byte key
    res = aes_decrypt(bytes_to_intlist("0x69c4e0d86a7b0430d8cdb78070b4c55a"), bytes_to_intlist("0x000102030405060708090a0b0c0d0e0f"), 4)
    assert intlist_to_bytes(res) == b"\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff"

    # test for 192 byte key

# Generated at 2022-06-12 16:23:59.458514
# Unit test for function aes_decrypt
def test_aes_decrypt():
    """
    Test case from
    https://www.informatik.htw-dresden.de/~beck/AES/source.html
    """
    test_data = [0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0x07, 0xa8, 0x8d, 0xa2, 0x34]
    test_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:24:11.548670
# Unit test for function aes_decrypt
def test_aes_decrypt():
    nist_key = bytes_to_intlist(compat_b64decode(b"k6AjyIY5U6nQFcLeh4uB7HHZ4oze0l2xCAtS+u8oInY="))
    nist_cipher = bytes_to_intlist(compat_b64decode(b"0D2hGuXjt1s0RKsN/pzZTgH/MI3qVgEk"))
    nist_expanded_key = key_expansion(nist_key)
    nist_decrypted_data = bytes_to_intlist(compat_b64decode(b"A test vector"))

# Generated at 2022-06-12 16:24:20.350797
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    print('Testing aes_cbc_decrypt...')
    key = [0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe, 0x2b, 0x73, 0xae, 0xf0, 0x85, 0x7d, 0x77, 0x81, 0x1f, 0x35, 0x2c, 0x07, 0x3b, 0x61, 0x08, 0xd7, 0x2d, 0x98, 0x10, 0xa3, 0x09, 0x14, 0xdf, 0xf4]

# Generated at 2022-06-12 16:24:33.316158
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, start_value=0):
            self._value = start_value

        def next_value(self):
            self._value += 1
            return intlist_to_bytes(self._value, BLOCK_SIZE_BYTES)

    data = 'a' * 40
    key = b'YELLOW SUBMARINE'
    ciphertext = bytes_to_intlist(b'\x1a_\xaa\x05\xd7\xca\x13z\x84\x01\x1a\x9f\xaa\x05\x05\xd7\xca\x13\xaa\x05\xd7\xca\x13\xaa\x05\xd7\xca\x13')
    counter = Counter()
    assert a

# Generated at 2022-06-12 16:24:40.337883
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class IncrementingCounter:
        def __init__(self, initial_value=0):
            self.initial_value = initial_value

        def next_value(self):
            self.initial_value += 1
            return intlist_to_bytes(self.initial_value)[-16:]

    aes_ctr_decrypt(
        data=bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')),
        key=bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE')),
        counter=IncrementingCounter(0)
    ) == bytes_to_intlist

# Generated at 2022-06-12 16:24:44.284029
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    plaintext = u'Hallo, Welt!'.encode('utf-8')
    password = 'Testpassword1234'
    key_size_bytes = 16  # 128-Bit

    data = aes_encrypt_text(plaintext, password, key_size_bytes)
    assert aes_decrypt_text(data, password, key_size_bytes) == plaintext



# Generated at 2022-06-12 16:24:52.608917
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    password = b'passw0rd'
    password_key_size_bytes = 24
    text = b'RmFzdCBhcyBmZWVkYmFjayBhcyBzb29uIGFzIHlvdSBjYW4hCg=='
    decrypted_text = aes_decrypt_text(text, password, password_key_size_bytes)
    assert decrypted_text == b'As fast as feedback as soon as you can!\n'



# Generated at 2022-06-12 16:24:57.951125
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = '0'.join([chr(i) for i in range(0,32)])
    data = "1234567890123456"
    iv = [0]*16
    cipher = aes_cbc_encrypt(bytes_to_intlist(str.encode(data)), bytes_to_intlist(str.encode(key)), iv)
    cipher_bytes = intlist_to_bytes(cipher)
    assert str(cipher_bytes, 'utf-8') == "1234567890123456\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10\x10"
    return True


# Generated at 2022-06-12 16:25:04.814782
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    ZERO_BYTE_STRING = bytes_to_intlist(b'\x00' * 100)
    AES_KEY = bytes_to_intlist(b'Sixteen byte key')
    KEY_SIZE_BYTES = len(AES_KEY)
    KEY_EXPANDED = key_expansion(AES_KEY)

    DECRYPTED_DATA = aes_ctr_decrypt(ZERO_BYTE_STRING, KEY_EXPANDED, Counter(ZERO_BYTE_STRING))
    ENCRYPTED_DATA = aes_encrypt_text(DECRYPTED_DATA, AES_KEY, KEY_SIZE_BYTES)

    plaintext = aes_decrypt_text(ENCRYPTED_DATA, AES_KEY, KEY_SIZE_BYTES)
    assert plaintext

# Generated at 2022-06-12 16:25:14.554560
# Unit test for function inc
def test_inc():
    data = [0, 0, 0, 0]
    inc(data)
    assert data == [0, 0, 0, 1], hex(data[0]) + " " + hex(data[1]) + " " + hex(data[2]) + " " + hex(data[3])
    data = [0, 0, 0, 255]
    inc(data)
    assert data == [0, 0, 1, 0], hex(data[0]) + " " + hex(data[1]) + " " + hex(data[2]) + " " + hex(data[3])
    data = [0, 0, 255, 255]
    inc(data)
    assert data == [0, 1, 0, 0], hex(data[0]) + " " + hex(data[1]) + " " + hex(data[2]) + " "

# Generated at 2022-06-12 16:25:24.886160
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text('1zgHZc9bEKYCgKfvS/W5Iw==', 'password', 16) == b'hello world'
    assert aes_decrypt_text('1vq3Wq7V0ybYQShmVJvzG0m0pCfzI+ZJ7vC8q3WV7oE=', 'password', 24) == b'hello world'
    assert aes_decrypt_text('1vq3Wq7V0ybyYcAo4F4x2l+9XCtHCLI+/vM8rCQO7dw=', 'password', 32) == b'hello world'



# Generated at 2022-06-12 16:25:29.198700
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    password = 'password'
    key_size_bytes = 16
    data = 'mT1TROriSyT3qWRYszsZlg=='
    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    assert plaintext == 'This is a test password.'



# Generated at 2022-06-12 16:25:41.601761
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import binascii
    from .counter import Counter

    # long_vid
    cipher_text = 'MZTfTj1OiW2V8eUx+H1w7sE6bqU6oXZpLT4C+oY4Y4k='
    cipher_text = compat_b64decode(cipher_text)
    key = '7cee6cca60e888d2'
    key = bytes_to_intlist(key)
    expected_plain_text = '{\n  "playbackUrl": "https://r1---sn-4g57knlz.googlevideo.com/videoplayback?itag=22&source=youtube&ei=Kw5PWce5D5bO1wKDk5-wCg&i...'
    expected_

# Generated at 2022-06-12 16:25:45.359610
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = list(range(32))
    iv = list(range(16))
    cleartext = list(range(20))
    cipher = aes_cbc_encrypt(cleartext, key, iv)



# Generated at 2022-06-12 16:25:54.616613
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    results = []
    msg = b"0123456789ABCDEFFEDCBA9876543210"
    key = b"0F62B5085BAE0154A7FA4DA0F34699EC"
    iv = b"3DAFBA458BF87BC2F53AE13C"
    decrypted_cbc_data = aes_cbc_encrypt(bytes_to_intlist(msg),
                                         bytes_to_intlist(key),
                                         bytes_to_intlist(iv))
    encrypted_cbc_data = 'd1daa78208f9b8a622cd6b815d50f11e6295b0643867aa6d355'

# Generated at 2022-06-12 16:26:07.004833
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = [207, 210, 189, 221, 78, 21, 195, 94, 239, 119, 141, 146, 91, 188, 128, 169]
    key = [148, 95, 224, 177, 138, 74, 160, 160, 83, 208, 77, 144, 89, 250, 136, 176,
        5, 30, 46, 250, 89, 243, 13, 142, 116, 9, 46, 209, 213, 140, 211, 94]

# Generated at 2022-06-12 16:26:08.337659
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 16:26:18.664617
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    print("TEST AES CBC ENCRYPT")
    key = bytes_to_intlist(compat_b64decode("CQ1dk+tDk0yjJFy1/xvX9oHyP+CiYcYdYj0k+JOwqb8="))
    iv = bytes_to_intlist(compat_b64decode("YjYEn/m+qw8b2Hr5njMK5Q=="))

# Generated at 2022-06-12 16:26:32.028831
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .test_vectors import aes_test_vectors
    from .test_vectors import aes_ctr_test_vectors

    # Unit test test vector from https://en.wikipedia.org/wiki/Block_cipher_mode_of_operation#Counter_.28CTR.29
    counter = Counter.new(bytes_to_intlist(b"\x00\x00\x00\x00\x00\x00\x00\x00"))
    key = bytes_to_intlist(b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00")

# Generated at 2022-06-12 16:26:44.741858
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = intlist_to_bytes([1, 4, 45, 32, 75, 6, 8, 1, 9, 5, 4, 7, 9, 6, 2, 3])
    iv = intlist_to_bytes([65, 12, 1, 57, 83, 43, 89, 9, 5, 4, 67, 9, 6, 2, 3, 9])
    cipher = intlist_to_bytes([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])
    decrypted_data = aes_cbc_decrypt(cipher, key, iv)

# Generated at 2022-06-12 16:26:57.812116
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    test_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    test_iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-12 16:27:07.807702
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:27:20.620642
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test 1
    key = "140b41b22a29beb4061bda66b6747e14"
    expanded_key = ("8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b"
                    "70f9db3002b49e6c939b1e10b1e7af44ee7dbdffe7fb770b"
                    "0d3a2aa5")
    data = "4ca00ff4c898d61e1edbf1800618fb28"
    expanded_key_decoded = []
    for i in range(0, len(expanded_key), 2):
        expanded_key_decoded.append(int(expanded_key[i:i + 2], 16))
    data_dec

# Generated at 2022-06-12 16:27:27.845850
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytes_to_intlist(b'\xCA\xA9\x9E\xE8\xB3\xF3\x94\xFA\xCE\x3B\xD0\x56\xCC\xD6\xAC\xE7')
    key = bytes_to_intlist(b'\x6C\x6C\x6C\x6C\x6C\x6C\x6C\x6C\x6C\x6C\x6C\x6C\x6C\x6C\x6C\x6C')

# Generated at 2022-06-12 16:27:40.126190
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    def aes_cbc_decrypt_to_intlist(data, key, iv):
        return bytes_to_intlist(aes_cbc_decrypt(bytes_to_intlist(data), bytes_to_intlist(key), bytes_to_intlist(iv)))

# Generated at 2022-06-12 16:27:51.170748
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist('140b41b22a29beb4061bda66b6747e14')
    iv = bytes_to_intlist('4ca00ff4c898d61e1edbf1800618fb28')
    data = bytes_to_intlist('28a226d160dad07883d04e008a7897ee'
                            '2e4b7465d5290d0c0e6c6822236e1daa'
                            'fb94ffe0c5da05d9476be028ad7c1d81')
    result = aes_cbc_decrypt(data, key, iv)

# Generated at 2022-06-12 16:27:59.627442
# Unit test for function aes_decrypt
def test_aes_decrypt():
    encrypted_data = compat_b64decode("/w1+bqlmfNtJXD3KjBvQAQ==")
    key = compat_b64decode("mE4Z1I4Z6X0U6sv+UumCYh0Mhj0xq3gLsNS2hmUbOjI=")
    iv = compat_b64decode("TGJyEuV8e+1ZJDwB7jKHQw==")
    expanded_key = key_expansion(key)
    data = aes_cbc_decrypt(encrypted_data, key, iv)
    print(data)


# Generated at 2022-06-12 16:28:12.408585
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # from https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38a.pdf
    # Appendix F.1.1 AES-128 Algorithm Example (p. 54)
    cipher = [0x69, 0xc4, 0xe0, 0xd8, 0x6a, 0x7b, 0x04, 0x30, 0xd8, 0xcd, 0xb7, 0x80, 0x70, 0xb4, 0xc5, 0x5a]

# Generated at 2022-06-12 16:28:21.210359
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(
        compat_b64decode('dGhlIHNhbXBsZSBub25jZQ=='))
    iv = bytes_to_intlist(compat_b64decode('YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4'))
    cipher = bytes_to_intlist(
        compat_b64decode('d2J2X3Rva1RV+nH58YjYzgIB8nJ2QV7PkOFjmEZ7HE8orrv4u5d6ErYHO6b5'))

# Generated at 2022-06-12 16:28:36.502944
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c'
                     'f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0')

# Generated at 2022-06-12 16:28:44.387993
# Unit test for function key_expansion
def test_key_expansion():
    # see: https://en.wikipedia.org/wiki/Rijndael_key_schedule
    key = [0x2b, 0x7e, 0x15, 0x16,
           0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88,
           0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:28:51.383907
# Unit test for function key_expansion
def test_key_expansion():
    for key_size_bytes in [16, 24, 32]:
        key = intlist_to_bytes(range(1, key_size_bytes + 1))
        expanded_key = key_expansion(bytes_to_intlist(key))
        assert len(expanded_key) == 240 if key_size_bytes == 32 else 208 if key_size_bytes == 24 else 176



# Generated at 2022-06-12 16:29:02.814666
# Unit test for function key_expansion

# Generated at 2022-06-12 16:29:10.093393
# Unit test for function key_expansion
def test_key_expansion():
    import random
    for _ in range(1):
        num = random.randint(0,3)
        if num == 0:
            key = [random.randint(0,255) for _ in range(16)]
        if num == 1:
            key = [random.randint(0,255) for _ in range(24)]
        if num == 2:
            key = [random.randint(0,255) for _ in range(32)]
        print('key:', key)
        
        reversed_key = []
        for i in range(len(key)//4):
            reversed_key += key[i*4:(i+1)*4][::-1]
        print('reversed:', reversed_key)
        reversed_key_expanded = key_expansion(reversed_key)
        print

# Generated at 2022-06-12 16:29:22.930184
# Unit test for function key_expansion
def test_key_expansion():
    first_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:29:35.911889
# Unit test for function key_expansion
def test_key_expansion():
    """
    Test key_expansion
    """

# Generated at 2022-06-12 16:29:43.546047
# Unit test for function key_expansion
def test_key_expansion():
    import unittest

    # Test vectors (from http://csrc.nist.gov/archive/aes/rijndael/rijndael-vals.zip)

# Generated at 2022-06-12 16:29:55.775877
# Unit test for function key_expansion

# Generated at 2022-06-12 16:30:07.183544
# Unit test for function key_expansion

# Generated at 2022-06-12 16:30:21.900737
# Unit test for function key_expansion
def test_key_expansion():
    with open('aes_key_expansion_test_data.txt', 'r') as lf:
        for line in lf:
            if line[0] == '#':
                continue

            comment, key, expected_key_expansion, expected_rcon_iters = line.rstrip('\r\n\t ').split('|')
            key = bytes_to_intlist(compat_b64decode(key))
            expected_key_expansion = bytes_to_intlist(compat_b64decode(expected_key_expansion))
            expected_rcon_iters = int(expected_rcon_iters, 16)

            expanded_key = key_expansion(key)
            if expanded_key != expected_key_expansion:
                print(expanded_key)

# Generated at 2022-06-12 16:30:31.778511
# Unit test for function key_expansion
def test_key_expansion():
    input_data = bytes_to_intlist(compat_b64decode('wSNBgkoMu3kC3csC9AQFXA=='))

# Generated at 2022-06-12 16:30:44.883938
# Unit test for function key_expansion
def test_key_expansion():
    # Test 1, from FIPS-197 Appendix A
    test_input = bytes_to_intlist(compat_b64decode('gRVgNtGGxT7Vu8cIh/nzKA=='))
    expected_output = bytes_to_intlist(compat_b64decode('kEJG++I+7ArxTUTj0pzOuFyDIIeMKN9G+J71kCdQ+ynwbeGO1x0xmo5o5Ue+YU6Jj1n9mUZVTmU=\n'))
    assert(key_expansion(test_input) == expected_output)

    # Test 2, from http://www.inconteam.com/software-development/41-encryption/55-aes-test-vectors


# Generated at 2022-06-12 16:30:54.638919
# Unit test for function key_expansion
def test_key_expansion():
    test_key = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F'

# Generated at 2022-06-12 16:31:06.931539
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:18.569745
# Unit test for function key_expansion
def test_key_expansion():
    def _test(key, expected):
        expanded_key = key_expansion(key)
        assert expanded_key == expected, (key, expanded_key, expected)


# Generated at 2022-06-12 16:31:26.127984
# Unit test for function key_expansion
def test_key_expansion():
    data = [0] * 16
    expanded_key = key_expansion(data)
    assert len(expanded_key) == 176

    data = [0] * 24
    expanded_key = key_expansion(data)
    assert len(expanded_key) == 208

    data = [0] * 32
    expanded_key = key_expansion(data)
    assert len(expanded_key) == 240



# Generated at 2022-06-12 16:31:34.691961
# Unit test for function key_expansion
def test_key_expansion():

    # Test cases for AES 128
    data = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]

# Generated at 2022-06-12 16:31:46.944546
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:57.080195
# Unit test for function key_expansion
def test_key_expansion():
  # 128 bit test key
  key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:32:11.676258
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('LD8rbiHZzWsVr+ClTv9rs61MY1Q='))
    expected_key = bytes_to_intlist(compat_b64decode('LD8rbiHZzWsVr+ClTv9rs61MY1Q=N/N/Ow8tfD0l6i1yHjKp0UxX6UgY='))
    expanded_key = key_expansion(key)
    assert expanded_key == expected_key
# End unit test for function key_expansion



# Generated at 2022-06-12 16:32:19.919228
# Unit test for function key_expansion
def test_key_expansion():
    K = bytes_to_intlist(compat_b64decode('Mk9m98IfEblQHVdKFjq3dA=='))
    res = bytes_to_intlist(compat_b64decode('Mk9m98IfEblQHVdKFjq3dJVi3q3qN/e+lOjI/yDxodwB2Y1Y/f4g4XZGkH/bmppb0FYRJWduMxROxD1teQopIYg=='))
    for x, y in zip(key_expansion(K), res):
        if x != y:
            print('key_expansion test_key_expansion failed')
# End unit test


# Generated at 2022-06-12 16:32:32.416972
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:42.680891
# Unit test for function key_expansion
def test_key_expansion():
    # AES
    test_aes_128 = 0x2b7e151628aed2a6abf7158809cf4f3c
    test_aes_192 = 0x8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b
    test_aes_256 = 0x603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4

# Generated at 2022-06-12 16:32:54.097615
# Unit test for function key_expansion

# Generated at 2022-06-12 16:33:06.099279
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b,0x7e,0x15,0x16,0x28,0xae,0xd2,0xa6,0xab,0xf7,0x15,0x88,0x09,0xcf,0x4f,0x3c]

# Generated at 2022-06-12 16:33:18.368964
# Unit test for function key_expansion
def test_key_expansion():
    key_16_bytes = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    key_24_bytes = [0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5, 0x62, 0xf8, 0xea, 0xd2, 0x52, 0x2c, 0x6b, 0x7b]