

# Generated at 2022-06-12 16:23:55.632874
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
          0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-12 16:24:07.439409
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():

    class DummyCounter():
        def next_value(self):
            return [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]

    data = [int(x, 16) for x in
        ['69', 'C4', 'E0', 'D8', '6A', '7B', '04', '30', 'D8', 'CD', 'B7', '80', '70', 'B4', 'C5', '5A']]

# Generated at 2022-06-12 16:24:17.549430
# Unit test for function aes_decrypt
def test_aes_decrypt():
    assert aes_decrypt([0] * BLOCK_SIZE_BYTES, [0] * BLOCK_SIZE_BYTES) == [0] * BLOCK_SIZE_BYTES

# Generated at 2022-06-12 16:24:30.601893
# Unit test for function aes_decrypt_text

# Generated at 2022-06-12 16:24:41.200724
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = [0] * BLOCK_SIZE_BYTES
    test_data = [
        ("dda97ca4864cdfe06eaf70a0ec0d7191", "d9313225f88406e5a55909c5aff5269a86a7a9531534f7da2e4c303d8a318a721c3c0c95956809532fcf0e2449a6b525b16aedf5aa0de657ba637b391aafd255", iv),
        ]
    for key_hex, cipher_hex, iv in test_data:
        key = bytes_to_intlist(compat_b64decode(key_hex))
        cipher = bytes_to_intlist(compat_b64decode(cipher_hex.encode()))

# Generated at 2022-06-12 16:24:54.394740
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(compat_b64decode(
        b'wU6i2U6n14mR9giV5d5JjDl2CNRrj0n7AuF3q+x7jOPz0cXWM7SNp8iY0G7VF1EW'
    ))
    key = bytes_to_intlist(compat_b64decode(
        b'1DmjBTJ7Vn3q3uOh7V5iAf/PpBQU/9I/kp7lDF/fN1k='
    ))
    class TestCounter():
        def __init__(self, counter):
            self.counter = counter

# Generated at 2022-06-12 16:25:06.283230
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter:
        def __init__(self, start=0):
            self.counter = start

        def next_value(self):
            self.counter += 1
            return bytes_to_intlist(compat_b64decode('NkJCQzIxOUI4NjY2QTAxMkU0RTMzMkIxNjJCRDdEMjA='))


# Generated at 2022-06-12 16:25:17.671472
# Unit test for function aes_encrypt
def test_aes_encrypt():
    # From FIPS-197
    plaintext  = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, \
                  0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]
    key        = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, \
                  0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-12 16:25:20.505847
# Unit test for function inc
def test_inc():
    data = [1, 0, 0, 0]
    assert inc(data) == [1, 0, 0, 1]
    assert data == [1, 0, 0, 0]  # data is not changed
    data = [0, 255, 255, 255]
    assert inc(data) == [1, 0, 0, 0]
    data = [255, 255, 255, 255]
    assert inc(data) == [0, 0, 0, 0]
    print('test_inc success!')


test_inc()


# Generated at 2022-06-12 16:25:25.766097
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    aes_key = bytes_to_intlist(compat_b64decode(
        b'rHaKgeI8G+gYUL01O/5/XQ=='))
    iv = [0] * 16
    aes_cbc_encrypted_data = bytes_to_intlist(compat_b64decode(
        b'1FyKfURo8iDYjQhf4Gn9nQ=='))
    aes_cbc_decrypted_data = aes_cbc_decrypt(
        aes_cbc_encrypted_data, aes_key, iv)
    assert intlist_to_bytes(aes_cbc_decrypted_data) == b'foobar'

# Generated at 2022-06-12 16:25:37.164313
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    password = b'password'
    data = b'Q1G2QIK8mWtC/mONw4n0giVp+8TkTZFJvS9/SZ/g9j8='
    assert aes_decrypt_text(data, password, 16) == b'123456'
    assert aes_decrypt_text(data, password, 24) == b'123456'
    assert aes_decrypt_text(data, password, 32) == b'123456'


# Generated at 2022-06-12 16:25:46.351258
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = bytes_to_intlist(compat_b64decode(b'Mk9m98IfEblmPfrpsawt7BmxObt98Jev'))
    cleartext = bytes_to_intlist(b'867-5309')
    cipher = bytes_to_intlist(compat_b64decode(b'RUFNTTMzRVZTU01ZRU1SREhRTFNZU01NRlFMUk1qUTVESQ=='))
    assert(aes_encrypt(cleartext, key_expansion(key)) == cipher)


# Generated at 2022-06-12 16:25:54.157446
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    print("AES Decryption")
    enc = '1l3dii9zZabpOJLfndDh+Q=='
    pw = 'passw0rd'
    print("Encrypted (Base64)    : %s" % enc)
    print("Password              : %s" % pw)
    dec = aes_decrypt_text(enc, pw, 32)
    print("Decrypted (Text)      : %s" % dec)
    assert dec == b'Hello World!'
    print("Success!\n")
test_aes_decrypt_text()

# unit test for function aes_ctr_decrypt

# Generated at 2022-06-12 16:26:03.875575
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, start_value):
            self.value = start_value

        def next_value(self):
            self.value += 1
            return intlist_to_bytes(self.value)

    from .AES import aes_encrypt

    data = intlist_to_bytes(range(19))
    key = [0] * 16
    enc_data = aes_ctr_decrypt(data, key, Counter(0))
    dec_data = aes_ctr_decrypt(enc_data, key, Counter(0))
    assert data == dec_data


# Generated at 2022-06-12 16:26:15.740962
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text(
        "f5eA1r8KjGp5d5i5",
        "",
        16) == "blubb"
    assert aes_decrypt_text(
        "Jki5/5D7/5zjO5JwN5zjnb5j7L5Y2Y5YWr",
        "blablabla",
        24) == "abcdefghijklmnopqrstuvwxyz"

    password = "blablabla"
    data = "Jki5/5D7/5zjO5JwN5zjnb5j7L5Y2Y5YWr"

# Generated at 2022-06-12 16:26:28.522070
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = "ejKTOc8tHgOaYvtkiEjKTOc8tHgOaYvtkiEjKTOc8tHgOaYvtkiEjKTOc8tHgOaYvtkiEjKTOc8tHgOaYvtkiEjKTOc8tHgOaYvtkiEjKTOc8tHgOaYvtk=="
    key = "haksu"
    plaintext = aes_decrypt_text(data, key, 16)


# Generated at 2022-06-12 16:26:38.981750
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = bytes_to_intlist(b'1234567890abcdef1234567890abcdef')
    data = bytes_to_intlist(b'1234567890abcdef')
    expanded_key = key_expansion(key)
    cipher = aes_encrypt(data, expanded_key)
    expected = [0x7d, 0xfd, 0xf9, 0xca, 0x91, 0x27, 0xce, 0x40, 0x0e, 0x7f, 0x0a, 0x4b, 0xb4, 0x0f, 0x6d, 0xfc]
    assert cipher == expected


# Generated at 2022-06-12 16:26:46.424108
# Unit test for function aes_encrypt
def test_aes_encrypt():
    data = [65, 27, 9, 1, 4, 3, 40, 50, 91, 7, 6, 0, 2, 5, 68, 22]

# Generated at 2022-06-12 16:26:59.529202
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Data taken from http://www.inconteam.com/software-development/41-encryption/55-aes-test-vectors
    data = "7649abac8119b246cee98e9b12e9197d"
    data = bytes_to_intlist(compat_b64decode(data))

    key = "603deb1015ca71be2b73aef0857d7781"
    key = bytes_to_intlist(compat_b64decode(key))
    expanded_key = key_expansion(key)

    cipher = "f69f2445df4f9b17ad2b417be66c3710"
    cipher = bytes_to_intlist(compat_b64decode(cipher))

# Generated at 2022-06-12 16:27:05.597230
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Test data generated with pycrypto
    # (returned bytes are encoded with base64)
    data = b'Bfhet7+WwjLDb5A5u5MtMv7Vu5IM8O+pjmKD/PfkCwY='
    password = '0123456789'

    decrypted_data = aes_decrypt_text(data, password, 32)

    assert decrypted_data == b'Hello World!'



# Generated at 2022-06-12 16:27:22.232192
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Key Size: 16 bytes
    keySize = 16
    # Key: '1234567890123456'
    key = bytes_to_intlist(compat_b64decode("MTIzNDU2Nzg5MDEyMzQ1Ng=="), 'big')
    # Cipher: 'U2FsdGVkX1/5bggbkKcCAg=='
    cipher = bytes_to_intlist(compat_b64decode("U2FsdGVkX1/5bggbkKcCAg=="), 'big')
    # Plain:  '1234567890123456'
    plain = bytes_to_intlist(compat_b64decode("MTIzNDU2Nzg5MDEyMzQ1Ng=="), 'big')
    


# Generated at 2022-06-12 16:27:33.493392
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
  data = bytes_to_intlist(compat_b64decode('riZXaL/MrYIH2ksQcD+Gxw=='))
  key = bytes_to_intlist('5*j0Ye.F(=lzVdTu')
  iv = bytes_to_intlist('\xa1\xaa\x2f\x17\x88\x69\x92\x4a\x15\x4e\x9a\x4c\x4e\x97\x2b\x0e')

# Generated at 2022-06-12 16:27:45.415353
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # create clear text
    clear_text = b'YELLOW SUBMARINE'
    clear_text_bytes = [ord(c) for c in clear_text]
    # create key
    key = b'YELLOW SUBMARINE'*2
    key_bytes = [ord(c) for c in key]
    # create iv
    iv = bytes_to_intlist(compat_b64decode(b'x'*16))
    # encrypt
    encrypted_data = aes_cbc_encrypt(clear_text_bytes, key_bytes, iv)

# Generated at 2022-06-12 16:27:54.685030
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist('36f18357be4dbd77f050515c73fcf9f2')
    iv = bytes_to_intlist('36f18357be4dbd77f050515c73fcf9f2')
    data = bytes_to_intlist('Hello World 1234')

    encrypted_data = aes_cbc_encrypt(data, key, iv)
    #print(encrypted_data)
    assert(
        encrypted_data == [
            0x29, 0xc3, 0x50, 0x5f, 0x57, 0x14, 0x20, 0xf6, 0x40, 0x22,
            0x99, 0xb3, 0x1a, 0x02, 0xd7, 0x3a
        ]
    )

# Unit test

# Generated at 2022-06-12 16:28:01.612031
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0, 0, 0, 0] * 4
    iv = [0] * 16
    data = [0] * 4 + [1] * 4 + [2] * 4 + [3] * 4

    result = aes_cbc_encrypt(data, key, iv)

    expected_result = [0] * 4 + [1] * 4 + [2] * 4 + [3] * 4
    assert result == expected_result


# Generated at 2022-06-12 16:28:14.138071
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = [0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5, 0x62, 0xf8, 0xea, 0xd2, 0x52, 0x2c, 0x6b, 0x7b]

# Generated at 2022-06-12 16:28:20.587443
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test vector from http://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38a.pdf
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-12 16:28:34.015573
# Unit test for function aes_decrypt

# Generated at 2022-06-12 16:28:40.131153
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode(b'ZD5Ku5L5xd5r5c5J5h5C5b5n5u5W5i5F5u5Z5B5l5L5w5E5h5B5y5F5a5M5f5G5d5e'))

# Generated at 2022-06-12 16:28:53.205342
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    bs = 16
    data = bytes_to_intlist(compat_b64decode('3cNwD4LybRlR1AwJJKjyu/x0G6jKAfW8kC6FywcBwv6q3NO6rQL9XUCAwEAAQ=='))
    iv = bytes_to_intlist(b'\xe8\x30n\x9d\x9c\xae\xe4\xd7\x0f\xf7\x16\xf4\x7f\x12\x9e\x8d\xaa')
    decrypted_data = aes_c

# Generated at 2022-06-12 16:29:05.942502
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Ensure that AES decryption works with the same key
    correct_key = bytes_to_intlist(compat_b64decode('K5j5F5S5e5I5k5y5'))
    incorrect_key = bytes_to_intlist(compat_b64decode('K5j5F5S5e5I5k5y6'))

    iv = bytes_to_intlist(compat_b64decode('X3q3T3H3T3u3K3f3'))
    iv2 = bytes_to_intlist(compat_b64decode('X3q3T3H3T3u3K3f4'))


# Generated at 2022-06-12 16:29:18.380240
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    def do_test(key, iv, data, expected):
        key = bytes_to_intlist(compat_b64decode(key))
        iv = bytes_to_intlist(compat_b64decode(iv))
        data = bytes_to_intlist(compat_b64decode(data))
        expected = compat_b64decode(expected)
        result = intlist_to_bytes(aes_cbc_decrypt(data, key, iv))
        assert result == expected

    # Test vectors from:
    # http://csrc.nist.gov/groups/STM/cavp/documents/aes/KAT_CBC.zip
    # cbc_varKey_varTxt.txt

# Generated at 2022-06-12 16:29:31.096486
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # From http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    key = bytes_to_intlist(compat_b64decode('gUuTKwHIER70bVAkfWKnEA=='))
    iv = bytes_to_intlist(compat_b64decode('wzGtLcqmY8E='))
    data = bytes_to_intlist(compat_b64decode('wzGtLcqmY8HThlNxX+fXkw=='))
    expected = bytes_to_intlist(compat_b64decode('YK7CpP+xX9uoV+bSXXOI45g=='))

# Generated at 2022-06-12 16:29:39.589352
# Unit test for function aes_decrypt
def test_aes_decrypt():
    assert aes_decrypt([217,175,135,48,219,137,186,166,239,33,170,34,191,123,3,31], key_expansion([47,198,1,239,180,78,247,86,158,242,246,18,172,225,9,178,63,248,69,20,214,179,208,107,166,151,112,173,13,225,35])) == [74,40,188,101,159,91,19,206,157,171,115,219,29,166,252,231]


# Generated at 2022-06-12 16:29:47.999778
# Unit test for function aes_decrypt
def test_aes_decrypt():
    cipher = [0x29, 0xc3, 0x50, 0x5f, 0x57, 0x14, 0x20, 0xf6, 0x40, 0x22, 0x99, 0xb3, 0x1a, 0x02, 0xd7, 0x3a]
    key = [0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)
    state = aes_decrypt(cipher, expanded_key)

# Generated at 2022-06-12 16:29:56.228648
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data = intlist_to_bytes(aes_decrypt(
        bytes_to_intlist(compat_b64decode('w0mfhGk0m+EBkDh8rCX9PA==')),
        bytes_to_intlist(compat_b64decode('CFCGjK8g+hG9hMOFtLjowA==')),
    ))
    assert data == compat_b64decode('QklFMQ==')


# Generated at 2022-06-12 16:30:07.545692
# Unit test for function aes_decrypt
def test_aes_decrypt():
    """
    Test for aes_decrypt
    """
    key_hex = "2b7e151628aed2a6abf7158809cf4f3c"
    key = bytes_to_intlist(compat_b64decode(key_hex, '_-'))
    aes_key = key_expansion(key)

    data_hex = "3ad77bb40d7a3660a89ecaf32466ef97"
    cipher = bytes_to_intlist(compat_b64decode(data_hex, '_-'))

    data = aes_decrypt(cipher, aes_key)
    data_hex = intlist_to_bytes(data).hex()


# Generated at 2022-06-12 16:30:19.026272
# Unit test for function aes_decrypt
def test_aes_decrypt():
    """
    Test function aes_decrypt by checking it against known correct values.
    """
    # Test vectors from http://csrc.nist.gov/groups/STM/cavp/documents/aes/KAT_AES.zip
    # Multi-block Message Test Encryption
    # ECB VarTxt 1024

# Generated at 2022-06-12 16:30:27.918883
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:30:32.562654
# Unit test for function aes_decrypt
def test_aes_decrypt():
    test_key = bytes_to_intlist(b'\1' * 16)
    test_expanded_key = key_expansion(test_key)
    assert aes_decrypt([1] * 16, test_expanded_key) == [0] * 16



# Generated at 2022-06-12 16:30:47.055544
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('/wF+mv0EJztO2QQ=='))
    data = bytes_to_intlist(compat_b64decode(
        'MFUCBhcGA+8N/RXzv7yuIf4Lo4nE8Z3qia4QP7VHgYzYc7yS1XzvFF7h1pB5d5Zo'
        'x5OAolhbKRtQfzxyjWXCv1D0ejmf2Qai/OZ+lA0EK1aYIvYI=='))

# Generated at 2022-06-12 16:30:55.936385
# Unit test for function key_expansion
def test_key_expansion():
    # Test vector set 1 (128-bit key)
    data = bytes_to_intlist(compat_b64decode(b"U3ByaW5nQmxhZGU="))
    result = key_expansion(data)

# Generated at 2022-06-12 16:31:00.485784
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode(b'CfHYdH0JbIQwMgdOgoxTsQ=='))
    iv = bytes_to_intlist(compat_b64decode(b'wHgBG0pD1Fn0dZAwRvkJ6g=='))
    enc = bytes_to_intlist(compat_b64decode(b'ewoVvh/qtPWYXsLs64/29priy1wAaA=='))
    dec = aes_cbc_decrypt(enc, key, iv)
    assert dec == [0, 0, 0, 0]



# Generated at 2022-06-12 16:31:07.092357
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:31:18.759816
# Unit test for function key_expansion
def test_key_expansion():
    assert key_expansion(bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')) == bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da5'
                                                                                         '573f3d6fc6a50440fa33cc3a6f29760b3ef6c8885a3b25fa'
                                                                                         '448c570d66727fbd3d194f789b3ce4b4bd9e1320bbe9520c'
                                                                                         '2e496817ff05d8be8')

# Generated at 2022-06-12 16:31:30.643839
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [4, 211, 31, 197, 84, 157, 252, 254, 11, 100, 157, 250, 63, 170, 106, 206, 107, 124, 212, 45, 111, 107, 9, 219, 200, 177, 0, 240, 143, 156, 44, 207]
    iv = [83, 73, 191, 98, 2, 205, 113, 3, 234, 6, 55, 70, 242, 96, 52, 126]

# Generated at 2022-06-12 16:31:42.539558
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:31:53.904978
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Hello world encrypted with python's Crypto library
    # Using the same key, iv and data
    data = 'z93U6HkU6zQ/sFJhR0/0PbwPGs/3qr/o0hJNHEdXNjU='
    data = compat_b64decode(data)
    data = list(compat_bytes(data))
    iv = data[:16]
    data = data[16:]
    key = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    decrypted_data = aes_cbc_decrypt(
        data, key, iv)
    assert len(decrypted_data) == len(compat_bytes('Hello world'))
    assert decrypted_data

# Generated at 2022-06-12 16:32:00.944101
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    import base64
    from .aes import test_aes_cbc_encrypt

    for i in range(8):
        key = bytes_to_intlist(base64.b64decode(test_aes_cbc_encrypt.TEST_VECTORS[i]['key']))
        data = bytes_to_intlist(base64.b64decode(test_aes_cbc_encrypt.TEST_VECTORS[i]['input']))
        iv = bytes_to_intlist(base64.b64decode(test_aes_cbc_encrypt.TEST_VECTORS[i]['iv']))

# Generated at 2022-06-12 16:32:12.430490
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data_hex = (
        'c1cf68568521d98b2d0f8a5c178889e3f5db5f5b5d03b5ee5b5ceb'
        '0a8c75a2ddeec67b445f9010d73ecc37fbebfa791d0a71e8f8c4cc'
        '4'
    )

    key_hex = '2b7e151628aed2a6abf7158809cf4f3c'
    iv_hex = '000102030405060708090a0b0c0d0e0f'

    data = bytes_to_intlist(compat_b64decode(data_hex))

# Generated at 2022-06-12 16:32:20.154329
# Unit test for function key_expansion
def test_key_expansion():
    def test_key_expansion_for_key_size(key_size_bytes):
        key = [0] * key_size_bytes
        expected_result = [0] * key_expansion_length
        expected_result[len(expected_result) - key_size_bytes:] = key
        result = key_expansion(key)
        assert result == expected_result
    for key_size_bytes in [16, 24, 32]:
        test_key_expansion_for_key_size(key_size_bytes)


# Generated at 2022-06-12 16:32:32.694005
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:42.878447
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:54.293475
# Unit test for function key_expansion

# Generated at 2022-06-12 16:33:06.226054
# Unit test for function key_expansion
def test_key_expansion():
    def _assert(key, answer):
        answer = bytes_to_intlist(compat_b64decode(answer))
        expanded_key = key_expansion(bytes_to_intlist(key))
        assert expanded_key == answer, "expanded_key: %r\nexpected_answer: %r" % (expanded_key, answer)


# Generated at 2022-06-12 16:33:18.369748
# Unit test for function key_expansion
def test_key_expansion():
    import unittest

    class TestKeyExpansion(unittest.TestCase):
        def test_aes128(self):
            key = bytes_to_intlist(compat_b64decode(b'gAeDVdZbwdyTSelMOJgOlA=='))
            expanded_key = bytes_to_intlist(compat_b64decode(b'gAeDVdZbwdyTSelMOJgOlCB5YpY8Dr5lDw5w5Ur0MkzvA+Rcx6X9SSdWYn8UQ7VZhCG6Z0qVu+k8FkfT1yHPxQ=='))
            self.assertEqual(key_expansion(key), expanded_key)
