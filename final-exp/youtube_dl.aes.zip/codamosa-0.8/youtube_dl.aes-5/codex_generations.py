

# Generated at 2022-06-12 16:23:45.930270
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = bytes_to_intlist(compat_b64decode('wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY'))
    # print(key)  # [119, 74, 97, 108, 114, 88, 85, 116, 110, 70, 69, 77, 73, 47, 75, 55]
    data1 = [225, 228, 227, 207, 157, 129, 184, 111, 107, 93, 65, 43, 149, 88, 11, 58]
    data2 = bytes_to_intlist('aes_cbc_encrypt')
    data3 = bytes_to_intlist('aes_cbc_decrypt')
    # print(data1)  # [225, 228, 227, 207, 157, 129, 184, 111, 107, 93

# Generated at 2022-06-12 16:23:54.938753
# Unit test for function key_expansion
def test_key_expansion():
    key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    result = key_expansion(key)

# Generated at 2022-06-12 16:24:06.249262
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes import counter
    from .aes import expand_key
    from .aes import encrypt
    from .aes import byte_string_to_block_list
    from .aes import block_list_to_byte_string
    from .aes import string_to_byte_array
    from .aes import byte_array_to_string

    # http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    # Appendix F.5  CTR Example Vectors
    # F.5.1 CTR-AES128.Encrypt
    key = string_to_byte_array("2b7e151628aed2a6abf7158809cf4f3c")
    expanded_key = expand_key(key)

    assert expand_key

# Generated at 2022-06-12 16:24:13.581663
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    password = 'Hello'
    cipher = 'YjY5ZjM0ZDg1ZmQ2M2RlMzI1ZmU3ZTc3NDRmODY0NjZjZDZmMWE1YmYyY2QyYTdlZjk2M2Nh'
    plaintext = 'Hello World!'
    assert aes_decrypt_text(cipher, password, 16) == plaintext.encode('utf-8')



# Generated at 2022-06-12 16:24:16.866060
# Unit test for function inc
def test_inc():
    assert inc([255, 255, 255]) == [255, 255, 0]
    assert inc([0, 0, 0]) == [0, 0, 1]
    assert inc([0, 0, 255]) == [0, 1, 0]



# Generated at 2022-06-12 16:24:22.607699
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = bytes_to_intlist(b"YELLOW SUBMARINE")
    cipher = compat_b64decode(b"""
    L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==""")
    cipher = bytes_to_intlist(cipher)

    class Counter(object):
        def __init__(self, nonce):
            self.nonce = nonce
            self.increment = 0

        def next_value(self):
            result = self.nonce + [self.increment]
            self.increment += 1
            return result

    counter = Counter([0, 0, 0, 0, 0, 0, 0, 0])

    decrypted_

# Generated at 2022-06-12 16:24:34.609341
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

    cbc_iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
              0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]


# Generated at 2022-06-12 16:24:43.413331
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist("6bc1bee22e409f96e93d7e117393172a")
    key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    counter = AESCounter(bytes_to_intlist("000102030405060708090a0b0c0d0e0f"))
    result = aes_ctr_decrypt(data, key, counter)
    assert result == bytes_to_intlist("69c4e0d86a7b0430d8cdb78070b4c55a")


# This class is a helper for aes_ctr_decrypt

# Generated at 2022-06-12 16:24:55.615127
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # example from https://en.wikipedia.org/wiki/Block_cipher_mode_of_operation#Cipher_Block_Chaining_.28CBC.29
    key = intlist_to_bytes([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
                           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c])

# Generated at 2022-06-12 16:25:07.294184
# Unit test for function aes_decrypt_text

# Generated at 2022-06-12 16:25:25.352015
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    assert aes_cbc_encrypt([], b'\x00' * 16, b'\x00' * 16) == []

    data = 'foo bar'.encode('utf-8')
    key = '01234567012345670123456701234567'.encode('utf-8')

# Generated at 2022-06-12 16:25:31.985695
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist("140b41b22a29beb4061bda66b6747e14")
    iv = bytes_to_intlist("4ca00ff4c898d61e1edbf1800618fb28")
    data = bytes_to_intlist("Hello World")
    encrypted_data = aes_cbc_encrypt(data, key, iv)

    assert intlist_to_bytes(encrypted_data) == compat_b64decode("4ca00ff4c898d61e1edbf1800618fb2828a226d160dad07883d04e008a7897ee2e4b7465d5290d0c0e6c6822236e1daafb94ffe0c5da05d9476be028ad7c1d81")



# Generated at 2022-06-12 16:25:44.450180
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode(b'rCgHlW8bOUI='))
    iv = bytes_to_intlist(compat_b64decode(b'rCgHlW8bOUI='))
    cipher = bytes_to_intlist(compat_b64decode(b'RBEj0V+wZfI='))
    # print repr(intlist_to_bytes(aes_cbc_decrypt(cipher, key, iv)))

    key = bytes_to_intlist(compat_b64decode(b'6m5+WxHR8Ae5Zg85Yug+aQ=='))

# Generated at 2022-06-12 16:25:54.096732
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = bytes_to_intlist(compat_b64decode('jNQXAC9iTzTfA9F9EDuDFQ=='))
    key = bytes_to_intlist(compat_b64decode('d/tKjq9p/yfVzugEkN0iJQ=='))
    data = bytes_to_intlist(compat_b64decode(
        'ug95oW+xci24CKwTzLceTfJbTxzcj9+ybGKMmgQYFNI='))

# Generated at 2022-06-12 16:26:06.480767
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from .utils import bytes_to_intlist, intlist_to_hexstr, intlist_to_bytes
    iv_str = "8EA2B7CA516745BFEAFC49904B496089"
    key_str = "2b7e151628aed2a6abf7158809cf4f3c"
    data_str = "6bc1bee22e409f96e93d7e117393172aae2d8a571e03ac9c9eb76fac45af8e5130c81c46a35ce411e5fbc1191a0a52eff69f2445df4f9b17ad2b417be66c3710"

# Generated at 2022-06-12 16:26:17.404816
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    print("\nParameters:")
    key = bytes_to_intlist("2b7e151628aed2a6abf7158809cf4f3c")
    iv = bytes_to_intlist("000102030405060708090a0b0c0d0e0f")
    print("\tkey: ", key)
    print("\tiv: ", iv)

    data = bytes_to_intlist("6bc1bee22e409f96e93d7e117393172aae2d8a571e03ac9c9eb76fac45af8e5130c81c46a35ce411e5fbc1191a0a52eff69f2445df4f9b17ad2b417be66c3710")
    print("\tdata: ", data)

# Generated at 2022-06-12 16:26:30.955223
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    print('Testing AES-CBC decryption...')
    key = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2]
    iv = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    aes_cbc_cipher = [0] * 16
    # Unit test with empty data
    decrypted = aes_cbc_decrypt(aes_cbc_cipher, key, iv)
    assert decrypted == [0] * 16, 'Error testing AES-CBC decryption with empty data'

    # Unit test with vulnerable key

# Generated at 2022-06-12 16:26:42.324760
# Unit test for function aes_decrypt

# Generated at 2022-06-12 16:26:55.628292
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [82, 117, 45, 187, 120, 59, 66, 155, 198, 28, 112, 217, 165, 129, 10, 237, 105, 118, 113, 144, 125, 231, 192,
           133, 119, 228, 159, 8, 134, 105, 7]
    iv = [82, 117, 45, 187, 120, 59, 66, 155, 198, 28, 112, 217, 165, 129, 10, 237]

# Generated at 2022-06-12 16:27:00.005507
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist('HelloWorld')
    key = bytes_to_intlist('YELLOW SUBMARINE')
    iv = bytes_to_intlist('0123456789abcdef')
    encrypted = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypted) == compat_b64decode('OKfZAZV0i0wYWDGc7xu27Q==')
    return True
test_aes_cbc_encrypt()



# Generated at 2022-06-12 16:27:11.284034
# Unit test for function aes_decrypt
def test_aes_decrypt():
    #key=[]
    #key=[0x00,0x00,0x00,0x00]
    key=[0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00]
    #key=[0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f]

# Generated at 2022-06-12 16:27:23.959418
# Unit test for function aes_decrypt

# Generated at 2022-06-12 16:27:35.609651
# Unit test for function aes_decrypt
def test_aes_decrypt():
    encrypted_data = bytes_to_intlist(compat_b64decode('HgV7yhQ0vkoI7Ou8bzfV7OZa1wRV+bsWQGdKCShiMjI='))
    expanded_key = bytes_to_intlist(compat_b64decode('e2xk7aAJLlC+rzq3X8DjBVu0d/5wYV5I5NkIf7Nu/Q2vn7AuN9+FhmPPOZDPH2hvJb30a1fEz35b0+iz/oJ0h391C9Xe6PbJOZTOE4s4sM3hqTdT+T6fUGG6SbBh9Xh'))

# Generated at 2022-06-12 16:27:47.462321
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode(b'qCkFqwM9XRmsPDEuLpDYFA=='))
    cipher = bytes_to_intlist(compat_b64decode(b'yQjY1TzcSzzS4dTzMrZ0llelDz4+a4WpX8L1yc/YbYM='))
    iv = bytes_to_intlist(compat_b64decode(b'NkE3NTI5NDY2Q0FBQkRFRg=='))
    expected_plain = b'Plaintext \xc3\xa9\xc3\xa0\xc3\xb9\xc3\xa7\xc3\xa8'.decode('latin-1')
   

# Generated at 2022-06-12 16:27:54.423851
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist(compat_b64decode(
        'CzM1wGp3qdpg/tkm3PcLXg=='))
    data = bytes_to_intlist(compat_b64decode(
        'Nztc/bXsxoD2ScOeTZZrvw=='))
    expanded_key = key_expansion(key)
    decrypted_data = aes_decrypt(data, expanded_key)
    assert intlist_to_bytes(decrypted_data) == 'TeST'

# Generated at 2022-06-12 16:28:06.346539
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist(compat_b64decode('q3xGxmglnV7D+MkzpvK4uA=='))
    expanded_key = key_expansion(key)
    data = bytes_to_intlist(b'\x9d\x1f\xc8Y\x0c\r\xadp\xb8\x00\x87\x17\x0c\x86\xb0\xae\xea\x00w\x0e\x87\xd3|\x01')
    result = aes_decrypt(data, expanded_key)

# Generated at 2022-06-12 16:28:17.087510
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Test 1: ECB mode
    # Test data from "Applied Cryptography, Second Edition", Bruce Schneier, John Wiley & Sons, 1996. Page 362.
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    cipher_text = [0x39, 0x25, 0x84, 0x1d, 0x02, 0xdc, 0x09, 0xfb, 0xdc, 0x11, 0x85, 0x97, 0x19, 0x6a, 0x0b, 0x32]

# Generated at 2022-06-12 16:28:30.135623
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:28:40.857568
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = 'YELLOW SUBMARINE'
    iv = [0] * BLOCK_SIZE_BYTES

# Generated at 2022-06-12 16:28:53.361124
# Unit test for function aes_decrypt
def test_aes_decrypt():
    '''
    Checks if the function aes_decrypt works
    '''

    # This is the example from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    data = bytes_to_intlist(compat_b64decode('kTfBLJ7Vu8QQYG1FeulGRg=='))
    expanded_key = bytes_to_intlist(compat_b64decode('kTfBLJ7Vu8QQYG1FeulGRg=='))

# Generated at 2022-06-12 16:29:05.703120
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    assert bytes_to_intlist(aes_cbc_decrypt(bytes_to_intlist('JUB1Lg0KVmhDUgsJXg=='.encode()), [0x00112233, 0x44556677, 0x8899aabb], [10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 2, 3, 4, 5, 6, 7])) == [0x0b, 0x1f,0x8a, 0x7a, 0x55,0xc3, 0x29, 0x20, 0x0c, 0x45, 0xc3, 0xcd, 0xf0, 0xb3, 0xcd, 0x2b]


# Generated at 2022-06-12 16:29:06.960713
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    #TODO write a unit test
    assert 1 == 0



# Generated at 2022-06-12 16:29:19.454945
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:29:29.285668
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = 'uV7F8vLxAg/SgveZ0t/W/J8+vOzAEX4NyqcLWPTN8/c='
    key = 'IHcEQRR1s95Pl9XD'
    iv = 'IHcEQRR1s95Pl9XD'
    decrypted_data = aes_cbc_decrypt(bytes_to_intlist(compat_b64decode(data)), bytes_to_intlist(key), bytes_to_intlist(iv))
    print(intlist_to_bytes(decrypted_data))


# Generated at 2022-06-12 16:29:41.570263
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-12 16:29:53.160561
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Example from: https://en.wikipedia.org/wiki/Block_cipher_mode_of_operation#Cipher_Block_Chaining_.28CBC.29
    iv = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]

# Generated at 2022-06-12 16:30:05.133874
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # empty input
    key = [1]*16
    iv = [2]*16
    data = bytes([])
    assert aes_cbc_decrypt(data, key, iv) == [], "Empty input string."

    # empty key
    key = bytes([])
    iv = [2]*16
    data = [1]*BLOCK_SIZE_BYTES
    assert aes_cbc_decrypt(data, key, iv) == [], "Empty key string."

    # cipher w/o padding
    key = [3]*16
    iv = [4]*16
    data = [1]*BLOCK_SIZE_BYTES

# Generated at 2022-06-12 16:30:12.995710
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:30:23.827877
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('s/sZ4xfej/CavL/pnfVFQ=='))
    iv = bytes_to_intlist(compat_b64decode('44444444444444444444444444444444'))
    cipher = bytes_to_intlist(compat_b64decode(
        '2H2GopfY0iLbRjTquhLGxibx0oLGAIaCe4O4j4ptHY4bBG0Zs9sO'))
    assert aes_cbc_decrypt(cipher, key, iv) == bytes_to_intlist(b'hello there')



# Generated at 2022-06-12 16:30:30.782352
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist("140b41b22a29beb4061bda66b6747e14")
    iv = bytes_to_intlist("4ca00ff4c898d61e1edbf1800618fb28")
    data = bytes_to_intlist("28a226d160dad07883d04e008a7897ee2e4b7465d5290d0c0e6c6822236e1daafb94ffe0c5da05d9476be028ad7c1d81")

    decrypted_data = aes_cbc_decrypt(data, key, iv)
    decrypted_data_string = intlist_to_bytes(decrypted_data)

    assert decrypted_data_string == "Basic CBC mode encryption needs padding."

# Generated at 2022-06-12 16:30:45.761457
# Unit test for function key_expansion
def test_key_expansion():
    key16 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    key24 = [0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5, 0x62, 0xf8, 0xea, 0xd2, 0x52, 0x2c, 0x6b, 0x7b]

# Generated at 2022-06-12 16:30:55.188598
# Unit test for function key_expansion
def test_key_expansion():
    expanded_key = key_expansion(intlist_to_bytes([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]))

# Generated at 2022-06-12 16:31:07.525603
# Unit test for function key_expansion
def test_key_expansion():
    assert key_expansion(bytes_to_intlist(b'')) == b''

# Generated at 2022-06-12 16:31:19.214603
# Unit test for function key_expansion
def test_key_expansion():
    key = [0] * 16
    key = key_expansion(key)
    key = intlist_to_bytes(key)

# Generated at 2022-06-12 16:31:31.028463
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:43.079077
# Unit test for function key_expansion
def test_key_expansion():
    key_size_bytes = 16
    cipher_key = bytes_to_intlist(b"YELLOW SUBMARINE")
    expanded_key_size_bytes = (key_size_bytes // 4 + 7) * BLOCK_SIZE_BYTES

# Generated at 2022-06-12 16:31:54.415707
# Unit test for function key_expansion
def test_key_expansion():
    print('Testing function key_expansion')
    expanded_key_128 = key_expansion(bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c'))

# Generated at 2022-06-12 16:32:03.680135
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:14.773836
# Unit test for function key_expansion
def test_key_expansion():
    key_128 = bytes_to_intlist(compat_b64decode('2b7e151628aed2a6abf7158809cf4f3c'))
    key_192 = bytes_to_intlist(compat_b64decode('8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b'))
    key_256 = bytes_to_intlist(compat_b64decode('603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4'))


# Generated at 2022-06-12 16:32:25.271009
# Unit test for function key_expansion
def test_key_expansion():
    expanded_key = key_expansion([0] * 16)
    assert len(expanded_key) == 176
    assert expanded_key[:16] == [0] * 16
    assert expanded_key[16:32] == [0x8d, 0x01, 0x02, 0x04, 0x8f, 0x05, 0x06, 0x08, 0x16, 0x0a, 0x0c, 0x0d, 0x07, 0x0f, 0x10, 0x11]

# Generated at 2022-06-12 16:32:39.156002
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:42.139873
# Unit test for function key_expansion
def test_key_expansion():
    _test_key_expansion(range(16))
    _test_key_expansion(range(24))
    _test_key_expansion(range(32))



# Generated at 2022-06-12 16:32:53.669188
# Unit test for function key_expansion

# Generated at 2022-06-12 16:33:05.745889
# Unit test for function key_expansion
def test_key_expansion():
    import binascii
    # https://cryptopals.com/sets/2/challenges/10
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    iv = bytes_to_intlist(compat_b64decode('\x00' * 16))

# Generated at 2022-06-12 16:33:11.435997
# Unit test for function key_expansion
def test_key_expansion():
    import random

    def _test():
        key = [random.randint(0, 255) for _ in range(32)]
        expanded_key = key_expansion(key)

        print('Key:', key)
        print('Expanded Key:', expanded_key)
    _test()
    _test()

