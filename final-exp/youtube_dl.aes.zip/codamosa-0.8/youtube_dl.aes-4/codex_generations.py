

# Generated at 2022-06-12 16:23:50.302843
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key_size = 32
    data = bytes_to_intlist("TEST") + [0] * 12
    key = data[:key_size]
    expanded_key = key_expansion(key)
    cipher = aes_encrypt(data, expanded_key)
    expect = [212, 223, 110, 142, 129, 74, 106, 40, 170, 224, 76, 23, 57, 88, 109, 21]
    assert cipher == expect


# Generated at 2022-06-12 16:23:58.571078
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('C4f4yQQa3KmV0Lw1Z+7zew=='))
    iv = bytes_to_intlist(compat_b64decode('5St5eRrvj1zY2Y9fYe1vgQ=='))
    data = bytes_to_intlist(compat_b64decode(
        '8X9b/xN2QaDlNreW8KIOgEtuCZOwvZzHlrW8/3q9mC0='))
    test_data = bytes_to_intlist(compat_b64decode('test data'))
    cipher = aes_cbc_decrypt(data, key, iv)
    assert cipher == test_data


# Generated at 2022-06-12 16:24:10.911269
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    expanded_key = key_expansion(key)
    data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    assert (aes_encrypt(data, expanded_key) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])

    key = [137, 80, 78, 71, 13, 10, 26, 10, 0, 0, 0, 13, 73, 72, 68, 82]
    expanded_key = key_expansion(key)

# Generated at 2022-06-12 16:24:19.968033
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import random
    import hashlib

    def intlist_to_str(intlist):
        return ''.join(map(chr, intlist))

    def random_intlist(length):
        return [random.randint(0, 255) for _ in range(length)]

    class TestCounter:
        def __init__(self):
            self.counter = 0

        def next_value(self):
            self.counter += 1
            return random_intlist(BLOCK_SIZE_BYTES)

    def test_case_generator(length):
        for _ in range(length):
            key = random_intlist(16)
            counter = TestCounter()
            data = random_intlist(random.randint(0, 63))

# Generated at 2022-06-12 16:24:32.985965
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # Check for EBC mode
    data = bytearray(b"\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff")
    key = bytearray(b"\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f")
    expanded_key = key_expansion(key)
    assert aes_decrypt(aes_encrypt(data, expanded_key), expanded_key) == data
    assert aes_decrypt(aes_encrypt(data, expanded_key), expanded_key) == data

# Generated at 2022-06-12 16:24:43.016359
# Unit test for function key_expansion
def test_key_expansion():
    key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32]
    data = key_expansion(key)
    assert len(data) == 240
    assert data[0] == 1
    assert data[239] == 56
    key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    data = key_expansion(key)
    assert len(data) == 176
    assert data[0] == 1
    assert data[175] == 24
    key = [1, 2, 3, 4]
    data = key

# Generated at 2022-06-12 16:24:55.327683
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-12 16:25:07.135756
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import os
    import re
    search = re.compile(b'''decrypt_aes_cbc\(\s*
        \s*["']([A-Za-z0-9+/=]{43})["']  # cipher base64
        \s*,\s*
        \s*["'](.*?)["']                # password
        \s*,\s*
        \s*(16|24|32)                    # key size
        \s*\)''', re.VERBOSE)
    files_to_scan = [
        os.path.join('youtube_dl', 'extractor', 'common.py'),
        os.path.join('youtube_dl', 'extractor', 'youtube.py'),
    ]

# Generated at 2022-06-12 16:25:18.325767
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    test_data = """\
4qPE3iyJwNyAcBpCzYIS+rq3LjBtlZHbkj2nBJZx7+lRwKzYJYcMvYXsLj2s+sT
TtguZTajxLP7pI+wkBmI2QdxSYtGJBbY7jKlF0xI7pBmtcjBZ57mTkC9N3fq3ou
a/jKPNPzNxP/R0/FgkM0/EuGZ9eU5S6SauWzd8bFeUH4hk=
"""

    # key for test data

# Generated at 2022-06-12 16:25:24.970349
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    cleartext = [0]*16
    key = [0]*16
    iv = [0]*16
    encrypted_data = aes_cbc_encrypt(cleartext, key, iv)
    assert (encrypted_data == iv)
    cleartext = [0]*17
    encrypted_data = aes_cbc_encrypt(cleartext, key, iv)
    assert(encrypted_data == [0]*16)



# Generated at 2022-06-12 16:25:41.548561
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test method aes_decrypt_text
    """
    import base64
    import sys

    if sys.version_info < (3,):
        base64_decode = lambda x: base64.decodestring(x)
    else:
        base64_decode = base64.decodebytes


# Generated at 2022-06-12 16:25:52.245748
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist('140b41b22a29beb4061bda66b6747e14'.decode('hex'))
    iv = bytes_to_intlist('4ca00ff4c898d61e1edbf1800618fb28'.decode('hex'))

    encrypted = aes_cbc_encrypt(
        bytes_to_intlist('hello world hello world hello world hello world'.encode('utf-8')),
        key, iv)


# Generated at 2022-06-12 16:26:05.633499
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Test vectors from: https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf
    assert aes_decrypt_text('QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F', 'password123', 16) == b'\x00' * 16
    assert aes_decrypt_text('QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F', 'password123', 24) == b'\x00' * 16
    assert aes_decrypt_text('QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F', 'password123', 32)

# Generated at 2022-06-12 16:26:16.725505
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = intlist_to_bytes(range(16))

# Generated at 2022-06-12 16:26:30.267396
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    '''
    Test function aes_decrypt_text
    '''
    print('Test function aes_decrypt_text')

# Generated at 2022-06-12 16:26:33.915214
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = b'Some cleartext here'
    data = bytes_to_intlist(data)

    key = b'\x00' * 16
    key = bytes_to_intlist(key)

    iv = [0] * 16

    encrypted_data = aes_cbc_encrypt(data, key, iv)
    decrypted_data = aes_cbc_decrypt(encrypted_data, key, iv)

    assert(data == decrypted_data)

test_aes_cbc_encrypt()



# Generated at 2022-06-12 16:26:44.221954
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, initial_value):
            self._initial_value = initial_value
            self._counter_value = initial_value
        def next_value(self):
            counter_value = self._counter_value
            block = [0] * BLOCK_SIZE_BYTES
            for i in range(BLOCK_SIZE_BYTES):
                block[BLOCK_SIZE_BYTES - i - 1] = counter_value & 0xff
                counter_value >>= 8
            self._counter_value += 1
            return block

    with open('test_cases/test_aes_ctr_decrypt.txt', 'r') as f:
        for line in f:
            cipher_str, key_str, counter_str, plaintext_str = line.strip().split(';')

# Generated at 2022-06-12 16:26:48.098221
# Unit test for function inc
def test_inc():
    data1 = [10, 20]
    data2 = inc(data1)
    assert data1 == data1, "inc should have copied"
    assert data2 == [11, 20], "inc failed to increment"



# Generated at 2022-06-12 16:27:01.161659
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes import key_expansion

    key = bytes_to_intlist(compat_b64decode(b'qCqjKM+JkCYsYQzW1l8+vK9fPys5Knx2ywJw5mRvyyA='))
    encrypted_data = bytes_to_intlist(compat_b64decode(b'N8aVimJ+0KjrzZ/e/u8Jk/0Aj+uV7lxlw8uVvdCk1nE='))
    expanded_key = key_expansion(key)

    assert len(encrypted_data) % BLOCK_SIZE_BYTES == 0

    class Counter(object):
        def __init__(self):
            self.counter = 0


# Generated at 2022-06-12 16:27:06.821346
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = "Hello World"
    key = "0123456789abcdef"
    iv = "0123456789abcdef"

    encrypted_data = aes_cbc_encrypt(data, key, iv)
    encrypted_data = intlist_to_bytes(encrypted_data)
    assert encrypted_data == "n\xd4\x87\xc0\x0f\x20\x24\x4d\x1e"



# Generated at 2022-06-12 16:27:24.191495
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from .compat import compat_b64encode

    key = bytes_to_intlist(compat_b64decode(b'QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNk'))
    iv = bytes_to_intlist(compat_b64decode(b'QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNk'))
    data = bytes_to_intlist(compat_b64decode(b'QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNk'))
    result = aes_cbc_encrypt(data, key, iv)
    expected_result = bytes_to_intlist

# Generated at 2022-06-12 16:27:35.969846
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [177, 161, 244, 128, 84, 143, 225, 115, 63, 180, 3, 255, 107, 154, 212, 246, 138, 7, 110, 91, 112, 46, 34, 105, 47, 130, 203, 46, 122, 234, 64, 252]
    iv = [54, 84, 164, 147, 69, 90, 100, 97, 132, 220, 145, 74, 229, 228, 245, 188]
    data = [84, 104, 101, 32, 113, 117, 105, 99, 107, 32, 98, 114, 111, 119, 110, 32, 102, 111, 120, 32, 106, 117, 109, 112, 115, 32, 111, 118, 101, 114, 32, 116, 104, 101, 32, 108, 97, 122, 121, 32, 100, 111, 103]
    encrypted

# Generated at 2022-06-12 16:27:47.752936
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    import base64
    data = 'YELLOW SUBMARINE'
    key = bytes_to_intlist('YELLOW SUBMARINE')
    iv = bytes_to_intlist('\x00' * BLOCK_SIZE_BYTES)
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    
    encrypted_data_base64 = base64.b64encode(intlist_to_bytes(encrypted_data))
    expected_data_base64 = 'c4e54b8a2b67aefa640edac7d4eaf8caf7b4d3e4e4c2696e8e9bad9d87b527d7'
    assert(encrypted_data_base64 == expected_data_base64)



# Generated at 2022-06-12 16:27:56.278156
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Example from http://en.wikipedia.org/wiki/Block_cipher_mode_of_operation
    data = bytes_to_intlist(b'abcdefghijklmnop')
    key = bytes_to_intlist(b'2b7e151628aed2a6abf7158809cf4f3c')
    iv = bytes_to_intlist(b'000102030405060708090a0b0c0d0e0f')

    encrypted_data = aes_cbc_encrypt(data, key, iv)
    expected_result = '69c4e0d86a7b0430d8cdb78070b4c55a'
    assert (len(encrypted_data) == 16)

# Generated at 2022-06-12 16:28:05.537723
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist('123')
    key = bytes_to_intlist('abcdefghijklmnop')
    iv = bytes_to_intlist('1234567890123456')

    encrypted_data = aes_cbc_encrypt(data, key, iv)
    encrypted_data = intlist_to_bytes(encrypted_data)

    if encrypted_data == compat_b64decode('iU6YIz6FpU6AJU6iUFNJyQ=='):
        print(True)
    else:
        print(False)

# Generated at 2022-06-12 16:28:14.773917
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = [0] * BLOCK_SIZE_BYTES

    data = []
    for i in range(BLOCK_SIZE_BYTES):
        data.append(i)

    encrypted_data = aes_cbc_encrypt(data, key, iv)
    expected_encrypted_data = bytes_to_intlist(compat_b64decode('L/VJFP8Bmj7N/n1l7TOzfw=='))

    assert encrypted_data == expected_encrypted_data

# Generated at 2022-06-12 16:28:26.528156
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    input_data = [87, 111, 114, 108, 100, 32, 112, 97, 115, 115, 119, 111, 114, 100]
    assert aes_cbc_encrypt(input_data, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]) == \
           [53, 132, 110, 17, 195, 157, 33, 170, 48, 199, 181, 36, 161, 90, 208, 222, 120, 107, 154, 234, 149, 239, 1, 211, 217, 194, 227, 22, 169, 103, 163, 161, 226, 28, 138]



# Generated at 2022-06-12 16:28:38.636405
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b"YELLOW SUBMARINE")
    iv = bytes([0] * 16)
    plaintext = compat_b64decode("SSBhbSBhIGZhdm9yaXRlIHNvdXggcGllY2U=")
    plaintext = bytes_to_intlist(plaintext)

    encrypted_data = aes_cbc_encrypt(plaintext, key, iv)
    encrypted_data = intlist_to_bytes(encrypted_data)
    # Test vector from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    expected = compat_b64decode("w1IdFtYYMdhZD9hln0RxETxzNg8=")

# Generated at 2022-06-12 16:28:50.740743
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from os import urandom
    from .compat import compat_b64encode
    message = b'Hello World!'
    key = urandom(16)
    iv = urandom(16)
    cipher = aes_cbc_encrypt(bytes_to_intlist(message), bytes_to_intlist(key), bytes_to_intlist(iv))
    b64_result = compat_b64encode(intlist_to_bytes(cipher)).decode()
    assert b64_result == b'E8KjwCfZ/zDv283p5CS5/A=='


# Generated at 2022-06-12 16:29:02.486026
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from .aes_ctr import Counter
    import base64

    def _test(test_set):
        key = test_set['key']
        iv = test_set['iv']
        cleartext = bytes_to_intlist(
            base64.b64decode(compat_b64decode(test_set['cleartext'])))
        cipher = bytes_to_intlist(
            base64.b64decode(compat_b64decode(test_set['cipher'])))

        key = bytes_to_intlist(base64.b64decode(compat_b64decode(key)))
        iv = bytes_to_intlist(base64.b64decode(compat_b64decode(iv)))


# Generated at 2022-06-12 16:29:17.710354
# Unit test for function key_expansion
def test_key_expansion():
    key1 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    key2 = [0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5,
            0x62, 0xf8, 0xea, 0xd2, 0x52, 0x2c, 0x6b, 0x7b]

# Generated at 2022-06-12 16:29:29.386145
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00' * 16)

# Generated at 2022-06-12 16:29:41.570532
# Unit test for function key_expansion

# Generated at 2022-06-12 16:29:48.901968
# Unit test for function key_expansion

# Generated at 2022-06-12 16:30:01.539223
# Unit test for function key_expansion
def test_key_expansion():
    random = compat_b64decode('lkRJX9KjMG1d/3/q8eP/xg==')
    expanded = key_expansion(bytes_to_intlist(random))
    assert len(expanded) == 240

# Generated at 2022-06-12 16:30:11.022020
# Unit test for function key_expansion

# Generated at 2022-06-12 16:30:22.812552
# Unit test for function key_expansion
def test_key_expansion():
    class TestCase:
        def __init__(self, key, expected_result):
            self.key = key
            self.expected_result = expected_result


# Generated at 2022-06-12 16:30:30.155902
# Unit test for function key_expansion
def test_key_expansion():

    def assert_expansion(key, expected_expanded_key):
        expanded_key = key_expansion(bytes_to_intlist(key))

        assert expanded_key == bytes_to_intlist(expected_expanded_key)

    assert_expansion(
        compat_b64decode('Cji97P/S4uyG4d/Q2rr8ow=='),
        compat_b64decode('Cji97P/S4uyG4d/Q2rr8owM9YWYau0IkdU6xj0CrDu8='))

# Generated at 2022-06-12 16:30:42.924496
# Unit test for function key_expansion
def test_key_expansion():
    def test(key_data, result_data):
        assert key_expansion(key_data) == result_data

    key_data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    result_data = [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0]
    test(key_data, result_data)

    key_data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
   

# Generated at 2022-06-12 16:30:53.635013
# Unit test for function key_expansion
def test_key_expansion():
    from .test_data import KEY_EXPANSION_DATA

    for key_size_bytes, key, result in KEY_EXPANSION_DATA:
        print('testing: key_expansion(key={0})'.format(key))
        expanded_key = key_expansion([ord(c) for c in key])
        expanded_key_int = intlist_to_bytes(expanded_key)
        expanded_key_hex = expanded_key_int.encode('hex')
        expected_hex = result.encode('hex')
        if expanded_key_hex != expected_hex:
            print('key_expansion(key={0}) does not match!'.format(key))
            print('  expected: {0}'.format(expected_hex))

# Generated at 2022-06-12 16:31:09.808314
# Unit test for function key_expansion
def test_key_expansion():
    key_size_bytes = 16
    data = [0] * key_size_bytes
    key = [0x2b, 0x7e, 0x15, 0x16,
           0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88,
           0x09, 0xcf, 0x4f, 0x3c,
           ]

    ret = key_expansion(key)
    # expected result:
    # [0x2b, 0x7e, 0x15, 0x16,
    #  0x28, 0xae, 0xd2, 0xa6,
    #  0xab, 0xf7, 0x15, 0x88,
    #  0x09, 0xcf, 0x4f,

# Generated at 2022-06-12 16:31:21.525324
# Unit test for function key_expansion
def test_key_expansion():
    key1 = [0x2b,0x7e,0x15,0x16,0x28,0xae,0xd2,0xa6,0xab,0xf7,0x15,0x88,0x09,0xcf,0x4f,0x3c]
    key2 = [0x8e,0x73,0xb0,0xf7,0xda,0x0e,0x64,0x52,0xc8,0x10,0xf3,0x2b,0x80,0x90,0x79,0xe5,
            0x62,0xf8,0xea,0xd2,0x52,0x2c,0x6b,0x7b]

# Generated at 2022-06-12 16:31:26.974895
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode(b'gZP7VuP3xmKbaQy1lJy+/w=='))
    expanded_key =  key_expansion(key)
    print(expanded_key)
test_key_expansion()


# Generated at 2022-06-12 16:31:35.101178
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x0f, 0x15, 0x71, 0xc9, 0x47, 0xd9, 0xe8, 0x59, 0x0c, 0xb7, 0xad, 0xd6, 0xaf, 0x7f, 0x67, 0x98]

# Generated at 2022-06-12 16:31:47.306388
# Unit test for function key_expansion
def test_key_expansion():

    # AES-128
    key = [
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
        0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f
    ]

# Generated at 2022-06-12 16:31:55.441698
# Unit test for function key_expansion
def test_key_expansion():
    from .test_data import TEST_DATA
    for key_size_bytes in (16, 24, 32):
        for expanded_key_size_bytes in (176, 208, 240):
            for data, expected in TEST_DATA[('key_expansion', key_size_bytes, expanded_key_size_bytes)]:
                decoded_data = bytes_to_intlist(compat_b64decode(data))
                decoded_expected = bytes_to_intlist(compat_b64decode(expected))
                assert key_expansion(decoded_data) == decoded_expected



# Generated at 2022-06-12 16:32:06.247727
# Unit test for function key_expansion
def test_key_expansion():
    if 'key_expansion' in globals().keys():
        key = ''.join(map(chr, [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                                0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]))
        # AES-128

# Generated at 2022-06-12 16:32:16.403844
# Unit test for function key_expansion
def test_key_expansion():
    """
    Test key_expansion
    """
    key = bytes_to_intlist(b'6d86c82e7c8c1f9f9d44e96b13ce732f')
    assert (
        key_expansion(key) ==
        bytes_to_intlist(b'6d86c82e7c8c1f9f9d44e96b13ce732f2ed55f8c8a69c7fca0daf26b7a8b8c8615d9c71f1238725f7c8d4925b4a3f3cc4f4d8efc4b2d5b3e5dc6703f903280c')
    )


# Generated at 2022-06-12 16:32:27.750303
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:39.067810
# Unit test for function key_expansion
def test_key_expansion():  # pragma: no cover
    keys = [b'\x00' * 16, b'\x00' * 24, b'\x00' * 32]
    expected_keys = [
        b'\x00' * 176,
        b'\x00' * 208,
        b'\x00' * 240
    ]
    for i in range(3):
        key = keys[i]
        expected_key = expected_keys[i]
        expanded_key = key_expansion(bytes_to_intlist(key))
        expanded_key = intlist_to_bytes(expanded_key)
        print(expanded_key == expected_key)


# Generated at 2022-06-12 16:33:01.650488
# Unit test for function key_expansion

# Generated at 2022-06-12 16:33:13.742535
# Unit test for function key_expansion