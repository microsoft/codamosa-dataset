

# Generated at 2022-06-12 16:23:45.814440
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    cleartext = bytes_to_intlist(compat_b64decode('CxY9HsWnCxY9HsWn'))
    key = bytes_to_intlist(compat_b64decode('qJD4N4+jdZJ2eZhdfzqqjQ=='))
    iv = bytes_to_intlist(compat_b64decode('0mZgYb8QKjQFbZCe'))
    cipher = bytes_to_intlist(compat_b64decode('ZS8S0Pi1zRJhY00gFY9XqP4q4xjKcwQJF7tG8qrWV7vH'))

    result = aes_cbc_encrypt(cleartext, key, iv)

# Generated at 2022-06-12 16:23:54.812793
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b'123456789012345678901234567890123456789012345678901234567890')
    key = bytes_to_intlist(b'0123456789abcdef0123456789abcdef')
    iv = bytes_to_intlist(b'0123456789abcdef0123456789abcdef')
    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-12 16:24:06.251276
# Unit test for function aes_decrypt
def test_aes_decrypt():
  # key = 0x000102030405060708090a0b0c0d0e0f
  key_bytes = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'
  key_ints = bytes_to_intlist(key_bytes)
  
  # expanded_key = 0x2b7e151628aed2a6abf7158809cf4f3c762e716036b692546fceaa6c44dff7a7928e0db09222f0e86c817e3c1f86a7f60c066993ca3574669f13706fd2036a0b016

# Generated at 2022-06-12 16:24:17.020639
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b'hello world')
    key = bytes_to_intlist(b'\x00' * 16)
    iv = bytes_to_intlist(compat_b64decode(b'XKQ2oNaq3o3Zh3qqkyxI8w=='))

# Generated at 2022-06-12 16:24:27.425356
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    message = "Yellow Submarine"
    key = bytes_to_intlist(compat_b64decode(b'FQ1zM8iA/9XE38Ajxo43QA=='))
    iv = bytes_to_intlist(compat_b64decode(b'iRtGxB5JOXM8D4M4+4KGzw=='))
    result = aes_cbc_encrypt(bytes_to_intlist(message), key, iv)
    print(result)
    print(b' '.join(map(bytes, list(intlist_to_bytes(result)))))


# Generated at 2022-06-12 16:24:32.029266
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aescbc import aes_cbc_decrypt
    from .aes import aes_encrypt, key_expansion
    from .xor import xor

    data = bytes_to_intlist(b"Calling all station.")
    key = bytes_to_intlist(b"Yellow Submarine")
    iv = bytes_to_intlist(b"ABCDEFGHIJKLMNOP")

    edata = aes_cbc_decrypt(data, key, iv)
    counter = Counter()
    assert aes_ctr_decrypt(edata, key, counter) == data

    data = bytes_to_intlist(b"Calling all station. Calling all statio")
    ekey = key_expansion(key)
    edata = aes_encrypt(data, ekey)
    counter = Counter()

# Generated at 2022-06-12 16:24:42.400689
# Unit test for function aes_decrypt
def test_aes_decrypt():
    cipher = [0xe1, 0xc8, 0x31, 0x58, 0xae, 0xfd, 0x1d, 0x6e, 0x37, 0x8b, 0x22, 0xa2, 0x1a, 0x75, 0x04, 0x7b]

# Generated at 2022-06-12 16:24:50.531084
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
  iv = [0] * 16
  data_decrypt = aes_cbc_decrypt(bytes_to_intlist(compat_b64decode('VuGcZs+7Vq3Mh18kYdPpvw==')), bytes_to_intlist('hJ9HZWRnfZWGcZk1'), iv)
  assert intlist_to_bytes(data_decrypt) == b'i'



# Generated at 2022-06-12 16:25:02.975106
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = b'\x39\x25\x84\x1d\x02\xdc\x09\xfb\xdc\x11\x85\x97\x19\x6a\x0b\x32'
    key = b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c'
    iv = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'
    data = bytes_to_intlist(compat_b64decode(data))


# Generated at 2022-06-12 16:25:10.738177
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    test_case = '12345678'
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    test_cases = [test_case]

# Generated at 2022-06-12 16:25:21.654887
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # assert_equals('abcdefghijklmnop', aes_decrypt_text(str(b'zZJtbz7PwE2abJzCevyjXdAsY7tLUG3qTII7VZpzOmw\x03\x03\x03\x03'), 'Encyption', 16))
    pass


# Generated at 2022-06-12 16:25:26.354853
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(compat_b64decode('kT/grsZV7Q/8eWsWV7vNiz47m+YmRzk4='))
    expanded_key = key_expansion(data)


# Generated at 2022-06-12 16:25:37.266854
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    expanded_key = key_expansion(key)
    assert expanded_key == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] + [0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] + [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    counter

# Generated at 2022-06-12 16:25:49.290644
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Test with key size 16 byte
    plaintext = "This is a message to encrypt.\n"
    password = "hunter2"
    key_size_bytes = 16
    cipher = aes_encrypt_text(plaintext, password, key_size_bytes)
    decrypted_data = aes_decrypt_text(cipher, password, key_size_bytes)
    print(repr(decrypted_data))
    assert decrypted_data == plaintext

    # Test with key size 24 byte
    plaintext = "This is a message to encrypt.\n"
    password = "hunter2"
    key_size_bytes = 24
    cipher = aes_encrypt_text(plaintext, password, key_size_bytes)

# Generated at 2022-06-12 16:26:01.574382
# Unit test for function key_expansion
def test_key_expansion():
    print("test key_expansion")
    key = bytes_to_intlist(b"spqrstuvwxyzabcd")

# Generated at 2022-06-12 16:26:13.878465
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_cipher import aes_encrypt

    data = bytes_to_intlist('AE5C5F10C5B5D324B5A5D5F10D5A5F5A5D5C5A5B5D5F5C5E'.decode('hex'))
    key = bytes_to_intlist('A69F73CCA23A9AC5C8B567DC185A756E'.decode('hex'))
    encrypted = aes_encrypt(data, key)
    assert encrypted == bytes_to_intlist('EB92C9B9D8B8635B7F87D6B63A6ED318'.decode('hex'))

    class _Counter:
        def __init__(self, initial_value = 0):
            self.counter = initial_

# Generated at 2022-06-12 16:26:15.747789
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text("CgI8Cp8/aRc=", "Password", 16) == "This is a secret string."


# Generated at 2022-06-12 16:26:28.522230
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = bytes_to_intlist(compat_b64decode('Q28dVESv4e4GiKHGzL1jhA=='))

    ciphertext = bytes_to_intlist(
        compat_b64decode('KLpq3FqGBO7DFSgX8R4ljQ=='))

    class Counter(object):
        def __init__(self):
            self.counter = 0
        def next_value(self):
            self.counter += 1
            return bytes_to_intlist(
                compat_b64decode('aHN1CnENgNnaZQljOg=='))[:16]
    counter = Counter()

    assert aes_ctr_decrypt(ciphertext, key, counter) == \
        bytes_to_int

# Generated at 2022-06-12 16:26:40.658771
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'EBAjDg0a8yEa0QY90MWGvzjX4W0Z0jpHPGozPEGc527g7rif5C5Dza7pYtYgdgVm'
    password = 'test'

# Generated at 2022-06-12 16:26:48.518985
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0, 0, 0, 255]) == [0, 0, 1, 0]
    assert inc([0, 0, 255, 255]) == [0, 1, 0, 0]
    assert inc([0, 255, 255, 255]) == [1, 0, 0, 0]
    assert inc([255, 255, 255, 255]) == [0, 0, 0, 0]



# Generated at 2022-06-12 16:26:55.422851
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert b'0123456789ABCDEF' == aes_decrypt_text(
        'sMKS1fZwjKFLaQ6OQT6h0g', 'aes_encryption_password-2', 24)


# helper functions

# Generated at 2022-06-12 16:27:06.429007
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class FakeCounter(object):
        def __init__(self):
            self.i = 0

        def next_value(self):
            self.i += 1
            return [self.i] * 16

    data = bytes_to_intlist(compat_b64decode('YKU+CN6uqq7VwRb6uZ+VWM0D1fB7VGGxnqeoMbe5A5A='))
    key = bytes_to_intlist(compat_b64decode('z5i5Lzr0Km04msIQwR7+mA=='))
    counter = FakeCounter()

# Generated at 2022-06-12 16:27:12.287396
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Example taken from:
    # https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38a.pdf
    key = bytes_to_intlist(compat_b64decode(
        'YHgWpX9zF5i/RHV7ySJ85w=='))
    counter = Counter()
    counter.iv = bytes_to_intlist(compat_b64decode(
        'xEcwvjtCS/TtRZzR+EI8kQ=='))

# Generated at 2022-06-12 16:27:24.128290
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = '140b41b22a29beb4061bda66b6747e14'
    data = '4ca00ff4c898d61e1edbf1800618fb28'
    counter = Counter(
        intlist_to_bytes(
            bytes_to_intlist(compat_b64decode('YgYyr4DFbzAeJkpHtjPjt0A=='))))
    encrypted = aes_ctr_decrypt(
        bytes_to_intlist(compat_b64decode(data)),
        bytes_to_intlist(compat_b64decode(key)),
        counter
    )
    assert hexlify(intlist_to_bytes(encrypted)) == 'aed2a6d02541268e6e8690c1ee315a62'

# Generated at 2022-06-12 16:27:35.867672
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import binascii
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15,
           0x88, 0x09, 0xcf, 0x4f, 0x3c]
    key = bytes_to_intlist(key)
    data = [0x87, 0x4d, 0x61, 0x91, 0xb6, 0x20, 0xe3, 0x26, 0x1b, 0xef, 0x68,
            0x64, 0x99, 0x0d, 0xb6, 0xce]
    data = bytes_to_intlist(data)

# Generated at 2022-06-12 16:27:47.652855
# Unit test for function aes_decrypt_text

# Generated at 2022-06-12 16:27:56.214581
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text(
        'LQjf96xEG6QU1i6dWj6OZ+zK1E0lqXl3iT0yKLcxPwE=',
        'abc',
        16
    ) == b'hello world'
    assert aes_decrypt_text(
        'rpTlN6ZbU6uteLjdDsg2/XhJfCsQ2xBxmRmROB+8GdM=',
        'abc',
        24
    ) == b'hello world'

# Generated at 2022-06-12 16:28:02.538101
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """ Unit test for function aes_decrypt_text """
    password = 'mySecretPassword'
    cleartext = 'This is only a test!'
    crypted_text = aes_encrypt_text(cleartext, password, 16)
    decrypted_text = aes_decrypt_text(crypted_text, password, 16)

    assert cleartext == decrypted_text



# Generated at 2022-06-12 16:28:14.732520
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import unittest

    # Class that implements counter.next_value() function
    class Counter(object):
        def __init__(self):
            self.counter = 0

        def next_value(self):
            self.counter += 1
            return [self.counter] * BLOCK_SIZE_BYTES

    counter = Counter()
    data = bytes_to_intlist('000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f')
    expanded_key = key_expansion([0] * 32)
    decrypted_data = aes_ctr_decrypt(data, expanded_key, counter)

# Generated at 2022-06-12 16:28:20.855451
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class TestCounter(object):
        def __init__(self):
            self.counter = 0
        def next_value(self):
            self.counter += 1
            return [0] * 16
    
    ctr = TestCounter()
    ctr.next_value()
    # test with 1 block (16byte)
    block_input = bytes_to_intlist("1af38c2dc2b96ffdd86694092341bc04")
    expected = aes_ctr_decrypt(block_input, [1]*16, ctr)
    assert expected == bytes_to_intlist("1af38c2dc2b96ffdd86694092341bc04")
    # test with 2 blocks (32byte)

# Generated at 2022-06-12 16:28:35.794175
# Unit test for function key_expansion

# Generated at 2022-06-12 16:28:44.008989
# Unit test for function key_expansion

# Generated at 2022-06-12 16:28:57.100061
# Unit test for function key_expansion
def test_key_expansion():
    def get_key_schedule(key):
        """
        This is the key schedule as it's written in the spec

        @see http://csrc.nist.gov/archive/aes/rijndael/Rijndael-ammended.pdf
        """

# Generated at 2022-06-12 16:29:06.904856
# Unit test for function key_expansion
def test_key_expansion():
    data1 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    data2 = [0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5, 0x62, 0xf8, 0xea, 0xd2, 0x52, 0x2c, 0x6b, 0x7b]

# Generated at 2022-06-12 16:29:19.365560
# Unit test for function key_expansion

# Generated at 2022-06-12 16:29:32.524324
# Unit test for function key_expansion
def test_key_expansion():
    print('*** Test key_expansion function ***')
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    res = key_expansion(key)
    print(res)

# Generated at 2022-06-12 16:29:43.273154
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')

# Generated at 2022-06-12 16:29:49.621007
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(compat_b64decode('zyw1/QQV7/f9+/n1/bMtMZ/PJg+aH4/Pw=='))
    expanded_key = key_expansion(data)

    assert len(expanded_key) == 240

# Generated at 2022-06-12 16:30:02.277701
# Unit test for function key_expansion
def test_key_expansion():
    data=[0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    print(key_expansion(data))
    # data=[0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17]
    # print(key_exp

# Generated at 2022-06-12 16:30:11.509184
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    key = key_expansion(key)


# Generated at 2022-06-12 16:30:25.237669
# Unit test for function key_expansion
def test_key_expansion():
    # Test vectors from FIPS-197
    assert (key_expansion(bytes_to_intlist(compat_b64decode(
        b'gI0GAILBdu7pI7AkU3/GsnyuH0LWgdwJ9g98dD7QHgQ='))) ==
        bytes_to_intlist(compat_b64decode(
        b'cYK7XPiEsMqXFb9r+Pz5fjGtQ5z5JxDtC+RMKj1Ykqc3EWEnJkbjKcEoLz+Fw==')))

# Generated at 2022-06-12 16:30:36.607432
# Unit test for function key_expansion
def test_key_expansion():
    '''
    AES 256-bit test vector for function key_expansion
    '''
    key = bytes_to_intlist('603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4')

# Generated at 2022-06-12 16:30:48.762535
# Unit test for function key_expansion

# Generated at 2022-06-12 16:30:56.918158
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:08.835235
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:20.492990
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:31.751632
# Unit test for function key_expansion
def test_key_expansion():
    unit_test_key_ex = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    unit_test_key_ex = key_expansion(unit_test_key_ex)


# Generated at 2022-06-12 16:31:44.874832
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:55.230429
# Unit test for function key_expansion
def test_key_expansion():
    key = [
        0x2B, 0x7E, 0x15, 0x16,
        0x28, 0xAE, 0xD2, 0xA6,
        0xAB, 0xF7, 0x15, 0x88,
        0x09, 0xCF, 0x4F, 0x3C
    ]

# Generated at 2022-06-12 16:32:05.833217
# Unit test for function key_expansion
def test_key_expansion():
    KEYSIZE = 16
    KEY = [0] * KEYSIZE
    for x in range(KEYSIZE):
        KEY[x] = x
    expanded_key = key_expansion(KEY)
    assert len(expanded_key) == 176
    assert expanded_key[:16] == KEY

    KEYSIZE = 24
    KEY = [0] * KEYSIZE
    for x in range(KEYSIZE):
        KEY[x] = x
    expanded_key = key_expansion(KEY)
    assert len(expanded_key) == 208
    assert expanded_key[:24] == KEY

    KEYSIZE = 32
    KEY = [0] * KEYSIZE
    for x in range(KEYSIZE):
        KEY[x] = x
    expanded_key = key_expansion(KEY)

# Generated at 2022-06-12 16:32:18.671614
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]

# Generated at 2022-06-12 16:32:31.221917
# Unit test for function key_expansion
def test_key_expansion():
    # from https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf
    # Appendix C
    key = bytes_to_intlist(compat_b64decode('AQIDBAUGBwgJ'))

# Generated at 2022-06-12 16:32:33.992746
# Unit test for function key_expansion
def test_key_expansion():
    for key_size_bytes in (16, 24, 32):
        key = range(key_size_bytes)
        key_expansion(key)



# Generated at 2022-06-12 16:32:43.664113
# Unit test for function key_expansion
def test_key_expansion():
    key1 = bytes_to_intlist(compat_b64decode('gI0GAILBdukQOQI='))
    expanded_key1 = bytes_to_intlist(compat_b64decode('gI0GAILBdukQOQI6eI0GAILBdukQOQI6gI0GAILBdukQOQI6'))
    key2 = bytes_to_intlist(compat_b64decode('EqQzUIjyFq/8L9nSVzXYpvBHhV0j8AnT'))

# Generated at 2022-06-12 16:32:55.719894
# Unit test for function key_expansion
def test_key_expansion():
    # AES key of size 16 bytes
    key = bytes_to_intlist(compat_b64decode('hRIuY/PjXdR5xBJMZmtsAg=='))
    expanded_key = key_expansion(key)


# Generated at 2022-06-12 16:33:06.788642
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(compat_b64decode('qQnl1N4j9qk4P4jyYHwtg=='))
    x = key_expansion(data)
    print(x)

# Generated at 2022-06-12 16:33:18.661383
# Unit test for function key_expansion
def test_key_expansion():
    """
    Test function key_expansion against official examples
    """
    key = intlist_to_bytes([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c])