

# Generated at 2022-06-12 16:23:47.310751
# Unit test for function aes_decrypt
def test_aes_decrypt():
    #test_key = [43, 126, 21, 22, 40, 174, 210, 166, 171, 247, 21, 136, 9, 207, 79, 60, ]
    #test_data = [10, 40, 31, 152, 207, 110, 157, 51, 214, 231, 48, 92, 216, 21, 228, 135, ]

    test_key = [43, 126, 21, 22, 40, 174, 210, 166, 171, 247, 21, 136, 9, 207, 79, 60, ]
    test_data = [10, 40, 31, 152, 207, 110, 157, 51, 214, 231, 48, 92, 216, 21, 228, 135, ]
    expanded_key = key_expansion(test_key)

    data2 = aes_decrypt(test_data, expanded_key)

# Generated at 2022-06-12 16:23:56.214438
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = [59, 166, 38, 157, 97, 135, 176, 39, 235, 118, 24, 250, 96, 226, 31, 126]

# Generated at 2022-06-12 16:24:08.273307
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    plain = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]
    cipher = aes_encrypt(plain, key)

# Generated at 2022-06-12 16:24:17.296698
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist('1234567890123456')
    key = bytes_to_intlist('000102030405060708090A0B0C0D0E0F')
    IV = bytes_to_intlist('FEDCBA9876543210')

    encrypted_data = aes_cbc_encrypt(data, key, IV)
    assert intlist_to_bytes(encrypted_data) == '\x8e\x3c\x07\x6f\xb6\x19\xe0\x46\x2c\x54\x82\x4a\x4f\x4e\x4b\x4c'


# Generated at 2022-06-12 16:24:30.199861
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist('Thats my Kung Fu')
    data = bytes_to_intlist('Two One Nine Two')
    iv = bytes_to_intlist('thats not a pbkdf2')

    res = aes_cbc_decrypt(data, key, iv)
    assert intlist_to_bytes(res) == b'\xaa\xf4\xc6\x1d\xdc\xc5\xe8\xa2\xda\xbe\xde\x0f\x15\xaf\xd9\x22\x75\x06\x97\xc9\x7f\x6b\x55\xf3\x7a\x19\x52\xb2\x7a\x8a\x5e'



# Generated at 2022-06-12 16:24:37.078180
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    from .utils import bytes_to_hex
    data = bytes_to_intlist(b"hello worl")
    key = bytes_to_intlist(b"YELLOW SUBMARINE")
    iv = [0] * 16

    result = aes_cbc_encrypt(data, key, iv)
    assert bytes_to_hex(intlist_to_bytes(result)) == "9c1a7cc17f4656f88b47d8df64c09cb5"


# Generated at 2022-06-12 16:24:39.815588
# Unit test for function inc
def test_inc():
    data = [1,3,5,7]
    inc(data)
    assert data == [1,3,5,8]
    data = [0xFF,0xFF,0xFF,0xFF]
    inc(data)
    assert data == [0,0,0,0]
    


# Generated at 2022-06-12 16:24:52.192131
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """
    aes_cbc_decrypt
    """
    key = [0x2, 0x3, 0x5, 0x7, 0xb, 0xd, 0x11, 0x13, 0x17, 0x1d, 0x1f, 0x25, 0x29, 0x2b, 0x2f, 0x35]
    iv = [0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0]

# Generated at 2022-06-12 16:25:04.345933
# Unit test for function aes_encrypt

# Generated at 2022-06-12 16:25:11.461998
# Unit test for function aes_decrypt
def test_aes_decrypt():
    pass

    # Test the data that OpenSSL outputs
    # openssl enc -aes-128-ecb -d -in /tmp/aescrypt -K bb7a0d3e3b7e17ab25a937e78dcc1c99 -nosalt
    # test_data = [225, 254, 49, 237, 137, 254, 175, 31, 42, 51, 196, 19, 121, 49, 65, 150]
    # result_should_be = ['p', 'o', 'e', 't', ' ', 'i', 'n', ' ', 'g', 'h', 'o', 'e', 's', 't', 'e', ' ', 'v', 'l', 'a', 'a', 'g', '.']
    # result = bytes_to_intlist(aes_decrypt(test_data

# Generated at 2022-06-12 16:25:26.811009
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, iv):
            self.iv = iv

        def next_value(self):
            aes_ctr_decrypt_test.counter_value += 1
            return self.iv + [aes_ctr_decrypt_test.counter_value & 0xFF] * 8

    def aes_ctr_decrypt_test(cipher, key, iv):
        aes_ctr_decrypt_test.counter_value = 0
        return aes_ctr_decrypt(cipher, key, Counter(iv))


# Generated at 2022-06-12 16:25:33.696078
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    decrypted_text = aes_decrypt_text("QVOHQy50A0V5r5D5G5V7AMgCvU+J6UwF6UuVQz8+6q3QSLh+CJjKW+b8EUvZuVhbwGFnJzW7+8=", "zsO1fYXpIoEa8gZs", 16)
    assert(decrypted_text == "it's a secret to everyone".encode("utf-8"))



# Generated at 2022-06-12 16:25:40.765801
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = aes_decrypt_text(
        'Q2Nz9XVgMk8bIeVm+sCElJ1GwPI2m0ykvtV6UAXpL9g=',
        'password123',
        BLOCK_SIZE_BYTES)
    assert data == b"\x03\x02\x01\x00\x05\x04\x03\x02"



# Generated at 2022-06-12 16:25:47.520473
# Unit test for function key_expansion
def test_key_expansion():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    result = key_expansion(data)

# Generated at 2022-06-12 16:25:59.154941
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    cipher = 'QV7Q2e+IuV7o8nPuYfkRSYa1G+Zw8wDd+mb7VQ2+NDuA7V8oPGJ5agBMVd+vqH3t+8='
    decrypted_data = aes_ctr_decrypt(
        bytes_to_intlist(compat_b64decode(cipher)),
        bytes_to_intlist(b'2NUlpTJBz1C6hNuBmSi8Zm0uk6O7f6G1'),
        AESCounter(
            bytes_to_intlist(b'\x00' * BLOCK_SIZE_BYTES)
        )
    )

# Generated at 2022-06-12 16:26:11.628585
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class DummyCounter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value = [sum(x) for x in zip(self.value, [1] * len(self.value))]
            return self.value[:]

    # Test vectors from Ali Babar, "Implementing AES Counter mode in Go",
    # http://blog.golang.org/go-crypto-cheat-sheet
    # key = bytes_to_intlist('63636363636363636363636363636363')
    # iv = bytes_to_intlist('0000000000000000'),
    # plaintext = bytes_to_intlist('63636363636363636363636363636363')

    # key = bytes_to_intlist

# Generated at 2022-06-12 16:26:18.536264
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    password = 'Hello World!'
    key_size_bytes = 16
    cipher = aes_encrypt(bytes_to_intlist(password.encode('utf-8')), key_expansion(bytes_to_intlist('abcdefghijklmnop')))
    cipher = intlist_to_bytes(cipher)
    cipher = compat_b64encode(cipher)
    plaintext = aes_decrypt_text(cipher, password, key_size_bytes)

    assert plaintext == password.encode('utf-8')

# Generated at 2022-06-12 16:26:32.014645
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    def test(counter, data, key, expected):
        output = aes_ctr_decrypt(data, key, counter)
        assert output == expected

    counter = Counter("AAAAAAAAP////8AAAAAA")
    data = "AAAA"
    key = "1234567890123456"
    expected = "A836"
    test(counter, data, key, expected)

    counter = Counter("AAAAAAAAP////8AAAAAA")
    data = "AAAABBBB"
    key = "1234567890123456"
    expected = "A836B2A0"
    test(counter, data, key, expected)

    counter = Counter("AAAAAAAAP////8AAAAAA")
    data = "AAAABBBBCCCCDDDD"
    key = "1234567890123456"

# Generated at 2022-06-12 16:26:43.064253
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-12 16:26:56.803268
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    def bin2hex(b):
        return ''.join('%02x' % x for x in b)

    message = b'{2}This is an example of a message that was encrypted with the AES-256 counter mode.{2}'
    password = 'password'

# Generated at 2022-06-12 16:27:11.790563
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = [43, 126, 21, 22, 40, 174, 210, 166, 171, 247, 21, 136, 9, 207, 79, 60]
    cipher = [227, 176, 196, 66, 152, 252, 28, 20, 154, 251, 244, 200, 153, 111, 185, 36,
              39, 174, 65, 228, 100, 155, 147, 76, 164, 149, 153, 27, 120, 82, 184, 85]
    counter = CounterBlock(initial_value=0)
    decrypted = aes_ctr_decrypt(cipher, key, counter)

# Generated at 2022-06-12 16:27:24.081524
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = [0x69, 0x20, 0xe2, 0x99, 0xa5, 0x20, 0x2a, 0x6d, 0x65, 0x6e, 0x63, 0x68, 0x69, 0x74, 0x6f, 0x2a]
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    counter = Counter(init_value=0)
    expected = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-12 16:27:27.937630
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    text = 'kHZz9WgRnDlzHr72E2bLc8i3Aoc='
    password = 'password'
    decrypted = aes_decrypt_text(text, password, 16)
    assert decrypted == 'Test'



# Generated at 2022-06-12 16:27:40.174273
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter():
        def __init__(self, initial_value):
            self.counter = initial_value

        def next_value(self):
            self.counter += 1
            return self.counter
    # initial_value = bytes_to_intlist(compat_b64decode('AAAAAAAAAAAAAAAA'))
    # counter = Counter(initial_value)
    # print(counter.next_value())
    # print(counter.next_value())
    # print(counter.next_value())
    # 3
    # 4
    # 5
    # encrypted = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ

# Generated at 2022-06-12 16:27:51.263149
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, offset):
            self._offset = offset
        def next_value(self):
            self._offset += 1
            return [self._offset] * BLOCK_SIZE_BYTES
    # Test vectors
    key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

# Generated at 2022-06-12 16:28:00.514542
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    decrypted_data = aes_decrypt_text(
        'uV7gLM+Fc5X9wtEmta6UgW6U8Z6l+b6UWN3qUm5x5Q8=', 'password', 24)
    decrypted_data = decrypted_data.decode('latin-1')  # because there are some non-utf-8 bytes
    assert decrypted_data == ('Arbitrary data can be encrypted with AES-CTR. This can e.g. be '
                              + 'done with the CryptoJS library (see code example on website).'
                              + 'This decryption function should work with any key size.')
# end of Unit test for function aes_decrypt_text



# Generated at 2022-06-12 16:28:13.221271
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Language: Python
    # Python version: 2.7.6
    # Version: 1.0
    # Author: jcgregorio
    # Website: https://github.com/pyca/pyopenssl
    #
    # OpenSSL 1.0.1f 6 Jan 2014 (Library: OpenSSL 1.0.1g 7 Apr 2014)
    import os
    import ctypes
    import binascii
    from ctypes import c_char_p, c_int, c_void_p, POINTER, pointer
    from ctypes.util import find_library

    # Cipher
    AES_ENCRYPT = 1
    AES_DECRYPT = 0
    # Result codes
    AES_OK = 0
    AES_BAD_KEY_INSTANCE = -1
    AES_BAD_KEY_MAT = -2
   

# Generated at 2022-06-12 16:28:23.368600
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    encrypted_data = 'f20bdba6ff29eed7b046d1df9fb7000058b1ffb4210a580f748b4ac714c001bd4a61044426fb515dad3f21f18aa577c0bdf302936266926ff37dbf7035d5eeb4'
    key = '36f18357be4dbd77f050515c73fcf9f2'
    counter = Counter()

    decrypted_data = aes_ctr_decrypt(bytes_to_intlist(compat_b64decode(encrypted_data)),
                                     bytes_to_intlist(compat_b64decode(key)),
                                     counter)
    assert intlist_to_bytes(decrypted_data) == b'foo'


# Generated at 2022-06-12 16:28:36.288663
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Example key and initial counter
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    counter = Counter(bytes_to_intlist(b'\x00' * 8))

    # Example cipher

# Generated at 2022-06-12 16:28:44.285086
# Unit test for function key_expansion
def test_key_expansion():
    import binascii


# Generated at 2022-06-12 16:29:35.728526
# Unit test for function key_expansion
def test_key_expansion():
    assert bytes_to_intlist(compat_b64decode('ZbdEir8xWtvJhv1nEytXge+R1sHsW4oOS4q3nMtT+a8=')) == key_expansion([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])
    assert bytes_to_intlist(compat_b64decode('ZbdEir8xWtvJhv1nEytXge+R1sHsW4oOS4q3nMtT+a8=')[0:16]) == key_expansion([1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1])
    assert bytes_

# Generated at 2022-06-12 16:29:45.469132
# Unit test for function key_expansion

# Generated at 2022-06-12 16:29:57.844866
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')

# Generated at 2022-06-12 16:30:08.686616
# Unit test for function key_expansion
def test_key_expansion():
    def test_case(key):
        key = bytes_to_intlist(compat_b64decode(key))
        expanded_key = key_expansion(key)
        return intlist_to_bytes(expanded_key).encode('hex')

# Generated at 2022-06-12 16:30:20.748492
# Unit test for function key_expansion
def test_key_expansion():
    assert key_expansion(bytes_to_intlist(compat_b64decode('g83vxwr1vMyZj+oafIfDdQ=='))) == \
        bytes_to_intlist(compat_b64decode('g83vxwr1vMyZj+oafIfDdU6FbW8YXmC5d5m0Z0/+zGWQk5GdHhB0hcg=='))

# Generated at 2022-06-12 16:30:29.058439
# Unit test for function key_expansion

# Generated at 2022-06-12 16:30:42.089192
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('Dm4l4Dl4m8zy6/BkH7i3/Q=='))

# Generated at 2022-06-12 16:30:53.124976
# Unit test for function key_expansion
def test_key_expansion():
    # Example from https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf#page=28
    assert key_expansion(bytes_to_intlist(compat_b64decode(b'2b7e151628aed2a6abf7158809cf4f3c'))) == bytes_to_intlist(compat_b64decode(b'2b7e151628aed2a6abf7158809cf4f3c7c9b9e64274f23c61e6d88f6241719c0'))

# Generated at 2022-06-12 16:31:05.510241
# Unit test for function key_expansion
def test_key_expansion():
    key128 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    key192 = [0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5, 0x62, 0xf8, 0xea, 0xd2, 0x52, 0x2c, 0x6b, 0x7b]

# Generated at 2022-06-12 16:31:16.969388
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
           0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
           0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
           0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f]

# Generated at 2022-06-12 16:31:32.661416
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:45.657795
# Unit test for function key_expansion
def test_key_expansion():
    key1 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    key2 = [0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5,
            0x62, 0xf8, 0xea, 0xd2, 0x52, 0x2c, 0x6b, 0x7b]

# Generated at 2022-06-12 16:31:55.946228
# Unit test for function key_expansion
def test_key_expansion():
    key = [ 0x54,0x68,0x61,0x74,0x73,0x20,0x6D,0x79,0x20,0x4B,0x75,0x6E,0x67,0x20,0x46,0x75 ]

# Generated at 2022-06-12 16:32:06.820698
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:16.751911
# Unit test for function key_expansion
def test_key_expansion():
    print('Testing key_expansion')
    key = bytes_to_intlist(compat_b64decode(b"kPH+bIxk5D2deZiIxcaaaA=="))

# Generated at 2022-06-12 16:32:23.675451
# Unit test for function key_expansion
def test_key_expansion():
    success = True
    for key_size_bytes in [16, 24, 32]:
        key = [1] * key_size_bytes
        expected_key = []
        for block_idx in range(key_size_bytes // 4 + 7):
            if block_idx == 0:
                expected_key += key
            elif block_idx == 4:
                temp = expected_key[-4:]
                temp = sub_bytes(temp)
                expected_key += expected_key[-key_size_bytes:4-key_size_bytes] + temp
            else:
                temp = expected_key[-4:]
                expected_key += expected_key[-key_size_bytes:4-key_size_bytes] + temp

        expanded_key = key_expansion(key)

# Generated at 2022-06-12 16:32:35.670354
# Unit test for function key_expansion
def test_key_expansion():
    # http://csrc.nist.gov/groups/STM/cavp/documents/aes/KAT_AES.zip
    key = bytes_to_intlist(compat_b64decode('GQPU/iDmq49qnI/Cf8ZHnF/fSgI2/jnX9/H4B4aa4E='))

# Generated at 2022-06-12 16:32:44.440431
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('hyXUcKj+8dRJZcYpZzMjqQ=='))
    expanded_key = bytes_to_intlist(compat_b64decode(
        'hyXUcKj+8dRJZcYpZzMjqSvJ8WG+w/YzLmxj4/bQe8mkJtAENHsK9O89wdqcWq+M2LJwAvoCeBvnUGWSuI8bJ1fBX9yg+vfSsDp8gOLzwUrOMtL2v4+W4ePc+tFS9XsJQ=='))
    assert key_expansion(key) == expanded_key



# Generated at 2022-06-12 16:32:56.934325
# Unit test for function key_expansion
def test_key_expansion():
    intlist_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:33:07.345626
# Unit test for function key_expansion