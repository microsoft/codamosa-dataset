

# Generated at 2022-06-12 16:23:47.787212
# Unit test for function aes_decrypt
def test_aes_decrypt():
    data        = [0x32, 0x88, 0x31, 0xe0, 0x43, 0x5a, 0x31, 0x37, 0xf6, 0x30, 0x98, 0x07, 0xa8, 0x8d, 0xa2, 0x34]

# Generated at 2022-06-12 16:23:56.651101
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    cipher = [0x3a, 0xd7, 0x7b, 0xb4, 0x0d, 0x7a, 0x36, 0x60, 0xa8, 0x9e, 0xca, 0xf3, 0x24, 0x66, 0xef, 0x97]

# Generated at 2022-06-12 16:24:08.683741
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():

    data = intlist_to_bytes(aes_cbc_encrypt(bytes_to_intlist('test123'),
                                            bytes_to_intlist('test123test1234'),
                                            bytes_to_intlist('1234567890123456')))
    password = 'test123'

    decrypt_test_cases = [
        {
            'description': '128-Bit',
            'key_size_bytes': 16,
            'expected': 'test123'
        },
        {
            'description': '192-Bit',
            'key_size_bytes': 24,
            'expected': 'test123'
        },
        {
            'description': '256-Bit',
            'key_size_bytes': 32,
            'expected': 'test123'
        },
    ]


# Generated at 2022-06-12 16:24:15.102279
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'ZtQDnJT46fGaYKd9nOKnt+xz/Afk/JbQz+ZwN3q/Cg=='
    password = 'Password'

    key_size_bytes_list = [16, 24, 32]
    for key_size_bytes in key_size_bytes_list:
        assert aes_decrypt_text(data, password, key_size_bytes) == b'Text'



# Generated at 2022-06-12 16:24:22.007115
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    """
    Test for function `aes_ctr_decrypt`,
    copied from:
    https://gist.github.com/pwang/0f7d4f3ee4ad4f00dd8c
    """
    data = bytes_to_intlist(
        compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(
        compat_b64decode('YELLOW SUBMARINE'))
    counter = StreamCounter()


# Generated at 2022-06-12 16:24:30.756804
# Unit test for function aes_decrypt
def test_aes_decrypt():
    plaintext = intlist_to_bytes(aes_decrypt(aes_encrypt(bytes_to_intlist(b'abcdefghijklmnop'), key_expansion(bytes_to_intlist(b'foobarfoobarfoobar'))), key_expansion(bytes_to_intlist(b'foobarfoobarfoobar'))))

# Generated at 2022-06-12 16:24:41.332259
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist('YELLOW SUBMARINE')
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-12 16:24:54.576418
# Unit test for function aes_encrypt
def test_aes_encrypt():
    #-------------------------------------------------------------------
    # Test cases for aes_encrypt
    #-------------------------------------------------------------------
    print('\nBegin test cases for aes_encrypt\n')
    # Let us test the function aes_encrypt

    # AES-128 encrypt
    # https://csrc.nist.gov/csrc/media/publications/fips/197/final/documents/fips-197.pdf
    # Appendix C
    data = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]

# Generated at 2022-06-12 16:25:06.459692
# Unit test for function aes_encrypt

# Generated at 2022-06-12 16:25:17.468875
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Test 1
    data = bytes_to_intlist("L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==".encode('utf-8'))
    key = bytes_to_intlist("YELLOW SUBMARINE".encode('utf-8'))
    counter = Counter(0)
    plaintext = aes_ctr_decrypt(data, key, counter)
    plaintext = intlist_to_bytes(plaintext).decode('utf-8')
    print(plaintext)
    assert plaintext == """Yo, VIP Let's kick it Ice, Ice, baby Ice, Ice, baby """



# Generated at 2022-06-12 16:25:30.535997
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():

    class Counter(object):
        def __init__(self, initial_value):
            self._value = initial_value
        def next_value(self):
            self._value += 1
            return self._value

    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:25:43.285716
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:25:53.185137
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:26:06.216813
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytes_to_intlist(compat_b64decode(b'CRIwqt4+szDbqkNY+I0qbDe3LQz0wiw0SuxBQtAM5TDdMbjCMD/venUDW9BL'))

# Generated at 2022-06-12 16:26:17.181021
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_cipher import aes_encrypt
    from .counters import Counter

    def bytes_to_hex(arr):
        return ''.join(format(x, '02x') for x in arr)

    data = bytes_to_intlist(compat_b64decode(
        'XLI7Vj0Tb2Qx7cwaABwTfI0i+y0jD1B9u'
        'V7q3JZW0PxzUaHslU1BEvU6yfU6RcF6I'))

# Generated at 2022-06-12 16:26:30.646531
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:26:33.842679
# Unit test for function key_expansion
def test_key_expansion():
    assert b'@\xfd\x84\x8f\xba"\xc8\xba\xd8\x93o{\x9b\x91\x8cO\xd6\x89' == intlist_to_bytes(
        key_expansion(bytes_to_intlist(compat_b64decode('gZwQIQjh0jhN17wDnjbdgg=='))))



# Generated at 2022-06-12 16:26:44.191681
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    Decryption_result = "Wir sind die Guten. Wir wollen die Welt retten. Wir wissen nur nicht wie."

# Generated at 2022-06-12 16:26:57.501098
# Unit test for function key_expansion
def test_key_expansion():
    data = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'

# Generated at 2022-06-12 16:27:07.589978
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, initial_value):
            self._counter = initial_value[:]

        def next_value(self):
            for i in range(len(self._counter) - 1, -1, -1):
                self._counter[i] += 1
                if self._counter[i] != 256:
                    break
                self._counter[i] = 0
            return self._counter


# Generated at 2022-06-12 16:27:25.445983
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
	cipher = b'26439400f948c0b9a24d0a859882d499'
	key = b'000102030405060708090a0b0c0d0e0f'
	data = b'6bc1bee22e409f96e93d7e117393172a'
	assert(aes_ctr_decrypt(bytes_to_intlist(compat_b64decode(cipher)), bytes_to_intlist(compat_b64decode(key)), Counter(0)) == bytes_to_intlist(compat_b64decode(data)))
	cipher = b'e0e518f67ec09cdb61ac2d34a05a3209'

# Generated at 2022-06-12 16:27:37.041097
# Unit test for function aes_decrypt_text

# Generated at 2022-06-12 16:27:48.888412
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = bytes_to_intlist(
        compat_b64decode('541A87F1F78D6E4AC4B3EFF8B5B5BF9D')
    )
    key = bytes_to_intlist(
        compat_b64decode('8A2500870C918D25DF699D2D6A805C6A')
    )

# Generated at 2022-06-12 16:27:56.882634
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .crypto import Counter, aes_cbc_encrypt, aes_ecb_encrypt
    import binascii

    for key_len in [16, 24, 32]:
        key = [1] * key_len
        data = [2] * 16
        iv = [3] * 16
        expanded_key = key_expansion(key)
        ecb_encrypted = aes_ecb_encrypt(iv, expanded_key)
        cbc_encrypted = aes_cbc_encrypt(data, key, iv)
        assert data == aes_cbc_decrypt(cbc_encrypted, key, iv)
        assert ecb_encrypted == aes_cbc_decrypt(iv, key, iv)


# Generated at 2022-06-12 16:28:09.337641
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import json
    import re
    import unittest
    import sys

    class Counter(object):

        def __init__(self, initval=0):
            self.val = initval

        def next_value(self):
            self.val += 1
            return bytes_to_intlist([(self.val >> 24) & 0xFF, (self.val >> 16) & 0xFF, (self.val >> 8) & 0xFF, (self.val) & 0xFF])

    class TestAES(unittest.TestCase):

        def test_counter(self):
            # Test counter increments
            counter = Counter()
            self.assertEqual(counter.next_value(), [0,0,0,1])
            self.assertEqual(counter.next_value(), [0,0,0,2])

# Generated at 2022-06-12 16:28:18.782296
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text(
        'A/pOb/zgjwR/aHxjT79bAQ==',
        'Test',
        16) == 'Test'.encode('utf-8')

    assert aes_decrypt_text(
        'Zp8Kj9cgUb1lyjK5h5wP+iiSxSjGln4cYKj+LZ8nzv4=',
        'Correct horse battery staple',
        16) == 'Correct horse battery staple'.encode('utf-8')


# Generated at 2022-06-12 16:28:31.940943
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, num):
            self.num = num

        def next_value(self):
            self.num += 1
            return self.num
    raw_data = b'\x0f\x1e\x2d\x3c\x4b\x5a\x69\x78\x87\x96\xa5\xb4\xc3\xd2\xe1\xf0'
    encrypted_data = b'\xd4\x1d\x8c\xd9\x8f\x00\xb2\x04\xe9\x80\x09\x98\xec\xf8\x42\x7e'

# Generated at 2022-06-12 16:28:41.964434
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes import AES_BLOCK_SIZE_BYTES

    key = [80, 104, 117, 119, 86, 71, 99, 88, 65, 100, 76, 66,
           104, 77, 68, 81, 87, 49, 99, 104, 76, 67, 74, 89, 72,
           100, 81, 119, 82, 90, 66, 89]
    cipher_text = [221, 161, 217, 106, 233, 169, 110, 205, 14,
                   136, 225, 129, 251, 223, 114, 144]
    counter = AES_Ctr_Counter(start=0)

    encrypted = aes_ctr_decrypt(cipher_text, key, counter)

# Generated at 2022-06-12 16:28:54.603903
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:28:58.366280
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = [0] * 16
    key = [0] * 16
    data = [0] * 16

    assert aes_cbc_decrypt(data, key, iv) == data



# Generated at 2022-06-12 16:29:08.254922
# Unit test for function inc
def test_inc():
    assert inc([0xFF, 0xFF, 0xFF, 0xFF]) == [0x00, 0x00, 0x00, 0x00]
    assert inc([0xFF, 0xFF, 0xFF, 0x00]) == [0x00, 0x00, 0x00, 0x01]
    assert inc([0xFF, 0x00, 0x00, 0xFF]) == [0x00, 0x00, 0x01, 0x00]



# Generated at 2022-06-12 16:29:21.206516
# Unit test for function key_expansion

# Generated at 2022-06-12 16:29:34.065177
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # taken from https://cryptii.com/pipes/aes-cbc-decryption
    data = bytes_to_intlist("6B1BE029B2446F38AD82E81186F94E99")
    key = bytes_to_intlist("AABB09182736CCDD")
    iv = bytes_to_intlist("AABBCCDDEEFF1122")
    assert aes_cbc_decrypt(data, key, iv) == bytes_to_intlist("00112233445566778899AABBCCDDEEFF")

    data = bytes_to_intlist("296F923A15C40F5BE5B1F43B5C5AD5C5")

# Generated at 2022-06-12 16:29:44.298300
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    iv = bytes_to_intlist(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')


# Generated at 2022-06-12 16:29:56.914161
# Unit test for function key_expansion
def test_key_expansion():
    key_expansion([83, 133, -45, -80, -73, -124, -72, -15, -121, -70, 82, -110, 1, -128, -31, 68])
    key_expansion([-107, 73, -29, -57, -117, -100, -72, -17, -1, -43, -33, 42, -73, -19, -122, -52, 83, 133, -45, -80, -73, -124, -72, -15, -121, -70, 82, -110, 1, -128, -31, 68])

# Generated at 2022-06-12 16:30:07.946827
# Unit test for function key_expansion

# Generated at 2022-06-12 16:30:19.821722
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:30:28.310582
# Unit test for function key_expansion

# Generated at 2022-06-12 16:30:41.382454
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test vector from: http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    key = bytes_to_intlist(compat_b64decode('gIaanIKAl6PXLN6UOC9XUg=='))
    iv = bytes_to_intlist(compat_b64decode('fyCSEII1E9X2h5cMI8Bx5A=='))
    data = bytes_to_intlist(compat_b64decode('YFpzZGxkZnNzZHBkc3Nkc2Rzc2Q='))

# Generated at 2022-06-12 16:30:47.523059
# Unit test for function inc

# Generated at 2022-06-12 16:31:02.181071
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:10.658966
# Unit test for function key_expansion
def test_key_expansion():
    for key in ['2b7e151628aed2a6abf7158809cf4f3c763e7e59a4294f38b02502a8ac04abab',
                '2b7e151628aed2a6abf7158809cf4f3c']:
        key = bytes_to_intlist(compat_b64decode(key))
        expandedKey = key_expansion(key)
        assert(len(expandedKey) == 176)
        assert(len(expandedKey) != len(key))


# Generated at 2022-06-12 16:31:23.129617
# Unit test for function key_expansion
def test_key_expansion():
    # Input from FIPS-197, Appendix C
    assert key_expansion(bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')) == bytes_to_intlist(
        '2b7e151628aed2a6abf7158809cf4f3cef '
        'aafbf2142f7d883b845f0536b230bab3'
    )

# Generated at 2022-06-12 16:31:32.989997
# Unit test for function key_expansion
def test_key_expansion():
    import unittest

# Generated at 2022-06-12 16:31:45.978203
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('gZL8wxQIB9B44ypmAGoMtNbE1kYzpvYxCJly04iKFm8='))
    key_expanded = bytes_to_intlist(compat_b64decode('gZL8wxQIB9B44ypmAGoMtNbE1kYzpvYxCJly04iKFm+ZtcR8W7X0JvOJT7a1T+EawVJhSjS4xVZ+u6ZJfW7X4d4CKJbSpiDjrkpvEt+YZJ0FxA='))
    assert key_expansion(key) == key_expanded



# Generated at 2022-06-12 16:31:50.597235
# Unit test for function key_expansion
def test_key_expansion():
    from .utils import intlist_to_hex
    from .aes_data import KEY_EXPANSION_KEY, KEY_EXPANSION_DATA
    expanded_key = key_expansion(KEY_EXPANSION_KEY)
    assert intlist_to_hex(expanded_key) == KEY_EXPANSION_DATA



# Generated at 2022-06-12 16:31:59.336263
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:11.259349
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:19.725518
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:32.182558
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:44.895624
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')

# Generated at 2022-06-12 16:32:49.659125
# Unit test for function key_expansion
def test_key_expansion():
  for key_size_bytes in (16, 24, 32):
    data = [0] * key_size_bytes
    assert key_expansion(data)[-1] == 0

    data = [23] * key_size_bytes
    assert key_expansion(data)[-1] == 23



# Generated at 2022-06-12 16:33:02.750439
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(b'\xb6\x73\x10\x3f\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01')

# Generated at 2022-06-12 16:33:15.122402
# Unit test for function key_expansion
def test_key_expansion():
    # Test case 1
    # Encryption key: 2b7e151628aed2a6abf7158809cf4f3c
    # Encryption key (hex): 0x2b7e151628aed2a6abf7158809cf4f3c
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    # Encryption key (base 64): KwBfMjU2MjhhZWQyYTZhYmY3MTU4ODA5Y2Y0ZjNj