

# Generated at 2022-06-12 16:23:53.247025
# Unit test for function aes_encrypt
def test_aes_encrypt():
    test_data = [0x16, 0xaf, 0x5b, 0x14, 0x5f, 0xc9, 0xf5, 0x79, 0xc1, 0x75, 0xf9, 0x3e, 0x3b, 0xfb, 0x0e, 0xed]
    test_key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:24:03.337689
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .utils import intlist_to_bytes
    from .compat import compat_b64decode

    class Counter:
        def __init__(self, nonce, block_count):
            self.nonce = nonce
            self.block_count = block_count

        def next_value(self):
            block_count = self.block_count
            self.block_count += 1
            return (self.nonce + [0, 0, 0, block_count >> 24 & 255, block_count >> 16 & 255, block_count >> 8 & 255, block_count & 255])[::-1]

    key = intlist_to_bytes(bytes_to_intlist(compat_b64decode(b'VfzsjdAF/n4yZAq4FgT7TQ')))
    nonce

# Generated at 2022-06-12 16:24:14.244192
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist('1e589e156b4c2b4128fbea8d81750f29a3f3a3eebd00149440ed934efb79312e')
    iv = bytes_to_intlist('5cf6cbfce6d5e01b079a139422a70a0f')
    data = bytes_to_intlist('68747470733a2f2f6c6f63616c686f7374')

# Generated at 2022-06-12 16:24:19.900374
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = '3kcEUr/XnYvlR6VsShtg6U5N2Hrw42MEUd6igJSy6XE='
    password = '48656c6c6f2c20576f726c6421'
    key_size_bytes = 32
    expected_plaintext = 'Hello, World!'

    plaintext = aes_decrypt_text(data, password, key_size_bytes)
    plaintext = plaintext.decode('utf-8')
    assert expected_plaintext == plaintext, 'plaintext: {}\nexpected: {}'.format(plaintext, expected_plaintext)
test_aes_decrypt_text()


# Generated at 2022-06-12 16:24:32.942400
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .m3u8 import M3U8
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c,
          0xa0, 0xf0, 0xa1, 0x39, 0x45, 0xd8, 0x98, 0xc2, 0x96, 0x4f, 0xe3, 0x42, 0xe2, 0xfe, 0x1a, 0x7f]

# Generated at 2022-06-12 16:24:40.305465
# Unit test for function rijndael_mul
def test_rijndael_mul():
    print("\nUnit test for function rijndael_mul")
    print("{0:#0{1}x}".format(rijndael_mul(0x57, 0x83), 10))
    print("{0:#0{1}x}".format(rijndael_mul(0x83, 0x57), 10))
    print("{0:#0{1}x}".format(rijndael_mul(0x83, 0x13), 10))
    print("{0:#0{1}x}".format(rijndael_mul(0x13, 0x83), 10))
    print("{0:#0{1}x}".format(rijndael_mul(0x8e, 0x9a), 10))

# Generated at 2022-06-12 16:24:53.203549
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # AES
    ciphertext = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    expanded_key = key_expansion(bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE')))
    assert intlist_to_bytes(aes_decrypt(ciphertext, expanded_key)) == b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby'

    # AES-CTR

# Generated at 2022-06-12 16:24:59.218892
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_cbc import aes_cbc_encrypt
    from .aes_ecb import aes_ecb_encrypt
    from .aes_ctr import Counter

    counter = Counter(bytes_to_intlist(b'\x00\x00\x00\x00'))
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    data = b'This is a test!'
    ctr_encrypted = aes_ctr_encrypt(data, key, counter)
    ecb_encrypted = aes_ecb_encrypt(data, key)

# Generated at 2022-06-12 16:25:08.429885
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Test vector given in https://en.wikipedia.org/wiki/Block_cipher_mode_of_operation#Counter_.28CTR.29
    counter_example = WikipediaTestVector()

    # sanity checks
    decrypted_data = aes_ctr_decrypt(counter_example.data, counter_example.key, counter_example)
    assert decrypted_data == counter_example.data_decrypted

    # Test vector for the initial counter block
    initial_ctr_test_vector = b'0E1DBE24270889FA'
    init_ctr = counter_example.next_value()
    assert init_ctr == bytes_to_intlist(compat_b64decode(initial_ctr_test_vector))


# Generated at 2022-06-12 16:25:19.266616
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = bytes_to_intlist(b"YELLOW SUBMARINE")
    expanded_key = key_expansion(key)

    assert (
        intlist_to_bytes(
            aes_encrypt(
                bytes_to_intlist(b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"),
                expanded_key
            )
        )
        ==
        b"\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c"
    )



# Generated at 2022-06-12 16:25:29.754104
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    iv = bytes_to_intlist(compat_b64decode('uGO3zJxw2HzxkfHj7VFRcg=='))
    key = bytes_to_intlist(compat_b64decode('uGO3zJxw2HzxkfHj7VFRcg=='))
    data = bytes_to_intlist(compat_b64decode('4f16b61aa9d9338a5a8c514637d632d67dcfcdd6'))

    encrypted_data = aes_cbc_encrypt(
        data, key, iv
    )
    print (intlist_to_bytes(encrypted_data))



# Generated at 2022-06-12 16:25:42.293469
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
	
	key = bytes_to_intlist(b"YELLOW SUBMARINE")
	iv  = bytes_to_intlist(b"\x00"*16)

# Generated at 2022-06-12 16:25:52.480204
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    plaintext = 'This is a test'.encode('ascii')
    key = bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f')
    iv = bytes_to_intlist(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')

    print(intlist_to_bytes(aes_cbc_encrypt(bytes_to_intlist(plaintext), key, iv)))

# Generated at 2022-06-12 16:26:05.682591
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:26:16.768582
# Unit test for function aes_decrypt
def test_aes_decrypt():
    temp_data = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    temp_key = bytes_to_intlist(compat_b64decode(b'YELLOW SUBMARINE'))
    temp_expanded_key = key_expansion(temp_key)
    decrypted_data = aes_decrypt(temp_data, temp_expanded_key)
    print(intlist_to_bytes(decrypted_data))


test_aes_decrypt()


# Generated at 2022-06-12 16:26:30.265900
# Unit test for function aes_decrypt
def test_aes_decrypt():
    # key_size = 32
    test_data = [44, 133, 70, 210, 162, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

# Generated at 2022-06-12 16:26:41.704329
# Unit test for function aes_decrypt
def test_aes_decrypt():
    print("testing aes_decrypt...")
    x = intlist_to_bytes([213, 35, 197, 73, 26, 171, 159, 147, 44, 214, 27, 19, 55, 223, 59, 113])
    y = intlist_to_bytes([83, 246, 209, 85, 173, 235, 176, 155, 125, 225, 146, 115, 134, 67, 106, 171])
    z = intlist_to_bytes([182, 251, 11, 251, 25, 30, 30, 251, 30, 255, 226, 255, 226, 255, 226, 255])

    x = bytes_to_intlist(x)
    y = bytes_to_intlist(y)
    z = bytes_to_intlist(z)

    assert aes_decrypt(x, y) == z

# Generated at 2022-06-12 16:26:54.885497
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = [0x3D, 0xAF, 0xBA, 0x42, 0x9D, 0x9E, 0xB4, 0x30, 0xB4, 0x22, 0xDA, 0x80, 0x2C, 0x9F, 0xAC, 0x41]
    key = [0x56, 0xE4, 0x7A, 0x38, 0xC5, 0x59, 0x89, 0x74, 0xBC, 0x46, 0x90, 0x3D, 0xBA, 0x29, 0x03, 0x49]

# Generated at 2022-06-12 16:27:06.028225
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    test_iv = [0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34]

# Generated at 2022-06-12 16:27:12.095144
# Unit test for function aes_decrypt
def test_aes_decrypt():
    """
    Perform unit test for function 'aes_encrypt'
    """
    # test vector from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    key = bytes_to_intlist(compat_b64decode('QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F'))
    cipher = bytes_to_intlist(compat_b64decode('RkhBRyBQQVJBTUVURVJXSVJFRCBIRUxQT1JU'))
    expanded_key = key_expansion(key)
    state = aes_decrypt(cipher, expanded_key)

# Generated at 2022-06-12 16:27:25.567503
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = bytes_to_intlist('A'*BLOCK_SIZE_BYTES)
    key = bytes_to_intlist('B'*BLOCK_SIZE_BYTES)
    
    data = [ ]

# Generated at 2022-06-12 16:27:37.132044
# Unit test for function aes_decrypt
def test_aes_decrypt():
    assert aes_decrypt([227, 61, 1, 0, 253, 23, 25, 4, 232, 252, 158, 233, 127, 2, 5, 208],
                       key_expansion([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16])) \
           == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    return True

aes_decrypt([227, 61, 1, 0, 253, 23, 25, 4, 232, 252, 158, 233, 127, 2, 5, 208],key_expansion([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]))

# Generated at 2022-06-12 16:27:48.984112
# Unit test for function aes_decrypt
def test_aes_decrypt():

    # test vectors from https://csrc.nist.gov/projects/cryptographic-algorithm-validation-program/block-ciphers#AES
    key = bytes_to_intlist(compat_b64decode(b'fU6hDMaT+jHwhBzfQtt3qw=='))

# Generated at 2022-06-12 16:27:56.779180
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:28:00.827921
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = "Hello World"
    key = "1234567812345678"
    iv = "12345678abcdefgh"
    res = aes_cbc_decrypt(data, key, iv)
    print(res)



# Generated at 2022-06-12 16:28:13.498077
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = intlist_to_bytes([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c])

# Generated at 2022-06-12 16:28:22.971989
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6]
    iv = [6, 5, 4, 3, 2, 1, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
    data = intlist_to_bytes([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5])

    assert aes_cbc_decrypt(data, key, iv) == intlist_to_bytes([1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5])



# Generated at 2022-06-12 16:28:32.096457
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Encrypt with openssl
    test_key = '40F09E2980A79F38C97DF9F47600A8E1'.decode('hex')
    test_iv = '8000000000000000'.decode('hex')
    test_data = aes_cbc_decrypt('f0a5a75c5d1d21f8af9ad1d52916f673'.decode('hex'), test_key, test_iv)
    assert test_data.encode('hex') == '00000000000000000000000000000000'



# Generated at 2022-06-12 16:28:42.070963
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():

    # https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38a.pdf
    key = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')
    iv = bytes_to_intlist('000102030405060708090a0b0c0d0e0f')

# Generated at 2022-06-12 16:28:46.164125
# Unit test for function inc
def test_inc():
    assert inc([1, 2, 3]) == [1, 2, 4]
    assert inc([0xff]) == [0] * 1
    assert inc([0] * 16) == [1] + [0] * 15



# Generated at 2022-06-12 16:28:59.878887
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test vectors from http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:29:05.902667
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = [0] * 16
    key = [0] * 16
    plain = [0] * 16
    cipher = aes_cbc_encrypt(plain, key, iv)
    print("cipher:\n" + str(cipher))
    plain2 = aes_cbc_decrypt(cipher, key, iv)
    print("plain:\n" + str(plain2))

test_aes_cbc_decrypt()


# Generated at 2022-06-12 16:29:18.331982
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:29:28.333133
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test case from this site:
    # http://kuchiriel.com/symmetric-cryptography-with-python-and-cryptography
    test_key = "this is a key123"
    test_iv = "this is an iv456"
    test_ciphertext = "7e/NxCjKHlY="
    expected_plaintext = "somemessage"
    assert aes_cbc_decrypt(compat_b64decode(test_ciphertext),
                           bytes_to_intlist(test_key),
                           bytes_to_intlist(test_iv)) == bytes_to_intlist(expected_plaintext)



# Generated at 2022-06-12 16:29:40.702845
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytes_to_intlist([185, 96, 92, 85, 171, 230, 136, 3, 254, 111, 92, 47, 254, 213, 132, 70, 116, 107, 154, 0, 133, 135, 32, 104, 119, 76, 112, 176, 131, 191, 70, 249])
    key = bytes_to_intlist([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c])

# Generated at 2022-06-12 16:29:48.503844
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .hls_cipher import HLSDecipher


# Generated at 2022-06-12 16:29:58.711419
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    test_key = bytes_to_intlist(b'YELLOW SUBMARINE')
    test_iv = [101, 120, 112, 97, 110, 100, 32, 51, 50, 45, 98, 121, 116, 101, 32, 107]
    test_text = bytes_to_intlist(b'hello burma')
    test_cipher = aes_cbc_encrypt(test_text, test_key, test_iv)
    test_decrypted = aes_cbc_decrypt(test_cipher, test_key, test_iv)
    print(intlist_to_bytes(test_decrypted))



# Generated at 2022-06-12 16:30:09.329154
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = list(map(ord, compat_b64decode(b'dEDpqYbEqcMz3xqH+sANHRZjNPH2hwNtTnny2K1/tNk=')))
    key = list(map(ord, compat_b64decode(b'uV3F3YluFJax1cknvbcGwg==')))
    iv = list(map(ord, compat_b64decode(b'To9Vjco9rYSrLkKn')))
    data = bytes_to_intlist(compat_b64decode(b'dEDpqYbEqcMz3xqH+sANHRZjNPH2hwNtTnny2K1/tNk='))

# Generated at 2022-06-12 16:30:19.034892
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    k = bytes_to_intlist("00010203050607080a0b0c0d0f101113")
    data = [79, 161, 243, 65, 119, 147, 71, 185, 89, 23, 189, 17, 139, 1, 125, 107]
    iv = [69, 244, 208, 93, 149, 115, 73, 36, 177, 163, 192, 56, 234, 186, 89, 210]
    d = aes_cbc_decrypt(data, k, iv)
    v = intlist_to_bytes(d)
    assert v == b"YELLOW SUBMARINE"



# Generated at 2022-06-12 16:30:27.931077
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:30:42.754332
# Unit test for function key_expansion
def test_key_expansion():
    # 16 byte key
    expected_key = [0x60, 0x3d, 0xeb, 0x10, 0x15, 0xca, 0x71, 0xbe, 0x2b, 0x73, 0xae, 0xf0, 0x85, 0x7d, 0x77, 0x81, 0x1f, 0x35, 0x2c, 0x07, 0x3b, 0x61, 0x08, 0xd7, 0x2d, 0x98, 0x10, 0xa3, 0x09, 0x14, 0xdf, 0xf4]

# Generated at 2022-06-12 16:30:53.592175
# Unit test for function key_expansion
def test_key_expansion():
    # 16-Byte cipher key
    ck16 = bytes_to_intlist('00000000000000000000000000000000'.encode())
    ek16 = bytes_to_intlist('00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'.encode())
    assert(key_expansion(ck16) == ek16)

    # 24-Byte cipher key
    ck24 = bytes_to_intlist('000000000000000000000000000000000000000000000000'.encode())
    ek24 = bytes_to_intlist('000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'.encode())
    assert(key_expansion(ck24) == ek24)

    # 32-Byte cipher key
    ck32 = bytes_to_intlist('0000000000000000000000000000000000000000000000000000000000000000'.encode())

# Generated at 2022-06-12 16:31:06.074881
# Unit test for function key_expansion
def test_key_expansion():
    key128 = bytes_to_intlist(compat_b64decode(b'gqO4op4jzW+65C7v2yLbXFI49ey+mWziIcHvwY+YJvg='))
    key192 = bytes_to_intlist(compat_b64decode(b'gqO4op4jzW+65C7v2yLbXFI49ey+mWziIcHvwY+YJvgRyY+//1RzP6n5U6MkSJ9g'))

# Generated at 2022-06-12 16:31:13.846797
# Unit test for function key_expansion
def test_key_expansion():
    assert key_expansion(bytes_to_intlist(b'\x00'*16)) == bytes_to_intlist(b'\x00'*176)
    assert key_expansion(bytes_to_intlist(b'\x00'*24)) == bytes_to_intlist(b'\x00'*208)
    assert key_expansion(bytes_to_intlist(b'\x00'*32)) == bytes_to_intlist(b'\x00'*240)



# Generated at 2022-06-12 16:31:26.229722
# Unit test for function key_expansion
def test_key_expansion():
    import unittest

    if not unittest.source:
        print('\033[91mTests for function key_expansion are skipped')
        return


# Generated at 2022-06-12 16:31:34.752971
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b"Sample #1")
    expanded_key = key_expansion(key)

# Generated at 2022-06-12 16:31:45.564191
# Unit test for function key_expansion
def test_key_expansion():
    iv = [64, 191, 183, 176, 136, 33, 167, 60, 109, 3, 180, 145, 146, 201, 158, 212,
          211, 42, 79, 28, 221, 253, 221, 71, 231, 236, 147, 63, 208, 232, 17, 128]
    key = [101, 120, 112, 97, 110, 100, 32, 51, 50, 45, 98, 121, 116, 101, 32, 107]
    ctr = Counter(iv)
    rnd = aes_ctr_decrypt(iv, key, ctr)
    print(rnd)
    expk = key_expansion(key)
    print(expk)


# Generated at 2022-06-12 16:31:55.862050
# Unit test for function key_expansion
def test_key_expansion():
    print("\nUnit test for function key_expansion")
    key_16 = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')
    key_24 = bytes_to_intlist('8E73B0F7DA0E6452C810F32B809079E562F8EAD2522C6B7B')
    key_32 = bytes_to_intlist('603DEB1015CA71BE2B73AEF0857D77811F352C073B6108D72D9810A30914DFF4')

# Generated at 2022-06-12 16:31:58.635822
# Unit test for function key_expansion
def test_key_expansion():
    for key_length in [16, 24, 32]:
        data = [0] * key_length
        assert key_expansion(data) == key_expansion(data)
# Run unit tests
test_key_expansion()



# Generated at 2022-06-12 16:32:10.786288
# Unit test for function key_expansion
def test_key_expansion():
    print("Testing Key Expansion...", end='')
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:32:24.008607
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:35.986638
# Unit test for function key_expansion
def test_key_expansion():
    print("Test key_expansion")
    key_size_bytes = 16
    data = [0] * key_size_bytes
    expanded_key_size_bytes = (key_size_bytes // 4 + 7) * BLOCK_SIZE_BYTES

    data = key_expansion(data)
    assert len(data) == expanded_key_size_bytes

    key_size_bytes = 24
    data = [0] * key_size_bytes
    expanded_key_size_bytes = (key_size_bytes // 4 + 7) * BLOCK_SIZE_BYTES

    data = key_expansion(data)
    assert len(data) == expanded_key_size_bytes

    key_size_bytes = 32
    data = [0] * key_size_bytes

# Generated at 2022-06-12 16:32:44.623132
# Unit test for function key_expansion
def test_key_expansion():
    """
    Test for function key_expansion

    @returns {none}
    """
    key = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')
    expanded_key = key_expansion(key)

# Generated at 2022-06-12 16:32:57.104795
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(compat_b64decode('''
        QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F
    '''))

# Generated at 2022-06-12 16:33:07.405624
# Unit test for function key_expansion

# Generated at 2022-06-12 16:33:19.402735
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')