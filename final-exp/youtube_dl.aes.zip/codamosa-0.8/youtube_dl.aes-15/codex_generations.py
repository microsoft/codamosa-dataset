

# Generated at 2022-06-12 16:23:35.083465
# Unit test for function aes_decrypt
def test_aes_decrypt():
    plain_text = b'Hello World!'
    key = b'Sixteen byte key'
    data = bytes_to_intlist(plain_text)
    key = bytes_to_intlist(key)
    expanded_key = key_expansion(key)
    encrypted = aes_encrypt(data, expanded_key)
    decrypted = aes_decrypt(encrypted, expanded_key)
    assert plain_text == intlist_to_bytes(decrypted)

test_aes_decrypt()

# Generated at 2022-06-12 16:23:45.736059
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    key = key + [0] * (32 - len(key))

    counter = Counter(0, BLOCK_SIZE_BYTES)

    # Encrypt-then-decrypt string
    assert(aes_ctr_decrypt(aes_ctr_encrypt(b'', key, counter), key, counter) == b'')
    assert(aes_ctr_decrypt(aes_ctr_encrypt(b'9', key, counter), key, counter) == b'9')

# Generated at 2022-06-12 16:23:52.228331
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]
    expanded_key = key_expansion(key)
    assert isinstance(expanded_key, list)
    assert len(expanded_key) == 44
    print(expanded_key)
    print(len(_expanded_key))



# Generated at 2022-06-12 16:23:59.507935
# Unit test for function key_expansion
def test_key_expansion():
    if not KEY_EXPANSION_TESTS:
        return
    print("Testing key expansion")
    for key, expected in KEY_EXPANSION_TESTS:
        key = intlist_to_bytes(bytes_to_intlist(compat_b64decode(key)))
        expanded_key = key_expansion(key)
        expanded_key = intlist_to_bytes(expanded_key)
        expected = compat_b64decode(expected)
        if expanded_key != expected:
            print("Test failed")
            print("\tKey:      %s" % key)
            print("\tExpected: %s" % expected)
            print("\tActual:   %s" % expanded_key)
    print("All tests passed")



# Generated at 2022-06-12 16:24:11.549667
# Unit test for function aes_decrypt
def test_aes_decrypt():
    import unittest
    from collections import OrderedDict

    from .compat import compat_chr, compat_unichr

    # Based on https://www.samiam.org/key-schedule.html

# Generated at 2022-06-12 16:24:17.208027
# Unit test for function inc
def test_inc():
    for i in range(256):
        assert inc([i]) == [i+1 % 256]
        assert inc([i,i]) == [(i + 1) % 256, i]
        assert inc([i,i,i]) == [(i + 1) % 256, i, i]
        assert inc([i,i,i,i]) == [(i + 1) % 256, i, i, i]

test_inc()




# Generated at 2022-06-12 16:24:30.096023
# Unit test for function aes_encrypt
def test_aes_encrypt():
    message = bytes_to_intlist(bytearray.fromhex("00112233445566778899aabbccddeeff"))
    key = bytes_to_intlist(bytearray.fromhex("000102030405060708090a0b0c0d0e0f"))
    expanded_key = bytes_to_intlist(bytearray.fromhex("000102030405060708090a0b0c0d0e0f1011121314151617202122232425262728292a2b2c2d2e2f303132333435363738393a3b3c3d3e3f4041424344454647"))
    cipher = aes_encrypt(message, expanded_key)

# Generated at 2022-06-12 16:24:40.747244
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test 1
    key = bytes_to_intlist(compat_b64decode('CY9rzUYh03PK3k6DJie09g=='))
    iv = bytes_to_intlist(compat_b64decode('tiihtNczf5v6AKRyjwEUhQ=='))
    data = bytes_to_intlist(b'Basic exercises')
    encrypt_res = aes_cbc_encrypt(data, key, iv)
    assert intlist_to_bytes(encrypt_res) == compat_b64decode(
        'KDlTtXchhZTGufMYmOYGS4uFxHdHlTf7IvxwcfypFPH1C')
    # Test 2

# Generated at 2022-06-12 16:24:47.301574
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-12 16:24:59.547885
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b"foo bar baz")
    key = bytes_to_intlist(b"1234567890123456")
    iv = bytes_to_intlist(b"1234567890123456")

    encrypted_data = aes_cbc_encrypt(data, key, iv)
    expected = [
        31, 75, 164, 40, 74, 139, 254, 253,
        190, 230, 43, 10, 55, 36, 220, 164,
        8, 175, 174, 214, 13, 206, 42, 94,
        211, 21, 221, 3, 202, 203, 125, 46
    ]
    assert encrypted_data == expected, "aes_cbc_encrypt failed"
    print("aes_cbc_encrypt OK")

test_aes

# Generated at 2022-06-12 16:25:23.583554
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = [143, 194, 34, 208, 145, 203, 230, 143, 177, 246, 97, 206, 145, 92, 255, 84]
    cipher = [40, 57, 83, 181, 119, 33, 133, 148, 198, 185, 243, 24, 152, 230, 6, 75, 129, 223, 127, 19, 210, 82, 183, 230, 168, 33, 215, 104, 143, 112, 56, 102]
    index_counter = IndexCounter(0, 1)
    res = aes_ctr_decrypt(cipher, key, index_counter)
    assert res == [226, 152, 139, 150, 94, 140, 163, 161, 34, 216, 39, 144, 154, 209, 189, 12]
    print('🍺 Unit test for aes_ctr_decrypt successed!')


# Generated at 2022-06-12 16:25:31.181580
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # key and iv are taken from original JS source
    key = bytes_to_intlist(b"\x60\x3d\xeb\x10\x15\xca\x71\xbe\x2b\x73\xae\xf0\x85\x7d\x77\x81\x1f\x35\x2c\x07\x3b\x61\x08\xd7\x2d\x98\x10\xa3\x09\x14\xdf\xf4")
    iv = bytes_to_intlist(b"\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f")
    non

# Generated at 2022-06-12 16:25:42.340742
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    test_key = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    test_iv = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    test_cipher = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    assert aes_cbc_decrypt(test_cipher, test_key, test_iv) == [i ^ j for i, j in zip(test_cipher, test_iv)]



# Generated at 2022-06-12 16:25:52.833223
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:26:06.003944
# Unit test for function aes_decrypt_text

# Generated at 2022-06-12 16:26:17.020419
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')
    key = bytes_to_intlist('YELLOW SUBMARINE')
    class Counter:
        def __init__(self):
            self.value = 1
        def next_value(self):
            out = self.value
            out = [out & 0xff, (out >> 8) & 0xff, (out >> 16) & 0xff, (out >> 24) & 0xff]
            self.value += 1
            return out
    counter = Counter()
    result = intlist_to_bytes(aes_ctr_decrypt(data, key, counter))
    assert result

# Generated at 2022-06-12 16:26:29.808066
# Unit test for function inc
def test_inc():
    print("Unit test for function inc")
    data = [0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0]
    exp = [0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1]
    print("Actual:  " + "".join("%02x" % x for x in data))
    print("Expected:" + "".join("%02x" % x for x in exp))
    inc(data)
    print("Result:  " + "".join("%02x" % x for x in data))
    print("Pass") if data == exp else print("Fail")
    print("=" * 15)



# Generated at 2022-06-12 16:26:34.647008
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key_b64 = '1xyyvfAoAep8h4m4H9J4QQ=='
    iv_b64 = 'CJz1vBkIAGNW8pJtR5Nt7A=='
    cipher_b64 = 'wY3hq/v/yLkW/NQ99c1Xq+BvZJyrGsZ7VuCYwwz+LpE='
    cbc_b64 = 'F9I6MxM6iJU6Ekzw+r0HrQ=='

    key = bytes_to_intlist(compat_b64decode(key_b64))
    iv = bytes_to_intlist(compat_b64decode(iv_b64))

# Generated at 2022-06-12 16:26:44.532280
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .utils import a2b_hex, a2b_hex
    from .aes import aes_encrypt, aes_decrypt

    # Encrypt plaintext, decrypt with aes_ctr_decrypt
    plaintext = b'Hello World'
    key = a2b_hex('603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4')
    counter = AESCounter(b'\xFF' * 16)
    cipher = aes_encrypt(plaintext, key)
    assert plaintext == aes_ctr_decrypt(cipher, key, counter)

    # Encrypt plaintext, decrypt with aes_decrypt
    plaintext = b'Hello World' * 1048

# Generated at 2022-06-12 16:26:57.659867
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .utils import rand_bytes
    from .aes_compat import aes_cbc_encrypt
    from .aes_cbc_compat import aes_cbc_decrypt as aes_cbc_decrypt_compat

    for i in range(1000):
        key = rand_bytes(16)
        iv = rand_bytes(16)
        to_encrypt = b'loremipsumdolorsitamet'
        encrypted = aes_cbc_encrypt(to_encrypt, key, iv)
        # print(encrypted)
        decrypted = aes_cbc_decrypt(encrypted, key, iv)
        decrypted_compat = aes_cbc_decrypt_compat(encrypted, key, iv)
        # print(decrypted)
        assert decrypted == decrypted

# Generated at 2022-06-12 16:27:08.156897
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    class TestCounter(object):
        def __init__(self):
            self.i = 0
        def next_value(self):
            self.i += 1
            return intlist_to_bytes(self.i * [0])
    counter = TestCounter()
    decrypted = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-12 16:27:21.208501
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'X4e4uY7To4FZ8uV7d4lSgSV2+b0dU5v2'
    data = bytes_to_intlist(compat_b64decode(data))
    password = bytes_to_intlist(b'qwerty123')
    key_size_bytes = 32
    passkey = password[:key_size_bytes] + [0] * (key_size_bytes - len(password))
    key = aes_encrypt(passkey[:BLOCK_SIZE_BYTES], key_expansion(passkey)) * (key_size_bytes // BLOCK_SIZE_BYTES)

# Generated at 2022-06-12 16:27:28.140901
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes import aes_encrypt
    from .aes import aes_decrypt
    from .aes import key_expansion
    from binascii import unhexlify
    key = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

    class SimpleIV:
        def __init__(self, iv):
            self.iv = bytes_to_intlist(iv)
        def next_value(self):
            self.iv[14] += 1
            return self.iv


# Generated at 2022-06-12 16:27:40.405731
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    bs = 16
    data = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
    key = (1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1)

# Generated at 2022-06-12 16:27:51.444967
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    assert aes_decrypt_text(
        'xvmT0G0EZrjr+vEWgV7PBkIBFcl8VHs+sB6aGK6jgUOZCpSZWUOnjM4Ogj7A4Od4',
        'MySecretPassword',
        16
    ) == b'Hello World!'
    assert aes_decrypt_text(
        '5zgxZn0xZzjD+o8WZkDDgIBFcl8VHs+sB6aGK6jgUOZCpSZWUOnjM4Ogj7A4Od4',
        '123456',
        16
    ) == b'Hello World!'

# Generated at 2022-06-12 16:28:01.671350
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, start=0):
            self.i = start
        def next_value(self):
            self.i += 1
            return bytes_to_intlist(as111_int(self.i).to_bytes(16, 'big'))
    # Inputs and expected results

# Generated at 2022-06-12 16:28:14.182508
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():

    class Counter(object):
        def __init__(self, nonce, initial_value=1):
            self._nonce = nonce
            self._initial_value = initial_value

        def next_value(self):
            nonce = self._nonce
            initial_value = self._initial_value
            counter_block = nonce + [
                (initial_value >> 24) & 0xff,
                (initial_value >> 16) & 0xff,
                (initial_value >> 8) & 0xff,
                initial_value & 0xff,
                ]
            assert len(counter_block) == BLOCK_SIZE_BYTES
            self._initial_value += 1
            return counter_block

    # test vector from http://en.wikipedia.org/wiki/Block_cipher_mode_of_operation#Counter_.28CTR

# Generated at 2022-06-12 16:28:24.930608
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, counter):
            if len(counter) != BLOCK_SIZE_BYTES:
                raise ValueError('Invalid counter size!')
            self.counter = counter

        def next_value(self):
            self.counter = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115]
            return self.counter


    class Counter2(object):
        def __init__(self, start_value):
            if len(start_value) != BLOCK_SIZE_BYTES:
                raise ValueError('Invalid start_value size!')
            self.start_value = start_value
            self.cur_value = start_value


# Generated at 2022-06-12 16:28:37.701215
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    import string
    import random
    import codecs
    class Counter:
        def __init__(self, init_value=[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]):
            self.counter = init_value

        def next_value(self):
            return self.counter

    alphabet = string.printable
    plain_text = ''.join(random.choice(alphabet) for x in range(random.randint(32, 256)))

    data = codecs.encode(plain_text, 'hex_codec', 'strict').decode('latin-1')
    key = [random.randint(0, 255) for x in range(32)]

# Generated at 2022-06-12 16:28:44.882176
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():

    # Example taken from https://en.wikipedia.org/wiki/Block_cipher_mode_of_operation#Counter_.28CTR.29
    data = bytes_to_intlist(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    counter = Counter(bytes_to_intlist(b'\x00\x00\x00\x00\x00\x00\x00\x00'))
    expected_data = bytes_to_intlist(b'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby ')
    assert aes_

# Generated at 2022-06-12 16:28:51.082347
# Unit test for function inc
def test_inc():
    for i in range(256):
        print(i, '=', inc([i]))

#test_inc()


# Generated at 2022-06-12 16:28:55.845515
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0]) == [0, 0, 1]
    assert inc([0, 0, 255]) == [0, 1, 0]
    assert inc([0, 255, 255]) == [1, 0, 0]
    assert inc([255, 255, 255]) == [0, 0, 0]


# Generated at 2022-06-12 16:28:58.130235
# Unit test for function inc
def test_inc():
    data = [0, 0, 0, 0]
    print(inc(data))



# Generated at 2022-06-12 16:29:07.547619
# Unit test for function key_expansion
def test_key_expansion():
    assert key_expansion(bytes_to_intlist(compat_b64decode(b'X9BSyBaoS1iWd8xKxFUDHw=='))) == bytes_to_intlist(compat_b64decode(b'X9BSyBaoS1iWd8xKxFUDHwoArbMj1jV9JiMuwaP7V8E='))

# Generated at 2022-06-12 16:29:20.211073
# Unit test for function key_expansion

# Generated at 2022-06-12 16:29:33.100204
# Unit test for function key_expansion
def test_key_expansion():
    import unittest
    import hashlib
    class TestKeyExpansion(unittest.TestCase):
        def test_128(self):
            key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                   0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-12 16:29:43.692413
# Unit test for function inc
def test_inc():
    assert inc([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x01]
    assert inc([0x00, 0x00, 0x00, 0x01]) == [0x00, 0x00, 0x00, 0x02]
    assert inc([0x00, 0x00, 0x00, 0x02]) == [0x00, 0x00, 0x00, 0x03]
    assert inc([0x00, 0x00, 0x00, 0xff]) == [0x00, 0x00, 0x01, 0x00]
    assert inc([0x00, 0x00, 0x01, 0x00]) == [0x00, 0x00, 0x01, 0x01]

# Generated at 2022-06-12 16:29:55.971485
# Unit test for function key_expansion

# Generated at 2022-06-12 16:30:03.574028
# Unit test for function inc
def test_inc():
    assert inc([0, 0, 0, 0]) == [0, 0, 0, 1]
    assert inc([0xff, 0, 0, 0]) == [0, 1, 0, 0]
    assert inc([0, 0, 0, 0xff]) == [0, 0, 0, 0]
    assert inc([0, 0xff, 0, 0xff]) == [0, 0, 1, 0]
    assert inc([0xff, 0xff, 0xff, 0xff]) == [0, 0, 0, 0]



# Generated at 2022-06-12 16:30:12.234932
# Unit test for function key_expansion

# Generated at 2022-06-12 16:30:25.992758
# Unit test for function key_expansion

# Generated at 2022-06-12 16:30:36.067876
# Unit test for function key_expansion
def test_key_expansion():
    hex_key = "140b41b22a29beb4061bda66b6747e14"
    intlist_key = list(bytes_to_intlist(compat_b64decode(hex_key)))
    expanded_key = key_expansion(intlist_key)
    assert intlist_to_bytes(expanded_key).hex() == "140b41b22a29beb4061bda66b6747e1470dda5dfd8976fa45af8246515d0f92a62ec8ecd4c7f6c2c4e0e4f162"
    print("Function key_expansion() - Successful")

test_key_expansion()


# Generated at 2022-06-12 16:30:48.521967
# Unit test for function key_expansion

# Generated at 2022-06-12 16:30:56.736286
# Unit test for function key_expansion
def test_key_expansion():
    # 16 Byte key
    key = [
        0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
        0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c,
    ]

# Generated at 2022-06-12 16:31:08.423239
# Unit test for function key_expansion
def test_key_expansion():
    # Unit vectors from
    #   http://csrc.nist.gov/publications/nistpubs/800-38a/sp800-38a.pdf
    #   Appendix F - Example Vectors
    #     Keys of Various Lengths
    import binascii

    key_1 = bytes_to_intlist(binascii.unhexlify('2b7e151628aed2a6abf7158809cf4f3c'))

# Generated at 2022-06-12 16:31:19.897464
# Unit test for function key_expansion
def test_key_expansion():
    print("Unit test for function key_expansion.")
    test_key_1 = bytes_to_intlist(compat_b64decode('rFW3N9vL8VZWu5eO+i7Vvw=='))
    test_key_2 = bytes_to_intlist(compat_b64decode('fUsaVvQGK0w8VuYaY3qzFw=='))
    test_key_3 = bytes_to_intlist(compat_b64decode('njTfNQ2Xh0nHZFjUit+czQ=='))
    test_keys = [test_key_1, test_key_2, test_key_3]


# Generated at 2022-06-12 16:31:31.557767
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:44.690925
# Unit test for function key_expansion
def test_key_expansion():
    # AES-128 key expansion
    data = bytes_to_intlist(compat_b64decode('kPH+bIxk5D2deZiIxcaaaA=='))
    result = key_expansion(data)

# Generated at 2022-06-12 16:31:55.104690
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(b'\x00\x04\x08\x0c\x10\x14\x18\x1c\x20\x24\x28\x2c\x30\x34\x38\x3c')


# Generated at 2022-06-12 16:32:05.392006
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]


# Generated at 2022-06-12 16:32:17.925933
# Unit test for function key_expansion
def test_key_expansion():
    A1 = [0x2b, 0x28, 0xab, 0x09, 0x7e, 0xae, 0xf7, 0xcf, 0x15, 0xd2, 0x15, 0x4f, 0x16, 0xa6, 0x88, 0x3c]
    A2 = [0x8a, 0xe9, 0xb1, 0x3d, 0x51, 0x10, 0x41, 0x62, 0x57, 0x9b, 0x39, 0x93, 0xfe, 0xf6, 0x1c, 0x8b]

# Generated at 2022-06-12 16:32:24.260834
# Unit test for function key_expansion
def test_key_expansion():
    testcases = []

# Generated at 2022-06-12 16:32:36.263670
# Unit test for function key_expansion
def test_key_expansion():
    test_test = key_expansion(bytes_to_intlist(b'\x00' * 16))

# Generated at 2022-06-12 16:32:40.140365
# Unit test for function key_expansion
def test_key_expansion():
    # key size 16
    key = bytes_to_intlist(bytearray(b'Sixteen byte key'))
    expanded_key = key_expansion(key)

# Generated at 2022-06-12 16:32:52.666096
# Unit test for function key_expansion
def test_key_expansion():
    test_vectors = []
    test_vectors.append({'key': bytes_to_intlist(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'), 'w': []})
    test_vectors.append({'key': bytes_to_intlist(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'), 'w': [0x00010203, 0x04050607, 0x08090a0b, 0x0c0d0e0f]})
    test_ve

# Generated at 2022-06-12 16:33:05.052983
# Unit test for function key_expansion
def test_key_expansion():
    print("Test key_expansion")
    key = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')
    expanded_key = key_expansion(key)

# Generated at 2022-06-12 16:33:17.313650
# Unit test for function key_expansion