

# Generated at 2022-06-12 16:23:47.189220
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(b'abc')
    key = bytes_to_intlist(b'aes_key')
    counter = AESCounter(0)
    data = aes_ctr_decrypt(data, key, counter)
    assert intlist_to_bytes(data) == b'abc'
    data = aes_ctr_decrypt(data, key, counter)
    assert intlist_to_bytes(data) == b'abc'
# End Unit test block



# Generated at 2022-06-12 16:23:56.139330
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = b"q1qpUI6i/U6/xU4bqyOHLpUO1iU6i9U6/xU4bqyOHLpUO1iU6i9U6/xU4bqyOHLpUO1iU6i9U6/xU4bqyOHLpUO1"
    password = "AES"

# Generated at 2022-06-12 16:24:08.177756
# Unit test for function key_expansion
def test_key_expansion():
    key16 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]

# Generated at 2022-06-12 16:24:18.180730
# Unit test for function aes_decrypt
def test_aes_decrypt():
    from .compat import compat_b64decode

    input_ = b"abcdefghijklmnopqrstuvwxyz123456"
    password = b"testpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpasswordtestpassword"
    data = bytes_to_intlist

# Generated at 2022-06-12 16:24:31.364882
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    """
    Test for aes_ctr_decrypt
    """
    # Set 1, Challenge 5
    key = bytes_to_intlist(b'ICE')
    cipher = '0b3637272a2b2e63622c2e69692a23693a2a3c6324202d623d63343c2a26226324272765272'
    cipher += 'a282b2f20430a652e2c652a3124333a653e2b2027630c692b20283165286326302e27282f'
    cipher = bytes_to_intlist(compat_b64decode(cipher.encode('utf-8')))

    class Counter:
        def __init__(self, block):
            self.counter = block[:]


# Generated at 2022-06-12 16:24:38.358444
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    from .aes_cbc import aes_cbc_encrypt

    class DummyCounter(object):
        def __init__(self, n):
            self.n = n
        def next_value(self):
            return self.n

    # Test vector for block size 16-bytes
    key = bytes_to_intlist(compat_b64decode(b'uGZWk9twq5i5ugYV7QG0Zw=='))       # 16-bytes
    iv = bytes_to_intlist(compat_b64decode(b'oFmooNdmlquFArjT/MhTIA=='))      # 16-bytes
    plaintext = bytes_to_intlist(b'test plaintext')

# Generated at 2022-06-12 16:24:46.192873
# Unit test for function aes_decrypt
def test_aes_decrypt():
	key = bytes_to_intlist(compat_b64decode(b'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXoK'))
	expanded_key = key_expansion(key)
	plaintext = bytes_to_intlist(compat_b64decode(b'bXVsdGx5IHNlY3VyZSBvdmVyIHRoZSB0ZWFsIGNvbnRyb2wgb2YgbWV0cm9wb2xpdGFuZXMK'))

# Generated at 2022-06-12 16:24:53.202940
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    def test_aes_decrypt_text(input_data, input_password, expected):
        actual = aes_decrypt_text(input_data, input_password, 16)
        print(actual)

    test_aes_decrypt_text("VjFaL2QzaHFYMHU1T1U9PVM0SfmZSODVZK2I2U3d3dlY=", "test", b"test")



# Generated at 2022-06-12 16:24:59.192613
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_counter import AESCounter
    import base64
    from .utils import bytes_to_intlist, intlist_to_bytes
    from .compat import compat_b64decode

    test_value = "L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=="
    test_key = b"YELLOW SUBMARINE"
    test_key = bytes_to_intlist(test_key)
    test_counter = AESCounter(b"\x00" * 8)

# Generated at 2022-06-12 16:25:08.933714
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    cleartext = bytes_to_intlist('cleartext to encrypt')
    key_bytes = compat_b64decode('QSxCRUdJTiBDQU1FUklDIENFUlRJRklDQVRFLU1BSUxJU0FELU1FVEhPRDBXUjJGMVp5OWphR2x2YjNkaU1RPT0KQ1JFQVRFVE9LRVIgQ0FNQVJJQy1DQVJUSUZJQ0FURS1NQVJLSU5HIE1FVEhPRDBXUjJGMVp5OWphR2x2YjNkaU1RPT0K')
    key = bytes_to_intlist(key_bytes[:32])
    iv = bytes_to_int

# Generated at 2022-06-12 16:25:26.493380
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    test_data = b'1234'
    test_key = b'YELLOW SUBMARINE'
    test_iv = [0] * BLOCK_SIZE_BYTES

    encrypted_data = aes_cbc_encrypt(bytes_to_intlist(test_data),
                                     bytes_to_intlist(test_key),
                                     test_iv)
    expected_data = [226, 134, 200, 115, 212, 137, 169, 81, 112, 117, 57, 127, 253, 52, 120, 101]
    assert encrypted_data == expected_data



# Generated at 2022-06-12 16:25:32.428614
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """
    AES CBC Decrypt test vectors from NIST FIPS 197 Appendix C
    """

# Generated at 2022-06-12 16:25:44.601654
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Input:
    # data = 0x3736414c6d366b7337735846786c316e
    # key = 0x320A74175DF7E8DA2F9F009D0E8629A3
    # iv = 0x30B5C299F5CA2E427DDF9676B9CFE4E4
    # Output:
    # 0xFEF6A5E6134C0CF8F97948D7F9A2E2F7
    data = bytes_to_intlist('3736414c6d366b7337735846786c316e')
    key = bytes_to_intlist('320A74175DF7E8DA2F9F009D0E8629A3')

# Generated at 2022-06-12 16:25:52.833067
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    cipher = bytes_to_intlist(compat_b64decode('L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode('YELLOW SUBMARINE'))
    counter = Counter()

    plain = aes_ctr_decrypt(cipher, key, counter)
    assert intlist_to_bytes(plain) == b"Yo, VIP Let's kick it Ice, Ice, baby Ice, Ice, baby "



# Generated at 2022-06-12 16:26:06.015830
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """
    Unit test for function aes_cbc_decrypt

    @returns {None}
    """
    import unittest

    class AesCbcDecryptTest(unittest.TestCase):
        def test_vectors(self):
            key = bytes_to_intlist(compat_b64decode(
                'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4'))
            iv = bytes_to_intlist(compat_b64decode(
                'ZWVmZ2hpamtsbW5vcA=='))

# Generated at 2022-06-12 16:26:17.019697
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-12 16:26:30.487266
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """
    Test for function aes_cbc_decrypt
    """

# Generated at 2022-06-12 16:26:41.882785
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:26:55.060220
# Unit test for function aes_encrypt
def test_aes_encrypt():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    data = [0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff]


# Generated at 2022-06-12 16:27:05.819438
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode(b'CmUJYWNEi8sTtP/rJTKvAg=='))
    iv = bytes_to_intlist(compat_b64decode(b'FwRhDhIzOS1KjUh6cG0XhQ=='))
    data = bytes_to_intlist(compat_b64decode(b'W1tZh9sZDgjKpv3Oq3Aj/acw/Smlqctp/uq3qE+jVf4='))
    assert  (b'0123456789' == intlist_to_bytes(aes_cbc_decrypt(data, key, iv)))

# Generated at 2022-06-12 16:27:14.262825
# Unit test for function inc
def test_inc():
    start_value = [255, 255, 255, 0]
    end_value = [0, 0, 0, 1]
    assert end_value == inc(start_value)



# Generated at 2022-06-12 16:27:22.913300
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    aes_ctr_decrypt([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], IncrementalCounter(0))

from .aes import aes_encrypt
from .utils import intlist_to_bytes, xor
from .compat import compat_b64decode
from .crypto import key_expansion
from .utils import bytes_to_intlist
from math import ceil

# Generated at 2022-06-12 16:27:34.391113
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    password = "password"
    data = "hiO5Q4b4Z/O4jKt/rf0L+hNtSxBtME9BKj+8tN7PzLE="
    expected = "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus."

    decrypted = aes_decrypt_text(data, password, key_size_bytes=16)
    assert decrypted == expected, "Sorry, this implementation cannot decrypt this. Maybe you used the wrong password?"


# Generated at 2022-06-12 16:27:46.246068
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-12 16:27:55.307840
# Unit test for function inc
def test_inc():
    if(inc([0xFF, 0xFF, 0xFF, 0xFF]) != [0x00, 0x00, 0x00, 0x00]):
        print("Error 1 in function inc")
    if(inc([0x00, 0x00, 0x00, 0xFF]) != [0x00, 0x00, 0x01, 0x00]):
        print("Error 2 in function inc")
    if(inc([0x00, 0x00, 0xFF, 0xFF]) != [0x00, 0x01, 0x00, 0x00]):
        print("Error 3 in function inc")

# Generated at 2022-06-12 16:28:03.255485
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test the following
    @param: data - string
    @param: password - string
    @param: key_size_bytes - int
    @returns: decrypted data - string
    """
    data = "QxpQ60Wd0XmY0Mk34BmD+g=="
    password = "test"
    key_size_bytes = 16
    decrypted_data = aes_decrypt_text(data, password, key_size_bytes)
    assert decrypted_data == "hello world!"



# Generated at 2022-06-12 16:28:15.266371
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = (0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6, 0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C)
    iv = (0xF0, 0xF1, 0xF2, 0xF3, 0xF4, 0xF5, 0xF6, 0xF7, 0xF8, 0xF9, 0xFA, 0xFB, 0xFC, 0xFD, 0xFE, 0xFF)

# Generated at 2022-06-12 16:28:27.523422
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Unit test for function aes_decrypt_text
    """
    # Decrypted value with password 'test' and key size 32
    target_value = '{ "text": "test", "number": 123, "boolean": true, "array": ["a", "b", "c"]}'.encode('utf-8')

    # Encrypted value with password 'test', key size 32, nonce 'testtesttest' and
    # cipher text '{"text":"test","number":123,"boolean":true,"array":["a","b","c"]}'
    encrypted_value = '8WZUVfz9a2eCnYzvDdWbsnS5gJrBjL5Hd3D2nh4b4XtG+zt1cHDt8WZUVfz9a2eC'

# Generated at 2022-06-12 16:28:39.035289
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class MyCounter(object):
        def next_value(self):
            self.n = self.n + 1 if hasattr(self, 'n') else 0
            return self.n

    cipher = ''
    key = bytes_to_intlist(b'the key 123456789012345')
    counter = MyCounter()
    decrypted_data = aes_ctr_decrypt(cipher, key, counter)
    assert not decrypted_data, 'Empty cipher should be decrypted as empty data'


# Generated at 2022-06-12 16:28:51.756242
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class TestCounter(object):

        def __init__(self, initial_value):
            self.value = initial_value[:]

        def next_value(self):
            value = self.value
            self.value = self.value[:BLOCK_SIZE_BYTES - 1] + [(value[BLOCK_SIZE_BYTES - 1] + 1) % 256]
            return value


# Generated at 2022-06-12 16:29:05.782325
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
    iv = [0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]

# Generated at 2022-06-12 16:29:18.192452
# Unit test for function key_expansion
def test_key_expansion():
    key_16 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7,
              0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:29:30.939689
# Unit test for function inc
def test_inc():
    test_data = [0x00, 0x01, 0x02, 0x03]
    result = [0x00, 0x01, 0x02, 0x04]
    assert inc(test_data) == result

    test_data = [0x00, 0x01, 0x02, 0xfc]
    result = [0x00, 0x01, 0x02, 0xfd]
    assert inc(test_data) == result

    test_data = [0x00, 0x01, 0x02, 0xff]
    result = [0x00, 0x01, 0x03, 0x00]
    assert inc(test_data) == result

    test_data = [0x00, 0x01, 0xff, 0xfe]

# Generated at 2022-06-12 16:29:34.116838
# Unit test for function inc
def test_inc():
    data = [255] * 16
    data = inc(data)
    assert(data == [0] * 15 + [1]), "inc test fail"


# Generated at 2022-06-12 16:29:44.388310
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b"140b41b22a29beb4061bda66b6747e14")
    iv = bytes_to_intlist(b"4ca00ff4c898d61e1edbf1800618fb28")
    data = bytes_to_intlist(b"This is a 48-byte message (exactly 3 AES blocks)")
    expected_result = bytes_to_intlist(b"28a226d160dad07883d04e008a7897ee2e4b7465d5290d0c0e6c6822236e1daafb94ffe0c5da05d9476be028ad7c1d81")
    result = aes_cbc_encrypt(data, key, iv)
    assert result == expected_result


# Generated at 2022-06-12 16:29:57.037819
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    """
    Comments
    """
    test_data = bytes_to_intlist('Hello')
    test_key = bytes_to_intlist('1234567890123456')
    test_IV = bytes_to_intlist('1234567890123456')
    enc = [0x6f, 0xb3, 0x2c, 0xef, 0xa1, 0xb8, 0x9d, 0xcf, 0x00, 0xca, 0x1f, 0x81, 0x54, 0x2c, 0x2d, 0x02]
    test1 = aes_cbc_encrypt(test_data, test_key, test_IV)

# Generated at 2022-06-12 16:30:08.076824
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    debug = True
    if debug:
        print("Testing aes_cbc_encrypt...")
    data = bytes_to_intlist(compat_b64decode(
        b'stMg6hYjYdUbMs5bxKiB5I5IQSaj5P8hhFj0E5Zepz0='))
    key = bytes_to_intlist(compat_b64decode(
        b'mji9dxG+TFMc1VidRQKQ2Q=='))
    iv = bytes_to_intlist(compat_b64decode(
        b'e8d5w5bHn5B5CpS5yihzAQ=='))

# Generated at 2022-06-12 16:30:20.268552
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b'1234567890ABCDEF')
    key = bytes_to_intlist(compat_b64decode(b'f/Ne+uL7VwOq1uK7J3dRxQ=='))
    iv = bytes_to_intlist(compat_b64decode(b'uK7+PxLflsxnxJXy0IpHBw=='))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    encrypted_data_string = ''.join(['%02x' % b for b in encrypted_data])
    assert encrypted_data_string == 'de0c6ee0f858e0806c4a6a4f6aaae3d8'



# Generated at 2022-06-12 16:30:28.085671
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # check function with different keys
    key16 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    key24 = [0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5, 0x62, 0xf8, 0xea, 0xd2, 0x52, 0x2c, 0x6b, 0x7b]

# Generated at 2022-06-12 16:30:40.945024
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test case 1
    data = []
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    expected = [0x76, 0x49, 0xab, 0xac, 0x81, 0x19, 0xb2, 0x46, 0xce, 0xe9, 0x8e, 0x9b, 0x12, 0xe9, 0x19, 0x7d]
    actual = aes_

# Generated at 2022-06-12 16:30:51.618412
# Unit test for function key_expansion
def test_key_expansion():
    data=compat_b64decode(b'QkUgU1VSRSBUTyBEUklOSyBZT1VSIE9WQUxUSU5F')
    key=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    cipher=key_expansion(key)
    if len(cipher)==240:
        print("Test passed")
    else:
        print("Test failed")
test_key_expansion()


# Generated at 2022-06-12 16:31:04.100189
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:15.459935
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:28.049624
# Unit test for function key_expansion
def test_key_expansion():
    key16 = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
    key24 = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,0,1,2,3,4,5,6,7]
    key32 = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]

# Generated at 2022-06-12 16:31:35.717277
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c'.decode('hex'))
    expanded_key = key_expansion(key)


# Generated at 2022-06-12 16:31:47.484032
# Unit test for function key_expansion
def test_key_expansion():
    assert (key_expansion([0] * 16) == [0] * 176)
    assert (key_expansion([0] * 24) == [0] * 208)
    assert (key_expansion([0] * 32) == [0] * 240)

# Generated at 2022-06-12 16:31:57.487476
# Unit test for function key_expansion
def test_key_expansion():
    key_16 = [
        0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6,
        0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    key_24 = [
        0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52,
        0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5,
        0x62, 0xf8, 0xea, 0xd2, 0x52, 0x2c, 0x6b, 0x7b]

# Generated at 2022-06-12 16:32:09.603418
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(compat_b64decode('qCfQeN/bzfSloTlNn97TCQ=='))
    result = key_expansion(data)
    expected = bytes_to_intlist(compat_b64decode('qCfQeN/bzfSloTlNn97TCQS9bSZvSTTZ1i8s1sHpwe4='))
    assert result == expected

    data = bytes_to_intlist(compat_b64decode('wQ15rlx/gU6y+D6fLRzmKnX9V7GDHZQY'))
    result = key_expansion(data)

# Generated at 2022-06-12 16:32:18.092379
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:30.231920
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(b'\x2b\x7e\x15\x16\x28\xae\xd2\xa6\xab\xf7\x15\x88\x09\xcf\x4f\x3c')

# Generated at 2022-06-12 16:32:43.495680
# Unit test for function key_expansion
def test_key_expansion():
    """
    Test of key expansion from RFC3610
    """

    key_128 = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:32:55.598105
# Unit test for function key_expansion

# Generated at 2022-06-12 16:33:06.721466
# Unit test for function key_expansion
def test_key_expansion():
    plain_key = bytes_to_intlist(compat_b64decode(
        'yfjK8tdvh6sVCF6Zcjo6ZxBeFCqL3X4S'))

# Generated at 2022-06-12 16:33:18.618728
# Unit test for function key_expansion
def test_key_expansion():
    print("Expected result 128 bit key :")
    print("2b 7e 15 16 28 ae d2 a6 ab f7 15 88 09 cf 4f 3c")
    print("Result:")
    print(*key_expansion([0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]))
    print("Expected result 192 bit key :")
    print("8e a2 b7 ca 51 67 45 bf ea fc 49 90 4b 49 60 89")
    print("Result:")