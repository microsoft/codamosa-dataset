

# Generated at 2022-06-12 16:23:50.868427
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = bytes_to_intlist(compat_b64decode('8A5W0gv03ANDKpVQBZUJ8w=='))
    iv = bytes_to_intlist(compat_b64decode('srPxoZ6iR8F0IluBvCh5Mg=='))
    cipher = bytes_to_intlist(compat_b64decode('W8eDG5JZEz3qU3LdUz8bvHYF6xEg/RKlGnfLC6v/iQo='))
    data = aes_cbc_decrypt(cipher, key, iv)
    data = intlist_to_bytes(data)

# Generated at 2022-06-12 16:23:58.890883
# Unit test for function key_expansion
def test_key_expansion():
    """
    Unit test
    """
    key = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

# Generated at 2022-06-12 16:24:11.408230
# Unit test for function inc
def test_inc():
    assert inc([0x00, 0x00, 0x00, 0x00]) == [0x00, 0x00, 0x00, 0x01]
    assert inc([0x00, 0x00, 0x00, 0xFF]) == [0x00, 0x00, 0x01, 0x00]
    assert inc([0x00, 0x00, 0xFF, 0xFF]) == [0x00, 0x01, 0x00, 0x00]
    assert inc([0x00, 0xFF, 0xFF, 0xFF]) == [0x01, 0x00, 0x00, 0x00]
    assert inc([0xFF, 0xFF, 0xFF, 0xFF]) == [0x00, 0x00, 0x00, 0x00]



# Generated at 2022-06-12 16:24:20.269701
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    # Example from https://csrc.nist.gov/projects/cryptographic-standards-and-guidelines/example-values
    KEY = bytes_to_intlist('2b7e151628aed2a6abf7158809cf4f3c')
    CIPHER = bytes_to_intlist('874d6191b620e3261bef6864990db6ce')
    COUNTER_BLOCK = bytes_to_intlist('f0f1f2f3f4f5f6f7f8f9fafbfcfdfeff')
    PLAINTEXT = bytes_to_intlist('6bc1bee22e409f96e93d7e117393172a')

    class Counter:

        def next_value(self):
            return COUNTER_BLOCK

    counter = Counter()


# Generated at 2022-06-12 16:24:33.269829
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    import re
    # Verifying that decryption function returned the expected result
    # for the test string encrypted with the test password
    def validate_decryption(decrypted_text):
        valid_decrypted_text = re.sub('(\\{.*?\\}){1,}', '<switch_protocols>', decrypted_text)
        assert valid_decrypted_text == 'This is a test string. It contains utf-8 characters as well äöüß.'

    # Testing encrypted strings with different lengths

# Generated at 2022-06-12 16:24:38.808955
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    TEST_INPUTS = (
        # (decoded text, password, key_size_bytes)
        ('3q2+7w==', 'password', 16),
        ('3q2+7/I=', 'password', 24),
        ('3q2+7/Cs', 'password', 32),
    )
    for input_idx, (decoded_text, password, key_size_bytes) in enumerate(TEST_INPUTS):
        assert aes_decrypt_text(decoded_text, password, key_size_bytes) == b'foobar'

# Generated at 2022-06-12 16:24:44.572914
# Unit test for function aes_decrypt
def test_aes_decrypt():
    cipher = bytes_to_intlist(compat_b64decode(b'rZgjKan+hPvLsP2W8ikJjg=='))
    key = bytes_to_intlist(b'BadPassword')
    expanded_key = key_expansion(key)
    data = aes_decrypt(cipher, expanded_key)
    assert data == [27, 91, 234, 218, 206, 198, 223, 19, 215, 103, 183, 62, 20,
                    114, 125, 116]



# Generated at 2022-06-12 16:24:54.216178
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """aes_cbc_decrypt unit test"""
    key = bytes_to_intlist(b"9C4B4C4F4E4A4B4B")
    iv = bytes_to_intlist(b"0000000000000000")
    encrypted = bytes_to_intlist(b"FFBECB87BCF46C55BCB3C3B9C907D8BEA8A14CB722940F0E")
    decrypted = aes_cbc_decrypt(encrypted, key, iv)
    assert decrypted == bytes_to_intlist(b"0000000000000000")



# Generated at 2022-06-12 16:25:06.120039
# Unit test for function key_expansion

# Generated at 2022-06-12 16:25:17.418873
# Unit test for function aes_decrypt
def test_aes_decrypt():
    simple_key = 0x000102030405060708090A0B0C0D0E0F
    simple_key = bytes_to_intlist(simple_key.to_bytes(16, endian='little'))

    simple_data = 0x00112233445566778899AABBCCDDEEFF

    decrypted_data = 0x69C4E0D86A7B0430D8CDB78070B4C55A

    expanded_key = key_expansion(simple_key)
    encrypted_data = aes_encrypt(bytes_to_intlist(simple_data.to_bytes(16, endian='little')), expanded_key)

    assert intlist_to_bytes(encrypted_data) == decrypted_data.to_bytes(16, endian='little')

    dec

# Generated at 2022-06-12 16:25:34.883366
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    input = 'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='
    key = 'YELLOW SUBMARINE'
    counter = Counter(0)
    data = aes_ctr_decrypt(
        bytes_to_intlist(compat_b64decode(input)),
        bytes_to_intlist(key), counter)
    assert intlist_to_bytes(data) == b"Yo, VIP Let's kick it Ice, Ice, baby Ice, Ice, baby "



# Generated at 2022-06-12 16:25:47.201848
# Unit test for function key_expansion
def test_key_expansion():
    print("--------------Test key_expansion--------------")
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:25:55.195262
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .aes_cipher_counter import AESCipherCounterIVPlus
    data = bytes_to_intlist('This is a test!')
    key = bytes_to_intlist('YELLOW SUBMARINE')
    counter = AESCipherCounterIVPlus(bytes_to_intlist('\x00' * 16))
    encryption_result = 'H\xcc\xb3\x91g\xf2~\x9b\x91\x18\xae\xd1\x8b\x88\xcdi'
    assert(intlist_to_bytes(aes_ctr_decrypt(bytes_to_intlist(encryption_result), key, counter)) == intlist_to_bytes(data))
# end Unit test for function aes_ctr_decrypt


# Generated at 2022-06-12 16:26:07.293699
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self._value = value

        def next_value(self):
            self._value += 1
            return self._value

    key = [0x00010203, 0x04050607, 0x08090A0B, 0x0C0D0E0F]
    counter = Counter(0)
    data = [0x69, 0xC4, 0xE0, 0xD8, 0x6A, 0x7B, 0x04, 0x30, 0xD8, 0xCD, 0xB7, 0x80, 0x70, 0xB4, 0xC5, 0x5A]
    data = aes_ctr_decrypt(data, key, counter)

# Generated at 2022-06-12 16:26:17.975691
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = bytes_to_intlist(b'YELLOW SUBMARINE')
    iv = bytes_to_intlist(b'\x00' * BLOCK_SIZE_BYTES)
    data = bytes_to_intlist(b'a secret message')
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    print(encrypted_data)
    print(intlist_to_bytes(encrypted_data))
    # 0x28a72324f0d6a3b6f2c6e88e0a72f8d8
    # b'($\x92/F\rj;o,n\x88\xe0\xa7/\xd8'

# Generated at 2022-06-12 16:26:24.438320
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    """
    Test function aes_decrypt_text
    """
    data = '3q2+796tvu/erb7v3q2+796tvu/erb7v3q2+796tvu/erb6AAAAAAAAAAAAAAAAAAAAA'
    assert aes_decrypt_text(data, 'foobar', 32) == 'barfoo'



# Generated at 2022-06-12 16:26:37.167155
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .utils import intlist_to_bytes, intlist_to_hex
    from .aes import aes_decrypt
    from .counter import Counter
    import base64

    key_hex = "000102030405060708090a0b0c0d0e0f"
    encrypted_hex = (
        "69c4e0d86a7b0430d8cdb78070b4c55a"
        "d79e5d5b50e6d53f2d8b08f8e3d3c266")
    encrypted = bytes_to_intlist(intlist_to_bytes(
        encrypted_hex, 'little').decode('hex'))

# Generated at 2022-06-12 16:26:45.686117
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-12 16:26:55.056531
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    key = compat_b64decode('KUEh/f5d5FZVTg==')
    cipher = compat_b64decode('B+FN9yudhNbWOaJd+CjuQHZLbA')
    counter = Iterator(aes_cbc_decrypt(cipher, key[:16], key[16:]))
    assert intlist_to_bytes(aes_ctr_decrypt(bytes_to_intlist(cipher), bytes_to_intlist(key), counter)).decode() == 'Hello World'


# Generated at 2022-06-12 16:27:06.146963
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = "CQ4sKs25sRkZDVYqG3uq7A=="
    data = bytes_to_intlist(compat_b64decode(data))
    data = data[:32]
    key = "B7lgfJZzp+j0BtGz1j9qiA=="
    key = bytes_to_intlist(compat_b64decode(key))
    class Counter:
        def __init__(self):
            self.count = 0
        def next_value(self):
            if self.count == 0:
                counter = '\x00' * 16
            elif self.count == 1:
                counter = '\x01' * 16
            else:
                raise Exception("Only 2 blocks supported")
            self.count += 1


# Generated at 2022-06-12 16:27:24.482052
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = "140b41b22a29beb4061bda66b6747e14"
    cleartext = "4ca00ff4c898d61e1edbf1800618fb2828a226d160dad07883d04e008a7897ee2e4b7465d5290d0c0e6c6822236e1daafb94ffe0c5da05d9476be028ad7c1d81"
    iv = "000102030405060708090a0b0c0d0e0f"

# Generated at 2022-06-12 16:27:36.114690
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # https://tools.ietf.org/html/rfc3602#section-4
    iv = bytes_to_intlist(b"\x56\x2e\x17\x99\x6d\x09\x3d\x28\xdd\xb3\xba\x69\x5a\x2e\x6f\x58")
    key = bytes_to_intlist(b"\xae\x68\x52\xf8\x12\x10\x67\xcc\x4b\xf7\xa5\x76\x55\x77\xf3\x9e")

# Generated at 2022-06-12 16:27:47.945912
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    key = [ 0x2b,0x7e,0x15,0x16,0x28,0xae,0xd2,0xa6,0xab,0xf7,0x15,0x88,0x09,0xcf,0x4f,0x3c ]
    iv  = [ 0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f ]

# Generated at 2022-06-12 16:27:56.432289
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-12 16:28:08.786040
# Unit test for function aes_cbc_encrypt

# Generated at 2022-06-12 16:28:14.606942
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    assert (aes_cbc_encrypt(b'YELLOW_SUBMARINE', list(map(ord, "YELLOW SUBMARINE")), [0]*16) ==
            bytes_to_intlist(compat_b64decode('lCpSk/KzMpl1rcZNmuUDbA==')))


# Generated at 2022-06-12 16:28:25.952575
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    cleartext1 = bytes_to_intlist(b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00")
    plaintext1 = bytes_to_intlist(b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00")
    ciphertext1 = aes_cbc_encrypt(plaintext1, cleartext1, cleartext1)

# Generated at 2022-06-12 16:28:36.383749
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist(b'This is a test!')
    key = bytes_to_intlist(b'0123456789ABCDEF')
    iv = bytes_to_intlist(b'0000000000000000')
    encrypted_data = aes_cbc_encrypt(data, key, iv)

# Generated at 2022-06-12 16:28:44.336968
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    # Test vectors are taken from https://www.rfc-editor.org/rfc/rfc3602.txt
    cleartext = bytes_to_intlist(compat_b64decode("YELLOW SUBMARINE"))
    cipherkey = bytes_to_intlist(compat_b64decode("YELLOW SUBMARINE"))
    iv = bytes_to_intlist(compat_b64decode("YELLOW SUBMARINE"))

    result = intlist_to_bytes(aes_cbc_encrypt(cleartext, cipherkey, iv))
    expected_result = compat_b64decode("jcW8e+/unFgBZNmpf/T7TsrJYrN+7c1GwzJbg+W8mfzg=")


# Generated at 2022-06-12 16:28:57.569216
# Unit test for function key_expansion

# Generated at 2022-06-12 16:29:08.780399
# Unit test for function key_expansion
def test_key_expansion():
    key128 = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-12 16:29:21.727506
# Unit test for function key_expansion
def test_key_expansion():
    print("Test for key_expansion")
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    #expanded 128-bit key

# Generated at 2022-06-12 16:29:34.646455
# Unit test for function key_expansion
def test_key_expansion():
    key = [40, 47, 57, 49, 66, 54, 41, 54, 67, 54, 71, 69, 73, 54, 75, 54]
    expanded_key = key_expansion(key)


# Generated at 2022-06-12 16:29:41.378106
# Unit test for function key_expansion
def test_key_expansion():
    # Key size: 128 bit
    data = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    result = key_expansion(data)

# Generated at 2022-06-12 16:29:52.825566
# Unit test for function key_expansion

# Generated at 2022-06-12 16:30:04.802321
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    expanded_key = key_expansion(key)


# Generated at 2022-06-12 16:30:11.880711
# Unit test for function key_expansion
def test_key_expansion():
    testset = []
    with open('test/key_expansion.txt') as f:
        f.readline()
        for line in f:
            key_size, key, expanded_key = line.strip().split('|')
            testset.append((
                int(key_size),
                bytes_to_intlist(compat_b64decode(key)),
                bytes_to_intlist(compat_b64decode(expanded_key))
            ))
    for i, test in enumerate(testset):
        if key_expansion(test[1]) != test[2]:
            raise Exception('Test %s failed' % i)



# Generated at 2022-06-12 16:30:19.719637
# Unit test for function key_expansion
def test_key_expansion():
    from .test_data import KEY_EXPANSION_TEST_DATA
    for key, expanded_key in KEY_EXPANSION_TEST_DATA.items():
        key = bytes_to_intlist(compat_b64decode(key))
        expanded_key = bytes_to_intlist(compat_b64decode(expanded_key))
        assert key_expansion(key) == expanded_key
test_key_expansion()



# Generated at 2022-06-12 16:30:28.246819
# Unit test for function key_expansion
def test_key_expansion():
    test_keys = [
        [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c],
        [0x8e, 0x73, 0xb0, 0xf7, 0xda, 0x0e, 0x64, 0x52, 0xc8, 0x10, 0xf3, 0x2b, 0x80, 0x90, 0x79, 0xe5,
         0x62, 0xf8, 0xea, 0xd2, 0x52, 0x2c, 0x6b, 0x7b]
        ]

# Generated at 2022-06-12 16:30:41.383161
# Unit test for function key_expansion
def test_key_expansion():
    import random
    import sys
    import struct
    from base64 import b64encode

    def test_key(key):
        def byte_to_hex(byte):
            return '%02X' % byte
        key_size_bytes = len(key)
        assert key_size_bytes in (16, 24, 32), 'Invalid key size %d' % key_size_bytes
        key_expanded = key_expansion(key)
        key_expanded_size_bytes = len(key_expanded)
        assert key_expanded_size_bytes == (key_size_bytes // 4 + 7) * BLOCK_SIZE_BYTES, \
            'Invalid expanded key size %d' % key_expanded_size_bytes
        return ''.join(map(byte_to_hex, key_expanded))

   

# Generated at 2022-06-12 16:30:54.844498
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:07.206496
# Unit test for function key_expansion
def test_key_expansion():
    data = bytes_to_intlist(compat_b64decode("vYsxq3ys4sG8fKSmM1w6BfaS6dSzABXK"))
    expected_result = bytes_to_intlist(compat_b64decode("fSilg6i1KBbX9XzkTMGKPx6mQ0F2ZPy6jZU6Ip23Jcv1f6H9XWG7U+MxNM3s4N4JlZj+f/afL1/T0Sd/S+jTQ=="))
    expanded_key = key_expansion(data)
    assert expanded_key == expected_result


# Generated at 2022-06-12 16:31:18.853866
# Unit test for function key_expansion

# Generated at 2022-06-12 16:31:30.785351
# Unit test for function key_expansion
def test_key_expansion():
    # 128-bit key
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:31:42.721372
# Unit test for function key_expansion
def test_key_expansion():
    key192 = [43, 126, 21, 22, 40, 174, 210, 166, 171, 247, 21, 136, 9, 207, 79, 60, 0, 166, 57, 64, 16, 132, 11, 68, 9, 104, 111, 97, 203, 40]

# Generated at 2022-06-12 16:31:54.092588
# Unit test for function key_expansion
def test_key_expansion():
    key_size = 16
    key = []
    for i in range(key_size):
        key += [i]
    expanded_key = key_expansion(key)

# Generated at 2022-06-12 16:32:01.032738
# Unit test for function key_expansion

# Generated at 2022-06-12 16:32:12.428880
# Unit test for function key_expansion
def test_key_expansion():
    tests = [
        ("140b41b22a29beb4061bda66b6747e14", "140b41b22a29beb4061bda66b6747e14ac0d8f8f16e67b7a3b3c2f26"),
        ("140b41b22a29beb4061bda66b6747e14ac0d8f8f16e67b7a3b3c2f26", "140b41b22a29beb4061bda66b6747e14ac0d8f8f16e67b7a3b3c2f26f6c4115a4f4135c2607c25d02a9")
    ]


# Generated at 2022-06-12 16:32:19.749042
# Unit test for function key_expansion
def test_key_expansion():
    assert key_expansion([0x0]*16) == []

# Generated at 2022-06-12 16:32:32.227898
# Unit test for function key_expansion
def test_key_expansion():
    key = bytes_to_intlist(compat_b64decode('+97tDy/tDSASL8uqJp+Vh5uc9l5x5RWJixDnhRV7KdE='))
    assert len(key) == 32
    expanded_key = key_expansion(key)

# Generated at 2022-06-12 16:32:45.985930
# Unit test for function key_expansion
def test_key_expansion():
    key = intlist_to_bytes(range(16))
    expanded_key = key_expansion(key)
    assert len(expanded_key) == 176
    assert expanded_key[:16] == key

# Generated at 2022-06-12 16:32:59.289949
# Unit test for function key_expansion
def test_key_expansion():
    """
    Test for function key_expansion

    @see http://csrc.nist.gov/groups/STM/cavp/documents/aes/KAT_AES.zip
    """

# Generated at 2022-06-12 16:33:08.026120
# Unit test for function key_expansion
def test_key_expansion():
    """
    Unit test for function key_expansion
    """
    if not hasattr(test_key_expansion, 'has_run'):
        test_key_expansion.has_run = False

    if test_key_expansion.has_run:
        return

    for key_size_bytes in [16, 24, 32]:
        for key in range(1 << (key_size_bytes * 8)):
            key = bytes_to_intlist(intlist_to_bytes(key, key_size_bytes))
            expanded_key = key_expansion(key)
            assert sorted(set(expanded_key)) == [item for item in range(256)], (
                'Key expansion failed with key of size %d bytes and key %r' % (
                    key_size_bytes, key))
    test_key

# Generated at 2022-06-12 16:33:19.797734
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]
