

# Generated at 2022-06-12 16:23:46.688161
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key_hex = "140b41b22a29beb4061bda66b6747e14"
    iv_hex = "4ca00ff4c898d61e1edbf1800618fb28"
    cipher_hex = "28a226d160dad07883d04e008a7897ee2e4b7465d5290d0c0e6c6822236e1daafb94ffe0c5da05d9476be028ad7c1d81"

# Generated at 2022-06-12 16:23:55.712219
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:24:07.579182
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    iv = [
        0x54, 0x68, 0x61, 0x74,
        0x73, 0x20, 0x6D, 0x79,
        0x20, 0x4B, 0x75, 0x6E,
        0x67, 0x20, 0x46, 0x75
    ]
    data = 'asdf'
    key = "YELLOW SUBMARINE"
    expected_result = [
        0x87, 0x4D, 0x61, 0x91,
        0xB6, 0x20, 0xE3, 0x26,
        0x1B, 0xEF, 0x68, 0x64,
        0x99, 0x0D, 0xB6, 0xCE
    ]
    result = aes_cbc_enc

# Generated at 2022-06-12 16:24:17.670951
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    data = bytes_to_intlist('Hello World')
    key = bytes_to_intlist('1234567890123456')
    iv = bytes_to_intlist('abcdefghijklmnop')
    #print('len(data)', len(data))
    encrypted_data = aes_cbc_encrypt(data, key, iv)
    #print('len(encrypted_data)', len(encrypted_data))
    encrypted_data_hex = intlist_to_bytes(encrypted_data).encode('hex')
    assert encrypted_data_hex == 'dbaee93e0d8c8a16f5717e082f9b378d2e2a4dfdd76d3c4f58cca4c6e85e6bd0'
test_aes_cbc_encrypt()


# Generated at 2022-06-12 16:24:30.763257
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .crypto import aes_encrypt
    from .crypto import aes_ctr_decrypt
    from .crypto import aes_ctr_decrypt_text
    from .crypto import sbox
    from .crypto import inv_sbox
    from .crypto import rcon
    from .crypto import key_expansion
    from .crypto import mix_columns
    from .crypto import inv_mix_columns
    from .crypto import _add_round_key
    from .crypto import _sub_bytes
    from .crypto import _inv_sub_bytes
    from .crypto import _shift_rows
    from .crypto import _inv_shift_rows
    from .crypto import _mix_single_column
    from .crypto import _inv_mix_single_column

# Generated at 2022-06-12 16:24:37.571081
# Unit test for function aes_cbc_encrypt
def test_aes_cbc_encrypt():
    plaintext = '0123456789012345012345678901234501234567890123450123456789012345'
    key = '0f1571c947d9e8590cb7add6af7f6798'
    iv = '1247f23a385a6f12487512645f4a1284'

    ciphertext = '1abc9c3ff391f826d94f3f3b3e065b8733b9c1b2e40142d927e2a8f0c2d22321' + \
        'f67d1ad555b51ffaadb9cf628c93d47e3c83a1bc3a95c68e705d9a82b9c9208f'
    ciphertext = cipher

# Generated at 2022-06-12 16:24:45.878966
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = bytes_to_intlist(compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ=='))
    key = bytes_to_intlist(compat_b64decode(b'YELLOW SUBMARINE'))
    class Counter(object):
        def __init__(self, value):
            assert len(value) == BLOCK_SIZE_BYTES
            self.value = value
        def next_value(self):
            value = self.value[:]
            for i in range(BLOCK_SIZE_BYTES - 1, -1, -1):
                if self.value[i] == 255:
                    self

# Generated at 2022-06-12 16:24:58.563875
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    #source:  https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-38a.pdf
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]

# Generated at 2022-06-12 16:25:06.103681
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    data = '5c8d65f5198854b27a2d2f58c8f52800'.decode('hex')
    key = '3b3fd92eb72dad20333449f8e83cfb4a'.decode('hex')
    counter = Counter(0)
    result = aes_ctr_decrypt(data, key, counter)
    assert result == 'deebf1a86b7c8b69'.decode('hex')
# End unit test for function aes_ctr_decrypt



# Generated at 2022-06-12 16:25:17.420614
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:25:23.869692
# Unit test for function inc
def test_inc():
    data = [0,1,3,4]
    data_inc = inc(data)
    print(data_inc)
    print([0,2,3,4])

if __name__ == "__main__":
    test_inc()

# Generated at 2022-06-12 16:25:31.332026
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():

    def _test(test_input):
        data = bytes_to_intlist(compat_b64decode(test_input['cipher']))
        key = bytes_to_intlist(compat_b64decode(test_input['key']))
        iv = bytes_to_intlist(compat_b64decode(test_input['iv']))
        expected = compat_b64decode(test_input['plain'])

        decrypted_data = aes_cbc_decrypt(data, key, iv)
        assert intlist_to_bytes(decrypted_data) == expected


# Generated at 2022-06-12 16:25:43.834896
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    # Encrypt function
    def aes_encrypt_text(data, password, key_size_bytes):
        NONCE_LENGTH_BYTES = 8

        key = password[:key_size_bytes] + [0] * (key_size_bytes - len(password))
        key = aes_encrypt(key[:BLOCK_SIZE_BYTES], key_expansion(key)) * (key_size_bytes // BLOCK_SIZE_BYTES)

        nonce = [random.randint(0, 255) for _ in range(NONCE_LENGTH_BYTES)]

        class Counter(object):
            __value = nonce + [0] * (BLOCK_SIZE_BYTES - NONCE_LENGTH_BYTES)


# Generated at 2022-06-12 16:25:53.756417
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    class Counter(object):
        def __init__(self, value):
            self.value = value

        def next_value(self):
            self.value += 1
            return [ord(char) for char in compat_b64decode(to_base64(self.value, width=16))]
    data = intlist_to_bytes([0x69, 0xcf, 0x0b, 0xc3, 0xde, 0x7a, 0x0f, 0x46, 0x8a, 0xf5, 0x65, 0xd5, 0x7f, 0x6b, 0x2b, 0xdc])

# Generated at 2022-06-12 16:26:04.465954
# Unit test for function aes_decrypt
def test_aes_decrypt():
    key = bytes_to_intlist(compat_b64decode('N6F1U2/X9Jh/N+YnoYBZf/Q=='))
    cipher = bytes_to_intlist(compat_b64decode('pUEjYO5qcp7xkxniwI1H0A=='))
    expanded_key = key_expansion(key)
    decrypted_data = aes_decrypt(cipher, expanded_key)
    assert(intlist_to_bytes(decrypted_data) == compat_b64decode('wg/t0mVHj+E9l/Vl+DnYng=='))



# Generated at 2022-06-12 16:26:15.465529
# Unit test for function aes_ctr_decrypt
def test_aes_ctr_decrypt():
    from .utils import intlist_from_str, intlist_to_str
    from io import BytesIO
    data = compat_b64decode(b'L77na/nrFsKvynd6HzOoG7GHTLXsTVu9qvY/2syLXzhPweyyMTJULu/6/kXX0KSvoOLSFQ==')
    data = bytes_to_intlist(data)
    key = bytes_to_intlist(b'secret')
    ctr = Counter(1)
    assert intlist_to_str(aes_ctr_decrypt(data, key, ctr)) == 'Yo, VIP Let\'s kick it Ice, Ice, baby Ice, Ice, baby '



# Generated at 2022-06-12 16:26:28.038233
# Unit test for function aes_ctr_decrypt

# Generated at 2022-06-12 16:26:40.223798
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    XML = '<ROOT><HEADER>\x3C/HEADER><BODY>\x3C/BODY></ROOT>'

# Generated at 2022-06-12 16:26:53.429008
# Unit test for function aes_decrypt
def test_aes_decrypt():
    from .common import calculate_sha256sum
    from .compat import compat_b64decode

    def _assert_aes_decrypt(aes_key, aes_iv, expected_result, aes_encrypted_data):
        encrypted_data = bytes_to_intlist(aes_encrypted_data)
        key = bytes_to_intlist(aes_key)
        iv = bytes_to_intlist(aes_iv)
        expanded_key = key_expansion(key)
        block_count = int(ceil(float(len(encrypted_data)) / BLOCK_SIZE_BYTES))
        decrypted_data = []
        previous_cipher_block = iv

# Generated at 2022-06-12 16:27:03.541628
# Unit test for function aes_decrypt_text
def test_aes_decrypt_text():
    data = 'QvS+5F5L5Y+U6wQ='
    password = 'test'
    assert aes_decrypt_text(data, password, 16) == b'test'
    data = '1dJPLneiKj3LWz9XqVuJhQ=='
    password = 'key'
    assert aes_decrypt_text(data, password, 32) == b'data'
    data = 'TfoTb7RSxHheZrt1KGmd/g=='
    password = 'test'
    assert aes_decrypt_text(data, password, 24) == b'data'
    assert True



# Generated at 2022-06-12 16:27:23.604287
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [38, 48, 64, 73, 95, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117, 117]
    iv = [97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97, 97]

# Generated at 2022-06-12 16:27:35.134013
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test the decryption of an empty String
    data = bytes()
    key = bytes(b'\x00' * 16)
    iv = bytes(b'\x00' * 16)
    decrypted = aes_cbc_decrypt(bytes_to_intlist(data), bytes_to_intlist(key), bytes_to_intlist(iv))
    assert intlist_to_bytes(decrypted) == b''

    # Test the decryption of a 16 byte String
    data = bytes(b'\x00' * 16)
    key = bytes(b'\x00' * 16)
    iv = bytes(b'\x00' * 16)

# Generated at 2022-06-12 16:27:46.959978
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """ Unit test for function aes_cbc_decrypt """
    from .aes import aes_cbc_encrypt
    data = bytes_to_intlist("we will rock you ")
    key = [
        0xDC, 0xFB, 0x1C, 0x55, 0x7A, 0x47, 0xBA, 0xFE,
        0x76, 0xFA, 0xFE, 0x42, 0x87, 0x3C, 0x5D, 0x9B
    ]

# Generated at 2022-06-12 16:27:55.782577
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    testfile = open('tests/test_aes_cbc_decrypt.txt', 'r')
    for line in testfile:
        line = line.strip()
        if line:
            param, result = line.split('->')
            param = param.split()
            key = bytes_to_intlist(compat_b64decode(param[0]))
            iv = bytes_to_intlist(compat_b64decode(param[1]))
            data = bytes_to_intlist(compat_b64decode(param[2]))
            actual_result = intlist_to_bytes(
                aes_cbc_decrypt(data, key, iv)).strip(b'\0')

# Generated at 2022-06-12 16:28:07.930646
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    cipher = "C97A65E275D2E0C0526B2DFC3F3C8D0B"
    key = "C5B5B5B5B5B5B5B5C5B5B5B5B5B5B5B5"
    iv = "00000000000000000000000000000000"

    cipher = intlist_to_bytes(bytes_to_intlist(util.hex_decode(cipher)))
    key = intlist_to_bytes(bytes_to_intlist(util.hex_decode(key)))
    iv = intlist_to_bytes(bytes_to_intlist(util.hex_decode(iv)))

    msg = aes_cbc_decrypt(cipher, key, iv)

# Generated at 2022-06-12 16:28:18.121527
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # http://csrc.nist.gov/publications/fips/fips197/fips-197.pdf Appendix C.3
    key = [0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c]
    iv = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f]

# Generated at 2022-06-12 16:28:22.361270
# Unit test for function inc
def test_inc():
    data = list(range(16))
    for i in range(256):
        data_inc = inc(data)
        assert data_inc == [x + 1 for x in data]
        data = data_inc
test_inc()



# Generated at 2022-06-12 16:28:30.494552
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:28:41.137407
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
	# Test example from http://tools.ietf.org/html/rfc3602#section-3
	data = bytes_to_intlist(b'4ca00ff4c898d61e1edbf1800618fb2828a226d160dad07883d04e008a7897ee2e4b7465d5290d0c0e6c6822236e1daafb94ffe0c5da05d9476be028ad7c1d81')
	key = bytes_to_intlist(b'140b41b22a29beb4061bda66b6747e14')
	iv = bytes_to_intlist(b'4ca00ff4c898d61e1edbf1800618fb28')

# Generated at 2022-06-12 16:28:53.685675
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    iv = [0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
          0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01]


# Generated at 2022-06-12 16:29:10.487156
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    import random
    from .aes import gen_key

    for round in range(16):
        for i in range(1, 17):
            key = gen_key()
            data = [random.randint(0, 255) for _ in range(i)]
            iv = gen_key()

            encrypted = aes_cbc_encrypt(data, key, iv)
            decrypted = aes_cbc_decrypt(encrypted, key, iv)

            assert len(data) == len(decrypted)
            assert data == decrypted

            if i % BLOCK_SIZE_BYTES == 0:
                encrypted0 = encrypted[:(i // BLOCK_SIZE_BYTES) * BLOCK_SIZE_BYTES]
                decrypted0 = aes_cbc_decrypt(encrypted0, key, iv)

                encrypted

# Generated at 2022-06-12 16:29:23.120620
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    print('Testing phase: aes_cbc_decrypt')
    # Testing phase for aes_cbc_decrypt
    test_ciphertext = 'b9c9f1240fcbce57d7204fcf0f33b50f'
    test_key = 'f020a9a1c3e8cd3a3d47630f2afe7c0e'
    test_iv = '130ce2c9b504a22b5d5b7b5f5f5ddecc'

    test_ciphertext = bytes_to_intlist(compat_b64decode(test_ciphertext))
    test_key = bytes_to_intlist(compat_b64decode(test_key))

# Generated at 2022-06-12 16:29:36.067859
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:29:43.579927
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:29:48.247197
# Unit test for function inc
def test_inc():
    byte_data = bytes(1)
    byte_data_1 = int(byte_data.hex(), 16)
    byte_data_2 = byte_data_1 + 1
    byte_data_2 = bytes(byte_data_2)
    assert inc(byte_data) == byte_data_2


# Generated at 2022-06-12 16:30:01.044736
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:30:02.454398
# Unit test for function inc
def test_inc():
    assert(inc([1,2,3,4,5]) == [1,2,3,4,6])
    assert(inc([1,2,3,4,255]) == [1,2,3,5,0])



# Generated at 2022-06-12 16:30:11.603914
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:30:23.307721
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from Crypto.Cipher import AES
    from Crypto.Util import Counter
    import struct
    import sys

    def get_test_data(key_id, salt, stream_bytes_id, stream_bits_id, iv_bytes_id, iv_bits_id, expected_bytes_id, expected_bits_id, stream_bits_offset=None, iv_bits_offset=None, expected_bits_offset=None):
        key = (b'\x00' * 16).decode('ascii')
        salt = (b'\x00' * 16).decode('ascii')
        expected_bytes_id = (b'\x00' * 16).decode('ascii')
        stream_bits_id = 0
        iv_bits_id = 0
        expected_bits_id = 0

        key = b

# Generated at 2022-06-12 16:30:26.665950
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0]*16
    iv = [0]*16
    data = [0]*16
    decrypted_data = aes_cbc_decrypt(data, key, iv)
    assert decrypted_data == [0]*16
    return 'Test passed'

# Generated at 2022-06-12 16:30:44.233854
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    b1 = b"0123456780123456"
    b2 = b"1111111111111111"
    b3 = b"2222222222222222"
    result = aes_cbc_decrypt(compat_b64decode(b2+b3),compat_b64decode(b1),[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])
    print(list(result))


# Generated at 2022-06-12 16:30:54.029488
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    import base64
    iv = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    cipher_bytes = base64.b64decode(b'gOGQp/tb+I/TKXvG8TtTq+GmPY3YdSvn1KwW1l+I4a4=')
    key = [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]
    decrypted_bytes = aes_cbc_decrypt(bytes_to_intlist(cipher_bytes), key, iv)
    print(intlist_to_bytes(decrypted_bytes))



# Generated at 2022-06-12 16:31:04.447867
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = bytes_to_intlist(compat_b64decode('G1z+aLHg2QlncJlRg+knxw=='))
    key = bytes_to_intlist(compat_b64decode('+eZ5U5KW8/w6JDSmYBYDrg=='))
    iv = bytes_to_intlist(compat_b64decode('2wCK4YdYzCcnGWWfIEbzKg=='))
    assert aes_cbc_decrypt(data, key, iv) == bytes_to_intlist(b'hello world')

# Generated at 2022-06-12 16:31:15.817350
# Unit test for function aes_cbc_decrypt

# Generated at 2022-06-12 16:31:28.431798
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    from .test_constants import AES_KEY, AES_IV, UNENCRYPTED_INPUT
    from .test_utils import aes_cbc_encrypt, to_byte_string_extended_ascii, assert_bytes

    encrypted_input = aes_cbc_encrypt(UNENCRYPTED_INPUT, bytes_to_intlist(AES_KEY), bytes_to_intlist(AES_IV))
    decrypted_input = aes_cbc_decrypt(encrypted_input, bytes_to_intlist(AES_KEY), bytes_to_intlist(AES_IV))
    assert_bytes(to_byte_string_extended_ascii(decrypted_input), UNENCRYPTED_INPUT)

# Generated at 2022-06-12 16:31:34.597979
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    data = '5d0d5bc0ad66fa8b8ea5c99d33f0e5b5'
    key = '00000000000000000000000000000000'
    iv = '00000000000000000000000000000000'
    data = bytes_to_intlist(bytearray.fromhex(data))
    key = bytes_to_intlist(bytearray.fromhex(key))
    iv = bytes_to_intlist(bytearray.fromhex(iv))
    data = aes_cbc_decrypt(data, key, iv)

# Generated at 2022-06-12 16:31:46.854649
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    key = [0x2b,0x7e,0x15,0x16,0x28,0xae,0xd2,0xa6,0xab,0xf7,0x15,0x88,0x09,0xcf,0x4f,0x3c]
    encrypted = [0x39,0x25,0x84,0x1d,0x02,0xdc,0x09,0xfb,0xdc,0x11,0x85,0x97,0x19,0x6a,0x0b,0x32]

# Generated at 2022-06-12 16:31:57.004429
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    assert (aes_cbc_decrypt(
        bytes_to_intlist(compat_b64decode(b'GmwHt12+ztJgRpfjDtOIWtpgv9ZbzjZK')),
        bytes_to_intlist(compat_b64decode(b'QX9vfUY+YU1mZmjwWbpyvw==')),
        bytes_to_intlist(compat_b64decode(b'V7/uEoNTTv7s4s2q3y4MYA=='))
    ) == bytes_to_intlist(b'{"seq":0,"ofs":0,"size":4}'))
test_aes_cbc_decrypt()



# Generated at 2022-06-12 16:32:08.880699
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    """
    Test that aes_cbc_decrypt works correctly
    """
    from .aes import aes_cbc_encrypt


# Generated at 2022-06-12 16:32:17.756226
# Unit test for function aes_cbc_decrypt
def test_aes_cbc_decrypt():
    # Test vector #1
    key = (0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c)
    iv = (0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f)

# Generated at 2022-06-12 16:33:14.786542
# Unit test for function key_expansion
def test_key_expansion():
    key = [0x2B, 0x7E, 0x15, 0x16, 0x28, 0xAE, 0xD2, 0xA6,
           0xAB, 0xF7, 0x15, 0x88, 0x09, 0xCF, 0x4F, 0x3C]