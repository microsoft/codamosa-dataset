

# Generated at 2022-06-18 09:59:56.097078
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:00:09.433312
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:00:21.817752
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com:8000/foo") == '<a href="http://www.example.com:8000/foo">http://www.example.com:8000/foo</a>'
    assert linkify("https://www.example.com/") == '<a href="https://www.example.com/">https://www.example.com/</a>'

# Generated at 2022-06-18 10:00:34.784287
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com:8000/foo") == '<a href="http://www.example.com:8000/foo">http://www.example.com:8000/foo</a>'
    assert linkify("https://www.example.com/") == '<a href="https://www.example.com/">https://www.example.com/</a>'

# Generated at 2022-06-18 10:00:45.677870
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:00:52.530553
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/foo/bar") == '<a href="http://www.example.com/foo/bar">http://www.example.com/foo/bar</a>'
    assert linkify("http://www.example.com/foo/bar?baz=1") == '<a href="http://www.example.com/foo/bar?baz=1">http://www.example.com/foo/bar?baz=1</a>'

# Generated at 2022-06-18 10:01:04.321930
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/") == '<a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("http://www.google.com:8080") == '<a href="http://www.google.com:8080">http://www.google.com:8080</a>'
    assert linkify("http://www.google.com:8080/") == '<a href="http://www.google.com:8080/">http://www.google.com:8080/</a>'

# Generated at 2022-06-18 10:01:16.416105
# Unit test for function linkify
def test_linkify():
    text = 'Hello http://tornadoweb.org!'
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text, shorten=True) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text, shorten=True, extra_params='rel="nofollow" class="external"') == 'Hello <a href="http://tornadoweb.org" rel="nofollow" class="external">http://tornadoweb.org</a>!'

# Generated at 2022-06-18 10:01:27.764950
# Unit test for function linkify
def test_linkify():
    assert linkify(None) is None
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.google.com/") == 'hello <a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("hello http://www.google.com/", shorten=True) == 'hello <a href="http://www.google.com/">http://www.go...</a>'
    assert linkify("hello http://www.google.com/", shorten=True, extra_params="class='external'") == 'hello <a href="http://www.google.com/" class=\'external\'>http://www.go...</a>'

# Generated at 2022-06-18 10:01:38.879012
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo?bar=baz") == '<a href="http://example.com/foo?bar=baz">http://example.com/foo?bar=baz</a>'
    assert linkify("http://example.com/foo?bar=baz&quot;") == '<a href="http://example.com/foo?bar=baz&quot;">http://example.com/foo?bar=baz&quot;</a>'

# Generated at 2022-06-18 10:02:02.965767
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2#frag") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2#frag">http://example.com/foo/bar/baz/quux?a=1&b=2#frag</a>'

# Generated at 2022-06-18 10:02:15.724971
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar/baz") == '<a href="http://example.com/foo/bar/baz">http://example.com/foo/bar/baz</a>'

# Generated at 2022-06-18 10:02:26.893662
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("Hello http://www.google.com") == 'Hello <a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-18 10:02:36.060931
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params='class="external"') == '<a href="http://example.com/foo&amp;bar" class="external">http://example.com/foo&amp;bar</a>'

# Generated at 2022-06-18 10:02:48.801058
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com", shorten=True) == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar/baz/quux/spam") == '<a href="http://example.com/foo/bar/baz/quux/spam">http://example.com/foo/bar/baz/quux/spam</a>'

# Generated at 2022-06-18 10:02:59.754396
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params="class='external'") == '<a href="http://example.com/foo&amp;bar" class=\'external\'>http://example.com/foo&amp;bar</a>'


# Generated at 2022-06-18 10:03:09.425671
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com", shorten=True) == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com", shorten=True, extra_params="class='external'") == '<a href="http://www.google.com" class=\'external\'>http://www.google.com</a>'

# Generated at 2022-06-18 10:03:20.978577
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com:8000/foo") == '<a href="http://www.example.com:8000/foo">http://www.example.com:8000/foo</a>'
    assert linkify("https://www.example.com/") == '<a href="https://www.example.com/">https://www.example.com/</a>'

# Generated at 2022-06-18 10:03:25.687720
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=test") == '<a href="http://www.google.com/search?q=test">http://www.google.com/search?q=test</a>'
    assert linkify("http://www.google.com/search?q=test", shorten=True) == '<a href="http://www.google.com/search?q=test">http://www.google.com/search?q=...</a>'

# Generated at 2022-06-18 10:03:34.963850
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:03:51.699769
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("Hello http://www.google.com") == 'Hello <a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-18 10:04:00.493192
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=test") == '<a href="http://www.google.com/search?q=test">http://www.google.com/search?q=test</a>'
    assert linkify("http://www.google.com/search?q=test&foo=bar") == '<a href="http://www.google.com/search?q=test&amp;foo=bar">http://www.google.com/search?q=test&amp;foo=bar</a>'

# Generated at 2022-06-18 10:04:10.081377
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/") == '<a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("http://www.google.com/search?q=foo") == '<a href="http://www.google.com/search?q=foo">http://www.google.com/search?q=foo</a>'

# Generated at 2022-06-18 10:04:21.986637
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:04:32.223974
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.tornadoweb.org/") == '<a href="http://www.tornadoweb.org/">http://www.tornadoweb.org/</a>'
    assert linkify("www.tornadoweb.org") == '<a href="http://www.tornadoweb.org">www.tornadoweb.org</a>'
    assert linkify("Hello http://www.tornadoweb.org/!") == 'Hello <a href="http://www.tornadoweb.org/">http://www.tornadoweb.org/</a>!'
    assert linkify("Visit http://www.tornadoweb.org/ today!") == 'Visit <a href="http://www.tornadoweb.org/">http://www.tornadoweb.org/</a> today!'

# Generated at 2022-06-18 10:04:41.345390
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:04:52.222051
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:05:01.943714
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar/baz") == '<a href="http://example.com/foo/bar/baz">http://example.com/foo/bar/baz</a>'

# Generated at 2022-06-18 10:05:09.988404
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.tornadoweb.org world") == 'hello <a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a> world'
    assert linkify("hello http://www.tornadoweb.org/ world") == 'hello <a href="http://www.tornadoweb.org/">http://www.tornadoweb.org/</a> world'
    assert linkify("hello http://www.tornadoweb.org:8000 world") == 'hello <a href="http://www.tornadoweb.org:8000">http://www.tornadoweb.org:8000</a> world'

# Generated at 2022-06-18 10:05:21.149594
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo?bar=baz") == '<a href="http://example.com/foo?bar=baz">http://example.com/foo?bar=baz</a>'
    assert linkify("http://example.com/foo?bar=baz&bing=bong") == '<a href="http://example.com/foo?bar=baz&amp;bing=bong">http://example.com/foo?bar=baz&amp;bing=bong</a>'


# Generated at 2022-06-18 10:05:44.548513
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'

# Generated at 2022-06-18 10:05:52.707035
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'

# Generated at 2022-06-18 10:06:03.280915
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?baz=1") == '<a href="http://example.com/foo/bar?baz=1">http://example.com/foo/bar?baz=1</a>'

# Generated at 2022-06-18 10:06:12.287139
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=foo") == '<a href="http://www.google.com/search?q=foo">http://www.google.com/search?q=foo</a>'
    assert linkify("http://www.google.com/search?q=foo&bar=baz") == '<a href="http://www.google.com/search?q=foo&amp;bar=baz">http://www.google.com/search?q=foo&amp;bar=baz</a>'

# Generated at 2022-06-18 10:06:22.848860
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:06:33.678881
# Unit test for function linkify
def test_linkify():
    assert linkify(None) is None
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.tornadoweb.org") == 'hello <a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a>'
    assert linkify("hello www.tornadoweb.org") == 'hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>'
    assert linkify("hello http://www.tornadoweb.org/page/") == 'hello <a href="http://www.tornadoweb.org/page/">http://www.tornadoweb.org/page/</a>'

# Generated at 2022-06-18 10:06:45.823404
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com", shorten=True) == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com", shorten=True, extra_params="class='external'") == '<a href="http://www.google.com" class=\'external\'>http://www.google.com</a>'

# Generated at 2022-06-18 10:06:53.775293
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:07:04.725605
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com", shorten=True) == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2">http://example.com/foo/bar/baz/quux?a=1&b=2</a>'

# Generated at 2022-06-18 10:07:11.763146
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com:8000/foo") == '<a href="http://www.example.com:8000/foo">http://www.example.com:8000/foo</a>'
    assert linkify("https://www.example.com/") == '<a href="https://www.example.com/">https://www.example.com/</a>'

# Generated at 2022-06-18 10:07:37.127955
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=foo&bar=baz") == '<a href="http://www.google.com/search?q=foo&bar=baz">http://www.google.com/search?q=foo&amp;bar=baz</a>'
    assert linkify("http://www.google.com/search?q=foo&bar=baz", shorten=True) == '<a href="http://www.google.com/search?q=foo&bar=baz">http://www.google.com/search?q=foo&amp;bar=baz</a>'

# Generated at 2022-06-18 10:07:45.331729
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:07:54.687591
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/") == '<a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("http://www.google.com/foo") == '<a href="http://www.google.com/foo">http://www.google.com/foo</a>'
    assert linkify("http://www.google.com/foo/") == '<a href="http://www.google.com/foo/">http://www.google.com/foo/</a>'

# Generated at 2022-06-18 10:08:06.734226
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com", shorten=True) == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar/baz/quux/spam") == '<a href="http://example.com/foo/bar/baz/quux/spam">http://example.com/foo/bar/baz/quux/spam</a>'

# Generated at 2022-06-18 10:08:18.621209
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:08:29.076923
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:08:39.518308
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?a=b&c=d") == '<a href="http://example.com/foo/bar?a=b&c=d">http://example.com/foo/bar?a=b&c=d</a>'

# Generated at 2022-06-18 10:08:50.328804
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com", shorten=True) == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com", shorten=True, extra_params="rel='nofollow'") == '<a href="http://www.google.com" rel=\'nofollow\'>http://www.google.com</a>'

# Generated at 2022-06-18 10:08:58.617612
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo?bar=baz&ding=dong") == '<a href="http://example.com/foo?bar=baz&amp;ding=dong">http://example.com/foo?bar=baz&amp;ding=dong</a>'
    assert linkify("http://example.com/foo?bar=baz&ding=dong", shorten=True) == '<a href="http://example.com/foo?bar=baz&amp;ding=dong">http://example.com/foo?bar...</a>'

# Generated at 2022-06-18 10:09:10.405382
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com", shorten=True) == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com", shorten=True, extra_params='rel="nofollow" class="external"') == '<a href="http://example.com" rel="nofollow" class="external">http://example.com</a>'
    assert linkify("http://example.com", shorten=True, extra_params=lambda x: 'rel="nofollow" class="external"') == '<a href="http://example.com" rel="nofollow" class="external">http://example.com</a>'
   