

# Generated at 2022-06-18 10:00:14.943132
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2#fnord") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2#fnord">http://example.com/foo/bar/baz/quux?a=1&b=2#fnord</a>'

# Generated at 2022-06-18 10:00:21.705343
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ''
    assert linkify('') == ''
    assert linkify('Hello') == 'Hello'
    assert linkify('Hello http://tornadoweb.org!') == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify('Hello http://tornadoweb.org!/foo/bar') == 'Hello <a href="http://tornadoweb.org!/foo/bar">http://tornadoweb.org!/foo/bar</a>'
    assert linkify('Hello http://tornadoweb.org!/foo/bar.') == 'Hello <a href="http://tornadoweb.org!/foo/bar">http://tornadoweb.org!/foo/bar</a>.'

# Generated at 2022-06-18 10:00:34.637056
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:00:45.604554
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params='class="external"') == '<a href="http://example.com/foo&amp;bar" class="external">http://example.com/foo&amp;bar</a>'

# Generated at 2022-06-18 10:00:57.358452
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?baz=1") == '<a href="http://example.com/foo/bar?baz=1">http://example.com/foo/bar?baz=1</a>'

# Generated at 2022-06-18 10:01:09.900931
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=test") == '<a href="http://www.google.com/search?q=test">http://www.google.com/search?q=test</a>'
    assert linkify("http://www.google.com/search?q=test&foo=bar") == '<a href="http://www.google.com/search?q=test&amp;foo=bar">http://www.google.com/search?q=test&amp;foo=bar</a>'

# Generated at 2022-06-18 10:01:20.315300
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:01:32.712116
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com", shorten=True) == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com", shorten=True, extra_params="class='external'") == '<a href="http://www.google.com" class=\'external\'>http://www.google.com</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'

# Generated at 2022-06-18 10:01:44.558678
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com/foo") == '<a href="http://www.example.com/foo">http://www.example.com/foo</a>'
    assert linkify("http://www.example.com/foo/") == '<a href="http://www.example.com/foo/">http://www.example.com/foo/</a>'

# Generated at 2022-06-18 10:01:55.710831
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/") == '<a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("http://www.google.com/foo") == '<a href="http://www.google.com/foo">http://www.google.com/foo</a>'
    assert linkify("http://www.google.com/foo/") == '<a href="http://www.google.com/foo/">http://www.google.com/foo/</a>'

# Generated at 2022-06-18 10:02:15.176943
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.tornadoweb.org") == 'hello <a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a>'  # noqa: E501
    assert linkify("hello www.tornadoweb.org") == 'hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>'  # noqa: E501
    assert linkify("hello http://www.tornadoweb.org/") == 'hello <a href="http://www.tornadoweb.org/">http://www.tornadoweb.org/</a>'  # noqa: E501

# Generated at 2022-06-18 10:02:26.021506
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com:8000/foo") == '<a href="http://www.example.com:8000/foo">http://www.example.com:8000/foo</a>'
    assert linkify("https://www.example.com/") == '<a href="https://www.example.com/">https://www.example.com/</a>'
    assert linkify("http://www.example.com/foo?bar=baz&ding=dong")

# Generated at 2022-06-18 10:02:35.737572
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo?bar=baz&ding=dong") == '<a href="http://example.com/foo?bar=baz&ding=dong">http://example.com/foo?bar=baz&amp;ding=dong</a>'
    assert linkify("http://example.com/foo?bar=baz&ding=dong", extra_params='rel="nofollow" class="external"') == '<a href="http://example.com/foo?bar=baz&ding=dong" rel="nofollow" class="external">http://example.com/foo?bar=baz&amp;ding=dong</a>'

# Generated at 2022-06-18 10:02:48.520509
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/") == '<a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("http://www.google.com/search?q=tornado") == '<a href="http://www.google.com/search?q=tornado">http://www.google.com/search?q=tornado</a>'

# Generated at 2022-06-18 10:02:59.572417
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?baz=1") == '<a href="http://example.com/foo/bar?baz=1">http://example.com/foo/bar?baz=1</a>'

# Generated at 2022-06-18 10:03:09.299026
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    text = "Hello http://tornadoweb.org/!"
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org/">http://tornadoweb.org/</a>!'
    text = "Hello http://tornadoweb.org/!/"
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org/!/">http://tornadoweb.org/!/</a>!'
    text = "Hello http://tornadoweb.org/!/!"

# Generated at 2022-06-18 10:03:20.819356
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo?bar=baz&ding=dong") == '<a href="http://example.com/foo?bar=baz&amp;ding=dong">http://example.com/foo?bar=baz&amp;ding=dong</a>'
    assert linkify("http://example.com/foo/bar/baz/ding/dong/") == '<a href="http://example.com/foo/bar/baz/ding/dong/">http://example.com/foo/bar/baz/ding/dong/</a>'

# Generated at 2022-06-18 10:03:31.394744
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar/baz") == '<a href="http://example.com/foo/bar/baz">http://example.com/foo/bar/baz</a>'

# Generated at 2022-06-18 10:03:38.734999
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?a=b&c=d") == '<a href="http://example.com/foo/bar?a=b&c=d">http://example.com/foo/bar?a=b&c=d</a>'

# Generated at 2022-06-18 10:03:49.950483
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert link

# Generated at 2022-06-18 10:04:03.579824
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2#fnord") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2#fnord">http://example.com/foo/bar/baz/quux?a=1&b=2#fnord</a>'

# Generated at 2022-06-18 10:04:14.585358
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.example.com") == 'hello <a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("hello http://www.example.com/") == 'hello <a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("hello www.example.com") == 'hello <a href="http://www.example.com">www.example.com</a>'
    assert linkify("hello www.example.com/") == 'hello <a href="http://www.example.com/">www.example.com/</a>'

# Generated at 2022-06-18 10:04:26.509334
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:04:35.698202
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:04:39.747820
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:04:51.076090
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/foo/bar") == '<a href="http://www.example.com/foo/bar">http://www.example.com/foo/bar</a>'
    assert linkify("http://www.example.com/foo/bar?a=b&c=d") == '<a href="http://www.example.com/foo/bar?a=b&c=d">http://www.example.com/foo/bar?a=b&c=d</a>'

# Generated at 2022-06-18 10:05:00.843201
# Unit test for function linkify
def test_linkify():
    assert linkify(None) is None
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.google.com/") == 'hello <a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("hello http://www.google.com/", shorten=True) == 'hello <a href="http://www.google.com/">http://www.go...</a>'
    assert linkify("hello http://www.google.com/", shorten=True, extra_params="class='external'") == 'hello <a href="http://www.google.com/" class=\'external\'>http://www.go...</a>'

# Generated at 2022-06-18 10:05:09.455166
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.tornadoweb.org world") == 'hello <a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a> world'  # noqa: E501
    assert linkify("hello www.tornadoweb.org world") == 'hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a> world'  # noqa: E501
    assert linkify("hello http://www.tornadoweb.org/ world") == 'hello <a href="http://www.tornadoweb.org/">http://www.tornadoweb.org/</a> world'  # noqa: E501
   

# Generated at 2022-06-18 10:05:20.295516
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=test") == '<a href="http://www.google.com/search?q=test">http://www.google.com/search?q=test</a>'
    assert linkify("http://www.google.com/search?q=test+test") == '<a href="http://www.google.com/search?q=test+test">http://www.google.com/search?q=test+test</a>'

# Generated at 2022-06-18 10:05:30.600293
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo?bar=baz") == '<a href="http://example.com/foo?bar=baz">http://example.com/foo?bar=baz</a>'
    assert linkify("http://example.com/foo?bar=baz&bing=bong") == '<a href="http://example.com/foo?bar=baz&bing=bong">http://example.com/foo?bar=baz&amp;bing=bong</a>'

# Generated at 2022-06-18 10:05:48.007515
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:05:59.170138
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com", shorten=True) == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:06:07.525329
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar/baz") == '<a href="http://example.com/foo/bar/baz">http://example.com/foo/bar/baz</a>'

# Generated at 2022-06-18 10:06:14.678547
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=test") == '<a href="http://www.google.com/search?q=test">http://www.google.com/search?q=test</a>'
    assert linkify("http://www.google.com/search?q=test&amp;foo=bar") == '<a href="http://www.google.com/search?q=test&amp;foo=bar">http://www.google.com/search?q=test&amp;foo=bar</a>'

# Generated at 2022-06-18 10:06:26.011630
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:06:36.215520
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?baz=1") == '<a href="http://example.com/foo/bar?baz=1">http://example.com/foo/bar?baz=1</a>'

# Generated at 2022-06-18 10:06:48.267275
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:06:56.441264
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:07:07.131064
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.facebook.com") == '<a href="http://www.facebook.com">http://www.facebook.com</a>'
    assert linkify("http://www.facebook.com/") == '<a href="http://www.facebook.com/">http://www.facebook.com/</a>'
    assert linkify("http://www.facebook.com/foo") == '<a href="http://www.facebook.com/foo">http://www.facebook.com/foo</a>'
    assert linkify("http://www.facebook.com/foo?bar=baz") == '<a href="http://www.facebook.com/foo?bar=baz">http://www.facebook.com/foo?bar=baz</a>'

# Generated at 2022-06-18 10:07:16.255177
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text, shorten=True) == 'Hello <a href="http://tornadoweb.org">tornadoweb.org</a>!'
    assert linkify(text, extra_params='rel="nofollow" class="external"') == 'Hello <a href="http://tornadoweb.org" rel="nofollow" class="external">http://tornadoweb.org</a>!'
    assert linkify(text, require_protocol=True) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

# Generated at 2022-06-18 10:07:38.344275
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/") == '<a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("http://www.google.com/foo") == '<a href="http://www.google.com/foo">http://www.google.com/foo</a>'
    assert linkify("http://www.google.com/foo/") == '<a href="http://www.google.com/foo/">http://www.google.com/foo/</a>'

# Generated at 2022-06-18 10:07:46.102226
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'

# Generated at 2022-06-18 10:07:55.726689
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.example.com/") == 'hello <a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("hello http://www.example.com/", shorten=True) == 'hello <a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("hello http://www.example.com/one-two") == 'hello <a href="http://www.example.com/one-two">http://www.example.com/one-two</a>'

# Generated at 2022-06-18 10:08:08.246524
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("Hello http://www.google.com") == 'Hello <a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-18 10:08:19.666675
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?baz=1") == '<a href="http://example.com/foo/bar?baz=1">http://example.com/foo/bar?baz=1</a>'

# Generated at 2022-06-18 10:08:30.157920
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com", shorten=True) == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:08:40.696467
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:08:51.358015
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text, shorten=True) == 'Hello <a href="http://tornadoweb.org">tornadoweb.org</a>!'
    assert linkify(text, extra_params='rel="nofollow" class="external"') == 'Hello <a href="http://tornadoweb.org" rel="nofollow" class="external">http://tornadoweb.org</a>!'
    assert linkify(text, require_protocol=True) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

# Generated at 2022-06-18 10:08:59.254932
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("Hello http://www.google.com") == 'Hello <a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-18 10:09:10.660162
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params="class='external'") == '<a href="http://example.com/foo&amp;bar" class=\'external\'>http://example.com/foo&amp;bar</a>'
