

# Generated at 2022-06-18 09:59:53.638203
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=test") == '<a href="http://www.google.com/search?q=test">http://www.google.com/search?q=test</a>'
    assert linkify("http://www.google.com/search?q=test&foo=bar") == '<a href="http://www.google.com/search?q=test&amp;foo=bar">http://www.google.com/search?q=test&amp;foo=bar</a>'

# Generated at 2022-06-18 10:00:01.116457
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo?bar=baz&blah=1") == '<a href="http://example.com/foo?bar=baz&amp;blah=1">http://example.com/foo?bar=baz&amp;blah=1</a>'

# Generated at 2022-06-18 10:00:14.800294
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?baz=1") == '<a href="http://example.com/foo/bar?baz=1">http://example.com/foo/bar?baz=1</a>'

# Generated at 2022-06-18 10:00:27.524803
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com:8000/foo") == '<a href="http://www.example.com:8000/foo">http://www.example.com:8000/foo</a>'
    assert linkify("https://www.example.com/") == '<a href="https://www.example.com/">https://www.example.com/</a>'

# Generated at 2022-06-18 10:00:39.985616
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:00:50.889752
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/") == '<a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("http://www.google.com/foo") == '<a href="http://www.google.com/foo">http://www.google.com/foo</a>'
    assert linkify("http://www.google.com/foo/") == '<a href="http://www.google.com/foo/">http://www.google.com/foo/</a>'

# Generated at 2022-06-18 10:01:03.030425
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com", shorten=True) == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com", shorten=True, extra_params="class='external'") == '<a href="http://www.google.com" class=\'external\'>http://www.google.com</a>'

# Generated at 2022-06-18 10:01:15.206515
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params="class='external'") == '<a href="http://example.com/foo&amp;bar" class=\'external\'>http://example.com/foo&amp;bar</a>'


# Generated at 2022-06-18 10:01:22.985102
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text, shorten=True) == 'Hello <a href="http://tornadoweb.org">tornadoweb.org</a>!'
    assert linkify(text, extra_params='rel="nofollow" class="external"') == 'Hello <a href="http://tornadoweb.org" rel="nofollow" class="external">http://tornadoweb.org</a>!'
    assert linkify(text, require_protocol=True) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

# Generated at 2022-06-18 10:01:35.514582
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.google.com") == 'hello <a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("hello http://www.google.com/search?q=linkify") == 'hello <a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("hello www.google.com") == 'hello <a href="http://www.google.com">www.google.com</a>'

# Generated at 2022-06-18 10:01:54.218751
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:02:06.322220
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?a=b&c=d") == '<a href="http://example.com/foo/bar?a=b&c=d">http://example.com/foo/bar?a=b&c=d</a>'

# Generated at 2022-06-18 10:02:18.199081
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=tornado") == '<a href="http://www.google.com/search?q=tornado">http://www.google.com/search?q=tornado</a>'
    assert linkify("http://www.google.com/search?q=tornado&ie=utf-8") == '<a href="http://www.google.com/search?q=tornado&ie=utf-8">http://www.google.com/search?q=tornado&ie=utf-8</a>'

# Generated at 2022-06-18 10:02:30.971266
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:02:43.134706
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:02:55.335238
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:03:05.912950
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com/foo") == '<a href="http://www.example.com/foo">http://www.example.com/foo</a>'
    assert linkify("http://www.example.com/foo/") == '<a href="http://www.example.com/foo/">http://www.example.com/foo/</a>'

# Generated at 2022-06-18 10:03:15.611201
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params="class='external'") == '<a href="http://example.com/foo&amp;bar" class=\'external\'>http://example.com/foo&amp;bar</a>'


# Generated at 2022-06-18 10:03:27.511596
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?baz=1") == '<a href="http://example.com/foo/bar?baz=1">http://example.com/foo/bar?baz=1</a>'

# Generated at 2022-06-18 10:03:36.360135
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/") == '<a href="http://example.com/">http://example.com/</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/") == '<a href="http://example.com/foo/">http://example.com/foo/</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify

# Generated at 2022-06-18 10:03:52.114661
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/foo") == '<a href="http://www.example.com/foo">http://www.example.com/foo</a>'
    assert linkify("http://www.example.com/foo/bar") == '<a href="http://www.example.com/foo/bar">http://www.example.com/foo/bar</a>'
    assert linkify("http://www.example.com/foo/bar/baz") == '<a href="http://www.example.com/foo/bar/baz">http://www.example.com/foo/bar/baz</a>'
    assert linkify

# Generated at 2022-06-18 10:04:00.850305
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com:8000/foo") == '<a href="http://www.example.com:8000/foo">http://www.example.com:8000/foo</a>'
    assert linkify("https://www.example.com/") == '<a href="https://www.example.com/">https://www.example.com/</a>'

# Generated at 2022-06-18 10:04:11.116046
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:04:23.142348
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params='class="external"') == '<a href="http://example.com/foo&amp;bar" class="external">http://example.com/foo&amp;bar</a>'

# Generated at 2022-06-18 10:04:32.870658
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com", shorten=True) == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:04:42.068942
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/foo") == '<a href="http://www.example.com/foo">http://www.example.com/foo</a>'
    assert linkify("http://www.example.com/foo/bar") == '<a href="http://www.example.com/foo/bar">http://www.example.com/foo/bar</a>'

# Generated at 2022-06-18 10:04:52.916046
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("Hello http://www.google.com") == 'Hello <a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-18 10:05:02.580213
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("www.example.com") == '<a href="http://www.example.com">www.example.com</a>'
    assert linkify("www.example.com/") == '<a href="http://www.example.com/">www.example.com/</a>'
    assert linkify("www.example.com:8000") == '<a href="http://www.example.com:8000">www.example.com:8000</a>'
    assert linkify

# Generated at 2022-06-18 10:05:10.692713
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?a=b&c=d") == '<a href="http://example.com/foo/bar?a=b&c=d">http://example.com/foo/bar?a=b&c=d</a>'

# Generated at 2022-06-18 10:05:21.836146
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params='class="external"') == '<a href="http://example.com/foo&amp;bar" class="external">http://example.com/foo&amp;bar</a>'

# Generated at 2022-06-18 10:05:44.630486
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/") == '<a href="http://example.com/">http://example.com/</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/") == '<a href="http://example.com/foo/">http://example.com/foo/</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify

# Generated at 2022-06-18 10:05:52.763975
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("Hello http://www.google.com") == 'Hello <a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-18 10:06:03.281395
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:06:12.287149
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params="class='external'") == '<a href="http://example.com/foo&amp;bar" class=\'external\'>http://example.com/foo&amp;bar</a>'


# Generated at 2022-06-18 10:06:22.848384
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/foo/bar") == '<a href="http://www.example.com/foo/bar">http://www.example.com/foo/bar</a>'
    assert linkify("http://www.example.com/foo/bar?baz=1") == '<a href="http://www.example.com/foo/bar?baz=1">http://www.example.com/foo/bar?baz=1</a>'

# Generated at 2022-06-18 10:06:33.635405
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com", shorten=True) == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&c=d&e=f">http://example.com/foo/bar/baz/quux?a=b&c=d&e=f</a>'

# Generated at 2022-06-18 10:06:45.777869
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?a=b") == '<a href="http://example.com/foo/bar?a=b">http://example.com/foo/bar?a=b</a>'

# Generated at 2022-06-18 10:06:54.706841
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ''
    assert linkify('') == ''
    assert linkify('Hello') == 'Hello'
    assert linkify('Hello http://tornadoweb.org!') == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify('Hello http://tornadoweb.org!, Hello http://tornadoweb.org!') == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!, Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

# Generated at 2022-06-18 10:07:05.794785
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?baz=1") == '<a href="http://example.com/foo/bar?baz=1">http://example.com/foo/bar?baz=1</a>'

# Generated at 2022-06-18 10:07:14.781681
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert link

# Generated at 2022-06-18 10:07:39.808780
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.facebook.com") == '<a href="http://www.facebook.com">http://www.facebook.com</a>'
    assert linkify("www.facebook.com") == '<a href="http://www.facebook.com">www.facebook.com</a>'
    assert linkify("www.facebook.com", require_protocol=True) == 'www.facebook.com'
    assert linkify("http://www.facebook.com", extra_params="rel='nofollow'") == '<a href="http://www.facebook.com" rel=\'nofollow\'>http://www.facebook.com</a>'

# Generated at 2022-06-18 10:07:46.634604
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:07:56.874299
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:08:08.692932
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2#frag") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2#frag">http://example.com/foo/bar/baz/quux?a=1&b=2#frag</a>'

# Generated at 2022-06-18 10:08:20.056490
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar/baz") == '<a href="http://example.com/foo/bar/baz">http://example.com/foo/bar/baz</a>'

# Generated at 2022-06-18 10:08:30.605829
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com", shorten=True) == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com", shorten=True, extra_params="rel='nofollow'") == '<a href="http://example.com" rel=\'nofollow\'>http://example.com</a>'
    assert linkify("http://example.com", shorten=True, extra_params=lambda x: "rel='nofollow'") == '<a href="http://example.com" rel=\'nofollow\'>http://example.com</a>'

# Generated at 2022-06-18 10:08:40.960234
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:08:51.610841
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com", shorten=True) == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar/baz/quux/spam/eggs") == '<a href="http://example.com/foo/bar/baz/quux/spam/eggs">http://example.com/foo/bar/baz/quux/spam/eggs</a>'

# Generated at 2022-06-18 10:08:59.392629
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:09:10.784967
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'