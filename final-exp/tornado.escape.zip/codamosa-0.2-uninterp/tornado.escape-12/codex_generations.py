

# Generated at 2022-06-18 10:00:10.414239
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/") == '<a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("http://www.google.com/test") == '<a href="http://www.google.com/test">http://www.google.com/test</a>'
    assert linkify("http://www.google.com/test/") == '<a href="http://www.google.com/test/">http://www.google.com/test/</a>'

# Generated at 2022-06-18 10:00:22.752032
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/foo") == '<a href="http://www.example.com/foo">http://www.example.com/foo</a>'
    assert linkify("http://www.example.com/foo/bar") == '<a href="http://www.example.com/foo/bar">http://www.example.com/foo/bar</a>'

# Generated at 2022-06-18 10:00:35.843438
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=test") == '<a href="http://www.google.com/search?q=test">http://www.google.com/search?q=test</a>'
    assert linkify("http://www.google.com/search?q=test", shorten=True) == '<a href="http://www.google.com/search?q=test">http://www.google.com/search?q=test</a>'

# Generated at 2022-06-18 10:00:46.182717
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar/baz") == '<a href="http://example.com/foo/bar/baz">http://example.com/foo/bar/baz</a>'

# Generated at 2022-06-18 10:00:57.636654
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:01:10.329211
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("Hello http://www.google.com") == 'Hello <a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-18 10:01:20.594451
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.google.com") == 'hello <a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("hello http://www.google.com/search?q=linkify") == 'hello <a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("hello http://www.google.com/search?q=linkify extra") == 'hello <a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'
   

# Generated at 2022-06-18 10:01:32.976451
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"foo%2Bbar", plus=True) == "foo+bar"
    assert url_unescape(b"foo%2Bbar", plus=False) == "foo%2Bbar"
    assert url_unescape(b"foo%2Bbar", encoding="ascii", plus=True) == "foo+bar"
    assert url_unescape(b"foo%2Bbar", encoding="ascii", plus=False) == "foo%2Bbar"
    assert url_unescape(b"foo%2Bbar", encoding=None, plus=True) == b"foo bar"
    assert url_unescape(b"foo%2Bbar", encoding=None, plus=False) == b"foo%2Bbar"

# Generated at 2022-06-18 10:01:39.225840
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("Hello http://www.google.com") == 'Hello <a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-18 10:01:51.467047
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2#fnord") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2#fnord">http://example.com/foo/bar/baz/quux?a=1&b=2#fnord</a>'

# Generated at 2022-06-18 10:02:14.768619
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar?baz=1&blah=2") == '<a href="http://example.com/foo/bar?baz=1&blah=2">http://example.com/foo/bar?baz=1&blah=2</a>'

# Generated at 2022-06-18 10:02:24.988923
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com?foo=bar&baz=quux") == '<a href="http://example.com?foo=bar&amp;baz=quux">http://example.com?foo=bar&amp;baz=quux</a>'

# Generated at 2022-06-18 10:02:35.227620
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify", shorten=True) == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linki...</a>'


# Generated at 2022-06-18 10:02:48.099841
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar/baz") == '<a href="http://example.com/foo/bar/baz">http://example.com/foo/bar/baz</a>'

# Generated at 2022-06-18 10:02:59.159804
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.google.com") == 'hello <a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("hello http://www.google.com/search?q=linkify") == 'hello <a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("hello http://www.google.com/search?q=linkify extra") == 'hello <a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'
   

# Generated at 2022-06-18 10:03:09.010336
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:03:20.557636
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:03:31.170621
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?baz=1") == '<a href="http://example.com/foo/bar?baz=1">http://example.com/foo/bar?baz=1</a>'

# Generated at 2022-06-18 10:03:38.167019
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?a=1&b=2") == '<a href="http://example.com/foo/bar?a=1&b=2">http://example.com/foo/bar?a=1&b=2</a>'

# Generated at 2022-06-18 10:03:49.288813
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert link

# Generated at 2022-06-18 10:04:08.353184
# Unit test for function linkify
def test_linkify():
    assert linkify(None) is None
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.example.com/") == 'hello <a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("hello http://www.example.com/", shorten=True) == 'hello <a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("hello http://www.example.com/path") == 'hello <a href="http://www.example.com/path">http://www.example.com/path</a>'

# Generated at 2022-06-18 10:04:19.851852
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == u'<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == u'<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify&foo=bar") == u'<a href="http://www.google.com/search?q=linkify&amp;foo=bar">http://www.google.com/search?q=linkify&amp;foo=bar</a>'

# Generated at 2022-06-18 10:04:30.939517
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'

# Generated at 2022-06-18 10:04:39.490440
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar/baz") == '<a href="http://example.com/foo/bar/baz">http://example.com/foo/bar/baz</a>'

# Generated at 2022-06-18 10:04:50.805125
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:05:00.587164
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:05:09.245415
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params="class='external'") == '<a href="http://example.com/foo&amp;bar" class=\'external\'>http://example.com/foo&amp;bar</a>'


# Generated at 2022-06-18 10:05:19.941521
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com:8000/foo") == '<a href="http://www.example.com:8000/foo">http://www.example.com:8000/foo</a>'
    assert linkify("https://www.example.com/") == '<a href="https://www.example.com/">https://www.example.com/</a>'

# Generated at 2022-06-18 10:05:30.369390
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("Hello http://www.google.com") == 'Hello <a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-18 10:05:41.108406
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/") == '<a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("http://www.google.com/test") == '<a href="http://www.google.com/test">http://www.google.com/test</a>'
    assert linkify("http://www.google.com/test/") == '<a href="http://www.google.com/test/">http://www.google.com/test/</a>'

# Generated at 2022-06-18 10:06:08.348110
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("Hello http://www.google.com") == 'Hello <a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-18 10:06:15.000495
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/") == '<a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("http://www.google.com/foo") == '<a href="http://www.google.com/foo">http://www.google.com/foo</a>'
    assert linkify("http://www.google.com/foo/") == '<a href="http://www.google.com/foo/">http://www.google.com/foo/</a>'

# Generated at 2022-06-18 10:06:26.374678
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    text = "Hello www.tornadoweb.org!"
    assert linkify(text) == 'Hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>!'
    text = "Hello www.tornadoweb.org! http://tornadoweb.org"
    assert linkify(text) == 'Hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>! <a href="http://tornadoweb.org">http://tornadoweb.org</a>'

# Generated at 2022-06-18 10:06:36.594234
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:06:48.614684
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.google.com/") == 'hello <a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("hello http://www.google.com/", shorten=True) == 'hello <a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("hello http://www.google.com/", shorten=True, extra_params='rel="nofollow" class="external"') == 'hello <a href="http://www.google.com/" rel="nofollow" class="external">http://www.google.com/</a>'
    assert linkify

# Generated at 2022-06-18 10:06:57.836075
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ''
    assert linkify('') == ''
    assert linkify('Hello') == 'Hello'
    assert linkify('Hello http://tornadoweb.org!') == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify('Hello http://tornadoweb.org!, Hello again http://tornadoweb.org!') == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!, Hello again <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

# Generated at 2022-06-18 10:07:08.316280
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("Hello http://www.google.com") == 'Hello <a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-18 10:07:17.681593
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.tornadoweb.org") == 'hello <a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a>'
    assert linkify("hello www.tornadoweb.org") == 'hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>'
    assert linkify("hello http://www.tornadoweb.org hello") == 'hello <a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a> hello'

# Generated at 2022-06-18 10:07:28.476710
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:07:33.294691
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/") == '<a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("http://www.google.com/foo") == '<a href="http://www.google.com/foo">http://www.google.com/foo</a>'
    assert linkify("http://www.google.com/foo/") == '<a href="http://www.google.com/foo/">http://www.google.com/foo/</a>'

# Generated at 2022-06-18 10:08:18.161776
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/") == '<a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("http://www.google.com/search?q=test") == '<a href="http://www.google.com/search?q=test">http://www.google.com/search?q=test</a>'

# Generated at 2022-06-18 10:08:28.304442
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com/foo") == '<a href="http://www.example.com/foo">http://www.example.com/foo</a>'
    assert linkify("http://www.example.com/foo/") == '<a href="http://www.example.com/foo/">http://www.example.com/foo/</a>'

# Generated at 2022-06-18 10:08:39.027202
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:08:49.847155
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2">http://example.com/foo/bar/baz/quux?a=1&b=2</a>'

# Generated at 2022-06-18 10:08:58.303813
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params="class='external'") == '<a href="http://example.com/foo&amp;bar" class=\'external\'>http://example.com/foo&amp;bar</a>'


# Generated at 2022-06-18 10:09:02.193899
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"



# Generated at 2022-06-18 10:09:13.194153
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2#fnord") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2#fnord">http://example.com/foo/bar/baz/quux?a=1&b=2#fnord</a>'
    assert linkify("www.example.com") == '<a href="http://www.example.com">www.example.com</a>'


# Generated at 2022-06-18 10:09:21.040314
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:09:28.948405
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'