

# Generated at 2022-06-18 09:59:49.993713
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("Hello http://www.google.com") == 'Hello <a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-18 10:00:01.173128
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com/foo") == '<a href="http://www.example.com/foo">http://www.example.com/foo</a>'
    assert linkify("http://www.example.com/foo/") == '<a href="http://www.example.com/foo/">http://www.example.com/foo/</a>'

# Generated at 2022-06-18 10:00:14.849353
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('%E4%B8%AD%E6%96%87') == '中文'
    assert url_unescape('%E4%B8%AD%E6%96%87', encoding=None) == b'\xe4\xb8\xad\xe6\x96\x87'
    assert url_unescape('%E4%B8%AD%E6%96%87', encoding='utf-8') == '中文'
    assert url_unescape('%E4%B8%AD%E6%96%87', encoding='utf-8', plus=False) == '%E4%B8%AD%E6%96%87'

# Generated at 2022-06-18 10:00:21.607263
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:00:34.534943
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:00:45.494517
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.tornadoweb.org") == 'hello <a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a>'
    assert linkify("hello http://www.tornadoweb.org/") == 'hello <a href="http://www.tornadoweb.org/">http://www.tornadoweb.org/</a>'
    assert linkify("hello http://www.tornadoweb.org/foo") == 'hello <a href="http://www.tornadoweb.org/foo">http://www.tornadoweb.org/foo</a>'

# Generated at 2022-06-18 10:00:57.358411
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo?bar=baz") == '<a href="http://example.com/foo?bar=baz">http://example.com/foo?bar=baz</a>'
    assert linkify("http://example.com/foo?bar=baz&ding=dong") == '<a href="http://example.com/foo?bar=baz&ding=dong">http://example.com/foo?bar=baz&amp;ding=dong</a>'

# Generated at 2022-06-18 10:01:09.902011
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com", shorten=True) == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:01:20.315537
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("Hello http://www.google.com") == 'Hello <a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-18 10:01:32.711622
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:01:55.575870
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("a%2Bb") == "a+b"
    assert url_unescape("a%2Bb", plus=False) == "a%2Bb"
    assert url_unescape(b"a%2Bb") == b"a+b"
    assert url_unescape(b"a%2Bb", plus=False) == b"a%2Bb"
    assert url_unescape("a%2Bb", encoding=None) == b"a+b"
    assert url_unescape("a%2Bb", encoding=None, plus=False) == b"a%2Bb"
    assert url_unescape(b"a%2Bb", encoding=None) == b"a+b"

# Generated at 2022-06-18 10:02:08.901165
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=foo") == '<a href="http://www.google.com/search?q=foo">http://www.google.com/search?q=foo</a>'
    assert linkify("http://www.google.com/search?q=foo&bar=baz") == '<a href="http://www.google.com/search?q=foo&amp;bar=baz">http://www.google.com/search?q=foo&amp;bar=baz</a>'

# Generated at 2022-06-18 10:02:19.346376
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2#fnord") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2#fnord">http://example.com/foo/bar/baz/quux?a=1&b=2#fnord</a>'

# Generated at 2022-06-18 10:02:32.207843
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:02:45.172823
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text, shorten=True) == 'Hello <a href="http://tornadoweb.org">tornadoweb.org</a>!'
    assert linkify(text, extra_params='rel="nofollow" class="external"') == 'Hello <a href="http://tornadoweb.org" rel="nofollow" class="external">http://tornadoweb.org</a>!'
    assert linkify(text, require_protocol=True) == 'Hello http://tornadoweb.org!'

# Generated at 2022-06-18 10:02:48.897635
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("http%3A%2F%2Fwww.google.com%2F") == "http://www.google.com/"
    assert url_unescape("http%3A%2F%2Fwww.google.com%2F", plus=False) == "http://www.google.com/"
    assert url_unescape("http%3A%2F%2Fwww.google.com%2F", encoding=None) == b"http://www.google.com/"
    assert url_unescape("http%3A%2F%2Fwww.google.com%2F", encoding=None, plus=False) == b"http://www.google.com/"



# Generated at 2022-06-18 10:02:59.844462
# Unit test for function linkify
def test_linkify():
    assert linkify(None) is None
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.example.com/") == 'hello <a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("hello http://www.example.com/", shorten=True) == 'hello <a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("hello http://www.example.com/path/to/file") == 'hello <a href="http://www.example.com/path/to/file">http://www.example.com/path/to/file</a>'

# Generated at 2022-06-18 10:03:09.457685
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:03:20.978683
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("a%2Bb") == "a+b"
    assert url_unescape("a%2Bb", plus=False) == "a%2Bb"
    assert url_unescape(b"a%2Bb", encoding=None) == b"a+b"
    assert url_unescape(b"a%2Bb", encoding=None, plus=False) == b"a%2Bb"
    assert url_unescape("a%2Bb", encoding="utf-8") == "a+b"
    assert url_unescape("a%2Bb", encoding="utf-8", plus=False) == "a%2Bb"
    assert url_unescape(b"a%2Bb", encoding="utf-8") == "a+b"

# Generated at 2022-06-18 10:03:31.481499
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'

# Generated at 2022-06-18 10:03:55.964410
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:04:03.535189
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params='class="external"') == '<a href="http://example.com/foo&amp;bar" class="external">http://example.com/foo&amp;bar</a>'

# Generated at 2022-06-18 10:04:14.545378
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2#frag") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2#frag">http://example.com/foo/bar/baz/quux?a=1&b=2#frag</a>'

# Generated at 2022-06-18 10:04:26.466026
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.google.com") == 'hello <a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("hello http://www.google.com/") == 'hello <a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("hello www.google.com") == 'hello <a href="http://www.google.com">www.google.com</a>'
    assert linkify("hello www.google.com/") == 'hello <a href="http://www.google.com/">www.google.com/</a>'

# Generated at 2022-06-18 10:04:35.666621
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params='class="external"') == '<a href="http://example.com/foo&amp;bar" class="external">http://example.com/foo&amp;bar</a>'

# Generated at 2022-06-18 10:04:46.737585
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=foo&bar=baz") == '<a href="http://www.google.com/search?q=foo&amp;bar=baz">http://www.google.com/search?q=foo&amp;bar=baz</a>'
    assert linkify("http://www.google.com/search?q=foo&bar=baz", shorten=True) == '<a href="http://www.google.com/search?q=foo&amp;bar=baz">http://www.google.com/search?q...</a>'

# Generated at 2022-06-18 10:04:51.194387
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.google.com") == 'hello <a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("hello http://www.google.com/") == 'hello <a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("hello www.google.com") == 'hello <a href="http://www.google.com">www.google.com</a>'
    assert linkify("hello www.google.com/") == 'hello <a href="http://www.google.com/">www.google.com/</a>'

# Generated at 2022-06-18 10:05:00.925724
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params='class="external"') == '<a href="http://example.com/foo&amp;bar" class="external">http://example.com/foo&amp;bar</a>'

# Generated at 2022-06-18 10:05:09.548932
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2#fnord") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2#fnord">http://example.com/foo/bar/baz/quux?a=1&b=2#fnord</a>'

# Generated at 2022-06-18 10:05:20.383135
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com", extra_params='rel="nofollow" class="external"') == '<a href="http://example.com" rel="nofollow" class="external">http://example.com</a>'
    assert linkify("www.example.com") == '<a href="http://www.example.com">www.example.com</a>'

# Generated at 2022-06-18 10:05:37.592804
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:05:48.687522
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:05:59.711262
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com", shorten=True) == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com", shorten=True, extra_params="class='external'") == '<a href="http://www.google.com" class=\'external\'>http://www.google.com</a>'

# Generated at 2022-06-18 10:06:07.876293
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.tornadoweb.org") == 'hello <a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a>'
    assert linkify("hello www.tornadoweb.org") == 'hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>'
    assert linkify("hello http://www.tornadoweb.org", require_protocol=True) == 'hello <a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a>'

# Generated at 2022-06-18 10:06:14.906406
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com/foo") == '<a href="http://www.example.com/foo">http://www.example.com/foo</a>'
    assert linkify("http://www.example.com/foo/") == '<a href="http://www.example.com/foo/">http://www.example.com/foo/</a>'

# Generated at 2022-06-18 10:06:26.283201
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text, shorten=True) == 'Hello <a href="http://tornadoweb.org" title="http://tornadoweb.org">tornadoweb.org/...</a>!'
    assert linkify(text, extra_params='rel="nofollow" class="external"') == 'Hello <a href="http://tornadoweb.org" rel="nofollow" class="external">http://tornadoweb.org</a>!'
    assert linkify(text, require_protocol=True) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert link

# Generated at 2022-06-18 10:06:36.493899
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("Hello") == "Hello"
    assert linkify("Hello http://tornadoweb.org!") == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify("Hello http://tornadoweb.org:8080!") == 'Hello <a href="http://tornadoweb.org:8080">http://tornadoweb.org:8080</a>!'
    assert linkify("Hello http://user:pass@tornadoweb.org!") == 'Hello <a href="http://user:pass@tornadoweb.org">http://user:pass@tornadoweb.org</a>!'

# Generated at 2022-06-18 10:06:48.529920
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert link

# Generated at 2022-06-18 10:06:57.740168
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2#frag") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2#frag">http://example.com/foo/bar/baz/quux?a=1&b=2#frag</a>'

# Generated at 2022-06-18 10:07:08.243909
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert link

# Generated at 2022-06-18 10:07:26.127116
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params="class='external'") == '<a href="http://example.com/foo&amp;bar" class=\'external\'>http://example.com/foo&amp;bar</a>'


# Generated at 2022-06-18 10:07:36.268347
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.facebook.com") == '<a href="http://www.facebook.com">http://www.facebook.com</a>'
    assert linkify("www.facebook.com") == '<a href="http://www.facebook.com">www.facebook.com</a>'
    assert linkify("www.facebook.com", require_protocol=True) == 'www.facebook.com'
    assert linkify("http://www.facebook.com", extra_params='rel="nofollow" class="external"') == '<a href="http://www.facebook.com" rel="nofollow" class="external">http://www.facebook.com</a>'

# Generated at 2022-06-18 10:07:44.725882
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:07:53.633575
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert link

# Generated at 2022-06-18 10:08:06.184745
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:08:17.980327
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?baz=1") == '<a href="http://example.com/foo/bar?baz=1">http://example.com/foo/bar?baz=1</a>'

# Generated at 2022-06-18 10:08:28.102397
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    assert linkify(text, shorten=True) == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    assert linkify(text, shorten=True, extra_params="rel=\"nofollow\" class=\"external\"") == "Hello <a href=\"http://tornadoweb.org\" rel=\"nofollow\" class=\"external\">http://tornadoweb.org</a>!"

# Generated at 2022-06-18 10:08:38.945148
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.example.com/") == 'hello <a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("hello http://www.example.com/", shorten=True) == 'hello <a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("hello http://www.example.com/path/to/file") == 'hello <a href="http://www.example.com/path/to/file">http://www.example.com/path/to/file</a>'

# Generated at 2022-06-18 10:08:49.698775
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2#frag") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2#frag">http://example.com/foo/bar/baz/quux?a=1&b=2#frag</a>'

# Generated at 2022-06-18 10:08:58.206356
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/") == '<a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("http://www.google.com/search?q=foo&bar=baz") == '<a href="http://www.google.com/search?q=foo&amp;bar=baz">http://www.google.com/search?q=foo&amp;bar=baz</a>'