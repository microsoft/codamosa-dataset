

# Generated at 2022-06-18 10:00:01.878580
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ''
    assert linkify('') == ''
    assert linkify('Hello') == 'Hello'
    assert linkify('Hello http://tornadoweb.org!') == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify('Hello http://tornadoweb.org!, Hello http://tornadoweb.org!') == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!, Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

# Generated at 2022-06-18 10:00:15.732740
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:00:28.111078
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com/foo") == '<a href="http://www.example.com/foo">http://www.example.com/foo</a>'
    assert linkify("http://www.example.com/foo/") == '<a href="http://www.example.com/foo/">http://www.example.com/foo/</a>'

# Generated at 2022-06-18 10:00:40.544321
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo?bar=baz&ding=dong") == '<a href="http://example.com/foo?bar=baz&amp;ding=dong">http://example.com/foo?bar=baz&amp;ding=dong</a>'
    assert linkify("http://example.com/foo?bar=baz&ding=dong", shorten=True) == '<a href="http://example.com/foo?bar=baz&amp;ding=dong">http://example.com/foo?bar...</a>'

# Generated at 2022-06-18 10:00:48.311192
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar/baz") == '<a href="http://example.com/foo/bar/baz">http://example.com/foo/bar/baz</a>'

# Generated at 2022-06-18 10:01:00.101335
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/") == '<a href="http://www.google.com/">http://www.google.com/</a>'
    assert linkify("http://www.google.com/test") == '<a href="http://www.google.com/test">http://www.google.com/test</a>'
    assert linkify("http://www.google.com/test/") == '<a href="http://www.google.com/test/">http://www.google.com/test/</a>'

# Generated at 2022-06-18 10:01:12.752036
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo?bar=baz") == '<a href="http://example.com/foo?bar=baz">http://example.com/foo?bar=baz</a>'
    assert linkify("http://example.com/foo?bar=baz&ding=dong") == '<a href="http://example.com/foo?bar=baz&ding=dong">http://example.com/foo?bar=baz&amp;ding=dong</a>'

# Generated at 2022-06-18 10:01:22.940297
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2#frag") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2#frag">http://example.com/foo/bar/baz/quux?a=1&b=2#frag</a>'

# Generated at 2022-06-18 10:01:35.470100
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=b&c=d&e=f") == '<a href="http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f">http://example.com/foo/bar/baz/quux?a=b&amp;c=d&amp;e=f</a>'

# Generated at 2022-06-18 10:01:47.042222
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2">http://example.com/foo/bar/baz/quux?a=1&b=2</a>'

# Generated at 2022-06-18 10:02:11.415952
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'%C3%A9') == 'é'
    assert url_unescape(b'%C3%A9', encoding=None) == b'\xc3\xa9'
    assert url_unescape(b'%C3%A9', encoding='ascii') == 'é'
    assert url_unescape(b'%C3%A9', encoding='ascii', plus=False) == '%C3%A9'
    assert url_unescape(b'%C3%A9', encoding='ascii', plus=True) == 'é'
    assert url_unescape(b'%C3%A9', encoding='ascii', plus=True) == 'é'

# Generated at 2022-06-18 10:02:20.734196
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2#frag") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2#frag">http://example.com/foo/bar/baz/quux?a=1&b=2#frag</a>'

# Generated at 2022-06-18 10:02:32.422922
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("a%20b") == "a b"
    assert url_unescape("a%20b", plus=False) == "a%20b"
    assert url_unescape("a+b") == "a b"
    assert url_unescape("a+b", plus=False) == "a+b"
    assert url_unescape("a+b", encoding=None) == b"a+b"
    assert url_unescape(b"a+b") == "a b"
    assert url_unescape(b"a+b", plus=False) == "a+b"
    assert url_unescape(b"a+b", encoding=None) == b"a+b"



# Generated at 2022-06-18 10:02:45.450499
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify", shorten=True) == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=link...</a>'
   

# Generated at 2022-06-18 10:02:56.754280
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:03:07.158565
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"a%20b") == "a b"
    assert url_unescape(b"a%20b", encoding=None) == b"a b"
    assert url_unescape(b"a+b") == "a b"
    assert url_unescape(b"a+b", encoding=None) == b"a b"
    assert url_unescape(b"a+b", plus=False) == "a+b"
    assert url_unescape(b"a+b", encoding=None, plus=False) == b"a+b"
    assert url_unescape(b"a%2Bb") == "a+b"
    assert url_unescape(b"a%2Bb", encoding=None) == b"a+b"

# Generated at 2022-06-18 10:03:18.225975
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("a%20b") == "a b"
    assert url_unescape("a%20b", encoding=None) == b"a b"
    assert url_unescape("a+b") == "a+b"
    assert url_unescape("a+b", plus=False) == "a b"
    assert url_unescape("a+b", encoding=None) == b"a+b"
    assert url_unescape("a+b", encoding=None, plus=False) == b"a b"
    assert url_unescape("a+b", encoding="ascii") == "a b"
    assert url_unescape("a+b", encoding="ascii", plus=False) == "a+b"

# Generated at 2022-06-18 10:03:29.268870
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:03:37.555441
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ""
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.facebook.com/") == 'hello <a href="http://www.facebook.com/">http://www.facebook.com/</a>'
    assert linkify("hello http://www.facebook.com/", shorten=True) == 'hello <a href="http://www.facebook.com/">http://www.facebook.com/</a>'
    assert linkify("hello http://www.facebook.com/path/to/file") == 'hello <a href="http://www.facebook.com/path/to/file">http://www.facebook.com/path/to/file</a>'

# Generated at 2022-06-18 10:03:44.868067
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("%2B") == "+"
    assert url_unescape("%2B", plus=False) == "%2B"
    assert url_unescape("%2B", encoding=None) == b"+"
    assert url_unescape("%2B", encoding=None, plus=False) == b"%2B"
    assert url_unescape("%2B", encoding="utf-8") == "+"
    assert url_unescape("%2B", encoding="utf-8", plus=False) == "%2B"



# Generated at 2022-06-18 10:04:00.049447
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text, shorten=True) == 'Hello <a href="http://tornadoweb.org">tornadoweb.org</a>!'
    assert linkify(text, shorten=True, extra_params='rel="nofollow" class="external"') == 'Hello <a href="http://tornadoweb.org" rel="nofollow" class="external">tornadoweb.org</a>!'

# Generated at 2022-06-18 10:04:09.613082
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com:8000/foo") == '<a href="http://www.example.com:8000/foo">http://www.example.com:8000/foo</a>'
    assert linkify("https://www.example.com/") == '<a href="https://www.example.com/">https://www.example.com/</a>'
    assert linkify("http://www.example.com/foo?bar=baz&ding=dong")

# Generated at 2022-06-18 10:04:21.623239
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?a=b") == '<a href="http://example.com/foo/bar?a=b">http://example.com/foo/bar?a=b</a>'

# Generated at 2022-06-18 10:04:31.916095
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:04:41.133668
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    assert linkify(text, extra_params='rel="nofollow" class="external"') == "Hello <a href=\"http://tornadoweb.org\" rel=\"nofollow\" class=\"external\">http://tornadoweb.org</a>!"
    assert linkify(text, require_protocol=True) == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    assert linkify(text, permitted_protocols=["http"]) == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"

# Generated at 2022-06-18 10:04:52.003452
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params="class='external'") == '<a href="http://example.com/foo&amp;bar" class=\'external\'>http://example.com/foo&amp;bar</a>'


# Generated at 2022-06-18 10:05:01.732059
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo?bar=baz&ding=dong") == '<a href="http://example.com/foo?bar=baz&amp;ding=dong">http://example.com/foo?bar=baz&amp;ding=dong</a>'
    assert linkify("http://example.com/foo?bar=baz&ding=dong", shorten=True) == '<a href="http://example.com/foo?bar=baz&amp;ding=dong">http://example.com/foo?bar...</a>'

# Generated at 2022-06-18 10:05:10.088480
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar/baz") == '<a href="http://example.com/foo/bar/baz">http://example.com/foo/bar/baz</a>'

# Generated at 2022-06-18 10:05:15.125034
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text, shorten=True) == 'Hello <a href="http://tornadoweb.org" title="http://tornadoweb.org">tornadoweb.org/...</a>!'
    assert linkify(text, require_protocol=True) == 'Hello http://tornadoweb.org!'
    assert linkify(text, permitted_protocols=["http"]) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

# Generated at 2022-06-18 10:05:25.833295
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("Hello http://www.google.com") == 'Hello <a href="http://www.google.com">http://www.google.com</a>'

# Generated at 2022-06-18 10:05:42.392686
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:05:51.667580
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/foo/bar") == '<a href="http://www.example.com/foo/bar">http://www.example.com/foo/bar</a>'
    assert linkify("http://www.example.com/foo/bar?a=b&c=d") == '<a href="http://www.example.com/foo/bar?a=b&c=d">http://www.example.com/foo/bar?a=b&c=d</a>'

# Generated at 2022-06-18 10:06:02.798012
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/foo/bar/baz/quux?a=1&b=2#fnord") == '<a href="http://example.com/foo/bar/baz/quux?a=1&b=2#fnord">http://example.com/foo/bar/baz/quux?a=1&b=2#fnord</a>'

# Generated at 2022-06-18 10:06:09.774551
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?a=b&c=d") == '<a href="http://example.com/foo/bar?a=b&c=d">http://example.com/foo/bar?a=b&c=d</a>'

# Generated at 2022-06-18 10:06:18.436879
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("http://www.example.com/") == '<a href="http://www.example.com/">http://www.example.com/</a>'
    assert linkify("http://www.example.com:8000/foo") == '<a href="http://www.example.com:8000/foo">http://www.example.com:8000/foo</a>'
    assert linkify("https://www.example.com/") == '<a href="https://www.example.com/">https://www.example.com/</a>'
    assert linkify("http://www.example.com/foo?bar=baz&ding=dong")

# Generated at 2022-06-18 10:06:29.618056
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("foo@example.com") == '<a href="mailto:foo@example.com">foo@example.com</a>'
    assert linkify("foo@example.com", extra_params='class="email"') == '<a href="mailto:foo@example.com" class="email">foo@example.com</a>'
    assert linkify("foo@example.com", require_protocol=True) == 'foo@example.com'

# Generated at 2022-06-18 10:06:40.388777
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:06:51.754986
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:06:58.298217
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?baz=1") == '<a href="http://example.com/foo/bar?baz=1">http://example.com/foo/bar?baz=1</a>'

# Generated at 2022-06-18 10:07:08.425434
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo?bar=baz&ding=dong") == '<a href="http://example.com/foo?bar=baz&ding=dong">http://example.com/foo?bar=baz&amp;ding=dong</a>'
    assert linkify("http://example.com/foo#bar") == '<a href="http://example.com/foo#bar">http://example.com/foo#bar</a>'
    assert linkify("http://example.com/foo#bar", shorten=True) == '<a href="http://example.com/foo#bar">http://example.com/foo#bar</a>'
   

# Generated at 2022-06-18 10:07:26.726002
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar/baz") == '<a href="http://example.com/foo/bar/baz">http://example.com/foo/bar/baz</a>'

# Generated at 2022-06-18 10:07:36.905661
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com", shorten=True) == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com", shorten=True, extra_params='rel="nofollow" class="external"') == '<a href="http://www.google.com" rel="nofollow" class="external">http://www.google.com</a>'

# Generated at 2022-06-18 10:07:45.176347
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:07:54.126740
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:08:06.618252
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?baz=1") == '<a href="http://example.com/foo/bar?baz=1">http://example.com/foo/bar?baz=1</a>'

# Generated at 2022-06-18 10:08:18.480929
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar", extra_params="class=\"external\"") == '<a href="http://example.com/foo&amp;bar" class="external">http://example.com/foo&amp;bar</a>'

# Generated at 2022-06-18 10:08:28.944946
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar?baz=1") == '<a href="http://example.com/foo/bar?baz=1">http://example.com/foo/bar?baz=1</a>'

# Generated at 2022-06-18 10:08:39.407512
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=foo&bar=baz") == '<a href="http://www.google.com/search?q=foo&amp;bar=baz">http://www.google.com/search?q=foo&amp;bar=baz</a>'
    assert linkify("http://www.google.com/search?q=foo&bar=baz", shorten=True) == '<a href="http://www.google.com/search?q=foo&amp;bar=baz">http://www.google.com/search?q...</a>'

# Generated at 2022-06-18 10:08:50.277734
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo") == '<a href="http://example.com/foo">http://example.com/foo</a>'
    assert linkify("http://example.com/foo/bar") == '<a href="http://example.com/foo/bar">http://example.com/foo/bar</a>'
    assert linkify("http://example.com/foo/bar/baz") == '<a href="http://example.com/foo/bar/baz">http://example.com/foo/bar/baz</a>'

# Generated at 2022-06-18 10:08:58.588269
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:09:13.344828
# Unit test for function linkify
def test_linkify():
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.facebook.com") == 'hello <a href="http://www.facebook.com">http://www.facebook.com</a>'
    assert linkify("hello http://www.facebook.com/") == 'hello <a href="http://www.facebook.com/">http://www.facebook.com/</a>'
    assert linkify("hello http://www.facebook.com/foo") == 'hello <a href="http://www.facebook.com/foo">http://www.facebook.com/foo</a>'
    assert linkify("hello http://www.facebook.com/foo/") == 'hello <a href="http://www.facebook.com/foo/">http://www.facebook.com/foo/</a>'

# Generated at 2022-06-18 10:09:21.124095
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/search?q=linkify") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a>'
    assert linkify("http://www.google.com/search?q=linkify extra") == '<a href="http://www.google.com/search?q=linkify">http://www.google.com/search?q=linkify</a> extra'

# Generated at 2022-06-18 10:09:28.972499
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo&bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'
    assert linkify("http://example.com/foo&amp;bar") == '<a href="http://example.com/foo&amp;bar">http://example.com/foo&amp;bar</a>'