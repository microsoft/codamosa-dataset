

# Generated at 2022-06-26 07:49:23.355830
# Unit test for function utf8
def test_utf8():
    assert utf8("abc") == b"abc"
    assert utf8("abc".encode("ascii")) == b"abc"
    assert utf8("abc".encode("utf-8")) == b"abc"
    assert utf8("abc".encode("utf-16")) == b"abc"
    assert utf8("abc".encode("utf-32")) == b"abc"


# Generated at 2022-06-26 07:49:31.671960
# Unit test for function utf8
def test_utf8():
    any_0 = utf8(True)
    any_1 = utf8(False)
    any_2 = utf8(True)
    any_3 = utf8(False)
    any_4 = utf8(True)
    any_5 = utf8(False)
    any_6 = utf8(True)
    any_7 = utf8(False)
    any_8 = utf8(True)
    any_9 = utf8(False)
    any_10 = utf8(False)
    any_11 = utf8(True)
    any_12 = utf8(False)
    any_13 = utf8(True)
    any_14 = utf8(False)
    any_15 = utf8(True)
    any_16 = utf

# Generated at 2022-06-26 07:49:36.650334
# Unit test for function utf8
def test_utf8():
    # Test exception behavior
    try:
        utf8({"test": "dictionary"})
    except TypeError as exception_0:
        assert exception_0.args[0] == "Expected bytes, unicode, or None; got <class 'dict'>"


# Generated at 2022-06-26 07:49:49.074678
# Unit test for function linkify
def test_linkify():
    valid_url = _URL_RE.search('http://tornadoweb.org')
    assert valid_url is not None

    # Test without extra_params
    assert linkify('Hello <b>http://tornadoweb.org</b>!') == 'Hello <b><a href="http://tornadoweb.org">http://tornadoweb.org</a></b>!'
    assert linkify('Hello <b>www.tornadoweb.org</b>!') == 'Hello <b><a href="http://www.tornadoweb.org">www.tornadoweb.org</a></b>!'
    assert linkify('Hello <b>tornadoweb.org</b>!') == 'Hello <b>tornadoweb.org</b>!'

    # Test with extra_params

# Generated at 2022-06-26 07:49:50.290562
# Unit test for function linkify
def test_linkify():
    str_0 = "Simple text"
    str_1 = linkify(str_0)

# Generated at 2022-06-26 07:49:59.217208
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com/foo.php?baz=bar&biz=buz") == '<a href="http://example.com/foo.php?baz=bar&amp;biz=buz">http://example.com/foo.php?baz=bar&amp;biz=buz</a>'

# Generated at 2022-06-26 07:50:03.444256
# Unit test for function utf8
def test_utf8():
    # Test for function utf8
    str_0 = 'test' 
    bytes_0 = utf8(str_0)
    assert bytes_0 == b'test'

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-26 07:50:09.849621
# Unit test for function linkify
def test_linkify():
    string_0 = "Hello http://tornadoweb.org!"
    string_1 = linkify(string_0)
    bool_0 = True
    any_0 = recursive_unicode(bool_0)
    string_2 = " Hello http://tornadoweb.org! "
    string_3 = linkify(string_2, True)


# Generated at 2022-06-26 07:50:18.830553
# Unit test for function utf8
def test_utf8():
    assert utf8(u"foo") == b'foo'
    assert utf8(u"foo".encode("utf-8")) == b'foo'
    assert utf8(b"foo") == b'foo'
    assert utf8(None) is None
    try:
        utf8(1)
    except TypeError:
        pass
    else:
        assert False


_TO_UNICODE_TYPES = (unicode_type, type(None))


# Generated at 2022-06-26 07:50:24.395696
# Unit test for function utf8
def test_utf8():
    string_0 = "1"
    bytearray_0 = bytearray(string_0, "utf-8")
    string_1 = utf8(bytearray_0)
    assert string_1 == bytearray_0, "Expected \"1\", but got {0}".format(string_1)


# Generated at 2022-06-26 07:50:53.557645
# Unit test for function linkify
def test_linkify():
    '''Test case for function linkify
    '''
    text = 'Hello http://tornadoweb.org!'
    shorten = False
    extra_params = 'rel="nofollow" class="external"'
    require_protocol = False
    permitted_protocols = ['http', 'https']
    
    expected_result = 'Hello <a href="http://tornadoweb.org" rel="nofollow" class="external">http://tornadoweb.org</a>!'
    actual_result = linkify(text, shorten, extra_params, require_protocol, permitted_protocols)
    assert actual_result == expected_result


# Generated at 2022-06-26 07:51:04.211594
# Unit test for function linkify
def test_linkify():
    url = "https://www.google.com/search?q=tornado&oq=tornado&aqs=chrome..69i57j0l5.4195j0j4&sourceid=chrome&ie=UTF-8"
    result = linkify(url)
    print(result)
    assert result == '<a href="https://www.google.com/search?q=tornado&oq=tornado&aqs=chrome..69i57j0l5.4195j0j4&sourceid=chrome&ie=UTF-8">https://www.google.com/search?q=tornado&oq=tornado&aqs=chrome..69i57j0l5.4195j0j4&sourceid=chrome&ie=UTF-8</a>'


# Generated at 2022-06-26 07:51:08.518549
# Unit test for function linkify
def test_linkify():
    # TODO
    pass


# Generated at 2022-06-26 07:51:11.311569
# Unit test for function linkify
def test_linkify():
    text_0 = 'Hello http://tornadoweb.org!'
    str_0 = linkify(text_0)
    print(str_0)


# Generated at 2022-06-26 07:51:17.499362
# Unit test for function linkify
def test_linkify():
    str_0 = "Hello http://www.rinohtype.org!"
    str_1 = linkify(str_0)
    assert(str_1 == "Hello <a href=\"http://www.rinohtype.org\">http://www.rinohtype.org</a>!")


# Generated at 2022-06-26 07:51:22.097161
# Unit test for function linkify
def test_linkify():
    string_0 = "http://www.google.com/"
    boolean_0 = True
    string_1 = linkify(string_0, boolean_0)
    print(string_1)


if __name__ == "__main__":
    test_case_0()
    # test_linkify()

# Generated at 2022-06-26 07:51:27.671106
# Unit test for function linkify
def test_linkify():
    linkify("github.com/Tiger66639",True,"haha",False,["https"])
    linkify("github.com/Tiger66639",False,"haha",False,["https"])
    linkify("github.com/Tiger66639",True,"haha",False,["http"])
    linkify("github.com/Tiger66639",False,"haha",False,["http"])


# Generated at 2022-06-26 07:51:34.513342
# Unit test for function linkify
def test_linkify():
    str_0 = 'You can find Tornado at <a href="http://www.tornadoweb.org/en/stable/">www.tornadoweb.org</a>'
    str_1 = linkify('You can find Tornado at http://www.tornadoweb.org/en/stable/')
    assert(str_0 == str_1)


# Generated at 2022-06-26 07:51:43.337513
# Unit test for function linkify
def test_linkify():
    # Testing a string
    print(linkify("Hello http://www.google.com!"))
    # Testing a byte string
    print(linkify(bytes("Hello http://www.google.com!", "utf-8")))
    # Check that unquoting works
    print(linkify("https://www.google.com?q=%22hello,%20world%22"))
    # Check unicode
    print(linkify("Превед медвед"))
    # Check that our regex doesn't mistake an email address for a link
    print(linkify("Email me at xyz@example.com"))



if __name__ == "__main__":
    test_case_0()
    test_linkify()

# Generated at 2022-06-26 07:51:53.637933
# Unit test for function linkify
def test_linkify():
    print("Testing Linkify")
    # Test linkification
    test_str = "http://www.tornadoweb.org"
    expected_str = '<a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a>'
    assert (linkify(test_str) == expected_str)
    # Test no linkification
    test_str = "example.com"
    expected_str = "example.com"
    assert (linkify(test_str) == expected_str)
    # Test linkification with extra_params
    test_str = "http://www.tornadoweb.org/en/stable"

# Generated at 2022-06-26 07:52:08.141686
# Unit test for function linkify
def test_linkify():
    test_case_0()

# Invoke unit tests
test_linkify()

# vim:et:sta:sts=4:sw=4:ts=4:tw=79:

# Generated at 2022-06-26 07:52:10.201264
# Unit test for function linkify
def test_linkify():
    # Test for function linkify, test number 0
    test_case_0()

test_linkify()

# Generated at 2022-06-26 07:52:13.496819
# Unit test for function linkify
def test_linkify():
    test_case_0()

if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-26 07:52:17.985158
# Unit test for function linkify
def test_linkify():
    print(linkify('Hello http://tornadoweb.org!', '"', 'www.google.com'))
    assert linkify('Hello http://tornadoweb.org!', '"', 'www.google.com') == '<a href="http://tornadoweb.org">Hello http://tornadoweb.org!</a>'
    print('pass test_linkify')


# Generated at 2022-06-26 07:52:21.584246
# Unit test for function linkify
def test_linkify():
    # Test case 0
    str_0 = ' 5Oly\r'
    str_1 = linkify(str_0, str_0)
    return



# Generated at 2022-06-26 07:52:30.359105
# Unit test for function linkify
def test_linkify():
    print(linkify('Hello http://tornadoweb.org!'))
    print(linkify('Hello http://tornadoweb.org!', shorten=True))
    print(linkify('Hello http://tornadoweb.org!', shorten=True, extra_params='rel="nofollow" class="external"'))
    print(linkify('Hello http://tornadoweb.org!', shorten=True, extra_params=lambda x: 'rel="nofollow" class="external"'))
    print(linkify('Hello www.tornadoweb.org!', require_protocol=True))
    print(linkify('Hello www.tornadoweb.org!', require_protocol=False))
    print(linkify('Hello http://example.com/ http://tornadoweb.org/!', permitted_protocols=set(['http'])))
   

# Generated at 2022-06-26 07:52:43.366041
# Unit test for function linkify

# Generated at 2022-06-26 07:52:48.446649
# Unit test for function linkify
def test_linkify():
    str_0 = ' 5Oly\r'
    str_1 = linkify(str_0, str_0)

    # Test
    if str_1 != ' 5Oly\r':
        raise Exception("Result = {0}. Expected = {1}.".format(str_1, ' 5Oly\r'))


# Generated at 2022-06-26 07:52:50.988619
# Unit test for function linkify
def test_linkify():
    str_0 = 'toto'
    str_1 = linkify(str_0, str_0)
    print('toto')

test_linkify()

# Generated at 2022-06-26 07:52:52.710429
# Unit test for function linkify
def test_linkify():
    x = 'http://www.baidu.com'
    y = linkify(x)


# Generated at 2022-06-26 07:53:13.888372
# Unit test for function linkify
def test_linkify():
    str_0 = ' 5Oly\r'

    str_1 = ' 5Oly\r'
    str_2 = ' 5Oly\r'
    result = linkify(str_1, str_2)
    assert result == ''

    str_2 = ' 5Oly\r'
    str_1 = ' 5Oly\r'
    result = linkify(str_1, str_2)
    assert result == ''

    str_2 = ' 5Oly\r'
    str_1 = ' 5Oly\r'
    result = linkify(str_1, str_2)
    assert result == ''

    str_1 = ' 5Oly\r'
    result = linkify(str_1)
    assert result == ''

    str_1 = ' 5Oly\r'
    result

# Generated at 2022-06-26 07:53:18.756041
# Unit test for function linkify
def test_linkify():
    print('Test linkify')
    for str_0 in [' 4 ', '4', '4 d', '4 d ', ' 4d ', '5d', '5.5', '5.5d']:
        print(linkify(str_0))


# Generated at 2022-06-26 07:53:21.766787
# Unit test for function linkify
def test_linkify():
    str_0 = ' 5Oly\r'
    str_1 = linkify(str_0, str_0)


if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-26 07:53:23.917061
# Unit test for function linkify
def test_linkify():
    # test 0
    try:
        test_case_0()
    except:
        print ('test 0 failed')
    else:
        print ('test 0 passed')


# Generated at 2022-06-26 07:53:39.337283
# Unit test for function linkify
def test_linkify():
    # For example: linkify("Hello http://tornadoweb.org!") would return
    # "Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!"
    assert linkify("Hello http://tornadoweb.org!") == \
    "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"

    assert linkify("Hello www.tornadoweb.org!") == \
    "Hello <a href=\"http://www.tornadoweb.org\">www.tornadoweb.org</a>!"

    assert linkify("Hello <http://tornadoweb.org>!") == \
    "Hello &lt;<a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>&gt;!"


# Generated at 2022-06-26 07:53:41.466022
# Unit test for function linkify
def test_linkify():
    str_0 = '5Oly\r'
    str_1 = linkify(str_0, str_0)



# Generated at 2022-06-26 07:53:53.200385
# Unit test for function linkify
def test_linkify():
    ## string is a tuple
    ## string is a list
    ## string is a dict
    ## string is a none
    ## string is a str
    ## string is a byte
    ## long string
    str_1 = 'https://www.google.com/?sourceid=chrome-instant&rlz=1C1CHBD_enUS814US814&ion=1&espv=2&ie=UTF-8#q=python%20string%20is%20a%20byte'
    str_2 = linkify(str_1)
    ## str_1 is longer than max_len

# Generated at 2022-06-26 07:53:54.649609
# Unit test for function linkify
def test_linkify():
    print(linkify('hello http://tornadoweb.org'))


# Generated at 2022-06-26 07:53:57.218942
# Unit test for function linkify
def test_linkify():
    test_case_0()

if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-26 07:54:06.203969
# Unit test for function linkify
def test_linkify():
    # Test for linkify function
    str_0 = ' 5Oly\r'
    str_1 = linkify(str_0, str_0)
    assert str_1 == ' 5Oly\r'

    str_0 = '5Oly'
    str_1 = linkify(str_0, str_0)
    assert str_1 == '5Oly'

    str_0 = '5Oly'
    str_1 = linkify(str_0, str_0)
    assert str_1 == '5Oly'

    str_0 = '5Oly'
    str_1 = linkify(str_0, str_0)
    assert str_1 == '5Oly'

    str_0 = '5Oly'
    str_1 = linkify(str_0, str_0)

# Generated at 2022-06-26 07:54:19.332980
# Unit test for function linkify
def test_linkify():
    print('test_linkify...')
    str_0 = ' 5Oly\r'
    assert linkify(str_0, str_0) == ' 5Oly\r'

# Generated at 2022-06-26 07:54:24.323553
# Unit test for function linkify
def test_linkify():
    str_0 = ' 5Oly\r'
    str_1 = linkify(str_0, str_0)
    if str_0.capitalize() < str_1:
        return str_1.encode('utf-8')
    else:
        return str_0.encode('utf-8')

# Generated at 2022-06-26 07:54:36.175245
# Unit test for function linkify

# Generated at 2022-06-26 07:54:41.989370
# Unit test for function linkify
def test_linkify():
    #test case 1
    assert linkify('5Oly\r') == '5Oly\r'

    #test case 2
    assert linkify('http://5Oly\r') == '<a href="http://5Oly\r">http://5Oly\r</a>'

    #test case 3
    assert linkify('http://www.5Oly\r') == '<a href="http://www.5Oly\r">http://www.5Oly\r</a>'

    #test case 4
    assert linkify('https://www.5Oly\r') == '<a href="https://www.5Oly\r">https://www.5Oly\r</a>'

    #test case 5

# Generated at 2022-06-26 07:54:52.350039
# Unit test for function linkify
def test_linkify():
    str_0 = ' 5Oly\r'
    str_1 = linkify(str_0, str_0)
    assert str_0 == str_1

    str_2 = '\x0fp\t\x13\x0c\\'
    str_3 = linkify(str_2, str_0)
    assert str_2 == str_3

    str_4 = '\x0bho\x01'
    str_5 = linkify(str_4, str_0)
    assert str_4 == str_5

    str_6 = '\x08 \x0e'
    str_7 = linkify(str_6, str_0)
    assert str_6 == str_7

    str_8 = 'jga\tQ/\t\x1f'

# Generated at 2022-06-26 07:54:56.800447
# Unit test for function linkify
def test_linkify():
    #str_0 = ' 5Oly\r'
    #str_1 = linkify(str_0, str_0)
    #assert str_1 == ' 5Oly\r'
    pass


# Generated at 2022-06-26 07:55:00.230071
# Unit test for function linkify
def test_linkify():
    str_0 = ' 5Oly\r'
    str_1 = linkify(str_0, str_0)
    assert str_1 == ' 5Oly\r'


# Generated at 2022-06-26 07:55:10.053398
# Unit test for function linkify
def test_linkify():
    str_0 = 'www.apple.com'
    str_1 = linkify(str_0, str_0)
    print(str_1)
    assert_true(str_1)

    str_0 = 'www.apple.com'
    str_1 = linkify(str_0, str_0)
    print(str_1)
    assert_true(str_1)

    str_0 = 'www.apple.com'
    str_1 = linkify(str_0, str_0)
    print(str_1)
    assert_true(str_1)


# Generated at 2022-06-26 07:55:24.527757
# Unit test for function linkify

# Generated at 2022-06-26 07:55:36.803441
# Unit test for function linkify
def test_linkify():
    # Tries to decode a string from string to bytes.
    # 
    #   If `errors` is specified, and the input is invalid, a
    # UnicodeDecodeError is raised for the first invalid byte, showing
    # `string_name` as the object name.  Otherwise, a ValueError is
    # raised.

    # Arguments:
    # 1) input: The string to decode.
    # 2) encoding: The encoding to use, if any.
    # 3) errors: Default: "strict". An error mode.
    str_0 = ' 5Oly\r'
    str_1 = unicode(str_0, str_0)
    # str_1 = str(str_0, str_0)
    print(str_1)

    # str_2 = str("5Oly\r", "utf-

# Generated at 2022-06-26 07:55:59.674204
# Unit test for function linkify
def test_linkify():
    test_case_0()
    pass

if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-26 07:56:04.819047
# Unit test for function linkify
def test_linkify():
    str_0 = ' 5Oly\r'
    str_1 = linkify(str_0, str_0)
    print('str_1: ', str_1)

if __name__ == '__main__':
    test_case_0()
    test_linkify()

# Generated at 2022-06-26 07:56:12.395989
# Unit test for function linkify

# Generated at 2022-06-26 07:56:17.472279
# Unit test for function linkify
def test_linkify():
    '''
    Test the function linkify

    Parameters
    ----------
    None

    Returns
    -------
    out : 
        Bool representing if test was successful
    '''
    res = linkify('This is a link: www.google.com')
    assert 'This is a link: <a href="http://www.google.com">www.google.com</a>' == res
    return True

if __name__ == '__main__':
    
    test_case_0()
    test_linkify()

# Generated at 2022-06-26 07:56:24.200167
# Unit test for function linkify
def test_linkify():
    str_0 = ' 5Oly\r'
    str_1 = linkify(str_0, str_0)
    test_tuple = (str_0, str_1)
    return test_tuple


# Generated at 2022-06-26 07:56:28.477912
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'


# Generated at 2022-06-26 07:56:33.310803
# Unit test for function linkify
def test_linkify():
    str_0 = ' 5Oly\r'
    str_1 = linkify(str_0, str_0)
    assert str_1 == str_0
    assert True



if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-26 07:56:44.380980
# Unit test for function linkify
def test_linkify():
    from tornado.util import linkify

# Generated at 2022-06-26 07:56:48.546474
# Unit test for function linkify
def test_linkify():
    str_0 = ' 5Oly\r'
    str_1 = linkify(str_0, str_0)
    test_string = """<a href="http://Oly%0A">Oly%0A</a>"""
    assert test_string == str_1


# Generated at 2022-06-26 07:56:56.826873
# Unit test for function linkify
def test_linkify():
    assert(linkify("Hello (tornadoweb.org)!") == "Hello (tornadoweb.org)!")
    assert(linkify("Hello <tornadoweb.org>!") == "Hello &lt;tornadoweb.org&gt;!")
    assert(linkify("Hello www.tornadoweb.org!") == "Hello <a href=\"http://www.tornadoweb.org\">www.tornadoweb.org</a>!")
    assert(linkify("Hello http://tornadoweb.org!") == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!")
    assert(linkify("Hello http://tornadoweb.org/!") == "Hello <a href=\"http://tornadoweb.org/\">http://tornadoweb.org/</a>!")


# Generated at 2022-06-26 07:57:43.011638
# Unit test for function linkify
def test_linkify():
    test_case_0()


# Generated at 2022-06-26 07:57:54.923162
# Unit test for function linkify
def test_linkify():
    assert linkify("1") == u"1"
    assert linkify("a b") == u"a b"
    assert linkify("www.google.com") == u'<a href="http://www.google.com">www.google.com</a>'
    assert linkify("http://www.google.com") == u'<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("http://www.google.com/") == u'<a href="http://www.google.com/">http://www.google.com/</a>'

# Generated at 2022-06-26 07:58:00.772710
# Unit test for function linkify
def test_linkify():
    # str_0 = ' 5Oly\r'
    # str_1 = linkify(str_0, str_0)
    import re
    str_0 = '5Oly\r'
    str_0 = re.split(r"\n", str_0)
    str_1 = linkify(str_0, str_0)
    print(str_1)


# Generated at 2022-06-26 07:58:11.043130
# Unit test for function linkify
def test_linkify():
    assert linkify('http://example.com').startswith('<a href=')
    assert linkify('hello http://example.com').startswith('hello <a href=')
    assert linkify('Go to ftp://ftp.example.com/').startswith('Go to <a href=')
    assert linkify('Go to ftp://ftp.example.com/ and say hello').startswith('Go to <a href=')
    assert linkify('www.example.com').startswith('<a href=')
    assert linkify('Go to www.example.com/').startswith('Go to <a href=')
    assert linkify('Go to www.example.com/ and say hello').startswith('Go to <a href=')



# Generated at 2022-06-26 07:58:12.459937
# Unit test for function linkify
def test_linkify():
    test_case_0()

if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-26 07:58:23.257702
# Unit test for function linkify
def test_linkify():
    assert linkify('Hello http://tornadoweb.org!') == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify('Hello http://tornadoweb.org/!') == 'Hello <a href="http://tornadoweb.org/">http://tornadoweb.org/</a>!'
    assert linkify('Hello http://www.tornadoweb.org') == 'Hello <a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a>'
    assert linkify('Hello http://www.tornadoweb.org:8888') == 'Hello <a href="http://www.tornadoweb.org:8888">http://www.tornadoweb.org:8888</a>'

# Generated at 2022-06-26 07:58:33.646001
# Unit test for function linkify

# Generated at 2022-06-26 07:58:39.314511
# Unit test for function linkify
def test_linkify():
    str_0 = ' 5Oly\r'
    str_1 = linkify(str_0, str_0)
if __name__ == "__main__":
    test_case_0()
    test_linkify()

# Generated at 2022-06-26 07:58:49.523972
# Unit test for function linkify
def test_linkify():
    # Test number 0
    str_0 = " 5Oly\r"
    str_1 = linkify(str_0, str_0)
    assert str_1 == " 5Oly\r"
    # Test number 1
    str_0 = "http://slashdot.org"
    str_1 = linkify(str_0, str_0)
    assert str_1 == '<a href="http://slashdot.org">http://slashdot.org</a>'
    # Test number 2
    str_0 = "http://slashdot.org"
    str_1 = linkify(str_0, str_0)
    assert str_1 == '<a href="http://slashdot.org">http://slashdot.org</a>'

