

# Generated at 2022-06-26 07:48:58.592490
# Unit test for function linkify
def test_linkify():
    # Tests if this function runs without error
    linkify("http://www.inveneo.org", shorten=False, extra_params="", require_protocol=False)

if __name__ == '__main__':
    test_case_0()
    test_linkify()

# Generated at 2022-06-26 07:49:00.124493
# Unit test for function linkify
def test_linkify():

    text_0 = "Hello http://tornadoweb.org!"
    optional_0 = linkify(text_0)


# Generated at 2022-06-26 07:49:01.510573
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape(optional_0)


# Generated at 2022-06-26 07:49:02.915910
# Unit test for function linkify
def test_linkify():
    text_0 = "http://www.google.com"
    optional_0 = linkify(text_0)


# Generated at 2022-06-26 07:49:13.219822
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("http%3A%2F%2Fabc.com", encoding=None) == b"http://abc.com"
    assert url_unescape("http%3A%2F%2Fabc.com", encoding="utf-8") == "http://abc.com"
    assert url_unescape(b"http%3A%2F%2Fabc.com", encoding=None) == b"http://abc.com"
    assert url_unescape(b"http%3A%2F%2Fabc.com", encoding="utf-8") == "http://abc.com"


# Generated at 2022-06-26 07:49:15.014015
# Unit test for function linkify
def test_linkify():
    print("Executing function " + inspect.getframeinfo(inspect.currentframe()).function, file=sys.stderr)
    value_0 = linkify("Hello http://tornadoweb.org!")
    print(value_0, file=sys.stderr)


# Generated at 2022-06-26 07:49:16.103072
# Unit test for function linkify
def test_linkify():
    string_0 = "Hello www.torndoweb.org!"
    str_0 = linkify(string_0)


# Generated at 2022-06-26 07:49:18.584241
# Unit test for function linkify
def test_linkify():
    test_case_0()


if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-26 07:49:29.681189
# Unit test for function linkify
def test_linkify():
    # Test original functionality
    test_input = '<Hello http://tornadoweb.org!>'

    output = linkify(test_input)
    assert output == '<Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!>'

    # Test shorten functionality and new extra_params

# Generated at 2022-06-26 07:49:34.289801
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    actual_result = linkify(text)
    assert actual_result == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"


# Generated at 2022-06-26 07:49:47.249828
# Unit test for function linkify
def test_linkify():
    str_0 = "Hello http://tornadoweb.org!"
    str_1 = "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    assert linkify(str_0) == str_1


# Generated at 2022-06-26 07:49:52.742269
# Unit test for function linkify
def test_linkify():
    text = '''
        <p>www.google.com is the new player in the search engine game.</p>

        <p>www.cnn.com is a news site.</p>

        <p>This is some text. http://www.yahoo.com/some/path?foo=bar&baz=quux#x</p>
        '''

    new_text = linkify(text)


# Generated at 2022-06-26 07:49:56.003048
# Unit test for function linkify
def test_linkify():
    text_0 = b"{\x16'\tnA\x0f\xaaK\xf1|*\x13\xb9\x94\x81"
    assertEqual(linkify(text_0), expected_0)


# Generated at 2022-06-26 07:50:03.764625
# Unit test for function linkify
def test_linkify():
    # Create a clean test environment
    import tempfile
    import os
    env = tempfile.mkdtemp()
    curr_dir = os.getcwd()
    os.chdir(env)

    # Setup test data
    long_url = "http://" + ("a" * 1000) + ".com"
    url_with_params = "http://example.com?foo=bar"
    permitted_protocols = ["http", "https"]

    # Test with extra_params
    text = "Hello http://tornadoweb.org!"
    extra_params = "rel='nofollow' class='external'"
    expected = "Hello <a href='http://tornadoweb.org' " + extra_params + ">http://tornadoweb.org</a>!"  # noqa: E501

# Generated at 2022-06-26 07:50:08.850981
# Unit test for function url_unescape
def test_url_unescape():  # noqa: N802
    optional_0 = url_unescape(b"\x04{\x16'\tnA\x0f\xaaK\xf1|*\x13\xb9\x94\x81")


# Generated at 2022-06-26 07:50:21.787753
# Unit test for function linkify
def test_linkify():
    assert linkify(b"Hello http://tornadoweb.org!") == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    assert linkify(b"Hello https://tornadoweb.org!") == "Hello <a href=\"https://tornadoweb.org\">https://tornadoweb.org</a>!"
    assert linkify(b"Hello <b>http://tornadoweb.org!</b>") == "Hello <b><a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!</b>"
    assert linkify(b"Hello <p>http://tornadoweb.org!</p>") == "Hello <p><a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!</p>"
   

# Generated at 2022-06-26 07:50:31.493935
# Unit test for function linkify
def test_linkify():
    string_0 = "www.facebook.com"
    string_1 = "https://www.facebook.com/"
    string_2 = "Hello https://www.facebook.com/!"

    # string_0 = linkify(string_0, False, "", False, ["http", "https"])
    # print(string_0)
    # string_0 = linkify(string_1, False, "", False, ["http", "https"])
    # print(string_0)
    string_0 = linkify(string_2, False, "", False, ["http", "https"])
    print(string_0)


if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-26 07:50:43.256977
# Unit test for function linkify
def test_linkify():
    class TestLinkify(unittest.TestCase):
        def helper(self, input, output, **kwargs):
            self.assertEqual(linkify(input, **kwargs), output)

        def test_empty(self):
            self.helper("", "")

        def test_plain(self):
            self.helper("plain", "plain")

        def test_url(self):
            self.helper(
                "text http://example.com/ link",
                'text <a href="http://example.com/">http://example.com/</a> link',
            )


# Generated at 2022-06-26 07:50:56.302068
# Unit test for function url_unescape
def test_url_unescape():
    # Test xrange is there
    assert "xrange" in globals(), "xrange not defined -- typing issue?"
    # test unicode behavior
    assert url_unescape("%E4%BD%A0+%E5%A5%BD") == u"\u4f60 \u597d", "Wrong unicode results"
    # test byte behavior
    assert url_unescape(b"%E4%BD%A0+%E5%A5%BD") == b"\xe4\xbd\xa0 \xe5\xa5\xbd", "Wrong byte string results"

# Generated at 2022-06-26 07:51:03.422655
# Unit test for function linkify
def test_linkify():
    text_0 = "abc def"
    require_protocol_0 = False
    shorten_0 = False
    text_1 = "http://www.example.com/foo/"
    require_protocol_1 = False
    shorten_1 = True
    text_2 = "Hi there http://example.com/"
    require_protocol_2 = False
    shorten_2 = False
    text_3 = "http://example.com/"
    require_protocol_3 = False
    shorten_3 = True
    text_4 = "http://example.com/foo/bar?baz=1"
    require_protocol_4 = False
    shorten_4 = True
    text_5 = "this is a link to http://example.com/\n"
    require_protocol_5 = False
    shorten_5 = False

# Generated at 2022-06-26 07:51:22.092253
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    assert linkify(str_0) == 'plain'
    str_1 = 'http://tornadoweb.org'
    assert linkify(str_1) == '<a href="http://tornadoweb.org">http://tornadoweb.org</a>'
    str_2 = 'plain www.tornadoweb.org'
    assert linkify(str_2) == 'plain <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>'
    str_3 = 'https://github.com/facebook/tornado'
    assert linkify(str_3) == '<a href="https://github.com/facebook/tornado">https://github.com/facebook/tornado</a>'

# Generated at 2022-06-26 07:51:29.231199
# Unit test for function linkify
def test_linkify():

    # First URL-escape so that our strings are all safe.
    # The regex is modified to avoid character entites other than &amp; so
    # that we won't pick up &quot;, etc.
    text = _unicode(xhtml_escape('Hello www.facebook.com!'))
    return _URL_RE.sub(make_link, text)

    text = 'Hello www.facebook.com!'

    # Call function being tested
    result = linkify(text, False, "", False, ['http', 'https'])

    # Check results

    assert result == 'Hello <a href="http://www.facebook.com">www.facebook.com</a>!', "Result does not match expected value"


# Generated at 2022-06-26 07:51:30.581710
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    ret_0 = linkify(str_0)
    assert ret_0 == 'plain'


# Generated at 2022-06-26 07:51:41.350401
# Unit test for function linkify
def test_linkify():
    # Test case 1
    #<linkify>
    test_case_1 = '<linkify>'
    res = linkify(test_case_1)
    expected_output = '&lt;linkify&gt;'
    assert res == expected_output

    # Test case 2
    #<linkify>
    # more text
    test_case_2 = '<linkify>\nmore text'
    res = linkify(test_case_2)
    expected_output = '&lt;linkify&gt;\nmore text'
    assert res == expected_output

    # Test case 3
    # http://google.com
    test_case_3 = 'http://google.com'
    res = linkify(test_case_3)

# Generated at 2022-06-26 07:51:43.596623
# Unit test for function linkify
def test_linkify():
    expected = 'plain'
    assert linkify('plain') == expected
    str_0 = 'url'


# Generated at 2022-06-26 07:51:53.757830
# Unit test for function linkify
def test_linkify():
    # Test number: 0
    str_0 = 'plain'

    # Test number: 1
    str_1 = 'plain http://www.tornadoweb.org'

    # Test number: 2
    str_2 = 'plain http://www.tornadoweb.org/'

    # Test number: 3
    str_3 = 'plain http://www.tornadoweb.org/doc'

    # Test number: 4
    str_4 = 'plain http://www.tornadoweb.org/doc/'

    # Test number: 5
    str_5 = 'plain http://www.tornadoweb.org/doc/tornado'

    # Test number: 6
    str_6 = 'plain http://www.tornadoweb.org/doc/tornado/'

    # Test number: 7

# Generated at 2022-06-26 07:52:07.437676
# Unit test for function linkify
def test_linkify():
    # Try calling function 'linkify'
    str_0 = 'plain'
    str_1 = '<a href="http://google.com">google.com</a>'
    str_2 = '<a href="http://google.com">google.com</a>'
    str_3 = '<a href="http://google.com">google.com</a>'
    str_4 = '<a href="http://google.com">google.com</a>'
    str_5 = '<a href="http://google.com">google.com</a>'

    assert linkify(str_0, True) == str_1
    assert linkify(str_0) == str_2
    assert linkify(str_0, False) == str_3
    assert linkify(str_0, True, ' ')

# Generated at 2022-06-26 07:52:21.488666
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    assert linkify(str_0) == 'plain'
    str_1 = 'linked'
    assert linkify(str_1, True, '', True, []) == '<a href="http://linked">linked</a>'
    str_2 = 'linked'
    assert linkify(str_2, True, '', True, ['http']) == '<a href="http://linked">linked</a>'
    str_3 = 'linked'
    assert linkify(str_3, True, '', True, ['https']) == 'linked'
    str_4 = 'linked'
    assert linkify(str_4, True, '', True, ['http', 'https']) == '<a href="http://linked">linked</a>'
    str_5 = 'linked'
   

# Generated at 2022-06-26 07:52:30.358652
# Unit test for function linkify
def test_linkify():
    text = 'plain'
    test = linkify(text)
    print('test linkify 0 =', test)
    assert test == 'plain'

    text = 'http://yo.org'
    test = linkify(text)
    print('test linkify 1 =', test)
    assert test == '<a href="http://yo.org">http://yo.org</a>'

    text = 'http://yo.org?key=value'
    test = linkify(text)
    print('test linkify 2 =', test)
    assert test == '<a href="http://yo.org?key=value">http://yo.org?key=value</a>'

    text = 'http://www.showme.com/sh?id=4983920&key=value'
    test = linkify(text)
    print

# Generated at 2022-06-26 07:52:33.553939
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    str_1 = linkify(str_0)

    assert str_1 == 'plain'


# Generated at 2022-06-26 07:53:18.214340
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    assert "plain" == linkify(str_0)
    str_0 = 'a http://www.google.com link'
    assert "a <a href=\"http://www.google.com\">http://www.google.com</a> link" == linkify(str_0)
    str_0 = 'hello world'
    assert "<" == linkify(str_0)
    str_0 = 'hello world'
    assert "&lt;" == linkify(str_0)
    str_0 = 'hello world'
    assert "&lt;<a" == linkify(str_0)
    str_0 = 'hello world'
    assert "<a href=\"http://www.google.com\">http://www.google.com</a>" == linkify(str_0)
    str_

# Generated at 2022-06-26 07:53:29.969852
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    result = linkify(str_0)
    assert result == 'plain'

    str_0 = 'html'
    result = linkify(str_0)
    assert result == 'html'

    str_0 = 'http://www.yahoo.com'
    result = linkify(str_0)
    assert result == '<a href="http://www.yahoo.com">http://www.yahoo.com</a>'

    str_0 = 'http://www.yahoo.com'
    result = linkify(str_0, extra_params = 'rel="nofollow"')
    assert result == '<a href="http://www.yahoo.com" rel="nofollow">http://www.yahoo.com</a>'

    str_0 = 'http://www.yahoo.com'


# Generated at 2022-06-26 07:53:38.901148
# Unit test for function linkify
def test_linkify():
    assert linkify('http://www.youtube.com/watch?v=ZPFmgM4f4dk',
        shorten=True,
        extra_params='rel="nofollow" class="external"',
        require_protocol=True,
        permitted_protocols=["http", "https"]) == '<a href="http://www.youtube.com/watch?v=ZPFmgM4f4dk" rel="nofollow" class="external">http://www.youtube.com/watch?v=...</a>'
    assert linkify('www.youtube.com/watch?v=ZPFmgM4f4dk',
        shorten=True,
        extra_params='rel="nofollow" class="external"',
        require_protocol=True,
        permitted_protocols=["http", "https"])

# Generated at 2022-06-26 07:53:40.138221
# Unit test for function linkify
def test_linkify():
    #
    # Test case 0
    #
    str_0 = 'plain'
    test_case_0(str_0)


# Generated at 2022-06-26 07:53:45.817237
# Unit test for function linkify
def test_linkify():
    text_0 = 'plain https://www.facebook.com/'
    result_0 = linkify(text_0)
    assert result_0 is not None
    assert result_0 == 'plain <a href="https://www.facebook.com/">https://www.facebook.com/</a>'

    test_case_0()


# Generated at 2022-06-26 07:53:57.268145
# Unit test for function linkify
def test_linkify():
    # test the case when text input is a plain string
    text_0 = 'plain'
    assert linkify(text_0) == 'plain'
    # test the case when text input is an HTML link
    text_1 = '<a href="http://tornadoweb.org">http://tornadoweb.org</a>'
    assert linkify(text_1) == '<a href="http://tornadoweb.org">http://tornadoweb.org</a>'
    # test the case when text input is an HTML link
    text_2 = 'plain <a href="http://tornadoweb.org">http://tornadoweb.org</a>'
    assert linkify(text_2) == 'plain <a href="http://tornadoweb.org">http://tornadoweb.org</a>'
    # test the case

# Generated at 2022-06-26 07:54:00.670387
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    str_0 = linkify(str_0)
    str_1 = 'plain'
    assert str_0 == str_1


# Generated at 2022-06-26 07:54:02.978026
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    #assert linkify(str_0) == 'plain'

if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-26 07:54:09.317056
# Unit test for function linkify
def test_linkify():
    str_0 = "blank"
    assert_equal(linkify(str_0), "blank")
    str_0 = "none"
    assert_equal(linkify(str_0), "none")
    str_0 = "http://test.com"
    assert_equal(linkify(str_0), "<a href=\"http://test.com\">http://test.com</a>")

# Generated at 2022-06-26 07:54:12.803165
# Unit test for function linkify
def test_linkify():
    str_1 = 'link'
    str_2 = 'http://moo.com/'

# Main program code
if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-26 07:54:28.089404
# Unit test for function linkify
def test_linkify():
    text = 'Hello www.tornadoweb.org!'
    assert( linkify(text) == 
        'Hello <a href="http://wwww.tornadoweb.org">www.tornadoweb.org</a>!' )
test_linkify()



# Generated at 2022-06-26 07:54:36.936565
# Unit test for function linkify
def test_linkify():
    errorCode = 0
    print('Running test_linkify...', end = '')
    try:
        test_case_0()
    except Exception as e:
        print("Error during test_linkify: " + str(e))
        errorCode = 1
    if errorCode == 0:
        print("Passed")
    else:
        print("Failed")
    return errorCode

# Generated at 2022-06-26 07:54:48.804881
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    str_1 = 'not a link'
    str_2 = 'link: http://www.example.com/?a=b&c=d&e=f'
    str_3 = 'link: http://www.example.com/a/b/c?a=&b=&c=&d=&e='
    str_4 = 'link: http://www.example.com/?a=b&c=d&amp;e=f'
    str_5 = 'link: http://www.example.com/?a=b&c=d&#38;e=f'
    str_6 = 'link: http://www.example.com/?a=b&c=d&;e=f'

# Generated at 2022-06-26 07:54:52.311882
# Unit test for function linkify
def test_linkify():
    str_0 = 'url: http://www.google.com'
    str_1 = linkify(str_0)
    str_2 = 'url: <a href="http://www.google.com">http://www.google.com</a>'


# Generated at 2022-06-26 07:55:03.028954
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    str_1 = 'www.plain'
    str_2 = 'https://www.plain'
    str_3 = 'https://www.plain.com'
    str_4 = 'https://www.plain.com/'
    str_5 = 'https://www.plain.com/path'
    str_6 = 'https://www.plain.com/path?query=param'
    str_7 = 'https://www.plain.com/path?query=param&param2=value2'
    str_8 = 'https://www.plain.com/path?query=param&param2=value2#fragment'
    assert (linkify(str_0) == 'plain')

# Generated at 2022-06-26 07:55:15.080993
# Unit test for function linkify
def test_linkify():
    print ('test_linkify...')
    str_0 = 'plain'
    str_1 = 'plain http://www.google.com/'
    str_2 = 'plain http://www.google.com/ index.html'
    str_3 = 'plain http://www.google.com/ index.html?query=1&num=2#fragment'
    str_4 = 'plain http://www.google.com/favicon.ico'
    str_5 = 'plain http://www.google.com/favicon.ico?query=1&num=2#fragment'
    str_6 = 'plain index.html?query=1&num=2#fragment'
    str_7 = 'plain index.html'

# Generated at 2022-06-26 07:55:16.874229
# Unit test for function linkify
def test_linkify():
    test_case_0()
    print('PASSED')
test_linkify()


# Generated at 2022-06-26 07:55:29.923146
# Unit test for function linkify
def test_linkify():
    # Function we are testing.
    res = linkify('plain text')
    assert res == u'plain text', 'Expected: plain text, Got: %s' % res

    # Function we are testing.
    res = linkify('text with http://foo.com/ url')
    assert res == u'text with <a href="http://foo.com/">http://foo.com/</a> url', 'Expected: text with <a href="http://foo.com/">http://foo.com/</a> url, Got: %s' % res

    # Function we are testing.
    res = linkify('text with www.foo.com url')

# Generated at 2022-06-26 07:55:42.824412
# Unit test for function linkify
def test_linkify():
    assert_equal(linkify('<i>Hello</i>http://tornadoweb.org!&nbsp;'), '<i>Hello</i><a href="http://tornadoweb.org">http://tornadoweb.org</a>&nbsp;')
    assert_equal(linkify('http://with.port.com:5000', shorten=True), '<a href="http://with.port.com:5000">http://with.port.com:5000</a>')
    assert_equal(linkify('http://with.port.com:5000', shorten=False), '<a href="http://with.port.com:5000">http://with.port.com:5000</a>')

# Generated at 2022-06-26 07:55:50.772048
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    str_1 = 'plain with http://tornadoweb.org'
    str_2 = 'plain with https://www.tornadoweb.org'
    str_3 = 'plain with ftp://ftp.tornadoweb.org'
    str_4 = 'plain with irc://irc.tornadoweb.org'
    str_5 = 'plain with git://github.com/tornadoweb/tornado'
    str_6 = 'plain with www.tornadoweb.org'
    str_7 = 'plain with http://192.168.1.1'
    str_8 = 'plain with http://[2001::1]'
    str_9 = 'plain with http://[2001:db8::1]'

# Generated at 2022-06-26 07:56:18.249465
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    str_1 = 'I get it'
    str_2 = 'How about <a href="http://www.example.com">www.example.com</a>?'
    str_3 = '<a href="/foo">/foo/bar</a>'
    str_4 = '<a href="javascript:alert(1)">javascript</a>'
    str_5 = '<a href="//example.com/">example.com</a>'
    str_6 = '<a href="http://example.com/">example.com</a>'
    str_7 = '<a href="http://www.example.com:80">www.example.com</a>'

# Generated at 2022-06-26 07:56:31.467833
# Unit test for function linkify
def test_linkify():


    str_0 = 'plain'
    str_1 = '<plain>'
    str_2 = '<a href="http://www.facebook.com">www.facebook.com</a>'
    str_3 = '<a href="http://www.facebook.com">www.facebook.com</a>'
    str_4 = '<a href="http://www.facebook.com">www.facebook.com</a>'
    str_5 = '<a href="mailto:foo@example.com">foo@example.com</a>'
    str_6 = '<a href="http://google.com">google.com</a>'
    str_7 = '<a href="http://google.com">google.com</a>'

# Generated at 2022-06-26 07:56:43.755226
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    str_1 = '<a href="http://example.com">http://example.com</a>'
    str_2 = '<a href="https://example.com">https://example.com</a>'
    str_3 = '<a href="mailto:example@example.com">example@example.com</a>'
    str_4 = '<a href="ftp://example.com">ftp://example.com</a>'
    str_5 = '<a href="http://example.com/foo">http://example.com/foo</a>'
    str_6 = '<a href="http://example.com/foo">http://example.com/...</a>'

# Generated at 2022-06-26 07:56:54.233572
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    assert linkify(str_0) == html_escape('plain')
    str_0 = '<plain>'
    assert linkify(str_0) == html_escape('<plain>')
    str_0 = '<plain>'
    assert linkify(str_0) == html_escape('<plain>')
    str_0 = 'plain'
    assert linkify(str_0) == html_escape('plain')
    str_0 = 'plain'
    assert linkify(str_0) == html_escape('plain')
    str_0 = "'\""
    assert linkify(str_0) == html_escape('\'\"')
    str_0 = 'http://example.com/\'"&'

# Generated at 2022-06-26 07:57:09.459060
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    str_1 = 'plain'
    str_2 = 'plain http://link'
    str_3 = 'plain http://link'
    str_4 = 'plain http://link'
    str_5 = 'plain http://link'
    str_6 = 'plain http://link'
    str_7 = u'plain http://link'
    str_8 = u'plain http://link'
    str_9 = u'plain http://link'
    str_10 = str_2
    str_11 = str_2
    str_12 = str_1
    str_13 = str_3
    str_14 = str_3
    str_15 = str_3
    str_16 = str_1
    str_17 = str_13
    str_18 = str_1
   

# Generated at 2022-06-26 07:57:22.367950
# Unit test for function linkify
def test_linkify():
    text = 'Hello http://tornadoweb.org!'

    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text, shorten=True) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text, require_protocol=True) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text, permitted_protocols=["http", "https"]) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

# Generated at 2022-06-26 07:57:25.419426
# Unit test for function linkify
def test_linkify():
    assert linkify(str_0) == "plain", 'linkify(str_0) = plain'
    pass


# Generated at 2022-06-26 07:57:38.266336
# Unit test for function linkify
def test_linkify():
    print(linkify('plain'))
    print(linkify('<p>html', extra_params=None))
    print(linkify('http://example.com/'))
    print(linkify('http://example.com/', shorten=True, extra_params='rel="nofollow"'))
    print(linkify('www.example.com', shorten=True, extra_params='rel="nofollow"'))
    print(linkify('http://example.com/föo', shorten=True, extra_params='rel="nofollow"'))
    print(linkify('http://example.com/föo', shorten=False, extra_params='rel="nofollow"'))
    print(linkify('www.example.com', shorten=True, extra_params=None))

# Generated at 2022-06-26 07:57:44.958476
# Unit test for function linkify
def test_linkify():
    # str_0: str = '...plain...'
    str_1 = linkify('...plain...')
    assert str_1 == '...plain...'


# Generated at 2022-06-26 07:57:56.184000
# Unit test for function linkify
def test_linkify():
    str_0 = 'plain'
    def func(arg_0):
        return arg_0
    # test with default parameters
    linkify_0 = linkify(str_0)
    print(linkify_0)
    # test with extra params, require protocol = false
    linkify_1 = linkify(str_0, False, 'extra')
    print(linkify_1)
    # test with extra params, require protocol = true
    linkify_2 = linkify(str_0, True, 'extra')
    print(linkify_2)
    # test with extra params cb, require protocol = false
    linkify_3 = linkify(str_0, False, func)
    print(linkify_3)
    # test with extra params cb, require protocol = true