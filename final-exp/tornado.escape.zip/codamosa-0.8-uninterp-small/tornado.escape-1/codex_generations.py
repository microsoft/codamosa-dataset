

# Generated at 2022-06-26 07:49:18.652507
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://en.wikipedia.org/wiki/URL'
    str_1 = linkify(str_0)
    assert str_1 == '<a href="http://en.wikipedia.org/wiki/URL">http://en.wikipedia.org/wiki/URL</a>'

    str_0 = 'This is a string containing a URL http://en.wikipedia.org/wiki/URL'
    str_1 = linkify(str_0)
    assert str_1 == 'This is a string containing a URL <a href="http://en.wikipedia.org/wiki/URL">http://en.wikipedia.org/wiki/URL</a>'

    str_0 = 'This is a string containing a URL http://en.wikipedia.org/wiki/URL'
    str_1 = linkify(str_0, shorten=True)


# Generated at 2022-06-26 07:49:23.582949
# Unit test for function linkify
def test_linkify():
    str_1 = 'Hello http://tornadoweb.org!'
    res_1 = linkify(str_1)
    assert_equal(res_1, 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!')



# Generated at 2022-06-26 07:49:26.889719
# Unit test for function linkify
def test_linkify():
    assert linkify('http://www.google.com') == '<a href="http://www.google.com">http://www.google.com</a>'


# Generated at 2022-06-26 07:49:36.651104
# Unit test for function linkify
def test_linkify():
    text = "Take a look at http://www.tornadoweb.org"
    print(linkify(text))
    assert linkify(text) == "Take a look at <a href=\"http://www.tornadoweb.org\">http://www.tornadoweb.org</a>"

    text = "Take a look at www.tornadoweb.org"
    print(linkify(text, require_protocol=False))
    assert linkify(text, require_protocol=False) == "Take a look at <a href=\"http://www.tornadoweb.org\">www.tornadoweb.org</a>"

test_linkify()

# Generated at 2022-06-26 07:49:41.261165
# Unit test for function linkify
def test_linkify():
    str_0 = 'Dansk'
    str_1 = linkify(str_0)
    assert str_1 == str_0

if __name__ == '__main__':
    test_case_0()
    test_linkify()

# Generated at 2022-06-26 07:49:52.023633
# Unit test for function linkify
def test_linkify():
    import pprint
    params_set = set( ('http://www.google.com', True ,'', True, ['http', 'https']),
                      ('http://www.google.com', False,'', True, ['http', 'https']),
                      ('http://www.google.com', True ,'', False, ['http', 'https']),
                      ('www.google.com', False,'', False, ['http', 'https']),
                      ('http://www.google.com', True ,'', True, ['http']),
                      ('http://www.google.com', True ,'', True, ['https']),
                      ('http://www.google.com', True ,'', True, ['ftp']),
                      ('http://www.google.com', True ,'', True, []) )

# Generated at 2022-06-26 07:49:54.153509
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    print( linkify(text) )
# test_linkify


# Generated at 2022-06-26 07:49:57.821930
# Unit test for function linkify
def test_linkify():
    text = "www.baidu.com"
    print(linkify(text))

if __name__ == "__main__":
    test_linkify()

# References
# [1] https://github.com/tornadoweb/tornado/blob/master/tornado/escape.py

# Generated at 2022-06-26 07:49:58.812279
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://test.test.test.test/test/test/test/test/test/test/test?test=test;test=test'

# Generated at 2022-06-26 07:50:01.963223
# Unit test for function linkify
def test_linkify():
    str_0 = 'Hello http://tornadoweb.org!'
    str_1 = linkify(str_0)
    print(str_1)
    # Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!


# Generated at 2022-06-26 07:50:10.573958
# Unit test for function linkify
def test_linkify():
    print(linkify(str_0))



# Generated at 2022-06-26 07:50:23.227794
# Unit test for function linkify
def test_linkify():
    # string_types = (str,) if PY3 else (basestring,)
    link = linkify(
        "foo http://www.facebook.com/l/7AQEFzjSi/1.gif bar"
    )
    assert ">" not in link
    link = linkify(
        "foo http://www.facebook.com/l/7AQEFzjSi/1.gif?foo=bar&baz=bat bar"
    )
    assert ">" not in link
    link = linkify(
        "http://tornadoweb.org/en/stable/", extra_params='rel="nofollow" class="external"'
    )
    assert link.startswith('<a href=')
    assert 'rel="nofollow" class="external"' in link

# Generated at 2022-06-26 07:50:33.408685
# Unit test for function linkify
def test_linkify():
    assert linkify('text@text.com') == '<a href="mailto:%(link)s">%(link)s</a>' % {'link': text@text.com}
    assert linkify('text.com') == '<a href="http://%(link)s">%(link)s</a>' % {'link': text.com}
    assert linkify('http://localhost') == '<a href="http://localhost">localhost</a>'
    assert linkify('http://example.com') == '<a href="http://example.com">example.com</a>'
    assert linkify('') == ''
    assert linkify(' asdasd asdasdads ') == ' asdasd asdasdads '

# Generated at 2022-06-26 07:50:41.785754
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://test.test.test.test/test/test/test/test/test/test/test?test=test;test=test'
    html_0 = '<a href="http://test.test.test.test/test/test/test/test/test/test/test?test=test;test=test">http://test.test.test.test/test/test/test/test/test/test/test?test=test;test=test</a>'
    assert linkify(str_0) == html_0


# Generated at 2022-06-26 07:50:55.104805
# Unit test for function linkify
def test_linkify():
    assert linkify('http://test.test.test.test/test/test/test/test/test/test/test?test=test;test=test') == '<a href="http://test.test.test.test/test/test/test/test/test/test/test?test=test;test=test">http://test.test.test.test/test/test/test/test/test/test/test?test=test;test=test</a>'

# Generated at 2022-06-26 07:51:00.162559
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://test.test.test.test/test/test/test/test/test/test/test?test=test;test=test'
    str_1 = 'string'
    str_2 = 'string'
    str_3 = 'http://test.test.test.test'
    str_4 = 'http://test.test.test.test'
    str_5 = 'string'


# Generated at 2022-06-26 07:51:12.435282
# Unit test for function linkify
def test_linkify():
    assert linkify('http://tornadoweb.org') == u'<a href="http://tornadoweb.org">http://tornadoweb.org</a>'
    assert linkify('http://tornadoweb.org/') == u'<a href="http://tornadoweb.org/">http://tornadoweb.org/</a>'
    assert linkify('Hello http://tornadoweb.org!') == u'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify('Hello http://tornadoweb.org/!') == u'Hello <a href="http://tornadoweb.org/">http://tornadoweb.org/</a>!'

# Generated at 2022-06-26 07:51:17.961627
# Unit test for function linkify
def test_linkify():
    text = 'http://tornadoweb.org'
    assert linkify(text) == '<a href="http://tornadoweb.org">http://tornadoweb.org</a>'

if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-26 07:51:18.647709
# Unit test for function linkify
def test_linkify():
    assert True



# Generated at 2022-06-26 07:51:27.888206
# Unit test for function linkify
def test_linkify():
    # Test case 0
    str_0 = 'http://test.test.test.test/test/test/test/test/test/test/test?test=test;test=test'
    # Expected output of function linkify
    expected_0 = '<a href="http://test.test.test.test/test/test/test/test/test/test/test?test=test;test=test">http://test.test.test.test/test/test/test/test/test/test/test?test=test;test=test</a>'
    actual_0 = linkify(str_0)
    # Compare actual to expected
    assert actual_0 == expected_0, 'Function linkify could not turn http addresses into clickable hyperlinks'
    print('Test case 0 passed')
    #######################################################################
    # Test case

# Generated at 2022-06-26 07:51:45.146449
# Unit test for function linkify
def test_linkify():
    test_case_0()
    #assert( linkify('http://www.google.com')=='<a href="http://www.google.com">http://www.google.com</a>')
    #assert( linkify('aalto.fi')=='aalto.fi')
    #assert linkify('www.aalto.fi')=='<a href="http://www.aalto.fi">www.aalto.fi</a>'
    #assert linkify('https://www.aalto.fi')=='<a href="https://www.aalto.fi">https://www.aalto.fi</a>'
    #assert linkify('mailto:abc@xyz.com')=='mailto:abc@xyz.com'
    #assert linkify('mailto:abc@

# Generated at 2022-06-26 07:51:53.770100
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com?x=1&y=2'
    str_1 = linkify(str_0)
    # print(str_1)
    str_2 = linkify(str_0, short=True)
    # print(str_2)
    str_3 = linkify(str_0, short=False, extra_params=lambda x: "rel=\"nofollow\"")
    # print(str_3)
    print("Test pass")

if __name__ == "__main__":
    test_case_0()
    # test_linkify()

# Generated at 2022-06-26 07:51:55.397222
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    print (linkify(str_0))



# Generated at 2022-06-26 07:51:57.640639
# Unit test for function linkify
def test_linkify():
    test_case_0()

# Unit Tests for function utf8

# Generated at 2022-06-26 07:52:03.996273
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)
    assert str_1 == '<a href="http://www.google.com">http://www.google.com</a>'
    assert type(str_1) is str

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 07:52:07.009219
# Unit test for function linkify

# Generated at 2022-06-26 07:52:19.338252
# Unit test for function linkify
def test_linkify():
    # Case-1
    str_0 = 'http://www.google.com'
    str_1 = '<a href="http://www.google.com">http://www.google.com</a>'
    try:
        assert str_1 == linkify(str_0)
        print("Success")
    except AssertionError:
        print("AssertionError")
    # Case-2
    str_2 = 'https://www.bing.com'
    str_3 = '<a href="https://www.bing.com">https://www.bing.com</a>'
    try:
        assert str_3 == linkify(str_2)
        print("Success")
    except AssertionError:
        print("AssertionError")


if __name__ == "__main__":
    test_

# Generated at 2022-06-26 07:52:22.252195
# Unit test for function linkify
def test_linkify():
    test_case_0()

# Test this module
if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-26 07:52:25.544395
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)
    print(str_1)

if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-26 07:52:38.210748
# Unit test for function linkify
def test_linkify():

    str_1 = linkify('Hello http://tornadoweb.org!')
    str_2 = linkify('Hello http://tornadoweb.org!', shorten=True)
    str_3 = linkify(
        'Hello http://tornadoweb.org!',
        shorten=True,
        extra_params='rel="nofollow" class="external"')
    str_4 = linkify(
        'Hello http://tornadoweb.org!', shorten=True, extra_params=lambda x: 'rel="nofollow" class="external"')
    str_5 = linkify(
        'Hello http://tornadoweb.org!', shorten=False, extra_params=lambda x: 'rel="nofollow" class="external"')

# Generated at 2022-06-26 07:52:48.935036
# Unit test for function linkify
def test_linkify():
    test_case_0()

if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-26 07:52:52.209900
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    str_1 = '<a href="http://www.google.com">http://www.google.com</a>'
    return str_1 == linkify(str_0)


# Generated at 2022-06-26 07:52:53.734430
# Unit test for function linkify
def test_linkify():
    str_example = 'http://www.google.com'
    result = linkify(str_example)
    print(result)


# Generated at 2022-06-26 07:53:06.558428
# Unit test for function linkify
def test_linkify():
    # Test 1
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)
    if not isinstance(str_1, str):
        print(str_1)
    assert (isinstance(str_1, str))


    # Test 2
    str_2 = 'https://www.wikipedia.org'
    str_3 = linkify(str_2)
    if not isinstance(str_3, str):
        print(str_3)
    assert (isinstance(str_3, str))


    # Test 3
    str_4 = 'https://www.cnn.com'
    str_5 = linkify(str_4)
    if not isinstance(str_5, str):
        print(str_5)

# Generated at 2022-06-26 07:53:09.843694
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)
    print(str_1)


# Generated at 2022-06-26 07:53:10.894452
# Unit test for function linkify
def test_linkify():
    test_case_0()


# Generated at 2022-06-26 07:53:14.050209
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)
    assert(str_1 == '<a href="http://www.google.com">http://www.google.com</a>')


# Generated at 2022-06-26 07:53:16.802571
# Unit test for function linkify
def test_linkify():
    str_0 = 'https://www.google.com'
    str_0 = linkify(str_0)


# Generated at 2022-06-26 07:53:18.084243
# Unit test for function linkify
def test_linkify():
    test_case_0()


# Generated at 2022-06-26 07:53:29.765846
# Unit test for function linkify
def test_linkify():
    # Test case no: 0
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)

    # Test case no: 1
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0, extra_params='rel="nofollow" class="external"')

    # Test case no: 2
    def extra_params_cb(url):
        if url.startswith('http://example.com'):
            return 'class="internal"'
        else:
            return 'class="external" rel="nofollow"'
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0, extra_params=extra_params_cb)

    # Test case no: 3

# Generated at 2022-06-26 07:53:49.750013
# Unit test for function linkify
def test_linkify():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-26 07:53:51.818767
# Unit test for function linkify
def test_linkify():
    test_case_0()

if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-26 07:54:02.249493
# Unit test for function linkify
def test_linkify():
    input_0 = 'http://www.google.com'
    input_1 = 'This is a test sting with URL: https://www.google.com'
    output_0 = '<a href="http://www.google.com">http://www.google.com</a>'
    output_1 = 'This is a test sting with URL: <a href="https://www.google.com">https://www.google.com</a>'

    assert(linkify(input_0) == output_0)
    assert(linkify(input_1) == output_1)

if __name__ == '__main__':
    test_linkify()
    test_case_0()

# Generated at 2022-06-26 07:54:08.123154
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)
    str_2 = '<a href="http://www.google.com">http://www.google.com</a>'
    assert str_1 == str_2


# Generated at 2022-06-26 07:54:12.883256
# Unit test for function linkify
def test_linkify():
    
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)

    str_2 = '<a href="http://www.google.com">http://www.google.com</a>'
    assert str_1 == str_2


# Generated at 2022-06-26 07:54:16.554226
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    str_1 = '<a href="http://www.google.com">http://www.google.com</a>'
    str_2 = linkify(str_0)
    if str_1 == str_2:
        print("linkify() works. YES!")
    else:
        prin("linkify() does not work. NO!")


# Generated at 2022-06-26 07:54:17.764171
# Unit test for function linkify
def test_linkify():
    msg_Is = "Is equal"
    test_case_0()


# Generated at 2022-06-26 07:54:25.781082
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)
    assert str_1 == '<a href="http://www.google.com">http://www.google.com</a>'

    str_0 = 'mailto:me@example.com'
    str_1 = linkify(str_0, permitted_protocols=["mailto"])
    assert str_1 == '<a href="mailto:me@example.com">mailto:me@example.com</a>'


# Generated at 2022-06-26 07:54:29.832773
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    assert linkify(str_0) ==  '<a href="http://www.google.com">http://www.google.com</a>'



# Generated at 2022-06-26 07:54:35.369841
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)
    assert str_1 == '<a href="http://www.google.com">http://www.google.com</a>'
    print('Passed test_linkify')



# Generated at 2022-06-26 07:55:16.060204
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)
    print(str_1)

    assert 0, 'test_case_0 failed'

# Generated at 2022-06-26 07:55:29.035589
# Unit test for function linkify
def test_linkify():
    """
    test_linkify
    """
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)
    assert str_1.startswith('<a href="http://www.google.com">')
    assert str_1.endswith('</a>')
    assert str_1.index('http://www.google.com') > 0
    test_case_0()


# Then we have the slightly evil types.ListType and types.StringTypes that
# have been removed in Python3. Let's try to import them and if we can't,
# let's just create our own version.
try:
    from types import ListType, StringTypes
except ImportError:
    ListType, StringTypes = ([],)  # type: ignore



# Generated at 2022-06-26 07:55:34.397673
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    # str_1 = linkify(str_0)
    # print(str_1)
    # assert str_1 == "<a href=\"http://www.google.com\">http://www.google.com</a>"
    test_case_0()


# Generated at 2022-06-26 07:55:37.203868
# Unit test for function linkify
def test_linkify():
    str_0 = 'Hello http://www.google.com'
    str_1 = linkify(str_0)
    print(str_1)


# Generated at 2022-06-26 07:55:46.356431
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)

    print(str_1)

    assert str_1 == '<a href="http://www.google.com">http://www.google.com</a>'

    str_2 = 'https://www.google.com'
    str_3 = linkify(str_2)

    print(str_3)

    assert str_3 == '<a href="https://www.google.com">https://www.google.com</a>'

    str_4 = 'www.google.com'
    str_5 = linkify(str_4)

    print(str_5)

    assert str_5 == '<a href="http://www.google.com">www.google.com</a>'

    str

# Generated at 2022-06-26 07:55:53.943125
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)
    str_2 = '<a href="http://www.google.com">http://www.google.com</a>'
    assert str_1 == str_2
    print('test linkify completed')

# test_linkify()
test_case_0()

# Generated at 2022-06-26 07:55:55.091587
# Unit test for function linkify
def test_linkify():
    test_case_0()

test_linkify()

# Generated at 2022-06-26 07:55:58.021861
# Unit test for function linkify
def test_linkify():
    print('Executing test_linkify')
    try:
        test_case_0()
    except:
        print('test_linkify failed')
        raise


# Generated at 2022-06-26 07:55:59.062691
# Unit test for function linkify
def test_linkify():
    test_case_0()


# Generated at 2022-06-26 07:56:03.901140
# Unit test for function linkify
def test_linkify():
    a_string = 'http://www.google.com'
    assert(linkify(a_string) == '<a href="http://www.google.com">http://www.google.com</a>')


# Generated at 2022-06-26 07:56:54.263673
# Unit test for function linkify
def test_linkify():
    assert linkify('http://google.com') == '<a href="http://google.com">http://google.com</a>'
    assert linkify('http://google.com/') == '<a href="http://google.com/">http://google.com/</a>'
    assert linkify('http://google.com:8000/foobar') == '<a href="http://google.com:8000/foobar">http://google.com:8000/foobar</a>'
    assert linkify('https://google.com:8000/foobar') == '<a href="https://google.com:8000/foobar">https://google.com:8000/foobar</a>'

# Generated at 2022-06-26 07:57:02.561882
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)
    assert str_1  ==  '<a href="http://www.google.com">http://www.google.com</a>'

test_linkify()

# Generated at 2022-06-26 07:57:07.980688
# Unit test for function linkify
def test_linkify():
    print('Begin unit test for function linkify')
    start = time.time()
    test_case_0()
    end = time.time()
    print('End unit test for function linkify')
    print('Total time spent is %f seconds' % (end - start))


if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-26 07:57:13.820411
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)
    expected_str_1 = '<a href="http://www.google.com">http://www.google.com</a>'

    assert str_1 == expected_str_1

    str_2 = 'http://www.google.com/search?q=test'
    str_3 = linkify(str_2)
    expected_str_3 = '<a href="http://www.google.com/search?q=test">' + \
                     'http://www.google.com/search?q=test</a>'

    assert str_3 == expected_str_3

    str_4 = 'http://www.google.com/search?q=test&source=movie'
    str_5 = link

# Generated at 2022-06-26 07:57:19.004654
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://www.google.com'
    str_1 = linkify(str_0)
    assert str_1 == '<a href="http://www.google.com">http://www.google.com</a>'



# Generated at 2022-06-26 07:57:23.051238
# Unit test for function linkify
def test_linkify():
    linkify('http://www.google.com')

# Generated at 2022-06-26 07:57:24.610697
# Unit test for function linkify
def test_linkify():
    test_case_0()



# Generated at 2022-06-26 07:57:36.997611
# Unit test for function linkify
def test_linkify():
    test_case_0()


_EMAIL_RE = re.compile(
    r'''([\w.%+-]+)@([\w.-]+(?:\.[\w.-]+)+)''',
    re.UNICODE | re.IGNORECASE,
)

# Matches a string of 'w's between two '@' characters. This is used in
# _strip_addresses to detect email addresses with no username.



# Generated at 2022-06-26 07:57:40.398798
# Unit test for function linkify
def test_linkify():
    test_case_1()
    print('All test cases passed')



# Generated at 2022-06-26 07:57:48.802774
# Unit test for function linkify
def test_linkify():
    str_0 = '<script>alert("123")</script>'
    str_1 = linkify(str_0)
    assert str_1 == '&lt;script&gt;alert("123")&lt;/script&gt;'
    str_0 = 'www.google.com'
    str_1 = linkify(str_0)
    assert str_1 == 'www.google.com'
