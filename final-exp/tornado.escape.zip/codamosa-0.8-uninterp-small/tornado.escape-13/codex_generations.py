

# Generated at 2022-06-26 07:49:06.706932
# Unit test for function linkify
def test_linkify():
    str_0 = to_unicode(b'\xcd\x94\xdc\x09\xd4\x8c')
    assert len(str_0) > 0
    str_1 = to_unicode(b'\xcd\x94\xdc\x09\xd4\x8c')
    assert len(str_1) > 0
    str_2 = to_unicode(b'\xcd\x94\xdc\x09\xd4\x8c')
    assert len(str_2) > 0
    bytes_0 = b'\xcd\x94\xdc\x09\xd4\x8c'
    str_3 = linkify(bytes_0)
    assert len(str_3) > 0

# Generated at 2022-06-26 07:49:10.189322
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'\xa0'
    str_0 = linkify(bytes_0)
    print(str_0)


if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-26 07:49:11.466619
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'2\xa9*'
    str_0 = linkify(bytes_0)


# Generated at 2022-06-26 07:49:15.375155
# Unit test for function linkify
def test_linkify():
    text_0 = "hello"
    str_0 = linkify(text_0)
    print(str_0)


if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-26 07:49:18.331363
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'2\xa9*'
    assert_equal(linkify(bytes_0), '2\xa9*')

# Generated at 2022-06-26 07:49:29.558012
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'2\xa9*'
    str_0 = linkify(bytes_0)
    bytes_1 = b'http://foo'
    str_1 = linkify(bytes_1)
    bytes_2 = b'\x5e\x122#\\xB1@\x93\xD8:\xF0Q\x9C\x8D\xD0\xFA'
    str_2 = linkify(bytes_2)

# Generated at 2022-06-26 07:49:32.894995
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'e'
    result_0 = linkify(bytes_0)
    assert result_0 == "<a href=\"http://e\"></a>"


# Generated at 2022-06-26 07:49:34.810389
# Unit test for function linkify
def test_linkify():
    assert func_in(linkify, globals())


# Generated at 2022-06-26 07:49:38.110305
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'2\xa9*'
    str_0 = linkify(bytes_0)


if __name__ == "__main__":
    test_case_0()
    test_linkify()

# Generated at 2022-06-26 07:49:43.708412
# Unit test for function linkify
def test_linkify():
    print(linkify(b'\x02\xa9*', shorten=True, extra_params='rel="nofollow" class="external"', require_protocol=False, permitted_protocols=["http", "https"]))

if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-26 07:50:11.802113
# Unit test for function linkify
def test_linkify():
    #///////////////////////////////////
    # linkify - function test 0
    #//////////////////////////////////

    print('\n*** linkify - function test 0 ***\n')

    # test case 0
    test_case_0()



# Generated at 2022-06-26 07:50:24.403360
# Unit test for function linkify
def test_linkify():
    import nose
    import nose.tools
    import sys

    def test_linkify_extra_params():
        # Test that we can pass extra attributes to links
        # Also tests that we can pass a callable that generates extra attributes
        text = "test www.example.com"
        nose.tools.eq_(
            linkify(text, extra_params="rel=nofollow"),
            'test <a href="http://www.example.com" rel=nofollow>www.example.com</a>',
        )

        def extra_params_cb(url):
            return 'rel="nofollow" style="background-color:red"'


# Generated at 2022-06-26 07:50:29.709847
# Unit test for function linkify

# Generated at 2022-06-26 07:50:30.290741
# Unit test for function linkify
def test_linkify():
    assert True


# Generated at 2022-06-26 07:50:35.112647
# Unit test for function linkify
def test_linkify():
    var_1 = linkify("Hello http://tornadoweb.org!")  # This is a test of the linkify function
    var_1 = linkify("Hello http://tornadoweb.org!")  # This is a test of the linkify function
    var_1 = linkify("Hello http://tornadoweb.org!")  # This is a test of the linkify function
    var_1 = linkify("Hello http://tornadoweb.org!")  # This is a test of the linkify function

# Generated at 2022-06-26 07:50:46.841548
# Unit test for function linkify
def test_linkify():
    print("Testing function linkify")
    # case 0
    var_0 = linkify("")
    assert var_0 == u""
    # case 1
    var_1 = linkify("Hello http://tornadoweb.org!")
    assert var_1 == u'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    # case 2
    var_2 = linkify("Hello http://tornadoweb.org! What about http://google.com/?")
    assert var_2 == u'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>! What about <a href="http://google.com/">http://google.com/</a>?'
    # case 3

# Generated at 2022-06-26 07:50:58.765759
# Unit test for function linkify
def test_linkify():
    def test_linkify_0():
        var_0 = linkify("Hello http://tornadoweb.org!")
        print(var_0)

    def test_linkify_1():
        var_0 = linkify("Hello example.com")
        print(var_0)

    def test_linkify_2():
        var_0 = linkify("Hello www.example.com")
        print(var_0)

    def test_linkify_3():
        var_0 = linkify("Hello example.com", require_protocol=True)
        print(var_0)

    def test_linkify_4():
        var_0 = linkify("Hello example.com", require_protocol=False)
        print(var_0)


# Generated at 2022-06-26 07:51:02.775345
# Unit test for function linkify
def test_linkify():
    # TODO fix this test so that it tests the functionality
    assert True == True


# Generated at 2022-06-26 07:51:14.500028
# Unit test for function linkify
def test_linkify():
    assert "ab" == linkify("ab")
    assert "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>" == linkify(
        "Hello http://tornadoweb.org"
    )
    assert "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>" == linkify(
        "Hello http://tornadoweb.org", require_protocol=False
    )
    assert "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!" == linkify(
        "Hello http://tornadoweb.org!"
    )

# Generated at 2022-06-26 07:51:18.247655
# Unit test for function linkify
def test_linkify():
    print("passed")

# Generated at 2022-06-26 07:51:32.804053
# Unit test for function linkify
def test_linkify():
    # Test #0
    try:
        test_case_0()
    except Exception:
        print('FAILED TEST CASE 0')
    else:
        print('PASSED TEST CASE 0')


if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-26 07:51:33.962098
# Unit test for function linkify
def test_linkify():
    test_case_0()


# Generated at 2022-06-26 07:51:47.173107
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'\xd9\x98'
    bytes_1 = b'\xa0'
    bytes_2 = b'\x18\x9a\xafT'
    bytes_3 = b'\x96\x88'
    str_0 = linkify(bytes_0)
    str_1 = linkify(bytes_1, False)
    str_2 = linkify(bytes_2, True)
    str_3 = linkify(bytes_3, True, 'rel="nofollow" class="external"')
    str_4 = linkify(bytes_0, False, 'rel="nofollow" class="external"')
    str_5 = linkify(bytes_0, False, 'rel="nofollow" class="external"', True)

# Generated at 2022-06-26 07:51:48.518036
# Unit test for function linkify
def test_linkify():
    test_case_0()



# Generated at 2022-06-26 07:51:52.284674
# Unit test for function linkify
def test_linkify():
    assert linkify(b"Hello www.tornadoweb.org!") == "Hello <a href=\"http://www.tornadoweb.org\">www.tornadoweb.org</a>!"



# Generated at 2022-06-26 07:51:56.778525
# Unit test for function linkify
def test_linkify():
    func = linkify
    func(b'2\xa9*', False, '', False, [])
    func('', True, '', True, [])
    func('', False, '', False, [])
    func(b'2\xa9*', True, '', True, [])
    func('', True, '', True, [])
    func(b'2\xa9*', True, '', True, [])


# Generated at 2022-06-26 07:51:59.060208
# Unit test for function linkify
def test_linkify():
    assert linkify(b'2\xa9*') == u'2\xa9*'


# Generated at 2022-06-26 07:52:07.385211
# Unit test for function linkify
def test_linkify():
    result = linkify('Hello http://tornadoweb.org!')
    print(result)

if __name__ == '__main__':
    import timeit
    # print(timeit.timeit("test_linkify()", setup="from __main__ import test_linkify", number=10000))
    print(timeit.timeit("test_case_0()", setup="from __main__ import test_case_0", number=10000))

# Generated at 2022-06-26 07:52:12.842845
# Unit test for function linkify

# Generated at 2022-06-26 07:52:20.846348
# Unit test for function linkify
def test_linkify():
    # test a link with http://
    test_str = 'this is a test http://www.love.com.tw/'
    expected_str = 'this is a test <a href="http://www.love.com.tw/">http://www.love.com.tw/</a>'
    assert(linkify(test_str) == expected_str)

    # test a link with https://
    test_str = 'this is a test https://www.love.com.tw/'
    expected_str = 'this is a test <a href="https://www.love.com.tw/">https://www.love.com.tw/</a>'
    assert(linkify(test_str) == expected_str)

    # test a link without http://

# Generated at 2022-06-26 07:52:38.401203
# Unit test for function linkify
def test_linkify():
    str_0 = 'http://example.com'
    str_1 = linkify(str_0)
    str_2 = 'http://example.com '
    str_3 = linkify(str_2)
    str_4 = '<http://example.com>'
    str_5 = linkify(str_4)
    str_6 = 'http://an.example.com/url/with/a?long=query&string=1'
    str_7 = linkify(str_6)
    str_8 = 'http://an.example.com/url/with/a?long=query&string=1 '
    str_9 = linkify(str_8)
    str_10 = '<http://an.example.com/url/with/a?long=query&string=1>'
    str_11

# Generated at 2022-06-26 07:52:40.474287
# Unit test for function linkify
def test_linkify():
    assert callable(linkify)


# Generated at 2022-06-26 07:52:42.465299
# Unit test for function linkify
def test_linkify():
    print("Unit test for function linkify")

    test_case_0()

# Execute the unit test
test_linkify()

# Generated at 2022-06-26 07:52:52.853892
# Unit test for function linkify
def test_linkify():
    print("Testing linkify(self, text, shorten=False, extra_params='', require_protocol=False, permitted_protocols=['http', 'https']) ...")

    bytes_0 = b'2\xa9*'
    str_0 = linkify(bytes_0)
    assert str_0 == '2\xa9*'

    bytes_1 = b'?[^\xad'
    str_1 = linkify(bytes_1)
    assert str_1 == '?[^\xad'

    bytes_2 = b'#'
    str_2 = linkify(bytes_2)
    assert str_2 == '#'

    bytes_3 = b'$\x81\x13\x1b'
    str_3 = linkify(bytes_3)

# Generated at 2022-06-26 07:53:05.503516
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'asdfsadf'
    str_0 = linkify(bytes_0)
    bytes_1 = b'#/&/'
    str_1 = linkify(bytes_1)
    str_2 = linkify(str_1)
    bytes_2 = b'alice@localhost'
    str_3 = linkify(bytes_2)
    bytes_3 = b'alice@localhost'
    str_4 = linkify(bytes_3)
    bytes_4 = b'#/&/'
    str_5 = linkify(bytes_4)
    bytes_5 = b'http://some.site.com/blah_blah'
    str_6 = linkify(bytes_5)

# Generated at 2022-06-26 07:53:16.584302
# Unit test for function linkify
def test_linkify():
    text = "I firmly believe in open source. http://tornadoweb.org"
    expected = 'I firmly believe in open source. <a href="http://tornadoweb.org">http://tornadoweb.org</a>'
    assert linkify(text) == expected

    text = 'For more information, see http://tornadoweb.org, or email ' 'foo@example.com'
    expected = 'For more information, see <a href="http://tornadoweb.org">http://tornadoweb.org</a>, or email <a href="mailto:foo@example.com">foo@example.com</a>'
    assert linkify(text) == expected

    # Test with shortened urls
    text = "This is a link: http://example.com/blahblahblahblah"

# Generated at 2022-06-26 07:53:25.648590
# Unit test for function linkify
def test_linkify():
    # Test assertions
    str_0 = linkify("Hello http://tornadoweb.org!")
    assert str_0 == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    str_1 = linkify("http://www.facebook.com/l.php?u=http%3A%2F%2Fbit.ly%2FhmDY8J&h=yAQG9Jst8AQHmjPV9za1ZjXyTgD-I2TzrELwO_0I2Qv_s7w&s=1")

# Generated at 2022-06-26 07:53:27.140657
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'2\xa9*'
    str_0 = linkify(bytes_0)



# Generated at 2022-06-26 07:53:31.337930
# Unit test for function linkify
def test_linkify():
    text = "http://www.google.com"
    str_0 = linkify(text)
    assert str_0 == "<a href=\"http://www.google.com\">http://www.google.com</a>"


# Generated at 2022-06-26 07:53:34.432707
# Unit test for function linkify
def test_linkify():
    print ("Test for function linkify")
    test_case_0()
    print ("Test for function linkify OK")

# Test for function linkify
test_linkify()

# Generated at 2022-06-26 07:53:43.757493
# Unit test for function linkify
def test_linkify():
    print("linkify function start!")
    test_case_0()
    print("linkify function end!")


# Generated at 2022-06-26 07:53:54.029634
# Unit test for function linkify
def test_linkify():
    text = 'abcd efgh ijkl mnop.'
    text_linkified = linkify(text, shorten=True)
    assert text_linkified == 'abcd efgh ijkl mnop.'

    text = 'Google is http://www.google.com/'
    text_linkified = linkify(text)
    assert text_linkified == 'Google is <a href="http://www.google.com/">http://www.google.com/</a>'

    text = 'Hello http://tornadoweb.org!'
    text_linkified = linkify(text)
    assert text_linkified == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'


# Generated at 2022-06-26 07:53:56.248427
# Unit test for function linkify
def test_linkify():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 07:54:05.673231
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'http://www.python.org'
    str_0 = linkify(bytes_0)
    assert str(type(str_0)) == "<class 'str'>"
    #assert str_0 = '<a href="http://www.python.org">http://www.python.org</a>'
    bytes_1 = b'www.python.org'
    str_1 = linkify(bytes_1)
    assert str(type(str_1)) == "<class 'str'>"
    bytes_2 = b'http://www.python.org/a=1&b=2'
    str_2 = linkify(bytes_2)
    assert str(type(str_2)) == "<class 'str'>"

# Generated at 2022-06-26 07:54:10.872320
# Unit test for function linkify
def test_linkify():
    bytes_7 = b'\xc3\xb3\xc3\xb5\xc3\xb1'
    linkify(bytes_7)
    # \xc3\xb3\xc3\xb5\xc3\xb1 = "ónúñ"



# Generated at 2022-06-26 07:54:25.830334
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'\xfd\xd8\x0e\x80\xd1\x0e\x12\x0e\x16\x0f\x84\xf4\xd4\x80\x00\x00\x13\x10\x10\x16\x18\x1c\x1a\x1c\x19\x1d\x10\x15\x16\x14\x1a\x1d\x15\x15\x15\x1d\x15\x15\x15\x15\x00\x14\x11\x15\x00\x14'
    str_0 = linkify(bytes_0)


# Generated at 2022-06-26 07:54:31.066839
# Unit test for function linkify
def test_linkify():
    # Verify the body of linkify is correct
    bytes_0 = b'2\xa9*'

    # Verify the return type of function linkify
    assert isinstance(linkify(bytes_0), str)


# Generated at 2022-06-26 07:54:35.703376
# Unit test for function linkify
def test_linkify():
    text = b'''This is a text with a link: http://www.google.com. Some more text.'''
    res = linkify(text)
    assert(res == 'This is a text with a link: <a href="http://www.google.com">http://www.google.com</a>. Some more text.')


# Generated at 2022-06-26 07:54:39.842410
# Unit test for function linkify
def test_linkify():
    print('Executing test_linkify...')
    test_case = [(b'2\xa9*', b'2\xa9*')]

    # Test template for function linkify
    for sample in test_case:
        assert linkify(sample[0]) == sample[1]
        # print('{0} == {1}'.format(linkify(sample[0]), sample[1]))
    return


# Generated at 2022-06-26 07:54:50.605748
# Unit test for function linkify
def test_linkify(): 
    assert (linkify(b'2\xb11')) == u'<a href="http://2&#177;1">2\xb11</a>' # noqa: E501
    assert (linkify(b'2\xb11', permitted_protocols=[], extra_params='')) == u'<a href="http://2&#177;1">2\xb11</a>' # noqa: E501
    assert (linkify(b'2\xb11', permitted_protocols=[], require_protocol=False, extra_params='')) == u'<a href="http://2&#177;1">2\xb11</a>' # noqa: E501

# Generated at 2022-06-26 07:55:03.873924
# Unit test for function linkify
def test_linkify():
    # Test to make sure that it can handle basic strings
    string = "This is a simple test"
    assert linkify(string) == string

    # Test to make sure that it can handle basic links
    string = "This is a simple test with a link to google http://google.com"
    assert linkify(string) == "This is a simple test with a link to google <a href=\"http://google.com\">http://google.com</a>"

    # Test to make sure that it can handle links with https
    string = "This is a simple test with a link to google https://google.com"
    assert linkify(string) == "This is a simple test with a link to google <a href=\"https://google.com\">https://google.com</a>"

    # Test to make sure that it can handle links with www

# Generated at 2022-06-26 07:55:10.812738
# Unit test for function linkify
def test_linkify():
    # Test each of the expected inputs
    print('Testing linkify for expected inputs\n')
    hyperlink = linkify('Hello http://tornadoweb.org!')
    print('URL  Hello http://tornadoweb.org!\n')
    print('Link Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!\n')

if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-26 07:55:24.987046
# Unit test for function linkify
def test_linkify():
    assert linkify('') == ''
    assert linkify('hello') == 'hello'
    assert linkify('google.com') == 'google.com'
    assert linkify('google.com.') == 'google.com.'
    assert linkify('http://google.com.') == '<a href="http://google.com">http://google.com</a>.'
    assert linkify('<some html>') == '&lt;some html&gt;'

# Generated at 2022-06-26 07:55:37.257155
# Unit test for function linkify
def test_linkify():
    # Test case where byte string is given and linkify would have thrown
    # an exception in a previous version
    try:
        bytes_0 = type(b'\x8a\xe6\xc1')()
        str_0 = linkify(bytes_0)
    except BaseException as e:
        raise IOError('Failed to linkify byte string!') from e
    try:
        str_1 = linkify(str_0)
    except BaseException as e:
        raise IOError('Failed to linkify string!') from e
    try:
        str_2 = linkify(str_1, extra_params='shape=rect coords="1,2,3,4"')
    except BaseException as e:
        raise IOError('Failed to linkify string with extra parameters!') from e

# Generated at 2022-06-26 07:55:39.308027
# Unit test for function linkify
def test_linkify():
    # Setup
    text = b'Testing http://google.com'
    # Exercise
    # Verify


# Generated at 2022-06-26 07:55:43.820067
# Unit test for function linkify
def test_linkify():
    test_case_0()

if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-26 07:55:49.885870
# Unit test for function linkify
def test_linkify():
    assert 'c7e0a46d08a7a9d9e47a7a72000f5f5e' == hashlib.md5(linkify('2\xa9*').encode('utf-8')).hexdigest()

if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-26 07:56:03.203434
# Unit test for function linkify
def test_linkify():
    # Argument 1
    bytes_0 = b'Incorrect account number'
    # Argument 2 (default value)
    shorten = True
    # Argument 3 (default value)
    extra_params = 'rel="nofollow" class="external"'
    # Argument 4 (default value)
    require_protocol = True
    # Argument 5 (default value)
    permitted_protocols = ['http', 'https']

    str_0 = linkify(bytes_0, shorten, extra_params, require_protocol, permitted_protocols)
    # str_1 = linkify(bytes_0)  # default parameter
    # str_2 = linkify(bytes_0, shorten)  # default parameter
    # str_3 = linkify(bytes_0, shorten, extra_params)  # default parameter
    # str_4 = linkify(

# Generated at 2022-06-26 07:56:05.439135
# Unit test for function linkify
def test_linkify():
    """
    Test linkify
    """
    # Test case 0
    test_case_0()


if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-26 07:56:12.588521
# Unit test for function linkify

# Generated at 2022-06-26 07:56:21.842347
# Unit test for function linkify
def test_linkify():
    test_case_0()


# Generated at 2022-06-26 07:56:23.829043
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'2\xa9*'
    str_0 = linkify(bytes_0)



# Generated at 2022-06-26 07:56:29.718262
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'1234'

    str_0 = linkify(bytes_0)

    # try:
    #     str_0 = linkify(bytes_0, True)
    # except Exception as err:
    #     print(err)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 07:56:33.764443
# Unit test for function linkify
def test_linkify():
    res = linkify(b'2\xa9*')
    assert res == u'<a href="http://2\xa9*">2\xa9*</a>'


# Generated at 2022-06-26 07:56:38.768818
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'2\xa9*'
    str_0 = linkify(bytes_0)
    str_1 = linkify(bytes_0)
    assert str_0 == "<a href=\"http://2*\">2*</a>"
    assert str_1 == "<a href=\"http://2*\">2*</a>"


# Generated at 2022-06-26 07:56:47.130289
# Unit test for function linkify
def test_linkify():
    example_0 = "January 1, 2018"
    example_1 = "January 1, 2018 is not a valid date"
    example_2 = "Today is January 1, 2018. Tomorrow is the 2nd of May, 2018 and the third will be in the year 2020. Let's enjoy the moment."

# Generated at 2022-06-26 07:56:51.517629
# Unit test for function linkify
def test_linkify():
    test_case_0()

# Collect all test cases in this class
testcases_linkify = [
    (test_case_0)
]

# Collect all test classes in this file
testclasses_all = [
    TestLinkify
]



# Generated at 2022-06-26 07:56:54.386243
# Unit test for function linkify
def test_linkify():
    assert callable(linkify)


# Generated at 2022-06-26 07:57:02.196673
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'2\xa9*'
    str_0 = linkify(bytes_0)
    print(str_0)
    # test_case_0()

if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-26 07:57:11.550080
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'w\x1d\x1b,!\x96\xc2\x9d\x86\x06\x1d'
    str_0 = linkify(bytes_0)
    assert str_0 == 'w<a href="http://1d">1d</a>,!<a href="http://96">96</a><a href="http://9d">9d</a><a href="http://86">86</a>06<a href="http://1d">1d</a>'


# Generated at 2022-06-26 07:57:33.972626
# Unit test for function linkify
def test_linkify():
    assert linkify(b'Hello!') == 'Hello!'
    text = b'Hello http://www.facebook.com!'
    assert linkify(text) == 'Hello <a href="http://www.facebook.com">http://www.facebook.com</a>!'
    assert 0


# override the standard json.loads to automatically decode utf8
_orig_json_decode = json.loads
_orig_json_encode = json.dumps



# Generated at 2022-06-26 07:57:36.374979
# Unit test for function linkify
def test_linkify():
    test_case_0()

#
# Unit test
#

# Generated at 2022-06-26 07:57:41.670058
# Unit test for function linkify
def test_linkify():
    # Test cases
    bytes_0 = b'2\xa9*'
    str_0 = linkify(bytes_0)
    # End of test cases
    pass

if __name__ == "__main__":
    test_linkify()

# Generated at 2022-06-26 07:57:45.939508
# Unit test for function linkify

# Generated at 2022-06-26 07:57:49.066629
# Unit test for function linkify
def test_linkify():
    # Setup
    bytes_0 = b'2\xa9*'

    # Invoke method
    str_0 = linkify(bytes_0)

# Generated at 2022-06-26 07:57:58.160419
# Unit test for function linkify
def test_linkify():
    # Test cases
    str_0 = linkify(b'<a href="https://www.us-cert.gov" rel=\"nofollow\"><img src=x onerror=alert(document.domain)></a>')
    str_1 = linkify(b'<a href="https://www.us-cert.gov" rel=\"nofollow\"><img src=x onerror=alert(document.domain)></a>', 
    True, 
    b'rel="nofollow"', 
    True, 
    ['http', 'https'])

# Generated at 2022-06-26 07:58:09.580382
# Unit test for function linkify
def test_linkify():
    # Test function call with a string argument and return a string
    str_0 = linkify('string')
    # Test function call with an array argument and return an array
    array_0 = linkify([str_0])
    # Test function call with an array and two keywords argument
    # and return an array
    array_1 = linkify([str_0], shorten=array_0)
    # Test function call with an array, a dictionary and two keywords
    # argument and return an array
    array_2 = linkify([str_0], extra_params=array_1)
    # Test function call with an array, a dictionary, an object and
    # two keywords argument and return an array
    array_3 = linkify([str_0], extra_params=array_1, require_protocol=array_2)
    # Test function call with an array

# Generated at 2022-06-26 07:58:11.651515
# Unit test for function linkify
def test_linkify():
    print('Testing linkify')
    # test_case_0()

if __name__ == '__main__':
    test_linkify()

# Generated at 2022-06-26 07:58:20.967070
# Unit test for function linkify
def test_linkify():

    # This test was automatically generated and is for detecting whether
    # functions in this file are being called (possibly indirectly) from the
    # global scope. If your tests need to call this function, please consider
    # moving them into the top-level of your test file and use a different
    # function name.
    # If you are unsure about where this test is being run please contact the
    # Tornado maintainers for help.
    # https://groups.google.com/forum/#!forum/python-tornado
    test_case_0()
    test_linkify.__code__.co_varnames


# Generated at 2022-06-26 07:58:24.868783
# Unit test for function linkify
def test_linkify():
    bytes_0 = b'2\xa9*'
    str_0 = linkify(bytes_0)

if __name__ == '__main__':
    test_linkify()