

# Generated at 2022-06-22 03:28:25.649732
# Unit test for function linkify
def test_linkify():
    text = 'Hello http://tornadoweb.org!'
    result = linkify(text)
    assert result == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"

# Generated at 2022-06-22 03:28:28.411944
# Unit test for function squeeze
def test_squeeze():
    assert squeeze(" b  c  d") == "b c d"
    assert squeeze(" a ") == "a"
    assert squeeze("    ") == ""



# Generated at 2022-06-22 03:28:36.108980
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({'a':'b'})=={'a':'b'}
    assert recursive_unicode({'a':b'b'})=={'a':'b'}
    assert recursive_unicode([b'a',b'b'])==['a','b']
    assert recursive_unicode([['a'],['b']])==[['a'],['b']]
    assert recursive_unicode({'a':{'a':'b','b':'c'}})=={'a':{'a':'b','b':'c'}}
    assert recursive_unicode({'a':[{'a':'b'},{'b':'c'}]})=={'a':[{'a':'b'},{'b':'c'}]}
    assert recursive_

# Generated at 2022-06-22 03:28:39.164168
# Unit test for function native_str
def test_native_str():
    assert isinstance(str(""), str)
    assert isinstance(str("value"), str)
    assert str("value") == "value"

# Generated at 2022-06-22 03:28:45.602592
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
	a = b'name=joe&password=password&id=1000&url=http%3A%2F%2Fwww%2Egoogle%2Ecom%2F'
	b = parse_qs_bytes(a)
	assert b == {'id': [b'1000'], 'name': [b'joe'], 'password': [b'password'], 'url': [b'http://www.google.com/']}
test_parse_qs_bytes()


# Generated at 2022-06-22 03:28:57.657219
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print(xhtml_unescape('&lt;p&gt;Hello&amp;&apos;&#39;&#39;&apos;&#x20;World&lt;/p&gt;'))
    print(xhtml_unescape(''))
    print(xhtml_unescape('&#39;'))
    print(xhtml_unescape('&lt;a&gt;'))
test_xhtml_unescape()

# Allow unpickling even if cgi is not available
try:
    import cgi

    _html_unescape = cgi.escape
except ImportError:

    def _html_unescape(s: str) -> str:
        s = s.replace("&lt;", "<")
        s = s.replace("&gt;", ">")
        s = s.replace

# Generated at 2022-06-22 03:29:09.569413
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    # Test 1
    x = "&lt;&gt;&quot;&amp;&#39;"
    out = xhtml_unescape(x)
    print(out)

    # Test 2
    y = "<>\"&'"
    out = xhtml_unescape(y)
    print(out)

    # Test 3
    z = "My dog is <>&"
    out = xhtml_unescape(z)
    print(out)

test_xhtml_unescape()

# html_escape and html_unescape depend on xhtml_escape and
# xhtml_unescape, but we can't just assign to html_escape since
# someone might have already imported and used the name "html_escape"
# from this module.
html_escape = xhtml_escape
html_unescape = xhtml_un

# Generated at 2022-06-22 03:29:15.448572
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'\xe6\x88\x91\xe5\x9c\xa8\xe5\x9c\xb0\xe7\x90\x83') == '我在地球'
    assert url_unescape('\u6211\u5728\u5730\u7403', plus=False) == '我在地球'



# Generated at 2022-06-22 03:29:20.835598
# Unit test for function json_decode
def test_json_decode():
    data = {
        "name": "John",
        "email": "john@hotmail.com"
    }
    # Encoding the JSON data using dumps()
    encoded_json = json.dumps(data)
    result = json_decode(encoded_json)
    assert result == data
test_json_decode()



# Generated at 2022-06-22 03:29:22.222445
# Unit test for function url_unescape
def test_url_unescape():
  print(type(url_unescape("%E6%88%91")))


# Generated at 2022-06-22 03:29:39.419971
# Unit test for function json_encode
def test_json_encode():
    d = {"a":"b"}
    e = '{"a":"b"}'
    assert json_encode(d) == e


_basestring_type = str
_unicode_type = str

if str is bytes:
    # Python 2
    _basestring_type = typing.Union[bytes, str]
    _unicode_type = unicode



# Generated at 2022-06-22 03:29:42.521983
# Unit test for function recursive_unicode
def test_recursive_unicode():
    """
    >>> test_recursive_unicode()
    """
    l = [b'123',{'a':b'b'}]
    assert recursive_unicode(l) == [u'123',{u'a':u'b'}]
    return True



# Generated at 2022-06-22 03:29:48.101968
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<html>") == "&lt;html&gt;"
    assert xhtml_escape('"html"') == "&quot;html&quot;"
    assert xhtml_escape("'html'") == "&#39;html&#39;"
    assert xhtml_escape("&html;") == "&amp;html;"



# Generated at 2022-06-22 03:29:50.253140
# Unit test for function squeeze
def test_squeeze():
    print(squeeze("Test 1 2 3 4"))


# Generated at 2022-06-22 03:30:02.094418
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes("") == {}
    assert parse_qs_bytes("a=") == {"a": [""]}
    assert parse_qs_bytes("a=1&a=2") == {"a": ["1", "2"]}
    assert parse_qs_bytes("a=1&b=") == {"a": ["1"], "b": [""]}
    assert parse_qs_bytes("a=1;b=2", True) == {"a": ["1"], "b": ["2"]}
    assert parse_qs_bytes("a=1;b=2", False) == {"a": ["1"]}
    assert parse_qs_bytes("a=1&b=&c") == {"a": ["1"], "b": [""], "c": [""]}

# Generated at 2022-06-22 03:30:07.655279
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = b'foo=1&foo=2&foo=3&bar=hello%20%2B%20world'
    result = parse_qs_bytes(qs)
    assert result == {
        'foo': [b'1', b'2', b'3'],
        'bar': [b'hello + world'],
    }
test_parse_qs_bytes()



# Generated at 2022-06-22 03:30:18.212406
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("a b") == "a+b"
    assert url_escape("a b", plus=False) == "a%20b"

# URL decoding
# -------------

# Constants from the urllib module. Not needed from Python 3.
_ALWAYS_SAFE = frozenset(b"ABCDEFGHIJKLMNOPQRSTUVWXYZ" b"abcdefghijklmnopqrstuvwxyz" b"0123456789_.-")
_ALWAYS_SAFE_BYTES = bytes(_ALWAYS_SAFE)
_safe_map = None  # type: Optional[List[int]]  # initialized on first request



# Generated at 2022-06-22 03:30:30.088034
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("    ") == ' '
    assert squeeze(" in") == ' in'
    assert squeeze("in  out") == 'in out'


_javascript_escapes = {
    ord("\\"): "\\u005C",
    ord("'"): "\\u0027",
    ord('"'): "\\u0022",
    ord(">"): "\\u003E",
    ord("<"): "\\u003C",
    ord("&"): "\\u0026",
    ord("="): "\\u003D",
    ord("-"): "\\u002D",
    ord(";"): "\\u003B",
    ord("\u2028"): "\\u2028",
    ord("\u2029"): "\\u2029",
}

# Escape every ASCII character with a value

# Generated at 2022-06-22 03:30:38.904074
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode([1, [2, 3]]) == [1, [2, 3]]

    assert recursive_unicode({"a": "b"}) == {"a": "b"}

    assert recursive_unicode({"a": [1, 2, 3]}) == {"a": [1, 2, 3]}

    assert recursive_unicode([1, [{"a": "b", "c": "d"}, 2, 3]]) == [
        1,
        [{"a": "b", "c": "d"}, 2, 3],
    ]



# Generated at 2022-06-22 03:30:43.419663
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    value = '&lt;div&gt;&amp;nbsp;&lt;/div&gt;'
    res = xhtml_unescape(value)
    assert '<div>&nbsp;</div>' == res

# Generated at 2022-06-22 03:31:08.206316
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    s = "&lt;&#001;&#x11;&amp;&#13;&apos;&diams; &ndash;"
    assert xhtml_unescape(s) == "<\x01\x11&\x0d'♦ –"


_JSON_ESCAPE_RE = re.compile(
    r'[\x00-\x1f\\"\b\f\n\r\t\x7f-\uffff]')
_JSON_ESCAPE_ASCII_RE = re.compile(
    r'([\\"]|[^\ -~])')

# Generated at 2022-06-22 03:31:16.044598
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    result = parse_qs_bytes('foo=bar&baz=blah&baz=blarg')
    assert result['foo'] == [b'bar']
    assert result['baz'] == [b'blah',b'blarg']
    # Python 3 only.
    unicode_value = u'\u00e9'  # 'e with an accent'
    encoded = unicode_value.encode('utf8')
    with pytest.raises(UnicodeDecodeError):
        parse_qs_bytes(encoded)



# Generated at 2022-06-22 03:31:24.997085
# Unit test for function linkify
def test_linkify():
    assert(linkify("Hello http://tornadoweb.org!") == 
        'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!')
    assert(linkify("Hello http://tornadoweb.org", shorten=True) == 
        'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>')
    assert(linkify("http://www.facebook.com/?param=http://othersite.com", require_protocol=True) == 
        '<a href="http://www.facebook.com/?param=http://othersite.com">http://www.facebook.com/?param=http://othersite.com</a>')

# Generated at 2022-06-22 03:31:29.825835
# Unit test for function json_encode
def test_json_encode():
    assert json_encode([]) == "[]"
    assert json_encode({}) == "{}"
    #assert json_encode([unsafe_unicode('\u2019')]) == (
    #    '[\n    "%s"\n]' % unsafe_unicode('\\u2019'))
    return True



# Generated at 2022-06-22 03:31:34.794376
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert "&quot;&gt;" == xhtml_escape('">')
    assert "&lt;&#39;" == xhtml_escape("<'")
    assert "&amp;" == xhtml_escape("&")

_JSON_ENCODE_OPTIONS = {
    "ensure_ascii": False,
    "separators": (",", ":"),
}



# Generated at 2022-06-22 03:31:45.813800
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape(b"\x00") == "&amp;"
    assert xhtml_escape(0) == "0"
    assert xhtml_escape(None) == "None"
    assert xhtml_escape("<") == "&lt;"
    assert xhtml_escape("\"") == "&quot;"
    assert xhtml_escape("'") == "&#39;"
    assert xhtml_escape("&") == "&amp;"
    assert xhtml_escape(u"\u2222") == "&#8706;"
    assert xhtml_escape(u"\u00e9") == "&#233;"
    assert xhtml_escape(u"\U0001d120") == "&#119056;"

# Generated at 2022-06-22 03:31:51.958137
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("a+b") == b"a b"
    assert url_unescape("a+b", "utf-8") == "a b"
    assert url_unescape(b"a+b", encoding=None) == b"a+b"
    assert url_unescape("a+b", encoding=None) == b"a+b"
    assert url_unescape(b"a+b", encoding="utf-8") == "a b"
    assert url_unescape("a+b", plus=True) == "a b"
    assert url_unescape("a%2b+b") == "a+ b"
    assert url_unescape("a%2b+b", plus=True) == "a+ b"

# Generated at 2022-06-22 03:31:55.421084
# Unit test for function json_encode
def test_json_encode():

    name = 'aaa'
    base = {'a':'2', 'b':'1'}
    total = {'name':name, 'base':base}
    result1 = json_encode(total)
    print(result1)
# Unit test end


# Generated at 2022-06-22 03:32:02.604816
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&#38;") == "&"
    assert xhtml_unescape("&#x26;") == "&"
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&#60;") == "<"
    assert xhtml_unescape("&#x3c;") == "<"
    assert xhtml_unescape("&gt;") == ">"
    assert xhtml_unescape("&#62;") == ">"
    assert xhtml_unescape("&#x3e;") == ">"
    assert xhtml_unescape('&quot;') == '"'
    assert xhtml_unescape('&#34;') == '"'
    assert xhtml_unescape

# Generated at 2022-06-22 03:32:07.374080
# Unit test for function json_encode
def test_json_encode():
    assert json_encode(123) in ['123', '123.0']
    assert json_encode([1,2,3]) == '[1, 2, 3]'
    assert json_encode({"a":2,"b":3}) == '{"a": 2, "b": 3}'
    assert json_encode("str") in ['"str"', '"str"']
    assert json_encode(True) in ['true', 'true']
    assert json_encode(None) == 'null'
    assert json_encode({"a": True}) == '{"a": true}'
    # json encode object
    class Foo:
        def __init__(self, val=None):
            self.val = val
    assert json_encode(Foo("abc")) == '{"val": "abc"}'
test_

# Generated at 2022-06-22 03:32:14.194087
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape(r"&lt;") == "<"



# Generated at 2022-06-22 03:32:18.798141
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('foo') == 'foo'
    assert url_escape('foo bar') == 'foo%20bar'
    assert url_escape('foo bar', plus=True) == 'foo+bar'



# Generated at 2022-06-22 03:32:30.176402
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"abc") == b"abc"
    assert url_unescape(b"abc+") == b"abc+"
    assert url_unescape(b"abc%20") == b"abc "
    assert url_unescape(b"abc%20", encoding=None) == b"abc%20"
    assert url_unescape(b"abc%2B", plus=False) == b"abc%2B"
    assert url_unescape(b"abc%2B") == b"abc+"
    assert url_unescape(b"abc%2B", encoding=None) == b"abc%2B"
    assert url_unescape(b"abc%2B", plus=True, encoding=None) == b"abc+"

# Generated at 2022-06-22 03:32:31.991714
# Unit test for function url_escape
def test_url_escape():
    url_escape(" ")


# Generated at 2022-06-22 03:32:40.233987
# Unit test for function url_escape
def test_url_escape():
    assert url_escape(b'foo bar') == 'foo+bar'
    assert url_escape(b'foo+bar') == 'foo%2Bbar'
    assert url_escape(b'foo%2Bbar') == 'foo%252Bbar'
    assert url_escape(b'foo+bar', plus=False) == 'foo%2Bbar'
    assert url_escape(b'foo bar', plus=False) == 'foo%20bar'
    assert url_escape(1) == '1'
    assert url_escape(u'foo bar') == 'foo+bar'
   



# Generated at 2022-06-22 03:32:53.933891
# Unit test for function url_unescape
def test_url_unescape():
    print(url_unescape('%C4%B0stanbul')) # İstanbul
    print(url_unescape('%C4%B0stanbul', plus=False)) # %C4%B0stanbul
    # print(url_unescape('%E2%80%9C'))  # UnicodeEncodeError: 'ascii' codec can't encode character '\u201c' in position 0: ordinal not in range(128)
    # print(url_unescape('%E2%80%9C', encoding='utf8'))  # '��'
    print(url_unescape('%E2%80%9C', encoding=None))  # b'\xe2\x80\x9c'

    print(url_unescape('%E2%80%9C', encoding='utf8'))  # Unicode

# Generated at 2022-06-22 03:33:06.255845
# Unit test for function squeeze
def test_squeeze():
    test_str_1 = "abc   def"
    test_str_2 = "\t" + "abc   def"
    test_str_3 = "abc   def" + "\n"
    test_str_4 = "\t" + "abc   def" + "\n"
    assert squeeze(test_str_1) == "abc def"
    assert squeeze(test_str_2) == "\tabc def"
    assert squeeze(test_str_3) == "abc   def"
    assert squeeze(test_str_4) == "\tabc def"

# This function fulfills the role of the Python 2 basestring type,
# which does not exist in Python 3
_BASESTRING_TYPES = (str, bytes)  # type: typing.Tuple[Any, ...]



# Generated at 2022-06-22 03:33:14.094081
# Unit test for function linkify
def test_linkify():
    text1 = "Hello <world> , http://tornadoweb.org and www.google.com are good websites."
    text2 = "Hello <world> , http://tornadoweb.org and www.google.com are good websites. www.facebook.com is not."
    answer1 = "Hello <world> , <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a> and <a href=\"http://www.google.com\">www.google.com</a> are good websites."
    answer2 = "Hello <world> , <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a> and <a href=\"http://www.google.com\">www.google.com</a> are good websites. www.facebook.com is not."

# Generated at 2022-06-22 03:33:25.706949
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape(r"&lt;") == '<'

#
#_URL_ENCODE_RE = re.compile(r"\W")
#_URL_DECODE_RE = re.compile(r"%(?:2[146-9A-E]|3[\dABD]|4[\dA-F]|5[\dAF]|6[1-9A-F]|7[\dAE])")

#def url_escape(value, plus=True):
#    """Escapes a string so it is valid within a URL.

#    If ``safe`` is not specified, this function escapes all characters except
#    alphanumerics.
#    """
#    if plus:
#        value = value.replace(" ", "+")
#    return _URL_ENCODE

# Generated at 2022-06-22 03:33:37.654061
# Unit test for function json_decode
def test_json_decode():
    _str1 = '{"1":1,"2":2,"3":3,"4":4}'
    _bytes = b'{"1":1,"2":2,"3":3,"4":4}'
    _dict1 = {"1":1,"2":2,"3":3,"4":4}
    _dict2 = json_decode(_str1)
    _dict3 = json_decode(_bytes)
    _str2 = json_encode(_dict1)
    print(_str1, type(_str1))
    print(_str2, type(_str2))
    print(_dict1, type(_dict1))
    print(_dict2, type(_dict2))
    print(_dict3, type(_dict3))
    return


_JSON_DECODE_ERROR = object()
_BASESTRING_TYPES

# Generated at 2022-06-22 03:33:46.045647
# Unit test for function linkify
def test_linkify():
    assert linkify(u'Hello http://tornadoweb.org!') == u'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'


# Generated at 2022-06-22 03:33:49.236925
# Unit test for function native_str
def test_native_str():
    string1 = 'hello world'
    answer = native_str(string1)
    print("The natural string is {0}".format(answer))

test_native_str()


# Generated at 2022-06-22 03:34:01.833453
# Unit test for function native_str
def test_native_str():
    b = b"this is a test"
    u = u"this is a test"
    s = "this is a test"
    assert isinstance(native_str(b), bytes)
    assert isinstance(native_str(u), unicode)
    assert isinstance(native_str(s), unicode)
    try:
        # Python 3.x
        assert u == s
        assert native_str(b) == b
        assert native_str(u) == u
        assert native_str(s) == u
    except NameError:
        # Python 2.x
        assert u == s.decode("utf-8")
        assert native_str(b) == b
        assert native_str(u) == s
        assert native_str(s) == s


# Generated at 2022-06-22 03:34:04.285481
# Unit test for function recursive_unicode
def test_recursive_unicode():
    obj = {"a": 1, "b": [1, 2, 3], "c": "string", "d": b"bytes"}
    recursive_unicode(obj)

# Generated at 2022-06-22 03:34:10.257408
# Unit test for function utf8
def test_utf8():
    try:
        utf8('foo')
        assert False
    except TypeError as e:
        print('utf8 raises TypeError correctly')
    assert utf8(b'foo') == b'foo'
    assert utf8(None) is None
    assert utf8('foo') == b'foo'

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:34:20.388411
# Unit test for function linkify
def test_linkify():
    t1 = 'Hello http://tornadoweb.org!'
    r1 = 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(t1) == r1

    t2 = 'Hello http://tornadoweb.org! Please buy me a http://apple.com'
    r2 = 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>! Please buy me a <a href="http://apple.com">http://apple.com</a>'
    assert linkify(t2) == r2

    t3 = 'Hello http://tornadoweb.org'
    r3 = 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>'

# Generated at 2022-06-22 03:34:30.219411
# Unit test for function linkify

# Generated at 2022-06-22 03:34:34.176287
# Unit test for function json_encode
def test_json_encode():
    x = [3, 1, {'a': 'b', 'c': 'd'}, list(range(10))]
    assert json_encode(x) == "[3,1,{\"a\":\"b\",\"c\":\"d\"},[0,1,2,3,4,5,6,7,8,9]]"



# Generated at 2022-06-22 03:34:35.834653
# Unit test for function squeeze
def test_squeeze():
    print("start")
    print(squeeze("hello lol"))


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:34:41.917419
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('http://hi.baidu.com/{asdf}/{asdf}.html', False) == 'http%3A//hi.baidu.com/%7Basdf%7D/%7Basdf%7D.html'


# Unit tests for function url_escape

# Generated at 2022-06-22 03:34:54.848748
# Unit test for function recursive_unicode
def test_recursive_unicode():
    d = {"x": "a", "y": "b", "z": "c"}
    assert recursive_unicode(d) == {"x": "a", "y": "b", "z": "c"}
    assert recursive_unicode({"x": u"a", "y": "b"}) == {"x": u"a", "y": u"b"}
    assert recursive_unicode(["a", "b"]) == [u"a", u"b"]
    assert recursive_unicode(("a", "b")) == (u"a", u"b")
    assert recursive_unicode("foo") == u"foo"
    assert recursive_unicode(b"foo") == u"foo"

# Define our own version of isinstance that always passes bools to correct sides
# of the isinstance call.  Python 2 has

# Generated at 2022-06-22 03:34:58.325246
# Unit test for function squeeze
def test_squeeze():
    assert squeeze(" a b  c   d") == "a b c d"
    assert squeeze("a\nb\r\nc\td") == "a b c d"
    assert squeeze("   a b  c   d\n") == "a b c d"


# Generated at 2022-06-22 03:35:07.463068
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(utf8(""), plus=False) == utf8("")
    assert url_unescape(utf8("+"), plus=False) == utf8("+")
    assert url_unescape(utf8("%2B"), plus=False) == utf8("+")
    assert url_unescape(utf8("%2b"), plus=False) == utf8("+")
    assert url_unescape(utf8("a+b"), plus=False) == utf8("a+b")
    assert url_unescape(utf8("a%20b"), plus=False) == utf8("a b")
    assert url_unescape(utf8("a%2Bb"), plus=False) == utf8("a+b")

# Generated at 2022-06-22 03:35:19.996644
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # Test on binary data
    data = b'q=python&param_name=foo+bar&param_name=baz'
    result = parse_qs_bytes(data, True)
    assert result == {b'q': [b'python'], b'param_name': [b'foo bar', b'baz']}
    # Test on string data
    data = "q=python&param_name=foo+bar&param_name=baz"
    result = parse_qs_bytes(data, True)
    assert result == {b'q': [b'python'], b'param_name': [b'foo bar', b'baz']}
    # Test on string data with unicode characters
    data = "q=python&param_name=foo+bar&param_name=baz"
    result = parse_

# Generated at 2022-06-22 03:35:24.630822
# Unit test for function json_decode
def test_json_decode():
    import json
    v = '[{"name": "瑞游", "age": 20, "content": {"name": "这里是嵌套", "obj": {"name": "再嵌套"}}}]'
    print(v)
    v_dict = json.loads(v)
    print(v_dict)
    # print(v_dict[0]['name'])


# Normalizes strings as potentially unicode objects

# Generated at 2022-06-22 03:35:34.918751
# Unit test for function linkify
def test_linkify():
    txt = "please visit http://google.com"
    assert linkify(txt) == "please visit <a href=\"http://google.com\">http://google.com</a>"
    txt = 'please visit <a href="http://google.com">http://google.com</a>'
    assert linkify(txt) == 'please visit <a href="http://google.com">http://google.com</a>'
    txt = "<p>please visit <a href=\"http://google.com\">http://google.com</a></p>"
    assert linkify(txt) == "<p>please visit <a href=\"http://google.com\">http://google.com</a></p>"
    txt = "<p>please visit <a https://google.com\">https://google.com</a></p>"

# Generated at 2022-06-22 03:35:39.518908
# Unit test for function recursive_unicode
def test_recursive_unicode():
    a = {1:'string',2:'哈哈哈'}
    b = recursive_unicode(a)
    print(b)
# test_recursive_unicode()



# Generated at 2022-06-22 03:35:46.274025
# Unit test for function json_encode
def test_json_encode():
    obj = {
        "key": "value",
        "array": [1, 2, 3],
        "object": {
            "foo": "bar"
        }
    }
    # print(json_encode(obj))
    assert json_encode(obj) == '{"key": "value", "array": [1, 2, 3], "object": {"foo": "bar"}}'


# Determines if the given string is valid JSON

# Generated at 2022-06-22 03:35:51.844615
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("{}") == {}
    assert json_decode("[]") == []
    assert json_decode("\"asdf\"") == "asdf"

_JSON_RECURSE_LIMIT = 100



# Generated at 2022-06-22 03:35:54.195205
# Unit test for function url_escape
def test_url_escape():
    import re
    assert re.match(r"%2F", url_escape("/"))
    # (note: %2F strings may be upper or lower case)
# Test method url_escape
test_url_escape()



# Generated at 2022-06-22 03:36:06.699045
# Unit test for function utf8
def test_utf8():
    assert repr(utf8('foo')) == "b'foo'"
    assert repr(utf8('fóo')) == "b'f\\xc3\\xb3o'"
    assert repr(utf8('f\u20ac')) == "b'f\\xe2\\x82\\xac'"
    assert repr(utf8(None)) is None
    try:
        utf8(1)
    except TypeError:
        pass
    else:
        raise AssertionError("expected exception")



# Generated at 2022-06-22 03:36:12.988012
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    text_1 = '&lt;div dir=&quot;ltr&quot;&gt'
    assert html.unescape(text_1) == '<div dir="ltr">'
    assert html.unescape('&lt;div dir=&quot;ltr&quot;/&gt;') == '<div dir="ltr"/>'



# Generated at 2022-06-22 03:36:24.171714
# Unit test for function linkify
def test_linkify():
    text = "Hello"
    proto_list = ["http://", "https://"]
    for text in ["Hello", "Hello http://tornadoweb.org!"]:
        for proto in proto_list:
            new_text = proto + text
            assert linkify(new_text) == "<a href=\"" + new_text + "\">" + new_text + "</a>"
    text = "Hello"
    proto = "http://"
    new_text = proto + text
    assert linkify(new_text, shorten=True) == "<a href=\"" + new_text + "\">" + text + "</a>"

    text = "Hello"
    proto = "http://"
    new_text = proto + text

# Generated at 2022-06-22 03:36:26.714266
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("foo bar") == "foo+bar"
    assert url_escape("foo bar", plus=False) == "foo%20bar"
    
    

# Generated at 2022-06-22 03:36:37.840334
# Unit test for function url_unescape
def test_url_unescape():
    # Test with plus signs unescaped
    assert url_unescape(b"x%2Bx", plus=True) == b"x+x"
    assert url_unescape(b"x%2Bx", plus=False) == b"x+x"
    if bytes is not str:
        assert url_unescape(b"x+x", plus=True) == b"x x"
        assert url_unescape(b"x+x", plus=False) == b"x+x"
        assert url_unescape(b"x%2Bx", encoding="utf-8", plus=True) == "x+x"
        assert url_unescape(b"x%2Bx", encoding="utf-8", plus=False) == "x+x"

# Generated at 2022-06-22 03:36:46.126674
# Unit test for function utf8
def test_utf8():
    assert utf8("foo") == b'foo'
    assert utf8(b'foo') == b'foo'
    assert utf8("\N{SNOWMAN}") == b'\xe2\x98\x83'
    assert utf8(b'\xe2\x98\x83') == b'\xe2\x98\x83'


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:36:48.702320
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print(xhtml_unescape("&amp;lt;html&amp;gt;"))


# Generated at 2022-06-22 03:36:50.736729
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('&<>"\'') == '&amp;&lt;&gt;&quot;&#39;'


# Generated at 2022-06-22 03:36:57.658804
# Unit test for function url_unescape
def test_url_unescape():
    if url_unescape("", None) != b"":
        raise AssertionError
    if url_unescape("", "utf-8") != u"":
        raise AssertionError
    if url_unescape("a", None) != b"a":
        raise AssertionError
    if url_unescape("a", "utf-8") != u"a":
        raise AssertionError
    if url_unescape("%", None) != b"%":
        raise AssertionError
    if url_unescape("%", "utf-8") != u"%":
        raise AssertionError
    if url_unescape("%2B", None) != b"+":
        raise AssertionError
    if url_unescape("%2B", "utf-8") != u"+":
        raise

# Generated at 2022-06-22 03:37:05.518174
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"foo": "</script>"}) == '{"foo": "<\\\\/script>"}'


_basestring_type = type("")
_string_types = (bytes, _basestring_type)
_non_string_types = (type(None), int, float, bytearray)  # noqa: F821
_number_types = (int, float, complex)



# Generated at 2022-06-22 03:37:17.109992
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print(xhtml_unescape('&amp;&quot;&#39;&#32;&lt;&gt;'))
test_xhtml_unescape()


# Generated at 2022-06-22 03:37:28.297495
# Unit test for function url_escape
def test_url_escape():
    #value= r"http://www.baidu.com/s?wd=%E6%9C%9D%E9%98%B3&rsv_spt=1&rsv_iqid=0x9a2fb0c200023571&issp=1&f=8&rsv_bp=0&rsv_idx=2&ie=utf-8&tn=baiduhome_pg&rsv_enter=1&rsv_sug3=3&rsv_sug1=2&rsv_sug7=100&rsv_sug2=0&inputT=1427&rsv_sug4=1427"
    value= "abc"
    print(url_escape(value))


# Generated at 2022-06-22 03:37:37.539188
# Unit test for function recursive_unicode
def test_recursive_unicode():
    obj = "a string"
    print(type(obj))
    print(type(recursive_unicode(obj)))
    obj = u"a string"
    print(type(obj))
    print(type(recursive_unicode(obj)))
    obj = bytes("a string", "utf8")
    print(type(obj))
    print(type(recursive_unicode(obj)))
    obj = [{1:1, 2:2}, [3, 4, 5], (6, 7, 8)]
    print(type(obj))
    print(type(recursive_unicode(obj)))

# test_recursive_unicode()



# Generated at 2022-06-22 03:37:41.617037
# Unit test for function native_str
def test_native_str():
    from tornado.escape import native_str
    assert(native_str(b'abc') == 'abc')
    assert(native_str('abc') == 'abc')
    assert(native_str(1) == '1')


# Generated at 2022-06-22 03:37:53.388107
# Unit test for function linkify

# Generated at 2022-06-22 03:37:56.678751
# Unit test for function json_decode
def test_json_decode():
    d = {'data': [1, 2, 3], 'success': True}
    assert json_decode(json_encode(d)) == d



# Generated at 2022-06-22 03:37:58.633311
# Unit test for function squeeze
def test_squeeze():
    test = squeeze("   abc def  ")
    assert test == "abc def"


# Generated at 2022-06-22 03:38:04.697282
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = 'a=1&b=2&c=3&d=&e='
    result = parse_qs_bytes(qs)
    print(result)
    print(type(result))
    print(result['d'][0])
    print(type(result['d'][0]))
    print(result['e'][0])
    print(type(result['e'][0]))
    
