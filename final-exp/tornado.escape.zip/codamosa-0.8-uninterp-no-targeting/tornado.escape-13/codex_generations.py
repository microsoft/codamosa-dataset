

# Generated at 2022-06-22 03:28:21.888259
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = "foo=abc&foo=123&bar=xyz"
    result = parse_qs_bytes(qs)
    print(result)
    assert result["foo"] == [b"abc", b"123"]
    assert result["bar"] == [b"xyz"]


# Generated at 2022-06-22 03:28:25.830653
# Unit test for function url_escape
def test_url_escape():
    test_value = "Hello, world!"
    actual_value = url_escape(test_value)
    expected_value = "Hello%2C+world%21"
    assert actual_value == expected_value


# Generated at 2022-06-22 03:28:28.967499
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("1 < 2 && 3 > 2 & 1 == 1") == "1 &lt; 2 &amp;&amp; 3 &gt; 2 &amp; 1 == 1"


# Generated at 2022-06-22 03:28:36.283344
# Unit test for function utf8
def test_utf8():
    assert utf8(None) is None
    assert utf8(b'abc') == b'abc'
    assert utf8('abc') == b'abc'
    assert utf8('\xe9') == b'\xc3\xa9'
    assert_raises(TypeError, utf8, 1)
    assert_raises(TypeError, utf8, object())


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:28:46.982416
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">http://example.com</a>'
    assert linkify("http://example.com extra") == '<a href="http://example.com">http://example.com</a> extra'
    assert linkify("http://example.com/some/long/path/to/a/file") == '<a href="http://example.com/some/long/path/to/a/file">http://example.com/some...</a>'
    assert linkify("https://example.com/some/long/path/to/a/file") == '<a href="https://example.com/some/long/path/to/a/file">https://example.com/some...</a>'
    assert linkify("www.example.com")

# Generated at 2022-06-22 03:28:54.478845
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&quot;&amp;&#39;&lt;&gt;") == '"&\'<>'
    assert xhtml_unescape("&quot;&amp;&#39;&lt;&gt;&#32;&#33;&#64;") == '"&\'<> !@'
    assert xhtml_unescape("&#x61;&#x62;&#x63;") == 'abc'



# Generated at 2022-06-22 03:28:57.936167
# Unit test for function json_decode
def test_json_decode():
    s = '{"int": 1, "dict": {"a": 1, "b": 2}}'
    print(json_decode(s))
    return None
test_json_decode()

# This singleton "decoder" object is used to decode items while
# decoding a JSON object with decode.  See comments in decode.
_CONVERT_UNICODE_TO_TEXT_DECODER = json.JSONDecoder(
    object_hook=_decode_dict, parse_constant=_parse_constant
)


# Generated at 2022-06-22 03:29:09.862350
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(utf8(""), "utf-8") == ""
    assert url_unescape(utf8(""), "utf-8", plus=False) == ""
    assert url_unescape(utf8(""), encoding=None, plus=False) == b""
    assert url_unescape(utf8(" "), "utf-8") == " "
    assert url_unescape(utf8(" "), "utf-8", plus=False) == " "
    assert url_unescape(utf8(" "), encoding=None, plus=False) == b" "
    assert url_unescape(utf8("%2B"), "utf-8") == "+"
    assert url_unescape(utf8("%2B"), "utf-8", plus=False) == "%2B"

# Generated at 2022-06-22 03:29:14.625541
# Unit test for function utf8
def test_utf8():
    assert utf8('hello') == b'hello'
    assert utf8(b'hello') == b'hello'
    assert utf8(None) == None

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:29:21.595674
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({'b': 'bar'}) == {'b': 'bar'}
    assert recursive_unicode([1, 2]) == [1, 2]
    assert recursive_unicode({'a': 'foo', 'b': 'bar'}) == {'a': 'foo', 'b': 'bar'}
    assert recursive_unicode([1, 2]) == [1, 2]
    assert recursive_unicode((1, 2)) == (1, 2)



# Generated at 2022-06-22 03:29:40.419815
# Unit test for function native_str
def test_native_str():
    assert native_str(b'foo', 'latin1') == 'foo'
    assert native_str(u'foo', 'latin1') == 'foo'
    assert native_str(b'\xe2\x98\xa0', 'latin1') == b'\\xe2\\x98\\xa0'.decode('unicode-escape')
    assert native_str(u'\N{SNOWMAN}', 'latin1') == b'\\xe2\\x98\\xa0'.decode('unicode-escape')


# Generated at 2022-06-22 03:29:47.748261
# Unit test for function json_encode
def test_json_encode():
    assert json_encode(1) == '1'
    assert json_encode(10) == '10'
    assert json_encode({"a": [1,2,3]}) == '{"a": [1, 2, 3]}'
    assert json_encode({"a": [1,2,3]}, indent = 4) == '{\n    "a": [\n        1,\n        2,\n        3\n    ]\n}'
    assert json_encode({"a": [1,2,3]}, indent = 2, separators = ('&', '|')) == '{"a"&[1|2|3]}'

# Generated at 2022-06-22 03:30:00.348586
# Unit test for function native_str
def test_native_str():
    assert native_str('x') == b'x'
    assert native_str('x', 'ascii') == b'x'
    assert native_str(b'x') == b'x'
    assert native_str(b'x', 'ascii') == b'x'
    assert native_str(u'x') == b'x'
    assert native_str(u'x', 'ascii') == b'x'
    assert native_str(u'\xe9') == b'\xc3\xa9'
    assert native_str(u'\xe9', 'ascii') == b'\xe9'
    assert native_str(u'\xe9', 'latin1') == b'\xe9'
    assert native_str(u'\ua000', 'ascii') == b

# Generated at 2022-06-22 03:30:04.827551
# Unit test for function json_encode
def test_json_encode():
    x = [{"test": "success"}, {"test": "failed"}, {"test": "success"}]
    assert json_encode(x) == "[{\"test\": \"success\"}, {\"test\": \"failed\"}, {\"test\": \"success\"}]"
    

# Generated at 2022-06-22 03:30:18.127856
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('/%E6%B5%8B%E8%AF%95/%E6%B5%8B%E8%AF%95', encoding='utf-8') == '/测试/测试'
    assert url_unescape('/%E6%B5%8B%E8%AF%95/%E6%B5%8B%E8%AF%95', encoding=None) == b'/\xe6\xb5\x8b\xe8\xaf\x95/\xe6\xb5\x8b\xe8\xaf\x95'

# Generated at 2022-06-22 03:30:28.233364
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    stringtest = b"test=test&test1=test1&test3=test3"
    stringresult = parse_qs_bytes(stringtest)
    assert stringresult == {b'test': [b'test'], b'test1': [b'test1'], b'test3': [b'test3']}
    stringtest = "test=test&test1=test1&test3=test3".encode()
    stringresult = parse_qs_bytes(stringtest)
    assert stringresult == {b'test': [b'test'], b'test1': [b'test1'], b'test3': [b'test3']}



# Generated at 2022-06-22 03:30:32.728669
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape(r"&#38;&#38;") == r"&&"
    assert xhtml_unescape(r"&amp;&amp;") == r"&&"
    assert xhtml_unescape(r"&Aring;") == r"Å"



# Generated at 2022-06-22 03:30:40.335406
# Unit test for function url_unescape
def test_url_unescape():
    try:
        print(url_unescape('%E4%BD%A0%E5%A5%BD'))
        print(url_unescape('%E4%BD%A0%E5%A5%BD', encoding='utf-8')) # need to specify encoding for unicode
        print(url_unescape('%E4%BD%A0%E5%A5%BD', encoding=None)) # byte string
    finally:
        pass


# Generated at 2022-06-22 03:30:49.869016
# Unit test for function utf8
def test_utf8():
    assert utf8(b'foo') == b'foo'
    assert utf8('foo') == b'foo'
    assert utf8(u'foo') == b'foo'

    assert utf8(None) == None
    assert utf8(b'\xf6\xe4\xfc') == b'\xf6\xe4\xfc'
    assert utf8(u'\xf6\xe4\xfc') == b'\xf6\xe4\xfc'

    try:
        utf8(1)
    except TypeError:
        pass
    else:
        assert False, "expected exception"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:30:53.298072
# Unit test for function native_str
def test_native_str():
    pass


_BASESTRING_TYPES = (unicode_type, bytes, type(None))



# Generated at 2022-06-22 03:31:00.358550
# Unit test for function url_unescape
def test_url_unescape():
    x = "url_unescape"
    assert url_unescape(b"a string", encoding="gbk") == "a string"
    assert url_unescape("a string", encoding="gbk") == "a string"



# Generated at 2022-06-22 03:31:08.534695
# Unit test for function recursive_unicode
def test_recursive_unicode():
    a = [b'hai', {b'key': b'value'}]
    b = recursive_unicode(a)
    assert isinstance(b[0], str)
    assert isinstance(b[1]['key'], str)

#
# The _unicode function is otherwise identical to the to_unicode function,
# except for the name.  This allows it to be used as an "alias" for
# to_unicode without triggering a name collision in programs that use
# both tornado.escape and the standard library.

# Generated at 2022-06-22 03:31:16.497179
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<html>") == "&lt;html&gt;"
    assert xhtml_escape("'") == "&#39;"

# When dealing with the standard library across python 2 and 3 it is
# sometimes useful to have a direct conversion to the native string type
if str is unicode_type:  # noqa: F821
    native_str = unicode_type
else:
    native_str = str  # noqa: F821


# Fake out typing.cast
_T = typing.TypeVar('_T')

# Generated at 2022-06-22 03:31:19.696973
# Unit test for function linkify
def test_linkify():
    assert linkify("hello http://google.com") == 'hello <a href="http://google.com">http://google.com</a>'



# Generated at 2022-06-22 03:31:23.835022
# Unit test for function url_escape
def test_url_escape():
    import urllib.parse
    assert url_escape('http://www.baidu.com') == \
        urllib.parse.quote_plus('http://www.baidu.com')
    assert url_escape('http://www.baidu.com', plus=False) == \
        urllib.parse.quote('http://www.baidu.com')


# Generated at 2022-06-22 03:31:34.719148
# Unit test for function url_unescape
def test_url_unescape(): # pragma: no cover
    assert url_unescape(b'abc') == 'abc'
    assert url_unescape(b'abc%20def', encoding=None) == b'abc def'
    assert url_unescape(b'abc%20def', encoding='latin1') == 'abc def'
    assert url_unescape(b'abc%20def', encoding='utf8') == 'abc def'
    assert url_unescape(b'abc+def', encoding='utf8', plus=True) == 'abc def'
    assert url_unescape(b'abc%2Bdef', encoding='utf8') == 'abc+def'
    assert url_unescape(b'abc%2Bdef', encoding='utf8', plus=True) == 'abc+def'

# Generated at 2022-06-22 03:31:38.913589
# Unit test for function json_decode
def test_json_decode():
    c = """{"a":1,"b":"c"}"""
    e = json.loads(c)
    d = json_decode(c)
    assert e == d


# Generated at 2022-06-22 03:31:44.611696
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    expected = 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text) == expected
    params = 'rel="nofollow" class="external"'
    expected = 'Hello <a href="http://tornadoweb.org" %s>http://tornadoweb.org</a>!' % params
    assert linkify(text, extra_params=params) == expected

# Another unit test for the linkify function

# Generated at 2022-06-22 03:31:56.361689
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # type: () -> None
    assert recursive_unicode(u"test") == u"test"
    assert recursive_unicode(u"test".encode("utf-8")) == u"test"
    assert recursive_unicode([u"test"]) == [u"test"]
    assert recursive_unicode(["test".encode("utf-8")]) == [u"test"]
    assert recursive_unicode((u"test", "test".encode("utf-8"))) == (u"test", u"test")
    assert recursive_unicode({u"test": u"test"}) == {u"test": u"test"}
    assert recursive_unicode({"test": "test".encode("utf-8")}) == {u"test": u"test"}



# Generated at 2022-06-22 03:32:09.947438
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&quot;&lt;&gt;&amp;&#39;') == '"<>&\''
    assert xhtml_unescape('&lt;&quot;&gt;') == '<"&gt;'
    assert xhtml_unescape('&lt;&quot;&gt;&amp;&#39;&#128;') == '<"&gt;&\x80'
    assert (
        xhtml_unescape('&#39;&#38;&#34;&#60;&#62;&#x27;')
        == '\'&"<>\x27'
    )

# Generated at 2022-06-22 03:32:21.720947
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org!"
    result = linkify(text)
    expected = "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    assert result == expected

# test_linkify()


# Generated at 2022-06-22 03:32:27.161623
# Unit test for function url_unescape
def test_url_unescape():
   a = "blah"
   b = a.upper()
   c = b.lower()
   d = b.lower()
   e = d.title()
   f = e.swapcase()
   g = f.split()
   h = " ".join(g)
   i = h.rstrip()



# Generated at 2022-06-22 03:32:30.591469
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('"string"') == "string"
    assert json_decode('1') == 1
    assert json_decode('["string", 1]') == ["string", 1]
    assert json_decode('{}') == {}



# Generated at 2022-06-22 03:32:41.467611
# Unit test for function json_decode
def test_json_decode():
    assert json_decode(b'"\\"') == '"'
    assert json_decode('"\\"') == '"'
    assert json_decode(b'"\\u0000"') == "\u0000"
    assert json_decode('"\\u0000"') == "\u0000"
    assert json_decode('null') is None
    assert json_decode('1') == 1
    assert json_decode('"foo"') == "foo"


# to_unicode and to_basestring are copied from six:
# https://pythonhosted.org/six/#six.text_type
#
# Copyright (c) 2010-2018 Benjamin Peterson
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without

# Generated at 2022-06-22 03:32:44.404075
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('A B') == 'A+B'
    assert url_escape('A B', False) == 'A%20B'



# Generated at 2022-06-22 03:32:56.779226
# Unit test for function json_decode

# Generated at 2022-06-22 03:33:01.276175
# Unit test for function json_decode
def test_json_decode():
    json_data = '{ "name":"John", "age":30, "city":"New York"}'
    assert type(json_decode(json_data)) == dict
    assert type(json_decode(json_data)["name"]) == str



# Generated at 2022-06-22 03:33:11.441855
# Unit test for function linkify
def test_linkify():
    print("linkify('http://www.example.com')")
    print(linkify("http://www.example.com"))
    print("linkify('http://www.example.com', shorten=True)")
    print("linkify('http://www.example.com', shorten=True)")
    print("linkify('http://www.example.com', shorten=True, require_protocol=True)")
    print("linkify('www.example.com', shorten=True, require_protocol=True)")
    print("linkify('www.example.com', shorten=True, require_protocol=False)")
    print("linkify('www.example.com', shorten=True, require_protocol=False, permitted_protocols=['http'])")

# Generated at 2022-06-22 03:33:23.265829
# Unit test for function squeeze
def test_squeeze():
     assert squeeze('a b c') == 'a b c'
     assert squeeze('a\tb\nc') == 'a b c'
     assert squeeze('a\t b\nc') == 'a b c'
     assert squeeze('  a  b  c  ') == 'a b c'
     assert squeeze('  \t a \n b c  ') == 'a b c'
     assert squeeze('a\n\tb\nc\t') == 'a b c'
     assert squeeze('a\tb\nc\t') == 'a b c'
     assert squeeze('a\tb\nc') == 'a b c'
     assert squeeze('a\t\nb\nc') == 'a b c'
     assert squeeze(' a  b  c ') == 'a b c'

# Generated at 2022-06-22 03:33:27.971606
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a b c") == "a b c"
    assert squeeze("a    b    c") == "a b c"
    assert squeeze("   a b c") == "a b c"
    assert squeeze("a") == "a"
    assert squeeze("") == ""


_unicode_type = unicode_type



# Generated at 2022-06-22 03:33:43.892633
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    res = parse_qs_bytes(b"foo=1&bar=2")
    assert res == {"foo": [b"1"], "bar": [b"2"]}
    res = parse_qs_bytes(b"foo=1&bar=&foo=2")
    assert res == {"foo": [b"1", b"2"], "bar": [b""]}



# Generated at 2022-06-22 03:33:47.501045
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&#39;") == "'"

_BASESTRING_TYPES = typing.Union[typing.AnyStr, typing.ByteString]
# Used in tests

# Generated at 2022-06-22 03:33:54.066216
# Unit test for function xhtml_escape
def test_xhtml_escape():
    input = "<a href='b'>c</a>"
    expect = "&lt;a href=&#39;b&#39;&gt;c&lt;/a&gt;"
    result = xhtml_escape(input)
    assert result == expect


# to_unicode was previously named _unicode not because it was private,
# but to avoid conflicts with the built-in unicode() function/type

# Generated at 2022-06-22 03:34:06.418413
# Unit test for function linkify
def test_linkify():
    def extra_params_cb(url):
        if url.startswith("http://example.com"):
            return 'class="internal"'
        else:
            return 'class="external" rel="nofollow"'
    text = "Hello http://tornadoweb.org!"
    assert linkify(text) == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    assert linkify(text, shorten=True) == "Hello <a href=\"http://tornadoweb.org\">tornadoweb.org</a>!"
    assert linkify(text, extra_params='rel="nofollow" class="external"') == "Hello <a href=\"http://tornadoweb.org\" rel=\"nofollow\" class=\"external\">http://tornadoweb.org</a>!"
    assert link

# Generated at 2022-06-22 03:34:09.346894
# Unit test for function linkify
def test_linkify():
    assert (
        linkify("Hello http://tornadoweb.org!") == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    )



# Generated at 2022-06-22 03:34:12.307894
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    t1 = _unicode(xhtml_unescape('&lt;html&gt;&lt;&#47;html&gt;'))
    t2 = _unicode('<html></html>')
    assert t1==t2


# Generated at 2022-06-22 03:34:22.500695
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#34;') == '"'
    assert xhtml_unescape('&#39;') == "'"
    assert xhtml_unescape('&quot;') == '"'
    assert xhtml_unescape('&apos;') == "'"
    assert xhtml_unescape('&gt;') == '>'
    assert xhtml_unescape('&lt;') == '<'
    assert xhtml_unescape('&amp;') == '&'
    assert xhtml_unescape('&#x0D;') == '\r'
    assert xhtml_unescape('&#13;') == '\r'
    assert xhtml_unescape('&#x0A;') == '\n'
    assert xhtml_unescape('&#10;') == '\n'


# Generated at 2022-06-22 03:34:27.706710
# Unit test for function utf8
def test_utf8():
    assert utf8(u"abc") == b"abc"
    assert utf8("abc") == b"abc"
    assert utf8(b"abc") == b"abc"
    assert utf8(None) == None



# Generated at 2022-06-22 03:34:32.103563
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('good   morning') == 'good morning'
    assert squeeze('   bad morning   ') == 'bad morning'
    assert squeeze('   ') == ''
    assert squeeze('good morning') == 'good morning'



# Generated at 2022-06-22 03:34:36.908351
# Unit test for function utf8
def test_utf8():
    assert(utf8("hello") == b"hello")
    assert(utf8(u"hello") == b"hello")
    assert(utf8(b"hello") == b"hello")
    assert(utf8(None) is None)
    try:
        utf8(1)
        assert(False)
    except:
        assert(True)


# Generated at 2022-06-22 03:35:07.317594
# Unit test for function native_str
def test_native_str():
    unicode_str = u'\u804a\u5929'
    bytes_str = unicode_str.encode('utf-8')
    assert native_str(unicode_str) == unicode_str
    assert native_str(bytes_str) == bytes_str.decode('utf-8')

# Generated at 2022-06-22 03:35:19.416777
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    from . import _unittest_case
    _unittest_case.unittest_case.assertEqual(xhtml_unescape(''), '')
    _unittest_case.unittest_case.assertEqual(xhtml_unescape('&#8211;'), u'\u2013')
    _unittest_case.unittest_case.assertEqual(xhtml_unescape('&#x2013;'), u'\u2013')
    _unittest_case.unittest_case.assertEqual(xhtml_unescape('&amp;'), u'&')
    _unittest_case.unittest_case.assertEqual(xhtml_unescape('&#x27;'), u'\'')



# Generated at 2022-06-22 03:35:26.335424
# Unit test for function linkify
def test_linkify():
    assert """<a href="http://example.com">http://example.com</a>""" == linkify("http://example.com")
    assert """<a href="http://foo.com/blah_blah">http://foo.com/blah_blah</a>""" == linkify("http://foo.com/blah_blah")
    assert """<a href="http://foo.com/blah_blah/">http://foo.com/blah_blah/</a>""" == linkify("http://foo.com/blah_blah/")
    assert """<a href="http://foo.com/blah_blah_(wikipedia)">http://foo.com/blah_blah_(wikipedia)</a>""" == linkify("http://foo.com/blah_blah_(wikipedia)")

# Generated at 2022-06-22 03:35:36.984350
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<a href="http://example.com?foo=1&bar=2">x</a></script></x></a></foo></bar></baz>') == '&lt;a href=&quot;http://example.com?foo=1&amp;bar=2&quot;&gt;x&lt;/a&gt;&lt;/script&gt;&lt;/x&gt;&lt;/a&gt;&lt;/foo&gt;&lt;/bar&gt;&lt;/baz&gt;'
    assert xhtml_escape('&<>"\'') == '&amp;&lt;&gt;&quot;&#39;'
    assert xhtml_escape(1) == '1'

_XML_ESCAPE_RE = re.comp

# Generated at 2022-06-22 03:35:48.702288
# Unit test for function json_decode
def test_json_decode():
    json_decode(b'{"a": 1}')
    json_decode(b'{"a": 1}')
    json_decode('{"a": 1}')
    json_decode('{"a": 1}')
    json_decode('{"a": 1}')
    json_decode(b'{"a": 1}')
    json_decode(b'{"a": 1}')
    json_decode('{"a": 1}')
    json_decode('{"a": 1}')
    json_decode('{"a": 1}')
    json_decode(b'{"a": 1}')
    json_decode(b'{"a": 1}')
    json_decode('{"a": 1}')
    json_decode('{"a": 1}')
    json_decode

# Generated at 2022-06-22 03:35:51.644002
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"x": "&", "y": ["1", 2, 3]}) == '{"x": "&", "y": ["1", 2, 3]}'



# Generated at 2022-06-22 03:35:53.355295
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('><"&') == '&gt;&lt;&quot;&amp;'


# Generated at 2022-06-22 03:36:01.802542
# Unit test for function utf8
def test_utf8():
    assert utf8('abc') == b'abc'
    assert utf8(u'abc') == b'abc'
    assert utf8(b'abc') == b'abc'
    assert utf8(None) is None
    assert utf8(u'\xc3\xa9') == b'\xc3\xa9'
    try:
        utf8(object())
        assert False
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:36:05.256978
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("\t  hello   world  \n") == "hello world"
if __name__ == "__main__":
    test_squeeze()
    print("Pass")



# Generated at 2022-06-22 03:36:17.048297
# Unit test for function linkify
def test_linkify():
    assert linkify(None) == ''
    assert linkify('') == ''
    assert linkify('Hello') == 'Hello'
    assert linkify('Hello http://tornadoweb.org!') == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify('http://tornadoweb.org', require_protocol=True) == \
        '<a href="http://tornadoweb.org">http://tornadoweb.org</a>'
    assert linkify('Hello http://tornadoweb.org!', extra_params="") == \
        'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

# Generated at 2022-06-22 03:36:55.591165
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a") == "a"
    assert squeeze("   a   ") == "a"
    assert squeeze("a b") == "a b"
    assert squeeze("a   b") == "a b"
    assert squeeze("a   b   ") == "a b"
    assert squeeze("   a   b   ") == "a b"
    assert squeeze("   a   b   c   ") == "a b c"
    # for now, don't do anything about newlines and such.
    assert squeeze("a\nb") == "a\nb"
    assert squeeze("a\n   b") == "a\n   b"
    assert squeeze("a\n   b\n ") == "a\n   b\n "



# Generated at 2022-06-22 03:36:59.864763
# Unit test for function json_decode
def test_json_decode():
    json_decode("{'key': 'value'}")
    assert "key" in json_decode("{'key': 'value'}")
    json_decode(u"{'key': 'value'}")
    assert "key" in json_decode(u"{'key': 'value'}")
# End unit test for function test_json_decode



# Generated at 2022-06-22 03:37:09.828825
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"") == dict()
    assert parse_qs_bytes(b"&") == dict()
    assert parse_qs_bytes(b"&&") == dict()
    assert parse_qs_bytes(b"&&=") == dict()
    assert parse_qs_bytes(b"=&=") == dict()
    assert parse_qs_bytes(b"test") == dict()
    assert parse_qs_bytes(b"test=") == dict(test=[b""])
    assert parse_qs_bytes(b"test=&") == dict(test=[b""])
    assert parse_qs_bytes(b"&test=") == dict(test=[b""])
    assert parse_qs_bytes(b"&test&") == dict(test=[b""])
    assert parse_qs_

# Generated at 2022-06-22 03:37:14.945786
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#60;&#62;') == "<>"
    assert xhtml_unescape('&#60;&#62;') != '<>'
    assert xhtml_unescape('&lt;&gt;') == "<>"
    assert xhtml_unescape('&lt;&gt;') != '<>'


# Generated at 2022-06-22 03:37:17.070643
# Unit test for function json_encode
def test_json_encode():
    test_data = '{"id":1, "name": "tom"}'
    result = json_encode(test_data)
    print(result)



# Generated at 2022-06-22 03:37:22.485719
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'http%3a%2f%2ffoo%2ebar%2ffoo') == b'http://foo.bar/foo'
    assert url_unescape('http://foo.bar/foo', encoding='ascii') == 'http://foo.bar/foo'



# Generated at 2022-06-22 03:37:27.801361
# Unit test for function squeeze
def test_squeeze():
    assert squeeze(' a  b \n\n  c') == 'a b c'
    assert squeeze('   \n') == ''


# Use the name "escape" rather than "url_escape" so that application code
# can import this function directly from this module without triggering
# additional imports (as happens with urllib.parse.quote).

# Generated at 2022-06-22 03:37:34.338744
# Unit test for function json_decode
def test_json_decode():
    try:
        json.loads(1)
        raise AssertionError("Failed to raise TypeError")
    except TypeError:
        pass
    try:
        json.loads(b"1")
        raise AssertionError("Failed to raise TypeError")
    except TypeError:
        pass


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:37:36.728615
# Unit test for function json_encode
def test_json_encode():
    # python3 only
    #assert json_encode({'a': u'\u2028\u2029'}) == '{"a": "\u2028\u2029"}'
    pass



# Generated at 2022-06-22 03:37:48.698068
# Unit test for function json_encode
def test_json_encode():
    value = json.dumps("</")
    print(json_encode(value)) # prints "\"<\\/\"" as expected


# json_decode is expected to return unicode strings for dict keys
if hasattr(json, "JSONDecoder"):

    class TornadoJSONDecoder(json.JSONDecoder):
        def decode(self, s: Any, _w: typing.Any = ...) -> Any:
            result = super().decode(s)  # type: Any
            return self._decode(result)
            
        # This code is taken from the stdlib json lib, with one minor
        # modification: the calls to isinstance are changed to check
        # if the key is a string like instead of just if it is a string.
        # This works around a problem in simplejson and other json libraries
        # that do not take