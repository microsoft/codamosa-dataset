

# Generated at 2022-06-22 03:28:25.736999
# Unit test for function json_encode
def test_json_encode():
    obj = {'foo': '</script>'}
    assert json_encode(obj) == '{"foo": "<\\/script>"}'


# json_decode wraps json.loads to maintain consistency with json_encode.

# Generated at 2022-06-22 03:28:34.687231
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    """Unit test for function parse_qs_bytes."""
    assert parse_qs_bytes(b'username=abc&password=123')=={'username': [b'abc'], 'password': [b'123']}
test_parse_qs_bytes()


#json_decode = json.JSONDecoder().decode
#json_encode = json.JSONEncoder().encode

# Don't use cgi.escape, which uses html.escape and thus leaves "&".
_escape_table = {
    ord(b"&"): b"&amp;",
    ord(b"<"): b"&lt;",
    ord(b">"): b"&gt;",
    ord(b'"'): b"&quot;",
    ord(b"'"): b"&#39;",
}



# Generated at 2022-06-22 03:28:37.660738
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"q=1&q=2")=={b'q': [b'1', b'2']}



# Generated at 2022-06-22 03:28:39.597448
# Unit test for function json_encode
def test_json_encode():
    assert '"<\\/script>"' == json_encode("</script>")



# Generated at 2022-06-22 03:28:45.267806
# Unit test for function native_str
def test_native_str():
    assert native_str("abc") == u"abc"
    assert native_str(1) == 1
    assert native_str(True) == True
    assert native_str(None) == None
    assert native_str({"a": 1}) == {"a": 1}
    assert native_str([1,2,3]) == [1,2,3]


# Generated at 2022-06-22 03:28:50.130533
# Unit test for function native_str
def test_native_str():

    # Make sure native_str works with byte strings
    assert native_str('hello') == b'hello'

    # Make sure it works with unicode strings
    assert native_str(u'hello') == b'hello'



# Generated at 2022-06-22 03:28:58.117851
# Unit test for function utf8
def test_utf8():
    assert utf8(b"") == b""
    assert utf8("") == b""
    assert utf8(None) is None
    assert utf8(b"abc") == b"abc"
    assert utf8(u"abc") == b"abc"
    assert utf8(u"\xe9") == b"\xc3\xa9"

    try:
        utf8(123)
        assert False
    except TypeError:
        pass

_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:29:00.107319
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print('Test xhtml_unescape():')
    print(xhtml_unescape(xhtml_escape('&<>"\'')))



# Generated at 2022-06-22 03:29:05.503243
# Unit test for function linkify
def test_linkify():
    assert linkify("") == ""
    assert linkify("test") == "test"
    assert (
        linkify("http://example.com/")
        == '<a href="http://example.com/">http://example.com/</a>'
    )
    assert (
        linkify("foo bar https://example.com/ baz")
        == 'foo bar <a href="https://example.com/">https://example.com/</a> baz'
    )
    assert (
        linkify("foo bar https://example.com/ baz", shorten=True)
        == 'foo bar <a href="https://example.com/" title="https://example.com/">https://example.com/</a> baz'
    )

# Generated at 2022-06-22 03:29:11.402371
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("/xx/yy") == "/xx/yy"
    assert url_escape("/xx/yy/") == "/xx/yy/"
    assert url_escape("/xx/yy/0") == "/xx/yy/0"
    assert url_escape("/xx/yy/0/") == "/xx/yy/0/"


# Generated at 2022-06-22 03:29:37.306447
# Unit test for function linkify
def test_linkify():
    assert linkify(u"http://www.google.com") == u'<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify(u"http://www.google.com", shorten=True) == u'<a href="http://www.google.com">http://www...</a>'
    assert linkify(u"http://www.google.com", shorten=True, require_protocol=True) == u'<a href="http://www.google.com">http://www...</a>'
    assert linkify(u"www.google.com", require_protocol=True) == u'www.google.com'

# Generated at 2022-06-22 03:29:40.522808
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"a": "</script>"}) == '{"a": "<\\/script>"}'



# Generated at 2022-06-22 03:29:42.721492
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    a = xhtml_unescape(b"&#39;")
    print(a)
#test_xhtml_unescape()



# Generated at 2022-06-22 03:29:55.297173
# Unit test for function recursive_unicode
def test_recursive_unicode():
    class TestClass:
        def __init__(self):
            self.attr = b"bar"
    obj = {
        "foo": [b"bar", "baz"],
        "quux": {"foo": b"bar", "moo": ["cow", b"pig"]},
        "float": 1.24,
        "unicode": u"blah",
        b"bytes": b"blah",
        "test_class": TestClass(),
    }
    unicoded = recursive_unicode(obj)
    assert isinstance(unicoded["foo"][0], unicode_type)
    assert isinstance(unicoded["foo"][1], unicode_type)
    assert isinstance(unicoded["quux"]["foo"], unicode_type)

# Generated at 2022-06-22 03:29:59.693896
# Unit test for function xhtml_escape
def test_xhtml_escape():
    test_str = "&<>\"'"
    assert xhtml_escape(test_str) == "&amp;&lt;&gt;&quot;&#39;"


_BASESTRING_TYPES = (bytes, unicode_type)



# Generated at 2022-06-22 03:30:05.981420
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("123  456   789") == "123 456 789"
    assert squeeze("   123   ") == "123"
    assert squeeze("abc def ghi") == "abc def ghi"
    assert squeeze(" \n \t \r abc") == "abc"
    assert squeeze("abc ") == "abc"
    assert squeeze(" abc") == "abc"
    assert squeeze("") == ""


# Generated at 2022-06-22 03:30:07.570477
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<html>") == "&lt;html&gt;"

# Generated at 2022-06-22 03:30:16.829660
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"abc", encoding=None) == b"abc"
    assert url_unescape(b"a+b", encoding=None) == b"a+b"
    assert url_unescape(b"a%20b", encoding=None) == b"a b"
    assert url_unescape(b"a+b", encoding="ascii") == "a b"
    assert url_unescape(b"a+b", encoding="ascii", plus=False) == "a+b"



# Generated at 2022-06-22 03:30:21.659365
# Unit test for function json_decode
def test_json_decode():
    s: Union[str, bytes] = json_encode({"hi": "hi"})
    print(s)
    assert s == '{"hi": "hi"}'
    dict1 = json_decode(s)
    print(dict1)
    assert dict1 == {"hi": "hi"}

# Tests for function json_encode

# Generated at 2022-06-22 03:30:23.633795
# Unit test for function json_encode
def test_json_encode():
    assert json_encode('"') == '"\\""'
    assert json_encode("'") == '"\'"'



# Generated at 2022-06-22 03:30:35.555356
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    expected = {"b": [b"abc"]}
    assert parse_qs_bytes("b=abc") == expected
    # bytes in, bytes out.
    assert parse_qs_bytes(b"b=abc") == expected
    # Latin1 means bytes values work the same in python2 and python3.
    assert parse_qs_bytes("b=%E9") == {"b": [b"\xe9"]}
#test_parse_qs_bytes()



# Generated at 2022-06-22 03:30:44.127242
# Unit test for function native_str
def test_native_str():
    assert native_str == str if str is bytes else str
    if str is bytes:
        assert native_str(u"hello") == b"hello"
        assert native_str(b"hello") == b"hello"
    else:
        assert native_str(u"hello") == "hello"
        assert native_str(b"hello") == "hello"


_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-22 03:30:47.308849
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('one  two') == 'one two'
    assert squeeze('  one  two  \n  three  ') == 'one two three'
    assert squeeze('one\ttwo  three\nfour') == 'one two three four'



# Generated at 2022-06-22 03:30:54.103398
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = "q=%D1%80%D0%B0%D0%B7%D0%B2%D0%B8%D1%82%D0%B8%D0%B5+%D1%81%D0%BF%D0%B8%D1%81%D0%BA%D0%B0"
    qs = qs.lstrip(b"?")

# Generated at 2022-06-22 03:31:01.299934
# Unit test for function xhtml_escape
def test_xhtml_escape():
    string_type = typing.TypeVar("S")
    def _test_type(typ: typing.Type[string_type]) -> None:
        xhtml_escape("<foo>")
        xhtml_escape("<foo>".encode("utf-8"))
        xhtml_escape("<foo>".encode("ascii"))
        xhtml_escape("<foo>".encode("latin-1"))
        xhtml_escape("<foo>".encode("utf-16"))
        xhtml_escape("<foo>".encode("utf-32"))
        xhtml_escape("<foo>".encode("binary"))
        xhtml_escape("<foo>".encode("utf-8"))
        xhtml_escape("<foo>".encode("ascii"))

# Generated at 2022-06-22 03:31:07.180455
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"1": b"a"}) == {"1": "a"}
    assert recursive_unicode({"1": {"2": b"a"}}) == {"1": {"2": "a"}}
    assert recursive_unicode({"1": {"2": {"3": b"a"}}}) == {"1": {"2": {"3": "a"}}}


# Generated at 2022-06-22 03:31:10.095675
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=1&b=%20") == {
        "a": [b"1"],
        "b": [b"%20"],
    }
test_parse_qs_bytes()

# Generated at 2022-06-22 03:31:12.945349
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert b'&lt;b&gt;&lt;/b&gt;' == xhtml_escape(b'<b></b>')



# Generated at 2022-06-22 03:31:20.780646
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('"test"') == 'test'
    assert json_decode('"\\u0026"') == '\u0026'

_HTML_UNESCAPE = {
    ord("&"): "&amp;",
    ord('"'): "&quot;",
    ord("'"): "&#39;",
    ord("<"): "&lt;",
    ord(">"): "&gt;",
}



# Generated at 2022-06-22 03:31:32.873258
# Unit test for function linkify

# Generated at 2022-06-22 03:31:47.400094
# Unit test for function url_unescape
def test_url_unescape():
    assert isinstance(url_unescape(b'1.1.1.1', encoding=None, plus=True), bytes)  # type: ignore
    assert isinstance(url_unescape('1.1.1.1', encoding=None, plus=True), bytes)
    assert isinstance(url_unescape(b'1.1.1.1', encoding='utf-8', plus=True), str)
    assert isinstance(url_unescape('1.1.1.1', encoding='utf-8', plus=True), str)
    assert url_unescape(b'1.1.1.1', encoding=None, plus=True) == b'1.1.1.1'  # type: ignore

# Generated at 2022-06-22 03:31:57.974172
# Unit test for function linkify
def test_linkify():
    assert linkify('hello') == 'hello'
    assert linkify('hello http://example.com') == 'hello <a href="http://example.com">http://example.com</a>'
    assert linkify('hello <a href="http://example.com">http://example.com</a>') == 'hello <a href="http://example.com">http://example.com</a>'
    assert linkify('hello http://example.com.') == 'hello <a href="http://example.com">http://example.com</a>.'
    assert linkify('hello<br>http://example.com') == 'hello<br><a href="http://example.com">http://example.com</a>'

# Generated at 2022-06-22 03:32:00.495608
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a  b") == "a b"
    assert squeeze("a\tb\rc\nd") == "a b c d"



# Generated at 2022-06-22 03:32:03.799419
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("  this   and  \n that \t too") == "this and that too"



# Generated at 2022-06-22 03:32:11.150333
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("/some value") == "%2Fsome%20value"
    assert url_escape("/some value", True) == "%2Fsome+value"
    assert url_escape("/some value", False) == "%2Fsome%20value"
    # bytes
    assert url_escape(b"/some value") == "%2Fsome%20value"
    assert url_escape(b"/some value", True) == "%2Fsome+value"
    assert url_escape(b"/some value", False) == "%2Fsome%20value"



# Generated at 2022-06-22 03:32:18.481599
# Unit test for function recursive_unicode
def test_recursive_unicode():
    d = {'str': 'str', 'unicode':u'unicode', 'byte str':b'byte str', \
         'list': [1, 2, b'3', 4], 'tuple': (b'one', 2, '3', 4), \
         'dict': {'k1': 1, b'k2': b'2', 'k3': b'3', u'k4': u'4'}}
    d = recursive_unicode(d)
    print(d)

# test_recursive_unicode()

_BASESTRING_TYPES = (unicode_type, bytes)
if str is unicode_type:
    # Python 3
    _BASESTRING_TYPES += (str,)
    from functools import reduce  # type: ignore  # noqa: F

# Generated at 2022-06-22 03:32:28.134935
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({'foo': 'bar'}) == {'foo': 'bar'}
    assert recursive_unicode({b'foo': b'bar'}) == {'foo': 'bar'}
    assert recursive_unicode({'foo': b'bar'}) == {'foo': 'bar'}
    assert recursive_unicode({b'foo': {b'foo1': b'bar'}}) == {'foo': {'foo1': 'bar'}}
    assert recursive_unicode({b'foo': [b'foo1', b'bar']}) == {'foo': ['foo1', 'bar']}



# Generated at 2022-06-22 03:32:36.177203
# Unit test for function native_str
def test_native_str():
    assert native_str(b'hello') == 'hello'
    assert native_str(u'\u1234') == u'\u1234'
    assert native_str(None) == None
    assert native_str(ValueError(u'\u1234')) == u'\u1234'
    try:
        assert native_str(ValueError(u'\u1234'), encoding='ascii')
    except UnicodeEncodeError as e:
        assert isinstance(e.__cause__, ValueError)
        assert u'\u1234' in str(e.__cause__)
    else:
        assert False
    

# Generated at 2022-06-22 03:32:37.791937
# Unit test for function xhtml_escape
def test_xhtml_escape():
	assert xhtml_escape("<html>") == "&lt;html&gt;"


# Generated at 2022-06-22 03:32:39.583095
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    from tornado.escape import xhtml_unescape

    assert xhtml_unescape("&lt;&gt;&quot;&apos;&amp;") == "<>\"'&"


# Generated at 2022-06-22 03:32:48.938522
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"foo": "<bar>"}) == '{"foo": "<bar>"}'



# Generated at 2022-06-22 03:33:00.750331
# Unit test for function native_str
def test_native_str():
    # Convert to unicode
    expected_u = "你好"
    actual_u = "你好"
    assert native_str(actual_u) == expected_u

    # Convert to bytes
    expected_b = b"\xe4\xbd\xa0\xe5\xa5\xbd"
    actual_b = "你好"
    assert native_str(actual_b) == expected_b

    # Return None if it is None
    assert native_str(None) is None

    # Return primitive value as it is if it is not None
    assert native_str(123) == 123

    # Convert from unicode to bytes
    expected_b = b"\xe4\xbd\xa0\xe5\xa5\xbd"
    actual_u = "你好"


# Generated at 2022-06-22 03:33:09.819290
# Unit test for function json_decode
def test_json_decode():
    test_json = '{"a":1}'
    decode_results = json_decode(test_json)
    print(decode_results)
    assert type(decode_results) is dict
    print(decode_results["a"])
    assert decode_results["a"] == 1
    test_json2 = '[1,2,3]'
    decode_results2 = json_decode(test_json2)
    print(decode_results2)
    assert type(decode_results2) is list
    assert decode_results2[0] == 1
    assert decode_results2[1] == 2
    assert decode_results2[2] == 3


# Generated at 2022-06-22 03:33:14.329009
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'foo=bar') == {b"foo": [b"bar"]}
    assert parse_qs_bytes(b'foo=bar&foo=baz') == {b"foo": [b"bar", b"baz"]}


# Generated at 2022-06-22 03:33:24.861980
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({'foo':2}) == {'foo': 2}
    assert recursive_unicode([b'foo']) == ['foo']
    assert recursive_unicode((b'foo', {b'bar': b'bas'})) == ('foo', {'bar': 'bas'})

test_recursive_unicode()

# When dealing with the standard library across python 2 and 3 it is
# sometimes useful to have a direct conversion to bytes
if bytes is str:
    native_bytes = lambda s: s.encode("latin1")
    _to_bytes = native_bytes
else:
    native_bytes = bytes
    _to_bytes = to_basestring



# Generated at 2022-06-22 03:33:27.972485
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&amp;&lt;&gt;&quot;&#39;") == "&<>\"'"
# End Unit test for function xhtml_unescape


# Generated at 2022-06-22 03:33:38.531613
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert(recursive_unicode([1,2,3]) == [1,2,3])
    assert(recursive_unicode([1,'2',3]) == [1, '2', 3])
    assert(recursive_unicode([1,bytes('2', 'utf-8'),3]) == [1, '2', 3])
    assert(recursive_unicode({1:2, 3:4}) == {1:2, 3:4})
    assert(recursive_unicode({1:'2', 3:4}) == {1:'2', 3:4})
    assert(recursive_unicode({1:2, 3:bytes('4', 'utf-8')}) == {1:2, 3:'4'})


# Generated at 2022-06-22 03:33:49.555843
# Unit test for function native_str

# Generated at 2022-06-22 03:33:51.737982
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("123 \n\t 345") == "123 345"


# Generated at 2022-06-22 03:34:02.333352
# Unit test for function squeeze
def test_squeeze():
    params = ["a ", " a ", "a   a"]
    for param in params:
        print(squeeze(param))


_css_escapes = {
    " ": "\\ ",
    "\\": "\\\\",
    "\n": "\\n",
    "\r": "\\r",
    "\t": "\\t",
}
for i in range(0x20):
    _css_escapes.setdefault(chr(i), "\\%x" % i)
for i in range(0x80, 0xa0):
    _css_escapes.setdefault(chr(i), "\\%x" % i)



# Generated at 2022-06-22 03:34:12.185404
# Unit test for function linkify

# Generated at 2022-06-22 03:34:22.415052
# Unit test for function json_encode
def test_json_encode():
    test_data = {
        "dict_data": {
            "key1": "value1",
            "key2": ["value2", "value3", 4],
            "key3": {"key4": "value4"},
        },
        "list_data": [
            {
                "key1": "value1",
                "key2": ["value2", "value3", 4],
                "key3": {"key4": "value4"},
            },
            "value1",
            ["value2", "value3", 4],
            {"key4": "value4"},
        ],
    }
    assert json_encode(test_data) == json.dumps(test_data).replace("</", "<\\/")


# to_unicode is deprecated in tornado>=5.0

# Generated at 2022-06-22 03:34:33.858540
# Unit test for function linkify
def test_linkify():
    assert linkify("Hello http://tornadoweb.org!") == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify("http://example.com/test?foo=bar&baz=1") == '<a href="http://example.com/test?foo=bar&baz=1">http://example.com/test?foo=bar&baz=1</a>'
    assert linkify("https://example.com/test?foo=bar&baz=1") == '<a href="https://example.com/test?foo=bar&baz=1">https://example.com/test?foo=bar&baz=1</a>'

# Generated at 2022-06-22 03:34:36.317847
# Unit test for function json_decode
def test_json_decode():
    test_dict = \
        {
            "animal": "horse",
            "price": {
                "apple": "$15"
            }
        }
    assert json_decode(json_encode(test_dict)) == test_dict



# Generated at 2022-06-22 03:34:43.738143
# Unit test for function json_encode
def test_json_encode():
    data = {
        "foo": "test",
        "bar": [1, 2, 3],
        "baz": {
            "hello": "world"
        }
    }
    encoded = json_encode(data)
    assert encoded == '{"bar": [1, 2, 3], "foo": "test", "baz": {"hello": "world"}}'
test_json_encode()



# Generated at 2022-06-22 03:34:45.321329
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({'foo': 'bar'}) == '{"foo": "bar"}'



# Generated at 2022-06-22 03:34:50.715732
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    result1 = xhtml_unescape('&lt;div&gt;&#39;&#x27;&amp;&gt;')
    assert result1 == '<div>\'\'&>'
    result2 = xhtml_unescape('&amp;foo&amp;&#39;&#1234;&#x0ffff;&amp;bar;')

# Generated at 2022-06-22 03:34:57.338857
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("https://tornado.readthedocs.io/en/stable/") == "https%3A%2F%2Ftornado.readthedocs.io%2Fen%2Fstable%2F"
    assert url_escape("https://tornado.readthedocs.io/en/stable/", plus = False) == "https%3A//tornado.readthedocs.io/en/stable/"



# Generated at 2022-06-22 03:34:59.640212
# Unit test for function native_str
def test_native_str():
    assert _native_str(u"123") == "123"
    assert _native_str("123") == "123"
    assert _native_str(b"123") == b"123"
    assert _native_str(123) == "123"
    assert _native_str(None) is None



# Generated at 2022-06-22 03:35:00.249638
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('  abc   cde   ') == 'abc cde'


# Generated at 2022-06-22 03:35:22.844406
# Unit test for function linkify
def test_linkify():
    assert(
        linkify("http://example.com") ==
        '<a href="http://example.com">http://example.com</a>'
    )
    assert(
        linkify("http://example.com", shorten=True) ==
        '<a href="http://example.com">http://example.com</a>'
    )
    assert(
        linkify("http://example.com?foo=bar", shorten=True) ==
        '<a href="http://example.com?foo=bar">http://example.com/...</a>'
    )
    assert(
        linkify("http://example.com/foo/bar", shorten=True) ==
        '<a href="http://example.com/foo/bar">http://example.com/...</a>'
    )

# Generated at 2022-06-22 03:35:28.453351
# Unit test for function linkify
def test_linkify():
    def extra_params_cb(url):  # type: ignore
        if url.startswith("http://example.com"):
            return 'class="internal"'
        else:
            return 'class="external" rel="nofollow"'
    input = "hello www.example.com"
    assert linkify(input,extra_params=extra_params_cb) == \
           'hello <a href="http://www.example.com" class="external" rel="nofollow">www.example.com</a>'
    input = "hello http://example.com"
    assert linkify(input, extra_params=extra_params_cb) == \
           'hello <a href="http://example.com" class="internal">http://example.com</a>'


# Generated at 2022-06-22 03:35:30.830388
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"test": "<a></a>"}) == '{"test": "<a><\\/a>"}'

# Generated at 2022-06-22 03:35:35.857053
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{"hello": "world"}') == {'hello': 'world'}
    assert json_decode('{"123": "hello"}') == {'123': 'hello'}
    assert json_decode('{"1": "2", "3": "4"}') == {'1': '2', '3': '4'}



# Generated at 2022-06-22 03:35:41.319144
# Unit test for function json_decode
def test_json_decode():
    d = {"a": 1, "b": 2}
    input1 = json.dumps(d)
    print(json.loads(input1))
    print(json_decode(input1))

test_json_decode()



# Generated at 2022-06-22 03:35:43.323940
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"a": "</"}) == '{"a": "<\\/"}'


# Generated at 2022-06-22 03:35:48.048649
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("http://localhost:8000/hello world") == "http%3A%2F%2Flocalhost%3A8000%2Fhello+world"
    assert url_escape("http://localhost:8000/hello world", False) == "http%3A%2F%2Flocalhost%3A8000%2Fhello%20world"


# Generated at 2022-06-22 03:35:51.067683
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    expected = {"foo": [b"bar"]}
    assert expected == parse_qs_bytes("foo=bar")
    assert expected == parse_qs_bytes(b"foo=bar")
    assert expected == parse_qs_bytes(b"foo=bar")
    assert expected == parse_qs_bytes(b"foo=bar")



# Generated at 2022-06-22 03:35:54.144551
# Unit test for function native_str
def test_native_str():
    from unicodedata import normalize
    str_ = "悪夢のような夜明け"
    result = native_str(str_)
    assert result == normalize('NFC', str_)
    for x in result:
        assert(isinstance(x, str))


# Generated at 2022-06-22 03:36:00.148121
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("foo/bar") == "foo%2Fbar"
    assert url_escape("foo/bar", plus=False) == "foo%2Fbar"
    assert url_escape("foo bar") == "foo+bar"
    assert url_escape("foo bar", plus=False) == "foo%20bar"



# Generated at 2022-06-22 03:36:04.692750
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(['hello', 'world']) == ('hello', 'world')


# Generated at 2022-06-22 03:36:08.543948
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    str1 = "&lt;&amp;&gt;&quot;&#39;"
    str2 = "<&>\"'"
    assert(xhtml_unescape(str1) == str2)


# Generated at 2022-06-22 03:36:14.602936
# Unit test for function json_decode
def test_json_decode():
    value = b'{"foo": "bar", "baz": true}'
    value_json = json.loads(value.decode('utf-8'))
    value_json['foo'] = 'baz'
    x = json.loads(b'{"bar": "baz"}')
    print(x)
    assert isinstance(value_json, typing.Dict)
    assert json_decode(value) == value_json


# Generated at 2022-06-22 03:36:26.145564
# Unit test for function url_unescape
def test_url_unescape():
    unescape = url_unescape
    # Test str input with different encodings
    # Test that str input defaults to 'utf-8'
    assert unescape("http%3A%2F%2Fwww.tornadoweb.org%2F") == "http://www.tornadoweb.org/"
    # Test str input with different encodings
    assert unescape("http%3A%2F%2Fwww.tornadoweb.org%2F", 'latin1') == "http://www.tornadoweb.org/"
    # Test str input with different encodings, plus=True
    assert unescape("http%3A%2F%2Fwww.tornadoweb.org%2F", 'latin1', plus=True) == "http://www.tornadoweb.org/"
    # Test str input with different enc

# Generated at 2022-06-22 03:36:37.198597
# Unit test for function native_str
def test_native_str():
    try:  # In Python 2:
        assert native_str(b"foo") == "foo"
        assert native_str(u"foo") == "foo"
        assert native_str(u"foo".encode("utf8")) == "foo"
        assert isinstance(native_str(u"foo"), str)
        assert native_str(b"\xe2\x98\x83".decode("utf8")) == u"\u2603"
    except NameError:  # In Python 3:
        assert native_str(b"foo") == "foo"
        assert native_str(u"foo") == "foo"
        assert native_str(u"foo".encode("utf8")) == "foo"
        assert isinstance(native_str(u"foo"), str)

# Generated at 2022-06-22 03:36:44.342518
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("a<b") == "a&lt;b"
    assert xhtml_escape(b"a<b") == "a&lt;b"
    assert xhtml_escape("a'b") == "a&#39;b"
    assert xhtml_escape("a&b") == "a&amp;b"
    assert xhtml_escape("a\"b") == "a&quot;b"



# Generated at 2022-06-22 03:36:49.564072
# Unit test for function json_encode
def test_json_encode():
    test_value=[]
    test_value.append({'test':'</test>'})
    test_value.append({'test':'<\\/test>'})
    test_result=json_encode(test_value)
    print(test_result)
#test_json_encode()


_JSON_DECODE_OPTIONS = json.JSONDecodeError, ValueError



# Generated at 2022-06-22 03:36:57.108980
# Unit test for function xhtml_escape
def test_xhtml_escape():
    value = """<script src="script.js"></script>"""
    assert xhtml_escape(value) == """&lt;script src=&quot;script.js&quot;&gt;&lt;/script&gt;"""


# Generated at 2022-06-22 03:37:00.089602
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"a": '<script>'}) == '{"a": "<\\/script>"}'



# Generated at 2022-06-22 03:37:09.943929
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.example.com") == '<a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("hello http://www.example.com") == 'hello <a href="http://www.example.com">http://www.example.com</a>'
    assert linkify("Go to: http://www.example.com") == 'Go to: <a href="http://www.example.com">http://www.example.com</a>'

# Generated at 2022-06-22 03:37:18.474000
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"foo": "bar"}) == '{"foo": "bar"}'
    assert json_encode({"foo": "</bar>"}) == '{"foo": "<\\/bar>"}'
    assert json_encode(["<b>", "</b>"]) == '["<b>", "<\\/b>"]'


# When json_decode receives a str type in Python 3,
# we need to convert it to bytes to ensure it is valid utf8.
# coercion to unicode is not sufficient.

# Generated at 2022-06-22 03:37:25.762898
# Unit test for function recursive_unicode
def test_recursive_unicode():
    x = [b'a', b'b', 1, 2, b'c', ('d', b'e'), {'f': b'g', 'h': b'i'}]
    assert recursive_unicode(x) == [
        'a',
        'b',
        1,
        2,
        'c',
        ('d', 'e'),
        {'f': 'g', 'h': 'i'},
    ]



# Generated at 2022-06-22 03:37:31.514873
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape('abc')
    url_unescape('abc',plus=True)
    url_unescape('abc',plus=False)
    url_unescape('abc',encoding='utf-8')
    url_unescape('abc',encoding='utf-8',plus=True)
    url_unescape('abc',encoding='utf-8',plus=False)



# Generated at 2022-06-22 03:37:34.296841
# Unit test for function squeeze
def test_squeeze():
    value = '  hello  there'
    assert squeeze(value) == 'hello there'


# Generated at 2022-06-22 03:37:36.107614
# Unit test for function native_str
def test_native_str():
    for i in range(1000):
        x = str(i)
        y = native_str(str(i))
        assert x == y

# Generated at 2022-06-22 03:37:37.901088
# Unit test for function native_str
def test_native_str():
    assert native_str(u"test") == "test"
    assert native_str(b"test") == "test"



# Generated at 2022-06-22 03:37:50.741058
# Unit test for function linkify
def test_linkify():
    def extra_params_cb(url):
        if url.startswith("http://example.com"):
            return 'class="internal"'
        else:
            return 'class="external" rel="nofollow"'
    assert linkify("Hello http://tornadoweb.org!") == "Hello <a href=\"http://tornadoweb.org\">http://tornadoweb.org</a>!"
    assert linkify("Hello http://tornadoweb.org!", shorten=True) == "Hello <a href=\"http://tornadoweb.org\">http://torna...</a>!"

# Generated at 2022-06-22 03:37:57.613896
# Unit test for function linkify
def test_linkify():
    assert linkify("Hi there http://google.com/ ok") == 'Hi there <a href="http://google.com/">http://google.com/</a> ok'
    assert linkify("Hi http://www.yahoo.com/news/ there") == 'Hi <a href="http://www.yahoo.com/news/">http://www.yahoo.com/news/</a> there'
    assert linkify("Hi http://www.yahoo.com/news/ there") == 'Hi <a href="http://www.yahoo.com/news/">http://www.yahoo.com/news/</a> there'
    assert linkify("Hi http://www.yahoo.com/news/ there") == 'Hi <a href="http://www.yahoo.com/news/">http://www.yahoo.com/news/</a> there'
   