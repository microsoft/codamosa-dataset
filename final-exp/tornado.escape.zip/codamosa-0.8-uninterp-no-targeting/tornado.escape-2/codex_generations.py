

# Generated at 2022-06-22 03:28:23.320720
# Unit test for function utf8
def test_utf8():
    assert utf8(None) is None
    assert utf8("hello") == b"hello"
    assert utf8(u"hello") == b"hello"
    assert utf8(b"hello") == b"hello"
    try:
        utf8(object())
    except Exception as err:
        assert isinstance(err, TypeError)


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:28:24.828486
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("   a   b ") == 'a b'



# Generated at 2022-06-22 03:28:29.493500
# Unit test for function recursive_unicode
def test_recursive_unicode():
  assert(recursive_unicode(['byte', b"string", ["three", 1], {'tuple': ('tuple', 'tuple')}]) ==
  ['byte', "string", ["three", 1], {'tuple': ('tuple', 'tuple')}])
# Test for the function recursive_unicode
test_recursive_unicode()

# Generated at 2022-06-22 03:28:33.735168
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("aa  bb\tcc\ndd\r")=="aa bb cc dd"
    assert squeeze("aa  bb cc")=="aa bb cc"
    assert squeeze("  bb cc  ")=="bb cc"
    assert squeeze("")==""
    assert squeeze(" a")=="a"
    assert squeeze("a ")=="a"



# Generated at 2022-06-22 03:28:38.566621
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<>&"') == '&lt;&gt;&amp;&quot;'
    assert xhtml_escape('<>&\'"') == '&lt;&gt;&amp;&quot;&#39;'




# Generated at 2022-06-22 03:28:47.753355
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    import unittest
    import http.cookies
    class TestParseQsBytes(unittest.TestCase):
        def test_parse_qs_bytes(self):
            d = parse_qs_bytes(b"name=foo&age=42")
            self.assertEqual(d, {b"name": [b"foo"], b"age": [b"42"]})
            # function parse_qs_bytes is a drop-in replacement for the
            # built-in function parse_qs, except that it returns byte strings
            # instead of unicode strings in python2 and str objects in python3.
            # See http.cookies for an example of its use.
            c = http.cookies.SimpleCookie()
            self.assertEqual(c.value_decode, lambda v: v.replace('+', ' '))

# Generated at 2022-06-22 03:28:52.892484
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = 'a=hello&b=how+are+you&b=fine'
    res = parse_qs_bytes(qs)
    assert 'a' in res and res['a'] == [b'hello']
    assert 'b' in res and res['b'] == [b'how are you', b'fine']
    qs = ''
    res = parse_qs_bytes(qs)
    assert res == {}
    qs = 'a'
    res = parse_qs_bytes(qs)
    assert 'a' in res and res['a'] == [b'']
    qs = '='
    res = parse_qs_bytes(qs)
    assert '' in res and res[''] == [b'']
    qs = 'a='
    res = parse_qs_bytes(qs)

# Generated at 2022-06-22 03:28:58.130522
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("%7e") == '~'
    assert url_unescape("%7E") == '~'
    assert url_unescape("%7e", encoding="utf-8") == '~'
    assert url_unescape("text%20moretext", encoding="utf-8") == 'text moretext'
    assert url_unescape("text+moretext", encoding="utf-8") == 'text moretext'
    assert url_unescape("text%20moretext", encoding="utf-8", plus=False) == 'text%20moretext'
    assert url_unescape("text+moretext", encoding="utf-8", plus=False) == 'text+moretext'
    assert url_unescape(b'%7e') == b'~'
    assert url_unescape(b'%7E')

# Generated at 2022-06-22 03:29:10.054395
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("http%3A%2F%2Fwww.example.com%2F%20") == "http://www.example.com/ "
    assert url_unescape("http%3A%2F%2Fwww.example.com%2F%20", encoding="ascii") == "http://www.example.com/ "
    assert url_unescape("http%3A%2F%2Fwww.example.com%2F%20", plus=False) == "http%3A%2F%2Fwww.example.com%2F%20"
    assert url_unescape(b"http%3A%2F%2Fwww.example.com%2F%20") == b"http://www.example.com/ "



# Generated at 2022-06-22 03:29:17.382529
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('https://github.com/tornadoweb/tornado/blob/master/tornado/escape.py') == 'https://github.com/tornadoweb/tornado/blob/master/tornado/escape.py'
    assert url_escape('/path/to/file') == '%2Fpath%2Fto%2Ffile'
    assert url_escape('/path/to/file', plus=False) == '%2Fpath%2Fto%2Ffile'
test_url_escape()



# Generated at 2022-06-22 03:29:37.801937
# Unit test for function url_unescape
def test_url_unescape():
    def _test(val, encoding, plus, expect):
        got = url_unescape(val, encoding, plus)
        assert got == expect, "for %r,%r,%r, got %r != %r" % (
            val,
            encoding,
            plus,
            got,
            expect,
        )

    _test("blah", None, False, b"blah")
    _test("+blah+", None, False, b"+blah+")
    _test("+blah+", None, True, b" blah ")
    _test("+blah+", "ascii", True, "+blah+")
    _test("%F0%90%8C%BC", "utf-8", True, "\U000103bc")



# Generated at 2022-06-22 03:29:45.965218
# Unit test for function recursive_unicode
def test_recursive_unicode():
    unicode_string = 'test'
    byte_string = b'test'
    ex_dict = {unicode_string: byte_string}
    ex_list = [unicode_string, byte_string]
    ex_tuple = (unicode_string, byte_string)

    assert recursive_unicode(ex_dict) == {'test': 'test'}
    assert recursive_unicode(ex_list) == ['test', 'test']
    assert recursive_unicode(ex_tuple) == ('test', 'test')



# Generated at 2022-06-22 03:29:58.701495
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'a=1&b=2') == {b'a': [b'1'], b'b': [b'2']}
    assert parse_qs_bytes(b'a=1&a=2') == {b'a': [b'1', b'2']}
    assert parse_qs_bytes(b'a=1&b=') == {b'a': [b'1'], b'b': [b'']}
    assert parse_qs_bytes(b'a=1&b=&c=3') == {b'a': [b'1'], b'b': [b''], b'c': [b'3']}

# Generated at 2022-06-22 03:30:06.331732
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&gt;&lt;&amp;") == "><&"
    assert xhtml_unescape("&#60;&#x3c;&#X3C;") == "<<<"
    assert xhtml_unescape("&lt;&foo&#62;") == "<&foo>"
    assert xhtml_unescape("&#61&#61;&#x3d;&#x3D;") == "===", "test_xhtml_unescape failed"
test_xhtml_unescape()


# Generated at 2022-06-22 03:30:13.005285
# Unit test for function utf8
def test_utf8():
	assert utf8("asdf") == b"asdf"
	assert utf8(u"asdf") == b"asdf"
	assert utf8(None) == None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:30:16.209644
# Unit test for function json_decode
def test_json_decode():
    test_input = "{'a': 'b', 'c': False}"
    expected = {'a': 'b', 'c': False}
    value = json_decode(test_input)
    assert value == expected



# Generated at 2022-06-22 03:30:18.170508
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"a":"a"}) == json.dumps({"a":"a"}).replace("</", "<\\/")



# Generated at 2022-06-22 03:30:21.614677
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"a": ["b", "c"], "d": b"e"}) == {
        "a": ["b", "c"],
        "d": "e",
    }



# Generated at 2022-06-22 03:30:25.037883
# Unit test for function native_str
def test_native_str():
    assert native_str(b'str') == "str"
    assert native_str('str') == "str"
    assert native_str(None) == None
    assert native_str(10) == "10"
    assert native_str(True) == "True"



# Generated at 2022-06-22 03:30:28.681880
# Unit test for function url_escape
def test_url_escape():
    url = url_escape("http://www.baidu.com?name=张三")
    print(url)



# Generated at 2022-06-22 03:30:43.846792
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert "&>  " == xhtml_unescape("&amp;&gt;  ")
    assert "&>  " == xhtml_unescape("&#38;&gt;  ")
    assert "&>  " == xhtml_unescape("&#x26;&gt;  ")



# Generated at 2022-06-22 03:30:52.147414
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("[1,2,3]") == json.loads("[1,2,3]")
    assert json_decode(b"[1,2,3]") == json.loads(b"[1,2,3]")



# Generated at 2022-06-22 03:30:56.843703
# Unit test for function json_encode
def test_json_encode():
    try:
        assert json_encode('</script>') == '"<\\/script>"'
    except:
        print('error')


# json_encode_pretty is preserved for backward compatibility
json_encode_pretty = lambda v: json.dumps(v, sort_keys=True, indent=4)

# Generated at 2022-06-22 03:31:04.412721
# Unit test for function utf8
def test_utf8():
    assert utf8('a') == b'a'
    assert utf8('a\xc3\xa9') == b'a\xc3\xa9'
    assert utf8(u'a\xc3\xa9') == b'a\xc3\xa9'
    assert utf8(None) is None
#test_utf8()


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:31:10.192400
# Unit test for function native_str
def test_native_str():
    if bytes is str:  # Python 2
        assert isinstance(native_str(u"foo"), str)
        assert isinstance(native_str(u"foo".encode("utf-8")), str)
        assert isinstance(native_str(None), str)
    else:
        assert isinstance(native_str(u"foo"), str)
        assert isinstance(native_str(b"foo"), bytes)
        assert isinstance(native_str(None), type(None))



# Generated at 2022-06-22 03:31:15.858857
# Unit test for function xhtml_escape
def test_xhtml_escape():
    # source: https://docs.python.org/3/library/html.html
    assert xhtml_escape("A 'quote' is <b>bold</b>") == \
        "A &#39;quote&#39; is &lt;b&gt;bold&lt;/b&gt;"



# Generated at 2022-06-22 03:31:24.907028
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"x%3d+y", plus=True) == b"x= y"
    assert url_unescape(b"x%3d+y", plus=False) == b"x=+y"
    assert url_unescape(b"x%3d+y", encoding=None, plus=True) == b"x= y"
    assert url_unescape(b"x%3d+y", encoding=None, plus=False) == b"x=+y"
    assert url_unescape(b"x%3d+y", encoding="utf-8", plus=True) == "x= y"
    assert url_unescape(b"x%3d+y", encoding="utf-8", plus=False) == "x=+y"



# Generated at 2022-06-22 03:31:35.123784
# Unit test for function native_str
def test_native_str():
    assert native_str("test") == "test"
    assert native_str("test".encode("utf-8")) == "test"
    assert native_str("test".encode("utf-16")) == u"test"
    if PY3:
        assert native_str("test".encode("latin-1")) == b"test"
    else:
        assert native_str("test".encode("latin-1")) == "test"
    if PY3:
        assert isinstance(native_str("test".encode("latin-1")), bytes)
    else:
        assert isinstance(native_str("test".encode("latin-1")), str)
    assert native_str(u"test") == u"test"


# Generated at 2022-06-22 03:31:43.241318
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('abc &amp; def') == "abc & def"
    assert xhtml_unescape('&lt;&gt;&quot;&amp;') == "<>\"&"
    assert xhtml_unescape('&#32;&#x20;') == "  "
    assert xhtml_unescape('&#x7f;') == unichr(0x7f)
    assert xhtml_unescape('&#160;') == unichr(0xa0)
    assert xhtml_unescape('&#x0a;') == "\n"
    assert xhtml_unescape('&#13;') == "\r"
    assert xhtml_unescape('&#009;') == "\t"
    assert xhtml_unescape('&#x1f4a9;') == unich

# Generated at 2022-06-22 03:31:46.987589
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{"key": "value"}') == {"key": "value"}
    assert json_decode(b'{"key": "value"}') == {"key": "value"}
    assert json_decode(b'{"key": "value"}') == json_decode('{"key": "value"}')



# Generated at 2022-06-22 03:31:59.000170
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('https://www.google.com/&') == 'https://www.google.com/%26'
    assert url_escape('https://www.google.com/&', plus=False) == 'https://www.google.com/%26'
    assert url_escape('https://www.google.com/ ') == 'https://www.google.com/+'
    assert url_escape('https://www.google.com/ ', plus=False) == 'https://www.google.com/%20'


# Generated at 2022-06-22 03:32:00.850228
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    want = {"foo":"bar"}
    assert want == parse_qs_bytes(b"foo=bar")



# Generated at 2022-06-22 03:32:08.762118
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("http://www.example.com:80/?q=foo&s=bar") == \
        "http%3A//www.example.com%3A80/?q=foo&s=bar"
    assert url_escape("http://www.example.com:80/?q=foo&s=bar", plus=True) == \
        "http%3A//www.example.com%3A80/?q=foo%26s%3Dbar"



# Generated at 2022-06-22 03:32:11.838797
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("foo bar") == "foo+bar"
    assert url_escape("foo bar", plus=False) == "foo%20bar"
    assert url_escape(u"\u00a2") == "%C2%A2"



# Generated at 2022-06-22 03:32:16.254427
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"foo": "bar"}) == '{"foo": "bar"}'


# The fact that json_decode wraps json.loads is an implementation detail.
# Please see https://github.com/tornadoweb/tornado/pull/706
# before sending a pull request that adds **kwargs to this function.

# Generated at 2022-06-22 03:32:28.920437
# Unit test for function linkify
def test_linkify():
    text = 'www.tornadoweb.org'
    assert linkify(text, require_protocol=False) == '<a href="http://www.tornadoweb.org">www.tornadoweb.org</a>'
    assert linkify(text, require_protocol=True) == 'www.tornadoweb.org'
    text = 'Hello http://tornadoweb.org!'
    assert linkify(text, require_protocol=False) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(text, require_protocol=True) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    text = 'Hello https://tornadoweb.org!'

# Generated at 2022-06-22 03:32:37.175090
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({
        'a': [1,2,4],
        'b': bytes('a','utf8'),
        'c': {'a': bytes('a','utf8')}
    }) == {
        'a': [1,2,4],
        'b': to_unicode(bytes('a','utf8')),
        'c':  {'a': to_unicode(bytes('a','utf8'))}
    }, "recursive_unicode test"

# Generated at 2022-06-22 03:32:41.631466
# Unit test for function native_str
def test_native_str():
    assert native_str("test") == "test"
    assert native_str(b"test") == "test"
    assert native_str(u"test") == "test"
    assert native_str(u"\xe9") == "\xe9"
    raises(UnicodeDecodeError, lambda: native_str(b"\xff"))



# Generated at 2022-06-22 03:32:43.466020
# Unit test for function json_decode
def test_json_decode():
    # Test for function json_decode
    pass



# Generated at 2022-06-22 03:32:45.685655
# Unit test for function url_unescape
def test_url_unescape():

    expected_result = "http://www.google.com/"
    input = "http%3A%2F%2Fwww.google.com%2F"
    result = url_unescape(input)
    assert result == expected_result, "url_unescape failed test case"



# Generated at 2022-06-22 03:32:53.277938
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'foo=bar&foo=baz') == {'foo': [b'bar', b'baz']}



# Generated at 2022-06-22 03:32:59.008069
# Unit test for function xhtml_escape
def test_xhtml_escape():
    a = "&<>\"'"
    b = xhtml_escape(a)
    print(b)
#test_xhtml_escape()


_BASESTRING_TYPES = (bytes, str, unicode_type)  # type: typing.Tuple[Any]
_MAX_INT32 = 2147483647



# Generated at 2022-06-22 03:33:00.893604
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode([u"hello", [b"world"]]) == [u"hello", [u"world"]]

# Generated at 2022-06-22 03:33:04.419802
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=1&b=2", True, True) == {"a": [b"1"], "b": [b"2"]}



# Generated at 2022-06-22 03:33:10.098373
# Unit test for function json_encode
def test_json_encode():
    data = {'a': 1, 'b': 2}
    json_encode(data)

# json_encode.__module__ = ''
# json_encode.__name__ = ''
# test_json_encode()


# When we are passed Unicode objects in callback arguments
# we need to convert them to UTF8.  While this is not a problem for JSON
# callbacks, it becomes a problem for non-JSON callbacks that expect
# byte strings.

# Generated at 2022-06-22 03:33:12.788947
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("1 2 3") == "1 2 3"
    assert squeeze("    1    2    3  ") == "1 2 3"



# Generated at 2022-06-22 03:33:14.710805
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"a": "b"}) == '{"a": "b"}'



# Generated at 2022-06-22 03:33:18.653313
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("  a b c\n") == "a b c"
    assert squeeze("\t\ta\t\tb\t\tc\t\t") == "a b c"
    assert squeeze("a b c") == "a b c"



# Generated at 2022-06-22 03:33:29.899389
# Unit test for function json_encode
def test_json_encode():
    print(json_encode({"a": "b"}))
    print(json_encode(["a", "b"]))
    print(json_encode("a"))
    print(json_encode(1))
test_json_encode()


_JSON_DECODE_OPTIONS = None  # type: typing.Optional[Dict[str, Any]]
if hasattr(json, "JSONDecodeError"):
    # The simplejson module used in Python < 2.7 does not support a
    # `strict` argument, so we must use this slightly different way to
    # specify that we want decoding errors to throw exceptions.
    _JSON_DECODE_OPTIONS = {"strict": True}



# Generated at 2022-06-22 03:33:37.090956
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    input = 'a=1&b=2'
    output = {
        'a': [b'1'],
        'b': [b'2'],
    }
    assert parse_qs_bytes(input) == output


# When dealing with the standard library across python 2 and 3 it is
# sometimes useful to have a direct conversion to the native string
# type
if str == bytes:
    native_str = bytes
else:
    native_str = str



# Generated at 2022-06-22 03:33:57.343375
# Unit test for function squeeze
def test_squeeze():
    text = "A very long string, which requires trimming."
    assert squeeze(text) == "A very long string, which requires trimming."


_UTF8_TYPES = typing.Union[bytes, bytearray, memoryview]



# Generated at 2022-06-22 03:34:04.693104
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{"a": 1, "b": "test"}') == {"a": 1, "b": "test"}
    assert json_decode(b'{"a": 1, "b": "test"}') == {"a": 1, "b": "test"}


# json_encode, json_decode moved to utf8.py in Tornado 4.
# Aliases preserved for compatibility.
utf8_json_encode = json_encode
utf8_json_decode = json_decode



# Generated at 2022-06-22 03:34:14.848949
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<&>') == '&lt;&amp;&gt;'
    assert xhtml_escape('"') == '&quot;'
    assert xhtml_escape("'") == '&#39;'
    assert xhtml_escape(1) == '1'
    assert xhtml_escape(None) == ''



# Generated at 2022-06-22 03:34:22.619663
# Unit test for function json_encode
def test_json_encode():
    print(json_encode({1: 2}))


# When json_decode receives an invalid input, we'd like to raise a
# ValueError with a reasonably clear error message, but json.loads
# raises a less-useful ValueError and c-speedups.py raises a
# less-useful TypeError.  Help python pick the right exception
# by coercing params to the right type.  When passed bytes,
# coerce to unicode if possible (and allow \u-escaped unicode).
# When passed unicode, coerce to bytes if possible.  If neither
# coercion is possible, re-raise the original error.

# Generated at 2022-06-22 03:34:28.456690
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("&") == "&amp;"
    assert xhtml_escape("<") == "&lt;"
    assert xhtml_escape(">") == "&gt;"
    assert xhtml_escape('"') == "&quot;"
    assert xhtml_escape("'") == "&#39;"



# Generated at 2022-06-22 03:34:33.181813
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("\\t\\ta    b \\n c\\r\\n d ") == "a b c d"
    assert squeeze("\\t\\ta\tb \tc\\r\\n d ") == "a b c d"
    assert squeeze("sum(a, b)") == "sum(a, b)"


# Generated at 2022-06-22 03:34:34.922933
# Unit test for function linkify
def test_linkify():
    print(linkify("Hello http://tornadoweb.org!"))

# A simple test request

# Generated at 2022-06-22 03:34:46.374424
# Unit test for function json_encode
def test_json_encode():
    j1 = json_encode({"a": 1, "b": 1, "c": "</script>"})
    j2 = json_encode({"a": 1, "b": 1, "c": "</script>"}).replace("</", "<\\/")
    return True


# When we are running from a pyinstaller compiled executable, sys._xoptions
# will contain the non-standard options that would have otherwise been passed
# to the underlying executable.
try:
    json_decode = json.loads
    assert json_decode
except (AttributeError, AssertionError):
    def json_decode(s: str) -> Any:
        return json.loads(to_basestring(s))


# urllib.quote and urlparse.urljoin have inconsistent support for Unicode
# strings when the argument is not ASCII

# Generated at 2022-06-22 03:34:49.439054
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('http://www.example.com/') == 'http%3A%2F%2Fwww.example.com%2F'
    print('url_escape test passed!')
test_url_escape()


# Generated at 2022-06-22 03:34:56.559393
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes('a=1&b=2&c=3', False, False)
    #assert parse_qs_bytes('a=1&b=2&c=3', True, False)
    #assert parse_qs_bytes('a=1&b=2&c=3', False, True)
    #assert parse_qs_bytes('a=1&b=2&c=3', True, True)
    #assert parse_qs_bytes(b'a=1&b=2&c=3', False, False)
    #assert parse_qs_bytes(b'a=1&b=2&c=3', True, False)
    #assert parse_qs_bytes(b'a=1&b=2&c=3', False, True)
    #assert parse_qs_bytes(b'a

# Generated at 2022-06-22 03:35:19.110480
# Unit test for function utf8
def test_utf8():
    assert utf8(None) == None
    assert utf8("abc") == b"abc"
    assert utf8(b"abc") == b"abc"
    assert utf8(u"abc") == b"abc"
    assert utf8(u"\xe0") == b"\xc3\xa0"
    assert utf8(u"\ud800") == b"\xed\xa0\x80"
    assert utf8(u"\ud800\udc00") == b"\xf0\x90\x80\x80"
    try:
        utf8(object())
        assert False
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:35:20.710807
# Unit test for function json_encode
def test_json_encode():
  value = {"a":"b"}
  print(json_encode(value))


# Generated at 2022-06-22 03:35:24.615958
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    testurl =  b"/a?a=1&b=2&c=a+b"
    result = parse_qs_bytes(testurl)
    assert result == {b"a": [b"1"], b"b": [b"2"], b"c": [b"a b"]}



# Generated at 2022-06-22 03:35:25.922841
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("   hello   world   ") == "hello world"



# Generated at 2022-06-22 03:35:28.770615
# Unit test for function url_escape
def test_url_escape():
    # test_url_escape()
    print('{}'.format(url_escape("test"))) 
    print('{}'.format(url_escape("test", False))) 
#test_url_escape()


# Generated at 2022-06-22 03:35:29.737172
# Unit test for function utf8
def test_utf8():
    assert utf8(1) == 1


# Generated at 2022-06-22 03:35:34.270407
# Unit test for function json_decode
def test_json_decode():
    f = open("test_json", "r")
    text = f.read()
    text = text.replace("'", "\"")
    value = json_decode(text)
    print(value)
    print(type(value))
    print(value["category"])
    return value


# Generated at 2022-06-22 03:35:42.074946
# Unit test for function utf8
def test_utf8():
    r = utf8('ab')
    assert r == b'ab'
    r = utf8('ab码')
    assert r == b'ab\xe7\xa0\x81'
    r = utf8(None)
    assert r is None
    r = utf8(b'ab')
    assert r == b'ab'



# Generated at 2022-06-22 03:35:43.976143
# Unit test for function url_escape
def test_url_escape():
    escaped_str = url_escape(u'testing')
    assert escaped_str == 'testing'



# Generated at 2022-06-22 03:35:50.752276
# Unit test for function json_encode
def test_json_encode():
    test_value = {
        "name": "test",
        "id": 42,
        "email": "test@testio.com",
        "numbers": [1, 2, 3, 4]
    }
    assert json_encode(test_value) == '{"name": "test", "id": 42, "email": "test@testio.com", "numbers": [1, 2, 3, 4]}'

_JSON_DECODE_OPTIONS = {
    "strict": False,
    "parse_constant": False,
    "parse_float": None,
    "parse_int": None,
    "parse_constant": None,
}



# Generated at 2022-06-22 03:36:19.543519
# Unit test for function json_encode
def test_json_encode():
    assert json_encode("</script>") == '"<\\/script>"'


URL_ESCAPE_RE = re.compile(r"[^\w;/?:@&=+$,-_.!~*()%]")



# Generated at 2022-06-22 03:36:22.204829
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('http://www.baidu.com') == 'http%3A//www.baidu.com'
test_url_escape()



# Generated at 2022-06-22 03:36:33.957416
# Unit test for function linkify
def test_linkify():
    assert linkify(b"http://www.example.com/foo") == '<a href="http://www.example.com/foo">http://www.example.com/foo</a>'
    assert (
        linkify(
            "www.example.com/foo", require_protocol=False
        )
        == '<a href="http://www.example.com/foo">www.example.com/foo</a>'
    )
    assert (
        linkify(
            "www.example.com/foo", require_protocol=True
        )
        == 'www.example.com/foo'
    )
    assert linkify(b"'onclick'=alert('foo')") == "<a>'onclick'=alert('foo')</a>"

# Generated at 2022-06-22 03:36:36.254490
# Unit test for function json_decode
def test_json_decode():
    value = '{"a": 5}'
    rez = json_decode(value)
    assert rez["a"] == 5



# Generated at 2022-06-22 03:36:48.410552
# Unit test for function native_str
def test_native_str():
    n = native_str('x')
    assert n == 'x'
    n = native_str('x', 'ascii')
    assert n == 'x'
    n = native_str('x', 'utf8')
    assert n == 'x'
    # This test is skipped on Python 3, because passing a Unicode string
    # to str() in Python 3 always decodes it, even with an explicit
    # encoding
    # TODO: figure out why this is not the case for all Unicode strings
    if sys.version_info[0] < 3:
        n = native_str(u'x', 'ascii')
        assert n == 'x'
        n = native_str(u'x', 'utf8')
        assert n == 'x'



# Generated at 2022-06-22 03:36:52.665125
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('  abc  ') == 'abc'
    assert squeeze('  a  b  ') == 'a b'
    assert squeeze('  a\nb\tc   ') == 'a b c'
    assert squeeze(u'  a\u00a0b\tc   ') == 'a b c'



# Generated at 2022-06-22 03:36:57.239536
# Unit test for function linkify
def test_linkify():
    print(linkify("http://www.google.com"))
    print(linkify("Hello http://tornadoweb.org!"))
    print(linkify("Hello www.cnn.com!"))
    print(linkify("http://www.tornadoweb.org", require_protocol=True))
    print(linkify("http://www.tornadoweb.org", require_protocol=False))



# Generated at 2022-06-22 03:37:03.955541
# Unit test for function url_escape
def test_url_escape():
    import urllib.parse
    for plus in [True, False]:
        for u in {
            '\u00e9': b'%C3%A9',
            '\u00e9'.encode('latin1'): '%E9'
        }:
            print(url_escape(u, plus), urllib.parse.quote(u, safe='', encoding='latin1' if isinstance(u, bytes) else 'utf-8', errors='replace'))
        #     assert url_escape(u, plus) == urllib.parse.quote(u, safe='', encoding='latin1' if isinstance(u, bytes) else 'utf-8', errors='replace'), plus
    # print(url_escape('héhe', plus), urllib.parse.quote(u, safe='', encoding='

# Generated at 2022-06-22 03:37:08.025850
# Unit test for function recursive_unicode
def test_recursive_unicode():
    print(recursive_unicode({"a": "b"}))
    print(recursive_unicode([1, 2, 3]))
    print(recursive_unicode((1, 2, 3)))
    print(recursive_unicode(b"string"))
    print(recursive_unicode(1))

test_recursive_unicode()



# Generated at 2022-06-22 03:37:12.704358
# Unit test for function json_encode
def test_json_encode():
    print('Entering test_json_encode')
    js = json_encode({ 'a': 1, 'b': 2})
    print('js = ')
    print(js)
    print('Exiting test_json_encode')

    