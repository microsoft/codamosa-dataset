

# Generated at 2022-06-22 03:28:20.009363
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a b  c  d   e    f     g") == "a b c d e f g"



# Generated at 2022-06-22 03:28:29.003027
# Unit test for function json_decode
def test_json_decode():
    """
    Note:
        Do not expect this function to be automatically tested.
    """
    from tornado.testing import AsyncHTTPTestCase
    from tornado.web import Application, RequestHandler
    from tornado.escape import json_decode
    import tornado.httpserver
    import json
    import typing
    @typing.overload
    def test_json_decode_decorator(json_str:str, expected:typing.Any) -> None:
        ...
    @typing.overload
    def test_json_decode_decorator(json_str:bytes, expected:typing.Any) -> None:
        ...
    def test_json_decode_decorator(json_str, expected):
        class TestHandler(RequestHandler):
            def get(self):
                json_str = self.get_argument

# Generated at 2022-06-22 03:28:30.989939
# Unit test for function native_str
def test_native_str():
    assert native_str(b"foo") == "foo"
    assert native_str(u"foo") == b"foo"
    assert native_str(None) is None



# Generated at 2022-06-22 03:28:36.230981
# Unit test for function native_str
def test_native_str():
    b = 'b'
    s = 'a'
    ss = b + s
    unicode_str = '中文'
    print(ss)
    print(type(ss))
    print(type(unicode_str))
    
test_native_str()


# Generated at 2022-06-22 03:28:43.308963
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({'a': 'b'}) == '{"a": "b"}'


# json_encode = json.dumps
# _unicode = str
_unicode = lambda value: value if isinstance(value, str) else value.decode("utf-8", "strict")
_utf8 = lambda value: value if isinstance(value, bytes) else value.encode("utf-8")



# Generated at 2022-06-22 03:28:45.743371
# Unit test for function json_decode
def test_json_decode():
    input_string = b'"test_passed"'
    output_string = json_decode(input_string)
    assertEqual(output_string, "test_passed")



# Generated at 2022-06-22 03:28:56.061028
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # Test for empty python object
    assert recursive_unicode(None) is None
    # Test for string
    assert recursive_unicode("abc") == "abc"
    # Test for dict
    assert type(recursive_unicode({'a': 'b'})) == dict
    # Test for list
    assert type(recursive_unicode(["a", "b"])) == list
    # Test for tuple
    assert type(recursive_unicode(("a", "b"))) == tuple
    # Test for type conversion from bytes to utf8
    assert recursive_unicode(b"abc") == "abc"
    assert type(recursive_unicode(b"abc")) == str



# Generated at 2022-06-22 03:28:57.129346
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("&<>\"'") == "&amp;&lt;&gt;&quot;&#39;"



# Generated at 2022-06-22 03:29:02.182811
# Unit test for function json_decode
def test_json_decode():
    s0: Union[str, bytes] = '{"code":"200","state":"success"}'
    s1: Union[str, bytes] = b'{"code":"200","state":"success"}'
    assert json_decode(s0) == {"code": "200", "state": "success"}
    assert json_decode(s1) == {"code": "200", "state": "success"}


# Generated at 2022-06-22 03:29:10.005846
# Unit test for function native_str
def test_native_str():
    assert _none_native_str() == _native_str(b'None')
    assert _native_str(b'1') == _native_str(b'1')
    assert _native_str(u'1') == _native_str(b'1')
    assert _native_str('1') == _native_str(b'1')
    assert _native_str(1) == _native_str(b'1')



# Generated at 2022-06-22 03:29:22.490366
# Unit test for function url_unescape
def test_url_unescape():
    # mypy : error: Argument 1 to "url_unescape" has incompatible type "Optional[str]"; expected "Union[bytes, str]"
    url_unescape("abc")


# Generated at 2022-06-22 03:29:31.122450
# Unit test for function linkify
def test_linkify():
    expected = u'<a href="http://www.demo.com">http://www.demo.com</a>'
    url = u'http://www.demo.com'
    test_case = linkify(url)

    assert test_case == expected
test_linkify()

# From https://github.com/sloria/textblob/blob/master/textblob/utils.py
# Copyright (c) 2014 Steven Loria
import unicodedata
import re



# Generated at 2022-06-22 03:29:40.418726
# Unit test for function squeeze
def test_squeeze():
    print("Unit test for function squeeze")
    assert squeeze("a   b   c") == "a b c"
test_squeeze()

_unescape_entity_re = re.compile(r"&(#?)(\d+|\w+);")

# This is slightly faster than the alternative below.  The alternative is
# safer (e.g. against malicious HTML) but also slower.  See
# http://stackoverflow.com/questions/5693864/what-is-the-fastest-way-to-unescape-html-in-python

# Generated at 2022-06-22 03:29:46.016618
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("{'x': 1}") == {'x': 1}
    assert json_decode(b"{'x': 1}") == {'x': 1}


# to_unicode is deprecated in py3, but it is conceptually a good name for
# this function.
to_unicode = _unicode  # type: Callable[[str], str]



# Generated at 2022-06-22 03:29:58.745693
# Unit test for function linkify
def test_linkify():
    text = "Hello http://tornadoweb.org !"
    assert linkify(text) == 'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a> !'

    text = "Hello www.tornadoweb.org !"
    assert linkify(text) == 'Hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a> !'

    text = "Hello example.com !"
    assert linkify(text) == 'Hello example.com !'

    text = "Hello example.com !"
    assert linkify(text, require_protocol=True) == 'Hello example.com !'

    text = "Hello www.tornadoweb.org !"

# Generated at 2022-06-22 03:30:07.740552
# Unit test for function json_decode
def test_json_decode():
    test_value = b'{"abc":"def"}'
    result = json_decode(test_value)
    assert result == {"abc": "def"}
    assert type(result) == dict
    test_value = b'["abc","def"]'
    result = json_decode(test_value)
    assert result == ["abc", "def"]
    assert type(result) == list
    test_value = '[1,"abc","def"]'
    result = json_decode(test_value)
    assert result == [1, "abc", "def"]
    assert type(result) == list


_JSON_RECURSION_LIMIT = 1000



# Generated at 2022-06-22 03:30:12.297221
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&Ntilde;&iexcl;') == 'Ñ¡'
test_xhtml_unescape()



# Generated at 2022-06-22 03:30:20.963465
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    to_unescape = "&lt;a href=&quot;www.google.com&quot;&gt;Google&lt;/a&gt;"
    unescaped_value = xhtml_unescape(to_unescape)
    assert unescaped_value == "<a href=\"www.google.com\">Google</a>"

test_xhtml_unescape()

# Allow code to use u"" to represent a Unicode string for Python 2 and 3
try:
    _unicode = unicode  # type: Callable[[Any], str]
except NameError:
    _unicode = str

_TO_UNICODE_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:30:21.891101
# Unit test for function url_unescape
def test_url_unescape():
    assert 1 == 1



# Generated at 2022-06-22 03:30:27.605161
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("&<>\"\''") == "&amp;&lt;&gt;&quot;&#39;"
    assert xhtml_escape(b"&<>\"\'") == "&amp;&lt;&gt;&quot;&#39;"
test_xhtml_escape()



# Generated at 2022-06-22 03:30:48.414489
# Unit test for function linkify
def test_linkify():
    url="www.baidu.com"
    print(linkify(url))
    url="http://www.youdao.com"
    print(linkify(url))
    url="http://www.baidu.com"
    print(linkify(url))
    url = "http://www.baidu.com/s;?wd=1&class=2"
    print(linkify(url))
    url = "http://www.baidu.com/s;?wd=1&class=2"
    print(linkify(url,True))
    url = "http://www.baidu.com/s;?wd=1&class=2"
    print(linkify(url,True,extra_params='rel="nofollow" class="external"'))


# Obsolete synonyms (pre

# Generated at 2022-06-22 03:30:51.088208
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#39;') == '\''
    assert xhtml_unescape('&#x27;') == '\''
    assert xhtml_unescape('&#x1F601;') == '😁'


# Generated at 2022-06-22 03:30:54.856090
# Unit test for function utf8
def test_utf8():
    from tornado import gen
    assert utf8("foo") == b"foo"
    assert utf8(u"foo") == b"foo"
    assert utf8(u"\u2603") == b"\xe2\x98\x83"
    assert utf8(None) is None
    with gen.coroutine(lambda: utf8(gen.sleep(1))):
        pass


_TO_UNICODE_TYPES = (bytes, type(None), unicode_type)



# Generated at 2022-06-22 03:31:04.283903
# Unit test for function utf8
def test_utf8():
    assert utf8("v1") == b"v1"
    assert utf8(u"v1") == b"v1"
    assert utf8(None) is None
    assert utf8(1) == b"1"
    assert utf8(1.2) == b"1.2"
    assert utf8(True) == b"True"
    assert utf8(b"1") == b"1"

test_utf8()



# Generated at 2022-06-22 03:31:12.103799
# Unit test for function json_decode
def test_json_decode():
    value = """{
        "url": "/app/foo",
        "args": {"param1": "hello", "param2": "world"},
        "headers": {
            "Host": "localhost:3000",
            "Accept-Language": "en-US",
            "Accept-Encoding": "gzip"
        }
    }"""
    value = json_decode(value)
    print(value)
    # url
    url = value["url"]
    assert url == "/app/foo"
    # args
    args = value["args"]
    assert args["param1"] == "hello"
    assert args["param2"] == "world"
    # headers
    headers = value["headers"]
    assert headers["Host"] == "localhost:3000"
    assert headers["Accept-Language"] == "en-US"

# Generated at 2022-06-22 03:31:15.155370
# Unit test for function url_escape
def test_url_escape():
    url = url_escape("http://www.baidu.com")
    print(url)


# Generated at 2022-06-22 03:31:19.564281
# Unit test for function json_decode
def test_json_decode():
    # type: () -> None
    assert json_decode('{"a": "b"}') == {"a": "b"}
    assert json_decode(b'{"a": "b"}') == {"a": "b"}



# Generated at 2022-06-22 03:31:25.915547
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    # convert & to &amp;
    assert xhtml_escape("&") == "&amp;", "& -> &amp;"
    # convert < to &lt;
    assert xhtml_escape("<") == "&lt;", "< -> &lt;"
    # convert > to &gt;
    assert xhtml_escape(">") == "&gt;", "> -> &gt;"
    # convert " to &quot;
    assert xhtml_escape('"') == "&quot;", '" -> &quot;'
    # convert ' to &#39;
    assert xhtml_escape("'") == "&#39;", "' -> &#39;"


# html entity definitions
_html_entities = html.entities.entitydefs

# Generated at 2022-06-22 03:31:31.323808
# Unit test for function url_unescape
def test_url_unescape():
    result: str  = url_unescape(b'', encoding=None)
    result: str  = url_unescape(b'a', encoding="utf-8", plus=False)
    result: str  = url_unescape(b'a', encoding="utf-8", plus=True)
    result: bytes  = url_unescape(b'a', encoding=None)



# Generated at 2022-06-22 03:31:32.664335
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'a=1&b=2', True, True) == {b'a': [b'1'], b'b': [b'2']}



# Generated at 2022-06-22 03:31:49.097928
# Unit test for function native_str
def test_native_str():
    assert native_str("ascii") == "ascii"
    assert native_str("ascii", "ascii") == "ascii"
    assert native_str("hello world") == "hello world"
    assert native_str("hello world", "ascii") == "hello world"
    assert native_str("こんにちは") == "こんにちは"
    assert native_str("こんにちは", "utf-8") == "こんにちは"
    assert native_str("こんにちは", "utf8") == "こんにちは"



# Generated at 2022-06-22 03:31:52.344426
# Unit test for function squeeze
def test_squeeze():
    return squeeze("this    is  a    test")
# Return 'this is a test'


# Generated at 2022-06-22 03:31:56.484805
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(b"foo") == "foo"
    assert recursive_unicode(["a", b"b"]) == ["a", "b"]
    assert recursive_unicode(("a", b"b")) == ("a", "b")
    assert recursive_unicode({"a": b"b"}) == {"a": "b"}



# Generated at 2022-06-22 03:31:57.738715
# Unit test for function json_encode
def test_json_encode():
    assert json_encode(None) == 'null'



# Generated at 2022-06-22 03:32:04.014839
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = 'value=a&key=b'
    result = parse_qs_bytes(qs)
    assert result['value'][0] == b'a'
    assert result['key'][0] == b'b'
    qs = 'value=a&key=b&value=c'
    result = parse_qs_bytes(qs)
    assert result['value'][-1] == b'c'
    assert result['key'][0] == b'b'
    qs = 'value=a&key=b&value=c&key=d'
    result = parse_qs_bytes(qs)
    assert result['value'][-1] == b'c'
    assert result['key'][-1] == b'd'
test_parse_qs_bytes()
# End unit test for function parse_

# Generated at 2022-06-22 03:32:08.039711
# Unit test for function url_unescape
def test_url_unescape():
    assert b"http://test.com" == url_unescape("http%3A//test.com", encoding=None)
    assert "http://test.com" == url_unescape("http%3A//test.com", encoding="utf-8")



# Generated at 2022-06-22 03:32:12.245000
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(
        {"foo": [1, 2, {"bar": b"baz"}]}) == {'foo': [1, 2, {'bar': 'baz'}]}
    assert recursive_unicode([b"foo", {"bar": b"baz"}]) == ['foo', {'bar': 'baz'}]



# Generated at 2022-06-22 03:32:15.798042
# Unit test for function json_encode
def test_json_encode():
    a = dict(name=12, age='1')
    print(json_encode(a))
    return 1

_JSON_DECODE_FUNC = getattr(json, "loads", None) or getattr(json, "load")


# Generated at 2022-06-22 03:32:28.878558
# Unit test for function utf8
def test_utf8():
    assert utf8("x") == b"x"
    assert utf8(b"x") == b"x"
    assert utf8("\x80") == b"\xc2\x80"
    assert utf8("\u1234") == b"\xe1\x88\xb4"
    assert utf8("\U00012345") == b"\xf0\x92\x8d\x85"
    assert utf8(None) is None
    try:
        utf8(u"\udc80")
        assert False, "invalid continuation byte"
    except UnicodeEncodeError:
        pass
    try:
        utf8(dict())
        assert False, "expected string, bytes, or None"
    except TypeError:
        pass


_TO_UNICODE_

# Generated at 2022-06-22 03:32:40.053958
# Unit test for function native_str
def test_native_str():
    assert native_str("") == ""
    assert native_str("abc") == "abc"
    if sys.version_info[0] < 3:
        assert isinstance(native_str("abc"), str)
        assert native_str("abc") == str("abc")
    else:
        assert isinstance(native_str("abc"), str)
        assert native_str("abc") == bytes("abc").decode()
    assert isinstance(native_str(u"abc"), str)
    assert native_str(u"abc") == u"abc".encode("utf-8").decode()
    assert isinstance(native_str(b"abc"), str)
    assert native_str(b"abc") == b"abc".decode()



# Generated at 2022-06-22 03:33:09.003345
# Unit test for function xhtml_escape
def test_xhtml_escape():
    test_string = '"hi"'
    print(xhtml_escape(test_string))

_JSON_ESCAPE_DICT: Dict[str, str] = {
    ord("&"): "\\u0026",
    ord("<"): "\\u003c",
    ord(">"): "\\u003e",
    # \u2028 and \u2029 are legal in JSON strings, but are not legal
    # JSONP, with the result that some browsers ignore the
    #Content-Type: application/json header.
    ord("\u2028"): "\\u2028",
    ord("\u2029"): "\\u2029",
    0x00: "\\u0000",
}

for i in range(0x20):
    _JSON_ESCAPE_DICT.set

# Generated at 2022-06-22 03:33:15.363006
# Unit test for function utf8
def test_utf8():
    assert utf8('foo') == b'foo'
    assert utf8(u'foo') == b'foo'
    assert utf8(b'foo') == b'foo'
    assert utf8(None) is None
    assert utf8(object()) == b'<object object at 0x%x>' % id(object())


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:33:16.941531
# Unit test for function json_encode
def test_json_encode():
    assert json_encode('</') == '"<\/"'


# Generated at 2022-06-22 03:33:29.017377
# Unit test for function linkify
def test_linkify():
    # linkify: Force https URLs
    # https://github.com/tornadoweb/tornado/issues/1383
    assert linkify("http://example.com") == '<a href="https://example.com">example.com</a>'
    assert linkify("http://foo.org/blah_blah") == '<a href="https://foo.org/blah_blah">foo.org/blah_blah</a>'
    assert linkify("http://foo.org/blah_blah_(wikipedia)") == '<a href="https://foo.org/blah_blah_(wikipedia)">foo.org/blah_blah_(wikipedia)</a>'

# Generated at 2022-06-22 03:33:33.074459
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<>\"'&") == "&lt;&gt;&quot;&#39;&amp;"
    assert xhtml_escape(1) == "1"



# Generated at 2022-06-22 03:33:36.935597
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print(xhtml_unescape("&lt;&gt;"))
    print(xhtml_unescape("&#39;"))
    print(xhtml_unescape("&amp;"))
# test_xhtml_unescape()



# Generated at 2022-06-22 03:33:47.757159
# Unit test for function native_str
def test_native_str():
    if typing.TYPE_CHECKING:
        assert native_str("abc") == "abc"
        assert native_str(b"abc") == "abc"
        assert native_str(None) == None
        assert native_str(u"abc") == "abc"
        #
        assert native_str(123) == "123"
        assert native_str(b"123") == "123"
        assert native_str(None, errors='ignore') == None
        assert native_str(u"123") == "123"

    assert native_str("abc", errors='strict') == "abc"
    assert native_str("abc", errors='ignore') == "abc"
    assert native_str("abc", errors='backslashreplace') == "abc"
    assert native_str("abc", errors='replace') == "?bc"
   

# Generated at 2022-06-22 03:33:57.207903
# Unit test for function json_encode
def test_json_encode():
    assert(json_encode(1) == "1")
    assert(json_encode("asdasd") == "\"\\u0061\\u0073\\u0064\\u0061\\u0073\\u0064\"")
    assert(json_encode({"a":1}) == '{"a": 1}')
    assert(json_encode([1]) == '[1]')
    assert(json_encode([[1]]) == '[[1]]')
    assert(json_encode([[1, 2]]) == '[[1, 2]]')



# Generated at 2022-06-22 03:34:04.127087
# Unit test for function json_encode
def test_json_encode():
    assert json_encode(['<', 'b']) == '["<", "b"]'


# The fact that _recursive_unicode and recursive_unicode are
# implementation details of json_decode and utf8 are implementation
# details of recursive_unicode is an implementation detail.
# Please see https://github.com/tornadoweb/tornado/pull/706
# before sending a pull request that adds **kwargs to a function
# or removing **kwargs from a function.

# Generated at 2022-06-22 03:34:06.199715
# Unit test for function json_decode
def test_json_decode():
    r=json_decode('{"a":1}')
    assert isinstance(r, dict)
    assert r["a"]==1
    r=json_decode('["a",1]')
    assert isinstance(r, list)
    assert r[0]=="a"

# 字符串转为驼峰命名法

# Generated at 2022-06-22 03:35:43.925455
# Unit test for function json_decode
def test_json_decode():
    value = '{"a":"a"}'
    v = json_decode(value)
    # print(v["a"])


# json_encode, json_decode = _json_decode = getattr(json, '{}'.format)

# When json_encode() is passed a dict with keys that are not strings
# we attempt to convert them to strings using repr().  Some classes
# may not have a sensible __repr__ (such as tornado.web.RequestHandler)
# and will raise an exception.  We can't use force_str here because
# that would also convert RequestHandler instances to strings.  This
# function replaces such values with a placeholder so that json_encode()
# will convert them to JSON nulls instead of raising an exception.
#
# _cp_config = {}
# _null_type = type(None

# Generated at 2022-06-22 03:35:50.482187
# Unit test for function recursive_unicode
def test_recursive_unicode():
    value = {"key": "value",
             "int": 1,
             "double": 1.1,
             "list": ["value1", "value2"],
             "dict": {"key1": "value1",
                      "key2": "value2"
                      }
             }
    assert recursive_unicode(value) == {
        "key": "value",
        "int": 1,
        "double": 1.1,
        "list": ["value1", "value2"],
        "dict": {"key1": "value1",
                 "key2": "value2"
                 }
    }



# Generated at 2022-06-22 03:35:54.442059
# Unit test for function utf8
def test_utf8():
    s = "日本語"
    assert utf8(s) == s.encode('utf-8')
    s2 = utf8(s)
    assert s2.decode('utf-8') == s



_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:35:59.745695
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('hello%20world', plus=False) == 'hello world'
    assert url_unescape('hello+world', plus=True) == 'hello world'
    assert url_unescape(b'hello%20world') == b'hello world'



# Generated at 2022-06-22 03:36:11.224626
# Unit test for function linkify
def test_linkify():
    assert linkify("http://google.com/") == '<a href="http://google.com/">http://google.com/</a>'
    assert 'rel="nofollow"' in linkify("http://google.com/", extra_params='rel="nofollow"')
    assert 'class="external"' in linkify("http://google.com/", extra_params=lambda x: 'class="external"')
    assert 'class="external"' in linkify("http://google.com/", extra_params=lambda x: 'class="external"')
    assert 'rel="nofollow"' not in linkify("http://google.com/", extra_params=lambda x: 'class="external"')

# Generated at 2022-06-22 03:36:13.874654
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("foo bar") == "foo+bar"
    assert url_escape("foo+bar") == "foo%2Bbar"


# Generated at 2022-06-22 03:36:21.338351
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    print('\n')
    print('test_parse_qs_bytes:')
    print(parse_qs_bytes(b'foo=bar&baz=quux'))
    print(parse_qs_bytes(b'foo=bar&baz=quux&foo=quux'))
    print(parse_qs_bytes(b'foo=bar&baz='))
    print(parse_qs_bytes(b'foo=bar&baz=&foo=quux'))
    print(parse_qs_bytes(b'foo=bar&baz=&foo=quux&foo='))


# Generated at 2022-06-22 03:36:31.410689
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{"key":"value"}') == {"key": "value"}
    assert json_decode(b'{"key": "value"}') == {"key": "value"}

# Note that we allow trailing commas in json_decode because json.dumps
# requires them in certain cases to produce valid JSON.


# Simple regexp that matches commas but not commas within double quotes
_JSON_DECODE_COMMA_RE = re.compile(r'(?<![^\\]"(?:\\.|[^"\\])*"),')



# Generated at 2022-06-22 03:36:37.418902
# Unit test for function xhtml_escape
def test_xhtml_escape():
    """Test function xhtml_escape"""
    data: str = 'a < b & c > d " e \' f'
    assert "a &lt; b &amp; c &gt; d &quot; e &#39; f" == xhtml_escape(data)


# Final value of _HTML_UNESCAPE_TABLE
_HTML_UNESCAPE_TABLE = None
# Final value of _JSON_ESCAPE_RE
_JSON_ESCAPE_RE = None



# Generated at 2022-06-22 03:36:48.541408
# Unit test for function json_encode