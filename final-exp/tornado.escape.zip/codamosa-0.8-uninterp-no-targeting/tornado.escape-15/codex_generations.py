

# Generated at 2022-06-22 03:28:25.665489
# Unit test for function native_str
def test_native_str():
    import sys
    print(native_str("test"))
    print(native_str("test", "utf8"))
    print(native_str("test", "utf8", "ignore"))
    print(type(native_str("test")))
    print(type(native_str("test", "utf8")))
    print(type(native_str("test", "utf8", "ignore")))
    if sys.version_info < (3, 0):
        print(repr(native_str("test", "utf8", "ignore")), str)


# Generated at 2022-06-22 03:28:30.571249
# Unit test for function url_escape
def test_url_escape():
    assert(url_escape('/:/ailab') == '%2F%3A%2Failab')
    assert(url_escape('/:/ailab', plus=False) == '%2F%3A%2Failab')
    assert(url_escape('/:/ailab', plus=True) == '%2F%3A%2Failab')


# Generated at 2022-06-22 03:28:37.609043
# Unit test for function utf8
def test_utf8():
    test1 = "abcd"
    test2 = b"abc"
    # TODO: Fix this behavior
    # assert utf8(test1) == test1.encode("utf-8")
    assert utf8(test2) == test2


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:28:47.283575
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # for simplicity, let's only support parsing a single value
    # with no query arguments
    assert parse_qs_bytes(b"a") == {"a": [b""]}
    assert parse_qs_bytes(b"a=1") == {"a": [b"1"]}
    assert parse_qs_bytes(b"a=1&a=2") == {"a": [b"1", b"2"]}
    assert parse_qs_bytes(b"a=1&a=2", keep_blank_values=True) == {"a": [b"1", b"2", b""]}
    assert parse_qs_bytes(b"a=1&b=2") == {"a": [b"1"], "b": [b"2"]}
    assert parse_qs_bytes(b"a=A%20B")

# Generated at 2022-06-22 03:28:51.152445
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('/path/to/file') == '/path/to/file'

_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:29:00.021098
# Unit test for function url_escape
def test_url_escape():
    test_data = {            
        'http://localhost/' : 'http%3A//localhost/',
        'http://localhost/这是中文' : 'http%3A//localhost/%E8%BF%99%E6%98%AF%E4%B8%AD%E6%96%87',
        'http://localhost/这是中文&' : 'http%3A//localhost/%E8%BF%99%E6%98%AF%E4%B8%AD%E6%96%87%26',
    }
    for param in test_data.keys():
        assert url_escape(param) == test_data[param]


# Generated at 2022-06-22 03:29:01.744772
# Unit test for function recursive_unicode
def test_recursive_unicode():
    import doctest
    doctest.testmod(
        verbose=True
    )


# Generated at 2022-06-22 03:29:04.185436
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("  hello \n\tworld") == "hello world"
    assert squeeze("   ") == ""



# Generated at 2022-06-22 03:29:16.154992
# Unit test for function linkify
def test_linkify():
    print(linkify("<a href='http://example.com/'>Hello</a>"))
    print(linkify("http://example.com/", True))
    print(linkify("http://example.com/", False))

    print(linkify("Say hello to http://example.com/", True, ''))
    print(linkify("Say hello to http://example.com/", False, ''))

    print(
        linkify(
            "http://example.com/", True, 'rel="nofollow" class="external"'
        )
    )
    print(
        linkify(
            "http://example.com/", False, 'rel="nofollow" class="external"'
        )
    )


# Generated at 2022-06-22 03:29:20.783076
# Unit test for function utf8
def test_utf8():
    print(utf8(u'\xa1'))
    print(utf8('\xc2\xa1'))
    print(utf8(None))


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:29:33.483165
# Unit test for function utf8
def test_utf8():
    assert utf8('') == b''
    assert utf8(None) is None
    assert utf8('foo') == b'foo'


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:29:35.396920
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("&") == "&amp;"

_unescape_dict = None



# Generated at 2022-06-22 03:29:38.624903
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"x": [1, {"y": b"z"}]}) == {
        "x": [1, {"y": "z"}]
    }



# Generated at 2022-06-22 03:29:50.878746
# Unit test for function xhtml_escape
def test_xhtml_escape():
    # Test basic xhtml escape
    assert xhtml_escape("<>&\"'") == "&lt;&gt;&amp;&quot;&#39;"
    assert xhtml_escape(None) == ""
    assert xhtml_escape(123) == "123"
    assert xhtml_escape("<>&\"'\u00a0") == "&lt;&gt;&amp;&quot;&#39;\u00a0"
    assert xhtml_escape("<>&\"'\u00a0".encode("utf8")) == "&lt;&gt;&amp;&quot;&#39;\u00a0"

# Generated at 2022-06-22 03:29:59.557633
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("%C3%A9") == "é"
    assert url_unescape("%C3%A9", encoding="ascii") == "é"
    assert url_unescape("%C3%A9", encoding="utf-8") == "é"
    assert url_unescape(b"%C3%A9", encoding="utf-8") == "é"
    assert url_unescape(b"%C3%A9", encoding=None) == b"\xc3\xa9"



# Generated at 2022-06-22 03:30:09.524966
# Unit test for function xhtml_escape
def test_xhtml_escape():
    result = xhtml_escape("<htmlscript>alert(1);</htmlscript>")
    assert result == "&lt;htmlscript&gt;alert(1);&lt;/htmlscript&gt;"
# Exported symbols
__all__ = ("linkify", "xhtml_escape", "JSONEncoder", "recursive_unicode")



# Generated at 2022-06-22 03:30:18.374976
# Unit test for function linkify
def test_linkify():
    assert linkify(u'Hello http://tornadoweb.org!') == u'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'
    assert linkify(u'Hello www.tornadoweb.org!') == u'Hello <a href="http://www.tornadoweb.org">www.tornadoweb.org</a>!'
    assert linkify(u'Visit http://😊tornadoweb.org!') == u'Visit <a href="http://😊tornadoweb.org">http://😊tornadoweb.org</a>!'


# Generated at 2022-06-22 03:30:22.413083
# Unit test for function json_decode
def test_json_decode():
    j = '[{"foo": 1, "bar": [1, 2, 3]}]'
    assert isinstance(json_decode(j), list)
    assert json_decode(j) == [{"foo": 1, "bar": [1, 2, 3]}]



# Generated at 2022-06-22 03:30:34.104398
# Unit test for function linkify
def test_linkify():
    assert linkify(None) is None
    assert linkify("") == ""
    assert linkify("hello") == "hello"
    assert linkify("hello http://www.world.com") == 'hello <a href="http://www.world.com">http://www.world.com</a>'
    assert linkify("hello www.world.com", require_protocol=False) == 'hello <a href="http://www.world.com">www.world.com</a>'

# Generated at 2022-06-22 03:30:46.519258
# Unit test for function linkify
def test_linkify():
    text = '<h1>我是首页</h1>'
    result = '<h1>我是首页</h1>'
    print(linkify(text))
    print(xhtml_escape('http://www.baidu.com'))
    print(xhtml_escape('http://www.baidu.com/s?wd=tornado'))

# Generated at 2022-06-22 03:31:00.113848
# Unit test for function json_encode
def test_json_encode():
    assert json_encode(1) == '1'
    assert json_encode(u'foo') == '"foo"'
    assert json_encode('foo') == '"foo"'
    assert json_encode({u'foo': u'bar'}) == '{"foo": "bar"}'
    assert json_encode({1: 9}) == '{"1": 9}'
    assert json_encode([1, 2, 3, {u'foo': [1, 2, 3]}]) == '[1, 2, 3, {"foo": [1, 2, 3]}]'
    assert json_encode(True) == 'true'
    assert json_encode(None) == 'null'



# Generated at 2022-06-22 03:31:08.373694
# Unit test for function json_encode
def test_json_encode():
    # type: () -> None
    assert json_encode({"a": 1}) == '{"a": 1}'
    assert json_encode(1) == '1'
    assert json_encode("</") == '"<\\/"'
    assert json_encode(u"\u2028") == '"\\u2028"'
    assert json_encode(u"\u2029") == '"\\u2029"'
    assert json_encode(u"</script>") == '"<\\/script>"'

# Generated at 2022-06-22 03:31:20.360424
# Unit test for function url_escape

# Generated at 2022-06-22 03:31:32.403038
# Unit test for function linkify
def test_linkify():
    words = 'linkify "http://tornadoweb.org" and http://www.tornadoweb.org!'
    assert linkify(words) == 'linkify <a href="http://tornadoweb.org">http://tornadoweb.org</a> and <a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a>!'
    assert linkify(words, True) == 'linkify <a href="http://tornadoweb.org">http://tornad...</a> and <a href="http://www.tornadoweb.org">http://www.torna...</a>!'

# Generated at 2022-06-22 03:31:37.750436
# Unit test for function xhtml_escape
def test_xhtml_escape():
    print(xhtml_escape('<>"&\''))
    print(xhtml_escape(b'<>"&\''))
test_xhtml_escape()



# Generated at 2022-06-22 03:31:47.091818
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'foo=1&foo=2') == {'foo': [b'1', b'2']}
    assert parse_qs_bytes(b'foo=1&foo=%28%29&bar=1') == {'foo': [b'1', b'()'], 'bar': [b'1']}
    assert parse_qs_bytes(b'foo=1%262', True) == {'foo': [b'1&2']}
    assert parse_qs_bytes(b'foo=1%2B2', True) == {'foo': [b'1+2']}
    assert parse_qs_bytes(b'foo=1 2', True) == {'foo': [b'1 2']}


# Generated at 2022-06-22 03:31:56.332191
# Unit test for function utf8
def test_utf8():
    def _test_utf8(value):
        assert utf8(value) == value
    _test_utf8(b"ascii")
    _test_utf8("ascii")
    _test_utf8("Non-ASCII üñîçøðé")
    _test_utf8(None)
    assert isinstance(utf8("ascii"), bytes)
    assert isinstance(utf8(u"ascii"), bytes)
    _test_utf8("Non-ASCII üñîçøðé")
    try:
        utf8(1)
        assert False
    except TypeError:
        pass



# Generated at 2022-06-22 03:32:01.254890
# Unit test for function utf8
def test_utf8():
    str1 = "this is a test"
    str1_bytes = b"this is a test"
    assert utf8(str1) == str1_bytes
    str2 = ""
    str2_byte = b""
    assert utf8(str2) == str2_byte
    str3 = "1234567890"
    str3_bytes = b"1234567890"
    assert utf8(str3) == str3_bytes



# Generated at 2022-06-22 03:32:04.158023
# Unit test for function squeeze
def test_squeeze():
    print(squeeze('a  b d c'))



# Generated at 2022-06-22 03:32:14.660386
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('a%2Bb') == b'a+b'
    assert url_unescape('a+b') == b'a+b'
    assert url_unescape('a%2Bb', plus=False) == 'a+b'

    assert url_unescape('a%2Bb', encoding=None) == b'a+b'
    assert url_unescape('a+b', encoding=None) == b'a+b'
    assert url_unescape('a%2Bb', encoding=None, plus=False) == 'a+b'

    assert url_unescape('a%2Bb', encoding='ascii') == 'a+b'
    assert url_unescape('a+b', encoding='ascii') == 'a b'

# Generated at 2022-06-22 03:32:28.326579
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"foo": "</script>"}) == '{"foo": "<\\/script>"}'


# This singleton "undefined" is used to detect undefined values in
# JSON-encoded scripts.  Note that, because it is a constant, it is
# treated as a compile-time constant by the closure compiler, so it
# is *not* stripped out by the minifier.
undefined = object()  # type: Any



# Generated at 2022-06-22 03:32:31.266444
# Unit test for function json_encode
def test_json_encode():
    assert json_encode("</") == "<\\/>"
    assert json_encode("<\/") == "<\\/\\/>"
    assert json_encode("<\\/") == "<\\/\\/\\/>"



# Generated at 2022-06-22 03:32:32.613428
# Unit test for function json_decode
def test_json_decode():
    assert isinstance(json_decode("\"abcd\""), str)



# Generated at 2022-06-22 03:32:36.188960
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"foo%20bar", None) == b"foo bar"
    assert url_unescape(b"foo%20bar", "utf-8") == u"foo bar"


# Generated at 2022-06-22 03:32:39.264542
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert "&#38;#39;" == xhtml_unescape("&amp;#39;")
    assert xhtml_unescape(xhtml_escape("&#39;")) == "&#39;"


# Generated at 2022-06-22 03:32:40.235137
# Unit test for function native_str
def test_native_str():
    return str(1)

# Generated at 2022-06-22 03:32:51.541670
# Unit test for function utf8
def test_utf8():
    from tornado.util import bytes_type
    assert utf8("foo") == b"foo"
    assert utf8(u"foo") == b"foo"
    assert type(utf8("foo")) is bytes_type
    assert utf8(None) is None
    assert type(utf8(None)) is type(None)
    assert utf8(b"foo") == b"foo"
    assert type(utf8(b"foo")) is bytes_type


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:33:03.805178
# Unit test for function recursive_unicode
def test_recursive_unicode():
    s = {
        # b'foo': b'bar',
        u'foo': u'bar',
        u'baz': [  
          b'asdf',
          u'asdf',
        ]
    }
    r = recursive_unicode(s)
    # assert r[b'foo'] == u'bar'
    assert r[u'foo'] == u'bar'
    assert r[u'baz'][0] == u'asdf'
    assert r[u'baz'][1] == u'asdf'
    assert not isinstance(r, dict)
    assert isinstance(r, dict)
    assert isinstance(r[u'baz'], list)
    assert isinstance(r[u'baz'][0], str)

# Generated at 2022-06-22 03:33:08.593677
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
  value = "&lt;&gt;&amp;&quot;&apos;&#39;&#65;&#x65;"
  assert xhtml_unescape(value) == "<>&\"''Ae"
test_xhtml_unescape.__test__ = False

_BASESTRING_TYPES = (bytes, str)



# Generated at 2022-06-22 03:33:15.883263
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('$0.01') == '$0.01'
    assert xhtml_unescape('&gt;') == '>'
    assert xhtml_unescape('&amp;') == '&'


_JSON_ESCAPE_RE = re.compile(r"[<>&]")
_JSON_ESCAPE_DICT = {
    "<": r"\u003c",
    ">": r"\u003e",
    "&": r"\u0026",
}



# Generated at 2022-06-22 03:33:34.181656
# Unit test for function recursive_unicode
def test_recursive_unicode():
    a = dict(str1='a', str2='b', int1=1, int2=2, float1=3.14)
    b = dict(str1=u'a', str2=u'b', int1=1, int2=2, float1=3.14)
    assert recursive_unicode(a) == b
    assert recursive_unicode(b) == b

    a = [1, 'a', ('a', 1), ['b', ('c', [2, 3.0])]]
    b = [1, u'a', (u'a', 1), [u'b', (u'c', [2, 3.0])]]
    assert recursive_unicode(a) == b
    assert recursive_unicode(b) == b


# Generated at 2022-06-22 03:33:38.855048
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    query = b'a=b&c=d'
    result = parse_qs_bytes(query)
    assert(result=={'a': [b'b'], 'c': [b'd']})
    print("test_parse_qs_bytes is passed!")
test_parse_qs_bytes()

_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:33:43.983358
# Unit test for function json_decode
def test_json_decode():
    input = "{\"a\": [1,true,\"text\"]}"
    output = json_decode(input)
    assert isinstance(output, dict)
    assert isinstance(output['a'], list)
    assert output['a'][0] == 1
    assert output['a'][1] == True
    assert output['a'][2] == "text"



# Generated at 2022-06-22 03:33:46.767673
# Unit test for function url_escape
def test_url_escape():
    value = '中国'
    plus = False
    print(url_escape(value, plus))

test_url_escape()
 


# Generated at 2022-06-22 03:33:55.126648
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<html><script>alert(window.name)</script></html>') == "&lt;html&gt;&lt;script&gt;alert(window.name)&lt;/script&gt;&lt;/html&gt;"
    assert xhtml_escape(u'<html><script>alert(window.name)</script></html>') == "&lt;html&gt;&lt;script&gt;alert(window.name)&lt;/script&gt;&lt;/html&gt;"



# Generated at 2022-06-22 03:34:07.469176
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"") == {}
    assert parse_qs_bytes(b"foo") == {"foo": [b""]}
    assert parse_qs_bytes(b"foo=") == {"foo": [b""]}
    assert parse_qs_bytes(b"foo=bar") == {"foo": [b"bar"]}
    assert parse_qs_bytes(b"foo=bar&foo=baz") == {"foo": [b"bar", b"baz"]}
    assert parse_qs_bytes(b"foo=1&bar=2") == {"foo": [b"1"], "bar": [b"2"]}

# Generated at 2022-06-22 03:34:14.892118
# Unit test for function recursive_unicode
def test_recursive_unicode():
        dict_data = {b"a": b"Hello",b"b": b"World"}
        list_data = [b"Hello",b"World"]
        tuple_data = (b"Hello",b"World")
        recursive_unicode(dict_data)
        recursive_unicode(list_data)
        recursive_unicode(tuple_data)
if __name__ == '__main__':
    test_recursive_unicode()

# This singleton "null" object is used as a sentinel value.
# It is also used as a placeholder for functions that have
# not yet been bound at a module level.
null = object()



# Generated at 2022-06-22 03:34:16.968949
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    parse_qs_bytes("a=1&a=2&b=3", keep_blank_values = False, strict_parsing = False)


# Generated at 2022-06-22 03:34:27.079675
# Unit test for function linkify
def test_linkify():
    assert linkify("http://google.com") == '<a href="http://google.com">http://google.com</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("https://google.com") == '<a href="https://google.com">https://google.com</a>'
    assert linkify("google.com") == 'google.com'
    assert linkify("google.com", require_protocol = True) == 'google.com'

unicode_type = type(None)  # For backwards compatibility



# Generated at 2022-06-22 03:34:32.014664
# Unit test for function squeeze
def test_squeeze():
    assert(squeeze("\t    \x08\r\n") == " ")
    assert(squeeze("   hello  world  ") == "hello world")


_utf8_str = typing.TypeVar("_utf8_str", bound=str)



# Generated at 2022-06-22 03:34:51.848617
# Unit test for function native_str
def test_native_str():
    # Increase coverage of native_str
    assert isinstance(native_str('123'), str)
    assert isinstance(native_str(b'123'), str)

# Generated at 2022-06-22 03:34:53.996834
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#&lt;&gt;&quot;&#39;&amp;') == '&#<>"\'&'
test_xhtml_unescape()



# Generated at 2022-06-22 03:35:04.685279
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == (
        '<a href="http://example.com">http://example.com</a>'
    )
    assert linkify("http://example.com extra") == (
        '<a href="http://example.com">http://example.com</a> extra'
    )
    assert linkify("http://example.com/path/name?query=value") == (
        '<a href="http://example.com/path/name?query=value">'
        "http://example.com/path/name?query=value</a>"
    )
    assert linkify("http://example.com", require_protocol=False) == (
        '<a href="http://example.com">http://example.com</a>'
    )

# Generated at 2022-06-22 03:35:11.569211
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('aa      bb') == 'aa bb'
    assert squeeze('a   b') == 'a b'
    assert squeeze('\n  \n 123 \n') == '123'
    assert squeeze('  \n 123 \n') == '123'
    assert squeeze('\n 123 \n') == '123'
    assert squeeze('\n \n 123 \n') == '123'


_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:35:14.168601
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&amp; &lt; &gt; &quot; &#39;') == '& < > " \''


# Generated at 2022-06-22 03:35:19.826510
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(['123']) == ['123']
    assert recursive_unicode({'a': '123'}) == {'a': '123'}
    assert recursive_unicode(('a',)) == ('a',)
    assert recursive_unicode(b'123') == '123'



# Generated at 2022-06-22 03:35:24.754324
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    s = "A &amp; B &amp;amp; C &#38; D &#x26; E &LT; F &gt; G &QUOT; H &apos; I &#x27; J &Love; K &#123456789; L"
    assert xhtml_unescape(s) == "A & B &amp; C &#38; D &#x26; E < F > G \" H ' I ' J ♥ K &#123456789; L"


# Generated at 2022-06-22 03:35:29.066402
# Unit test for function json_decode
def test_json_decode():
    assert json_decode(bytes("{\"hello\" : \"world\"}", "utf-8")) == {"hello": "world"}
    assert json_decode("{\"hello\" : \"world\"}") == {"hello": "world"}
    assert json_decode(b"{\"hello\" : \"world\"}") == {"hello": "world"}



# Generated at 2022-06-22 03:35:42.022573
# Unit test for function linkify

# Generated at 2022-06-22 03:35:46.047997
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<>&'\"") == "&lt;&gt;&amp;&#39;&quot;"
    assert xhtml_escape("This&That") == "This&amp;That"
#Unit test for function xhtml_unescape

# Generated at 2022-06-22 03:36:02.224253
# Unit test for function xhtml_escape
def test_xhtml_escape():
    print("***** in test_xhtml_escape *****")
    assert xhtml_escape("<<>>&'") == "&lt;&lt;&gt;&gt;&amp;&apos;"

_XHTML_UNESCAPE_ENTITY_RE = re.compile("&(#?)(\d{1,5}|\w{1,8});")



# Generated at 2022-06-22 03:36:10.313697
# Unit test for function linkify
def test_linkify():
    assert linkify("http://www.google.com") == '<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify("www.google.com") == '<a href="http://www.google.com">www.google.com</a>'
    assert linkify("<some_tag class='button'>") == '&lt;some_tag class=\'button\'&gt;'

# Test the function unit test
test_linkify()



# Generated at 2022-06-22 03:36:20.560810
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    r = parse_qs_bytes(u'a=1&b=&c=3', keep_blank_values=True)
    assert r == {u'a': [b'1'], u'b': [b''], u'c': [b'3']}
    r = parse_qs_bytes(u'a=1&b=&c=3', keep_blank_values=False)
    assert r == {u'a': [b'1'], u'c': [b'3']}
    r = parse_qs_bytes(u'a=1;b=2;c=3', keep_blank_values=False)
    assert r == {u'a': [b'1'], u'b': [b'2'], u'c': [b'3']}



# Generated at 2022-06-22 03:36:32.886726
# Unit test for function xhtml_escape
def test_xhtml_escape():
  assert xhtml_escape("<a><b>&\"'</b></a>") == "&lt;a&gt;&lt;b&gt;&amp;&quot;&#39;&lt;/b&gt;&lt;/a&gt;"

_JSON_ESCAPE = re.compile(r"[^\w\$]")
_JSON_ESCAPE_DCT = {
    "\b": r"\b",
    "\f": r"\f",
    "\n": r"\n",
    "\r": r"\r",
    "\t": r"\t",
    "\v": r"\v",
    "'": r"\'",
    '"': r'\"',
    "\\": r"\\",
}

_JSON_ESCAPE_ASCII_

# Generated at 2022-06-22 03:36:40.594774
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print(xhtml_unescape('&#65;&#x41;'))
    print(xhtml_unescape('&amp;&gt;&lt;&quot;'))
    print(xhtml_unescape('&#234234;&#x234234;&quot;'))

# Test
# test_xhtml_unescape()

_BASESTRING_TYPES = (str, bytes)
if typing.TYPE_CHECKING:
    _BASESTRING_TYPES += (bytes, unicode_type)



# Generated at 2022-06-22 03:36:50.885316
# Unit test for function linkify
def test_linkify():
    # Standard forms
    assert linkify(u"http://www.facebook.com/") == '<a href="http://www.facebook.com/">http://www.facebook.com/</a>'
    assert linkify(u"http://www.facebook.com/", shorten=True) == '<a href="http://www.facebook.com/">http://www.facebook.com/</a>'
    assert linkify(u"www.facebook.com") == '<a href="http://www.facebook.com">www.facebook.com</a>'
    assert linkify(u"www.facebook.com", shorten=True) == '<a href="http://www.facebook.com">www.facebook.com</a>'

# Generated at 2022-06-22 03:36:53.264665
# Unit test for function native_str
def test_native_str():
    assert type(native_str("")) is str
    assert type(native_str(b"")) is str
    assert type(native_str(u"")) is str

# Generated at 2022-06-22 03:36:54.483436
# Unit test for function url_escape
def test_url_escape():
    x = url_escape("a")
    y = urllib.parse.quote_plus('a')


# Generated at 2022-06-22 03:37:02.670447
# Unit test for function utf8
def test_utf8():
    assert utf8("a") == b"a"
    assert utf8(b"a") == b"a"
    assert utf8(u"a") == b"a"
    assert utf8(None) is None
    try:
        utf8(1)
        raise Exception("shouldn't have gotten here")
    except:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:37:10.827365
# Unit test for function json_encode
def test_json_encode():
    # Test primitives
    assert json_encode(None) == "null"
    assert json_encode(True) == "true"
    assert json_encode(False) == "false"
    assert json_encode(3.14159) == "3.14159"
    assert json_encode(0) == "0"
    assert json_encode(u"") == ""
    assert json_encode("") == ""
    assert json_encode("foo") == "foo"
    assert json_encode(u"foo") == "foo"
    assert json_encode("foo bar") == "foo bar"
    assert json_encode("f'oo") == "f'oo"
    assert json_encode("<script>") == "<script>"

# Generated at 2022-06-22 03:37:57.084299
# Unit test for function xhtml_escape
def test_xhtml_escape():
    if __name__ == "__main__":
        print(xhtml_escape(b"<script>alert(document.cookie)</script>"))
        # &lt;script&gt;alert(document.cookie)&lt;/script&gt;
test_xhtml_escape()


_JSON_ESCAPE_RE = re.compile(r"[<>&\"\'\\\x00-\x1f\u2028\u2029]")
_JSON_ESCAPE_DICT = {
    "<": "\\u003c",
    ">": "\\u003e",
    "&": "\\u0026",
    '"': "\\u0022",
    "'": "\\u0027",
    "\\": "\\\\",
}
for _ord in range(0x20):
    _JSON_