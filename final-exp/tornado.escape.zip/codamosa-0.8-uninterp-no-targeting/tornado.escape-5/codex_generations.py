

# Generated at 2022-06-22 03:28:42.837800
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    l = [
        (r"&lt;&gt;&amp;&quot;&#39;", "<>&\"'"),
        (r"&lt;&gt;&amp;&quot;&#39;", "<>&\"'"),
        (r"&lt;&#0062;&#x0043;&amp;&quot;&apos;&#x07C;&nbsp;", "<b>C&\"'|\xA0")
    ]
    for (esc, expected) in l:
        assert xhtml_unescape(esc) == expected


# Generated at 2022-06-22 03:28:50.373886
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(
        {'a': b'\xc3\xa9', 'b': ['\xe2\x82\xac'], 'c': (b'\xca\xbc', b'\xe2\x82\xac')}) == {'a': '\u00e9', 'b': ['\u20ac'], 'c': ('\u01bc', '\u20ac')}


# Generated at 2022-06-22 03:28:51.396143
# Unit test for function json_encode
def test_json_encode():
    json_encode(None)



# Generated at 2022-06-22 03:28:55.702723
# Unit test for function native_str
def test_native_str():
    assert native_str('abcd') == 'abcd'
    assert native_str(bytearray(b'abcd')) == 'abcd'
    assert native_str(bytes([97, 98, 99, 100])) == 'abcd'
    assert native_str(b'abcd') == 'abcd'



# Generated at 2022-06-22 03:29:07.148411
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape(r"&amp;&gt;&quot;&#39;") == "&>\"'"
    assert xhtml_unescape('&lt;div&gt;&lt;class="test"&gt;&lt;/div&gt;') == \
        '<div><class="test"></div>'
    assert xhtml_unescape(r'&#x27;')  == "&#x27;"
    assert xhtml_unescape(r"&#39;") == "&#39;"
    assert xhtml_unescape(r"&#x27;&#39;") == "&#x27;&#39;"
    assert xhtml_unescape(r"&#39;&#x27;") == "&#39;&#x27;"


# Generated at 2022-06-22 03:29:11.805305
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print(xhtml_unescape("&amp;"))
    print(xhtml_unescape("&amp;&lt;&gt;&quot;&apos;"))


_BASESTRING_TYPES = (str, unicode_type)



# Generated at 2022-06-22 03:29:16.794030
# Unit test for function recursive_unicode
def test_recursive_unicode():
    value = {u"b": u"\u00fc", u"a": u"\u00e4"}
    b = {b"b": b"\xc3\xbc".decode("utf8"), b"a": b"\xc3\xa4".decode("utf8")}
    assert recursive_unicode(b) == value



# Generated at 2022-06-22 03:29:29.264959
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=b") == {"a": [b"b"]}
    assert parse_qs_bytes(b"a=b&a=c") == {"a": [b"b", b"c"]}
    assert parse_qs_bytes(b"a=b&a=c&d=e") == {"a": [b"b", b"c"], "d": [b"e"]}
    assert parse_qs_bytes(b"a=a%20b") == {"a": [b"a b"]}
    assert parse_qs_bytes(b"a=a%20b&a=c") == {"a": [b"a b", b"c"]}

# Generated at 2022-06-22 03:29:31.909273
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = "a=%C2%B5"
    a = parse_qs_bytes(qs)
    assert(a ==  {"a": [b"\xc2\xb5"]})

test_parse_qs_bytes()



# Generated at 2022-06-22 03:29:44.061850
# Unit test for function linkify
def test_linkify():
    # Test that stray <'s and >'s are escaped
    assert linkify(u(">"), shorten=True) == u"&gt;"
    assert linkify(u("<"), shorten=True) == u"&lt;"
    assert linkify(u("<>"), shorten=True) == u"&lt;&gt;"
    # no protocol
    assert linkify(u("www.facebook.com"), shorten=True) == u'<a href="http://www.facebook.com">www.facebook.com</a>'
    assert linkify(u("http://facebook.com"), shorten=True) == u'<a href="http://facebook.com">facebook.com</a>'

# Generated at 2022-06-22 03:29:54.269975
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<h1>Hello, world!') == '&lt;h1&gt;Hello, world!'
test_xhtml_escape()



# Generated at 2022-06-22 03:29:56.650729
# Unit test for function json_encode
def test_json_encode():
    assert (b'<\\/script>' == json_encode(u'</script>').encode("utf-8"))


# Generated at 2022-06-22 03:30:06.464412
# Unit test for function native_str
def test_native_str():
    s = '\xe4\xb8\xad\xe6\x96\x87'
    assert native_str(s) == s
    s = u'\u4e2d\u6587'
    assert native_str(s) == s
    s = b'\xe4\xb8\xad\xe6\x96\x87'
    assert native_str(s) == s
    from io import BytesIO
    s = BytesIO(b'\xe4\xb8\xad\xe6\x96\x87')
    assert native_str(s.read()) == s.read().decode('utf-8')



# Generated at 2022-06-22 03:30:18.685708
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'%E7%89%B9%E8%81%94%E5%BE%AE%E4%BF%A1%E5%B9%BF%E5%91%8A') == b'\xe7\x89\xb9\xe8\x81\x94\xe5\xbe\xae\xe4\xbf\xa1\xe5\xb9\xbf\xe5\x91\x8a'

# Generated at 2022-06-22 03:30:20.963148
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("A string with spaces") == 'A+string+with+spaces'



# Generated at 2022-06-22 03:30:32.495008
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape(b"%2B")
    url_unescape("%2B", plus=False)
    url_unescape(b"%2B", encoding="utf-8", plus=False)
    url_unescape(b"%2B", encoding="latin1", plus=False)
    url_unescape(b"%2B", plus=True)
    url_unescape("%2B", encoding="utf-8", plus=True)
    url_unescape("%2B", encoding="latin1", plus=True)
    url_unescape("%2B", encoding=None, plus=False)
    url_unescape(b"%2B", encoding=None, plus=True)
    url_unescape("%2B", encoding=None, plus=False)

# Generated at 2022-06-22 03:30:44.977808
# Unit test for function linkify
def test_linkify():
    print(linkify(text="abc",extra_params= "rel=1",require_protocol=False,permitted_protocols=["http", "https"]))
    print(linkify(text="abc",extra_params= "rel=1",require_protocol=False,permitted_protocols=["http", "https"]))
    print(linkify(text="abc",extra_params= "rel=1",require_protocol=False,permitted_protocols=["http", "https"]))
    print(linkify(text="abc",extra_params= "rel=1",require_protocol=False,permitted_protocols=["http", "https"]))

# Generated at 2022-06-22 03:30:49.401840
# Unit test for function native_str
def test_native_str():
    assert to_unicode(b"abc") == "abc"
    assert to_unicode(u"abc") == u"abc"
    assert to_unicode(None) is None

    try:
        to_unicode(object())
        assert False, "to_unicode(object()) didn't throw"
    except TypeError:
        pass



# Generated at 2022-06-22 03:30:50.808220
# Unit test for function json_encode
def test_json_encode():
    string = "</"
    assert json_encode(string) == "\"<\\\\/\""



# Generated at 2022-06-22 03:30:52.906293
# Unit test for function utf8
def test_utf8():
    x = None
    x = utf8(x)

    x = ""
    x = utf8(x)

    x = "s"
    x = utf8(x)



# Generated at 2022-06-22 03:31:08.842549
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert recursive_unicode(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert recursive_unicode({'a': 'b', 'c': 'd'}) == {'a': 'b', 'c': 'd'}
    assert recursive_unicode(b'abc') == u'abc'
    assert recursive_unicode('abc') == u'abc'
#
test_recursive_unicode()


# TODO: the following two functions could probably be unified


# Generated at 2022-06-22 03:31:15.336133
# Unit test for function url_escape
def test_url_escape():
    url_escape("abcde")
    url_escape(b"abcde")
    url_escape("你好")

# Generated at 2022-06-22 03:31:24.633491
# Unit test for function linkify
def test_linkify():
    # Test linkify function.
    text = "Hello http://www.google.com, and http://localhost:8888"
    assert linkify(text) == u'Hello <a href="http://www.google.com">http://www.google.com</a>, ' \
                            u'and <a href="http://localhost:8888">http://localhost:8888</a>'
    # Test linkify function, with extra params.
    assert linkify(text, extra_params='target="_blank"') == u'Hello <a href="http://www.google.com" target="_blank">http://www.google.com</a>, ' \
                                                             u'and <a href="http://localhost:8888" target="_blank">http://localhost:8888</a>'
    # Test linkify function with require_

# Generated at 2022-06-22 03:31:27.954510
# Unit test for function squeeze
def test_squeeze():
    # Arrange
    input = "aaa bbb ccc"

    # Action
    actual = squeeze(input)

    # Assert
    expected = "aaa bbb ccc"
    assert actual == expected


# Generated at 2022-06-22 03:31:32.235492
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("This   is   a    test") == "This is a test"
    assert squeeze("\t This  is a test") == " This is a test"
    assert squeeze("\t\r\n\fThis\tis\tthe\r\ntest") == "This is the test"



# Generated at 2022-06-22 03:31:41.494486
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"key": "value"}) == '{"key": "value"}'
    assert json_encode({"key": "value"}) == '{"key": "value"}'
    assert json_encode({"key": "value"}) == '{"key": "value"}'
    assert json_encode({"key": "value"}) == '{"key": "value"}'


# py2 json_encode()
# def json_encode(value):
#     return json.dumps(value)



# Generated at 2022-06-22 03:31:45.775893
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes("foo=bar") == {b"foo": [b"bar"]}
    assert parse_qs_bytes("foo=bar&foo=baz", keep_blank_values=True) == {
        b"foo": [b"bar", b"baz"]
    }



# Generated at 2022-06-22 03:31:52.106810
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    test_dict = {}
    test_dict['A'] = [b'A']
    test_dict['BB'] = [b'BB']
    test_dict['CCC'] = [b'CCC']
    assert parse_qs_bytes(b'A=A&BB=BB&CCC=CCC') == test_dict

# Generated at 2022-06-22 03:31:56.991695
# Unit test for function linkify
def test_linkify():
    print(linkify('<a href="http://www.facebook.com/" target="_blank">www.facebook.com</a>',permitted_protocols=["http", "ftp",
      "mailto"]))
# test_linkify()


_FIND_HTML_TITLE_RE = re.compile(r"<title>(.*?)</title>", re.I | re.S)



# Generated at 2022-06-22 03:31:58.193865
# Unit test for function url_escape
def test_url_escape():
    url_escape("/products/%20", False)



# Generated at 2022-06-22 03:32:07.625191
# Unit test for function url_escape
def test_url_escape():
    escaped = url_escape('Hello world')
    if escaped != 'Hello+world':
        print(escaped)
    assert escaped == 'Hello+world'
test_url_escape()


# Generated at 2022-06-22 03:32:08.991283
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("A   B") == "A B"



# Generated at 2022-06-22 03:32:12.521929
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("&<>'\"") == "&amp;&lt;&gt;&#39;&quot;"
    assert xhtml_escape("foo") == "foo"
test_xhtml_escape()


# to_unicode was previously named _unicode not because it was private,
# but to avoid conflicts with the built-in unicode() function/type

# Generated at 2022-06-22 03:32:17.788505
# Unit test for function native_str
def test_native_str():
    if str == bytes:
        assert native_str(b'abc') == b'abc'
        assert native_str(u'abc') == b'abc'
        assert native_str('abc') == b'abc'
    else:
        assert native_str(b'abc') == 'abc'
        assert native_str(u'abc') == u'abc'
        assert native_str('abc') == 'abc'
_BASESTRING_TYPES = (unicode_type, bytes)



# Generated at 2022-06-22 03:32:23.817679
# Unit test for function linkify
def test_linkify():
    assert linkify("I get email@example.com")=="I get <a href=\"mailto:email@example.com\">email@example.com</a>"
    assert linkify("http://example.com/")=="<a href=\"http://example.com/\">http://example.com/</a>"

test_linkify()



# Generated at 2022-06-22 03:32:32.240737
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    test_string = 'test=test&test2=test2'
    result = parse_qs_bytes(test_string)
    # TODO: test for expected result
    # print(result)
    assert len(result) == 2
    assert 'test' in result.keys()
    assert 'test2' in result.keys()
    assert len(result['test']) == 1
    assert len(result['test2']) == 1
    assert result['test'][0] == b'test'
    assert result['test2'][0] == b'test2'

# parse_qsl is currently not supported because it's trickier than parse_qs
# See https://github.com/tornadoweb/tornado/issues/750

# The encoding used for quoted-printable.
# Per RFC 1521, this should be us-

# Generated at 2022-06-22 03:32:42.137391
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('spam') == 'spam'
    assert url_escape('spam&eggs') == 'spam%26eggs'
    assert url_escape('spam eggs') == 'spam+eggs'
    assert url_escape('spam eggs', plus=False) == 'spam%20eggs'
    assert url_escape('/:@&?+') == '%2F%3A%40%26%3F%2B'
    assert url_escape('/:@&?+', plus=False) == '%2F%3A%40%26%3F%2B'
    assert url_escape('meh') == 'meh'
    assert url_escape('meh', plus=False) == 'meh'


# Generated at 2022-06-22 03:32:45.121440
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<script>alert(0);</script>') == '&lt;script&gt;alert(0);&lt;/script&gt;'


# Generated at 2022-06-22 03:32:47.111445
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape('foo%2B')
    # no error


# Generated at 2022-06-22 03:32:59.634021
# Unit test for function native_str
def test_native_str():
    method_name = 'native_str'
    def test_native_str(self):
        # It would be nice to be able to use self.assertRaises here,
        # but it does not work with native types.
        try:
            # hardcode the string before calling the method so that
            # that char '\x92' will raise UnicodeDecodeError when encoding
            # but not decoding
            native_str(u'\xe8')
            self.fail("native_str did not raise a UnicodeDecodeError")
        except UnicodeDecodeError:
            pass

# Generated at 2022-06-22 03:33:09.224469
# Unit test for function json_decode
def test_json_decode():
    assert json_decode("{}") == {}
    assert json_decode("[]") == []
    assert json_decode("true") is True
    assert json_decode("null") is None

_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:33:20.860948
# Unit test for function linkify
def test_linkify():
    assert "Hello " in linkify("Hello www.facebook.com")
    assert "Hello " in linkify("Hello www.facebook.com", require_protocol=False)
    assert "Hello " not in linkify("Hello www.facebook.com", require_protocol=True)
    assert "Hello " in linkify("Hello http://www.facebook.com")
    assert "Hello " in linkify("Hello http://www.facebook.com/")
    assert "Hello " not in linkify("Hello http://www.facebook.com/", shorten=True)
    long_url = "http://www.facebook.com/note.php?note_id=43813138919&ref=mf"
    assert "Hello " not in linkify("Hello " + long_url)

# Generated at 2022-06-22 03:33:27.133300
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("Hello World!") == "Hello World!"
    assert squeeze("Hello  World!") == "Hello World!"
    assert squeeze(" Hello World!") == "Hello World!"
    assert squeeze("Hello World! ") == "Hello World!"
    assert squeeze("     Hello  World!   ") == "Hello World!"
    assert squeeze(" \n \t\rHello\t\nWorld! \n\n\n   ") == "Hello World!"


# Generated at 2022-06-22 03:33:38.680500
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"http%3A%2F%2Fwww.abc.com") == "http://www.abc.com"
    assert url_unescape(b"http%3A%2F%2Fwww.abc.com", encoding=None) == b"http://www.abc.com"
    # encoding=None, plus=False
    assert url_unescape(b"http%3A%2F%2Fwww.abc.com", encoding=None, plus=False) ==  b"http://www.abc.com"
    # encoding="utf-8", plus=False
    assert url_unescape(b"http%3A%2F%2Fwww.abc.com", "utf-8", False) == "http://www.abc.com"
    # encoding=None, plus=True
   

# Generated at 2022-06-22 03:33:45.616053
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"key": "valÜe"}) == {"key": "valÜe"}
    assert recursive_unicode(("key", "valÜe")) == ("key", "valÜe")
    assert recursive_unicode(["key", "valÜe"]) == ["key", "valÜe"]
    assert recursive_unicode("value") == "value"
    assert recursive_unicode(b"val\xc3\xbc") == "valÜ"



# Generated at 2022-06-22 03:33:58.154791
# Unit test for function linkify
def test_linkify():
    a = "Hello www.tornadoweb.org!"
    b = linkify("Hello www.tornadoweb.org!")
    assert(b == "Hello <a href=\"http://www.tornadoweb.org\">www.tornadoweb.org</a>!")
    b = linkify("Hello http://www.tornadoweb.org!")
    assert(b == "Hello <a href=\"http://www.tornadoweb.org\">http://www.tornadoweb.org</a>!")
    b = linkify("Hello https://www.tornadoweb.org!")
    assert(b == "Hello <a href=\"https://www.tornadoweb.org\">https://www.tornadoweb.org</a>!")
    b = linkify("Hello https://www.tornadoweb.org/en/stable/!")


# Generated at 2022-06-22 03:34:03.007845
# Unit test for function json_encode
def test_json_encode():
    from tornado.escape import json_encode
    json_data=json_encode(
        {"pk": 149, "model": "blog.blog", "fields": {"content": "test"}}
    )
    print(json_data)
#test_json_encode()

# Generated at 2022-06-22 03:34:07.049917
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"html": "<html>"}) == '{"html": "<html>"}'
    assert not json_encode({"html": "<html>"}) == '{"html": "<html>"}'



# Generated at 2022-06-22 03:34:09.057667
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a  b") == "a b"
    assert squeeze("   a    b     ") == "a b"



# Generated at 2022-06-22 03:34:18.405022
# Unit test for function json_encode
def test_json_encode():
    import io
    import tornado.testing
    data1 = {"foo": "bar", "baz": None}
    data2 = {"foo": "bar", "baz": None}
    data3 = {"foo": "bar", "baz": None}
    data4 = {"foo": "bar", "baz": None}

    class TestJSON(tornado.testing.AsyncTestCase):
        def test_json_decode(self):
            self.assertEqual(json.loads(json_encode(data1)), data1)
            self.assertEqual(json.loads(json_encode(data2)), data2)
            with io.StringIO() as f:
                f.write(json_encode(data3))
                f.seek(0)

# Generated at 2022-06-22 03:34:30.354865
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    result = parse_qs_bytes('name=tom&age=18'.encode('utf-8'))
    print(result)

test_parse_qs_bytes()


# Generated at 2022-06-22 03:34:38.973177
# Unit test for function linkify
def test_linkify():
    assert linkify("Hello http://tornadoweb.org!") == \
           u'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

    assert linkify(u"Hello http://tornadoweb.org!", shorten=True) == \
           u'Hello <a href="http://tornadoweb.org">http://tornadoweb.org</a>!'

    assert linkify(u"Hello http://www.tornadoweb.org!", shorten=True) == \
           u'Hello <a href="http://www.tornadoweb.org">http://www.tornadoweb.org</a>!'


# Generated at 2022-06-22 03:34:48.906298
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    a = {'a':[b'1',b'2'], 'b':[b'3'],'c':[b'4'], 'd':[b'5', b'6']}
    b = parse_qs_bytes('a=1&a=2&b=3&c=4&d=5&d=6')
    assert a == b
    b = parse_qs_bytes('a=1&a=2&b=3&c=4&d=5&d=6',strict_parsing=True)
    assert a == b
    b = parse_qs_bytes('a=1&a=2&b=3&c=4&d=5&d=6',keep_blank_values=True)
    assert a == b

# Generated at 2022-06-22 03:34:53.895369
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('http://www.google.com') == urllib.parse.quote('http://www.google.com')
    assert url_escape('http://www.google.com',plus=False) == urllib.parse.quote('http://www.google.com',safe='')
    assert url_escape('http://www.google.com',plus=True) == urllib.parse.quote_plus('http://www.google.com')
#test_url_escape()



# Generated at 2022-06-22 03:35:04.661546
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<") == "&lt;"
    assert xhtml_escape(">") == "&gt;"
    assert xhtml_escape("my value \"") == "my value &quot;"
    assert xhtml_escape(">>") == "&gt;&gt;"

_JSON_ESCAPE_RE = re.compile(r"[\x00-\x1f\\\"\b\f\n\r\t]")

# Generated at 2022-06-22 03:35:13.941033
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    b = {b'key': [b'value']}
    assert b == parse_qs_bytes(b'key=value')
    assert b == parse_qs_bytes(b'key=value', True)
    assert b == parse_qs_bytes(b'key=value', False)
    assert b == parse_qs_bytes(b'key=value', False, True)
    assert b == parse_qs_bytes(b'key=value', False, False)
    assert b == parse_qs_bytes(b'key=value', True, True)
    assert b == parse_qs_bytes(b'key=value', True, False)



# Generated at 2022-06-22 03:35:19.590936
# Unit test for function json_encode
def test_json_encode():
    result = json_encode({'foo': '</script>'})
    assert result == '{"foo": "<\\/script>"}'

# json_encode_pretty is only inserted if simplejson is available.
# See the docstring for json_encode_pretty in template.py.

# Generated at 2022-06-22 03:35:28.971363
# Unit test for function recursive_unicode
def test_recursive_unicode():
    x = {u"ascii": "ascii_value", "byte": b"byte_value", u"unicode": u"unicode_value"}
    y = recursive_unicode(x)
    assert y[u"ascii"] == u"ascii_value"
    assert y[u"byte"] == u"byte_value"
    assert y[u"unicode"] == u"unicode_value"
    x = ["ascii", b"byte", u"unicode"]
    y = recursive_unicode(x)
    assert y[0] == u"ascii"
    assert y[1] == u"byte"
    assert y[2] == u"unicode"
    x = ("ascii", b"byte", u"unicode")

# Generated at 2022-06-22 03:35:31.362942
# Unit test for function native_str
def test_native_str():
    pass


_BASESTRING_TYPES = (unicode_type, bytes, type(None))



# Generated at 2022-06-22 03:35:33.671354
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&amp;&lt;&gt;&quot;&#39;') == '&<>"\''



# Generated at 2022-06-22 03:35:42.406917
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;&gt;&amp;&#39;&quot;") == "<>&'\""


# Generated at 2022-06-22 03:35:50.809068
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b"a=1&a=2&b=3") == {"a": [b"1", b"2"], "b": [b"3"]}
    assert parse_qs_bytes(b"a=1&a=2&b=3", keep_blank_values=True) == {
        "a": [b"1", b"2"],
        "b": [b"3"],
    }
    assert parse_qs_bytes(b"a=1&a=2&b=3", strict_parsing=True) == {
        "a": [b"1", b"2"],
        "b": [b"3"],
    }

# Generated at 2022-06-22 03:35:53.657560
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('    a   bc  def  g') == 'a bc def g'
    assert squeeze('abc') == 'abc'
    assert squeeze('') == ''


# Generated at 2022-06-22 03:36:04.258596
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("foo+bar") == "foo bar"
    assert url_unescape("foo%2Bbar") == "foo+bar"
    assert url_unescape("foo%20bar", encoding=None) == b"foo bar"
    assert url_unescape("foo%20bar") == "foo bar"
    assert url_unescape(b"foo%2Bbar", encoding=None) == b"foo+bar"
    assert url_unescape(b"foo%20bar", encoding=None) == b"foo bar"
test_url_unescape = (
    False  # pytest: disable=unused-argument
)  # type: ignore



# Generated at 2022-06-22 03:36:07.741858
# Unit test for function json_encode
def test_json_encode():
    a = json_encode({'a': 'b', 'c': '</script>'})
    assert a == '{"a": "b", "c": "<\\/script>"}'



# Generated at 2022-06-22 03:36:11.384691
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({'foo': [1, 2, {'bar': 'baz'}]}) == '{"foo": [1, 2, {"bar": "baz"}]}'

_JSON_DECODE_ERROR = None



# Generated at 2022-06-22 03:36:13.661411
# Unit test for function json_decode
def test_json_decode():
    a = json_decode(json.dumps(1))
    print(a)


# Generated at 2022-06-22 03:36:20.836447
# Unit test for function json_decode
def test_json_decode():
    json_decode("{}")
    json_decode("{}".encode())
    try:
        json_decode(1)
        raise RuntimeError("Expected a 'TypeError' but not.")
    except TypeError:
        pass


# base64.b64encode/base64.b64decode accepts bytes and bytearray objects
# without issue, but base64.standard_b64encode/base64.standard_b64decode
# require str.  This function closes the gap, allowing all four functions
# to work with either bytes or str.

# Generated at 2022-06-22 03:36:29.167895
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    result = xhtml_unescape("Smith&#39;s")
    assert result == "Smith's"
    result = xhtml_unescape("Smith&#39")
    assert result == "Smith&#39"

_BASESTRING_TYPE = type("")
if typing.TYPE_CHECKING:
    _to_basestring_target_type = Union[str, bytes]
else:
    _to_basestring_target_type = None


# Generated at 2022-06-22 03:36:39.775426
# Unit test for function linkify
def test_linkify():
    assert linkify("http://foo.com") == '<a href="http://foo.com">http://foo.com</a>'
    assert linkify("foo@foo.com") == '<a href="mailto:foo@foo.com">foo@foo.com</a>'
    assert linkify("foo@foo.com", extra_params='class="bar"') == '<a href="mailto:foo@foo.com" class="bar">foo@foo.com</a>'
    assert linkify("foo@foo.com", extra_params=lambda x: 'class="bar"') == '<a href="mailto:foo@foo.com" class="bar">foo@foo.com</a>'
    assert linkify("http://foo.com/?foo=bar&baz=blah#boo", shorten=True)

# Generated at 2022-06-22 03:36:51.621640
# Unit test for function linkify
def test_linkify():
    text = "This is link http://www.google.com"
    text = linkify(text)
    print(text)
    assert text == "This is link <a href=\"http://www.google.com\">http://www.google.com</a>"


_EMAIL_RE = re.compile(
    to_unicode(
        r"""\b[\w.%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}\b"""  # noqa: E501
    )
)



# Generated at 2022-06-22 03:36:55.329296
# Unit test for function utf8
def test_utf8():
    assert utf8(None) is None
    assert utf8(u'hi') == b'hi'
    assert utf8(u'hi'.encode('utf-8')) == b'hi'
    try:
        utf8(5)
        assert False
    except TypeError:
        pass
    print("Passed all tests")
test_utf8()



# Generated at 2022-06-22 03:36:59.626525
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    data = parse_qs_bytes(b'encoding=latin1&errors=strict')
    assert data[b'encoding'][0] == b'latin1'
    assert data[b'errors'][0] == b'strict'
test_parse_qs_bytes()

_UTF8_TYPES = (bytes, type(None))



# Generated at 2022-06-22 03:37:04.117339
# Unit test for function url_unescape
def test_url_unescape():
    input = 'helloworld%2B'
    output = url_unescape(input, plus=True)
    assert output == 'helloworld+'


# Generated at 2022-06-22 03:37:06.105615
# Unit test for function squeeze
def test_squeeze():
    text = "asdf  aasdf"
    result = squeeze(text)
    print("result is ", result)


# Generated at 2022-06-22 03:37:11.227622
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&amp; &lt; &gt; &quot; &#39;") == "& < > \" '"
    assert xhtml_unescape("&#33; &#46; &#6d; &#x6d;") == "! . m m"
    assert xhtml_unescape("&#x6d") == "m"
    assert xhtml_unescape("&#x6d;") == "m"
    assert xhtml_unescape("&gt;") == ">"
    assert xhtml_unescape("&amp;") == "&"

# Generated at 2022-06-22 03:37:15.816103
# Unit test for function utf8
def test_utf8():
    encoding = utf8("abc")
    assert isinstance(encoding, bytes)
    assert encoding == b"abc"
    assert utf8(b"abc") == b"abc"
    assert utf8(None) is None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:37:27.669654
# Unit test for function recursive_unicode
def test_recursive_unicode():
    data = dict(
        string=b"foo",
        dict=dict(a=1, b=2),
        list=[1, 2, 3],
        tuple=(1, 2, 3),
        int=42,
        float=3.14,
    )
    recursive_unicode(data)
    assert data == dict(
        string="foo",
        dict=dict(a=1, b=2),
        list=[1, 2, 3],
        tuple=(1, 2, 3),
        int=42,
        float=3.14,
    )


# Fake byte literal support:  In python 2.6+, you can say b"foo" to get
# a byte literal (str in 2.x, bytes in 3.x).  There's no way to do this
# in a way that supports 2.5, though

# Generated at 2022-06-22 03:37:38.024070
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print("\n=== test_xhtml_unescape ===")
    @print_args
    def t(s: str, expected: str):
        actual: str = xhtml_unescape(s)
        print("actual = ", actual)
        assert expected == actual
    t("&lt;&gt;&nbsp;&amp;&#39;&#xA9;", "<>\u00A0&'\u00A9")
    t("&#999999999999;", "&#999999999999;")
    t("&missing;", "&missing;")
    t("&#45;&#45;&#45;", "&#45;&#45;&#45;")
test_xhtml_unescape()

# @print_args

# Generated at 2022-06-22 03:37:50.781222
# Unit test for function recursive_unicode
def test_recursive_unicode():
    b1 = b'\xe4\xbd\xa0\xe5\xa5\xbd' # 这是一个中文 
    u1 = b1.decode()
    assert recursive_unicode(u1) == u1
    assert recursive_unicode(b1) == u1
    assert recursive_unicode("abc") == "abc"
    assert recursive_unicode("abc") == "abc"
    dict1 = {b1: "abcd", "ab": b1}
    assert recursive_unicode(dict1) == {u1: "abcd", "ab": u1}
    list1 = [b1, u1, "abc"]
    assert recursive_unicode(list1) == [u1, u1, "abc"]