

# Generated at 2022-06-22 03:28:47.625589
# Unit test for function url_escape
def test_url_escape():
    # type: () -> None
    test_urls = [
        [
            "a",
            "a",
            "a",
        ],
        [
            "a b",
            "a+b",
            "a b",
        ],
        [
            "a+b",
            "a%2Bb",
            "a+b",
        ],
        [
            "\x00",
            "%00",
            "%00",
        ],
        [
            "中文",
            "%E4%B8%AD%E6%96%87",
            "%E4%B8%AD%E6%96%87",
        ],
    ]

    for val, plus, non_plus in test_urls:
        assert url_escape(val) == plus

# Generated at 2022-06-22 03:28:52.390103
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('>&<"\'') == "&gt;&amp;&lt;&quot;&#39;"

# Make it an alias to escape
escape = xhtml_escape

# TODO: deprecate and move to tornado.util

# Generated at 2022-06-22 03:28:54.530680
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    value = 'I &#39;heart&#39; you'
    assert xhtml_unescape(value) == "I 'heart' you"

# Generated at 2022-06-22 03:28:59.828591
# Unit test for function native_str
def test_native_str():
    assert native_str('a') == b'a'
    assert native_str(b'a') == b'a'
    assert native_str(b'\x80') == b'\xc2\x80'
    assert native_str(u'\u20ac') == b'\xe2\x82\xac'
    assert native_str(u'\uc6b0', 'euc-kr') == b'\xa1\xbe'
    assert native_str(u'\u20ac', 'utf-16') == b'\xff\xfee\x02'
    assert native_str(u'\u20ac', 'utf-16-le') == b'e\x02\xff\xfe'


# Generated at 2022-06-22 03:29:01.215676
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print(xhtml_unescape('&amp;'))


# Generated at 2022-06-22 03:29:06.571928
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"foo": [b"bar", b"baz"]}) == {"foo": ["bar", "baz"]}
    assert recursive_unicode(u"foo") == u"foo"
    assert recursive_unicode(1) == 1
    assert recursive_unicode([b"bar", 1]) == ["bar", 1]



# Generated at 2022-06-22 03:29:14.044817
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs1 = b"a=1&b=2"
    qs2 = b"a=b&a=c"
    expected1 = {"a": [b"1"], "b": [b"2"]}
    expected2 = {"a": [b"b", b"c"]}
    assert expected1 == parse_qs_bytes(qs1)
    assert expected2 == parse_qs_bytes(qs2)



# Generated at 2022-06-22 03:29:16.102991
# Unit test for function json_decode
def test_json_decode():
    test_dict: Dict[str,Any] = {}
    test_dict["item1"] = "some string"
    test_dict["item2"] = [1,2,3]
    test_json: str = json.dumps(test_dict)
    assert json_decode(test_json) == test_dict
test_json_decode()



# Generated at 2022-06-22 03:29:16.657408
# Unit test for function squeeze
def test_squeeze():
	pass



# Generated at 2022-06-22 03:29:25.718905
# Unit test for function utf8
def test_utf8():
    assert utf8(u"abc") == b"abc"
    assert utf8(u"\u2603") == b"\xe2\x98\x83"
    assert utf8(None) == None
    assert utf8(b"abc") == b"abc"
    try:
        utf8(5)
        assert False
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:29:46.751422
# Unit test for function json_encode
def test_json_encode():
    json_encode("</script>")



# Generated at 2022-06-22 03:29:58.657524
# Unit test for function utf8
def test_utf8():
    data = {
        "": "",
        "a": b"a",
        # This is a character that takes 3 bytes in utf-8
        "\u20ac": b"\xe2\x82\xac",
        # This is a character that takes 4 bytes in utf-8
        "\U0001f4a9": b"\xf0\x9f\x92\xa9",
        # None translates to None
        None: None,
    }
    for decoded, encoded in data.items():
        assert utf8(decoded) == encoded


# Unit tests for function test_utf8
if __name__ == "__main__":
    test_utf8()



# Generated at 2022-06-22 03:30:06.289244
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = "a%24b=1&%EF%BC%88%EF%BC%89=%EF%BC%8C&%EF%BC%8D=3"
    result = parse_qs_bytes(qs)
    assert result["a$b"] == [b"1"]

# Generated at 2022-06-22 03:30:08.060674
# Unit test for function url_escape
def test_url_escape():
    a = 'wwww.baidu.com'
    print(url_escape(a))


# Generated at 2022-06-22 03:30:13.869182
# Unit test for function json_encode
def test_json_encode():
    x = {'a':1, 'b':2, 'c':3}
    result = json_encode(x)
    assert result == '{"a": 1, "b": 2, "c": 3}', result

# Generated at 2022-06-22 03:30:22.657336
# Unit test for function url_escape
def test_url_escape():
    assert url_escape('test') == urllib.parse.quote('test')
    assert url_escape('test', True) == urllib.parse.quote_plus('test')
    assert url_escape('test', False) == urllib.parse.quote('test')
    assert url_escape('/path/to/file') == urllib.parse.quote('/path/to/file')
    assert url_escape('/path/to/file', True) == urllib.parse.quote_plus('/path/to/file')
    assert url_escape('/path/to/file', False) == urllib.parse.quote('/path/to/file')



# Generated at 2022-06-22 03:30:26.211345
# Unit test for function native_str
def test_native_str():
    assert native_str('\u00bc') == '\xbc'
    assert native_str('\u00bc', 'ascii') == '¼'



# Generated at 2022-06-22 03:30:30.803423
# Unit test for function json_decode
def test_json_decode():
    d = {"a": 1, "b": 2, "c": 3}
    d_repr = repr(d)
    assert json_decode(d_repr) == d
    assert json_decode(d_repr.encode()) == d

# Generated at 2022-06-22 03:30:32.728159
# Unit test for function url_escape
def test_url_escape():
    a = url_escape("http://google.com")
    print(a)

test_url_escape()



# Generated at 2022-06-22 03:30:37.492504
# Unit test for function squeeze
def test_squeeze():
    a = 'a  b'
    b = squeeze(a)
    print(b)
    with open('/Users/zhengguang/PycharmProjects/PyWeb/test_squeeze') as f:
        print(f.read())

# test_squeeze()



# Generated at 2022-06-22 03:31:20.316885
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("&<>'\"") == "&amp;&lt;&gt;&#39;&quot;"

# xhtml_escape = string.Template("$value").substitute

_XML_ESCAPE_RE = re.compile("[&<>\"]")
_XML_ESCAPE_DICT = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
}



# Generated at 2022-06-22 03:31:27.626993
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<p>&</p>') == '&lt;p&gt;&amp;&lt;/p&gt;'
    assert xhtml_escape('a"b') == 'a&quot;b'
    assert xhtml_escape("a'b") == "a&#39;b"
    assert xhtml_escape(123) == '123'



# Generated at 2022-06-22 03:31:33.246190
# Unit test for function url_escape
def test_url_escape():
    try:
        test_url = "http://blog.kubernetes.io/"
        url_encoded = url_escape(test_url)
        if url_encoded == "http://blog.kubernetes.io/":
            print("url_escape is tested successfully")
            return True
        else:
            raise TypeError("Test failed")
    except:
        raise TypeError("Test failed")


# Generated at 2022-06-22 03:31:45.358119
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<htmlstuff>") == "&lt;htmlstuff&gt"
    with pytest.raises(KeyError) as exception_info:
        _XHTML_ESCAPE_DICT['&']
    assert exception_info.value.args[0] == '&'

_JSON_ESCAPE = {ord("&"): "\\u0026", ord("<"): "\\u003c", ord(">"): "\\u003e"}
_JSON_ESCAPE_ASCII = {ord("&"): "\\u0026", ord("<"): "\\u003c", ord(">"): "\\u003e"}

# Generated at 2022-06-22 03:31:49.977356
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    query_string = b"a=1&b=2&c=3"
    result = parse_qs_bytes(query_string)
    assert result == {'a': [b'1'], 'b': [b'2'], 'c': [b'3']}



# Generated at 2022-06-22 03:31:51.773319
# Unit test for function url_unescape
def test_url_unescape():
    pass



# Generated at 2022-06-22 03:31:53.525700
# Unit test for function json_decode
def test_json_decode():
    print (json_decode('{"name":"john", "age": 30}'))

# Generated at 2022-06-22 03:31:58.231859
# Unit test for function json_decode
def test_json_decode():
    json_str = '{"a":1,"b":2,"c":3,"d":4,"e":5}'
    json_str_bytes = b'{"a":1,"b":2,"c":3,"d":4,"e":5}'
    print(json_str_bytes[0])
    print(json_decode(json_str_bytes))

test_json_decode()


# Generated at 2022-06-22 03:32:03.149492
# Unit test for function recursive_unicode
def test_recursive_unicode():
    a = {'a': 1, 'b': 2}
    assert recursive_unicode(a) == {'a': 1, 'b': 2}
    b = [1.2, 11.22, 111.222]
    assert recursive_unicode(b) == [1.2, 11.22, 111.222]
    c = (1, 2)
    assert recursive_unicode(c) == (1, 2)
    d = b'0110'
    assert recursive_unicode(d) == '0110'
    e = 11
    assert recursive_unicode(e) == 11



# Generated at 2022-06-22 03:32:12.680794
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = 'a=3&a=4&b=b1&b=&c=&c=c2'
    print(parse_qs_bytes(qs))  # {'a': ['3', '4'], 'b': ['b1', ''], 'c': ['', 'c2']}
    print(parse_qs_bytes(qs, keep_blank_values=True))  # {'a': ['3', '4'], 'b': ['b1', ''], 'c': ['', 'c2']}
    print(parse_qs_bytes(qs, strict_parsing=True))  # {'a': ['3', '4'], 'b': ['b1'], 'c': ['', 'c2']}


# Generated at 2022-06-22 03:33:01.885088
# Unit test for function json_encode
def test_json_encode():
    try:
        from tornado.escape import json_decode
    except ImportError:
        from tornado.escape import utf8 as json_decode

    # Basic types
    assert json_encode(None) == "null"
    assert json_encode(True) == "true"
    assert json_encode(False) == "false"
    assert json_encode(0) == "0"
    assert json_encode(123) == "123"
    assert json_encode(123.456) == "123.456"
    assert json_encode(1e100) == "1e+100"
    assert json_encode(-123.456) == "-123.456"
    assert json_encode(1j) == "null"  # json doesn't support complex numbers

# Generated at 2022-06-22 03:33:09.484417
# Unit test for function json_encode
def test_json_encode():
    # Check that </script is escaped
    assert json_encode({"a": "</script>"}) == r'{"a": "<\/script>"}'
    # check that </script is not escaped when it is part of a longer token
    assert json_encode({"script": "</script>"}) == r'{"script": "</script>"}'
    # check that </script is not escaped at the end of the json
    assert json_encode(["</script>"]) == r'["<\/script>"]'



# Generated at 2022-06-22 03:33:20.242179
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<>&\"\'") == "&lt;&gt;&amp;&quot;&#39;"
    assert xhtml_escape("1 < 2") == "1 &lt; 2"
    assert xhtml_escape(b"<>&\"\'") == "&lt;&gt;&amp;&quot;&#39;"
    assert xhtml_escape(u"<>&\"\'") == u"&lt;&gt;&amp;&quot;&#39;"

# Get rid of invalid control characters so we can use b.encode('utf8')
_CONTROL_CHAR_RE = re.compile(r"[\x00-\x08\x0e-\x1f]")



# Generated at 2022-06-22 03:33:32.660098
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"hello%21", "utf-8")=="hello!"
    assert url_unescape(b"hello%2B", "utf-8")=="hello+"
    assert url_unescape(b"hello%2B", "utf-8")=="hello+"
    assert url_unescape(b"hello%25", "utf-8")=="hello%"
    assert url_unescape(b"hello%25", "utf-8", plus=False)=="hello%25"
    assert url_unescape(b"hello+", "utf-8")=="hello "
    assert url_unescape(b"hello+", "utf-8", plus=False)=="hello+"

# Generated at 2022-06-22 03:33:35.448217
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('&<>"\'') == "&amp;&lt;&gt;&quot;&#39;"


# Generated at 2022-06-22 03:33:37.689409
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<script>") == "&lt;script&gt;"
    assert xhtml_escape("<script>") != "&gt;script&gt;"


# Generated at 2022-06-22 03:33:44.112602
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#39;') == "'"
    assert xhtml_unescape('&amp;') == '&'
    assert xhtml_unescape('&lt;') == '<'
    assert xhtml_unescape('&gt;') == '>'
    assert xhtml_unescape('&quot;') == '"'
    assert xhtml_unescape('&apos;') == "'"
    assert xhtml_unescape('') == ''



# Generated at 2022-06-22 03:33:56.908741
# Unit test for function linkify
def test_linkify():
    assert linkify(u"http://www.google.com") == \
        u'<a href="http://www.google.com">http://www.google.com</a>'
    assert linkify(u"www.google.com") == \
        u'<a href="http://www.google.com">www.google.com</a>'
    assert linkify(u"Hello http://www.google.com") == \
        u'Hello <a href="http://www.google.com">http://www.google.com</a>'
    assert linkify(u"Visit www.google.com today!") == \
        u'Visit <a href="http://www.google.com">www.google.com</a> today!'
    assert linkify(u"www.google.com is great") == \
        u

# Generated at 2022-06-22 03:34:08.439464
# Unit test for function json_encode
def test_json_encode():
    import json
    a=""" { "value": null, "type": "null", "raw": "null" } """
    b=json.loads(a)
    assert json_encode(b)==a
test_json_encode()


# JSON permits but does not require forward slashes to be escaped.
# This is useful when json data is emitted in a <script> tag
# in HTML, as it prevents </script> tags from prematurely terminating
# the JavaScript.  Some json libraries do this escaping by default,
# although python's standard library does not, so we do it here.
# http://stackoverflow.com/questions/1580647/json-why-are-forward-slashes-escaped
_JSON_ESCAPE = re.compile(r'[\x00-\x1f\\"]')
_JSON_ESCAP

# Generated at 2022-06-22 03:34:15.131574
# Unit test for function native_str
def test_native_str():
    # nonascii:  u'\xe4\xf6\xfc'
    # native: '\xc3\xa4\xc3\xb6\xc3\xbc'
    bytes = b'\xc3\xa4\xc3\xb6\xc3\xbc'
    assert native_str(bytes) == u'\xe4\xf6\xfc'

    bytes = b'\xc3\xa2\xc2\x82\xc2\xa2'
    assert native_str(bytes) == u'\u0382'



# Generated at 2022-06-22 03:35:22.427506
# Unit test for function recursive_unicode
def test_recursive_unicode():
    dict_unicode = {'abc': [1,2,3], 'cba': 1}
    dict_utf8 = '{"abc": [1, 2, 3], "cba": 1}'
    dict_multibyte = b'{"\xe3\x81\x82": [1, 2, 3], "\xe3\x81\x84": 1}'
    dict_japanese = '{"あ": [1, 2, 3], "い": 1}'
    dict_mixed = '{"abc": [1, 2, "あ"], "い": 1}'
    # 直接の変換
    assert recursive_unicode(dict_utf8) == dict_unicode, 'Failed to conver to unicode.'

# Generated at 2022-06-22 03:35:24.284073
# Unit test for function json_encode
def test_json_encode():
    # given
    message = "</script>"
    # when
    result = json_encode(message)
    # then
    assert result == '"<\\/script>"'



# Generated at 2022-06-22 03:35:27.041423
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("abc%20def", encoding='utf-8') == 'abc def'
    assert url_unescape(b"abc%20def", encoding=None) == b'abc def'



# Generated at 2022-06-22 03:35:29.544469
# Unit test for function json_decode
def test_json_decode():
    a = json_decode(b'\u0065')
    print(a)

_UTF8_TYPES = (bytes, type(None))

# Generated at 2022-06-22 03:35:32.491480
# Unit test for function json_decode
def test_json_decode():
    # type: () -> None
    assert isinstance(json_decode('"foo"'), str)
    assert json_decode('"foo"') == "foo"



# Generated at 2022-06-22 03:35:38.426788
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert parse_qs_bytes(b'a=1&a=2&%61=3&a=3') == {'a': [b'1', b'2', b'3'], 'a': [b'1', b'2', b'3'], 'a': [b'1', b'2', b'3']}
test_parse_qs_bytes()



# Generated at 2022-06-22 03:35:44.829305
# Unit test for function url_unescape
def test_url_unescape():
    url_unescape("a")
    url_unescape(b"a", encoding="utf-8")
    url_unescape("a", encoding="utf-8", plus=False)
    url_unescape(b"a", encoding=None, plus=False)
    url_unescape("a", encoding=None, plus=True)



# Generated at 2022-06-22 03:35:47.821441
# Unit test for function json_encode
def test_json_encode():
    a = [{"a": 1234, "b": 5678}]
    assert json_encode(a) == '[{"a": 1234, "b": 5678}]'
    assert type(json_encode(a)) is str



# Generated at 2022-06-22 03:35:50.516862
# Unit test for function url_escape
def test_url_escape():
    url_escape("hello world")
    # url_escape(b"hi world")
    # url_escape(b"hi world", True)



# Generated at 2022-06-22 03:36:02.181562
# Unit test for function json_decode
def test_json_decode():
    # typing.Dict[typing.Optional[str], typing.Any]
    a = json_decode(b'{"a": 1}')  # a is typing.Dict[str, int]
    # a: typing.Dict[str, int]
    a['a']  # int
    a['b']  # keyerror
    # a: typing.Dict[str, int]
    # Any
    b = json_decode(b'[1, 2, 3]')
    b[0]  # 1
    # b: typing.List[int]
    # Any
    b[1]["key"]  # keyerror
    b[1][1]  # 2
    b[1]  # 2
    # b: typing.List[int]
    # Any
    # Any
    c = json

# Generated at 2022-06-22 03:36:55.059139
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = "a=1&b=2"
    test = parse_qs_bytes(qs)
    assert test == {'a': [b'1'], 'b': [b'2']}



# Generated at 2022-06-22 03:36:59.686556
# Unit test for function recursive_unicode
def test_recursive_unicode():
  a = {'a': 'foo',
       'b': ['bar', b'baz']}
  b = recursive_unicode(a)
  assert isinstance(b['b'][1], str)
  assert b['b'][1] == to_unicode(a['b'][1])



# Generated at 2022-06-22 03:37:03.784293
# Unit test for function url_escape
def test_url_escape():
    print(url_escape("http://www.cnn.com", plus = False))
    return "pass"


# Generated at 2022-06-22 03:37:09.238319
# Unit test for function recursive_unicode
def test_recursive_unicode():
    a = recursive_unicode({"a":1, "b":"2", "c": [1,2,3], "d":{1,2,3}, "e": b"bytes", "f":[1,2,b"3", b"4"]})
    assert a["b"] == "2"
    assert a["c"] == [1,2,3]
    assert a["d"] == {1,2,3}
    assert a["e"] == "bytes"
    assert a["f"] == [1,2,"3", "4"]


# Generated at 2022-06-22 03:37:18.206955
# Unit test for function linkify

# Generated at 2022-06-22 03:37:23.099893
# Unit test for function json_decode
def test_json_decode():
    #Test function GIVEN a dictionary WHEN json_decode() is called THEN a same dictionary is returned
    input = {"test":"test"}
    expected_output = {"test":"test"}
    output = json_decode(input)
    assert expected_output == output


# Generated at 2022-06-22 03:37:33.640165
# Unit test for function url_unescape
def test_url_unescape():
    for plus in [True, False]:
        assert url_unescape(b'foo+bar', plus=plus) == 'foo+bar'
        assert url_unescape('foo+bar', plus=plus) == 'foo+bar'
        assert url_unescape(b'%2B', plus=plus, encoding=None) == b'+'
        assert url_unescape('%2B', plus=plus) == '+'
        assert url_unescape(b'%2B', plus=plus) == '+'
        assert url_unescape('%2B', plus=plus, encoding=None) == '+'



# Generated at 2022-06-22 03:37:38.940811
# Unit test for function json_encode
def test_json_encode():
    print(json_encode(123))
    print(json_encode(0))
    print(json_encode(1))
    print(json_encode(0.01))
    print(json_encode(-0.01))
    print(json_encode(0.000000000001))
    print(json_encode(-0.000000000001))
    print(json_encode(0.00000000000000000001))
    print(json_encode(-0.00000000000000000001))

    print(json_encode(["one", 2, True, None, [], {}]))
    print(json_encode({"one": 1, 'two': 2, 'three': 3}))
    print(json_encode({"one": "one", 'two': "two", 'three': "three"}))


# json_decode is available

# Generated at 2022-06-22 03:37:51.061873
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # The following declaration is used to type check the function call
    # in the assert statement. Python 3.5.2 does not allow a direct call to
    # recursive_unicode.
    f: Callable[[Any], Any] = recursive_unicode
    assert f({"foo": "bar", "baz": 3, "a": 1.0}) == {"foo": "bar", "baz": 3, "a": 1.0}
    assert f(["foo", 3]) == ["foo", 3]
    assert f(("foo", 3)) == ("foo", 3)
    assert f(b"foo") == "foo"
    assert f(3) == 3
    assert f(3.4) == 3.4

# Generated at 2022-06-22 03:37:57.755935
# Unit test for function recursive_unicode
def test_recursive_unicode():
    # Dictionaries
    assert(recursive_unicode({"foo": "bar"}) == {"foo": "bar"})
    assert(recursive_unicode({"foo": "bar".encode("utf-8")}) == {"foo": "bar"})
    # Tuples
    assert(recursive_unicode(("foo", "bar")) == ("foo", "bar"))
    assert(recursive_unicode(("foo", "bar".encode("utf-8"))) == ("foo", "bar"))
    assert(recursive_unicode((("foo", "bar"), ("baz", "qux"))) == (("foo", "bar"), ("baz", "qux")))
    # Lists
    assert(recursive_unicode(["foo", "bar"]) == ["foo", "bar"])