

# Generated at 2022-06-22 03:28:45.140196
# Unit test for function json_encode
def test_json_encode():
    # Test json_encode() by calling json.loads() on the returned value
    # and comparing the result to the original argument.
    data = "string", 1, {"a": 1, "b": True}, [1, 2, 3]
    for value in data:
        json_str = json_encode(value)
        print(json_str)
        assert value == json.loads(json_str)

test_json_encode()

# json_encode = json.dumps
# xhtml_escape = escape.xhtml_escape
# xhtml_unescape = escape.xhtml_unescape
# url_escape = escape.url_escape
# url_unescape = escape.url_unescape
# url_encode = escape.url_encode
# url_decode = escape.url_decode



# Generated at 2022-06-22 03:28:56.449446
# Unit test for function json_encode
def test_json_encode():
    import json
    import tornado.escape
    data = [
        'foo',
        {
            'bar': ('baz', None, 1.0, 2)
        }
    ]
    tornado = json.dumps(data).replace("</", "<\\/")
    my = tornado.escape.json_encode(data)
    print(tornado)
    print(my)
    print (tornado == my)

# # Unit test for function json_encode
# def test_json_encode():
#     import json
#     import tornado.escape
#     data = [
#         'foo',
#         {
#             'bar': ('baz', None, 1.0, 2)
#         }
#     ]
#     tornado = json.dumps(data)
#     my = tornado.escape.json

# Generated at 2022-06-22 03:29:00.991423
# Unit test for function squeeze
def test_squeeze():
    value = "<font size=\"3\">江苏省宿迁市</font>"
    assert squeeze(value).split() == ['<font', 'size="3">江苏省宿迁市</font>']
test_squeeze()


# Generated at 2022-06-22 03:29:11.157731
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'foo%26bar%3Dbaz', plus=False) == b'foo&bar=baz'
    assert url_unescape(b'foo&bar=baz', plus=True) == 'foo bar baz'
    assert url_unescape(b'foo', encoding='latin1') == 'foo'
    assert url_unescape(b'foo%26bar%3Dbaz', encoding='latin1', plus=False) == 'foo&bar=baz'
    assert url_unescape(b'foo&bar=baz', encoding='latin1', plus=True) == 'foo bar baz'



# Generated at 2022-06-22 03:29:22.491013
# Unit test for function url_unescape
def test_url_unescape():
    assert(url_unescape(b"abc") == "abc")
    assert(url_unescape(b"\xf0\x90\x80\x80") == b"\xf0\x90\x80\x80")
    assert(url_unescape(b"\xf0\x90\x80\x80", encoding=None) == b"\xf0\x90\x80\x80")
    assert(url_unescape(b"\xf0\x90\x80\x80", encoding="ascii") == b"\xf0\x90\x80\x80")
    assert(url_unescape(b"%F0%90%80%80") == "\U00010000")

# Generated at 2022-06-22 03:29:35.084518
# Unit test for function native_str
def test_native_str():
    assert native_str("foo") == "foo"
    assert native_str("foo", "latin1") == "foo"
    assert native_str("foo", "utf8") == "foo"
    assert type(native_str("foo")) == str
    assert type(native_str("foo", "utf8")) == str
    assert native_str(b"foo") == "foo"
    assert native_str(b"foo", "latin1") == "foo"
    assert native_str(b"foo", "utf8") == "foo"
    assert type(native_str(b"foo")) == str
    assert native_str(u"foo") == "foo"
    assert type(native_str(u"foo")) == str
    assert native_str(u"foo", "utf8") == "foo"
    assert type

# Generated at 2022-06-22 03:29:47.324840
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    latin1_qs = "foo=1&foo=2&bar=3".encode("latin1")
    assert parse_qs_bytes(latin1_qs) == {
        "foo": [b"1", b"2"],
        "bar": [b"3"],
    }


# One might wonder why parse_qs_bytes is latin1 and parse_qsl_bytes
# is utf8.  The reason is that parse_qsl_bytes is the right
# thing for parsing the query arguments out of a URL and should
# therefore never be called on something that isn't valid utf8.
#
# parse_qs_bytes, on the other hand, is used for splitting up the
# body of a POST request and should default to latin1
# (iso-8859-1).  iso-8859-1 is basically

# Generated at 2022-06-22 03:29:58.137044
# Unit test for function json_encode
def test_json_encode():
    assert json_encode([1,2,3]) == '[1, 2, 3]'
    assert json_encode({'a':1,'b':2}) == '{"a": 1, "b": 2}'
    assert json_encode('</script>') == '"<\\/script>"'
    assert json_encode(True) == 'true'
    assert json_encode(False) == 'false'
    assert json_encode(None) == 'null'
    assert json_encode(1) == '1'
    assert json_encode(1.2) == '1.2'

# This function is not in the tornado package

# Generated at 2022-06-22 03:30:07.188433
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&gt;") == ">"
    assert xhtml_unescape("&quot;") == '"'
    assert xhtml_unescape("&apos;") == "'"
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&#32;") == " "
    assert xhtml_unescape("&#x20;") == " "

    assert xhtml_unescape("&#32") == "&#32"
    assert xhtml_unescape("&#x20") == "&#x20"


# Generated at 2022-06-22 03:30:15.533330
# Unit test for function linkify
def test_linkify():
    # These should all pass, linkify may modify the string and change the test
    assert linkify('hi http://foo.com!') == 'hi <a href="http://foo.com">http://foo.com</a>!'
    assert linkify('hi http://foo.com/!') == 'hi <a href="http://foo.com/">http://foo.com/</a>!'
    assert linkify('hi http://foo.com:8000/bar') == 'hi <a href="http://foo.com:8000/bar">http://foo.com:8000/bar</a>'
    assert linkify('hi https://foo.com:8000/bar?hi&hi') == 'hi <a href="https://foo.com:8000/bar?hi&hi">https://foo.com:8000/bar?hi&hi</a>'


# Generated at 2022-06-22 03:30:34.801480
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('1 2 3 4 5') == '1 2 3 4 5'
    assert squeeze('1   2   3   4   5') == '1 2 3 4 5'
    assert squeeze('1\t2\t3\t4\t5') == '1 2 3 4 5'
    assert not squeeze('1 2 3 4 5') == '1, 2, 3, 4, 5'
    assert not squeeze('1   2   3   4   5') == '1, 2, 3, 4, 5'
    assert not squeeze('1\t2\t3\t4\t5') == '1, 2, 3, 4, 5'

# sqeeze1
# This function is used to squeeze the string with the separator
# Example:
#   squeeze1('1 2 3 4 5',',') => '1,2,3,

# Generated at 2022-06-22 03:30:37.643524
# Unit test for function json_encode
def test_json_encode():
    # type: () -> None
    assert json_encode({"a": "<foo>"}) == '{"a": "<foo>"}'



# Generated at 2022-06-22 03:30:43.322752
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a  b") == "a b"
    assert squeeze("   \n \t\n a \n\t  b    \t\n   ") == "a b"
    assert squeeze("a\n\nb") == "a b"



# Generated at 2022-06-22 03:30:45.789963
# Unit test for function xhtml_escape
def test_xhtml_escape():
    # type: () -> None
    assert xhtml_escape("<>&\"'") == "&lt;&gt;&amp;&quot;&#39;"



# Generated at 2022-06-22 03:30:56.600699
# Unit test for function url_unescape
def test_url_unescape():
    assert url_escape("/") == "%2F"  # sanity check
    assert url_unescape("/") == "/"
    assert type(url_unescape("/")) is str
    assert url_unescape("/", encoding=None) == b"/"
    assert type(url_unescape("/", encoding=None)) is bytes
    assert url_unescape(b"/") == "/"
    assert url_unescape(b"/", encoding=None) == b"/"
    assert type(url_unescape(b"/", encoding=None)) is bytes
    assert url_escape(" ") == "+"
    assert url_unescape("+") == " "
    assert url_unescape("abc+def") == "abc+def"  # not special in query strings

# Generated at 2022-06-22 03:31:05.054653
# Unit test for function url_unescape
def test_url_unescape():
    # type: () -> None
    assert url_unescape("%E4%B8%AD%E6%96%87", "utf-8") == "中文"
    assert url_unescape(b"%E4%B8%AD%E6%96%87", "utf-8") == "中文"
    assert url_unescape(b"%E4%B8%AD%E6%96%87", None) == b"\xe4\xb8\xad\xe6\x96\x87"



# Generated at 2022-06-22 03:31:09.587569
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&lt;') == '<'
    assert xhtml_unescape('&lt;&gt;&amp;&quot;&#39;') == '<>&"\''
    assert xhtml_unescape('&#39;') == "'"
    assert xhtml_unescape('&#x27;') == "'"



# Generated at 2022-06-22 03:31:21.644393
# Unit test for function json_decode
def test_json_decode():

    # Test non empty string input
    json_str = '{"key": "value"}'
    value = json_decode(json_str)
    assert isinstance(value, dict)
    assert value['key'] == 'value'

    # Test empty string input
    json_str = ''
    value = json_decode(json_str)
    assert isinstance(value, str)
    assert value == ''

    # Test non string input
    json_str = b'{"key": "value"}'
    value = json_decode(json_str)
    assert isinstance(value, dict)
    assert value['key'] == 'value'

    # Test non empty string input
    json_str = '{"key": "value"}'
    value = json_decode(json_str)
    assert isinstance(value, dict)

# Generated at 2022-06-22 03:31:25.830532
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('  \n \t \r   我爱你中国') == '我爱你中国'



# Generated at 2022-06-22 03:31:35.710058
# Unit test for function squeeze
def test_squeeze():
    print('Test for function squeeze()')
    value = " \x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f"
    assert squeeze(value) == ' '
    assert squeeze(value*10) == ' '
    assert not squeeze(value*10) == '  '
    assert not squeeze(value*10) == ''
    print('Function squeeze() pass.')
print('Test for function squeeze() begin.')
test_squeeze()

# Generated at 2022-06-22 03:31:44.890545
# Unit test for function squeeze
def test_squeeze():
    assert squeeze(";drop schema database;") == squeeze("; drop schema database;")
    assert squeeze(">") == squeeze("> ")
    assert squeeze(";") != squeeze("; ")



# Generated at 2022-06-22 03:31:55.247432
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<hello>") == "&lt;hello&gt;", "test_xhtml_escape"


_JSON_ESCAPE_RE = re.compile(r"[\x00-\x1f\\\"\b\f\n\r\t]")
_JSON_ESCAPE_DCT: Dict[str, str] = {
    "\\": "\\\\",
    '"': '\\"',
    "\b": "\\b",
    "\f": "\\f",
    "\n": "\\n",
    "\r": "\\r",
    "\t": "\\t",
}



# Generated at 2022-06-22 03:32:02.495710
# Unit test for function json_decode

# Generated at 2022-06-22 03:32:04.865270
# Unit test for function json_encode
def test_json_encode():
    try:
        data = {"foo": "bar"}
        assert json_encode(data) == """{"foo": "bar"}"""
    except AssertionError as e:
        raise AssertionError()
    except Exception as e:
        raise AssertionError(str(e))
test_json_encode()



# Generated at 2022-06-22 03:32:15.306202
# Unit test for function native_str
def test_native_str():
    assert native_str("a") == "a"
    assert native_str("a", encoding="utf-8") == "a"
    assert native_str(b"a") == "a"
    assert native_str(b"a", encoding="utf-8") == "a"
    assert native_str(b"a", encoding="ascii") == "a"
    assert native_str(u"a") == "a"
    assert native_str(u"a", encoding="utf-8") == "a"
    assert native_str(1) == "1"
    with pytest.raises(TypeError, match="1.*str.*int"):
        native_str(1, encoding="utf-8")
    with pytest.raises(ValueError, match=r"test.*ascii"):
        native_

# Generated at 2022-06-22 03:32:19.529366
# Unit test for function url_escape
def test_url_escape():
    value = bytes('a+b', 'utf-8')
    assert(url_escape(value) == 'a%2Bb')
test_url_escape()



# Generated at 2022-06-22 03:32:26.466608
# Unit test for function native_str
def test_native_str():
    assert native_str(b'test') == 'test'
    assert native_str('test') == 'test'
    assert native_str(u'test') == u'test'
    try:
        assert native_str(None) == None
    except Exception as e:
        assert str(e) == 'Expected bytes, unicode, or None; got <class \'NoneType\'>'


# Generated at 2022-06-22 03:32:36.306269
# Unit test for function native_str
def test_native_str():
    utf8_str = '\u00A9'
    gbk_str = '\xa9\xa6'

    assert native_str(utf8_str, 'utf8') == utf8_str
    assert native_str(utf8_str, 'gbk') == gbk_str
    assert native_str(utf8_str) == utf8_str

    assert native_str(gbk_str, 'utf8') == utf8_str
    assert native_str(gbk_str, 'gbk') == gbk_str
    assert native_str(gbk_str) == utf8_str

    assert native_str(None, 'utf8') == None
    assert native_str(None, 'gbk') == None
    assert native_str(None) == None

# Unit

# Generated at 2022-06-22 03:32:40.452298
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    res = parse_qs_bytes(b'foo=bar&baz=blah&baz=1234yahoo&foo=yahoo')
    assert res == {'foo': [b'bar', b'yahoo'], 'baz': [b'blah', b'1234yahoo']}


# Generated at 2022-06-22 03:32:52.895978
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<") == "&lt;"
    assert xhtml_escape(">") == "&gt;"
    assert xhtml_escape('"') == "&quot;"
    assert xhtml_escape("'") == "&#39;"
    assert xhtml_escape("&") == "&amp;"


_XML_ESCAPE_RE = re.compile("[&<>\"']")
_XML_ESCAPE_DICT = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&apos;",
}



# Generated at 2022-06-22 03:33:03.919793
# Unit test for function squeeze
def test_squeeze():
    string = squeeze("abc def ghi")
    assert string == "abc def ghi"
    string = squeeze("abc  def  ghi")
    assert string == "abc def ghi"
    string = squeeze("abc\ndef\nghi")
    assert string == "abc def ghi"
    string = squeeze("abc\tdef\tghi")
    assert string == "abc def ghi"
    string = squeeze("\t  \n\r\nabc\tdef\tghi\t  \n\r\n")
    assert string == "abc def ghi"
    string = squeeze("\t  \n\r\nabc \t def \t ghi \t  \n\r\n")
    assert string == "abc def ghi"



# Generated at 2022-06-22 03:33:09.181178
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape(r"&lt;") == "<"
    assert xhtml_unescape(r"&gt;") == ">"
    assert xhtml_unescape(r"&quot;") == "\""
    assert xhtml_unescape(r"&#39;") == "'"
    assert xhtml_unescape(r"&amp;") == "&"
    assert xhtml_unescape(r"&#38;") == "&"

# Generated at 2022-06-22 03:33:14.373135
# Unit test for function url_escape
def test_url_escape():

    value = "ab cd ef"
    result = url_escape(value)
    correct_result = "ab%20cd%20ef"
    if result != correct_result:
        raise RuntimeError(f"failed test: value: {value}, result: {result}, correct_result: {correct_result}")


test_url_escape()



# Generated at 2022-06-22 03:33:20.600117
# Unit test for function json_decode
def test_json_decode():
    test_str = "{'a': 'b', 'c': 'd'}"
    res = json_decode(test_str)
    for k, v in res.items():
        print(k + '=' + v)

_UNESCAPE_HTML_ENTITY_RE = re.compile("&(#?)(\d{1,5}|\w{1,8});")



# Generated at 2022-06-22 03:33:32.966081
# Unit test for function url_escape
def test_url_escape():
    # NOTE: In Python 2, url_escape is a wrapper around urllib.quote,
    # which does not treat the '/' character as unsafe:
    # https://docs.python.org/2/library/urllib.html#urllib.quote
    # In Python 3 url_escape is a wrapper around urllib.parse.quote,
    # which does treat the '/' character as unsafe:
    # https://docs.python.org/3/library/urllib.parse.html#urllib.parse.quote
    assert url_escape("my_awesome_string/with-slashes") == "my_awesome_string%2Fwith-slashes"
    assert url_escape("my_awesome_string/with-slashes", plus=False) == "my_awesome_string%2Fwith-slashes"

# Generated at 2022-06-22 03:33:39.607474
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('foo') == 'foo'
    assert xhtml_unescape('&lt;') == '<'
    assert xhtml_unescape('&quot;') == '"'
    assert xhtml_unescape('&#39;') == "'"
    assert xhtml_unescape('&#x4a;') == 'J'
    assert xhtml_unescape('&bar;') == '&bar;'
    assert xhtml_unescape('&#37;') == '%'
    assert xhtml_unescape('&#x4a;') == 'J'



# Generated at 2022-06-22 03:33:44.069827
# Unit test for function utf8
def test_utf8():
    assert utf8('mammoth') == b'mammoth'
    assert utf8(b'mammoth') == b'mammoth'
    assert utf8(None) is None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:33:46.456428
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<html>") == "&lt;html&gt;"


# Generated at 2022-06-22 03:33:57.099250
# Unit test for function url_escape
def test_url_escape():
    def test(inp, expected):
        actual = url_escape(inp, False)
        print('actual:',actual)
        print('expected:',expected)
        assert actual == expected
    test('foo', 'foo')
    test('foo bar', 'foo%20bar')
    test('foo+bar', 'foo%2Bbar')
    test('foo%20bar', 'foo%2520bar')
    test('foo bar', 'foo+bar', True)
    test('foo+bar', 'foo%2Bbar', True)
    test('foo%20bar', 'foo%20bar', True)
# Unit test
test_url_escape()


# Generated at 2022-06-22 03:34:04.399433
# Unit test for function utf8
def test_utf8():
    assert utf8("hello") == b'hello'
    assert not utf8("hello") == 'hello'
    assert utf8("你好") == b'\xe4\xbd\xa0\xe5\xa5\xbd'
    assert not utf8("你好") == '你好'
test_utf8()


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:34:22.619588
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&#25;") == "%"
    assert xhtml_unescape("&#x60;") == "`"
    assert xhtml_unescape("&nbsp;&lt;&gt;&amp;&quot;&#39;") == " <>&\"'"
    assert xhtml_unescape("&#39;") == "'"
    # Note: in Python 2 html.entities.html5 only exists if
    # html5lib is installed.  In Python 3, it's built-in.
    if hasattr(html.entities, "html5"):
        assert xhtml_unescape("&natur;") == "♮"
    # unknown entities are passed through unmodified
    assert xhtml_unescape

# Generated at 2022-06-22 03:34:34.105942
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b'http://www.baidu.com') == 'http://www.baidu.com'
    assert url_unescape(b'http') == 'http'
    assert url_unescape(b'http', plus=False) == 'http'
    assert url_unescape(b'http+//www') == 'http+//www'
    assert url_unescape(b'http+//www', plus=False) == 'http+//www'
    assert url_unescape(b'http%3A%2F%2Fwww.baidu.com') == 'http%3A%2F%2Fwww.baidu.com'

# Generated at 2022-06-22 03:34:37.184118
# Unit test for function utf8
def test_utf8():
    assert utf8("abc") == b"abc"
    assert utf8(u"abc") == b"abc"
    assert utf8(None) is None
    try:
        utf8(1)
        assert False
    except TypeError:
        pass


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:34:42.210591
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("abc") == "abc"
    assert url_escape(" ") == "+"
    assert url_escape("+") == "%2B"
    assert url_escape("=") == "%3D"
    assert url_escape("&") == "%26"


# Generated at 2022-06-22 03:34:49.289069
# Unit test for function recursive_unicode
def test_recursive_unicode():
    obj=[str('abc'),str('def')]
    re_obj=recursive_unicode(obj)
    assert re_obj==obj
    obj=(str('abc'),str('def'))
    re_obj=recursive_unicode(obj)
    assert re_obj==obj
    obj={'a':'b','c':'d'}
    re_obj=recursive_unicode(obj)
    assert re_obj==obj
    obj=b'abc'
    re_obj=recursive_unicode(obj)
    assert re_obj=='abc'
test_recursive_unicode()

# Generated at 2022-06-22 03:34:56.475878
# Unit test for function utf8
def test_utf8():
    # type: () -> None
    assert utf8(None) is None
    assert utf8('foo') == b'foo'
    assert utf8(b'foo bar') == b'foo bar'
    assert utf8(u'foo') == b'foo'
    assert utf8(u'foo\u00E9') == b'foo\xc3\xa9'
    assert utf8(b'foo\xc3\xa9') == b'foo\xc3\xa9'
    assert utf8(u'foo\xc3\xa9') == b'foo\xc3\xa9'
    assert utf8(u'foo\u00E9') == b'foo\xc3\xa9'


_TO_UNICODE_TYPES = (unicode_type, type(None))

# Generated at 2022-06-22 03:35:06.063630
# Unit test for function linkify

# Generated at 2022-06-22 03:35:12.918041
# Unit test for function json_encode
def test_json_encode():
    # json_encode
    assert json_encode({"x": "y"}) == '{"x": "y"}'
    assert json_encode(["x", "y"]) == '["x", "y"]'
    assert json_encode({"x": "</"}) == '{"x": "<\\/"}'
    # Note the above 2 lines.  See the discussion of forward-slash
    # escaping at the top of this file.




# Generated at 2022-06-22 03:35:22.681732
# Unit test for function utf8
def test_utf8():
    assert utf8(None) is None
    assert utf8(b"ascii") == b"ascii"
    assert utf8("ascii") == b"ascii"
    assert utf8("I \xf1t\xebrn\xe2ti\xf4n\xe0liz\xe6ti\xf8n") == b"I \xc3\xb1t\xc3\xabrn\xc3\xa2ti\xc3\xb4n\xc3\xa0liz\xc3\xa6ti\xc3\xb8n"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:35:32.886181
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    import tornado.httputil
    import tornado.escape

    def check(qs, expected):
        parsed = tornado.httputil.parse_qs_bytes(qs)
        for k, v in parsed.items():
            assert [x.decode() for x in v] == [
                w.decode() for w in expected.get(k, [])
            ]

        parsed = tornado.httputil.parse_qs_bytes(qs.encode())
        for k, v in parsed.items():
            assert [x.decode() for x in v] == [
                w.decode() for w in expected.get(k, [])
            ]

# Generated at 2022-06-22 03:35:45.674558
# Unit test for function url_escape
def test_url_escape():
    expected = "%E9%A2%86%E5%8F%8A"
    assert url_escape("领及") == expected
    quote = urllib.parse.quote
    assert quote(utf8("领及")) == expected


# Generated at 2022-06-22 03:35:55.652755
# Unit test for function recursive_unicode
def test_recursive_unicode():
    obj = [1,2,3]
    assert(obj == recursive_unicode(obj))
    obj = [1,"2",[3,4], {"five":"six"}]
    assert(obj == recursive_unicode(obj))
    obj = [1,"2",[3,4], {"five":"six"}, b"seven"]
    assert(obj == recursive_unicode(obj))
    obj = [1,"2",[3,4], {"five":"six"}, b"seven", b"eight"]
    assert(obj == recursive_unicode(obj))
    obj = [b"one",b"two",3,u"four"]
    assert(obj == recursive_unicode(obj))
    obj = [1,"2",[b"three",4], {"five":b"six"}, b"seven", b"eight"]

# Generated at 2022-06-22 03:36:01.142326
# Unit test for function url_escape
def test_url_escape():
    value = "foo bar"
    print("url_escape(%r) -> %r" % (value, url_escape(value)))
    print("url_escape(%r, plus=False) -> %r" % (value, url_escape(value, plus=False)))
#test_url_escape()



# Generated at 2022-06-22 03:36:13.225350
# Unit test for function linkify

# Generated at 2022-06-22 03:36:24.484860
# Unit test for function native_str
def test_native_str():
    # Converts byte/unicode strings, bytes in lists, and byte/unicode keys
    # in dicts to native strings.
    assert native_str(b"abc") == "abc"
    assert native_str(u"abc") == "abc"
    assert native_str(b"\x80") == "\x80"
    assert native_str([b"a", b"\x80"]) == ["a", "\x80"]
    assert native_str([u"a", b"\x80"]) == ["a", "\x80"]
    assert native_str({"a": u"\u0080"}) == {"a": "\x80"}
    # Objects that implement __str__ are converted directly
    class Foo(object):
        def __str__(self):
            return b"abc"


# Generated at 2022-06-22 03:36:35.244259
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(['1', 2, b'3']) == ['1', 2, '3']
    assert recursive_unicode({'1': '1', 2: b'2'}) == {'1': '1', 2: '2'}
    assert recursive_unicode({'1': '1', 2: b'2', '3': [b'3']}) == {'1': '1', 2: '2', '3': ['3']}
    assert recursive_unicode({'1': '1', 2: b'2', '3': [b'3'], '5': {'6': {7: b'8'}}}) == \
        {'1': '1', 2: '2', '3': ['3'], '5': {'6': {7: '8'}}}


# Generated at 2022-06-22 03:36:41.150458
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape('%24', encoding=None) == b'$'
    assert url_unescape('%24', encoding='latin-1') == '$'
    assert url_unescape('%C2%A2', encoding='latin-1') == '¢'
    assert url_unescape('%25', plus=False, encoding='latin-1') == '%'



# Generated at 2022-06-22 03:36:50.584639
# Unit test for function utf8
def test_utf8():
    assert utf8(None) is None
    assert utf8(b"foo") == b"foo"
    assert utf8("foo") == b"foo"
    assert utf8(u"foo") == b"foo"
    assert utf8(u"\xe9") == b"\xc3\xa9"
    try:
        # This should be prevented by the typing, but just in case,
        # ensure that we don't accidentally allow it.
        utf8(u"foo", "ignore")
    except TypeError:
        pass
    else:
        assert False


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:36:53.302034
# Unit test for function squeeze
def test_squeeze():
    test_string = """
    The quick brown fox jumps over the lazy dog
    """
    expected = "The quick brown fox jumps over the lazy dog"
    assert squeeze(test_string) == expected
    
    

# Generated at 2022-06-22 03:37:03.867528
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<a>&b</a>') == "&lt;a&gt;&amp;b&lt;/a&gt;"


_JSON_ESCAPE_RE = re.compile(r"[<>&_]")
_JSON_ESCAPE_DICT = {
    # Some characters are escaped for compatibility reasons with browsers.
    # For example, '<' and '>' are escaped because they can be confused
    # by browsers as the start and end of tags.
    '<': '\\u003C',
    '>': '\\u003E',
    '&': '\\u0026',
    '_': '\\u005F',
}



# Generated at 2022-06-22 03:37:18.939575
# Unit test for function utf8
def test_utf8():
    # Overloads
    assert utf8("foo") == b"foo"
    assert utf8(u"foo") == b"foo"
    assert utf8(b"foo") == b"foo"
    assert utf8(None) is None
    try:
        utf8(3)
        assert False
    except TypeError:
        pass
    # Unit tests
    # If we try to convert "©" to utf8, it will be encoded as "Ã" + ",".
    assert utf8("©") == b"\xc2\xa9"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:37:22.850326
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    assert  parse_qs_bytes(b"a=1&b=1&b=2") == {'a': [b'1'], 'b': [b'1', b'2']}
#test_parse_qs_bytes()



# Generated at 2022-06-22 03:37:25.681302
# Unit test for function native_str
def test_native_str():
    assert native_str("text") == "text"
    assert native_str(b"text") == "text"




# Generated at 2022-06-22 03:37:36.839478
# Unit test for function utf8
def test_utf8():
    def roundtrip(x: Any) -> Any:
        return to_unicode(utf8(x))

    assert roundtrip(None) is None
    assert roundtrip("") == ""
    assert roundtrip("Hello") == "Hello"
    assert roundtrip("\xe9") == "\xe9"
    assert roundtrip("\u20ac") == "\u20ac"

    assert utf8(None) is None
    assert utf8(b"") == b""
    assert utf8(b"Hello") == b"Hello"
    assert utf8(b"\xe9") == b"\xe9"
    assert utf8(u"") == b""
    assert utf8(u"Hello") == b"Hello"

# Generated at 2022-06-22 03:37:48.848821
# Unit test for function linkify
def test_linkify():
    assert linkify("this is a simple test") == "this is a simple test"
    assert linkify(
        "http://example.com"
    ) == "<a href=\"http://example.com\">http://example.com</a>"
    assert linkify(
        "http://example.com", extra_params="class=\"empty\""
    ) == "<a href=\"http://example.com\" class=\"empty\">http://example.com</a>"
    assert linkify(
        "http://example.com",
        extra_params=lambda url: 'class="%s"' % url.split("/")[2].split(".")[0],
    ) == "<a href=\"http://example.com\" class=\"example\">http://example.com</a>"

# Generated at 2022-06-22 03:37:52.848945
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({ 'a': 1, 'b': 2, 'c': { 'd': '3' } }) == '{"a": 1, "b": 2, "c": {"d": "3"}}'



# Generated at 2022-06-22 03:38:04.227295
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    print("---%s---" % xhtml_unescape("&amp;"))
    print("---%s---" % xhtml_unescape("Привет"))
    print("---%s---" % xhtml_unescape("Привет&amp;&amp;"))
    print("---%s---" % xhtml_unescape("Привет&amp;&amp;&#123;&quot;test&quot;:&#123;&quot;test&quot;:&#123;&quot;test&quot;:&#123;&#123;&quot;test&quot;:&#123;&quot;test&quot;:&quot;test&quot;}}}}}"))

