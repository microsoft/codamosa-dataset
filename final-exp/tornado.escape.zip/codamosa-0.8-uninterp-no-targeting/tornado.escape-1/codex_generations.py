

# Generated at 2022-06-22 03:28:28.367051
# Unit test for function native_str
def test_native_str():
    assert native_str('unicode') == str('unicode')
    assert native_str(b'bytes') == str('bytes')
    assert native_str(u'unicode') == str('unicode')
    assert native_str(1) == str(1)
    with pytest.raises(TypeError):
        native_str(None)



# Generated at 2022-06-22 03:28:36.088939
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape('&#1234;') == '\u04d2'
    assert xhtml_unescape('&#x1234;') == '\u04d2'
    assert xhtml_unescape('&amp;') == '&'
    assert xhtml_unescape('&#38;') == '&'
    assert xhtml_unescape('&#x26;') == '&'
    assert xhtml_unescape('&foo;') == '&foo;'
    assert xhtml_unescape('&#9999999999;') == '&#9999999999;'
    assert xhtml_unescape(u"&#x0000000e9;") == u"\xe9"

# json_encode, json_decode moved to tornado/util.py
# because they depend on settings.




# Generated at 2022-06-22 03:28:45.096832
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(b"foo") == "foo"
    assert recursive_unicode({"foo": b"bar"}) == {"foo": "bar"}
    assert recursive_unicode({"foo": {"bar": b"baz"}}) == {"foo": {"bar": "baz"}}
    assert recursive_unicode(b"foo") == "foo"
    assert recursive_unicode({"foo": b"bar"}) == {"foo": "bar"}
    assert recursive_unicode({"foo": {"bar": b"baz"}}) == {"foo": {"bar": "baz"}}



# Generated at 2022-06-22 03:28:46.270999
# Unit test for function native_str
def test_native_str():
    assert native_str("spůj") == "spůj"



# Generated at 2022-06-22 03:28:47.642478
# Unit test for function native_str
def test_native_str():
  pass



# Generated at 2022-06-22 03:28:57.798095
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({'k': [{'n': 1}, {'s': 'foo'}]}) == {'k': [{'n': 1}, {'s': 'foo'}]}
    # assert recursive_unicode(['x', 'y', 'z']) == ['x', 'y', 'z']
    # assert recursive_unicode(('x', 'y', 'z')) == ('x', 'y', 'z')
    # assert recursive_unicode('foo') == 'foo'
    # assert recursive_unicode('foo'.encode('utf-8')) == 'foo'
    # assert recursive_unicode(None) is None
test_recursive_unicode()


# Generated at 2022-06-22 03:29:00.277800
# Unit test for function json_encode
def test_json_encode():
    print(json_encode("/foo/"))
    print(json_encode("<x>x</x>"))
    print(json_encode("\\/"))


# Generated at 2022-06-22 03:29:03.808451
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode([b"\xe7\x99\xbe", b"\xe4\xba\x8c"]) == ["\u7396", "\u4e8c"]


# Generated at 2022-06-22 03:29:15.800042
# Unit test for function linkify
def test_linkify():
    assert linkify('My friends are <b>awesome</b>.') == 'My friends are &lt;b&gt;awesome&lt;/b&gt;.'
    assert linkify('Go to http://www.tornadoweb.org/') == 'Go to <a href="http://www.tornadoweb.org/">http://www.tornadoweb.org/</a>'
    assert linkify('http://example.com/', shorten=True) == '<a href="http://example.com/">example.com/</a>'

if __name__ == '__main__':
    from minitest import *


# Generated at 2022-06-22 03:29:22.342767
# Unit test for function url_unescape
def test_url_unescape():
    from tornado.web import RequestHandler

    class MyHandler(RequestHandler):
        def get(self):
            url = url_unescape(self.get_argument('url'), plus=False)
            self.write(url)

    import tornado.ioloop

    app = tornado.web.Application([(r"/", MyHandler)])
    app.listen(8888)
    tornado.ioloop.IOLoop.current().start()

# Generated at 2022-06-22 03:29:43.841488
# Unit test for function native_str
def test_native_str():
    assert native_str('test') == 'test'
    assert native_str('中文'.encode('utf-8')) == '中文'
    assert isinstance(native_str('中文'.encode('utf-8')), str)
test_native_str()



# Generated at 2022-06-22 03:29:52.840627
# Unit test for function utf8
def test_utf8():
    assert utf8(b"hello") == b"hello"
    assert utf8("hello") == b"hello"
    assert utf8(u"hello") == b"hello"
    assert utf8(None) is None
    try:
        utf8(5)
        raise Exception("shouldn't get here")
    except TypeError as e:
        assert "Expected bytes, unicode, or None" in str(e)


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:29:56.182467
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert "<>" == xhtml_unescape("&lt;&gt;")
    assert "& " == xhtml_unescape("&amp;&nbsp;")

# Generated at 2022-06-22 03:30:07.124928
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape("") == ""
    assert (
        url_unescape("http%3A%2F%2Fwww.tornadoweb.org%2F")
        == "http://www.tornadoweb.org/"
    )
    assert url_unescape("http%3A%2F%2Fwww.tornadoweb.org%2F", encoding="utf-8") == "http://www.tornadoweb.org/"
    assert (
        url_unescape("http%3A%2F%2Fwww.tornadoweb.org%2F", encoding=None)
        == b"http://www.tornadoweb.org/"
    )

# Generated at 2022-06-22 03:30:19.682157
# Unit test for function json_decode
def test_json_decode():
    a: Dict[str, Any] = {}
    a["a"] = "1"
    a["d"] = "s"
    b: List[Any] = []
    b.append(a)

    testString = '{"a": "1", "d": "s"}'
    testResult = json_decode(testString)
    assert(testResult["a"] == a["a"])
    assert(testResult["d"] == a["d"])
    testString = "[{\"a\": \"1\", \"d\": \"s\"}]"
    testResult = json_decode(testString)
    assert(testResult[0]["a"] == b[0]["a"])
    assert(testResult[0]["d"] == b[0]["d"])


# Generated at 2022-06-22 03:30:23.865116
# Unit test for function utf8
def test_utf8():
    utf8("")
    utf8("a")
    utf8("aasdadsasd")
    utf8(u"")
    utf8(u"a")
    utf8(u"aasdadsasd")
    utf8(None)



# Generated at 2022-06-22 03:30:27.508692
# Unit test for function native_str
def test_native_str():
    def f(x):
        return x.encode()
    def g(x):
        return x
    return f, g


# Generated at 2022-06-22 03:30:39.268230
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;script&gt;") == "<script>"
    assert xhtml_unescape("&#39;") == "'"
    assert xhtml_unescape("&#46;") == "."
    # assert xhtml_unescape("&#1;") == "&#1;"
    assert xhtml_unescape("&#x2F;") == "/"
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&lt;") == "<"
    assert xhtml_unescape("&gt;") == ">"
    assert xhtml_unescape("&quot;") == '"'
    assert xhtml_unescape("&#39;") == "'"
    assert xhtml_unescape("&#46;") == "."
    assert xhtml

# Generated at 2022-06-22 03:30:47.483598
# Unit test for function native_str
def test_native_str():
    # Test that native_str works with ascii chars
    assert native_str(b"hello") == "hello"

    # Test that native_str works with unicode chars
    assert native_str(u"aéée") == "aéée"

    # Test that native_str works with str chars
    assert native_str("aéée") == "aéée"

    # Test that native_str raises an error with an integer
    try:
        native_str(5)
        assert False
    except TypeError:
        pass

    return


# Generated at 2022-06-22 03:30:48.978284
# Unit test for function json_decode
def test_json_decode():
    value = json_decode('{"test": 1}')
    assert value['test'] == 1


# Generated at 2022-06-22 03:31:06.444387
# Unit test for function utf8
def test_utf8():
    utf8(b'123') == b'123'
    utf8(u'123') == b'123'
    utf8('') == b''
    utf8(None) == None


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:31:12.485206
# Unit test for function url_unescape
def test_url_unescape():
    assert url_unescape(b"foo") == "foo"
    assert url_unescape(b"foo%2Bbar") == "foo+bar"
    assert url_unescape(b"foo%2Bbar", encoding=None) == b"foo+bar"
    assert url_unescape(b"foo%2Bbar", plus=False) == "foo%2Bbar"

    # utf-8 encoding
    assert url_unescape(b"foo%C3%A9") == "\ufffd\ufffd"
    assert url_unescape(b"foo%C3%A9", encoding="utf-8") == "fooÃ©"



# Generated at 2022-06-22 03:31:19.025617
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("hello\t\nworld") == "hello world"
    assert squeeze("  foo   bar    ") == "foo bar"
    assert squeeze("    ") == ""

#_UTF8_TYPES = (bytes, type(None))
_UTF8_TYPES = (str, type(None))



# Generated at 2022-06-22 03:31:21.905813
# Unit test for function json_decode
def test_json_decode():
    assert len(json_decode(json_encode([1,2,3]))) == 3

# json_encode_string is deprecated in favor of json_encode.
json_encode_string = json_encode



# Generated at 2022-06-22 03:31:26.883273
# Unit test for function json_decode
def test_json_decode():
    expected = [1, 2, 3]
    assert json_decode(b'[1, 2, 3]') == expected
    assert json_decode('[1, 2, 3]') == expected
    


# Generated at 2022-06-22 03:31:30.142806
# Unit test for function squeeze
def test_squeeze():
    s = '''hello

    world'''
    expect = 'hello world'
    actual = squeeze(s)
    assert actual == expect, 'failed'
test_squeeze()



# Generated at 2022-06-22 03:31:33.076289
# Unit test for function json_decode
def test_json_decode():
    assert json_decode('{"a":"b"}') == {"a":"b"}
    assert json_decode(b'{"a":"b"}') == {"a":"b"}
test_json_decode()



# Generated at 2022-06-22 03:31:45.361289
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape("<>\"'&") == '&lt;&gt;&quot;&#39;&amp;'
    assert xhtml_escape(b"<>\"'&") == '&lt;&gt;&quot;&#39;&amp;'
    assert xhtml_escape(b"<>\"'&".decode("utf-8")) == '&lt;&gt;&quot;&#39;&amp;'
    assert xhtml_escape(b"<>\"'&".decode("utf-8").encode("utf-8")) == '&lt;&gt;&quot;&#39;&amp;'



# Generated at 2022-06-22 03:31:47.175318
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&amp;") == "&"
    assert xhtml_unescape("&#38;") == "&"


# Generated at 2022-06-22 03:31:48.251049
# Unit test for function json_decode
def test_json_decode():
    assert 'hello' == json_decode(json_encode('hello'))



# Generated at 2022-06-22 03:31:57.410791
# Unit test for function json_decode
def test_json_decode():
    print(json_decode('[1, 2, 3]'))
    print(json_decode('{"a":1, "b":2}'))



# Generated at 2022-06-22 03:32:10.037767
# Unit test for function recursive_unicode
def test_recursive_unicode():
    test_dict1 = {b"foo": b"bar",
                  b"hoo": b"dar",
                  b"int": 1,
                  b"list": [1,2,3,4],
                  b"dict": {b"foo": b"bar",
                            b"hoo": b"dar",
                            b"int": 1,
                            b"list": [1,2,3,4]}}

# Generated at 2022-06-22 03:32:17.968342
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    qs = 'foo=bar&foo=baz&blah=%40%23%24%25%5E'
    assert parse_qs_bytes(qs)['blah'][0] == b'@#$%^'
test_parse_qs_bytes()


# I originally used the regex from
# http://daringfireball.net/2010/07/improved_regex_for_matching_urls
# but it gets all exponential on certain patterns (such as too many trailing
# dots), causing the regex matcher to never return.
# This regex should avoid those problems.

# Generated at 2022-06-22 03:32:21.673520
# Unit test for function json_decode
def test_json_decode():
    value = '{"name":"john","age":20}'
    r = json_decode(value) #should be {'name': 'john', 'age': 20}


# Generated at 2022-06-22 03:32:28.175445
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("hello world") == "hello world"
    assert squeeze(" hello world") == "hello world"
    assert squeeze("hello world ") == "hello world"
    assert squeeze("hello   world  ") == "hello world"
    assert squeeze("hello\nworld") == "hello world"
    assert squeeze("hello\tworld") == "hello world"
    assert squeeze("hello  \t \n  world") == "hello world"



# Generated at 2022-06-22 03:32:38.664449
# Unit test for function recursive_unicode
def test_recursive_unicode():
    x=[1,2,3]
    assert recursive_unicode(x)==x
    x={b'foo':b'bar',b'test':b'123'}
    assert recursive_unicode(x)=={'foo':'bar','test':'123'}
    x=b'str'
    assert recursive_unicode(x)=='str'
    assert recursive_unicode(None)==None
    x=[b'test']
    assert recursive_unicode(x)==['test']
    x=('1',b'test')
    assert recursive_unicode(x)==('1','test')
test_recursive_unicode()


# Generated at 2022-06-22 03:32:39.607281
# Unit test for function squeeze
def test_squeeze():
    print(squeeze("a     b    c    d"))



# Generated at 2022-06-22 03:32:41.216673
# Unit test for function squeeze
def test_squeeze():
    assert squeeze(' Hi ') == 'Hi'
    assert squeeze(' Hi   you  ') == 'Hi you'


# Generated at 2022-06-22 03:32:51.285561
# Unit test for function utf8
def test_utf8():
    assert utf8(None) is None
    assert utf8("value") == b"value"
    assert utf8(b"value") == b"value"
    assert utf8(u"value") == b"value"
    assert utf8(1) == b"1"
    assert utf8(u"\u2603") == b"\xe2\x98\x83"
    try:
        utf8(object())
    except TypeError:
        pass
    else:
        raise AssertionError("Expected TypeError")



# Generated at 2022-06-22 03:33:03.532272
# Unit test for function url_unescape
def test_url_unescape():
    ty = typing.TypeVar('ty')
    def f(value:Union[str,bytes], encoding:Optional[str]=None) -> Union[str,bytes]:
        return url_unescape(value,encoding)
    assert isinstance(f(b'abc'), bytes)
    assert isinstance(f('abc'), str)
    

# When adding new entities here, please also add them to
# tornado.util.web.Datauri.XHTML_ENTITIES
_HTML_UNESCAPE = {
    "&apos;": "'",
    "&amp;": "&",
    "&quot;": '"',
    "&gt;": ">",
    "&lt;": "<",
    "&nbsp;": " ",
}


# Generated at 2022-06-22 03:33:24.474069
# Unit test for function json_decode
def test_json_decode():
    data = '{"name": "John Doe", "age": 42}'
    try:
        pData = json_decode(data)
        assert pData['age'] == 42
    except Exception as e:
        print ("Exception happened and the test failed")
        raise e
    print ("The unit test passed")
test_json_decode()



# Generated at 2022-06-22 03:33:31.002416
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode(b"foo") == "foo"
    assert recursive_unicode({"foo": "bar", "baz": 12}) == {"foo": "bar", "baz": 12}
    assert (
        recursive_unicode(("foo", b"bar", {"baz": ("blah", b"wacky")}))
        == ("foo", "bar", {"baz": ("blah", "wacky")})
    )



# Generated at 2022-06-22 03:33:40.184543
# Unit test for function recursive_unicode
def test_recursive_unicode():
    assert recursive_unicode({"foo": "bar", "baz": 1}) is {"foo": "bar", "baz": 1}
    assert recursive_unicode({"foo": "bar", "baz": 1}) == {"foo": "bar", "baz": 1}
    assert recursive_unicode({"foo": "bar", "baz": 1}) != {"foo": "bar", "baz": 2}
    assert recursive_unicode({"foo": "bar", "baz": 1}) == {"foo": "bar", "baz": 1}
    assert recursive_unicode({"foo": "bar", "baz": 1}) is not {"foo": "bar", "baz": 1}
    assert recursive_unicode({"foo": "bar", "baz": 1}) is not {"foo": "bar", "baz": 2}

# Generated at 2022-06-22 03:33:42.056212
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a b  c")=="a b c", "squeeze failed"

# Generated at 2022-06-22 03:33:47.943678
# Unit test for function json_decode
def test_json_decode():
    temp = b'{{\x22f\x22:1,\x22g\x22:2,\x22v\x22:}'
    print(temp)
    json_v = json_decode(temp)
    print('type: %s' % type(json_v))
    print(json_v)
    if isinstance(json_v, dict):
        print('dict')


# Generated at 2022-06-22 03:34:00.416478
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    # Test from RFC 3986 Appendix B
    assert parse_qs_bytes("") == {}
    assert parse_qs_bytes("a=1") == {"a": [b"1"]}
    assert parse_qs_bytes("a=1&a=2") == {"a": [b"1", b"2"]}
    assert parse_qs_bytes("a=1;a=2") == {"a": [b"1", b"2"]}
    assert parse_qs_bytes("a=1&b=2") == {"a": [b"1"], "b": [b"2"]}
    assert parse_qs_bytes("a=Hello%20World!") == {"a": [b"Hello World!"]}

# Generated at 2022-06-22 03:34:04.739160
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt; &gt; &amp; &quot; &#39;") == "< > & \" '"


# to_basestring is used for ensuring a
# given value is either a str or unicode, using the default encoding utf-8

# Generated at 2022-06-22 03:34:14.849591
# Unit test for function recursive_unicode

# Generated at 2022-06-22 03:34:25.143653
# Unit test for function utf8
def test_utf8():
    assert utf8("foo") == b"foo"
    assert utf8("foo") is not "foo"
    assert utf8("foo") == utf8("foo")
    assert utf8("foo") is utf8("foo")
    assert utf8(u"foo") == b"foo"
    assert utf8(u"foo") is not u"foo"
    assert utf8(u"foo") == utf8(u"foo")
    assert utf8(u"foo") is utf8(u"foo")


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:34:28.625252
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    assert xhtml_unescape("&lt;") == "<"



# Generated at 2022-06-22 03:34:57.922313
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("a b    c  \n\n   \t d") == "a b c d"
    assert squeeze("a b    c  \n\n   \t d") != "a b c d "



# Generated at 2022-06-22 03:35:01.686555
# Unit test for function linkify
def test_linkify():
    import requests
    url = "https://baidu.com"
    t = linkify(url)
    print(t)

    t = linkify(t)
    print(t)

# Generated at 2022-06-22 03:35:03.628063
# Unit test for function utf8
def test_utf8():
    assert utf8(u"Ag\u00e9") == b"Ag\xc3\xa9"
    assert utf8(None) is None
    assert utf8(b"hello") == b"hello"


_TO_UNICODE_TYPES = (unicode_type, type(None))



# Generated at 2022-06-22 03:35:06.882256
# Unit test for function squeeze
def test_squeeze():
        string = r"Under the	moon	I see the	moon	shine under the	moon"
        assert(squeeze(string) == "Under the moon I see the moon shine under the moon")
test_squeeze()


# Generated at 2022-06-22 03:35:16.883364
# Unit test for function recursive_unicode
def test_recursive_unicode():
    o = {'foo': ['bar', 'baz', 1, None], 'quux': 'quuux', 1: 2}
    u = {'foo': ['bar', 'baz', 1, None], 'quux': 'quuux', 1: 2}
    uo = recursive_unicode(o)
    assert isinstance(uo, dict)
    assert isinstance(uo['foo'], list)
    assert isinstance(uo['quux'], str)
    assert o == u == uo
    test_recursive_unicode.called = True

test_recursive_unicode.called = False



# Generated at 2022-06-22 03:35:19.825552
# Unit test for function xhtml_escape
def test_xhtml_escape():
    assert xhtml_escape('<script>alert("hi")</script>') == '&lt;script&gt;alert(&quot;hi&quot;)&lt;/script&gt;'

# Generated at 2022-06-22 03:35:29.206639
# Unit test for function xhtml_unescape
def test_xhtml_unescape(): # type: () -> None
    xhtml_str = '&amp;<><&><><&><><&'
    new_xhtml_str = xhtml_unescape(xhtml_str)
    assert new_xhtml_str == '&<><&><><&><><&'
    print(new_xhtml_str)



# Generated at 2022-06-22 03:35:33.306380
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    s = 'a=1&b=2'
    t = parse_qs_bytes(s)
    print(t)
    # {'a': [b'1'], 'b': [b'2']}

#test_parse_qs_bytes()



# Generated at 2022-06-22 03:35:37.316817
# Unit test for function json_encode
def test_json_encode():
    assert \
    json_encode({"foo": "bar"}) == '{"foo": "bar"}'
    assert \
    json_encode({"foo": "</script>"}) == '{"foo": "<\\/script>"}'


# Generated at 2022-06-22 03:35:42.976021
# Unit test for function json_encode
def test_json_encode():
    value = 1
    x = json_encode(value)
    print(f"json_encode(1): {x}")


# json_encode = functools.partial(json.dumps, default=_default)
# test_json_encode()


# Generated at 2022-06-22 03:36:40.929262
# Unit test for function parse_qs_bytes
def test_parse_qs_bytes():
    pairs = ["test=test", "test2=test2", "test=test3&test4=test4"]
    for i in pairs:
        print("{}->{}".format(i, parse_qs_bytes(i)))



# Generated at 2022-06-22 03:36:44.407418
# Unit test for function squeeze
def test_squeeze():
    assert squeeze('       aaa 123') == 'aaa 123'
    assert squeeze('       aaa       123') == 'aaa 123'


# Generated at 2022-06-22 03:36:46.126794
# Unit test for function squeeze
def test_squeeze():
    assert squeeze("  abc")=="abc"


# Generated at 2022-06-22 03:36:53.028139
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    h = "&#264;&#265;&#266;&#267;&#268;&#269;&#270;&#271;&#272;"
    h = xhtml_unescape(h)
    assert h == "ĄąĆćĘęŁłŃńÓó"


# graciously borrowed from django's escape function
_HTML_ESCAPE_RE = re.compile(r"&(#?)(\w+?);")



# Generated at 2022-06-22 03:36:54.225759
# Unit test for function json_encode
def test_json_encode():
    assert json_encode({"he": "llo"}) == '{"he": "llo"}'



# Generated at 2022-06-22 03:37:05.272036
# Unit test for function url_unescape
def test_url_unescape():
    # https://stackoverflow.com/questions/18788982/checking-the-output-of-a-multi-overload-function-with-pytest-typing
    # https://stackoverflow.com/questions/40404021/check-if-type-of-return-value-in-python-is-str
    assert isinstance(url_unescape("abc"), str)
    assert isinstance(url_unescape("abc", encoding=None), bytes)
    assert isinstance(url_unescape("abc", encoding="ascii"), str)


_UTF8_TYPES = (bytes, type(None))
_TO_UNICODE_TYPES = (str, type(None))



# Generated at 2022-06-22 03:37:11.837410
# Unit test for function linkify
def test_linkify():
    assert linkify("http://example.com") == '<a href="http://example.com">example.com</a>'
    assert linkify("www.example.com") == '<a href="http://www.example.com">www.example.com</a>'
    assert linkify("foo@bar.com") == '<a href="mailto:foo@bar.com">foo@bar.com</a>'
    assert linkify("HTTP://EXAMPLE.COM") == '<a href="HTTP://EXAMPLE.COM">EXAMPLE.COM</a>'
    assert linkify("http://user@www.example.com") == '<a href="http://user@www.example.com">user@www.example.com</a>'

# Generated at 2022-06-22 03:37:16.765256
# Unit test for function url_escape
def test_url_escape():
    assert url_escape("https://www.python.org/") == "https%3A//www.python.org/"
    assert url_escape("https://www.python.org/", plus=False) == "https%3A//www.python.org/"
    assert url_escape("https://www.python.org/", plus=True) == "https%3A%2F%2Fwww.python.org%2F"



# Generated at 2022-06-22 03:37:20.995315
# Unit test for function recursive_unicode
def test_recursive_unicode():
    def _func():
        return recursive_unicode({b"a": [1, 2], "b": b"3"})
    assert _func() == {"a": [1, 2], "b": "3"}


# Generated at 2022-06-22 03:37:24.682839
# Unit test for function xhtml_unescape
def test_xhtml_unescape():
    res = xhtml_unescape('&#039;&#x27;&#39;&#039;')
    print(res)

test_xhtml_unescape()
